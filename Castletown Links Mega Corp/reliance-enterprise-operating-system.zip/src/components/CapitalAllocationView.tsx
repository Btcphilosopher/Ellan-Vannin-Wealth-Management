import React, { useState } from 'react';
import {
  DollarSign,
  TrendingUp,
  Sliders,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FileCheck,
  Shield,
  Layers,
  ArrowRight
} from 'lucide-react';
import { CapitalRequest, ScenarioType, RoleType } from '../types';

interface CapitalAllocationViewProps {
  capitalRequests: CapitalRequest[];
  onApproveRequest: (requestId: string, role: RoleType, reason: string) => void;
  displayModeLakhCrore: boolean;
  currentRole: RoleType;
}

export const CapitalAllocationView: React.FC<CapitalAllocationViewProps> = ({
  capitalRequests,
  onApproveRequest,
  displayModeLakhCrore,
  currentRole
}) => {
  const [selectedScenario, setSelectedScenario] = useState<ScenarioType>('BASE');
  const [selectedRequest, setSelectedRequest] = useState<CapitalRequest | null>(capitalRequests[0] || null);
  const [approvalReason, setApprovalReason] = useState<string>('');

  const scenarios: { type: ScenarioType; label: string; desc: string }[] = [
    { type: 'BASE', label: 'Base Case', desc: 'Standard market assumptions' },
    { type: 'UPSIDE', label: 'Upside Demand', desc: '+15% volume expansion & higher margins' },
    { type: 'DOWNSIDE', label: 'Downside Risk', desc: '-15% commodity price contraction' },
    { type: 'STRESS', label: 'Macro Stress', desc: '-30% cashflow shock & high interest rate' },
    { type: 'TRANSITION', label: 'Green Transition', desc: 'Accelerated carbon cost & green subsidy' }
  ];

  // Apply scenario multiplier to metrics for model display
  const getScenarioAdjustedMetrics = (req: CapitalRequest) => {
    let mult = 1.0;
    if (selectedScenario === 'UPSIDE') mult = 1.18;
    if (selectedScenario === 'DOWNSIDE') mult = 0.82;
    if (selectedScenario === 'STRESS') mult = 0.65;
    if (selectedScenario === 'TRANSITION') mult = 1.08;

    return {
      npv: Math.round(req.npvCrores * mult),
      irr: (req.irrPercentage * mult).toFixed(1),
      roic: (req.roicPercentage * mult).toFixed(1),
      payback: (req.paybackYears / Math.sqrt(mult)).toFixed(1),
      riskReturn: (req.riskAdjustedReturn * mult).toFixed(1)
    };
  };

  const handleApprove = (reqId: string) => {
    onApproveRequest(reqId, currentRole, approvalReason || 'Approved by executive authority');
    setApprovalReason('');
  };

  return (
    <div className="space-y-6">
      {/* Capital Allocation Engine Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <span className="p-2 bg-emerald-950 border border-emerald-800 rounded-lg text-emerald-400">
              <DollarSign className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-100 font-mono tracking-wide">
                CAPITAL ALLOCATION SUBSYSTEM
              </h2>
              <p className="text-xs text-slate-400">
                Exact Decimal Arithmetic • IRR / NPV / ROIC / Payback • Dynamic Scenario Shock Simulator
              </p>
            </div>
          </div>
        </div>

        {/* Total Capital Deployed Badge */}
        <div className="bg-slate-950 px-4 py-2.5 rounded-lg border border-slate-800 flex items-center space-x-4 font-mono text-xs">
          <div>
            <div className="text-slate-400 text-[10px]">TOTAL GROUP CAPEX POOL</div>
            <div className="text-emerald-400 font-bold text-base">₹1,25,000 Cr</div>
          </div>
          <div className="h-8 w-[1px] bg-slate-800" />
          <div>
            <div className="text-slate-400 text-[10px]">MIN HURDLE RATE</div>
            <div className="text-amber-400 font-bold text-base">14.0% ROIC</div>
          </div>
        </div>
      </div>

      {/* Scenario Model Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-xs font-bold text-slate-300 font-mono flex items-center gap-2 uppercase tracking-wider">
            <Sliders className="w-4 h-4 text-amber-400" />
            SELECT SCENARIO RETURN MODEL
          </h3>
          <span className="text-[11px] text-slate-400 font-mono">Decimal Precision Active</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
          {scenarios.map((sc) => {
            const isSelected = selectedScenario === sc.type;
            return (
              <button
                key={sc.type}
                onClick={() => setSelectedScenario(sc.type)}
                className={`p-3 rounded-lg border text-left transition ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 border-amber-400 font-bold shadow-md shadow-amber-500/20'
                    : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                }`}
              >
                <div className="text-xs font-mono font-bold">{sc.label}</div>
                <div className={`text-[10px] mt-1 ${isSelected ? 'text-slate-900' : 'text-slate-400'}`}>
                  {sc.desc}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Capital Requests List & Selected Detail Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Requests Table */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-200 font-mono flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-400" />
              CAPITAL ALLOCATION REQUESTS ({capitalRequests.length})
            </h3>
            <span className="text-xs text-slate-400 font-mono">Scenario: {selectedScenario}</span>
          </div>

          <div className="space-y-3">
            {capitalRequests.map((req) => {
              const adj = getScenarioAdjustedMetrics(req);
              const isSelected = selectedRequest?.id === req.id;
              return (
                <div
                  key={req.id}
                  onClick={() => setSelectedRequest(req)}
                  className={`p-4 rounded-xl border text-left transition cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800 border-amber-500 ring-1 ring-amber-500/50 shadow-md'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[11px] font-mono bg-blue-950 text-blue-300 border border-blue-800 px-2.5 py-0.5 rounded">
                      {req.category} • {req.businessUnit}
                    </span>
                    <span
                      className={`text-[11px] font-mono font-bold px-2 py-0.5 rounded ${
                        req.status === 'BOARD_APPROVED'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : req.status === 'COMMITTED'
                          ? 'bg-blue-950 text-blue-400 border border-blue-800'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                      }`}
                    >
                      {req.status}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-100 mb-2">{req.title}</h4>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs font-mono pt-2 border-t border-slate-800/80">
                    <div>
                      <div className="text-slate-400 text-[10px]">CAPEX REQUEST</div>
                      <div className="text-emerald-400 font-bold">₹{req.amountCrores.toLocaleString('en-IN')} Cr</div>
                    </div>
                    <div>
                      <div className="text-slate-400 text-[10px]">SCENARIO NPV</div>
                      <div className="text-slate-200 font-bold">₹{adj.npv.toLocaleString('en-IN')} Cr</div>
                    </div>
                    <div>
                      <div className="text-slate-400 text-[10px]">SCENARIO IRR</div>
                      <div className="text-amber-400 font-bold">{adj.irr}%</div>
                    </div>
                    <div>
                      <div className="text-slate-400 text-[10px]">PAYBACK</div>
                      <div className="text-slate-300 font-bold">{adj.payback} Yrs</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Capital Approval Panel & Detailed Financials */}
        {selectedRequest && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <span className="text-[10px] font-mono bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded uppercase">
                EXECUTIVE RETURN MODEL & APPROVAL
              </span>
              <h3 className="text-lg font-bold text-slate-100 font-mono mt-2">{selectedRequest.title}</h3>
              <p className="text-xs text-slate-400 font-mono">Requested by {selectedRequest.requestedBy} on {selectedRequest.date}</p>
            </div>

            <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-3 font-mono text-xs">
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">CapEx Outlay:</span>
                <strong className="text-emerald-400 text-sm">₹{selectedRequest.amountCrores.toLocaleString('en-IN')} Cr</strong>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Funding Source:</span>
                <strong className="text-slate-200">{selectedRequest.fundingSource}</strong>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Carbon Abatement Impact:</span>
                <strong className="text-emerald-400">{selectedRequest.carbonImpactTons.toLocaleString()} tCO2e / yr</strong>
              </div>
              <div className="flex justify-between border-b border-slate-800/80 pb-2">
                <span className="text-slate-400">Base Return on Capital (ROIC):</span>
                <strong className="text-amber-400">{selectedRequest.roicPercentage}%</strong>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Risk-Adjusted Return Index:</span>
                <strong className="text-slate-200">{selectedRequest.riskAdjustedReturn}</strong>
              </div>
            </div>

            {selectedRequest.status !== 'BOARD_APPROVED' ? (
              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-bold text-slate-300 uppercase font-mono">EXECUTIVE APPROVAL ACTION</h4>
                <textarea
                  value={approvalReason}
                  onChange={(e) => setApprovalReason(e.target.value)}
                  placeholder="Enter board approval justification or risk review comments..."
                  className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-slate-200 outline-none focus:border-amber-500 font-mono"
                  rows={3}
                />
                <button
                  onClick={() => handleApprove(selectedRequest.id)}
                  className="w-full py-2.5 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-slate-950 font-bold rounded-lg text-xs font-mono uppercase tracking-wider transition shadow-lg shadow-emerald-950/40 flex items-center justify-center gap-2"
                >
                  <FileCheck className="w-4 h-4" />
                  Grant Board Approval & Commit CapEx (Role: {currentRole})
                </button>
              </div>
            ) : (
              <div className="bg-emerald-950/50 border border-emerald-800/80 p-3.5 rounded-lg text-xs font-mono text-emerald-300 flex items-center space-x-2">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <span>Board Approval Granted & Committed to Group Ledger</span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
