import React, { useState } from 'react';
import {
  Radio,
  Wifi,
  AlertOctagon,
  CheckCircle,
  Clock,
  UserCheck,
  Zap,
  Activity,
  ChevronRight,
  ShieldCheck,
  Server
} from 'lucide-react';
import { NetworkSite, NetworkIncident, RoleType } from '../types';

interface TelecomNocViewProps {
  sites: NetworkSite[];
  incidents: NetworkIncident[];
  onUpdateIncidentStatus: (incidentId: string, newStatus: any, engineer: string, reason: string) => void;
  currentRole: RoleType;
}

export const TelecomNocView: React.FC<TelecomNocViewProps> = ({
  sites,
  incidents,
  onUpdateIncidentStatus,
  currentRole
}) => {
  const [selectedIncident, setSelectedIncident] = useState<NetworkIncident | null>(incidents[0] || null);
  const [targetStatus, setTargetStatus] = useState<string>('RESOLVED');

  const handleUpdate = (incId: string) => {
    onUpdateIncidentStatus(
      incId,
      targetStatus,
      'R. Iyengar (NOC Level-3 Lead)',
      'Field dispatch verified fiber splicing restored secondary ring'
    );
  };

  return (
    <div className="space-y-6">
      {/* NOC Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <span className="p-2 bg-blue-950 border border-blue-800 rounded-lg text-blue-400">
              <Radio className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-100 font-mono tracking-wide">
                JIO 4G/5G NETWORK OPERATIONS CENTRE (NOC)
              </h2>
              <p className="text-xs text-slate-400">
                Radio Access Network (RAN) • Fiber Backhaul • 5G Core Network • Incident Triage Lifecycle
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-4 font-mono text-xs">
          <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <span className="text-slate-400">ACTIVE TOWERS:</span> <strong className="text-emerald-400">480,000</strong>
          </div>
          <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <span className="text-slate-400">DAILY TRAFFIC:</span> <strong className="text-blue-400">412 PB/day</strong>
          </div>
        </div>
      </div>

      {/* Network Sites Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-slate-200 font-mono flex items-center gap-2 border-b border-slate-800 pb-3">
          <Wifi className="w-4 h-4 text-emerald-400" />
          TELECOM CIRCLE MACRO & 5G GIGA SITES
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {sites.map((site) => (
            <div
              key={site.siteId}
              className="bg-slate-950 border border-slate-800/80 rounded-lg p-4 font-mono space-y-2"
            >
              <div className="flex items-center justify-between text-xs">
                <span className="bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded text-[10px] font-bold">
                  {site.circle} • {site.towerType}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                    site.status === 'OPTIMAL'
                      ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      : 'bg-amber-950 text-amber-400 border border-amber-800'
                  }`}
                >
                  {site.status}
                </span>
              </div>

              <h4 className="text-xs font-bold text-slate-100">{site.name}</h4>

              <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 pt-1 border-t border-slate-800">
                <div>
                  Users: <strong className="text-slate-200">{site.activeUsers.toLocaleString()}</strong>
                </div>
                <div>
                  Traffic: <strong className="text-emerald-400">{site.trafficGbps} Gbps</strong>
                </div>
                <div>
                  Latency: <strong className="text-blue-400">{site.latencyMs} ms</strong>
                </div>
                <div>
                  Backhaul: <strong className="text-slate-300">{site.backhaulType}</strong>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Incident Triage Lifecycle Manager */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-200 font-mono flex items-center gap-2">
              <AlertOctagon className="w-4 h-4 text-rose-400" />
              NOC INCIDENT TICKETS ({incidents.length})
            </h3>
            <span className="text-xs text-slate-400 font-mono">Workflow: DETECTED → RESOLVED</span>
          </div>

          <div className="space-y-3">
            {incidents.map((inc) => {
              const isSelected = selectedIncident?.incidentId === inc.incidentId;
              return (
                <div
                  key={inc.incidentId}
                  onClick={() => setSelectedIncident(inc)}
                  className={`p-4 rounded-xl border font-mono text-xs transition cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800 border-amber-500 ring-1 ring-amber-500 shadow-md'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="bg-rose-950 text-rose-400 border border-rose-800 text-[10px] font-bold px-2 py-0.5 rounded">
                      SEVERITY: {inc.severity}
                    </span>
                    <span className="text-amber-400 font-bold bg-amber-950/60 border border-amber-800 px-2 py-0.5 rounded text-[10px]">
                      STATUS: {inc.status}
                    </span>
                  </div>

                  <h4 className="text-sm font-bold text-slate-100 mb-1">{inc.title}</h4>
                  <p className="text-slate-400 text-[11px] mb-2">{inc.rootCause}</p>

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800">
                    <span>Assigned: <strong className="text-slate-200">{inc.assignedEngineer}</strong></span>
                    <span>Subscribers Impacted: <strong className="text-rose-400">{inc.affectedSubscribers.toLocaleString()}</strong></span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Incident Update Form */}
        {selectedIncident && (
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            <div className="border-b border-slate-800 pb-3">
              <span className="text-[10px] font-mono bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded uppercase font-bold">
                INCIDENT STATE MANAGER
              </span>
              <h3 className="text-base font-bold text-slate-100 font-mono mt-2">{selectedIncident.title}</h3>
              <p className="text-xs text-slate-400 font-mono">Ticket #{selectedIncident.incidentId}</p>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <label className="text-slate-400">Set Target Status:</label>
              <select
                value={targetStatus}
                onChange={(e) => setTargetStatus(e.target.value)}
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2.5 text-amber-400 outline-none font-bold"
              >
                <option value="INVESTIGATING">INVESTIGATING</option>
                <option value="MITIGATING">MITIGATING</option>
                <option value="RESOLVED">RESOLVED</option>
                <option value="VERIFIED">VERIFIED</option>
                <option value="CLOSED">CLOSED</option>
              </select>

              <button
                onClick={() => handleUpdate(selectedIncident.incidentId)}
                className="w-full py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-slate-100 font-bold rounded-lg text-xs font-mono uppercase tracking-wider transition shadow-lg shadow-blue-950/40 flex items-center justify-center gap-2"
              >
                <CheckCircle className="w-4 h-4" />
                Update Ticket Status
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
