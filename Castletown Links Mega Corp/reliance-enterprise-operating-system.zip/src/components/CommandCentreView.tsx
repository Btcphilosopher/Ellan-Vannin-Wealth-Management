import React, { useState } from 'react';
import {
  TrendingUp,
  Activity,
  Zap,
  Radio,
  ShoppingBag,
  DollarSign,
  ShieldCheck,
  Flame,
  Cpu,
  Leaf,
  Layers,
  ExternalLink,
  ChevronRight,
  Database,
  ArrowUpRight,
  ArrowDownRight
} from 'lucide-react';
import { GroupKPI, BusinessEntity, IndianLanguage } from '../types';

interface CommandCentreViewProps {
  kpis: GroupKPI[];
  businesses: BusinessEntity[];
  displayModeLakhCrore: boolean;
  language: IndianLanguage;
  onSelectSubdomain: (domain: string) => void;
}

export const CommandCentreView: React.FC<CommandCentreViewProps> = ({
  kpis,
  businesses,
  displayModeLakhCrore,
  language,
  onSelectSubdomain
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('GROUP');

  const categories = [
    { id: 'GROUP', label: 'Group Consolidated', icon: Layers },
    { id: 'O2C', label: 'Oil-to-Chemicals (O2C)', icon: Flame },
    { id: 'NEW_ENERGY', label: 'New Energy Giga Hub', icon: Zap },
    { id: 'TELECOM', label: 'Jio 5G Telecom', icon: Radio },
    { id: 'RETAIL', label: 'Reliance Retail', icon: ShoppingBag },
    { id: 'CLOUD', label: 'Jio Cloud & AI', icon: Cpu },
    { id: 'FINANCE', label: 'Capital & Treasury', icon: DollarSign },
    { id: 'SUSTAINABILITY', label: 'ESG & Net-Zero', icon: Leaf }
  ];

  // Helper to format currency values based on Lakh/Crore setting
  const formatVal = (kpi: GroupKPI) => {
    if (kpi.unit === '₹ Crores' || kpi.unit.includes('Crores')) {
      if (displayModeLakhCrore && kpi.displayLakhCrore) {
        return kpi.displayLakhCrore;
      }
      return `₹${kpi.value.toLocaleString('en-IN')} Cr`;
    }
    return `${kpi.value.toLocaleString('en-IN')} ${kpi.unit}`;
  };

  return (
    <div className="space-[#121824] space-y-6">
      {/* Executive Command Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <span className="p-2 bg-blue-950/80 border border-blue-800/80 rounded-lg text-blue-400">
              <Activity className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-100 tracking-wide font-mono">
                GROUP EXECUTIVE COMMAND CENTRE
              </h2>
              <p className="text-xs text-slate-400">
                Unified Computational Engine • Real-time Traceable Source Audit
              </p>
            </div>
          </div>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex flex-wrap gap-1.5 bg-slate-950 p-1.5 rounded-lg border border-slate-800">
          {categories.map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition ${
                  isSelected
                    ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {kpis.map((kpi) => (
          <div
            key={kpi.id}
            className="bg-slate-900 border border-slate-800 rounded-xl p-4 hover:border-slate-700 transition relative overflow-hidden group"
          >
            <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
              <span className="font-mono text-[11px] uppercase tracking-wider text-slate-400">
                {kpi.category}
              </span>
              <span className="flex items-center gap-1 font-mono text-[11px] bg-slate-800 text-slate-300 px-2 py-0.5 rounded">
                <Database className="w-3 h-3 text-amber-400" />
                {kpi.sourceRecord}
              </span>
            </div>

            <h3 className="text-sm font-semibold text-slate-200 mb-1">{kpi.name}</h3>

            <div className="flex items-baseline justify-between mt-2">
              <span className="text-xl font-bold font-mono text-slate-100 tracking-tight">
                {formatVal(kpi)}
              </span>
              <span
                className={`text-xs font-semibold px-2 py-0.5 rounded flex items-center gap-0.5 ${
                  kpi.changePct >= 0
                    ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/50'
                    : 'bg-rose-950 text-rose-400 border border-rose-800/50'
                }`}
              >
                {kpi.changePct >= 0 ? (
                  <ArrowUpRight className="w-3.5 h-3.5" />
                ) : (
                  <ArrowDownRight className="w-3.5 h-3.5" />
                )}
                {Math.abs(kpi.changePct)}%
              </span>
            </div>

            <div className="mt-3 pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                Status: <strong className="text-slate-300">{kpi.status}</strong>
              </span>
              <span className="text-amber-400/80 group-hover:text-amber-300 transition flex items-center gap-0.5">
                Trace Record <ChevronRight className="w-3 h-3" />
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Business Entities Portfolio Summary */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold text-slate-100 font-mono flex items-center gap-2">
              <Layers className="w-4 h-4 text-blue-400" />
              CONGLOMERATE BUSINESS ENTITIES PORTFOLIO
            </h3>
            <p className="text-xs text-slate-400">
              12 Operating Sub-groups • Legal Entity, Cost Centre & Management Hierarchy
            </p>
          </div>
          <span className="text-xs font-mono bg-blue-950 text-blue-300 border border-blue-800 px-3 py-1 rounded-md">
            148 Subsidiaries Consolidated
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-950 text-slate-400 uppercase font-mono text-[11px]">
              <tr>
                <th className="px-4 py-3">Business Unit</th>
                <th className="px-4 py-3">Legal Entity</th>
                <th className="px-4 py-3">HQ Location</th>
                <th className="px-4 py-3 text-right">Revenue (Cr)</th>
                <th className="px-4 py-3 text-right">EBITDA (Cr)</th>
                <th className="px-4 py-3 text-right">Asset Base</th>
                <th className="px-4 py-3 text-right">Workforce</th>
                <th className="px-4 py-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 font-mono">
              {businesses.map((biz) => (
                <tr key={biz.id} className="hover:bg-slate-800/50 transition">
                  <td className="px-4 py-3 font-semibold text-slate-100 flex items-center space-x-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400" />
                    <span>{biz.name}</span>
                  </td>
                  <td className="px-4 py-3 text-slate-400">{biz.legalEntity}</td>
                  <td className="px-4 py-3 text-slate-400">{biz.headquarters}</td>
                  <td className="px-4 py-3 text-right font-bold text-emerald-400">
                    ₹{biz.revenueCrores.toLocaleString('en-IN')} Cr
                  </td>
                  <td className="px-4 py-3 text-right font-bold text-slate-200">
                    ₹{biz.ebitdaCrores.toLocaleString('en-IN')} Cr
                  </td>
                  <td className="px-4 py-3 text-right text-slate-300">
                    ₹{biz.assetValueCrores.toLocaleString('en-IN')} Cr
                  </td>
                  <td className="px-4 py-3 text-right text-slate-400">
                    {biz.employeeCount.toLocaleString('en-IN')}
                  </td>
                  <td className="px-4 py-3 text-center">
                    <button
                      onClick={() => onSelectSubdomain(biz.category)}
                      className="px-2.5 py-1 bg-slate-800 hover:bg-amber-500 hover:text-slate-950 text-amber-400 rounded transition font-semibold text-[11px] inline-flex items-center gap-1"
                    >
                      <span>Drilldown</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
