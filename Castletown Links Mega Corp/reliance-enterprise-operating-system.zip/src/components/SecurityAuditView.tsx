import React from 'react';
import {
  ShieldCheck,
  Lock,
  Terminal,
  FileText,
  ShieldAlert,
  CheckCircle2,
  Key,
  Database,
  Layers
} from 'lucide-react';
import { AuditRecord } from '../types';

interface SecurityAuditViewProps {
  auditTrail: AuditRecord[];
}

export const SecurityAuditView: React.FC<SecurityAuditViewProps> = ({ auditTrail }) => {
  return (
    <div className="space-y-6 font-mono">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <span className="p-2 bg-emerald-950 border border-emerald-800 rounded-lg text-emerald-400">
              <ShieldCheck className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-100 tracking-wide">
                CYBERSECURITY & IMMUTABLE AUDIT TRAIL
              </h2>
              <p className="text-xs text-slate-400">
                OT Command Gateway • ABAC / RBAC Policy Engine • Cryptographic Log Ledger
              </p>
            </div>
          </div>
        </div>

        <div className="bg-emerald-950/60 border border-emerald-800 px-3 py-1.5 rounded-lg text-xs text-emerald-300 flex items-center gap-1.5">
          <Lock className="w-4 h-4 text-emerald-400" />
          <span>OT Airgap Policy: STRICT ENFORCED</span>
        </div>
      </div>

      {/* Action Chain Visualizer */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3 text-xs">
        <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-2 uppercase tracking-wider">
          ENFORCED ACTION AUTHORIZATION CHAIN
        </h3>
        <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 flex items-center justify-between overflow-x-auto whitespace-nowrap text-slate-300 gap-2">
          <span className="px-3 py-1 bg-slate-900 border border-slate-700 rounded text-amber-400 font-bold">1. USER</span>
          <span>→</span>
          <span className="px-3 py-1 bg-slate-900 border border-slate-700 rounded text-blue-400 font-bold">2. DEVICE</span>
          <span>→</span>
          <span className="px-3 py-1 bg-slate-900 border border-slate-700 rounded text-purple-400 font-bold">3. IDENTITY</span>
          <span>→</span>
          <span className="px-3 py-1 bg-slate-900 border border-slate-700 rounded text-amber-300 font-bold">4. POLICY</span>
          <span>→</span>
          <span className="px-3 py-1 bg-slate-900 border border-slate-700 rounded text-rose-400 font-bold">5. AUTHORIZATION</span>
          <span>→</span>
          <span className="px-3 py-1 bg-slate-900 border border-slate-700 rounded text-emerald-400 font-bold">6. ACTION</span>
          <span>→</span>
          <span className="px-3 py-1 bg-slate-900 border border-emerald-800 rounded text-emerald-300 font-bold">7. AUDIT LEDGER</span>
        </div>
      </div>

      {/* Audit Log Records Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-3 flex items-center gap-2">
          <FileText className="w-4 h-4 text-amber-400" />
          IMMUTABLE ENTERPRISE AUDIT TRAIL ({auditTrail.length})
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-slate-400 uppercase text-[11px]">
              <tr>
                <th className="px-4 py-3">Timestamp / Audit ID</th>
                <th className="px-4 py-3">User & Role</th>
                <th className="px-4 py-3">Action</th>
                <th className="px-4 py-3">Target Object</th>
                <th className="px-4 py-3">Reason</th>
                <th className="px-4 py-3 text-right">Correlation ID</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80">
              {auditTrail.map((log) => (
                <tr key={log.auditId} className="hover:bg-slate-800/50 transition">
                  <td className="px-4 py-3 text-slate-300 font-semibold">
                    <div>{log.auditId}</div>
                    <div className="text-[10px] text-slate-400">{log.timestamp}</div>
                  </td>
                  <td className="px-4 py-3">
                    <div className="text-amber-300 font-bold">{log.userName}</div>
                    <div className="text-[10px] text-slate-400">{log.userRole}</div>
                  </td>
                  <td className="px-4 py-3 text-emerald-400 font-bold">{log.action}</td>
                  <td className="px-4 py-3 text-slate-200">{log.targetObject}</td>
                  <td className="px-4 py-3 text-slate-400 text-[11px] max-w-[200px] truncate">{log.reason}</td>
                  <td className="px-4 py-3 text-right text-slate-300 font-bold">{log.correlationId}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
