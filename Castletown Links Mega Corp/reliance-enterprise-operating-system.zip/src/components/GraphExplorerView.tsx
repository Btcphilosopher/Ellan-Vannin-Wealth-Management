import React, { useState } from 'react';
import {
  Share2,
  ArrowRight,
  Zap,
  Flame,
  Radio,
  ShoppingBag,
  Cpu,
  Layers,
  Database,
  ShieldCheck,
  CheckCircle2
} from 'lucide-react';
import { GraphNode, GraphEdge } from '../types';

interface GraphExplorerViewProps {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export const GraphExplorerView: React.FC<GraphExplorerViewProps> = ({ nodes, edges }) => {
  const [selectedNodeId, setSelectedNodeId] = useState<string>(nodes[0]?.id || 'GN-CAPITAL');

  const selectedNode = nodes.find((n) => n.id === selectedNodeId) || nodes[0];
  const connectedEdges = edges.filter(
    (e) => e.sourceId === selectedNodeId || e.targetId === selectedNodeId
  );

  const getCategoryBadge = (cat: string) => {
    switch (cat) {
      case 'O2C':
        return 'bg-amber-950 text-amber-300 border-amber-700';
      case 'OIL_GAS':
        return 'bg-orange-950 text-orange-300 border-orange-700';
      case 'NEW_ENERGY':
        return 'bg-emerald-950 text-emerald-300 border-emerald-700';
      case 'TELECOM':
        return 'bg-blue-950 text-blue-300 border-blue-700';
      case 'CLOUD':
        return 'bg-purple-950 text-purple-300 border-purple-700';
      case 'RETAIL':
        return 'bg-rose-950 text-rose-300 border-rose-700';
      case 'AI_PLATFORM':
        return 'bg-cyan-950 text-cyan-300 border-cyan-700';
      default:
        return 'bg-slate-800 text-slate-300 border-slate-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <span className="p-2 bg-indigo-950 border border-indigo-800 rounded-lg text-indigo-400">
              <Share2 className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-100 font-mono tracking-wide">
                CANONICAL ENTERPRISE BUSINESS GRAPH
              </h2>
              <p className="text-xs text-slate-400">
                Intersecting Physical Industrial Economy + Digital Network Economy + Consumer Economy + Financial Capital
              </p>
            </div>
          </div>
        </div>

        {/* Fundamental Graph Chain Indicator */}
        <div className="bg-slate-950 px-4 py-2 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto whitespace-nowrap flex items-center space-x-1.5">
          <span className="text-amber-400 font-bold">CAPITAL</span>
          <ArrowRight className="w-3 h-3 text-slate-500" />
          <span>ENTERPRISE</span>
          <ArrowRight className="w-3 h-3 text-slate-500" />
          <span>BUSINESSES</span>
          <ArrowRight className="w-3 h-3 text-slate-500" />
          <span>ASSETS</span>
          <ArrowRight className="w-3 h-3 text-slate-500" />
          <span>NETWORKS</span>
          <ArrowRight className="w-3 h-3 text-slate-500" />
          <span>PLATFORMS</span>
          <ArrowRight className="w-3 h-3 text-slate-500" />
          <span>PRODUCTS</span>
          <ArrowRight className="w-3 h-3 text-slate-500" />
          <span>CUSTOMERS</span>
          <ArrowRight className="w-3 h-3 text-slate-500" />
          <span className="text-emerald-400 font-bold">DECISIONS</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Graph Nodes Visual Grid */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 className="text-sm font-bold text-slate-200 font-mono flex items-center gap-2">
              <Layers className="w-4 h-4 text-amber-400" />
              INTERSECTING ENTERPRISE NODES ({nodes.length})
            </h3>
            <span className="text-xs text-slate-400 font-mono">Select node to inspect telemetry & flows</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
            {nodes.map((node) => {
              const isSelected = node.id === selectedNodeId;
              return (
                <button
                  key={node.id}
                  onClick={() => setSelectedNodeId(node.id)}
                  className={`p-3.5 rounded-lg border text-left transition relative ${
                    isSelected
                      ? 'bg-slate-800 border-amber-500 ring-1 ring-amber-500/50 shadow-lg shadow-amber-500/10'
                      : 'bg-slate-950 border-slate-800 hover:border-slate-700 hover:bg-slate-900'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded border uppercase font-semibold ${getCategoryBadge(
                        node.category
                      )}`}
                    >
                      {node.category}
                    </span>
                    <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  </div>

                  <h4 className="text-xs font-bold text-slate-100 mb-1">{node.name}</h4>
                  <p className="text-[11px] text-slate-400 font-mono mb-2">{node.type}</p>

                  <div className="pt-2 border-t border-slate-800/60 flex items-center justify-between text-[11px] text-amber-400/90 font-mono">
                    <span>{node.metricsSummary}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Node Details & Connected Edges Inspector */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="border-b border-slate-800 pb-3">
            <span className="text-[10px] font-mono bg-amber-950 text-amber-300 border border-amber-800 px-2 py-0.5 rounded uppercase">
              NODE INSPECTOR
            </span>
            <h3 className="text-lg font-bold text-slate-100 font-mono mt-2">{selectedNode.name}</h3>
            <p className="text-xs text-slate-400 font-mono">{selectedNode.type} • Status: {selectedNode.status}</p>
          </div>

          <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg space-y-2">
            <div className="text-xs text-slate-400 font-mono flex items-center justify-between">
              <span>Node ID:</span>
              <strong className="text-slate-200">{selectedNode.id}</strong>
            </div>
            <div className="text-xs text-slate-400 font-mono flex items-center justify-between">
              <span>Category:</span>
              <strong className="text-amber-400">{selectedNode.category}</strong>
            </div>
            <div className="text-xs text-slate-400 font-mono flex items-center justify-between">
              <span>Live Rate:</span>
              <strong className="text-emerald-400">{selectedNode.metricsSummary}</strong>
            </div>
          </div>

          <div className="space-y-3 pt-2">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono">
              ACTIVE DOMAIN FLOW CONNECTIONS ({connectedEdges.length})
            </h4>

            {connectedEdges.map((edge) => {
              const source = nodes.find((n) => n.id === edge.sourceId);
              const target = nodes.find((n) => n.id === edge.targetId);
              return (
                <div
                  key={edge.id}
                  className="bg-slate-950 border border-slate-800/80 rounded-lg p-3 text-xs font-mono space-y-2"
                >
                  <div className="flex items-center justify-between text-slate-400 text-[11px]">
                    <span className="text-amber-400 font-bold">{edge.flowType}</span>
                    <span className="text-emerald-400">{edge.volumeToday}</span>
                  </div>

                  <div className="flex items-center justify-between font-semibold text-slate-200">
                    <span className="truncate max-w-[110px]">{source?.name}</span>
                    <ArrowRight className="w-4 h-4 text-blue-400 flex-shrink-0" />
                    <span className="truncate max-w-[110px]">{target?.name}</span>
                  </div>

                  <div className="text-[10px] text-slate-400 pt-1 border-t border-slate-800/60 flex items-center justify-between">
                    <span>Capacity Rate:</span>
                    <strong className="text-slate-300">{edge.capacityRate}</strong>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};
