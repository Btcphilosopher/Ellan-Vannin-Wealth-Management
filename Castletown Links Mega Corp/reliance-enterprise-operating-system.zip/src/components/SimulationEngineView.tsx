import React, { useState } from 'react';
import {
  Sliders,
  Play,
  TrendingUp,
  AlertTriangle,
  RefreshCw,
  Zap,
  DollarSign,
  Activity,
  Layers,
  ArrowRight
} from 'lucide-react';
import { SimulationScenario, SimulationResult } from '../types';

export const SimulationEngineView: React.FC = () => {
  const [scenario, setScenario] = useState<SimulationScenario>({
    id: 'SIM-001',
    name: 'Global Oil Spike + 5G Network Traffic Surge',
    oilPriceChangePct: 20,
    gasProductionChangePct: -10,
    retailDemandChangePct: 15,
    networkTrafficMultiplier: 2.0,
    inrUsdExchangeRate: 84.50,
    solarEfficiencyDeltaPct: 2.5
  });

  const [result, setResult] = useState<SimulationResult | null>(null);
  const [loading, setLoading] = useState<boolean>(false);

  const handleRunSimulation = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/simulation/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ scenario })
      });
      const data = await res.json();
      setResult(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 font-mono">
      {/* Simulation Engine Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <span className="p-2 bg-amber-950 border border-amber-800 rounded-lg text-amber-400">
              <Sliders className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-100 tracking-wide">
                ENTERPRISE SCENARIO & MACRO SHOCK SIMULATION
              </h2>
              <p className="text-xs text-slate-400">
                Monte Carlo Shocks • Oil Prices • Network Surge • FX Volatility • Reinvestment Impact
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={handleRunSimulation}
          disabled={loading}
          className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-bold rounded-lg text-xs uppercase tracking-wider transition shadow-lg shadow-amber-950/40 flex items-center justify-center gap-2"
        >
          <Play className="w-4 h-4" />
          {loading ? 'Simulating Graph...' : 'Execute Scenario Shock'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sliders Input Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-3 flex items-center gap-2">
            <Sliders className="w-4 h-4 text-amber-400" />
            SHOCK PARAMETER INPUTS
          </h3>

          <div className="space-y-4 text-xs">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-400">Oil Price Change:</span>
                <strong className={scenario.oilPriceChangePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  {scenario.oilPriceChangePct > 0 ? '+' : ''}{scenario.oilPriceChangePct}%
                </strong>
              </div>
              <input
                type="range"
                min="-30"
                max="50"
                value={scenario.oilPriceChangePct}
                onChange={(e) => setScenario({ ...scenario, oilPriceChangePct: Number(e.target.value) })}
                className="w-full bg-slate-950 h-2 rounded-lg cursor-pointer accent-amber-400"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-400">Gas Production Change:</span>
                <strong className={scenario.gasProductionChangePct >= 0 ? 'text-emerald-400' : 'text-rose-400'}>
                  {scenario.gasProductionChangePct}%
                </strong>
              </div>
              <input
                type="range"
                min="-40"
                max="20"
                value={scenario.gasProductionChangePct}
                onChange={(e) => setScenario({ ...scenario, gasProductionChangePct: Number(e.target.value) })}
                className="w-full bg-slate-950 h-2 rounded-lg cursor-pointer accent-orange-400"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-400">Retail Festive Demand:</span>
                <strong className="text-emerald-400">+{scenario.retailDemandChangePct}%</strong>
              </div>
              <input
                type="range"
                min="-10"
                max="40"
                value={scenario.retailDemandChangePct}
                onChange={(e) => setScenario({ ...scenario, retailDemandChangePct: Number(e.target.value) })}
                className="w-full bg-slate-950 h-2 rounded-lg cursor-pointer accent-emerald-400"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-400">Jio Network Traffic Surge:</span>
                <strong className="text-blue-400">{scenario.networkTrafficMultiplier}x Peak</strong>
              </div>
              <input
                type="range"
                min="1.0"
                max="4.0"
                step="0.1"
                value={scenario.networkTrafficMultiplier}
                onChange={(e) => setScenario({ ...scenario, networkTrafficMultiplier: Number(e.target.value) })}
                className="w-full bg-slate-950 h-2 rounded-lg cursor-pointer accent-blue-400"
              />
            </div>

            <div>
              <div className="flex justify-between mb-1">
                <span className="text-slate-400">INR / USD Exchange Rate:</span>
                <strong className="text-slate-200">₹{scenario.inrUsdExchangeRate} / $</strong>
              </div>
              <input
                type="range"
                min="78.00"
                max="92.00"
                step="0.25"
                value={scenario.inrUsdExchangeRate}
                onChange={(e) => setScenario({ ...scenario, inrUsdExchangeRate: Number(e.target.value) })}
                className="w-full bg-slate-950 h-2 rounded-lg cursor-pointer accent-purple-400"
              />
            </div>
          </div>
        </div>

        {/* Simulation Calculated Results Output */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-3 flex items-center gap-2">
            <Activity className="w-4 h-4 text-emerald-400" />
            PROJECTED GRAPH IMPACT METRICS
          </h3>

          {result ? (
            <div className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl">
                  <div className="text-slate-400 text-[10px]">PROJECTED REVENUE</div>
                  <div className="text-emerald-400 font-bold text-lg mt-1">
                    ₹{result.projectedRevenueCrores.toLocaleString('en-IN')} Cr
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl">
                  <div className="text-slate-400 text-[10px]">PROJECTED EBITDA</div>
                  <div className="text-slate-100 font-bold text-lg mt-1">
                    ₹{result.projectedEbitdaCrores.toLocaleString('en-IN')} Cr
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl">
                  <div className="text-slate-400 text-[10px]">CASH FLOW SHOCK</div>
                  <div className="text-amber-400 font-bold text-lg mt-1">
                    ₹{result.projectedCashImpactCrores.toLocaleString('en-IN')} Cr
                  </div>
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-3">
                <h4 className="text-xs font-bold text-amber-400 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" />
                  IDENTIFIED GRAPH BOTTLENECKS
                </h4>

                <ul className="space-y-2 text-xs text-slate-300">
                  {result.bottlenecksIdentified.map((b, i) => (
                    <li key={i} className="flex items-start gap-2 bg-slate-900 p-2.5 rounded border border-slate-800">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 mt-1 flex-shrink-0" />
                      <span>{b}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ) : (
            <div className="bg-slate-950 border border-slate-800 p-8 rounded-xl text-center text-xs text-slate-400">
              Adjust shock parameters on the left and click &quot;Execute Scenario Shock&quot; to calculate financial and physical bottlenecks.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
