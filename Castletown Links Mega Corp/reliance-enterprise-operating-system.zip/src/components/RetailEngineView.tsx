import React, { useState } from 'react';
import {
  ShoppingBag,
  Store,
  Truck,
  MapPin,
  Clock,
  PackageCheck,
  Zap,
  CheckCircle2,
  Box
} from 'lucide-react';
import { RetailStore, QuickCommerceDelivery } from '../types';

interface RetailEngineViewProps {
  stores: RetailStore[];
  quickDeliveries: QuickCommerceDelivery[];
}

export const RetailEngineView: React.FC<RetailEngineViewProps> = ({ stores, quickDeliveries }) => {
  const [selectedFormat, setSelectedFormat] = useState<string>('ALL');

  const filteredStores = stores.filter(
    (s) => selectedFormat === 'ALL' || s.format === selectedFormat
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <span className="p-2 bg-rose-950 border border-rose-800 rounded-lg text-rose-400">
              <ShoppingBag className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-100 font-mono tracking-wide">
                RELIANCE RETAIL & JIOMART DIGITAL COMMERCE ENGINE
              </h2>
              <p className="text-xs text-slate-400">
                18,940 Operational Stores • Pan-India Dark Stores • Hyperlocal Quick Commerce Delivery ETA Math
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-3 font-mono text-xs">
          <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800">
            <span className="text-slate-400">DAILY COMMERCE ORDERS:</span> <strong className="text-emerald-400">2.4M</strong>
          </div>
        </div>
      </div>

      {/* Retail Store Network & Format Selector */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-800 pb-3 gap-2">
          <h3 className="text-sm font-bold text-slate-200 font-mono flex items-center gap-2">
            <Store className="w-4 h-4 text-amber-400" />
            OMNICHANNEL STORE FOOTPRINT ({filteredStores.length})
          </h3>

          <div className="flex space-x-2 font-mono text-xs">
            {['ALL', 'HYPERMARKET', 'ELECTRONICS', 'DARK_STORE', 'FASHION'].map((fmt) => (
              <button
                key={fmt}
                onClick={() => setSelectedFormat(fmt)}
                className={`px-3 py-1 rounded-md transition ${
                  selectedFormat === fmt
                    ? 'bg-amber-500 text-slate-950 font-bold'
                    : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
                }`}
              >
                {fmt}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {filteredStores.map((st) => (
            <div key={st.storeId} className="bg-slate-950 border border-slate-800/80 rounded-xl p-4 font-mono space-y-2">
              <div className="flex items-center justify-between text-[10px]">
                <span className="bg-rose-950 text-rose-300 border border-rose-800 px-2 py-0.5 rounded font-bold">
                  {st.format}
                </span>
                <span className="text-emerald-400 font-bold">{st.status}</span>
              </div>

              <h4 className="text-xs font-bold text-slate-100">{st.name}</h4>
              <p className="text-[11px] text-slate-400">{st.city}, {st.state}</p>

              <div className="pt-2 border-t border-slate-800 space-y-1 text-[11px]">
                <div className="flex justify-between text-slate-400">
                  <span>Footfall Today:</span>
                  <strong className="text-slate-200">{st.footfallToday.toLocaleString()}</strong>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Daily Sales:</span>
                  <strong className="text-emerald-400">₹{(st.dailySalesINR / 100000).toFixed(1)} Lakhs</strong>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>Inventory SKUs:</span>
                  <strong className="text-slate-300">{st.onHandInventorySKUs.toLocaleString()}</strong>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Hyperlocal Quick Commerce Real ETA Calculation Subsystem */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-bold text-slate-200 flex items-center gap-2">
            <Truck className="w-4 h-4 text-emerald-400" />
            JIOMART EXPRESS QUICK COMMERCE DISPATCH (LIVE ETA MATH)
          </h3>
          <span className="text-xs text-slate-400">No Hardcoded ETAs • Dynamic Distance Matrix</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {quickDeliveries.map((del) => (
            <div key={del.orderId} className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-3">
              <div className="flex items-center justify-between text-xs">
                <span className="text-amber-400 font-bold">{del.orderId}</span>
                <span className="bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded text-[10px] font-bold">
                  {del.status}
                </span>
              </div>

              <div className="text-xs text-slate-300 flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-rose-400 flex-shrink-0" />
                <span>{del.customerLocation}</span>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center text-[11px] bg-slate-900 p-2.5 rounded-lg border border-slate-800">
                <div>
                  <div className="text-slate-400 text-[10px]">DISTANCE</div>
                  <div className="text-slate-100 font-bold">{del.distanceKm} km</div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">CALCULATED ETA</div>
                  <div className="text-emerald-400 font-bold text-sm">{del.calculatedEtaMinutes} Mins</div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">TOTAL</div>
                  <div className="text-slate-100 font-bold">₹{del.orderTotalINR}</div>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                <span>Picker: <strong className="text-slate-200">{del.pickerName}</strong></span>
                <span>Rider: <strong className="text-slate-200">{del.riderName}</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
