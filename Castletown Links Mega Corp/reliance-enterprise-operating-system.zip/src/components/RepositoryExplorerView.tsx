import React, { useState } from 'react';
import {
  FolderTree,
  FileCode,
  Terminal,
  Copy,
  CheckCircle2,
  Code2,
  BookOpen,
  Play
} from 'lucide-react';

interface RepoFile {
  path: string;
  type: 'python' | 'rust' | 'kotlin' | 'sql' | 'markdown' | 'test';
  content: string;
}

const REPO_FILES: RepoFile[] = [
  {
    path: 'reliance-enterprise-os/backend/capital/engine.py',
    type: 'python',
    content: `from decimal import Decimal, getcontext
from pydantic import BaseModel

getcontext().prec = 28  # Exact Decimal precision for money

class CapitalAllocationEngine:
    @staticmethod
    def calculate_npv(initial_outlay: Decimal, cash_flows: list[Decimal], discount_rate: Decimal) -> Decimal:
        npv = -initial_outlay
        r = discount_rate / Decimal("100.0")
        for t, cf in enumerate(cash_flows, start=1):
            npv += cf / ((Decimal("1.0") + r) ** Decimal(str(t)))
        return round(npv, 2)`
  },
  {
    path: 'reliance-enterprise-os/rust-core/src/lib.rs',
    type: 'rust',
    content: `use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IndustrialTelemetryPacket {
    pub asset_id: String,
    pub temperature_celsius: f64,
    pub vibration_mm_s: f64,
}

pub struct TelemetryEngine;
impl TelemetryEngine {
    pub fn evaluate_packet(packet: &IndustrialTelemetryPacket) -> bool {
        packet.temperature_celsius < 350.0 && packet.vibration_mm_s < 4.5
    }
}`
  },
  {
    path: 'reliance-enterprise-os/android/executive/MainActivity.kt',
    type: 'kotlin',
    content: `package com.reliance.reos.executive

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Text(text = "REOS Rugged Tablet & Executive Client (Ktor/Kotlin)")
        }
    }
}`
  },
  {
    path: 'reliance-enterprise-os/database/schema.sql',
    type: 'sql',
    content: `CREATE SCHEMA IF NOT EXISTS reos;

CREATE TABLE reos.capital_request (
    id VARCHAR(64) PRIMARY KEY,
    amount_crores NUMERIC(18, 4) NOT NULL CHECK (amount_crores > 0),
    funding_source VARCHAR(64) NOT NULL,
    npv_crores NUMERIC(18, 4) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'PROPOSED'
);`
  },
  {
    path: 'reliance-enterprise-os/docs/architecture/overview.md',
    type: 'markdown',
    content: `# RELIANCE ENTERPRISE OPERATING SYSTEM (REOS)
## Architecture Reference Specification

Fundamental Enterprise Graph:
CAPITAL -> ENTERPRISE -> BUSINESSES -> ASSETS -> NETWORKS -> PLATFORMS -> PRODUCTS -> CUSTOMERS -> TRANSACTIONS -> DATA -> AI -> DECISIONS -> CAPITAL ALLOCATION`
  }
];

export const RepositoryExplorerView: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<RepoFile>(REPO_FILES[0]);
  const [copied, setCopied] = useState<boolean>(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 font-mono">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <span className="p-2 bg-indigo-950 border border-indigo-800 rounded-lg text-indigo-400">
              <FolderTree className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-100 tracking-wide">
                REOS CODE REPOSITORY EXPLORER
              </h2>
              <p className="text-xs text-slate-400">
                25-Phase Full Architecture • Python FastAPI • Rust Telemetry Core • Kotlin Android Client • PostgreSQL DDL
              </p>
            </div>
          </div>
        </div>

        <div className="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-xs text-amber-400 flex items-center gap-1.5">
          <Terminal className="w-4 h-4" />
          <span>reliance-enterprise-os/</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* File Tree Selector */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-bold text-slate-200 border-b border-slate-800 pb-3 flex items-center gap-2">
            <FolderTree className="w-4 h-4 text-amber-400" />
            REPOSITORY STRUCTURE
          </h3>

          <div className="space-y-2 text-xs">
            {REPO_FILES.map((file) => {
              const isSelected = selectedFile.path === file.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left p-3 rounded-lg border transition ${
                    isSelected
                      ? 'bg-slate-800 border-amber-500 text-amber-300 font-bold'
                      : 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center space-x-2">
                    <FileCode className="w-4 h-4 text-blue-400 flex-shrink-0" />
                    <span className="truncate">{file.path.replace('reliance-enterprise-os/', '')}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Code Viewer Panel */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div className="flex items-center space-x-2">
              <Code2 className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-bold text-slate-200">{selectedFile.path}</span>
            </div>

            <button
              onClick={handleCopy}
              className="px-3 py-1 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded text-xs text-slate-200 flex items-center gap-1.5 transition"
            >
              {copied ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Source'}</span>
            </button>
          </div>

          <pre className="bg-slate-950 border border-slate-800 p-4 rounded-xl text-xs text-amber-100/90 overflow-x-auto leading-relaxed">
            <code>{selectedFile.content}</code>
          </pre>
        </div>
      </div>
    </div>
  );
};
