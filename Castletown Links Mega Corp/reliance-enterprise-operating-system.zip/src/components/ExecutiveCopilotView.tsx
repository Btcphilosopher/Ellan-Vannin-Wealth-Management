import React, { useState } from 'react';
import {
  Cpu,
  Send,
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  Database,
  FileText,
  UserCheck
} from 'lucide-react';
import { AIRecommendation, AIModelArtifact, IndianLanguage, RoleType } from '../types';

interface ExecutiveCopilotViewProps {
  models: AIModelArtifact[];
  recommendations: AIRecommendation[];
  onApproveRecommendation: (recId: string, approvedBy: string, role: RoleType) => void;
  language: IndianLanguage;
  currentRole: RoleType;
}

export const ExecutiveCopilotView: React.FC<ExecutiveCopilotViewProps> = ({
  models,
  recommendations,
  onApproveRecommendation,
  language,
  currentRole
}) => {
  const [question, setQuestion] = useState<string>('');
  const [messages, setMessages] = useState<
    { role: 'user' | 'assistant'; text: string; citations?: string[]; confidence?: number }[]
  >([
    {
      role: 'assistant',
      text: `Namaste. I am RELIANCE EXECUTIVE COPILOT (REOS).
I synthesize real-time graph intelligence across Oil-to-Chemicals (Jamnagar), 5G Network NOC, Retail, New Energy Giga Hubs, and Treasury.

How can I assist your capital allocation, industrial yield, or risk decisions today?`,
      citations: ['GL-CONS-2026-Q2-REV', 'O2C-JMN-TELEMETRY-4491'],
      confidence: 0.985
    }
  ]);
  const [loading, setLoading] = useState<boolean>(false);

  const handleAsk = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim()) return;

    const userQ = question;
    setQuestion('');
    setMessages((prev) => [...prev, { role: 'user', text: userQ }]);
    setLoading(true);

    try {
      const res = await fetch('/api/ai/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: userQ, language })
      });
      const data = await res.json();
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: data.answer || 'Processing query...',
          citations: data.sourceCitations || ['REOS-GENERIC-DATA'],
          confidence: data.confidenceScore || 0.98
        }
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          role: 'assistant',
          text: 'Executive Copilot query completed with local synthetic logic.',
          citations: ['REOS-SYNTHETIC-RECORD'],
          confidence: 0.95
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <span className="p-2 bg-cyan-950 border border-cyan-800 rounded-lg text-cyan-400">
              <Cpu className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-100 font-mono tracking-wide">
                RELIANCE EXECUTIVE COPILOT & AI GOVERNANCE
              </h2>
              <p className="text-xs text-slate-400">
                Traceable AI Decision Engine • Mandatory Human Approval Guardrails for Capital & OT Controls
              </p>
            </div>
          </div>
        </div>

        <div className="bg-cyan-950/60 border border-cyan-800 px-3 py-1.5 rounded-lg text-xs font-mono text-cyan-300 flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4 text-cyan-400" />
          <span>AI Governance Policy 20.1 Active</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Copilot Interactive Terminal */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 flex flex-col h-[520px]">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
            <h3 className="text-sm font-bold text-slate-200 font-mono flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-400" />
              EXECUTIVE COPILOT CHAT SESSION ({language})
            </h3>
            <span className="text-[11px] font-mono text-slate-400">Powered by Gemini 2.5 Flash / Synthetic</span>
          </div>

          {/* Messages Body */}
          <div className="flex-1 overflow-y-auto space-y-4 pr-2 font-mono text-xs">
            {messages.map((m, idx) => (
              <div
                key={idx}
                className={`p-4 rounded-xl space-y-2 ${
                  m.role === 'user'
                    ? 'bg-amber-950/40 border border-amber-800/60 ml-12 text-amber-100'
                    : 'bg-slate-950 border border-slate-800 text-slate-200 mr-4'
                }`}
              >
                <div className="flex items-center justify-between text-[10px] text-slate-400 pb-1 border-b border-slate-800/60">
                  <span className="font-bold uppercase text-amber-400">
                    {m.role === 'user' ? `EXECUTIVE (${currentRole})` : 'RELIANCE EXECUTIVE COPILOT'}
                  </span>
                  {m.confidence && (
                    <span className="text-emerald-400">Confidence: {(m.confidence * 100).toFixed(1)}%</span>
                  )}
                </div>

                <div className="whitespace-pre-wrap leading-relaxed">{m.text}</div>

                {m.citations && m.citations.length > 0 && (
                  <div className="pt-2 border-t border-slate-800/80 flex items-center gap-2 flex-wrap text-[10px]">
                    <span className="text-slate-400">Source Records Cites:</span>
                    {m.citations.map((c, i) => (
                      <span key={i} className="bg-slate-900 border border-slate-700 px-2 py-0.5 rounded text-amber-300">
                        {c}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
            {loading && (
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-amber-400 animate-pulse">
                Synthesizing enterprise graph data & calculating decision returns...
              </div>
            )}
          </div>

          {/* Question Input Form */}
          <form onSubmit={handleAsk} className="pt-4 border-t border-slate-800 flex gap-2">
            <input
              type="text"
              value={question}
              onChange={(e) => setQuestion(e.target.value)}
              placeholder="Ask Copilot about refinery yields, capital requests, network traffic shocks, or EBITDA..."
              className="flex-1 bg-slate-950 border border-slate-800 rounded-lg px-4 py-2.5 text-xs text-slate-200 outline-none focus:border-amber-500 font-mono"
            />
            <button
              type="submit"
              disabled={loading}
              className="px-4 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-lg text-xs font-mono flex items-center gap-1.5 transition"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Ask</span>
            </button>
          </form>
        </div>

        {/* AI Governance Human Approval Panel */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4 font-mono">
          <div className="border-b border-slate-800 pb-3">
            <span className="text-[10px] bg-rose-950 text-rose-300 border border-rose-800 px-2 py-0.5 rounded font-bold uppercase">
              MANDATORY HUMAN APPROVAL QUEUE
            </span>
            <h3 className="text-base font-bold text-slate-100 mt-2">AI DECISION GOVERNANCE</h3>
            <p className="text-xs text-slate-400">Section 20 Enforcement: AI cannot autonomously alter financial records or OT settings.</p>
          </div>

          <div className="space-y-3">
            {recommendations.map((rec) => (
              <div key={rec.id} className="bg-slate-950 border border-slate-800 p-4 rounded-xl space-y-2.5 text-xs">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded font-bold">
                    {rec.domain}
                  </span>
                  <span
                    className={`font-bold px-2 py-0.5 rounded ${
                      rec.status === 'APPROVED'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-amber-950 text-amber-400 border border-amber-800'
                    }`}
                  >
                    {rec.status}
                  </span>
                </div>

                <h4 className="font-bold text-slate-100">{rec.title}</h4>
                <p className="text-slate-400 text-[11px]">{rec.reasoningSummary}</p>

                <div className="bg-slate-900 p-2.5 rounded border border-slate-800/80 text-[11px] text-amber-300">
                  <strong>Recommended Action:</strong> {rec.recommendedAction}
                </div>

                {rec.status !== 'APPROVED' ? (
                  <button
                    onClick={() => onApproveRecommendation(rec.id, 'Group COO', currentRole)}
                    className="w-full py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 text-slate-950 font-bold rounded-lg text-xs font-mono uppercase transition flex items-center justify-center gap-1.5"
                  >
                    <UserCheck className="w-3.5 h-3.5" />
                    Sign-Off & Execute Recommendation
                  </button>
                ) : (
                  <div className="text-emerald-400 text-[11px] flex items-center gap-1 font-bold">
                    <CheckCircle2 className="w-4 h-4" /> Approved by {rec.approvedBy}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
