import React, { useState } from 'react';
import {
  Flame,
  Zap,
  BatteryCharging,
  Cpu,
  Building2,
  Activity,
  AlertTriangle,
  RefreshCw,
  Gauge,
  Thermometer,
  ShieldAlert,
  Sliders,
  CheckCircle
} from 'lucide-react';
import { IndustrialAsset } from '../types';

interface DigitalTwinsViewProps {
  assets: IndustrialAsset[];
}

export const DigitalTwinsView: React.FC<DigitalTwinsViewProps> = ({ assets }) => {
  const [selectedAssetId, setSelectedAssetId] = useState<string>(assets[0]?.id || 'AST-JMN-REF-01');
  const [simChargeState, setSimChargeState] = useState<number>(88);
  const [simTemp, setSimTemp] = useState<number>(34);

  const selectedAsset = assets.find((a) => a.id === selectedAssetId) || assets[0];

  return (
    <div className="space-y-6">
      {/* Digital Twins Header */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-3">
            <span className="p-2 bg-amber-950 border border-amber-800 rounded-lg text-amber-400">
              <Flame className="w-6 h-6 animate-pulse" />
            </span>
            <div>
              <h2 className="text-xl font-bold text-slate-100 font-mono tracking-wide">
                INDUSTRIAL ASSETS & DIGITAL TWINS ENGINE
              </h2>
              <p className="text-xs text-slate-400">
                Refinery Twin • E&P Off-shore Field • Solar Giga Factory • Battery Storage Twin • Hyperscale Data Centres
              </p>
            </div>
          </div>
        </div>

        <div className="flex items-center space-x-3 text-xs font-mono">
          <span className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-md text-slate-300 flex items-center gap-1.5">
            <Activity className="w-3.5 h-3.5 text-emerald-400 animate-spin" />
            Telemetry Frequency: 100ms (Rust Core)
          </span>
        </div>
      </div>

      {/* Asset Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {assets.map((ast) => {
          const isSelected = ast.id === selectedAssetId;
          return (
            <button
              key={ast.id}
              onClick={() => setSelectedAssetId(ast.id)}
              className={`p-4 rounded-xl border text-left transition relative ${
                isSelected
                  ? 'bg-slate-800 border-amber-500 ring-1 ring-amber-500/50 shadow-lg'
                  : 'bg-slate-900 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 uppercase font-semibold">
                  {ast.assetType} • {ast.category}
                </span>
                <span className="text-xs font-mono font-bold text-emerald-400">
                  {ast.utilisationPct}% Utilized
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-100 mb-1">{ast.name}</h3>
              <p className="text-[11px] text-slate-400 font-mono mb-3">{ast.location}</p>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-2 border-t border-slate-800/80">
                <div>
                  <div className="text-slate-400 text-[10px]">CURRENT OUTPUT</div>
                  <div className="text-slate-200 font-bold">{ast.currentOutput}</div>
                </div>
                <div>
                  <div className="text-slate-400 text-[10px]">HEALTH INDEX</div>
                  <div className="text-emerald-400 font-bold">{ast.healthIndex} / 100</div>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Selected Digital Twin Deep Inspection Dashboard */}
      {selectedAsset && (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-4 gap-4">
            <div>
              <span className="text-[10px] font-mono bg-blue-950 text-blue-300 border border-blue-800 px-2 py-0.5 rounded uppercase font-bold">
                DIGITAL TWIN REAL-TIME TELEMETRY MODEL
              </span>
              <h3 className="text-xl font-bold text-slate-100 font-mono mt-1">{selectedAsset.name}</h3>
              <p className="text-xs text-slate-400 font-mono">
                AssetID: {selectedAsset.id} • Book Value: ₹{selectedAsset.bookValueCrores.toLocaleString('en-IN')} Cr
              </p>
            </div>

            <div className="flex items-center space-x-3 text-xs font-mono">
              <div className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-300">
                Carbon Intensity: <strong className="text-emerald-400">{selectedAsset.carbonIntensity}</strong>
              </div>
              <div className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-slate-300">
                Risk Score: <strong className="text-amber-400">{selectedAsset.riskScore}/100</strong>
              </div>
            </div>
          </div>

          {/* Conditional Digital Twin Interactive Simulation for Refinery & Battery */}
          {selectedAsset.assetType === 'Refinery' && (
            <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl space-y-4 font-mono">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-amber-400 flex items-center gap-2">
                  <Flame className="w-4 h-4" />
                  JAMNAGAR REFINERY & COKER DIGITAL TWIN SCHEMATIC
                </h4>
                <span className="text-xs text-slate-400">Yield Optimization Engine Active</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-xs text-center">
                <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
                  <div className="text-slate-400 text-[10px]">CRUDE FEEDSTOCK</div>
                  <div className="text-emerald-400 font-bold text-sm mt-1">1,385,000 BPD</div>
                  <div className="text-[10px] text-slate-400 mt-1">API Gravity: 32.4°</div>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
                  <div className="text-slate-400 text-[10px]">ATMOSPHERIC DISTILLATION</div>
                  <div className="text-slate-200 font-bold text-sm mt-1">362°C • 4.2 Bar</div>
                  <div className="text-[10px] text-amber-400 mt-1">Unit Health: 98%</div>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
                  <div className="text-slate-400 text-[10px]">DELAYED COKER UNIT</div>
                  <div className="text-amber-400 font-bold text-sm mt-1">495°C • 2.1 Bar</div>
                  <div className="text-[10px] text-slate-400 mt-1">Petcoke Yield: 8.4%</div>
                </div>

                <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg">
                  <div className="text-slate-400 text-[10px]">POLYMER NAPHTHA DISPATCH</div>
                  <div className="text-emerald-400 font-bold text-sm mt-1">42,100 MT / Day</div>
                  <div className="text-[10px] text-emerald-400 mt-1">To Hazira Plant</div>
                </div>
              </div>
            </div>
          )}

          {selectedAsset.assetType === 'BatteryPlant' && (
            <div className="bg-slate-950 border border-slate-800 p-5 rounded-xl space-y-4 font-mono">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-bold text-emerald-400 flex items-center gap-2">
                  <BatteryCharging className="w-4 h-4" />
                  LFP GIGA BATTERY CELL & BMS THERMAL SIMULATOR
                </h4>
                <span className="text-xs text-slate-400">State of Health (SOH): 99.4%</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-3 bg-slate-900 border border-slate-800 p-4 rounded-lg">
                  <div className="flex justify-between text-xs">
                    <span className="text-slate-400">State of Charge (SOC):</span>
                    <strong className="text-emerald-400">{simChargeState}%</strong>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="100"
                    value={simChargeState}
                    onChange={(e) => setSimChargeState(Number(e.target.value))}
                    className="w-full bg-slate-800 h-2 rounded-lg cursor-pointer accent-emerald-400"
                  />

                  <div className="flex justify-between text-xs pt-2">
                    <span className="text-slate-400">Cell Operating Temperature:</span>
                    <strong className={simTemp > 45 ? 'text-rose-400 font-bold' : 'text-slate-200'}>
                      {simTemp}°C
                    </strong>
                  </div>
                  <input
                    type="range"
                    min="20"
                    max="65"
                    value={simTemp}
                    onChange={(e) => setSimTemp(Number(e.target.value))}
                    className="w-full bg-slate-800 h-2 rounded-lg cursor-pointer accent-amber-400"
                  />
                </div>

                <div className="bg-slate-900 border border-slate-800 p-4 rounded-lg space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">BMS Thermal Mode:</span>
                    <strong className="text-emerald-400">ACTIVE LIQUID COOLING</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Cell Voltage:</span>
                    <strong className="text-slate-200">3.25 V / Cell</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Discharge Capacity:</span>
                    <strong className="text-slate-200">320 Ah Module</strong>
                  </div>
                  <div className="flex justify-between pt-1 border-t border-slate-800">
                    <span className="text-slate-400">Thermal Degradation Index:</span>
                    <strong className={simTemp > 45 ? 'text-rose-400' : 'text-emerald-400'}>
                      {simTemp > 45 ? 'ELEVATED' : 'NOMINAL (0.01%/yr)'}
                    </strong>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
