import React, { useEffect, useState } from 'react';
import {
  Layers,
  Share2,
  DollarSign,
  Flame,
  Radio,
  ShoppingBag,
  Cpu,
  Sliders,
  ShieldCheck,
  FolderTree,
  Activity,
  CheckCircle2,
  RefreshCw
} from 'lucide-react';
import {
  RoleType,
  IndianLanguage,
  GroupKPI,
  BusinessEntity,
  GraphNode,
  GraphEdge,
  CapitalRequest,
  IndustrialAsset,
  NetworkSite,
  NetworkIncident,
  RetailStore,
  QuickCommerceDelivery,
  AIModelArtifact,
  AIRecommendation,
  AuditRecord
} from './types';

import { Header } from './components/Header';
import { CommandCentreView } from './components/CommandCentreView';
import { GraphExplorerView } from './components/GraphExplorerView';
import { CapitalAllocationView } from './components/CapitalAllocationView';
import { DigitalTwinsView } from './components/DigitalTwinsView';
import { TelecomNocView } from './components/TelecomNocView';
import { RetailEngineView } from './components/RetailEngineView';
import { ExecutiveCopilotView } from './components/ExecutiveCopilotView';
import { SimulationEngineView } from './components/SimulationEngineView';
import { SecurityAuditView } from './components/SecurityAuditView';
import { RepositoryExplorerView } from './components/RepositoryExplorerView';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('COMMAND_CENTRE');
  const [role, setRole] = useState<RoleType>('GroupExecutive');
  const [language, setLanguage] = useState<IndianLanguage>('English');
  const [displayModeLakhCrore, setDisplayModeLakhCrore] = useState<boolean>(true);

  // App state
  const [kpis, setKpis] = useState<GroupKPI[]>([]);
  const [businesses, setBusinesses] = useState<BusinessEntity[]>([]);
  const [graphNodes, setGraphNodes] = useState<GraphNode[]>([]);
  const [graphEdges, setGraphEdges] = useState<GraphEdge[]>([]);
  const [capitalRequests, setCapitalRequests] = useState<CapitalRequest[]>([]);
  const [industrialAssets, setIndustrialAssets] = useState<IndustrialAsset[]>([]);
  const [networkSites, setNetworkSites] = useState<NetworkSite[]>([]);
  const [networkIncidents, setNetworkIncidents] = useState<NetworkIncident[]>([]);
  const [retailStores, setRetailStores] = useState<RetailStore[]>([]);
  const [quickDeliveries, setQuickDeliveries] = useState<QuickCommerceDelivery[]>([]);
  const [aiModels, setAiModels] = useState<AIModelArtifact[]>([]);
  const [aiRecommendations, setAiRecommendations] = useState<AIRecommendation[]>([]);
  const [auditTrail, setAuditTrail] = useState<AuditRecord[]>([]);

  const [notification, setNotification] = useState<string | null>(null);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 4000);
  };

  // Fetch initial data from Express backend
  const refreshAllData = async () => {
    try {
      const [groupRes, kpiRes, graphRes, capRes, assetRes, nocRes, retailRes, aiRes, auditRes] = await Promise.all([
        fetch('/api/group').then((r) => r.json()),
        fetch('/api/kpis').then((r) => r.json()),
        fetch('/api/graph').then((r) => r.json()),
        fetch('/api/capital').then((r) => r.json()),
        fetch('/api/industrial/assets').then((r) => r.json()),
        fetch('/api/telecom/noc').then((r) => r.json()),
        fetch('/api/retail').then((r) => r.json()),
        fetch('/api/ai/recommendations').then((r) => r.json()),
        fetch('/api/audit').then((r) => r.json())
      ]);

      setBusinesses(groupRes.businesses || []);
      setKpis(kpiRes || []);
      setGraphNodes(graphRes.nodes || []);
      setGraphEdges(graphRes.edges || []);
      setCapitalRequests(capRes || []);
      setIndustrialAssets(assetRes || []);
      setNetworkSites(nocRes.sites || []);
      setNetworkIncidents(nocRes.incidents || []);
      setRetailStores(retailRes.stores || []);
      setQuickDeliveries(retailRes.quickCommerce || []);
      setAiModels(aiRes.models || []);
      setAiRecommendations(aiRes.recommendations || []);
      setAuditTrail(auditRes || []);
    } catch (err) {
      console.error('Error fetching backend REOS state:', err);
    }
  };

  useEffect(() => {
    refreshAllData();
  }, []);

  // Capital Approval Handler
  const handleApproveCapitalRequest = async (requestId: string, currentRole: RoleType, reason: string) => {
    try {
      const res = await fetch('/api/capital/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ requestId, approvedBy: 'Group Executive', role: currentRole, reason })
      });
      const data = await res.json();
      if (data.success) {
        showNotification(`Capital Request #${requestId} Approved & Committed to Ledger!`);
        refreshAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // Incident Status Update Handler
  const handleUpdateIncidentStatus = async (incidentId: string, newStatus: string, engineer: string, reason: string) => {
    try {
      const res = await fetch('/api/telecom/incident/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ incidentId, newStatus, engineer, reason })
      });
      const data = await res.json();
      if (data.success) {
        showNotification(`Network Ticket #${incidentId} Status updated to ${newStatus}`);
        refreshAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  // AI Recommendation Sign-Off Handler
  const handleApproveAIRecommendation = async (recId: string, approvedBy: string, currentRole: RoleType) => {
    try {
      const res = await fetch('/api/ai/recommendation/approve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ recId, approvedBy, role: currentRole })
      });
      const data = await res.json();
      if (data.success) {
        showNotification(`AI Recommendation #${recId} Human Sign-Off Recorded!`);
        refreshAllData();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const navTabs = [
    { id: 'COMMAND_CENTRE', label: 'Group Command Centre', icon: Layers },
    { id: 'ENTERPRISE_GRAPH', label: 'Canonical Enterprise Graph', icon: Share2 },
    { id: 'CAPITAL_ALLOCATION', label: 'Capital Allocation Engine', icon: DollarSign },
    { id: 'DIGITAL_TWINS', label: 'Industrial & Digital Twins', icon: Flame },
    { id: 'TELECOM_NOC', label: 'Jio Network OS & NOC', icon: Radio },
    { id: 'RETAIL_COMMERCE', label: 'Retail & JioMart Engine', icon: ShoppingBag },
    { id: 'EXECUTIVE_COPILOT', label: 'Reliance Executive Copilot', icon: Cpu },
    { id: 'SIMULATION_ENGINE', label: 'Scenario Shock Simulator', icon: Sliders },
    { id: 'SECURITY_AUDIT', label: 'Cybersecurity & Audit Log', icon: ShieldCheck },
    { id: 'REPO_EXPLORER', label: 'REOS Repository Explorer', icon: FolderTree }
  ];

  const getActiveViewTitle = () => {
    const item = navTabs.find((t) => t.id === activeTab);
    return item ? item.label : 'Group Command Centre';
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-amber-500 selection:text-slate-950">
      {/* Top Header */}
      <Header
        currentRole={role}
        onRoleChange={setRole}
        currentLang={language}
        onLangChange={setLanguage}
        displayModeLakhCrore={displayModeLakhCrore}
        onToggleCurrencyFormat={() => setDisplayModeLakhCrore(!displayModeLakhCrore)}
        activeViewTitle={getActiveViewTitle()}
      />

      {/* Main Layout Body */}
      <div className="flex-1 flex flex-col lg:flex-row">
        {/* Navigation Sidebar */}
        <aside className="w-full lg:w-64 bg-slate-900 border-r border-slate-800 p-4 space-y-2 flex-shrink-0">
          <div className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-widest px-3 py-1 mb-2">
            CONGLOMERATE SUBSYSTEMS
          </div>

          <nav className="space-y-1 font-mono text-xs">
            {navTabs.map((tab) => {
              const Icon = tab.icon;
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full flex items-center space-x-3 px-3.5 py-2.5 rounded-lg text-left transition font-semibold ${
                    isActive
                      ? 'bg-amber-500 text-slate-950 font-bold shadow-md shadow-amber-500/20'
                      : 'text-slate-300 hover:text-slate-100 hover:bg-slate-800/80'
                  }`}
                >
                  <Icon className="w-4 h-4 flex-shrink-0" />
                  <span className="truncate">{tab.label}</span>
                </button>
              );
            })}
          </nav>

          {/* Quick System Status Card */}
          <div className="pt-6">
            <div className="bg-slate-950 border border-slate-800 p-3.5 rounded-xl space-y-2 font-mono text-[11px]">
              <div className="flex items-center justify-between text-slate-400">
                <span>Rust Core:</span>
                <span className="text-emerald-400 font-bold">ONLINE</span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>OT Gateway:</span>
                <span className="text-emerald-400 font-bold">AIRGAP STRICT</span>
              </div>
              <div className="flex items-center justify-between text-slate-400">
                <span>Audit Trail:</span>
                <span className="text-amber-400 font-bold">{auditTrail.length} Logs</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Dynamic Main Workspace Content View */}
        <main className="flex-1 p-6 space-y-6 overflow-y-auto max-w-7xl">
          {/* Notification Toast */}
          {notification && (
            <div className="bg-emerald-950 border border-emerald-700 text-emerald-200 px-4 py-3 rounded-xl flex items-center space-x-3 text-xs font-mono shadow-lg animate-bounce">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>{notification}</span>
            </div>
          )}

          {activeTab === 'COMMAND_CENTRE' && (
            <CommandCentreView
              kpis={kpis}
              businesses={businesses}
              displayModeLakhCrore={displayModeLakhCrore}
              language={language}
              onSelectSubdomain={(cat) => {
                if (cat === 'TELECOM') setActiveTab('TELECOM_NOC');
                else if (cat === 'RETAIL') setActiveTab('RETAIL_COMMERCE');
                else if (cat === 'NEW_ENERGY' || cat === 'O2C') setActiveTab('DIGITAL_TWINS');
                else setActiveTab('ENTERPRISE_GRAPH');
              }}
            />
          )}

          {activeTab === 'ENTERPRISE_GRAPH' && (
            <GraphExplorerView nodes={graphNodes} edges={graphEdges} />
          )}

          {activeTab === 'CAPITAL_ALLOCATION' && (
            <CapitalAllocationView
              capitalRequests={capitalRequests}
              onApproveRequest={handleApproveCapitalRequest}
              displayModeLakhCrore={displayModeLakhCrore}
              currentRole={role}
            />
          )}

          {activeTab === 'DIGITAL_TWINS' && <DigitalTwinsView assets={industrialAssets} />}

          {activeTab === 'TELECOM_NOC' && (
            <TelecomNocView
              sites={networkSites}
              incidents={networkIncidents}
              onUpdateIncidentStatus={handleUpdateIncidentStatus}
              currentRole={role}
            />
          )}

          {activeTab === 'RETAIL_COMMERCE' && (
            <RetailEngineView stores={retailStores} quickDeliveries={quickDeliveries} />
          )}

          {activeTab === 'EXECUTIVE_COPILOT' && (
            <ExecutiveCopilotView
              models={aiModels}
              recommendations={aiRecommendations}
              onApproveRecommendation={handleApproveAIRecommendation}
              language={language}
              currentRole={role}
            />
          )}

          {activeTab === 'SIMULATION_ENGINE' && <SimulationEngineView />}

          {activeTab === 'SECURITY_AUDIT' && <SecurityAuditView auditTrail={auditTrail} />}

          {activeTab === 'REPO_EXPLORER' && <RepositoryExplorerView />}
        </main>
      </div>
    </div>
  );
}
