import {
  RelianceGroup,
  BusinessEntity,
  GraphNode,
  GraphEdge,
  GroupKPI,
  CapitalRequest,
  IndustrialAsset,
  NetworkSite,
  NetworkIncident,
  RetailStore,
  QuickCommerceDelivery,
  AIModelArtifact,
  AIRecommendation,
  CarbonLedgerRecord,
  AuditRecord,
  SimulationScenario,
  SimulationResult
} from '../types';

export const INITIAL_RELIANCE_GROUP: RelianceGroup = {
  id: 'GRP-RELIANCE-001',
  name: 'RELIANCE ENTERPRISE OPERATING SYSTEM',
  code: 'REOS-INDIA',
  holdingCompany: 'Reliance Holding & Investments Pvt Ltd (Synthetic)',
  legalEntitiesCount: 148,
  totalCapExAllocated: 125000, // ₹1,25,000 Cr
  currency: 'INR'
};

export const INITIAL_BUSINESSES: BusinessEntity[] = [
  {
    id: 'BIZ-O2C',
    name: 'Oil-to-Chemicals (O2C)',
    category: 'O2C',
    legalEntity: 'Reliance O2C Assets Ltd (Synthetic)',
    country: 'India',
    currency: 'INR',
    headquarters: 'Jamnagar, Gujarat',
    costCentres: ['CC-JMN-REF-1', 'CC-JMN-CRK-2', 'CC-HZ-PETRO-1'],
    profitCentres: ['PC-O2C-GLOBAL-EXPORT', 'PC-DOMESTIC-POLYMERS'],
    revenueCrores: 485000,
    ebitdaCrores: 62400,
    assetValueCrores: 340000,
    employeeCount: 42000
  },
  {
    id: 'BIZ-OILGAS',
    name: 'Exploration & Production (E&P)',
    category: 'OIL_GAS',
    legalEntity: 'Reliance E&P Energy Ltd (Synthetic)',
    country: 'India',
    currency: 'INR',
    headquarters: 'Kakinada, Andhra Pradesh',
    costCentres: ['CC-KGD6-OFFSHORE', 'CC-CBM-MP'],
    profitCentres: ['PC-DEEPWATER-GAS'],
    revenueCrores: 24500,
    ebitdaCrores: 16800,
    assetValueCrores: 68000,
    employeeCount: 6500
  },
  {
    id: 'BIZ-NEWENERGY',
    name: 'Green Energy & Materials Giga Complex',
    category: 'NEW_ENERGY',
    legalEntity: 'Reliance New Energy Ventures Ltd (Synthetic)',
    country: 'India',
    currency: 'INR',
    headquarters: 'Jamnagar Green Complex, Gujarat',
    costCentres: ['CC-SOLAR-CELL-GIGA', 'CC-BATTERY-PACK-GIGA', 'CC-HYDROGEN-ELECTROLYSER'],
    profitCentres: ['PC-RENEWABLE-POWER', 'PC-GREEN-HYDROGEN-EXPORT'],
    revenueCrores: 18200,
    ebitdaCrores: 5400,
    assetValueCrores: 85000,
    employeeCount: 14200
  },
  {
    id: 'BIZ-RETAIL',
    name: 'Reliance Retail Ventures',
    category: 'RETAIL',
    legalEntity: 'Reliance Retail Ltd (Synthetic)',
    country: 'India',
    currency: 'INR',
    headquarters: 'Mumbai, Maharashtra',
    costCentres: ['CC-RETAIL-LOGISTICS-HUB', 'CC-STORE-OPS-WEST', 'CC-DARKSTORE-MUMBAI'],
    profitCentres: ['PC-JIOMART-COMMERCE', 'PC-RETAIL-STORES-PAN-INDIA'],
    revenueCrores: 306000,
    ebitdaCrores: 23100,
    assetValueCrores: 112000,
    employeeCount: 389000
  },
  {
    id: 'BIZ-TELECOM',
    name: 'Jio Platforms & Digital Services',
    category: 'TELECOM',
    legalEntity: 'Jio Infocomm Enterprises Ltd (Synthetic)',
    country: 'India',
    currency: 'INR',
    headquarters: 'Navi Mumbai, Maharashtra',
    costCentres: ['CC-5G-SPECTRUM-PAN-INDIA', 'CC-FIBER-BACKHAUL-MUMBAI', 'CC-NOC-CENTRAL'],
    profitCentres: ['PC-SUBSCRIBER-CONNECTIVITY', 'PC-ENTERPRISE-5G-SLAS'],
    revenueCrores: 118000,
    ebitdaCrores: 56200,
    assetValueCrores: 295000,
    employeeCount: 78000
  },
  {
    id: 'BIZ-CLOUD-AI',
    name: 'Jio Cloud & Enterprise AI',
    category: 'CLOUD',
    legalEntity: 'Jio Cloud Computing Systems Ltd (Synthetic)',
    country: 'India',
    currency: 'INR',
    headquarters: 'Jamnagar & Jamnagar AI Center',
    costCentres: ['CC-GPU-CLUSTER-1', 'CC-HYPERSCALE-DC-JAMNAGAR'],
    profitCentres: ['PC-CLOUD-INFRA-ENTERPRISE', 'PC-AI-PLATFORM-SAAS'],
    revenueCrores: 14200,
    ebitdaCrores: 6800,
    assetValueCrores: 42000,
    employeeCount: 9500
  },
  {
    id: 'BIZ-MEDIA',
    name: 'Jio Media & Digital Entertainment',
    category: 'MEDIA',
    legalEntity: 'Jio Media Network Ltd (Synthetic)',
    country: 'India',
    currency: 'INR',
    headquarters: 'Mumbai, Maharashtra',
    costCentres: ['CC-STUDIO-PRODUCTION', 'CC-CDN-STREAMING-INFRA'],
    profitCentres: ['PC-OTT-STREAMING', 'PC-BROADCAST-ADVERTISING'],
    revenueCrores: 21500,
    ebitdaCrores: 3200,
    assetValueCrores: 28000,
    employeeCount: 11200
  }
];

export const INITIAL_GRAPH_NODES: GraphNode[] = [
  { id: 'GN-CAPITAL', name: 'Group Capital Pool', category: 'CAPITAL', type: 'Capital Treasury', metricsSummary: '₹1.25L Cr CapEx Budget', status: 'OPTIMAL' },
  { id: 'GN-KGD6', name: 'KG-D6 Deepwater Gas Field', category: 'OIL_GAS', type: 'Offshore Field', metricsSummary: '30 MMSCMD Gas Flow', status: 'OPTIMAL' },
  { id: 'GN-REFINERY', name: 'Jamnagar Complex Twin', category: 'O2C', type: 'Refinery & Cracker', metricsSummary: '1.4M BPD Throughput', status: 'OPTIMAL' },
  { id: 'GN-PETROCHEM', name: 'Hazira Polymer Plant', category: 'PETROCHEMICALS', type: 'Polymer Cracker', metricsSummary: '98.4% Yield Rate', status: 'OPTIMAL' },
  { id: 'GN-SOLAR', name: 'Jamnagar Solar Giga Factory', category: 'NEW_ENERGY', type: 'Module Mfg', metricsSummary: '20 GW Annual Capacity', status: 'OPTIMAL' },
  { id: 'GN-BATTERY', name: 'Battery Storage Giga Plant', category: 'NEW_ENERGY', type: 'LFP Cell Mfg', metricsSummary: '30 GWh Cell Prod', status: 'OPTIMAL' },
  { id: 'GN-TOWERS', name: 'Jio 5G Network Grid', category: 'TELECOM', type: '4G/5G Radio Network', metricsSummary: '480,000 Active Towers', status: 'OPTIMAL' },
  { id: 'GN-CLOUD', name: 'Jio Enterprise Cloud', category: 'CLOUD', type: 'Hyperscale Data Center', metricsSummary: '12,000 H100 Equivalent GPUs', status: 'OPTIMAL' },
  { id: 'GN-RETAIL-DC', name: 'National Distribution Hub', category: 'RETAIL', type: 'Automated DC', metricsSummary: '1.2M SKU Capacity', status: 'OPTIMAL' },
  { id: 'GN-JIOMART', name: 'JioMart Digital Engine', category: 'DIGITAL', type: 'Omnichannel Commerce', metricsSummary: '2.4M Daily Orders', status: 'OPTIMAL' },
  { id: 'GN-CONSUMER', name: 'Unified Indian Customer Graph', category: 'CUSTOMER', type: 'Identity & Consent', metricsSummary: '485M Active Users', status: 'OPTIMAL' },
  { id: 'GN-AI-ENGINE', name: 'Reliance Enterprise AI', category: 'AI_PLATFORM', type: 'Copilot & Governance', metricsSummary: '99.98% Model Confidence', status: 'OPTIMAL' }
];

export const INITIAL_GRAPH_EDGES: GraphEdge[] = [
  { id: 'GE-1', sourceId: 'GN-CAPITAL', targetId: 'GN-REFINERY', flowType: 'CAPITAL', capacityRate: '₹35,000 Cr', volumeToday: '₹120 Cr/day' },
  { id: 'GE-2', sourceId: 'GN-KGD6', targetId: 'GN-REFINERY', flowType: 'FEEDSTOCK', capacityRate: '35 MMSCMD', volumeToday: '30.2 MMSCMD' },
  { id: 'GE-3', sourceId: 'GN-REFINERY', targetId: 'GN-PETROCHEM', flowType: 'FEEDSTOCK', capacityRate: '45,000 MT/day', volumeToday: '42,100 MT/day' },
  { id: 'GE-4', sourceId: 'GN-SOLAR', targetId: 'GN-BATTERY', flowType: 'POWER', capacityRate: '500 MW', volumeToday: '460 MW' },
  { id: 'GE-5', sourceId: 'GN-TOWERS', targetId: 'GN-CLOUD', flowType: 'CONNECTIVITY', capacityRate: '100 Tbps', volumeToday: '74.2 Tbps' },
  { id: 'GE-6', sourceId: 'GN-CLOUD', targetId: 'GN-AI-ENGINE', flowType: 'DATA', capacityRate: '50 PetaFLOPS', volumeToday: '42 PetaFLOPS' },
  { id: 'GE-7', sourceId: 'GN-RETAIL-DC', targetId: 'GN-JIOMART', flowType: 'LOGISTICS', capacityRate: '5,000 Tons/day', volumeToday: '4,650 Tons/day' },
  { id: 'GE-8', sourceId: 'GN-JIOMART', targetId: 'GN-CONSUMER', flowType: 'PRODUCT', capacityRate: '3M Orders/day', volumeToday: '2.4M Orders/day' },
  { id: 'GE-9', sourceId: 'GN-CONSUMER', targetId: 'GN-AI-ENGINE', flowType: 'DATA', capacityRate: '1B Events/day', volumeToday: '840M Events/day' },
  { id: 'GE-10', sourceId: 'GN-AI-ENGINE', targetId: 'GN-CAPITAL', flowType: 'CAPITAL', capacityRate: 'Decision Loop', volumeToday: '1,420 Recs/day' }
];

export const INITIAL_GROUP_KPIS: GroupKPI[] = [
  { id: 'KPI-REV', name: 'Consolidated Gross Revenue', category: 'FINANCIAL', value: 984500, unit: '₹ Crores', changePct: 14.2, displayLakhCrore: '₹9,84,500 Cr', sourceRecord: 'GL-CONS-2026-Q2-REV', status: 'TARGET_MET' },
  { id: 'KPI-EBITDA', name: 'Consolidated EBITDA', category: 'FINANCIAL', value: 168500, unit: '₹ Crores', changePct: 18.5, displayLakhCrore: '₹1,68,500 Cr', sourceRecord: 'GL-CONS-2026-Q2-EBITDA', status: 'HEALTHY' },
  { id: 'KPI-CAPEX', name: 'Group CapEx Deployed', category: 'FINANCIAL', value: 125000, unit: '₹ Crores', changePct: 9.1, displayLakhCrore: '₹1,25,000 Cr', sourceRecord: 'CAPEX-POOL-2026-ALLOC', status: 'HEALTHY' },
  { id: 'KPI-ROIC', name: 'Return on Capital (ROIC)', category: 'FINANCIAL', value: 15.8, unit: '%', changePct: 1.4, sourceRecord: 'FIN-RATIO-ROIC-2026', status: 'TARGET_MET' },
  { id: 'KPI-REFINERY-TP', name: 'Refinery Throughput', category: 'OPERATIONAL', value: 1.42, unit: 'Million BPD', changePct: 3.2, sourceRecord: 'O2C-JMN-TELEMETRY-4491', status: 'HEALTHY' },
  { id: 'KPI-SOLAR-CAP', name: 'Solar Cell & Module Mfg', category: 'OPERATIONAL', value: 20.0, unit: 'GW / Year', changePct: 45.0, sourceRecord: 'NEW-ENERGY-GIGA-01', status: 'TARGET_MET' },
  { id: 'KPI-BATTERY-PROD', name: 'Giga Battery Storage Output', category: 'OPERATIONAL', value: 30.0, unit: 'GWh Capacity', changePct: 62.0, sourceRecord: 'NEW-ENERGY-BATT-02', status: 'HEALTHY' },
  { id: 'KPI-JIO-USERS', name: 'Jio Active Connectivity Base', category: 'NETWORK', value: 485.4, unit: 'Million Users', changePct: 8.6, sourceRecord: 'TELECOM-SUBSCRIBER-DB-MAIN', status: 'TARGET_MET' },
  { id: 'KPI-NETWORK-TRAFFIC', name: 'Daily Data Traffic', category: 'NETWORK', value: 412, unit: 'Petabytes / day', changePct: 24.1, sourceRecord: 'NOC-TRAFFIC-TELEMETRY-MAIN', status: 'HEALTHY' },
  { id: 'KPI-RETAIL-SALES', name: 'Retail Network Footprint', category: 'RETAIL', value: 18940, unit: 'Operational Stores', changePct: 11.3, sourceRecord: 'RETAIL-STORE-MASTER-INDIA', status: 'TARGET_MET' },
  { id: 'KPI-CARBON-INTENSITY', name: 'Group Scope 1+2 Emissions', category: 'SUSTAINABILITY', value: 28.4, unit: 'Million tCO2e', changePct: -6.8, sourceRecord: 'ESG-CARBON-LEDGER-2026', status: 'HEALTHY' },
  { id: 'KPI-SAFETY-INDEX', name: 'Group Lost Time Incident Rate', category: 'OPERATIONAL', value: 0.04, unit: 'LTIR per 1M hrs', changePct: -15.0, sourceRecord: 'HSE-SAFETY-CLEARANCE-LOG', status: 'TARGET_MET' }
];

export const INITIAL_CAPITAL_REQUESTS: CapitalRequest[] = [
  {
    id: 'CAP-2026-001',
    title: '50GW Jamnagar Solar Wafer & Cell Expansion (Phase III)',
    businessUnit: 'Green Energy & Materials',
    category: 'NEW_ENERGY',
    amountCrores: 18500,
    capexType: 'GROWTH',
    fundingSource: 'GREEN_BONDS',
    npvCrores: 24100,
    irrPercentage: 22.4,
    roicPercentage: 19.8,
    paybackYears: 4.2,
    riskAdjustedReturn: 18.5,
    carbonImpactTons: -4200000,
    status: 'BOARD_APPROVED',
    requestedBy: 'Dr. A. Sharma (Director, New Energy)',
    date: '2026-08-15'
  },
  {
    id: 'CAP-2026-002',
    title: '5G SA Network Densification & 6G Innovation Testbed',
    businessUnit: 'Jio Platforms',
    category: 'TELECOM',
    amountCrores: 14200,
    capexType: 'GROWTH',
    fundingSource: 'INTERNAL_ACCRUALS',
    npvCrores: 19800,
    irrPercentage: 21.0,
    roicPercentage: 18.2,
    paybackYears: 3.8,
    riskAdjustedReturn: 17.2,
    carbonImpactTons: -180000,
    status: 'COMMITTED',
    requestedBy: 'V. Ramanathan (CTO, Network Infra)',
    date: '2026-07-28'
  },
  {
    id: 'CAP-2026-003',
    title: 'Jamnagar Deep Conversion Hydrogen Electrolyser Hub',
    businessUnit: 'Oil-to-Chemicals',
    category: 'O2C',
    amountCrores: 9500,
    capexType: 'SUSTAINABILITY',
    fundingSource: 'GREEN_BONDS',
    npvCrores: 11200,
    irrPercentage: 17.5,
    roicPercentage: 16.1,
    paybackYears: 5.1,
    riskAdjustedReturn: 14.8,
    carbonImpactTons: -2900000,
    status: 'BOARD_APPROVED',
    requestedBy: 'P. Mehta (VP, Refining Operations)',
    date: '2026-09-02'
  },
  {
    id: 'CAP-2026-004',
    title: 'Pan-India Hyperlocal Dark Store Automated Fulfillment (500 Stores)',
    businessUnit: 'Reliance Retail Ventures',
    category: 'RETAIL',
    amountCrores: 4800,
    capexType: 'GROWTH',
    fundingSource: 'INTERNAL_ACCRUALS',
    npvCrores: 7600,
    irrPercentage: 26.8,
    roicPercentage: 24.2,
    paybackYears: 2.7,
    riskAdjustedReturn: 22.1,
    carbonImpactTons: -45000,
    status: 'PROPOSED',
    requestedBy: 'S. Kulkarni (Head of Supply Chain)',
    date: '2026-09-10'
  }
];

export const INITIAL_INDUSTRIAL_ASSETS: IndustrialAsset[] = [
  {
    id: 'AST-JMN-REF-01',
    name: 'Jamnagar Mega Refinery & Coker Complex',
    assetType: 'Refinery',
    category: 'O2C',
    location: 'Jamnagar, Gujarat',
    state: 'Gujarat',
    capacity: '1,400,000 BPD',
    currentOutput: '1,385,000 BPD',
    utilisationPct: 98.9,
    status: 'OPERATING',
    bookValueCrores: 185000,
    replacementValueCrores: 240000,
    energyConsumptionMW: 1250,
    riskScore: 12,
    carbonIntensity: '0.38 tCO2e / Ton',
    healthIndex: 96,
    lastTelemetryTimestamp: '2026-09-12T11:48:10Z'
  },
  {
    id: 'AST-KGD6-OFFSHORE',
    name: 'KG-D6 Deepwater Gas Field (Ruby & Satellite Fields)',
    assetType: 'OilField',
    category: 'OIL_GAS',
    location: 'Krishna Godavari Basin Offshore',
    state: 'Andhra Pradesh Offshore',
    capacity: '35.0 MMSCMD',
    currentOutput: '30.4 MMSCMD',
    utilisationPct: 86.8,
    status: 'OPERATING',
    bookValueCrores: 42000,
    replacementValueCrores: 58000,
    energyConsumptionMW: 180,
    riskScore: 24,
    carbonIntensity: '0.19 tCO2e / kNm3',
    healthIndex: 92,
    lastTelemetryTimestamp: '2026-09-12T11:49:02Z'
  },
  {
    id: 'AST-JMN-SOLAR-01',
    name: 'Dhirubhai Ambani Green Energy Solar Giga Complex',
    assetType: 'SolarFarm',
    category: 'NEW_ENERGY',
    location: 'Jamnagar New Energy Zone',
    state: 'Gujarat',
    capacity: '20,000 MW / year',
    currentOutput: '18,400 MW / year',
    utilisationPct: 92.0,
    status: 'OPERATING',
    bookValueCrores: 38000,
    replacementValueCrores: 45000,
    energyConsumptionMW: 45,
    riskScore: 8,
    carbonIntensity: '0.02 tCO2e / MW',
    healthIndex: 99,
    lastTelemetryTimestamp: '2026-09-12T11:45:00Z'
  },
  {
    id: 'AST-JMN-BATT-01',
    name: 'Giga Battery Energy Storage Factory (LFP Chemistry)',
    assetType: 'BatteryPlant',
    category: 'NEW_ENERGY',
    location: 'Jamnagar New Energy Hub',
    state: 'Gujarat',
    capacity: '30 GWh Annual',
    currentOutput: '26.8 GWh Annual',
    utilisationPct: 89.3,
    status: 'OPERATING',
    bookValueCrores: 26000,
    replacementValueCrores: 32000,
    energyConsumptionMW: 310,
    riskScore: 15,
    carbonIntensity: '0.12 tCO2e / kWh',
    healthIndex: 94,
    lastTelemetryTimestamp: '2026-09-12T11:47:33Z'
  },
  {
    id: 'AST-JIO-DC-MUMBAI',
    name: 'Jio Hyperscale AI Data Centre - Mumbai 01',
    assetType: 'DataCentre',
    category: 'CLOUD',
    location: 'Navi Mumbai',
    state: 'Maharashtra',
    capacity: '120 MW IT Power',
    currentOutput: '108 MW IT Power',
    utilisationPct: 90.0,
    status: 'OPERATING',
    bookValueCrores: 14500,
    replacementValueCrores: 18000,
    energyConsumptionMW: 135,
    riskScore: 6,
    carbonIntensity: '0.28 tCO2e / MWh',
    healthIndex: 98,
    lastTelemetryTimestamp: '2026-09-12T11:49:55Z'
  },
  {
    id: 'AST-RTL-DC-BHIWANDI',
    name: 'Bhiwandi National Distribution Center (Mega FC)',
    assetType: 'Warehouse',
    category: 'RETAIL',
    location: 'Bhiwandi, Thane',
    state: 'Maharashtra',
    capacity: '1,500,000 Sq Ft',
    currentOutput: '1,320,000 Sq Ft Occupied',
    utilisationPct: 88.0,
    status: 'OPERATING',
    bookValueCrores: 3200,
    replacementValueCrores: 4100,
    energyConsumptionMW: 12,
    riskScore: 10,
    carbonIntensity: '0.08 tCO2e / SqFt',
    healthIndex: 95,
    lastTelemetryTimestamp: '2026-09-12T11:50:00Z'
  }
];

export const INITIAL_NETWORK_SITES: NetworkSite[] = [
  { siteId: 'TOW-MUM-4011', name: 'Bandra Kurla Complex Giga 5G Macro', circle: 'Mumbai', region: 'West', towerType: '5G_GIGA', connectedCells: 24, activeUsers: 14850, trafficGbps: 8.4, latencyMs: 6.2, packetLossPct: 0.01, backhaulType: 'FIBER_10G', powerBackupMin: 240, status: 'OPTIMAL' },
  { siteId: 'TOW-DEL-8821', name: 'Connaught Place Core 5G Node', circle: 'Delhi NCR', region: 'North', towerType: '5G_GIGA', connectedCells: 18, activeUsers: 18900, trafficGbps: 11.2, latencyMs: 7.1, packetLossPct: 0.02, backhaulType: 'FIBER_10G', powerBackupMin: 360, status: 'OPTIMAL' },
  { siteId: 'TOW-GUJ-1044', name: 'Jamnagar Refinery Peripheral Macro', circle: 'Gujarat', region: 'West', towerType: 'MACRO', connectedCells: 12, activeUsers: 4200, trafficGbps: 3.1, latencyMs: 12.4, packetLossPct: 0.05, backhaulType: 'FIBER_10G', powerBackupMin: 480, status: 'OPTIMAL' },
  { siteId: 'TOW-TN-5520', name: 'Chennai Tech Corridor Small Cell', circle: 'Tamil Nadu', region: 'South', towerType: 'SMALL_CELL', connectedCells: 8, activeUsers: 6800, trafficGbps: 4.8, latencyMs: 8.0, packetLossPct: 0.12, backhaulType: 'FIBER_10G', powerBackupMin: 180, status: 'CONGESTED' },
  { siteId: 'TOW-KA-9012', name: 'Bengaluru Electronic City Node 04', circle: 'Karnataka', region: 'South', towerType: '5G_GIGA', connectedCells: 32, activeUsers: 22100, trafficGbps: 14.5, latencyMs: 5.8, packetLossPct: 0.01, backhaulType: 'FIBER_10G', powerBackupMin: 300, status: 'OPTIMAL' }
];

export const INITIAL_NETWORK_INCIDENTS: NetworkIncident[] = [
  {
    incidentId: 'INC-2026-9041',
    title: 'Chennai Tech Corridor Optical Fiber Degradation',
    affectedCircle: 'Tamil Nadu',
    siteId: 'TOW-TN-5520',
    severity: 'MAJOR',
    status: 'INVESTIGATING',
    detectedAt: '2026-09-12T10:14:00Z',
    assignedEngineer: 'R. Iyengar (NOC Level-3)',
    affectedSubscribers: 12400,
    rootCause: 'Third-party road digging cut primary fiber channel; secondary ring active.'
  },
  {
    incidentId: 'INC-2026-9042',
    title: 'Cell Congestion Peak during Festive Promo in Delhi NCR',
    affectedCircle: 'Delhi NCR',
    siteId: 'TOW-DEL-8821',
    severity: 'MINOR',
    status: 'MITIGATING',
    detectedAt: '2026-09-12T11:02:00Z',
    assignedEngineer: 'A. Verma (Radio Network Optimization)',
    affectedSubscribers: 8900,
    rootCause: 'Transient traffic surge; dynamically beam-forming extra capacity from adjacent macro.'
  }
];

export const INITIAL_RETAIL_STORES: RetailStore[] = [
  { storeId: 'STR-MUM-01', name: 'Reliance Smart Bazaar - Malad West', format: 'HYPERMARKET', city: 'Mumbai', state: 'Maharashtra', footfallToday: 12450, conversionRatePct: 78.5, dailySalesINR: 4250000, onHandInventorySKUs: 34000, energyConsumptionkWh: 1250, status: 'OPEN' },
  { storeId: 'STR-DEL-14', name: 'Reliance Digital Megastore - South Extension', format: 'ELECTRONICS', city: 'Delhi', state: 'Delhi NCR', footfallToday: 5800, conversionRatePct: 42.1, dailySalesINR: 8900000, onHandInventorySKUs: 14200, energyConsumptionkWh: 1800, status: 'OPEN' },
  { storeId: 'STR-BLR-08', name: 'JioMart Express Dark Store - Indiranagar', format: 'DARK_STORE', city: 'Bengaluru', state: 'Karnataka', footfallToday: 0, conversionRatePct: 96.2, dailySalesINR: 3100000, onHandInventorySKUs: 8500, energyConsumptionkWh: 620, status: 'OPERATING' },
  { storeId: 'STR-AMD-03', name: 'Trends Fashion Hub - CG Road', format: 'FASHION', city: 'Ahmedabad', state: 'Gujarat', footfallToday: 7400, conversionRatePct: 61.0, dailySalesINR: 2800000, onHandInventorySKUs: 22000, energyConsumptionkWh: 910, status: 'OPEN' }
];

export const INITIAL_QUICK_COMMERCE_DELIVERIES: QuickCommerceDelivery[] = [
  { orderId: 'ORD-JIO-88120', customerLocation: 'Indiranagar Block 4, Bengaluru', darkStoreId: 'STR-BLR-08', pickerName: 'Suresh Kumar', riderName: 'Ramesh P', distanceKm: 2.1, calculatedEtaMinutes: 11, itemsCount: 7, orderTotalINR: 1240, status: 'OUT_FOR_DELIVERY' },
  { orderId: 'ORD-JIO-88121', customerLocation: 'Koramangala 5th Block, Bengaluru', darkStoreId: 'STR-BLR-08', pickerName: 'Anita Roy', riderName: 'Kiran G', distanceKm: 3.8, calculatedEtaMinutes: 14, itemsCount: 12, orderTotalINR: 2890, status: 'PICKING' }
];

export const INITIAL_AI_MODELS: AIModelArtifact[] = [
  { modelId: 'MDL-JIOBRAIN-OPT-v4', name: 'REOS Network Traffic Optimization LLM', domain: 'TELECOM', version: 'v4.2.1', accuracyScore: 0.984, lastTrainedAt: '2026-09-01', gpuClusterAllocated: 'GPU-CLUSTER-JMN-01', status: 'DEPLOYED' },
  { modelId: 'MDL-O2C-YIELD-v3', name: 'Jamnagar Coker Yield Predictor Twin', domain: 'O2C', version: 'v3.8.0', accuracyScore: 0.991, lastTrainedAt: '2026-08-28', gpuClusterAllocated: 'GPU-CLUSTER-JMN-02', status: 'DEPLOYED' },
  { modelId: 'MDL-RETAIL-DEMAND-v5', name: 'JioMart Hyperlocal Inventory Engine', domain: 'RETAIL', version: 'v5.1.0', accuracyScore: 0.976, lastTrainedAt: '2026-09-05', gpuClusterAllocated: 'GPU-CLUSTER-MUM-01', status: 'DEPLOYED' }
];

export const INITIAL_AI_RECOMMENDATIONS: AIRecommendation[] = [
  {
    id: 'REC-AI-2026-881',
    title: 'Re-route Jamnagar Coker Naphtha Feed to Polymer Cracker 2',
    domain: 'Oil-to-Chemicals',
    model: 'Jamnagar Coker Yield Predictor Twin',
    version: 'v3.8.0',
    dataSource: 'O2C Sensor Stream #JMN-CRK-88 + Global Naphtha Spot Index',
    timestamp: '2026-09-12T11:30:00Z',
    confidenceScore: 0.96,
    reasoningSummary: 'Global polymer spread increased by 4.2%. Redirecting 1,200 MT/day of heavy naphtha yields ₹1.8 Cr/day additional gross margin.',
    recommendedAction: 'Adjust valve trim V-401 to 68% open for Polymer Unit 2.',
    requiresHumanApproval: true,
    status: 'PENDING_HUMAN_APPROVAL'
  },
  {
    id: 'REC-AI-2026-882',
    title: 'Pre-charge Battery Giga Pack #4 at Off-Peak Solar Window',
    domain: 'New Energy',
    model: 'Green Energy Storage Optimizer',
    version: 'v2.1.0',
    dataSource: 'Jamnagar Solar Array Live Generation + Grid Tariff Schedule',
    timestamp: '2026-09-12T11:40:00Z',
    confidenceScore: 0.98,
    reasoningSummary: 'Solar generation peak expected in 45 mins. Pre-charging 500 MWh battery storage saves ₹42 Lakhs in peak grid draw.',
    recommendedAction: 'Trigger Battery BMS Charge State profile #B-SOLAR-FAST.',
    requiresHumanApproval: false,
    status: 'EXECUTED'
  }
];

export const INITIAL_CARBON_RECORDS: CarbonLedgerRecord[] = [
  { id: 'CAR-001', assetId: 'AST-JMN-REF-01', assetName: 'Jamnagar Mega Refinery', businessUnit: 'O2C', scope: 'Scope 1', co2eTons: 18450, measurementMethod: 'CEMS_CONTINUOUS', timestamp: '2026-09-12T11:00:00Z', confidenceScore: 0.99 },
  { id: 'CAR-002', assetId: 'AST-KGD6-OFFSHORE', assetName: 'KG-D6 Deepwater Field', businessUnit: 'OIL_GAS', scope: 'Scope 1', co2eTons: 2100, measurementMethod: 'CEMS_CONTINUOUS', timestamp: '2026-09-12T11:00:00Z', confidenceScore: 0.98 },
  { id: 'CAR-003', assetId: 'AST-JIO-DC-MUMBAI', assetName: 'Jio Hyperscale DC Mumbai', businessUnit: 'CLOUD', scope: 'Scope 2', co2eTons: 840, measurementMethod: 'UTILITY_BILL', timestamp: '2026-09-12T11:00:00Z', confidenceScore: 0.95 }
];

export const INITIAL_AUDIT_RECORDS: AuditRecord[] = [
  {
    auditId: 'AUD-2026-99120',
    userId: 'USR-EXEC-001',
    userName: 'K. Reliance Executive',
    userRole: 'GroupExecutive',
    deviceInfo: 'Industrial Rugged Slate Pro (Ktor/Kotlin OS)',
    timestamp: '2026-09-12T11:42:15Z',
    ipAddress: '10.140.4.12 (Internal OT/IT Gateway)',
    action: 'CAPITAL_ALLOCATION_APPROVE',
    targetObject: 'CapitalRequest #CAP-2026-001 (Jamnagar Solar Wafer Phase III)',
    beforeState: 'PROPOSED',
    afterState: 'BOARD_APPROVED',
    reason: 'Strategic Alignment with 2030 Net Zero & 100GW Target',
    policyValidationPassed: true,
    correlationId: 'CORR-CAP-9012'
  },
  {
    auditId: 'AUD-2026-99121',
    userId: 'USR-NOC-009',
    userName: 'R. Iyengar',
    userRole: 'NetworkEngineer',
    deviceInfo: 'NOC Terminal #04',
    timestamp: '2026-09-12T11:45:00Z',
    ipAddress: '10.220.8.44',
    action: 'INCIDENT_UPDATE',
    targetObject: 'NetworkIncident #INC-2026-9041',
    beforeState: 'CLASSIFIED',
    afterState: 'INVESTIGATING',
    reason: 'Field dispatch confirmed fiber cut location',
    policyValidationPassed: true,
    correlationId: 'CORR-NOC-8812'
  }
];

export const REOS_REPOSITORY_STRUCTURE = [
  {
    path: 'reliance-enterprise-os/backend/',
    description: 'Python 3.12 FastAPI core engine with Pydantic v2 schemas and OpenTelemetry integration'
  },
  {
    path: 'reliance-enterprise-os/rust-core/',
    description: 'Rust high-throughput telemetry parser, stream processor, and cryptographic audit engine'
  },
  {
    path: 'reliance-enterprise-os/android/',
    description: 'Kotlin Jetpack Compose, Coroutines, Flow, Ktor & Room tablet-first industrial client'
  },
  {
    path: 'reliance-enterprise-os/database/',
    description: 'PostgreSQL relational schemas, Alembic migrations, DDL constraints & seed scripts'
  },
  {
    path: 'reliance-enterprise-os/openapi/',
    description: 'OpenAPI 3.1 canonical endpoints specifications for all 12 enterprise business domains'
  },
  {
    path: 'reliance-enterprise-os/simulation/',
    description: 'Monte Carlo & deterministic scenario simulator for energy shocks and retail demand spikes'
  },
  {
    path: 'reliance-enterprise-os/tests/',
    description: 'Unit, integration, property-based, financial decimal, OT security & localisation test suites'
  },
  {
    path: 'reliance-enterprise-os/docs/',
    description: 'Architecture documentation, domain model maps, financial rules & Indian language specs'
  }
];
