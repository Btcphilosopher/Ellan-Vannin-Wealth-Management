/**
 * RELIANCE ENTERPRISE OPERATING SYSTEM (REOS)
 * Synthetic Enterprise Reference Architecture Data Models & Types
 */

export type BusinessCategory = 
  | 'ENERGY'
  | 'O2C'
  | 'PETROCHEMICALS'
  | 'OIL_GAS'
  | 'RETAIL'
  | 'DIGITAL'
  | 'TELECOM'
  | 'CLOUD'
  | 'AI'
  | 'MEDIA'
  | 'NEW_ENERGY'
  | 'NEW_MATERIALS';

export type RoleType = 
  | 'GroupExecutive'
  | 'CFO'
  | 'COO'
  | 'CTO'
  | 'CIO'
  | 'BusinessCEO'
  | 'PlantManager'
  | 'RefineryManager'
  | 'NetworkEngineer'
  | 'CloudEngineer'
  | 'AIEngineer'
  | 'RetailManager'
  | 'StoreManager'
  | 'SupplyChainManager'
  | 'FinanceManager'
  | 'SecurityOfficer'
  | 'Employee'
  | 'Customer';

export type IndianLanguage = 
  | 'English'
  | 'Hindi'
  | 'Tamil'
  | 'Telugu'
  | 'Bengali'
  | 'Marathi'
  | 'Gujarati'
  | 'Kannada'
  | 'Malayalam'
  | 'Punjabi'
  | 'Odia'
  | 'Assamese';

// Group Structure & Hierarchy
export interface RelianceGroup {
  id: string;
  name: string;
  code: string;
  holdingCompany: string;
  legalEntitiesCount: number;
  totalCapExAllocated: number; // In INR Crores
  currency: 'INR' | 'USD' | 'EUR';
}

export interface BusinessEntity {
  id: string;
  name: string;
  category: BusinessCategory;
  legalEntity: string;
  country: string;
  currency: string;
  headquarters: string;
  costCentres: string[];
  profitCentres: string[];
  revenueCrores: number;
  ebitdaCrores: number;
  assetValueCrores: number;
  employeeCount: number;
}

// Enterprise Graph Node & Edge
export interface GraphNode {
  id: string;
  name: string;
  category: BusinessCategory | 'CAPITAL' | 'CUSTOMER' | 'AI_PLATFORM';
  type: string;
  metricsSummary: string;
  status: 'OPTIMAL' | 'WARNING' | 'CRITICAL' | 'MAINTENANCE';
  location?: string;
}

export interface GraphEdge {
  id: string;
  sourceId: string;
  targetId: string;
  flowType: 'FEEDSTOCK' | 'PRODUCT' | 'CONNECTIVITY' | 'CAPITAL' | 'DATA' | 'POWER' | 'LOGISTICS';
  capacityRate: string;
  volumeToday: string;
}

// Executive KPI
export interface GroupKPI {
  id: string;
  name: string;
  category: 'FINANCIAL' | 'OPERATIONAL' | 'NETWORK' | 'RETAIL' | 'SUSTAINABILITY' | 'AI';
  value: number; // Internal raw value
  unit: string;
  changePct: number;
  displayLakhCrore?: string;
  sourceRecord: string; // Traceability URI / Record ID
  status: 'HEALTHY' | 'ALERT' | 'TARGET_MET';
}

// Capital Allocation Subsystem
export type ScenarioType = 'BASE' | 'UPSIDE' | 'DOWNSIDE' | 'STRESS' | 'TRANSITION' | 'HIGH_DEMAND' | 'LOW_DEMAND';

export interface CapitalRequest {
  id: string;
  title: string;
  businessUnit: string;
  category: BusinessCategory;
  amountCrores: number; // Stored with exact decimal precision
  capexType: 'GROWTH' | 'SUSTAINABILITY' | 'MAINTENANCE' | 'DIGITAL_TRANSFORMATION';
  fundingSource: 'INTERNAL_ACCRUALS' | 'GREEN_BONDS' | 'DEBT_FACILITY' | 'EQUITY';
  npvCrores: number;
  irrPercentage: number;
  roicPercentage: number;
  paybackYears: number;
  riskAdjustedReturn: number;
  carbonImpactTons: number;
  status: 'PROPOSED' | 'UNDER_REVIEW' | 'BOARD_APPROVED' | 'COMMITTED' | 'REJECTED';
  requestedBy: string;
  date: string;
}

// Industrial Assets & Digital Twins
export type AssetType = 
  | 'OilField'
  | 'Refinery'
  | 'Cracker'
  | 'ChemicalPlant'
  | 'SolarFarm'
  | 'BatteryPlant'
  | 'Electrolyser'
  | 'HydrogenPlant'
  | 'NetworkTower'
  | 'DataCentre'
  | 'RetailStore'
  | 'DarkStore'
  | 'Warehouse';

export interface IndustrialAsset {
  id: string;
  name: string;
  assetType: AssetType;
  category: BusinessCategory;
  location: string;
  state: string;
  capacity: string;
  currentOutput: string;
  utilisationPct: number;
  status: 'OPERATING' | 'RESTOCKING' | 'MAINTENANCE' | 'OFFLINE';
  bookValueCrores: number;
  replacementValueCrores: number;
  energyConsumptionMW: number;
  riskScore: number; // 0 - 100
  carbonIntensity: string; // e.g. "0.42 tCO2e/t"
  healthIndex: number;
  lastTelemetryTimestamp: string;
}

// Telecom / Jio Network Engine & NOC
export interface NetworkSite {
  siteId: string;
  name: string;
  circle: string; // Indian Telecom Circle (e.g. Mumbai, Delhi, Tamil Nadu, Gujarat)
  region: string;
  towerType: 'MACRO' | 'MICRO' | 'SMALL_CELL' | '5G_GIGA';
  connectedCells: number;
  activeUsers: number;
  trafficGbps: number;
  latencyMs: number;
  packetLossPct: number;
  backhaulType: 'FIBER_10G' | 'MICROWAVE' | 'SATELLITE';
  powerBackupMin: number;
  status: 'OPTIMAL' | 'CONGESTED' | 'FAULT' | 'POWER_SAVING';
}

export interface NetworkIncident {
  incidentId: string;
  title: string;
  affectedCircle: string;
  siteId: string;
  severity: 'CRITICAL' | 'MAJOR' | 'MINOR';
  status: 'DETECTED' | 'CLASSIFIED' | 'ASSIGNED' | 'INVESTIGATING' | 'MITIGATING' | 'RESOLVED' | 'VERIFIED' | 'CLOSED';
  detectedAt: string;
  assignedEngineer: string;
  affectedSubscribers: number;
  rootCause?: string;
}

// Retail & Commerce
export interface RetailStore {
  storeId: string;
  name: string;
  format: 'HYPERMARKET' | 'SMART_SUPERMARKET' | 'ELECTRONICS' | 'FASHION' | 'DARK_STORE';
  city: string;
  state: string;
  footfallToday: number;
  conversionRatePct: number;
  dailySalesINR: number;
  onHandInventorySKUs: number;
  energyConsumptionkWh: number;
  status: 'OPEN' | 'OPERATING' | 'RESTOCKING' | 'MAINTENANCE' | 'CLOSING';
}

export interface QuickCommerceDelivery {
  orderId: string;
  customerLocation: string;
  darkStoreId: string;
  pickerName: string;
  riderName: string;
  distanceKm: number;
  calculatedEtaMinutes: number;
  itemsCount: number;
  orderTotalINR: number;
  status: 'PLACED' | 'PICKING' | 'PACKED' | 'OUT_FOR_DELIVERY' | 'DELIVERED';
}

// Enterprise AI & Governance
export interface AIModelArtifact {
  modelId: string;
  name: string;
  domain: BusinessCategory;
  version: string;
  accuracyScore: number;
  lastTrainedAt: string;
  gpuClusterAllocated: string;
  status: 'TRAINING' | 'EVALUATING' | 'DEPLOYED' | 'RETRAIN_REQUIRED';
}

export interface AIRecommendation {
  id: string;
  title: string;
  domain: string;
  model: string;
  version: string;
  dataSource: string;
  timestamp: string;
  confidenceScore: number; // 0.00 to 1.00
  reasoningSummary: string;
  recommendedAction: string;
  requiresHumanApproval: boolean;
  status: 'PENDING_HUMAN_APPROVAL' | 'APPROVED' | 'REJECTED' | 'EXECUTED';
  approvedBy?: string;
}

// ESG Carbon Ledger
export interface CarbonLedgerRecord {
  id: string;
  assetId: string;
  assetName: string;
  businessUnit: BusinessCategory;
  scope: 'Scope 1' | 'Scope 2' | 'Scope 3';
  co2eTons: number;
  measurementMethod: 'CEMS_CONTINUOUS' | 'UTILITY_BILL' | 'EMISSION_FACTOR_ESTIMATE';
  timestamp: string;
  confidenceScore: number;
}

// Security & Audit
export interface AuditRecord {
  auditId: string;
  userId: string;
  userName: string;
  userRole: RoleType;
  deviceInfo: string;
  timestamp: string;
  ipAddress: string;
  action: string;
  targetObject: string;
  beforeState: string;
  afterState: string;
  reason: string;
  policyValidationPassed: boolean;
  correlationId: string;
}

// Scenario Simulation
export interface SimulationScenario {
  id: string;
  name: string;
  oilPriceChangePct: number; // e.g., +20%
  gasProductionChangePct: number; // e.g., -10%
  retailDemandChangePct: number; // e.g., +15%
  networkTrafficMultiplier: number; // e.g., 2.0x
  inrUsdExchangeRate: number; // e.g. 84.50
  solarEfficiencyDeltaPct: number;
}

export interface SimulationResult {
  scenarioName: string;
  projectedRevenueCrores: number;
  projectedEbitdaCrores: number;
  projectedCashImpactCrores: number;
  netCarbonImpactTons: number;
  riskScoreDelta: number;
  bottlenecksIdentified: string[];
}

export interface SystemLanguageConfig {
  code: IndianLanguage;
  nativeName: string;
  bannerNotice: string;
}
