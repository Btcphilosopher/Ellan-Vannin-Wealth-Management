-- RELIANCE ENTERPRISE OPERATING SYSTEM (REOS)
-- Relational Enterprise Database Schema (PostgreSQL 16+)
-- Enforces Foreign Keys, Unique Constraints, Immutable Ledgers & Versioning

CREATE SCHEMA IF NOT EXISTS reos;

-- 1. GROUP STRUCTURE
CREATE TABLE reos.holding_company (
    id VARCHAR(64) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    country VARCHAR(64) NOT NULL DEFAULT 'India',
    currency VARCHAR(8) NOT NULL DEFAULT 'INR',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE reos.business_unit (
    id VARCHAR(64) PRIMARY KEY,
    holding_id VARCHAR(64) REFERENCES reos.holding_company(id),
    name VARCHAR(255) NOT NULL,
    category VARCHAR(32) NOT NULL CHECK (category IN (
        'ENERGY', 'O2C', 'PETROCHEMICALS', 'OIL_GAS', 'RETAIL', 'DIGITAL', 
        'TELECOM', 'CLOUD', 'AI', 'MEDIA', 'NEW_ENERGY', 'NEW_MATERIALS'
    )),
    legal_entity VARCHAR(255) NOT NULL,
    cost_centre_code VARCHAR(64) UNIQUE NOT NULL,
    profit_centre_code VARCHAR(64) UNIQUE NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 2. CAPITAL ALLOCATION ENGINE (Exact Numeric for Money)
CREATE TABLE reos.capital_request (
    id VARCHAR(64) PRIMARY KEY,
    business_unit_id VARCHAR(64) REFERENCES reos.business_unit(id),
    title VARCHAR(255) NOT NULL,
    amount_crores NUMERIC(18, 4) NOT NULL CHECK (amount_crores > 0),
    funding_source VARCHAR(64) NOT NULL,
    npv_crores NUMERIC(18, 4) NOT NULL,
    irr_pct NUMERIC(6, 2) NOT NULL,
    roic_pct NUMERIC(6, 2) NOT NULL,
    payback_years NUMERIC(6, 2) NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'PROPOSED' CHECK (status IN ('PROPOSED', 'UNDER_REVIEW', 'BOARD_APPROVED', 'COMMITTED', 'REJECTED')),
    requested_by VARCHAR(128) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 3. INDUSTRIAL ASSET GRAPH
CREATE TABLE reos.industrial_asset (
    id VARCHAR(64) PRIMARY KEY,
    business_unit_id VARCHAR(64) REFERENCES reos.business_unit(id),
    name VARCHAR(255) NOT NULL,
    asset_type VARCHAR(64) NOT NULL,
    location_state VARCHAR(128) NOT NULL,
    capacity_descriptor VARCHAR(128) NOT NULL,
    book_value_crores NUMERIC(18, 4) NOT NULL,
    health_index INT CHECK (health_index BETWEEN 0 AND 100),
    status VARCHAR(32) DEFAULT 'OPERATING',
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 4. ESG CARBON LEDGER (IMMUTABLE)
CREATE TABLE reos.carbon_ledger (
    id VARCHAR(64) PRIMARY KEY,
    asset_id VARCHAR(64) REFERENCES reos.industrial_asset(id),
    scope VARCHAR(16) NOT NULL CHECK (scope IN ('Scope 1', 'Scope 2', 'Scope 3')),
    co2e_tons NUMERIC(14, 4) NOT NULL,
    measurement_method VARCHAR(64) NOT NULL,
    confidence_score NUMERIC(4, 3) NOT NULL,
    recorded_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- 5. IMMUTABLE AUDIT TRAIL
CREATE TABLE reos.audit_trail (
    audit_id VARCHAR(64) PRIMARY KEY,
    user_id VARCHAR(64) NOT NULL,
    user_role VARCHAR(64) NOT NULL,
    action VARCHAR(64) NOT NULL,
    target_object VARCHAR(255) NOT NULL,
    before_state JSONB,
    after_state JSONB,
    reason TEXT NOT NULL,
    policy_passed BOOLEAN NOT NULL,
    correlation_id VARCHAR(64) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);
