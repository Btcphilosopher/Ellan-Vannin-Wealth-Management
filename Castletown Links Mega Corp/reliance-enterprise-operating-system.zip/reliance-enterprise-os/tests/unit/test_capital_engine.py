import pytest
from decimal import Decimal
from backend.capital.engine import CapitalAllocationEngine, CapitalProjectModel

def test_npv_and_payback_calculation():
    engine = CapitalAllocationEngine()
    project = CapitalProjectModel(
        project_id="TEST-001",
        title="Test Solar Project",
        business_unit="New Energy",
        initial_outlay_crores=Decimal("1000.00"),
        cash_flows_year_1_to_5=[Decimal("300.00"), Decimal("350.00"), Decimal("400.00"), Decimal("400.00"), Decimal("400.00")],
        discount_rate_pct=Decimal("10.0"),
        carbon_impact_tons=Decimal("-50000.0")
    )
    
    base_res = engine.evaluate_project(project, scenario="BASE")
    assert base_res.npv_crores > Decimal("0")
    assert base_res.payback_years > Decimal("2.0") and base_res.payback_years < Decimal("4.0")
    assert base_res.roic_pct > Decimal("30.0")

def test_scenario_shock_stress():
    engine = CapitalAllocationEngine()
    project = CapitalProjectModel(
        project_id="TEST-002",
        title="Refinery Modernization",
        business_unit="O2C",
        initial_outlay_crores=Decimal("500.00"),
        cash_flows_year_1_to_5=[Decimal("100.00"), Decimal("100.00"), Decimal("100.00"), Decimal("100.00"), Decimal("100.00")],
        discount_rate_pct=Decimal("10.0"),
        carbon_impact_tons=Decimal("0.0")
    )
    
    stress_res = engine.evaluate_project(project, scenario="STRESS")
    assert stress_res.npv_crores < engine.evaluate_project(project, scenario="BASE").npv_crores
