package com.reliance.reos.executive

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * REOS Rugged Tablet & Executive Client
 * Built with Jetpack Compose, Ktor Client, Coroutines & Flow
 */
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ExecutiveDashboardScreen()
                }
            }
        }
    }
}

@Composable
fun ExecutiveDashboardScreen() {
    Column(modifier = Modifier.padding(16.dp)) {
        Text(
            text = "RELIANCE ENTERPRISE OPERATING SYSTEM (REOS)",
            style = MaterialTheme.typography.headlineMedium
        )
        Text(
            text = "SYNTHETIC DATA | सिंथेटिक डेटा",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.error
        )
        Spacer(modifier = Modifier.height(16.dp))
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "Consolidated Revenue: ₹9,84,500 Cr", style = MaterialTheme.typography.titleLarge)
                Text(text = "Group EBITDA: ₹1,68,500 Cr", style = MaterialTheme.typography.bodyLarge)
                Text(text = "Active Telecom Base: 485.4M", style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}
