//! RELIANCE ENTERPRISE OPERATING SYSTEM (REOS) - High-Throughput Rust Telemetry Engine
//! 
//! Provides low-latency, deterministic processing for industrial sensors, 
//! network cell packets, and financial ledger validation.

use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct IndustrialTelemetryPacket {
    pub asset_id: String,
    pub timestamp_epoch_ms: u64,
    pub temperature_celsius: f64,
    pub pressure_bar: f64,
    pub flow_rate_m3h: f64,
    pub vibration_mm_s: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TelemetryProcessResult {
    pub asset_id: String,
    pub health_score: u8,
    pub anomaly_detected: bool,
    pub carbon_estimate_kg: f64,
}

pub struct TelemetryEngine;

impl TelemetryEngine {
    pub fn evaluate_packet(packet: &IndustrialTelemetryPacket) -> TelemetryProcessResult {
        let mut anomaly = false;
        let mut health = 100u8;

        if packet.temperature_celsius > 350.0 || packet.vibration_mm_s > 4.5 {
            anomaly = true;
            health = 75;
        }

        let carbon_kg = (packet.flow_rate_m3h * 0.42) / 1000.0;

        TelemetryProcessResult {
            asset_id: packet.asset_id.clone(),
            health_score: health,
            anomaly_detected: anomaly,
            carbon_estimate_kg: carbon_kg,
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_normal_telemetry() {
        let pkt = IndustrialTelemetryPacket {
            asset_id: "AST-REF-01".into(),
            timestamp_epoch_ms: 1789123400,
            temperature_celsius: 210.0,
            pressure_bar: 45.0,
            flow_rate_m3h: 1200.0,
            vibration_mm_s: 1.2,
        };
        let res = TelemetryEngine::evaluate_packet(&pkt);
        assert_eq!(res.health_score, 100);
        assert!(!res.anomaly_detected);
    }
}
