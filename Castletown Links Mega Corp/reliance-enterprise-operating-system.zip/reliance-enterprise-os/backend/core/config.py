# Python 3.12 Core Configuration Module for RELIANCE ENTERPRISE OPERATING SYSTEM (REOS)
from pydantic_settings import BaseSettings
from decimal import Decimal
import os

class REOSSettings(BaseSettings):
    APP_NAME: str = "RELIANCE ENTERPRISE OPERATING SYSTEM"
    APP_SHORT_NAME: str = "REOS"
    ENV: str = "production"
    SYNTHETIC_DATA_ONLY: bool = True
    DEFAULT_CURRENCY: str = "INR"
    EXCHANGE_RATE_USD_INR: Decimal = Decimal("84.25")
    
    # Database
    DATABASE_URL: str = os.getenv("DATABASE_URL", "postgresql://reos_admin:synth_pass@localhost:5432/reos_db")
    REDIS_URL: str = os.getenv("REDIS_URL", "redis://localhost:6379/0")
    
    # OT Security Policy
    OT_GATEWAY_AIRGAP_ENFORCED: bool = True
    MAX_UNCHECKED_CRITICAL_ACTIONS: int = 0
    
    class Config:
        env_file = ".env"

settings = REOSSettings()
