/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';
import { createServer as createViteServer } from 'vite';

import { MUFG_GROUP_ENTITIES, EXECUTIVE_GROUP_KPIS } from './src/data/groupStructure';
import {
  SYNTHETIC_CUSTOMERS,
  SYNTHETIC_ACCOUNTS,
  SYNTHETIC_LOANS,
  SYNTHETIC_SECURITIES,
  SYNTHETIC_FX_RATES,
  SYNTHETIC_ALM_BUCKETS,
  SYNTHETIC_TREASURY_POSITION,
  SYNTHETIC_JOURNALS,
  SYNTHETIC_RECONCILIATION_CASES,
  SYNTHETIC_PAYMENTS,
  SYNTHETIC_AML_ALERTS,
  SYNTHETIC_RISK_EXPOSURES,
  SYNTHETIC_AUDIT_LOGS
} from './src/data/syntheticDatabase';
import { CANONICAL_FINANCIAL_TERMS, searchFinancialTerms } from './src/data/dictionaryData';
import { evaluateCreditRisk } from './src/engines/creditEngine';
import { validateAndPostJournal } from './src/engines/ledgerEngine';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// ==========================================
// In-Memory Live State (Synthetic Store)
// ==========================================
let customersStore = [...SYNTHETIC_CUSTOMERS];
let accountsStore = [...SYNTHETIC_ACCOUNTS];
let loansStore = [...SYNTHETIC_LOANS];
let journalsStore = [...SYNTHETIC_JOURNALS];
let paymentsStore = [...SYNTHETIC_PAYMENTS];
let amlAlertsStore = [...SYNTHETIC_AML_ALERTS];
let auditLogsStore = [...SYNTHETIC_AUDIT_LOGS];
let reconciliationStore = [...SYNTHETIC_RECONCILIATION_CASES];

// ==========================================
// Gemini AI Financial Copilot Client Setup
// ==========================================
let aiClient: GoogleGenAI | null = null;
function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient && process.env.GEMINI_API_KEY) {
    aiClient = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

// ==========================================
// REST API Endpoints
// ==========================================

// 1. Health & Telemetry
app.get('/api/health', (req, res) => {
  res.json({
    status: 'HEALTHY',
    system: 'MUFG JAPAN FINANCIAL OS',
    version: '3.7.0-ENTERPRISE-PROD',
    environment: 'SYNTHETIC_DEMO_ENVIRONMENT',
    locale: 'ja-JP',
    timestamp: new Date().toISOString()
  });
});

// 2. Group Structure & KPIs
app.get('/api/group-entities', (req, res) => {
  res.json({
    entities: MUFG_GROUP_ENTITIES,
    kpis: EXECUTIVE_GROUP_KPIS
  });
});

// 3. Customers & Accounts
app.get('/api/customers', (req, res) => {
  res.json({ customers: customersStore });
});

app.get('/api/accounts', (req, res) => {
  res.json({ accounts: accountsStore });
});

// 4. Commercial Loans & Facilities
app.get('/api/loans', (req, res) => {
  res.json({ loans: loansStore });
});

// 5. Global Markets, Securities & FX
app.get('/api/securities', (req, res) => {
  res.json({ securities: SYNTHETIC_SECURITIES });
});

app.get('/api/fx-rates', (req, res) => {
  res.json({ rates: SYNTHETIC_FX_RATES });
});

// 6. Treasury & ALM
app.get('/api/alm-buckets', (req, res) => {
  res.json({ buckets: SYNTHETIC_ALM_BUCKETS, treasury: SYNTHETIC_TREASURY_POSITION });
});

// 7. General Ledger & Reconciliation
app.get('/api/journals', (req, res) => {
  res.json({ journals: journalsStore });
});

app.get('/api/reconciliations', (req, res) => {
  res.json({ reconciliations: reconciliationStore });
});

// 8. Payments & AML
app.get('/api/payments', (req, res) => {
  res.json({ payments: paymentsStore });
});

app.get('/api/aml-alerts', (req, res) => {
  res.json({ alerts: amlAlertsStore });
});

// 9. Risk Metrics & Audit
app.get('/api/risk-metrics', (req, res) => {
  res.json({ metrics: SYNTHETIC_RISK_EXPOSURES });
});

app.get('/api/audit-logs', (req, res) => {
  res.json({ logs: auditLogsStore });
});

// 10. Financial Dictionary Search
app.get('/api/dictionary', (req, res) => {
  const q = (req.query.q as string) || '';
  res.json({ terms: searchFinancialTerms(q) });
});

// 11. Credit Evaluation API
app.post('/api/credit-eval', (req, res) => {
  try {
    const input = req.body;
    const result = evaluateCreditRisk(input);

    // Record immutable audit log
    const auditRecord = {
      id: `aud_${Date.now()}`,
      correlationId: `eval-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: req.body.userId || 'USR-RM-OFFICER',
      userNameJa: req.body.userNameJa || '法人審査担当役員',
      role: 'Credit Risk Officer',
      ipAddress: '10.120.4.52',
      deviceInfo: 'MUFG Financial OS Desktop Workstation',
      action: 'CREDIT_RATING_EVALUATION',
      targetObject: `Customer: ${input.customerId}`,
      afterStateJson: JSON.stringify({ score: result.creditScore, rating: result.riskGrade, pd: result.pd, maxLimitJPY: result.maxCreditLimitJPY }),
      reasonJa: '信用審査エンジンによる定量的格付判定実行',
      approvalStatus: 'OFFICER_APPROVED' as const,
      isImmutableVerified: true
    };
    auditLogsStore.unshift(auditRecord);

    res.json({ success: true, result });
  } catch (error: any) {
    res.status(400).json({ success: false, error: error.message });
  }
});

// 12. Double-Entry Posting API
app.post('/api/post-journal', (req, res) => {
  try {
    const { entityId, transactionType, lines, createdBy, sourceModule, correlationId } = req.body;
    const validation = validateAndPostJournal(entityId, transactionType, lines, createdBy, sourceModule, correlationId);

    if (!validation.success || !validation.entry) {
      return res.status(400).json({ success: false, errorMessageJa: validation.errorMessageJa });
    }

    journalsStore.unshift(validation.entry);

    // Log Audit
    auditLogsStore.unshift({
      id: `aud_${Date.now()}`,
      correlationId: correlationId || `gl-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: createdBy || 'SYS_GL',
      userNameJa: '主計統括役',
      role: 'Accounting Controller',
      ipAddress: '10.120.2.14',
      deviceInfo: 'MUFG Core Ledger Node',
      action: 'GENERAL_LEDGER_POSTING',
      targetObject: `Journal: ${validation.entry.entryNumber}`,
      afterStateJson: JSON.stringify({ totalDebit: validation.entry.totalDebitJPY, totalCredit: validation.entry.totalCreditJPY }),
      reasonJa: `${transactionType} に伴う複式仕訳起票`,
      approvalStatus: 'OFFICER_APPROVED',
      isImmutableVerified: true
    });

    res.json({ success: true, entry: validation.entry });
  } catch (error: any) {
    res.status(500).json({ success: false, errorMessageJa: error.message });
  }
});

// 13. AML Alert Disposition API (Human Decision Approval)
app.post('/api/aml/resolve', (req, res) => {
  try {
    const { alertId, disposition, officerNotesJa, officerNameJa } = req.body;
    const alertIndex = amlAlertsStore.findIndex(a => a.id === alertId);

    if (alertIndex === -1) {
      return res.status(404).json({ success: false, error: 'Alert not found' });
    }

    amlAlertsStore[alertIndex] = {
      ...amlAlertsStore[alertIndex],
      humanDisposition: disposition,
      decisionNotesJa: officerNotesJa,
      assignedInvestigatorJa: officerNameJa || amlAlertsStore[alertIndex].assignedInvestigatorJa,
      resolvedAt: new Date().toISOString()
    };

    auditLogsStore.unshift({
      id: `aud_${Date.now()}`,
      correlationId: `aml-disp-${alertId}`,
      timestamp: new Date().toISOString(),
      userId: 'USR-AML-COMPLIANCE',
      userNameJa: officerNameJa || '高木 麻衣 (AML審査役)',
      role: 'AML Compliance Officer',
      ipAddress: '10.120.90.8',
      deviceInfo: 'MUFG Secure Compliance Terminal',
      action: 'AML_ALERT_DISPOSITION',
      targetObject: `AMLAlert: ${alertId}`,
      afterStateJson: JSON.stringify({ disposition, officerNotesJa }),
      reasonJa: 'コンプライアンス審査官による最終処分決裁 (Human Approval)',
      approvalStatus: 'OFFICER_APPROVED',
      isImmutableVerified: true
    });

    res.json({ success: true, updatedAlert: amlAlertsStore[alertIndex] });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 14. AI Financial Copilot with Structured Japanese Output
app.post('/api/copilot/query', async (req, res) => {
  try {
    const { prompt, currentRole } = req.body;

    if (!prompt || !prompt.trim()) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    const ai = getGeminiClient();

    // Context summary for grounding the AI in the exact financial OS state
    const financialContext = {
      executiveKPIs: EXECUTIVE_GROUP_KPIS,
      treasurySummary: SYNTHETIC_TREASURY_POSITION,
      topCustomers: customersStore.map(c => ({ code: c.customerCode, name: c.nameJa, rating: c.creditRating, revenue: c.annualRevenueJPY })),
      keyRisks: SYNTHETIC_RISK_EXPOSURES.map(r => ({ name: r.nameJa, utilization: `${r.utilizationPct}%`, status: r.status })),
      pendingAml: amlAlertsStore.filter(a => a.humanDisposition === 'PENDING_REVIEW')
    };

    const systemInstruction = `
あなたは「MUFG Financial Copilot」（三菱UFJフィナンシャル・グループ 総合金融OS 意思決定支援AI）です。
日本の大手総合金融機関（MUFG等）の経営陣・審査役・ディーラー・RM向けの高度な金融分析アシスタントとして振る舞ってください。

【厳格な回答フォーマット規定】
ユーザーからの金融照会に対し、必ず以下の7つの明確な見出し構造で日本語で回答してください。

1. 【結論】
（要点を1〜2文で明確かつ端的に提示）

2. 【根拠】
（財務指標、金利環境、信用スコア、規制要件、ALMギャップ等の論理的根拠）

3. 【データ】
（参照した金融OSの具体的数値データ、口座情報、通貨、比率）

4. 【計算】
（適用された計算式、PD/LGD/EAD、VaR、LCR、DSCR、PV01等の計算ステップ）

5. 【不確実性・リスク】
（金利変動シナリオ、為替リスク、信用集中、流動性ストレス等の留意点）

6. 【関連取引・口座】
（対象となる顧客コード、口座番号、融資ファシリティ、取引参照番号）

7. 【監査ログ・コンプライアンス情報】
（操作ID、参照権限レベル、AIガバナンス条項「本回答は意思決定支援であり、融資・送金の最終執行には承認権限者による確認が必要です」を明記）

【禁止事項】
・AIによる融資承認、取引執行、AML最終判断の代行は不可（Human in the Loop）。
・実在のMUFG内部機密情報ではなく、金融OS内の正規化されたデータに基づいて回答すること。
`;

    let replyText = '';

    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: `ユーザーからの照会: "${prompt}"\n\n現在の金融システム状態:\n${JSON.stringify(financialContext, null, 2)}`,
          config: {
            systemInstruction,
            temperature: 0.2
          }
        });
        replyText = response.text || '';
      } catch (geminiErr: any) {
        console.warn('Gemini API query fallback:', geminiErr.message);
      }
    }

    // Fallback template if API key is missing or failed
    if (!replyText) {
      replyText = `
1. 【結論】
MUFG総合金融グループの現在の財務基盤および流動性指標は健全であり、総資産412.5兆円、CET1比率12.45%、LCR 164.5%を維持しています。照会内容「${prompt}」に関するリスクは管理許容範囲内です。

2. 【根拠】
日銀当座預金36.2兆円およびHQLAバッファー92.4兆円が確保されており、30日間の重度ストレスシナリオ下でも耐久日数（Survival Horizon）は142日と算定されています。また、主要法人先（東都産業 AA-、日本東洋物流 A+）の信用スコアも堅調です。

3. 【データ】
・グループ総預金: ¥236.8兆円 / 総貸出金: ¥124.6兆円 (預貸率: 52.6%)
・日次VaR(99% 1日): ¥425億円 (限度枠: ¥600億円 / 消化率: 70.8%)
・未処理AML高リスクアラート: 1件 (東京アセット向け急速資金移動)

4. 【計算】
・CET1比率 = 普通株式等Tier1資本 (¥19.8兆円) ÷ 総リスクアセット (¥159.0兆円) = 12.45%
・LCR = 適格高品質流動性資産 (¥92.4兆円) ÷ 30日純資金流出 (¥56.2兆円) = 164.5%
・加重平均資金調達コスト = 0.32%

5. 【不確実性・リスク】
金利が+100bpsシフトした場合のポートフォリオPV01感応度は年間約¥3,850億円の純金利収益押し上げ効果（資産超過ギャップ）となる一方、超長期国債（30年JGB）の評価損リスクに留意が必要です。

6. 【関連取引・口座】
・対象元帳: GL-2026-0912 / BOJ-ACT-0005-MAIN
・主要ファシリティ: LN-2024-TOTO-001 (東都産業 250億円)
・照会元ロール: ${currentRole || 'Group Executive'}

7. 【監査ログ・コンプライアンス情報】
[監査ログID: COPILOT-QUERY-${Date.now()}] 本回答は意思決定支援（Decision Support）です。銀行法および内部規程に基づき、取引実行および融資決裁には正規の決裁権限者（人間）による最終承認が必須となります。
      `.trim();
    }

    // Record Audit
    auditLogsStore.unshift({
      id: `aud_${Date.now()}`,
      correlationId: `copilot-${Date.now()}`,
      timestamp: new Date().toISOString(),
      userId: 'COPILOT_USER',
      userNameJa: '金融AIコパイロット利用者',
      role: currentRole || 'Executive User',
      ipAddress: '10.120.1.10',
      deviceInfo: 'iPad Pro / Copilot Client',
      action: 'AI_FINANCIAL_INQUIRY',
      targetObject: `Prompt: ${prompt.substring(0, 40)}...`,
      reasonJa: 'MUFG Financial Copilot による日本語高度金融分析クエリ実行',
      approvalStatus: 'AUTO_AUTHORIZED',
      isImmutableVerified: true
    });

    res.json({ success: true, reply: replyText });
  } catch (error: any) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ==========================================
// Vite Middleware & Static Server
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[MUFG Financial OS] Server booted and running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
