/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Sparkles,
  Send,
  Bot,
  User,
  ShieldCheck,
  CheckCircle2,
  FileText,
  HelpCircle,
  Clock,
  Layers
} from 'lucide-react';
import { UserRole } from '../Header';

interface FinancialCopilotViewProps {
  currentRole: UserRole;
  initialQuery?: string;
}

interface Message {
  id: string;
  sender: 'user' | 'assistant';
  content: string;
  timestamp: string;
}

const PRESET_QUERIES = [
  '東都産業（顧客コード: CUST-TOTO-001）の信用格付審査および推奨スプレッドを算定してください。',
  '日銀が追加利上げ（+25bps）を実施した場合のグループALM金利感応度および年間純利息収益への影響を試算してください。',
  '現在の上限枠超過（Breach）リスクおよび警戒水準にあるエクスポージャーをCRO向けに総括してください。',
  '東京アセットマネジメント宛ての2.8億円送金に対する疑わしい取引（SAR）判定の法的根拠を整理してください。'
];

export const FinancialCopilotView: React.FC<FinancialCopilotViewProps> = ({
  currentRole,
  initialQuery = ''
}) => {
  const [query, setQuery] = useState<string>(initialQuery);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'msg_welcome',
      sender: 'assistant',
      content: `
1. 【結論】
MUFG Financial Copilot (Gemini 3.7 統合金融意思決定支援AI) が正常にオンライン起動しました。

2. 【根拠】
三菱UFJフィナンシャル・グループ統合データモデル（顧客、勘定、有価証券、ALMギャップ、リスク限度枠、不変監査ログ）と完全同期しています。

3. 【データ】
・対象グループ総資産: ¥412.5兆円 / CET1比率: 12.45% / LCR: 164.5%
・現在適用ロール: ${currentRole}
・監査ログID: IMMUTABLE-BOOT-001

4. 【計算】
財務指標およびリスク計算エンジン（IRB信用審査モデル、パラメトリックVaR、期間別金利ギャップ）を即時実行可能です。

5. 【不確実性・リスク】
外部マクロ環境（日銀金融政策動向、為替ボラティリティ）を考慮した感応度分析をサポートします。

6. 【関連取引・口座】
法人融資ファシリティ、FICCディーリングポジション、全銀/SWIFT決済キューにアクセス可能です。

7. 【監査ログ・ガバナンス】
本AIの回答は意思決定支援（Decision Support）を目的としており、融資承認や取引執行には正規の承認権限者（人間）による確認が必要です。何について分析・試算しますか？
      `.trim(),
      timestamp: new Date().toLocaleTimeString('ja-JP')
    }
  ]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleSend = async (textToSend?: string) => {
    const promptText = textToSend || query;
    if (!promptText.trim()) return;

    const userMsg: Message = {
      id: `user_${Date.now()}`,
      sender: 'user',
      content: promptText,
      timestamp: new Date().toLocaleTimeString('ja-JP')
    };

    setMessages(prev => [...prev, userMsg]);
    setQuery('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/copilot/query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: promptText,
          currentRole
        })
      });
      const data = await res.json();

      const assistantMsg: Message = {
        id: `ai_${Date.now()}`,
        sender: 'assistant',
        content: data.reply || '応答を受信できませんでした。',
        timestamp: new Date().toLocaleTimeString('ja-JP')
      };

      setMessages(prev => [...prev, assistantMsg]);
    } catch (err: any) {
      setMessages(prev => [
        ...prev,
        {
          id: `ai_err_${Date.now()}`,
          sender: 'assistant',
          content: `エラーが発生しました: ${err.message}`,
          timestamp: new Date().toLocaleTimeString('ja-JP')
        }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-4.5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <Sparkles className="w-5 h-5 text-red-500" />
            <h1 className="text-xl font-bold text-white">MUFG Financial Copilot (Gemini 3.7 金融意思決定AI)</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            日本の金融機関実務に最適化された7部構成（結論・根拠・データ・計算・リスク・口座・監査）日本語回答エンジン
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-300 font-mono">
          <span className="px-2.5 py-1 rounded bg-slate-800 border border-slate-700">
            モデル: <strong className="text-red-400">Gemini 3.7 Enterprise</strong>
          </span>
          <span className="px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
            Human-in-the-Loop 統制中
          </span>
        </div>
      </div>

      {/* Preset Queries Grid */}
      <div className="space-y-1.5">
        <span className="text-[11px] text-slate-400 font-mono">【推奨金融分析プロンプト (クリックで実行)】</span>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {PRESET_QUERIES.map((preset, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(preset)}
              className="text-left p-2.5 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded-lg text-xs text-slate-300 transition-all cursor-pointer flex items-center justify-between group"
            >
              <span className="line-clamp-1">{preset}</span>
              <Sparkles className="w-3.5 h-3.5 text-slate-500 group-hover:text-amber-300 shrink-0 ml-2" />
            </button>
          ))}
        </div>
      </div>

      {/* Chat Conversation Box */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4.5 shadow-xl flex flex-col h-[520px]">
        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto space-y-4 pr-1">
          {messages.map(msg => (
            <div
              key={msg.id}
              className={`flex items-start space-x-3 ${
                msg.sender === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {msg.sender === 'assistant' && (
                <div className="w-8 h-8 rounded-lg bg-red-900/80 border border-red-700/60 flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}

              <div
                className={`max-w-2xl p-4 rounded-xl text-xs space-y-2 leading-relaxed ${
                  msg.sender === 'user'
                    ? 'bg-red-700 text-white rounded-tr-none shadow-md font-medium'
                    : 'bg-slate-950 border border-slate-800 text-slate-200 rounded-tl-none font-sans whitespace-pre-wrap'
                }`}
              >
                <div className="flex items-center justify-between border-b border-slate-800/60 pb-1.5 text-[10px] text-slate-400 font-mono">
                  <span>{msg.sender === 'user' ? '照会者 (User)' : 'MUFG Financial Copilot'}</span>
                  <span>{msg.timestamp}</span>
                </div>
                <div>{msg.content}</div>
              </div>

              {msg.sender === 'user' && (
                <div className="w-8 h-8 rounded-lg bg-slate-800 border border-slate-700 flex items-center justify-center shrink-0">
                  <User className="w-4 h-4 text-slate-300" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center space-x-3 text-xs text-slate-400 p-3 bg-slate-950/60 rounded-lg border border-slate-800 animate-pulse">
              <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
              <span>金融データモデル照合・リスク感応度計算および日本語7部構成レポートを生成中...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="pt-3 border-t border-slate-800 mt-2">
          <form
            onSubmit={e => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center space-x-2"
          >
            <input
              type="text"
              value={query}
              onChange={e => setQuery(e.target.value)}
              placeholder="金融データ照会・融資審査・ALMシミュレーション・リスク分析を指示..."
              className="flex-1 bg-slate-950 border border-slate-700 rounded-lg px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-red-500 font-sans"
            />
            <button
              type="submit"
              disabled={isLoading || !query.trim()}
              className="px-4 py-2 bg-red-700 hover:bg-red-600 disabled:bg-slate-800 text-white rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 shadow-md"
            >
              <Send className="w-3.5 h-3.5" />
              <span>送信</span>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
