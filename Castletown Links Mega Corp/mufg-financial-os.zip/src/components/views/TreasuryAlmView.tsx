/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Landmark,
  ShieldCheck,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  Sliders,
  Sparkles,
  BarChart3
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend
} from 'recharts';
import { AlmBucketGap, TreasuryPosition } from '../../types/financial';
import { formatJPY, formatExactJPY, formatPercent } from '../../engines/japaneseFormatters';
import { calculateAlmAggregates, simulateLiquidityStress } from '../../engines/treasuryAlmEngine';

interface TreasuryAlmViewProps {
  buckets: AlmBucketGap[];
  treasury: TreasuryPosition;
  onOpenCopilot: (query?: string) => void;
}

export const TreasuryAlmView: React.FC<TreasuryAlmViewProps> = ({
  buckets,
  treasury,
  onOpenCopilot
}) => {
  const [depositShockPct, setDepositShockPct] = useState<number>(15.0);
  const [fundingShockPct, setFundingShockPct] = useState<number>(30.0);

  const almAggregates = calculateAlmAggregates(buckets);
  const stressResult = simulateLiquidityStress(treasury, depositShockPct, fundingShockPct);

  const chartData = buckets.map(b => ({
    name: b.bucketNameJa,
    運用資産: Math.round(b.assetAmountJPY / 1_000_000_000_000),
    調達負債: Math.round(b.liabilityAmountJPY / 1_000_000_000_000),
    ネットギャップ: Math.round(b.netGapJPY / 1_000_000_000_000)
  }));

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-4.5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <Landmark className="w-5 h-5 text-emerald-400" />
            <h1 className="text-xl font-bold text-white">トレジャリー & ALM 金利感応度ギャップ管理 (Treasury & ALM)</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            期間別金利ギャップ分析、PV01感応度、LCR/NSFR規制流動性バッファー、動的ストレステストシミュレーション
          </p>
        </div>

        <button
          onClick={() => onOpenCopilot('金利が急速に100bps上昇した場合のALMポートフォリオ損益影響および適格流動性資産の充足度を解説してください。')}
          className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-700 hover:bg-red-600 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-md"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>AI ALMストレステスト診断</span>
        </button>
      </div>

      {/* Top Level Treasury Health Indicators */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
          <span className="text-xs text-slate-400 font-medium">適格高品質流動性資産 (HQLA)</span>
          <div className="text-xl font-bold text-emerald-400 font-mono mt-1">
            {formatJPY(treasury.hqlBufferJPY)}
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">日銀当座預金・JGB</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
          <span className="text-xs text-slate-400 font-medium">流動性カバレッジ比率 (LCR)</span>
          <div className="text-xl font-bold text-white font-mono mt-1">
            {formatPercent(treasury.lcrRatioPct, 1)}
          </div>
          <span className="text-[10px] text-emerald-400 mt-1 block">規制最低比率 100% 達成</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
          <span className="text-xs text-slate-400 font-medium">安定調達比率 (NSFR)</span>
          <div className="text-xl font-bold text-white font-mono mt-1">
            {formatPercent(treasury.nsfrRatioPct, 1)}
          </div>
          <span className="text-[10px] text-cyan-400 mt-1 block">長期資金調達の安定性確保</span>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-lg">
          <span className="text-xs text-slate-400 font-medium">耐久日数 (Survival Horizon)</span>
          <div className="text-xl font-bold text-amber-400 font-mono mt-1">
            {treasury.survivalHorizonDays} 日間
          </div>
          <span className="text-[10px] text-slate-500 mt-1 block">市場封鎖下での自律耐久力</span>
        </div>
      </div>

      {/* ALM Bucket Gap Analysis Chart */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold text-white">金利更改期間別 資産・負債ギャップ構造 (Maturity Ladder)</h3>
            <p className="text-[11px] text-slate-400 font-mono">単位: 兆円 (資産 vs 負債 vs ネットギャップ)</p>
          </div>
          <div className="text-right text-xs">
            <span className="text-slate-400">金利+100bpsシフト時 EaR影響: </span>
            <strong className="text-emerald-400 font-mono">
              +{formatJPY(almAggregates.rateShift100bpsImpactJPY)} / 年
            </strong>
          </div>
        </div>

        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
              <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} />
              <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
              <Tooltip
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }}
              />
              <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
              <Bar dataKey="運用資産" fill="#38bdf8" radius={[4, 4, 0, 0]} />
              <Bar dataKey="調達負債" fill="#64748b" radius={[4, 4, 0, 0]} />
              <Bar dataKey="ネットギャップ" fill="#10b981" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* ALM Table Breakdown */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-800 text-slate-400 border-b border-slate-700 font-medium">
              <tr>
                <th className="py-2.5 px-3">期間区分 (Bucket)</th>
                <th className="py-2.5 px-3 text-right">運用資産 (JPY)</th>
                <th className="py-2.5 px-3 text-right">調達負債 (JPY)</th>
                <th className="py-2.5 px-3 text-right">ネットギャップ</th>
                <th className="py-2.5 px-3 text-right">累積ギャップ</th>
                <th className="py-2.5 px-3 text-right">PV01 (金利1bp変動)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 font-mono">
              {almAggregates.enrichedBuckets.map(b => (
                <tr key={b.bucketId || b.tenor} className="hover:bg-slate-800/40">
                  <td className="py-2 px-3 font-sans font-medium text-white">{b.bucketNameJa || b.tenor}</td>
                  <td className="py-2 px-3 text-right text-slate-300">{formatJPY(b.assetAmountJPY)}</td>
                  <td className="py-2 px-3 text-right text-slate-400">{formatJPY(b.liabilityAmountJPY)}</td>
                  <td className={`py-2 px-3 text-right font-bold ${b.netGapJPY >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                    {formatJPY(b.netGapJPY, { showPlus: true })}
                  </td>
                  <td className="py-2 px-3 text-right text-slate-300">{formatJPY(b.cumulativeGapJPY)}</td>
                  <td className="py-2 px-3 text-right text-cyan-400">{formatJPY(b.pv01JPY, { showPlus: true })}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive Liquidity Stress Test Sandbox */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
          <Sliders className="w-5 h-5 text-red-500" />
          <div>
            <h3 className="text-sm font-bold text-white">動的流動性ストレステスト・サンドボックス (Liquidity Shock Simulation)</h3>
            <p className="text-xs text-slate-400">急激な市場流動性収縮および預金大量流出を想定したストレステスト</p>
          </div>
        </div>

        {/* Sliders */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 bg-slate-950/60 p-4 rounded-lg border border-slate-800">
          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-slate-300">想定預金流出率 (30日間):</span>
              <strong className="text-red-400 font-mono">{depositShockPct.toFixed(1)}%</strong>
            </div>
            <input
              type="range"
              min="0"
              max="35"
              step="1"
              value={depositShockPct}
              onChange={e => setDepositShockPct(Number(e.target.value))}
              className="w-full accent-red-600"
            />
            <span className="text-[10px] text-slate-500">標準ベースライン: 5% / 激甚ストレス: 25%</span>
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1.5">
              <span className="text-slate-300">市場資金調達ショック (Wholesale Funding Shock):</span>
              <strong className="text-amber-400 font-mono">{fundingShockPct.toFixed(1)}%</strong>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              step="5"
              value={fundingShockPct}
              onChange={e => setFundingShockPct(Number(e.target.value))}
              className="w-full accent-amber-600"
            />
            <span className="text-[10px] text-slate-500">インターバンク・コマーシャルペーパー市場の縮小想定</span>
          </div>
        </div>

        {/* Shock Output Result Card */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs">
          <div>
            <span className="text-slate-400">想定総資金流出額</span>
            <div className="text-base font-bold text-rose-400 font-mono mt-0.5">
              {formatJPY(stressResult.totalNetOutflowJPY)}
            </div>
          </div>
          <div>
            <span className="text-slate-400">ストレス後 LCR比率</span>
            <div className={`text-base font-bold font-mono mt-0.5 ${stressResult.isCompliant ? 'text-emerald-400' : 'text-red-500'}`}>
              {stressResult.stressedLcrPct}%
            </div>
          </div>
          <div>
            <span className="text-slate-400">ストレス後 耐久日数</span>
            <div className="text-base font-bold text-amber-400 font-mono mt-0.5">
              {stressResult.stressedSurvivalDays} 日間
            </div>
          </div>
        </div>

        <div className="p-3 bg-slate-800/80 rounded border border-slate-700 text-xs text-slate-300">
          <strong>【ALM統括オフィサー評価】: </strong>
          <span>{stressResult.requiredActionJa}</span>
        </div>
      </div>
    </div>
  );
};
