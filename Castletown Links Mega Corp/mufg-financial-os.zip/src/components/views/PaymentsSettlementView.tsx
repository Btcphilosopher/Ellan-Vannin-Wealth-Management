/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  SendHorizontal,
  CheckCircle2,
  Clock,
  ArrowRightLeft,
  Layers,
  Globe2,
  ShieldCheck,
  Sparkles
} from 'lucide-react';
import { PaymentOrder } from '../../types/financial';
import { formatExactJPY, formatJPY } from '../../engines/japaneseFormatters';
import { SYNTHETIC_PAYMENTS } from '../../data/syntheticDatabase';

interface PaymentsSettlementViewProps {
  onOpenCopilot: (query?: string) => void;
}

export const PaymentsSettlementView: React.FC<PaymentsSettlementViewProps> = ({ onOpenCopilot }) => {
  const [payments, setPayments] = useState<PaymentOrder[]>(SYNTHETIC_PAYMENTS);
  const [selectedNetwork, setSelectedNetwork] = useState<string>('ALL');

  const filteredPayments = selectedNetwork === 'ALL'
    ? payments
    : payments.filter(p => p.clearingNetwork === selectedNetwork);

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-4.5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <SendHorizontal className="w-5 h-5 text-sky-400" />
            <h1 className="text-xl font-bold text-white">決済・資金移動ネットワーク (Payments & Settlement Engine)</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            全銀システム (Zengin 24/7/365)、SWIFT (ISO 20022 pacs.008/pacs.009)、日銀ネット (BOJ-NET RTGS/DVP)
          </p>
        </div>

        <div className="flex items-center space-x-2.5 text-xs font-mono">
          <span className="px-2.5 py-1 rounded bg-slate-800 border border-slate-700 text-slate-300">
            全銀コア: <strong className="text-emerald-400">STP 99.98%</strong>
          </span>
          <span className="px-2.5 py-1 rounded bg-slate-800 border border-slate-700 text-slate-300">
            SWIFT gpi: <strong className="text-cyan-400">即時追跡可能</strong>
          </span>
        </div>
      </div>

      {/* Network Filter Pills */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs">
        {['ALL', 'ZENGIN', 'SWIFT_ISO20022', 'BOJ_NET_RTGS', 'INTERNAL_TRANSFER'].map(net => (
          <button
            key={net}
            onClick={() => setSelectedNetwork(net)}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedNetwork === net
                ? 'bg-sky-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:bg-slate-800'
            }`}
          >
            {net === 'ALL' ? '全決済網統合' : net}
          </button>
        ))}
      </div>

      {/* Payment Orders Ledger Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4.5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold text-slate-300 uppercase font-mono">
            当日決済トランザクション・キュー ({filteredPayments.length}件)
          </h2>
          <span className="text-[10px] text-slate-400 font-mono">リアルタイム清算ステータス</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-800 text-slate-400 border-b border-slate-700 font-medium">
              <tr>
                <th className="py-2.5 px-3">決済参照番号</th>
                <th className="py-2.5 px-3">決済網</th>
                <th className="py-2.5 px-3">送金人</th>
                <th className="py-2.5 px-3">受取人 / 仕向銀行</th>
                <th className="py-2.5 px-3 text-right">決済金額</th>
                <th className="py-2.5 px-3 text-center">AML スクリーニング</th>
                <th className="py-2.5 px-3 text-center">処理ステータス</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredPayments.map(p => (
                <tr key={p.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-mono font-bold text-slate-200">{p.referenceNumber}</td>
                  <td className="py-2.5 px-3 font-mono text-[11px] text-sky-300">{p.clearingNetwork}</td>
                  <td className="py-2.5 px-3 text-slate-200">
                    <div className="font-semibold">{p.senderNameJa}</div>
                    <div className="text-[10px] text-slate-500 font-mono">口座: {p.senderAccountNumber}</div>
                  </td>
                  <td className="py-2.5 px-3 text-slate-300">
                    <div className="font-semibold text-white">{p.receiverNameJa}</div>
                    <div className="text-[10px] text-slate-400">{p.receiverBankNameJa}</div>
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-bold text-white">
                    {p.currency === 'JPY' ? formatExactJPY(p.amount) : `${p.currency} ${p.amount.toLocaleString()}`}
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      p.amlScreeningStatus === 'PASSED'
                        ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                        : 'bg-amber-950 text-amber-400 border border-amber-800 animate-pulse'
                    }`}>
                      {p.amlScreeningStatus}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-950 text-sky-400 border border-sky-800">
                      {p.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
