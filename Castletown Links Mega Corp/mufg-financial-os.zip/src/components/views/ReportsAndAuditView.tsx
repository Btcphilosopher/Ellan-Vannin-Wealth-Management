/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  FileText,
  ShieldCheck,
  CheckCircle2,
  Lock,
  Printer,
  Download,
  Search,
  Eye,
  Layers,
  Sparkles
} from 'lucide-react';
import { AuditLogEntry, Customer } from '../../types/financial';
import { formatDateTimeJa, formatDateJa, formatExactJPY } from '../../engines/japaneseFormatters';
import { generateBalanceCertificate, generateCreditAssessmentMemo, GeneratedFinancialReport } from '../../engines/japaneseReportEngine';
import { evaluateCreditRisk } from '../../engines/creditEngine';

interface ReportsAndAuditViewProps {
  customers: Customer[];
  auditLogs: AuditLogEntry[];
  onOpenReportModal: (report: GeneratedFinancialReport) => void;
}

export const ReportsAndAuditView: React.FC<ReportsAndAuditViewProps> = ({
  customers,
  auditLogs,
  onOpenReportModal
}) => {
  const [activeTab, setActiveTab] = useState<'AUDIT_TRAIL' | 'OFFICIAL_REPORTS'>('AUDIT_TRAIL');
  const [searchLog, setSearchLog] = useState<string>('');

  const filteredLogs = searchLog
    ? auditLogs.filter(l =>
        l.action.toLowerCase().includes(searchLog.toLowerCase()) ||
        l.userNameJa.includes(searchLog) ||
        l.targetObject.includes(searchLog) ||
        l.reasonJa.includes(searchLog)
      )
    : auditLogs;

  const handleCreateSampleBalanceCert = () => {
    const cust = customers[0];
    const dummyAccounts = [
      { id: 'acc_01', accountNumber: '1849201', branchCode: '001', branchName: '本店営業部', accountType: 'ORDINARY_SAVINGS' as const, currency: 'JPY' as const, balance: 14500000000, status: 'ACTIVE' as const, entityId: 'ent_bk_01' },
      { id: 'acc_02', accountNumber: '2940182', branchCode: '001', branchName: '東京営業部', accountType: 'TIME_DEPOSIT' as const, currency: 'JPY' as const, balance: 25000000000, status: 'ACTIVE' as const, entityId: 'ent_bk_01' }
    ];
    const report = generateBalanceCertificate(cust, dummyAccounts as any);
    onOpenReportModal(report);
  };

  const handleCreateCreditMemo = () => {
    const cust = customers[0];
    const evalRes = evaluateCreditRisk({
      customerId: cust.id,
      annualRevenueJPY: 250000000000,
      operatingIncomeJPY: 20000000000,
      ebitdaJPY: 28000000000,
      netIncomeJPY: 13000000000,
      totalAssetsJPY: 300000000000,
      netAssetsJPY: 165000000000,
      interestBearingDebtJPY: 85000000000,
      cashAndEquivalentsJPY: 35000000000,
      freeCashFlowJPY: 15000000000,
      collateralValueJPY: 50000000000,
      industryRiskTier: 'LOW',
      existingDelinquency: false
    });
    const memo = generateCreditAssessmentMemo(cust, evalRes);
    onOpenReportModal(memo);
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-4.5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <h1 className="text-xl font-bold text-white">公式金融帳票 & 不変監査ログ (Reports & Immutable Audit Trail)</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            残高証明書・融資稟議調書・返済計画書発行、SHA-256暗号化チェーン検証付き改ざん防止監査証跡
          </p>
        </div>

        <div className="flex items-center space-x-2 text-xs font-mono text-slate-300">
          <span className="px-2.5 py-1 rounded bg-slate-800 border border-slate-700">
            監査チェーン: <strong className="text-emerald-400">暗号完全性検証済 (Valid)</strong>
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('AUDIT_TRAIL')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 ${
            activeTab === 'AUDIT_TRAIL'
              ? 'bg-slate-800 text-white border border-slate-700'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Lock className="w-3.5 h-3.5 text-emerald-400" />
          <span>不変監査ログ証跡 ({filteredLogs.length}件)</span>
        </button>

        <button
          onClick={() => setActiveTab('OFFICIAL_REPORTS')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 ${
            activeTab === 'OFFICIAL_REPORTS'
              ? 'bg-slate-800 text-white border border-slate-700'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <FileText className="w-3.5 h-3.5 text-sky-400" />
          <span>公式日本語帳票発行エンジン</span>
        </button>
      </div>

      {activeTab === 'AUDIT_TRAIL' ? (
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4.5 shadow-lg space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h2 className="text-xs font-bold text-slate-300 uppercase font-mono">
              全社操作・決裁・仕訳・クエリ 不変監査ログ (Immutable Audit Logs)
            </h2>
            <div className="relative w-72">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-2.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchLog}
                onChange={e => setSearchLog(e.target.value)}
                placeholder="アクション・担当者・対象を検索..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-8 pr-3 py-1.5 text-xs text-white placeholder-slate-500 font-sans"
              />
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-800 text-slate-400 border-b border-slate-700 font-medium">
                <tr>
                  <th className="py-2.5 px-3">タイムスタンプ</th>
                  <th className="py-2.5 px-3">操作者 (User / Role)</th>
                  <th className="py-2.5 px-3">実行アクション</th>
                  <th className="py-2.5 px-3">操作対象 (Target)</th>
                  <th className="py-2.5 px-3">決裁ステータス</th>
                  <th className="py-2.5 px-3 text-center">完全性検証</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono text-[11px]">
                {filteredLogs.map(log => (
                  <tr key={log.id} className="hover:bg-slate-800/40">
                    <td className="py-2.5 px-3 text-slate-400">{formatDateTimeJa(log.timestamp)}</td>
                    <td className="py-2.5 px-3 text-slate-200">
                      <div className="font-sans font-bold">{log.userNameJa}</div>
                      <div className="text-[10px] text-slate-500">{log.role}</div>
                    </td>
                    <td className="py-2.5 px-3 font-bold text-sky-400">{log.action}</td>
                    <td className="py-2.5 px-3 font-sans text-slate-300">{log.targetObject}</td>
                    <td className="py-2.5 px-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                        {log.approvalStatus}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className="inline-flex items-center space-x-1 text-emerald-400 text-[10px]">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>SHA256-OK</span>
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Certificate Generator Card 1 */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg bg-red-950 border border-red-800 flex items-center justify-center">
                <FileText className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">残高証明書 (Balance Certificate)</h3>
                <p className="text-xs text-slate-400">預金口座・信託受託勘定の基準日残高公式証明書</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              監査法人提出用、決算確定用、相続税申告用の公的残高証明書をPDF/印刷レイアウトで即時発行します。
            </p>

            <button
              onClick={handleCreateSampleBalanceCert}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold border border-slate-600 transition-all cursor-pointer flex items-center justify-center space-x-2"
            >
              <Eye className="w-4 h-4 text-emerald-400" />
              <span>残高証明書をプレビュー・発行</span>
            </button>
          </div>

          {/* Certificate Generator Card 2 */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 rounded-lg bg-sky-950 border border-sky-800 flex items-center justify-center">
                <FileText className="w-5 h-5 text-sky-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">信用格付・与信審査稟議調書 (Credit Underwriting Memo)</h3>
                <p className="text-xs text-slate-400">IRB格付判定、コベナンツ要件、推奨極度枠記録</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              審査部・融資委員会決裁用の公式稟議書。定量スコア、倒産確率(PD)、保全後損失率(LGD)を完全記録。
            </p>

            <button
              onClick={handleCreateCreditMemo}
              className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold border border-slate-600 transition-all cursor-pointer flex items-center justify-center space-x-2"
            >
              <Eye className="w-4 h-4 text-cyan-400" />
              <span>審査稟議調書をプレビュー・発行</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
