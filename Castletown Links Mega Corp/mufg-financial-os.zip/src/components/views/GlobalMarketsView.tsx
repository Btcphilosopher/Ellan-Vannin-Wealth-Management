/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  TrendingUp,
  ArrowRightLeft,
  DollarSign,
  Activity,
  CheckCircle2,
  AlertTriangle,
  Play,
  RotateCcw
} from 'lucide-react';
import { SecurityInstrument, FxRate } from '../../types/financial';
import { formatExactJPY, formatJPY, formatPercent } from '../../engines/japaneseFormatters';
import { SYNTHETIC_SECURITIES, SYNTHETIC_FX_RATES } from '../../data/syntheticDatabase';

interface GlobalMarketsViewProps {
  onOpenCopilot: (query?: string) => void;
}

export const GlobalMarketsView: React.FC<GlobalMarketsViewProps> = ({ onOpenCopilot }) => {
  const [securities, setSecurities] = useState<SecurityInstrument[]>(SYNTHETIC_SECURITIES);
  const [fxRates, setFxRates] = useState<FxRate[]>(SYNTHETIC_FX_RATES);
  const [selectedSecurity, setSelectedSecurity] = useState<SecurityInstrument>(securities[0]);

  // Trade Ticket Simulator State
  const [tradeSide, setTradeSide] = useState<'BUY' | 'SELL'>('BUY');
  const [orderQuantity, setOrderQuantity] = useState<number>(1000000000); // 10億円
  const [orderPrice, setOrderPrice] = useState<number>(100.15);
  const [tradeSuccessMsg, setTradeSuccessMsg] = useState<string | null>(null);

  const handleExecuteTrade = () => {
    const tradeValue = (orderQuantity * orderPrice) / 100;
    setTradeSuccessMsg(
      `【約定完了 (STP)】${tradeSide === 'BUY' ? '買付' : '売却'} 約定: ${selectedSecurity.nameJa} 数量: ${formatJPY(orderQuantity)} @ ${orderPrice.toFixed(3)} (約定代金: ${formatExactJPY(tradeValue)}) // BOJ-NET DVP決済キュー送達済`
    );
    setTimeout(() => {
      setTradeSuccessMsg(null);
    }, 6000);
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-4.5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5 text-cyan-400" />
            <h1 className="text-xl font-bold text-white">グローバルマーケッツ & FICC・為替ディーリング (Global Markets)</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            国債 (JGB)・金利スワップ (IRS)・主要通貨為替 (FX)・社債引受・プライムブローカレッジ
          </p>
        </div>

        <div className="flex items-center space-x-3 text-xs font-mono text-slate-300">
          <span className="px-2.5 py-1 rounded bg-slate-800 border border-slate-700">
            TONA: <strong className="text-emerald-400 font-bold">0.250%</strong>
          </span>
          <span className="px-2.5 py-1 rounded bg-slate-800 border border-slate-700">
            3M TIBOR: <strong className="text-cyan-400 font-bold">0.385%</strong>
          </span>
        </div>
      </div>

      {/* FX Rates Ticker Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {fxRates.map(fx => (
          <div key={fx.pair} className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex items-center justify-between">
            <div>
              <div className="text-xs font-bold font-mono text-white">{fx.pair}</div>
              <div className="text-[10px] text-slate-400">{fx.descriptionJa}</div>
            </div>
            <div className="text-right font-mono">
              <div className="text-sm font-bold text-cyan-400">
                {((fx.spotRate ?? fx.mid) ?? 0).toFixed(3)}
              </div>
              <div className="text-[10px] text-slate-500">
                {((fx.bidRate ?? fx.bid) ?? 0).toFixed(2)} / {((fx.askRate ?? fx.ask) ?? 0).toFixed(2)}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Main Trading Floor Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Securities Watchlist & Blotter */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-4.5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-slate-300 uppercase font-mono">
              FICC 取引銘柄・有価証券ブロッター ({securities.length}銘柄)
            </h2>
            <span className="text-[10px] text-slate-400 font-mono">市場レート: リアルタイム同期中</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-800 text-slate-400 border-b border-slate-700 font-medium">
                <tr>
                  <th className="py-2.5 px-3">ISIN / 銘柄コード</th>
                  <th className="py-2.5 px-3">銘柄名称</th>
                  <th className="py-2.5 px-3">種別</th>
                  <th className="py-2.5 px-3 text-right">表面利率</th>
                  <th className="py-2.5 px-3 text-right">現在値 (円)</th>
                  <th className="py-2.5 px-3 text-right">保有残高</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800">
                {securities.map(sec => {
                  const isSelected = sec.id === selectedSecurity.id;
                  return (
                    <tr
                      key={sec.id}
                      onClick={() => {
                        setSelectedSecurity(sec);
                        setOrderPrice(sec.marketPrice ?? sec.currentPrice ?? 100);
                      }}
                      className={`hover:bg-slate-800/50 cursor-pointer transition-colors ${
                        isSelected ? 'bg-slate-800/80 font-semibold' : ''
                      }`}
                    >
                      <td className="py-2.5 px-3 font-mono text-slate-300">{sec.isin}</td>
                      <td className="py-2.5 px-3 text-white font-medium">{sec.nameJa}</td>
                      <td className="py-2.5 px-3 text-slate-400">{sec.assetClass ?? sec.type ?? 'JGB'}</td>
                      <td className="py-2.5 px-3 text-right font-mono text-cyan-400">
                        {sec.couponPct ?? sec.couponRatePct ?? 0}%
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-white font-bold">
                        {((sec.marketPrice ?? sec.currentPrice) ?? 0).toFixed(3)}
                      </td>
                      <td className="py-2.5 px-3 text-right font-mono text-emerald-400">{formatJPY(sec.outstandingAmountJPY)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Trade Execution Order Ticket */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 className="text-sm font-bold text-white">取引執行チケット (Trade Ticket)</h3>
              <p className="text-[11px] text-slate-400 mt-0.5">{selectedSecurity.nameJa}</p>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
              STP 自動直結
            </span>
          </div>

          {tradeSuccessMsg && (
            <div className="p-3 bg-emerald-950/80 border border-emerald-700 text-emerald-300 text-xs rounded-lg flex items-start space-x-2">
              <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5 text-emerald-400" />
              <span>{tradeSuccessMsg}</span>
            </div>
          )}

          {/* Side Selector */}
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => setTradeSide('BUY')}
              className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                tradeSide === 'BUY' ? 'bg-red-600 text-white shadow-lg' : 'bg-slate-800 text-slate-400'
              }`}
            >
              買付 (BUY)
            </button>
            <button
              onClick={() => setTradeSide('SELL')}
              className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                tradeSide === 'SELL' ? 'bg-blue-600 text-white shadow-lg' : 'bg-slate-800 text-slate-400'
              }`}
            >
              売却 (SELL)
            </button>
          </div>

          {/* Form Fields */}
          <div className="space-y-3 text-xs">
            <div>
              <label className="text-slate-400 block mb-1">発注額面金額 (JPY)</label>
              <input
                type="number"
                value={orderQuantity}
                onChange={e => setOrderQuantity(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
              />
              <span className="text-[10px] text-slate-400 mt-0.5 block font-mono">
                表記: {formatExactJPY(orderQuantity)}
              </span>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">指定指値価格 (100円額面あたり)</label>
              <input
                type="number"
                step="0.01"
                value={orderPrice}
                onChange={e => setOrderPrice(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
              />
            </div>

            <div className="p-3 bg-slate-950 rounded border border-slate-800 space-y-1 font-mono text-[11px]">
              <div className="flex justify-between text-slate-400">
                <span>受渡決済方式</span>
                <span className="text-slate-200">BOJ-NET DVP (T+1)</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>概算約定代金</span>
                <span className="text-emerald-400 font-bold">
                  {formatExactJPY((orderQuantity * orderPrice) / 100)}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={handleExecuteTrade}
            className="w-full py-2.5 bg-gradient-to-r from-red-700 to-rose-700 hover:from-red-600 hover:to-rose-600 text-white rounded-lg text-xs font-bold shadow-lg shadow-red-950 transition-all cursor-pointer"
          >
            注文送信 & 約定執行 (Execute Order)
          </button>
        </div>
      </div>
    </div>
  );
};
