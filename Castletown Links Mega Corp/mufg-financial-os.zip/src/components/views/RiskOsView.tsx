/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  TrendingDown,
  Activity,
  Sliders,
  Sparkles,
  Layers
} from 'lucide-react';
import { RiskExposureMetric } from '../../types/financial';
import { formatJPY, formatPercent } from '../../engines/japaneseFormatters';
import { calculateParametricVaR, evaluateRiskStatus } from '../../engines/riskEngine';
import { SYNTHETIC_RISK_EXPOSURES } from '../../data/syntheticDatabase';

interface RiskOsViewProps {
  onOpenCopilot: (query?: string) => void;
}

export const RiskOsView: React.FC<RiskOsViewProps> = ({ onOpenCopilot }) => {
  const [metrics, setMetrics] = useState<RiskExposureMetric[]>(SYNTHETIC_RISK_EXPOSURES);
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // Parametric VaR Sandbox state
  const [portfolioValueJPY, setPortfolioValueJPY] = useState<number>(3_500_000_000_000); // 3.5兆円
  const [dailyVolPct, setDailyVolPct] = useState<number>(1.25);
  const [confidenceLevel, setConfidenceLevel] = useState<0.95 | 0.99>(0.99);

  const calculatedVaR = calculateParametricVaR(portfolioValueJPY, dailyVolPct, confidenceLevel, 1);

  const filteredMetrics = selectedCategory === 'ALL'
    ? metrics
    : metrics.filter(m => m.category === selectedCategory);

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-4.5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <ShieldAlert className="w-5 h-5 text-amber-400" />
            <h1 className="text-xl font-bold text-white">統合リスク管理 OS (Enterprise Risk Management OS)</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            信用リスク (IRB/EAD/LGD)、市場リスク (VaR 99%/Expected Shortfall)、流動性リスク、オペレーショナルリスク、限度枠管理
          </p>
        </div>

        <button
          onClick={() => onOpenCopilot('グループ全体のリスク限度枠の消化状況および警戒水準にあるエクスポージャーを網羅的に報告してください。')}
          className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-700 hover:bg-red-600 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-md"
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          <span>AI リスク統括診断</span>
        </button>
      </div>

      {/* Category Filter Pills */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs">
        {['ALL', 'MARKET', 'CREDIT', 'LIQUIDITY', 'OPERATIONAL', 'COUNTRY_LIMIT'].map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3 py-1.5 rounded-lg font-bold transition-all cursor-pointer ${
              selectedCategory === cat
                ? 'bg-red-600 text-white shadow-md'
                : 'bg-slate-900 text-slate-400 border border-slate-800 hover:bg-slate-800'
            }`}
          >
            {cat === 'ALL' ? '全リスク区分統合' : cat}
          </button>
        ))}
      </div>

      {/* Risk Limit Table Grid */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4.5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-xs font-bold text-slate-300 uppercase font-mono">
            リスク限度枠・エクスポージャー監視マトリクス ({filteredMetrics.length}件)
          </h2>
          <span className="text-[10px] text-slate-400 font-mono">
            更新基準: リアルタイム・ストリーミング
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-800 text-slate-400 border-b border-slate-700 font-medium">
              <tr>
                <th className="py-2.5 px-3">リスク区分</th>
                <th className="py-2.5 px-3">管理指標</th>
                <th className="py-2.5 px-3 text-right">現存エクスポージャー</th>
                <th className="py-2.5 px-3 text-right">設定限度枠</th>
                <th className="py-2.5 px-3 text-center">消化率ゲージ</th>
                <th className="py-2.5 px-3 text-center">判定</th>
                <th className="py-2.5 px-3">管理主管</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {filteredMetrics.map(item => {
                const evalStatus = evaluateRiskStatus(item);
                return (
                  <tr key={item.id} className="hover:bg-slate-800/40 transition-colors">
                    <td className="py-2.5 px-3 font-mono font-bold text-slate-300">{item.category}</td>
                    <td className="py-2.5 px-3 font-medium text-white">{item.nameJa}</td>
                    <td className="py-2.5 px-3 text-right font-mono font-bold text-slate-200">
                      {formatJPY(item.exposureAmountJPY)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-400">
                      {formatJPY(item.limitAmountJPY)}
                    </td>
                    <td className="py-2.5 px-3 text-center font-mono">
                      <div className="flex items-center justify-center space-x-2">
                        <div className="w-20 bg-slate-800 rounded-full h-2 overflow-hidden">
                          <div
                            className={`h-full ${
                              item.utilizationPct > 90
                                ? 'bg-red-500'
                                : item.utilizationPct > 75
                                ? 'bg-amber-500'
                                : 'bg-emerald-500'
                            }`}
                            style={{ width: `${Math.min(100, item.utilizationPct)}%` }}
                          ></div>
                        </div>
                        <span className="font-bold text-slate-200">{item.utilizationPct.toFixed(1)}%</span>
                      </div>
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        evalStatus.status === 'BREACH'
                          ? 'bg-red-950 text-red-400 border border-red-700 animate-pulse'
                          : evalStatus.status === 'WARNING'
                          ? 'bg-amber-950 text-amber-400 border border-amber-700'
                          : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                      }`}>
                        {evalStatus.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-slate-400">{item.ownerDepartmentJa}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Parametric VaR & Expected Shortfall Calculator */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex items-center space-x-2 border-b border-slate-800 pb-3">
          <Activity className="w-5 h-5 text-cyan-400" />
          <div>
            <h3 className="text-sm font-bold text-white">市場リスク VaR (Value at Risk) / Expected Shortfall 算出エンジン</h3>
            <p className="text-xs text-slate-400">正規分布パラメトリック法および極値損失シミュレーション</p>
          </div>
        </div>

        {/* Input Parameters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          <div>
            <label className="text-slate-400 block mb-1">ポートフォリオ時価総額 (JPY)</label>
            <input
              type="number"
              value={portfolioValueJPY}
              onChange={e => setPortfolioValueJPY(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">日次価格変動ボラティリティ (%)</label>
            <input
              type="number"
              step="0.05"
              value={dailyVolPct}
              onChange={e => setDailyVolPct(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">信頼水準 (Confidence Level)</label>
            <select
              value={confidenceLevel}
              onChange={e => setConfidenceLevel(Number(e.target.value) as any)}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-sans"
            >
              <option value={0.99}>99% (バーゼル規制標準 / Z=2.326)</option>
              <option value={0.95}>95% (内部管理標準 / Z=1.645)</option>
            </select>
          </div>
        </div>

        {/* Output Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-950 p-4 rounded-lg border border-slate-800 text-xs">
          <div>
            <span className="text-slate-400 font-medium">1日保有期間 算出 VaR ({confidenceLevel * 100}%)</span>
            <div className="text-2xl font-bold text-amber-400 font-mono mt-1">
              {formatJPY(calculatedVaR.varJPY)}
            </div>
            <span className="text-[10px] text-slate-500 mt-0.5 block">
              1営業日における最大想定損失額 (99%の確率でこの損失額以内に収まる)
            </span>
          </div>

          <div>
            <span className="text-slate-400 font-medium">期待ショートフォール (Expected Shortfall / Tail Risk)</span>
            <div className="text-2xl font-bold text-rose-400 font-mono mt-1">
              {formatJPY(calculatedVaR.expectedShortfallJPY)}
            </div>
            <span className="text-[10px] text-slate-500 mt-0.5 block">
              VaR水準を超過した場合の極値テール損失の期待値
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
