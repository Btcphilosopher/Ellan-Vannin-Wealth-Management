/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Building2,
  PlusCircle,
  FileSpreadsheet,
  Calculator,
  ShieldCheck,
  AlertCircle,
  ExternalLink,
  ChevronRight,
  TrendingUp,
  Landmark,
  Layers
} from 'lucide-react';
import { Customer, LoanFacility, CreditAssessmentResult } from '../../types/financial';
import { formatJPY, formatExactJPY, formatDateJa, formatBps, formatPercent } from '../../engines/japaneseFormatters';
import { evaluateCreditRisk } from '../../engines/creditEngine';
import { generateAmortizationSchedule, AmortizationScheduleRow } from '../../engines/loanEngine';

interface CorporateBankingViewProps {
  customers: Customer[];
  loans: LoanFacility[];
  onOpenAssessmentModal: (customer?: Customer) => void;
  onOpenReportModal: (report: any) => void;
  onOpenCopilot: (query?: string) => void;
}

export const CorporateBankingView: React.FC<CorporateBankingViewProps> = ({
  customers,
  loans,
  onOpenAssessmentModal,
  onOpenReportModal,
  onOpenCopilot
}) => {
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(customers[0]?.id || '');
  const [selectedLoanId, setSelectedLoanId] = useState<string>(loans[0]?.id || '');
  const [amortizationSchedule, setAmortizationSchedule] = useState<AmortizationScheduleRow[]>([]);
  const [scheduleTenor, setScheduleTenor] = useState<number>(5);
  const [scheduleRate, setScheduleRate] = useState<number>(1.25);
  const [scheduleAmount, setScheduleAmount] = useState<number>(10_000_000_000);
  const [scheduleType, setScheduleType] = useState<'BULLET' | 'EQUAL_PRINCIPAL' | 'EQUAL_PAYMENT'>('EQUAL_PRINCIPAL');

  const selectedCustomer = customers.find(c => c.id === selectedCustomerId) || customers[0];
  const selectedLoan = loans.find(l => l.id === selectedLoanId) || loans[0];

  // Quick Amortization Generator
  const handleGenerateSchedule = () => {
    const rows = generateAmortizationSchedule(
      scheduleAmount,
      scheduleRate,
      scheduleTenor,
      4,
      scheduleType,
      '2026-10-01'
    );
    setAmortizationSchedule(rows);
  };

  // Quick live credit assessment on selected customer
  const liveCreditEval: CreditAssessmentResult = selectedCustomer ? evaluateCreditRisk({
    customerId: selectedCustomer.id,
    annualRevenueJPY: selectedCustomer.annualRevenueJPY || 250000000000,
    operatingIncomeJPY: (selectedCustomer.annualRevenueJPY || 250000000000) * 0.08,
    ebitdaJPY: (selectedCustomer.annualRevenueJPY || 250000000000) * 0.11,
    netIncomeJPY: (selectedCustomer.annualRevenueJPY || 250000000000) * 0.05,
    totalAssetsJPY: (selectedCustomer.annualRevenueJPY || 250000000000) * 1.2,
    netAssetsJPY: (selectedCustomer.annualRevenueJPY || 250000000000) * 0.55,
    interestBearingDebtJPY: (selectedCustomer.annualRevenueJPY || 250000000000) * 0.35,
    cashAndEquivalentsJPY: (selectedCustomer.annualRevenueJPY || 250000000000) * 0.15,
    freeCashFlowJPY: (selectedCustomer.annualRevenueJPY || 250000000000) * 0.06,
    collateralValueJPY: (selectedCustomer.annualRevenueJPY || 250000000000) * 0.20,
    industryRiskTier: 'LOW',
    existingDelinquency: false
  }) : {} as any;

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-4.5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <Building2 className="w-5 h-5 text-red-500" />
            <h1 className="text-xl font-bold text-white">法人金融 & グローバルCIB (Commercial & Syndication)</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            大企業・中堅企業向けコミットメントライン、シンジケートローン、プロジェクトファイナンス、IRB信用格付審査
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={() => onOpenAssessmentModal(selectedCustomer)}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-700 hover:bg-red-600 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-md"
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>新規信用格付・与信審査を実行</span>
          </button>
        </div>
      </div>

      {/* Customer Selection & Primary Details */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Customer Directory List */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-slate-300 uppercase font-mono">担当法人先ポートフォリオ ({customers.length}社)</h2>
            <span className="text-[10px] text-slate-500 font-mono">RM: 営業第一部</span>
          </div>

          <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
            {customers.map(c => {
              const isSelected = c.id === selectedCustomerId;
              return (
                <button
                  key={c.id}
                  onClick={() => setSelectedCustomerId(c.id)}
                  className={`w-full text-left p-3 rounded-lg border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800/90 border-red-600/80 shadow-md ring-1 ring-red-600/40'
                      : 'bg-slate-950/60 border-slate-800/80 hover:bg-slate-800/50 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-white truncate">{c.nameJa}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded font-mono ${
                      c.creditRating?.startsWith('A') ? 'bg-emerald-950 text-emerald-300 border border-emerald-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}>
                      {c.creditRating || 'BBB'} 級
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1 flex items-center justify-between">
                    <span>{c.industryCategory || '一般事業'}</span>
                    <span className="font-mono text-slate-300">年商 {formatJPY(c.annualRevenueJPY || 0)}</span>
                  </div>
                  <div className="text-[10px] text-slate-500 font-mono mt-0.5">
                    コード: {c.customerCode} | 主任: {c.relationshipManagerJa}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Customer Credit & Quantitative Assessment Card */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-start justify-between border-b border-slate-800 pb-3">
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-white">{selectedCustomer?.nameJa}</h3>
                <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">
                  {selectedCustomer?.customerType}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{selectedCustomer?.addressJa} | 設立: 1972年 | 従業員数: 14,200名</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 font-mono">IRB 内部信用スコア</span>
              <div className="text-2xl font-bold text-emerald-400 font-mono">
                {liveCreditEval.creditScore} <span className="text-xs text-slate-400">/ 1000</span>
              </div>
            </div>
          </div>

          {/* Quantitative Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-950/70 p-3.5 rounded-lg border border-slate-800 text-xs">
            <div>
              <span className="text-slate-400">倒産確率 (PD)</span>
              <div className="text-sm font-bold text-white font-mono mt-0.5">
                {formatPercent(liveCreditEval.pd * 100, 2)}
              </div>
              <span className="text-[10px] text-slate-500">1年期待値</span>
            </div>
            <div>
              <span className="text-slate-400">保全後損失率 (LGD)</span>
              <div className="text-sm font-bold text-white font-mono mt-0.5">
                {formatPercent(liveCreditEval.lgd * 100, 1)}
              </div>
              <span className="text-[10px] text-slate-500">担保保全考慮</span>
            </div>
            <div>
              <span className="text-slate-400">推奨与信限度枠</span>
              <div className="text-sm font-bold text-amber-400 font-mono mt-0.5">
                {formatJPY(liveCreditEval.maxCreditLimitJPY)}
              </div>
              <span className="text-[10px] text-slate-500">単一先集中制限内</span>
            </div>
            <div>
              <span className="text-slate-400">推奨貸出スプレッド</span>
              <div className="text-sm font-bold text-cyan-400 font-mono mt-0.5">
                +{formatBps(liveCreditEval.recommendedSpreadBps)}
              </div>
              <span className="text-[10px] text-slate-500">TONA/TIBOR基準</span>
            </div>
          </div>

          {/* Rating Description & Covenant recommendations */}
          <div className="space-y-2">
            <div className="text-xs font-semibold text-slate-300 flex items-center justify-between">
              <span>【格付判定結果 & コベナンツ要件】</span>
              <span className="text-[10px] text-slate-400 font-mono">決裁権限: {liveCreditEval.approvalAuthorityLevel}</span>
            </div>
            <div className="bg-slate-800/80 p-3 rounded-lg border border-slate-700 text-xs text-slate-300">
              <p className="font-semibold text-emerald-300">{liveCreditEval.internalRatingDescriptionJa}</p>
              <ul className="list-disc list-inside mt-2 space-y-1 text-slate-400 text-[11px]">
                {liveCreditEval.covenantRecommendations?.map((cov, idx) => (
                  <li key={idx}>{cov}</li>
                ))}
              </ul>
            </div>
          </div>

          {/* Copilot Action Shortcut */}
          <div className="flex items-center justify-between pt-2">
            <button
              onClick={() => onOpenCopilot(`${selectedCustomer.nameJa}（顧客コード: ${selectedCustomer.customerCode}）の信用リスクプロファイルおよびコベナンツ遵守状況を精査してください。`)}
              className="text-xs text-red-400 hover:text-red-300 flex items-center space-x-1 cursor-pointer font-medium"
            >
              <span>AI コパイロットでこの顧客の財務深層分析を実行 →</span>
            </button>
          </div>
        </div>
      </div>

      {/* Active Loan Facilities Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4.5 shadow-lg space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Landmark className="w-4 h-4 text-emerald-400" />
            <h3 className="text-sm font-bold text-white">現存融資ファシリティ・コミットメントライン一覧</h3>
          </div>
          <span className="text-xs text-slate-400 font-mono">全 {loans.length} 件</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-700 font-medium">
              <tr>
                <th className="py-2.5 px-3">ファシリティ番号</th>
                <th className="py-2.5 px-3">借入人 (企業名)</th>
                <th className="py-2.5 px-3">種別</th>
                <th className="py-2.5 px-3 text-right">極度額 / 実行残高</th>
                <th className="py-2.5 px-3 text-center">適用金利</th>
                <th className="py-2.5 px-3">満期日</th>
                <th className="py-2.5 px-3 text-center">ステータス</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {loans.map(loan => (
                <tr
                  key={loan.id}
                  onClick={() => setSelectedLoanId(loan.id)}
                  className={`hover:bg-slate-800/50 cursor-pointer transition-colors ${
                    loan.id === selectedLoanId ? 'bg-slate-800/80' : ''
                  }`}
                >
                  <td className="py-2.5 px-3 font-mono font-bold text-slate-200">{loan.facilityNumber}</td>
                  <td className="py-2.5 px-3 font-semibold text-white">{loan.borrowerNameJa}</td>
                  <td className="py-2.5 px-3 text-slate-300">{loan.facilityType}</td>
                  <td className="py-2.5 px-3 text-right font-mono">
                    <span className="font-bold text-white">{formatExactJPY(loan.outstandingPrincipalJPY)}</span>
                    <span className="text-[10px] text-slate-400 block">枠: {formatExactJPY(loan.commitmentLimitJPY)}</span>
                  </td>
                  <td className="py-2.5 px-3 text-center font-mono">
                    <span className="font-bold text-cyan-400">{loan.currentInterestRatePct}%</span>
                    <span className="text-[9px] text-slate-400 block">({loan.baseRateIndex} + {loan.spreadBps}bps)</span>
                  </td>
                  <td className="py-2.5 px-3 font-mono text-slate-300">{loan.maturityDate}</td>
                  <td className="py-2.5 px-3 text-center">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-950 text-emerald-400 border border-emerald-800">
                      {loan.facilityStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Loan Amortization Simulator Tool */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 className="text-sm font-bold text-white flex items-center space-x-2">
              <Calculator className="w-4 h-4 text-red-500" />
              <span>融資償還シミュレーション・返済計画書生成エンジン</span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              元金均等・元利均等・期日一括弁済スケジュールを浮動金利または固定金利で即時計算
            </p>
          </div>
          <button
            onClick={handleGenerateSchedule}
            className="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold border border-slate-600 transition-all cursor-pointer"
          >
            返済計画を計算実行
          </button>
        </div>

        {/* Input Controls */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <label className="text-slate-400 block mb-1">融資元本 (円)</label>
            <input
              type="number"
              value={scheduleAmount}
              onChange={e => setScheduleAmount(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1">適用年利 (%)</label>
            <input
              type="number"
              step="0.05"
              value={scheduleRate}
              onChange={e => setScheduleRate(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1">期間 (年)</label>
            <input
              type="number"
              value={scheduleTenor}
              onChange={e => setScheduleTenor(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1">償還方式</label>
            <select
              value={scheduleType}
              onChange={e => setScheduleType(e.target.value as any)}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-sans"
            >
              <option value="EQUAL_PRINCIPAL">元金均等返済 (季払い)</option>
              <option value="EQUAL_PAYMENT">元利均等返済 (季払い)</option>
              <option value="BULLET">期日一括弁済 (期中利払いのみ)</option>
            </select>
          </div>
        </div>

        {/* Generated Schedule Table */}
        {amortizationSchedule.length > 0 && (
          <div className="space-y-2 mt-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-300">
                【生成された償還計画表 (全 {amortizationSchedule.length} 回)】
              </span>
              <span className="text-[11px] text-slate-400 font-mono">
                初回支払日: {amortizationSchedule[0]?.paymentDate}
              </span>
            </div>
            <div className="max-h-56 overflow-y-auto border border-slate-800 rounded-lg">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-800 text-slate-400 sticky top-0 font-medium">
                  <tr>
                    <th className="py-2 px-3">回号</th>
                    <th className="py-2 px-3">返済期日</th>
                    <th className="py-2 px-3 text-right">元本返済額</th>
                    <th className="py-2 px-3 text-right">利息支払額</th>
                    <th className="py-2 px-3 text-right">元利金合計</th>
                    <th className="py-2 px-3 text-right">返済後残高</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800 bg-slate-950/60 font-mono">
                  {amortizationSchedule.map(row => (
                    <tr key={row.installmentNumber} className="hover:bg-slate-800/30">
                      <td className="py-1.5 px-3 text-slate-400">{row.installmentNumber}</td>
                      <td className="py-1.5 px-3 text-slate-300">{row.paymentDate}</td>
                      <td className="py-1.5 px-3 text-right text-emerald-400">{formatExactJPY(row.principalPaymentJPY)}</td>
                      <td className="py-1.5 px-3 text-right text-amber-400">{formatExactJPY(row.interestPaymentJPY)}</td>
                      <td className="py-1.5 px-3 text-right text-white font-bold">{formatExactJPY(row.totalPaymentJPY)}</td>
                      <td className="py-1.5 px-3 text-right text-slate-300">{formatExactJPY(row.remainingPrincipalJPY)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
