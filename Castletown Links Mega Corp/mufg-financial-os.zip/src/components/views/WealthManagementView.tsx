/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Gem,
  ShieldCheck,
  Building2,
  PieChart as PieChartIcon,
  TrendingUp,
  FileText,
  UserCheck,
  CheckCircle2,
  Sparkles
} from 'lucide-react';
import {
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend
} from 'recharts';
import { Customer } from '../../types/financial';
import { formatJPY, formatExactJPY, formatPercent } from '../../engines/japaneseFormatters';
import { generateBalanceCertificate } from '../../engines/japaneseReportEngine';

interface WealthManagementViewProps {
  customers: Customer[];
  onOpenReportModal: (report: any) => void;
  onOpenCopilot: (query?: string) => void;
}

const WEALTH_ALLOCATION = [
  { name: '日本株・私募投信 (三菱UFJアセット)', value: 1250000000, color: '#ef4444' },
  { name: '外国株式・オルタナティブ (モルガン・スタンレー)', value: 890000000, color: '#38bdf8' },
  { name: '家族信託受託資産 (三菱UFJ信託)', value: 920000000, color: '#10b981' },
  { name: '国内短期債・外貨定期預金', value: 450000000, color: '#fbbf24' }
];

export const WealthManagementView: React.FC<WealthManagementViewProps> = ({
  customers,
  onOpenReportModal,
  onOpenCopilot
}) => {
  const wealthCustomers = customers.filter(c => c.customerType === 'HNW_INDIVIDUAL' || c.id === 'cust_matsudaira_01');
  const [selectedCustId, setSelectedCustId] = useState<string>(wealthCustomers[0]?.id || customers[0]?.id);

  const currentCustomer = customers.find(c => c.id === selectedCustId) || customers[0];

  const handleIssueCertificate = () => {
    const dummyAccounts = [
      { id: 'acc_w1', accountNumber: '7829103', branchCode: '001', branchName: '東京営業部 (プライベートバンキング室)', accountType: 'ORDINARY_SAVINGS' as const, currency: 'JPY' as const, balance: 450000000, status: 'ACTIVE' as const, entityId: 'ent_bk_01' },
      { id: 'acc_w2', accountNumber: '9102834', branchCode: '001', branchName: '信託財産受託第一課', accountType: 'MONEY_TRUST' as const, currency: 'JPY' as const, balance: 920000000, status: 'ACTIVE' as const, entityId: 'ent_tr_01' }
    ];
    const cert = generateBalanceCertificate(currentCustomer, dummyAccounts as any);
    onOpenReportModal(cert);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-4.5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <Gem className="w-5 h-5 text-amber-400" />
            <h1 className="text-xl font-bold text-white">ウェルスマネジメント & 信託・資産承継 (Wealth Management)</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            富裕層オーナー・ファミリーオフィス向け資産管理、信託受託勘定、MUFG×モルガン・スタンレー共同プライベートバンキング
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={handleIssueCertificate}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-bold border border-slate-600 transition-all cursor-pointer"
          >
            <FileText className="w-3.5 h-3.5 text-slate-300" />
            <span>残高証明書を発行</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Customer Selector Card */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
          <h2 className="text-xs font-bold text-slate-400 uppercase font-mono">担当PB顧客ポートフォリオ</h2>
          <div className="space-y-2">
            {customers.map(c => {
              const isSelected = c.id === selectedCustId;
              return (
                <button
                  key={c.id}
                  onClick={() => setSelectedCustId(c.id)}
                  className={`w-full text-left p-3 rounded-lg border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800 border-amber-500/80 ring-1 ring-amber-500/40'
                      : 'bg-slate-950/60 border-slate-800 hover:bg-slate-800/40 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs text-white">{c.nameJa}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-950 text-amber-300 border border-amber-800 font-mono">
                      {c.customerType}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1">
                    顧客コード: {c.customerCode} | 担当PB: {c.relationshipManagerJa}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Wealth Portfolio Detail */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-start justify-between border-b border-slate-800 pb-3">
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-white">{currentCustomer.nameJa} 様</h3>
                <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-emerald-400 font-mono">
                  MUFG PB Tier 1 (AUM 35億円超)
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">{currentCustomer.addressJa}</p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 font-mono">総合受託残高 (Total AUM)</span>
              <div className="text-2xl font-bold text-amber-400 font-mono">
                ¥3,510,000,000
              </div>
            </div>
          </div>

          {/* Asset Allocation Chart & Breakdown */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 items-center">
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={WEALTH_ALLOCATION}
                    cx="50%"
                    cy="50%"
                    innerRadius={45}
                    outerRadius={75}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {WEALTH_ALLOCATION.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    formatter={(val: number) => formatExactJPY(val)}
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>

            <div className="space-y-2 text-xs">
              <span className="text-xs font-semibold text-slate-300">【資産構成・信託受託区分】</span>
              {WEALTH_ALLOCATION.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 rounded bg-slate-950/60 border border-slate-800/80">
                  <div className="flex items-center space-x-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: item.color }}></span>
                    <span className="text-slate-300 text-[11px] truncate max-w-[150px]">{item.name}</span>
                  </div>
                  <span className="font-mono font-bold text-white text-[11px]">{formatJPY(item.value)}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Succession & Trust Governance Panel */}
          <div className="bg-slate-950/70 p-3.5 rounded-lg border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-200">【事業承継・家族信託設計ステータス】</span>
              <span className="text-[10px] text-emerald-400 font-mono">信託契約締結済 (受託者: 三菱UFJ信託)</span>
            </div>
            <p className="text-[11px] text-slate-400">
              第1受益者（松平氏本人）から第2受益者（長男・後継経営者）への受益権連続型信託組成完了。自社株式の議決権留保信託スキームにより経営権の円滑承継を担保。
            </p>
          </div>

          <div className="pt-1">
            <button
              onClick={() => onOpenCopilot(`${currentCustomer.nameJa} 様のポートフォリオにおける税務最適化シナリオおよび信託スキームの法的安全性を評価してください。`)}
              className="text-xs text-red-400 hover:text-red-300 flex items-center space-x-1 cursor-pointer font-medium"
            >
              <span>AI コパイロットで富裕層資産承継プランを詳細検討 →</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
