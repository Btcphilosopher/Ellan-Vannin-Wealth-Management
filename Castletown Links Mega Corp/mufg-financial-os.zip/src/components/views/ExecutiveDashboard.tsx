/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  TrendingUp,
  ShieldCheck,
  Landmark,
  Layers,
  ArrowUpRight,
  ArrowDownRight,
  Sparkles,
  AlertTriangle,
  Building2,
  PieChart as PieChartIcon
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  AreaChart,
  Area
} from 'recharts';
import { formatJPY, formatPercent, formatBps } from '../../engines/japaneseFormatters';
import { EXECUTIVE_GROUP_KPIS, MUFG_GROUP_ENTITIES } from '../../data/groupStructure';
import { SYNTHETIC_RISK_EXPOSURES } from '../../data/syntheticDatabase';

interface ExecutiveDashboardProps {
  onOpenCopilot: (query?: string) => void;
  onNavigate: (workspace: any) => void;
}

const PROFIT_TREND_DATA = [
  { period: '2024 Q3', 業務純益: 4200, 当期純利益: 3650, 貸出残高: 118 },
  { period: '2024 Q4', 業務純益: 4450, 当期純利益: 3820, 貸出残高: 120 },
  { period: '2025 Q1', 業務純益: 4680, 当期純利益: 4100, 貸出残高: 122 },
  { period: '2025 Q2', 業務純益: 4890, 当期純利益: 4320, 貸出残高: 123 },
  { period: '2025 Q3', 業務純益: 5120, 当期純利益: 4580, 貸出残高: 124 },
  { period: '2025 Q4', 業務純益: 5350, 当期純利益: 4800, 貸出残高: 124.6 }
];

const SUBSIDIARY_ASSETS_DATA = MUFG_GROUP_ENTITIES.slice(0, 6).map(ent => ({
  name: ent.name.replace('株式会社', '').replace('三菱UFJ', ''),
  総資産: Math.round(ent.totalAssetsJPY / 1_000_000_000_000),
  自己資本: Math.round(ent.totalEquityJPY / 1_000_000_000_000)
}));

export const ExecutiveDashboard: React.FC<ExecutiveDashboardProps> = ({
  onOpenCopilot,
  onNavigate
}) => {
  const kpi = EXECUTIVE_GROUP_KPIS;

  return (
    <div className="space-y-6">
      {/* Executive Welcome & Live Telemetry Banner */}
      <div className="bg-gradient-to-r from-[#0B132B] via-[#1C2541] to-[#0B132B] p-5 rounded-xl border border-slate-700/80 shadow-xl flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <span className="text-xs font-mono text-red-400 font-bold tracking-wider">EXECUTIVE COMMAND CENTRE // 経営最高会議</span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-700/60 font-mono">
              全社ガバナンス正常稼働
            </span>
          </div>
          <h1 className="text-2xl font-bold text-white tracking-tight mt-1">
            おはようございます。本日の金融グループ総合概況
          </h1>
          <p className="text-xs text-slate-300 mt-1">
            銀行・信託・証券・資産運用・カード・リースを単一の正規化金融モデルで統合監視しています。
          </p>
        </div>

        <div className="flex items-center space-x-3">
          <button
            onClick={() => onOpenCopilot('本日の流動性ポジションおよび主要リスク限度枠の消化状況を経営向けに総括してください。')}
            className="flex items-center space-x-2 px-3.5 py-2 bg-gradient-to-r from-red-700 to-rose-700 hover:from-red-600 hover:to-rose-600 text-white rounded-lg text-xs font-bold shadow-lg shadow-red-950 transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>AI 経営状況分析レポート</span>
          </button>
        </div>
      </div>

      {/* Primary Financial Pillars (KPI Bento Grid) */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3.5">
        {/* Total Assets */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl shadow-lg relative overflow-hidden">
          <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
            <span>グループ総資産 (Total Assets)</span>
            <Building2 className="w-4 h-4 text-slate-500" />
          </div>
          <div className="text-2xl font-bold text-white font-mono mt-1">
            {formatJPY(kpi.totalAssetsJPY)}
          </div>
          <div className="flex items-center space-x-1.5 text-[11px] text-emerald-400 mt-2 font-medium">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>前年同期比 +4.2% (貸出・有価証券伸長)</span>
          </div>
        </div>

        {/* Deposits & Loans */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl shadow-lg relative overflow-hidden">
          <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
            <span>預貸金構造 (Deposits / Loans)</span>
            <Landmark className="w-4 h-4 text-slate-500" />
          </div>
          <div className="flex items-baseline space-x-2 mt-1">
            <span className="text-xl font-bold text-white font-mono">{formatJPY(kpi.totalDepositsJPY)}</span>
            <span className="text-xs text-slate-400">/ 貸出 {formatJPY(kpi.totalLoansJPY)}</span>
          </div>
          <div className="flex items-center space-x-1.5 text-[11px] text-slate-300 mt-2">
            <span>預貸率: <strong className="text-white font-mono">52.62%</strong> (十分な資金余剰)</span>
          </div>
        </div>

        {/* CET1 & Capital */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl shadow-lg relative overflow-hidden">
          <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
            <span>普通株式等Tier1比率 (CET1)</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-emerald-400 font-mono mt-1">
            {formatPercent(kpi.cet1RatioPct, 2)}
          </div>
          <div className="text-[11px] text-slate-400 mt-2">
            規制最低基準 (4.5% + バッファー) に対し <strong className="text-emerald-400 font-mono">+4.45%</strong>
          </div>
        </div>

        {/* Profitability & ROE */}
        <div className="bg-slate-900/90 border border-slate-800 p-4 rounded-xl shadow-lg relative overflow-hidden">
          <div className="text-[11px] font-medium text-slate-400 flex items-center justify-between">
            <span>当期純利益 / ROE</span>
            <TrendingUp className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="text-2xl font-bold text-white font-mono mt-1">
            {formatJPY(kpi.netProfitJPY)}
          </div>
          <div className="flex items-center space-x-2 text-[11px] text-cyan-300 mt-2">
            <span>ROE: <strong className="font-mono">{formatPercent(kpi.roePct, 2)}</strong></span>
            <span>RORA: <strong className="font-mono">{formatPercent(kpi.roraPct, 2)}</strong></span>
          </div>
        </div>
      </div>

      {/* Secondary Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-900/60 p-3.5 rounded-xl border border-slate-800 text-xs">
        <div className="border-r border-slate-800 pr-3">
          <span className="text-slate-400">流動性カバレッジ比率 (LCR)</span>
          <div className="text-base font-bold text-white font-mono mt-0.5">{formatPercent(kpi.lcrRatioPct, 1)}</div>
          <span className="text-[10px] text-emerald-400">規制基準 100% 超過</span>
        </div>
        <div className="border-r border-slate-800 pr-3">
          <span className="text-slate-400">適格流動性資産バッファー (HQLA)</span>
          <div className="text-base font-bold text-white font-mono mt-0.5">{formatJPY(kpi.hqlBufferJPY)}</div>
          <span className="text-[10px] text-slate-400">日銀当預・国債中心</span>
        </div>
        <div className="border-r border-slate-800 pr-3">
          <span className="text-slate-400">純資金利ざや (NIM)</span>
          <div className="text-base font-bold text-white font-mono mt-0.5">{formatPercent(kpi.nimPct, 2)}</div>
          <span className="text-[10px] text-cyan-400">金利上昇に伴い改善傾向</span>
        </div>
        <div>
          <span className="text-slate-400">日次市場リスク量 (VaR 99% 1日)</span>
          <div className="text-base font-bold text-amber-400 font-mono mt-0.5">{formatJPY(kpi.dailyVaR99_JPY)}</div>
          <span className="text-[10px] text-slate-400">上限枠 600億円以内</span>
        </div>
      </div>

      {/* Charts Grid: Profitability Trend & Subsidiary Asset Distribution */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Trend Area Chart */}
        <div className="bg-slate-900 border border-slate-800 p-4.5 rounded-xl shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">グループ収益・純利益推移 (四半期ベース)</h3>
              <p className="text-[11px] text-slate-400 font-mono">単位: 億円 (業務純益 vs 当期純利益)</p>
            </div>
            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono">2024-2025</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={PROFIT_TREND_DATA} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorProfit" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#c8102e" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#c8102e" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorNet" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#38bdf8" stopOpacity={0.8}/>
                    <stop offset="95%" stopColor="#38bdf8" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="period" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Area type="monotone" dataKey="業務純益" stroke="#ef4444" fillOpacity={1} fill="url(#colorProfit)" />
                <Area type="monotone" dataKey="当期純利益" stroke="#38bdf8" fillOpacity={1} fill="url(#colorNet)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Subsidiary Asset Breakdown Bar Chart */}
        <div className="bg-slate-900 border border-slate-800 p-4.5 rounded-xl shadow-lg">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-white">主要グループ各社 総資産・自己資本規模</h3>
              <p className="text-[11px] text-slate-400 font-mono">単位: 兆円 (銀行・信託・証券・AM・カード・リース)</p>
            </div>
            <button
              onClick={() => onNavigate('dictionary')}
              className="text-[10px] text-red-400 hover:text-red-300 font-medium cursor-pointer"
            >
              グループ全社一覧 →
            </button>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={SUBSIDIARY_ASSETS_DATA} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={10} tickLine={false} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', fontSize: '11px' }}
                />
                <Legend wrapperStyle={{ fontSize: '11px', paddingTop: '8px' }} />
                <Bar dataKey="総資産" fill="#1e40af" radius={[4, 4, 0, 0]} />
                <Bar dataKey="自己資本" fill="#dc2626" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Global Risk OS Summary Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-4.5 shadow-lg">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <h3 className="text-sm font-bold text-white">グループ統合リスク管理マトリクス (Risk OS Summary)</h3>
          </div>
          <button
            onClick={() => onNavigate('risk')}
            className="text-xs text-red-400 hover:text-red-300 font-medium cursor-pointer"
          >
            詳細リスク管理画面へ →
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-800/80 text-slate-400 border-b border-slate-700 font-medium">
              <tr>
                <th className="py-2.5 px-3">リスク区分</th>
                <th className="py-2.5 px-3">管理指標名称</th>
                <th className="py-2.5 px-3 text-right">現存エクスポージャー</th>
                <th className="py-2.5 px-3 text-right">上限限度枠</th>
                <th className="py-2.5 px-3 text-center">枠消化率</th>
                <th className="py-2.5 px-3 text-center">ステータス</th>
                <th className="py-2.5 px-3">主管部室</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {SYNTHETIC_RISK_EXPOSURES.map(risk => (
                <tr key={risk.id} className="hover:bg-slate-800/40 transition-colors">
                  <td className="py-2.5 px-3 font-mono font-semibold text-slate-300">{risk.category}</td>
                  <td className="py-2.5 px-3 font-medium text-white">{risk.nameJa}</td>
                  <td className="py-2.5 px-3 text-right font-mono font-semibold text-slate-200">{formatJPY(risk.exposureAmountJPY)}</td>
                  <td className="py-2.5 px-3 text-right font-mono text-slate-400">{formatJPY(risk.limitAmountJPY)}</td>
                  <td className="py-2.5 px-3 text-center font-mono font-bold text-slate-200">
                    <div className="flex items-center justify-center space-x-1.5">
                      <div className="w-16 bg-slate-800 rounded-full h-1.5 overflow-hidden">
                        <div
                          className={`h-full ${risk.utilizationPct > 90 ? 'bg-red-500' : risk.utilizationPct > 75 ? 'bg-amber-500' : 'bg-emerald-500'}`}
                          style={{ width: `${Math.min(100, risk.utilizationPct)}%` }}
                        ></div>
                      </div>
                      <span>{(risk.utilizationPct ?? 0).toFixed(1)}%</span>
                    </div>
                  </td>
                  <td className="py-2.5 px-3 text-center">
                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                      risk.status === 'NORMAL' ? 'bg-emerald-950 text-emerald-400 border border-emerald-800/60' : 'bg-amber-950 text-amber-400 border border-amber-800/60'
                    }`}>
                      {risk.status}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-slate-400">{risk.ownerDepartmentJa}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
