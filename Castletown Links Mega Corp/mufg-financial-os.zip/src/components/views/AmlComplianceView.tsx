/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Scale,
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  FileCheck,
  UserCheck,
  Sparkles
} from 'lucide-react';
import { AMLAlert } from '../../types/financial';
import { formatExactJPY, formatDateJa } from '../../engines/japaneseFormatters';
import { SYNTHETIC_AML_ALERTS } from '../../data/syntheticDatabase';

interface AmlComplianceViewProps {
  alerts: AMLAlert[];
  onResolveAlert: (alertId: string, disposition: any, notesJa: string) => void;
  onOpenCopilot: (query?: string) => void;
}

export const AmlComplianceView: React.FC<AmlComplianceViewProps> = ({
  alerts,
  onResolveAlert,
  onOpenCopilot
}) => {
  const [selectedAlert, setSelectedAlert] = useState<AMLAlert>(alerts[0]);
  const [resolutionNotes, setResolutionNotes] = useState<string>('');
  const [isResolving, setIsResolving] = useState<boolean>(false);

  const handleExecuteDecision = (disposition: 'CLEARED_FALSE_POSITIVE' | 'ESCALATED_SAR' | 'FROZEN_ACCOUNT') => {
    if (!resolutionNotes.trim()) {
      alert('コンプライアンス審査役の決裁理由（Notes）を入力してください。');
      return;
    }
    onResolveAlert(selectedAlert.id, disposition, resolutionNotes);
    setResolutionNotes('');
    alert(`【決裁完了】アラート ${selectedAlert.alertNumber} に対する処分（${disposition}）が不変監査ログに記録されました。`);
  };

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-4.5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <Scale className="w-5 h-5 text-rose-500" />
            <h1 className="text-xl font-bold text-white">AML & コンプライアンス・制裁スクリーニング (AML / CFT OS)</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            疑わしい取引 (SAR) 届出判定、外国PEPs・制裁リスト照合、急速資金移動検知、AI審査支援 & 人間決裁 (Human-in-the-Loop)
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={() => onOpenCopilot(`AMLアラート ${selectedAlert.alertNumber}（対象: ${selectedAlert.customerNameJa}、金額: ${formatExactJPY(selectedAlert.transactionAmountJPY)}）の疑わしき取引届出 (SAR) の必要性をFATF基準および犯罪収益移転防止法に基づいて判定支援してください。`)}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-700 hover:bg-red-600 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-md"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>AI SAR法適合性分析</span>
          </button>
        </div>
      </div>

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* AML Alert List */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-slate-400 uppercase font-mono">
              未済・審査中アラート一覧 ({alerts.length}件)
            </h2>
            <span className="text-[10px] text-rose-400 font-mono font-bold">要対応</span>
          </div>

          <div className="space-y-2">
            {alerts.map(a => {
              const isSelected = a.id === selectedAlert?.id;
              return (
                <button
                  key={a.id}
                  onClick={() => setSelectedAlert(a)}
                  className={`w-full text-left p-3 rounded-lg border transition-all cursor-pointer ${
                    isSelected
                      ? 'bg-slate-800 border-rose-500/80 ring-1 ring-rose-500/40'
                      : 'bg-slate-950/60 border-slate-800 hover:bg-slate-800/40 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs font-mono text-white">{a.alertNumber}</span>
                    <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded font-mono ${
                      a.severity === 'CRITICAL' || a.severity === 'HIGH' ? 'bg-rose-950 text-rose-300 border border-rose-800' : 'bg-amber-950 text-amber-300 border border-amber-800'
                    }`}>
                      {a.severity}
                    </span>
                  </div>
                  <div className="text-xs text-slate-200 font-medium mt-1 truncate">{a.customerNameJa}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5">{a.scenarioTypeJa}</div>
                  <div className="text-[10px] text-slate-500 font-mono mt-1 flex justify-between">
                    <span>{formatDateJa(a.triggeredAt)}</span>
                    <span className="text-slate-300 font-bold">{formatExactJPY(a.transactionAmountJPY)}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected AML Investigation & Human Decision Console */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
          <div className="flex items-start justify-between border-b border-slate-800 pb-3">
            <div>
              <div className="flex items-center space-x-2">
                <h3 className="text-lg font-bold text-white font-mono">{selectedAlert.alertNumber}</h3>
                <span className="text-xs px-2 py-0.5 rounded bg-rose-950 text-rose-400 font-bold border border-rose-800">
                  {selectedAlert.scenarioTypeJa}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                対象顧客: <strong className="text-white">{selectedAlert.customerNameJa}</strong> ({selectedAlert.customerId})
              </p>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-slate-400 font-mono">検知スコア (Risk Score)</span>
              <div className="text-2xl font-bold text-rose-400 font-mono">
                {selectedAlert.riskScore} <span className="text-xs text-slate-400">/ 100</span>
              </div>
            </div>
          </div>

          {/* Alert Description & Facts */}
          <div className="bg-slate-950/70 p-4 rounded-lg border border-slate-800 space-y-2 text-xs">
            <span className="font-bold text-slate-300">【アラート検知詳細 & 取引動態】</span>
            <p className="text-slate-300 leading-relaxed">{selectedAlert.descriptionJa}</p>
            <div className="flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-800/80 font-mono">
              <span>対象取引金額: <strong className="text-white font-bold">{formatExactJPY(selectedAlert.transactionAmountJPY)}</strong></span>
              <span>担当調査官: <strong className="text-slate-200">{selectedAlert.assignedInvestigatorJa}</strong></span>
            </div>
          </div>

          {/* Current Status */}
          <div className="flex items-center justify-between p-3 rounded-lg bg-slate-800 text-xs">
            <span className="text-slate-300">現在の審査ステータス:</span>
            <span className="font-bold text-amber-400 font-mono px-2 py-0.5 rounded bg-slate-900 border border-amber-500/40">
              {selectedAlert.humanDisposition}
            </span>
          </div>

          {/* Human Officer Decision Form */}
          <div className="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-3">
            <span className="text-xs font-bold text-white flex items-center space-x-1.5">
              <UserCheck className="w-4 h-4 text-emerald-400" />
              <span>コンプライアンス審査役 最終処分決裁 (Human Approval Required)</span>
            </span>

            <textarea
              rows={3}
              value={resolutionNotes}
              onChange={e => setResolutionNotes(e.target.value)}
              placeholder="調査結果および処分理由を記入 (例: 実体取引確認済み、または金融庁・財務省への疑わしい取引届出決定)..."
              className="w-full bg-slate-900 border border-slate-700 rounded p-2.5 text-xs text-white placeholder-slate-500 font-sans focus:outline-none focus:ring-1 focus:ring-red-500"
            />

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1">
              <button
                onClick={() => handleExecuteDecision('CLEARED_FALSE_POSITIVE')}
                className="py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-bold border border-slate-600 transition-all cursor-pointer flex items-center justify-center space-x-1"
              >
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                <span>誤検知解除 (Clear)</span>
              </button>

              <button
                onClick={() => handleExecuteDecision('ESCALATED_SAR')}
                className="py-2 px-3 bg-amber-700 hover:bg-amber-600 text-white rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center space-x-1 shadow-md"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span>当局へSAR届出 (Escalate)</span>
              </button>

              <button
                onClick={() => handleExecuteDecision('FROZEN_ACCOUNT')}
                className="py-2 px-3 bg-red-700 hover:bg-red-600 text-white rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center space-x-1 shadow-md"
              >
                <XCircle className="w-3.5 h-3.5" />
                <span>口座凍結・取引停止 (Freeze)</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
