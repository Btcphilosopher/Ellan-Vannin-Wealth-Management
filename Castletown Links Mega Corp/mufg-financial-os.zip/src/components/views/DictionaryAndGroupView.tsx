/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  BookA,
  Building2,
  Search,
  Network,
  Globe2,
  ExternalLink,
  Layers,
  Sparkles
} from 'lucide-react';
import { FinancialTerm } from '../../types/dictionary';
import { CANONICAL_FINANCIAL_TERMS, searchFinancialTerms } from '../../data/dictionaryData';
import { MUFG_GROUP_ENTITIES } from '../../data/groupStructure';
import { formatJPY } from '../../engines/japaneseFormatters';

interface DictionaryAndGroupViewProps {
  onSelectTerm?: (term: FinancialTerm) => void;
  onOpenCopilot: (query?: string) => void;
}

export const DictionaryAndGroupView: React.FC<DictionaryAndGroupViewProps> = ({
  onSelectTerm,
  onOpenCopilot
}) => {
  const [activeTab, setActiveTab] = useState<'DICTIONARY' | 'GROUP_STRUCTURE'>('DICTIONARY');
  const [query, setQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  const terms = searchFinancialTerms(query);
  const filteredTerms = selectedCategory === 'ALL'
    ? terms
    : terms.filter(t => t.categoryJa.toUpperCase().includes(selectedCategory) || t.canonicalEntity.toUpperCase().includes(selectedCategory));

  const categories = ['ALL', 'LENDING', 'MARKETS', 'TREASURY', 'ACCOUNTING', 'RISK', 'COMPLIANCE', 'WEALTH'];

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-4.5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <BookA className="w-5 h-5 text-red-500" />
            <h1 className="text-xl font-bold text-white">金融用語辞書 & グループ組織構造 (Terminology & Corporate Hierarchy)</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            漢字・ひらがな・ローマ字・英語略語・業界別エイリアスを網羅した正規化金融辞書とグループ連結構造
          </p>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setActiveTab('DICTIONARY')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'DICTIONARY' ? 'bg-red-700 text-white' : 'bg-slate-800 text-slate-300'
            }`}
          >
            金融用語辞書 ({CANONICAL_FINANCIAL_TERMS.length}語)
          </button>
          <button
            onClick={() => setActiveTab('GROUP_STRUCTURE')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'GROUP_STRUCTURE' ? 'bg-red-700 text-white' : 'bg-slate-800 text-slate-300'
            }`}
          >
            MUFG グループ組織構造 ({MUFG_GROUP_ENTITIES.length}社)
          </button>
        </div>
      </div>

      {activeTab === 'DICTIONARY' ? (
        <div className="space-y-4">
          {/* Search & Filter Bar */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-900 p-4 rounded-xl border border-slate-800">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="用語・読み仮名・ローマ字・英略語を検索 (例: 融資, yuushi, lcr, var, 貸倒引当金)..."
                className="w-full bg-slate-950 border border-slate-700 rounded-lg pl-9 pr-4 py-2 text-xs text-white placeholder-slate-500 font-sans"
              />
            </div>

            <div className="flex items-center space-x-1.5 overflow-x-auto text-xs">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-2.5 py-1 rounded text-[11px] font-bold transition-all cursor-pointer ${
                    selectedCategory === cat ? 'bg-red-600 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          {/* Terminology Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {filteredTerms.map(term => (
              <div
                key={term.id}
                className="bg-slate-900 border border-slate-800 rounded-xl p-4.5 space-y-2 hover:border-slate-700 transition-all shadow-md"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="text-base font-bold text-white">{term.termJa}</h3>
                      <span className="text-xs text-slate-400 font-mono">({term.kana})</span>
                    </div>
                    <p className="text-xs text-cyan-400 font-mono">{term.termEn}</p>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono border border-slate-700">
                    {term.categoryJa}
                  </span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed pt-1">
                  {term.definitionJa}
                </p>

                {term.aliases.length > 0 && (
                  <div className="pt-2 border-t border-slate-800/80 flex flex-wrap gap-1 text-[10px]">
                    <span className="text-slate-500 font-mono">別名・検索キー:</span>
                    {term.aliases.map((alias, idx) => (
                      <span key={idx} className="px-1.5 py-0.2 rounded bg-slate-950 text-slate-400 font-mono border border-slate-850">
                        {alias}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ) : (
        /* Group Structure List */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {MUFG_GROUP_ENTITIES.map(ent => (
            <div key={ent.id} className="bg-slate-900 border border-slate-800 rounded-xl p-4.5 space-y-3 shadow-md">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="text-sm font-bold text-white">{ent.name}</h3>
                  <p className="text-xs text-slate-400 font-mono">{ent.nameEn}</p>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-800">
                  {ent.jurisdiction}
                </span>
              </div>

              <div className="space-y-1.5 text-xs text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">事業種目:</span>
                  <span className="font-semibold text-white">{ent.type}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">総資産規模:</span>
                  <span className="font-mono font-bold text-emerald-400">{formatJPY(ent.totalAssetsJPY)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">自己資本:</span>
                  <span className="font-mono font-bold text-slate-200">{formatJPY(ent.totalEquityJPY)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">国内拠点数:</span>
                  <span className="font-mono font-bold text-slate-200">{ent.branchesCount} 拠点</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">従業員数:</span>
                  <span className="text-slate-200 font-mono">{ent.employeesCount.toLocaleString()} 名</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
