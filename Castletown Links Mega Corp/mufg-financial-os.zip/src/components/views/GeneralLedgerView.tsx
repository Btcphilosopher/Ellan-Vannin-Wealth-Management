/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  BookOpenCheck,
  CheckCircle2,
  AlertCircle,
  PlusCircle,
  RefreshCw,
  Search,
  Sparkles,
  Layers
} from 'lucide-react';
import { JournalEntry, ReconciliationCase } from '../../types/financial';
import { formatExactJPY, formatJPY } from '../../engines/japaneseFormatters';
import { SYNTHETIC_JOURNALS, SYNTHETIC_RECONCILIATION_CASES } from '../../data/syntheticDatabase';

interface GeneralLedgerViewProps {
  journals: JournalEntry[];
  reconciliations: ReconciliationCase[];
  onOpenNewTransactionModal: () => void;
  onOpenCopilot: (query?: string) => void;
}

export const GeneralLedgerView: React.FC<GeneralLedgerViewProps> = ({
  journals,
  reconciliations,
  onOpenNewTransactionModal,
  onOpenCopilot
}) => {
  const [activeTab, setActiveTab] = useState<'JOURNALS' | 'RECONCILIATION'>('JOURNALS');
  const [selectedJournal, setSelectedJournal] = useState<JournalEntry | null>(journals[0] || null);

  return (
    <div className="space-y-6">
      {/* View Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/90 p-4.5 rounded-xl border border-slate-800">
        <div>
          <div className="flex items-center space-x-2">
            <BookOpenCheck className="w-5 h-5 text-sky-400" />
            <h1 className="text-xl font-bold text-white">総勘定元帳 & 照合エンジン (Double-Entry General Ledger & Recon)</h1>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            浮動小数点数誤差完全排除の整数複式簿記（借方・貸方一致性検証）、外部決済網との残高アンブレイク照合
          </p>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={onOpenNewTransactionModal}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-red-700 hover:bg-red-600 text-white rounded-lg text-xs font-bold transition-all cursor-pointer shadow-md"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>新規複式仕訳を起票 (Post Journal)</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center space-x-2 border-b border-slate-800 pb-2">
        <button
          onClick={() => setActiveTab('JOURNALS')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer ${
            activeTab === 'JOURNALS'
              ? 'bg-slate-800 text-white border border-slate-700'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          複式仕訳伝票一覧 ({journals.length}件)
        </button>
        <button
          onClick={() => setActiveTab('RECONCILIATION')}
          className={`px-4 py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center space-x-1.5 ${
            activeTab === 'RECONCILIATION'
              ? 'bg-slate-800 text-white border border-slate-700'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <span>外部残高照合 & 差異調査 (Reconciliation)</span>
          <span className="px-1.5 py-0.2 rounded-full bg-amber-600 text-white text-[10px] font-mono">
            {reconciliations.filter(r => r.reconciliationStatus === 'UNRECONCILED_BREAK').length}
          </span>
        </button>
      </div>

      {activeTab === 'JOURNALS' ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
          {/* Journal Entries List */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <h2 className="text-xs font-bold text-slate-400 uppercase font-mono">起票済仕訳伝票</h2>
            <div className="space-y-2 max-h-[500px] overflow-y-auto pr-1">
              {journals.map(j => {
                const isSelected = selectedJournal?.id === j.id;
                return (
                  <button
                    key={j.id}
                    onClick={() => setSelectedJournal(j)}
                    className={`w-full text-left p-3 rounded-lg border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-slate-800 border-sky-500/80 ring-1 ring-sky-500/40'
                        : 'bg-slate-950/60 border-slate-800 hover:bg-slate-800/40 text-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-xs font-mono text-white">{j.entryNumber}</span>
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-emerald-950 text-emerald-400 border border-emerald-800 font-mono">
                        {j.status}
                      </span>
                    </div>
                    <div className="text-xs text-slate-300 font-medium mt-1">{j.transactionType}</div>
                    <div className="text-[10px] text-slate-400 font-mono mt-1 flex justify-between">
                      <span>起票日: {j.postingDate}</span>
                      <span className="text-emerald-400 font-bold">{formatExactJPY(j.totalDebitJPY)}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Detailed Double-Entry Ledger Lines for Selected Entry */}
          <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 space-y-4">
            {selectedJournal ? (
              <>
                <div className="flex items-start justify-between border-b border-slate-800 pb-3">
                  <div>
                    <div className="flex items-center space-x-2">
                      <h3 className="text-base font-bold text-white font-mono">{selectedJournal.entryNumber}</h3>
                      <span className="text-xs px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {selectedJournal.transactionType}
                      </span>
                    </div>
                    <p className="text-xs text-slate-400 mt-0.5">
                      起票元モジュール: {selectedJournal.sourceModule} | 起票者: {selectedJournal.createdBy}
                    </p>
                  </div>
                  <div className="flex items-center space-x-1 text-emerald-400 text-xs font-bold bg-emerald-950/80 px-2.5 py-1 rounded border border-emerald-800">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>貸借完全一致 (Balanced)</span>
                  </div>
                </div>

                {/* Journal Lines Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-800 text-slate-400 font-medium border-b border-slate-700">
                      <tr>
                        <th className="py-2.5 px-3">勘定科目コード</th>
                        <th className="py-2.5 px-3">勘定科目名称</th>
                        <th className="py-2.5 px-3 text-right">借方金額 (Debit JPY)</th>
                        <th className="py-2.5 px-3 text-right">貸方金額 (Credit JPY)</th>
                        <th className="py-2.5 px-3">摘要</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800 font-mono">
                      {selectedJournal.lines.map(line => (
                        <tr key={line.id} className="hover:bg-slate-800/30">
                          <td className="py-2 px-3 text-slate-400">{line.accountCode}</td>
                          <td className="py-2 px-3 font-sans font-medium text-white">{line.accountNameJa}</td>
                          <td className="py-2 px-3 text-right font-bold text-emerald-400">
                            {line.debitJPY > 0 ? formatExactJPY(line.debitJPY) : '-'}
                          </td>
                          <td className="py-2 px-3 text-right font-bold text-cyan-400">
                            {line.creditJPY > 0 ? formatExactJPY(line.creditJPY) : '-'}
                          </td>
                          <td className="py-2 px-3 font-sans text-slate-300">{line.descriptionJa}</td>
                        </tr>
                      ))}
                      {/* Total Balancing Row */}
                      <tr className="bg-slate-950 font-bold border-t-2 border-slate-700">
                        <td colSpan={2} className="py-2.5 px-3 font-sans text-right text-slate-300">
                          借貸合計 (Total)
                        </td>
                        <td className="py-2.5 px-3 text-right text-emerald-400">
                          {formatExactJPY(selectedJournal.totalDebitJPY)}
                        </td>
                        <td className="py-2.5 px-3 text-right text-cyan-400">
                          {formatExactJPY(selectedJournal.totalCreditJPY)}
                        </td>
                        <td className="py-2.5 px-3 font-sans text-emerald-400">差額: ¥0 (完全合致)</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </>
            ) : (
              <div className="p-8 text-center text-slate-500 text-xs">仕訳を選択してください</div>
            )}
          </div>
        </div>
      ) : (
        /* Reconciliation Table */
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-4.5 shadow-lg space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-slate-300 uppercase font-mono">
              外部決済機構・カストディアン残高照合マトリクス ({reconciliations.length}件)
            </h2>
            <span className="text-[10px] text-slate-400 font-mono">自動突合バッチ: 完了</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-800 text-slate-400 border-b border-slate-700 font-medium">
                <tr>
                  <th className="py-2.5 px-3">照合ケースID</th>
                  <th className="py-2.5 px-3">対象外部システム</th>
                  <th className="py-2.5 px-3">勘定科目名称</th>
                  <th className="py-2.5 px-3 text-right">社内元帳残高</th>
                  <th className="py-2.5 px-3 text-right">外部ステートメント残高</th>
                  <th className="py-2.5 px-3 text-right">照合差額 (Break)</th>
                  <th className="py-2.5 px-3 text-center">ステータス</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 font-mono">
                {reconciliations.map(recon => (
                  <tr key={recon.id} className="hover:bg-slate-800/40">
                    <td className="py-2.5 px-3 font-bold text-slate-200">{recon.caseNumber}</td>
                    <td className="py-2.5 px-3 font-sans font-semibold text-white">{recon.externalSource}</td>
                    <td className="py-2.5 px-3 font-sans text-slate-300">{recon.accountNameJa}</td>
                    <td className="py-2.5 px-3 text-right text-slate-200">{formatExactJPY(recon.internalLedgerAmountJPY)}</td>
                    <td className="py-2.5 px-3 text-right text-slate-200">{formatExactJPY(recon.externalStatementAmountJPY)}</td>
                    <td className={`py-2.5 px-3 text-right font-bold ${recon.discrepancyJPY === 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {formatExactJPY(recon.discrepancyJPY)}
                    </td>
                    <td className="py-2.5 px-3 text-center">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        recon.reconciliationStatus === 'MATCHED'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-amber-950 text-amber-400 border border-amber-800'
                      }`}>
                        {recon.reconciliationStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
