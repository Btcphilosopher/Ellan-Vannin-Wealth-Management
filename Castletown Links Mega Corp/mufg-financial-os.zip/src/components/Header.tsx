/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Building2,
  ShieldAlert,
  Search,
  Activity,
  Bell,
  UserCheck,
  ChevronDown,
  Sparkles,
  FileSpreadsheet,
  Globe2,
  Database
} from 'lucide-react';
import { FinancialTerm } from '../types/dictionary';
import { searchFinancialTerms } from '../data/dictionaryData';

export type UserRole = 
  | 'EXECUTIVE'
  | 'CORPORATE_RM'
  | 'WEALTH_PB'
  | 'TRADER'
  | 'RISK_OFFICER'
  | 'TREASURY_ALM'
  | 'AML_COMPLIANCE'
  | 'OPERATIONS';

interface HeaderProps {
  currentRole: UserRole;
  onSelectRole: (role: UserRole) => void;
  onOpenCopilot: (initialQuery?: string) => void;
  onOpenNewTransaction: () => void;
  onOpenNewAssessment: () => void;
  onSelectTerm: (term: FinancialTerm) => void;
}

const ROLE_LABELS: Record<UserRole, { label: string; sub: string; icon: string }> = {
  EXECUTIVE: { label: 'グループ経営役員 (CEO/CFO/CRO)', sub: '全社総括・資本政策・ガバナンス', icon: '🏛️' },
  CORPORATE_RM: { label: '法人RM (Commercial & CIB)', sub: '企業融資・格付審査・シンジケーション', icon: '🏢' },
  WEALTH_PB: { label: 'ウェルスPB (Private Banking)', sub: '富裕層資産管理・信託・事業承継', icon: '💎' },
  TRADER: { label: 'マーケッツ・ディーラー (FICC/FX)', sub: '債券・為替・金利スワップ取引', icon: '📊' },
  RISK_OFFICER: { label: 'リスク統括部 (Risk Manager)', sub: '信用・市場・流動性・限度枠管理', icon: '🛡️' },
  TREASURY_ALM: { label: '財務企画・トレジャリー (ALM)', sub: '資金調達・LCR/NSFR・金利ギャップ', icon: '🏦' },
  AML_COMPLIANCE: { label: 'コンプライアンス・AML審査官', sub: '疑わしい取引・制裁照合・調査決裁', icon: '⚖️' },
  OPERATIONS: { label: '決済オペレーション・主計', sub: '全銀/SWIFT送金・総勘定元帳・照合', icon: '⚙️' }
};

export const Header: React.FC<HeaderProps> = ({
  currentRole,
  onSelectRole,
  onOpenCopilot,
  onOpenNewTransaction,
  onOpenNewAssessment,
  onSelectTerm
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<FinancialTerm[]>([]);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isRoleDropdownOpen, setIsRoleDropdownOpen] = useState(false);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setSearchQuery(val);
    if (val.trim()) {
      const results = searchFinancialTerms(val);
      setSearchResults(results.slice(0, 6));
      setIsSearchOpen(true);
    } else {
      setSearchResults([]);
      setIsSearchOpen(false);
    }
  };

  return (
    <header className="bg-[#0B132B] border-b border-slate-800 text-slate-100 sticky top-0 z-40 shadow-xl">
      {/* Top Demo Synthetic Banner */}
      <div className="bg-gradient-to-r from-red-950 via-slate-900 to-red-950 px-4 py-1 text-[11px] font-mono flex items-center justify-between border-b border-red-900/60">
        <div className="flex items-center space-x-2 text-red-300">
          <span className="inline-block w-2 h-2 rounded-full bg-red-500 animate-pulse"></span>
          <span className="font-bold tracking-widest uppercase">DEMO / SYNTHETIC DATA // 合成データ環境</span>
          <span className="text-slate-400">| 実在のMUFG内部機密情報は一切含まれません | 実取引不可</span>
        </div>
        <div className="hidden md:flex items-center space-x-4 text-slate-300">
          <span>日銀当預: <strong className="text-emerald-400 font-mono">¥36.2兆円</strong></span>
          <span>USD/JPY: <strong className="text-cyan-400 font-mono">152.43</strong></span>
          <span>10Y JGB: <strong className="text-amber-400 font-mono">1.055%</strong></span>
          <span>全銀/BOJ-NET: <strong className="text-emerald-400 font-mono">STP 稼働中</strong></span>
        </div>
      </div>

      {/* Main Bar */}
      <div className="px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Logo & Brand */}
        <div className="flex items-center space-x-3 min-w-[280px]">
          <div className="w-9 h-9 rounded-md bg-gradient-to-br from-red-600 to-red-800 flex items-center justify-center shadow-lg shadow-red-900/40 border border-red-500/40">
            <span className="text-white font-extrabold text-sm tracking-tighter">MUFG</span>
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="font-bold text-base tracking-tight text-white">MUFG FINANCIAL OS</span>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-red-900/60 text-red-300 border border-red-700/50">v3.7 Enterprise</span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">三菱UFJフィナンシャル・グループ 総合金融基盤</p>
          </div>
        </div>

        {/* Global Search Bar (Kanji / Kana / Romaji / English / Entity) */}
        <div className="relative flex-1 max-w-xl hidden sm:block">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={handleSearchChange}
              onFocus={() => searchQuery && setIsSearchOpen(true)}
              placeholder="金融用語・顧客・勘定・取引・格付・規制を検索 (例: 融資, yuushi, LCR, 東都産業, VaR)..."
              className="w-full bg-slate-900/90 border border-slate-700 rounded-lg pl-9 pr-4 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-red-500 focus:border-red-500 transition-all font-sans"
            />
          </div>

          {/* Autocomplete Dropdown */}
          {isSearchOpen && searchResults.length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-1 bg-slate-900 border border-slate-700 rounded-lg shadow-2xl overflow-hidden z-50">
              <div className="p-2 border-b border-slate-800 text-[10px] text-slate-400 font-mono">
                CANONICAL FINANCIAL TERMINOLOGY SEARCH ({searchResults.length}件)
              </div>
              <div className="max-h-64 overflow-y-auto divide-y divide-slate-800/60">
                {searchResults.map(term => (
                  <button
                    key={term.id}
                    onClick={() => {
                      onSelectTerm(term);
                      setIsSearchOpen(false);
                      setSearchQuery('');
                    }}
                    className="w-full text-left p-2.5 hover:bg-slate-800/80 transition-colors flex items-start justify-between gap-2"
                  >
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-bold text-xs text-white">{term.termJa}</span>
                        <span className="text-[10px] text-slate-400 font-mono">({term.kana} / {term.termEn})</span>
                      </div>
                      <p className="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{term.definitionJa}</p>
                    </div>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 font-mono shrink-0">
                      {term.categoryJa}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Action Controls & Role Switcher */}
        <div className="flex items-center space-x-2.5">
          {/* AI Copilot Quick Button */}
          <button
            onClick={() => onOpenCopilot()}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-gradient-to-r from-red-700 to-rose-700 hover:from-red-600 hover:to-rose-600 text-white text-xs font-semibold rounded-lg shadow-md shadow-red-950 transition-all cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300 animate-spin-slow" />
            <span>AI Copilot</span>
          </button>

          {/* Role Switcher Menu */}
          <div className="relative">
            <button
              onClick={() => setIsRoleDropdownOpen(!isRoleDropdownOpen)}
              className="flex items-center space-x-2 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-700 rounded-lg text-xs text-slate-200 transition-all cursor-pointer"
            >
              <span>{ROLE_LABELS[currentRole].icon}</span>
              <div className="text-left hidden lg:block">
                <div className="font-bold text-[11px] text-white leading-tight">{ROLE_LABELS[currentRole].label}</div>
                <div className="text-[9px] text-slate-400">{ROLE_LABELS[currentRole].sub}</div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
            </button>

            {isRoleDropdownOpen && (
              <div className="absolute right-0 top-full mt-1.5 w-72 bg-slate-900 border border-slate-700 rounded-xl shadow-2xl overflow-hidden z-50 p-1 divide-y divide-slate-800">
                <div className="px-3 py-2 text-[10px] font-mono text-slate-400">
                  ロール切替 (ROLE-BASED WORKSPACE)
                </div>
                <div className="py-1 space-y-0.5">
                  {(Object.keys(ROLE_LABELS) as UserRole[]).map(roleKey => (
                    <button
                      key={roleKey}
                      onClick={() => {
                        onSelectRole(roleKey);
                        setIsRoleDropdownOpen(false);
                      }}
                      className={`w-full text-left px-3 py-2 rounded-lg text-xs flex items-center space-x-2.5 transition-all ${
                        currentRole === roleKey
                          ? 'bg-red-950/80 text-white font-bold border border-red-800/80'
                          : 'text-slate-300 hover:bg-slate-800'
                      }`}
                    >
                      <span className="text-base">{ROLE_LABELS[roleKey].icon}</span>
                      <div>
                        <div className="font-semibold text-[11px]">{ROLE_LABELS[roleKey].label}</div>
                        <div className="text-[10px] text-slate-400 font-normal">{ROLE_LABELS[roleKey].sub}</div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
