/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  LayoutDashboard,
  Building2,
  Gem,
  TrendingUp,
  Landmark,
  ShieldAlert,
  SendHorizontal,
  BookOpenCheck,
  Scale,
  Sparkles,
  FileText,
  BookA,
  Network
} from 'lucide-react';

export type ActiveWorkspace = 
  | 'executive'
  | 'corporate'
  | 'wealth'
  | 'markets'
  | 'treasury'
  | 'risk'
  | 'payments'
  | 'ledger'
  | 'aml'
  | 'copilot'
  | 'reports'
  | 'dictionary';

interface SidebarProps {
  activeWorkspace: ActiveWorkspace;
  onSelectWorkspace: (workspace: ActiveWorkspace) => void;
  pendingAmlCount?: number;
  riskBreachCount?: number;
  reconBreakCount?: number;
}

interface NavItem {
  id: ActiveWorkspace;
  labelJa: string;
  subJa: string;
  icon: React.ElementType;
  badge?: number;
  badgeColor?: string;
}

const NAV_ITEMS: NavItem[] = [
  { id: 'executive', labelJa: '経営統合ダッシュボード', subJa: 'Executive Command Centre', icon: LayoutDashboard },
  { id: 'corporate', labelJa: '法人金融 & CIB', subJa: 'Commercial Banking & Syndication', icon: Building2 },
  { id: 'wealth', labelJa: 'ウェルスマネジメント', subJa: 'Wealth & Asset Management', icon: Gem },
  { id: 'markets', labelJa: 'グローバルマーケッツ', subJa: 'FICC, FX, Equities & Trading', icon: TrendingUp },
  { id: 'treasury', labelJa: 'トレジャリー & ALM', subJa: 'Cash, Liquidity & Gap Engine', icon: Landmark },
  { id: 'risk', labelJa: 'リスク管理 OS', subJa: 'Credit, Market VaR & Limits', icon: ShieldAlert, badgeColor: 'bg-amber-600' },
  { id: 'payments', labelJa: '決済 & 資金移動', subJa: 'Zengin, SWIFT & Settlement', icon: SendHorizontal },
  { id: 'ledger', labelJa: '総勘定元帳 & 照合', subJa: 'Double-Entry GL & Break Recon', icon: BookOpenCheck, badgeColor: 'bg-sky-600' },
  { id: 'aml', labelJa: 'AML & コンプライアンス', subJa: 'Sanctions, PEP & SAR Review', icon: Scale, badgeColor: 'bg-rose-600' },
  { id: 'copilot', labelJa: '金融 AI コパイロット', subJa: 'MUFG Financial Copilot (Gemini 3.7)', icon: Sparkles },
  { id: 'reports', labelJa: '公式帳票 & 監査ログ', subJa: 'Japanese Reports & Audit Trail', icon: FileText },
  { id: 'dictionary', labelJa: '用語辞書 & グループ構造', subJa: 'Canonical Financial Dictionary', icon: BookA }
];

export const Sidebar: React.FC<SidebarProps> = ({
  activeWorkspace,
  onSelectWorkspace,
  pendingAmlCount = 1,
  riskBreachCount = 0,
  reconBreakCount = 1
}) => {
  return (
    <aside className="w-64 bg-[#090E1A] border-r border-slate-800 text-slate-300 flex flex-col shrink-0 select-none overflow-y-auto">
      {/* Workspace Menu List */}
      <div className="p-2.5 space-y-1">
        <div className="px-3 py-1 text-[10px] font-mono tracking-wider text-slate-500 uppercase">
          CORE WORKSPACES // 中核金融業務
        </div>
        {NAV_ITEMS.map(item => {
          const Icon = item.icon;
          const isActive = activeWorkspace === item.id;
          
          let badgeNum: number | undefined;
          if (item.id === 'aml' && pendingAmlCount > 0) badgeNum = pendingAmlCount;
          if (item.id === 'ledger' && reconBreakCount > 0) badgeNum = reconBreakCount;
          if (item.id === 'risk' && riskBreachCount > 0) badgeNum = riskBreachCount;

          return (
            <button
              key={item.id}
              onClick={() => onSelectWorkspace(item.id)}
              className={`w-full text-left px-3 py-2 rounded-lg flex items-center justify-between group transition-all cursor-pointer ${
                isActive
                  ? 'bg-gradient-to-r from-red-950/90 to-slate-900 text-white font-bold border-l-3 border-red-600 shadow-md'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              }`}
            >
              <div className="flex items-center space-x-2.5 min-w-0">
                <Icon
                  className={`w-4 h-4 shrink-0 transition-colors ${
                    isActive ? 'text-red-400' : 'text-slate-500 group-hover:text-slate-300'
                  }`}
                />
                <div className="truncate">
                  <div className={`text-xs truncate ${isActive ? 'text-white font-semibold' : 'text-slate-300'}`}>
                    {item.labelJa}
                  </div>
                  <div className="text-[9px] text-slate-500 font-mono truncate">{item.subJa}</div>
                </div>
              </div>

              {badgeNum !== undefined && (
                <span className={`text-[10px] font-mono font-bold text-white px-1.5 py-0.2 rounded-full ${item.badgeColor || 'bg-red-600'} shrink-0 ml-1.5`}>
                  {badgeNum}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* System Status Footnote */}
      <div className="mt-auto p-3 m-2 bg-slate-900/80 rounded-lg border border-slate-800 text-[10px] text-slate-400 font-mono space-y-1">
        <div className="flex items-center justify-between text-slate-300">
          <span>CANONICAL ENGINE</span>
          <span className="text-emerald-400 font-bold">ONLINE</span>
        </div>
        <div>DB: PostgreSQL Relational</div>
        <div>Ledger: Double-Entry Exact</div>
        <div className="text-slate-500 pt-1 border-t border-slate-800">
          MUFG Japan Financial OS 2026
        </div>
      </div>
    </aside>
  );
};
