/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Calculator, ShieldCheck, CheckCircle2, AlertTriangle } from 'lucide-react';
import { Customer, CreditAssessmentResult } from '../../types/financial';
import { evaluateCreditRisk } from '../../engines/creditEngine';
import { formatExactJPY, formatJPY, formatPercent, formatBps } from '../../engines/japaneseFormatters';

interface NewLoanAssessmentModalProps {
  isOpen: boolean;
  onClose: () => void;
  customer?: Customer;
  onAssessmentCompleted?: (result: CreditAssessmentResult) => void;
}

export const NewLoanAssessmentModal: React.FC<NewLoanAssessmentModalProps> = ({
  isOpen,
  onClose,
  customer,
  onAssessmentCompleted
}) => {
  const [revenue, setRevenue] = useState<number>(customer?.annualRevenueJPY || 250000000000);
  const [operatingIncome, setOperatingIncome] = useState<number>((customer?.annualRevenueJPY || 250000000000) * 0.08);
  const [ebitda, setEbitda] = useState<number>((customer?.annualRevenueJPY || 250000000000) * 0.11);
  const [netIncome, setNetIncome] = useState<number>((customer?.annualRevenueJPY || 250000000000) * 0.05);
  const [totalAssets, setTotalAssets] = useState<number>((customer?.annualRevenueJPY || 250000000000) * 1.2);
  const [netAssets, setNetAssets] = useState<number>((customer?.annualRevenueJPY || 250000000000) * 0.55);
  const [interestDebt, setInterestDebt] = useState<number>((customer?.annualRevenueJPY || 250000000000) * 0.35);
  const [cash, setCash] = useState<number>((customer?.annualRevenueJPY || 250000000000) * 0.15);
  const [freeCashFlow, setFreeCashFlow] = useState<number>((customer?.annualRevenueJPY || 250000000000) * 0.06);
  const [collateralValue, setCollateralValue] = useState<number>((customer?.annualRevenueJPY || 250000000000) * 0.20);
  const [delinquent, setDelinquent] = useState<boolean>(false);
  const [evalResult, setEvalResult] = useState<CreditAssessmentResult | null>(null);

  if (!isOpen) return null;

  const handleRunEvaluation = async () => {
    const res = evaluateCreditRisk({
      customerId: customer?.id || 'CUST-NEW-CORP',
      annualRevenueJPY: revenue,
      operatingIncomeJPY: operatingIncome,
      ebitdaJPY: ebitda,
      netIncomeJPY: netIncome,
      totalAssetsJPY: totalAssets,
      netAssetsJPY: netAssets,
      interestBearingDebtJPY: interestDebt,
      cashAndEquivalentsJPY: cash,
      freeCashFlowJPY: freeCashFlow,
      collateralValueJPY: collateralValue,
      industryRiskTier: 'LOW',
      existingDelinquency: delinquent
    });
    setEvalResult(res);

    // Call server to record immutable audit log
    try {
      await fetch('/api/credit-eval', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerId: customer?.id || 'CUST-NEW-CORP',
          ...res
        })
      });
    } catch (e) {
      console.error(e);
    }

    if (onAssessmentCompleted) {
      onAssessmentCompleted(res);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-2xl w-full p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <Calculator className="w-5 h-5 text-red-500" />
            <h2 className="text-lg font-bold text-white">法人信用格付 & 与信リスク審査エンジン</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Target Entity */}
        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs text-slate-300">
          対象先: <strong className="text-white">{customer?.nameJa || '新規審査法人'}</strong> (コード: {customer?.customerCode || 'NEW'})
        </div>

        {/* Inputs */}
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div>
            <label className="text-slate-400 block mb-1">年間売上高 (円)</label>
            <input
              type="number"
              value={revenue}
              onChange={e => setRevenue(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1">営業利益 (円)</label>
            <input
              type="number"
              value={operatingIncome}
              onChange={e => setOperatingIncome(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1">EBITDA (円)</label>
            <input
              type="number"
              value={ebitda}
              onChange={e => setEbitda(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1">有利子負債総額 (円)</label>
            <input
              type="number"
              value={interestDebt}
              onChange={e => setInterestDebt(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1">純資産 (自己資本 JPY)</label>
            <input
              type="number"
              value={netAssets}
              onChange={e => setNetAssets(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
            />
          </div>
          <div>
            <label className="text-slate-400 block mb-1">担保保全価値 (円)</label>
            <input
              type="number"
              value={collateralValue}
              onChange={e => setCollateralValue(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-mono"
            />
          </div>
        </div>

        <div className="flex items-center space-x-2 text-xs text-slate-300">
          <input
            type="checkbox"
            id="delinquent"
            checked={delinquent}
            onChange={e => setDelinquent(e.target.checked)}
            className="accent-red-600 rounded"
          />
          <label htmlFor="delinquent">過去3年以内の返済延滞・条件変更・事故歴あり (ペナルティ適用)</label>
        </div>

        <button
          onClick={handleRunEvaluation}
          className="w-full py-2.5 bg-gradient-to-r from-red-700 to-rose-700 hover:from-red-600 hover:to-rose-600 text-white font-bold rounded-lg text-xs shadow-lg transition-all cursor-pointer"
        >
          IRBモデルによる格付スコアリング & 与信枠算定を実行
        </button>

        {/* Results Box */}
        {evalResult && (
          <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="text-xs font-bold text-white">【審査判定結果】</span>
              <span className="text-base font-bold text-emerald-400 font-mono">
                格付: {evalResult.riskGrade} 級 (スコア: {evalResult.creditScore}/1000)
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-xs">
              <div className="bg-slate-900 p-2 rounded">
                <span className="text-slate-400">倒産確率 (PD)</span>
                <div className="font-bold text-white font-mono">{formatPercent(evalResult.pd * 100, 2)}</div>
              </div>
              <div className="bg-slate-900 p-2 rounded">
                <span className="text-slate-400">保全後損失率 (LGD)</span>
                <div className="font-bold text-white font-mono">{formatPercent(evalResult.lgd * 100, 1)}</div>
              </div>
              <div className="bg-slate-900 p-2 rounded">
                <span className="text-slate-400">推奨与信限度枠</span>
                <div className="font-bold text-amber-400 font-mono">{formatExactJPY(evalResult.maxCreditLimitJPY)}</div>
              </div>
              <div className="bg-slate-900 p-2 rounded">
                <span className="text-slate-400">推奨スプレッド</span>
                <div className="font-bold text-cyan-400 font-mono">+{formatBps(evalResult.recommendedSpreadBps)}</div>
              </div>
            </div>

            <p className="text-xs text-slate-300 font-medium">{evalResult.internalRatingDescriptionJa}</p>
          </div>
        )}
      </div>
    </div>
  );
};
