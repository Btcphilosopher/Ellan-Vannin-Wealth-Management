/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { X, Plus, Trash2, CheckCircle2, AlertCircle, BookOpen } from 'lucide-react';
import { formatExactJPY } from '../../engines/japaneseFormatters';

interface NewTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPostSuccess: () => void;
}

interface TempLine {
  accountCode: string;
  accountNameJa: string;
  debitJPY: number;
  creditJPY: number;
  descriptionJa: string;
}

export const NewTransactionModal: React.FC<NewTransactionModalProps> = ({
  isOpen,
  onClose,
  onPostSuccess
}) => {
  const [transactionType, setTransactionType] = useState<string>('LOAN_DISBURSEMENT');
  const [lines, setLines] = useState<TempLine[]>([
    { accountCode: '1110', accountNameJa: '貸出金 (Commercial Loans)', debitJPY: 5000000000, creditJPY: 0, descriptionJa: '企業向け設備資金新規実行' },
    { accountCode: '2110', accountNameJa: '当座預金 (Current Deposits)', debitJPY: 0, creditJPY: 5000000000, descriptionJa: '借入人口座へ振替入金' }
  ]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const totalDebit = lines.reduce((sum, l) => sum + Number(l.debitJPY || 0), 0);
  const totalCredit = lines.reduce((sum, l) => sum + Number(l.creditJPY || 0), 0);
  const isBalanced = totalDebit === totalCredit && totalDebit > 0;

  const handleAddLine = () => {
    setLines([
      ...lines,
      { accountCode: '1120', accountNameJa: '日銀当座預金', debitJPY: 0, creditJPY: 0, descriptionJa: '' }
    ]);
  };

  const handleRemoveLine = (idx: number) => {
    setLines(lines.filter((_, i) => i !== idx));
  };

  const handleUpdateLine = (index: number, field: keyof TempLine, value: any) => {
    const updated = [...lines];
    updated[index] = { ...updated[index], [field]: value };
    setLines(updated);
  };

  const handleSubmit = async () => {
    if (!isBalanced) {
      setErrorMsg('借方合計と貸方合計が一致していません。');
      return;
    }

    try {
      const res = await fetch('/api/post-journal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          entityId: 'ent_bk_01',
          transactionType,
          lines,
          createdBy: 'USR-RM-OFFICER',
          sourceModule: 'CORE_BANKING_UI',
          correlationId: `txn-${Date.now()}`
        })
      });

      const data = await res.json();
      if (!data.success) {
        setErrorMsg(data.errorMessageJa || '仕訳の記帳に失敗しました。');
      } else {
        alert(`【記帳完了】仕訳伝票 ${data.entry.entryNumber} が元帳に確定起票されました。`);
        onPostSuccess();
        onClose();
      }
    } catch (e: any) {
      setErrorMsg(e.message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl max-w-3xl w-full p-6 shadow-2xl space-y-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <BookOpen className="w-5 h-5 text-sky-400" />
            <h2 className="text-lg font-bold text-white">新規複式仕訳伝票 起票 (Double-Entry Journal)</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="p-3 bg-red-950/80 border border-red-700 text-red-300 text-xs rounded-lg flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMsg}</span>
          </div>
        )}

        {/* Transaction Type */}
        <div className="text-xs">
          <label className="text-slate-400 block mb-1">取引種別</label>
          <select
            value={transactionType}
            onChange={e => setTransactionType(e.target.value)}
            className="w-full bg-slate-950 border border-slate-700 rounded p-2 text-white font-sans"
          >
            <option value="LOAN_DISBURSEMENT">法人融資新規実行 (Loan Disbursement)</option>
            <option value="SECURITIES_PURCHASE">有価証券買付・約定受渡 (Securities Purchase)</option>
            <option value="INTERBANK_SETTLEMENT">全銀/日銀ネット資金清算 (Interbank Settlement)</option>
            <option value="FEE_INCOME">信託報酬・手数料収益計上 (Fee & Commission)</option>
          </select>
        </div>

        {/* Lines Editor */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-300">【仕訳明細 (借方・貸方)】</span>
            <button
              onClick={handleAddLine}
              className="text-xs text-sky-400 hover:text-sky-300 flex items-center space-x-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>行を追加</span>
            </button>
          </div>

          <div className="space-y-2 max-h-60 overflow-y-auto">
            {lines.map((line, idx) => (
              <div key={idx} className="grid grid-cols-12 gap-2 bg-slate-950 p-2.5 rounded-lg border border-slate-800 items-center text-xs">
                <div className="col-span-2">
                  <input
                    type="text"
                    placeholder="勘定コード"
                    value={line.accountCode}
                    onChange={e => handleUpdateLine(idx, 'accountCode', e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-white font-mono text-xs"
                  />
                </div>
                <div className="col-span-3">
                  <input
                    type="text"
                    placeholder="勘定科目名"
                    value={line.accountNameJa}
                    onChange={e => handleUpdateLine(idx, 'accountNameJa', e.target.value)}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-white text-xs"
                  />
                </div>
                <div className="col-span-3">
                  <input
                    type="number"
                    placeholder="借方金額 (Debit)"
                    value={line.debitJPY || ''}
                    onChange={e => handleUpdateLine(idx, 'debitJPY', Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-emerald-400 font-mono text-xs"
                  />
                </div>
                <div className="col-span-3">
                  <input
                    type="number"
                    placeholder="貸方金額 (Credit)"
                    value={line.creditJPY || ''}
                    onChange={e => handleUpdateLine(idx, 'creditJPY', Number(e.target.value))}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-cyan-400 font-mono text-xs"
                  />
                </div>
                <div className="col-span-1 text-center">
                  <button
                    onClick={() => handleRemoveLine(idx)}
                    disabled={lines.length <= 2}
                    className="p-1 text-slate-500 hover:text-red-400 disabled:opacity-30"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Balancing Totals */}
        <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 flex items-center justify-between text-xs font-mono">
          <div>
            借方合計: <strong className="text-emerald-400">{formatExactJPY(totalDebit)}</strong>
          </div>
          <div>
            貸方合計: <strong className="text-cyan-400">{formatExactJPY(totalCredit)}</strong>
          </div>
          <div className={`font-bold ${isBalanced ? 'text-emerald-400' : 'text-rose-400'}`}>
            {isBalanced ? '✓ 借貸完全合致 (Balanced)' : `不一致: 差額 ${formatExactJPY(Math.abs(totalDebit - totalCredit))}`}
          </div>
        </div>

        <button
          onClick={handleSubmit}
          disabled={!isBalanced}
          className="w-full py-2.5 bg-gradient-to-r from-red-700 to-rose-700 hover:from-red-600 hover:to-rose-600 disabled:bg-slate-800 disabled:opacity-40 text-white font-bold rounded-lg text-xs shadow-lg transition-all cursor-pointer"
        >
          元帳へ起票・記帳を確定実行 (Post Entry)
        </button>
      </div>
    </div>
  );
};
