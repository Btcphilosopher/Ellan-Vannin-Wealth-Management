/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header, UserRole } from './components/Header';
import { Sidebar, ActiveWorkspace } from './components/Sidebar';
import { ExecutiveDashboard } from './components/views/ExecutiveDashboard';
import { CorporateBankingView } from './components/views/CorporateBankingView';
import { WealthManagementView } from './components/views/WealthManagementView';
import { GlobalMarketsView } from './components/views/GlobalMarketsView';
import { TreasuryAlmView } from './components/views/TreasuryAlmView';
import { RiskOsView } from './components/views/RiskOsView';
import { PaymentsSettlementView } from './components/views/PaymentsSettlementView';
import { GeneralLedgerView } from './components/views/GeneralLedgerView';
import { AmlComplianceView } from './components/views/AmlComplianceView';
import { FinancialCopilotView } from './components/views/FinancialCopilotView';
import { ReportsAndAuditView } from './components/views/ReportsAndAuditView';
import { DictionaryAndGroupView } from './components/views/DictionaryAndGroupView';

import { NewLoanAssessmentModal } from './components/modals/NewLoanAssessmentModal';
import { NewTransactionModal } from './components/modals/NewTransactionModal';
import { ReportPreviewModal } from './components/modals/ReportPreviewModal';

import {
  Customer,
  LoanFacility,
  AlmBucketGap,
  TreasuryPosition,
  JournalEntry,
  ReconciliationCase,
  AMLAlert,
  AuditLogEntry
} from './types/financial';
import { FinancialTerm } from './types/dictionary';
import { GeneratedFinancialReport } from './engines/japaneseReportEngine';

import {
  SYNTHETIC_CUSTOMERS,
  SYNTHETIC_LOANS,
  SYNTHETIC_ALM_BUCKETS,
  SYNTHETIC_TREASURY_POSITION,
  SYNTHETIC_JOURNALS,
  SYNTHETIC_RECONCILIATION_CASES,
  SYNTHETIC_AML_ALERTS,
  SYNTHETIC_AUDIT_LOGS
} from './data/syntheticDatabase';

export default function App() {
  const [currentRole, setCurrentRole] = useState<UserRole>('EXECUTIVE');
  const [activeWorkspace, setActiveWorkspace] = useState<ActiveWorkspace>('executive');

  // In-memory synced state
  const [customers, setCustomers] = useState<Customer[]>(SYNTHETIC_CUSTOMERS);
  const [loans, setLoans] = useState<LoanFacility[]>(SYNTHETIC_LOANS);
  const [almBuckets, setAlmBuckets] = useState<AlmBucketGap[]>(SYNTHETIC_ALM_BUCKETS);
  const [treasury, setTreasury] = useState<TreasuryPosition>(SYNTHETIC_TREASURY_POSITION);
  const [journals, setJournals] = useState<JournalEntry[]>(SYNTHETIC_JOURNALS);
  const [reconciliations, setReconciliations] = useState<ReconciliationCase[]>(SYNTHETIC_RECONCILIATION_CASES);
  const [amlAlerts, setAmlAlerts] = useState<AMLAlert[]>(SYNTHETIC_AML_ALERTS);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(SYNTHETIC_AUDIT_LOGS);

  // Modals state
  const [isAssessmentModalOpen, setIsAssessmentModalOpen] = useState(false);
  const [assessmentCustomer, setAssessmentCustomer] = useState<Customer | undefined>(undefined);
  const [isTransactionModalOpen, setIsTransactionModalOpen] = useState(false);
  const [previewReport, setPreviewReport] = useState<GeneratedFinancialReport | null>(null);
  const [copilotInitialQuery, setCopilotInitialQuery] = useState<string>('');

  // Auto-switch workspace when role changes if appropriate
  const handleRoleChange = (newRole: UserRole) => {
    setCurrentRole(newRole);
    if (newRole === 'CORPORATE_RM') setActiveWorkspace('corporate');
    else if (newRole === 'WEALTH_PB') setActiveWorkspace('wealth');
    else if (newRole === 'TRADER') setActiveWorkspace('markets');
    else if (newRole === 'TREASURY_ALM') setActiveWorkspace('treasury');
    else if (newRole === 'RISK_OFFICER') setActiveWorkspace('risk');
    else if (newRole === 'AML_COMPLIANCE') setActiveWorkspace('aml');
    else if (newRole === 'OPERATIONS') setActiveWorkspace('ledger');
    else setActiveWorkspace('executive');
  };

  const handleOpenCopilot = (query?: string) => {
    if (query) {
      setCopilotInitialQuery(query);
    }
    setActiveWorkspace('copilot');
  };

  const handleOpenAssessment = (customer?: Customer) => {
    setAssessmentCustomer(customer || customers[0]);
    setIsAssessmentModalOpen(true);
  };

  const handleResolveAmlAlert = async (alertId: string, disposition: any, notesJa: string) => {
    try {
      const res = await fetch('/api/aml/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          alertId,
          disposition,
          officerNotesJa: notesJa
        })
      });
      const data = await res.json();
      if (data.success && data.updatedAlert) {
        setAmlAlerts(prev => prev.map(a => a.id === alertId ? data.updatedAlert : a));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const reloadJournals = async () => {
    try {
      const res = await fetch('/api/journals');
      const data = await res.json();
      if (data.journals) {
        setJournals(data.journals);
      }
      const audRes = await fetch('/api/audit-logs');
      const audData = await audRes.json();
      if (audData.logs) {
        setAuditLogs(audData.logs);
      }
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="min-h-screen bg-[#060A13] text-slate-100 flex flex-col font-sans antialiased selection:bg-red-900 selection:text-white">
      {/* Top Header */}
      <Header
        currentRole={currentRole}
        onSelectRole={handleRoleChange}
        onOpenCopilot={handleOpenCopilot}
        onOpenNewTransaction={() => setIsTransactionModalOpen(true)}
        onOpenNewAssessment={() => handleOpenAssessment()}
        onSelectTerm={(term: FinancialTerm) => {
          setActiveWorkspace('dictionary');
        }}
      />

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Dock */}
        <Sidebar
          activeWorkspace={activeWorkspace}
          onSelectWorkspace={setActiveWorkspace}
          pendingAmlCount={amlAlerts.filter(a => a.humanDisposition === 'PENDING_REVIEW').length}
          riskBreachCount={0}
          reconBreakCount={reconciliations.filter(r => r.reconciliationStatus === 'UNRECONCILED_BREAK').length}
        />

        {/* Content Viewport */}
        <main className="flex-1 overflow-y-auto p-5 md:p-7 max-w-7xl mx-auto w-full">
          {activeWorkspace === 'executive' && (
            <ExecutiveDashboard
              onOpenCopilot={handleOpenCopilot}
              onNavigate={setActiveWorkspace}
            />
          )}

          {activeWorkspace === 'corporate' && (
            <CorporateBankingView
              customers={customers}
              loans={loans}
              onOpenAssessmentModal={handleOpenAssessment}
              onOpenReportModal={setPreviewReport}
              onOpenCopilot={handleOpenCopilot}
            />
          )}

          {activeWorkspace === 'wealth' && (
            <WealthManagementView
              customers={customers}
              onOpenReportModal={setPreviewReport}
              onOpenCopilot={handleOpenCopilot}
            />
          )}

          {activeWorkspace === 'markets' && (
            <GlobalMarketsView onOpenCopilot={handleOpenCopilot} />
          )}

          {activeWorkspace === 'treasury' && (
            <TreasuryAlmView
              buckets={almBuckets}
              treasury={treasury}
              onOpenCopilot={handleOpenCopilot}
            />
          )}

          {activeWorkspace === 'risk' && (
            <RiskOsView onOpenCopilot={handleOpenCopilot} />
          )}

          {activeWorkspace === 'payments' && (
            <PaymentsSettlementView onOpenCopilot={handleOpenCopilot} />
          )}

          {activeWorkspace === 'ledger' && (
            <GeneralLedgerView
              journals={journals}
              reconciliations={reconciliations}
              onOpenNewTransactionModal={() => setIsTransactionModalOpen(true)}
              onOpenCopilot={handleOpenCopilot}
            />
          )}

          {activeWorkspace === 'aml' && (
            <AmlComplianceView
              alerts={amlAlerts}
              onResolveAlert={handleResolveAmlAlert}
              onOpenCopilot={handleOpenCopilot}
            />
          )}

          {activeWorkspace === 'copilot' && (
            <FinancialCopilotView
              currentRole={currentRole}
              initialQuery={copilotInitialQuery}
            />
          )}

          {activeWorkspace === 'reports' && (
            <ReportsAndAuditView
              customers={customers}
              auditLogs={auditLogs}
              onOpenReportModal={setPreviewReport}
            />
          )}

          {activeWorkspace === 'dictionary' && (
            <DictionaryAndGroupView
              onOpenCopilot={handleOpenCopilot}
            />
          )}
        </main>
      </div>

      {/* Modals */}
      <NewLoanAssessmentModal
        isOpen={isAssessmentModalOpen}
        onClose={() => setIsAssessmentModalOpen(false)}
        customer={assessmentCustomer}
        onAssessmentCompleted={res => {
          reloadJournals();
        }}
      />

      <NewTransactionModal
        isOpen={isTransactionModalOpen}
        onClose={() => setIsTransactionModalOpen(false)}
        onPostSuccess={reloadJournals}
      />

      <ReportPreviewModal
        report={previewReport}
        onClose={() => setPreviewReport(null)}
      />
    </div>
  );
}
