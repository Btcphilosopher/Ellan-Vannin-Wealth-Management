/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { RiskExposureMetric, RiskCategory } from '../types/financial';

/**
 * リスク管理OS エンジン (Risk Management OS Engine)
 * VaR (Value at Risk 99% 1日), Expected Shortfall, CS01, DV01, 限度枠消化率の判定
 */
export function evaluateRiskStatus(
  exposure: RiskExposureMetric
): { status: 'NORMAL' | 'WARNING' | 'BREACH'; alertMessageJa?: string } {
  const utilization = (exposure.exposureAmountJPY / exposure.limitAmountJPY) * 100;

  if (utilization >= 100) {
    return {
      status: 'BREACH',
      alertMessageJa: `【限度額超過 (BREACH)】${exposure.nameJa} が上限枠を超過しています (消化率: ${utilization.toFixed(1)}%)。リスク統括役員 (CRO) への即時エスカレーションとポジション削減が必要です。`
    };
  } else if (utilization >= 85) {
    return {
      status: 'WARNING',
      alertMessageJa: `【警戒水準 (WARNING)】${exposure.nameJa} の枠消化率が ${utilization.toFixed(1)}% に達しました。早期是正・ヘッジ検討が推奨されます。`
    };
  }

  return { status: 'NORMAL' };
}

export function calculateParametricVaR(
  positionValueJPY: number,
  dailyVolatilityPct: number = 1.25, // 1日の価格変動率標準偏差 (%)
  confidenceLevel: 0.95 | 0.99 = 0.99,
  holdingPeriodDays: number = 1
): { varJPY: number; expectedShortfallJPY: number } {
  // 99%信頼水準のZ値 = 2.326, 95% = 1.645
  const z = confidenceLevel === 0.99 ? 2.3263 : 1.6449;
  const esMultiplier = confidenceLevel === 0.99 ? 2.665 : 2.063; // 正規分布下でのExpected Shortfall係数

  const dailyVol = dailyVolatilityPct / 100;
  const timeFactor = Math.sqrt(holdingPeriodDays);

  const varJPY = Math.round(positionValueJPY * dailyVol * z * timeFactor);
  const expectedShortfallJPY = Math.round(positionValueJPY * dailyVol * esMultiplier * timeFactor);

  return { varJPY, expectedShortfallJPY };
}
