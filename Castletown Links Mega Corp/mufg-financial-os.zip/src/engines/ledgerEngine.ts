/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { JournalEntry, JournalLine } from '../types/financial';

/**
 * 複式簿記・総勘定元帳エンジン (Double-Entry General Ledger Engine)
 * 金融計算における浮動小数点数（float）誤差を排除し、厳格な借方・貸方一致性（Debit == Credit）を検証
 */
export function validateAndPostJournal(
  entityId: string,
  transactionType: string,
  lines: Omit<JournalLine, 'id'>[],
  createdBy: string,
  sourceModule: string,
  correlationId: string
): { success: boolean; entry?: JournalEntry; errorMessageJa?: string } {
  let totalDebit = 0;
  let totalCredit = 0;

  const enrichedLines: JournalLine[] = lines.map((line, idx) => {
    // 整数単位 (Integer JPY) で厳密計算
    const debit = Math.round(line.debitJPY || 0);
    const credit = Math.round(line.creditJPY || 0);
    totalDebit += debit;
    totalCredit += credit;

    return {
      id: `jl_${Date.now()}_${idx}`,
      accountCode: line.accountCode,
      accountNameJa: line.accountNameJa,
      debitJPY: debit,
      creditJPY: credit,
      currency: line.currency || 'JPY',
      originalAmount: line.originalAmount || (debit > 0 ? debit : credit),
      descriptionJa: line.descriptionJa
    };
  });

  const isBalanced = totalDebit === totalCredit;

  if (!isBalanced) {
    const diff = Math.abs(totalDebit - totalCredit);
    return {
      success: false,
      errorMessageJa: `【仕訳不一致エラー】借方合計 (¥${totalDebit.toLocaleString()}) と貸方合計 (¥${totalCredit.toLocaleString()}) に ¥${diff.toLocaleString()} の不一致があります。`
    };
  }

  const entryNumber = `GL-${new Date().getFullYear()}-${String(new Date().getMonth() + 1).padStart(2, '0')}${String(new Date().getDate()).padStart(2, '0')}-${String(Math.floor(Math.random() * 90000) + 10000)}`;

  const entry: JournalEntry = {
    id: `jn_${Date.now()}`,
    entryNumber,
    entityId,
    transactionType,
    postingDate: new Date().toISOString().split('T')[0],
    valueDate: new Date().toISOString().split('T')[0],
    lines: enrichedLines,
    totalDebitJPY: totalDebit,
    totalCreditJPY: totalCredit,
    isBalanced: true,
    status: 'POSTED',
    createdBy,
    sourceModule,
    correlationId
  };

  return { success: true, entry };
}
