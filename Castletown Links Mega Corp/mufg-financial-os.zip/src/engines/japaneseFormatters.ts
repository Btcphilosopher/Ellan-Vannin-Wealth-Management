/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * 日本語金融数値フォーマッター (Japanese Financial Number & Currency Formatter)
 * 計算（正確な整数/固定小数点）と表示（兆・億円・万円表記）を厳格に分離
 */

/**
 * 金額を日本円表記（例: ¥1,500,000 または 大規模単位: 412.5兆円、1,250億円）に変換
 */
export function formatJPY(amount: number, options?: { fullNumeric?: boolean; showPlus?: boolean }): string {
  if (isNaN(amount) || amount === null || amount === undefined) return '¥0';

  const isNegative = amount < 0;
  const absAmount = Math.abs(amount);
  const sign = isNegative ? '-' : (options?.showPlus && amount > 0 ? '+' : '');

  if (options?.fullNumeric) {
    return `${sign}¥${Math.round(absAmount).toLocaleString('ja-JP')}`;
  }

  // 大規模金額 (1兆円以上)
  if (absAmount >= 1_000_000_000_000) {
    const cho = absAmount / 1_000_000_000_000;
    const rounded = Number(cho.toFixed(2));
    return `${sign}¥${rounded.toLocaleString('ja-JP')}兆円`;
  }

  // 大規模金額 (1億円以上)
  if (absAmount >= 100_000_000) {
    const oku = absAmount / 100_000_000;
    const rounded = Number(oku.toFixed(1));
    return `${sign}¥${rounded.toLocaleString('ja-JP')}億円`;
  }

  // 1万円以上
  if (absAmount >= 10_000) {
    const man = absAmount / 10_000;
    const rounded = Number(man.toFixed(1));
    return `${sign}¥${rounded.toLocaleString('ja-JP')}万円`;
  }

  return `${sign}¥${Math.round(absAmount).toLocaleString('ja-JP')}`;
}

export function formatExactJPY(amount: number): string {
  return `¥${Math.round(amount || 0).toLocaleString('ja-JP')}`;
}

export function formatPercent(value: number, decimals: number = 2, showPlus: boolean = false): string {
  if (isNaN(value) || value === null || value === undefined) return '0.00%';
  const sign = showPlus && value > 0 ? '+' : '';
  return `${sign}${value.toFixed(decimals)}%`;
}

export function formatBps(bps: number, showPlus: boolean = false): string {
  const sign = showPlus && bps > 0 ? '+' : '';
  return `${sign}${Math.round(bps)} bps`;
}

export function formatDateJa(dateStr: string): string {
  if (!dateStr) return '-';
  try {
    const d = new Date(dateStr);
    return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日`;
  } catch {
    return dateStr;
  }
}

export function formatDateTimeJa(dateStr: string): string {
  if (!dateStr) return '-';
  try {
    const d = new Date(dateStr);
    const time = `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
    return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日 ${time}`;
  } catch {
    return dateStr;
  }
}
