/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CreditAssessmentInput, CreditAssessmentResult } from '../types/financial';

/**
 * 信用審査・格付エンジン (Enterprise Credit Assessment Engine)
 * 金融検査マニュアル資産査定要領および内部格付手法 (IRB Approach) に基づく定量スコアリングモデル
 */
export function evaluateCreditRisk(input: CreditAssessmentInput): CreditAssessmentResult {
  const {
    annualRevenueJPY,
    operatingIncomeJPY,
    ebitdaJPY,
    netIncomeJPY,
    totalAssetsJPY,
    netAssetsJPY,
    interestBearingDebtJPY,
    cashAndEquivalentsJPY,
    freeCashFlowJPY,
    collateralValueJPY,
    industryRiskTier,
    existingDelinquency
  } = input;

  // 1. 財務指標の厳密算出
  const equityRatioPct = totalAssetsJPY > 0 ? (netAssetsJPY / totalAssetsJPY) * 100 : 0;
  const netDebtJPY = Math.max(0, interestBearingDebtJPY - cashAndEquivalentsJPY);
  const debtToEbitda = ebitdaJPY > 0 ? Number((interestBearingDebtJPY / ebitdaJPY).toFixed(2)) : 99.9;
  
  // 推定支払利息 (年率1.2%と仮定)
  const estimatedInterestExpenseJPY = interestBearingDebtJPY * 0.012;
  const icr = estimatedInterestExpenseJPY > 0 ? Number((ebitdaJPY / estimatedInterestExpenseJPY).toFixed(2)) : 99.9;
  
  // 元利金返済カバー率 (DSCR: 年間元本返済負担を年商の5%と仮定)
  const annualDebtServiceJPY = estimatedInterestExpenseJPY + (interestBearingDebtJPY * 0.1);
  const dscr = annualDebtServiceJPY > 0 ? Number(((operatingIncomeJPY + freeCashFlowJPY * 0.5) / annualDebtServiceJPY).toFixed(2)) : 1.0;
  
  // LTV (担保充足率)
  const ltvPct = collateralValueJPY > 0 ? Number(((interestBearingDebtJPY / collateralValueJPY) * 100).toFixed(1)) : 100.0;

  // 2. 定量スコア計算 (0〜1000点)
  let score = 500;

  // 自己資本比率スコア (0〜200点)
  if (equityRatioPct >= 50) score += 200;
  else if (equityRatioPct >= 30) score += 140;
  else if (equityRatioPct >= 15) score += 80;
  else if (equityRatioPct > 0) score += 20;
  else score -= 150; // 債務超過

  // 収益性・EBITDAスコア (0〜250点)
  const operatingMarginPct = annualRevenueJPY > 0 ? (operatingIncomeJPY / annualRevenueJPY) * 100 : 0;
  if (operatingMarginPct >= 12) score += 250;
  else if (operatingMarginPct >= 6) score += 180;
  else if (operatingMarginPct >= 2) score += 100;
  else if (operatingMarginPct >= 0) score += 30;
  else score -= 120; // 営業赤字

  // 返済能力・レバレッジスコア (0〜250点)
  if (debtToEbitda <= 2.0 && debtToEbitda > 0) score += 250;
  else if (debtToEbitda <= 4.0) score += 180;
  else if (debtToEbitda <= 7.0) score += 80;
  else score -= 100;

  // 業種リスク補正
  if (industryRiskTier === 'LOW') score += 50;
  else if (industryRiskTier === 'HIGH') score -= 50;

  // 延滞・事故歴のペナルティ
  if (existingDelinquency) score -= 350;

  score = Math.max(50, Math.min(980, Math.round(score)));

  // 3. 倒産確率 (PD) および格付 (Risk Grade 1〜10) のマッピング
  let riskGrade = '5';
  let pd = 0.015; // 1.5%
  let ratingDesc = '正常先 (BBB級)';
  let maxLimitJPY = Math.round(annualRevenueJPY * 0.25);
  let recommendedSpreadBps = 65;
  let authority: 'BRANCH_MANAGER' | 'CREDIT_COMMITTEE' | 'BOARD_OF_DIRECTORS' = 'BRANCH_MANAGER';

  if (score >= 880) {
    riskGrade = '1';
    pd = 0.0010; // 0.10% (AAA)
    ratingDesc = '極めて優良・超低リスク (AAA / 債務履行能力は最高水準)';
    maxLimitJPY = Math.round(annualRevenueJPY * 0.40);
    recommendedSpreadBps = 25;
    authority = 'BRANCH_MANAGER';
  } else if (score >= 780) {
    riskGrade = '2';
    pd = 0.0035; // 0.35% (AA)
    ratingDesc = '優良先 (AA / 高い信用力と強固な財務体質)';
    maxLimitJPY = Math.round(annualRevenueJPY * 0.35);
    recommendedSpreadBps = 40;
    authority = 'BRANCH_MANAGER';
  } else if (score >= 660) {
    riskGrade = '3';
    pd = 0.0080; // 0.80% (A)
    ratingDesc = '良好先 (A / 安定した事業基盤と財務余裕)';
    maxLimitJPY = Math.round(annualRevenueJPY * 0.30);
    recommendedSpreadBps = 55;
    authority = 'BRANCH_MANAGER';
  } else if (score >= 520) {
    riskGrade = '4';
    pd = 0.0180; // 1.80% (BBB)
    ratingDesc = '正常先 (BBB / 標準的な財務健全性)';
    maxLimitJPY = Math.round(annualRevenueJPY * 0.20);
    recommendedSpreadBps = 80;
    authority = 'CREDIT_COMMITTEE';
  } else if (score >= 400) {
    riskGrade = '5';
    pd = 0.0380; // 3.80% (BB)
    ratingDesc = '要注意先 (BB / 景気後退局面における感応度注視)';
    maxLimitJPY = Math.round(annualRevenueJPY * 0.12);
    recommendedSpreadBps = 140;
    authority = 'CREDIT_COMMITTEE';
  } else if (score >= 280) {
    riskGrade = '6';
    pd = 0.0850; // 8.50% (B)
    ratingDesc = '要管理先 (B / 財務改善計画及び担保保全の強化必須)';
    maxLimitJPY = Math.round(annualRevenueJPY * 0.05);
    recommendedSpreadBps = 260;
    authority = 'BOARD_OF_DIRECTORS';
  } else {
    riskGrade = '7+';
    pd = 0.2200; // 22.0% (破綻懸念先)
    ratingDesc = '破綻懸念先・実質破綻先 (原則新規融資禁止)';
    maxLimitJPY = 0;
    recommendedSpreadBps = 500;
    authority = 'BOARD_OF_DIRECTORS';
  }

  // 4. LGD (保全後損失率) 及び Expected Loss (予想損失額)
  // 担保価値が債務を上回る場合はLGDを低減
  const collateralCoverage = interestBearingDebtJPY > 0 ? Math.min(1.0, collateralValueJPY / interestBearingDebtJPY) : 0;
  const lgd = Number((0.45 * (1 - collateralCoverage * 0.65)).toFixed(3)); // 15%〜45%
  const ead = interestBearingDebtJPY + (maxLimitJPY * 0.5); // 現存債務 + 枠未引出分の引出想定
  const expectedLossJPY = Math.round(ead * pd * lgd);

  // 5. コベナンツ (財務制限条項) の自動レコメンデーション
  const covenantRecommendations: string[] = [
    `有利子負債 / EBITDA倍率: ${Math.max(3.0, debtToEbitda + 0.8).toFixed(1)}倍以内を毎期末維持`,
    `純資産維持条項: 直前期末純資産の75%以上および${Math.round(netAssetsJPY * 0.8 / 100_000_000)}億円以上を維持`,
    `利益維持条項: 2期連続の経常赤字または営業赤字を回避`
  ];

  if (ltvPct > 70) {
    covenantRecommendations.push('担保価値再評価 (年1回) および追加担保差入条項');
  }

  return {
    assessmentId: `CR-EVAL-${Date.now()}`,
    customerId: input.customerId,
    modelCode: input.modelCode || 'MUFG-IRB-CORP-V4.2',
    modelVersion: '2026.3-PROD',
    creditScore: score,
    pd,
    lgd,
    ead,
    expectedLossJPY,
    riskGrade,
    internalRatingDescriptionJa: ratingDesc,
    dscr,
    debtToEbitda,
    ltvPct,
    icr,
    maxCreditLimitJPY: maxLimitJPY,
    recommendedSpreadBps,
    approvalAuthorityLevel: authority,
    covenantRecommendations,
    evaluatedAt: new Date().toISOString()
  };
}
