/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Customer, Account, LoanFacility, CreditAssessmentResult, AMLAlert } from '../types/financial';
import { formatExactJPY, formatDateJa, formatPercent, formatBps } from './japaneseFormatters';

export interface GeneratedFinancialReport {
  id: string;
  reportType: 'BALANCE_CERT' | 'LOAN_SCHEDULE' | 'CREDIT_MEMO' | 'ALM_GOVERNANCE' | 'AML_DISPOSITION';
  titleJa: string;
  generatedDateJa: string;
  issuingEntityJa: string;
  documentNumber: string;
  contentHtml: string;
  summaryTextJa: string;
}

export function generateBalanceCertificate(customer: Customer, accounts: Account[]): GeneratedFinancialReport {
  const docNo = `CERT-${new Date().getFullYear()}-${Math.floor(Math.random() * 90000 + 10000)}`;
  const totalJPY = accounts.reduce((sum, a) => sum + (a.currency === 'JPY' ? a.balance : a.balance * 152.43), 0);

  const accountRows = accounts.map(a => `
    <tr class="border-b border-slate-700">
      <td class="py-2.5 px-3 font-mono">${a.accountNumber}</td>
      <td class="py-2.5 px-3">${a.branchName}</td>
      <td class="py-2.5 px-3">${a.accountType}</td>
      <td class="py-2.5 px-3 text-right font-mono">${a.currency}</td>
      <td class="py-2.5 px-3 text-right font-mono font-semibold">${formatExactJPY(a.balance)}</td>
    </tr>
  `).join('');

  const contentHtml = `
    <div class="p-6 bg-slate-900 text-slate-100 rounded-lg border border-slate-700 space-y-6">
      <div class="flex justify-between items-start border-b border-slate-700 pb-4">
        <div>
          <span class="text-xs font-mono text-red-400 font-bold tracking-wider">MUFG FINANCIAL OS // 公式帳票</span>
          <h2 class="text-2xl font-bold text-white mt-1">残高証明書 (Balance Certificate)</h2>
          <p class="text-xs text-slate-400 mt-0.5">発効番号: ${docNo} / DEMO SYNTHETIC DATA</p>
        </div>
        <div class="text-right text-xs text-slate-400 space-y-0.5">
          <p class="font-bold text-slate-200">株式会社三菱UFJ銀行</p>
          <p>本店営業部 業務統括室</p>
          <p>発行基準日: ${formatDateJa(new Date().toISOString())}</p>
        </div>
      </div>

      <div class="bg-slate-800/80 p-4 rounded border border-slate-700">
        <p class="text-xs text-slate-400 font-medium">顧客名 (お届出先)</p>
        <p class="text-lg font-bold text-white mt-0.5">${customer.nameJa}</p>
        <p class="text-xs text-slate-400 mt-1">${customer.addressJa} | 顧客コード: ${customer.customerCode}</p>
      </div>

      <div>
        <p class="text-sm font-semibold text-slate-300 mb-2">【預金・信託受託勘定残高 明細】</p>
        <div class="overflow-x-auto">
          <table class="w-full text-xs text-left">
            <thead class="bg-slate-800 text-slate-400 border-b border-slate-700 font-medium">
              <tr>
                <th class="py-2 px-3">口座番号</th>
                <th class="py-2 px-3">取扱店</th>
                <th class="py-2 px-3">預金種目</th>
                <th class="py-2 px-3 text-right">通貨</th>
                <th class="py-2 px-3 text-right">基準日残高</th>
              </tr>
            </thead>
            <tbody>
              ${accountRows}
            </tbody>
          </table>
        </div>
      </div>

      <div class="flex justify-between items-center bg-slate-800 p-4 rounded border border-slate-700">
        <span class="text-sm font-bold text-slate-300">円換算 総合残高合計</span>
        <span class="text-xl font-bold text-emerald-400 font-mono">${formatExactJPY(totalJPY)}</span>
      </div>

      <div class="text-[11px] text-slate-500 border-t border-slate-800 pt-3">
        ※本証明書は三菱UFJフィナンシャル・グループ統合金融OSにより自動発行された正規電子証明書です (合成データデモ環境)。
      </div>
    </div>
  `;

  return {
    id: `rep_${Date.now()}`,
    reportType: 'BALANCE_CERT',
    titleJa: `残高証明書 - ${customer.nameJa}`,
    generatedDateJa: formatDateJa(new Date().toISOString()),
    issuingEntityJa: '株式会社三菱UFJ銀行 本店営業部',
    documentNumber: docNo,
    contentHtml,
    summaryTextJa: `${customer.nameJa} 様の預金勘定合計 ${formatExactJPY(totalJPY)} の残高証明を発行しました。`
  };
}

export function generateCreditAssessmentMemo(customer: Customer, evalResult: CreditAssessmentResult): GeneratedFinancialReport {
  const docNo = `CR-MEMO-${new Date().getFullYear()}-${Math.floor(Math.random() * 90000 + 10000)}`;

  const contentHtml = `
    <div class="p-6 bg-slate-900 text-slate-100 rounded-lg border border-slate-700 space-y-6">
      <div class="flex justify-between items-start border-b border-slate-700 pb-4">
        <div>
          <span class="text-xs font-mono text-red-400 font-bold tracking-wider">MUFG FINANCIAL OS // 融資審査決裁書</span>
          <h2 class="text-2xl font-bold text-white mt-1">法人信用格付・与信審査稟議調書</h2>
          <p class="text-xs text-slate-400 mt-0.5">審査番号: ${evalResult.assessmentId} / 決裁番号: ${docNo}</p>
        </div>
        <div class="text-right text-xs text-slate-400 space-y-0.5">
          <p class="font-bold text-slate-200">三菱UFJフィナンシャル・グループ</p>
          <p>審査部・法人営業部 合議</p>
          <p>審査日時: ${formatDateJa(evalResult.evaluatedAt)}</p>
        </div>
      </div>

      <div class="grid grid-cols-2 gap-4">
        <div class="bg-slate-800/80 p-3.5 rounded border border-slate-700">
          <p class="text-xs text-slate-400 font-medium">対象先企業</p>
          <p class="text-base font-bold text-white mt-0.5">${customer.nameJa}</p>
          <p class="text-xs text-slate-400 mt-1">業種: ${customer.industryCategory || '一般製造業'}</p>
        </div>
        <div class="bg-slate-800/80 p-3.5 rounded border border-slate-700">
          <p class="text-xs text-slate-400 font-medium">判定格付・スコア</p>
          <p class="text-base font-bold text-emerald-400 mt-0.5">格付 ${evalResult.riskGrade} 級 (スコア: ${evalResult.creditScore}/1000)</p>
          <p class="text-xs text-slate-400 mt-1">${evalResult.internalRatingDescriptionJa}</p>
        </div>
      </div>

      <div class="grid grid-cols-4 gap-3 bg-slate-800/60 p-3.5 rounded border border-slate-700 text-center text-xs">
        <div>
          <p class="text-slate-400">倒産確率 (PD)</p>
          <p class="text-sm font-bold text-white font-mono mt-0.5">${formatPercent(evalResult.pd * 100, 2)}</p>
        </div>
        <div>
          <p class="text-slate-400">保全後損失率 (LGD)</p>
          <p class="text-sm font-bold text-white font-mono mt-0.5">${formatPercent(evalResult.lgd * 100, 1)}</p>
        </div>
        <div>
          <p class="text-slate-400">推奨与信限度枠</p>
          <p class="text-sm font-bold text-amber-400 font-mono mt-0.5">${formatExactJPY(evalResult.maxCreditLimitJPY)}</p>
        </div>
        <div>
          <p class="text-slate-400">推奨スプレッド</p>
          <p class="text-sm font-bold text-cyan-400 font-mono mt-0.5">${formatBps(evalResult.recommendedSpreadBps)}</p>
        </div>
      </div>

      <div class="space-y-2">
        <p class="text-xs font-semibold text-slate-300">【推奨付帯コベナンツ (財務制限条項)】</p>
        <ul class="list-disc list-inside text-xs text-slate-400 space-y-1 bg-slate-800 p-3 rounded border border-slate-700">
          ${evalResult.covenantRecommendations.map(c => `<li>${c}</li>`).join('')}
        </ul>
      </div>

      <div class="flex justify-between items-center text-xs text-slate-400 border-t border-slate-800 pt-3">
        <span>決裁権限レベル: <strong class="text-slate-200">${evalResult.approvalAuthorityLevel}</strong></span>
        <span>適用モデル: <strong class="text-slate-200">${evalResult.modelCode} (v${evalResult.modelVersion})</strong></span>
      </div>
    </div>
  `;

  return {
    id: `rep_cr_${Date.now()}`,
    reportType: 'CREDIT_MEMO',
    titleJa: `信用格付審査調書 - ${customer.nameJa}`,
    generatedDateJa: formatDateJa(evalResult.evaluatedAt),
    issuingEntityJa: '三菱UFJ銀行 審査統括部',
    documentNumber: docNo,
    contentHtml,
    summaryTextJa: `${customer.nameJa} に対する信用格付 ${evalResult.riskGrade} 級、与信限度枠 ${formatExactJPY(evalResult.maxCreditLimitJPY)} の審査稟議書を生成しました。`
  };
}
