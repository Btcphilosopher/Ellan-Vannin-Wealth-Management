/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface JapaneseHoliday {
  date: string; // YYYY-MM-DD
  nameJa: string;
}

export class JapaneseCalendarProvider {
  // 動的祝日テーブル
  private holidays: Map<string, string> = new Map([
    ['2026-01-01', '元日'],
    ['2026-01-12', '成人の日'],
    ['2026-02-11', '建国記念の日'],
    ['2026-02-23', '天皇誕生日'],
    ['2026-03-20', '春分の日'],
    ['2026-04-29', '昭和の日'],
    ['2026-05-03', '憲法記念日'],
    ['2026-05-04', 'みどりの日'],
    ['2026-05-05', 'こどもの日'],
    ['2026-05-06', '振替休日'],
    ['2026-07-20', '海の日'],
    ['2026-08-11', '山の日'],
    ['2026-09-21', '敬老の日'],
    ['2026-09-22', '国民の休日'],
    ['2026-09-23', '秋分の日'],
    ['2026-10-12', 'スポーツの日'],
    ['2026-11-03', '文化の日'],
    ['2026-11-23', '勤労感謝の日'],
    ['2026-12-31', '銀行休業日 (大晦日)']
  ]);

  public isBusinessDay(date: Date): boolean {
    const day = date.getDay();
    if (day === 0 || day === 6) return false; // 土日
    const dateKey = date.toISOString().split('T')[0];
    return !this.holidays.has(dateKey);
  }

  public getHolidayName(date: Date): string | undefined {
    const dateKey = date.toISOString().split('T')[0];
    return this.holidays.get(dateKey);
  }

  public getNextBusinessDay(startDate: Date, offsetDays: number = 1): Date {
    const current = new Date(startDate);
    let added = 0;
    while (added < offsetDays) {
      current.setDate(current.getDate() + 1);
      if (this.isBusinessDay(current)) {
        added++;
      }
    }
    return current;
  }

  public getSettlementDate(tradeDate: Date, settlementCycle: 'T+1' | 'T+2' = 'T+1'): Date {
    const offset = settlementCycle === 'T+1' ? 1 : 2;
    return this.getNextBusinessDay(tradeDate, offset);
  }

  public isMonthEnd(date: Date): boolean {
    const nextDay = new Date(date);
    nextDay.setDate(date.getDate() + 1);
    return nextDay.getMonth() !== date.getMonth();
  }

  public isFiscalYearEnd(date: Date): boolean {
    // 日本の金融機関の会計年度末: 3月31日
    return date.getMonth() === 2 && date.getDate() === 31;
  }
}

export const calendarProvider = new JapaneseCalendarProvider();
