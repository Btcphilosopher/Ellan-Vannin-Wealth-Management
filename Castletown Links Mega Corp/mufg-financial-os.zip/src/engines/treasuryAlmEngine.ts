/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { AlmBucketGap, TreasuryPosition } from '../types/financial';

/**
 * トレジャリー & ALM エンジン (Treasury & Asset Liability Management Engine)
 * 金利感応度、デュレーション・ギャップ、流動性バッファー、ストレステスト耐性を計算
 */
export function calculateAlmAggregates(buckets: AlmBucketGap[]) {
  let totalAssetsJPY = 0;
  let totalLiabilitiesJPY = 0;
  let totalPv01JPY = 0;
  let cumulativeGapJPY = 0;

  const enrichedBuckets = buckets.map(b => {
    totalAssetsJPY += b.assetAmountJPY;
    totalLiabilitiesJPY += b.liabilityAmountJPY;
    totalPv01JPY += b.pv01JPY;
    cumulativeGapJPY += (b.assetAmountJPY - b.liabilityAmountJPY);

    return {
      ...b,
      netGapJPY: b.assetAmountJPY - b.liabilityAmountJPY,
      cumulativeGapJPY
    };
  });

  // 100bps金利上昇シナリオにおける年間損益影響 (EaR: Earnings at Risk)
  const rateShift100bpsImpactJPY = Math.round(totalPv01JPY * 100);

  return {
    enrichedBuckets,
    totalAssetsJPY,
    totalLiabilitiesJPY,
    netTotalGapJPY: totalAssetsJPY - totalLiabilitiesJPY,
    totalPv01JPY,
    rateShift100bpsImpactJPY
  };
}

export function simulateLiquidityStress(
  treasury: TreasuryPosition,
  depositRunoffPct: number = 15.0, // 預金流出率 (ストレスシナリオ 15%)
  wholesaleFundingShockPct: number = 30.0
) {
  const depositOutflowJPY = treasury.totalDepositsJPY * (depositRunoffPct / 100);
  const wholesaleLossJPY = (treasury.totalCashReservesJPY * 0.4) * (wholesaleFundingShockPct / 100);
  const totalNetOutflowJPY = depositOutflowJPY + wholesaleLossJPY;

  const stressedHqlaRemainingJPY = treasury.hqlBufferJPY - totalNetOutflowJPY;
  const stressedLcrPct = Number(((stressedHqlaRemainingJPY / (totalNetOutflowJPY * 0.85)) * 100).toFixed(1));
  const stressedSurvivalDays = Math.max(10, Math.round(treasury.survivalHorizonDays * (1 - (depositRunoffPct / 50))));

  return {
    scenarioNameJa: `重度流動性ストレス (預金流出: ${depositRunoffPct}%, 市場資金調達制限: ${wholesaleFundingShockPct}%)`,
    depositOutflowJPY,
    totalNetOutflowJPY,
    stressedHqlaRemainingJPY,
    stressedLcrPct,
    stressedSurvivalDays,
    isCompliant: stressedLcrPct >= 100.0,
    requiredActionJa: stressedLcrPct >= 100.0 
      ? '健全水準維持。追加アクション不要。' 
      : '流動性緊急時対応計画 (Contingency Funding Plan) の発動及び日銀適格担保オペの実行を推奨。'
  };
}
