/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface AmortizationScheduleRow {
  installmentNumber: number;
  paymentDate: string;
  principalPaymentJPY: number;
  interestPaymentJPY: number;
  totalPaymentJPY: number;
  remainingPrincipalJPY: number;
}

/**
 * 融資計算・償還スケジュール生成エンジン (Loan & Amortization Engine)
 * 金利計算: Principal × Rate × DayCountFraction
 * 浮動金利: BaseRate (TONA / TIBOR) + Spread
 */
export function calculateInterestAmount(
  principalJPY: number,
  annualRatePct: number,
  days: number,
  dayCountFraction: 'ACTUAL_365' | 'ACTUAL_360' | '30_360' = 'ACTUAL_365'
): number {
  const divisor = dayCountFraction === 'ACTUAL_360' ? 360 : 365;
  const rateDecimal = annualRatePct / 100;
  return Math.round(principalJPY * rateDecimal * (days / divisor));
}

export function generateAmortizationSchedule(
  principalJPY: number,
  annualRatePct: number,
  tenorYears: number,
  paymentFrequencyPerYear: number = 4, // 季払い
  amortizationType: 'BULLET' | 'EQUAL_PRINCIPAL' | 'EQUAL_PAYMENT' = 'EQUAL_PRINCIPAL',
  startDate: string = '2026-10-01'
): AmortizationScheduleRow[] {
  const totalInstallments = tenorYears * paymentFrequencyPerYear;
  const schedule: AmortizationScheduleRow[] = [];
  let currentBalance = principalJPY;
  const periodRate = (annualRatePct / 100) / paymentFrequencyPerYear;

  const start = new Date(startDate);

  if (amortizationType === 'BULLET') {
    // 期日一括弁済 (満期まで利息のみ支払い)
    for (let i = 1; i <= totalInstallments; i++) {
      const payDate = new Date(start);
      payDate.setMonth(start.getMonth() + (i * (12 / paymentFrequencyPerYear)));
      const isFinal = i === totalInstallments;
      const principalPayment = isFinal ? currentBalance : 0;
      const interestPayment = Math.round(currentBalance * periodRate);
      const remaining = isFinal ? 0 : currentBalance;

      schedule.push({
        installmentNumber: i,
        paymentDate: payDate.toISOString().split('T')[0],
        principalPaymentJPY: principalPayment,
        interestPaymentJPY: interestPayment,
        totalPaymentJPY: principalPayment + interestPayment,
        remainingPrincipalJPY: remaining
      });
    }
  } else if (amortizationType === 'EQUAL_PRINCIPAL') {
    // 元金均等返済
    const equalPrincipal = Math.round(principalJPY / totalInstallments);
    for (let i = 1; i <= totalInstallments; i++) {
      const payDate = new Date(start);
      payDate.setMonth(start.getMonth() + (i * (12 / paymentFrequencyPerYear)));
      const isFinal = i === totalInstallments;
      const principalPayment = isFinal ? currentBalance : equalPrincipal;
      const interestPayment = Math.round(currentBalance * periodRate);
      currentBalance -= principalPayment;

      schedule.push({
        installmentNumber: i,
        paymentDate: payDate.toISOString().split('T')[0],
        principalPaymentJPY: principalPayment,
        interestPaymentJPY: interestPayment,
        totalPaymentJPY: principalPayment + interestPayment,
        remainingPrincipalJPY: Math.max(0, currentBalance)
      });
    }
  } else {
    // 元利均等返済
    const pmt = Math.round(
      (principalJPY * periodRate * Math.pow(1 + periodRate, totalInstallments)) /
      (Math.pow(1 + periodRate, totalInstallments) - 1)
    );

    for (let i = 1; i <= totalInstallments; i++) {
      const payDate = new Date(start);
      payDate.setMonth(start.getMonth() + (i * (12 / paymentFrequencyPerYear)));
      const isFinal = i === totalInstallments;
      const interestPayment = Math.round(currentBalance * periodRate);
      let principalPayment = pmt - interestPayment;
      if (isFinal || principalPayment > currentBalance) {
        principalPayment = currentBalance;
      }
      currentBalance -= principalPayment;

      schedule.push({
        installmentNumber: i,
        paymentDate: payDate.toISOString().split('T')[0],
        principalPaymentJPY: principalPayment,
        interestPaymentJPY: interestPayment,
        totalPaymentJPY: principalPayment + interestPayment,
        remainingPrincipalJPY: Math.max(0, currentBalance)
      });
    }
  }

  return schedule;
}
