/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { FinancialTerm } from '../types/dictionary';

export const CANONICAL_FINANCIAL_TERMS: FinancialTerm[] = [
  {
    id: 'term_01',
    termJa: '融資',
    kana: 'ゆうし',
    romaji: 'yuushi',
    termEn: 'Loan / Credit Facility',
    categoryJa: '法人金融 / 貸出業務',
    definitionJa: '銀行等の金融機関が利息の収受を目的として資金を必要とする顧客に金銭を供与する行為。形態として手形貸付、証書貸付、当座貸越等がある。',
    aliases: ['貸出', 'ローン', 'credit', 'lending', 'facility', '融資枠', '借入'],
    canonicalEntity: 'LoanFacility',
    regulatoryReference: '銀行法 第10条第1項第2号（資金の貸付け）'
  },
  {
    id: 'term_02',
    termJa: '流動性カバレッジ比率',
    kana: 'りゅうどうせいかばれっじひりつ',
    romaji: 'ryuudousei coverage hiritsu',
    termEn: 'Liquidity Coverage Ratio (LCR)',
    categoryJa: 'ALM / バーゼル規制',
    definitionJa: '短期的な資金流出ストレス（30日間）に対し、換金性の高い適格高品質流動性資産（HQLA）を十分に保有しているかを示す比率。最低基準値は100%。',
    aliases: ['LCR', 'エルシーアール', '流動性比率', 'liquidity buffer', 'HQLA'],
    canonicalEntity: 'TreasuryPosition',
    regulatoryReference: 'バーゼルIII 流動性規制枠組み'
  },
  {
    id: 'term_03',
    termJa: '自己資本比率',
    kana: 'じこしほんひりつ',
    romaji: 'jiko shihon hiritsu',
    termEn: 'Capital Adequacy Ratio / CET1 Ratio',
    categoryJa: 'リスク・財務・自己資本',
    definitionJa: '総リスクアセットに対する普通株式等Tier1資本（CET1）等の割合。金融機関の健全性と損失吸収力の基礎的指標。国際統一基準行は8%以上、CET1は4.5%+資本保全バッファー。',
    aliases: ['CET1', 'Tier1', '資本比率', 'BIS比率', 'Capital Ratio'],
    canonicalEntity: 'TreasuryPosition',
    regulatoryReference: '銀行法 第14条の2 / バーゼルIII資本合意'
  },
  {
    id: 'term_04',
    termJa: 'バリュー・アット・リスク',
    kana: 'ばりゅーあっとりすく',
    romaji: 'value at risk',
    termEn: 'Value at Risk (VaR)',
    categoryJa: '市場リスク管理',
    definitionJa: 'ある保有期間（例: 1日、10日）と信頼水準（例: 99%）の下で、市場変動によりポートフォリオが被る可能性のある最大損失予想額。',
    aliases: ['VaR', 'バー', 'バリューアットリスク', '市場リスク量', 'ES', 'Expected Shortfall'],
    canonicalEntity: 'RiskExposureMetric',
    regulatoryReference: '金融庁 市場リスク管理態勢監督指針'
  },
  {
    id: 'term_05',
    termJa: '全銀システム',
    kana: 'ぜんぎんしすてむ',
    romaji: 'zengin system',
    termEn: 'Zengin System / Domestic Funds Transfer',
    categoryJa: '決済・資金移動',
    definitionJa: '全国銀行データ通信システムの略。日本の民間金融機関相互の国内為替取引（振込、送金等）をリアルタイムでオンライン中継・清算する中核決済ネットワーク。',
    aliases: ['全銀', '国内送金', 'Zengin', '内為', '振込'],
    canonicalEntity: 'PaymentTransaction',
    regulatoryReference: '一般社団法人全国銀行資金決済ネットワーク（全銀ネット）'
  },
  {
    id: 'term_06',
    termJa: '総勘定元帳',
    kana: 'そうかんじょうもとちょう',
    romaji: 'soukanjou motochou',
    termEn: 'General Ledger (GL)',
    categoryJa: '主計・会計・複式簿記',
    definitionJa: 'すべての取引勘定科目の借方・貸方の発生と残高を一元的に記録・統括する会計帳簿。全ての金融取引イベントから複式仕訳が自動生成される。',
    aliases: ['GL', '元帳', '勘定元帳', '複式簿記', 'Double Entry', 'Trial Balance'],
    canonicalEntity: 'JournalEntry',
    regulatoryReference: '企業会計基準 / 銀行法施行規則'
  },
  {
    id: 'term_07',
    termJa: '信用リスク審査',
    kana: 'しんようりすくしんさ',
    romaji: 'shinyou risk shinsa',
    termEn: 'Credit Rating & Underwriting Engine',
    categoryJa: '信用リスク・審査',
    definitionJa: '債務者の財務諸表、返済能力（DSCR, Debt/EBITDA）、担保・保証価値から倒産確率（PD）及び保全考慮後損失率（LGD）を定量算出し、内部格付（1〜10）と与信限度額を判定する機構。',
    aliases: ['格付', 'PD', 'LGD', 'EAD', '債務者区分', 'Credit Score', '与信審査'],
    canonicalEntity: 'CreditAssessmentResult',
    regulatoryReference: '金融検査マニュアル資産査定要領準拠（内部モデル）'
  },
  {
    id: 'term_08',
    termJa: '外国為替スワップ',
    kana: 'がいこくかわせすわっぷ',
    romaji: 'gaikoku kawase swap',
    termEn: 'FX Swap / Forward Exchange',
    categoryJa: '市場・外国為替',
    definitionJa: '同一通貨ペアについて、異なる受渡期日の直物取引（Spot）と先物取引（Forward）を同時に反対売買することで、為替変動リスクを排除しつつ異種通貨資金を調達・運用する手法。',
    aliases: ['FXスワップ', '為替先物', 'FX Forward', '通貨スワップ', '為替ヘッジ'],
    canonicalEntity: 'FXRate',
    regulatoryReference: 'ISDA Master Agreement / 金融商品取引法'
  },
  {
    id: 'term_09',
    termJa: '疑わしい取引の届出',
    kana: 'うたがわしいとりひきのとどけで',
    romaji: 'utagawashii torihiki no todokede',
    termEn: 'Suspicious Activity Report (SAR / AML)',
    categoryJa: 'コンプライアンス / AML・CFT',
    definitionJa: 'マネー・ローンダリングやテロ資金供与に関与していると疑われる取引を検知し、法令に基づき行政庁（金融庁・JAFIC）へ報告する義務。AI検知と厳格な人間判断（四つ目承認）が要求される。',
    aliases: ['AML', 'SAR', '疑わしい取引', 'マネロン', '反社チェック', 'PEP', '制裁照合'],
    canonicalEntity: 'AMLAlert',
    regulatoryReference: '犯罪による収益の移転防止法 第8条'
  },
  {
    id: 'term_10',
    termJa: '受託財産・信託',
    kana: 'じゅたくざいさん・しんたく',
    romaji: 'jutaku zaisan shintaku',
    termEn: 'Trust Assets / Fiduciary Custody',
    categoryJa: '信託銀行・ウェルス管理',
    definitionJa: '委託者から信託目的に従い財産の移転を受け、受益者のために管理・処分される財産。固有財産との厳格な分別管理（倒産隔離）が法的に保証されている。',
    aliases: ['信託', 'Trust', '受託資産', 'カストディ', '遺言信託', '年金信託'],
    canonicalEntity: 'Account',
    regulatoryReference: '信託法 / 信託業法'
  },
  {
    id: 'term_11',
    termJa: 'ALM（資産負債総合管理）',
    kana: 'えーえるえむ',
    romaji: 'alm',
    termEn: 'Asset Liability Management (ALM)',
    categoryJa: 'トレジャリー / 財務',
    definitionJa: '金利変動や流動性不足による損失を回避し、収益を最大化するために、資産（貸出金・有価証券等）と負債（預金・市場調達等）の期間・金利感応度のギャップを総合的に把握・調整する統括管理手法。',
    aliases: ['ALM', '金利リスク', 'ギャップ分析', 'デュレーション', '資金調達コスト'],
    canonicalEntity: 'AlmBucketGap',
    regulatoryReference: '日本銀行 ALM実務ガイドライン'
  },
  {
    id: 'term_12',
    termJa: '照合・勘定突合',
    kana: 'しょうごう・かんじょうとつごう',
    romaji: 'shougou kanjou totsugou',
    termEn: 'Reconciliation & Break Management',
    categoryJa: 'オペレーション / 決済照合',
    definitionJa: '自社元帳と外部金融機関（日銀、保管機関、コルレス先）の口座残高および取引明細を電子的に突合し、差異（Break）を検知・原因究明して即座にCase IDで是正する統制プロセス。',
    aliases: ['レコメン', '突合', 'Recon', 'アンマッチ', '勘定照合', 'Break'],
    canonicalEntity: 'ReconciliationCase',
    regulatoryReference: '内閣府令 内部統制報告制度（J-SOX）'
  }
];

export function searchFinancialTerms(query: string): FinancialTerm[] {
  if (!query || !query.trim()) return CANONICAL_FINANCIAL_TERMS;
  const cleanQ = query.trim().toLowerCase();
  
  return CANONICAL_FINANCIAL_TERMS.filter(item => {
    return (
      item.termJa.toLowerCase().includes(cleanQ) ||
      item.kana.toLowerCase().includes(cleanQ) ||
      item.romaji.toLowerCase().includes(cleanQ) ||
      item.termEn.toLowerCase().includes(cleanQ) ||
      item.categoryJa.toLowerCase().includes(cleanQ) ||
      item.definitionJa.toLowerCase().includes(cleanQ) ||
      item.aliases.some(alias => alias.toLowerCase().includes(cleanQ)) ||
      item.canonicalEntity.toLowerCase().includes(cleanQ)
    );
  });
}
