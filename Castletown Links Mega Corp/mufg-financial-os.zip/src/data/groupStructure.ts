/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GroupEntity } from '../types/financial';

export const MUFG_GROUP_ENTITIES: GroupEntity[] = [
  {
    id: 'ent_hd',
    name: '株式会社三菱UFJフィナンシャル・グループ',
    nameEn: 'Mitsubishi UFJ Financial Group, Inc. (Holding Co.)',
    code: 'MUFG-HD-8306',
    type: 'HoldingCompany',
    jurisdiction: 'JP',
    baseCurrency: 'JPY',
    totalAssetsJPY: 412_500_000_000_000, // 412.5 兆円
    totalEquityJPY: 19_800_000_000_000, // 19.8 兆円
    branchesCount: 1,
    employeesCount: 3200,
    descriptionJa: 'グループ全体の経営戦略策定、コンプライアンス統括、リスク管理、資本政策を司る持株持株会社。',
    status: 'ACTIVE'
  },
  {
    id: 'ent_bk',
    name: '株式会社三菱UFJ銀行',
    nameEn: 'MUFG Bank, Ltd.',
    code: 'MUFG-BK-0005',
    type: 'Bank',
    jurisdiction: 'JP',
    baseCurrency: 'JPY',
    totalAssetsJPY: 268_400_000_000_000, // 268.4 兆円
    totalEquityJPY: 12_400_000_000_000,
    branchesCount: 420,
    employeesCount: 31200,
    descriptionJa: '国内最大級の預貸基盤、決済インフラ、グローバルCIBネットワークを有する総合商業銀行。',
    status: 'ACTIVE'
  },
  {
    id: 'ent_tb',
    name: '三菱UFJ信託銀行株式会社',
    nameEn: 'Mitsubishi UFJ Trust and Banking Corporation',
    code: 'MUFG-TB-0288',
    type: 'TrustBank',
    jurisdiction: 'JP',
    baseCurrency: 'JPY',
    totalAssetsJPY: 54_200_000_000_000, // 54.2 兆円（受託財産130兆円超）
    totalEquityJPY: 2_950_000_000_000,
    branchesCount: 52,
    employeesCount: 7100,
    descriptionJa: '受託財産管理、年金信託、不動産ファイナンス、資産承継・遺言信託を手掛ける中核信託銀行。',
    status: 'ACTIVE'
  },
  {
    id: 'ent_sec',
    name: '三菱UFJモルガン・スタンレー証券株式会社',
    nameEn: 'Mitsubishi UFJ Morgan Stanley Securities Co., Ltd.',
    code: 'MUFG-MS-0008',
    type: 'SecuritiesCompany',
    jurisdiction: 'JP',
    baseCurrency: 'JPY',
    totalAssetsJPY: 38_600_000_000_000, // 38.6 兆円
    totalEquityJPY: 1_820_000_000_000,
    branchesCount: 65,
    employeesCount: 5800,
    descriptionJa: 'リテール富裕層証券仲介からM&Aアドバイザリー、DCM/ECM債券株式引受、FICCトレーディングを展開。',
    status: 'ACTIVE'
  },
  {
    id: 'ent_am',
    name: '三菱UFJアセットマネジメント株式会社',
    nameEn: 'MUFG Asset Management Co., Ltd.',
    code: 'MUFG-AM-0101',
    type: 'AssetManagementCompany',
    jurisdiction: 'JP',
    baseCurrency: 'JPY',
    totalAssetsJPY: 4_800_000_000_000, // 運用残高 35兆円
    totalEquityJPY: 320_000_000_000,
    branchesCount: 3,
    employeesCount: 1100,
    descriptionJa: '投資信託の設定・運用、機関投資家向け年金運用、オルタナティブ投資を提供する資産運用会社。',
    status: 'ACTIVE'
  },
  {
    id: 'ent_nic',
    name: '三菱UFJニコス株式会社',
    nameEn: 'Mitsubishi UFJ NICOS Co., Ltd.',
    code: 'MUFG-NC-0012',
    type: 'CreditCardCompany',
    jurisdiction: 'JP',
    baseCurrency: 'JPY',
    totalAssetsJPY: 6_200_000_000_000,
    totalEquityJPY: 410_000_000_000,
    branchesCount: 12,
    employeesCount: 3400,
    descriptionJa: 'MUFGカード・DC・NICOSブランドのクレジットカード発行、加盟店決済アクワイアリング事業。',
    status: 'ACTIVE'
  },
  {
    id: 'ent_acm',
    name: 'アコム株式会社',
    nameEn: 'ACOM CO., LTD.',
    code: 'MUFG-AC-8572',
    type: 'ConsumerFinanceCompany',
    jurisdiction: 'JP',
    baseCurrency: 'JPY',
    totalAssetsJPY: 2_950_000_000_000,
    totalEquityJPY: 580_000_000_000,
    branchesCount: 780,
    employeesCount: 2200,
    descriptionJa: 'コンシューマーファイナンス、信用保証事業（提携地方銀行向け保証）を展開。',
    status: 'ACTIVE'
  },
  {
    id: 'ent_lse',
    name: '三菱HCキャピタル株式会社',
    nameEn: 'Mitsubishi HC Capital Inc.',
    code: 'MUFG-HC-8593',
    type: 'LeasingCompany',
    jurisdiction: 'JP',
    baseCurrency: 'JPY',
    totalAssetsJPY: 11_400_000_000_000,
    totalEquityJPY: 1_650_000_000_000,
    branchesCount: 34,
    employeesCount: 8900,
    descriptionJa: '産業設備リース、航空機リース、再生可能エネルギー投資、モビリティファイナンスを展開。',
    status: 'ACTIVE'
  },
  {
    id: 'ent_emea',
    name: 'MUFG Bank (Europe) N.V. / EMEA拠点',
    nameEn: 'MUFG Bank (Europe) N.V. / EMEA',
    code: 'MUFG-EU-0991',
    type: 'ForeignSubsidiary',
    jurisdiction: 'NL/UK',
    baseCurrency: 'EUR',
    totalAssetsJPY: 18_200_000_000_000,
    totalEquityJPY: 980_000_000_000,
    branchesCount: 14,
    employeesCount: 2400,
    descriptionJa: '欧州・中東・アフリカにおける多国籍企業向け融資、シンジケーション、グローバルキャッシュマネジメント。',
    status: 'ACTIVE'
  },
  {
    id: 'ent_us',
    name: 'MUFG Americas Holdings Corporation',
    nameEn: 'MUFG Americas Holdings Corporation',
    code: 'MUFG-US-0442',
    type: 'ForeignSubsidiary',
    jurisdiction: 'US',
    baseCurrency: 'USD',
    totalAssetsJPY: 24_500_000_000_000,
    totalEquityJPY: 1_450_000_000_000,
    branchesCount: 18,
    employeesCount: 3100,
    descriptionJa: '北米コーポレートバンキング、プロジェクトファイナンス、機関投資家向け証券・FICCソリューション。',
    status: 'ACTIVE'
  }
];

export const EXECUTIVE_GROUP_KPIS = {
  totalAssetsJPY: 412_500_000_000_000, // 412.5兆円
  totalDepositsJPY: 236_800_000_000_000, // 236.8兆円
  totalLoansJPY: 124_600_000_000_000, // 124.6兆円
  netOperatingIncomeJPY: 1_620_000_000_000, // 1兆6200億円
  netProfitJPY: 1_430_000_000_000, // 1兆4300億円
  roePct: 8.92, // ROE 8.92%
  roraPct: 1.15, // RORA
  cet1RatioPct: 12.45, // CET1 12.45%
  nimPct: 0.88, // Net Interest Margin
  creditCostRatioBps: 18, // 18 bps
  hqlBufferJPY: 92_000_000_000_000, // 92兆円
  lcrRatioPct: 164.2, // 164.2%
  nsfrRatioPct: 128.6,
  dailyVaR99_JPY: 42_500_000_000, // 425億円
  syntheticDataNote: 'DEMO / SYNTHETIC DATA (実在のMUFG内部機密情報は一切使用しておりません)'
};
