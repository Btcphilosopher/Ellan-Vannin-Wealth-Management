/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Customer,
  Account,
  LoanFacility,
  Security,
  MarketOrder,
  FXRate,
  AlmBucketGap,
  TreasuryPosition,
  JournalEntry,
  ReconciliationCase,
  PaymentTransaction,
  AMLAlert,
  RiskExposureMetric,
  AuditLogRecord,
} from '../types/financial';

// ==========================================
// 1. Synthetic Customers
// ==========================================
export const SYNTHETIC_CUSTOMERS: Customer[] = [
  {
    id: 'cust_corp_01',
    customerCode: 'CORP-JP-10029',
    type: 'CORPORATE',
    nameJa: '東都産業株式会社',
    nameKana: 'とうとさんぎょうかぶしきがいしゃ',
    nameEn: 'Toto Heavy Industries Ltd.',
    entityId: 'ent_bk',
    industryCategory: '精密機械・産業用ロボット製造',
    creditRating: '2 (AA-)',
    riskScore: 18,
    kycStatus: 'VERIFIED',
    amlRiskRating: 'LOW',
    representativeJa: '代表取締役社長 鈴木 健一',
    capitalJPY: 15_000_000_000,
    annualRevenueJPY: 148_000_000_000,
    totalAssetsJPY: 185_000_000_000,
    totalLiabilitiesJPY: 76_000_000_000,
    rmName: '佐藤 達也 (上席RM)',
    rmDepartment: '法人営業第一部 第3グループ',
    contactEmail: 'corp-ir@toto-sangyo-synthetic.jp',
    phone: '03-5555-0101',
    addressJa: '東京都千代田区丸の内二丁目7番1号',
    beneficialOwners: [
      { id: 'bo_01', nameJa: '東都ホールディングス有限会社', title: '親会社 (41.2%)', shareholdingPct: 41.2, pepStatus: false, sanctionClearance: true },
      { id: 'bo_02', nameJa: '鈴木 健一', title: '創業者親族・代表取締役 (12.5%)', shareholdingPct: 12.5, pepStatus: false, sanctionClearance: true }
    ],
    covenants: ['有利子負債 / EBITDA倍率 3.5倍以内維持', '純資産額 800億円以上維持 (前年同期比75%以上)', '配当性向 30%上限'],
    createdAt: '2018-04-01T09:00:00+09:00',
    updatedAt: '2026-09-10T14:30:00+09:00'
  },
  {
    id: 'cust_corp_02',
    customerCode: 'CORP-JP-10482',
    type: 'CORPORATE',
    nameJa: '日本東洋物流株式会社',
    nameKana: 'にっぽんとうようぶつりゅうかぶしきがいしゃ',
    nameEn: 'Nippon Toyo Logistics Corp.',
    entityId: 'ent_bk',
    industryCategory: '国際総合物流・港湾運送・倉庫',
    creditRating: '3 (A+)',
    riskScore: 28,
    kycStatus: 'VERIFIED',
    amlRiskRating: 'MEDIUM',
    representativeJa: '代表取締役社長 渡辺 誠司',
    capitalJPY: 8_500_000_000,
    annualRevenueJPY: 89_000_000_000,
    totalAssetsJPY: 112_000_000_000,
    totalLiabilitiesJPY: 58_000_000_000,
    rmName: '松本 玲奈 (主任RM)',
    rmDepartment: '法人営業第三部 運輸開発室',
    contactEmail: 'finance@toyo-logistics-synthetic.jp',
    phone: '03-5555-0202',
    addressJa: '東京都港区芝浦一丁目13番10号',
    beneficialOwners: [
      { id: 'bo_03', nameJa: '東洋海運財団', title: '筆頭株主 (28.4%)', shareholdingPct: 28.4, pepStatus: false, sanctionClearance: true }
    ],
    covenants: ['インタレスト・カバレッジ・レシオ (ICR) 4.0倍以上維持', '担保設定制限条項 (Negative Pledge)'],
    createdAt: '2019-11-15T10:00:00+09:00',
    updatedAt: '2026-09-11T11:20:00+09:00'
  },
  {
    id: 'cust_corp_03',
    customerCode: 'CORP-JP-10903',
    type: 'CORPORATE',
    nameJa: '東京アセット株式会社',
    nameKana: 'とうきょうあせっとかぶしきがいしゃ',
    nameEn: 'Tokyo Asset Management & Development K.K.',
    entityId: 'ent_tb',
    industryCategory: '都市型不動産開発・信託受益権投資',
    creditRating: '4 (BBB+)',
    riskScore: 42,
    kycStatus: 'VERIFIED',
    amlRiskRating: 'MEDIUM',
    representativeJa: '代表取締役 高橋 弘樹',
    capitalJPY: 4_200_000_000,
    annualRevenueJPY: 34_500_000_000,
    totalAssetsJPY: 98_000_000_000,
    totalLiabilitiesJPY: 68_000_000_000,
    rmName: '中村 剛 (信託RM)',
    rmDepartment: '信託不動産営業第二部',
    contactEmail: 'treasury@tokyo-asset-synthetic.co.jp',
    phone: '03-5555-0303',
    addressJa: '東京都中央区日本橋本町一丁目4番8号',
    beneficialOwners: [
      { id: 'bo_04', nameJa: 'グローバル・キャピタル・ファンドII', title: '投資事業組合 (55.0%)', shareholdingPct: 55.0, pepStatus: false, sanctionClearance: true }
    ],
    covenants: ['LTV (Loan to Value) 70%以内維持', 'DSCR (元利金返済カバー率) 1.35倍以上'],
    createdAt: '2021-02-20T13:15:00+09:00',
    updatedAt: '2026-09-08T16:45:00+09:00'
  },
  {
    id: 'cust_wealth_01',
    customerCode: 'WLTH-JP-80112',
    type: 'WEALTH',
    nameJa: '顧客001: 徳川 栄一',
    nameKana: 'とくがわ えいいち',
    nameEn: 'Eiichi Tokugawa (Private Wealth Client 001)',
    entityId: 'ent_tb',
    riskScore: 12,
    kycStatus: 'VERIFIED',
    amlRiskRating: 'LOW',
    totalAssetsJPY: 4_850_000_000, // 48.5億円
    totalLiabilitiesJPY: 420_000_000,
    rmName: '一条 貴弘 (プライベートバンカー)',
    rmDepartment: 'ウェルスマネジメント営業第一部',
    contactEmail: 'e.tokugawa-private@synthetic.jp',
    phone: '090-5555-0011',
    addressJa: '東京都港区南麻布四丁目',
    covenants: ['事業承継信託契約締結済', '遺言代用信託設定'],
    createdAt: '2015-06-10T11:00:00+09:00',
    updatedAt: '2026-09-12T09:00:00+09:00'
  },
  {
    id: 'cust_wealth_02',
    customerCode: 'WLTH-JP-80244',
    type: 'WEALTH',
    nameJa: '顧客002: 渋沢 雅子',
    nameKana: 'しぶさわ まさこ',
    nameEn: 'Masako Shibusawa (Private Wealth Client 002)',
    entityId: 'ent_sec',
    riskScore: 16,
    kycStatus: 'VERIFIED',
    amlRiskRating: 'LOW',
    totalAssetsJPY: 2_680_000_000, // 26.8億円
    totalLiabilitiesJPY: 80_000_000,
    rmName: '小泉 美咲 (PBシニアマネージャー)',
    rmDepartment: 'MUFGウェルス・アドバイザリー室',
    contactEmail: 'm.shibusawa-private@synthetic.jp',
    phone: '090-5555-0022',
    addressJa: '東京都世田谷区成城六丁目',
    covenants: ['ESGテーマ型信託運用マランデート受託'],
    createdAt: '2017-09-18T15:30:00+09:00',
    updatedAt: '2026-09-09T17:20:00+09:00'
  }
];

// ==========================================
// 2. Synthetic Accounts
// ==========================================
export const SYNTHETIC_ACCOUNTS: Account[] = [
  {
    id: 'acc_01',
    accountNumber: 'JP00100001',
    customerId: 'cust_corp_01',
    entityId: 'ent_bk',
    accountType: 'CURRENT_DEPOSIT',
    currency: 'JPY',
    balance: 14_850_000_000, // 148.5億円
    availableBalance: 14_850_000_000,
    holdAmount: 0,
    interestRatePct: 0.125,
    status: 'ACTIVE',
    branchCode: '001',
    branchName: '本店営業部 (001)',
    openedDate: '2018-04-01',
    lastActivityDate: '2026-09-12'
  },
  {
    id: 'acc_02',
    accountNumber: 'JP00100002',
    customerId: 'cust_corp_01',
    entityId: 'ent_bk',
    accountType: 'FOREIGN_CURRENCY_DEPOSIT',
    currency: 'USD',
    balance: 45_000_000, // $45M USD
    availableBalance: 45_000_000,
    holdAmount: 0,
    interestRatePct: 4.85,
    status: 'ACTIVE',
    branchCode: '001',
    branchName: '本店営業部 (001)',
    openedDate: '2019-06-15',
    lastActivityDate: '2026-09-11'
  },
  {
    id: 'acc_03',
    accountNumber: 'JP00100003',
    customerId: 'cust_corp_02',
    entityId: 'ent_bk',
    accountType: 'ORDINARY_DEPOSIT',
    currency: 'JPY',
    balance: 6_420_000_000, // 64.2億円
    availableBalance: 6_220_000_000,
    holdAmount: 200_000_000,
    interestRatePct: 0.125,
    status: 'ACTIVE',
    branchCode: '020',
    branchName: '丸の内支店 (020)',
    openedDate: '2019-11-15',
    lastActivityDate: '2026-09-12'
  },
  {
    id: 'acc_04',
    accountNumber: 'JP00288001',
    customerId: 'cust_corp_03',
    entityId: 'ent_tb',
    accountType: 'TRUST_CUSTODY',
    currency: 'JPY',
    balance: 22_500_000_000, // 225億円
    availableBalance: 22_500_000_000,
    holdAmount: 0,
    interestRatePct: 0.25,
    status: 'ACTIVE',
    branchCode: '100',
    branchName: '信託信託本店 (100)',
    openedDate: '2021-02-20',
    lastActivityDate: '2026-09-10'
  },
  {
    id: 'acc_05',
    accountNumber: 'JP00088001',
    customerId: 'cust_wealth_01',
    entityId: 'ent_sec',
    accountType: 'SECURITIES_CUSTODY',
    currency: 'JPY',
    balance: 3_250_000_000, // 32.5億円
    availableBalance: 3_250_000_000,
    holdAmount: 0,
    interestRatePct: 0.0,
    status: 'ACTIVE',
    branchCode: '501',
    branchName: 'プライベートバンキング営業部 (501)',
    openedDate: '2015-06-10',
    lastActivityDate: '2026-09-12'
  }
];

// ==========================================
// 3. Synthetic Loan Facilities
// ==========================================
export const SYNTHETIC_LOANS: LoanFacility[] = [
  {
    id: 'fac_01',
    facilityCode: 'LN-2024-TOTO-001',
    customerId: 'cust_corp_01',
    entityId: 'ent_bk',
    facilityType: 'TERM_LOAN',
    committedLimitJPY: 25_000_000_000, // 250億円
    drawnAmountJPY: 18_500_000_000,
    undrawnAmountJPY: 6_500_000_000,
    currency: 'JPY',
    baseRateType: 'TONA',
    baseRatePct: 0.25,
    spreadBps: 45,
    effectiveRatePct: 0.70,
    dayCountFraction: 'ACTUAL_365',
    startDate: '2024-04-01',
    maturityDate: '2029-03-31',
    amortizationType: 'EQUAL_PRINCIPAL',
    collateralDescriptionJa: '横浜テクノロジーセンター工場敷地および機械設備 (第一順位根抵当権 120億円)',
    collateralValueJPY: 14_500_000_000,
    status: 'ACTIVE',
    leadArranger: '三菱UFJ銀行 本店営業部',
    covenants: ['連結純資産維持条項', '格付維持条項 (BBB以上)']
  },
  {
    id: 'fac_02',
    facilityCode: 'LN-2025-TOYO-002',
    customerId: 'cust_corp_02',
    entityId: 'ent_bk',
    facilityType: 'SYNDICATED_LOAN',
    committedLimitJPY: 15_000_000_000, // 150億円 (シンジケートローン)
    drawnAmountJPY: 12_000_000_000,
    undrawnAmountJPY: 3_000_000_000,
    currency: 'JPY',
    baseRateType: 'TIBOR_3M',
    baseRatePct: 0.38,
    spreadBps: 60,
    effectiveRatePct: 0.98,
    dayCountFraction: 'ACTUAL_365',
    startDate: '2025-01-15',
    maturityDate: '2030-01-14',
    amortizationType: 'BULLET',
    collateralDescriptionJa: '東京港第5コンテナターミナル信託受益権',
    collateralValueJPY: 16_000_000_000,
    status: 'ACTIVE',
    leadArranger: '三菱UFJ銀行 (幹事行 / 参加行 7行)',
    covenants: ['DSCR 1.30倍以上', '配当制限']
  },
  {
    id: 'fac_03',
    facilityCode: 'LN-2023-TKAS-003',
    customerId: 'cust_corp_03',
    entityId: 'ent_tb',
    facilityType: 'PROJECT_FINANCE',
    committedLimitJPY: 30_000_000_000, // 300億円 (信託・不動産PF)
    drawnAmountJPY: 28_000_000_000,
    undrawnAmountJPY: 2_000_000_000,
    currency: 'JPY',
    baseRateType: 'FIXED',
    baseRatePct: 1.45,
    spreadBps: 0,
    effectiveRatePct: 1.45,
    dayCountFraction: '30_360',
    startDate: '2023-09-01',
    maturityDate: '2033-08-31',
    amortizationType: 'EQUAL_PAYMENT',
    collateralDescriptionJa: '日本橋スマートタワー複合ビル信託受益権 (担保評価額 420億円)',
    collateralValueJPY: 42_000_000_000,
    status: 'ACTIVE',
    leadArranger: '三菱UFJ信託銀行 信託不動産営業部',
    covenants: ['テナント稼働率 85%以上維持', 'LTV 70%以内']
  }
];

// ==========================================
// 4. Synthetic Securities & Rates
// ==========================================
export const SYNTHETIC_SECURITIES: Security[] = [
  {
    id: 'sec_jgb_10y',
    isin: 'JP1103751N76',
    ticker: 'JGB10Y#375',
    nameJa: '第375回 利付国債 (10年)',
    nameEn: 'Japanese Government Bond 10-Year #375',
    type: 'JGB',
    currency: 'JPY',
    currentPrice: 99.45,
    dayChangePct: -0.08,
    yieldToMaturityPct: 1.055,
    couponRatePct: 1.00,
    maturityDate: '2034-06-20',
    issuerJa: '日本国財務省',
    creditRating: 'A1 / A+'
  },
  {
    id: 'sec_jgb_30y',
    isin: 'JP1300801G71',
    ticker: 'JGB30Y#80',
    nameJa: '第80回 超長期利付国債 (30年)',
    nameEn: 'Japanese Government Bond 30-Year #80',
    type: 'JGB',
    currency: 'JPY',
    currentPrice: 94.20,
    dayChangePct: -0.15,
    yieldToMaturityPct: 2.185,
    couponRatePct: 1.90,
    maturityDate: '2054-03-20',
    issuerJa: '日本国財務省',
    creditRating: 'A1 / A+'
  },
  {
    id: 'sec_corp_mufg',
    isin: 'JP3902900004',
    ticker: '8306.T',
    nameJa: '三菱UFJフィナンシャル・グループ 普通株式',
    nameEn: 'Mitsubishi UFJ Financial Group, Inc. Equity',
    type: 'EQUITY',
    currency: 'JPY',
    currentPrice: 1845.5,
    dayChangePct: 1.42,
    issuerJa: '三菱UFJフィナンシャル・グループ',
    creditRating: 'AA-'
  },
  {
    id: 'sec_fund_emaxis',
    isin: 'JP90C000GK88',
    ticker: 'eMAXIS-SLIM-AC',
    nameJa: 'eMAXIS Slim 全世界株式 (オール・カントリー)',
    nameEn: 'eMAXIS Slim All Country World Equity Fund',
    type: 'MUTUAL_FUND',
    currency: 'JPY',
    currentPrice: 26850,
    dayChangePct: 0.65,
    issuerJa: '三菱UFJアセットマネジメント',
    creditRating: 'AAA'
  }
];

export const SYNTHETIC_FX_RATES: FXRate[] = [
  { pair: 'USD/JPY', bid: 152.42, ask: 152.44, mid: 152.43, high: 153.10, low: 151.90, change24hPct: -0.32, tenor: 'SPOT', updatedAt: '2026-09-12T03:25:00Z' },
  { pair: 'EUR/JPY', bid: 165.18, ask: 165.21, mid: 165.195, high: 165.80, low: 164.95, change24hPct: 0.15, tenor: 'SPOT', updatedAt: '2026-09-12T03:25:00Z' },
  { pair: 'GBP/JPY', bid: 196.80, ask: 196.85, mid: 196.825, high: 197.40, low: 196.20, change24hPct: 0.28, tenor: 'SPOT', updatedAt: '2026-09-12T03:25:00Z' },
  { pair: 'AUD/JPY', bid: 99.45, ask: 99.49, mid: 99.47, high: 100.10, low: 99.20, change24hPct: -0.45, tenor: 'SPOT', updatedAt: '2026-09-12T03:25:00Z' },
  { pair: 'EUR/USD', bid: 1.0835, ask: 1.0837, mid: 1.0836, high: 1.0870, low: 1.0815, change24hPct: 0.42, tenor: 'SPOT', updatedAt: '2026-09-12T03:25:00Z' },
  { pair: 'USD/CNY', bid: 7.2150, ask: 7.2180, mid: 7.2165, high: 7.2250, low: 7.2100, change24hPct: 0.05, tenor: 'SPOT', updatedAt: '2026-09-12T03:25:00Z' }
];

// ==========================================
// 5. Synthetic ALM Gap Analysis Tenors
// ==========================================
export const SYNTHETIC_ALM_BUCKETS: AlmBucketGap[] = [
  { tenor: 'Overnight', assetAmountJPY: 38_500_000_000_000, liabilityAmountJPY: 46_200_000_000_000, netGapJPY: -7_700_000_000_000, cumulativeGapJPY: -7_700_000_000_000, interestRateSensitivityBps: 2.1, pv01JPY: 385_000_000 },
  { tenor: '1W', assetAmountJPY: 14_200_000_000_000, liabilityAmountJPY: 12_800_000_000_000, netGapJPY: 1_400_000_000_000, cumulativeGapJPY: -6_300_000_000_000, interestRateSensitivityBps: 3.5, pv01JPY: 142_000_000 },
  { tenor: '1M', assetAmountJPY: 22_400_000_000_000, liabilityAmountJPY: 19_600_000_000_000, netGapJPY: 2_800_000_000_000, cumulativeGapJPY: -3_500_000_000_000, interestRateSensitivityBps: 5.2, pv01JPY: 224_000_000 },
  { tenor: '3M', assetAmountJPY: 31_000_000_000_000, liabilityAmountJPY: 26_500_000_000_000, netGapJPY: 4_500_000_000_000, cumulativeGapJPY: 1_000_000_000_000, interestRateSensitivityBps: 8.4, pv01JPY: 310_000_000 },
  { tenor: '6M', assetAmountJPY: 28_600_000_000_000, liabilityAmountJPY: 24_100_000_000_000, netGapJPY: 4_500_000_000_000, cumulativeGapJPY: 5_500_000_000_000, interestRateSensitivityBps: 11.2, pv01JPY: 286_000_000 },
  { tenor: '1Y', assetAmountJPY: 45_200_000_000_000, liabilityAmountJPY: 36_800_000_000_000, netGapJPY: 8_400_000_000_000, cumulativeGapJPY: 13_900_000_000_000, interestRateSensitivityBps: 18.0, pv01JPY: 452_000_000 },
  { tenor: '2Y', assetAmountJPY: 34_800_000_000_000, liabilityAmountJPY: 28_200_000_000_000, netGapJPY: 6_600_000_000_000, cumulativeGapJPY: 20_500_000_000_000, interestRateSensitivityBps: 24.5, pv01JPY: 348_000_000 },
  { tenor: '3Y', assetAmountJPY: 29_500_000_000_000, liabilityAmountJPY: 21_000_000_000_000, netGapJPY: 8_500_000_000_000, cumulativeGapJPY: 29_000_000_000_000, interestRateSensitivityBps: 32.1, pv01JPY: 295_000_000 },
  { tenor: '5Y', assetAmountJPY: 52_000_000_000_000, liabilityAmountJPY: 16_400_000_000_000, netGapJPY: 35_600_000_000_000, cumulativeGapJPY: 64_600_000_000_000, interestRateSensitivityBps: 48.0, pv01JPY: 520_000_000 },
  { tenor: '10Y', assetAmountJPY: 68_400_000_000_000, liabilityAmountJPY: 8_200_000_000_000, netGapJPY: 60_200_000_000_000, cumulativeGapJPY: 124_800_000_000_000, interestRateSensitivityBps: 85.0, pv01JPY: 684_000_000 },
  { tenor: '20Y', assetAmountJPY: 32_500_000_000_000, liabilityAmountJPY: 2_100_000_000_000, netGapJPY: 30_400_000_000_000, cumulativeGapJPY: 155_200_000_000_000, interestRateSensitivityBps: 120.0, pv01JPY: 325_000_000 },
  { tenor: '30Y', assetAmountJPY: 15_400_000_000_000, liabilityAmountJPY: 900_000_000_000, netGapJPY: 14_500_000_000_000, cumulativeGapJPY: 169_700_000_000_000, interestRateSensitivityBps: 165.0, pv01JPY: 154_000_000 }
];

export const SYNTHETIC_TREASURY_POSITION: TreasuryPosition = {
  id: 'tr_pos_001',
  entityId: 'ent_bk',
  totalCashReservesJPY: 45_800_000_000_000,
  bojCurrentAccountBalanceJPY: 36_200_000_000_000, // 36.2兆円 日銀当預
  hqlBufferJPY: 92_400_000_000_000, // 92.4兆円
  lcrRatioPct: 164.5,
  nsfrRatioPct: 128.2,
  survivalHorizonDays: 142, // ストレス環境下での耐久日数 142日
  fundingCostAvgPct: 0.32,
  totalDepositsJPY: 236_800_000_000_000,
  totalLoansJPY: 124_600_000_000_000,
  loanToDepositRatioPct: 52.62,
  cet1CapitalRatioPct: 12.45,
  tier1CapitalRatioPct: 14.20,
  totalCapitalRatioPct: 16.10
};

// ==========================================
// 6. Synthetic Double-Entry General Ledger
// ==========================================
export const SYNTHETIC_JOURNALS: JournalEntry[] = [
  {
    id: 'jn_001',
    entryNumber: 'GL-2026-0912-00891',
    entityId: 'ent_bk',
    transactionType: '融資実行・預金振替 (Loan Drawdown)',
    postingDate: '2026-09-12',
    valueDate: '2026-09-12',
    lines: [
      { id: 'jl_01', accountCode: '1100', accountNameJa: '貸出金 (Loans & Advances)', debitJPY: 5_000_000_000, creditJPY: 0, currency: 'JPY', originalAmount: 5_000_000_000, descriptionJa: '東都産業向けタームローン第3回実行' },
      { id: 'jl_02', accountCode: '2100', accountNameJa: '当座預金 (Current Deposits)', debitJPY: 0, creditJPY: 4_992_500_000, currency: 'JPY', originalAmount: 4_992_500_000, descriptionJa: '東都産業 当座口(JP00100001)への入金' },
      { id: 'jl_03', accountCode: '4200', accountNameJa: '融資関連手数料収益 (Loan Commitment Fees)', debitJPY: 0, creditJPY: 7_500_000, currency: 'JPY', originalAmount: 7_500_000, descriptionJa: '組成事務手数料 (Upfront Fee 15bps)' }
    ],
    totalDebitJPY: 5_000_000_000,
    totalCreditJPY: 5_000_000_000,
    isBalanced: true,
    status: 'POSTED',
    createdBy: 'SYS_LOAN_CORE',
    approvedBy: '田中 浩二 (主計課長)',
    sourceModule: 'LOAN',
    correlationId: 'tx-loan-drawdown-20260912-001'
  },
  {
    id: 'jn_002',
    entryNumber: 'GL-2026-0912-00892',
    entityId: 'ent_bk',
    transactionType: '外国為替受渡決済 (FX Spot Settlement)',
    postingDate: '2026-09-12',
    valueDate: '2026-09-12',
    lines: [
      { id: 'jl_04', accountCode: '1020', accountNameJa: '日銀当座預金 (BOJ Current Account)', debitJPY: 1_524_300_000, creditJPY: 0, currency: 'JPY', originalAmount: 1_524_300_000, descriptionJa: 'USD/JPY 直物売買 (買: JPY / 売: USD10M)' },
      { id: 'jl_05', accountCode: '1030', accountNameJa: '外国為替ノストロ勘定 (USD Nostro / J.P. Morgan NY)', debitJPY: 0, creditJPY: 1_524_300_000, currency: 'USD', originalAmount: 10_000_000, descriptionJa: 'USD 10,000,000 払出受渡 (Rate: 152.43)' }
    ],
    totalDebitJPY: 1_524_300_000,
    totalCreditJPY: 1_524_300_000,
    isBalanced: true,
    status: 'POSTED',
    createdBy: 'SYS_FX_SETTLE',
    approvedBy: 'システム自動照合 (STP)',
    sourceModule: 'FX',
    correlationId: 'tx-fx-settle-20260912-882'
  }
];

// ==========================================
// 7. Synthetic Reconciliation Cases
// ==========================================
export const SYNTHETIC_RECONCILIATION_CASES: ReconciliationCase[] = [
  {
    id: 'rec_001',
    caseNumber: 'RC-2026-0912-001',
    sourceSystemA: 'MUFG Core GL (勘定系元帳)',
    sourceSystemB: 'BOJ-NET (日銀ネット預金残高)',
    accountOrRef: 'BOJ-ACT-0005-MAIN',
    currency: 'JPY',
    systemABalance: 36_200_000_000_000,
    systemBBalance: 36_200_000_000_000,
    variance: 0,
    status: 'MATCHED',
    assignedOfficerJa: '小林 健太 (資金決済部)',
    identifiedAt: '2026-09-12T07:00:00+09:00',
    resolvedAt: '2026-09-12T07:05:00+09:00'
  },
  {
    id: 'rec_002',
    caseNumber: 'RC-2026-0912-002',
    sourceSystemA: 'Securities Custody Ledger (証券保管口座)',
    sourceSystemB: 'JASDEC (証券保管振替機構)',
    accountOrRef: 'JASDEC-SEC-8306-01',
    currency: 'JPY',
    systemABalance: 845_200_000_000,
    systemBBalance: 845_180_000_000,
    variance: 20_000_000, // 2,000万円の一時差異
    status: 'PARTIAL',
    breakReasonJa: '夜間バッチ未達注文（東証立会外取引 T+1受渡タイミングの時差）',
    assignedOfficerJa: '山口 翔平 (証券オペレーション部)',
    identifiedAt: '2026-09-12T06:30:00+09:00'
  }
];

// ==========================================
// 8. Synthetic Payments & Settlements
// ==========================================
export const SYNTHETIC_PAYMENTS: PaymentTransaction[] = [
  {
    id: 'pmt_001',
    paymentRef: 'ZG-20260912-009182',
    senderNameJa: '東都産業株式会社',
    senderAccount: 'JP00100001',
    senderBank: '三菱UFJ銀行 本店営業部 (001)',
    receiverNameJa: '日本東洋物流株式会社',
    receiverAccount: 'JP00100003',
    receiverBank: '三菱UFJ銀行 丸の内支店 (020)',
    amount: 850_000_000, // 8.5億円
    currency: 'JPY',
    amountJPY: 850_000_000,
    network: 'ZENGIN',
    feeJPY: 0,
    lifecycleStatus: 'SETTLED',
    amlCheckStatus: 'PASSED',
    initiatedAt: '2026-09-12T08:30:15+09:00',
    settledAt: '2026-09-12T08:30:18+09:00',
    memoJa: '9月度 国際貨物取扱業務 委託料一括決済'
  },
  {
    id: 'pmt_002',
    paymentRef: 'SW-20260912-881902',
    senderNameJa: '日本東洋物流株式会社',
    senderAccount: 'JP00100003',
    senderBank: '三菱UFJ銀行',
    receiverNameJa: 'Rotterdam Terminal Logistics B.V.',
    receiverAccount: 'NL91ABNA0411823901',
    receiverBank: 'ABN AMRO Bank N.V. (Rotterdam)',
    amount: 4_200_000, // EUR 4.2M
    currency: 'EUR',
    amountJPY: 693_819_000,
    network: 'SWIFT',
    feeJPY: 4500,
    lifecycleStatus: 'SETTLED',
    amlCheckStatus: 'PASSED',
    initiatedAt: '2026-09-12T09:15:00+09:00',
    settledAt: '2026-09-12T09:18:22+09:00',
    memoJa: '欧州港湾ターミナルバース使用料・コンテナ保管料'
  }
];

// ==========================================
// 9. Synthetic AML & Sanctions Alerts
// ==========================================
export const SYNTHETIC_AML_ALERTS: AMLAlert[] = [
  {
    id: 'aml_001',
    alertCode: 'AML-20260912-0041',
    customerId: 'cust_corp_03',
    customerNameJa: '東京アセット株式会社',
    transactionRef: 'ZG-20260912-998877',
    amountJPY: 450_000_000,
    riskSeverity: 'HIGH',
    typologyJa: '急速な大口資金移動',
    detectionRuleCode: 'RULE-TM-RAPID-FLOW-09',
    aiExplanationJa: '口座開設後3ヶ月未満の関連会社へ、入金直後に4.5億円が複数回に分割して即日転送されています。資金移動元はオフショア信託であり、ペーパーカンパニー経由の資金洗浄リスクが疑われます。',
    aiRecommendedActionJa: '資金使途の契約書・不動産売買エビデンスの即時徴求、およびAML審査役による取引保留・ヒアリングを推奨。',
    humanDisposition: 'PENDING_REVIEW',
    assignedInvestigatorJa: '西村 俊樹 (コンプライアンス部 主任調査役)',
    requiresOfficerApproval: true,
    createdAt: '2026-09-12T09:45:00+09:00'
  },
  {
    id: 'aml_002',
    alertCode: 'AML-20260911-0028',
    customerId: 'cust_corp_02',
    customerNameJa: '日本東洋物流株式会社',
    transactionRef: 'SW-20260911-554433',
    amountJPY: 120_000_000,
    riskSeverity: 'MEDIUM',
    typologyJa: '制裁対象国・類似名照合',
    detectionRuleCode: 'RULE-SN-OFAC-EU-01',
    aiExplanationJa: '送金先船会社名がOFAC SDNリスト指定対象エンティティとスペル一致度84%を検知。照合調査の結果、別法人（シンガポール登記の正規パートナー）であることが確認されました。',
    aiRecommendedActionJa: '名寄せ確認調書を作成の上、フォールスポジティブとしてクローズ可能。',
    humanDisposition: 'FALSE_POSITIVE_DISMISSED',
    assignedInvestigatorJa: '高木 麻衣 (AML審査役)',
    decisionNotesJa: '法人登記簿謄本及び船荷証券(B/L)原本により、制裁対象外の別個法人と確認。',
    requiresOfficerApproval: true,
    createdAt: '2026-09-11T14:10:00+09:00',
    resolvedAt: '2026-09-11T16:20:00+09:00'
  }
];

// ==========================================
// 10. Synthetic Risk Exposures
// ==========================================
export const SYNTHETIC_RISK_EXPOSURES: RiskExposureMetric[] = [
  {
    id: 'risk_01',
    category: 'CreditRisk',
    nameJa: '大口与信集中度 (法人・総合信用リスク)',
    exposureAmountJPY: 124_600_000_000_000, // 124.6兆円
    limitAmountJPY: 150_000_000_000_000,
    utilizationPct: 83.07,
    status: 'NORMAL',
    var99_1d_JPY: 128_000_000_000,
    expectedShortfallJPY: 165_000_000_000,
    stressTestLossJPY: 620_000_000_000,
    ownerDepartmentJa: '審査部 / 信用リスク統括部',
    lastReviewedAt: '2026-09-10'
  },
  {
    id: 'risk_02',
    category: 'MarketRisk',
    nameJa: 'トレーディング勘定 市場リスク (VaR 99% 1日)',
    exposureAmountJPY: 42_500_000_000, // 425億円
    limitAmountJPY: 60_000_000_000,
    utilizationPct: 70.83,
    status: 'NORMAL',
    var99_1d_JPY: 42_500_000_000,
    expectedShortfallJPY: 56_000_000_000,
    stressTestLossJPY: 185_000_000_000,
    ownerDepartmentJa: '市場リスク統括部',
    lastReviewedAt: '2026-09-12'
  },
  {
    id: 'risk_03',
    category: 'LiquidityRisk',
    nameJa: '流動性リスク (LCRバッファー所要額比率)',
    exposureAmountJPY: 56_200_000_000_000,
    limitAmountJPY: 92_400_000_000_000, // HQLA Buffer
    utilizationPct: 60.82,
    status: 'NORMAL',
    ownerDepartmentJa: '財務企画部 / ALM・トレジャリー室',
    lastReviewedAt: '2026-09-12'
  },
  {
    id: 'risk_04',
    category: 'OperationalRisk',
    nameJa: 'オペレーショナル・サイバーリスク指標',
    exposureAmountJPY: 18_400_000_000,
    limitAmountJPY: 30_000_000_000,
    utilizationPct: 61.33,
    status: 'NORMAL',
    ownerDepartmentJa: 'オペレーショナルリスク統括室',
    lastReviewedAt: '2026-09-11'
  }
];

// ==========================================
// 11. Synthetic Immutable Audit Trail
// ==========================================
export const SYNTHETIC_AUDIT_LOGS: AuditLogRecord[] = [
  {
    id: 'aud_001',
    correlationId: 'corr-aud-20260912-001',
    timestamp: '2026-09-12T09:00:12+09:00',
    userId: 'USR-RM-8821',
    userNameJa: '佐藤 達也',
    role: 'Corporate Relationship Manager (法人RM)',
    ipAddress: '10.120.4.52 (MUFG Tokyo Head Office VPN)',
    deviceInfo: 'Apple iPad Pro 13-inch (iPadOS Enterprise 18.2 / MDM Enrolled)',
    action: 'CREDIT_ASSESSMENT_RUN',
    targetObject: 'Customer: CORP-JP-10029 (東都産業株式会社)',
    beforeStateJson: '{"rating": "2 (AA-)", "recommendedLimitJPY": 25000000000}',
    afterStateJson: '{"rating": "2 (AA-)", "recommendedLimitJPY": 28000000000, "score": 842, "pd": 0.0035}',
    reasonJa: '2026年度 中間決算好調に伴う与信枠増額事前シミュレーション実行',
    approvalStatus: 'OFFICER_APPROVED',
    isImmutableVerified: true
  },
  {
    id: 'aud_002',
    correlationId: 'corr-aud-20260912-002',
    timestamp: '2026-09-12T09:18:40+09:00',
    userId: 'USR-TRD-4109',
    userNameJa: '神崎 亮 (チーフ・ディーラー)',
    role: 'Global Markets Trader (為替・金利)',
    ipAddress: '10.120.88.11 (Dealing Room Subnet)',
    deviceInfo: 'MUFG Trading Workstation Pro',
    action: 'ORDER_EXECUTION',
    targetObject: 'Security: JGB10Y#375 (数量: 50億円)',
    beforeStateJson: '{"status": "VALIDATED"}',
    afterStateJson: '{"status": "EXECUTED", "executedPrice": 99.45, "yield": 1.055}',
    reasonJa: 'ALMポートフォリオ デュレーション調整目的のJGB買い付けオペレーション',
    approvalStatus: 'AUTO_AUTHORIZED',
    isImmutableVerified: true
  }
];
