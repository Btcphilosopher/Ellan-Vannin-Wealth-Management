/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// ==========================================
// 1. Group & Entity Models
// ==========================================
export type EntityType = 
  | 'HoldingCompany'
  | 'Bank'
  | 'TrustBank'
  | 'SecuritiesCompany'
  | 'AssetManagementCompany'
  | 'ConsumerFinanceCompany'
  | 'CreditCardCompany'
  | 'LeasingCompany'
  | 'InvestmentCompany'
  | 'ForeignSubsidiary';

export interface GroupEntity {
  id: string;
  name: string;
  nameEn: string;
  code: string;
  type: EntityType;
  jurisdiction: string;
  baseCurrency: string;
  totalAssetsJPY: number;
  totalEquityJPY: number;
  branchesCount: number;
  employeesCount: number;
  descriptionJa: string;
  status: 'ACTIVE' | 'RESTRICTED' | 'MAINTENANCE';
  role?: string;
  ownershipPct?: number;
  primaryRegulator?: string;
}

// ==========================================
// 2. Customer & KYC Models
// ==========================================
export type CustomerType = 'CORPORATE' | 'RETAIL' | 'WEALTH' | 'INSTITUTIONAL' | 'FINANCIAL_INSTITUTION' | 'HNW_INDIVIDUAL';

export interface Customer {
  id: string;
  customerCode: string;
  type?: CustomerType;
  customerType?: CustomerType;
  nameJa: string;
  nameKana?: string;
  nameEn?: string;
  entityId?: string;
  industryCategory?: string;
  creditRating?: string;
  riskScore?: number;
  kycStatus?: 'VERIFIED' | 'PENDING' | 'PERIODIC_REVIEW' | 'FLAGGED';
  amlRiskRating?: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  representativeJa?: string;
  capitalJPY?: number;
  annualRevenueJPY?: number;
  totalAssetsJPY?: number;
  totalLiabilitiesJPY?: number;
  relationshipManagerJa?: string;
  rmName?: string;
  rmDepartment?: string;
  contactEmail?: string;
  phone?: string;
  addressJa: string;
  beneficialOwners?: BeneficialOwner[];
  covenants?: string[];
  createdAt?: string;
  updatedAt?: string;
}

export interface BeneficialOwner {
  id: string;
  nameJa: string;
  title: string;
  shareholdingPct: number;
  pepStatus: boolean;
  sanctionClearance: boolean;
}

// ==========================================
// 3. Accounts & Balances
// ==========================================
export type AccountType = 
  | 'ORDINARY_DEPOSIT'
  | 'ORDINARY_SAVINGS'
  | 'TIME_DEPOSIT'
  | 'CURRENT_DEPOSIT'
  | 'MONEY_TRUST'
  | 'FOREIGN_CURRENCY_DEPOSIT'
  | 'SECURITIES_CUSTODY'
  | 'TRUST_CUSTODY'
  | 'LOAN_FACILITY'
  | 'TREASURY_NOSTRO'
  | 'SETTLEMENT_SUSPENSE';

export interface Account {
  id: string;
  accountNumber: string;
  customerId?: string;
  entityId?: string;
  accountType: AccountType | string;
  currency: string;
  balance: number;
  availableBalance?: number;
  holdAmount?: number;
  interestRatePct?: number;
  status: 'ACTIVE' | 'FROZEN' | 'DORMANT' | 'CLOSED';
  branchCode?: string;
  branchName: string;
  openedDate?: string;
  lastActivityDate?: string;
}

// ==========================================
// 4. Commercial & Credit Models
// ==========================================
export interface CreditAssessmentInput {
  customerId: string;
  annualRevenueJPY: number;
  operatingIncomeJPY: number;
  ebitdaJPY: number;
  netIncomeJPY: number;
  totalAssetsJPY: number;
  netAssetsJPY: number;
  interestBearingDebtJPY: number;
  cashAndEquivalentsJPY: number;
  freeCashFlowJPY: number;
  collateralValueJPY: number;
  guaranteeType?: string;
  industryRiskTier?: 'LOW' | 'MEDIUM' | 'HIGH';
  existingDelinquency?: boolean;
  modelCode?: string;
}

export interface CreditAssessmentResult {
  assessmentId: string;
  customerId: string;
  modelCode: string;
  modelVersion: string;
  creditScore: number;
  pd: number;
  lgd: number;
  ead: number;
  expectedLossJPY: number;
  riskGrade: string;
  internalRatingDescriptionJa: string;
  dscr: number;
  debtToEbitda: number;
  ltvPct: number;
  icr: number;
  maxCreditLimitJPY: number;
  recommendedSpreadBps: number;
  approvalAuthorityLevel: 'BRANCH_MANAGER' | 'CREDIT_COMMITTEE' | 'BOARD_OF_DIRECTORS';
  covenantRecommendations: string[];
  evaluatedAt: string;
}

export interface LoanFacility {
  id: string;
  facilityCode?: string;
  facilityNumber?: string;
  customerId?: string;
  borrowerNameJa?: string;
  entityId?: string;
  facilityType: string;
  committedLimitJPY?: number;
  commitmentLimitJPY?: number;
  drawnAmountJPY?: number;
  outstandingPrincipalJPY?: number;
  undrawnAmountJPY?: number;
  currency?: string;
  baseRateType?: string;
  baseRateIndex?: string;
  baseRatePct?: number;
  currentInterestRatePct?: number;
  spreadBps?: number;
  effectiveRatePct?: number;
  dayCountFraction?: string;
  startDate?: string;
  maturityDate: string;
  amortizationType?: string;
  collateralDescriptionJa?: string;
  collateralValueJPY?: number;
  status?: string;
  facilityStatus?: string;
  leadArranger?: string;
  covenants?: string[];
}

// ==========================================
// 5. Global Markets & Securities
// ==========================================
export type SecurityType = 'JGB' | 'EQUITY' | 'CORP_BOND' | 'ETF' | 'MUTUAL_FUND' | 'DERIVATIVE_OPTION' | 'FX_SWAP';

export interface Security {
  id: string;
  isin: string;
  ticker?: string;
  nameJa: string;
  nameEn?: string;
  type?: SecurityType;
  assetClass?: string;
  currency: string;
  currentPrice?: number;
  marketPrice?: number;
  dayChangePct?: number;
  yieldToMaturityPct?: number;
  couponRatePct?: number;
  couponPct?: number;
  maturityDate?: string;
  issuerJa?: string;
  creditRating?: string;
  outstandingAmountJPY?: number;
}

export type SecurityInstrument = Security;

export interface MarketOrder {
  id: string;
  orderNumber: string;
  customerId?: string;
  entityId?: string;
  securityId?: string;
  securityNameJa?: string;
  side: 'BUY' | 'SELL';
  orderType: 'LIMIT' | 'MARKET' | 'STOP';
  quantity: number;
  limitPrice?: number;
  executedPrice?: number;
  executedQuantity?: number;
  currency: string;
  orderStatus?: string;
  status?: string;
  settlementDate?: string;
  clearingHouse?: string;
  traderId?: string;
  desk?: string;
  timestamp?: string;
}

export interface FXRate {
  pair: string;
  spotRate?: number;
  bid?: number;
  bidRate?: number;
  ask?: number;
  askRate?: number;
  mid?: number;
  high?: number;
  low?: number;
  change24hPct?: number;
  tenor?: string;
  descriptionJa?: string;
  updatedAt?: string;
}

export type FxRate = FXRate;

// ==========================================
// 6. Treasury & ALM
// ==========================================
export interface AlmBucketGap {
  bucketId?: string;
  bucketNameJa?: string;
  tenor: string;
  assetAmountJPY: number;
  liabilityAmountJPY: number;
  netGapJPY: number;
  cumulativeGapJPY: number;
  interestRateSensitivityBps?: number;
  pv01JPY: number;
}

export interface TreasuryPosition {
  id?: string;
  entityId?: string;
  totalCashReservesJPY: number;
  bojCurrentAccountBalanceJPY: number;
  hqlBufferJPY: number;
  lcrRatioPct: number;
  nsfrRatioPct: number;
  survivalHorizonDays: number;
  fundingCostAvgPct?: number;
  totalDepositsJPY: number;
  totalLoansJPY: number;
  loanToDepositRatioPct?: number;
  cet1CapitalRatioPct?: number;
  tier1CapitalRatioPct?: number;
  totalCapitalRatioPct?: number;
}

// ==========================================
// 7. Double-Entry Accounting & Ledger
// ==========================================
export interface JournalLine {
  id: string;
  accountCode: string;
  accountNameJa: string;
  debitJPY: number;
  creditJPY: number;
  currency: string;
  originalAmount: number;
  descriptionJa: string;
}

export interface JournalEntry {
  id: string;
  entryNumber: string;
  entityId: string;
  transactionType: string;
  postingDate: string;
  valueDate: string;
  lines: JournalLine[];
  totalDebitJPY: number;
  totalCreditJPY: number;
  isBalanced: boolean;
  status: 'POSTED' | 'REVERSED' | 'PENDING_APPROVAL';
  createdBy: string;
  approvedBy?: string;
  sourceModule: string;
  correlationId: string;
}

// ==========================================
// 8. Reconciliation
// ==========================================
export interface ReconciliationCase {
  id: string;
  caseNumber: string;
  sourceSystemA?: string;
  sourceSystemB?: string;
  externalSource?: string;
  accountNameJa?: string;
  internalLedgerAmountJPY?: number;
  externalStatementAmountJPY?: number;
  discrepancyJPY?: number;
  reconciliationStatus?: string;
  accountOrRef?: string;
  currency?: string;
  systemABalance?: number;
  systemBBalance?: number;
  variance?: number;
  status?: string;
  breakReasonJa?: string;
  assignedOfficerJa?: string;
  identifiedAt?: string;
  resolvedAt?: string;
}

// ==========================================
// 9. Payments & Settlement
// ==========================================
export interface PaymentOrder {
  id: string;
  paymentRef?: string;
  referenceNumber?: string;
  senderNameJa: string;
  senderAccount?: string;
  senderAccountNumber?: string;
  senderBank?: string;
  receiverNameJa: string;
  receiverAccount?: string;
  receiverBank?: string;
  receiverBankNameJa?: string;
  amount: number;
  currency: string;
  amountJPY?: number;
  clearingNetwork?: string;
  network?: string;
  feeJPY?: number;
  status?: string;
  lifecycleStatus?: string;
  amlScreeningStatus?: string;
  amlCheckStatus?: string;
  initiatedAt?: string;
  settledAt?: string;
  memoJa?: string;
}

export type PaymentTransaction = PaymentOrder;

// ==========================================
// 10. AML, Sanctions & Compliance
// ==========================================
export interface AMLAlert {
  id: string;
  alertNumber?: string;
  alertCode?: string;
  customerId: string;
  customerNameJa: string;
  transactionRef?: string;
  transactionAmountJPY?: number;
  amountJPY?: number;
  severity?: string;
  riskSeverity?: string;
  riskScore?: number;
  scenarioTypeJa?: string;
  typologyJa?: string;
  descriptionJa?: string;
  detectionRuleCode?: string;
  aiExplanationJa?: string;
  aiRecommendedActionJa?: string;
  humanDisposition: string;
  assignedInvestigatorJa: string;
  decisionNotesJa?: string;
  requiresOfficerApproval?: boolean;
  triggeredAt?: string;
  createdAt?: string;
  resolvedAt?: string;
}

// ==========================================
// 11. Risk Management OS
// ==========================================
export type RiskCategory = 
  | 'CreditRisk'
  | 'MarketRisk'
  | 'LiquidityRisk'
  | 'InterestRateRisk'
  | 'FXRisk'
  | 'CounterpartyRisk'
  | 'OperationalRisk'
  | 'ModelRisk'
  | 'CyberRisk'
  | 'ConcentrationRisk'
  | 'CountryRisk'
  | string;

export interface RiskExposureMetric {
  id: string;
  category: RiskCategory;
  nameJa: string;
  exposureAmountJPY: number;
  limitAmountJPY: number;
  utilizationPct: number;
  status: 'NORMAL' | 'WARNING' | 'BREACH';
  var99_1d_JPY?: number;
  expectedShortfallJPY?: number;
  stressTestLossJPY?: number;
  ownerDepartmentJa: string;
  lastReviewedAt?: string;
  mitigationPlanJa?: string;
}

// ==========================================
// 12. Audit & Governance
// ==========================================
export interface AuditLogRecord {
  id: string;
  correlationId: string;
  timestamp: string;
  userId: string;
  userNameJa: string;
  role: string;
  ipAddress: string;
  deviceInfo: string;
  action: string;
  targetObject: string;
  beforeStateJson?: string;
  afterStateJson?: string;
  reasonJa: string;
  approvalStatus: 'AUTO_AUTHORIZED' | 'OFFICER_APPROVED' | 'PENDING' | 'REJECTED';
  isImmutableVerified: boolean;
}

export type AuditLogEntry = AuditLogRecord;
