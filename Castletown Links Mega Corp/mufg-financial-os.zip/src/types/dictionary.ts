/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface FinancialTerm {
  id: string;
  termJa: string;
  kana: string;
  romaji: string;
  termEn: string;
  categoryJa: string;
  definitionJa: string;
  aliases: string[];
  canonicalEntity: string;
  regulatoryReference?: string;
}
