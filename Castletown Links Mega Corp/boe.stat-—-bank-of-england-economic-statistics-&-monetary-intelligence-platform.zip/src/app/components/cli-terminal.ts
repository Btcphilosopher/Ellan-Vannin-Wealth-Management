import { ChangeDetectionStrategy, Component, ElementRef, OnInit, ViewChild, inject, output, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { BoeDataService } from '../services/boe-data';
import { YieldCurveEngineService } from '../services/yield-curve-engine';

interface TerminalLine {
  type: 'COMMAND' | 'OUTPUT' | 'ERROR' | 'SYSTEM';
  text: string;
}

@Component({
  selector: 'app-cli-terminal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4" role="dialog" aria-modal="true">
      <div class="bg-slate-950 border border-slate-700 w-full max-w-4xl h-[75vh] flex flex-col shadow-2xl font-mono text-xs">
        
        <!-- Terminal Header -->
        <div class="bg-slate-900 px-4 py-2 border-b border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-2">
            <span class="w-3 h-3 bg-red-500/80 rounded-full inline-block"></span>
            <span class="w-3 h-3 bg-amber-500/80 rounded-full inline-block"></span>
            <span class="w-3 h-3 bg-emerald-500/80 rounded-full inline-block"></span>
            <span class="text-slate-300 font-bold ml-2">boestat CLI — Bank of England Analytical Workstation Terminal (Rust x86_64)</span>
          </div>
          <button 
            type="button" 
            (click)="dismissModal.emit()" 
            class="text-slate-400 hover:text-slate-100 cursor-pointer"
            aria-label="Close terminal"
          >
            <mat-icon class="text-sm">close</mat-icon>
          </button>
        </div>

        <!-- Terminal Output Stream -->
        <div #terminalBody class="flex-1 p-4 overflow-y-auto space-y-1.5 text-slate-300 selection:bg-amber-500/30">
          @for (line of lines(); track $index) {
            @if (line.type === 'COMMAND') {
              <div class="flex items-center gap-2 text-amber-400 font-bold">
                <span class="text-slate-500">boe-stat@london-core:~$</span>
                <span>{{ line.text }}</span>
              </div>
            } @else if (line.type === 'ERROR') {
              <div class="text-red-400 pl-4 whitespace-pre-wrap">{{ line.text }}</div>
            } @else if (line.type === 'SYSTEM') {
              <div class="text-emerald-400 pl-4 whitespace-pre-wrap font-semibold">{{ line.text }}</div>
            } @else {
              <div class="text-slate-300 pl-4 whitespace-pre-wrap">{{ line.text }}</div>
            }
          }
        </div>

        <!-- Terminal Input Prompt -->
        <div class="bg-slate-900/90 px-4 py-2.5 border-t border-slate-800 flex items-center gap-2">
          <span class="text-amber-400 font-bold">boe-stat@london-core:~$</span>
          <input 
            #commandInput
            type="text"
            [value]="currentInput()"
            (input)="currentInput.set($any($event.target).value)"
            (keydown.enter)="executeCommand()"
            placeholder="Type 'help', 'boestat series search cpi', 'boestat curve gilt'..."
            class="bg-transparent border-none outline-none text-slate-100 placeholder-slate-600 flex-1 font-mono text-xs"
          />
          <button type="button" (click)="executeCommand()" class="px-3 py-1 bg-amber-600/30 border border-amber-500/50 text-amber-300 uppercase hover:bg-amber-600/50 cursor-pointer">Run</button>
        </div>

      </div>
    </div>
  `,
})
export class CliTerminalComponent implements OnInit {
  dismissModal = output<void>();
  @ViewChild('terminalBody') terminalBody!: ElementRef<HTMLDivElement>;
  @ViewChild('commandInput') commandInput!: ElementRef<HTMLInputElement>;

  private boeData = inject(BoeDataService);
  private yieldCurveEngine = inject(YieldCurveEngineService);

  currentInput = signal<string>('');
  lines = signal<TerminalLine[]>([
    { type: 'SYSTEM', text: 'BOE.STAT High-Performance Core Engine v4.2.0-RELEASE (Rust stable 1.81.0)' },
    { type: 'SYSTEM', text: 'Connected to Authoritative Columnar Parquet Fabric // Node ID: LON-DC1-PROD' },
    { type: 'OUTPUT', text: 'Type "help" for a list of available central-bank CLI commands.' },
    { type: 'OUTPUT', text: 'Try: boestat curve gilt --date 2026-09-30' },
  ]);

  ngOnInit() {
    setTimeout(() => {
      this.commandInput?.nativeElement?.focus();
    }, 50);
  }

  executeCommand() {
    const rawCmd = this.currentInput().trim();
    if (!rawCmd) return;

    this.lines.update((l) => [...l, { type: 'COMMAND', text: rawCmd }]);
    this.currentInput.set('');

    const cmd = rawCmd.toLowerCase();

    if (cmd === 'help') {
      this.lines.update((l) => [
        ...l,
        {
          type: 'OUTPUT',
          text: `AVAILABLE BOE.STAT CLI COMMANDS:
  boestat series search <term>          - Search master series catalog
  boestat series show <id>              - Inspect metadata, latest value & provenance
  boestat curve gilt [--date <YYYY-MM-DD>] - Display full UK Gilt zero-coupon curve
  boestat curve ois                     - Display SONIA OIS curve
  boestat fx <pair>                     - Display FX spot, volatility, carry & REER
  boestat inflation dashboard           - Headline CPI, Core, Services and expectations
  boestat vintage compare <id>          - Show historical revision triangle
  boestat model run <spec>              - Execute econometric estimation
  boestat audit verify                  - Cryptographically verify SHA-256 ledger
  clear                                 - Clear terminal screen`,
        },
      ]);
    } else if (cmd === 'clear') {
      this.lines.set([]);
    } else if (cmd.startsWith('boestat series search')) {
      const term = rawCmd.split(' ').slice(3).join(' ').replace(/['"]/g, '');
      const results = this.boeData.seriesCatalog.filter(
        (s) => s.id.toLowerCase().includes(term.toLowerCase()) || s.name.toLowerCase().includes(term.toLowerCase())
      );
      this.lines.update((l) => [
        ...l,
        {
          type: 'OUTPUT',
          text: `MATCHED SERIES (${results.length} found):\n` +
            results.map((r) => `  [${r.id}] ${r.name} -> ${r.latestValue} ${r.unit} (${r.provenance.source})`).join('\n'),
        },
      ]);
    } else if (cmd.startsWith('boestat series show')) {
      const id = rawCmd.split(' ')[3];
      const series = this.boeData.getSeriesById(id);
      if (series) {
        this.lines.update((l) => [
          ...l,
          {
            type: 'OUTPUT',
            text: `SERIES IDENTIFIER: ${series.id}
Name:         ${series.name}
Category:     ${series.category}
Frequency:    ${series.frequency} [${series.seasonalAdjustment}]
Latest Value: ${series.latestValue} ${series.unit} (Obs: ${series.lastObservation})
Provenance:   ${series.provenance.source} // ${series.provenance.methodology}
Quality:      ${series.qualityScore}/100 [${series.qualityFlags.join(', ')}]
Classification: ${series.classification}`,
          },
        ]);
      } else {
        this.lines.update((l) => [...l, { type: 'ERROR', text: `Error: Series "${id}" not found in canonical store.` }]);
      }
    } else if (cmd.startsWith('boestat curve gilt')) {
      const data = this.boeData.yieldCurveData;
      const table = data.map((d) => `  ${d.tenor.padEnd(5)} | Nom: ${d.nominalYield.toFixed(2)}% | Real: ${d.realYield.toFixed(2)}% | Breakeven: ${d.breakevenInflation.toFixed(2)}% | 1D: ${d.change1D >= 0 ? '+' : ''}${d.change1D}bp`).join('\n');
      this.lines.update((l) => [
        ...l,
        {
          type: 'OUTPUT',
          text: `UK GILT ZERO-COUPON YIELD CURVE (Fitted Nelson-Siegel-Svensson) [2026-09-30]\n${table}\n\nMetrics: 10Y Level = 3.92% | 2Y-10Y Slope = +6.0bp | 5Y-30Y Slope = +68.0bp`,
        },
      ]);
    } else if (cmd.startsWith('boestat curve ois')) {
      const data = this.boeData.yieldCurveData;
      const table = data.map((d) => `  ${d.tenor.padEnd(5)} | SONIA OIS: ${d.oisYield.toFixed(2)}% | Forward: ${d.oneYearForward.toFixed(2)}%`).join('\n');
      this.lines.update((l) => [
        ...l,
        {
          type: 'OUTPUT',
          text: `SONIA OIS CURVE (Daily Money Market Collection Form SMMD)\n${table}`,
        },
      ]);
    } else if (cmd.startsWith('boestat fx')) {
      const pair = rawCmd.split(' ')[2]?.toUpperCase() || 'GBP/USD';
      const cross = this.boeData.fxCrosses.find((f) => f.pair.replace('/', '') === pair.replace('/', '') || f.pair === pair);
      if (cross) {
        this.lines.update((l) => [
          ...l,
          {
            type: 'OUTPUT',
            text: `STERLING FX SPOT: ${cross.pair}
Spot Rate:     ${cross.spot}
1D Change:     ${cross.change1D >= 0 ? '+' : ''}${cross.change1D}%
1M Change:     ${cross.change1M >= 0 ? '+' : ''}${cross.change1M}%
1Y Change:     ${cross.change1Y >= 0 ? '+' : ''}${cross.change1Y}%
30D Volatility: ${cross.volatility30D}%
REER Index:    ${cross.reerIndex}
PPP Valuation: ${cross.pppValuationPct >= 0 ? '+' : ''}${cross.pppValuationPct}%`,
          },
        ]);
      } else {
        this.lines.update((l) => [...l, { type: 'ERROR', text: `Error: FX Pair "${pair}" not found.` }]);
      }
    } else if (cmd.startsWith('boestat inflation')) {
      const infl = this.boeData.inflationDecomposition;
      this.lines.update((l) => [
        ...l,
        {
          type: 'OUTPUT',
          text: `UK INFLATION OVERVIEW (${infl.date})
Headline CPI:  ${infl.headlineCpi}% YoY
Core CPI:      ${infl.coreCpi}% YoY
Services CPI:  ${infl.services}% YoY (Domestic persistence)
Goods CPI:     ${infl.goods}% YoY
Energy:        ${infl.energy}% YoY
Food:          ${infl.food}% YoY
3M Momentum:   ${infl.momentum3mAnnualised}% (Annualised)
Trimmed Mean:  ${infl.trimmedMean15}%`,
        },
      ]);
    } else if (cmd.startsWith('boestat audit verify')) {
      this.lines.update((l) => [
        ...l,
        {
          type: 'SYSTEM',
          text: `[AUDIT ENGINE] Running cryptographic SHA-256 hash-chain verification...
Verified 11,840 series observation blocks.
Ledger Root Hash: e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855
Latest Block Hash: 9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08
INTEGRITY STATUS: 100% VERIFIED // ZERO TAMPERING DETECTED`,
        },
      ]);
    } else {
      this.lines.update((l) => [
        ...l,
        {
          type: 'ERROR',
          text: `Command not recognized: "${rawCmd}". Type "help" for available commands.`,
        },
      ]);
    }

    setTimeout(() => {
      if (this.terminalBody) {
        this.terminalBody.nativeElement.scrollTop = this.terminalBody.nativeElement.scrollHeight;
      }
    }, 10);
  }
}
