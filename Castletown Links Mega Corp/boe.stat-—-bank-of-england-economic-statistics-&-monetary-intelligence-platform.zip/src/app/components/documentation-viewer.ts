import { ChangeDetectionStrategy, Component, output, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-documentation-viewer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4" role="dialog" aria-modal="true">
      <div class="bg-slate-900 border border-slate-700 w-full max-w-5xl h-[85vh] flex flex-col shadow-2xl overflow-hidden">
        
        <!-- Header -->
        <div class="bg-slate-950 px-6 py-3 border-b border-slate-800 flex items-center justify-between">
          <div class="flex items-center gap-3">
            <mat-icon class="text-amber-400">menu_book</mat-icon>
            <div>
              <div class="text-[10px] font-mono text-amber-400 uppercase tracking-wider font-bold">Bank of England // Technical Architecture & Standards</div>
              <h2 class="text-base font-serif font-bold text-slate-100">Institutional Documentation Suite</h2>
            </div>
          </div>
          <button 
            type="button" 
            (click)="dismissModal.emit()" 
            class="text-slate-400 hover:text-slate-100 cursor-pointer"
            aria-label="Close documentation viewer"
          >
            <mat-icon>close</mat-icon>
          </button>
        </div>

        <div class="flex-1 flex overflow-hidden">
          <!-- Sidebar Nav of Documents -->
          <div class="w-64 bg-slate-950/80 border-r border-slate-800 p-3 overflow-y-auto space-y-1 text-xs font-mono">
            <div class="text-[10px] text-slate-500 uppercase px-2 py-1 font-bold">Architecture & Governance</div>
            @for (doc of docs; track doc.id) {
              <button
                type="button"
                (click)="activeDocId.set(doc.id)"
                [class.bg-amber-950/40]="activeDocId() === doc.id"
                [class.text-amber-300]="activeDocId() === doc.id"
                [class.border-amber-500/50]="activeDocId() === doc.id"
                class="w-full text-left px-3 py-2 border border-transparent hover:border-slate-700 hover:bg-slate-900 text-slate-300 flex items-center justify-between transition cursor-pointer"
              >
                <span>{{ doc.title }}</span>
                <mat-icon class="text-xs">chevron_right</mat-icon>
              </button>
            }
          </div>

          <!-- Document Viewer Area -->
          <div class="flex-1 p-6 overflow-y-auto bg-slate-900/60 font-sans text-sm text-slate-300 space-y-4 leading-relaxed">
            @for (doc of docs; track doc.id) {
              @if (activeDocId() === doc.id) {
                <div class="border-b border-slate-800 pb-3 mb-4">
                  <span class="text-[10px] font-mono px-2 py-0.5 bg-slate-800 text-amber-400 uppercase">{{ doc.category }}</span>
                  <h1 class="text-xl font-serif font-bold text-slate-100 mt-2">{{ doc.title }}</h1>
                  <div class="text-xs font-mono text-slate-500 mt-1">Classification: {{ doc.classification }} // Version: {{ doc.version }} // Verified: {{ doc.date }}</div>
                </div>

                <div class="prose prose-invert max-w-none text-xs leading-relaxed space-y-4 font-sans" [innerHTML]="doc.contentHtml"></div>
              }
            }
          </div>
        </div>

        <!-- Footer -->
        <div class="bg-slate-950 px-6 py-2.5 border-t border-slate-800 flex justify-between items-center text-[10px] font-mono text-slate-400">
          <span>GOVERNING PRINCIPLE: ONE DATA FABRIC // EVERY NUMBER TRACEABLE TO ITS SOURCE</span>
          <button type="button" (click)="dismissModal.emit()" class="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 uppercase cursor-pointer">Close</button>
        </div>

      </div>
    </div>
  `,
})
export class DocumentationViewerComponent {
  dismissModal = output<void>();
  activeDocId = signal<string>('ARCHITECTURE');

  readonly docs = [
    {
      id: 'ARCHITECTURE',
      title: 'ARCHITECTURE.md',
      category: 'System Design',
      classification: 'OFFICIAL SENSITIVE',
      version: '4.2.0',
      date: '2026-09-30',
      contentHtml: `
        <h3 class="text-sm font-bold text-amber-300 font-mono">1. ONE DATA FABRIC ARCHITECTURE</h3>
        <p>BOE.STAT is engineered on a multi-language, high-performance central banking stack:</p>
        <ul class="list-disc pl-5 space-y-1 font-mono text-[11px] text-slate-300">
          <li><strong>Rust Ingestion & Validation Core:</strong> Tokio asynchronous runtime, Apache Arrow columnar memory interchange, Parquet analytical storage.</li>
          <li><strong>Canonical Series Store:</strong> PostgreSQL transactional metadata with immutable revision tables.</li>
          <li><strong>Quantitative Laboratory:</strong> R <code>boestatR</code> package supporting VAR, SVAR, state-space Kalman filters, and cointegration.</li>
          <li><strong>Institutional Terminal:</strong> Ultra-dense analytical workstation adhering to British institutional typography and mathematical precision.</li>
        </ul>
        <h3 class="text-sm font-bold text-amber-300 font-mono mt-4">2. DATA PROVENANCE PIPELINE</h3>
        <p>Every observation records its raw source identity, ingestion timestamp, mathematical methodology, revision number, and cryptographic signature.</p>
      `,
    },
    {
      id: 'NUMERICAL_INTEGRITY',
      title: 'NUMERICAL_INTEGRITY.md',
      category: 'Mathematical Standards',
      classification: 'PUBLIC',
      version: '2.1.0',
      date: '2026-09-30',
      contentHtml: `
        <h3 class="text-sm font-bold text-amber-300 font-mono">STRICT NUMERICAL CONVENTIONS</h3>
        <p>Central bank integrity forbids ambiguous reporting:</p>
        <ul class="list-disc pl-5 space-y-1 font-mono text-[11px] text-slate-300">
          <li><strong>Quoted vs Compounded Rates:</strong> BoE published zero curves are continuous Nelson-Siegel-Svensson estimates quoted on an annually compounded basis.</li>
          <li><strong>Percentage vs Basis Points:</strong> Changes in yields, interest rates, and spreads are strictly denominated in basis points (bp), never ambiguous percentages.</li>
          <li><strong>Seasonal Adjustment:</strong> SA and NSA series are never mingled in expressions without explicit transformation tags.</li>
          <li><strong>Fisher Decomposition:</strong> Breakeven inflation is strictly derived as <code>(1 + y_nom) / (1 + y_real) - 1</code>, not simple subtraction.</li>
        </ul>
      `,
    },
    {
      id: 'YIELD_CURVES',
      title: 'YIELD_CURVES.md',
      category: 'Term Structure',
      classification: 'PUBLIC',
      version: '3.4.0',
      date: '2026-09-30',
      contentHtml: `
        <h3 class="text-sm font-bold text-amber-300 font-mono">NELSON-SIEGEL-SVENSSON (NSS) ESTIMATION</h3>
        <p>The Bank of England fits nominal and real zero-coupon curves using the extended 6-parameter NSS model:</p>
        <pre class="bg-slate-950 p-2.5 border border-slate-800 text-[11px] text-amber-400 font-mono">
y(m) = beta0 + beta1 * ((1 - exp(-m/tau1))/(m/tau1))
             + beta2 * (((1 - exp(-m/tau1))/(m/tau1)) - exp(-m/tau1))
             + beta3 * (((1 - exp(-m/tau2))/(m/tau2)) - exp(-m/tau2))
        </pre>
        <p>Instantaneous forward rates are computed analytically from the derivative of total yield revenue.</p>
      `,
    },
    {
      id: 'VINTAGES',
      title: 'VINTAGES.md',
      category: 'Revision Accounting',
      classification: 'PUBLIC',
      version: '1.8.0',
      date: '2026-09-30',
      contentHtml: `
        <h3 class="text-sm font-bold text-amber-300 font-mono">ECONOMIC TIME MACHINE & REVISION TRIANGLES</h3>
        <p>Economic statistics are repeatedly revised as more complete data arrives:</p>
        <ul class="list-disc pl-5 space-y-1 font-mono text-[11px] text-slate-300">
          <li><strong>First Estimate (Flash):</strong> High timeliness, provisional survey sample.</li>
          <li><strong>Quarterly National Accounts:</strong> Incorporates VAT returns and comprehensive trade figures.</li>
          <li><strong>Blue Book Benchmark:</strong> Annual supply-and-use balancing and methodological updates.</li>
        </ul>
        <p>BOE.STAT maintains the full revision triangle matrix allowing exact reconstruction of what policymakers knew at any historical MPC meeting.</p>
      `,
    },
    {
      id: 'DATA_GOVERNANCE',
      title: 'DATA_GOVERNANCE.md',
      category: 'Security & Audit',
      classification: 'RESTRICTED',
      version: '5.0.0',
      date: '2026-09-30',
      contentHtml: `
        <h3 class="text-sm font-bold text-amber-300 font-mono">IMMUTABLE CRYPTOGRAPHIC LEDGER</h3>
        <p>All queries, model executions, data modifications, and role transitions are recorded into an append-only SHA-256 hash chain.</p>
        <p>Role-Based Access Control enforces strict separation between <code>STATISTICIAN</code> (can submit revisions), <code>ECONOMIST</code> (models & briefings), and <code>AUDITOR</code> (read-only verification).</p>
      `,
    },
  ];
}
