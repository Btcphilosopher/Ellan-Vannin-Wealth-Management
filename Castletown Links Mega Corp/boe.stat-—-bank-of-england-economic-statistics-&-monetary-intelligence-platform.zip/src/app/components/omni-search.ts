import { ChangeDetectionStrategy, Component, ElementRef, OnInit, ViewChild, input, output, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { SeriesMetadata } from '../models/boe.types';

@Component({
  selector: 'app-omni-search',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="fixed inset-0 z-50 flex items-start justify-center bg-slate-950/80 backdrop-blur-sm p-4 pt-20" role="dialog" aria-modal="true">
      <div class="bg-slate-900 border border-slate-700 w-full max-w-2xl shadow-2xl flex flex-col overflow-hidden">
        
        <!-- Search Input Bar -->
        <div class="bg-slate-950 px-4 py-3 border-b border-slate-800 flex items-center gap-3">
          <mat-icon class="text-amber-400">search</mat-icon>
          <input 
            #searchInput
            type="text"
            [value]="searchQuery()"
            (input)="onSearchInput($event)"
            placeholder="Search economic series, identifiers (e.g. GB.CPI.ALL), or commands..."
            class="bg-transparent border-none outline-none text-slate-100 placeholder-slate-400 w-full text-sm font-mono"
          />
          <button type="button" (click)="dismissModal.emit()" class="text-[10px] font-mono px-2 py-0.5 bg-slate-800 text-slate-400 border border-slate-700 hover:text-slate-200 cursor-pointer">ESC TO CLOSE</button>
        </div>

        <!-- Quick Filters -->
        <div class="px-4 py-2 bg-slate-950/40 border-b border-slate-800/80 flex items-center gap-2 overflow-x-auto text-xs font-mono">
          <span class="text-slate-400 text-[10px] uppercase">Quick Jumps:</span>
          <button type="button" (click)="setFilter('YIELD_CURVES')" class="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer">#YIELDS</button>
          <button type="button" (click)="setFilter('INFLATION')" class="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer">#INFLATION</button>
          <button type="button" (click)="setFilter('RATES')" class="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer">#RATES</button>
          <button type="button" (click)="setFilter('FX')" class="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer">#FX</button>
          <button type="button" (click)="setFilter('ECONOMY')" class="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-300 cursor-pointer">#ECONOMY</button>
        </div>

        <!-- Results List -->
        <div class="max-h-96 overflow-y-auto p-2 space-y-1">
          @for (series of filteredResults(); track series.id) {
            <button 
              type="button"
              (click)="selectSeries(series)"
              class="w-full text-left px-3 py-2.5 bg-slate-950/40 hover:bg-amber-950/30 border border-slate-800/60 hover:border-amber-500/40 cursor-pointer flex items-center justify-between group transition"
            >
              <div class="flex-1 pr-4">
                <div class="flex items-center gap-2 mb-0.5">
                  <span class="text-[10px] font-mono font-bold text-amber-400">{{ series.id }}</span>
                  <span class="text-[9px] font-mono px-1 py-0.2 bg-slate-800 text-slate-400">{{ series.frequency }}</span>
                  <span class="text-[9px] font-mono px-1 py-0.2 bg-emerald-950 text-emerald-400">{{ series.provenance.source }}</span>
                </div>
                <div class="text-xs font-semibold text-slate-200 group-hover:text-amber-200">{{ series.name }}</div>
                <div class="text-[11px] text-slate-400 line-clamp-1 mt-0.5">{{ series.description }}</div>
              </div>
              
              <div class="text-right font-mono">
                <div class="text-sm font-bold text-slate-100">{{ series.latestValue }} {{ series.unit }}</div>
                <div class="text-[10px] text-slate-400">Obs: {{ series.lastObservation }}</div>
              </div>
            </button>
          } @empty {
            <div class="p-8 text-center text-slate-400 font-mono text-xs">
              No matching economic series or identifiers found for "{{ searchQuery() }}".
            </div>
          }
        </div>

        <!-- Footer -->
        <div class="px-4 py-2 bg-slate-950 border-t border-slate-800 text-[10px] font-mono text-slate-400 flex justify-between">
          <span>{{ filteredResults().length }} SERIES MATCHED</span>
          <span>SELECT TO INSPECT TIME SERIES // TRACE PROVENANCE</span>
        </div>

      </div>
    </div>
  `,
})
export class OmniSearchComponent implements OnInit {
  catalog = input<SeriesMetadata[]>([]);
  seriesSelected = output<SeriesMetadata>();
  dismissModal = output<void>();

  @ViewChild('searchInput') searchInput!: ElementRef<HTMLInputElement>;
  searchQuery = signal<string>('');

  ngOnInit() {
    setTimeout(() => {
      this.searchInput?.nativeElement?.focus();
    }, 50);
  }

  onSearchInput(event: Event) {
    const val = (event.target as HTMLInputElement).value;
    this.searchQuery.set(val);
  }

  setFilter(filterText: string) {
    this.searchQuery.set(filterText);
  }

  filteredResults(): SeriesMetadata[] {
    const q = this.searchQuery().toLowerCase().trim();
    const list = this.catalog();
    if (!q) return list;

    return list.filter((s) => 
      s.id.toLowerCase().includes(q) ||
      s.name.toLowerCase().includes(q) ||
      s.category.toLowerCase().includes(q) ||
      s.aliases.some((a) => a.toLowerCase().includes(q)) ||
      s.description.toLowerCase().includes(q) ||
      s.provenance.source.toLowerCase().includes(q)
    );
  }

  selectSeries(series: SeriesMetadata) {
    this.seriesSelected.emit(series);
  }
}
