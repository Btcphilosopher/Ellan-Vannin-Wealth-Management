import { ChangeDetectionStrategy, Component, input, output } from '@angular/core';
import { KeyValuePipe } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DataLineageNode } from '../models/boe.types';

@Component({
  selector: 'app-lineage-modal',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, KeyValuePipe],
  template: `
    <div class="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4 animate-fade-in" role="dialog" aria-modal="true">
      <div class="bg-slate-900 border border-slate-700 w-full max-w-4xl max-h-[90vh] flex flex-col shadow-2xl overflow-hidden rounded-none">
        
        <!-- Header -->
        <div class="bg-slate-950 border-b border-slate-800 px-6 py-4 flex items-center justify-between">
          <div class="flex items-center gap-3">
            <div class="w-8 h-8 bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <mat-icon class="text-lg">account_tree</mat-icon>
            </div>
            <div>
              <div class="flex items-center gap-2">
                <span class="text-xs font-mono font-semibold tracking-wider text-amber-400 uppercase">One Data Fabric // Provenance Lineage</span>
                <span class="text-[10px] font-mono px-1.5 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800">SOURCE_VERIFIED</span>
              </div>
              <h2 class="text-lg font-serif font-bold text-slate-100">{{ seriesTitle() }}</h2>
            </div>
          </div>
          <button 
            type="button" 
            (click)="dismissModal.emit()" 
            class="p-1.5 text-slate-400 hover:text-slate-100 hover:bg-slate-800 transition cursor-pointer"
            aria-label="Close lineage modal"
          >
            <mat-icon>close</mat-icon>
          </button>
        </div>

        <!-- Body Lineage Graph -->
        <div class="p-6 overflow-y-auto space-y-6 flex-1">
          <div class="text-xs text-slate-400 bg-slate-950 p-3 border-l-2 border-amber-500 flex items-center justify-between">
            <span>Every observation in BOE.STAT is strictly immutable and cryptographically traceable from raw ingest to final publication.</span>
            <span class="font-mono text-amber-400">ISO-8000-61 COMPLIANT</span>
          </div>

          <div class="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-800">
            @for (node of lineageNodes(); track node.title; let i = $index) {
              <div class="relative flex items-start gap-4 group">
                <!-- Step Circle -->
                <div class="absolute -left-6 mt-1 w-5 h-5 rounded-full bg-slate-950 border-2 border-amber-500/60 flex items-center justify-center text-[10px] font-mono font-bold text-amber-400">
                  {{ i + 1 }}
                </div>

                <!-- Step Card -->
                <div class="flex-1 bg-slate-950/60 border border-slate-800 p-4 transition group-hover:border-slate-700">
                  <div class="flex items-center justify-between mb-1">
                    <span class="text-[10px] font-mono font-semibold text-amber-400/80 uppercase tracking-wider">
                      STAGE {{ i + 1 }}: {{ node.type }}
                    </span>
                    @if (node.verified) {
                      <span class="inline-flex items-center gap-1 text-[10px] font-mono text-emerald-400">
                        <mat-icon class="text-xs">verified</mat-icon> Cryptographically Signed
                      </span>
                    }
                  </div>
                  
                  <h3 class="text-sm font-semibold text-slate-100">{{ node.title }}</h3>
                  <p class="text-xs text-slate-400 mt-1">{{ node.description }}</p>

                  <!-- Node Metadata Table -->
                  @if (node.metadata) {
                    <div class="mt-3 grid grid-cols-2 md:grid-cols-4 gap-2 text-xs font-mono bg-slate-900/80 p-2.5 border border-slate-800/80">
                      @for (item of node.metadata | keyvalue; track item.key) {
                        <div>
                          <div class="text-[10px] text-slate-400 uppercase">{{ item.key }}</div>
                          <div class="text-slate-200 font-medium truncate">{{ item.value }}</div>
                        </div>
                      }
                    </div>
                  }
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Footer -->
        <div class="bg-slate-950 border-t border-slate-800 px-6 py-3 flex items-center justify-between text-xs font-mono text-slate-400">
          <div>
            LEDGER STATUS: <span class="text-emerald-400">ZERO DISCREPANCIES DETECTED</span>
          </div>
          <div class="flex items-center gap-3">
            <button 
              type="button" 
              (click)="dismissModal.emit()" 
              class="px-4 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 uppercase font-semibold text-xs transition cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        </div>

      </div>
    </div>
  `,
})
export class LineageModalComponent {
  seriesTitle = input<string>('Observation Lineage');
  lineageNodes = input<DataLineageNode[]>([]);
  dismissModal = output<void>();
}
