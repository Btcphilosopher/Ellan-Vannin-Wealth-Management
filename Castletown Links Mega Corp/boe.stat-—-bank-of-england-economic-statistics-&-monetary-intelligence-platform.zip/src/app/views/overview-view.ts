import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { BoeDataService } from '../services/boe-data';

@Component({
  selector: 'app-overview-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Top Banner Notice -->
      <div class="bg-slate-900 border border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
        <div class="flex items-center gap-3">
          <div class="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></div>
          <div>
            <div class="text-xs font-mono font-bold text-slate-200">EXECUTIVE MONETARY & FINANCIAL DASHBOARD</div>
            <div class="text-[11px] text-slate-400 font-mono">CANONICAL LEDGER VERSION 4.2 // 11,840 ACTIVE TIME SERIES // ZERO LATENCY INGESTION</div>
          </div>
        </div>
        <div class="flex items-center gap-2 text-xs font-mono">
          <span class="px-2 py-0.5 bg-slate-800 text-amber-300 border border-slate-700">NEXT MPC ROUND: 05 NOV 2026</span>
          <span class="px-2 py-0.5 bg-emerald-950 text-emerald-400 border border-emerald-800">ALL FEEDS OPERATIONAL</span>
        </div>
      </div>

      <!-- Key Economic & Market Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        
        <!-- Bank Rate Card -->
        <button type="button" (click)="openLineage.emit('GB.BANKRATE.LEVEL.PCT')" class="w-full text-left bg-slate-900/80 border border-slate-800 hover:border-amber-500/50 p-4 transition cursor-pointer group">
          <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
            <span class="uppercase">Policy Benchmark</span>
            <span class="text-[10px] text-emerald-400 flex items-center gap-0.5"><mat-icon class="text-xs">verified</mat-icon> MPC</span>
          </div>
          <div class="text-xs font-bold text-slate-300 group-hover:text-amber-300">Official Bank Rate</div>
          <div class="text-3xl font-mono font-bold text-slate-100 my-1">4.50<span class="text-sm font-normal text-slate-400 ml-1">%</span></div>
          <div class="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/80">
            <span class="text-emerald-400">-25bp vs Jul 2026</span>
            <span class="text-amber-400 underline decoration-amber-500/40">Trace Provenance →</span>
          </div>
        </button>

        <!-- 10Y Nominal Gilt Card -->
        <button type="button" (click)="openLineage.emit('GB.GILT.NOMINAL.ZERO.10Y.PCT')" class="w-full text-left bg-slate-900/80 border border-slate-800 hover:border-amber-500/50 p-4 transition cursor-pointer group">
          <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
            <span class="uppercase">Sovereign Benchmark</span>
            <span class="text-[10px] text-amber-400">NSS FITTED</span>
          </div>
          <div class="text-xs font-bold text-slate-300 group-hover:text-amber-300">10Y Nominal Gilt Yield</div>
          <div class="text-3xl font-mono font-bold text-slate-100 my-1">3.92<span class="text-sm font-normal text-slate-400 ml-1">%</span></div>
          <div class="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/80">
            <span class="text-emerald-400">-3.0bp 1D // -38bp YTD</span>
            <span class="text-amber-400 underline decoration-amber-500/40">Trace Provenance →</span>
          </div>
        </button>

        <!-- CPI Headline Card -->
        <button type="button" (click)="openLineage.emit('GB.CPI.ALL.YOY.PCT.M')" class="w-full text-left bg-slate-900/80 border border-slate-800 hover:border-amber-500/50 p-4 transition cursor-pointer group">
          <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
            <span class="uppercase">Price Stability</span>
            <span class="text-[10px] text-emerald-400">ONS NAT STAT</span>
          </div>
          <div class="text-xs font-bold text-slate-300 group-hover:text-amber-300">Headline CPI Inflation</div>
          <div class="text-3xl font-mono font-bold text-slate-100 my-1">2.30<span class="text-sm font-normal text-slate-400 ml-1">% YoY</span></div>
          <div class="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/80">
            <span class="text-slate-400">Target: 2.0% // Core: 3.1%</span>
            <span class="text-amber-400 underline decoration-amber-500/40">Trace Provenance →</span>
          </div>
        </button>

        <!-- Cable Spot Card -->
        <button type="button" (click)="openLineage.emit('GBP.USD.SPOT')" class="w-full text-left bg-slate-900/80 border border-slate-800 hover:border-amber-500/50 p-4 transition cursor-pointer group">
          <div class="flex items-center justify-between text-slate-400 text-xs font-mono mb-1">
            <span class="uppercase">Foreign Exchange</span>
            <span class="text-[10px] text-slate-400">16:00 FIX</span>
          </div>
          <div class="text-xs font-bold text-slate-300 group-hover:text-amber-300">Sterling / USD Spot (Cable)</div>
          <div class="text-3xl font-mono font-bold text-slate-100 my-1">1.3385<span class="text-sm font-normal text-slate-400 ml-1">USD</span></div>
          <div class="flex items-center justify-between text-[11px] font-mono text-slate-400 pt-2 border-t border-slate-800/80">
            <span class="text-emerald-400">+0.26% 1D // +3.24% 1Y</span>
            <span class="text-amber-400 underline decoration-amber-500/40">Trace Provenance →</span>
          </div>
        </button>

      </div>

      <!-- Secondary Metrics Strip -->
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <button type="button" (click)="openLineage.emit('GB.SONIA.RATE.PCT')" class="w-full text-left bg-slate-900/60 border border-slate-800/80 p-3 hover:border-slate-700 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">SONIA Overnight</div>
          <div class="text-lg font-mono font-bold text-slate-200">4.45%</div>
          <div class="text-[10px] font-mono text-slate-500">Vol: £82.4bn</div>
        </button>
        <button type="button" (click)="openLineage.emit('GB.GILT.REAL.ZERO.10Y.PCT')" class="w-full text-left bg-slate-900/60 border border-slate-800/80 p-3 hover:border-slate-700 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">10Y Real Gilt</div>
          <div class="text-lg font-mono font-bold text-slate-200">0.88%</div>
          <div class="text-[10px] font-mono text-slate-500">Index-Linked</div>
        </button>
        <button type="button" (click)="openLineage.emit('GB.GILT.INFLATION.ZERO.10Y.PCT')" class="w-full text-left bg-slate-900/60 border border-slate-800/80 p-3 hover:border-slate-700 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">10Y Breakeven</div>
          <div class="text-lg font-mono font-bold text-slate-200">3.04%</div>
          <div class="text-[10px] font-mono text-slate-500">Market-Implied</div>
        </button>
        <button type="button" (click)="openLineage.emit('GB.GDP.REAL.YOY.PCT.Q')" class="w-full text-left bg-slate-900/60 border border-slate-800/80 p-3 hover:border-slate-700 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">Real GDP YoY</div>
          <div class="text-lg font-mono font-bold text-slate-200">1.20%</div>
          <div class="text-[10px] font-mono text-slate-500">Q2 2026 BB26</div>
        </button>
        <button type="button" (click)="openLineage.emit('GB.LABOUR.UNEMPLOYMENT.ILO.PCT.M')" class="w-full text-left bg-slate-900/60 border border-slate-800/80 p-3 hover:border-slate-700 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">Unemployment (ILO)</div>
          <div class="text-lg font-mono font-bold text-slate-200">4.10%</div>
          <div class="text-[10px] font-mono text-slate-500">Jul 2026 3M</div>
        </button>
        <button type="button" (click)="openLineage.emit('GB.FCI.COMPOSITE.INDEX')" class="w-full text-left bg-slate-900/60 border border-slate-800/80 p-3 hover:border-slate-700 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">BoE FCI Composite</div>
          <div class="text-lg font-mono font-bold text-slate-200">+0.12</div>
          <div class="text-[10px] font-mono text-slate-500">Neutral Range</div>
        </button>
      </div>

      <!-- Two Column Layout: Yield Curve Snapshot + Release Calendar -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- Yield Curve Quick Summary -->
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 class="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
                <mat-icon class="text-amber-400 text-sm">show_chart</mat-icon>
                UK Sovereign Yield Curve Structure
              </h3>
              <p class="text-[11px] font-mono text-slate-400">Nelson-Siegel-Svensson continuous fit // Quoted annually compounded</p>
            </div>
            <button type="button" (click)="navigateTo.emit('YIELD_CURVES')" class="text-xs font-mono text-amber-400 hover:underline cursor-pointer">Full Curve Lab →</button>
          </div>

          <!-- Mini Table -->
          <div class="overflow-x-auto">
            <table class="w-full text-xs font-mono text-left">
              <thead>
                <tr class="text-slate-500 border-b border-slate-800 pb-1 text-[10px]">
                  <th class="py-1">TENOR</th>
                  <th>NOMINAL</th>
                  <th>REAL</th>
                  <th>BREAKEVEN</th>
                  <th>SONIA OIS</th>
                  <th class="text-right">1D CHG</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                @for (pt of boeData.yieldCurveData.slice(3, 10); track pt.tenor) {
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-1.5 font-bold text-slate-200">{{ pt.tenor }}</td>
                    <td class="text-amber-300">{{ pt.nominalYield.toFixed(2) }}%</td>
                    <td class="text-emerald-400">{{ pt.realYield.toFixed(2) }}%</td>
                    <td class="text-cyan-400">{{ pt.breakevenInflation.toFixed(2) }}%</td>
                    <td class="text-slate-300">{{ pt.oisYield.toFixed(2) }}%</td>
                    <td class="text-right text-emerald-400">{{ pt.change1D }}bp</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>

          <div class="grid grid-cols-3 gap-2 pt-2 border-t border-slate-800 text-[11px] font-mono bg-slate-950 p-2.5">
            <div><span class="text-slate-500">2Y-10Y Slope:</span> <span class="text-slate-200 font-bold">+6.0 bp</span></div>
            <div><span class="text-slate-500">5Y-30Y Slope:</span> <span class="text-slate-200 font-bold">+68.0 bp</span></div>
            <div><span class="text-slate-500">5Y Curvature:</span> <span class="text-slate-200 font-bold">-30.0 bp</span></div>
          </div>
        </div>

        <!-- Release Calendar & Data Status -->
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 class="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
                <mat-icon class="text-amber-400 text-sm">calendar_month</mat-icon>
                Economic Release Calendar & Vintages
              </h3>
              <p class="text-[11px] font-mono text-slate-400">Official release schedule with revision tracing</p>
            </div>
            <button type="button" (click)="navigateTo.emit('ECONOMY_MONEY')" class="text-xs font-mono text-amber-400 hover:underline cursor-pointer">View All →</button>
          </div>

          <div class="space-y-2.5">
            @for (rel of boeData.releaseCalendar; track rel.id) {
              <div class="p-2.5 bg-slate-950/60 border border-slate-800 hover:border-slate-700 flex items-start justify-between gap-3 text-xs font-mono">
                <div class="flex-1">
                  <div class="flex items-center gap-2">
                    <span class="text-amber-400 font-bold text-[10px]">{{ rel.date }} {{ rel.time }}</span>
                    <span class="text-[9px] px-1 py-0.2 bg-slate-800 text-slate-400">{{ rel.sourceOrg }}</span>
                    @if (rel.status === 'RELEASED') {
                      <span class="text-[9px] px-1 py-0.2 bg-emerald-950 text-emerald-400">RELEASED</span>
                    } @else {
                      <span class="text-[9px] px-1 py-0.2 bg-amber-950 text-amber-400">PENDING</span>
                    }
                  </div>
                  <div class="text-slate-200 font-semibold mt-1">{{ rel.seriesName }}</div>
                  <div class="text-[11px] text-slate-500 mt-0.5">Prev: {{ rel.previousValue }}{{ rel.unit }} // Consensus: {{ rel.consensusExpected }}{{ rel.unit }}</div>
                </div>
                @if (rel.status === 'RELEASED') {
                  <div class="text-right">
                    <div class="text-sm font-bold text-emerald-400">{{ rel.actualValue }}{{ rel.unit }}</div>
                    <div class="text-[10px] text-slate-500">Actual</div>
                  </div>
                }
              </div>
            }
          </div>
        </div>

      </div>
    </div>
  `,
})
export class OverviewViewComponent {
  openLineage = output<string>();
  navigateTo = output<string>();

  public boeData = inject(BoeDataService);
}
