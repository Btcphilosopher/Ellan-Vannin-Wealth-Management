import { ChangeDetectionStrategy, Component, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { AuditLogEntry, SeriesMetadata } from '../models/boe.types';
import { BoeDataService } from '../services/boe-data';

@Component({
  selector: 'app-explorer-audit-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, FormsModule],
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-slate-900 border border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-amber-400">CANONICAL SERIES CATALOG & CRYPTOGRAPHIC LEDGER</span>
            <span class="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-300">SHA-256 HASH CHAIN // ISO-8000-61 COMPLIANT</span>
          </div>
          <h1 class="text-xl font-serif font-bold text-slate-100 mt-1">Universal Series Explorer & Audit Ledger</h1>
        </div>

        <div class="flex bg-slate-950 p-1 border border-slate-800 text-xs font-mono">
          <button 
            (click)="activeSubTab.set('SERIES')" 
            [class.bg-slate-800]="activeSubTab() === 'SERIES'"
            [class.text-amber-300]="activeSubTab() === 'SERIES'"
            class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            Series Catalog ({{ boeData.seriesCatalog.length }})
          </button>
          <button 
            (click)="activeSubTab.set('AUDIT')" 
            [class.bg-slate-800]="activeSubTab() === 'AUDIT'"
            [class.text-amber-300]="activeSubTab() === 'AUDIT'"
            class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            Audit Log Chain ({{ auditLogs().length }})
          </button>
        </div>
      </div>

      <!-- Tab 1: Series Catalog & Detail Inspector -->
      @if (activeSubTab() === 'SERIES') {
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          <!-- Left Column: Filterable List -->
          <div class="bg-slate-900 border border-slate-800 p-4 space-y-3">
            <div class="flex items-center gap-2">
              <input 
                type="text" 
                [(ngModel)]="searchQuery" 
                placeholder="Filter series by name, ID, alias..."
                class="w-full bg-slate-950 border border-slate-700 text-slate-200 px-3 py-1.5 text-xs font-mono outline-none"
              />
            </div>

            <!-- Series List -->
            <div class="max-h-[600px] overflow-y-auto space-y-1.5 pr-1">
              @for (s of filteredSeries(); track s.id) {
                <button 
                  type="button"
                  (click)="selectedSeries.set(s)" 
                  [class.border-amber-500]="selectedSeries()?.id === s.id"
                  [class.bg-slate-950]="selectedSeries()?.id === s.id"
                  class="w-full text-left p-2.5 bg-slate-950/40 border border-slate-800 hover:border-slate-700 cursor-pointer text-xs font-mono space-y-1 transition"
                >
                  <div class="flex items-center justify-between">
                    <span class="text-amber-400 font-bold text-[10px]">{{ s.id }}</span>
                    <span class="text-slate-200 font-bold">{{ s.latestValue }} {{ s.unit }}</span>
                  </div>
                  <div class="text-slate-300 font-semibold truncate">{{ s.name }}</div>
                  <div class="flex items-center justify-between text-[10px] text-slate-500">
                    <span>{{ s.provenance.source }}</span>
                    <span>Obs: {{ s.lastObservation }}</span>
                  </div>
                </button>
              }
            </div>
          </div>

          <!-- Right 2 Columns: Full Series Metadata & Historical Inspection -->
          <div class="lg:col-span-2 bg-slate-900 border border-slate-800 p-5 space-y-4">
            @if (selectedSeries(); as s) {
              <div class="flex items-start justify-between border-b border-slate-800 pb-3">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-amber-400 uppercase font-bold">{{ s.category }}</span>
                    <span class="text-[10px] font-mono px-1.5 py-0.2 bg-emerald-950 text-emerald-400">{{ s.classification }}</span>
                    <span class="text-[10px] font-mono text-slate-500">Quality: {{ s.qualityScore }}/100</span>
                  </div>
                  <h2 class="text-lg font-serif font-bold text-slate-100 mt-1">{{ s.name }}</h2>
                  <div class="text-xs font-mono text-amber-400 font-bold mt-0.5">{{ s.id }}</div>
                </div>

                <button 
                  type="button"
                  (click)="openLineage.emit(s.id)" 
                  class="px-3 py-1.5 bg-amber-600/30 border border-amber-500/50 hover:bg-amber-600/50 text-amber-300 text-xs font-mono flex items-center gap-1.5 cursor-pointer"
                >
                  <mat-icon class="text-xs">account_tree</mat-icon> Trace Provenance
                </button>
              </div>

              <p class="text-xs text-slate-300 leading-relaxed font-sans">{{ s.description }}</p>

              <!-- Technical Metadata Grid -->
              <div class="grid grid-cols-2 md:grid-cols-4 gap-3 bg-slate-950 p-4 border border-slate-800 font-mono text-xs">
                <div>
                  <div class="text-[10px] text-slate-500 uppercase">Frequency</div>
                  <div class="text-slate-200 font-bold">{{ s.frequency }}</div>
                </div>
                <div>
                  <div class="text-[10px] text-slate-500 uppercase">Seasonal Adjustment</div>
                  <div class="text-slate-200 font-bold">{{ s.seasonalAdjustment }}</div>
                </div>
                <div>
                  <div class="text-[10px] text-slate-500 uppercase">First Observation</div>
                  <div class="text-slate-200 font-bold">{{ s.firstObservation }}</div>
                </div>
                <div>
                  <div class="text-[10px] text-slate-500 uppercase">Total Observations</div>
                  <div class="text-slate-200 font-bold">{{ s.observationCount }}</div>
                </div>
                <div>
                  <div class="text-[10px] text-slate-500 uppercase">Source Provider</div>
                  <div class="text-emerald-400 font-bold truncate">{{ s.provenance.source }}</div>
                </div>
                <div>
                  <div class="text-[10px] text-slate-500 uppercase">Raw Source ID</div>
                  <div class="text-slate-200 font-bold">{{ s.provenance.rawSourceId || 'N/A' }}</div>
                </div>
                <div>
                  <div class="text-[10px] text-slate-500 uppercase">Confidence Score</div>
                  <div class="text-cyan-400 font-bold">{{ (s.provenance.confidenceScore * 100).toFixed(0) }}%</div>
                </div>
                <div>
                  <div class="text-[10px] text-slate-500 uppercase">Last Audited</div>
                  <div class="text-slate-200 truncate">{{ s.provenance.lastAudited.slice(0,10) }}</div>
                </div>
              </div>

              <!-- Methodology Description -->
              <div class="bg-slate-950/60 p-3 border border-slate-800 text-xs font-mono">
                <div class="text-[10px] text-slate-500 uppercase font-bold">Methodology Pipeline</div>
                <div class="text-slate-300 mt-1">{{ s.provenance.methodology }}</div>
              </div>
            }
          </div>
        </div>
      }

      <!-- Tab 2: Cryptographic Audit Ledger -->
      @if (activeSubTab() === 'AUDIT') {
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 class="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
                <mat-icon class="text-emerald-400 text-sm">verified_user</mat-icon>
                Cryptographic SHA-256 Audit Chain
              </h3>
              <p class="text-xs text-slate-400 font-mono mt-0.5">
                Every query, model run, export, and role transition is recorded in an immutable hash chain.
              </p>
            </div>
            <span class="px-2.5 py-1 bg-emerald-950 border border-emerald-800 text-emerald-400 text-xs font-mono font-bold">LEDGER VERIFIED</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-xs font-mono text-left">
              <thead>
                <tr class="text-slate-500 border-b border-slate-800 pb-2 text-[10px]">
                  <th class="py-2">AUDIT ID</th>
                  <th>TIMESTAMP (UTC)</th>
                  <th>ACTOR IDENTITY</th>
                  <th>ROLE</th>
                  <th>ACTION TYPE</th>
                  <th>RESOURCE</th>
                  <th>REASON CODE</th>
                  <th class="text-right">BLOCK HASH</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                @for (entry of auditLogs(); track entry.id) {
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-2.5 font-bold text-amber-400">{{ entry.id }}</td>
                    <td class="text-slate-300">{{ entry.timestamp }}</td>
                    <td class="text-slate-200 font-semibold">{{ entry.actor }}</td>
                    <td>
                      <span class="px-1.5 py-0.2 bg-slate-800 text-slate-300 text-[10px]">{{ entry.actorRole }}</span>
                    </td>
                    <td class="font-bold text-cyan-400">{{ entry.actionType }}</td>
                    <td class="text-slate-300 max-w-xs truncate">{{ entry.resource }}</td>
                    <td class="text-slate-400 text-[10px]">{{ entry.reasonCode }}</td>
                    <td class="text-right font-mono text-[10px] text-emerald-400">{{ entry.hash.slice(0, 16) }}...</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }
    </div>
  `,
})
export class ExplorerAuditViewComponent {
  auditLogs = input<AuditLogEntry[]>([]);
  openLineage = output<string>();

  activeSubTab = signal<'SERIES' | 'AUDIT'>('SERIES');
  searchQuery = '';
  selectedSeries = signal<SeriesMetadata | null>(null);

  public boeData = inject(BoeDataService);

  constructor() {
    if (this.boeData.seriesCatalog.length > 0) {
      this.selectedSeries.set(this.boeData.seriesCatalog[0]);
    }
  }

  filteredSeries(): SeriesMetadata[] {
    const q = this.searchQuery.toLowerCase().trim();
    if (!q) return this.boeData.seriesCatalog;

    return this.boeData.seriesCatalog.filter((s) =>
      s.id.toLowerCase().includes(q) ||
      s.name.toLowerCase().includes(q) ||
      s.category.toLowerCase().includes(q) ||
      s.aliases.some((a) => a.toLowerCase().includes(q))
    );
  }
}
