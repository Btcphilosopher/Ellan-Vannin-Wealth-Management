import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { BoeDataService } from '../services/boe-data';

@Component({
  selector: 'app-inflation-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-slate-900 border border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-amber-400">INFLATION DECOMPOSITION & EXPECTATIONS LABORATORY</span>
            <span class="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-300">ONS COICOP HIERARCHY // LASPEYRES 2015=100</span>
          </div>
          <h1 class="text-xl font-serif font-bold text-slate-100 mt-1">Consumer Price Inflation & Expectations</h1>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono">
          <div class="bg-slate-950 px-3 py-1 border border-slate-800">
            <span class="text-slate-500">Target:</span> <strong class="text-slate-200">2.0%</strong>
          </div>
          <div class="bg-slate-950 px-3 py-1 border border-slate-800">
            <span class="text-slate-500">Headline CPI:</span> <strong class="text-amber-300">2.30%</strong>
          </div>
          <div class="bg-slate-950 px-3 py-1 border border-slate-800">
            <span class="text-slate-500">Core CPI:</span> <strong class="text-slate-100">3.10%</strong>
          </div>
        </div>
      </div>

      <!-- Key Inflation Aggregates Grid -->
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        <button type="button" (click)="openLineage.emit('GB.CPI.ALL.YOY.PCT.M')" class="w-full text-left bg-slate-900/70 border border-slate-800 p-3 hover:border-amber-500/40 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">CPI Headline</div>
          <div class="text-xl font-mono font-bold text-amber-300">2.30%</div>
          <div class="text-[10px] font-mono text-slate-500">+0.10% MoM</div>
        </button>

        <button type="button" (click)="openLineage.emit('GB.CPI.CORE.YOY.PCT.M')" class="w-full text-left bg-slate-900/70 border border-slate-800 p-3 hover:border-amber-500/40 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">Core CPI</div>
          <div class="text-xl font-mono font-bold text-slate-100">3.10%</div>
          <div class="text-[10px] font-mono text-emerald-400">-0.20% MoM</div>
        </button>

        <button type="button" (click)="openLineage.emit('GB.CPI.SERVICES.YOY.PCT.M')" class="w-full text-left bg-slate-900/70 border border-slate-800 p-3 hover:border-amber-500/40 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">Services CPI</div>
          <div class="text-xl font-mono font-bold text-blue-400">4.60%</div>
          <div class="text-[10px] font-mono text-slate-500">Domestic Gauge</div>
        </button>

        <div class="bg-slate-900/70 border border-slate-800 p-3">
          <div class="text-[10px] font-mono text-slate-400 uppercase">Goods CPI</div>
          <div class="text-xl font-mono font-bold text-emerald-400">-0.90%</div>
          <div class="text-[10px] font-mono text-slate-500">Deflationary</div>
        </div>

        <div class="bg-slate-900/70 border border-slate-800 p-3">
          <div class="text-[10px] font-mono text-slate-400 uppercase">Trimmed Mean (15%)</div>
          <div class="text-xl font-mono font-bold text-slate-200">2.45%</div>
          <div class="text-[10px] font-mono text-slate-500">Underlying Trend</div>
        </div>

        <div class="bg-slate-900/70 border border-slate-800 p-3">
          <div class="text-[10px] font-mono text-slate-400 uppercase">3M Annualised</div>
          <div class="text-xl font-mono font-bold text-slate-200">1.95%</div>
          <div class="text-[10px] font-mono text-emerald-400">Below 2% Target</div>
        </div>
      </div>

      <!-- Inflation Component Contribution Waterfall -->
      <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 class="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400 text-sm">pie_chart</mat-icon>
              CPI Basket Contribution Waterfall (Basis Points to 2.30% Headline)
            </h3>
            <p class="text-xs text-slate-400 font-mono mt-0.5">
              Exact mathematical contribution: C_i = W_i * Delta P_i / Sum W. Total sums to 230 bp.
            </p>
          </div>
          <span class="text-xs font-mono text-slate-400">Total Basket Weight: 1000‰</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono text-left">
            <thead>
              <tr class="text-slate-500 border-b border-slate-800 pb-2 text-[10px]">
                <th class="py-2">COMPONENT</th>
                <th>COICOP CODE</th>
                <th>BASKET WEIGHT (‰)</th>
                <th>ANNUAL RATE (%)</th>
                <th>CONTRIBUTION (BP)</th>
                <th>PREVIOUS (BP)</th>
                <th>SHARE OF HEADLINE</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (comp of boeData.inflationDecomposition.components; track comp.code) {
                <tr class="hover:bg-slate-800/40">
                  <td class="py-2.5 font-bold text-slate-200 flex items-center gap-2">
                    <span class="w-2 h-2 rounded-full" [style.background-color]="comp.color"></span>
                    {{ comp.name }}
                  </td>
                  <td class="text-slate-400">{{ comp.code }}</td>
                  <td class="text-slate-300 font-medium">{{ comp.weight }}‰</td>
                  <td [class.text-rose-400]="comp.latestYoyRate < 0" class="text-slate-100 font-bold">
                    {{ comp.latestYoyRate >= 0 ? '+' : '' }}{{ comp.latestYoyRate }}%
                  </td>
                  <td [class.text-emerald-400]="comp.contributionBp < 0" class="font-bold text-amber-300">
                    {{ comp.contributionBp >= 0 ? '+' : '' }}{{ comp.contributionBp }} bp
                  </td>
                  <td class="text-slate-400">{{ comp.previousContributionBp }} bp</td>
                  <td>
                    <div class="flex items-center gap-2">
                      <div class="w-20 h-2 bg-slate-800 overflow-hidden">
                        <div class="h-full" [style.background-color]="comp.color" [style.width.%]="Math.min(100, Math.abs(comp.contributionBp) / 2.3)"></div>
                      </div>
                      <span class="text-slate-300">{{ ((comp.contributionBp / 230) * 100).toFixed(1) }}%</span>
                    </div>
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Inflation Expectations Matrix -->
      <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 class="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400 text-sm">compare_arrows</mat-icon>
              Inflation Expectations Comparison Matrix
            </h3>
            <p class="text-xs text-slate-400 font-mono mt-0.5">
              Comparison across financial market pricing, household surveys, corporate DMP surveys, and professional forecasters.
            </p>
          </div>
          <button type="button" (click)="openLineage.emit('GB.GILT.INFLATION.ZERO.10Y.PCT')" class="text-xs font-mono text-amber-400 hover:underline cursor-pointer">Inspect 10Y Breakeven →</button>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          <!-- Market Pricing -->
          <div class="bg-slate-950 p-4 border border-slate-800 text-xs font-mono space-y-2">
            <div class="text-[10px] text-amber-400 font-bold uppercase">Financial Markets (Swaps & Gilts)</div>
            <div class="flex justify-between py-1 border-b border-slate-800">
              <span class="text-slate-400">10Y Gilt Breakeven:</span>
              <span class="font-bold text-slate-100">{{ boeData.inflationExpectations.marketBreakeven10Y }}%</span>
            </div>
            <div class="flex justify-between py-1 border-b border-slate-800">
              <span class="text-slate-400">5Y5Y Forward Inflation Swap:</span>
              <span class="font-bold text-cyan-400">{{ boeData.inflationExpectations.market5Y5YForward }}%</span>
            </div>
            <div class="flex justify-between py-1">
              <span class="text-slate-400">5Y Breakeven:</span>
              <span class="font-bold text-slate-100">{{ boeData.inflationExpectations.marketBreakeven5Y }}%</span>
            </div>
          </div>

          <!-- Surveys (Households & Businesses) -->
          <div class="bg-slate-950 p-4 border border-slate-800 text-xs font-mono space-y-2">
            <div class="text-[10px] text-emerald-400 font-bold uppercase">Surveys (Households & Firms)</div>
            <div class="flex justify-between py-1 border-b border-slate-800">
              <span class="text-slate-400">YouGov/Citigroup Household 1Y:</span>
              <span class="font-bold text-slate-100">{{ boeData.inflationExpectations.youGovHousehold1Y }}%</span>
            </div>
            <div class="flex justify-between py-1 border-b border-slate-800">
              <span class="text-slate-400">YouGov Household 5Y Ahead:</span>
              <span class="font-bold text-slate-100">{{ boeData.inflationExpectations.youGovHousehold5Y }}%</span>
            </div>
            <div class="flex justify-between py-1">
              <span class="text-slate-400">Decision Maker Panel (DMP) 1Y:</span>
              <span class="font-bold text-slate-100">{{ boeData.inflationExpectations.dmpBusiness1Y }}%</span>
            </div>
          </div>

          <!-- Forecasters & Staff -->
          <div class="bg-slate-950 p-4 border border-slate-800 text-xs font-mono space-y-2">
            <div class="text-[10px] text-purple-400 font-bold uppercase">Forecasts (Professional & Staff)</div>
            <div class="flex justify-between py-1 border-b border-slate-800">
              <span class="text-slate-400">Survey of External Forecasters 1Y:</span>
              <span class="font-bold text-slate-100">{{ boeData.inflationExpectations.surveyForecasters1Y }}%</span>
            </div>
            <div class="flex justify-between py-1 border-b border-slate-800">
              <span class="text-slate-400">BoE Staff MPR Central Projection 2Y:</span>
              <span class="font-bold text-emerald-400">{{ boeData.inflationExpectations.boeStaffForecast2Y }}%</span>
            </div>
            <div class="flex justify-between py-1">
              <span class="text-slate-400">BoE Staff Projection 3Y:</span>
              <span class="font-bold text-emerald-400">{{ boeData.inflationExpectations.boeStaffForecast3Y }}%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class InflationViewComponent {
  openLineage = output<string>();
  readonly Math = Math;

  public boeData = inject(BoeDataService);
}
