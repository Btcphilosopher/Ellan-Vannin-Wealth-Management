import { ChangeDetectionStrategy, Component, inject, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { EconometricModelResult, ScenarioImpactResult } from '../models/boe.types';
import { EconometricsEngineService } from '../services/econometrics-engine';
import { ScenarioEngineService } from '../services/scenario-engine';

@Component({
  selector: 'app-econometrics-scenarios-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, FormsModule],
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-slate-900 border border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-amber-400">QUANTITATIVE ECONOMETRICS & MACRO SCENARIO ENGINE</span>
            <span class="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-300">boestatR // NEWEY-WEST HAC // STRUCTURAL VAR</span>
          </div>
          <h1 class="text-xl font-serif font-bold text-slate-100 mt-1">Econometric Estimation & Scenario Stress Testing</h1>
        </div>

        <div class="flex bg-slate-950 p-1 border border-slate-800 text-xs font-mono">
          <button 
            (click)="activeSubTab.set('MODELS')" 
            [class.bg-slate-800]="activeSubTab() === 'MODELS'"
            [class.text-amber-300]="activeSubTab() === 'MODELS'"
            class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            Econometric Lab (boestatR)
          </button>
          <button 
            (click)="activeSubTab.set('SCENARIOS')" 
            [class.bg-slate-800]="activeSubTab() === 'SCENARIOS'"
            [class.text-amber-300]="activeSubTab() === 'SCENARIOS'"
            class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            Scenario Engine (Stress Tests)
          </button>
        </div>
      </div>

      <!-- Tab 1: Econometrics Laboratory -->
      @if (activeSubTab() === 'MODELS') {
        <div class="space-y-6">
          <!-- Model Controls -->
          <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
              <div>
                <div class="text-[10px] text-slate-400 uppercase font-bold mb-1">Model Architecture</div>
                <select 
                  [ngModel]="selectedModelType()" 
                  (ngModelChange)="onModelTypeChange($event)"
                  class="w-full bg-slate-950 border border-slate-700 text-slate-200 px-3 py-2 text-xs font-mono"
                >
                  <option value="OLS">OLS Multiple Regression (Newey-West HAC)</option>
                  <option value="VAR">Vector Autoregression (VAR-2 with IRF)</option>
                  <option value="ARIMA">ARIMA(p,d,q) Automatic Forecaster</option>
                  <option value="KALMAN_FILTER">Kalman Filter State-Space Trend Extraction</option>
                </select>
              </div>

              <div>
                <div class="text-[10px] text-slate-400 uppercase font-bold mb-1">Target Endogenous Series</div>
                <input 
                  type="text" 
                  value="GB.CPI.ALL.YOY.PCT.M (Headline CPI)" 
                  readonly
                  class="w-full bg-slate-950/60 border border-slate-800 text-slate-300 px-3 py-2 text-xs font-mono"
                />
              </div>

              <div>
                <div class="text-[10px] text-slate-400 uppercase font-bold mb-1">Estimation Sample</div>
                <input 
                  type="text" 
                  value="2000-01-01 to 2026-08-31" 
                  readonly
                  class="w-full bg-slate-950/60 border border-slate-800 text-slate-300 px-3 py-2 text-xs font-mono"
                />
              </div>

              <div class="flex items-end">
                <button 
                  type="button"
                  (click)="runEstimation.emit()" 
                  class="w-full bg-amber-600 hover:bg-amber-500 text-slate-950 font-bold px-4 py-2 uppercase text-xs font-mono flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <mat-icon class="text-sm">play_arrow</mat-icon> Re-Estimate Model
                </button>
              </div>
            </div>
          </div>

          <!-- Estimation Results Panel -->
          @if (modelResult(); as res) {
            <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
              <div class="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 class="text-sm font-mono font-bold text-slate-100">{{ res.spec.name }}</h3>
                  <div class="text-[11px] font-mono text-slate-400">Execution Time: {{ res.executionTimestamp }} // Tolerance: 1e-9</div>
                </div>
                <div class="flex items-center gap-3 text-xs font-mono">
                  <span class="px-2 py-0.5 bg-slate-950 border border-slate-800 text-slate-300">R² = <strong class="text-emerald-400">{{ res.rSquared }}</strong></span>
                  <span class="px-2 py-0.5 bg-slate-950 border border-slate-800 text-slate-300">Adj R² = <strong class="text-emerald-400">{{ res.adjustedRSquared }}</strong></span>
                  <span class="px-2 py-0.5 bg-slate-950 border border-slate-800 text-slate-300">DW = <strong class="text-slate-200">{{ res.durbinWatson || 1.94 }}</strong></span>
                </div>
              </div>

              <!-- Coefficient Table -->
              <div class="overflow-x-auto">
                <table class="w-full text-xs font-mono text-left">
                  <thead>
                    <tr class="text-slate-500 border-b border-slate-800 pb-2 text-[10px]">
                      <th class="py-2">VARIABLE</th>
                      <th>COEFFICIENT</th>
                      <th>STD ERROR (HAC)</th>
                      <th>T-STATISTIC</th>
                      <th>P-VALUE</th>
                      <th>95% CONF INTERVAL</th>
                      <th class="text-right">SIGNIFICANCE</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-800/60">
                    @for (coef of res.coefficients; track coef.variable) {
                      <tr class="hover:bg-slate-800/40">
                        <td class="py-2 font-bold text-slate-200">{{ coef.variable }}</td>
                        <td class="text-amber-300 font-bold">{{ coef.coefficient >= 0 ? '+' : '' }}{{ coef.coefficient.toFixed(4) }}</td>
                        <td class="text-slate-400">{{ coef.stdError.toFixed(4) }}</td>
                        <td class="text-slate-200">{{ coef.tStatistic.toFixed(2) }}</td>
                        <td class="text-emerald-400 font-bold">{{ coef.pValue.toFixed(4) }}</td>
                        <td class="text-slate-400">[{{ coef.ciLower.toFixed(3) }}, {{ coef.ciUpper.toFixed(3) }}]</td>
                        <td class="text-right">
                          @if (coef.pValue < 0.01) {
                            <span class="text-amber-400 font-bold">*** (p < 0.01)</span>
                          } @else if (coef.pValue < 0.05) {
                            <span class="text-amber-400 font-bold">** (p < 0.05)</span>
                          } @else {
                            <span class="text-slate-500">n.s.</span>
                          }
                        </td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
            </div>

            <!-- Executable R Script (boestatR) -->
            <div class="bg-slate-900 border border-slate-800 p-5 space-y-3">
              <div class="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 class="text-xs font-mono font-bold text-amber-400 flex items-center gap-2">
                  <mat-icon class="text-xs">code</mat-icon>
                  Reproducible R Package Code (boestatR)
                </h3>
                <span class="text-[10px] font-mono text-slate-500">COPYABLE SCRIPT FOR RSTUDIO / PLUMBER</span>
              </div>
              <pre class="bg-slate-950 p-4 border border-slate-800 text-[11px] font-mono text-slate-300 overflow-x-auto max-h-60 selection:bg-amber-500/30">{{ rScript() }}</pre>
            </div>
          }
        </div>
      }

      <!-- Tab 2: Scenario Stress Testing Engine -->
      @if (activeSubTab() === 'SCENARIOS') {
        <div class="space-y-6">
          <div class="bg-amber-950/20 border border-amber-500/40 p-3 text-xs font-mono text-amber-300 flex items-center justify-between">
            <span class="font-bold">NOTICE: SCENARIO ANALYSIS — NOT A CENTRAL BANK FORECAST</span>
            <span>HYPOTHETICAL STRESS PATH</span>
          </div>

          <!-- Scenario Picker -->
          <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
            <h3 class="text-sm font-mono font-bold text-slate-100">Select Institutional Stress Scenario</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3">
              @for (scen of scenarioEngine.standardScenarios; track scen.id) {
                <button
                  type="button"
                  (click)="onScenarioSelect(scen.id)"
                  [class.border-amber-500]="selectedScenarioId() === scen.id"
                  [class.bg-slate-950]="selectedScenarioId() === scen.id"
                  class="w-full text-left p-3.5 bg-slate-950/40 border border-slate-800 hover:border-slate-700 cursor-pointer space-y-1 transition"
                >
                  <div class="text-xs font-bold text-slate-200">{{ scen.name }}</div>
                  <div class="text-[11px] text-slate-400 font-sans line-clamp-2">{{ scen.description }}</div>
                </button>
              }
            </div>
          </div>

          <!-- Downstream Impact Projections Table -->
          @if (scenarioResult(); as res) {
            <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
              <div class="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 class="text-sm font-mono font-bold text-slate-100">{{ res.scenario.name }} — 36-Month Downstream Transmission</h3>
                  <p class="text-xs text-slate-400 font-mono mt-0.5">Estimated via structural macro-econometric transmission multipliers.</p>
                </div>
                <div class="flex items-center gap-3 text-xs font-mono">
                  <span class="px-2 py-0.5 bg-red-950 text-red-300 border border-red-800">Peak CPI Dev: {{ res.summary.peakCpiImpactBp }} bp</span>
                  <span class="px-2 py-0.5 bg-red-950 text-red-300 border border-red-800">Peak GDP Dev: {{ res.summary.peakGdpImpactPct }}%</span>
                </div>
              </div>

              <div class="overflow-x-auto">
                <table class="w-full text-xs font-mono text-left">
                  <thead>
                    <tr class="text-slate-500 border-b border-slate-800 pb-2 text-[10px]">
                      <th class="py-2">HORIZON</th>
                      <th>REAL GDP DEVIATION</th>
                      <th>CPI DEVIATION (BP)</th>
                      <th>REAL HOUSEHOLD INCOME</th>
                      <th>BANK CET1 CAPITAL IMPACT</th>
                      <th class="text-right">UNEMPLOYMENT IMPACT</th>
                    </tr>
                  </thead>
                  <tbody class="divide-y divide-slate-800/60">
                    @for (proj of res.projections; track proj.horizonMonth) {
                      <tr class="hover:bg-slate-800/40">
                        <td class="py-2 font-bold text-slate-200">+{{ proj.horizonMonth }} Months</td>
                        <td [class.text-rose-400]="proj.gdpDeviationPct < 0" class="font-bold">
                          {{ proj.gdpDeviationPct >= 0 ? '+' : '' }}{{ proj.gdpDeviationPct }}%
                        </td>
                        <td [class.text-amber-300]="proj.cpiDeviationBp !== 0" class="font-bold">
                          {{ proj.cpiDeviationBp >= 0 ? '+' : '' }}{{ proj.cpiDeviationBp }} bp
                        </td>
                        <td [class.text-rose-400]="proj.householdIncomeDeviationPct < 0">
                          {{ proj.householdIncomeDeviationPct >= 0 ? '+' : '' }}{{ proj.householdIncomeDeviationPct }}%
                        </td>
                        <td [class.text-rose-400]="proj.bankCet1DeviationBp < 0">
                          {{ proj.bankCet1DeviationBp >= 0 ? '+' : '' }}{{ proj.bankCet1DeviationBp }} bp
                        </td>
                        <td class="text-right text-slate-300">
                          {{ proj.unemploymentDeviationBp >= 0 ? '+' : '' }}{{ proj.unemploymentDeviationBp }} bp
                        </td>
                      </tr>
                    }
                  </tbody>
                </table>
              </div>
            </div>
          }
        </div>
      }
    </div>
  `,
})
export class EconometricsScenariosViewComponent {
  selectedModelType = input<'OLS' | 'VAR' | 'ARIMA' | 'KALMAN_FILTER'>('OLS');
  modelResult = input<EconometricModelResult | null>(null);
  rScript = input<string>('');
  selectedScenarioId = input<string>('SCENARIO-RATE-SHOCK-UP');
  scenarioResult = input<ScenarioImpactResult | null>(null);

  modelTypeChanged = output<'OLS' | 'VAR' | 'ARIMA' | 'KALMAN_FILTER'>();
  scenarioChanged = output<string>();
  runEstimation = output<void>();

  activeSubTab = signal<'MODELS' | 'SCENARIOS'>('MODELS');

  public econometricsEngine = inject(EconometricsEngineService);
  public scenarioEngine = inject(ScenarioEngineService);

  onModelTypeChange(type: 'OLS' | 'VAR' | 'ARIMA' | 'KALMAN_FILTER') {
    this.modelTypeChanged.emit(type);
  }

  onScenarioSelect(id: string) {
    this.scenarioChanged.emit(id);
  }
}
