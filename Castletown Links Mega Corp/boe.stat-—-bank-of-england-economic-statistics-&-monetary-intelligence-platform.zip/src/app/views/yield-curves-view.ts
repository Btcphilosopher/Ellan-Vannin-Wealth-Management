import { ChangeDetectionStrategy, Component, computed, inject, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { BoeDataService } from '../services/boe-data';
import { YieldCurveEngineService } from '../services/yield-curve-engine';

@Component({
  selector: 'app-yield-curves-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule, FormsModule],
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-slate-900 border border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-amber-400">SOVEREIGN & MONEY MARKET BENCHMARKS</span>
            <span class="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-300">NSS EXTENDED FIT // 1979-2026 FABRIC</span>
          </div>
          <h1 class="text-xl font-serif font-bold text-slate-100 mt-1">UK Yield Curves & Term Structure Engine</h1>
        </div>

        <div class="flex items-center gap-2">
          <!-- View Sub-tabs -->
          <div class="flex bg-slate-950 p-1 border border-slate-800 text-xs font-mono">
            <button 
              (click)="activeTab.set('OVERLAY')" 
              [class.bg-slate-800]="activeTab() === 'OVERLAY'"
              [class.text-amber-300]="activeTab() === 'OVERLAY'"
              class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
            >
              Curve Multi-Overlay
            </button>
            <button 
              (click)="activeTab.set('TENOR_GRID')" 
              [class.bg-slate-800]="activeTab() === 'TENOR_GRID'"
              [class.text-amber-300]="activeTab() === 'TENOR_GRID'"
              class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
            >
              Tenor Matrix (1M-50Y)
            </button>
            <button 
              (click)="activeTab.set('NSS_MODEL')" 
              [class.bg-slate-800]="activeTab() === 'NSS_MODEL'"
              [class.text-amber-300]="activeTab() === 'NSS_MODEL'"
              class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
            >
              Nelson-Siegel-Svensson
            </button>
            <button 
              (click)="activeTab.set('PCA')" 
              [class.bg-slate-800]="activeTab() === 'PCA'"
              [class.text-amber-300]="activeTab() === 'PCA'"
              class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
            >
              PCA Factors
            </button>
            <button 
              (click)="activeTab.set('SURFACE_3D')" 
              [class.bg-slate-800]="activeTab() === 'SURFACE_3D'"
              [class.text-amber-300]="activeTab() === 'SURFACE_3D'"
              class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
            >
              Yield Surface
            </button>
          </div>
        </div>
      </div>

      <!-- Main Graphical Canvas / Curve Overlay -->
      @if (activeTab() === 'OVERLAY' || activeTab() === 'NSS_MODEL') {
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="flex items-center justify-between">
            <div class="flex items-center gap-4 text-xs font-mono">
              <label class="flex items-center gap-1.5 cursor-pointer text-amber-400">
                <input type="checkbox" [(ngModel)]="showNominal" class="accent-amber-500" />
                <span>Nominal Zero-Coupon</span>
              </label>
              <label class="flex items-center gap-1.5 cursor-pointer text-emerald-400">
                <input type="checkbox" [(ngModel)]="showReal" class="accent-emerald-500" />
                <span>Real Zero-Coupon (IL)</span>
              </label>
              <label class="flex items-center gap-1.5 cursor-pointer text-cyan-400">
                <input type="checkbox" [(ngModel)]="showBreakeven" class="accent-cyan-500" />
                <span>Breakeven Inflation</span>
              </label>
              <label class="flex items-center gap-1.5 cursor-pointer text-purple-400">
                <input type="checkbox" [(ngModel)]="showOis" class="accent-purple-500" />
                <span>SONIA OIS</span>
              </label>
              <label class="flex items-center gap-1.5 cursor-pointer text-rose-400">
                <input type="checkbox" [(ngModel)]="showForwards" class="accent-rose-500" />
                <span>Inst. Forward f(m)</span>
              </label>
            </div>

            <div class="text-[11px] font-mono text-slate-400">
              Observation Date: <span class="text-slate-200 font-bold">30 Sep 2026</span>
            </div>
          </div>

          <!-- SVG High-Precision Chart Viewport -->
          <div class="relative w-full h-80 bg-slate-950 border border-slate-800 p-2 overflow-hidden">
            <!-- Grid Lines & Axis Markers -->
            <svg class="w-full h-full" viewBox="0 0 800 300" preserveAspectRatio="none">
              <!-- Horizontal Grid (Yields 0% to 5%) -->
              <line x1="40" y1="20" x2="780" y2="20" stroke="#1e293b" stroke-dasharray="2 2" />
              <text x="35" y="24" fill="#64748b" font-size="9" text-anchor="end" font-family="monospace">5.0%</text>

              <line x1="40" y1="80" x2="780" y2="80" stroke="#1e293b" stroke-dasharray="2 2" />
              <text x="35" y="84" fill="#64748b" font-size="9" text-anchor="end" font-family="monospace">4.0%</text>

              <line x1="40" y1="140" x2="780" y2="140" stroke="#1e293b" stroke-dasharray="2 2" />
              <text x="35" y="144" fill="#64748b" font-size="9" text-anchor="end" font-family="monospace">3.0%</text>

              <line x1="40" y1="200" x2="780" y2="200" stroke="#1e293b" stroke-dasharray="2 2" />
              <text x="35" y="204" fill="#64748b" font-size="9" text-anchor="end" font-family="monospace">2.0%</text>

              <line x1="40" y1="260" x2="780" y2="260" stroke="#1e293b" stroke-dasharray="2 2" />
              <text x="35" y="264" fill="#64748b" font-size="9" text-anchor="end" font-family="monospace">1.0%</text>

              <!-- Tenor Vertical Lines (1Y, 5Y, 10Y, 20Y, 30Y, 50Y) -->
              <line x1="100" y1="20" x2="100" y2="280" stroke="#1e293b" stroke-dasharray="2 2" />
              <text x="100" y="295" fill="#64748b" font-size="9" text-anchor="middle" font-family="monospace">1Y</text>

              <line x1="200" y1="20" x2="200" y2="280" stroke="#1e293b" stroke-dasharray="2 2" />
              <text x="200" y="295" fill="#64748b" font-size="9" text-anchor="middle" font-family="monospace">5Y</text>

              <line x1="350" y1="20" x2="350" y2="280" stroke="#1e293b" stroke-dasharray="2 2" />
              <text x="350" y="295" fill="#64748b" font-size="9" text-anchor="middle" font-family="monospace">10Y</text>

              <line x1="500" y1="20" x2="500" y2="280" stroke="#1e293b" stroke-dasharray="2 2" />
              <text x="500" y="295" fill="#64748b" font-size="9" text-anchor="middle" font-family="monospace">20Y</text>

              <line x1="640" y1="20" x2="640" y2="280" stroke="#1e293b" stroke-dasharray="2 2" />
              <text x="640" y="295" fill="#64748b" font-size="9" text-anchor="middle" font-family="monospace">30Y</text>

              <line x1="760" y1="20" x2="760" y2="280" stroke="#1e293b" stroke-dasharray="2 2" />
              <text x="760" y="295" fill="#64748b" font-size="9" text-anchor="middle" font-family="monospace">50Y</text>

              <!-- Nominal Curve Polyline -->
              @if (showNominal) {
                <path [attr.d]="nominalPath()" fill="none" stroke="#f59e0b" stroke-width="2.5" />
              }

              <!-- Real Curve Polyline -->
              @if (showReal) {
                <path [attr.d]="realPath()" fill="none" stroke="#10b981" stroke-width="2" />
              }

              <!-- Breakeven Curve Polyline -->
              @if (showBreakeven) {
                <path [attr.d]="breakevenPath()" fill="none" stroke="#06b6d4" stroke-width="2" stroke-dasharray="4 2" />
              }

              <!-- OIS Curve Polyline -->
              @if (showOis) {
                <path [attr.d]="oisPath()" fill="none" stroke="#a855f7" stroke-width="1.8" />
              }

              <!-- Instantaneous Forward Curve Polyline -->
              @if (showForwards) {
                <path [attr.d]="forwardPath()" fill="none" stroke="#f43f5e" stroke-width="1.8" stroke-dasharray="3 3" />
              }
            </svg>
          </div>

          <!-- Key Metrics Footer -->
          <div class="grid grid-cols-2 md:grid-cols-5 gap-3 text-xs font-mono bg-slate-950 p-3 border border-slate-800">
            <div>
              <div class="text-[10px] text-slate-500 uppercase">10Y Nominal Level</div>
              <div class="text-sm font-bold text-amber-300">3.92% <span class="text-xs font-normal text-emerald-400">(-3.0bp)</span></div>
            </div>
            <div>
              <div class="text-[10px] text-slate-500 uppercase">2Y-10Y Slope</div>
              <div class="text-sm font-bold text-slate-200">+6.0 bp <span class="text-xs font-normal text-slate-400">(Flattish)</span></div>
            </div>
            <div>
              <div class="text-[10px] text-slate-500 uppercase">5Y-30Y Slope</div>
              <div class="text-sm font-bold text-slate-200">+68.0 bp <span class="text-xs font-normal text-slate-400">(Steep)</span></div>
            </div>
            <div>
              <div class="text-[10px] text-slate-500 uppercase">5Y Curvature</div>
              <div class="text-sm font-bold text-slate-200">-30.0 bp</div>
            </div>
            <div>
              <div class="text-[10px] text-slate-500 uppercase">ACM 10Y Term Premium</div>
              <div class="text-sm font-bold text-cyan-300">+18.0 bp</div>
            </div>
          </div>
        </div>
      }

      <!-- Tenor Grid View (1M to 50Y) -->
      @if (activeTab() === 'TENOR_GRID') {
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-sm font-mono font-bold text-slate-100">UK Sovereign Tenor Disaggregation & Risk Metrics</h3>
            <span class="text-xs font-mono text-slate-400">15 Standard Maturities // All Yields Quoted in % Annually Compounded</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-xs font-mono text-left">
              <thead>
                <tr class="text-slate-500 border-b border-slate-800 pb-2 text-[10px]">
                  <th class="py-2">TENOR</th>
                  <th>MATURITY</th>
                  <th>NOMINAL ZERO</th>
                  <th>REAL ZERO (IL)</th>
                  <th>BREAKEVEN</th>
                  <th>SONIA OIS</th>
                  <th>FORWARD f(m)</th>
                  <th>ACM TERM PREM</th>
                  <th>1D CHG</th>
                  <th>1M CHG</th>
                  <th>5Y %ILE</th>
                  <th class="text-right">ACTION</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                @for (pt of boeData.yieldCurveData; track pt.tenor) {
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-2 font-bold text-slate-200">{{ pt.tenor }}</td>
                    <td class="text-slate-400">{{ pt.maturityYears.toFixed(2) }}Y</td>
                    <td class="text-amber-300 font-semibold">{{ pt.nominalYield.toFixed(2) }}%</td>
                    <td class="text-emerald-400">{{ pt.realYield.toFixed(2) }}%</td>
                    <td class="text-cyan-400">{{ pt.breakevenInflation.toFixed(2) }}%</td>
                    <td class="text-purple-300">{{ pt.oisYield.toFixed(2) }}%</td>
                    <td class="text-rose-400">{{ pt.instantaneousForward.toFixed(2) }}%</td>
                    <td class="text-slate-300">{{ pt.termPremium >= 0 ? '+' : '' }}{{ (pt.termPremium * 100).toFixed(0) }}bp</td>
                    <td class="text-emerald-400">{{ pt.change1D }}bp</td>
                    <td class="text-slate-300">{{ pt.change1M }}bp</td>
                    <td>
                      <span class="px-1.5 py-0.2 bg-slate-800 text-slate-300 text-[10px]">{{ pt.percentile5Y }}th</span>
                    </td>
                    <td class="text-right">
                      <button (click)="openLineage.emit('GB.GILT.NOMINAL.ZERO.10Y.PCT')" class="text-[10px] text-amber-400 hover:underline">Lineage →</button>
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

      <!-- NSS Model Inspector & Live Parameter Tuning -->
      @if (activeTab() === 'NSS_MODEL') {
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="border-b border-slate-800 pb-3">
            <h3 class="text-sm font-mono font-bold text-slate-100">Nelson-Siegel-Svensson Extended Fitting Model</h3>
            <p class="text-xs text-slate-400 font-mono mt-0.5">Parameters estimated via non-linear least squares on daily DMO gilt closing mid-prices.</p>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-3">
            <div class="bg-slate-950 p-3 border border-slate-800 font-mono text-xs">
              <div class="text-slate-500 text-[10px]">BETA 0 (Long Rate)</div>
              <div class="text-lg font-bold text-amber-400">{{ boeData.nssParams.beta0 }}%</div>
            </div>
            <div class="bg-slate-950 p-3 border border-slate-800 font-mono text-xs">
              <div class="text-slate-500 text-[10px]">BETA 1 (Short Slope)</div>
              <div class="text-lg font-bold text-slate-200">{{ boeData.nssParams.beta1 }}%</div>
            </div>
            <div class="bg-slate-950 p-3 border border-slate-800 font-mono text-xs">
              <div class="text-slate-500 text-[10px]">BETA 2 (Curvature 1)</div>
              <div class="text-lg font-bold text-slate-200">{{ boeData.nssParams.beta2 }}%</div>
            </div>
            <div class="bg-slate-950 p-3 border border-slate-800 font-mono text-xs">
              <div class="text-slate-500 text-[10px]">BETA 3 (Curvature 2)</div>
              <div class="text-lg font-bold text-slate-200">{{ boeData.nssParams.beta3 }}%</div>
            </div>
            <div class="bg-slate-950 p-3 border border-slate-800 font-mono text-xs">
              <div class="text-slate-500 text-[10px]">TAU 1 (Scale 1)</div>
              <div class="text-lg font-bold text-cyan-400">{{ boeData.nssParams.tau1 }}</div>
            </div>
            <div class="bg-slate-950 p-3 border border-slate-800 font-mono text-xs">
              <div class="text-slate-500 text-[10px]">FIT R-SQUARED</div>
              <div class="text-lg font-bold text-emerald-400">{{ boeData.nssParams.fitR2 }}</div>
            </div>
          </div>
        </div>
      }

      <!-- PCA Factors View -->
      @if (activeTab() === 'PCA') {
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="border-b border-slate-800 pb-3">
            <h3 class="text-sm font-mono font-bold text-slate-100">Principal Component Analysis (PCA) Factor Decomposition</h3>
            <p class="text-xs text-slate-400 font-mono mt-0.5">Statistical decomposition of UK yield curve variations into Level, Slope, and Curvature orthogonal factors.</p>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div class="bg-slate-950 p-4 border border-slate-800 text-xs font-mono">
              <div class="text-[10px] text-amber-400 font-bold uppercase">Factor 1: Level Shift</div>
              <div class="text-2xl font-bold text-slate-100 mt-1">{{ boeData.pcaFactors.factor1LevelPct }}%</div>
              <div class="text-slate-400 mt-1">Parallel shift across all maturities driven by global macro & expected rate path.</div>
            </div>
            <div class="bg-slate-950 p-4 border border-slate-800 text-xs font-mono">
              <div class="text-[10px] text-emerald-400 font-bold uppercase">Factor 2: Slope / Twist</div>
              <div class="text-2xl font-bold text-slate-100 mt-1">{{ boeData.pcaFactors.factor2SlopePct }}%</div>
              <div class="text-slate-400 mt-1">Steepening / flattening driven by near-term monetary cycle vs long-term growth.</div>
            </div>
            <div class="bg-slate-950 p-4 border border-slate-800 text-xs font-mono">
              <div class="text-[10px] text-cyan-400 font-bold uppercase">Factor 3: Curvature / Butterfly</div>
              <div class="text-2xl font-bold text-slate-100 mt-1">{{ boeData.pcaFactors.factor3CurvaturePct }}%</div>
              <div class="text-slate-400 mt-1">Belly curvature driven by intermediate tenor demand and term premium humps.</div>
            </div>
          </div>

          <!-- Factor Loadings Table -->
          <div class="mt-4">
            <h4 class="text-xs font-mono font-bold text-slate-300 mb-2">Eigenvector Loadings by Tenor</h4>
            <div class="overflow-x-auto">
              <table class="w-full text-xs font-mono text-left">
                <thead>
                  <tr class="text-slate-500 border-b border-slate-800 text-[10px]">
                    <th class="py-1.5">TENOR</th>
                    <th>FACTOR 1 (LEVEL)</th>
                    <th>FACTOR 2 (SLOPE)</th>
                    <th>FACTOR 3 (CURVATURE)</th>
                  </tr>
                </thead>
                <tbody class="divide-y divide-slate-800/60">
                  @for (ld of boeData.pcaFactors.loadings; track ld.tenor) {
                    <tr>
                      <td class="py-1.5 font-bold text-slate-200">{{ ld.tenor }}</td>
                      <td class="text-amber-300">{{ ld.level >= 0 ? '+' : '' }}{{ ld.level.toFixed(2) }}</td>
                      <td class="text-emerald-400">{{ ld.slope >= 0 ? '+' : '' }}{{ ld.slope.toFixed(2) }}</td>
                      <td class="text-cyan-400">{{ ld.curvature >= 0 ? '+' : '' }}{{ ld.curvature.toFixed(2) }}</td>
                    </tr>
                  }
                </tbody>
              </table>
            </div>
          </div>
        </div>
      }

      <!-- Yield Surface 3D / Historical Playback -->
      @if (activeTab() === 'SURFACE_3D') {
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h3 class="text-sm font-mono font-bold text-slate-100">Yield Curve Surface (Maturity X Date X Yield)</h3>
              <p class="text-xs text-slate-400 font-mono mt-0.5">Historical evolution of the UK term structure across policy cycles.</p>
            </div>
            <div class="flex items-center gap-2">
              <button 
                (click)="stepSurface(-1)" 
                [disabled]="surfaceIdx() === 0"
                class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-200 text-xs font-mono cursor-pointer"
              >
                ← Prev Date
              </button>
              <span class="text-xs font-mono font-bold text-amber-400 px-2">{{ surfaceData()[surfaceIdx()].label }} ({{ surfaceData()[surfaceIdx()].date }})</span>
              <button 
                (click)="stepSurface(1)" 
                [disabled]="surfaceIdx() === surfaceData().length - 1"
                class="px-2.5 py-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-30 text-slate-200 text-xs font-mono cursor-pointer"
              >
                Next Date →
              </button>
            </div>
          </div>

          <!-- Surface Table -->
          <div class="overflow-x-auto">
            <table class="w-full text-xs font-mono text-left">
              <thead>
                <tr class="text-slate-500 border-b border-slate-800 pb-2 text-[10px]">
                  <th class="py-2">TENOR</th>
                  <th>1Y</th>
                  <th>2Y</th>
                  <th>5Y</th>
                  <th>10Y</th>
                  <th>20Y</th>
                  <th>30Y</th>
                  <th>50Y</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                @for (entry of surfaceData(); track entry.date; let i = $index) {
                  <tr [class.bg-amber-950/20]="surfaceIdx() === i" class="hover:bg-slate-800/40">
                    <td class="py-2 font-bold text-slate-300">{{ entry.date }} ({{ entry.label }})</td>
                    @for (pt of entry.points; track pt.tenor) {
                      <td class="text-slate-100 font-medium">{{ pt.yield.toFixed(2) }}%</td>
                    }
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }
    </div>
  `,
})
export class YieldCurvesViewComponent {
  openLineage = output<string>();

  public boeData = inject(BoeDataService);
  public yieldCurveEngine = inject(YieldCurveEngineService);

  activeTab = signal<'OVERLAY' | 'TENOR_GRID' | 'NSS_MODEL' | 'PCA' | 'SURFACE_3D'>('OVERLAY');

  showNominal = true;
  showReal = true;
  showBreakeven = true;
  showOis = true;
  showForwards = false;

  surfaceIdx = signal<number>(8);
  surfaceData = signal(this.yieldCurveEngine.generateYieldSurface());

  stepSurface(delta: number) {
    const next = Math.max(0, Math.min(this.surfaceData().length - 1, this.surfaceIdx() + delta));
    this.surfaceIdx.set(next);
  }

  // Path generators for SVG curve representation
  nominalPath = computed(() => {
    return 'M 40,35 L 70,42 L 100,60 L 150,84 L 200,94 L 250,90 L 350,80 L 500,60 L 640,50 L 760,65';
  });

  realPath = computed(() => {
    return 'M 40,210 L 70,212 L 100,225 L 150,240 L 200,250 L 250,255 L 350,248 L 500,235 L 640,230 L 760,240';
  });

  breakevenPath = computed(() => {
    return 'M 40,142 L 70,144 L 100,148 L 150,152 L 200,150 L 250,146 L 350,138 L 500,130 L 640,126 L 760,128';
  });

  oisPath = computed(() => {
    return 'M 40,36 L 70,44 L 100,62 L 150,88 L 200,98 L 250,94 L 350,86 L 500,72 L 640,66 L 760,78';
  });

  forwardPath = computed(() => {
    return 'M 40,38 L 70,48 L 100,72 L 150,92 L 200,88 L 250,78 L 350,62 L 500,48 L 640,44 L 760,60';
  });
}
