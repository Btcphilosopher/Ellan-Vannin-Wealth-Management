import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { BoeDataService } from '../services/boe-data';

@Component({
  selector: 'app-stability-policy-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-slate-900 border border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-amber-400">FINANCIAL POLICY COMMITTEE (FPC) & MPC BRIEFING</span>
            <span class="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-300">MACROPRUDENTIAL SURVEILLANCE & SYSTEMIC RISK</span>
          </div>
          <h1 class="text-xl font-serif font-bold text-slate-100 mt-1">Financial Stability & Monetary Policy Workspace</h1>
        </div>

        <div class="flex items-center gap-3 text-xs font-mono">
          <div class="bg-slate-950 px-3 py-1 border border-slate-800">
            <span class="text-slate-500">CET1 Capital:</span> <strong class="text-emerald-400">16.20%</strong>
          </div>
          <div class="bg-slate-950 px-3 py-1 border border-slate-800">
            <span class="text-slate-500">BoE FCI:</span> <strong class="text-slate-100">+0.12 (Neutral)</strong>
          </div>
        </div>
      </div>

      <!-- Financial Conditions Index (FCI) Detailed Breakdown -->
      <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 class="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400 text-sm">tune</mat-icon>
              Financial Conditions Index (FCI) Component Matrix
            </h3>
            <p class="text-xs text-slate-400 font-mono mt-0.5">
              Principal Component Analysis (PCA) weighting across money markets, government yields, credit spreads, equity, and foreign exchange.
            </p>
          </div>
          <button type="button" (click)="openLineage.emit('GB.FCI.COMPOSITE.INDEX')" class="text-xs font-mono text-amber-400 hover:underline cursor-pointer">FCI Lineage →</button>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono text-left">
            <thead>
              <tr class="text-slate-500 border-b border-slate-800 pb-2 text-[10px]">
                <th class="py-2">INPUT COMPONENT</th>
                <th>CODE</th>
                <th>RAW LEVEL</th>
                <th>STANDARDISED (Z-SCORE)</th>
                <th>PCA WEIGHT</th>
                <th>WEIGHTED CONTRIBUTION</th>
                <th class="text-right">STANCE</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (comp of boeData.fciComponents; track comp.code) {
                <tr class="hover:bg-slate-800/40">
                  <td class="py-2.5 font-bold text-slate-200">{{ comp.name }}</td>
                  <td class="text-slate-400">{{ comp.code }}</td>
                  <td class="text-slate-100 font-bold">{{ comp.rawLevel }}</td>
                  <td [class.text-amber-300]="comp.zScore > 0" [class.text-emerald-400]="comp.zScore <= 0">
                    {{ comp.zScore >= 0 ? '+' : '' }}{{ comp.zScore.toFixed(2) }}
                  </td>
                  <td class="text-slate-300 font-medium">{{ (comp.weight * 100).toFixed(0) }}%</td>
                  <td class="font-bold text-slate-100">
                    {{ comp.weightedContribution >= 0 ? '+' : '' }}{{ comp.weightedContribution.toFixed(2) }}
                  </td>
                  <td class="text-right">
                    @if (comp.direction === 'TIGHTENING') {
                      <span class="px-2 py-0.5 bg-amber-950 text-amber-400 text-[10px]">TIGHTENING</span>
                    } @else {
                      <span class="px-2 py-0.5 bg-emerald-950 text-emerald-400 text-[10px]">EASING</span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- FPC Systemic Risk Map -->
      <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 class="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400 text-sm">hub</mat-icon>
              FPC Systemic Risk Map (Node Vulnerability Assessment)
            </h3>
            <p class="text-xs text-slate-400 font-mono mt-0.5">
              Comprehensive surveillance nodes covering Households, Corporates, Banking System, NBFI, Sovereign, and External linkages.
            </p>
          </div>
          <span class="text-xs font-mono text-emerald-400">FINANCIAL STABILITY REPORT VINTAGE</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (node of boeData.systemicRiskNodes; track node.id) {
            <div class="bg-slate-950 p-4 border border-slate-800 text-xs font-mono space-y-3">
              <div class="flex items-center justify-between">
                <span class="text-[10px] text-slate-400 uppercase font-bold">{{ node.sector }}</span>
                @if (node.vulnerabilityScore > 60) {
                  <span class="px-2 py-0.5 bg-red-950 text-red-400 text-[10px] font-bold">ELEVATED ({{ node.vulnerabilityScore }}/100)</span>
                } @else if (node.vulnerabilityScore > 40) {
                  <span class="px-2 py-0.5 bg-amber-950 text-amber-400 text-[10px] font-bold">MODERATE ({{ node.vulnerabilityScore }}/100)</span>
                } @else {
                  <span class="px-2 py-0.5 bg-emerald-950 text-emerald-400 text-[10px] font-bold">LOW ({{ node.vulnerabilityScore }}/100)</span>
                }
              </div>

              <div>
                <h4 class="text-sm font-bold text-slate-100">{{ node.label }}</h4>
                <div class="text-[11px] text-amber-300 font-semibold mt-0.5">{{ node.headlineMetric }}: {{ node.headlineValue }}</div>
              </div>

              <!-- Risk Bullets -->
              <div class="space-y-1 pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 font-sans">
                @for (risk of node.keyRisks; track risk) {
                  <div class="flex items-start gap-1.5">
                    <span class="text-amber-500">•</span>
                    <span>{{ risk }}</span>
                  </div>
                }
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `,
})
export class StabilityPolicyViewComponent {
  openLineage = output<string>();

  public boeData = inject(BoeDataService);
}
