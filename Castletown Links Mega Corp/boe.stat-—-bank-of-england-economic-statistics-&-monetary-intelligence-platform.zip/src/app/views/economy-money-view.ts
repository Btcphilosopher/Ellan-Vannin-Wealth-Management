import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { BoeDataService } from '../services/boe-data';

@Component({
  selector: 'app-economy-money-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-slate-900 border border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-amber-400">NATIONAL ACCOUNTS, LABOUR & MONETARY AGGREGATES</span>
            <span class="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-300">FORM BT // BLUE BOOK 2026 // LFS WEIGHTED</span>
          </div>
          <h1 class="text-xl font-serif font-bold text-slate-100 mt-1">Macroeconomy, Money & Credit Statistics</h1>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono">
          <span class="px-2.5 py-1 bg-slate-800 text-slate-200">Real GDP: <strong class="text-emerald-400">+1.20% YoY</strong></span>
          <span class="px-2.5 py-1 bg-slate-800 text-slate-200">M4ex Growth: <strong class="text-slate-100">+3.40% YoY</strong></span>
        </div>
      </div>

      <!-- Macro Indicators Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <button type="button" (click)="openLineage.emit('GB.GDP.REAL.YOY.PCT.Q')" class="w-full text-left bg-slate-900/80 border border-slate-800 p-4 hover:border-amber-500/40 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">Real GDP Growth</div>
          <div class="text-2xl font-mono font-bold text-slate-100 my-1">+1.20% <span class="text-xs font-normal text-slate-400">YoY</span></div>
          <div class="text-[11px] font-mono text-emerald-400">Q2 2026: +0.42% QoQ</div>
        </button>

        <button type="button" (click)="openLineage.emit('GB.LABOUR.UNEMPLOYMENT.ILO.PCT.M')" class="w-full text-left bg-slate-900/80 border border-slate-800 p-4 hover:border-amber-500/40 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">Unemployment Rate (ILO)</div>
          <div class="text-2xl font-mono font-bold text-slate-100 my-1">4.10%</div>
          <div class="text-[11px] font-mono text-slate-400">Slack: Modest // Vacancies: 860k</div>
        </button>

        <button type="button" (click)="openLineage.emit('GB.LABOUR.WAGES.AWE.REGULAR.YOY.PCT.M')" class="w-full text-left bg-slate-900/80 border border-slate-800 p-4 hover:border-amber-500/40 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">AWE Regular Pay Growth</div>
          <div class="text-2xl font-mono font-bold text-amber-300 my-1">4.70% <span class="text-xs font-normal text-slate-400">YoY</span></div>
          <div class="text-[11px] font-mono text-slate-400">Real Wage Growth: +2.40% YoY</div>
        </button>

        <button type="button" (click)="openLineage.emit('GB.BOE.BALANCE.APF.TOTAL.GBP.BN')" class="w-full text-left bg-slate-900/80 border border-slate-800 p-4 hover:border-amber-500/40 cursor-pointer">
          <div class="text-[10px] font-mono text-slate-400 uppercase">BoE APF Gilt Stock (QT)</div>
          <div class="text-2xl font-mono font-bold text-slate-100 my-1">£558.0 <span class="text-xs font-normal text-slate-400">Bn</span></div>
          <div class="text-[11px] font-mono text-emerald-400">-£100bn/yr reduction pace</div>
        </button>
      </div>

      <!-- Money & Credit Deep Dive -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- Broad Money & Bank Lending -->
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-sm font-mono font-bold text-slate-100">Broad Money (M4ex) & Bank Balance Sheets</h3>
            <button type="button" (click)="openLineage.emit('GB.MONEY.M4EX.GROWTH.YOY.PCT.M')" class="text-xs font-mono text-amber-400 hover:underline cursor-pointer">M4ex Provenance →</button>
          </div>

          <div class="space-y-3 font-mono text-xs">
            <div class="p-3 bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <div class="text-slate-400 text-[10px] uppercase">Broad Money M4ex Stock</div>
                <div class="text-base font-bold text-slate-100">£3,142 Billion</div>
              </div>
              <div class="text-right">
                <div class="text-emerald-400 font-bold">+3.40% YoY</div>
                <div class="text-[10px] text-slate-500">12M Annual Growth</div>
              </div>
            </div>

            <div class="p-3 bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <div class="text-slate-400 text-[10px] uppercase">BoE Sterling Reserve Balances</div>
                <div class="text-base font-bold text-slate-100">£742.5 Billion</div>
              </div>
              <div class="text-right">
                <div class="text-slate-300 font-bold">SMF Framework</div>
                <div class="text-[10px] text-slate-500">Remunerated at Bank Rate</div>
              </div>
            </div>

            <div class="p-3 bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <div class="text-slate-400 text-[10px] uppercase">Notes & Coin in Circulation</div>
                <div class="text-base font-bold text-slate-100">£89.2 Billion</div>
              </div>
              <div class="text-right">
                <div class="text-slate-300 font-bold">+1.8% YoY</div>
                <div class="text-[10px] text-slate-500">Narrow Money</div>
              </div>
            </div>
          </div>
        </div>

        <!-- Household & Corporate Credit Flows -->
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-3">
            <h3 class="text-sm font-mono font-bold text-slate-100">Household & Corporate Lending Conditions</h3>
            <button type="button" (click)="openLineage.emit('GB.CREDIT.MORTGAGE.NET.FLOW.GBP.M')" class="text-xs font-mono text-amber-400 hover:underline cursor-pointer">Mortgage Lineage →</button>
          </div>

          <div class="space-y-3 font-mono text-xs">
            <div class="p-3 bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <div class="text-slate-400 text-[10px] uppercase">Net Mortgage Lending (Monthly Flow)</div>
                <div class="text-base font-bold text-slate-100">£2,840 Million</div>
              </div>
              <div class="text-right">
                <div class="text-emerald-400 font-bold">+£190m MoM</div>
                <div class="text-[10px] text-slate-500">Approvals: 64.8k</div>
              </div>
            </div>

            <div class="p-3 bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <div class="text-slate-400 text-[10px] uppercase">Quoted 2Y 75% LTV Mortgage Rate</div>
                <div class="text-base font-bold text-amber-300">4.48%</div>
              </div>
              <div class="text-right">
                <div class="text-emerald-400 font-bold">-68bp 1Y</div>
                <div class="text-[10px] text-slate-500">Easing Pressure</div>
              </div>
            </div>

            <div class="p-3 bg-slate-950 border border-slate-800 flex justify-between items-center">
              <div>
                <div class="text-slate-400 text-[10px] uppercase">Consumer Credit (Credit Cards & Personal)</div>
                <div class="text-base font-bold text-slate-100">£1,250 Million / Mo</div>
              </div>
              <div class="text-right">
                <div class="text-slate-300 font-bold">+7.2% YoY</div>
                <div class="text-[10px] text-slate-500">Unsecured Lending</div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  `,
})
export class EconomyMoneyViewComponent {
  openLineage = output<string>();

  public boeData = inject(BoeDataService);
}
