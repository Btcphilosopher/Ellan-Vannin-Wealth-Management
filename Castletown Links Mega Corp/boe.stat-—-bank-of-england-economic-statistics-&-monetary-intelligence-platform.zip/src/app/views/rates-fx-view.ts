import { ChangeDetectionStrategy, Component, inject, output } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { BoeDataService } from '../services/boe-data';

@Component({
  selector: 'app-rates-fx-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-slate-900 border border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-amber-400">MONEY MARKETS & STERLING FOREIGN EXCHANGE</span>
            <span class="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-300">DAILY SMMD // REFINITIV 16:00 BENCHMARK</span>
          </div>
          <h1 class="text-xl font-serif font-bold text-slate-100 mt-1">Bank Rate, SONIA & Sterling FX Matrix</h1>
        </div>

        <div class="flex items-center gap-2 text-xs font-mono">
          <span class="px-2.5 py-1 bg-slate-800 text-slate-200">Current Bank Rate: <strong class="text-amber-300">4.50%</strong></span>
          <span class="px-2.5 py-1 bg-slate-800 text-slate-200">SONIA: <strong class="text-slate-100">4.45%</strong></span>
        </div>
      </div>

      <!-- Policy Path View (OIS Implied MPC Probabilities) -->
      <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 class="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400 text-sm">timeline</mat-icon>
              Market-Implied Policy Path (Forward SONIA OIS Curve)
            </h3>
            <p class="text-xs text-slate-400 font-mono mt-0.5">
              Market expectations of future Official Bank Rate priced into the OIS curve mapped to scheduled MPC decision dates.
            </p>
          </div>
          <span class="text-xs font-mono text-emerald-400">NO AUTOMATIC TRADING SIGNALS // PURE ANALYTICAL PRICING</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono text-left">
            <thead>
              <tr class="text-slate-500 border-b border-slate-800 pb-2 text-[10px]">
                <th class="py-2">MPC DECISION DATE</th>
                <th>MEETING LABEL</th>
                <th>IMPLIED RATE</th>
                <th>CURRENT RATE</th>
                <th>CUMULATIVE CHG</th>
                <th>P(25BP CUT)</th>
                <th>P(HOLD)</th>
                <th>MARKET STANCE</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (pt of boeData.policyPathData; track pt.mpcDate) {
                <tr class="hover:bg-slate-800/40">
                  <td class="py-2.5 font-bold text-slate-200">{{ pt.mpcDate }}</td>
                  <td class="text-amber-300">{{ pt.meetingLabel }}</td>
                  <td class="text-slate-100 font-bold">{{ pt.impliedRate.toFixed(2) }}%</td>
                  <td class="text-slate-400">{{ pt.currentBankRate.toFixed(2) }}%</td>
                  <td [class.text-emerald-400]="pt.cumulativeChangeBp < 0" class="font-medium">
                    {{ pt.cumulativeChangeBp >= 0 ? '+' : '' }}{{ pt.cumulativeChangeBp }} bp
                  </td>
                  <td>
                    <div class="flex items-center gap-2">
                      <div class="w-16 h-2 bg-slate-800 overflow-hidden">
                        <div class="h-full bg-emerald-500" [style.width.%]="pt.probability25bpCut"></div>
                      </div>
                      <span class="text-emerald-400">{{ pt.probability25bpCut }}%</span>
                    </div>
                  </td>
                  <td>
                    <div class="flex items-center gap-2">
                      <div class="w-16 h-2 bg-slate-800 overflow-hidden">
                        <div class="h-full bg-slate-400" [style.width.%]="pt.probabilityHold"></div>
                      </div>
                      <span class="text-slate-400">{{ pt.probabilityHold }}%</span>
                    </div>
                  </td>
                  <td>
                    @if (pt.probability25bpCut > 60) {
                      <span class="px-1.5 py-0.2 bg-emerald-950 text-emerald-400 text-[10px]">CUT PRICED IN</span>
                    } @else if (pt.probability25bpCut > 30) {
                      <span class="px-1.5 py-0.2 bg-amber-950 text-amber-400 text-[10px]">LIVE MEETING</span>
                    } @else {
                      <span class="px-1.5 py-0.2 bg-slate-800 text-slate-400 text-[10px]">HOLD EXPECTED</span>
                    }
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>

      <!-- Sterling FX Matrix -->
      <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
        <div class="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h3 class="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
              <mat-icon class="text-amber-400 text-sm">currency_exchange</mat-icon>
              Sterling Foreign Exchange (GBP FX Matrix)
            </h3>
            <p class="text-xs text-slate-400 font-mono mt-0.5">
              Spot rates, multi-horizon percentage changes, 30D/90D historical volatility, carry yields, and purchasing-power parity (PPP).
            </p>
          </div>
          <button type="button" (click)="openLineage.emit('GBP.USD.SPOT')" class="text-xs font-mono text-amber-400 hover:underline cursor-pointer">Inspect Cable Lineage →</button>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-xs font-mono text-left">
            <thead>
              <tr class="text-slate-500 border-b border-slate-800 pb-2 text-[10px]">
                <th class="py-2">PAIR</th>
                <th>SPOT RATE</th>
                <th>1D CHG</th>
                <th>1W CHG</th>
                <th>1M CHG</th>
                <th>3M CHG</th>
                <th>1Y CHG</th>
                <th>5Y CHG</th>
                <th>30D VOL</th>
                <th>CARRY YIELD</th>
                <th>REER INDEX</th>
                <th class="text-right">PPP VALUATION</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (fx of boeData.fxCrosses; track fx.pair) {
                <tr class="hover:bg-slate-800/40">
                  <td class="py-2.5 font-bold text-slate-200 flex items-center gap-1.5">
                    <span class="w-1.5 h-1.5 bg-amber-400 rounded-full"></span>
                    {{ fx.pair }}
                  </td>
                  <td class="text-slate-100 font-bold">{{ fx.spot }}</td>
                  <td [class.text-emerald-400]="fx.change1D >= 0" [class.text-rose-400]="fx.change1D < 0">
                    {{ fx.change1D >= 0 ? '+' : '' }}{{ fx.change1D }}%
                  </td>
                  <td [class.text-emerald-400]="fx.change1W >= 0" [class.text-rose-400]="fx.change1W < 0">
                    {{ fx.change1W >= 0 ? '+' : '' }}{{ fx.change1W }}%
                  </td>
                  <td [class.text-emerald-400]="fx.change1M >= 0" [class.text-rose-400]="fx.change1M < 0">
                    {{ fx.change1M >= 0 ? '+' : '' }}{{ fx.change1M }}%
                  </td>
                  <td [class.text-emerald-400]="fx.change3M >= 0" [class.text-rose-400]="fx.change3M < 0">
                    {{ fx.change3M >= 0 ? '+' : '' }}{{ fx.change3M }}%
                  </td>
                  <td [class.text-emerald-400]="fx.change1Y >= 0" [class.text-rose-400]="fx.change1Y < 0">
                    {{ fx.change1Y >= 0 ? '+' : '' }}{{ fx.change1Y }}%
                  </td>
                  <td [class.text-emerald-400]="fx.change5Y >= 0" [class.text-rose-400]="fx.change5Y < 0">
                    {{ fx.change5Y >= 0 ? '+' : '' }}{{ fx.change5Y }}%
                  </td>
                  <td class="text-slate-300">{{ fx.volatility30D }}%</td>
                  <td class="text-amber-300">{{ fx.carryYieldPct >= 0 ? '+' : '' }}{{ fx.carryYieldPct }}%</td>
                  <td class="text-slate-300">{{ fx.reerIndex }}</td>
                  <td class="text-right" [class.text-emerald-400]="fx.pppValuationPct >= 0" [class.text-rose-400]="fx.pppValuationPct < 0">
                    {{ fx.pppValuationPct >= 0 ? '+' : '' }}{{ fx.pppValuationPct }}%
                  </td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class RatesFxViewComponent {
  openLineage = output<string>();

  public boeData = inject(BoeDataService);
}
