import { ChangeDetectionStrategy, Component, inject, input, output, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { BoeDataService } from '../services/boe-data';

@Component({
  selector: 'app-vintages-reports-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Section Header -->
      <div class="bg-slate-900 border border-slate-800 p-4 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="text-xs font-mono font-bold text-amber-400">ECONOMIC TIME MACHINE & VINTAGE REVISION TRIANGLES</span>
            <span class="text-[10px] font-mono px-1.5 py-0.2 bg-slate-800 text-slate-300">AS-PUBLISHED MEMORY // REVISION TRACKING</span>
          </div>
          <h1 class="text-xl font-serif font-bold text-slate-100 mt-1">Vintage Database & Institutional Reports</h1>
        </div>

        <div class="flex bg-slate-950 p-1 border border-slate-800 text-xs font-mono">
          <button 
            (click)="activeSubTab.set('TIME_MACHINE')" 
            [class.bg-slate-800]="activeSubTab() === 'TIME_MACHINE'"
            [class.text-amber-300]="activeSubTab() === 'TIME_MACHINE'"
            class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            Economic Time Machine
          </button>
          <button 
            (click)="activeSubTab.set('REVISION_TRIANGLES')" 
            [class.bg-slate-800]="activeSubTab() === 'REVISION_TRIANGLES'"
            [class.text-amber-300]="activeSubTab() === 'REVISION_TRIANGLES'"
            class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            GDP Revision Triangles
          </button>
          <button 
            (click)="activeSubTab.set('REPORTS')" 
            [class.bg-slate-800]="activeSubTab() === 'REPORTS'"
            [class.text-amber-300]="activeSubTab() === 'REPORTS'"
            class="px-3 py-1 text-slate-400 hover:text-slate-200 cursor-pointer"
          >
            Report Generator & Exporter
          </button>
        </div>
      </div>

      <!-- Tab 1: Economic Time Machine -->
      @if (activeSubTab() === 'TIME_MACHINE') {
        <div class="space-y-6">
          <!-- Preset Selector -->
          <div class="bg-slate-900 border border-slate-800 p-5 space-y-3">
            <h3 class="text-sm font-mono font-bold text-slate-100">Select Historical Economic Memory Milestone</h3>
            <div class="grid grid-cols-1 md:grid-cols-5 gap-3 text-xs font-mono">
              <button 
                type="button"
                (click)="presetSelected.emit('2008_LEHMAN')" 
                [class.border-amber-500]="activePreset() === '2008_LEHMAN'"
                [class.bg-slate-950]="activePreset() === '2008_LEHMAN'"
                class="w-full p-3 bg-slate-950/40 border border-slate-800 hover:border-slate-700 text-left transition cursor-pointer"
              >
                <div class="text-amber-400 font-bold">15 SEP 2008</div>
                <div class="text-slate-200 font-semibold mt-1">Lehman Collapse</div>
                <div class="text-[10px] text-slate-400 mt-0.5">Bank Rate: 5.00% // 10Y: 4.54%</div>
              </button>

              <button 
                type="button"
                (click)="presetSelected.emit('2016_BREXIT')" 
                [class.border-amber-500]="activePreset() === '2016_BREXIT'"
                [class.bg-slate-950]="activePreset() === '2016_BREXIT'"
                class="w-full p-3 bg-slate-950/40 border border-slate-800 hover:border-slate-700 text-left transition cursor-pointer"
              >
                <div class="text-amber-400 font-bold">23 JUN 2016</div>
                <div class="text-slate-200 font-semibold mt-1">EU Referendum</div>
                <div class="text-[10px] text-slate-400 mt-0.5">GBP/USD: 1.48 // 10Y: 1.37%</div>
              </button>

              <button 
                type="button"
                (click)="presetSelected.emit('2020_COVID')" 
                [class.border-amber-500]="activePreset() === '2020_COVID'"
                [class.bg-slate-950]="activePreset() === '2020_COVID'"
                class="w-full p-3 bg-slate-950/40 border border-slate-800 hover:border-slate-700 text-left transition cursor-pointer"
              >
                <div class="text-amber-400 font-bold">23 MAR 2020</div>
                <div class="text-slate-200 font-semibold mt-1">Covid Lockdown</div>
                <div class="text-[10px] text-slate-400 mt-0.5">Bank Rate: 0.10% // 10Y: 0.44%</div>
              </button>

              <button 
                type="button"
                (click)="presetSelected.emit('2022_MINI_BUDGET')" 
                [class.border-amber-500]="activePreset() === '2022_MINI_BUDGET'"
                [class.bg-slate-950]="activePreset() === '2022_MINI_BUDGET'"
                class="w-full p-3 bg-slate-950/40 border border-slate-800 hover:border-slate-700 text-left transition cursor-pointer"
              >
                <div class="text-amber-400 font-bold">23 SEP 2022</div>
                <div class="text-slate-200 font-semibold mt-1">Mini-Budget Shock</div>
                <div class="text-[10px] text-slate-400 mt-0.5">10Y Gilt: 4.50% // Cable: 1.08</div>
              </button>

              <button 
                type="button"
                (click)="presetSelected.emit('2026_CURRENT')" 
                [class.border-amber-500]="activePreset() === '2026_CURRENT'"
                [class.bg-slate-950]="activePreset() === '2026_CURRENT'"
                class="w-full p-3 bg-slate-950/40 border border-slate-800 hover:border-slate-700 text-left transition cursor-pointer"
              >
                <div class="text-emerald-400 font-bold">30 SEP 2026</div>
                <div class="text-slate-200 font-semibold mt-1">Current State</div>
                <div class="text-[10px] text-slate-400 mt-0.5">Bank Rate: 4.50% // CPI: 2.30%</div>
              </button>
            </div>
          </div>

          <!-- Reconstructed Information Matrix for Selected Date -->
          <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <h3 class="text-sm font-mono font-bold text-slate-100 flex items-center gap-2">
                  <mat-icon class="text-amber-400 text-sm">history_toggle_off</mat-icon>
                  Information Set Available to Policymakers on {{ activePreset() }}
                </h3>
                <p class="text-xs text-slate-400 font-mono mt-0.5">
                  Full vintage reconstruction: "What did the Bank of England know at that exact point in time?"
                </p>
              </div>
              <span class="text-xs font-mono text-amber-300">EXACT VINTAGE REPLAY</span>
            </div>

            <div class="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs font-mono">
              <div class="p-3 bg-slate-950 border border-slate-800">
                <div class="text-slate-400 text-[10px]">RECONSTRUCTED BANK RATE</div>
                <div class="text-xl font-bold text-slate-100 mt-1">
                  {{ activePreset() === '2008_LEHMAN' ? '5.00%' : activePreset() === '2016_BREXIT' ? '0.50%' : activePreset() === '2020_COVID' ? '0.10%' : activePreset() === '2022_MINI_BUDGET' ? '2.25%' : '4.50%' }}
                </div>
              </div>

              <div class="p-3 bg-slate-950 border border-slate-800">
                <div class="text-slate-400 text-[10px]">10Y GILT YIELD AT THE TIME</div>
                <div class="text-xl font-bold text-amber-300 mt-1">
                  {{ activePreset() === '2008_LEHMAN' ? '4.54%' : activePreset() === '2016_BREXIT' ? '1.37%' : activePreset() === '2020_COVID' ? '0.44%' : activePreset() === '2022_MINI_BUDGET' ? '4.50%' : '3.92%' }}
                </div>
              </div>

              <div class="p-3 bg-slate-950 border border-slate-800">
                <div class="text-slate-400 text-[10px]">STERLING / USD (CABLE)</div>
                <div class="text-xl font-bold text-slate-100 mt-1">
                  {{ activePreset() === '2008_LEHMAN' ? '1.7920' : activePreset() === '2016_BREXIT' ? '1.4850' : activePreset() === '2020_COVID' ? '1.1540' : activePreset() === '2022_MINI_BUDGET' ? '1.0850' : '1.3385' }}
                </div>
              </div>

              <div class="p-3 bg-slate-950 border border-slate-800">
                <div class="text-slate-400 text-[10px]">HEADLINE CPI AS-PUBLISHED</div>
                <div class="text-xl font-bold text-slate-100 mt-1">
                  {{ activePreset() === '2008_LEHMAN' ? '4.70%' : activePreset() === '2016_BREXIT' ? '0.30%' : activePreset() === '2020_COVID' ? '1.70%' : activePreset() === '2022_MINI_BUDGET' ? '9.90%' : '2.30%' }}
                </div>
              </div>
            </div>
          </div>
        </div>
      }

      <!-- Tab 2: GDP Revision Triangles -->
      @if (activeSubTab() === 'REVISION_TRIANGLES') {
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="border-b border-slate-800 pb-3">
            <h3 class="text-sm font-mono font-bold text-slate-100">UK GDP Revision Triangle Matrix (First Estimate to Blue Book Benchmark)</h3>
            <p class="text-xs text-slate-400 font-mono mt-0.5">Tracking quarterly growth rates across release vintages without overwriting history.</p>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-xs font-mono text-left">
              <thead>
                <tr class="text-slate-500 border-b border-slate-800 pb-2 text-[10px]">
                  <th class="py-2">QUARTER</th>
                  <th>FIRST FLASH ESTIMATE</th>
                  <th>QNA SECOND ESTIMATE</th>
                  <th>BLUE BOOK BENCHMARK</th>
                  <th>LATEST VINTAGE (BB26)</th>
                  <th class="text-right">TOTAL REVISION DELTA</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                @for (rec of boeData.gdpVintages; track rec.observationDate) {
                  <tr class="hover:bg-slate-800/40">
                    <td class="py-2.5 font-bold text-slate-200">{{ rec.observationDate }}</td>
                    <td class="text-slate-400">{{ rec.vintages[0]?.value }}%</td>
                    <td class="text-slate-300">{{ rec.vintages[1]?.value }}%</td>
                    <td class="text-slate-200">{{ rec.vintages[2]?.value || '—' }}%</td>
                    <td class="text-amber-300 font-bold">{{ rec.vintages[rec.vintages.length - 1]?.value }}%</td>
                    <td class="text-right font-bold text-emerald-400">
                      +{{ ((rec.vintages[rec.vintages.length - 1]?.value || 0) - (rec.vintages[0]?.value || 0)).toFixed(2) }}%
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      }

      <!-- Tab 3: Reports Generator & Exporters -->
      @if (activeSubTab() === 'REPORTS') {
        <div class="bg-slate-900 border border-slate-800 p-5 space-y-4">
          <div class="border-b border-slate-800 pb-3">
            <h3 class="text-sm font-mono font-bold text-slate-100">Automated Institutional Report Generator & Multi-Format Exporter</h3>
            <p class="text-xs text-slate-400 font-mono mt-0.5">Generate reproducible central-bank briefing packs and export canonical data to Parquet, Arrow, CSV, or PDF.</p>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
            <button type="button" (click)="export.emit('CSV')" class="w-full text-left p-4 bg-slate-950 border border-slate-800 hover:border-amber-500 cursor-pointer space-y-1">
              <mat-icon class="text-amber-400">table_chart</mat-icon>
              <div class="font-bold text-slate-100">Export CSV Dataset</div>
              <div class="text-[11px] text-slate-400 font-sans">Full canonical series catalog and observations with provenance hashes.</div>
            </button>

            <button type="button" (click)="export.emit('JSON')" class="w-full text-left p-4 bg-slate-950 border border-slate-800 hover:border-amber-500 cursor-pointer space-y-1">
              <mat-icon class="text-emerald-400">data_object</mat-icon>
              <div class="font-bold text-slate-100">Export JSON Schema</div>
              <div class="text-[11px] text-slate-400 font-sans">REST API compatible full snapshot with curve points and metadata.</div>
            </button>

            <button type="button" (click)="export.emit('PARQUET')" class="w-full text-left p-4 bg-slate-950 border border-slate-800 hover:border-amber-500 cursor-pointer space-y-1">
              <mat-icon class="text-cyan-400">view_column</mat-icon>
              <div class="font-bold text-slate-100">Export Apache Parquet</div>
              <div class="text-[11px] text-slate-400 font-sans">Columnar schema with Snappy compression headers for Polars / DuckDB.</div>
            </button>

            <button type="button" (click)="export.emit('PDF')" class="w-full text-left p-4 bg-slate-950 border border-slate-800 hover:border-amber-500 cursor-pointer space-y-1">
              <mat-icon class="text-rose-400">picture_as_pdf</mat-icon>
              <div class="font-bold text-slate-100">Print / PDF Dossier</div>
              <div class="text-[11px] text-slate-400 font-sans">Institutional briefing print layout ready for MPC / Board circulation.</div>
            </button>
          </div>
        </div>
      }
    </div>
  `,
})
export class VintagesReportsViewComponent {
  activePreset = input<'2008_LEHMAN' | '2016_BREXIT' | '2020_COVID' | '2022_MINI_BUDGET' | '2026_CURRENT'>('2026_CURRENT');
  presetSelected = output<'2008_LEHMAN' | '2016_BREXIT' | '2020_COVID' | '2022_MINI_BUDGET' | '2026_CURRENT'>();
  export = output<'CSV' | 'JSON' | 'PARQUET' | 'PDF'>();

  activeSubTab = signal<'TIME_MACHINE' | 'REVISION_TRIANGLES' | 'REPORTS'>('TIME_MACHINE');

  public boeData = inject(BoeDataService);
}
