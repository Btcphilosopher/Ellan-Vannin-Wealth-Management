import { ChangeDetectionStrategy, Component, OnInit, inject, signal } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { CliTerminalComponent } from './components/cli-terminal';
import { DocumentationViewerComponent } from './components/documentation-viewer';
import { LineageModalComponent } from './components/lineage-modal';
import { OmniSearchComponent } from './components/omni-search';
import {
  AuditLogEntry,
  DataLineageNode,
  EconometricModelResult,
  EconometricModelSpec,
  ScenarioImpactResult,
  ScenarioSpec,
  SeriesMetadata,
  UserRole,
} from './models/boe.types';
import { BoeDataService } from './services/boe-data';
import { EconometricsEngineService } from './services/econometrics-engine';
import { ScenarioEngineService } from './services/scenario-engine';
import { YieldCurveEngineService } from './services/yield-curve-engine';
import { EconometricsScenariosViewComponent } from './views/econometrics-scenarios-view';
import { EconomyMoneyViewComponent } from './views/economy-money-view';
import { ExplorerAuditViewComponent } from './views/explorer-audit-view';
import { InflationViewComponent } from './views/inflation-view';
import { OverviewViewComponent } from './views/overview-view';
import { RatesFxViewComponent } from './views/rates-fx-view';
import { StabilityPolicyViewComponent } from './views/stability-policy-view';
import { VintagesReportsViewComponent } from './views/vintages-reports-view';
import { YieldCurvesViewComponent } from './views/yield-curves-view';

export type MainNavSection = 
  | 'OVERVIEW'
  | 'YIELD_CURVES'
  | 'RATES_FX'
  | 'INFLATION'
  | 'ECONOMY_MONEY'
  | 'STABILITY_POLICY'
  | 'ECONOMETRICS_SCENARIOS'
  | 'VINTAGES_REPORTS'
  | 'EXPLORER_AUDIT';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    MatIconModule,
    FormsModule,
    ReactiveFormsModule,
    LineageModalComponent,
    OmniSearchComponent,
    CliTerminalComponent,
    DocumentationViewerComponent,
    OverviewViewComponent,
    YieldCurvesViewComponent,
    RatesFxViewComponent,
    InflationViewComponent,
    EconomyMoneyViewComponent,
    StabilityPolicyViewComponent,
    EconometricsScenariosViewComponent,
    VintagesReportsViewComponent,
    ExplorerAuditViewComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit {
  public boeData = inject(BoeDataService);
  public yieldCurveEngine = inject(YieldCurveEngineService);
  public econometricsEngine = inject(EconometricsEngineService);
  public scenarioEngine = inject(ScenarioEngineService);

  activeSection = signal<MainNavSection>('OVERVIEW');
  currentUserRole = signal<UserRole>('ECONOMIST');
  systemDate = signal<string>('30 SEPTEMBER 2026');

  // Modals & Overlays
  showOmniSearch = signal<boolean>(false);
  showCliTerminal = signal<boolean>(false);
  showDocsViewer = signal<boolean>(false);
  showLineageModal = signal<boolean>(false);
  activeLineageSeries = signal<string>('GB.CPI.ALL.YOY.PCT.M');
  activeLineageNodes = signal<DataLineageNode[]>([]);

  // Econometric Lab State
  selectedModelType = signal<'OLS' | 'VAR' | 'ARIMA' | 'KALMAN_FILTER'>('OLS');
  targetSeriesId = signal<string>('GB.CPI.ALL.YOY.PCT.M');
  modelResult = signal<EconometricModelResult | null>(null);
  rScriptOutput = signal<string>('');

  // Scenario Engine State
  selectedScenarioId = signal<string>('SCENARIO-RATE-SHOCK-UP');
  scenarioResult = signal<ScenarioImpactResult | null>(null);

  // Time Machine Preset State
  activeTimeMachinePreset = signal<'2008_LEHMAN' | '2016_BREXIT' | '2020_COVID' | '2022_MINI_BUDGET' | '2026_CURRENT'>('2026_CURRENT');

  // Export Feedback Status
  exportStatus = signal<string>('');

  // Audit State
  auditLogs = signal<AuditLogEntry[]>([]);

  ngOnInit() {
    this.auditLogs.set(this.boeData.getAuditLogs());
    this.runEconometricEstimation();
    this.runScenarioSimulation();
  }

  setSection(section: MainNavSection) {
    this.activeSection.set(section);
    this.boeData.recordAuditLog(
      't.ramsay@boe.gov.uk',
      this.currentUserRole(),
      'QUERY',
      `NAV_SECTION_${section}`,
      { section },
      'USER_NAVIGATION'
    );
    this.auditLogs.set(this.boeData.getAuditLogs());
  }

  setRole(role: UserRole) {
    this.currentUserRole.set(role);
    this.boeData.recordAuditLog(
      't.ramsay@boe.gov.uk',
      role,
      'ROLE_SWITCH',
      'USER_SECURITY_CONTEXT',
      { previousRole: this.currentUserRole(), newRole: role },
      'AUTHORIZATION_CHANGE'
    );
    this.auditLogs.set(this.boeData.getAuditLogs());
  }

  openLineage(seriesId: string) {
    this.activeLineageSeries.set(seriesId);
    this.activeLineageNodes.set(this.boeData.resolveDataLineage(seriesId));
    this.showLineageModal.set(true);

    this.boeData.recordAuditLog(
      't.ramsay@boe.gov.uk',
      this.currentUserRole(),
      'QUERY',
      `LINEAGE_INSPECT_${seriesId}`,
      { seriesId },
      'PROVENANCE_AUDIT_TRACE'
    );
    this.auditLogs.set(this.boeData.getAuditLogs());
  }

  onOmniSeriesSelected(series: SeriesMetadata) {
    this.showOmniSearch.set(false);
    this.openLineage(series.id);
  }

  runEconometricEstimation() {
    const spec: EconometricModelSpec = {
      id: `SPEC-${this.selectedModelType()}-${Date.now()}`,
      name: `${this.selectedModelType()} Domestic Inflation Dynamics Specification`,
      modelType: this.selectedModelType(),
      targetSeries: this.targetSeriesId(),
      explanatorySeries: ['GB.BANKRATE.LEVEL.PCT', 'GB.LABOUR.WAGES.AWE.REGULAR.YOY.PCT.M', 'GB.FX.ERI.BROAD.INDEX'],
      sampleStart: '2000-01-01',
      sampleEnd: '2026-08-31',
      vintageDate: '2026-08-31',
      options: { robustHAC: true, lagLength: 4 },
    };

    const res = this.econometricsEngine.estimateModel(spec);
    this.modelResult.set(res);
    this.rScriptOutput.set(this.econometricsEngine.generateRScript(spec));
  }

  onModelTypeChanged(type: 'OLS' | 'VAR' | 'ARIMA' | 'KALMAN_FILTER') {
    this.selectedModelType.set(type);
    this.runEconometricEstimation();
  }

  runScenarioSimulation() {
    const scenario = this.scenarioEngine.standardScenarios.find((s: ScenarioSpec) => s.id === this.selectedScenarioId()) || this.scenarioEngine.standardScenarios[0];
    const res = this.scenarioEngine.simulateScenario(scenario);
    this.scenarioResult.set(res);
  }

  onScenarioChanged(id: string) {
    this.selectedScenarioId.set(id);
    this.runScenarioSimulation();
  }

  onPresetSelected(preset: '2008_LEHMAN' | '2016_BREXIT' | '2020_COVID' | '2022_MINI_BUDGET' | '2026_CURRENT') {
    this.activeTimeMachinePreset.set(preset);
  }

  exportData(format: 'CSV' | 'JSON' | 'PARQUET' | 'PDF') {
    this.exportStatus.set(`Exporting in ${format} format...`);
    
    setTimeout(() => {
      let content = '';
      let mimeType = 'text/plain';
      let extension = 'txt';

      if (format === 'CSV') {
        mimeType = 'text/csv';
        extension = 'csv';
        content = 'SERIES_ID,NAME,CATEGORY,FREQUENCY,UNIT,LATEST_VALUE,OBSERVATION_DATE,SOURCE\n' +
          this.boeData.seriesCatalog.map((s: SeriesMetadata) => `"${s.id}","${s.name}","${s.category}","${s.frequency}","${s.unit}",${s.latestValue},"${s.lastObservation}","${s.provenance.source}"`).join('\n');
      } else if (format === 'JSON') {
        mimeType = 'application/json';
        extension = 'json';
        content = JSON.stringify({
          institution: 'Bank of England',
          platform: 'BOE.STAT',
          exportDate: new Date().toISOString(),
          catalog: this.boeData.seriesCatalog,
          yieldCurve: this.boeData.yieldCurveData,
          inflation: this.boeData.inflationDecomposition,
        }, null, 2);
      } else if (format === 'PARQUET') {
        mimeType = 'application/json';
        extension = 'parquet.json';
        content = JSON.stringify({
          schema: 'Apache Arrow / Parquet v2.6.0 Encoded Format',
          fields: [
            { name: 'series_id', type: 'UTF8', nullable: false },
            { name: 'observation_date', type: 'DATE32', nullable: false },
            { name: 'value', type: 'FLOAT64', nullable: false },
          ],
          compression: 'SNAPPY',
          recordCount: 11840,
        }, null, 2);
      } else {
        window.print();
        this.exportStatus.set('Print dialog opened.');
        return;
      }

      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `BOE_STAT_${new Date().toISOString().slice(0, 10)}.${extension}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      this.exportStatus.set(`Successfully exported ${this.boeData.seriesCatalog.length} series in ${format} format.`);
    }, 200);
  }
}
