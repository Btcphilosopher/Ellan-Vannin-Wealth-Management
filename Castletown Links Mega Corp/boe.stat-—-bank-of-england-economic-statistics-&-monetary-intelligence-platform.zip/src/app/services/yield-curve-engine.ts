import { Injectable } from '@angular/core';
import { NelsonSiegelParams, YieldCurvePoint } from '../models/boe.types';

@Injectable({
  providedIn: 'root',
})
export class YieldCurveEngineService {
  /**
   * Evaluate Nelson-Siegel-Svensson zero-coupon yield at maturity m (in years)
   * y(m) = beta0 + beta1 * ((1 - exp(-m/tau1))/(m/tau1))
   *              + beta2 * (((1 - exp(-m/tau1))/(m/tau1)) - exp(-m/tau1))
   *              + beta3 * (((1 - exp(-m/tau2))/(m/tau2)) - exp(-m/tau2))
   */
  evaluateNSS(m: number, params: NelsonSiegelParams): number {
    if (m <= 0.0001) return params.beta0 + params.beta1;
    
    const tau1 = params.tau1 || 1.5;
    const x1 = m / tau1;
    const factor1 = (1.0 - Math.exp(-x1)) / x1;
    const factor2 = factor1 - Math.exp(-x1);

    let yieldVal = params.beta0 + params.beta1 * factor1 + params.beta2 * factor2;

    if (params.beta3 && params.tau2) {
      const x2 = m / params.tau2;
      const factor3 = ((1.0 - Math.exp(-x2)) / x2) - Math.exp(-x2);
      yieldVal += params.beta3 * factor3;
    }

    return yieldVal;
  }

  /**
   * Evaluate Instantaneous Forward Rate f(m)
   * f(m) = beta0 + beta1 * exp(-m/tau1) + beta2 * (m/tau1) * exp(-m/tau1) + beta3 * (m/tau2) * exp(-m/tau2)
   */
  evaluateInstantaneousForward(m: number, params: NelsonSiegelParams): number {
    const tau1 = params.tau1 || 1.5;
    const x1 = m / tau1;
    const exp1 = Math.exp(-x1);

    let forward = params.beta0 + params.beta1 * exp1 + params.beta2 * x1 * exp1;

    if (params.beta3 && params.tau2) {
      const x2 = m / params.tau2;
      const exp2 = Math.exp(-x2);
      forward += params.beta3 * x2 * exp2;
    }

    return forward;
  }

  /**
   * Generate continuous curve points for high-precision plotting (e.g. 100 points from 0.1 to 50 years)
   */
  generateContinuousCurve(params: NelsonSiegelParams, maxYears = 50, step = 0.5): { maturity: number; yield: number; forward: number }[] {
    const points: { maturity: number; yield: number; forward: number }[] = [];
    for (let m = 0.1; m <= maxYears; m += step) {
      const y = this.evaluateNSS(m, params);
      const f = this.evaluateInstantaneousForward(m, params);
      points.push({
        maturity: Number(m.toFixed(2)),
        yield: Number(y.toFixed(3)),
        forward: Number(f.toFixed(3)),
      });
    }
    return points;
  }

  /**
   * Calculate yield curve metrics: Level, Slope, Curvature, Butterfly
   */
  calculateCurveMetrics(points: YieldCurvePoint[]): {
    level10Y: number;
    slope2Y10Y: number;
    slope5Y30Y: number;
    curvature5Y: number;
    butterfly: number;
  } {
    const y2 = points.find((p) => p.tenor === '2Y')?.nominalYield || 3.86;
    const y5 = points.find((p) => p.tenor === '5Y')?.nominalYield || 3.74;
    const y10 = points.find((p) => p.tenor === '10Y')?.nominalYield || 3.92;
    const y30 = points.find((p) => p.tenor === '30Y')?.nominalYield || 4.42;

    const level10Y = y10;
    const slope2Y10Y = Number(((y10 - y2) * 100).toFixed(1)); // bp
    const slope5Y30Y = Number(((y30 - y5) * 100).toFixed(1)); // bp
    const curvature5Y = Number(((2 * y5 - (y2 + y10)) * 100).toFixed(1)); // bp
    const butterfly = Number(((y2 - 2 * y5 + y10) * 100).toFixed(1)); // bp

    return {
      level10Y,
      slope2Y10Y,
      slope5Y30Y,
      curvature5Y,
      butterfly,
    };
  }

  /**
   * Generate 3D Yield Curve Surface dataset (Tenor X, Date Y, Yield Z)
   */
  generateYieldSurface(): { date: string; label: string; points: { tenor: string; maturity: number; yield: number }[] }[] {
    const dates = [
      { date: '2024-09-30', label: '1 Year Ago', shift: 0.42, slopeShift: -0.15 },
      { date: '2024-12-31', label: 'Q4 2024', shift: 0.35, slopeShift: -0.10 },
      { date: '2025-03-31', label: 'Q1 2025', shift: 0.28, slopeShift: -0.05 },
      { date: '2025-06-30', label: 'Q2 2025', shift: 0.20, slopeShift: 0.02 },
      { date: '2025-09-30', label: 'Q3 2025', shift: 0.12, slopeShift: 0.08 },
      { date: '2025-12-31', label: 'Q4 2025', shift: 0.05, slopeShift: 0.12 },
      { date: '2026-03-31', label: 'Q1 2026', shift: -0.05, slopeShift: 0.18 },
      { date: '2026-06-30', label: 'Q2 2026', shift: -0.15, slopeShift: 0.22 },
      { date: '2026-09-30', label: '30 Sep 2026 (Current)', shift: 0.00, slopeShift: 0.00 },
    ];

    const tenors = [
      { tenor: '1Y', m: 1, base: 4.12 },
      { tenor: '2Y', m: 2, base: 3.86 },
      { tenor: '5Y', m: 5, base: 3.74 },
      { tenor: '10Y', m: 10, base: 3.92 },
      { tenor: '20Y', m: 20, base: 4.30 },
      { tenor: '30Y', m: 30, base: 4.42 },
      { tenor: '50Y', m: 50, base: 4.22 },
    ];

    return dates.map((d) => ({
      date: d.date,
      label: d.label,
      points: tenors.map((t) => {
        const yieldVal = Number((t.base + d.shift + (t.m > 5 ? d.slopeShift : -d.slopeShift)).toFixed(2));
        return {
          tenor: t.tenor,
          maturity: t.m,
          yield: yieldVal,
        };
      }),
    }));
  }
}
