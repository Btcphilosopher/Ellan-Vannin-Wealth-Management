import { Injectable } from '@angular/core';
import { ScenarioImpactResult, ScenarioSpec } from '../models/boe.types';

@Injectable({
  providedIn: 'root',
})
export class ScenarioEngineService {
  readonly standardScenarios: ScenarioSpec[] = [
    {
      id: 'SCENARIO-RATE-SHOCK-UP',
      name: 'Monetary Policy Tightening Shock (+100bp)',
      description: 'An unexpected 100bp increase in the Official Bank Rate held for 4 quarters before mean-reverting.',
      shocks: [
        { variable: 'GB.BANKRATE.LEVEL.PCT', label: 'Bank Rate', magnitude: 1.00, unit: 'Percentage Points' },
        { variable: 'GB.GILT.NOMINAL.ZERO.10Y.PCT', label: '10Y Gilt Yield', magnitude: 0.45, unit: 'Percentage Points' },
        { variable: 'GBP.USD.SPOT', label: 'Sterling Exchange Rate', magnitude: 2.50, unit: '%' },
      ],
    },
    {
      id: 'SCENARIO-STERLING-DEPRECIATION',
      name: 'Sterling Exchange Rate Shock (-10%)',
      description: 'A sudden 10% depreciation of the Sterling Trade-Weighted ERI driven by terms-of-trade deterioration.',
      shocks: [
        { variable: 'GB.FX.ERI.BROAD.INDEX', label: 'Sterling ERI', magnitude: -10.0, unit: '%' },
        { variable: 'COMMODITIES.OIL.BRENT', label: 'Import Energy Prices in GBP', magnitude: 12.0, unit: '%' },
      ],
    },
    {
      id: 'SCENARIO-ENERGY-SPIKE',
      name: 'Global Commodity & Energy Supply Shock (+30%)',
      description: 'A 30% surge in European natural gas and Brent crude oil prices transmitted through Ofgem price cap and input costs.',
      shocks: [
        { variable: 'ENERGY.GLOBAL.BRENT', label: 'Oil Price (USD/bbl)', magnitude: 30.0, unit: '%' },
        { variable: 'ENERGY.UK.NBP.GAS', label: 'UK NBP Gas', magnitude: 45.0, unit: '%' },
      ],
    },
    {
      id: 'SCENARIO-GILT-TERM-PREMIUM-SPIKE',
      name: 'Sovereign Gilt Spread Widening (+75bp)',
      description: 'A sudden term premium repricing on UK sovereign debt causing 10Y gilt yields to surge 75bp over OIS.',
      shocks: [
        { variable: 'GB.GILT.NOMINAL.ZERO.10Y.PCT', label: '10Y Gilt Yield', magnitude: 0.75, unit: 'Percentage Points' },
        { variable: 'GB.RATE.MORTGAGE.QUOTED.2Y75.PCT', label: '2Y Quoted Mortgage Rate', magnitude: 0.65, unit: 'Percentage Points' },
        { variable: 'GB.SPREAD.CORP.BBB.GBP.BP', label: 'Corporate Bond Spread', magnitude: 35.0, unit: 'Basis Points' },
      ],
    },
  ];

  /**
   * Simulate downstream macro-financial transmission
   */
  simulateScenario(scenario: ScenarioSpec): ScenarioImpactResult {
    const isRateUp = scenario.shocks.some((s) => s.variable === 'GB.BANKRATE.LEVEL.PCT' && s.magnitude > 0);
    const isSterlingDepreciation = scenario.shocks.some((s) => s.variable.includes('FX') && s.magnitude < 0);
    const isEnergySpike = scenario.shocks.some((s) => s.variable.includes('ENERGY'));
    const isGiltSpike = scenario.id.includes('GILT');

    const horizons = [3, 6, 9, 12, 18, 24, 36];
    const projections = horizons.map((m) => {
      let gdpDev = 0;
      let cpiDev = 0;
      let incomeDev = 0;
      let cet1Dev = 0;
      let unempDev = 0;

      if (isRateUp) {
        // Rate hike: GDP contracts, CPI falls with lag, unemployment rises
        const peakFactor = Math.sin((Math.min(m, 24) / 24) * Math.PI);
        gdpDev = -0.45 * peakFactor;
        cpiDev = -38 * Math.sin((Math.min(m, 36) / 36) * Math.PI);
        incomeDev = -0.65 * peakFactor;
        cet1Dev = 15 - 8 * peakFactor; // Early NIM boost, later loan loss
        unempDev = 22 * peakFactor;
      } else if (isSterlingDepreciation) {
        // FX down: CPI surges via import prices, GDP initially soft then exports rebound
        cpiDev = 65 * Math.exp(-m / 14);
        gdpDev = -0.25 * Math.exp(-m / 8) + 0.15 * (m > 12 ? 1 : 0);
        incomeDev = -0.80 * Math.exp(-m / 12);
        cet1Dev = -12;
        unempDev = 10;
      } else if (isEnergySpike) {
        // Stagflationary shock: CPI spikes immediately, severe real income squeeze
        cpiDev = 115 * Math.exp(-m / 10);
        gdpDev = -0.75 * Math.exp(-m / 14);
        incomeDev = -1.45 * Math.exp(-m / 12);
        cet1Dev = -25;
        unempDev = 35 * Math.sin((m / 24) * Math.PI);
      } else if (isGiltSpike) {
        // Financial tightening: Mortgage rates surge, housing market cools
        gdpDev = -0.35 * (m / 18);
        cpiDev = -15 * (m / 24);
        incomeDev = -0.55 * (m / 18);
        cet1Dev = -42 * Math.exp(-m / 12); // Marked-to-market bond portfolio impact
        unempDev = 18 * (m / 24);
      } else {
        gdpDev = -0.20;
        cpiDev = 20;
        incomeDev = -0.30;
        cet1Dev = -10;
        unempDev = 12;
      }

      return {
        horizonMonth: m,
        gdpDeviationPct: Number(gdpDev.toFixed(2)),
        cpiDeviationBp: Number(cpiDev.toFixed(0)),
        householdIncomeDeviationPct: Number(incomeDev.toFixed(2)),
        bankCet1DeviationBp: Number(cet1Dev.toFixed(0)),
        unemploymentDeviationBp: Number(unempDev.toFixed(0)),
      };
    });

    const maxCpi = Math.max(...projections.map((p) => Math.abs(p.cpiDeviationBp)));
    const minGdp = Math.min(...projections.map((p) => p.gdpDeviationPct));
    const minCet1 = Math.min(...projections.map((p) => p.bankCet1DeviationBp));

    return {
      scenario,
      transmissionHorizonMonths: 36,
      projections,
      summary: {
        peakCpiImpactBp: maxCpi,
        peakGdpImpactPct: minGdp,
        bankCapitalErosionBp: Math.abs(Math.min(0, minCet1)),
        riskCategory: Math.abs(minGdp) > 0.6 || maxCpi > 80 ? 'SEVERE' : 'MODERATE',
      },
    };
  }
}
