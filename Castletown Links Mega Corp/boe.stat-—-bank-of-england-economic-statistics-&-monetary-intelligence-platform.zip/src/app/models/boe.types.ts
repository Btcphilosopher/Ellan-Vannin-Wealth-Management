export type DataClassification = 'PUBLIC' | 'SYNTHETIC' | 'INTERNAL' | 'RESTRICTED' | 'CONFIDENTIAL';

export type SeriesFrequency = 'DAILY' | 'WEEKLY' | 'MONTHLY' | 'QUARTERLY' | 'ANNUAL';

export type SeasonalAdjustment = 'SA' | 'NSA' | 'NA';

export type SeriesCategory = 
  | 'YIELD_CURVES'
  | 'RATES'
  | 'FX'
  | 'INFLATION'
  | 'ECONOMY'
  | 'LABOUR'
  | 'MONEY_CREDIT'
  | 'BANKING'
  | 'FINANCIAL_STABILITY'
  | 'ASSET_MARKETS'
  | 'SURVEYS';

export type UserRole = 
  | 'BOARD'
  | 'EXECUTIVE'
  | 'ECONOMIST'
  | 'STATISTICIAN'
  | 'MARKET_ANALYST'
  | 'RESEARCHER'
  | 'DATA_ENGINEER'
  | 'SUPERVISOR'
  | 'ADMINISTRATOR'
  | 'AUDITOR'
  | 'READ_ONLY';

export interface DataProvenance {
  source: string;
  provider: string;
  methodology: string;
  rawSourceId?: string;
  sourceDocUrl?: string;
  aggregationMethod?: string;
  lastAudited: string;
  confidenceScore: number; // 0.0 - 1.0
  classification: DataClassification;
}

export interface SeriesObservation {
  date: string; // ISO date 'YYYY-MM-DD'
  value: number;
  vintageDate?: string;
  releaseDate?: string;
  status: 'FINAL' | 'PROVISIONAL' | 'REVISED' | 'ESTIMATED';
  revisionNumber: number;
  metadata?: Record<string, string | number>;
}

export interface SeriesMetadata {
  id: string; // Machine identifier, e.g., 'GB.CPI.ALL.YOY.PCT.M'
  name: string;
  shortName: string;
  description: string;
  category: SeriesCategory;
  frequency: SeriesFrequency;
  unit: string;
  unitMultiplier?: string; // e.g. '%', 'GBP Billions', 'Index (2015=100)'
  currency?: string;
  geography: string; // 'GB', 'UK', 'GLOBAL'
  sector?: string;
  seasonalAdjustment: SeasonalAdjustment;
  classification: DataClassification;
  provenance: DataProvenance;
  aliases: string[];
  firstObservation: string;
  lastObservation: string;
  observationCount: number;
  latestValue: number;
  previousValue: number;
  change1D?: number;
  change1M?: number;
  change1Y?: number;
  changeYoy?: number;
  qualityScore: number; // 0 - 100
  qualityFlags: string[];
  tags: string[];
}

export interface YieldCurvePoint {
  tenor: string;
  maturityYears: number;
  nominalYield: number; // %
  realYield: number; // %
  breakevenInflation: number; // %
  oisYield: number; // %
  instantaneousForward: number; // %
  oneYearForward: number; // %
  termPremium: number; // % (ACM model estimate)
  change1D: number; // bp
  change1W: number; // bp
  change1M: number; // bp
  changeYtd: number; // bp
  percentile5Y: number; // 0 - 100
  zScore: number;
}

export interface NelsonSiegelParams {
  beta0: number; // Level
  beta1: number; // Slope
  beta2: number; // Curvature 1
  beta3?: number; // Curvature 2 (Svensson)
  tau1: number; // Scale 1
  tau2?: number; // Scale 2 (Svensson)
  sse: number; // Sum of squared errors
  fitR2: number;
  date: string;
}

export interface PCAFactorResult {
  factor1LevelPct: number;
  factor2SlopePct: number;
  factor3CurvaturePct: number;
  cumulativeVariancePct: number;
  loadings: { tenor: string; level: number; slope: number; curvature: number }[];
}

export interface InflationComponentContribution {
  name: string;
  code: string;
  weight: number; // Basket weight in parts per 1000
  latestYoyRate: number; // %
  contributionBp: number; // Basis points to headline
  previousContributionBp: number;
  color: string;
}

export interface InflationDecomposition {
  date: string;
  headlineCpi: number;
  coreCpi: number;
  cpih: number;
  rpi: number;
  services: number;
  goods: number;
  energy: number;
  food: number;
  trimmedMean15: number;
  weightedMedian: number;
  persistenceScore: number; // 0 - 100
  momentum3mAnnualised: number;
  momentum6mAnnualised: number;
  diffusionPct: number; // % of basket rising > 2% YoY
  components: InflationComponentContribution[];
}

export interface InflationExpectationsSet {
  date: string;
  spotCpi: number;
  marketBreakeven5Y: number;
  marketBreakeven10Y: number;
  market5Y5YForward: number;
  youGovHousehold1Y: number;
  youGovHousehold5Y: number;
  dmpBusiness1Y: number;
  dmpBusiness3Y: number;
  surveyForecasters1Y: number;
  surveyForecasters3Y: number;
  boeStaffForecast1Y: number;
  boeStaffForecast2Y: number;
  boeStaffForecast3Y: number;
}

export interface FxCross {
  pair: string;
  base: string;
  quote: string;
  spot: number;
  change1D: number;
  change1W: number;
  change1M: number;
  change3M: number;
  change6M: number;
  change1Y: number;
  change5Y: number;
  volatility30D: number;
  volatility90D: number;
  carryYieldPct: number;
  reerIndex: number;
  pppValuationPct: number; // +/- % relative to PPP fair value
}

export interface PolicyPathPoint {
  mpcDate: string;
  meetingLabel: string;
  impliedRate: number;
  currentBankRate: number;
  cumulativeChangeBp: number;
  probability25bpCut: number;
  probability25bpHike: number;
  probabilityHold: number;
}

export interface FciComponent {
  name: string;
  code: string;
  rawLevel: number;
  zScore: number;
  weight: number;
  weightedContribution: number;
  direction: 'EASING' | 'TIGHTENING';
}

export interface EconomicReleaseEvent {
  id: string;
  date: string;
  time: string;
  seriesId: string;
  seriesName: string;
  frequency: string;
  periodCovered: string;
  previousValue: number;
  consensusExpected: number;
  actualValue: number;
  revisedPrevious?: number;
  unit: string;
  impactLevel: 'HIGH' | 'MEDIUM' | 'LOW';
  sourceOrg: string;
  docUrl: string;
  status: 'RELEASED' | 'PENDING';
}

export interface VintageRevisionRecord {
  observationDate: string;
  vintages: {
    vintageDate: string;
    releaseLabel: string;
    value: number;
    revisionDelta?: number;
  }[];
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actor: string;
  actorRole: UserRole;
  actionType: 'QUERY' | 'EXPORT' | 'MODEL_EXEC' | 'CONFIG_CHANGE' | 'ROLE_SWITCH' | 'SECURITY_VERIFY' | 'VINTAGE_ACCESS';
  resource: string;
  parameters: Record<string, unknown>;
  reasonCode: string;
  previousHash: string;
  hash: string;
  ipAddress: string;
  classification: DataClassification;
}

export interface DataLineageNode {
  type: 'VALUE' | 'SERIES' | 'SOURCE' | 'RAW_OBSERVATION' | 'TRANSFORMATION' | 'MODEL' | 'OUTPUT';
  title: string;
  description: string;
  metadata: Record<string, string | number>;
  verified: boolean;
}

export interface EconometricModelSpec {
  id: string;
  name: string;
  modelType: 'OLS' | 'VAR' | 'ARIMA' | 'KALMAN_FILTER' | 'NELSON_SIEGEL';
  targetSeries: string;
  explanatorySeries: string[];
  sampleStart: string;
  sampleEnd: string;
  vintageDate: string;
  options: Record<string, unknown>;
}

export interface EconometricModelResult {
  spec: EconometricModelSpec;
  executionTimestamp: string;
  rSquared?: number;
  adjustedRSquared?: number;
  fStatistic?: number;
  durbinWatson?: number;
  aic?: number;
  bic?: number;
  coefficients: {
    variable: string;
    coefficient: number;
    stdError: number;
    tStatistic: number;
    pValue: number;
    ciLower: number;
    ciUpper: number;
  }[];
  residuals: { date: string; actual: number; fitted: number; residual: number }[];
  forecasts?: { date: string; point: number; ci50Lower: number; ci50Upper: number; ci90Lower: number; ci90Upper: number }[];
  impulseResponses?: { step: number; response: number; lowerBand: number; upperBand: number }[];
  diagnostics: {
    ljungBoxQ: number;
    ljungBoxP: number;
    jarqueBeraStat: number;
    jarqueBeraP: number;
    heteroskedasticityWhiteP: number;
  };
}

export interface ScenarioSpec {
  id: string;
  name: string;
  description: string;
  shocks: {
    variable: string;
    label: string;
    magnitude: number;
    unit: string;
  }[];
}

export interface ScenarioImpactResult {
  scenario: ScenarioSpec;
  transmissionHorizonMonths: number;
  projections: {
    horizonMonth: number;
    gdpDeviationPct: number;
    cpiDeviationBp: number;
    householdIncomeDeviationPct: number;
    bankCet1DeviationBp: number;
    unemploymentDeviationBp: number;
  }[];
  summary: {
    peakCpiImpactBp: number;
    peakGdpImpactPct: number;
    bankCapitalErosionBp: number;
    riskCategory: 'LOW' | 'MODERATE' | 'SEVERE';
  };
}

export interface SystemicRiskNode {
  id: string;
  label: string;
  sector: string;
  vulnerabilityScore: number; // 0 - 100
  trend: 'IMPROVING' | 'STABLE' | 'DETERIORATING';
  headlineMetric: string;
  headlineValue: string;
  linkedSeriesIds: string[];
  keyRisks: string[];
}
