import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import { join } from 'node:path';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
const angularApp = new AngularNodeAppEngine();

app.use(express.json());

// ==============================================================================
// BOE.STAT REST API (v1) — Central Bank Monetary & Economic Data Fabric
// ==============================================================================

const BOE_METADATA = {
  institution: 'Bank of England',
  platform: 'BOE.STAT High-Precision Economic Engine',
  version: '4.2.0-PROD',
  dataFabric: 'Apache Arrow / Canonical Columnar Store',
  timestamp: new Date().toISOString(),
  classification: 'OFFICIAL SENSITIVE // BOE.STAT REST API',
};

// GET /api/v1/health
app.get('/api/v1/health', (req, res) => {
  res.json({
    status: 'HEALTHY',
    systemTime: new Date().toISOString(),
    engine: 'Rust Tokio + Axum / Node SSR Engine',
    pipelines: {
      marketDataFeed: 'ONLINE',
      onsIngestPipe: 'ONLINE',
      praRegulatoryReturns: 'ONLINE',
      nssYieldCurveFitter: 'ONLINE',
      auditLedger: 'VERIFIED',
    },
    ...BOE_METADATA,
  });
});

// GET /api/v1/series
app.get('/api/v1/series', (req, res) => {
  const query = (req.query['q'] as string || '').toLowerCase();
  const category = req.query['category'] as string;

  const catalog = [
    { id: 'GB.BANKRATE.LEVEL.PCT', name: 'Official Bank Rate', category: 'RATES', unit: '%', latestValue: 4.50, status: 'FINAL' },
    { id: 'GB.SONIA.RATE.PCT', name: 'Sterling Overnight Index Average (SONIA)', category: 'RATES', unit: '%', latestValue: 4.45, status: 'FINAL' },
    { id: 'GB.GILT.NOMINAL.ZERO.10Y.PCT', name: 'UK Nominal Gilt Zero-Coupon Yield 10Y', category: 'YIELD_CURVES', unit: '%', latestValue: 3.92, status: 'FINAL' },
    { id: 'GB.GILT.REAL.ZERO.10Y.PCT', name: 'UK Real Gilt Zero-Coupon Yield 10Y', category: 'YIELD_CURVES', unit: '%', latestValue: 0.88, status: 'FINAL' },
    { id: 'GB.GILT.INFLATION.ZERO.10Y.PCT', name: '10Y UK Breakeven Inflation Rate', category: 'INFLATION', unit: '%', latestValue: 3.04, status: 'FINAL' },
    { id: 'GB.CPI.ALL.YOY.PCT.M', name: 'Consumer Prices Index (CPI) Headline Inflation Rate', category: 'INFLATION', unit: '% YoY', latestValue: 2.30, status: 'FINAL' },
    { id: 'GB.CPI.CORE.YOY.PCT.M', name: 'CPI Core Inflation Rate', category: 'INFLATION', unit: '% YoY', latestValue: 3.10, status: 'FINAL' },
    { id: 'GB.CPI.SERVICES.YOY.PCT.M', name: 'CPI Services Inflation Rate', category: 'INFLATION', unit: '% YoY', latestValue: 4.60, status: 'FINAL' },
    { id: 'GBP.USD.SPOT', name: 'Sterling / US Dollar Spot Exchange Rate', category: 'FX', unit: 'USD per GBP', latestValue: 1.3385, status: 'FINAL' },
    { id: 'GBP.EUR.SPOT', name: 'Sterling / Euro Spot Exchange Rate', category: 'FX', unit: 'EUR per GBP', latestValue: 1.1960, status: 'FINAL' },
    { id: 'GB.FX.ERI.BROAD.INDEX', name: 'Sterling Effective Exchange Rate Index (ERI Broad)', category: 'FX', unit: 'Index', latestValue: 88.42, status: 'FINAL' },
    { id: 'GB.GDP.REAL.YOY.PCT.Q', name: 'Gross Domestic Product (Real GDP Growth YoY)', category: 'ECONOMY', unit: '% YoY', latestValue: 1.20, status: 'FINAL' },
    { id: 'GB.LABOUR.UNEMPLOYMENT.ILO.PCT.M', name: 'Unemployment Rate (ILO Definition 16+)', category: 'LABOUR', unit: '%', latestValue: 4.10, status: 'FINAL' },
    { id: 'GB.LABOUR.WAGES.AWE.REGULAR.YOY.PCT.M', name: 'Average Weekly Earnings (Regular Pay YoY)', category: 'LABOUR', unit: '% YoY', latestValue: 4.70, status: 'FINAL' },
    { id: 'GB.MONEY.M4EX.GROWTH.YOY.PCT.M', name: 'Broad Money M4ex Annual Growth Rate', category: 'MONEY_CREDIT', unit: '% YoY', latestValue: 3.40, status: 'FINAL' },
    { id: 'GB.CREDIT.MORTGAGE.NET.FLOW.GBP.M', name: 'Net Lending Secured on Dwellings (Mortgage Flows)', category: 'MONEY_CREDIT', unit: 'GBP Millions', latestValue: 2840, status: 'FINAL' },
    { id: 'GB.RATE.MORTGAGE.QUOTED.2Y75.PCT', name: 'Quoted Household Mortgage Rate (2-Year Fixed 75% LTV)', category: 'RATES', unit: '%', latestValue: 4.48, status: 'FINAL' },
    { id: 'GB.SPREAD.CORP.BBB.GBP.BP', name: 'Sterling BBB Corporate Bond Spread', category: 'ASSET_MARKETS', unit: 'bp', latestValue: 122, status: 'FINAL' },
    { id: 'GB.FCI.COMPOSITE.INDEX', name: 'Bank of England Financial Conditions Index (FCI)', category: 'FINANCIAL_STABILITY', unit: 'Z-Score', latestValue: 0.12, status: 'FINAL' },
    { id: 'GB.BANKING.SYSTEM.CET1.RATIO.PCT.Q', name: 'Major UK Banks Common Equity Tier 1 (CET1) Capital Ratio', category: 'BANKING', unit: '%', latestValue: 16.20, status: 'FINAL' },
    { id: 'GB.BOE.BALANCE.APF.TOTAL.GBP.BN', name: 'Bank of England APF Gilt Stock Holdings (QT)', category: 'MONEY_CREDIT', unit: 'GBP Bn', latestValue: 558.0, status: 'FINAL' }
  ];

  let filtered = catalog;
  if (category) {
    filtered = filtered.filter((s) => s.category.toUpperCase() === category.toUpperCase());
  }
  if (query) {
    filtered = filtered.filter((s) => s.id.toLowerCase().includes(query) || s.name.toLowerCase().includes(query));
  }

  res.json({
    total: filtered.length,
    series: filtered,
    meta: BOE_METADATA,
  });
});

// GET /api/v1/yields
app.get('/api/v1/yields', (req, res) => {
  res.json({
    date: '2026-09-30',
    model: 'Nelson-Siegel-Svensson Spline Fit',
    parameters: {
      beta0: 4.52,
      beta1: -0.04,
      beta2: -1.82,
      beta3: 0.94,
      tau1: 2.14,
      tau2: 8.65,
      rSquared: 0.9992,
    },
    curvePoints: [
      { tenor: '1M', nominal: 4.48, real: 1.52, breakeven: 2.96, ois: 4.46, forward: 4.45 },
      { tenor: '3M', nominal: 4.41, real: 1.48, breakeven: 2.93, ois: 4.39, forward: 4.35 },
      { tenor: '6M', nominal: 4.30, real: 1.40, breakeven: 2.90, ois: 4.28, forward: 4.18 },
      { tenor: '1Y', nominal: 4.12, real: 1.25, breakeven: 2.87, ois: 4.09, forward: 3.98 },
      { tenor: '2Y', nominal: 3.86, real: 1.05, breakeven: 2.81, ois: 3.82, forward: 3.80 },
      { tenor: '3Y', nominal: 3.78, real: 0.94, breakeven: 2.84, ois: 3.74, forward: 3.75 },
      { tenor: '5Y', nominal: 3.74, real: 0.85, breakeven: 2.89, ois: 3.69, forward: 3.85 },
      { tenor: '7Y', nominal: 3.81, real: 0.84, breakeven: 2.97, ois: 3.75, forward: 4.02 },
      { tenor: '10Y', nominal: 3.92, real: 0.88, breakeven: 3.04, ois: 3.84, forward: 4.24 },
      { tenor: '15Y', nominal: 4.14, real: 0.98, breakeven: 3.16, ois: 4.02, forward: 4.45 },
      { tenor: '20Y', nominal: 4.30, real: 1.06, breakeven: 3.24, ois: 4.15, forward: 4.58 },
      { tenor: '30Y', nominal: 4.42, real: 1.12, breakeven: 3.30, ois: 4.22, forward: 4.64 },
      { tenor: '50Y', nominal: 4.22, real: 0.98, breakeven: 3.24, ois: 4.04, forward: 4.28 },
    ],
    meta: BOE_METADATA,
  });
});

// GET /api/v1/inflation
app.get('/api/v1/inflation', (req, res) => {
  res.json({
    latestMonth: '2026-08-31',
    headlineCpi: 2.30,
    coreCpi: 3.10,
    servicesCpi: 4.60,
    goodsCpi: -0.90,
    energyCpi: -4.80,
    foodCpi: 1.80,
    target: 2.00,
    expectations: {
      market5y5yForward: 3.19,
      marketBreakeven10Y: 3.04,
      youGovHousehold1Y: 3.10,
      dmpBusiness1Y: 2.70,
      surveyForecasters1Y: 2.20,
      boeStaffForecast1Y: 2.10,
    },
    meta: BOE_METADATA,
  });
});

// POST /api/v1/models/run
app.post('/api/v1/models/run', (req, res) => {
  const { modelType, targetSeries } = req.body || {};
  res.json({
    status: 'SUCCESS',
    executionId: `EXEC-${Date.now()}`,
    modelType: modelType || 'OLS',
    targetSeries: targetSeries || 'GB.CPI.ALL.YOY.PCT.M',
    rSquared: 0.842,
    adjustedRSquared: 0.835,
    fStatistic: 124.6,
    durbinWatson: 1.94,
    coefficients: [
      { variable: 'Intercept', coefficient: 0.842, pValue: 0.0001 },
      { variable: 'BankRate(t-1)', coefficient: -0.284, pValue: 0.0001 },
      { variable: 'Wages(t-1)', coefficient: 0.385, pValue: 0.0000 },
    ],
    meta: BOE_METADATA,
  });
});

// POST /api/v1/scenarios/run
app.post('/api/v1/scenarios/run', (req, res) => {
  const { scenarioId } = req.body || {};
  res.json({
    status: 'SUCCESS',
    scenarioId: scenarioId || 'CUSTOM',
    transmissionHorizon: '36 Months',
    peakCpiImpactBp: 38,
    peakGdpImpactPct: -0.45,
    bankCapitalErosionBp: 8,
    meta: BOE_METADATA,
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }
    console.log(`BOE.STAT Node Express server listening on http://localhost:${port}`);
  });
}

export const reqHandler = createNodeRequestHandler(app);

