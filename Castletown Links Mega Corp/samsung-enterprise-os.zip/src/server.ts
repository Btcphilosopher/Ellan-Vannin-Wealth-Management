import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {GoogleGenAI} from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// Lazy Gemini client helper
let genAiClient: GoogleGenAI | null = null;
function getGenAI(): GoogleGenAI | null {
  const apiKey = process.env['GEMINI_API_KEY'];
  if (!apiKey) return null;
  if (!genAiClient) {
    genAiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return genAiClient;
}

// Enterprise Copilot API Endpoint
app.post('/api/copilot', async (req, res) => {
  try {
    const { query, locale } = req.body;
    const isKorean = locale === 'ko-KR';

    // System prompt with canonical synthetic enterprise context
    const ai = getGenAI();
    if (ai) {
      const response = await ai.models.generateContent({
        model: 'gemini-3.8-flash',
        contents: `You are the Samsung Enterprise Copilot (삼성 엔터프라이즈 코파일럿), the AI intelligence engine for Samsung Enterprise OS.
The enterprise operates across DS Semiconductor (Pyeongtaek P3/P4, Hwaseong EUV, Taylor Fab 1), DX Device (Galaxy S26 Ultra, Tab Active5), SDC Display (OLED, MicroLED), and Harman.
Financial summary: Revenue KRW 308.5 Trillion, Operating Profit KRW 45.2T (Margin 14.65%), CapEx KRW 54.0T, R&D KRW 31.2T.
Fab status: 3nm GAA yield at 94.8%, EUV scanner availability 98.5%, active wafer lot L8842-P3-GAA at Step 42/68.
Answer the user's query clearly in ${isKorean ? 'Korean (한국어)' : 'English'}, and provide structured metadata.
Format your output strictly as a JSON object matching this schema:
{
  "answerKo": "Detailed Korean response",
  "answerEn": "Detailed English response",
  "source": "MES Fab P3 Lot Telemetry / SAP S/4 Ledger / Global SCM Control Tower",
  "calculationMethod": "Mathematical calculation or telemetry aggregation used",
  "confidenceScore": 0.98,
  "dataFreshnessSeconds": 12,
  "requiresHumanApproval": true or false,
  "proposedAction": {
    "actionType": "CHANGE_RECIPE" | "APPROVE_PAYMENT" | "TRIGGER_MAINTENANCE" | "HALT_LINE" | "DISPATCH_CARGO",
    "targetEntity": "Target name",
    "impactDescriptionKo": "Korean impact description",
    "impactDescriptionEn": "English impact description"
  }
}
User query: "${query}"`,
        config: {
          responseMimeType: 'application/json',
          temperature: 0.2
        }
      });

      const parsed = JSON.parse(response.text || '{}');
      return res.json({
        ...parsed,
        query,
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' KST'
      });
    }

    // Fallback Enterprise Expert Knowledge Engine if API key is not yet set
    let answerKo = '';
    let answerEn = '';
    let source = 'MES Fab P3 Lot Telemetry & SAP S/4HANA Consolidated Ledger';
    let calculationMethod = 'SUM(Wafers_Processed * Good_Die_Count) / Total_Planned_Dies';
    const confidenceScore = 0.98;
    const dataFreshnessSeconds = 8;
    let requiresHumanApproval = false;
    let proposedAction = undefined;

    const q = (query || '').toLowerCase();

    if (q.includes('생산량') || q.includes('production') || q.includes('output')) {
      answerKo = '오늘 전사 반도체 팹 일일 총 생산량은 300mm 웨이퍼 기준 14,820매(목표 달성률 101.4%)입니다. 평택 P3 팹 3nm GAA 라인은 2,480매 처리 완료되었으며, 양품 다이 환산 시 약 1,280만 개의 칩이 정상 생산되었습니다.';
      answerEn = 'Today’s total semiconductor output is 14,820 wafers (300mm equivalent, 101.4% target achievement). Pyeongtaek P3 3nm GAA line processed 2,480 wafers, yielding approximately 12.8M verified good dies.';
      source = 'Pyeongtaek P3/Hwaseong Line 17 Fab MES Dispatch System';
      calculationMethod = 'Aggregated Daily Wafers = ∑(Bay_Tools_Passed_WaferCount)';
    } else if (q.includes('차질') || q.includes('disruption') || q.includes('stoppage')) {
      answerKo = '오늘 가장 큰 생산 병목은 아산 디스플레이 QD-OLED 증착 2호 라인의 진공 챔버 정기 세정 지연(2.5시간 다운타임, -420패널 영향)이었으나, 구미 스마트팩토리 모바일 조립 라인은 94.6%의 높은 OEE로 정상 가동 중입니다.';
      answerEn = 'The primary operational bottleneck was a scheduled vacuum chamber purge delay on Asan QD-OLED Deposition Line 2 (2.5h downtime, -420 panels impact). Gumi Mobile Smart Factory is running at an optimal 94.6% OEE.';
      source = 'Global Smart Factory Digital Twin Telemetry & SCADA Alert Logs';
      calculationMethod = 'Downtime Impact = Standard_Throughput_Rate * Maintenance_Delay_Hours';
      requiresHumanApproval = true;
      proposedAction = {
        actionType: 'TRIGGER_MAINTENANCE' as const,
        targetEntity: 'Asan QD-OLED Line 2 Chamber B',
        impactDescriptionKo: '진공 챔버 퍼지 가속 프로토콜 가동 및 버퍼 패널 투입 권고',
        impactDescriptionEn: 'Deploy accelerated purge protocol and release buffer substrate lots'
      };
    } else if (q.includes('수율') || q.includes('yield')) {
      answerKo = '최근 24시간 수율 변동 분석 결과: 2nm GAA Nanosheet 원자층 식각 공정(#Step 28)에서 일시적 파티클 미세 편차로 수율이 91.2%로 -0.6%p 변동되었으나 규격 허용치(LSL 90.0%) 이내입니다. 3nm 양산 수율은 94.8%로 견조합니다.';
      answerEn = 'Yield analysis for the last 24h: 2nm GAA Nanosheet ALE (#Step 28) showed a minor variance down to 91.2% (-0.6%p) due to particle micro-distribution, remaining within spec (LSL 90.0%). 3nm GAA production yield is robust at 94.8%.';
      source = 'Metrology Automated Defect Inspection & Yield SPC Curve Engine';
      calculationMethod = 'Wafer Yield % = (Passing_Die_Count / Total_Patterned_Dies) * 100';
    } else if (q.includes('재고') || q.includes('inventory') || q.includes('부품')) {
      answerKo = '재고 일수 위험 1위 부품은 항공우주 5등급 티타늄 아머 프레임(베트남 공급선, 현재 재고 8.4일분으로 안전재고 14일 대비 부족)입니다. 선제적 항공 특송(Air Freight) 전환을 권고합니다.';
      answerEn = 'Highest inventory risk item: Grade 5 Aerospace Titanium Armor Frame (Vietnam source, currently 8.4 days of stock vs 14-day safety threshold). Recommended switching next batch to expedited air freight.';
      source = 'Global SCM ERP Material Inventory Buffer Service';
      calculationMethod = 'Stock_Days_Left = Current_Inventory_Qty / Daily_Line_Consumption_Rate';
      requiresHumanApproval = true;
      proposedAction = {
        actionType: 'DISPATCH_CARGO' as const,
        targetEntity: 'PO-TITAN-VN-9042',
        impactDescriptionKo: '하노이-인천 KAL 전용 화물기 4톤 추가 부킹 배정',
        impactDescriptionEn: 'Assign 4-ton priority booking on KAL Air Cargo flight'
      };
    } else if (q.includes('capex') || q.includes('투자') || q.includes('자본')) {
      answerKo = '2026년 연간 CapEx 집행 계획은 총 54.0조 원이며, 현재까지 38.2조 원(70.7%)이 집행되었습니다. 이 중 DS 반도체 부문이 33.7조 원(평택 P4 증설 및 테일러 팹)으로 전체 투자의 62.5%를 차지합니다.';
      answerEn = 'FY2026 planned CapEx is KRW 54.0 Trillion, with KRW 38.2T (70.7%) executed to date. DS Semiconductor accounts for KRW 33.7T (62.5% of total CapEx), directed to Pyeongtaek P4 expansion and Taylor Fab 1.';
      source = 'Corporate Finance SAP S/4 Fixed Asset & Capital Allocation Module';
      calculationMethod = 'CapEx_Execution_Rate = (Committed_CapEx / Budgeted_CapEx) * 100';
    } else {
      answerKo = `요청하신 안건("${query}")에 대한 전사 통합 데이터 분석 결과, 전 사업부문(DS 반도체, DX 디바이스, SDC 디스플레이) 모두 글로벌 경영 KPI 및 감사 기준에 부합하며 정상 운영되고 있습니다.`;
      answerEn = `Consolidated enterprise analysis for query "${query}": All business units (DS Semiconductor, DX Device, SDC Display) are operating within target KPIs and strict audit compliance.`;
      source = 'Samsung Enterprise OS Unified Master Data Engine';
      calculationMethod = 'Cross-Domain Canonical Knowledge Graph Evaluation';
    }

    return res.json({
      query,
      answerKo,
      answerEn,
      source,
      calculationMethod,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' KST',
      confidenceScore,
      dataFreshnessSeconds,
      requiresHumanApproval,
      proposedAction
    });
  } catch (err: unknown) {
    console.error('Copilot API Error:', err);
    const message = err instanceof Error ? err.message : 'Internal error';
    return res.status(500).json({ error: message });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);

