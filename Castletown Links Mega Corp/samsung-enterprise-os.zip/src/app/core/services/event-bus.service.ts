import { Injectable, signal } from '@angular/core';
import { EnterpriseEvent } from '../models/enterprise.types';

@Injectable({
  providedIn: 'root'
})
export class EventBusService {
  private initialEvents: EnterpriseEvent[] = [
    {
      id: 'EVT-9042',
      eventType: 'LotStarted',
      domain: 'SEMICONDUCTOR',
      actorId: 'ENG-4029',
      actorName: '이진우 수석 (Jinwoo Lee)',
      timestamp: '2026-09-12 10:45:12 KST',
      details: 'Started Lot #LOT-3NM-8842 (25 Wafers, 3nm GAA Exynos Next) at Pyeongtaek P3 Fab Bay-02.',
      detailsKo: '평택 P3 팹 Bay-02에서 3nm GAA 엑시노스 차세대 25매 웨이퍼 로트(#LOT-3NM-8842) 공정 투입 완료.',
      severity: 'INFO',
      immutableHash: 'sha256:7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa3d677284addd200126d9069'
    },
    {
      id: 'EVT-9043',
      eventType: 'YieldAlert',
      domain: 'SEMICONDUCTOR',
      actorId: 'AUTO-METROLOGY-04',
      actorName: 'Metrology AI Automated SPC',
      timestamp: '2026-09-12 10:42:00 KST',
      details: 'Yield inspection at Gate-All-Around dry etch step completed: 94.8% (Target 94.0%, +0.8% sigma).',
      detailsKo: 'Gate-All-Around 건식 식각 공정 수율 검사 완료: 94.8% (목표 94.0% 대비 +0.8% 초과 달성).',
      severity: 'INFO',
      immutableHash: 'sha256:9b2c55e9668d227f272ef5862089851608677c7f3e8f5c9e422ffb6697b0b6d2'
    },
    {
      id: 'EVT-9044',
      eventType: 'EquipmentStateChanged',
      domain: 'MANUFACTURING',
      actorId: 'MES-AGENT-01',
      actorName: 'Gumi Smart Factory MES',
      timestamp: '2026-09-12 10:30:15 KST',
      details: 'Galaxy S26 Ultra Final Assembly Line #04 shifted to RUNNING state after automated optical calibration.',
      detailsKo: '구미 스마트팩토리 갤럭시 S26 Ultra 최종 조립 4호 라인 자동 광학 캘리브레이션 후 정상 가동(RUNNING) 전환.',
      severity: 'INFO',
      immutableHash: 'sha256:3a1b4c9e8f7d6a5c4b3e2d1f0a9b8c7d6e5f4a3b2c1d0e9f8a7b6c5d4e3f2a1b'
    },
    {
      id: 'EVT-9045',
      eventType: 'PurchaseOrderApproved',
      domain: 'FINANCE',
      actorId: 'DIR-8812',
      actorName: '김명진 부사장 (CFO/Finance Head)',
      timestamp: '2026-09-12 10:15:20 KST',
      details: 'Approved PO #PO-SCM-2026-901 for High-Purity EUV Pellicles ($14,500,000 USD).',
      detailsKo: '초고순도 EUV 펠리클 대량 조달 발주서(#PO-SCM-2026-901) 전결 승인 완료 (총액 1,450만 달러).',
      severity: 'INFO',
      immutableHash: 'sha256:d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5'
    },
    {
      id: 'EVT-9046',
      eventType: 'SecurityAlertTriggered',
      domain: 'SECURITY',
      actorId: 'ZERO-TRUST-SOC',
      actorName: 'Global SOC Sentinel Engine',
      timestamp: '2026-09-12 09:55:40 KST',
      details: 'Unusual telemetry anomaly blocked from non-enrolled Knox terminal outside perimeter. Device isolated.',
      detailsKo: '비인가 단말의 서초 R&D 캠퍼스 도면 저장소 접근 시도 차단 및 Knox 보안 격리 조치 완료.',
      severity: 'CRITICAL',
      immutableHash: 'sha256:e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c3d4e5f6a7b8c9d0e1f2'
    }
  ];

  readonly events = signal<EnterpriseEvent[]>(this.initialEvents);

  publish(event: Omit<EnterpriseEvent, 'id' | 'timestamp' | 'immutableHash'>) {
    const id = `EVT-${Math.floor(1000 + Math.random() * 9000)}`;
    const now = new Date().toISOString().replace('T', ' ').substring(0, 19) + ' KST';
    const hash = 'sha256:' + Array.from({length: 64}, () => Math.floor(Math.random()*16).toString(16)).join('');
    
    const newEvent: EnterpriseEvent = {
      ...event,
      id,
      timestamp: now,
      immutableHash: hash
    };

    this.events.update(prev => [newEvent, ...prev]);
    return newEvent;
  }
}
