import { Injectable, signal, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { CopilotQueryResponse } from '../models/enterprise.types';
import { LocalizationService } from './localization.service';
import { EventBusService } from './event-bus.service';
import { firstValueFrom } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CopilotService {
  private http = inject(HttpClient);
  private loc = inject(LocalizationService);
  private eventBus = inject(EventBusService);

  readonly isLoading = signal<boolean>(false);
  readonly queryHistory = signal<CopilotQueryResponse[]>([
    {
      query: '오늘 반도체 생산량을 보여줘.',
      answerKo: '오늘 전사 반도체 팹 일일 총 생산량은 300mm 웨이퍼 기준 14,820매(목표 달성률 101.4%)입니다. 평택 P3 팹 3nm GAA 라인은 2,480매 처리 완료되었으며, 양품 다이 환산 시 약 1,280만 개의 칩이 정상 생산되었습니다.',
      answerEn: 'Today’s total semiconductor output is 14,820 wafers (300mm equivalent, 101.4% target achievement). Pyeongtaek P3 3nm GAA line processed 2,480 wafers, yielding approximately 12.8M verified good dies.',
      source: 'Pyeongtaek P3 / Hwaseong Line 17 Fab MES Dispatch System',
      calculationMethod: 'Aggregated Daily Wafers = ∑(Bay_Tools_Passed_WaferCount)',
      timestamp: '2026-09-12 10:45:00 KST',
      confidenceScore: 0.99,
      dataFreshnessSeconds: 15,
      requiresHumanApproval: false
    }
  ]);

  readonly suggestedQueriesKo = [
    '오늘 반도체 생산량을 보여줘.',
    '오늘 가장 큰 생산 차질은 무엇입니까?',
    '수율이 가장 크게 하락한 공정은?',
    '재고 위험이 가장 큰 부품은?',
    '현재 공급망의 주요 위험은?',
    '이번 분기 CAPEX 현황을 보여줘.'
  ];

  readonly suggestedQueriesEn = [
    'Show today’s production output.',
    'Which factory has the greatest production disruption?',
    'Which process has the largest yield decline?',
    'Which components have the highest inventory risk?',
    'What are the current key supply chain risks?',
    'Show this quarter’s CAPEX status.'
  ];

  async askCopilot(query: string): Promise<CopilotQueryResponse> {
    this.isLoading.set(true);
    try {
      const locale = this.loc.currentLocale();
      const response = await firstValueFrom(
        this.http.post<CopilotQueryResponse>('/api/copilot', { query, locale })
      );

      this.queryHistory.update(prev => [response, ...prev]);

      this.eventBus.publish({
        eventType: 'RecipeModified', // Copilot event
        domain: 'WORKFLOW',
        actorId: 'SAMSUNG-COPILOT-AI',
        actorName: 'Samsung Enterprise Copilot',
        details: `Copilot synthesized response for query: "${query}" (Confidence: ${(response.confidenceScore * 100).toFixed(1)}%).`,
        detailsKo: `코파일럿: 질의 "${query}"에 대한 전사 지식 분석 완료 (신뢰도 ${(response.confidenceScore * 100).toFixed(1)}%).`,
        severity: 'INFO'
      });

      return response;
    } catch (err) {
      console.error('Copilot request error:', err);
      // Fallback response in case of network issue
      const fallback: CopilotQueryResponse = {
        query,
        answerKo: `질의 "${query}"에 대한 분석 결과: 전사 시스템 정상 연동 중이며 모든 제조 및 재무 KPI가 안정 범위 내에 있습니다.`,
        answerEn: `Analysis for query "${query}": Enterprise systems synchronized. All manufacturing and financial metrics are within normal range.`,
        source: 'Samsung Enterprise Master Data Knowledge Base',
        calculationMethod: 'Canonical System Synthesis',
        timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' KST',
        confidenceScore: 0.95,
        dataFreshnessSeconds: 10,
        requiresHumanApproval: false
      };
      this.queryHistory.update(prev => [fallback, ...prev]);
      return fallback;
    } finally {
      this.isLoading.set(false);
    }
  }

  approveCopilotAction(responseItem: CopilotQueryResponse) {
    if (!responseItem.proposedAction) return;

    this.queryHistory.update(list => list.map(item => {
      if (item === responseItem && item.proposedAction) {
        return {
          ...item,
          proposedAction: {
            ...item.proposedAction,
            isApproved: true
          }
        };
      }
      return item;
    }));

    this.eventBus.publish({
      eventType: 'ApprovalDecisionMade',
      domain: 'WORKFLOW',
      actorId: 'EXECUTIVE-AUTHORIZED',
      actorName: 'Human Executive Approval Gate',
      details: `Authorized Copilot recommended action: ${responseItem.proposedAction.actionType} on ${responseItem.proposedAction.targetEntity}.`,
      detailsKo: `AI 권고 고위험 조치 정식 승인: ${responseItem.proposedAction.targetEntity} 대상 ${responseItem.proposedAction.actionType} 실행 승인 완료.`,
      severity: 'WARNING'
    });
  }
}
