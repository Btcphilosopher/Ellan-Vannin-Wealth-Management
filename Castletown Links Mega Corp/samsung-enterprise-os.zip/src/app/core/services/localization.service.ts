import { Injectable, signal, computed } from '@angular/core';
import { Locale, TerminologyItem } from '../models/localization.types';


@Injectable({
  providedIn: 'root'
})
export class LocalizationService {
  readonly currentLocale = signal<Locale>('ko-KR');

  // Terminology Dictionary
  readonly terminologyDictionary: TerminologyItem[] = [
    { id: 'T01', korean: '기업', english: 'Enterprise', hanja: '企業', category: 'ORGANIZATION', definitionKo: '영리를 목적으로 생산·유통 활동을 수행하는 개별 경제 주체', definitionEn: 'A business or company undertaking commercial activities' },
    { id: 'T02', korean: '그룹', english: 'Group / Conglomerate', hanja: '集團', category: 'ORGANIZATION', definitionKo: '다수의 계열사와 사업부문으로 구성된 복합 기업 집단', definitionEn: 'Multi-business corporate group and global conglomerate' },
    { id: 'T03', korean: '법인', english: 'Legal Entity', hanja: '法人', category: 'ORGANIZATION', definitionKo: '법률상 권리와 의무의 주체가 되는 독립적 사업체', definitionEn: 'An independent legal entity having juridical rights' },
    { id: 'T04', korean: '사업부', english: 'Business Unit', hanja: '事業部', category: 'ORGANIZATION', definitionKo: '특정 제품군 또는 사업영역을 총괄하는 책임 조직', definitionEn: 'A distinct corporate division managing products and profit' },
    { id: 'T05', korean: '공장', english: 'Factory / Manufacturing Site', hanja: '工場', category: 'MANUFACTURING', definitionKo: '제품의 제조, 가공 및 조립이 이루어지는 생산 거점', definitionEn: 'A manufacturing facility where production takes place' },
    { id: 'T06', korean: '생산라인', english: 'Production Line', hanja: '生産Line', category: 'MANUFACTURING', definitionKo: '순차적 가공 및 조립 공정이 배치된 설비 열', definitionEn: 'A continuous sequence of automated manufacturing stations' },
    { id: 'T07', korean: '설비', english: 'Equipment / Machinery', hanja: '設備', category: 'MANUFACTURING', definitionKo: '제조 공정을 직접 수행하는 하드웨어 장치 및 모듈', definitionEn: 'Industrial tools, chambers, and machinery used in processing' },
    { id: 'T08', korean: '자산', english: 'Asset', hanja: '資産', category: 'FINANCE', definitionKo: '기업이 소유한 유무형의 경제적 가치를 지닌 자원', definitionEn: 'Economic resource owned by the enterprise' },
    { id: 'T09', korean: '제품', english: 'Product', hanja: '製品', category: 'MANUFACTURING', definitionKo: '최종 고객 또는 고객사에 납품되는 완제품', definitionEn: 'Finished goods delivered to markets or clients' },
    { id: 'T10', korean: '부품', english: 'Component / Part', hanja: '部品', category: 'SUPPLY_CHAIN', definitionKo: '제품을 구성하는 개별 기계·전자 단위 소자', definitionEn: 'Discrete hardware or electronic parts assembling a product' },
    { id: 'T11', korean: '공급망', english: 'Supply Chain', hanja: '供給網', category: 'SUPPLY_CHAIN', definitionKo: '원자재 조달부터 완제품 고객 전달까지의 전 공급 흐름', definitionEn: 'End-to-end network from raw material sourcing to customer delivery' },
    { id: 'T12', korean: '조달', english: 'Procurement', hanja: '調達', category: 'SUPPLY_CHAIN', definitionKo: '생산에 필요한 원자재 및 부품을 공급사로부터 구매', definitionEn: 'Acquisition of raw goods, components, and outsourced services' },
    { id: 'T13', korean: '재고', english: 'Inventory / Stock', hanja: '在庫', category: 'SUPPLY_CHAIN', definitionKo: '보유 중인 원자재, 재공품 및 완제품의 총량', definitionEn: 'Current quantity of raw materials, WIP, and finished stock' },
    { id: 'T14', korean: '물류', english: 'Logistics', hanja: '物流', category: 'SUPPLY_CHAIN', definitionKo: '제품과 자재의 물리적 운송, 보관 및 유통 관리', definitionEn: 'Physical transportation, warehousing, and freight tracking' },
    { id: 'T15', korean: '품질', english: 'Quality', hanja: '品質', category: 'QUALITY', definitionKo: '규격 및 고객 요구사항에 대한 제품의 부합도', definitionEn: 'Degree of excellence and adherence to engineering tolerances' },
    { id: 'T16', korean: '연구개발', english: 'Research & Development (R&D)', hanja: '硏究開發', category: 'ORGANIZATION', definitionKo: '차세대 원천기술 확보 및 신제품 설계를 위한 연구 활동', definitionEn: 'Systematic activity to discover and develop new technologies' },
    { id: 'T17', korean: '반도체', english: 'Semiconductor', hanja: '半導體', category: 'SEMICONDUCTOR', definitionKo: '집적회로(IC), 메모리(DRAM/NAND), 시스템 파운드리 웨이퍼', definitionEn: 'Silicon microchips, memory modules, and wafer fabrications' },
    { id: 'T18', korean: '웨이퍼', english: 'Wafer', hanja: 'Wafer', category: 'SEMICONDUCTOR', definitionKo: '반도체 집적회로가 인쇄되는 300mm 단결정 실리콘 원판', definitionEn: 'Thin 300mm circular silicon slice used for IC fabrication' },
    { id: 'T19', korean: '공정', english: 'Process / Step', hanja: '工程', category: 'SEMICONDUCTOR', definitionKo: '노광, 식각, 증착, 세정, CMP 등 웨이퍼 가공 단계', definitionEn: 'Sequence of chemical/physical litho, etch, and deposition steps' },
    { id: 'T20', korean: '수율', english: 'Yield', hanja: '收率', category: 'SEMICONDUCTOR', definitionKo: '투입된 총 칩(Die) 대비 합격 판정을 받은 양품의 비율', definitionEn: 'Percentage of non-defective dies manufactured per wafer' },
    { id: 'T21', korean: '원가', english: 'Cost of Goods / Unit Cost', hanja: '原價', category: 'FINANCE', definitionKo: '제품 1단위 제조에 소요된 재료비, 노무비, 경비의 합계', definitionEn: 'Total expenditure of material, labor, and overhead per unit' },
    { id: 'T22', korean: '매출', english: 'Revenue', hanja: '賣出', category: 'FINANCE', definitionKo: '기업이 제품이나 용역을 판매하여 획득한 총 금액', definitionEn: 'Total gross income from products and service operations' },
    { id: 'T23', korean: '영업이익', english: 'Operating Profit', hanja: '營業利益', category: 'FINANCE', definitionKo: '매출액에서 매출원가 및 판관비를 차감한 핵심 사업 이익', definitionEn: 'Profit realized from business operations after deducting COGS/SG&A' },
    { id: 'T24', korean: '결재', english: 'Approval Workflow', hanja: '決裁', category: 'WORKFLOW', definitionKo: '하급자가 작성한 안건을 상급자가 검토하여 승인 또는 반려함', definitionEn: 'Formal hierarchical corporate document review and sign-off' },
    { id: 'T25', korean: '승인', english: 'Approved', hanja: '承認', category: 'WORKFLOW', definitionKo: '상신된 안건에 대해 결재권자가 최종 동의함', definitionEn: 'Formal authorization grant by an executive approver' },
    { id: 'T26', korean: '반려', english: 'Rejected / Returned', hanja: '返戾', category: 'WORKFLOW', definitionKo: '결재 서류의 하자 또는 사유 미흡으로 기안자에게 되돌림', definitionEn: 'Disapproval with formal return of requisition' },
    { id: 'T27', korean: '전결', english: 'Delegated Authority', hanja: '專決', category: 'WORKFLOW', definitionKo: '위임전결 규정에 의거하여 위임받은 직급자가 최종 결재함', definitionEn: 'Final approval executed by delegated authority limit' },
    { id: 'T28', korean: '지식재산권', english: 'Intellectual Property (IP)', hanja: '知識財産權', category: 'ORGANIZATION', definitionKo: '특허, 실용신안, 상표, 영업비밀 등 지적 창작물 권리', definitionEn: 'Legal patent, trademark, and technological proprietary rights' },
    { id: 'T29', korean: '보안', english: 'Security / Zero Trust', hanja: '保安', category: 'SECURITY', definitionKo: '엔터프라이즈 자산, 디바이스, 네트워크, 기밀의 다계층 보호', definitionEn: 'Multi-layer defensive posture securing hardware, identity, and data' },
    { id: 'T30', korean: '디지털 트윈', english: 'Digital Twin', hanja: 'Digital Twin', category: 'MANUFACTURING', definitionKo: '실제 팹과 공장을 가상 환경에 1:1로 실시간 동기화한 모델', definitionEn: 'Real-time virtual replica of factories and equipment for simulation' }
  ];

  // Global Multi-lingual Dictionary Table
  private readonly translations: Record<Locale, Record<string, string>> = {
    'ko-KR': {
      // System Identity & Header
      'app.title': '삼성 엔터프라이즈 OS',
      'app.subtitle': '글로벌 기업 통합 운영 플랫폼',
      'app.tagline': '하나의 그룹 • 하나의 데이터 모델 • 하나의 운영체계',
      'app.synthetic_badge': '합성 데이터 / SYNTHETIC DATA',
      'app.synthetic_notice': '본 플랫폼의 모든 데이터는 교육 및 기술 시연용 합성 데이터이며, 실제 기밀이나 내부 자료와 무관합니다.',

      // Navigation Items
      'nav.executive': '경영진 통합 관제',
      'nav.semiconductor': '반도체 팹 OS',
      'nav.mes_digital_twin': '스마트팩토리 & 디지털 트윈',
      'nav.device_display': '디바이스 & 디스플레이',
      'nav.supply_chain': '공급망 컨트롤타워',
      'nav.finance_cost': '재무 & 원가 관리',
      'nav.approval': '전자결재 시스템',
      'nav.security_knox': '보안관제 & Knox 디바이스',
      'nav.copilot': '엔터프라이즈 코파일럿 (AI)',
      'nav.audit_events': '감사 추적 & 이벤트 버스',
      'nav.workspace_dex': '갤럭시 워크스페이스',
      'nav.terminology': '용어 사전',

      // Executive Dashboard
      'exec.kpi.revenue': '그룹 총 매출액',
      'exec.kpi.operating_profit': '영업이익',
      'exec.kpi.free_cash_flow': '잉여현금흐름 (FCF)',
      'exec.kpi.capex': '자본적 지출 (CapEx)',
      'exec.kpi.rnd': 'R&D 투자액',
      'exec.kpi.margin': '영업이익률',
      'exec.division_performance': '사업부문별 실적 요약 (DS / DX / SDC / Harman)',
      'exec.global_sites': '글로벌 제조 거점 현황',
      'exec.live_alerts': '경영 리스크 실시간 감지',

      // Semiconductor Fab
      'semi.title': '반도체 팹 운영체계 (Fab OS)',
      'semi.subtitle': '300mm 웨이퍼 로트 추적, EUV 공정 챔버 텔레메트리 및 수율 SPC 분석',
      'semi.fab_selector': '가동 팹 선택',
      'semi.active_lots': '진행 중 웨이퍼 로트',
      'semi.wafer_yield_target': '목표 수율 달성도',
      'semi.chamber_status': '공정 챔버 헬스체크',
      'semi.defect_density': '결함 밀도 (Defects/cm²)',
      'semi.euv_litho': 'EUV 극자외선 노광기',
      'semi.plasma_etch': '원자층 건식 식각기 (ALE)',
      'semi.ald_depo': '원자층 증착기 (ALD)',
      'semi.cmp_polish': '화학기계연마기 (CMP)',

      // MES & Digital Twin
      'mes.title': '스마트팩토리 MES & 디지털 트윈',
      'mes.oee_overall': '종합설비효율 (OEE)',
      'mes.availability': '시간가동률 (Availability)',
      'mes.performance': '성능가동률 (Performance)',
      'mes.quality': '양품률 (Quality)',
      'mes.what_if_simulator': 'What-If 시뮬레이션 엔진',
      'mes.run_simulation': '공정 중단 시뮬레이션 실행',
      'mes.reset_simulation': '정상 가동 상태 복원',

      // Device & BOM
      'device.title': '제품 개발 라이프사이클 & BOM 엔진',
      'device.bom_type': 'BOM 구분 (E-BOM / M-BOM / S-BOM)',
      'device.unit_cost': '단위 제조원가 (COGS)',
      'device.gross_margin': '목표 매출총이익률',
      'device.lifecycle_phase': '현재 개발 단계',
      'device.change_history': '설계 변경 이력 (ECO)',

      // Supply Chain
      'scm.title': '글로벌 공급망 컨트롤타워 (SCM Control Tower)',
      'scm.in_transit_shipments': '운송 중 컨테이너 및 항공 화물',
      'scm.supplier_risk_matrix': '공급사 지정학적/품질 리스크 매트릭스',
      'scm.port_congestion': '주요 환적항 혼잡도',
      'scm.temperature_coldchain': '콜드체인 텔레메트리 (반도체 소재/화학품)',

      // Approval
      'appr.title': '한국형 전자결재 시스템 (Approval Engine)',
      'appr.btn_approve': '승인 (Approve)',
      'appr.btn_reject': '반려 (Reject)',
      'appr.btn_delegate': '전결 처리 (Delegate)',
      'appr.btn_consult': '협의 요청 (Consult)',
      'appr.approver_line': '결재선 (직원 → 팀장 → 부서장 → 사업부장 → CEO)',
      'appr.status_pending': '결재 대기',
      'appr.status_approved': '결재 완료',
      'appr.status_rejected': '반려됨',

      // Copilot
      'copilot.title': '삼성 엔터프라이즈 코파일럿 (Copilot AI)',
      'copilot.placeholder': '경영, 생산량, 수율 하락 공정, 재고 리스크에 대해 질문하세요...',
      'copilot.send': '질의 실행',
      'copilot.source_badge': '데이터 출처 (Source)',
      'copilot.calc_badge': '계산 산식 (Calculation)',
      'copilot.confidence': '신뢰도 (Confidence)',
      'copilot.freshness': '데이터 신선도',
      'copilot.safety_alert': 'AI 안전 통제: 고위험 조치는 인간의 승인이 필수적입니다.',
      'copilot.btn_approve_action': '권고 조치 승인 및 실행',
      'copilot.btn_dismiss_action': '권고 반려',

      // Security & Knox
      'sec.title': '보안관제센터 (SOC) & Knox 디바이스 플릿',
      'sec.zero_trust': 'Zero Trust 위협 모니터링',
      'sec.knox_attestation': 'Knox 하드웨어 무결성 검증 (Attestation)',
      'sec.remote_lock': '원격 격리 및 정책 배포',

      // Common Actions
      'common.refresh': '새로고침',
      'common.export': '내보내기',
      'common.filter': '필터',
      'common.search': '검색',
      'common.details': '상세 정보',
      'common.status': '상태',
      'common.date': '일시',
      'common.user': '담당자',
      'common.active': '가동중'
    },
    'en-US': {
      // System Identity & Header
      'app.title': 'SAMSUNG ENTERPRISE OS',
      'app.subtitle': 'Unified Global Enterprise Operating Platform',
      'app.tagline': 'One Group • One Data Model • One Operating System',
      'app.synthetic_badge': 'SYNTHETIC DATA / 합성 데이터',
      'app.synthetic_notice': 'All data within this system is synthetic demonstration data for architectural showcase purposes and contains no confidential data.',

      // Navigation Items
      'nav.executive': 'Executive Command Centre',
      'nav.semiconductor': 'Semiconductor Fab OS',
      'nav.mes_digital_twin': 'Smart Factory & Digital Twin',
      'nav.device_display': 'Device & Display Business',
      'nav.supply_chain': 'Supply Chain Control Tower',
      'nav.finance_cost': 'Finance & Cost Engine',
      'nav.approval': 'Korean Approval Engine',
      'nav.security_knox': 'SOC & Knox Fleet',
      'nav.copilot': 'Enterprise Copilot (AI)',
      'nav.audit_events': 'Audit Trail & Event Bus',
      'nav.workspace_dex': 'Galaxy Workspace',
      'nav.terminology': 'Enterprise Terminology',

      // Executive Dashboard
      'exec.kpi.revenue': 'Group Total Revenue',
      'exec.kpi.operating_profit': 'Operating Profit',
      'exec.kpi.free_cash_flow': 'Free Cash Flow (FCF)',
      'exec.kpi.capex': 'Capital Expenditure (CapEx)',
      'exec.kpi.rnd': 'R&D Investment',
      'exec.kpi.margin': 'Operating Margin',
      'exec.division_performance': 'Business Unit Performance (DS / DX / SDC / Harman)',
      'exec.global_sites': 'Global Manufacturing Footprint',
      'exec.live_alerts': 'Executive Risk Signals',

      // Semiconductor Fab
      'semi.title': 'Semiconductor Fab Operating System',
      'semi.subtitle': '300mm Wafer Lot Tracking, EUV Tool Chamber Telemetry, and SPC Yield Curve',
      'semi.fab_selector': 'Select Active Fab',
      'semi.active_lots': 'Active Wafer Lots',
      'semi.wafer_yield_target': 'Yield Target Achievement',
      'semi.chamber_status': 'Chamber Health Matrix',
      'semi.defect_density': 'Defect Density (Defects/cm²)',
      'semi.euv_litho': 'EUV Lithography Scanner',
      'semi.plasma_etch': 'Atomic Layer Etcher (ALE)',
      'semi.ald_depo': 'Atomic Layer Deposition (ALD)',
      'semi.cmp_polish': 'Chemical Mechanical Planarization (CMP)',

      // MES & Digital Twin
      'mes.title': 'Smart Factory MES & Digital Twin',
      'mes.oee_overall': 'Overall Equipment Effectiveness (OEE)',
      'mes.availability': 'Availability Rate',
      'mes.performance': 'Performance Efficiency',
      'mes.quality': 'Quality Rate',
      'mes.what_if_simulator': 'What-If Simulation Engine',
      'mes.run_simulation': 'Simulate Equipment Stoppage',
      'mes.reset_simulation': 'Restore Normal State',

      // Device & BOM
      'device.title': 'Product Engineering & BOM Engine',
      'device.bom_type': 'BOM Structure (E-BOM / M-BOM / S-BOM)',
      'device.unit_cost': 'Unit Manufacturing Cost (COGS)',
      'device.gross_margin': 'Target Gross Margin',
      'device.lifecycle_phase': 'Current Lifecycle Stage',
      'device.change_history': 'Engineering Change History (ECO)',

      // Supply Chain
      'scm.title': 'Global Supply Chain Control Tower',
      'scm.in_transit_shipments': 'In-Transit Containers & Air Cargo',
      'scm.supplier_risk_matrix': 'Supplier Geopolitical & Quality Risk Matrix',
      'scm.port_congestion': 'Key Hub Port Congestion Levels',
      'scm.temperature_coldchain': 'Cold-Chain Telemetry (Fab Chemicals)',

      // Approval
      'appr.title': 'Korean Enterprise Approval Engine (전자결재)',
      'appr.btn_approve': 'Approve',
      'appr.btn_reject': 'Reject',
      'appr.btn_delegate': 'Delegate Authority',
      'appr.btn_consult': 'Request Consultation',
      'appr.approver_line': 'Approval Path (Staff → Team Leader → Dept Head → BU Head → CEO)',
      'appr.status_pending': 'Pending Review',
      'appr.status_approved': 'Approved',
      'appr.status_rejected': 'Rejected',

      // Copilot
      'copilot.title': 'Samsung Enterprise Copilot (AI)',
      'copilot.placeholder': 'Ask about revenue, fab production, yield drops, supply chain risks...',
      'copilot.send': 'Execute Query',
      'copilot.source_badge': 'Source System',
      'copilot.calc_badge': 'Calculation Formula',
      'copilot.confidence': 'Confidence Score',
      'copilot.freshness': 'Data Freshness',
      'copilot.safety_alert': 'AI Action Safety: High-impact actions require authorized human approval.',
      'copilot.btn_approve_action': 'Authorize & Execute Action',
      'copilot.btn_dismiss_action': 'Dismiss Recommendation',

      // Security & Knox
      'sec.title': 'Security Operations Centre (SOC) & Knox Fleet',
      'sec.zero_trust': 'Zero Trust Threat Monitoring',
      'sec.knox_attestation': 'Knox Hardware Root-of-Trust Attestation',
      'sec.remote_lock': 'Remote Device Isolation & Policy Push',

      // Common Actions
      'common.refresh': 'Refresh',
      'common.export': 'Export',
      'common.filter': 'Filter',
      'common.search': 'Search',
      'common.details': 'Details',
      'common.status': 'Status',
      'common.date': 'Timestamp',
      'common.user': 'Owner',
      'common.active': 'Active'
    },
    'en-GB': {
      // System Identity & Header
      'app.title': 'SAMSUNG ENTERPRISE OS',
      'app.subtitle': 'Unified Global Enterprise Operating Platform',
      'app.tagline': 'One Group • One Data Model • One Operating System',
      'app.synthetic_badge': 'SYNTHETIC DATA / 합성 데이터',
      'app.synthetic_notice': 'All data within this system is synthetic demonstration data for architectural showcase purposes and contains no confidential data.',

      // Navigation Items
      'nav.executive': 'Executive Command Centre',
      'nav.semiconductor': 'Semiconductor Fab OS',
      'nav.mes_digital_twin': 'Smart Factory & Digital Twin',
      'nav.device_display': 'Device & Display Business',
      'nav.supply_chain': 'Supply Chain Control Tower',
      'nav.finance_cost': 'Finance & Cost Engine',
      'nav.approval': 'Korean Approval Engine',
      'nav.security_knox': 'SOC & Knox Fleet',
      'nav.copilot': 'Enterprise Copilot (AI)',
      'nav.audit_events': 'Audit Trail & Event Bus',
      'nav.workspace_dex': 'Galaxy Workspace',
      'nav.terminology': 'Enterprise Terminology',

      // Executive Dashboard
      'exec.kpi.revenue': 'Group Total Revenue',
      'exec.kpi.operating_profit': 'Operating Profit',
      'exec.kpi.free_cash_flow': 'Free Cash Flow (FCF)',
      'exec.kpi.capex': 'Capital Expenditure (CapEx)',
      'exec.kpi.rnd': 'R&D Investment',
      'exec.kpi.margin': 'Operating Margin',
      'exec.division_performance': 'Business Unit Performance (DS / DX / SDC / Harman)',
      'exec.global_sites': 'Global Manufacturing Footprint',
      'exec.live_alerts': 'Executive Risk Signals',

      // Semiconductor Fab
      'semi.title': 'Semiconductor Fab Operating System',
      'semi.subtitle': '300mm Wafer Lot Tracking, EUV Tool Chamber Telemetry, and SPC Yield Curve',
      'semi.fab_selector': 'Select Active Fab',
      'semi.active_lots': 'Active Wafer Lots',
      'semi.wafer_yield_target': 'Yield Target Achievement',
      'semi.chamber_status': 'Chamber Health Matrix',
      'semi.defect_density': 'Defect Density (Defects/cm²)',
      'semi.euv_litho': 'EUV Lithography Scanner',
      'semi.plasma_etch': 'Atomic Layer Etcher (ALE)',
      'semi.ald_depo': 'Atomic Layer Deposition (ALD)',
      'semi.cmp_polish': 'Chemical Mechanical Planarisation (CMP)',

      // MES & Digital Twin
      'mes.title': 'Smart Factory MES & Digital Twin',
      'mes.oee_overall': 'Overall Equipment Effectiveness (OEE)',
      'mes.availability': 'Availability Rate',
      'mes.performance': 'Performance Efficiency',
      'mes.quality': 'Quality Rate',
      'mes.what_if_simulator': 'What-If Simulation Engine',
      'mes.run_simulation': 'Simulate Equipment Stoppage',
      'mes.reset_simulation': 'Restore Normal State',

      // Device & BOM
      'device.title': 'Product Engineering & BOM Engine',
      'device.bom_type': 'BOM Structure (E-BOM / M-BOM / S-BOM)',
      'device.unit_cost': 'Unit Manufacturing Cost (COGS)',
      'device.gross_margin': 'Target Gross Margin',
      'device.lifecycle_phase': 'Current Lifecycle Stage',
      'device.change_history': 'Engineering Change History (ECO)',

      // Supply Chain
      'scm.title': 'Global Supply Chain Control Tower',
      'scm.in_transit_shipments': 'In-Transit Containers & Air Cargo',
      'scm.supplier_risk_matrix': 'Supplier Geopolitical & Quality Risk Matrix',
      'scm.port_congestion': 'Key Hub Port Congestion Levels',
      'scm.temperature_coldchain': 'Cold-Chain Telemetry (Fab Chemicals)',

      // Approval
      'appr.title': 'Korean Enterprise Approval Engine (전자결재)',
      'appr.btn_approve': 'Approve',
      'appr.btn_reject': 'Reject',
      'appr.btn_delegate': 'Delegate Authority',
      'appr.btn_consult': 'Request Consultation',
      'appr.approver_line': 'Approval Path (Staff → Team Leader → Dept Head → BU Head → CEO)',
      'appr.status_pending': 'Pending Review',
      'appr.status_approved': 'Approved',
      'appr.status_rejected': 'Rejected',

      // Copilot
      'copilot.title': 'Samsung Enterprise Copilot (AI)',
      'copilot.placeholder': 'Ask about revenue, fab production, yield drops, supply chain risks...',
      'copilot.send': 'Execute Query',
      'copilot.source_badge': 'Source System',
      'copilot.calc_badge': 'Calculation Formula',
      'copilot.confidence': 'Confidence Score',
      'copilot.freshness': 'Data Freshness',
      'copilot.safety_alert': 'AI Action Safety: High-impact actions require authorised human approval.',
      'copilot.btn_approve_action': 'Authorise & Execute Action',
      'copilot.btn_dismiss_action': 'Dismiss Recommendation',

      // Security & Knox
      'sec.title': 'Security Operations Centre (SOC) & Knox Fleet',
      'sec.zero_trust': 'Zero Trust Threat Monitoring',
      'sec.knox_attestation': 'Knox Hardware Root-of-Trust Attestation',
      'sec.remote_lock': 'Remote Device Isolation & Policy Push',

      // Common Actions
      'common.refresh': 'Refresh',
      'common.export': 'Export',
      'common.filter': 'Filter',
      'common.search': 'Search',
      'common.details': 'Details',
      'common.status': 'Status',
      'common.date': 'Timestamp',
      'common.user': 'Owner',
      'common.active': 'Active'
    }
  };

  setLocale(locale: Locale) {
    this.currentLocale.set(locale);
  }

  isKorean = computed(() => this.currentLocale() === 'ko-KR');

  t(key: string, defaultText?: string): string {
    const loc = this.currentLocale();
    const dictionary = this.translations[loc] || this.translations['ko-KR'];
    return dictionary[key] || defaultText || key;
  }

  getCanonicalTerm(koreanTerm: string): TerminologyItem | undefined {
    return this.terminologyDictionary.find(
      item => item.korean.toLowerCase() === koreanTerm.toLowerCase() ||
              item.english.toLowerCase() === koreanTerm.toLowerCase()
    );
  }
}
