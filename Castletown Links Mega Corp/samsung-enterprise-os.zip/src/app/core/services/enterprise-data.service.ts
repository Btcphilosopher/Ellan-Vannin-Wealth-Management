import { Injectable, signal, inject } from '@angular/core';
import { 
  FinancialMetric, 
  SiteFacility, 
  WaferLot, 
  FabTool, 
  EnterpriseProduct, 
  LogisticsShipment, 
  EnterpriseApprovalDoc, 
  EnterpriseDevice, 
  SecurityIncident, 
  CostBreakdown,
  EquipmentState
} from '../models/enterprise.types';
import { EventBusService } from './event-bus.service';


@Injectable({
  providedIn: 'root'
})
export class EnterpriseDataService {
  private eventBus = inject(EventBusService);

  // 1. Group Executive Financials (Synthetic Conglomerate Accounting)
  readonly financials = signal<FinancialMetric>({
    groupRevenueKRW_Trillion: 308.5,
    operatingProfitKRW_Trillion: 45.2,
    operatingMarginPercent: 14.65,
    freeCashFlowKRW_Trillion: 38.6,
    capExKRW_Trillion: 54.0,
    rndInvestmentKRW_Trillion: 31.2,
    divisionBreakdown: [
      { division: 'DS (Semiconductor / Memory & Foundry)', divisionKo: 'DS 부문 (메모리·시스템LSI·파운드리)', revenueKRW_T: 108.4, operatingProfitKRW_T: 22.8, marginPct: 21.03, capExSharePct: 62.5 },
      { division: 'DX (Mobile Experience & Visual Display)', divisionKo: 'DX 부문 (MX 모바일·영상디스플레이·가전)', revenueKRW_T: 142.1, operatingProfitKRW_T: 14.5, marginPct: 10.20, capExSharePct: 14.0 },
      { division: 'SDC (Samsung Display / OLED & QD-OLED)', divisionKo: 'SDC (삼성디스플레이 OLED·QD-OLED)', revenueKRW_T: 34.2, operatingProfitKRW_T: 5.6, marginPct: 16.37, capExSharePct: 18.5 },
      { division: 'Harman (Automotive & Connected Audio)', divisionKo: '하만 (전장부품 및 프리미엄 오디오)', revenueKRW_T: 15.8, operatingProfitKRW_T: 1.8, marginPct: 11.39, capExSharePct: 3.5 },
      { division: 'Global Logistics & Corporate HQ', divisionKo: '글로벌 물류 및 코퍼레이트 총괄', revenueKRW_T: 8.0, operatingProfitKRW_T: 0.5, marginPct: 6.25, capExSharePct: 1.5 }
    ]
  });

  // 2. Global Sites & Facilities
  readonly facilities = signal<SiteFacility[]>([
    {
      id: 'SITE-PTK',
      name: 'Pyeongtaek Semiconductor Complex (Fab P3/P4)',
      nameKo: '평택 반도체 메가 콤플렉스 (P3/P4 팹)',
      code: 'KR-PTK-FAB',
      type: 'FAB',
      location: 'Pyeongtaek, Gyeonggi-do, Korea',
      country: 'KR',
      coordinates: { lat: 37.0435, lng: 127.0543 },
      activeLines: 12,
      totalPersonnel: 24500,
      energyConsumptionMW: 480.5,
      cleanroomClass: 'Class 1 (ISO 3)',
      oeePercent: 92.4
    },
    {
      id: 'SITE-HWS',
      name: 'Hwaseong EUV & Advanced R&D Campus',
      nameKo: '화성 EUV 전용 라인 및 차세대 R&D 캠퍼스',
      code: 'KR-HWS-EUV',
      type: 'FAB',
      location: 'Hwaseong, Gyeonggi-do, Korea',
      country: 'KR',
      coordinates: { lat: 37.2084, lng: 127.0657 },
      activeLines: 8,
      totalPersonnel: 18200,
      energyConsumptionMW: 320.0,
      cleanroomClass: 'Class 1 (ISO 3)',
      oeePercent: 93.8
    },
    {
      id: 'SITE-TAY',
      name: 'Taylor Advanced Logic Foundry (Fab 1)',
      nameKo: '미국 텍사스 테일러 첨단 파운드리 (Fab 1)',
      code: 'US-TAY-F01',
      type: 'FAB',
      location: 'Taylor, Texas, United States',
      country: 'US',
      coordinates: { lat: 30.5707, lng: -97.4092 },
      activeLines: 4,
      totalPersonnel: 4800,
      energyConsumptionMW: 195.0,
      cleanroomClass: 'Class 1 (ISO 3)',
      oeePercent: 89.2
    },
    {
      id: 'SITE-GUM',
      name: 'Gumi Mobile Smart City (Flagship Production)',
      nameKo: '구미 모바일 스마트시티 (플래그십 디바이스 제조)',
      code: 'KR-GUM-DX',
      type: 'SMART_FACTORY',
      location: 'Gumi, Gyeongsangbuk-do, Korea',
      country: 'KR',
      coordinates: { lat: 36.1195, lng: 128.3446 },
      activeLines: 16,
      totalPersonnel: 9400,
      energyConsumptionMW: 85.2,
      oeePercent: 94.6
    },
    {
      id: 'SITE-ASN',
      name: 'Asan Display City (OLED & MicroLED)',
      nameKo: '아산 디스플레이 시티 (OLED & MicroLED 패널)',
      code: 'KR-ASN-SDC',
      type: 'FAB',
      location: 'Asan, Chungcheongnam-do, Korea',
      country: 'KR',
      coordinates: { lat: 36.7898, lng: 127.0018 },
      activeLines: 10,
      totalPersonnel: 13500,
      energyConsumptionMW: 260.4,
      cleanroomClass: 'Class 10 (ISO 4)',
      oeePercent: 91.5
    },
    {
      id: 'SITE-VNM',
      name: 'Bac Ninh High-Volume Mobile Assembly Center',
      nameKo: '베트남 박닌 글로벌 모바일 조립 메가 플랜트',
      code: 'VN-BCN-MFG',
      type: 'SMART_FACTORY',
      location: 'Bac Ninh, Vietnam',
      country: 'VN',
      coordinates: { lat: 21.1861, lng: 106.0763 },
      activeLines: 24,
      totalPersonnel: 38000,
      energyConsumptionMW: 140.0,
      oeePercent: 93.1
    }
  ]);

  // 3. Semiconductor Fab Tools
  readonly fabTools = signal<FabTool[]>([
    {
      id: 'TOOL-EUV-01',
      name: 'EUV High-NA Scanner #01',
      bayId: 'BAY-LITHO-01',
      bayName: 'Lithography Bay A',
      model: 'NXE:3800E High-NA',
      vendor: 'ASML / Canon Partner Sync',
      state: 'RUNNING',
      utilizationRate: 98.2,
      oee: { availability: 98.5, performance: 97.4, quality: 99.1, total: 95.1 },
      currentRecipe: 'RECIPE_3NM_GAA_METAL_LAYER_04',
      currentLotId: 'LOT-3NM-8842',
      mtbfHours: 480,
      mttrHours: 2.5,
      maintenanceDueHours: 124,
      powerKw: 1150,
      chambers: [
        { id: 'CH-EUV-A', name: 'Optics Source Chamber', processType: 'LITHO_EUV', status: 'RUNNING', temperatureC: 22.4, pressureTorr: 0.0001, gasFlowSccm: 45, rfPowerWatts: 30000, wafersProcessedToday: 480, alarmsCount: 0 },
        { id: 'CH-EUV-B', name: 'Wafer Stage Chamber', processType: 'LITHO_EUV', status: 'RUNNING', temperatureC: 21.8, pressureTorr: 0.0002, gasFlowSccm: 10, rfPowerWatts: 0, wafersProcessedToday: 480, alarmsCount: 0 }
      ]
    },
    {
      id: 'TOOL-ETCH-04',
      name: 'Atomic Layer Plasma Etcher #04',
      bayId: 'BAY-ETCH-02',
      bayName: 'Dry Etch Bay B',
      model: 'Apex-GAA Dual Chamber',
      vendor: 'TEL / Lam Partner Sync',
      state: 'RUNNING',
      utilizationRate: 94.5,
      oee: { availability: 96.0, performance: 95.0, quality: 98.2, total: 89.6 },
      currentRecipe: 'RECIPE_GAA_NANOSHEET_SELECTIVE_ETCH',
      currentLotId: 'LOT-3NM-8843',
      mtbfHours: 320,
      mttrHours: 1.8,
      maintenanceDueHours: 68,
      powerKw: 420,
      chambers: [
        { id: 'CH-ETCH-1', name: 'RF Plasma Reactor 1', processType: 'ETCH_PLASMA', status: 'RUNNING', temperatureC: 65.2, pressureTorr: 0.05, gasFlowSccm: 240, rfPowerWatts: 1800, wafersProcessedToday: 425, alarmsCount: 0 },
        { id: 'CH-ETCH-2', name: 'RF Plasma Reactor 2', processType: 'ETCH_PLASMA', status: 'RUNNING', temperatureC: 65.0, pressureTorr: 0.05, gasFlowSccm: 240, rfPowerWatts: 1800, wafersProcessedToday: 425, alarmsCount: 0 }
      ]
    },
    {
      id: 'TOOL-ALD-02',
      name: 'Atomic Layer Deposition (High-k Metal Gate)',
      bayId: 'BAY-DEPO-01',
      bayName: 'Thin Film ALD Bay',
      model: 'AtomicFlux-Ultra 300',
      vendor: 'Wonik / Applied Partner Sync',
      state: 'RUNNING',
      utilizationRate: 91.8,
      oee: { availability: 95.2, performance: 93.0, quality: 99.4, total: 88.0 },
      currentRecipe: 'RECIPE_HKMG_HFO2_DEPOSITION',
      currentLotId: 'LOT-3NM-8844',
      mtbfHours: 410,
      mttrHours: 3.1,
      maintenanceDueHours: 210,
      powerKw: 310,
      chambers: [
        { id: 'CH-ALD-1', name: 'Precursor Reaction Chamber', processType: 'ALD_DEPO', status: 'RUNNING', temperatureC: 280.5, pressureTorr: 1.2, gasFlowSccm: 180, rfPowerWatts: 0, wafersProcessedToday: 390, alarmsCount: 0 }
      ]
    },
    {
      id: 'TOOL-CMP-07',
      name: 'Chemical Mechanical Polishing #07',
      bayId: 'BAY-CMP-01',
      bayName: 'Planarization Bay',
      model: 'PlanarMaster 3000',
      vendor: 'Ebara / KCTek Partner Sync',
      state: 'SETUP',
      utilizationRate: 84.0,
      oee: { availability: 88.0, performance: 92.0, quality: 97.5, total: 78.9 },
      currentRecipe: 'RECIPE_CU_INTERCONNECT_POLISH',
      mtbfHours: 250,
      mttrHours: 4.0,
      maintenanceDueHours: 12,
      powerKw: 180,
      chambers: [
        { id: 'CH-CMP-A', name: 'Slurry Head Platen 1', processType: 'CMP_POLISH', status: 'SETUP', temperatureC: 25.0, pressureTorr: 760.0, gasFlowSccm: 0, rfPowerWatts: 0, wafersProcessedToday: 210, alarmsCount: 0 }
      ]
    }
  ]);

  // 4. Wafer Lots in Fab
  readonly waferLots = signal<WaferLot[]>([
    {
      id: 'LOT-3NM-8842',
      lotNumber: 'L8842-P3-GAA',
      productCode: 'SEC-EXYNOS-2600-3NM',
      productName: 'Exynos 2600 Next-Gen 3nm GAA Mobile AP',
      processNode: '3nm GAA',
      fabId: 'SITE-PTK',
      fabName: 'Pyeongtaek P3 Fab',
      waferCount: 25,
      currentStep: 'Step 42/68: EUV Metal Layer 04 Exposure',
      stepIndex: 42,
      totalSteps: 68,
      yieldPercent: 94.8,
      cycleTimeDays: 46.2,
      targetCycleTimeDays: 48.0,
      defectDensityPerCm2: 0.042,
      status: 'PROCESSING',
      carrierId: 'FOUP-9021',
      startedAt: '2026-08-15 08:00 KST',
      estimatedCompletion: '2026-09-28 18:00 KST'
    },
    {
      id: 'LOT-2NM-1090',
      lotNumber: 'L1090-HWS-2NM',
      productCode: 'SEC-AI-NPU-2NM-HBM4',
      productName: 'Mach-2 Enterprise AI Accelerator Core (2nm GAA)',
      processNode: '2nm GAA',
      fabId: 'SITE-HWS',
      fabName: 'Hwaseong Line 17 Fab',
      waferCount: 25,
      currentStep: 'Step 28/84: Nanosheet Channel Atomic Etch',
      stepIndex: 28,
      totalSteps: 84,
      yieldPercent: 91.2,
      cycleTimeDays: 32.5,
      targetCycleTimeDays: 52.0,
      defectDensityPerCm2: 0.068,
      status: 'PROCESSING',
      carrierId: 'FOUP-7740',
      startedAt: '2026-08-28 14:30 KST',
      estimatedCompletion: '2026-10-15 12:00 KST'
    },
    {
      id: 'LOT-DRAM-9941',
      lotNumber: 'L9941-PTK-10NM',
      productCode: 'SEC-DRAM-32GB-LPDDR5T',
      productName: '32GB LPDDR5T Ultra-High Speed Memory',
      processNode: '10nm DRAM',
      fabId: 'SITE-PTK',
      fabName: 'Pyeongtaek P3 Fab',
      waferCount: 25,
      currentStep: 'Step 58/62: Laser Dicing & Probe Metrology',
      stepIndex: 58,
      totalSteps: 62,
      yieldPercent: 97.4,
      cycleTimeDays: 41.0,
      targetCycleTimeDays: 42.0,
      defectDensityPerCm2: 0.021,
      status: 'METROLOGY',
      carrierId: 'FOUP-3318',
      startedAt: '2026-08-10 11:00 KST',
      estimatedCompletion: '2026-09-15 09:00 KST'
    }
  ]);

  // 5. Enterprise Products & BOM
  readonly products = signal<EnterpriseProduct[]>([
    {
      id: 'PRD-GALAXY-S26U',
      modelCode: 'SM-S948B/DS',
      name: 'Samsung Galaxy S26 Ultra Enterprise Edition',
      nameKo: '갤럭시 S26 Ultra 엔터프라이즈 에디션',
      division: 'MOBILE',
      phase: 'MANUFACTURING',
      targetLaunchDate: '2027-01-20',
      currentBomRev: 'REV_2.4_PROD',
      unitCostUSD: 385.40,
      targetPriceUSD: 1299.00,
      grossMarginPercent: 70.33,
      engineeringChangesCount: 14,
      activeFirmwareVersion: 'S948BXXU1AZA4',
      certifications: ['IP68', 'MIL-STD-810H', 'Knox CC EAL6+', 'Common Criteria'],
      bomComponents: [
        { partNumber: 'SEC-AP-2600', name: 'Exynos 2600 3nm GAA AP + Mach NPU', nameKo: '3nm GAA 모바일 AP + 차세대 NPU', category: 'CHIPSET', supplier: 'Samsung Foundry / System LSI', supplierCountry: 'KR', quantity: 1, unitCostUSD: 110.00, lifecycleStatus: 'MASS_PRODUCTION', leadTimeDays: 45, riskRating: 'LOW' },
        { partNumber: 'SDC-M14-OLED', name: '6.8" QHD+ Dynamic AMOLED 2X (M14 Material)', nameKo: '6.8인치 QHD+ Dynamic AMOLED 2X (M14 유기재료)', category: 'DISPLAY_PANEL', supplier: 'Samsung Display (SDC)', supplierCountry: 'KR', quantity: 1, unitCostUSD: 68.50, lifecycleStatus: 'MASS_PRODUCTION', leadTimeDays: 30, riskRating: 'LOW' },
        { partNumber: 'SEC-ISOCELL-HP5', name: '200MP ISOCELL HP5 1/1.28" Sensor', nameKo: '2억 화소 초고해상도 이미지센서 HP5', category: 'OPTICS', supplier: 'Samsung System LSI', supplierCountry: 'KR', quantity: 1, unitCostUSD: 34.20, lifecycleStatus: 'MASS_PRODUCTION', leadTimeDays: 35, riskRating: 'LOW' },
        { partNumber: 'SDI-BAT-5500', name: '5,500mAh Solid-Electrolyte Safe Battery', nameKo: '5,500mAh 고밀도 안전 배터리팩', category: 'BATTERY', supplier: 'Samsung SDI', supplierCountry: 'KR', quantity: 1, unitCostUSD: 18.20, lifecycleStatus: 'MASS_PRODUCTION', leadTimeDays: 20, riskRating: 'LOW' },
        { partNumber: 'TI-CHAS-TITAN', name: 'Grade 5 Aerospace Titanium Armor Frame', nameKo: '5등급 항공우주 티타늄 아머 프레임', category: 'CHASSIS', supplier: 'Global Precision Material', supplierCountry: 'VN', quantity: 1, unitCostUSD: 24.50, lifecycleStatus: 'MASS_PRODUCTION', leadTimeDays: 25, riskRating: 'MEDIUM' },
        { partNumber: 'SEC-KNOX-SEC-ENCLAVE', name: 'Knox Vault Discrete Hardware Security Core', nameKo: '녹스 볼트 전용 하드웨어 보안 프로세서', category: 'CHIPSET', supplier: 'Samsung System LSI', supplierCountry: 'KR', quantity: 1, unitCostUSD: 6.80, lifecycleStatus: 'MASS_PRODUCTION', leadTimeDays: 30, riskRating: 'LOW' }
      ]
    },
    {
      id: 'PRD-ODYSSEY-G9-PRO',
      modelCode: 'LS49DG950SNXKR',
      name: 'Odyssey OLED G9 49" Dual QHD 240Hz Pro',
      nameKo: '오디세이 OLED G9 49형 듀얼 QHD 240Hz 프로',
      division: 'DISPLAY',
      phase: 'MANUFACTURING',
      targetLaunchDate: '2026-11-15',
      currentBomRev: 'REV_3.1_PROD',
      unitCostUSD: 520.00,
      targetPriceUSD: 1799.00,
      grossMarginPercent: 71.09,
      engineeringChangesCount: 8,
      activeFirmwareVersion: 'G950SXXU2BKL1',
      certifications: ['VESA DisplayHDR True Black 400', 'TUV Low Blue Light'],
      bomComponents: [
        { partNumber: 'SDC-QD-OLED-49', name: '49" 32:9 Curved QD-OLED Substrate', nameKo: '49인치 32:9 커브드 QD-OLED 패널 모듈', category: 'DISPLAY_PANEL', supplier: 'Samsung Display (SDC)', supplierCountry: 'KR', quantity: 1, unitCostUSD: 310.00, lifecycleStatus: 'MASS_PRODUCTION', leadTimeDays: 40, riskRating: 'LOW' },
        { partNumber: 'VD-CHIP-NEO-AI', name: 'Neo Quantum AI Processor Gen 3', nameKo: '네오 퀀텀 AI 프로세서 Gen 3', category: 'CHIPSET', supplier: 'Samsung VD / Foundry', supplierCountry: 'KR', quantity: 1, unitCostUSD: 45.00, lifecycleStatus: 'MASS_PRODUCTION', leadTimeDays: 35, riskRating: 'LOW' }
      ]
    },
    {
      id: 'PRD-GALAXY-TAB-ACT5',
      modelCode: 'SM-X306B',
      name: 'Galaxy Tab Active5 Pro Rugged Enterprise',
      nameKo: '갤럭시 탭 액티브5 프로 러기드 엔터프라이즈',
      division: 'MOBILE',
      phase: 'MANUFACTURING',
      targetLaunchDate: '2026-10-01',
      currentBomRev: 'REV_1.8_PROD',
      unitCostUSD: 240.00,
      targetPriceUSD: 699.00,
      grossMarginPercent: 65.66,
      engineeringChangesCount: 6,
      activeFirmwareVersion: 'X306BXXU1AWL4',
      certifications: ['MIL-STD-810H Drop 1.8m', 'IP68', 'ATEX Zone 2 Explosive-Proof'],
      bomComponents: [
        { partNumber: 'SEC-EXY-1380', name: 'Exynos 1380 Rugged Optimized SoC', nameKo: '엑시노스 1380 러기드 최적화 SoC', category: 'CHIPSET', supplier: 'Samsung System LSI', supplierCountry: 'KR', quantity: 1, unitCostUSD: 52.00, lifecycleStatus: 'MASS_PRODUCTION', leadTimeDays: 30, riskRating: 'LOW' }
      ]
    }
  ]);

  // 6. Unit Economics Cost Breakdown Engine
  readonly costBreakdowns = signal<CostBreakdown[]>([
    {
      productCode: 'SM-S948B (Galaxy S26 Ultra)',
      productName: 'Galaxy S26 Ultra Enterprise Edition',
      materialCostUSD: 262.20,
      laborCostUSD: 28.50,
      energyCostUSD: 14.80,
      equipmentDepreciationUSD: 32.40,
      manufacturingOverheadUSD: 21.00,
      logisticsAllocationUSD: 12.50,
      warrantyAllocationUSD: 14.00,
      rndAmortizationUSD: 0.00,
      totalUnitCostUSD: 385.40
    }
  ]);

  // 7. Supply Chain & Logistics Shipments
  readonly shipments = signal<LogisticsShipment[]>([
    {
      id: 'SHP-PACIFIC-8041',
      trackingNumber: 'HMM-ULCV-99214',
      type: 'VESSEL',
      origin: 'Busan New Port (KR)',
      destination: 'Port of Rotterdam (NL)',
      currentLocation: 'Indian Ocean (Lat 12.4N, Lng 68.2E)',
      cargoDescription: '12,000 Units Galaxy S26 Ultra & Neo QLED TVs',
      cargoValueUSD: 14200000,
      temperatureCelsius: 19.5,
      status: 'IN_TRANSIT',
      departureDate: '2026-09-02',
      eta: '2026-09-24',
      carrier: 'HMM Global Albatross',
      co2EmissionsKg: 42100
    },
    {
      id: 'SHP-AIR-9022',
      trackingNumber: 'KAL-CARGO-7741',
      type: 'AIR',
      origin: 'Incheon International (ICN)',
      destination: 'Dallas/Fort Worth (DFW)',
      currentLocation: 'Pacific Crossing FL340',
      cargoDescription: 'High-Purity Silicon Wafers & High-k Precursors',
      cargoValueUSD: 38500000,
      temperatureCelsius: 4.2,
      status: 'IN_TRANSIT',
      departureDate: '2026-09-12 04:00 KST',
      eta: '2026-09-12 18:30 CDT',
      carrier: 'Korean Air Cargo B777F',
      co2EmissionsKg: 18400
    },
    {
      id: 'SHP-PORT-6610',
      trackingNumber: 'ONE-CONT-5510',
      type: 'VESSEL',
      origin: 'Shanghai Port (CN)',
      destination: 'Long Beach, California (US)',
      currentLocation: 'Long Beach Anchorage Berth 4',
      cargoDescription: 'Precision Chassis Sub-assemblies',
      cargoValueUSD: 8400000,
      status: 'CUSTOMS_HOLD',
      departureDate: '2026-08-25',
      eta: '2026-09-11 (Delayed 24h)',
      carrier: 'Ocean Network Express',
      co2EmissionsKg: 28900
    }
  ]);

  // 8. Korean Approval Engine (전자결재)
  readonly approvals = signal<EnterpriseApprovalDoc[]>([
    {
      id: 'APPR-2026-09-001',
      docNumber: 'DS-FAB-2026-0941',
      title: 'CapEx Investment: Pyeongtaek Fab 4 Next-Gen High-NA EUV Line Expansion',
      titleKo: '[투자/CapEx] 평택 P4 차세대 High-NA EUV 라인 2단계 설비 증설 품의',
      drafter: {
        id: 'ENG-4029',
        name: 'Jinwoo Lee',
        nameKo: '이진우 수석연구원',
        departmentKo: 'DS부문 파운드리 제조기술팀',
        departmentEn: 'DS Foundry Manufacturing Tech Team',
        positionKo: '수석연구원 (Senior Principal Engineer)'
      },
      classification: 'HIGHLY_RESTRICTED',
      urgency: 'TOP_SECRET_EXPEDITE',
      category: 'CAPEX_INVESTMENT',
      amountKRW: 2400000000000, // 2.4 Trillion KRW
      summaryKo: '2nm GAA 선단 공정 캐파 선점을 위해 평택 4공장 내 High-NA EUV 노광 장비 4대 추가 반입 및 클린룸 인프라 공사 집행 승인을 요청합니다.',
      summaryEn: 'Request approval for CapEx investment of KRW 2.4 Trillion to acquire 4 units of High-NA EUV scanners for Pyeongtaek P4 Fab.',
      status: 'IN_PROGRESS',
      createdAt: '2026-09-11 15:30 KST',
      auditId: 'AUDIT-SEC-APPR-99410',
      steps: [
        { stepNumber: 1, approverId: 'MGR-1021', approverName: '박준혁 팀장', approverTitleKo: '팀장 (Director)', approverTitleEn: 'Director', departmentKo: '파운드리 공정개발팀', action: 'APPROVED', timestamp: '2026-09-11 16:45 KST', commentKo: '공정 타당성 검토 완료. 즉시 상신합니다.' },
        { stepNumber: 2, approverId: 'VP-3042', approverName: '최성훈 상무', approverTitleKo: '그룹장 (VP)', approverTitleEn: 'Vice President', departmentKo: '제조센터 총괄', action: 'APPROVED', timestamp: '2026-09-11 18:20 KST', commentKo: '생산 능력 확충 필수 건으로 승인함.' },
        { stepNumber: 3, approverId: 'EVP-8801', approverName: '한동수 사장', approverTitleKo: '사업부장 (President & BU Head)', approverTitleEn: 'President & BU Head', departmentKo: '파운드리사업부', action: 'APPROVED', timestamp: '2026-09-12 09:10 KST', commentKo: '고객사 수주 물량 대응 차원에서 승인.' },
        { stepNumber: 4, approverId: 'CFO-0002', approverName: '김명진 부사장 (CFO)', approverTitleKo: '최고재무책임자 (CFO)', approverTitleEn: 'Chief Financial Officer', departmentKo: '경영지원실 재무팀', action: 'PENDING' },
        { stepNumber: 5, approverId: 'CEO-0001', approverName: '전영현 부회장 (CEO)', approverTitleKo: '대표이사 부회장 (CEO)', approverTitleEn: 'Vice Chairman & CEO', departmentKo: '대표이사실', action: 'PENDING' }
      ]
    },
    {
      id: 'APPR-2026-09-002',
      docNumber: 'DX-PLM-2026-0182',
      title: 'Engineering Change Order: Galaxy S26 Ultra Thermal Architecture Revision',
      titleKo: '[설계변경] 갤럭시 S26 Ultra 베이퍼 챔버 방열 면적 25% 확대 건',
      drafter: {
        id: 'ENG-5512',
        name: 'Minji Kang',
        nameKo: '강민지 책임연구원',
        departmentKo: 'MX 기구개발팀',
        departmentEn: 'MX Hardware Mechanical Team',
        positionKo: '책임연구원 (Staff Engineer)'
      },
      classification: 'CONFIDENTIAL',
      urgency: 'URGENT',
      category: 'ENGINEERING_RELEASE',
      amountKRW: 450000000,
      summaryKo: 'NPU 고부하 온디바이스 AI 지속 연산 시 안정적인 클럭 유지를 위해 초박형 3D 베이퍼 챔버 면적을 25% 확대하는 설계 변경 건입니다.',
      summaryEn: 'Revision of vapor chamber heat dissipation area (+25%) for sustained On-Device AI NPU performance.',
      status: 'APPROVED',
      createdAt: '2026-09-10 11:00 KST',
      completedAt: '2026-09-11 14:00 KST',
      auditId: 'AUDIT-SEC-APPR-99388',
      steps: [
        { stepNumber: 1, approverId: 'MGR-7714', approverName: '송재익 팀장', approverTitleKo: '기구팀장', approverTitleEn: 'Hardware Lead', departmentKo: 'MX사업부', action: 'APPROVED', timestamp: '2026-09-10 13:00 KST', commentKo: '신뢰성 낙하/발열 테스트 통과 확인.' },
        { stepNumber: 2, approverId: 'VP-9912', approverName: '노태문 사장 (전결)', approverTitleKo: '사업부장 (전결)', approverTitleEn: 'Division Head (Delegated)', departmentKo: 'MX사업부', action: 'DELEGATED', timestamp: '2026-09-11 14:00 KST', commentKo: '양산 일정 차질 없이 즉시 도면 배포할 것 (전결 승인).' }
      ]
    }
  ]);

  // 9. Knox Enterprise Device Fleet
  readonly devices = signal<EnterpriseDevice[]>([
    {
      id: 'DEV-GAL-S26-904',
      serialNumber: 'R3CW809A12K',
      model: 'Galaxy S26 Ultra Enterprise',
      type: 'SMARTPHONE',
      assignedUser: '이진우 수석 (DS Foundry)',
      department: 'DS Foundry Engineering',
      osVersion: 'Android 17 / One UI 9.0 Enterprise',
      knoxAttestationStatus: 'PASSED',
      complianceState: 'COMPLIANT',
      batteryPercent: 88,
      lastSyncTime: '방금 전 (1분 이내)',
      activePolicies: ['Knox DualDAR Level 3', 'Biometric Passkey', 'Camera Factory Watermark', 'Zero Trust VPN'],
      location: 'Pyeongtaek Campus Cleanroom Bay 2'
    },
    {
      id: 'DEV-TAB-ACT-118',
      serialNumber: 'R52X401B98Q',
      model: 'Galaxy Tab Active5 Rugged',
      type: 'RUGGED_TERMINAL',
      assignedUser: '정재훈 기장 (Smart Factory MES)',
      department: 'Gumi Mobile Assembly Plant',
      osVersion: 'Android 16 Rugged Enterprise',
      knoxAttestationStatus: 'PASSED',
      complianceState: 'COMPLIANT',
      batteryPercent: 94,
      lastSyncTime: '3분 전',
      activePolicies: ['Barcode Lot Scan Agent', 'MES Mobile Gateway', 'Hardware PTT Active'],
      location: 'Gumi Factory #2 Assembly Line'
    },
    {
      id: 'DEV-DEX-WRK-002',
      serialNumber: 'DEX-DESK-7711',
      model: 'Samsung DeX Enterprise Station',
      type: 'DESKTOP_DEX',
      assignedUser: '김명진 부사장 (CFO)',
      department: 'Corporate Finance & Strategy',
      osVersion: 'One UI DeX 9 Enterprise Desktop',
      knoxAttestationStatus: 'PASSED',
      complianceState: 'COMPLIANT',
      batteryPercent: 100,
      lastSyncTime: '실시간 연결 중',
      activePolicies: ['FIPS 140-3 Hardware Token', 'Screen Watermarking', 'Restricted Copy/Paste'],
      location: 'Seocho Corporate HQ 34F'
    }
  ]);

  // 10. Security Operations Centre (SOC) Incidents
  readonly securityIncidents = signal<SecurityIncident[]>([
    {
      id: 'INC-2026-SOC-8812',
      severity: 'LOW',
      category: 'ZERO_TRUST_ANOMALY',
      sourceIp: '192.168.45.112 (Taylor Fab Guest VLAN)',
      targetAsset: 'PLM Engineering Repository',
      descriptionKo: '비인가 서브넷에서 기밀 반도체 마스크 설계도 접근 요청 감지. Knox 제로 트러스트 엔진이 자동 차단함.',
      descriptionEn: 'Unauthorized subnet attempted access to confidential mask design CAD repository. Blocked by Zero Trust gateway.',
      timestamp: '2026-09-12 09:12:04 KST',
      status: 'AUTO_MITIGATED',
      mitigationAction: 'Device isolated and security ticket assigned to Texas SOC response team.'
    },
    {
      id: 'INC-2026-SOC-8813',
      severity: 'LOW',
      category: 'CERTIFICATE_EXPIRY',
      sourceIp: '10.200.12.8 (Fab P3 MES Internal Cluster)',
      targetAsset: 'mTLS Tool Sensor Gateway',
      descriptionKo: 'EUV 노광기 #01 텔레메트리 mTLS 인증서 자동 갱신 완료 (유효기간 90일 연장).',
      descriptionEn: 'Automated 90-day mTLS certificate renewal completed for EUV Tool #01 telemetry broker.',
      timestamp: '2026-09-12 06:00:00 KST',
      status: 'RESOLVED',
      mitigationAction: 'Automated cryptographic key rotation logged into immutable ledger.'
    }
  ]);

  // 11. What-If Simulation State for MES & Digital Twin
  readonly isSimulationActive = signal<boolean>(false);
  readonly simulatedEquipmentDownId = signal<string | null>(null);

  toggleSimulateEquipmentDown(toolId: string) {
    if (this.simulatedEquipmentDownId() === toolId) {
      // Reset
      this.simulatedEquipmentDownId.set(null);
      this.isSimulationActive.set(false);
      this.fabTools.update(tools => tools.map(t => {
        if (t.id === toolId) {
          return { ...t, state: 'RUNNING' as EquipmentState, utilizationRate: 98.2 };
        }
        return t;
      }));
      this.eventBus.publish({
        eventType: 'EquipmentStateChanged',
        domain: 'MANUFACTURING',
        actorId: 'DIGITAL-TWIN-SIMULATOR',
        actorName: 'Digital Twin What-If Engine',
        details: `Restored Tool ${toolId} to normal RUNNING state.`,
        detailsKo: `디지털 트윈: 설비 ${toolId}를 정상 가동 상태(RUNNING)로 복원하였습니다.`,
        severity: 'INFO'
      });
    } else {
      // Trigger simulation
      this.simulatedEquipmentDownId.set(toolId);
      this.isSimulationActive.set(true);
      this.fabTools.update(tools => tools.map(t => {
        if (t.id === toolId) {
          return { ...t, state: 'DOWN' as EquipmentState, utilizationRate: 0 };
        }
        return t;
      }));
      this.eventBus.publish({
        eventType: 'EquipmentStateChanged',
        domain: 'MANUFACTURING',
        actorId: 'DIGITAL-TWIN-SIMULATOR',
        actorName: 'Digital Twin What-If Engine',
        details: `What-If Scenario: Simulated emergency stoppage on Tool ${toolId}. Capacity throughput impacted by -18.4%.`,
        detailsKo: `What-If 시뮬레이션: ${toolId} 설비 비상 정지 가상 시나리오 가동 (공장 전체 시간당 처리량 -18.4% 영향 산출).`,
        severity: 'WARNING'
      });
    }
  }

  // Method to approve pending Korean Approval
  approveDocument(docId: string, approverName: string) {
    this.approvals.update(docs => docs.map(doc => {
      if (doc.id === docId) {
        const updatedSteps = doc.steps.map(step => {
          if (step.action === 'PENDING') {
            return {
              ...step,
              action: 'APPROVED' as const,
              timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' KST',
              commentKo: `${approverName}: 결재 승인 완료.`
            };
          }
          return step;
        });
        const allApproved = updatedSteps.every(s => s.action === 'APPROVED' || s.action === 'DELEGATED');
        return {
          ...doc,
          steps: updatedSteps,
          status: allApproved ? 'APPROVED' as const : 'IN_PROGRESS' as const,
          completedAt: allApproved ? new Date().toISOString().replace('T', ' ').substring(0, 19) + ' KST' : undefined
        };
      }
      return doc;
    }));

    this.eventBus.publish({
      eventType: 'ApprovalDecisionMade',
      domain: 'WORKFLOW',
      actorId: 'EXECUTIVE-USER',
      actorName: approverName,
      details: `Approved electronic approval document #${docId}.`,
      detailsKo: `전자결재 문서 #${docId} 승인 처리 완료.`,
      severity: 'INFO'
    });
  }

  rejectDocument(docId: string, reasonKo: string) {
    this.approvals.update(docs => docs.map(doc => {
      if (doc.id === docId) {
        const updatedSteps = doc.steps.map(step => {
          if (step.action === 'PENDING') {
            return {
              ...step,
              action: 'REJECTED' as const,
              timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' KST',
              commentKo: `반려: ${reasonKo}`
            };
          }
          return step;
        });
        return {
          ...doc,
          steps: updatedSteps,
          status: 'REJECTED' as const,
          completedAt: new Date().toISOString().replace('T', ' ').substring(0, 19) + ' KST'
        };
      }
      return doc;
    }));

    this.eventBus.publish({
      eventType: 'ApprovalDecisionMade',
      domain: 'WORKFLOW',
      actorId: 'EXECUTIVE-USER',
      actorName: '최고경영진 결재자',
      details: `Rejected electronic approval document #${docId}. Reason: ${reasonKo}`,
      detailsKo: `전자결재 문서 #${docId} 반려 처리됨. 사유: ${reasonKo}`,
      severity: 'WARNING'
    });
  }
}
