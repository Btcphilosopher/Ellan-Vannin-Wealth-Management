// ==========================================
// SAMSUNG ENTERPRISE OS CANONICAL DATA MODEL
// ==========================================

export type BusinessUnitType = 
  | 'DS_SEMICONDUCTOR'   // Device Solutions (Memory, System LSI, Foundry)
  | 'DX_DEVICE'          // Device eXperience (Mobile MX, Visual Display, Digital Appliances)
  | 'SDC_DISPLAY'        // Samsung Display (OLED, QD-OLED, MicroLED)
  | 'HARMAN'             // Connected Car & Audio
  | 'GLOBAL_LOGISTICS'   // SDS / Global SCM
  | 'CORPORATE_HQ';      // Corporate Management & R&D

export type EquipmentState = 
  | 'RUNNING' 
  | 'IDLE' 
  | 'SETUP' 
  | 'MAINTENANCE' 
  | 'DOWN' 
  | 'QUALIFICATION' 
  | 'OFFLINE';

export type ProductLifecyclePhase = 
  | 'IDEA' 
  | 'REQUIREMENTS' 
  | 'DESIGN' 
  | 'ENGINEERING' 
  | 'PROTOTYPE' 
  | 'VALIDATION' 
  | 'CERTIFICATION' 
  | 'MANUFACTURING' 
  | 'DISTRIBUTION' 
  | 'SALE' 
  | 'SERVICE' 
  | 'END_OF_LIFE';

export type DocumentClassification = 
  | 'PUBLIC' 
  | 'INTERNAL' 
  | 'CONFIDENTIAL' 
  | 'RESTRICTED' 
  | 'HIGHLY_RESTRICTED';

export type ApprovalStatus = 
  | 'DRAFT' 
  | 'IN_PROGRESS' 
  | 'APPROVED' 
  | 'REJECTED' 
  | 'DELEGATED' 
  | 'CONSULTING';

export type DeviceLifecycle = 
  | 'PROCURED' 
  | 'ENROLLED' 
  | 'CONFIGURED' 
  | 'ACTIVE' 
  | 'COMPLIANT' 
  | 'NON_COMPLIANT' 
  | 'RETIRED';

// 1. Organization & Hierarchy
export interface LegalEntity {
  id: string;
  name: string;
  nameKo: string;
  code: string;
  country: string;
  region: 'APAC' | 'AMERICAS' | 'EMEA';
  currency: string;
  businessUnits: string[];
}

export interface SiteFacility {
  id: string;
  name: string;
  nameKo: string;
  code: string;
  type: 'FAB' | 'SMART_FACTORY' | 'RND_CAMPUS' | 'DISTRIBUTION_CENTER' | 'DATA_CENTER';
  location: string;
  country: string;
  coordinates: { lat: number; lng: number };
  activeLines: number;
  totalPersonnel: number;
  energyConsumptionMW: number;
  cleanroomClass?: string;
  oeePercent: number;
}

// 2. Semiconductor Fab Entities
export interface ToolChamber {
  id: string;
  name: string;
  processType: 'LITHO_EUV' | 'ETCH_PLASMA' | 'ALD_DEPO' | 'CMP_POLISH' | 'ION_IMPLANT' | 'METROLOGY';
  status: EquipmentState;
  temperatureC: number;
  pressureTorr: number;
  gasFlowSccm: number;
  rfPowerWatts: number;
  wafersProcessedToday: number;
  alarmsCount: number;
}

export interface FabTool {
  id: string;
  name: string;
  bayId: string;
  bayName: string;
  model: string;
  vendor: string;
  state: EquipmentState;
  utilizationRate: number; // 0-100
  oee: {
    availability: number;
    performance: number;
    quality: number;
    total: number;
  };
  currentRecipe: string;
  currentLotId?: string;
  chambers: ToolChamber[];
  mtbfHours: number;
  mttrHours: number;
  maintenanceDueHours: number;
  powerKw: number;
}

export interface WaferLot {
  id: string;
  lotNumber: string;
  productCode: string;
  productName: string;
  processNode: '2nm GAA' | '3nm GAA' | '10nm DRAM' | 'V-NAND 9th Gen';
  fabId: string;
  fabName: string;
  waferCount: number;
  currentStep: string;
  stepIndex: number;
  totalSteps: number;
  yieldPercent: number;
  cycleTimeDays: number;
  targetCycleTimeDays: number;
  defectDensityPerCm2: number;
  status: 'PROCESSING' | 'METROLOGY' | 'HOLD' | 'QUEUED' | 'COMPLETED';
  carrierId: string;
  startedAt: string;
  estimatedCompletion: string;
}

export interface WaferDieMap {
  waferId: string;
  lotId: string;
  dieCount: number;
  passingDie: number;
  defectMap: { x: number; y: number; defectType: 'PARTICLE' | 'BRIDGING' | 'SCRATCH' | 'VOID' }[];
  yieldPercent: number;
}

// 3. Product & BOM Engine
export interface BomComponent {
  partNumber: string;
  name: string;
  nameKo: string;
  category: 'CHIPSET' | 'DISPLAY_PANEL' | 'SENSOR' | 'BATTERY' | 'CHASSIS' | 'OPTICS' | 'SOFTWARE_FIRMWARE';
  supplier: string;
  supplierCountry: string;
  quantity: number;
  unitCostUSD: number;
  lifecycleStatus: 'MASS_PRODUCTION' | 'SAMPLE' | 'QUALIFIED' | 'OBSOLETE';
  leadTimeDays: number;
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH';
  children?: BomComponent[];
}

export interface EnterpriseProduct {
  id: string;
  modelCode: string;
  name: string;
  nameKo: string;
  division: 'MOBILE' | 'DISPLAY' | 'SEMICONDUCTOR' | 'APPLIANCE' | 'NETWORK';
  phase: ProductLifecyclePhase;
  targetLaunchDate: string;
  currentBomRev: string;
  unitCostUSD: number;
  targetPriceUSD: number;
  grossMarginPercent: number;
  bomComponents: BomComponent[];
  engineeringChangesCount: number;
  activeFirmwareVersion: string;
  certifications: string[];
}

// 4. MES & Digital Twin
export interface FactoryDigitalTwin {
  factoryId: string;
  factoryName: string;
  floors: {
    floorNumber: number;
    name: string;
    bays: {
      id: string;
      name: string;
      lines: {
        id: string;
        name: string;
        currentProduct: string;
        throughputPerHour: number;
        targetThroughput: number;
        activeWorkers: number;
        lineOEE: number;
        status: EquipmentState;
        tools: FabTool[];
      }[];
    }[];
  }[];
  environmental: {
    ambientTempC: number;
    cleanroomHumidityPct: number;
    particulate01umCount: number;
    powerGridLoadMW: number;
    recycledWaterPct: number;
  };
}

// 5. Supply Chain & Logistics
export interface LogisticsShipment {
  id: string;
  trackingNumber: string;
  type: 'VESSEL' | 'AIR' | 'TRUCK' | 'RAIL';
  origin: string;
  destination: string;
  currentLocation: string;
  cargoDescription: string;
  cargoValueUSD: number;
  temperatureCelsius?: number;
  status: 'IN_TRANSIT' | 'CUSTOMS_HOLD' | 'PORT_DISCHARGE' | 'DELIVERED' | 'DELAY_RISK';
  departureDate: string;
  eta: string;
  carrier: string;
  co2EmissionsKg: number;
}

export interface SupplierPartner {
  id: string;
  name: string;
  country: string;
  tier: 'TIER_1' | 'TIER_2' | 'CRITICAL_RAW_MATERIAL';
  category: string;
  qualityScore: number; // 0-100
  deliveryReliability: number; // 0-100
  geopoliticalRisk: 'LOW' | 'MEDIUM' | 'HIGH';
  totalSpendYTD_USD: number;
  activeContracts: number;
  openPOs: number;
}

// 6. Finance & Cost Allocation
export interface FinancialMetric {
  groupRevenueKRW_Trillion: number;
  operatingProfitKRW_Trillion: number;
  operatingMarginPercent: number;
  freeCashFlowKRW_Trillion: number;
  capExKRW_Trillion: number;
  rndInvestmentKRW_Trillion: number;
  divisionBreakdown: {
    division: string;
    divisionKo: string;
    revenueKRW_T: number;
    operatingProfitKRW_T: number;
    marginPct: number;
    capExSharePct: number;
  }[];
}

export interface CostBreakdown {
  productCode: string;
  productName: string;
  materialCostUSD: number;
  laborCostUSD: number;
  energyCostUSD: number;
  equipmentDepreciationUSD: number;
  manufacturingOverheadUSD: number;
  logisticsAllocationUSD: number;
  warrantyAllocationUSD: number;
  rndAmortizationUSD: number;
  totalUnitCostUSD: number;
}

export interface CapitalProject {
  id: string;
  title: string;
  titleKo: string;
  division: string;
  requestedCapExUSD_Million: number;
  expectedROICPercent: number;
  npvUSD_Million: number;
  paybackPeriodYears: number;
  strategicPriority: 'CRITICAL_NEXT_GEN' | 'EXPANSION' | 'EFFICIENCY' | 'MAINTENANCE';
  riskScore: 'LOW' | 'MEDIUM' | 'HIGH';
  status: 'APPROVED' | 'IN_REVIEW' | 'BOARD_PENDING' | 'REJECTED';
}

// 7. Korean Approval Engine (전자결재)
export interface ApprovalStep {
  stepNumber: number;
  approverId: string;
  approverName: string;
  approverTitleKo: string;
  approverTitleEn: string;
  departmentKo: string;
  action: 'PENDING' | 'APPROVED' | 'REJECTED' | 'CONSULTED' | 'DELEGATED';
  timestamp?: string;
  commentKo?: string;
  commentEn?: string;
}

export interface EnterpriseApprovalDoc {
  id: string;
  docNumber: string;
  title: string;
  titleKo: string;
  drafter: {
    id: string;
    name: string;
    nameKo: string;
    departmentKo: string;
    departmentEn: string;
    positionKo: string;
  };
  classification: DocumentClassification;
  urgency: 'NORMAL' | 'URGENT' | 'TOP_SECRET_EXPEDITE';
  category: 'CAPEX_INVESTMENT' | 'PRODUCTION_RECIPE_CHANGE' | 'SUPPLIER_CONTRACT' | 'HR_APPOINTMENT' | 'ENGINEERING_RELEASE';
  amountKRW?: number;
  summaryKo: string;
  summaryEn: string;
  status: ApprovalStatus;
  createdAt: string;
  completedAt?: string;
  steps: ApprovalStep[];
  auditId: string;
}

// 8. Device Management (Knox Enterprise Mobility)
export interface EnterpriseDevice {
  id: string;
  serialNumber: string;
  model: string;
  type: 'SMARTPHONE' | 'TABLET' | 'RUGGED_TERMINAL' | 'DESKTOP_DEX';
  assignedUser: string;
  department: string;
  osVersion: string;
  knoxAttestationStatus: 'PASSED' | 'WARNING' | 'COMPROMISED';
  complianceState: 'COMPLIANT' | 'NON_COMPLIANT' | 'ISOLATED';
  batteryPercent: number;
  lastSyncTime: string;
  activePolicies: string[];
  location: string;
}

// 9. SOC & Security
export interface SecurityIncident {
  id: string;
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  category: 'ZERO_TRUST_ANOMALY' | 'DATA_LOSS_PREVENTION' | 'CERTIFICATE_EXPIRY' | 'MALWARE_BLOCKED' | 'ACCESS_VIOLATION';
  sourceIp: string;
  targetAsset: string;
  descriptionKo: string;
  descriptionEn: string;
  timestamp: string;
  status: 'INVESTIGATING' | 'CONTAINED' | 'RESOLVED' | 'AUTO_MITIGATED';
  mitigationAction: string;
}

// 10. AI Copilot Response & Safety Gate
export interface CopilotQueryResponse {
  query: string;
  answerKo: string;
  answerEn: string;
  source: string;
  calculationMethod?: string;
  timestamp: string;
  confidenceScore: number; // e.g. 0.98
  dataFreshnessSeconds: number;
  requiresHumanApproval: boolean;
  proposedAction?: {
    actionType: 'CHANGE_RECIPE' | 'APPROVE_PAYMENT' | 'TRIGGER_MAINTENANCE' | 'HALT_LINE' | 'DISPATCH_CARGO';
    targetEntity: string;
    impactDescriptionKo: string;
    impactDescriptionEn: string;
    isApproved?: boolean;
  };
}

// 11. Immutable Audit Event
export interface EnterpriseEvent {
  id: string;
  eventType: 
    | 'LotStarted' 
    | 'WaferProcessed' 
    | 'EquipmentStateChanged' 
    | 'YieldAlert' 
    | 'DefectDetected' 
    | 'PurchaseOrderApproved' 
    | 'ShipmentDispatched' 
    | 'ApprovalSubmitted' 
    | 'ApprovalDecisionMade' 
    | 'SecurityAlertTriggered' 
    | 'DeviceEnrolled' 
    | 'RecipeModified';
  domain: 'SEMICONDUCTOR' | 'MANUFACTURING' | 'SUPPLY_CHAIN' | 'FINANCE' | 'SECURITY' | 'WORKFLOW';
  actorId: string;
  actorName: string;
  timestamp: string;
  details: string;
  detailsKo: string;
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  immutableHash: string;
}
