export type Locale = 'ko-KR' | 'en-US' | 'en-GB';

export type TerminologyClass = 
  | 'ORGANIZATION'
  | 'SEMICONDUCTOR'
  | 'MANUFACTURING'
  | 'SUPPLY_CHAIN'
  | 'FINANCE'
  | 'QUALITY'
  | 'SECURITY'
  | 'WORKFLOW'
  | 'AI_DATA';

export interface TranslationEntry {
  key: string;
  locale: Locale;
  text: string;
  context?: string;
  version: string;
  reviewStatus: 'APPROVED' | 'IN_REVIEW' | 'DRAFT';
  terminologyClass: TerminologyClass;
}

export interface TerminologyItem {
  id: string;
  korean: string;
  english: string;
  hanja?: string;
  category: TerminologyClass;
  definitionKo: string;
  definitionEn: string;
}
