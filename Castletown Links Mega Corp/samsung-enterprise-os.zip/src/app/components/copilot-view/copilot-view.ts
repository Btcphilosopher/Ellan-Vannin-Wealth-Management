import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { CopilotService } from '../../core/services/copilot.service';
import { LocalizationService } from '../../core/services/localization.service';


@Component({
  selector: 'app-copilot-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="enterprise-copilot-view" class="space-y-6">
      <!-- Title Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/70 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-indigo-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '삼성 엔터프라이즈 코파일럿 (Samsung Enterprise Copilot)' : 'Samsung Enterprise Copilot AI Assistant' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '생산 팹, 원가, 공급망, 결재 및 감사 데이터 기반 실시간 엔터프라이즈 AI 질의응답 & 안전 실행 승인' 
              : 'Enterprise-grounded AI copilot: Data provenance, mathematical formulation, confidence scoring, and human safety gates.' }}
          </p>
        </div>

        <div class="flex items-center space-x-2">
          <span class="text-xs px-3 py-1 rounded-lg bg-indigo-950/60 text-indigo-400 border border-indigo-800/40 font-mono">
            Model: Gemini 3.8 Flash (Enterprise Grounded)
          </span>
        </div>
      </div>

      <!-- Quick Suggested Query Chips (User Requirements) -->
      <div class="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 space-y-3">
        <div class="text-xs font-bold text-slate-300 flex items-center">
          <mat-icon class="text-indigo-400 mr-1.5 text-sm">tips_and_updates</mat-icon>
          {{ loc.isKorean() ? '추천 전사 경영 및 제조 질의 (Preset Enterprise Queries)' : 'Recommended Executive & Manufacturing Queries' }}
        </div>

        <div class="flex flex-wrap gap-2">
          @for (queryText of (loc.isKorean() ? copilot.suggestedQueriesKo : copilot.suggestedQueriesEn); track queryText) {
            <button 
              (click)="askQuestion(queryText)"
              [disabled]="copilot.isLoading()"
              class="px-3 py-2 rounded-xl bg-slate-950 hover:bg-slate-800 border border-slate-800 hover:border-indigo-500/50 text-slate-200 text-xs text-left transition-all cursor-pointer flex items-center space-x-2 disabled:opacity-50">
              <mat-icon class="text-indigo-400 text-xs">chat_bubble_outline</mat-icon>
              <span>{{ queryText }}</span>
            </button>
          }
        </div>
      </div>

      <!-- Interactive Input Bar -->
      <div class="flex gap-2">
        <input 
          #queryInput
          type="text"
          [placeholder]="loc.isKorean() ? '예: 이번 분기 CAPEX 집행 현황과 테일러 팹 진행 상황을 분석해줘...' : 'Ask about semiconductor yield, OEE, supply chain shipments, or unit cost...' "
          (keydown.enter)="askQuestion(queryInput.value); queryInput.value = ''"
          class="flex-1 bg-slate-900 border border-slate-800 focus:border-indigo-500 rounded-xl px-4 py-3 text-sm text-white focus:outline-none placeholder-slate-500 font-sans">
        <button 
          (click)="askQuestion(queryInput.value); queryInput.value = ''"
          [disabled]="copilot.isLoading()"
          class="px-6 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-sm shadow-lg shadow-indigo-950/60 transition-all cursor-pointer flex items-center disabled:opacity-50">
          @if (copilot.isLoading()) {
            <mat-icon class="animate-spin text-sm mr-1">sync</mat-icon>
            <span>{{ loc.isKorean() ? '분석 중...' : 'Analyzing...' }}</span>
          } @else {
            <mat-icon class="text-sm mr-1">send</mat-icon>
            <span>{{ loc.isKorean() ? '질의 실행' : 'Ask Copilot' }}</span>
          }
        </button>
      </div>

      <!-- AI Response Cards Stream -->
      <div class="space-y-4">
        @for (item of copilot.queryHistory(); track item.timestamp) {
          <div class="bg-slate-900/90 p-5 rounded-2xl border border-slate-800 space-y-4 shadow-xl">
            <!-- User Query Prompt -->
            <div class="flex items-center space-x-2 text-xs font-bold text-indigo-300 pb-2 border-b border-slate-800">
              <mat-icon class="text-sm text-indigo-400">help_outline</mat-icon>
              <span>{{ item.query }}</span>
            </div>

            <!-- Answer Content -->
            <div class="text-sm text-slate-100 leading-relaxed bg-slate-950/60 p-4 rounded-xl border border-slate-800/80">
              {{ loc.isKorean() ? item.answerKo : item.answerEn }}
            </div>

            <!-- Structured Metadata Provenance (Audit / Source / Calc / Confidence / Freshness) -->
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2 text-[11px] font-mono">
              <!-- Provenance Source -->
              <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800/70">
                <span class="text-slate-500 block text-[10px]">Data Provenance (데이터 출처):</span>
                <span class="text-slate-300 font-semibold truncate block">{{ item.source }}</span>
              </div>

              <!-- Calculation Method -->
              <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800/70">
                <span class="text-slate-500 block text-[10px]">Formula Calculation (산출 공식):</span>
                <span class="text-cyan-300 font-semibold truncate block">{{ item.calculationMethod }}</span>
              </div>

              <!-- Confidence -->
              <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800/70">
                <span class="text-slate-500 block text-[10px]">AI Confidence (신뢰도):</span>
                <span class="text-emerald-400 font-bold block">{{ (item.confidenceScore * 100).toFixed(1) }}% (Enterprise High)</span>
              </div>

              <!-- Freshness -->
              <div class="bg-slate-950 p-2.5 rounded-lg border border-slate-800/70">
                <span class="text-slate-500 block text-[10px]">Freshness & Timestamp:</span>
                <span class="text-slate-400 block">{{ item.dataFreshnessSeconds }}s ago ({{ item.timestamp.substring(11, 19) }})</span>
              </div>
            </div>

            <!-- AI Action Safety Gate (Requiring Human Executive Approval) -->
            @if (item.proposedAction) {
              <div class="p-4 bg-amber-950/30 border border-amber-500/40 rounded-xl space-y-3">
                <div class="flex items-center justify-between">
                  <div class="flex items-center space-x-2 text-xs font-bold text-amber-300">
                    <mat-icon class="text-amber-400 text-sm">gavel</mat-icon>
                    <span>{{ loc.isKorean() ? 'AI 고위험 권고 조치 (Human Safety Approval Gate)' : 'AI Action Safety Gate (Requires Human Approval)' }}</span>
                  </div>
                  <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 font-bold">
                    {{ item.proposedAction.actionType }}
                  </span>
                </div>

                <div class="text-xs text-slate-300">
                  {{ loc.isKorean() ? item.proposedAction.impactDescriptionKo : item.proposedAction.impactDescriptionEn }}
                </div>

                <div class="flex items-center justify-between pt-2 border-t border-amber-500/20">
                  <span class="text-[11px] text-slate-400 font-mono">Target: {{ item.proposedAction.targetEntity }}</span>
                  
                  @if (item.proposedAction.isApproved) {
                    <span class="text-xs font-bold text-emerald-400 font-mono flex items-center">
                      <mat-icon class="text-xs mr-1">check_circle</mat-icon>
                      {{ loc.isKorean() ? '임원 전결 승인 완료' : 'Executive Approved' }}
                    </span>
                  } @else {
                    <button 
                      (click)="copilot.approveCopilotAction(item)"
                      class="px-4 py-1.5 rounded-lg bg-amber-600 hover:bg-amber-500 text-white font-bold text-xs shadow transition-all cursor-pointer flex items-center">
                      <mat-icon class="text-xs mr-1">how_to_reg</mat-icon>
                      {{ loc.isKorean() ? '조치 정식 승인 및 집행' : 'Authorize & Execute' }}
                    </button>
                  }
                </div>
              </div>
            }
          </div>
        }
      </div>
    </div>
  `
})
export class CopilotViewComponent {
  copilot = inject(CopilotService);
  loc = inject(LocalizationService);

  askQuestion(query: string) {
    if (!query || !query.trim()) return;
    this.copilot.askCopilot(query.trim());
  }
}
