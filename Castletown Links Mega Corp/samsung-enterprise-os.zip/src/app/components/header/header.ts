import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { LocalizationService } from '../../core/services/localization.service';


@Component({
  selector: 'app-header',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <header id="enterprise-header" class="bg-slate-900/90 border-b border-slate-800 backdrop-blur-md sticky top-0 z-50 text-slate-100">
      <!-- Top Synthetic Notice Strip -->
      <div id="synthetic-data-banner" class="bg-blue-950/80 border-b border-blue-800/40 px-4 py-1 flex items-center justify-between text-xs">
        <div class="flex items-center space-x-2">
          <span class="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold bg-blue-500/20 text-blue-400 border border-blue-500/30">
            {{ loc.t('app.synthetic_badge') }}
          </span>
          <span class="text-slate-400 hidden sm:inline text-[11px]">
            {{ loc.t('app.synthetic_notice') }}
          </span>
        </div>
        <div class="flex items-center space-x-4 text-[11px] font-mono text-slate-400">
          <span>SEOUL (KST): {{ kstTime() }}</span>
          <span class="hidden md:inline">AUSTIN (CDT): {{ cdtTime() }}</span>
          <span class="inline-flex items-center text-emerald-400">
            <span class="w-2 h-2 rounded-full bg-emerald-500 mr-1.5 animate-pulse"></span>
            ZERO TRUST: SECURE
          </span>
        </div>
      </div>

      <!-- Main Navigation Header -->
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3 flex items-center justify-between">
        <!-- Logo & Title -->
        <div class="flex items-center space-x-3">
          <div class="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 via-indigo-700 to-slate-900 border border-blue-400/40 flex items-center justify-center shadow-lg shadow-blue-950/50">
            <span class="font-extrabold text-lg tracking-wider text-white">S</span>
          </div>
          <div>
            <div class="flex items-center space-x-2">
              <h1 class="font-bold text-lg text-white tracking-tight">{{ loc.t('app.title') }}</h1>
              <span class="text-xs px-2 py-0.5 rounded-full bg-slate-800 text-blue-400 border border-slate-700 font-mono">v3.7 Enterprise</span>
            </div>
            <p class="text-xs text-slate-400">{{ loc.t('app.tagline') }}</p>
          </div>
        </div>

        <!-- Right Action Items (Language, User Profile, System Indicator) -->
        <div class="flex items-center space-x-3">
          <!-- Language Selector -->
          <div class="flex items-center bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              id="lang-btn-ko"
              (click)="loc.setLocale('ko-KR')"
              [class.bg-blue-600]="loc.currentLocale() === 'ko-KR'"
              [class.text-white]="loc.currentLocale() === 'ko-KR'"
              [class.text-slate-400]="loc.currentLocale() !== 'ko-KR'"
              class="px-2.5 py-1 text-xs rounded font-medium transition-all cursor-pointer">
              한국어
            </button>
            <button
              id="lang-btn-en"
              (click)="loc.setLocale('en-US')"
              [class.bg-blue-600]="loc.currentLocale() === 'en-US'"
              [class.text-white]="loc.currentLocale() === 'en-US'"
              [class.text-slate-400]="loc.currentLocale() !== 'en-US'"
              class="px-2.5 py-1 text-xs rounded font-medium transition-all cursor-pointer">
              English (US)
            </button>
            <button
              id="lang-btn-en-gb"
              (click)="loc.setLocale('en-GB')"
              [class.bg-blue-600]="loc.currentLocale() === 'en-GB'"
              [class.text-white]="loc.currentLocale() === 'en-GB'"
              [class.text-slate-400]="loc.currentLocale() !== 'en-GB'"
              class="hidden sm:inline-block px-2.5 py-1 text-xs rounded font-medium transition-all cursor-pointer">
              UK
            </button>
          </div>

          <!-- User Role Pill -->
          <div class="hidden lg:flex items-center space-x-2 bg-slate-800/80 px-3 py-1.5 rounded-lg border border-slate-700/60">
            <div class="w-7 h-7 rounded-full bg-blue-600/30 text-blue-300 border border-blue-500/40 flex items-center justify-center font-bold text-xs">
              CEO
            </div>
            <div class="text-left">
              <div class="text-xs font-semibold text-slate-200">
                {{ loc.isKorean() ? '전영현 부회장 (대표이사)' : 'Vice Chairman & CEO' }}
              </div>
              <div class="text-[10px] text-slate-400 font-mono">ID: SEC-EXEC-0001</div>
            </div>
          </div>
        </div>
      </div>
    </header>
  `
})
export class HeaderComponent {
  loc = inject(LocalizationService);

  readonly kstTime = signal<string>('');
  readonly cdtTime = signal<string>('');

  constructor() {
    this.updateClocks();
    setInterval(() => this.updateClocks(), 1000);
  }

  private updateClocks() {
    const now = new Date();
    this.kstTime.set(now.toLocaleTimeString('ko-KR', { timeZone: 'Asia/Seoul', hour12: false }));
    this.cdtTime.set(now.toLocaleTimeString('en-US', { timeZone: 'America/Chicago', hour12: false }));
  }
}
