import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EnterpriseDataService } from '../../core/services/enterprise-data.service';
import { LocalizationService } from '../../core/services/localization.service';


@Component({
  selector: 'app-mes-digital-twin-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="mes-digital-twin" class="space-y-6">
      <!-- Title & Simulation Control Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/70 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '스마트팩토리 MES & 디지털 트윈 (Digital Twin Engine)' : 'Smart Factory MES & Digital Twin Simulator' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '실시간 설비 종합효율(OEE = 가동률 × 성능효율 × 양품률), AGV 무인 물류 및 가상 장애 시뮬레이션' 
              : 'Real-time Overall Equipment Effectiveness (OEE = A × P × Q), automated AGV dispatch & What-If failure simulation.' }}
          </p>
        </div>

        <div class="flex items-center space-x-3">
          <button 
            id="btn-what-if-sim"
            (click)="data.toggleSimulateEquipmentDown('TOOL-EUV-01')"
            [class.bg-rose-600]="data.isSimulationActive()"
            [class.hover:bg-rose-500]="data.isSimulationActive()"
            [class.bg-blue-600]="!data.isSimulationActive()"
            [class.hover:bg-blue-500]="!data.isSimulationActive()"
            class="px-4 py-2 rounded-xl text-xs font-bold text-white flex items-center shadow-lg transition-all cursor-pointer">
            <mat-icon class="mr-1.5 text-sm">{{ data.isSimulationActive() ? 'restart_alt' : 'bolt' }}</mat-icon>
            {{ data.isSimulationActive() 
              ? (loc.isKorean() ? 'What-If 시뮬레이션 해제 (정상 복원)' : 'Reset What-If Simulation') 
              : (loc.isKorean() ? 'What-If: EUV 설비 장애 시뮬레이션' : 'Simulate EUV Tool Breakdown') }}
          </button>
        </div>
      </div>

      <!-- Live Simulation Impact Alert Banner (If active) -->
      @if (data.isSimulationActive()) {
        <div class="p-4 bg-rose-950/80 border border-rose-600/50 rounded-xl text-rose-200 text-xs flex items-center justify-between animate-pulse">
          <div class="flex items-center space-x-3">
            <mat-icon class="text-rose-400 text-lg">warning</mat-icon>
            <div>
              <span class="font-bold font-mono">[SIMULATION ACTIVE] EUV High-NA Scanner #01 Emergency Stoppage</span>
              <p class="text-rose-300 text-[11px] mt-0.5">
                {{ loc.isKorean() 
                  ? '설비 다운타임 반영: 평택 P3 3nm GAA 라인 일일 생산량 -18.4% 감소 예상, 대체 라인 P4 Bay-04 버퍼 가동 권고.' 
                  : 'Downtime Impact: -18.4% daily throughput reduction on P3 3nm GAA line. Recommended rerouting buffer lots to P4 Bay-04.' }}
              </p>
            </div>
          </div>
          <span class="text-xs font-mono font-bold bg-rose-900 px-2.5 py-1 rounded">
            CAPACITY: -18.4%
          </span>
        </div>
      }

      <!-- OEE Exact Formula Math Grid -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
        <!-- Availability -->
        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800">
          <div class="text-slate-400 text-xs mb-1">{{ loc.isKorean() ? '1. 시간 가동률 (Availability)' : '1. Availability (A)' }}</div>
          <div class="text-2xl font-extrabold text-blue-400 font-mono">
            {{ data.isSimulationActive() ? '82.4%' : '98.5%' }}
          </div>
          <div class="text-[11px] text-slate-400 mt-1 font-mono">Operating Time / Planned Time</div>
        </div>

        <!-- Performance -->
        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800">
          <div class="text-slate-400 text-xs mb-1">{{ loc.isKorean() ? '2. 성능 효율 (Performance)' : '2. Performance (P)' }}</div>
          <div class="text-2xl font-extrabold text-cyan-400 font-mono">
            {{ data.isSimulationActive() ? '91.0%' : '97.4%' }}
          </div>
          <div class="text-[11px] text-slate-400 mt-1 font-mono">Total Output / Target Output</div>
        </div>

        <!-- Quality -->
        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800">
          <div class="text-slate-400 text-xs mb-1">{{ loc.isKorean() ? '3. 양품률 (Quality)' : '3. Quality (Q)' }}</div>
          <div class="text-2xl font-extrabold text-emerald-400 font-mono">99.1%</div>
          <div class="text-[11px] text-slate-400 mt-1 font-mono">Good Units / Total Units</div>
        </div>

        <!-- Overall OEE -->
        <div class="bg-slate-900/90 p-4 rounded-xl border border-slate-800">
          <div class="text-slate-400 text-xs mb-1">{{ loc.isKorean() ? '종합 설비 효율 (OEE = A×P×Q)' : 'Total OEE = A × P × Q' }}</div>
          <div 
            [class.text-rose-400]="data.isSimulationActive()"
            [class.text-emerald-400]="!data.isSimulationActive()"
            class="text-2xl font-extrabold font-mono">
            {{ data.isSimulationActive() ? '74.3%' : '95.1%' }}
          </div>
          <div class="text-[11px] text-slate-400 mt-1">
            {{ data.isSimulationActive() ? '⚠️ World Class Target (85%) 미달' : '✓ World Class Level (>85%) 달성' }}
          </div>
        </div>
      </div>

      <!-- Factory Floor Digital Twin Layout -->
      <div class="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 space-y-4">
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-bold text-white flex items-center">
            <mat-icon class="text-emerald-400 mr-2 text-base">view_in_ar</mat-icon>
            {{ loc.isKorean() ? '스마트팩토리 3D 디지털 트윈 플로어 맵 (Gumi & Pyeongtaek)' : 'Smart Factory 3D Digital Twin Floor Map' }}
          </h3>
          <span class="text-xs text-slate-400 font-mono">Live SCADA Sync (100ms)</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          <!-- Bay 1 Litho -->
          <div class="p-4 bg-slate-950/80 rounded-xl border border-slate-800 space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-white">Bay 01: EUV Lithography</span>
              <span 
                [class.bg-rose-500/20]="data.isSimulationActive()"
                [class.text-rose-400]="data.isSimulationActive()"
                [class.bg-emerald-500/20]="!data.isSimulationActive()"
                [class.text-emerald-400]="!data.isSimulationActive()"
                class="text-[10px] font-mono px-2 py-0.5 rounded border">
                {{ data.isSimulationActive() ? 'DOWN (SIM)' : 'ACTIVE 98.2%' }}
              </span>
            </div>
            <div class="text-xs text-slate-400">
              ASML NXE:3800E High-NA Scanner #01 & #02
            </div>
            <div class="h-1 bg-slate-800 rounded-full overflow-hidden">
              <div 
                [class.bg-rose-500]="data.isSimulationActive()"
                [class.w-0]="data.isSimulationActive()"
                [class.bg-blue-500]="!data.isSimulationActive()"
                [class.w-full]="!data.isSimulationActive()"
                class="h-full transition-all">
              </div>
            </div>
          </div>

          <!-- Bay 2 Dry Etch -->
          <div class="p-4 bg-slate-950/80 rounded-xl border border-slate-800 space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-white">Bay 02: Atomic Etch (ALE)</span>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                ACTIVE 94.5%
              </span>
            </div>
            <div class="text-xs text-slate-400">
              TEL Apex Dual-Chamber Plasma Reactors
            </div>
            <div class="h-1 bg-slate-800 rounded-full overflow-hidden">
              <div class="h-full bg-emerald-500 rounded-full w-[94%]"></div>
            </div>
          </div>

          <!-- Bay 3 Cleanroom AGV Fleet -->
          <div class="p-4 bg-slate-950/80 rounded-xl border border-slate-800 space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-white">OHT / AGV Cleanroom Logistics</span>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                18 AGVs ACTIVE
              </span>
            </div>
            <div class="text-xs text-slate-400">
              Overhead Hoist Transport (OHT) FOUP Delivery (99.99% On-Time)
            </div>
            <div class="h-1 bg-slate-800 rounded-full overflow-hidden">
              <div class="h-full bg-cyan-500 rounded-full w-[98%]"></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class MesDigitalTwinViewComponent {
  data = inject(EnterpriseDataService);
  loc = inject(LocalizationService);
}
