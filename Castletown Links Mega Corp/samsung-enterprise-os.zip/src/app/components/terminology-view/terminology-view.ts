import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { LocalizationService } from '../../core/services/localization.service';


@Component({
  selector: 'app-terminology-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="enterprise-terminology-dict" class="space-y-6">
      <!-- Title Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/70 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-blue-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '한국형 기업 표준 용어 사전 (Enterprise Terminology Dictionary)' : 'Korean Enterprise Canonical Terminology Dictionary' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '기안, 결재, 전결, 품의, 수율, OEE 등 한국 글로벌 제조·기술 대기업 표준 업무 용어 및 영문 매핑 체계' 
              : 'Standardized Korean-English enterprise terminology across corporate management, semiconductor, and manufacturing.' }}
          </p>
        </div>

        <div class="flex items-center space-x-2">
          <span class="text-xs px-3 py-1 rounded-lg bg-blue-950/60 text-blue-400 border border-blue-800/40 font-mono">
            TOTAL TERMS: {{ loc.terminologyDictionary.length }}
          </span>
        </div>
      </div>

      <!-- Search & Category Filters -->
      <div class="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 space-y-4">
        <div class="flex flex-col sm:flex-row gap-3">
          <input 
            type="text"
            [placeholder]="loc.isKorean() ? '용어 검색 (예: 기안, 결재, 전결, 수율, OEE, FOUP...)' : 'Search terms (e.g., Gian, Gyeoljae, Yield, OEE, Fab, CapEx)...'"
            (input)="onSearchInput($event)"
            class="flex-1 bg-slate-950 border border-slate-800 focus:border-blue-500 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none placeholder-slate-500">
          
          <div class="flex flex-wrap items-center gap-1.5">
            <button 
              (click)="selectedCategory.set('ALL')"
              [class.bg-blue-600]="selectedCategory() === 'ALL'"
              [class.text-white]="selectedCategory() === 'ALL'"
              [class.bg-slate-950]="selectedCategory() !== 'ALL'"
              [class.text-slate-400]="selectedCategory() !== 'ALL'"
              class="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              ALL
            </button>
            <button 
              (click)="selectedCategory.set('ORGANIZATION')"
              [class.bg-blue-600]="selectedCategory() === 'ORGANIZATION'"
              [class.text-white]="selectedCategory() === 'ORGANIZATION'"
              [class.bg-slate-950]="selectedCategory() !== 'ORGANIZATION'"
              [class.text-slate-400]="selectedCategory() !== 'ORGANIZATION'"
              class="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              조직/경영
            </button>
            <button 
              (click)="selectedCategory.set('SEMICONDUCTOR')"
              [class.bg-blue-600]="selectedCategory() === 'SEMICONDUCTOR'"
              [class.text-white]="selectedCategory() === 'SEMICONDUCTOR'"
              [class.bg-slate-950]="selectedCategory() !== 'SEMICONDUCTOR'"
              [class.text-slate-400]="selectedCategory() !== 'SEMICONDUCTOR'"
              class="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              반도체
            </button>
            <button 
              (click)="selectedCategory.set('MANUFACTURING')"
              [class.bg-blue-600]="selectedCategory() === 'MANUFACTURING'"
              [class.text-white]="selectedCategory() === 'MANUFACTURING'"
              [class.bg-slate-950]="selectedCategory() !== 'MANUFACTURING'"
              [class.text-slate-400]="selectedCategory() !== 'MANUFACTURING'"
              class="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              제조/품질
            </button>
            <button 
              (click)="selectedCategory.set('WORKFLOW')"
              [class.bg-blue-600]="selectedCategory() === 'WORKFLOW'"
              [class.text-white]="selectedCategory() === 'WORKFLOW'"
              [class.bg-slate-950]="selectedCategory() !== 'WORKFLOW'"
              [class.text-slate-400]="selectedCategory() !== 'WORKFLOW'"
              class="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              전자결재
            </button>
            <button 
              (click)="selectedCategory.set('FINANCE')"
              [class.bg-blue-600]="selectedCategory() === 'FINANCE'"
              [class.text-white]="selectedCategory() === 'FINANCE'"
              [class.bg-slate-950]="selectedCategory() !== 'FINANCE'"
              [class.text-slate-400]="selectedCategory() !== 'FINANCE'"
              class="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              재무/회계
            </button>
          </div>
        </div>

        <!-- Terms Grid -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (term of filteredTerms(); track term.id) {
            <div class="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2 hover:border-slate-700 transition-all">
              <div class="flex items-center justify-between">
                <div>
                  <span class="text-sm font-bold text-white">{{ term.korean }}</span>
                  @if (term.hanja) {
                    <span class="text-xs text-slate-500 ml-1 font-serif">({{ term.hanja }})</span>
                  }
                </div>
                <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {{ term.category }}
                </span>
              </div>

              <div class="text-xs font-semibold text-blue-400">
                {{ term.english }}
              </div>

              <div class="text-xs text-slate-300 leading-relaxed pt-1 border-t border-slate-800/60">
                {{ loc.isKorean() ? term.definitionKo : term.definitionEn }}
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class TerminologyViewComponent {
  loc = inject(LocalizationService);

  readonly searchQuery = signal<string>('');
  readonly selectedCategory = signal<string>('ALL');

  onSearchInput(e: Event) {
    const val = (e.target as HTMLInputElement).value;
    this.searchQuery.set(val);
  }

  readonly filteredTerms = computed(() => {
    const q = this.searchQuery().toLowerCase().trim();
    const cat = this.selectedCategory();
    return this.loc.terminologyDictionary.filter(t => {
      const matchCat = cat === 'ALL' || t.category === cat;
      const matchText = !q || 
        t.korean.toLowerCase().includes(q) || 
        t.english.toLowerCase().includes(q) || 
        (t.hanja && t.hanja.includes(q)) ||
        t.definitionKo.toLowerCase().includes(q) ||
        t.definitionEn.toLowerCase().includes(q);
      return matchCat && matchText;
    });
  });
}
