import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EnterpriseDataService } from '../../core/services/enterprise-data.service';
import { LocalizationService } from '../../core/services/localization.service';
import { EnterpriseProduct } from '../../core/models/enterprise.types';

@Component({
  selector: 'app-device-display-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="device-display-engineering" class="space-y-6">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/70 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-purple-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '디바이스 & 디스플레이 제품 개발 (Device & Display BOM Engine)' : 'Device & Display Engineering & BOM Engine' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '갤럭시 플래그십 및 QD-OLED 디스플레이 다단계 BOM(E-BOM/M-BOM), 제조 원가 구조, 기구/신뢰성 설계' 
              : 'Multi-level Bill of Materials (BOM), unit cost architecture, display substrate testing, and PLM lifecycle.' }}
          </p>
        </div>

        <!-- Product Selector Pills -->
        <div class="flex flex-wrap items-center gap-2">
          @for (prod of data.products(); track prod.id) {
            <button 
              (click)="selectedProduct.set(prod)"
              [class.bg-blue-600]="selectedProduct().id === prod.id"
              [class.text-white]="selectedProduct().id === prod.id"
              [class.bg-slate-800]="selectedProduct().id !== prod.id"
              [class.text-slate-300]="selectedProduct().id !== prod.id"
              class="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              {{ loc.isKorean() ? prod.nameKo : prod.name }}
            </button>
          }
        </div>
      </div>

      <!-- Selected Product Profile & Unit Cost Architecture -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Product Specs & PLM Card (5 Cols) -->
        <div class="lg:col-span-5 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div class="flex items-center justify-between">
            <div>
              <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                {{ selectedProduct().modelCode }}
              </span>
              <h3 class="text-base font-bold text-white mt-1">
                {{ loc.isKorean() ? selectedProduct().nameKo : selectedProduct().name }}
              </h3>
            </div>
            <div class="text-right">
              <span class="text-xs font-mono px-2 py-1 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                {{ selectedProduct().phase }}
              </span>
            </div>
          </div>

          <!-- Cost vs Retail Price Metric -->
          <div class="grid grid-cols-3 gap-2 bg-slate-950 p-3 rounded-xl border border-slate-800/80 text-center font-mono">
            <div>
              <div class="text-[10px] text-slate-400">Total Unit Cost</div>
              <div class="text-base font-bold text-slate-200">\${{ selectedProduct().unitCostUSD.toFixed(2) }}</div>
            </div>
            <div>
              <div class="text-[10px] text-slate-400">Target MSRP</div>
              <div class="text-base font-bold text-blue-400">\${{ selectedProduct().targetPriceUSD.toFixed(2) }}</div>
            </div>
            <div>
              <div class="text-[10px] text-slate-400">Gross Margin</div>
              <div class="text-base font-bold text-emerald-400">{{ selectedProduct().grossMarginPercent }}%</div>
            </div>
          </div>

          <!-- Enterprise Certifications -->
          <div class="space-y-1.5">
            <div class="text-xs font-semibold text-slate-300">{{ loc.isKorean() ? '보안 및 하드웨어 인증 규격' : 'Hardware & Security Specs' }}</div>
            <div class="flex flex-wrap gap-1.5">
              @for (cert of selectedProduct().certifications; track cert) {
                <span class="text-[11px] px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono border border-slate-700">
                  {{ cert }}
                </span>
              }
            </div>
          </div>

          <!-- Active Firmware & ECO Count -->
          <div class="p-3 bg-slate-950/60 rounded-xl border border-slate-800/60 flex items-center justify-between text-xs">
            <div>
              <span class="text-slate-400">Firmware Build:</span>
              <span class="font-mono text-slate-200 ml-1 font-bold">{{ selectedProduct().activeFirmwareVersion }}</span>
            </div>
            <div class="text-purple-400 font-mono">
              {{ selectedProduct().engineeringChangesCount }} ECOs Released
            </div>
          </div>
        </div>

        <!-- Multi-Level Bill of Materials (BOM) Table (7 Cols) -->
        <div class="lg:col-span-7 bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-sm font-bold text-white flex items-center">
              <mat-icon class="text-blue-400 mr-2 text-base">format_list_bulleted</mat-icon>
              {{ loc.isKorean() ? '다단계 부품 명세서 (Bill of Materials - E/M BOM)' : 'Multi-Level BOM Explorer' }}
            </h3>
            <span class="text-xs text-slate-400 font-mono">Rev: {{ selectedProduct().currentBomRev }}</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs text-slate-300">
              <thead class="bg-slate-950/70 text-slate-400 text-[11px] uppercase border-b border-slate-800 font-mono">
                <tr>
                  <th class="py-2.5 px-3">Part # & Name</th>
                  <th class="py-2.5 px-3">Category</th>
                  <th class="py-2.5 px-3">Supplier</th>
                  <th class="py-2.5 px-3 text-right">Cost (USD)</th>
                  <th class="py-2.5 px-3 text-right">Lead Time</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                @for (comp of selectedProduct().bomComponents; track comp.partNumber) {
                  <tr class="hover:bg-slate-800/40 transition-colors">
                    <td class="py-2.5 px-3">
                      <div class="font-mono font-bold text-blue-400 text-[11px]">{{ comp.partNumber }}</div>
                      <div class="text-slate-200">{{ loc.isKorean() ? comp.nameKo : comp.name }}</div>
                    </td>
                    <td class="py-2.5 px-3">
                      <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                        {{ comp.category }}
                      </span>
                    </td>
                    <td class="py-2.5 px-3">
                      <div class="text-slate-300">{{ comp.supplier }}</div>
                      <div class="text-[10px] text-slate-500 font-mono">Origin: {{ comp.supplierCountry }}</div>
                    </td>
                    <td class="py-2.5 px-3 text-right font-mono font-bold text-emerald-400">
                      \${{ comp.unitCostUSD.toFixed(2) }}
                    </td>
                    <td class="py-2.5 px-3 text-right font-mono text-slate-400">
                      {{ comp.leadTimeDays }}d
                    </td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DeviceDisplayViewComponent {
  data = inject(EnterpriseDataService);
  loc = inject(LocalizationService);

  readonly selectedProduct = signal<EnterpriseProduct>(this.data.products()[0]);
}
