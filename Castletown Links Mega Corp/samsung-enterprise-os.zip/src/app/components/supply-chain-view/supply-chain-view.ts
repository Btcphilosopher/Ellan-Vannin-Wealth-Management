import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EnterpriseDataService } from '../../core/services/enterprise-data.service';
import { LocalizationService } from '../../core/services/localization.service';

@Component({
  selector: 'app-supply-chain-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="supply-chain-control-tower" class="space-y-6">
      <!-- Title Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/70 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-cyan-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '공급망 컨트롤타워 & 글로벌 물류 (Global SCM Control Tower)' : 'Global Supply Chain & Logistics Control Tower' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '글로벌 항공/해상 화물 실시간 위치, 반도체 특수 화학물질 콜드체인(Cold-Chain), 항만 적체 지수' 
              : 'Real-time air & ocean freight tracking, wafer precursor cold-chain telemetry, port congestion indices.' }}
          </p>
        </div>

        <div class="flex items-center space-x-2 text-xs font-mono text-slate-300 bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
          <span class="text-slate-400">Total In-Transit Cargo Value:</span>
          <span class="text-emerald-400 font-bold">$61.1M USD</span>
        </div>
      </div>

      <!-- Live Shipments Grid -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        @for (shp of data.shipments(); track shp.id) {
          <div class="p-5 bg-slate-900/80 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all space-y-4">
            <div class="flex items-center justify-between">
              <div class="flex items-center space-x-2">
                <mat-icon class="text-cyan-400 text-base">
                  {{ shp.type === 'AIR' ? 'flight' : 'directions_boat' }}
                </mat-icon>
                <span class="text-xs font-bold text-white">{{ shp.carrier }}</span>
              </div>
              <span 
                [class.bg-emerald-500/20]="shp.status === 'IN_TRANSIT'"
                [class.text-emerald-400]="shp.status === 'IN_TRANSIT'"
                [class.border-emerald-500/30]="shp.status === 'IN_TRANSIT'"
                [class.bg-amber-500/20]="shp.status === 'CUSTOMS_HOLD'"
                [class.text-amber-400]="shp.status === 'CUSTOMS_HOLD'"
                [class.border-amber-500/30]="shp.status === 'CUSTOMS_HOLD'"
                class="text-[10px] font-mono font-bold px-2 py-0.5 rounded border">
                {{ shp.status }}
              </span>
            </div>

            <!-- Route Origin to Dest -->
            <div class="space-y-1">
              <div class="flex items-center justify-between text-xs text-slate-300 font-medium">
                <span>{{ shp.origin }}</span>
                <mat-icon class="text-slate-500 text-xs">arrow_forward</mat-icon>
                <span>{{ shp.destination }}</span>
              </div>
              <div class="text-[11px] text-cyan-400 font-mono">
                📍 {{ shp.currentLocation }}
              </div>
            </div>

            <!-- Cargo Description & Value -->
            <div class="p-3 bg-slate-950 rounded-xl border border-slate-800/80 text-xs space-y-1">
              <div class="text-slate-200 font-medium">{{ shp.cargoDescription }}</div>
              <div class="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1">
                <span>Value: <strong class="text-emerald-400">\${{ (shp.cargoValueUSD / 1000000).toFixed(1) }}M</strong></span>
                @if (shp.temperatureCelsius !== undefined) {
                  <span>Cold-Chain: <strong class="text-blue-300">{{ shp.temperatureCelsius }}°C</strong></span>
                }
              </div>
            </div>

            <!-- Departure & ETA -->
            <div class="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-2 border-t border-slate-800/60">
              <span>Dep: {{ shp.departureDate }}</span>
              <span class="text-slate-200">ETA: {{ shp.eta }}</span>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class SupplyChainViewComponent {
  data = inject(EnterpriseDataService);
  loc = inject(LocalizationService);
}
