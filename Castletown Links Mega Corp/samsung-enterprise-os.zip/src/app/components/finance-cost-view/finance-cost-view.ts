import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EnterpriseDataService } from '../../core/services/enterprise-data.service';
import { LocalizationService } from '../../core/services/localization.service';

@Component({
  selector: 'app-finance-cost-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="finance-cost-engine" class="space-y-6">
      <!-- Title Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/70 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '재무, 원가 관리 & 자본 배분 (Unit Economics & CapEx)' : 'Finance, Unit Economics & Capital Allocation' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '제품별 정밀 제조 원가(재료비+노무비+전력비+감가상각비), 대규모 CapEx 투자 회수 분석(ROIC/NPV)' 
              : 'Precision unit cost breakdown (Material, Labor, Energy, Depreciation) & CapEx allocation engine.' }}
          </p>
        </div>

        <div class="flex items-center space-x-2">
          <span class="text-xs px-3 py-1 rounded-lg bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 font-mono">
            FX: 1 USD = 1,385.50 KRW
          </span>
        </div>
      </div>

      <!-- Unit Cost Breakdown Card (Galaxy S26 Ultra Enterprise) -->
      @for (cost of data.costBreakdowns(); track cost.productCode) {
        <div class="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 space-y-4">
          <div class="flex items-center justify-between">
            <div>
              <span class="text-xs font-mono text-blue-400 font-bold">{{ cost.productCode }}</span>
              <h3 class="text-base font-bold text-white">{{ cost.productName }}</h3>
            </div>
            <div class="text-right">
              <span class="text-xs text-slate-400">Total Unit Manufacturing Cost</span>
              <div class="text-xl font-extrabold text-emerald-400 font-mono">\${{ cost.totalUnitCostUSD.toFixed(2) }}</div>
            </div>
          </div>

          <!-- Formula Components Breakdown Grid -->
          <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3 text-xs font-mono">
            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800/80">
              <div class="text-slate-400 text-[10px]">1. Material (재료비)</div>
              <div class="text-sm font-bold text-white mt-1">\${{ cost.materialCostUSD.toFixed(2) }}</div>
              <div class="text-[10px] text-slate-500">68.0%</div>
            </div>

            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800/80">
              <div class="text-slate-400 text-[10px]">2. Labor (직접노무비)</div>
              <div class="text-sm font-bold text-white mt-1">\${{ cost.laborCostUSD.toFixed(2) }}</div>
              <div class="text-[10px] text-slate-500">7.4%</div>
            </div>

            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800/80">
              <div class="text-slate-400 text-[10px]">3. Energy (전력/유틸리티)</div>
              <div class="text-sm font-bold text-white mt-1">\${{ cost.energyCostUSD.toFixed(2) }}</div>
              <div class="text-[10px] text-slate-500">3.8%</div>
            </div>

            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800/80">
              <div class="text-slate-400 text-[10px]">4. Deprec. (설비상각비)</div>
              <div class="text-sm font-bold text-amber-300 mt-1">\${{ cost.equipmentDepreciationUSD.toFixed(2) }}</div>
              <div class="text-[10px] text-slate-500">8.4%</div>
            </div>

            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800/80">
              <div class="text-slate-400 text-[10px]">5. Overhead (간접제조)</div>
              <div class="text-sm font-bold text-white mt-1">\${{ cost.manufacturingOverheadUSD.toFixed(2) }}</div>
              <div class="text-[10px] text-slate-500">5.5%</div>
            </div>

            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800/80">
              <div class="text-slate-400 text-[10px]">6. Logistics (물류배부)</div>
              <div class="text-sm font-bold text-white mt-1">\${{ cost.logisticsAllocationUSD.toFixed(2) }}</div>
              <div class="text-[10px] text-slate-500">3.2%</div>
            </div>

            <div class="bg-slate-950 p-3 rounded-xl border border-slate-800/80">
              <div class="text-slate-400 text-[10px]">7. Warranty (품질보증)</div>
              <div class="text-sm font-bold text-white mt-1">\${{ cost.warrantyAllocationUSD.toFixed(2) }}</div>
              <div class="text-[10px] text-slate-500">3.6%</div>
            </div>
          </div>
        </div>
      }
    </div>
  `
})
export class FinanceCostViewComponent {
  data = inject(EnterpriseDataService);
  loc = inject(LocalizationService);
}
