import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EnterpriseDataService } from '../../core/services/enterprise-data.service';
import { LocalizationService } from '../../core/services/localization.service';
import { EventBusService } from '../../core/services/event-bus.service';

@Component({
  selector: 'app-semiconductor-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="semiconductor-fab-os" class="space-y-6">
      <!-- Fab Header & Active Node Status -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/70 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-blue-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '반도체 팹 운영체계 (Semiconductor Fab OS)' : 'Semiconductor Fab OS & Metrology Engine' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '300mm 웨이퍼 로트 추적, EUV/식각/증착 챔버 텔레메트리, 결함 밀도 SPC 분석' 
              : '300mm wafer lot tracking, EUV/etch/deposition chamber sensors, defect density & SPC metrology.' }}
          </p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
          <button 
            (click)="selectedFabId.set('SITE-PTK')"
            [class.bg-blue-600]="selectedFabId() === 'SITE-PTK'"
            [class.text-white]="selectedFabId() === 'SITE-PTK'"
            [class.bg-slate-800]="selectedFabId() !== 'SITE-PTK'"
            [class.text-slate-300]="selectedFabId() !== 'SITE-PTK'"
            class="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer">
            {{ loc.isKorean() ? '평택 P3/P4 팹' : 'Pyeongtaek P3/P4' }}
          </button>
          <button 
            (click)="selectedFabId.set('SITE-HWS')"
            [class.bg-blue-600]="selectedFabId() === 'SITE-HWS'"
            [class.text-white]="selectedFabId() === 'SITE-HWS'"
            [class.bg-slate-800]="selectedFabId() !== 'SITE-HWS'"
            [class.text-slate-300]="selectedFabId() !== 'SITE-HWS'"
            class="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer">
            {{ loc.isKorean() ? '화성 EUV 17라인' : 'Hwaseong EUV Line' }}
          </button>
          <button 
            (click)="selectedFabId.set('SITE-TAY')"
            [class.bg-blue-600]="selectedFabId() === 'SITE-TAY'"
            [class.text-white]="selectedFabId() === 'SITE-TAY'"
            [class.bg-slate-800]="selectedFabId() !== 'SITE-TAY'"
            [class.text-slate-300]="selectedFabId() !== 'SITE-TAY'"
            class="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer">
            {{ loc.isKorean() ? '테일러 파운드리 Fab 1' : 'Taylor Foundry Fab 1' }}
          </button>
        </div>
      </div>

      <!-- Live Wafer Lots Table & Stepping -->
      <div class="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
        <div class="flex items-center justify-between mb-4">
          <h3 class="text-sm font-bold text-white flex items-center">
            <mat-icon class="text-blue-400 mr-2 text-base">layers</mat-icon>
            {{ loc.isKorean() ? '실시간 300mm 웨이퍼 로트 공정 현황' : 'Active 300mm Wafer Lots' }}
          </h3>
          <span class="text-xs text-slate-400 font-mono">FOUP Carrier Auto-Guided Dispatch</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          @for (lot of data.waferLots(); track lot.id) {
            <button 
              type="button"
              (click)="selectedLotId.set(lot.id)"
              [class.border-blue-500]="selectedLotId() === lot.id"
              [class.bg-blue-950/20]="selectedLotId() === lot.id"
              [class.bg-slate-950/70]="selectedLotId() !== lot.id"
              class="w-full text-left p-4 rounded-xl border border-slate-800 hover:border-slate-700 transition-all cursor-pointer space-y-3">
              <div class="flex items-center justify-between">
                <div>
                  <div class="text-xs font-bold text-white">{{ lot.lotNumber }}</div>
                  <div class="text-[11px] text-blue-400 font-mono">{{ lot.processNode }}</div>
                </div>
                <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  {{ lot.carrierId }}
                </span>
              </div>

              <div class="text-xs text-slate-300 line-clamp-1">
                {{ lot.productName }}
              </div>

              <!-- Progress Bar -->
              <div class="space-y-1">
                <div class="flex items-center justify-between text-[11px] text-slate-400 font-mono">
                  <span>{{ lot.currentStep }}</span>
                  <span>{{ Math.round((lot.stepIndex / lot.totalSteps) * 100) }}%</span>
                </div>
                <div class="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                  <div 
                    class="h-full bg-blue-500 rounded-full transition-all"
                    [style.width.%]="(lot.stepIndex / lot.totalSteps) * 100">
                  </div>
                </div>
              </div>

              <!-- Yield & Defect Density -->
              <div class="flex items-center justify-between text-xs pt-2 border-t border-slate-800/80">
                <div>
                  <span class="text-slate-400 text-[11px]">{{ loc.isKorean() ? '수율' : 'Yield' }}:</span>
                  <span class="font-bold text-emerald-400 ml-1 font-mono">{{ lot.yieldPercent }}%</span>
                </div>
                <div>
                  <span class="text-slate-400 text-[11px]">{{ loc.isKorean() ? '결함밀도' : 'Defect D.' }}:</span>
                  <span class="font-mono text-slate-200 ml-1">{{ lot.defectDensityPerCm2 }}/cm²</span>
                </div>
              </div>
            </button>
          }
        </div>
      </div>

      <!-- Two-Column: Equipment Chambers & Interactive Wafer Die Heatmap -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Equipment Chambers & Real-time Sensors (7 Cols) -->
        <div class="lg:col-span-7 space-y-4">
          <div class="bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
            <div class="flex items-center justify-between mb-4">
              <h3 class="text-sm font-bold text-white flex items-center">
                <mat-icon class="text-cyan-400 mr-2 text-base">settings_input_component</mat-icon>
                {{ loc.isKorean() ? '핵심 노광/식각/증착 설비 챔버 텔레메트리' : 'Litho / Etch / ALD Chamber Telemetry' }}
              </h3>
              <span class="text-xs text-slate-400 font-mono">SECS/GEM Protocol</span>
            </div>

            <div class="space-y-3">
              @for (tool of data.fabTools(); track tool.id) {
                <div class="p-4 bg-slate-950/80 rounded-xl border border-slate-800 space-y-3">
                  <div class="flex items-center justify-between">
                    <div>
                      <div class="flex items-center space-x-2">
                        <span class="text-xs font-bold text-white">{{ tool.name }}</span>
                        <span class="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400">{{ tool.model }}</span>
                      </div>
                      <div class="text-[11px] text-slate-400">{{ tool.bayName }} | {{ tool.vendor }}</div>
                    </div>
                    <div class="flex items-center space-x-2">
                      <span 
                        [class.bg-emerald-500/20]="tool.state === 'RUNNING'"
                        [class.text-emerald-400]="tool.state === 'RUNNING'"
                        [class.border-emerald-500/30]="tool.state === 'RUNNING'"
                        [class.bg-amber-500/20]="tool.state === 'SETUP'"
                        [class.text-amber-400]="tool.state === 'SETUP'"
                        [class.border-amber-500/30]="tool.state === 'SETUP'"
                        [class.bg-rose-500/20]="tool.state === 'DOWN'"
                        [class.text-rose-400]="tool.state === 'DOWN'"
                        [class.border-rose-500/30]="tool.state === 'DOWN'"
                        class="text-[11px] font-mono font-bold px-2.5 py-0.5 rounded border">
                        {{ tool.state }}
                      </span>
                    </div>
                  </div>

                  <!-- Chamber Sensor Grid -->
                  @for (ch of tool.chambers; track ch.id) {
                    <div class="bg-slate-900/90 p-3 rounded-lg border border-slate-800/80 flex flex-wrap items-center justify-between gap-3 text-xs">
                      <div class="font-medium text-slate-300">{{ ch.name }}</div>
                      <div class="flex items-center space-x-4 font-mono text-[11px]">
                        <div>
                          <span class="text-slate-500">Temp:</span>
                          <span class="text-amber-300 ml-1 font-semibold">{{ ch.temperatureC }}°C</span>
                        </div>
                        <div>
                          <span class="text-slate-500">Press:</span>
                          <span class="text-cyan-300 ml-1 font-semibold">{{ ch.pressureTorr }} Torr</span>
                        </div>
                        <div>
                          <span class="text-slate-500">Gas:</span>
                          <span class="text-emerald-300 ml-1 font-semibold">{{ ch.gasFlowSccm }} sccm</span>
                        </div>
                        <div>
                          <span class="text-slate-500">RF Power:</span>
                          <span class="text-purple-300 ml-1 font-semibold">{{ ch.rfPowerWatts }} W</span>
                        </div>
                      </div>
                    </div>
                  }
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Interactive 300mm Wafer Defect & Die Inspection Heatmap (5 Cols) -->
        <div class="lg:col-span-5 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-3">
              <h3 class="text-sm font-bold text-white flex items-center">
                <mat-icon class="text-purple-400 mr-2 text-base">radar</mat-icon>
                {{ loc.isKorean() ? '300mm 웨이퍼 결함 및 다이 검사 맵' : '300mm Wafer Die Inspection Map' }}
              </h3>
              <span class="text-xs px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 border border-purple-500/30 font-mono">
                Defect Density: 0.042/cm²
              </span>
            </div>
            <p class="text-xs text-slate-400 mb-4">
              {{ loc.isKorean() 
                ? '광학 전자현미경(SEM) 계측 기반 실시간 다이 합격(Pass)/불량(Defect) 패턴' 
                : 'Inline SEM metrology defect distribution across patterned 300mm substrate.' }}
            </p>

            <!-- Circular Wafer Graphic Representation -->
            <div class="relative w-64 h-64 mx-auto my-3 rounded-full bg-slate-950 border-2 border-blue-500/40 p-4 flex items-center justify-center shadow-inner shadow-blue-950/80 overflow-hidden">
              <!-- Notch at bottom -->
              <div class="absolute bottom-0 w-4 h-1.5 bg-slate-800 rounded-t-sm z-10"></div>

              <!-- Die Grid inside Wafer -->
              <div class="grid grid-cols-10 gap-1 w-full h-full p-2 place-content-center">
                @for (die of waferDies(); track die.id) {
                  <button 
                    type="button"
                    (click)="inspectDie(die)"
                    [class.bg-emerald-500]="die.status === 'PASS'"
                    [class.bg-rose-500]="die.status === 'DEFECT'"
                    [class.bg-amber-500]="die.status === 'EDGE_EXCLUSION'"
                    class="w-4 h-4 rounded-xs transition-transform hover:scale-125 focus:outline-none cursor-pointer"
                    [title]="'Die #' + die.id + ' (' + die.x + ',' + die.y + '): ' + die.status">
                  </button>
                }
              </div>
            </div>

            <!-- Legend & Selected Die Metrology -->
            <div class="flex items-center justify-center space-x-4 text-xs mt-3">
              <div class="flex items-center space-x-1.5">
                <span class="w-2.5 h-2.5 rounded-xs bg-emerald-500"></span>
                <span class="text-slate-300">Pass (94.8%)</span>
              </div>
              <div class="flex items-center space-x-1.5">
                <span class="w-2.5 h-2.5 rounded-xs bg-rose-500"></span>
                <span class="text-slate-300">Defect (3.2%)</span>
              </div>
              <div class="flex items-center space-x-1.5">
                <span class="w-2.5 h-2.5 rounded-xs bg-amber-500"></span>
                <span class="text-slate-300">Edge (2.0%)</span>
              </div>
            </div>
          </div>

          <!-- Metrology Inspection Details Card -->
          @if (inspectedDie(); as die) {
            <div class="mt-4 p-3 bg-slate-950 rounded-xl border border-slate-800 text-xs space-y-1">
              <div class="flex items-center justify-between">
                <span class="font-bold text-white">Die Coordinate [{{ die.x }}, {{ die.y }}]</span>
                <span 
                  [class.text-emerald-400]="die.status === 'PASS'"
                  [class.text-rose-400]="die.status === 'DEFECT'"
                  class="font-mono font-bold">
                  {{ die.status }}
                </span>
              </div>
              <div class="text-slate-400 text-[11px]">
                {{ die.status === 'PASS' 
                  ? 'Critical dimension: 18.2nm (Within ±0.3nm spec). No bridge defects detected.' 
                  : 'Particle defect detected at Contact Via layer. Size: 14nm.' }}
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class SemiconductorViewComponent {
  data = inject(EnterpriseDataService);
  loc = inject(LocalizationService);
  eventBus = inject(EventBusService);

  readonly Math = Math;
  readonly selectedFabId = signal<string>('SITE-PTK');
  readonly selectedLotId = signal<string>('LOT-3NM-8842');

  // Generate 80 dies for the 300mm wafer pattern
  readonly waferDies = computed(() => {
    const dies = [];
    for (let i = 0; i < 70; i++) {
      const x = (i % 10) - 5;
      const y = Math.floor(i / 10) - 3.5;
      const dist = Math.sqrt(x*x + y*y);
      let status: 'PASS' | 'DEFECT' | 'EDGE_EXCLUSION' = 'PASS';
      
      if (dist > 4.6) {
        status = 'EDGE_EXCLUSION';
      } else if (i === 14 || i === 33 || i === 52) {
        status = 'DEFECT';
      }
      dies.push({ id: i + 1, x, y, status });
    }
    return dies;
  });

  readonly inspectedDie = signal<{ id: number; x: number; y: number; status: string } | null>(null);

  inspectDie(die: { id: number; x: number; y: number; status: string }) {
    this.inspectedDie.set(die);
  }
}

