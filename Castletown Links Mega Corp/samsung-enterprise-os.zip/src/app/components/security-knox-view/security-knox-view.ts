import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EnterpriseDataService } from '../../core/services/enterprise-data.service';
import { LocalizationService } from '../../core/services/localization.service';
import { EventBusService } from '../../core/services/event-bus.service';


@Component({
  selector: 'app-security-knox-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="security-knox-fleet" class="space-y-6">
      <!-- Title Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/70 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '보안관제(SOC) & Knox 디바이스 관리 (Security & Knox Fleet)' : 'Global SOC & Knox Enterprise Fleet Management' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '녹스 볼트(Knox Vault) 하드웨어 기반 무결성 검증, 제로 트러스트 실시간 위협 차단, 기밀 도면 유출 방지' 
              : 'Knox Vault hardware-backed attestation, Zero-Trust threat mitigation, and enterprise fleet isolation.' }}
          </p>
        </div>

        <div class="flex items-center space-x-2">
          <span class="text-xs px-3 py-1 rounded-lg bg-emerald-950/60 text-emerald-400 border border-emerald-800/40 font-mono">
            KNOX EAL6+ VAULT ACTIVE
          </span>
        </div>
      </div>

      <!-- SOC Threat Incidents -->
      <div class="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 space-y-4">
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-bold text-white flex items-center">
            <mat-icon class="text-emerald-400 mr-2 text-base">shield</mat-icon>
            {{ loc.isKorean() ? '실시간 제로 트러스트 보안 인시던트 모니터링' : 'Real-time Zero-Trust Security Incidents' }}
          </h3>
          <span class="text-xs text-slate-400 font-mono">Auto-Mitigated via Sentinel SOC</span>
        </div>

        <div class="space-y-3">
          @for (inc of data.securityIncidents(); track inc.id) {
            <div class="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                  <span class="font-mono text-xs font-bold text-blue-400">{{ inc.id }}</span>
                  <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">{{ inc.category }}</span>
                </div>
                <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                  {{ inc.status }}
                </span>
              </div>
              <div class="text-xs text-slate-200">
                {{ loc.isKorean() ? inc.descriptionKo : inc.descriptionEn }}
              </div>
              <div class="text-[11px] text-slate-400 font-mono flex items-center justify-between pt-1 border-t border-slate-800/60">
                <span>Target: {{ inc.targetAsset }}</span>
                <span>{{ inc.timestamp }}</span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Knox Device Fleet Grid -->
      <div class="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 space-y-4">
        <div class="flex items-center justify-between">
          <h3 class="text-sm font-bold text-white flex items-center">
            <mat-icon class="text-blue-400 mr-2 text-base">phonelink_lock</mat-icon>
            {{ loc.isKorean() ? '녹스 엔터프라이즈 모바일/DeX 디바이스 플릿' : 'Knox Enterprise Mobile & DeX Fleet' }}
          </h3>
          <span class="text-xs text-slate-400 font-mono">Hardware Root of Trust Verified</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          @for (dev of data.devices(); track dev.id) {
            <div class="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
              <div class="flex items-center justify-between">
                <div class="text-xs font-bold text-white">{{ dev.model }}</div>
                <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-bold">
                  {{ dev.knoxAttestationStatus }}
                </span>
              </div>

              <div class="text-xs text-slate-300">
                {{ dev.assignedUser }} ({{ dev.department }})
              </div>

              <div class="space-y-1 text-[11px] text-slate-400 font-mono">
                <div>OS: {{ dev.osVersion }}</div>
                <div>Loc: {{ dev.location }}</div>
                <div>Battery: {{ dev.batteryPercent }}% | Sync: {{ dev.lastSyncTime }}</div>
              </div>

              <!-- Policies Badges -->
              <div class="flex flex-wrap gap-1 pt-2 border-t border-slate-800/80">
                @for (pol of dev.activePolicies; track pol) {
                  <span class="text-[9px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                    {{ pol }}
                  </span>
                }
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class SecurityKnoxViewComponent {
  data = inject(EnterpriseDataService);
  loc = inject(LocalizationService);
  eventBus = inject(EventBusService);
}
