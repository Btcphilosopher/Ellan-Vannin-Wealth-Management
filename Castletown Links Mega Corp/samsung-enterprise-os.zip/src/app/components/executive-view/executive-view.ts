import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EnterpriseDataService } from '../../core/services/enterprise-data.service';
import { LocalizationService } from '../../core/services/localization.service';

@Component({
  selector: 'app-executive-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="executive-command-centre" class="space-y-6">
      <!-- Title & Live Status Banner -->
      <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-slate-900/60 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '그룹 경영진 통합 관제 센터 (Executive Command Centre)' : 'Group Executive Command Centre' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '전사 실시간 재무 손익, 팹 가동 현황, 글로벌 공급망 및 차세대 R&D 통합 지표' 
              : 'Real-time group consolidated financials, Fab telemetry, SCM flow, and strategic R&D KPIs.' }}
          </p>
        </div>
        <div class="flex items-center space-x-2">
          <span class="text-xs px-3 py-1 rounded-lg bg-blue-950/60 text-blue-400 border border-blue-800/40 font-mono">
            {{ loc.isKorean() ? '감사 기준: IFRS 연결 회계' : 'Standard: IFRS Consolidated' }}
          </span>
          <span class="text-xs px-3 py-1 rounded-lg bg-slate-800 text-slate-300 font-mono">
            SYNC: 99.98%
          </span>
        </div>
      </div>

      <!-- Top Executive KPI Grid -->
      <div class="grid grid-cols-2 lg:grid-cols-6 gap-4">
        <!-- Revenue -->
        <div id="kpi-revenue" class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 hover:border-blue-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>{{ loc.t('exec.kpi.revenue') }}</span>
            <mat-icon class="text-blue-400 text-sm">payments</mat-icon>
          </div>
          <div class="text-2xl font-extrabold text-white font-mono">
            ₩{{ data.financials().groupRevenueKRW_Trillion }}T
          </div>
          <div class="text-[11px] text-emerald-400 flex items-center mt-1">
            <mat-icon class="text-xs mr-0.5">trending_up</mat-icon> +8.4% YoY
          </div>
        </div>

        <!-- Operating Profit -->
        <div id="kpi-op-profit" class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 hover:border-emerald-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>{{ loc.t('exec.kpi.operating_profit') }}</span>
            <mat-icon class="text-emerald-400 text-sm">account_balance</mat-icon>
          </div>
          <div class="text-2xl font-extrabold text-emerald-400 font-mono">
            ₩{{ data.financials().operatingProfitKRW_Trillion }}T
          </div>
          <div class="text-[11px] text-slate-400 mt-1">
            {{ loc.t('exec.kpi.margin') }}: <span class="text-white font-semibold">{{ data.financials().operatingMarginPercent }}%</span>
          </div>
        </div>

        <!-- Free Cash Flow -->
        <div id="kpi-fcf" class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 hover:border-cyan-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>{{ loc.t('exec.kpi.free_cash_flow') }}</span>
            <mat-icon class="text-cyan-400 text-sm">savings</mat-icon>
          </div>
          <div class="text-2xl font-extrabold text-white font-mono">
            ₩{{ data.financials().freeCashFlowKRW_Trillion }}T
          </div>
          <div class="text-[11px] text-cyan-400 mt-1">
            {{ loc.isKorean() ? '현금 보유 건전성 최우수' : 'Liquidity Grade: AAA' }}
          </div>
        </div>

        <!-- CapEx -->
        <div id="kpi-capex" class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 hover:border-amber-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>{{ loc.t('exec.kpi.capex') }}</span>
            <mat-icon class="text-amber-400 text-sm">precision_manufacturing</mat-icon>
          </div>
          <div class="text-2xl font-extrabold text-amber-300 font-mono">
            ₩{{ data.financials().capExKRW_Trillion }}T
          </div>
          <div class="text-[11px] text-slate-400 mt-1">
            {{ loc.isKorean() ? 'DS 반도체 투자 비중 62.5%' : 'Semiconductor Share 62.5%' }}
          </div>
        </div>

        <!-- R&D -->
        <div id="kpi-rnd" class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 hover:border-purple-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>{{ loc.t('exec.kpi.rnd') }}</span>
            <mat-icon class="text-purple-400 text-sm">science</mat-icon>
          </div>
          <div class="text-2xl font-extrabold text-purple-300 font-mono">
            ₩{{ data.financials().rndInvestmentKRW_Trillion }}T
          </div>
          <div class="text-[11px] text-purple-400 mt-1">
            {{ loc.isKorean() ? '매출 대비 10.1% 투자' : '10.1% of Revenue' }}
          </div>
        </div>

        <!-- Average Fab OEE -->
        <div id="kpi-oee" class="bg-slate-900/90 p-4 rounded-xl border border-slate-800 hover:border-blue-500/50 transition-all">
          <div class="flex items-center justify-between text-slate-400 text-xs mb-1">
            <span>{{ loc.isKorean() ? '글로벌 종합가동률' : 'Global Avg OEE' }}</span>
            <mat-icon class="text-blue-400 text-sm">speed</mat-icon>
          </div>
          <div class="text-2xl font-extrabold text-blue-400 font-mono">
            93.4%
          </div>
          <div class="text-[11px] text-emerald-400 mt-1">
            6개 메가 사이트 가동 중
          </div>
        </div>
      </div>

      <!-- Main Two-Column Division & Global Footprint Section -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Division Financial Performance Table (7 Cols) -->
        <div class="lg:col-span-7 bg-slate-900/80 p-5 rounded-2xl border border-slate-800">
          <div class="flex items-center justify-between mb-4">
            <h3 class="text-sm font-bold text-white flex items-center">
              <mat-icon class="text-blue-400 mr-2 text-base">domain</mat-icon>
              {{ loc.t('exec.division_performance') }}
            </h3>
            <span class="text-xs text-slate-400 font-mono">Unit: KRW Trillion / %</span>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs text-slate-300">
              <thead class="bg-slate-950/60 text-slate-400 text-[11px] uppercase border-b border-slate-800">
                <tr>
                  <th class="py-2.5 px-3">{{ loc.isKorean() ? '사업부문' : 'Business Unit' }}</th>
                  <th class="py-2.5 px-3 text-right">{{ loc.isKorean() ? '매출액' : 'Revenue' }}</th>
                  <th class="py-2.5 px-3 text-right">{{ loc.isKorean() ? '영업이익' : 'Op. Profit' }}</th>
                  <th class="py-2.5 px-3 text-right">{{ loc.isKorean() ? '이익률' : 'Margin' }}</th>
                  <th class="py-2.5 px-3 text-right">{{ loc.isKorean() ? 'CapEx 비중' : 'CapEx Share' }}</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-800/60">
                @for (div of data.financials().divisionBreakdown; track div.division) {
                  <tr class="hover:bg-slate-800/40 transition-colors">
                    <td class="py-3 px-3 font-medium text-white flex items-center">
                      <span class="w-2 h-2 rounded-full bg-blue-500 mr-2"></span>
                      {{ loc.isKorean() ? div.divisionKo : div.division }}
                    </td>
                    <td class="py-3 px-3 text-right font-mono text-slate-200">₩{{ div.revenueKRW_T }}T</td>
                    <td class="py-3 px-3 text-right font-mono font-bold text-emerald-400">₩{{ div.operatingProfitKRW_T }}T</td>
                    <td class="py-3 px-3 text-right font-mono">{{ div.marginPct }}%</td>
                    <td class="py-3 px-3 text-right font-mono text-slate-400">{{ div.capExSharePct }}%</td>
                  </tr>
                }
              </tbody>
            </table>
          </div>
        </div>

        <!-- Global Manufacturing Footprint (5 Cols) -->
        <div class="lg:col-span-5 bg-slate-900/80 p-5 rounded-2xl border border-slate-800 flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between mb-4">
              <h3 class="text-sm font-bold text-white flex items-center">
                <mat-icon class="text-emerald-400 mr-2 text-base">public</mat-icon>
                {{ loc.t('exec.global_sites') }}
              </h3>
              <span class="text-xs px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                6 Active Sites
              </span>
            </div>

            <div class="space-y-3">
              @for (site of data.facilities(); track site.id) {
                <div class="p-3 bg-slate-950/70 rounded-xl border border-slate-800/70 hover:border-slate-700 transition-all flex items-center justify-between">
                  <div class="space-y-0.5">
                    <div class="flex items-center space-x-2">
                      <span class="text-xs font-semibold text-white">
                        {{ loc.isKorean() ? site.nameKo : site.name }}
                      </span>
                      <span class="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-800 text-slate-300">
                        {{ site.country }}
                      </span>
                    </div>
                    <div class="text-[11px] text-slate-400">
                      {{ loc.isKorean() ? '가동라인: ' + site.activeLines + '개 | 인원: ' + site.totalPersonnel.toLocaleString() + '명' : site.activeLines + ' Lines | ' + site.totalPersonnel.toLocaleString() + ' Personnel' }}
                    </div>
                  </div>
                  <div class="text-right">
                    <div class="text-xs font-bold font-mono text-emerald-400">{{ site.oeePercent }}% OEE</div>
                    <div class="text-[10px] text-slate-400 font-mono">{{ site.energyConsumptionMW }} MW</div>
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ExecutiveViewComponent {
  data = inject(EnterpriseDataService);
  loc = inject(LocalizationService);
}
