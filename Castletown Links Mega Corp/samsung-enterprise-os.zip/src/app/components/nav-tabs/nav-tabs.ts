import { Component, ChangeDetectionStrategy, inject, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { LocalizationService } from '../../core/services/localization.service';

export type EnterpriseTabId = 
  | 'EXECUTIVE'
  | 'SEMICONDUCTOR'
  | 'MES_TWIN'
  | 'DEVICE_BOM'
  | 'SUPPLY_CHAIN'
  | 'FINANCE'
  | 'APPROVAL'
  | 'SECURITY_KNOX'
  | 'COPILOT'
  | 'WORKSPACE_DEX'
  | 'AUDIT'
  | 'TERMINOLOGY';

@Component({
  selector: 'app-nav-tabs',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <nav id="enterprise-nav-tabs" class="bg-slate-900/60 border-b border-slate-800 backdrop-blur-sm sticky top-[73px] z-40">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex space-x-1 overflow-x-auto py-2 scrollbar-none">
          <!-- 1. Executive -->
          <button 
            id="tab-btn-exec"
            (click)="tabSelected.emit('EXECUTIVE')"
            [class.bg-blue-600]="activeTab() === 'EXECUTIVE'"
            [class.text-white]="activeTab() === 'EXECUTIVE'"
            [class.shadow-md]="activeTab() === 'EXECUTIVE'"
            [class.bg-slate-900]="activeTab() !== 'EXECUTIVE'"
            [class.text-slate-400]="activeTab() !== 'EXECUTIVE'"
            class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">dashboard</mat-icon>
            <span>{{ loc.isKorean() ? '경영진 관제' : 'Executive' }}</span>
          </button>

          <!-- 2. Semiconductor Fab OS -->
          <button 
            id="tab-btn-semi"
            (click)="tabSelected.emit('SEMICONDUCTOR')"
            [class.bg-blue-600]="activeTab() === 'SEMICONDUCTOR'"
            [class.text-white]="activeTab() === 'SEMICONDUCTOR'"
            [class.shadow-md]="activeTab() === 'SEMICONDUCTOR'"
            [class.bg-slate-900]="activeTab() !== 'SEMICONDUCTOR'"
            [class.text-slate-400]="activeTab() !== 'SEMICONDUCTOR'"
            class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">memory</mat-icon>
            <span>{{ loc.isKorean() ? '반도체 팹 OS' : 'Semiconductor Fab' }}</span>
          </button>

          <!-- 3. Smart Factory MES & Digital Twin -->
          <button 
            id="tab-btn-mes"
            (click)="tabSelected.emit('MES_TWIN')"
            [class.bg-blue-600]="activeTab() === 'MES_TWIN'"
            [class.text-white]="activeTab() === 'MES_TWIN'"
            [class.shadow-md]="activeTab() === 'MES_TWIN'"
            [class.bg-slate-900]="activeTab() !== 'MES_TWIN'"
            [class.text-slate-400]="activeTab() !== 'MES_TWIN'"
            class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">precision_manufacturing</mat-icon>
            <span>{{ loc.isKorean() ? 'MES & 디지털트윈' : 'MES & Digital Twin' }}</span>
          </button>

          <!-- 4. Device & Display BOM -->
          <button 
            id="tab-btn-device"
            (click)="tabSelected.emit('DEVICE_BOM')"
            [class.bg-blue-600]="activeTab() === 'DEVICE_BOM'"
            [class.text-white]="activeTab() === 'DEVICE_BOM'"
            [class.shadow-md]="activeTab() === 'DEVICE_BOM'"
            [class.bg-slate-900]="activeTab() !== 'DEVICE_BOM'"
            [class.text-slate-400]="activeTab() !== 'DEVICE_BOM'"
            class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">devices</mat-icon>
            <span>{{ loc.isKorean() ? '디바이스 & BOM' : 'Device & Display' }}</span>
          </button>

          <!-- 5. Supply Chain & Logistics -->
          <button 
            id="tab-btn-scm"
            (click)="tabSelected.emit('SUPPLY_CHAIN')"
            [class.bg-blue-600]="activeTab() === 'SUPPLY_CHAIN'"
            [class.text-white]="activeTab() === 'SUPPLY_CHAIN'"
            [class.shadow-md]="activeTab() === 'SUPPLY_CHAIN'"
            [class.bg-slate-900]="activeTab() !== 'SUPPLY_CHAIN'"
            [class.text-slate-400]="activeTab() !== 'SUPPLY_CHAIN'"
            class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">local_shipping</mat-icon>
            <span>{{ loc.isKorean() ? '공급망/물류' : 'Supply Chain' }}</span>
          </button>

          <!-- 6. Finance & Unit Economics -->
          <button 
            id="tab-btn-fin"
            (click)="tabSelected.emit('FINANCE')"
            [class.bg-blue-600]="activeTab() === 'FINANCE'"
            [class.text-white]="activeTab() === 'FINANCE'"
            [class.shadow-md]="activeTab() === 'FINANCE'"
            [class.bg-slate-900]="activeTab() !== 'FINANCE'"
            [class.text-slate-400]="activeTab() !== 'FINANCE'"
            class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">calculate</mat-icon>
            <span>{{ loc.isKorean() ? '재무/원가분석' : 'Finance & Cost' }}</span>
          </button>

          <!-- 7. Korean Approval Engine -->
          <button 
            id="tab-btn-appr"
            (click)="tabSelected.emit('APPROVAL')"
            [class.bg-blue-600]="activeTab() === 'APPROVAL'"
            [class.text-white]="activeTab() === 'APPROVAL'"
            [class.shadow-md]="activeTab() === 'APPROVAL'"
            [class.bg-slate-900]="activeTab() !== 'APPROVAL'"
            [class.text-slate-400]="activeTab() !== 'APPROVAL'"
            class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">assignment_turned_in</mat-icon>
            <span>{{ loc.isKorean() ? '전자결재' : 'Approvals' }}</span>
          </button>

          <!-- 8. Security & Knox Fleet -->
          <button 
            id="tab-btn-sec"
            (click)="tabSelected.emit('SECURITY_KNOX')"
            [class.bg-blue-600]="activeTab() === 'SECURITY_KNOX'"
            [class.text-white]="activeTab() === 'SECURITY_KNOX'"
            [class.shadow-md]="activeTab() === 'SECURITY_KNOX'"
            [class.bg-slate-900]="activeTab() !== 'SECURITY_KNOX'"
            [class.text-slate-400]="activeTab() !== 'SECURITY_KNOX'"
            class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">security</mat-icon>
            <span>{{ loc.isKorean() ? '보안/Knox' : 'Security & Knox' }}</span>
          </button>

          <!-- 9. Samsung Enterprise Copilot -->
          <button 
            id="tab-btn-copilot"
            (click)="tabSelected.emit('COPILOT')"
            [class.bg-indigo-600]="activeTab() === 'COPILOT'"
            [class.text-white]="activeTab() === 'COPILOT'"
            [class.shadow-md]="activeTab() === 'COPILOT'"
            [class.bg-slate-900]="activeTab() !== 'COPILOT'"
            [class.text-indigo-400]="activeTab() !== 'COPILOT'"
            class="px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">auto_awesome</mat-icon>
            <span>{{ loc.isKorean() ? 'AI 코파일럿' : 'AI Copilot' }}</span>
          </button>

          <!-- 10. Workspace & DeX Simulator -->
          <button 
            id="tab-btn-dex"
            (click)="tabSelected.emit('WORKSPACE_DEX')"
            [class.bg-blue-600]="activeTab() === 'WORKSPACE_DEX'"
            [class.text-white]="activeTab() === 'WORKSPACE_DEX'"
            [class.shadow-md]="activeTab() === 'WORKSPACE_DEX'"
            [class.bg-slate-900]="activeTab() !== 'WORKSPACE_DEX'"
            [class.text-slate-400]="activeTab() !== 'WORKSPACE_DEX'"
            class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">devices_other</mat-icon>
            <span>{{ loc.isKorean() ? '갤럭시 워크스페이스' : 'Workspace & DeX' }}</span>
          </button>

          <!-- 11. Immutable Audit Trail -->
          <button 
            id="tab-btn-audit"
            (click)="tabSelected.emit('AUDIT')"
            [class.bg-blue-600]="activeTab() === 'AUDIT'"
            [class.text-white]="activeTab() === 'AUDIT'"
            [class.shadow-md]="activeTab() === 'AUDIT'"
            [class.bg-slate-900]="activeTab() !== 'AUDIT'"
            [class.text-slate-400]="activeTab() !== 'AUDIT'"
            class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">history_edu</mat-icon>
            <span>{{ loc.isKorean() ? '감사 로그' : 'Audit Trail' }}</span>
          </button>

          <!-- 12. Terminology Dictionary -->
          <button 
            id="tab-btn-dict"
            (click)="tabSelected.emit('TERMINOLOGY')"
            [class.bg-blue-600]="activeTab() === 'TERMINOLOGY'"
            [class.text-white]="activeTab() === 'TERMINOLOGY'"
            [class.shadow-md]="activeTab() === 'TERMINOLOGY'"
            [class.bg-slate-900]="activeTab() !== 'TERMINOLOGY'"
            [class.text-slate-400]="activeTab() !== 'TERMINOLOGY'"
            class="px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap flex items-center space-x-1.5 transition-all hover:text-white cursor-pointer">
            <mat-icon class="text-sm">menu_book</mat-icon>
            <span>{{ loc.isKorean() ? '표준 용어사전' : 'Terminology' }}</span>
          </button>
        </div>
      </div>
    </nav>
  `
})
export class NavTabsComponent {
  loc = inject(LocalizationService);

  activeTab = input.required<EnterpriseTabId>();
  tabSelected = output<EnterpriseTabId>();
}
