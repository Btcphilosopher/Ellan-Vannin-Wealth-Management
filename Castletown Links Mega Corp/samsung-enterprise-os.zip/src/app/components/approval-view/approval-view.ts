import { Component, ChangeDetectionStrategy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EnterpriseDataService } from '../../core/services/enterprise-data.service';
import { LocalizationService } from '../../core/services/localization.service';


@Component({
  selector: 'app-approval-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="korean-approval-engine" class="space-y-6">
      <!-- Title Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/70 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-blue-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '한국형 전자결재 시스템 (Electronic Approval Engine)' : 'Korean Enterprise Approval Engine (전자결재)' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '기안-검토-합의-전결-시행 다단계 결재선, 전결 규정 검증, 위·변조 방지 블록체인 감사 해시' 
              : 'Multi-tier approval lines (Drafter-Reviewer-Consensus-CEO Approval), delegation rules, and audit trails.' }}
          </p>
        </div>

        <div class="flex items-center space-x-2">
          <span class="text-xs px-3 py-1 rounded-lg bg-blue-950/60 text-blue-400 border border-blue-800/40 font-mono">
            {{ loc.isKorean() ? '전결 규정: 2026 개정 제4조 준수' : 'Delegation Policy Rule v2026.4' }}
          </span>
        </div>
      </div>

      <!-- Approval Documents List -->
      <div class="space-y-4">
        @for (doc of data.approvals(); track doc.id) {
          <div class="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 space-y-4">
            <!-- Header Row -->
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
              <div>
                <div class="flex items-center space-x-2">
                  <span class="text-[11px] font-mono font-bold px-2 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                    {{ doc.docNumber }}
                  </span>
                  <span class="text-[11px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">
                    {{ doc.classification }}
                  </span>
                  <span class="text-[11px] font-mono px-2 py-0.5 rounded bg-amber-500/20 text-amber-300">
                    {{ doc.urgency }}
                  </span>
                </div>
                <h3 class="text-base font-bold text-white mt-2">
                  {{ loc.isKorean() ? doc.titleKo : doc.title }}
                </h3>
              </div>

              <!-- Status Badge -->
              <div class="flex items-center space-x-2">
                <span 
                  [class.bg-emerald-500/20]="doc.status === 'APPROVED'"
                  [class.text-emerald-400]="doc.status === 'APPROVED'"
                  [class.border-emerald-500/30]="doc.status === 'APPROVED'"
                  [class.bg-blue-500/20]="doc.status === 'IN_PROGRESS'"
                  [class.text-blue-400]="doc.status === 'IN_PROGRESS'"
                  [class.border-blue-500/30]="doc.status === 'IN_PROGRESS'"
                  [class.bg-rose-500/20]="doc.status === 'REJECTED'"
                  [class.text-rose-400]="doc.status === 'REJECTED'"
                  [class.border-rose-500/30]="doc.status === 'REJECTED'"
                  class="text-xs font-mono font-bold px-3 py-1 rounded-lg border">
                  {{ doc.status }}
                </span>
              </div>
            </div>

            <!-- Drafter & Amount Meta -->
            <div class="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs bg-slate-950 p-3.5 rounded-xl border border-slate-800/80">
              <div>
                <span class="text-slate-400">{{ loc.isKorean() ? '기안자 (Drafter):' : 'Drafter:' }}</span>
                <div class="font-medium text-slate-200 mt-0.5">
                  {{ loc.isKorean() ? doc.drafter.nameKo : doc.drafter.name }} ({{ loc.isKorean() ? doc.drafter.departmentKo : doc.drafter.departmentEn }})
                </div>
              </div>
              @if (doc.amountKRW) {
                <div>
                  <span class="text-slate-400">{{ loc.isKorean() ? '품의 금액 (Amount):' : 'Requisition Amount:' }}</span>
                  <div class="font-bold font-mono text-emerald-400 mt-0.5">
                    ₩{{ (doc.amountKRW / 100000000).toLocaleString() }}억 원
                  </div>
                </div>
              }
              <div>
                <span class="text-slate-400">{{ loc.isKorean() ? '감사 고유 ID:' : 'Immutable Audit ID:' }}</span>
                <div class="font-mono text-slate-400 text-[11px] mt-0.5">
                  {{ doc.auditId }}
                </div>
              </div>
            </div>

            <!-- Summary Text -->
            <div class="text-xs text-slate-300 leading-relaxed bg-slate-950/40 p-3 rounded-lg border border-slate-800/50">
              {{ loc.isKorean() ? doc.summaryKo : doc.summaryEn }}
            </div>

            <!-- Approval Line Steps Flow (결재선) -->
            <div class="space-y-2">
              <div class="text-xs font-semibold text-slate-300 flex items-center">
                <mat-icon class="text-xs mr-1 text-blue-400">account_tree</mat-icon>
                {{ loc.isKorean() ? '결재 진행 라인 (Approval Line Workflow)' : 'Approval Workflow Steps' }}
              </div>

              <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2 text-xs">
                @for (step of doc.steps; track step.stepNumber) {
                  <div 
                    [class.border-emerald-500/50]="step.action === 'APPROVED' || step.action === 'DELEGATED'"
                    [class.bg-emerald-950/20]="step.action === 'APPROVED' || step.action === 'DELEGATED'"
                    [class.border-blue-500/50]="step.action === 'PENDING'"
                    [class.bg-blue-950/20]="step.action === 'PENDING'"
                    [class.border-rose-500/50]="step.action === 'REJECTED'"
                    [class.bg-rose-950/20]="step.action === 'REJECTED'"
                    class="p-3 rounded-xl border space-y-1">
                    <div class="flex items-center justify-between">
                      <span class="text-[10px] text-slate-400 font-mono">Step {{ step.stepNumber }}</span>
                      <span 
                        [class.text-emerald-400]="step.action === 'APPROVED' || step.action === 'DELEGATED'"
                        [class.text-blue-400]="step.action === 'PENDING'"
                        [class.text-rose-400]="step.action === 'REJECTED'"
                        class="text-[10px] font-mono font-bold">
                        {{ step.action }}
                      </span>
                    </div>
                    <div class="font-bold text-white text-[11px]">{{ step.approverName }}</div>
                    <div class="text-[10px] text-slate-400">{{ loc.isKorean() ? step.approverTitleKo : step.approverTitleEn }}</div>
                    @if (step.timestamp) {
                      <div class="text-[9px] font-mono text-slate-500">{{ step.timestamp }}</div>
                    }
                  </div>
                }
              </div>
            </div>

            <!-- Action Buttons for Pending Decisions -->
            @if (doc.status === 'IN_PROGRESS') {
              <div class="flex items-center justify-end space-x-3 pt-3 border-t border-slate-800">
                <button 
                  (click)="data.rejectDocument(doc.id, 'CapEx 타당성 추가 보완 요청')"
                  class="px-4 py-2 rounded-xl text-xs font-bold text-rose-300 bg-rose-950/60 hover:bg-rose-900/80 border border-rose-800/40 transition-all cursor-pointer">
                  {{ loc.isKorean() ? '반려 (Reject)' : 'Reject Requisition' }}
                </button>
                <button 
                  (click)="data.approveDocument(doc.id, '김명진 부사장 (CFO)')"
                  class="px-5 py-2 rounded-xl text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 shadow-lg shadow-blue-950/60 transition-all cursor-pointer flex items-center">
                  <mat-icon class="mr-1 text-sm">check_circle</mat-icon>
                  {{ loc.isKorean() ? '결재 승인 (Approve & Execute)' : 'Approve & Sign Electronically' }}
                </button>
              </div>
            }
          </div>
        }
      </div>
    </div>
  `
})
export class ApprovalViewComponent {
  data = inject(EnterpriseDataService);
  loc = inject(LocalizationService);
}
