import { Component, ChangeDetectionStrategy, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { LocalizationService } from '../../core/services/localization.service';
import { EventBusService } from '../../core/services/event-bus.service';

@Component({
  selector: 'app-workspace-dex-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="galaxy-workspace-dex" class="space-y-6">
      <!-- Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/70 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-blue-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '갤럭시 엔터프라이즈 워크스페이스 & DeX (Galaxy Workspace & DeX)' : 'Galaxy Enterprise Workspace & DeX Simulator' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '스마트폰, 러기드 태블릿 및 DeX 데스크톱 환경 전환, 현장 바코드/FOUP 스캐너 및 모바일 업무 포털' 
              : 'Seamless transition between Smartphone, Rugged Tablet, and DeX Desktop with shop-floor scanning.' }}
          </p>
        </div>

        <!-- Mode Toggle -->
        <div class="flex items-center bg-slate-950 p-1 rounded-xl border border-slate-800">
          <button 
            (click)="deviceMode.set('PHONE')"
            [class.bg-blue-600]="deviceMode() === 'PHONE'"
            [class.text-white]="deviceMode() === 'PHONE'"
            [class.text-slate-400]="deviceMode() !== 'PHONE'"
            class="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center space-x-1">
            <mat-icon class="text-xs">smartphone</mat-icon>
            <span>Phone</span>
          </button>
          <button 
            (click)="deviceMode.set('TABLET')"
            [class.bg-blue-600]="deviceMode() === 'TABLET'"
            [class.text-white]="deviceMode() === 'TABLET'"
            [class.text-slate-400]="deviceMode() !== 'TABLET'"
            class="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center space-x-1">
            <mat-icon class="text-xs">tablet_mac</mat-icon>
            <span>Rugged Tab</span>
          </button>
          <button 
            (click)="deviceMode.set('DEX')"
            [class.bg-blue-600]="deviceMode() === 'DEX'"
            [class.text-white]="deviceMode() === 'DEX'"
            [class.text-slate-400]="deviceMode() !== 'DEX'"
            class="px-3 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer flex items-center space-x-1">
            <mat-icon class="text-xs">desktop_windows</mat-icon>
            <span>Samsung DeX</span>
          </button>
        </div>
      </div>

      <!-- Simulated Form Factor Frame -->
      <div class="flex justify-center">
        @if (deviceMode() === 'PHONE') {
          <!-- Galaxy S26 Phone Frame -->
          <div class="w-full max-w-sm bg-slate-950 border-4 border-slate-700 rounded-[2.5rem] p-4 shadow-2xl shadow-blue-950/60 space-y-4 text-slate-100">
            <!-- Dynamic Island/Pill camera -->
            <div class="w-20 h-4 bg-black mx-auto rounded-full"></div>
            
            <div class="flex items-center justify-between text-xs px-2 pt-1 font-mono text-slate-400">
              <span>09:41 KST</span>
              <div class="flex items-center space-x-1">
                <span>5G SA</span>
                <span>Knox Safe</span>
              </div>
            </div>

            <!-- Mobile Applets -->
            <div class="bg-slate-900 p-4 rounded-2xl border border-slate-800 space-y-3">
              <div class="flex items-center space-x-2">
                <div class="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center font-bold text-xs">MES</div>
                <div>
                  <div class="text-xs font-bold text-white">Fab Lot Scanner</div>
                  <div class="text-[10px] text-slate-400">Pyeongtaek P3 Bay-02</div>
                </div>
              </div>

              <!-- Barcode scan simulator button -->
              <button 
                (click)="triggerBarcodeScan()"
                class="w-full py-2.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center space-x-1 shadow cursor-pointer">
                <mat-icon class="text-xs">qr_code_scanner</mat-icon>
                <span>{{ loc.isKorean() ? 'FOUP 캐리어 바코드 스캔' : 'Scan FOUP Carrier' }}</span>
              </button>

              @if (scanResult()) {
                <div class="p-2.5 bg-slate-950 rounded-lg text-xs font-mono border border-emerald-500/40 text-emerald-400">
                  {{ scanResult() }}
                </div>
              }
            </div>

            <div class="bg-slate-900 p-4 rounded-2xl border border-slate-800 text-xs space-y-2">
              <div class="font-bold text-slate-200">Knox Vault Security Status</div>
              <div class="text-[11px] text-slate-400">Hardware Keystore: FIPS 140-3 Validated</div>
              <div class="text-emerald-400 font-mono text-[10px]">Real-Time Kernel Protection: ACTIVE</div>
            </div>
          </div>
        } @else if (deviceMode() === 'TABLET') {
          <!-- Rugged Tablet Frame -->
          <div class="w-full max-w-2xl bg-slate-950 border-8 border-slate-800 rounded-3xl p-6 shadow-2xl space-y-4">
            <div class="flex items-center justify-between border-b border-slate-800 pb-3">
              <div class="flex items-center space-x-2">
                <span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span class="text-xs font-bold text-white">Galaxy Tab Active5 Rugged Enterprise OS</span>
              </div>
              <span class="text-xs font-mono text-slate-400">ATEX Zone 2 Certified</span>
            </div>

            <div class="grid grid-cols-2 gap-4">
              <div class="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                <div class="text-xs font-bold text-blue-400">Shift Handover Checklist</div>
                <div class="text-xs text-slate-300">Cleanroom Bay 2 Gas Pressure: Nominal</div>
                <div class="text-xs text-slate-300">EUV Source Power: 30kW (Stable)</div>
              </div>
              <div class="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
                <div class="text-xs font-bold text-emerald-400">Assigned Technician</div>
                <div class="text-xs text-slate-200">이진우 수석 (DS Foundry)</div>
                <div class="text-[11px] text-slate-400">Shift: 08:00 - 17:00 KST</div>
              </div>
            </div>
          </div>
        } @else {
          <!-- DeX Desktop Frame -->
          <div class="w-full bg-slate-950 border border-slate-800 rounded-2xl p-6 shadow-2xl space-y-4">
            <div class="flex items-center justify-between pb-3 border-b border-slate-800">
              <div class="flex items-center space-x-2">
                <div class="w-6 h-6 rounded bg-blue-600 flex items-center justify-center text-xs font-bold">DeX</div>
                <span class="text-sm font-bold text-white">Samsung DeX Multi-Window Enterprise Desktop</span>
              </div>
              <span class="text-xs font-mono text-slate-400">Resolution: 3840x2160 @ 120Hz</span>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div class="p-4 bg-slate-900 rounded-xl border border-slate-800">
                <div class="text-xs font-bold text-slate-200 mb-2">Window 1: SAP S/4HANA ERP</div>
                <div class="text-xs text-slate-400">Consolidated financial ledger synchronized.</div>
              </div>
              <div class="p-4 bg-slate-900 rounded-xl border border-slate-800">
                <div class="text-xs font-bold text-slate-200 mb-2">Window 2: Fab MES SCADA</div>
                <div class="text-xs text-emerald-400 font-mono">Telemetry polling: 100ms latency</div>
              </div>
              <div class="p-4 bg-slate-900 rounded-xl border border-slate-800">
                <div class="text-xs font-bold text-slate-200 mb-2">Window 3: PLM CAD Viewer</div>
                <div class="text-xs text-purple-400 font-mono">3nm GAA Mask Geometry: Loaded</div>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class WorkspaceDexViewComponent {
  loc = inject(LocalizationService);
  eventBus = inject(EventBusService);

  readonly deviceMode = signal<'PHONE' | 'TABLET' | 'DEX'>('PHONE');
  readonly scanResult = signal<string | null>(null);

  triggerBarcodeScan() {
    const lotId = 'LOT-3NM-8842';
    const carrier = 'FOUP-9021';
    this.scanResult.set(`✓ SCANNED: Carrier ${carrier} | Lot ${lotId} (25 Wafers)`);
    
    this.eventBus.publish({
      eventType: 'LotStarted',
      domain: 'MANUFACTURING',
      actorId: 'MOBILE-SCANNER-01',
      actorName: 'Shopfloor Mobile Barcode Agent',
      details: `Mobile operator scanned and verified carrier ${carrier} containing ${lotId}.`,
      detailsKo: `현장 작업자가 모바일 단말로 캐리어 ${carrier} (로트 ${lotId}) 바코드 스캔 및 확인 완료.`,
      severity: 'INFO'
    });
  }
}
