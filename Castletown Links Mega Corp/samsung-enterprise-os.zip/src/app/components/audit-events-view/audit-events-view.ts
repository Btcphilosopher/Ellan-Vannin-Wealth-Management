import { Component, ChangeDetectionStrategy, inject, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EventBusService } from '../../core/services/event-bus.service';
import { LocalizationService } from '../../core/services/localization.service';


@Component({
  selector: 'app-audit-events-view',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div id="immutable-audit-trail" class="space-y-6">
      <!-- Title Header -->
      <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-slate-900/70 p-5 rounded-2xl border border-slate-800">
        <div>
          <div class="flex items-center space-x-2">
            <span class="w-3 h-3 rounded-full bg-blue-500 animate-pulse"></span>
            <h2 class="text-xl font-bold text-white tracking-tight">
              {{ loc.isKorean() ? '불변 감사 추적 & 이벤트 버스 (Immutable Audit Trail)' : 'Immutable Audit Trail & Cryptographic Event Stream' }}
            </h2>
          </div>
          <p class="text-xs text-slate-400 mt-1">
            {{ loc.isKorean() 
              ? '전사 모든 트랜잭션의 SHA-256 해시 체이닝 감사 기록, 도메인별 실시간 이벤트 브로드캐스트' 
              : 'Cryptographically hashed event ledger ensuring zero tampering, full traceability, and regulatory compliance.' }}
          </p>
        </div>

        <div class="flex items-center space-x-2">
          <span class="text-xs px-3 py-1 rounded-lg bg-blue-950/60 text-blue-400 border border-blue-800/40 font-mono">
            HASH CHAIN: SHA-256 VERIFIED
          </span>
        </div>
      </div>

      <!-- Filters & Events Stream -->
      <div class="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 space-y-4">
        <!-- Filter Bar -->
        <div class="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div class="flex flex-wrap items-center gap-1.5">
            <button 
              (click)="selectedDomain.set('ALL')"
              [class.bg-blue-600]="selectedDomain() === 'ALL'"
              [class.text-white]="selectedDomain() === 'ALL'"
              [class.bg-slate-950]="selectedDomain() !== 'ALL'"
              [class.text-slate-400]="selectedDomain() !== 'ALL'"
              class="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              ALL
            </button>
            <button 
              (click)="selectedDomain.set('SEMICONDUCTOR')"
              [class.bg-blue-600]="selectedDomain() === 'SEMICONDUCTOR'"
              [class.text-white]="selectedDomain() === 'SEMICONDUCTOR'"
              [class.bg-slate-950]="selectedDomain() !== 'SEMICONDUCTOR'"
              [class.text-slate-400]="selectedDomain() !== 'SEMICONDUCTOR'"
              class="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              SEMICONDUCTOR
            </button>
            <button 
              (click)="selectedDomain.set('MANUFACTURING')"
              [class.bg-blue-600]="selectedDomain() === 'MANUFACTURING'"
              [class.text-white]="selectedDomain() === 'MANUFACTURING'"
              [class.bg-slate-950]="selectedDomain() !== 'MANUFACTURING'"
              [class.text-slate-400]="selectedDomain() !== 'MANUFACTURING'"
              class="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              MANUFACTURING
            </button>
            <button 
              (click)="selectedDomain.set('FINANCE')"
              [class.bg-blue-600]="selectedDomain() === 'FINANCE'"
              [class.text-white]="selectedDomain() === 'FINANCE'"
              [class.bg-slate-950]="selectedDomain() !== 'FINANCE'"
              [class.text-slate-400]="selectedDomain() !== 'FINANCE'"
              class="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              FINANCE
            </button>
            <button 
              (click)="selectedDomain.set('SECURITY')"
              [class.bg-blue-600]="selectedDomain() === 'SECURITY'"
              [class.text-white]="selectedDomain() === 'SECURITY'"
              [class.bg-slate-950]="selectedDomain() !== 'SECURITY'"
              [class.text-slate-400]="selectedDomain() !== 'SECURITY'"
              class="px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer">
              SECURITY
            </button>
          </div>

          <span class="text-xs font-mono text-slate-400">
            Total Ledger Records: {{ filteredEvents().length }}
          </span>
        </div>

        <!-- Event Cards Stream -->
        <div class="space-y-3">
          @for (evt of filteredEvents(); track evt.id) {
            <div class="p-4 bg-slate-950 rounded-xl border border-slate-800/90 space-y-2.5 hover:border-slate-700 transition-all font-sans">
              <div class="flex items-center justify-between">
                <div class="flex items-center space-x-2">
                  <span class="font-mono text-xs font-bold text-blue-400">{{ evt.id }}</span>
                  <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">{{ evt.eventType }}</span>
                  <span class="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-500/20 text-purple-300">{{ evt.domain }}</span>
                </div>
                <div class="flex items-center space-x-2">
                  <span 
                    [class.bg-emerald-500/20]="evt.severity === 'INFO'"
                    [class.text-emerald-400]="evt.severity === 'INFO'"
                    [class.bg-amber-500/20]="evt.severity === 'WARNING'"
                    [class.text-amber-400]="evt.severity === 'WARNING'"
                    [class.bg-rose-500/20]="evt.severity === 'CRITICAL'"
                    [class.text-rose-400]="evt.severity === 'CRITICAL'"
                    class="text-[10px] font-mono font-bold px-2 py-0.5 rounded">
                    {{ evt.severity }}
                  </span>
                  <span class="text-[11px] font-mono text-slate-400">{{ evt.timestamp }}</span>
                </div>
              </div>

              <!-- Event Details -->
              <div class="text-xs text-slate-200">
                {{ loc.isKorean() && evt.detailsKo ? evt.detailsKo : evt.details }}
              </div>

              <!-- Actor and SHA-256 Hash Footprint -->
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-1 pt-2 border-t border-slate-800/60 text-[11px] text-slate-400 font-mono">
                <div>Actor: <strong class="text-slate-300">{{ evt.actorName }}</strong> ({{ evt.actorId }})</div>
                <div class="text-[10px] text-slate-500 truncate max-w-sm" [title]="evt.immutableHash">
                  {{ evt.immutableHash }}
                </div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class AuditEventsViewComponent {
  eventBus = inject(EventBusService);
  loc = inject(LocalizationService);

  readonly selectedDomain = signal<string>('ALL');

  readonly filteredEvents = computed(() => {
    const domain = this.selectedDomain();
    const all = this.eventBus.events();
    if (domain === 'ALL') return all;
    return all.filter(e => e.domain === domain);
  });
}
