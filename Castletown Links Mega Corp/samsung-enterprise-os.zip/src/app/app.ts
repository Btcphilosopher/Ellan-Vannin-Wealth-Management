import { ChangeDetectionStrategy, Component, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { HeaderComponent } from './components/header/header';
import { NavTabsComponent, EnterpriseTabId } from './components/nav-tabs/nav-tabs';
import { ExecutiveViewComponent } from './components/executive-view/executive-view';
import { SemiconductorViewComponent } from './components/semiconductor-view/semiconductor-view';
import { MesDigitalTwinViewComponent } from './components/mes-digital-twin-view/mes-digital-twin-view';
import { DeviceDisplayViewComponent } from './components/device-display-view/device-display-view';
import { SupplyChainViewComponent } from './components/supply-chain-view/supply-chain-view';
import { FinanceCostViewComponent } from './components/finance-cost-view/finance-cost-view';
import { ApprovalViewComponent } from './components/approval-view/approval-view';
import { SecurityKnoxViewComponent } from './components/security-knox-view/security-knox-view';
import { CopilotViewComponent } from './components/copilot-view/copilot-view';
import { WorkspaceDexViewComponent } from './components/workspace-dex-view/workspace-dex-view';
import { AuditEventsViewComponent } from './components/audit-events-view/audit-events-view';
import { TerminologyViewComponent } from './components/terminology-view/terminology-view';
import { LocalizationService } from './core/services/localization.service';

@Component({
  selector: 'app-root',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [
    CommonModule,
    MatIconModule,
    HeaderComponent,
    NavTabsComponent,
    ExecutiveViewComponent,
    SemiconductorViewComponent,
    MesDigitalTwinViewComponent,
    DeviceDisplayViewComponent,
    SupplyChainViewComponent,
    FinanceCostViewComponent,
    ApprovalViewComponent,
    SecurityKnoxViewComponent,
    CopilotViewComponent,
    WorkspaceDexViewComponent,
    AuditEventsViewComponent,
    TerminologyViewComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  loc = inject(LocalizationService);
  readonly currentTab = signal<EnterpriseTabId>('EXECUTIVE');

  switchTab(tab: EnterpriseTabId) {
    this.currentTab.set(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
}

