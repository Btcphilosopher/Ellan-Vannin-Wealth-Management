import type {Metadata} from 'next';
import { Playfair_Display, Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css'; // Global styles

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-serif',
  weight: ['400', '500', '600', '700'],
  display: 'swap',
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-sans',
  weight: ['300', '400', '500', '600', '700'],
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Isle of Man Market | Digital Island Marketplace',
  description: 'Discover exceptional makers, craft, food, fashion and design from the Isle of Man, curated in a premium digital island market.',
  openGraph: {
    title: 'Isle of Man Market | Digital Island Marketplace',
    description: 'Discover exceptional makers, craft, food, fashion and design from the Isle of Man, curated in a premium digital island market.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Isle of Man Market | Digital Island Marketplace',
    description: 'Discover exceptional makers, craft, food, fashion and design from the Isle of Man, curated in a premium digital island market.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${plusJakarta.variable} ${playfair.variable}`}>
      <body suppressHydrationWarning className="font-sans antialiased bg-[#FAF7F2] text-[#1F2421]">
        {children}
      </body>
    </html>
  );
}
