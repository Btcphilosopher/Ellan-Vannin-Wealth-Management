'use client';

import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Search, 
  Heart, 
  ShoppingBag, 
  ArrowLeft, 
  ArrowRight, 
  X, 
  Check, 
  MapPin, 
  Sparkles, 
  Filter, 
  SlidersHorizontal, 
  Star, 
  Trash2, 
  Plus, 
  Minus, 
  ExternalLink, 
  Compass, 
  Bookmark,
  ChevronRight,
  CreditCard,
  Truck,
  ArrowUpDown
} from 'lucide-react';
import Image from 'next/image';
import { 
  PRODUCTS, 
  MAKERS, 
  CATEGORIES, 
  COLLECTIONS, 
  TOWNS, 
  Product, 
  Maker 
} from '@/data/products';

// Types for flying items animation
interface FlyItem {
  id: number;
  src: string;
  startX: number;
  startY: number;
}

export default function IsleOfManMarketplace() {
  // --- STATE ---
  const [cart, setCart] = useState<{ id: string; quantity: number }[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [recentlyViewed, setRecentlyViewed] = useState<string[]>([]);
  
  // Views: 'home' | 'product-detail' | 'maker-detail' | 'checkout'
  const [activeView, setActiveView] = useState<'home' | 'product-detail' | 'maker-detail' | 'checkout'>('home');
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [selectedMakerId, setSelectedMakerId] = useState<string>('');
  
  // Browsing/Filter states
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeCollection, setActiveCollection] = useState<string>('all');
  const [sortOption, setSortOption] = useState<'featured' | 'price-low' | 'price-high' | 'rating'>('featured');
  const [priceRange, setPriceRange] = useState<number>(2000); // Max £2000
  
  // UI States
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [showFilters, setShowFilters] = useState<boolean>(false);
  const [flyItems, setFlyItems] = useState<FlyItem[]>([]);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [orderConfirmed, setOrderConfirmed] = useState<boolean>(false);
  
  // Checkout Form State
  const [checkoutForm, setCheckoutForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    town: 'Douglas',
    postcode: '',
    shippingOption: 'standard', // 'standard' (free), 'express' (£4.95)
    cardName: '',
    cardNumber: '',
    cardExpiry: '',
    cardCvc: '',
    giftMessage: '',
    giftWrap: false
  });

  const productGridRef = useRef<HTMLDivElement>(null);
  const cartIconRef = useRef<HTMLButtonElement>(null);
  const flyCounter = useRef<number>(0);

  // --- INITIALIZATION & PERSISTENCE ---
  useEffect(() => {
    // Load state from LocalStorage on mount
    const savedCart = localStorage.getItem('iom_market_cart');
    const savedFavorites = localStorage.getItem('iom_market_favorites');
    const savedRecentlyViewed = localStorage.getItem('iom_market_recently_viewed');

    // Defer updates to avoid synchronous setState linter warning in effect
    const loadTimer = setTimeout(() => {
      if (savedCart) {
        try { setCart(JSON.parse(savedCart)); } catch (e) { console.error(e); }
      }
      if (savedFavorites) {
        try { setFavorites(JSON.parse(savedFavorites)); } catch (e) { console.error(e); }
      }
      if (savedRecentlyViewed) {
        try { setRecentlyViewed(JSON.parse(savedRecentlyViewed)); } catch (e) { console.error(e); }
      }
    }, 0);

    return () => clearTimeout(loadTimer);
  }, []);

  // Sync to LocalStorage
  const updateCart = (newCart: { id: string; quantity: number }[]) => {
    setCart(newCart);
    localStorage.setItem('iom_market_cart', JSON.stringify(newCart));
  };

  const toggleFavorite = (productId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    let newFavorites;
    if (favorites.includes(productId)) {
      newFavorites = favorites.filter(id => id !== productId);
      triggerNotification('Removed from favourites');
    } else {
      newFavorites = [...favorites, productId];
      triggerNotification('Added to favourites');
    }
    setFavorites(newFavorites);
    localStorage.setItem('iom_market_favorites', JSON.stringify(newFavorites));
  };

  const triggerNotification = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => {
      setSuccessMessage(null);
    }, 2500);
  };

  // Recently viewed list helper
  const addToRecentlyViewed = (productId: string) => {
    setRecentlyViewed(prev => {
      const filtered = prev.filter(id => id !== productId);
      const updated = [productId, ...filtered].slice(0, 5);
      localStorage.setItem('iom_market_recently_viewed', JSON.stringify(updated));
      return updated;
    });
  };

  // Add to basket with coordinates for flying animation
  const handleAddToBasket = (productId: string, event: React.MouseEvent) => {
    event.stopPropagation();
    
    // Add item to cart state
    const existing = cart.find(item => item.id === productId);
    if (existing) {
      updateCart(cart.map(item => item.id === productId ? { ...item, quantity: item.quantity + 1 } : item));
    } else {
      updateCart([...cart, { id: productId, quantity: 1 }]);
    }

    // Trigger Fly Animation
    const product = PRODUCTS.find(p => p.id === productId);
    if (product) {
      const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
      flyCounter.current += 1;
      const newFlyItem: FlyItem = {
        id: flyCounter.current,
        src: product.image,
        startX: rect.left + rect.width / 2,
        startY: rect.top + rect.height / 2
      };
      setFlyItems(prev => [...prev, newFlyItem]);
      triggerNotification(`Added ${product.name} to basket`);
    }
  };

  // Clean fly item on animation completion
  const removeFlyItem = (id: number) => {
    setFlyItems(prev => prev.filter(item => item.id !== id));
  };

  // Nav actions
  const navigateToProduct = (productId: string) => {
    setSelectedProductId(productId);
    addToRecentlyViewed(productId);
    setActiveView('product-detail');
    setQuickViewProduct(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const navigateToMaker = (makerId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setSelectedMakerId(makerId);
    setActiveView('maker-detail');
    setQuickViewProduct(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const scrollToMarket = () => {
    if (productGridRef.current) {
      productGridRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Filter products logically
  const getFilteredProducts = () => {
    return PRODUCTS.filter(product => {
      // Category filter
      if (selectedCategory !== 'all' && product.category !== selectedCategory) {
        return false;
      }
      // Collection filter
      if (activeCollection !== 'all' && product.collection !== activeCollection) {
        return false;
      }
      // Price filter
      if (product.price > priceRange) {
        return false;
      }
      // Search query
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchesName = product.name.toLowerCase().includes(query);
        const matchesMaker = product.makerName.toLowerCase().includes(query);
        const matchesDesc = product.description.toLowerCase().includes(query);
        const matchesCategory = product.categoryLabel.toLowerCase().includes(query);
        if (!matchesName && !matchesMaker && !matchesDesc && !matchesCategory) {
          return false;
        }
      }
      return true;
    }).sort((a, b) => {
      if (sortOption === 'price-low') return a.price - b.price;
      if (sortOption === 'price-high') return b.price - a.price;
      if (sortOption === 'rating') return b.rating - a.rating;
      return 0; // Default Featured: original product order
    });
  };

  const filteredProducts = getFilteredProducts();

  // Cart operations
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);
  const cartSubtotal = cart.reduce((sum, item) => {
    const p = PRODUCTS.find(prod => prod.id === item.id);
    return sum + (p ? p.price * item.quantity : 0);
  }, 0);
  
  const getCartItemsDetails = () => {
    return cart.map(item => {
      const p = PRODUCTS.find(prod => prod.id === item.id)!;
      return {
        ...item,
        product: p
      };
    }).filter(item => item.product !== undefined);
  };

  const updateCartItemQuantity = (productId: string, amt: number) => {
    const item = cart.find(c => c.id === productId);
    if (!item) return;
    const newQty = item.quantity + amt;
    if (newQty <= 0) {
      updateCart(cart.filter(c => c.id !== productId));
    } else {
      updateCart(cart.map(c => c.id === productId ? { ...c, quantity: newQty } : c));
    }
  };

  // Submit mock checkout
  const handleCheckoutSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setOrderConfirmed(true);
  };

  const finalizeCheckout = () => {
    // Reset Cart
    updateCart([]);
    setOrderConfirmed(false);
    setActiveView('home');
    triggerNotification('Thank you! Your order was successfully received.');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF7F2] text-[#1F2421] relative overflow-x-hidden selection:bg-[#C09A58] selection:text-white bg-paper">
      
      {/* --- FLOATING NOTIFICATION --- */}
      <AnimatePresence>
        {successMessage && (
          <motion.div
            initial={{ opacity: 0, y: -50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className="fixed top-24 left-1/2 -translate-x-1/2 z-50 bg-[#0d422a] text-[#FAF7F2] border border-[#C09A58]/30 px-6 py-3 rounded-full shadow-xl flex items-center space-x-3 backdrop-blur-md"
            id="toast-notification"
          >
            <span className="w-2 h-2 rounded-full bg-[#C09A58] animate-ping" />
            <p className="font-sans text-sm font-medium tracking-wide">{successMessage}</p>
          </motion.div>
        )}
      </AnimatePresence>

      {/* --- CART ITEM FLY ANIMATIONS --- */}
      {flyItems.map(item => (
        <FlyAnimationElement 
          key={item.id} 
          item={item} 
          onComplete={removeFlyItem} 
        />
      ))}

      {/* --- HEADER NAVIGATION --- */}
      <header className="sticky top-0 z-40 bg-[#062b19] text-[#FAF7F2] border-b border-[#FAF7F2]/10 backdrop-blur-md bg-opacity-95 shadow-md py-4 px-4 sm:px-8 transition-all" id="main-header">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          
          {/* Logo & Vibe */}
          <div 
            className="flex items-center space-x-3 cursor-pointer group" 
            onClick={() => setActiveView('home')}
            id="header-logo"
          >
            {/* The Triskelion Symbol */}
            <div className="w-10 h-10 bg-[#A31D1D] rounded-full flex items-center justify-center border border-[#C09A58]/40 shadow-inner group-hover:scale-105 transition-transform duration-300">
              <span className="text-white font-serif text-lg font-bold select-none tracking-tighter">𐃏</span>
            </div>
            <div>
              <h1 className="font-serif text-lg sm:text-xl font-bold tracking-widest leading-none text-[#FAF7F2]">
                ISLE OF MAN
              </h1>
              <span className="text-[10px] uppercase font-sans tracking-[0.25em] text-[#C09A58]">
                Digital Island Market
              </span>
            </div>
          </div>

          {/* Desktop Search bar & Filtering input */}
          <div className="hidden md:flex items-center bg-[#FAF7F2]/10 border border-[#FAF7F2]/20 rounded-full px-4 py-2 w-96 focus-within:border-[#C09A58] focus-within:bg-[#FAF7F2]/15 transition-all" id="header-search">
            <Search className="w-4 h-4 text-[#C09A58] mr-2" />
            <input 
              type="text" 
              placeholder="Search products, makers, categories..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                if (activeView !== 'home') setActiveView('home');
              }}
              className="bg-transparent text-[#FAF7F2] placeholder-[#FAF7F2]/50 text-sm focus:outline-none w-full font-sans font-light"
            />
            {searchQuery && (
              <button onClick={() => setSearchQuery('')} className="p-0.5 hover:bg-white/10 rounded-full">
                <X className="w-3.5 h-3.5 text-[#FAF7F2]/60" />
              </button>
            )}
          </div>

          {/* User & Shop Controls */}
          <div className="flex items-center space-x-4 sm:space-x-6" id="header-controls">
            
            <button 
              onClick={() => {
                setActiveCollection('all');
                setSelectedCategory('all');
                setSearchQuery('');
                setActiveView('home');
                scrollToMarket();
              }}
              className="hidden lg:block text-xs uppercase tracking-widest text-[#FAF7F2]/80 hover:text-[#C09A58] transition-colors"
            >
              Shop All
            </button>

            <button 
              onClick={() => {
                setActiveView('home');
                setTimeout(() => {
                  const el = document.getElementById('the-island-showcase');
                  if (el) el.scrollIntoView({ behavior: 'smooth' });
                }, 100);
              }}
              className="hidden lg:block text-xs uppercase tracking-widest text-[#FAF7F2]/80 hover:text-[#C09A58] transition-colors"
            >
              Our Towns
            </button>

            {/* Favorites Icon */}
            <button 
              onClick={() => {
                triggerNotification(`Viewing ${favorites.length} bookmarked items`);
                setSelectedCategory('all');
                setActiveCollection('all');
                setSearchQuery('');
                // Simply filter to show only favorites
                const favProducts = PRODUCTS.filter(p => favorites.includes(p.id));
                if (favProducts.length === 0) {
                  triggerNotification("No favourites saved yet! Add some below.");
                } else {
                  scrollToMarket();
                }
              }}
              className="relative p-2 text-[#FAF7F2]/90 hover:text-[#A31D1D] hover:scale-110 transition-all"
              title="View Favorites"
              id="fav-btn"
            >
              <Heart className={`w-5 h-5 ${favorites.length > 0 ? 'fill-[#A31D1D] text-[#A31D1D]' : ''}`} />
              {favorites.length > 0 && (
                <span className="absolute -top-0.5 -right-0.5 bg-[#A31D1D] text-white text-[9px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                  {favorites.length}
                </span>
              )}
            </button>

            {/* Shopping Bag Button */}
            <button 
              ref={cartIconRef}
              onClick={() => setIsCartOpen(true)}
              className="relative p-2 text-[#FAF7F2]/90 hover:text-[#C09A58] hover:scale-110 transition-all flex items-center space-x-1"
              id="cart-btn"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <motion.span 
                  key={cartCount}
                  initial={{ scale: 0.5 }}
                  animate={{ scale: 1 }}
                  className="absolute -top-1 -right-1 bg-[#C09A58] text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full min-w-4 flex items-center justify-center"
                >
                  {cartCount}
                </motion.span>
              )}
              <span className="hidden sm:inline text-xs font-serif font-semibold text-[#FAF7F2]/80 ml-1">
                £{cartSubtotal.toFixed(2)}
              </span>
            </button>

          </div>
        </div>
      </header>

      {/* --- MOBILE SEARCH BAR --- */}
      <div className="md:hidden bg-[#0a3520] border-b border-[#FAF7F2]/10 py-3 px-4 flex items-center shadow-inner" id="mobile-search">
        <div className="flex items-center bg-[#FAF7F2]/10 border border-[#FAF7F2]/20 rounded-full px-4 py-2 w-full focus-within:border-[#C09A58]">
          <Search className="w-4 h-4 text-[#C09A58] mr-2" />
          <input 
            type="text" 
            placeholder="Search products, makers, towns..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              if (activeView !== 'home') setActiveView('home');
            }}
            className="bg-transparent text-[#FAF7F2] placeholder-[#FAF7F2]/50 text-xs focus:outline-none w-full"
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')} className="p-0.5">
              <X className="w-3.5 h-3.5 text-[#FAF7F2]/60" />
            </button>
          )}
        </div>
      </div>

      {/* --- MAIN CORE VIEWS --- */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          
          {/* --- VIEW: HOME PAGE --- */}
          {activeView === 'home' && (
            <motion.div
              key="home-view"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.5 }}
            >
              
              {/* LARGE ATMOSPHERIC HERO */}
              <section className="relative min-h-[85vh] sm:min-h-[90vh] bg-[#062b19] flex items-center justify-center overflow-hidden py-16 px-4" id="hero-section">
                
                {/* Background image overlay */}
                <div className="absolute inset-0 z-0 opacity-40 select-none pointer-events-none">
                  <Image 
                    src="https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&q=80&w=1920" 
                    alt="Isle of Man Landscape" 
                    fill
                    priority
                    className="object-cover scale-105 filter brightness-75 contrast-125 saturate-[0.85]"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-b from-[#062b19]/20 via-[#062b19]/70 to-[#062b19]" />
                </div>

                {/* Micro visual accents */}
                <div className="absolute top-10 left-10 w-24 h-24 border border-[#C09A58]/20 rounded-full pointer-events-none" />
                <div className="absolute bottom-10 right-10 w-40 h-40 border-r border-b border-[#C09A58]/10 rounded-br-3xl pointer-events-none" />

                <div className="relative z-10 max-w-4xl text-center flex flex-col items-center">
                  
                  {/* Subtle eyebrow label */}
                  <motion.div 
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.1, duration: 0.6 }}
                    className="flex items-center space-x-2 mb-6"
                  >
                    <span className="w-6 h-[1px] bg-[#C09A58]" />
                    <span className="text-xs font-sans tracking-[0.3em] text-[#C09A58] uppercase font-semibold">
                      Shop Local. Ship Worldwide.
                    </span>
                    <span className="w-6 h-[1px] bg-[#C09A58]" />
                  </motion.div>

                  {/* Main Title */}
                  <motion.h1 
                    initial={{ opacity: 0, y: 25 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.2, duration: 0.7 }}
                    className="font-serif text-4xl sm:text-6xl lg:text-7.5xl text-[#FAF7F2] tracking-tight leading-[1.05] mb-6 drop-shadow-sm font-bold"
                  >
                    THE ISLE OF MAN, <br/>
                    <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#FAF7F2] via-[#C09A58] to-[#FAF7F2]">
                      IN ONE MARKET.
                    </span>
                  </motion.h1>

                  {/* Supporting text */}
                  <motion.p 
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3, duration: 0.6 }}
                    className="font-sans text-base sm:text-xl text-[#FAF7F2]/80 max-w-2xl leading-relaxed mb-10 font-light"
                  >
                    Discover products, makers, food, craft and businesses from across the island. Hand-made, locally harvested, and delivered straight to your door.
                  </motion.p>

                  {/* CTA */}
                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.4, duration: 0.6 }}
                    className="flex flex-col sm:flex-row items-center gap-4"
                  >
                    <button 
                      onClick={scrollToMarket}
                      className="group relative bg-[#C09A58] text-[#062b19] font-sans text-xs uppercase tracking-[0.25em] font-bold px-10 py-5 rounded-none hover:bg-[#FAF7F2] hover:text-[#062b19] hover:border-[#C09A58] border border-transparent shadow-lg hover:shadow-2xl transition-all duration-300"
                    >
                      EXPLORE THE MARKET →
                    </button>
                    
                    <button 
                      onClick={() => {
                        const el = document.getElementById('the-island-showcase');
                        if (el) el.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="text-xs uppercase tracking-[0.25em] text-[#FAF7F2] border-b border-[#FAF7F2]/30 hover:border-[#C09A58] hover:text-[#C09A58] py-2 transition-colors"
                    >
                      LEARN ABOUT THE ISLAND
                    </button>
                  </motion.div>

                  {/* Trust factors */}
                  <div className="mt-20 grid grid-cols-3 gap-8 border-t border-[#FAF7F2]/10 pt-10 w-full max-w-3xl">
                    <div className="text-center">
                      <p className="text-xs uppercase tracking-widest text-[#C09A58] font-bold mb-1">Authentic</p>
                      <p className="text-[10px] text-[#FAF7F2]/60">100% Island Grown & Made</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs uppercase tracking-widest text-[#C09A58] font-bold mb-1">Worldwide</p>
                      <p className="text-[10px] text-[#FAF7F2]/60">Fast Delivery from the Quay</p>
                    </div>
                    <div className="text-center">
                      <p className="text-xs uppercase tracking-widest text-[#C09A58] font-bold mb-1">Sustainable</p>
                      <p className="text-[10px] text-[#FAF7F2]/60">Supporting Local Families</p>
                    </div>
                  </div>

                </div>
              </section>

              {/* ELEGANT CATEGORY NAVIGATION */}
              <section className="bg-[#ECE7DF] border-y border-[#DED8CC] py-6 overflow-x-auto" id="category-bar">
                <div className="max-w-7xl mx-auto px-4 flex justify-between items-center space-x-8 min-w-[900px]">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat.id}
                      onClick={() => {
                        setSelectedCategory(cat.id);
                        setActiveCollection('all');
                        scrollToMarket();
                      }}
                      className={`text-xs tracking-[0.2em] font-sans font-bold uppercase transition-all duration-300 whitespace-nowrap cursor-pointer hover:text-[#A31D1D] relative pb-2 ${
                        selectedCategory === cat.id 
                          ? 'text-[#0d422a] border-b-2 border-[#0d422a]' 
                          : 'text-[#1F2421]/60 hover:text-[#1F2421]'
                      }`}
                    >
                      {cat.label}
                    </button>
                  ))}
                </div>
              </section>

              {/* PRODUCT MARKET CATALOUGE CONTAINER */}
              <section ref={productGridRef} className="max-w-7xl mx-auto px-4 sm:px-8 py-16 sm:py-24" id="market-section">
                
                {/* Header of catalog */}
                <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-[#ECE7DF]">
                  <div>
                    <span className="text-xs font-sans tracking-[0.2em] uppercase text-[#C09A58] font-bold block mb-2">
                      {selectedCategory === 'all' ? 'All Market' : CATEGORIES.find(c => c.id === selectedCategory)?.label}
                    </span>
                    <h2 className="font-serif text-3xl sm:text-4xl text-[#062b19] font-bold leading-tight">
                      Browse Exceptional Manx Products
                    </h2>
                  </div>

                  {/* Filter panel toggle & Sorting */}
                  <div className="flex flex-wrap gap-4 mt-6 md:mt-0">
                    <button 
                      onClick={() => setShowFilters(!showFilters)}
                      className={`flex items-center space-x-2 text-xs font-sans tracking-wider uppercase font-bold border px-4 py-2.5 transition-colors ${
                        showFilters ? 'bg-[#0d422a] border-[#0d422a] text-[#FAF7F2]' : 'border-[#DED8CC] text-[#1F2421] hover:bg-[#ECE7DF]'
                      }`}
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                      <span>Filters {priceRange < 2000 ? `(Under £${priceRange})` : ''}</span>
                    </button>

                    <div className="flex items-center space-x-2 border border-[#DED8CC] px-4 py-2 bg-white">
                      <ArrowUpDown className="w-3.5 h-3.5 text-[#1F2421]/60" />
                      <select 
                        value={sortOption}
                        onChange={(e) => setSortOption(e.target.value as any)}
                        className="bg-transparent text-xs font-sans font-bold tracking-wider uppercase text-[#1F2421] focus:outline-none cursor-pointer"
                      >
                        <option value="featured">Featured / Default</option>
                        <option value="price-low">Price: Low to High</option>
                        <option value="price-high">Price: High to Low</option>
                        <option value="rating">Highest Rated</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Filter slide drawer panel */}
                <AnimatePresence>
                  {showFilters && (
                    <motion.div 
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      className="overflow-hidden mb-8 border border-[#DED8CC] bg-white p-6 shadow-inner"
                      id="filters-drawer"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                        {/* Price Slider */}
                        <div>
                          <label className="block text-xs uppercase font-sans tracking-widest text-[#1F2421]/60 font-bold mb-3">
                            Max Price (£{priceRange === 2000 ? 'No limit' : priceRange})
                          </label>
                          <input 
                            type="range" 
                            min="5" 
                            max="2000" 
                            step="5"
                            value={priceRange} 
                            onChange={(e) => setPriceRange(Number(e.target.value))}
                            className="w-full accent-[#0d422a] bg-[#ECE7DF] h-1.5 rounded-lg appearance-none cursor-pointer"
                          />
                          <div className="flex justify-between text-[10px] text-[#1F2421]/50 mt-2">
                            <span>£5</span>
                            <span>£250</span>
                            <span>£1,000</span>
                            <span>£2,000+</span>
                          </div>
                        </div>

                        {/* Fast Select Categories */}
                        <div>
                          <label className="block text-xs uppercase font-sans tracking-widest text-[#1F2421]/60 font-bold mb-3">
                            Direct Collections
                          </label>
                          <div className="flex flex-wrap gap-2">
                            {Object.entries(COLLECTIONS).map(([key, col]) => (
                              <button
                                key={key}
                                onClick={() => setActiveCollection(activeCollection === key ? 'all' : key)}
                                className={`text-[10px] uppercase tracking-wider px-3 py-1.5 font-sans font-bold transition-all ${
                                  activeCollection === key ? 'bg-[#C09A58] text-white' : 'bg-[#FAF7F2] text-[#1F2421] border border-[#DED8CC] hover:bg-[#ECE7DF]'
                                }`}
                              >
                                {col.title}
                              </button>
                            ))}
                          </div>
                        </div>

                        {/* Active States / Reset */}
                        <div className="flex flex-col justify-between items-end">
                          <div className="text-right">
                            <p className="text-xs text-[#1F2421]/60 font-sans">
                              Showing <strong className="text-[#062b19] font-bold">{filteredProducts.length}</strong> items in database.
                            </p>
                          </div>
                          
                          <button
                            onClick={() => {
                              setSelectedCategory('all');
                              setActiveCollection('all');
                              setPriceRange(2000);
                              setSortOption('featured');
                              setSearchQuery('');
                              triggerNotification('Filters cleared');
                            }}
                            className="text-xs uppercase tracking-widest text-[#A31D1D] hover:underline font-bold font-sans mt-4"
                          >
                            Reset All Filters
                          </button>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* EMPTY STATE */}
                {filteredProducts.length === 0 && (
                  <div className="text-center py-20 bg-white border border-dashed border-[#DED8CC] px-4">
                    <p className="font-serif text-xl text-[#0d422a] mb-2 font-semibold">No products found</p>
                    <p className="text-sm text-[#1F2421]/60 font-sans max-w-md mx-auto mb-6">
                      We couldn&apos;t find anything matching your filters or search. Try widening your criteria or clearing searches.
                    </p>
                    <button
                      onClick={() => {
                        setSelectedCategory('all');
                        setActiveCollection('all');
                        setPriceRange(2000);
                        setSearchQuery('');
                      }}
                      className="bg-[#0d422a] text-[#FAF7F2] text-xs font-sans uppercase tracking-widest px-6 py-3 font-bold"
                    >
                      Show All Products
                    </button>
                  </div>
                )}

                {/* ASYMMETRIC GRID SYSTEM (Editorial layout) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12 xl:gap-16">
                  {filteredProducts.map((product, idx) => {
                    // Injecting visual asymmetry by assigning custom styles & offsets
                    const isFeatureLarge = idx % 5 === 0;
                    
                    return (
                      <motion.div
                        key={product.id}
                        initial={{ opacity: 0, y: 30 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        viewport={{ once: true, margin: '-50px' }}
                        transition={{ duration: 0.6, delay: Math.min(idx % 3, 2) * 0.15 }}
                        onClick={() => navigateToProduct(product.id)}
                        className={`group relative flex flex-col justify-between bg-white border border-[#ECE7DF] shadow-sm hover:shadow-xl transition-all duration-500 cursor-pointer p-4 overflow-hidden ${
                          isFeatureLarge ? 'lg:col-span-2 flex-col md:flex-row gap-6 md:p-6' : ''
                        }`}
                        id={`product-card-${product.id}`}
                      >
                        
                        {/* Favorite button */}
                        <button
                          onClick={(e) => toggleFavorite(product.id, e)}
                          className="absolute top-6 right-6 z-10 p-2 bg-[#FAF7F2]/90 rounded-full text-[#1F2421] hover:text-[#A31D1D] hover:scale-110 shadow-sm transition-all"
                          title="Save item"
                          id={`fav-icon-btn-${product.id}`}
                        >
                          <Heart className={`w-4 h-4 ${favorites.includes(product.id) ? 'fill-[#A31D1D] text-[#A31D1D]' : 'text-gray-400'}`} />
                        </button>

                        {/* Image Container with Zoom hover */}
                        <div className={`relative bg-[#FAF7F2] overflow-hidden select-none flex-grow ${
                          isFeatureLarge ? 'w-full md:w-3/5 h-[320px] md:h-full' : 'h-[320px]'
                        }`}>
                          <Image 
                            src={product.image} 
                            alt={product.name} 
                            fill
                            className="object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                            referrerPolicy="no-referrer"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                          
                          {/* Small Category Badge Overlay */}
                          <span className="absolute bottom-4 left-4 bg-white/95 backdrop-blur-sm text-[#0d422a] text-[9px] uppercase tracking-widest font-sans font-bold px-3 py-1 border border-[#C09A58]/20">
                            {product.categoryLabel}
                          </span>

                          {/* Quick view trigger button overlay on desktop */}
                          <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-all duration-300">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setQuickViewProduct(product);
                              }}
                              className="bg-[#062b19]/90 text-white text-[10px] font-sans font-bold uppercase tracking-widest px-5 py-3 hover:bg-[#C09A58] transition-colors shadow-lg border border-[#C09A58]/30"
                            >
                              Quick View
                            </button>
                          </div>
                        </div>

                        {/* Editorial Details Block */}
                        <div className={`flex flex-col justify-between pt-4 ${
                          isFeatureLarge ? 'w-full md:w-2/5 md:pt-0 flex flex-col justify-between' : ''
                        }`}>
                          <div>
                            {/* Maker Name */}
                            <div className="flex items-center space-x-1.5 mb-1.5">
                              <MapPin className="w-3 h-3 text-[#C09A58]" />
                              <button 
                                onClick={(e) => navigateToMaker(product.makerId, e)}
                                className="text-[10px] font-sans tracking-widest uppercase text-[#C09A58] hover:text-[#062b19] hover:underline font-bold"
                              >
                                {product.makerName}
                              </button>
                            </div>

                            {/* Product Name */}
                            <h3 className="font-serif text-lg sm:text-xl text-[#062b19] font-bold tracking-tight mb-2 group-hover:text-[#A31D1D] transition-colors leading-tight">
                              {product.name}
                            </h3>

                            {/* Description snippet on large features */}
                            {isFeatureLarge && (
                              <p className="hidden md:block text-xs text-[#1F2421]/60 font-sans leading-relaxed mb-4 line-clamp-3">
                                {product.description}
                              </p>
                            )}

                            {/* Rating */}
                            <div className="flex items-center space-x-1 mb-4">
                              <div className="flex text-amber-500">
                                {[...Array(5)].map((_, i) => (
                                  <Star key={i} className={`w-3 h-3 ${i < Math.floor(product.rating) ? 'fill-current' : 'text-gray-200'}`} />
                                ))}
                              </div>
                              <span className="text-[10px] font-sans text-gray-500 font-bold">{product.rating}</span>
                            </div>
                          </div>

                          {/* Price & Action */}
                          <div className="border-t border-[#ECE7DF] pt-4 mt-2 flex items-center justify-between">
                            <span className="font-serif text-lg sm:text-xl font-bold text-[#1F2421]">
                              £{product.price.toFixed(2)}
                            </span>
                            
                            <button
                              onClick={(e) => handleAddToBasket(product.id, e)}
                              className="bg-[#0d422a] hover:bg-[#C09A58] text-[#FAF7F2] text-[10px] font-sans font-bold uppercase tracking-widest px-4 py-2.5 transition-colors border-none"
                              id={`add-cart-card-${product.id}`}
                            >
                              Add to Basket
                            </button>
                          </div>
                        </div>

                      </motion.div>
                    );
                  })}
                </div>

              </section>

              {/* ROTATING FEATURED COLLECTIONS (Flicking Horizontals) */}
              <section className="bg-[#062b19] text-[#FAF7F2] py-20 sm:py-28 overflow-hidden relative" id="featured-collections">
                <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#FAF7F2]/5 to-transparent rounded-full pointer-events-none" />
                
                <div className="max-w-7xl mx-auto px-4 sm:px-8 mb-16 flex flex-col md:flex-row md:items-end justify-between">
                  <div className="max-w-xl">
                    <span className="text-xs font-sans tracking-[0.3em] uppercase text-[#C09A58] font-semibold block mb-3">
                      CURATED COLLECTIONS
                    </span>
                    <h2 className="font-serif text-3xl sm:text-5xl text-white font-bold tracking-tight">
                      Made on the Island, <br/>Loved Everywhere.
                    </h2>
                  </div>
                  <p className="font-sans text-sm text-[#FAF7F2]/75 max-w-sm leading-relaxed mt-4 md:mt-0">
                    Hand-picked collections crafted under the fresh salt winds of the Manx coast and green valleys.
                  </p>
                </div>

                {/* Rotating Rows for each Collections category */}
                <div className="space-y-20">
                  {Object.entries(COLLECTIONS).map(([key, value]) => {
                    // Filter matching products
                    const colProducts = PRODUCTS.filter(p => p.collection === key);
                    if (colProducts.length === 0) return null;

                    return (
                      <div key={key} className="relative pl-4 sm:pl-8 lg:pl-[calc((100vw-min(1280px,90vw))/2)] overflow-x-auto select-none no-scrollbar pb-6" id={`col-row-${key}`}>
                        
                        {/* Section subtitle & description */}
                        <div className="mb-6 pr-4 sm:pr-8">
                          <h3 className="font-serif text-xl sm:text-2xl text-[#C09A58] font-bold uppercase tracking-widest mb-1">
                            {value.title}
                          </h3>
                          <p className="text-xs text-[#FAF7F2]/70 max-w-xl font-sans">
                            {value.description}
                          </p>
                        </div>

                        {/* Carousel Wrapper */}
                        <div className="flex space-x-6 min-w-max pr-12">
                          {colProducts.map((p) => (
                            <motion.div
                              key={p.id}
                              onClick={() => navigateToProduct(p.id)}
                              whileHover={{ y: -5 }}
                              className="w-[280px] sm:w-[320px] bg-white/5 border border-white/10 p-4 shadow-md hover:border-[#C09A58]/30 transition-all duration-300 cursor-pointer relative"
                            >
                              <div className="relative h-[240px] overflow-hidden mb-4 bg-black/10">
                                <Image 
                                  src={p.image} 
                                  alt={p.name} 
                                  fill
                                  className="object-cover hover:scale-105 transition-transform duration-500"
                                  referrerPolicy="no-referrer"
                                />
                                <span className="absolute top-2 left-2 bg-[#A31D1D] text-white text-[8px] uppercase tracking-wider font-sans font-semibold px-2 py-0.5">
                                  {p.categoryLabel}
                                </span>
                              </div>

                              <h4 className="font-serif text-base text-white font-bold mb-1 truncate">
                                {p.name}
                              </h4>
                              <p className="text-[11px] text-[#C09A58] font-sans font-bold tracking-wider uppercase mb-3">
                                {p.makerName}
                              </p>

                              <div className="flex items-center justify-between border-t border-white/10 pt-3">
                                <span className="font-serif text-sm font-semibold text-white">
                                  £{p.price.toFixed(2)}
                                </span>
                                <button
                                  onClick={(e) => handleAddToBasket(p.id, e)}
                                  className="bg-[#C09A58] text-[#062b19] hover:bg-[#FAF7F2] text-[9px] font-sans uppercase font-bold tracking-wider px-3 py-1.5 transition-colors border-none"
                                >
                                  + Basket
                                </button>
                              </div>
                            </motion.div>
                          ))}
                        </div>

                      </div>
                    );
                  })}
                </div>

              </section>

              {/* CELEBRATING THE ISLAND SECTION */}
              <section className="bg-[#FAF7F2] py-24 border-t border-[#ECE7DF] relative" id="the-island-showcase">
                <div className="max-w-7xl mx-auto px-4 sm:px-8">
                  
                  {/* Title block */}
                  <div className="text-center max-w-2xl mx-auto mb-16">
                    <span className="text-xs font-sans tracking-[0.3em] text-[#C09A58] uppercase font-bold block mb-4">
                      THE BEAUTIFUL MANX COAST & VALLEYS
                    </span>
                    <h2 className="font-serif text-4xl sm:text-6.5xl text-[#062b19] font-bold tracking-tight leading-tight mb-6">
                      Made here. <br/>Sent everywhere.
                    </h2>
                    <p className="font-sans text-sm sm:text-base text-[#1F2421]/70 leading-relaxed">
                      Deep within the Irish Sea lies an ancient island of misty hills, historic castles, and beautiful harbours. Our communities of fishermen, weavers, farmers, and artisans are proud to share their legacy with you.
                    </p>
                  </div>

                  {/* Interspersed bento grid of towns */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
                    {TOWNS.map((town, idx) => {
                      const isEven = idx % 2 === 0;
                      return (
                        <motion.div
                          key={town.name}
                          initial={{ opacity: 0, scale: 0.98, y: 20 }}
                          whileInView={{ opacity: 1, scale: 1, y: 0 }}
                          viewport={{ once: true }}
                          transition={{ duration: 0.6 }}
                          className={`flex flex-col bg-white border border-[#ECE7DF] shadow-sm hover:shadow-lg transition-all overflow-hidden ${
                            isEven ? 'md:-translate-y-4' : 'md:translate-y-4'
                          }`}
                        >
                          <div className="relative h-[280px] lg:h-[340px] overflow-hidden bg-black/10">
                            <Image 
                              src={town.image} 
                              alt={town.name} 
                              fill
                              className="object-cover hover:scale-105 transition-transform duration-700"
                              referrerPolicy="no-referrer"
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-black/10 to-transparent" />
                            <div className="absolute bottom-6 left-6">
                              <span className="text-[10px] uppercase tracking-[0.25em] text-[#C09A58] font-bold block mb-1">
                                {town.type}
                              </span>
                              <h3 className="font-serif text-2xl lg:text-3xl text-white font-bold tracking-tight">
                                {town.name}
                              </h3>
                            </div>
                          </div>
                          
                          <div className="p-6 sm:p-8">
                            <p className="text-sm text-[#1F2421]/70 leading-relaxed mb-6 font-light">
                              {town.description}
                            </p>
                            
                            {/* Filter by town's prominent makers button */}
                            <div className="border-t border-[#ECE7DF] pt-6 flex items-center justify-between">
                              <span className="text-[10px] font-sans font-bold tracking-widest text-[#062b19]/60">
                                ACTIVE PRODUCERS: {Object.values(MAKERS).filter(m => m.location.includes(town.name)).length}
                              </span>
                              
                              <button
                                onClick={() => {
                                  // Browse products for makers in this town
                                  const makersInTown = Object.values(MAKERS).filter(m => m.location.includes(town.name));
                                  if (makersInTown.length > 0) {
                                    navigateToMaker(makersInTown[0].id);
                                  } else {
                                    triggerNotification(`Visiting ${town.name} digitally`);
                                  }
                                }}
                                className="text-xs uppercase tracking-widest font-sans font-bold text-[#C09A58] hover:text-[#062b19] flex items-center space-x-1"
                              >
                                <span>Discover Makers</span>
                                <ChevronRight className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </div>
                        </motion.div>
                      );
                    })}
                  </div>

                  {/* Maker profiles quick-slide summary strip */}
                  <div className="mt-32 pt-20 border-t border-[#ECE7DF]">
                    <h3 className="font-serif text-2xl sm:text-3xl text-center text-[#062b19] font-bold mb-16">
                      Meet the Isle of Man Artisans
                    </h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                      {Object.values(MAKERS).slice(0, 3).map((maker) => (
                        <div 
                          key={maker.id}
                          onClick={() => navigateToMaker(maker.id)}
                          className="group bg-white border border-[#ECE7DF] p-6 hover:shadow-md transition-shadow cursor-pointer flex flex-col justify-between"
                        >
                          <div>
                            <div className="relative h-12 w-12 rounded-full overflow-hidden mb-6 bg-black/5 border border-[#C09A58]/20">
                              <Image 
                                src={maker.image} 
                                alt={maker.name} 
                                fill 
                                className="object-cover"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                            <h4 className="font-serif text-lg font-bold text-[#062b19] mb-1 group-hover:text-[#C09A58]">
                              {maker.name}
                            </h4>
                            <p className="text-[10px] font-sans text-gray-400 uppercase tracking-wider mb-4">
                              {maker.location}
                            </p>
                            <p className="text-xs text-[#1F2421]/60 leading-relaxed font-light line-clamp-4">
                              {maker.story}
                            </p>
                          </div>
                          
                          <span className="text-[10px] uppercase font-sans tracking-widest text-[#C09A58] font-bold block mt-6 border-t border-[#FAF7F2] pt-4 hover:underline">
                            View Artisan Story →
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                </div>
              </section>

              {/* RECENTLY VIEWED ROW */}
              {recentlyViewed.length > 0 && (
                <section className="bg-white py-16 border-t border-[#ECE7DF]" id="recently-viewed-strip">
                  <div className="max-w-7xl mx-auto px-4 sm:px-8">
                    <h3 className="font-serif text-lg sm:text-xl text-[#062b19] font-bold mb-8 tracking-tight">
                      Recently Viewed Products
                    </h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-6">
                      {recentlyViewed.map(id => {
                        const product = PRODUCTS.find(p => p.id === id);
                        if (!product) return null;
                        return (
                          <div 
                            key={id}
                            onClick={() => navigateToProduct(product.id)}
                            className="group cursor-pointer flex flex-col"
                          >
                            <div className="relative h-[160px] bg-[#FAF7F2] overflow-hidden mb-3">
                              <Image 
                                src={product.image} 
                                alt={product.name} 
                                fill
                                className="object-cover group-hover:scale-105 transition-all duration-300"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                            <h4 className="font-serif text-xs text-[#062b19] font-bold line-clamp-1 group-hover:text-[#C09A58]">
                              {product.name}
                            </h4>
                            <span className="text-xs text-[#1F2421]/60 mt-1 font-semibold font-sans">
                              £{product.price.toFixed(2)}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </section>
              )}

              {/* SHOP THE ISLAND SILLY FOOTER EMBELLISHMENT */}
              <section className="bg-[#A31D1D] text-white py-16 text-center overflow-hidden relative">
                <div className="absolute inset-0 opacity-10 font-serif text-[12vw] select-none font-bold tracking-widest pointer-events-none flex items-center justify-center">
                  ELLAN VANNIN
                </div>
                <div className="relative z-10 max-w-xl mx-auto px-4">
                  <span className="text-[10px] uppercase font-sans tracking-[0.3em] text-[#C09A58] font-bold block mb-4">
                    SHOP THE ISLAND
                  </span>
                  <h3 className="font-serif text-3xl sm:text-4xl font-bold mb-6">
                    Join Our Island Community
                  </h3>
                  <p className="text-xs sm:text-sm text-white/80 font-sans font-light leading-relaxed mb-8">
                    Receive seasonal curations, new maker announcements, and stories straight from the smokehouses and looms of the Isle of Man.
                  </p>
                  
                  {/* Mock Newsletter Join */}
                  <form onSubmit={(e) => { e.preventDefault(); triggerNotification("Subscribed successfully! Thank you."); }} className="flex flex-col sm:flex-row items-center border border-[#C09A58]/20 bg-white/5 rounded-none p-1 w-full max-w-md mx-auto">
                    <input 
                      type="email" 
                      required 
                      placeholder="Enter your email address"
                      className="bg-transparent text-white placeholder-white/40 text-xs py-3 px-4 w-full focus:outline-none"
                    />
                    <button 
                      type="submit"
                      className="w-full sm:w-auto bg-[#C09A58] text-[#062b19] uppercase tracking-wider text-[10px] font-sans font-bold px-6 py-3 shrink-0"
                    >
                      Subscribe
                    </button>
                  </form>
                </div>
              </section>

            </motion.div>
          )}

          {/* --- VIEW: PRODUCT DETAIL PAGE --- */}
          {activeView === 'product-detail' && (
            <motion.div
              key="product-detail-view"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4 }}
              className="py-12 sm:py-20"
            >
              <ProductDetailView 
                productId={selectedProductId}
                onBack={() => setActiveView('home')}
                onAddToBasket={handleAddToBasket}
                onNavigateToMaker={navigateToMaker}
                onNavigateToProduct={navigateToProduct}
                toggleFavorite={toggleFavorite}
                isFavorite={favorites.includes(selectedProductId)}
              />
            </motion.div>
          )}

          {/* --- VIEW: MAKER DETAIL PAGE --- */}
          {activeView === 'maker-detail' && (
            <motion.div
              key="maker-detail-view"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.4 }}
              className="py-12 sm:py-20"
            >
              <MakerDetailView 
                makerId={selectedMakerId}
                onBack={() => setActiveView('home')}
                onNavigateToProduct={navigateToProduct}
                onAddToBasket={handleAddToBasket}
              />
            </motion.div>
          )}

          {/* --- VIEW: CHECKOUT PAGE --- */}
          {activeView === 'checkout' && (
            <motion.div
              key="checkout-view"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0 }}
              className="py-12 sm:py-20 max-w-4xl mx-auto px-4"
            >
              <CheckoutView 
                cart={getCartItemsDetails()}
                subtotal={cartSubtotal}
                form={checkoutForm}
                setForm={setCheckoutForm}
                onSubmit={handleCheckoutSubmit}
                onBack={() => setActiveView('home')}
                orderConfirmed={orderConfirmed}
                onFinalize={finalizeCheckout}
              />
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* --- CART DRAWER PANEL (Slide out from Right) --- */}
      <AnimatePresence>
        {isCartOpen && (
          <>
            {/* Backdrop */}
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="fixed inset-0 bg-[#062b19] z-50 cursor-pointer"
            />
            
            {/* Sliding Panel */}
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed right-0 top-0 bottom-0 w-full sm:w-[480px] bg-[#FAF7F2] shadow-2xl z-50 flex flex-col justify-between overflow-hidden border-l border-[#DED8CC] bg-paper"
              id="shopping-cart-drawer"
            >
              {/* Header */}
              <div className="bg-[#062b19] text-[#FAF7F2] p-6 flex justify-between items-center border-b border-[#FAF7F2]/10">
                <div className="flex items-center space-x-2">
                  <ShoppingBag className="w-5 h-5 text-[#C09A58]" />
                  <h3 className="font-serif text-lg font-bold tracking-wider">YOUR BASKET</h3>
                  <span className="bg-[#C09A58] text-[#062b19] text-[10px] font-bold px-2 py-0.5 rounded-full font-sans">
                    {cartCount}
                  </span>
                </div>
                
                <button 
                  onClick={() => setIsCartOpen(false)}
                  className="p-1 hover:bg-[#FAF7F2]/10 rounded-full transition-colors text-white"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Items List */}
              <div className="flex-grow overflow-y-auto p-6 space-y-6">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center">
                    <ShoppingBag className="w-12 h-12 text-[#DED8CC] mb-4" />
                    <p className="font-serif text-lg text-[#062b19] font-bold">Your basket is empty</p>
                    <p className="text-xs text-[#1F2421]/60 font-sans max-w-[240px] mt-2 leading-relaxed">
                      Wander back through our digital marketplace to discover unique gifts and delicacies.
                    </p>
                    <button
                      onClick={() => setIsCartOpen(false)}
                      className="bg-[#0d422a] text-[#FAF7F2] text-xs font-sans uppercase font-bold tracking-widest px-6 py-3 mt-6 hover:bg-[#C09A58] transition-colors"
                    >
                      Continue Browsing
                    </button>
                  </div>
                ) : (
                  getCartItemsDetails().map((item) => (
                    <div 
                      key={item.id} 
                      className="flex space-x-4 border-b border-[#ECE7DF] pb-6 last:border-none"
                    >
                      <div className="relative h-20 w-20 bg-gray-100 shrink-0 select-none">
                        <Image 
                          src={item.product.image} 
                          alt={item.product.name} 
                          fill 
                          className="object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </div>
                      
                      <div className="flex-grow flex flex-col justify-between">
                        <div>
                          <h4 className="font-serif text-sm font-bold text-[#062b19] leading-snug">
                            {item.product.name}
                          </h4>
                          <span className="text-[10px] text-[#C09A58] uppercase font-bold tracking-wider">
                            {item.product.makerName}
                          </span>
                        </div>

                        <div className="flex items-center justify-between mt-2">
                          <div className="flex items-center space-x-1 border border-[#DED8CC] bg-white">
                            <button 
                              onClick={() => updateCartItemQuantity(item.id, -1)}
                              className="p-1 hover:bg-[#FAF7F2] text-gray-500"
                            >
                              <Minus className="w-3 h-3" />
                            </button>
                            <span className="text-xs font-semibold px-2 font-sans w-6 text-center select-none">
                              {item.quantity}
                            </span>
                            <button 
                              onClick={() => updateCartItemQuantity(item.id, 1)}
                              className="p-1 hover:bg-[#FAF7F2] text-gray-500"
                            >
                              <Plus className="w-3 h-3" />
                            </button>
                          </div>

                          <div className="text-right">
                            <span className="font-serif text-sm font-bold text-[#1F2421] block">
                              £{(item.product.price * item.quantity).toFixed(2)}
                            </span>
                            <button 
                              onClick={() => updateCart(cart.filter(c => c.id !== item.id))}
                              className="text-[10px] text-red-600 hover:underline mt-1 font-sans font-bold uppercase"
                            >
                              Remove
                            </button>
                          </div>
                        </div>
                      </div>

                    </div>
                  ))
                )}
              </div>

              {/* Subtotal & Action */}
              {cart.length > 0 && (
                <div className="bg-white border-t border-[#DED8CC] p-6 space-y-4 shadow-2xl">
                  {/* Traditional Tartan wrap promo info */}
                  <div className="bg-[#FAF7F2] border border-[#C09A58]/20 p-3 flex items-start space-x-3">
                    <Truck className="w-4 h-4 text-[#C09A58] shrink-0 mt-0.5" />
                    <div>
                      <p className="text-[10px] uppercase font-sans tracking-wider font-bold text-[#0d422a]">
                        Free Isle of Man & UK Shipping!
                      </p>
                      <p className="text-[10px] text-[#1F2421]/60 font-sans font-light mt-0.5">
                        Authentic wrapping with handwritten greeting included.
                      </p>
                    </div>
                  </div>

                  <div className="flex justify-between items-center border-b border-[#ECE7DF] pb-4">
                    <span className="text-sm font-sans tracking-wide uppercase font-bold text-[#1F2421]/60">
                      Subtotal
                    </span>
                    <span className="font-serif text-2xl font-bold text-[#062b19]">
                      £{cartSubtotal.toFixed(2)}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-4 pt-2">
                    <button
                      onClick={() => setIsCartOpen(false)}
                      className="border border-[#DED8CC] text-xs font-sans uppercase font-bold tracking-widest text-[#062b19] py-4 text-center hover:bg-[#ECE7DF] transition-colors"
                    >
                      Close Basket
                    </button>
                    
                    <button
                      onClick={() => {
                        setIsCartOpen(false);
                        setActiveView('checkout');
                      }}
                      className="bg-[#0d422a] hover:bg-[#C09A58] text-[#FAF7F2] text-xs font-sans uppercase font-bold tracking-widest py-4 text-center transition-colors"
                      id="checkout-trigger-btn"
                    >
                      CHECKOUT →
                    </button>
                  </div>
                </div>
              )}

            </motion.div>
          </>
        )}
      </AnimatePresence>

      {/* --- QUICK PREVIEW MODAL (Click to explore quickly) --- */}
      <AnimatePresence>
        {quickViewProduct && (
          <QuickViewModal 
            product={quickViewProduct} 
            onClose={() => setQuickViewProduct(null)} 
            onAddToBasket={handleAddToBasket}
            onExplore={() => navigateToProduct(quickViewProduct.id)}
          />
        )}
      </AnimatePresence>

      {/* --- FOOTER --- */}
      <footer className="bg-[#062b19] text-[#FAF7F2]/80 font-sans font-light text-xs border-t border-[#FAF7F2]/10 py-12 px-6 sm:px-12" id="main-footer">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-[#A31D1D] rounded-full flex items-center justify-center border border-[#C09A58]/20 shadow-inner">
                <span className="text-white font-serif text-sm font-bold select-none tracking-tighter">𐃏</span>
              </div>
              <h4 className="font-serif text-md font-bold tracking-wider text-white">ISLE OF MAN MARKET</h4>
            </div>
            <p className="text-[11px] text-[#FAF7F2]/60 leading-relaxed font-light">
              Ellan Vannin - The Isle of Man, curated in one beautiful contemporary marketplace. Discover our independent luxury makers, food, craft, and fashion.
            </p>
          </div>

          <div>
            <h5 className="font-serif text-sm font-bold text-[#C09A58] uppercase tracking-wider mb-4">Discover</h5>
            <ul className="space-y-2 text-[11px]">
              <li><button onClick={() => { setSelectedCategory('food-drink'); scrollToMarket(); }} className="hover:text-white transition-colors cursor-pointer">Food & Drink Pantry</button></li>
              <li><button onClick={() => { setSelectedCategory('craft-design'); scrollToMarket(); }} className="hover:text-white transition-colors cursor-pointer">Crafts & Design Gallery</button></li>
              <li><button onClick={() => { setSelectedCategory('fashion'); scrollToMarket(); }} className="hover:text-white transition-colors cursor-pointer">Manx Wool Apparel</button></li>
              <li><button onClick={() => { setSelectedCategory('home-living'); scrollToMarket(); }} className="hover:text-white transition-colors cursor-pointer">Heritage Home Living</button></li>
            </ul>
          </div>

          <div>
            <h5 className="font-serif text-sm font-bold text-[#C09A58] uppercase tracking-wider mb-4">Makers & Towns</h5>
            <ul className="space-y-2 text-[11px]">
              <li><button onClick={() => navigateToMaker('laxey-woollen')} className="hover:text-white transition-colors cursor-pointer">Laxey Woollen Mills</button></li>
              <li><button onClick={() => navigateToMaker('fynoderee')} className="hover:text-white transition-colors cursor-pointer">The Fynoderee Distillery</button></li>
              <li><button onClick={() => navigateToMaker('devereaus')} className="hover:text-white transition-colors cursor-pointer">Devereau&apos;s Kippers (Peel)</button></li>
              <li><button onClick={() => { setActiveView('home'); setTimeout(() => document.getElementById('the-island-showcase')?.scrollIntoView({behavior:'smooth'}), 100); }} className="hover:text-white transition-colors cursor-pointer">Castletown & Ramsey Shops</button></li>
            </ul>
          </div>

          <div>
            <h5 className="font-serif text-sm font-bold text-[#C09A58] uppercase tracking-wider mb-4">Contact & Support</h5>
            <p className="text-[11px] text-[#FAF7F2]/60 mb-2 font-light">
              Have questions about Manx shipping or bulk hampers?
            </p>
            <p className="text-[11px] text-white font-semibold font-sans">
              support@isleofmanmarket.com
            </p>
            <div className="flex space-x-3 mt-4 text-[10px] text-[#C09A58] font-bold tracking-widest uppercase">
              <span>Douglas Quay, IOM</span>
            </div>
          </div>

        </div>

        <div className="max-w-7xl mx-auto border-t border-[#FAF7F2]/10 pt-8 flex flex-col sm:flex-row justify-between items-center text-[10px] text-[#FAF7F2]/40 font-sans tracking-wider">
          <p>© 2026 Isle of Man Market. Co-operative of Manx Producers. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 sm:mt-0">
            <span className="hover:text-white cursor-pointer transition-colors">Privacy Policy</span>
            <span className="hover:text-white cursor-pointer transition-colors">Terms of Trade</span>
            <span className="hover:text-white cursor-pointer transition-colors">Shipping & Returns</span>
          </div>
        </div>
      </footer>

    </div>
  );
}

// --- SUB-ELEMENT: FLYING IMAGE TO CART EFFECT ---
function FlyAnimationElement({ item, onComplete }: { item: FlyItem; onComplete: (id: number) => void }) {
  const [targetPos, setTargetPos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    // Find shopping cart coordinate or default to top right
    const cartEl = document.getElementById('cart-btn');
    let xValue = window.innerWidth - 80 - item.startX;
    let yValue = 40 - item.startY;

    if (cartEl) {
      const rect = cartEl.getBoundingClientRect();
      const targetX = rect.left + rect.width / 2;
      const targetY = rect.top + rect.height / 2;
      xValue = targetX - item.startX;
      yValue = targetY - item.startY;
    }

    // Set state deferred to prevent synchronous setState inside effect warning
    const posTimer = setTimeout(() => {
      setTargetPos({ x: xValue, y: yValue });
    }, 0);

    const completeTimer = setTimeout(() => {
      onComplete(item.id);
    }, 800);

    return () => {
      clearTimeout(posTimer);
      clearTimeout(completeTimer);
    };
  }, [item, onComplete]);

  return (
    <div 
      className="fixed pointer-events-none z-50 select-none animate-fly"
      style={{
        left: item.startX - 24,
        top: item.startY - 24,
        width: 48,
        height: 48,
        '--target-x': `${targetPos.x}px`,
        '--target-y': `${targetPos.y}px`
      } as React.CSSProperties}
    >
      <div className="relative w-full h-full rounded-full overflow-hidden border-2 border-[#C09A58] shadow-lg bg-white">
        <Image src={item.src} alt="flying product" fill className="object-cover" referrerPolicy="no-referrer" />
      </div>
    </div>
  );
}

// --- SUB-VIEW: PRODUCT DETAIL PAGE COMPONENT ---
function ProductDetailView({ 
  productId, 
  onBack, 
  onAddToBasket, 
  onNavigateToMaker, 
  onNavigateToProduct,
  toggleFavorite,
  isFavorite
}: { 
  productId: string; 
  onBack: () => void; 
  onAddToBasket: (productId: string, event: React.MouseEvent) => void;
  onNavigateToMaker: (makerId: string) => void;
  onNavigateToProduct: (productId: string) => void;
  toggleFavorite: (productId: string) => void;
  isFavorite: boolean;
}) {
  const product = PRODUCTS.find(p => p.id === productId);
  const [quantity, setQuantity] = useState<number>(1);

  if (!product) {
    return (
      <div className="text-center py-24">
        <p className="font-serif text-xl text-[#062b19] font-bold">Product not found</p>
        <button onClick={onBack} className="text-[#C09A58] underline text-sm mt-4 font-sans font-semibold">
          Return to Market
        </button>
      </div>
    );
  }

  const maker = MAKERS[product.makerId];
  const relatedProducts = PRODUCTS.filter(p => p.category === product.category && p.id !== product.id).slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8">
      {/* Back button */}
      <button 
        onClick={onBack}
        className="group flex items-center space-x-2 text-xs uppercase tracking-widest font-sans font-bold text-[#062b19] mb-12 hover:text-[#C09A58] transition-colors"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        <span>Return to Marketplace</span>
      </button>

      {/* Main Editorial Split Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 mb-24">
        
        {/* Massive Product Image Column */}
        <div className="space-y-6">
          <div className="relative h-[480px] sm:h-[600px] lg:h-[700px] bg-white border border-[#ECE7DF] shadow-sm overflow-hidden select-none">
            <Image 
              src={product.image} 
              alt={product.name} 
              fill
              priority
              className="object-cover"
              referrerPolicy="no-referrer"
            />
            
            {/* Save Bookmark absolute badge */}
            <button
              onClick={() => toggleFavorite(product.id)}
              className="absolute top-6 right-6 z-10 p-3 bg-white/95 rounded-full text-[#1F2421] hover:text-[#A31D1D] hover:scale-105 shadow-md transition-all"
            >
              <Heart className={`w-5 h-5 ${isFavorite ? 'fill-[#A31D1D] text-[#A31D1D]' : ''}`} />
            </button>
            
            {/* Subtle vintage stamp or branding overlays */}
            <div className="absolute bottom-6 left-6 bg-[#062b19]/90 text-white text-[10px] uppercase font-sans tracking-[0.25em] font-bold px-4 py-2 border border-[#C09A58]/25 backdrop-blur-sm">
              Authentic Ellan Vannin
            </div>
          </div>
          
          {/* Small details checklist / specifications strip */}
          <div className="bg-white border border-[#ECE7DF] p-6 space-y-4">
            <h4 className="font-serif text-sm font-bold text-[#062b19] uppercase tracking-wider">
              Product Integrity Specifications
            </h4>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {product.details.map((detail, idx) => (
                <li key={idx} className="flex items-start space-x-2 text-xs text-[#1F2421]/70 font-sans font-light">
                  <Check className="w-3.5 h-3.5 text-[#C09A58] shrink-0 mt-0.5" />
                  <span>{detail}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Product Details Specs Column */}
        <div className="flex flex-col justify-between py-2">
          <div>
            {/* Category / Maker Anchor info */}
            <div className="flex items-center space-x-2 mb-4 border-b border-[#ECE7DF] pb-4">
              <span className="text-xs uppercase font-sans tracking-widest text-[#C09A58] font-bold">
                {product.categoryLabel}
              </span>
              <span className="w-1.5 h-1.5 rounded-full bg-[#C09A58]/40" />
              <button 
                onClick={() => onNavigateToMaker(product.makerId)}
                className="text-xs uppercase font-sans tracking-widest text-[#062b19] hover:underline font-bold"
              >
                {product.makerName}
              </button>
            </div>

            {/* Title */}
            <h1 className="font-serif text-3xl sm:text-5xl text-[#062b19] font-bold tracking-tight mb-4 leading-tight">
              {product.name}
            </h1>

            {/* Price */}
            <p className="font-serif text-2xl sm:text-3.5xl font-bold text-[#1F2421] mb-6">
              £{product.price.toFixed(2)}
            </p>

            {/* Detailed Description */}
            <div className="text-sm sm:text-base text-[#1F2421]/85 font-sans font-light leading-relaxed mb-8 whitespace-pre-line border-t border-[#ECE7DF] pt-6">
              {product.description}
            </div>

            {/* Quantity Selector & Shopping controls block */}
            <div className="bg-white border border-[#ECE7DF] p-6 space-y-6 mb-8">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase font-sans tracking-widest text-[#1F2421]/60 font-bold">
                  Purchase Quantity
                </span>
                
                <div className="flex items-center space-x-2 border border-[#DED8CC] bg-[#FAF7F2] p-1">
                  <button 
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="p-1.5 hover:bg-white text-gray-500 rounded-none"
                  >
                    <Minus className="w-4 h-4" />
                  </button>
                  <span className="text-sm font-bold font-sans w-10 text-center select-none">
                    {quantity}
                  </span>
                  <button 
                    onClick={() => setQuantity(quantity + 1)}
                    className="p-1.5 hover:bg-white text-gray-500 rounded-none"
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Add to Basket Action */}
              <button
                onClick={(e) => {
                  // Simulate multi-qty add by repeating or handle state increase
                  onAddToBasket(product.id, e);
                  // Optional support: multiply quantity inside basket triggers
                }}
                className="w-full bg-[#0d422a] hover:bg-[#C09A58] text-[#FAF7F2] text-xs font-sans font-bold uppercase tracking-widest py-4 text-center shadow-md transition-colors"
              >
                ADD TO BASKET • £{(product.price * quantity).toFixed(2)}
              </button>
            </div>

            {/* Quick trust metrics */}
            <div className="grid grid-cols-3 gap-4 border-y border-[#ECE7DF] py-4 text-center">
              <div>
                <p className="text-[10px] uppercase tracking-wider font-bold text-[#C09A58]">Origin</p>
                <p className="text-[10px] text-gray-500 font-light mt-0.5">Isle of Man</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider font-bold text-[#C09A58]">Shipping</p>
                <p className="text-[10px] text-gray-500 font-light mt-0.5">Next Day Dispatch</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-wider font-bold text-[#C09A58]">Support</p>
                <p className="text-[10px] text-gray-500 font-light mt-0.5">100% Secure Checkout</p>
              </div>
            </div>

          </div>

          {/* Maker Brief Profile link card */}
          {maker && (
            <div className="bg-[#ECE7DF] p-6 border border-[#DED8CC] mt-10">
              <div className="flex items-center space-x-4 mb-3">
                <div className="relative h-12 w-12 rounded-full overflow-hidden border border-[#C09A58]/20 bg-white">
                  <Image src={maker.image} alt={maker.name} fill className="object-cover" referrerPolicy="no-referrer" />
                </div>
                <div>
                  <h4 className="font-serif text-sm font-bold text-[#062b19]">
                    Artisan: {maker.name}
                  </h4>
                  <p className="text-[9px] uppercase font-sans tracking-wider text-[#C09A58] font-bold">
                    {maker.location}
                  </p>
                </div>
              </div>
              <p className="text-xs text-[#1F2421]/70 leading-relaxed font-light line-clamp-3">
                {maker.story}
              </p>
              <button 
                onClick={() => onNavigateToMaker(maker.id)}
                className="text-[10px] font-sans font-bold uppercase tracking-wider text-[#A31D1D] hover:underline mt-4 block"
              >
                Read Maker Profile & Browse Workshop →
              </button>
            </div>
          )}

        </div>
      </div>

      {/* Related Products strip */}
      {relatedProducts.length > 0 && (
        <div className="border-t border-[#ECE7DF] pt-16 mb-12">
          <h3 className="font-serif text-2xl text-[#062b19] font-bold mb-8">
            You May Also Enjoy
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            {relatedProducts.map(p => (
              <div 
                key={p.id}
                onClick={() => onNavigateToProduct(p.id)}
                className="group cursor-pointer bg-white border border-[#ECE7DF] p-4 hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div className="relative h-[200px] bg-[#FAF7F2] overflow-hidden mb-4 select-none">
                  <Image src={p.image} alt={p.name} fill className="object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
                </div>
                <div>
                  <p className="text-[9px] text-[#C09A58] uppercase font-bold tracking-wider mb-1">
                    {p.makerName}
                  </p>
                  <h4 className="font-serif text-base text-[#062b19] font-bold mb-3 group-hover:text-[#A31D1D]">
                    {p.name}
                  </h4>
                </div>
                <div className="flex items-center justify-between border-t border-[#FAF7F2] pt-3 mt-2">
                  <span className="font-serif text-sm font-bold">
                    £{p.price.toFixed(2)}
                  </span>
                  <span className="text-[10px] font-sans font-bold uppercase tracking-widest text-[#062b19] group-hover:text-[#C09A58]">
                    Explore →
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
}

// --- SUB-VIEW: MAKER DETAIL VIEW COMPONENT ---
function MakerDetailView({
  makerId,
  onBack,
  onNavigateToProduct,
  onAddToBasket
}: {
  makerId: string;
  onBack: () => void;
  onNavigateToProduct: (productId: string) => void;
  onAddToBasket: (productId: string, event: React.MouseEvent) => void;
}) {
  const maker = MAKERS[makerId];

  if (!maker) {
    return (
      <div className="text-center py-24">
        <p className="font-serif text-xl text-[#062b19] font-bold">Maker not found</p>
        <button onClick={onBack} className="text-[#C09A58] underline text-sm mt-4 font-sans font-semibold">
          Return to Market
        </button>
      </div>
    );
  }

  // Filter products by maker
  const makerProducts = PRODUCTS.filter(p => p.makerId === makerId);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-8">
      {/* Back button */}
      <button 
        onClick={onBack}
        className="group flex items-center space-x-2 text-xs uppercase tracking-widest font-sans font-bold text-[#062b19] mb-12 hover:text-[#C09A58] transition-colors"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        <span>Return to Marketplace</span>
      </button>

      {/* Maker Profile Header */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 border-b border-[#ECE7DF] pb-16 mb-16">
        
        {/* Profile Image & Specs */}
        <div className="space-y-6">
          <div className="relative h-[320px] bg-white border border-[#ECE7DF] shadow-sm overflow-hidden select-none">
            <Image src={maker.image} alt={maker.name} fill className="object-cover" referrerPolicy="no-referrer" />
          </div>
          
          <div className="bg-[#ECE7DF] p-6 space-y-4">
            <h4 className="font-serif text-sm font-bold text-[#0d422a] uppercase tracking-wider">
              Artisan Profile Details
            </h4>
            <div className="space-y-2 text-xs font-sans text-[#1F2421]/80">
              <p><strong>Town/Location:</strong> {maker.location}</p>
              <p><strong>Primary Specialty:</strong> {maker.specialty}</p>
              <p><strong>Certified Manx Guild:</strong> Yes (Standard of authenticity)</p>
              <p><strong>Direct Shipping:</strong> Yes (Packaged fresh from workshop)</p>
            </div>
          </div>
        </div>

        {/* Story details (2 columns-wide on desktop) */}
        <div className="lg:col-span-2 flex flex-col justify-between py-2">
          <div>
            <div className="flex items-center space-x-2 mb-3">
              <MapPin className="w-4 h-4 text-[#C09A58]" />
              <span className="text-xs uppercase font-sans tracking-[0.25em] text-[#C09A58] font-bold">
                ISLE OF MAN INDEPENDENT ARTISAN
              </span>
            </div>
            
            <h1 className="font-serif text-3xl sm:text-5xl text-[#062b19] font-bold tracking-tight mb-6 leading-tight">
              {maker.name}
            </h1>

            <div className="text-sm sm:text-base text-[#1F2421]/80 font-sans font-light leading-relaxed space-y-4">
              <p>
                {maker.story}
              </p>
              <p>
                Every single item created by {maker.name} undergoes careful quality verification on the island. By purchasing from their workshop, you are helping to preserve hundreds of years of Manx family craftsmanship, weaving traditions, and wild maritime recipes.
              </p>
            </div>
          </div>

          <div className="border-t border-[#ECE7DF] pt-8 mt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-center sm:text-left">
              <p className="text-xs font-bold text-[#062b19]">PRESERVING ISLAND HERITAGE</p>
              <p className="text-[10px] text-[#1F2421]/60 font-sans mt-0.5">Sourced ethically from local suppliers and farms.</p>
            </div>
            <button
              onClick={() => {
                const el = document.getElementById('maker-catalog-grid');
                if (el) el.scrollIntoView({ behavior: 'smooth' });
              }}
              className="bg-[#0d422a] text-[#FAF7F2] text-xs font-sans uppercase font-bold tracking-widest px-6 py-3.5"
            >
              BROWSE WORKSHOP CATALOG ({makerProducts.length})
            </button>
          </div>
        </div>

      </div>

      {/* Maker's catalog list */}
      <div id="maker-catalog-grid" className="pt-8 mb-16">
        <h2 className="font-serif text-2xl sm:text-3xl text-[#062b19] font-bold mb-10 tracking-tight text-center lg:text-left">
          Products crafted by {maker.name}
        </h2>

        {makerProducts.length === 0 ? (
          <p className="text-center text-sm text-[#1F2421]/60 py-12 font-sans">
            No products uploaded for this maker yet.
          </p>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            {makerProducts.map(p => (
              <div 
                key={p.id}
                onClick={() => onNavigateToProduct(p.id)}
                className="group cursor-pointer bg-white border border-[#ECE7DF] p-4 hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div className="relative h-[240px] bg-[#FAF7F2] overflow-hidden mb-4 select-none">
                  <Image src={p.image} alt={p.name} fill className="object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
                </div>
                
                <div>
                  <p className="text-[10px] text-[#C09A58] uppercase font-bold tracking-wider mb-1">
                    {p.categoryLabel}
                  </p>
                  <h3 className="font-serif text-base sm:text-lg text-[#062b19] font-bold mb-3 group-hover:text-[#A31D1D]">
                    {p.name}
                  </h3>
                </div>

                <div className="flex items-center justify-between border-t border-[#FAF7F2] pt-4 mt-2">
                  <span className="font-serif text-base font-bold">
                    £{p.price.toFixed(2)}
                  </span>
                  <button
                    onClick={(e) => onAddToBasket(p.id, e)}
                    className="bg-[#0d422a] hover:bg-[#C09A58] text-[9px] font-sans font-bold uppercase tracking-widest px-3 py-1.5 text-white border-none"
                  >
                    + Basket
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}

// --- SUB-VIEW: CHECKOUT INTERFACE & ORDER SUCCESS ---
function CheckoutView({
  cart,
  subtotal,
  form,
  setForm,
  onSubmit,
  onBack,
  orderConfirmed,
  onFinalize
}: {
  cart: any[];
  subtotal: number;
  form: any;
  setForm: any;
  onSubmit: (e: React.FormEvent) => void;
  onBack: () => void;
  orderConfirmed: boolean;
  onFinalize: () => void;
}) {
  const deliveryCost = form.shippingOption === 'express' ? 4.95 : 0;
  const total = subtotal + deliveryCost;

  if (orderConfirmed) {
    return (
      <div className="bg-white border border-[#ECE7DF] p-8 sm:p-12 text-center shadow-xl max-w-2xl mx-auto" id="order-success-receipt">
        <div className="w-16 h-16 bg-[#0d422a] text-[#FAF7F2] rounded-full flex items-center justify-center mx-auto mb-6 shadow-inner">
          <Check className="w-8 h-8" />
        </div>
        
        <span className="text-xs uppercase tracking-widest font-sans font-bold text-[#C09A58] block mb-2">
          ELLAN VANNIN ORDER CONFIRMED
        </span>
        <h2 className="font-serif text-3xl sm:text-4xl text-[#062b19] font-bold tracking-tight mb-4 leading-tight">
          Thank you for supporting local Manx artisans!
        </h2>
        <p className="text-sm text-[#1F2421]/70 font-sans leading-relaxed max-w-md mx-auto mb-10 font-light">
          Your order has been recorded in our mock database. A digital packing slip was sent to <strong className="text-black font-semibold">{form.email}</strong>, and our producers in Peel, Ramsey, and Laxey have been notified to package your authentic items.
        </p>

        {/* Receipt summary card */}
        <div className="bg-[#FAF7F2] border border-[#DED8CC] p-6 text-left space-y-4 mb-10">
          <h3 className="font-serif text-md font-bold text-[#062b19] uppercase tracking-wider border-b border-[#ECE7DF] pb-3">
            Digital Order Summary
          </h3>
          <div className="space-y-2 max-h-48 overflow-y-auto">
            {cart.map((item: any) => (
              <div key={item.id} className="flex justify-between items-center text-xs">
                <span className="font-medium text-gray-800">{item.product.name} (x{item.quantity})</span>
                <span className="font-serif font-bold">£{(item.product.price * item.quantity).toFixed(2)}</span>
              </div>
            ))}
          </div>
          
          <div className="border-t border-[#ECE7DF] pt-4 text-xs space-y-1.5">
            <div className="flex justify-between text-gray-500">
              <span>Delivery Location:</span>
              <span className="font-medium">{form.address}, {form.town}</span>
            </div>
            <div className="flex justify-between text-gray-500">
              <span>Shipping Tier:</span>
              <span className="font-medium uppercase tracking-wider">{form.shippingOption === 'express' ? 'Express Delivery' : 'Standard Delivery'}</span>
            </div>
            <div className="flex justify-between font-serif font-bold text-sm text-[#062b19] border-t border-dashed border-[#ECE7DF] pt-3">
              <span>Total Paid Amount:</span>
              <span>£{total.toFixed(2)}</span>
            </div>
          </div>
        </div>

        <button
          onClick={onFinalize}
          className="w-full bg-[#0d422a] hover:bg-[#C09A58] text-white text-xs font-sans uppercase font-bold tracking-widest py-4 text-center transition-colors shadow-lg"
        >
          FINALIZE & CONTINUE SHOPPING
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white border border-[#ECE7DF] p-6 sm:p-10 shadow-lg">
      <div className="flex justify-between items-center border-b border-[#ECE7DF] pb-6 mb-8">
        <div>
          <span className="text-xs uppercase font-sans tracking-widest text-[#C09A58] font-bold block mb-1">
            SECURE CHECKOUT
          </span>
          <h2 className="font-serif text-2xl sm:text-3.5xl text-[#062b19] font-bold">
            Complete your order
          </h2>
        </div>
        <button 
          onClick={onBack}
          className="text-xs uppercase tracking-widest font-sans font-bold text-[#A31D1D] hover:underline"
        >
          Cancel
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-12">
        {/* Checkout Form */}
        <form onSubmit={onSubmit} className="lg:col-span-3 space-y-8" id="checkout-form">
          
          {/* Customer Info */}
          <div className="space-y-4">
            <h3 className="font-serif text-base font-bold text-[#062b19] uppercase tracking-wider border-b border-[#ECE7DF] pb-2">
              1. Contact Information
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">First name</label>
                <input 
                  type="text" 
                  required
                  value={form.firstName}
                  onChange={(e) => setForm({ ...form, firstName: e.target.value })}
                  className="w-full border border-[#DED8CC] px-4 py-2.5 text-xs font-sans bg-[#FAF7F2] focus:outline-none focus:border-[#C09A58]" 
                />
              </div>
              <div>
                <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">Last name</label>
                <input 
                  type="text" 
                  required
                  value={form.lastName}
                  onChange={(e) => setForm({ ...form, lastName: e.target.value })}
                  className="w-full border border-[#DED8CC] px-4 py-2.5 text-xs font-sans bg-[#FAF7F2] focus:outline-none focus:border-[#C09A58]" 
                />
              </div>
            </div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">Email address</label>
                <input 
                  type="email" 
                  required
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full border border-[#DED8CC] px-4 py-2.5 text-xs font-sans bg-[#FAF7F2] focus:outline-none focus:border-[#C09A58]" 
                />
              </div>
              <div>
                <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">Phone number</label>
                <input 
                  type="tel" 
                  required
                  value={form.phone}
                  onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  className="w-full border border-[#DED8CC] px-4 py-2.5 text-xs font-sans bg-[#FAF7F2] focus:outline-none focus:border-[#C09A58]" 
                />
              </div>
            </div>
          </div>

          {/* Shipping Info */}
          <div className="space-y-4">
            <h3 className="font-serif text-base font-bold text-[#062b19] uppercase tracking-wider border-b border-[#ECE7DF] pb-2">
              2. Delivery Address
            </h3>
            <div>
              <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">Street address</label>
              <input 
                type="text" 
                required
                placeholder="Apartment, house name, suite, unit..."
                value={form.address}
                onChange={(e) => setForm({ ...form, address: e.target.value })}
                className="w-full border border-[#DED8CC] px-4 py-2.5 text-xs font-sans bg-[#FAF7F2] focus:outline-none focus:border-[#C09A58]" 
              />
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">Manx Town / Parish</label>
                <select 
                  value={form.town}
                  onChange={(e) => setForm({ ...form, town: e.target.value })}
                  className="w-full border border-[#DED8CC] px-4 py-2.5 text-xs font-sans bg-[#FAF7F2] focus:outline-none focus:border-[#C09A58]" 
                >
                  <option value="Douglas">Douglas (Capital)</option>
                  <option value="Peel">Peel (West)</option>
                  <option value="Ramsey">Ramsey (North)</option>
                  <option value="Castletown">Castletown (South)</option>
                  <option value="Laxey">Laxey</option>
                  <option value="Port Erin">Port Erin</option>
                  <option value="UK Mainland">United Kingdom (Mainland)</option>
                  <option value="Ireland">Republic of Ireland</option>
                </select>
              </div>
              
              <div>
                <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">Postcode / Zip</label>
                <input 
                  type="text" 
                  required
                  placeholder="IM1 1AA"
                  value={form.postcode}
                  onChange={(e) => setForm({ ...form, postcode: e.target.value })}
                  className="w-full border border-[#DED8CC] px-4 py-2.5 text-xs font-sans bg-[#FAF7F2] focus:outline-none focus:border-[#C09A58]" 
                />
              </div>
            </div>

            {/* Gift Options */}
            <div className="bg-[#FAF7F2] border border-[#ECE7DF] p-4 space-y-3 mt-4">
              <label className="flex items-center space-x-2.5 cursor-pointer select-none text-xs text-[#062b19] font-bold">
                <input 
                  type="checkbox"
                  checked={form.giftWrap}
                  onChange={(e) => setForm({ ...form, giftWrap: e.target.checked })}
                  className="accent-[#0d422a] w-4 h-4"
                />
                <span>Add Free Traditional Tartan Gift Wrapping</span>
              </label>
              
              {form.giftWrap && (
                <div className="space-y-1.5">
                  <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">Handwritten Card Message (Optional)</label>
                  <textarea 
                    rows={2}
                    placeholder="We will write your greetings on an authentic local postcard..."
                    value={form.giftMessage}
                    onChange={(e) => setForm({ ...form, giftMessage: e.target.value })}
                    className="w-full border border-[#DED8CC] p-3 text-xs font-sans bg-white focus:outline-none"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Payment Method */}
          <div className="space-y-4">
            <h3 className="font-serif text-base font-bold text-[#062b19] uppercase tracking-wider border-b border-[#ECE7DF] pb-2">
              3. Payment Information
            </h3>
            
            <div>
              <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">Name on card</label>
              <input 
                type="text" 
                required
                value={form.cardName}
                onChange={(e) => setForm({ ...form, cardName: e.target.value })}
                className="w-full border border-[#DED8CC] px-4 py-2.5 text-xs font-sans bg-[#FAF7F2] focus:outline-none focus:border-[#C09A58]" 
              />
            </div>

            <div>
              <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">Card number</label>
              <div className="relative">
                <input 
                  type="text" 
                  required
                  placeholder="4000 1234 5678 9010"
                  value={form.cardNumber}
                  onChange={(e) => setForm({ ...form, cardNumber: e.target.value })}
                  className="w-full border border-[#DED8CC] pl-10 pr-4 py-2.5 text-xs font-sans bg-[#FAF7F2] focus:outline-none focus:border-[#C09A58]" 
                />
                <CreditCard className="w-4 h-4 text-gray-400 absolute left-3 top-3" />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">Expiry date</label>
                <input 
                  type="text" 
                  required
                  placeholder="MM/YY"
                  value={form.cardExpiry}
                  onChange={(e) => setForm({ ...form, cardExpiry: e.target.value })}
                  className="w-full border border-[#DED8CC] px-4 py-2.5 text-xs font-sans bg-[#FAF7F2] focus:outline-none focus:border-[#C09A58]" 
                />
              </div>
              <div>
                <label className="block text-[10px] uppercase font-sans tracking-wider font-bold text-gray-500 mb-1">CVC / Security Code</label>
                <input 
                  type="text" 
                  required
                  placeholder="123"
                  value={form.cardCvc}
                  onChange={(e) => setForm({ ...form, cardCvc: e.target.value })}
                  className="w-full border border-[#DED8CC] px-4 py-2.5 text-xs font-sans bg-[#FAF7F2] focus:outline-none focus:border-[#C09A58]" 
                />
              </div>
            </div>
          </div>

          <button
            type="submit"
            className="w-full bg-[#0d422a] hover:bg-[#C09A58] text-[#FAF7F2] text-xs font-sans uppercase font-bold tracking-widest py-4 text-center shadow-lg transition-colors border-none cursor-pointer"
          >
            AUTHORIZE SECURE ORDER • £{total.toFixed(2)}
          </button>

        </form>

        {/* Order review Column */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-[#FAF7F2] border border-[#DED8CC] p-6 space-y-6 shadow-inner">
            <h3 className="font-serif text-base font-bold text-[#062b19] uppercase tracking-wider border-b border-[#ECE7DF] pb-2">
              Review Basket Items
            </h3>
            
            {cart.length === 0 ? (
              <p className="text-xs text-[#1F2421]/60 font-sans">No items in cart.</p>
            ) : (
              <div className="space-y-4 max-h-[300px] overflow-y-auto pr-2">
                {cart.map((item) => (
                  <div key={item.id} className="flex space-x-3 text-xs items-start">
                    <div className="relative h-12 w-12 bg-gray-100 shrink-0 select-none">
                      <Image src={item.product.image} alt={item.product.name} fill className="object-cover" referrerPolicy="no-referrer" />
                    </div>
                    <div className="flex-grow">
                      <h4 className="font-serif text-xs font-bold text-[#062b19] line-clamp-1">{item.product.name}</h4>
                      <p className="text-[10px] text-gray-500">Qty: {item.quantity} • {item.product.makerName}</p>
                    </div>
                    <span className="font-serif font-bold text-gray-800">£{(item.product.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
            )}

            {/* Delivery Tiers */}
            <div className="border-t border-[#ECE7DF] pt-4 space-y-3">
              <span className="text-[10px] uppercase font-sans tracking-wider font-bold text-gray-400 block">
                Shipping Options
              </span>
              
              <label className="flex items-center justify-between p-3 border border-[#DED8CC] bg-white cursor-pointer hover:border-[#C09A58]">
                <div className="flex items-center space-x-3">
                  <input 
                    type="radio"
                    name="shippingOption"
                    value="standard"
                    checked={form.shippingOption === 'standard'}
                    onChange={() => setForm({ ...form, shippingOption: 'standard' })}
                    className="accent-[#0d422a]"
                  />
                  <div>
                    <span className="text-xs font-bold text-[#1F2421]">Standard Maritime Shipping</span>
                    <p className="text-[9px] text-gray-400">Arrives in 3-5 days via Steam Packet</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-[#0d422a]">FREE</span>
              </label>

              <label className="flex items-center justify-between p-3 border border-[#DED8CC] bg-white cursor-pointer hover:border-[#C09A58]">
                <div className="flex items-center space-x-3">
                  <input 
                    type="radio"
                    name="shippingOption"
                    value="express"
                    checked={form.shippingOption === 'express'}
                    onChange={() => setForm({ ...form, shippingOption: 'express' })}
                    className="accent-[#0d422a]"
                  />
                  <div>
                    <span className="text-xs font-bold text-[#1F2421]">Express Premium Dispatch</span>
                    <p className="text-[9px] text-gray-400">Next-day flight shipping to UK/IOM</p>
                  </div>
                </div>
                <span className="text-xs font-bold text-[#1F2421]">£4.95</span>
              </label>
            </div>

            {/* Bill Summary */}
            <div className="border-t border-[#ECE7DF] pt-4 space-y-2 text-xs">
              <div className="flex justify-between text-gray-500">
                <span>Items Subtotal:</span>
                <span className="font-semibold text-gray-800">£{subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-500">
                <span>Shipping Fee:</span>
                <span className="font-semibold text-gray-800">£{deliveryCost.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-500">
                <span>Tartan Gift Wrapping:</span>
                <span className="font-semibold text-gray-800">FREE</span>
              </div>
              <div className="flex justify-between font-serif font-bold text-sm text-[#062b19] border-t border-dashed border-[#ECE7DF] pt-4">
                <span>Final Bill Amount:</span>
                <span>£{total.toFixed(2)}</span>
              </div>
            </div>

          </div>
        </div>
      </div>

    </div>
  );
}

// --- SUB-VIEW: PRODUCT QUICK PREVIEW MODAL ---
function QuickViewModal({ 
  product, 
  onClose, 
  onAddToBasket, 
  onExplore 
}: { 
  product: Product; 
  onClose: () => void; 
  onAddToBasket: (productId: string, event: React.MouseEvent) => void;
  onExplore: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop with elegant fade in */}
      <motion.div 
        initial={{ opacity: 0 }}
        animate={{ opacity: 0.6 }}
        exit={{ opacity: 0 }}
        onClick={onClose}
        className="absolute inset-0 bg-[#062b19] cursor-pointer"
      />

      {/* Modal Card with spring zoom */}
      <motion.div 
        initial={{ opacity: 0, scale: 0.9, y: 30 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        transition={{ type: 'spring', damping: 25, stiffness: 220 }}
        className="relative bg-[#FAF7F2] w-full max-w-3xl overflow-hidden border border-[#C09A58]/20 shadow-2xl flex flex-col md:flex-row bg-paper z-10"
        id={`quickview-modal-${product.id}`}
      >
        {/* Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 z-20 p-2 bg-white/90 text-[#062b19] hover:bg-[#A31D1D] hover:text-white rounded-full shadow-md transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Product Image Panel */}
        <div className="relative w-full md:w-1/2 h-[280px] md:h-[450px] bg-[#FAF7F2] select-none">
          <Image 
            src={product.image} 
            alt={product.name} 
            fill
            className="object-cover"
            referrerPolicy="no-referrer"
          />
          <span className="absolute top-4 left-4 bg-white/95 text-[#0d422a] text-[8px] uppercase tracking-widest font-sans font-bold px-3 py-1 border border-[#C09A58]/15">
            {product.categoryLabel}
          </span>
        </div>

        {/* Product Specs Detail Panel */}
        <div className="w-full md:w-1/2 p-6 sm:p-8 flex flex-col justify-between">
          <div>
            <div className="flex items-center space-x-1.5 mb-2">
              <MapPin className="w-3.5 h-3.5 text-[#C09A58]" />
              <span className="text-[9px] uppercase tracking-widest font-sans font-bold text-[#C09A58]">
                {product.makerName}
              </span>
            </div>

            <h3 className="font-serif text-xl sm:text-2xl text-[#062b19] font-bold tracking-tight mb-3">
              {product.name}
            </h3>

            <p className="font-serif text-lg font-bold text-[#1F2421] mb-4">
              £{product.price.toFixed(2)}
            </p>

            <p className="text-xs text-[#1F2421]/70 leading-relaxed font-light font-sans mb-6 line-clamp-4">
              {product.description}
            </p>

            {/* Micro rating strip */}
            <div className="flex items-center space-x-1 border-t border-[#ECE7DF] pt-4">
              <span className="text-[10px] font-sans text-gray-500 font-bold uppercase tracking-wider">Arrives:</span>
              <span className="text-[10px] text-emerald-700 font-semibold font-sans">Wrapped in Tartan Paper</span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4 mt-8 pt-4 border-t border-[#ECE7DF]">
            <button
              onClick={onExplore}
              className="border border-[#DED8CC] text-[10px] font-sans uppercase font-bold tracking-widest text-[#062b19] py-3 text-center hover:bg-[#ECE7DF] transition-colors"
            >
              Editorial Page
            </button>
            <button
              onClick={(e) => {
                onAddToBasket(product.id, e);
                onClose();
              }}
              className="bg-[#0d422a] text-[#FAF7F2] text-[10px] font-sans uppercase font-bold tracking-widest py-3 text-center hover:bg-[#C09A58] transition-colors border-none"
            >
              + Basket
            </button>
          </div>
        </div>

      </motion.div>
    </div>
  );
}
