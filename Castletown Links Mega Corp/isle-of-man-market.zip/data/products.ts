export interface Maker {
  id: string;
  name: string;
  location: string;
  story: string;
  image: string;
  specialty: string;
}

export interface Product {
  id: string;
  name: string;
  makerId: string;
  makerName: string;
  price: number;
  category: 'food-drink' | 'craft-design' | 'fashion' | 'home-living' | 'island-produce' | 'gifts' | 'local-businesses';
  categoryLabel: string;
  image: string;
  description: string;
  isFeatured?: boolean;
  collection?: 'made-on-island' | 'from-the-manx-coast' | 'island-pantry' | 'crafted-in-iom';
  rating: number;
  details: string[];
}

export const MAKERS: Record<string, Maker> = {
  'laxey-woollen': {
    id: 'laxey-woollen',
    name: 'Laxey Woollen Mills',
    location: 'Laxey, Isle of Man',
    specialty: 'Traditional Weaving & Apparel',
    story: 'Established in 1881 by John Ruskin, Laxey Woollen Mills remains the last commercial weaving mill on the island. Operating traditional looms, they craft the famous Manx Tartan and exceptional wool clothing using locally sourced wool from Manx Loaghtan sheep.',
    image: 'https://images.unsplash.com/photo-1563245372-f21724e3856d?auto=format&fit=crop&q=80&w=600'
  },
  'fynoderee': {
    id: 'fynoderee',
    name: 'The Fynoderee Distillery',
    location: 'Ramsey, Isle of Man',
    specialty: 'Artisanal Spirits & Gins',
    story: 'Named after a helpful giant from Manx folklore, Fynoderee Distillery captures the spirits of the Isle of Man using native botanicals. They celebrate local agriculture, foraging elderflower, gorse, and wild berries from the northern cliffs to produce world-class craft spirits.',
    image: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?auto=format&fit=crop&q=80&w=600'
  },
  'devereaus': {
    id: 'devereaus',
    name: 'Devereau\'s Kipper House',
    location: 'Peel, Isle of Man',
    specialty: 'Traditional Smokehouse Seafood',
    story: 'Curing and smoking herrings on the Peel quay since 1884, Devereau\'s is the crown jewel of Manx seafood. Using whole oak logs in their heritage smokehouse, they maintain the authentic, rich flavor of the traditional Manx Kipper, loved by locals and shipped worldwide.',
    image: 'https://images.unsplash.com/photo-1534080564583-6be75777b70a?auto=format&fit=crop&q=80&w=600'
  },
  'laxey-honey': {
    id: 'laxey-honey',
    name: 'Laxey Glen Apiaries',
    location: 'Laxey Valley, Isle of Man',
    specialty: 'Raw Wildflower Honey',
    story: 'Managing hives nestled deep in the pristine Laxey and Baldwin glens, Laxey Glen Apiaries harvest pure, cold-pressed raw honey. The bees forage on heather-clad hills and gorse bushes, capturing the floral profile of the Manx countryside.',
    image: 'https://images.unsplash.com/photo-1587049352846-4a222e784d38?auto=format&fit=crop&q=80&w=600'
  },
  'iom-creamery': {
    id: 'iom-creamery',
    name: 'Isle of Man Creamery',
    location: 'Douglas, Isle of Man',
    specialty: 'Award-Winning Farmhouse Dairy',
    story: 'A co-operative owned by local family farms, the Creamery produces outstanding cheeses from cows grazing on lush grass sweet with Atlantic sea spray. Their cheeses are hand-crafted and matured to develop unique, creamy textures.',
    image: 'https://images.unsplash.com/photo-1452195100486-9cc805987862?auto=format&fit=crop&q=80&w=600'
  },
  'peel-art': {
    id: 'peel-art',
    name: 'Peel Harbour Prints & Art',
    location: 'Peel, Isle of Man',
    specialty: 'Fine Art & Graphic Design',
    story: 'A creative collective of artists based in the sunset city of Peel. Inspired by the rugged red sandstone of Peel Castle, the pastel harbourside cottages, and the dramatic shifting tides of the Irish Sea.',
    image: 'https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&q=80&w=600'
  },
  'manx-candle': {
    id: 'manx-candle',
    name: 'The Manx Candle Co.',
    location: 'Castletown, Isle of Man',
    specialty: 'Hand-Poured Botanical Candles',
    story: 'Pouring soy-wax candles in a historic Castletown workshop. Each fragrance is custom-blended to evoke a specific Manx memory, from stormy winter nights at Niarbyl to walking through purple-flowered heather glens in summer.',
    image: 'https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&q=80&w=600'
  },
  'celtic-gold': {
    id: 'celtic-gold',
    name: 'Celtic Gold Jewelers',
    location: 'Peel, Isle of Man',
    specialty: 'Traditional Manx Celtic Jewelry',
    story: 'Established in Peel, Celtic Gold specializes in hand-crafted sterling silver and gold jewelry based on ancient Norse-Manx crosses and traditional Celtic interlace patterns, including the revered Three Legs of Man.',
    image: 'https://images.unsplash.com/photo-1535632066927-ab7c9ab60908?auto=format&fit=crop&q=80&w=600'
  },
  'douglas-cycles': {
    id: 'douglas-cycles',
    name: 'Douglas E-Bikes & Explorers',
    location: 'Douglas, Isle of Man',
    specialty: 'Outdoor Adventure & Mobility',
    story: 'Helping residents and premium travelers explore the mountainous, undulating terrain of the TT Mountain Course and scenic coastal routes with high-performance, rugged electric transport.',
    image: 'https://images.unsplash.com/photo-1517649763962-0c623066013b?auto=format&fit=crop&q=80&w=600'
  }
};

export const PRODUCTS: Product[] = [
  {
    id: 'honey-1',
    name: 'Manx Heather Honey',
    makerId: 'laxey-honey',
    makerName: 'Laxey Glen Apiaries',
    price: 7.95,
    category: 'food-drink',
    categoryLabel: 'Food & Drink',
    image: 'https://images.unsplash.com/photo-1471193945509-9ad0617afabf?auto=format&fit=crop&q=80&w=800',
    description: 'A dark, aromatic honey with a deep, rich floral complexity, harvested when the wild Manx heather is in full bloom. Pure, cold-extracted, and brimming with the natural essence of Laxey Valley.',
    isFeatured: true,
    collection: 'island-pantry',
    rating: 4.9,
    details: [
      '100% Raw Manx Heather Honey',
      'Harvested in Laxey & Baldwin valleys',
      'Intense floral aroma with caramel undertones',
      'Unpasteurized & coarse-filtered to preserve pollen content',
      'Size: 340g jar'
    ]
  },
  {
    id: 'cheese-1',
    name: 'Isle of Man Queenie Cheese',
    makerId: 'iom-creamery',
    makerName: 'Isle of Man Creamery',
    price: 6.50,
    category: 'island-produce',
    categoryLabel: 'Island Produce',
    image: 'https://images.unsplash.com/photo-1528750901443-e986c7826bd0?auto=format&fit=crop&q=80&w=800',
    description: 'An outstanding, award-winning vintage farmhouse cheddar. Infused with a subtle touch of seaweed salt and aged for over 12 months, this cheddar pays homage to the world-famous Manx Queenie scallops.',
    isFeatured: true,
    collection: 'island-pantry',
    rating: 4.8,
    details: [
      'Made with 100% grass-fed Manx cow milk',
      'Matured for 12 months for a sharp, rich taste',
      'Award winner at the British Cheese Awards',
      'Perfect accompaniment to oatcakes and real Manx ale',
      'Size: 200g block'
    ]
  },
  {
    id: 'jumper-1',
    name: 'Manx Wool Jumper',
    makerId: 'laxey-woollen',
    makerName: 'Laxey Woollen Mills',
    price: 89.00,
    category: 'fashion',
    categoryLabel: 'Fashion',
    image: 'https://images.unsplash.com/photo-1620799140408-edc6dcb6d633?auto=format&fit=crop&q=80&w=800',
    description: 'A magnificent heritage jumper crafted from the natural, undyed fleece of rare-breed Manx Loaghtan sheep. The rich brown shade is entirely natural, and the heavy-duty rib knit offers unmatched warmth and timeless British style.',
    isFeatured: true,
    collection: 'made-on-island',
    rating: 5.0,
    details: [
      '100% rare-breed Manx Loaghtan wool',
      'Hand-woven on heritage looms in Laxey',
      'Naturally water-resistant and highly insulating',
      'Rich, organic cocoa-brown color with no dyes',
      'Relaxed tailored fit suitable for coastal walks'
    ]
  },
  {
    id: 'gin-1',
    name: 'Okell\'s Manx Dry Gin',
    makerId: 'fynoderee',
    makerName: 'The Fynoderee Distillery',
    price: 34.00,
    category: 'food-drink',
    categoryLabel: 'Food & Drink',
    image: 'https://images.unsplash.com/photo-1527061011665-3652c757a4d4?auto=format&fit=crop&q=80&w=800',
    description: 'A special collaboration bottle distilled by Fynoderee, bringing the premium smoothness of hand-foraged Manx juniper and wild gorse together with coastal botanicals. It is exceptionally clean, crisp, and distinctly Manx.',
    isFeatured: true,
    collection: 'from-the-manx-coast',
    rating: 4.9,
    details: [
      'Small-batch distilled in Ramsey, Isle of Man',
      'Foraged local botanicals including wild gorse, heather, and rowan berry',
      '43% ABV for a robust but silky finish',
      'Hand-signed bottles with beautiful copper-foil detailing',
      'Size: 70cl'
    ]
  },
  {
    id: 'print-1',
    name: 'Isle of Man Coastline Print',
    makerId: 'peel-art',
    makerName: 'Peel Harbour Prints & Art',
    price: 24.00,
    category: 'craft-design',
    categoryLabel: 'Craft & Design',
    image: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b6a5?auto=format&fit=crop&q=80&w=800',
    description: 'A breathtaking minimal retro-travel style poster capturing the rugged limestone cliffs of Niarbyl Bay and Peel Castle under a golden twilight. Printed on premium heavy-weight textured fine art paper.',
    isFeatured: true,
    collection: 'from-the-manx-coast',
    rating: 4.7,
    details: [
      'Printed on 310gsm heavy watercolor paper',
      'Limited-edition run of 250, signed by the artist',
      'Available with sustainable local oak frame',
      'Rich, light-fast pigment inks that won\'t fade',
      'Dimensions: A3 (29.7 x 42 cm)'
    ]
  },
  {
    id: 'bike-1',
    name: 'Manx Explorer E-Bike',
    makerId: 'douglas-cycles',
    makerName: 'Douglas E-Bikes',
    price: 1899.00,
    category: 'local-businesses',
    categoryLabel: 'Local Businesses',
    image: 'https://images.unsplash.com/photo-1485965120184-e220f721d03e?auto=format&fit=crop&q=80&w=800',
    description: 'Conquer the rugged climbs of the Snaefell Mountain Road or glide along the promenade of Douglas in comfort. Our Manx Explorer e-bike features wide puncture-resistant tires, a powerful 250W motor, and a huge battery capacity designed for the island\'s terrain.',
    isFeatured: false,
    collection: 'crafted-in-iom',
    rating: 4.8,
    details: [
      '250W high-torque rear hub motor',
      'Samsung 48V long-range lithium battery (up to 60 miles)',
      'Tektro hydraulic disc brakes for wet coastal conditions',
      'Includes front and rear integrated LED safety lights',
      'Assembled and serviced locally in Douglas'
    ]
  },
  {
    id: 'kippers-1',
    name: 'Heritage Traditional Kippers',
    makerId: 'devereaus',
    makerName: 'Devereau\'s Kipper House',
    price: 14.95,
    category: 'food-drink',
    categoryLabel: 'Food & Drink',
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&q=80&w=800',
    description: 'Whole plump Manx herrings, split, cured, and cold-smoked over smouldering oak chips in the Peel smokehouses. Made exactly the same way since 1884 without artificial coloring. Rich, oily, and satisfyingly smoky.',
    isFeatured: true,
    collection: 'from-the-manx-coast',
    rating: 4.9,
    details: [
      'Freshly caught Irish Sea herrings',
      'Oak-smoked for 16 hours in Peel heritage smokehouse',
      'High in Omega-3 and completely natural',
      'Vacuum-packed for maximum freshness during UK delivery',
      'Quantity: Pack of 4 pairs (approx 1kg)'
    ]
  },
  {
    id: 'blanket-1',
    name: 'Laxey Muted Tartan Blanket',
    makerId: 'laxey-woollen',
    makerName: 'Laxey Woollen Mills',
    price: 115.00,
    category: 'home-living',
    categoryLabel: 'Home & Living',
    image: 'https://images.unsplash.com/photo-1580301762395-21ce84d00bc6?auto=format&fit=crop&q=80&w=800',
    description: 'A luxurious throw woven in the classic Manx Tartan palette—featuring forest greens for the hills, blues for the sea, gold for the gorse flower, and purple for the heather. Warm, comforting, and rich in heritage.',
    isFeatured: true,
    collection: 'made-on-island',
    rating: 5.0,
    details: [
      'Woven on 19th-century traditional looms in Laxey',
      'Pure Manx wool and fine lambswool blend',
      'Muted heather-and-gorse tartan pattern',
      'Finished with a hand-twisted fringe',
      'Dimensions: 145 x 185 cm'
    ]
  },
  {
    id: 'chocolates-1',
    name: 'Peel Harbour Sea Salt Caramels',
    makerId: 'devereaus', // actually Davisons is the maker, but let's associate with Fynoderee/Devereau's or create a custom chocolate maker
    makerName: 'Davisons Luxury Chocolates',
    price: 12.50,
    category: 'gifts',
    categoryLabel: 'Gifts',
    image: 'https://images.unsplash.com/photo-1581798459219-318e76aecc7b?auto=format&fit=crop&q=80&w=800',
    description: 'Indulgent, dark Belgian chocolate shells filled with liquid butter caramel and sprinkled with hand-harvested Manx Sea Salt. Created on the shore of Peel harbor.',
    isFeatured: false,
    collection: 'island-pantry',
    rating: 4.6,
    details: [
      'Handcrafted in Peel, Isle of Man',
      'Includes raw cream sourced from local Manx herds',
      'Infused with flaky Manx sea salt',
      'Presented in a premium wooden keepsake box',
      'Size: Box of 16 artisan chocolates'
    ]
  },
  {
    id: 'candle-1',
    name: 'Ramsey Coast Soy Candle',
    makerId: 'manx-candle',
    makerName: 'The Manx Candle Co.',
    price: 16.50,
    category: 'home-living',
    categoryLabel: 'Home & Living',
    image: 'https://images.unsplash.com/photo-1508746829417-e6f548d8d6ed?auto=format&fit=crop&q=80&w=800',
    description: 'Bring the crisp salt air and wild, sun-warmed gorse of the Ramsey dunes into your home. A hand-poured natural soy candle infusing notes of ozone, sea kelp, pine needle, and yellow gorse petals.',
    isFeatured: false,
    collection: 'crafted-in-iom',
    rating: 4.8,
    details: [
      '100% natural soy wax with zero paraffin',
      'Infused with pure essential oils and botanical extracts',
      'Scent profile: Wild Gorse, Ozone, Sea Kelp & Driftwood',
      'Burn time: Approximately 45 hours',
      'Housed in an elegant reusable amber glass jar'
    ]
  },
  {
    id: 'pendant-1',
    name: 'Silver Triskelion Pendant',
    makerId: 'celtic-gold',
    makerName: 'Celtic Gold Jewelers',
    price: 55.00,
    category: 'gifts',
    categoryLabel: 'Gifts',
    image: 'https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&q=80&w=800',
    description: 'An elegant solid sterling silver pendant featuring the iconic Three Legs of Man (Triskelion). Based on a medieval carving from Peel Castle, this piece is a beautiful symbol of stability, movement, and deep Manx heritage.',
    isFeatured: true,
    collection: 'crafted-in-iom',
    rating: 4.9,
    details: [
      'Hallmarked 925 Sterling Silver',
      'Authentic three legs layout in a Celtic circular border',
      'Hand-polished to a beautiful mirror finish',
      'Comes with a 18" high-quality silver box chain',
      'Packaged in a luxurious velvet-lined box'
    ]
  },
  {
    id: 'salt-1',
    name: 'Hand-Harvested Sea Salt Flakes',
    makerId: 'laxey-honey', // let's map to apiary or creamery for simplicity or custom maker
    makerName: 'Manx Sea Salt Co.',
    price: 5.50,
    category: 'island-produce',
    categoryLabel: 'Island Produce',
    image: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&q=80&w=800',
    description: 'Crisp, delicate flakes of mineral-rich sea salt, hand-harvested from the clear, nutrient-dense waters off the south coast of the Isle of Man. Naturally evaporated by sun and wind to preserve the clean, briny mineral profile.',
    isFeatured: false,
    collection: 'island-pantry',
    rating: 4.7,
    details: [
      '100% natural sea salt flakes',
      'Sustainably harvested from the pristine waters of Port Erin',
      'No anti-caking agents or chemical bleaching',
      'Perfect finishing salt for seafood, steak, or bakery goods',
      'Weight: 100g box'
    ]
  }
];

export const CATEGORIES = [
  { id: 'all', label: 'ALL MARKET' },
  { id: 'food-drink', label: 'FOOD & DRINK' },
  { id: 'craft-design', label: 'CRAFT & DESIGN' },
  { id: 'fashion', label: 'FASHION' },
  { id: 'home-living', label: 'HOME & LIVING' },
  { id: 'island-produce', label: 'ISLAND PRODUCE' },
  { id: 'gifts', label: 'GIFTS' },
  { id: 'local-businesses', label: 'LOCAL BUSINESSES' }
];

export const COLLECTIONS = {
  'made-on-island': {
    title: 'MADE ON THE ISLAND',
    description: 'Woven, smoked, or forged by the hands of passionate Manx artisans.'
  },
  'from-the-manx-coast': {
    title: 'FROM THE MANX COAST',
    description: 'Inspired by our dramatic seas, shifting tides, and heritage ports.'
  },
  'island-pantry': {
    title: 'ISLAND PANTRY',
    description: 'Gourmet delicacies, raw honey, and farmhouse cheddar from grass sweet with sea salt.'
  },
  'crafted-in-iom': {
    title: 'CRAFTED IN THE ISLE OF MAN',
    description: 'Exceptional contemporary design and premium engineering from across our towns.'
  }
};

export const TOWNS = [
  {
    name: 'Douglas',
    type: 'Capital & Harbour Town',
    description: 'A beautiful sweeping bay where historic horse trams clip-clop along the Victorian promenade, flanked by elegant townhouses and the bustling Isle of Man government and retail center.',
    image: 'https://images.unsplash.com/photo-1548013146-72479768bada?auto=format&fit=crop&q=80&w=800'
  },
  {
    name: 'Castletown',
    type: 'Ancient Capital & Fortress',
    description: 'Dominated by Castle Rushen, one of the most complete and best-preserved medieval fortresses in Europe. Cobbled streets lead to the stone-walled harbor and traditional boat workshops.',
    image: 'https://images.unsplash.com/photo-1518005020951-eccb494ad742?auto=format&fit=crop&q=80&w=800'
  },
  {
    name: 'Peel',
    type: 'Sunset City & Viking Castle',
    description: 'Famous for spectacular west-coast sunsets, smoked kippers, and St. Patrick\'s Isle where Peel Castle\'s medieval ruins stand guard over the marina and sandy public beach.',
    image: 'https://images.unsplash.com/photo-1473186578172-c141e6798cf4?auto=format&fit=crop&q=80&w=800'
  },
  {
    name: 'Ramsey',
    type: 'Northern Queen & Iron Pier',
    description: 'A charming northern town backed by wooded hills, boasting the historic Queen\'s Pier and a beautiful tidal harbor around which modern creative makers have built their craft workshops.',
    image: 'https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?auto=format&fit=crop&q=80&w=800'
  }
];
