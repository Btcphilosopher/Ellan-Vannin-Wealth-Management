-- Digital Euro Prototype — PostgreSQL Authoritative Ledger & Workflow Schema
-- Integer euro cents (BIGINT) throughout; append-only journal immutability enforced by triggers.

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    handle TEXT NOT NULL UNIQUE,
    full_name TEXT NOT NULL,
    synthetic_national_id TEXT NOT NULL,
    country_code CHAR(2) NOT NULL DEFAULT 'DE',
    kyc_tier TEXT NOT NULL DEFAULT 'TIER_1_SYNTHETIC',
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'CONSUMER',
    linked_bank_name TEXT NOT NULL,
    linked_bank_iban_masked TEXT NOT NULL,
    recovery_phrase_hash TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS wallets (
    id TEXT PRIMARY KEY,
    owner_type TEXT NOT NULL CHECK (owner_type IN ('CONSUMER', 'MERCHANT')),
    owner_id TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('ACTIVE', 'FROZEN', 'RECOVERY_PENDING', 'CLOSED')),
    holding_limit_cents BIGINT NOT NULL CHECK (holding_limit_cents >= 0),
    daily_spend_limit_cents BIGINT NOT NULL CHECK (daily_spend_limit_cents >= 0),
    single_tx_limit_cents BIGINT NOT NULL CHECK (single_tx_limit_cents >= 0),
    waterfall_enabled BOOLEAN NOT NULL DEFAULT TRUE,
    reverse_waterfall_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS ledger_accounts (
    id TEXT PRIMARY KEY,
    code TEXT NOT NULL UNIQUE,
    owner_type TEXT NOT NULL CHECK (owner_type IN ('CONSUMER', 'MERCHANT', 'SYSTEM')),
    owner_id TEXT,
    account_type TEXT NOT NULL CHECK (
        account_type IN (
            'CONSUMER_AVAILABLE', 'CONSUMER_RESERVED',
            'MERCHANT_SETTLEMENT', 'BANK_CLEARING_IN', 'BANK_CLEARING_OUT', 'ISSUER_RESERVE'
        )
    ),
    normal_balance TEXT NOT NULL CHECK (normal_balance IN ('LIABILITY', 'ASSET')),
    allow_negative BOOLEAN NOT NULL DEFAULT FALSE,
    balance_cents BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_non_negative_balance CHECK (allow_negative OR balance_cents >= 0)
);

CREATE TABLE IF NOT EXISTS journal_transactions (
    id TEXT PRIMARY KEY,
    idempotency_key TEXT NOT NULL UNIQUE,
    tx_type TEXT NOT NULL,
    reference_type TEXT NOT NULL,
    reference_id TEXT NOT NULL,
    parent_tx_id TEXT REFERENCES journal_transactions(id),
    description TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS journal_postings (
    id TEXT PRIMARY KEY,
    journal_tx_id TEXT NOT NULL REFERENCES journal_transactions(id),
    account_id TEXT NOT NULL REFERENCES ledger_accounts(id),
    debit_cents BIGINT NOT NULL CHECK (debit_cents >= 0),
    credit_cents BIGINT NOT NULL CHECK (credit_cents >= 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_single_sided_posting CHECK (
        (debit_cents > 0 AND credit_cents = 0) OR (credit_cents > 0 AND debit_cents = 0)
    )
);

CREATE OR REPLACE FUNCTION prevent_ledger_mutation() RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'Append-only ledger records cannot be modified or deleted; create a compensating entry.';
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_journal_tx_immutable ON journal_transactions;
CREATE TRIGGER trg_journal_tx_immutable
BEFORE UPDATE OR DELETE ON journal_transactions
FOR EACH ROW EXECUTE FUNCTION prevent_ledger_mutation();

DROP TRIGGER IF EXISTS trg_journal_postings_immutable ON journal_postings;
CREATE TRIGGER trg_journal_postings_immutable
BEFORE UPDATE OR DELETE ON journal_postings
FOR EACH ROW EXECUTE FUNCTION prevent_ledger_mutation();

CREATE TABLE IF NOT EXISTS payments (
    id TEXT PRIMARY KEY,
    idempotency_key TEXT NOT NULL UNIQUE,
    kind TEXT NOT NULL,
    payer_user_id TEXT NOT NULL REFERENCES users(id),
    payee_kind TEXT NOT NULL CHECK (payee_kind IN ('MERCHANT', 'CONSUMER')),
    payee_id TEXT NOT NULL,
    payment_request_id TEXT,
    amount_cents BIGINT NOT NULL CHECK (amount_cents > 0),
    refunded_cents BIGINT NOT NULL DEFAULT 0 CHECK (refunded_cents >= 0),
    currency CHAR(3) NOT NULL DEFAULT 'EUR' CHECK (currency = 'EUR'),
    state TEXT NOT NULL CHECK (
        state IN ('CREATED', 'AWAITING_AUTHORISATION', 'RESERVED', 'POSTED', 'REJECTED', 'EXPIRED', 'CANCELLED')
    ),
    journal_tx_id TEXT REFERENCES journal_transactions(id),
    expires_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS reconciliation_records (
    id TEXT PRIMARY KEY,
    status TEXT NOT NULL CHECK (status IN ('BALANCED', 'MISMATCH')),
    total_debits_cents BIGINT NOT NULL,
    total_credits_cents BIGINT NOT NULL,
    total_clearing_asset_cents BIGINT NOT NULL,
    total_wallet_liability_cents BIGINT NOT NULL,
    discrepancy_cents BIGINT NOT NULL,
    checked_by TEXT NOT NULL,
    notes TEXT NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
