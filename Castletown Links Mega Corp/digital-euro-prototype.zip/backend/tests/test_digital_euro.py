import sqlite3
import unittest
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
from app.modules.ledger import LedgerError, PostingSpec, post_journal_entry, verify_reconciliation
from app.worker import run_cycle


def build_test_db() -> sqlite3.Connection:
    conn = sqlite3.connect(":memory:")
    conn.executescript(
        """
        CREATE TABLE ledger_accounts (
            id TEXT PRIMARY KEY,
            code TEXT NOT NULL UNIQUE,
            normal_balance TEXT NOT NULL CHECK (normal_balance IN ('LIABILITY', 'ASSET')),
            allow_negative INTEGER NOT NULL,
            balance_cents INTEGER NOT NULL
        );
        CREATE TABLE journal_transactions (
            id TEXT PRIMARY KEY,
            idempotency_key TEXT NOT NULL UNIQUE,
            tx_type TEXT NOT NULL,
            reference_type TEXT NOT NULL,
            reference_id TEXT NOT NULL,
            parent_tx_id TEXT,
            description TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TABLE journal_postings (
            id TEXT PRIMARY KEY,
            journal_tx_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            debit_cents INTEGER NOT NULL,
            credit_cents INTEGER NOT NULL,
            created_at TEXT NOT NULL
        );
        CREATE TRIGGER trg_no_update_postings BEFORE UPDATE ON journal_postings
        BEGIN SELECT RAISE(ABORT, 'immutable'); END;
        CREATE TABLE payments (
            id TEXT PRIMARY KEY,
            state TEXT NOT NULL,
            expires_at TEXT NOT NULL
        );
        """
    )
    conn.executemany(
        "INSERT INTO ledger_accounts VALUES (?, ?, ?, ?, ?)",
        [
            ("acc_clearing", "SYS:CLEARING", "ASSET", 1, 0),
            ("acc_clara_avail", "CON:clara:AVAIL", "LIABILITY", 0, 0),
            ("acc_clara_resv", "CON:clara:RESV", "LIABILITY", 0, 0),
            ("acc_lucas_avail", "CON:lucas:AVAIL", "LIABILITY", 0, 0),
            ("acc_cafe", "MRC:cafe:SETTLE", "LIABILITY", 0, 0),
        ],
    )
    return conn


class DigitalEuroPythonLedgerTests(unittest.TestCase):
    def test_10_step_accounting_and_reconciliation(self):
        conn = build_test_db()
        with conn:
            # 1. Fund €100.00
            post_journal_entry(
                conn,
                idempotency_key="fund-100",
                tx_type="BANK_FUNDING",
                reference_type="FUND",
                reference_id="f1",
                description="Simulated €100.00 funding",
                postings=[
                    PostingSpec("acc_clearing", 10000, 0),
                    PostingSpec("acc_clara_avail", 0, 10000),
                ],
            )
            # 2. Reserve + Post €12.50 merchant
            res_tx = post_journal_entry(
                conn,
                idempotency_key="res-1250",
                tx_type="RESERVATION",
                reference_type="PAY",
                reference_id="p1",
                description="Reserve €12.50",
                postings=[
                    PostingSpec("acc_clara_avail", 1250, 0),
                    PostingSpec("acc_clara_resv", 0, 1250),
                ],
            )
            post_journal_entry(
                conn,
                idempotency_key="settle-1250",
                tx_type="MERCHANT_PAYMENT",
                reference_type="PAY",
                reference_id="p1",
                parent_tx_id=res_tx,
                description="Settle €12.50",
                postings=[
                    PostingSpec("acc_clara_resv", 1250, 0),
                    PostingSpec("acc_cafe", 0, 1250),
                ],
            )
            # 3. €20.00 P2P
            post_journal_entry(
                conn,
                idempotency_key="p2p-2000",
                tx_type="P2P_PAYMENT",
                reference_type="PAY",
                reference_id="p2",
                description="P2P €20.00",
                postings=[
                    PostingSpec("acc_clara_avail", 2000, 0),
                    PostingSpec("acc_lucas_avail", 0, 2000),
                ],
            )
            # 4. €2.50 partial refund
            post_journal_entry(
                conn,
                idempotency_key="refund-250",
                tx_type="REFUND",
                reference_type="REF",
                reference_id="r1",
                description="Partial refund €2.50",
                postings=[
                    PostingSpec("acc_cafe", 250, 0),
                    PostingSpec("acc_clara_avail", 0, 250),
                ],
            )
            # 5. Idempotent duplicate call returns same tx without second debit
            post_journal_entry(
                conn,
                idempotency_key="p2p-2000",
                tx_type="P2P_PAYMENT",
                reference_type="PAY",
                reference_id="p2",
                description="Duplicate",
                postings=[
                    PostingSpec("acc_clara_avail", 2000, 0),
                    PostingSpec("acc_lucas_avail", 0, 2000),
                ],
            )

        bal = conn.execute("SELECT balance_cents FROM ledger_accounts WHERE id = 'acc_clara_avail'").fetchone()[0]
        self.assertEqual(bal, 7000)

        balanced, debits, credits, assets, liabilities = verify_reconciliation(conn)
        self.assertTrue(balanced)
        self.assertEqual(debits, credits)
        self.assertEqual(assets, 10000)
        self.assertEqual(liabilities, 10000)

    def test_prevents_unbalanced_and_negative_and_mutation(self):
        conn = build_test_db()
        with self.assertRaises(LedgerError):
            post_journal_entry(
                conn,
                idempotency_key="bad-unbal",
                tx_type="TEST",
                reference_type="T",
                reference_id="1",
                description="Unbalanced",
                postings=[
                    PostingSpec("acc_clearing", 100, 0),
                    PostingSpec("acc_clara_avail", 0, 99),
                ],
            )
        with self.assertRaises(LedgerError):
            post_journal_entry(
                conn,
                idempotency_key="bad-neg",
                tx_type="TEST",
                reference_type="T",
                reference_id="2",
                description="Negative consumer balance",
                postings=[
                    PostingSpec("acc_clara_avail", 500, 0),
                    PostingSpec("acc_lucas_avail", 0, 500),
                ],
            )
        cycle = run_cycle(conn)
        self.assertTrue(cycle["balanced"])


if __name__ == "__main__":
    unittest.main()
