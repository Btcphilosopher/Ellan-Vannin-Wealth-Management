"""
Background worker for expiry sweeps, reconciliation verification, and notification dispatch.
"""
import time
import logging

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("digital_euro.worker")


def run_cycle(conn) -> dict:
    """
    Executes one deterministic worker cycle:
    1. Expire stale OPEN payment requests and AWAITING_AUTHORISATION payment intents.
    2. Run double-entry trial-balance reconciliation.
    """
    with conn:
        cur = conn.cursor()
        cur.execute(
            "UPDATE payments SET state = 'EXPIRED' "
            "WHERE state IN ('CREATED', 'AWAITING_AUTHORISATION') AND expires_at < CURRENT_TIMESTAMP"
        )
        expired_payments = cur.rowcount

        cur.execute(
            "SELECT COALESCE(SUM(debit_cents), 0), COALESCE(SUM(credit_cents), 0) FROM journal_postings"
        )
        debits, credits = cur.fetchone()
        balanced = debits == credits
        logger.info("Worker cycle complete: expired=%s balanced=%s debits=%s", expired_payments, balanced, debits)
        return {"expired_payments": expired_payments, "balanced": balanced, "total_debits_cents": debits}


if __name__ == "__main__":
    logger.info("Digital Euro background worker started (interval=15s).")
    while True:
        time.sleep(15)
