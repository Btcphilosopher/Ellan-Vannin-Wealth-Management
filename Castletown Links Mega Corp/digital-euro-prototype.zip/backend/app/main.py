"""
Digital Euro Independent Research Prototype — FastAPI Modular Monolith
All modules (identity, wallets, ledger, payments, merchant_acceptance, funding_simulation,
administration, offline_research) are strictly separated by domain boundary.
Not official ECB / Eurosystem infrastructure. Simulated funds only.
"""
from fastapi import FastAPI
from .modules import (
    administration,
    funding_simulation,
    identity,
    ledger,
    merchant_acceptance,
    offline_research,
    payments,
    wallets,
)

app = FastAPI(
    title="Digital Euro Research Prototype API",
    version="0.1.0-demo",
    description="Independent prototype using synthetic identities and simulated funds (EUR integer cents).",
)

app.include_router(identity.router, prefix="/v1", tags=["identity"])
app.include_router(wallets.router, prefix="/v1", tags=["wallets"])
app.include_router(payments.router, prefix="/v1", tags=["payments"])
app.include_router(merchant_acceptance.router, prefix="/v1", tags=["merchant-acceptance"])
app.include_router(funding_simulation.router, prefix="/v1", tags=["funding-simulation"])
app.include_router(administration.router, prefix="/v1", tags=["administration"])
app.include_router(offline_research.router, prefix="/v1", tags=["offline-research"])


@app.get("/v1/health")
def health():
    return {
        "status": "ok",
        "prototype": "DEMONSTRATION_SIMULATED_FUNDS",
        "official_ecb_connection": False,
        "ledger_engine": ledger.ENGINE_MODE,
    }
