from . import ledger

try:
    from .domain_routers import (
        admin_router,
        funding_router,
        identity_router,
        merchant_router,
        offline_router,
        payments_router,
        wallets_router,
    )

    class _ModuleProxy:
        def __init__(self, router):
            self.router = router

    identity = _ModuleProxy(identity_router)
    wallets = _ModuleProxy(wallets_router)
    payments = _ModuleProxy(payments_router)
    merchant_acceptance = _ModuleProxy(merchant_router)
    funding_simulation = _ModuleProxy(funding_router)
    administration = _ModuleProxy(admin_router)
    offline_research = _ModuleProxy(offline_router)
except ImportError:
    # Allows ledger and worker modules to be tested in pure stdlib Python environments
    pass
