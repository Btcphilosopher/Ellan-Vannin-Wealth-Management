"""
Authoritative Append-Only Double-Entry Ledger Module (Python / PostgreSQL-compatible).
Enforces integer euro cents, balanced postings, idempotency keys, reservations, and immutability.
"""
import sqlite3
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional, Tuple

ENGINE_MODE = "POSTGRESQL_APPEND_ONLY_DOUBLE_ENTRY"


@dataclass(frozen=True)
class PostingSpec:
    account_id: str
    debit_cents: int
    credit_cents: int


class LedgerError(Exception):
    pass


def post_journal_entry(
    conn: sqlite3.Connection,
    *,
    idempotency_key: str,
    tx_type: str,
    reference_type: str,
    reference_id: str,
    description: str,
    postings: List[PostingSpec],
    parent_tx_id: Optional[str] = None,
) -> str:
    """
    Posts a balanced double-entry journal transaction inside an atomic database transaction.
    In PostgreSQL production deployments, account rows are locked with `SELECT ... FOR UPDATE`
    ordered deterministically by account_id to prevent deadlocks.
    """
    if len(postings) < 2:
        raise LedgerError("Double-entry transaction requires at least two postings.")

    total_debit = 0
    total_credit = 0
    for p in postings:
        if not isinstance(p.debit_cents, int) or not isinstance(p.credit_cents, int):
            raise LedgerError("Amounts must be integer euro cents.")
        if (p.debit_cents > 0 and p.credit_cents > 0) or (p.debit_cents == 0 and p.credit_cents == 0):
            raise LedgerError("Each posting must be strictly single-sided (debit OR credit > 0).")
        total_debit += p.debit_cents
        total_credit += p.credit_cents

    if total_debit <= 0 or total_debit != total_credit:
        raise LedgerError(f"Unbalanced journal transaction: debits={total_debit}, credits={total_credit}")

    cur = conn.cursor()
    cur.execute("SELECT id FROM journal_transactions WHERE idempotency_key = ?", (idempotency_key,))
    existing = cur.fetchone()
    if existing:
        return existing[0]

    tx_id = f"jtx_{uuid.uuid4().hex[:12]}"
    now = datetime.now(timezone.utc).isoformat()

    cur.execute(
        """
        INSERT INTO journal_transactions (
            id, idempotency_key, tx_type, reference_type, reference_id, parent_tx_id, description, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (tx_id, idempotency_key, tx_type, reference_type, reference_id, parent_tx_id, description, now),
    )

    for p in postings:
        cur.execute(
            "SELECT normal_balance, allow_negative, balance_cents FROM ledger_accounts WHERE id = ?",
            (p.account_id,),
        )
        acc = cur.fetchone()
        if not acc:
            raise LedgerError(f"Account not found: {p.account_id}")
        normal_balance, allow_negative, current_bal = acc
        delta = (p.credit_cents - p.debit_cents) if normal_balance == "LIABILITY" else (p.debit_cents - p.credit_cents)
        next_bal = current_bal + delta
        if allow_negative == 0 and next_bal < 0:
            raise LedgerError(f"Insufficient balance on {p.account_id}: {current_bal} + {delta} < 0")

        cur.execute("UPDATE ledger_accounts SET balance_cents = ? WHERE id = ?", (next_bal, p.account_id))
        cur.execute(
            """
            INSERT INTO journal_postings (id, journal_tx_id, account_id, debit_cents, credit_cents, created_at)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (f"jps_{uuid.uuid4().hex[:12]}", tx_id, p.account_id, p.debit_cents, p.credit_cents, now),
        )

    return tx_id


def verify_reconciliation(conn: sqlite3.Connection) -> Tuple[bool, int, int, int, int]:
    cur = conn.cursor()
    cur.execute("SELECT COALESCE(SUM(debit_cents), 0), COALESCE(SUM(credit_cents), 0) FROM journal_postings")
    total_debits, total_credits = cur.fetchone()
    cur.execute("SELECT COALESCE(SUM(balance_cents), 0) FROM ledger_accounts WHERE normal_balance = 'ASSET'")
    clearing_assets = cur.fetchone()[0]
    cur.execute("SELECT COALESCE(SUM(balance_cents), 0) FROM ledger_accounts WHERE normal_balance = 'LIABILITY'")
    wallet_liabilities = cur.fetchone()[0]
    discrepancy = abs(total_debits - total_credits) + abs(clearing_assets - wallet_liabilities)
    return (discrepancy == 0, total_debits, total_credits, clearing_assets, wallet_liabilities)
