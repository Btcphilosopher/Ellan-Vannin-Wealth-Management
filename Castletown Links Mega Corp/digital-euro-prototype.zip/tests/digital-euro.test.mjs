import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import fs from 'node:fs';
import { createRequire } from 'node:module';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

const tmpDir = path.join(process.cwd(), '.tmp-test');
fs.rmSync(tmpDir, { recursive: true, force: true });
fs.mkdirSync(tmpDir, { recursive: true });
const tmpDb = path.join(tmpDir, 'digital_euro_test.db');
process.env.DATABASE_PATH = tmpDb;

test.after(() => {
  fs.rmSync(tmpDir, { recursive: true, force: true });
});

const coreDir = path.resolve(process.cwd(), 'lib', 'core');
const tsFiles = fs
  .readdirSync(coreDir)
  .filter((f) => f.endsWith('.ts'))
  .map((f) => path.join(coreDir, f));

execFileSync(
  path.resolve(process.cwd(), 'node_modules', '.bin', 'tsc'),
  [
    '--outDir',
    tmpDir,
    '--module',
    'commonjs',
    '--moduleResolution',
    'node',
    '--target',
    'es2022',
    '--esModuleInterop',
    'true',
    '--skipLibCheck',
    'true',
    ...tsFiles,
  ],
  { stdio: 'pipe' }
);

const require = createRequire(import.meta.url);
const admin = require(path.join(tmpDir, 'admin.js'));
const auth = require(path.join(tmpDir, 'auth.js'));
const dbMod = require(path.join(tmpDir, 'db.js'));
const demo = require(path.join(tmpDir, 'demo-scenario.js'));
const funding = require(path.join(tmpDir, 'funding.js'));
const ledger = require(path.join(tmpDir, 'ledger.js'));
const payments = require(path.join(tmpDir, 'payments.js'));

test('10-step end-to-end demonstration passes with €70.00 final balance and zero discrepancy', async () => {
  const result = await demo.runFullTenStepDemonstration();
  assert.equal(result.allPassed, true, JSON.stringify(result.steps, null, 2));
  assert.equal(result.finalBalances.claraAvailableCents, 7000);
  assert.equal(result.finalBalances.lucasAvailableCents, 300);
  assert.equal(result.finalBalances.cafeEuropaSettlementCents, 2700);
});

test('Double-entry ledger rejects unbalanced transactions, negative consumer balances, and mutations', () => {
  dbMod.resetDatabaseForDemo(tmpDb);
  const db = dbMod.getDb();

  assert.throws(() => {
    db.transaction(() => {
      ledger.postJournalEntryInTx(db, {
        idempotencyKey: 'unbalanced-1',
        txType: 'TEST',
        referenceType: 'TEST',
        referenceId: '1',
        description: 'Unbalanced entry',
        postings: [
          { accountId: 'acc_bank_clearing_in', debitCents: 1000, creditCents: 0 },
          { accountId: 'acc_clara_avail', debitCents: 0, creditCents: 999 },
        ],
      });
    })();
  }, /Unbalanced journal transaction/);

  assert.throws(() => {
    db.transaction(() => {
      ledger.postJournalEntryInTx(db, {
        idempotencyKey: 'negative-1',
        txType: 'TEST',
        referenceType: 'TEST',
        referenceId: '2',
        description: 'Overdraft consumer',
        postings: [
          { accountId: 'acc_clara_avail', debitCents: 100, creditCents: 0 },
          { accountId: 'acc_lucas_avail', debitCents: 0, creditCents: 100 },
        ],
      });
    })();
  }, /Insufficient funds/);

  db.transaction(() => {
    ledger.postJournalEntryInTx(db, {
      idempotencyKey: 'valid-seed-for-trigger-test',
      txType: 'TEST_CREDIT',
      referenceType: 'TEST',
      referenceId: '3',
      description: 'Valid posting before testing immutability trigger',
      postings: [
        { accountId: 'acc_bank_clearing_in', debitCents: 100, creditCents: 0 },
        { accountId: 'acc_clara_avail', debitCents: 0, creditCents: 100 },
      ],
    });
  })();

  assert.throws(() => {
    db.prepare('UPDATE journal_postings SET debit_cents = 999').run();
  }, /Append-only ledger postings cannot be modified/);
});

test('Reservations, cancellation, and expiry release reserved balances accurately', () => {
  dbMod.resetDatabaseForDemo(tmpDb);
  const fund = funding.createFundingRequest({
    idempotencyKey: 'res-fund-1',
    userId: 'usr_clara',
    amountCents: 5000,
  });
  const ev = funding.buildSignedProviderEvent({
    externalEventId: 'evt-res-1',
    requestKind: 'FUNDING',
    requestId: fund.id,
    outcome: 'SETTLED',
    bankMessage: 'Settled',
  });
  funding.processProviderEvent({
    provider: 'rheinmain_demo_bank',
    rawBody: ev.bodyJson,
    signatureHeader: ev.signature,
  });

  const intent = payments.createPaymentIntent({
    idempotencyKey: 'cancel-pay-1',
    payerUserId: 'usr_clara',
    payeeKind: 'MERCHANT',
    payeeId: 'mrc_cafe_europa',
    amountCents: 1500,
  });
  const cancelled = payments.cancelPaymentIntent(intent.id, 'usr_clara');
  assert.equal(cancelled.state, 'CANCELLED');

  const req = payments.createPaymentRequest({
    kind: 'MERCHANT_POS',
    merchantId: 'mrc_cafe_europa',
    amountCents: 500,
    description: 'Expired test',
    expiresInSeconds: 30,
  });
  const db = dbMod.getDb();
  db.prepare(`UPDATE payment_requests SET expires_at = '2020-01-01T00:00:00.000Z' WHERE id = ?`).run(req.id);
  const swept = payments.expireStalePaymentRequestsAndIntents();
  assert.ok(swept.expiredRequests >= 1);
  assert.throws(() => {
    payments.createPaymentIntent({
      idempotencyKey: 'expired-pay-1',
      payerUserId: 'usr_clara',
      payeeKind: 'MERCHANT',
      payeeId: 'mrc_cafe_europa',
      amountCents: 500,
      paymentRequestId: req.id,
    });
  }, /EXPIRED/);
});

test('Refunds cannot exceed original settled amount', () => {
  dbMod.resetDatabaseForDemo(tmpDb);
  const fund = funding.createFundingRequest({ idempotencyKey: 'ref-fund', userId: 'usr_clara', amountCents: 3000 });
  const ev = funding.buildSignedProviderEvent({
    externalEventId: 'evt-ref-fund',
    requestKind: 'FUNDING',
    requestId: fund.id,
    outcome: 'SETTLED',
    bankMessage: 'OK',
  });
  funding.processProviderEvent({
    provider: 'rheinmain_demo_bank',
    rawBody: ev.bodyJson,
    signatureHeader: ev.signature,
  });

  const pay = payments.createPaymentIntent({
    idempotencyKey: 'ref-pay',
    payerUserId: 'usr_clara',
    payeeKind: 'MERCHANT',
    payeeId: 'mrc_cafe_europa',
    amountCents: 1000,
  });
  payments.authoriseAndPostPayment({
    paymentId: pay.id,
    actorUserId: 'usr_clara',
    authoriseIdempotencyKey: 'ref-auth',
  });

  const partial = payments.issueMerchantRefund({
    idempotencyKey: 'ref-1',
    originalPaymentId: pay.id,
    merchantId: 'mrc_cafe_europa',
    amountCents: 400,
    reason: 'Partial',
    actorId: 'mrc_cafe_europa',
  });
  assert.equal(partial.amountCents, 400);

  assert.throws(() => {
    payments.issueMerchantRefund({
      idempotencyKey: 'ref-2',
      originalPaymentId: pay.id,
      merchantId: 'mrc_cafe_europa',
      amountCents: 700,
      reason: 'Exceeds',
      actorId: 'mrc_cafe_europa',
    });
  }, /exceeds remaining refundable/);
});

test('Staff dual-control permissions, device recovery, and reconciliation', () => {
  dbMod.resetDatabaseForDemo(tmpDb);

  const proposal = admin.submitAdminAction({
    actorId: 'staff_operator',
    actorRole: 'OPERATOR',
    action: 'REQUEST_WALLET_FREEZE',
    targetId: 'wal_clara',
    reason: 'Suspicious device event under review',
  });
  assert.ok(proposal.approvalId);

  assert.throws(() => {
    admin.submitAdminAction({
      actorId: 'staff_operator',
      actorRole: 'OPERATOR',
      action: 'APPROVE_REQUEST',
      targetId: proposal.approvalId,
      reason: 'Attempted self-approval',
    });
  }, /Only SUPERVISOR/);

  const approved = admin.submitAdminAction({
    actorId: 'staff_supervisor',
    actorRole: 'SUPERVISOR',
    action: 'APPROVE_REQUEST',
    targetId: proposal.approvalId,
    reason: 'Supervisor verified compliance alert',
  });
  assert.match(approved.message, /Approved/);
  assert.equal(admin.getConsumerProfileById('usr_clara')?.walletStatus, 'FROZEN');

  const rec = admin.manageConsumerDevice({
    userId: 'usr_clara',
    action: 'RECOVER_WALLET',
    recoveryPhrase: 'amber-river-nordic-vault',
    deviceName: 'Recovered Device',
  });
  assert.ok(rec.devices.some((d) => d.status === 'ACTIVE' && d.deviceName === 'Recovered Device'));
  assert.equal(admin.getConsumerProfileById('usr_clara')?.walletStatus, 'ACTIVE');

  const tok = auth.signBearerToken({ sub: 'usr_clara', role: 'CONSUMER', deviceId: 'dev_1' });
  const claims = auth.verifyBearerToken(`Bearer ${tok}`);
  assert.equal(claims?.sub, 'usr_clara');

  const recCheck = ledger.runLedgerReconciliation(dbMod.getDb(), 'staff_supervisor', 'Final test suite reconciliation');
  assert.equal(recCheck.status, 'BALANCED');
  assert.equal(recCheck.discrepancyCents, 0);
});
