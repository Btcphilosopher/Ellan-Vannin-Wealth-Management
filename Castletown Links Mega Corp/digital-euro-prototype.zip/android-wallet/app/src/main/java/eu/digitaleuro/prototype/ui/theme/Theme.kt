package eu.digitaleuro.prototype.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val MidnightBlue = Color(0xFF0B1D3A)
val IvoryCanvas = Color(0xFFFAF8F3)
val EuropeanBlue = Color(0xFF003399)
val RestrainedGold = Color(0xFFC9A227)
val HairlineStone = Color(0xFFE4DFD3)

private val DigitalEuroColorScheme = lightColorScheme(
    primary = EuropeanBlue,
    onPrimary = Color.White,
    secondary = MidnightBlue,
    onSecondary = Color.White,
    tertiary = RestrainedGold,
    background = IvoryCanvas,
    onBackground = MidnightBlue,
    surface = Color.White,
    onSurface = MidnightBlue,
    outline = HairlineStone
)

@Composable
fun DigitalEuroTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DigitalEuroColorScheme,
        content = content
    )
}
