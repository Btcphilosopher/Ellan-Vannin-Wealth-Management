package eu.digitaleuro.prototype.security

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest

/**
 * Hardware-backed Android Keystore ECDSA key manager for device-bound wallet credentials.
 * Note: Production ECB offline payments additionally require certified Secure Element (SE/TEE)
 * monotonic counters and official Eurosystem device attestation.
 */
object DeviceKeyManager {
    private const val KEY_ALIAS = "deuro_proto_device_key_v1"

    fun ensureDeviceKeyFingerprint(): String {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (!ks.containsAlias(KEY_ALIAS)) {
            val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
            val spec = KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
            )
                .setDigests(KeyProperties.DIGEST_SHA256)
                .build()
            kpg.initialize(spec)
            kpg.generateKeyPair()
        }
        val cert = ks.getCertificate(KEY_ALIAS)
        val digest = MessageDigest.getInstance("SHA-256").digest(cert.publicKey.encoded)
        return "SHA256:" + digest.take(8).joinToString("") { "%02x".format(it) }
    }
}
