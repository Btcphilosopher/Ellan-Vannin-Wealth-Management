package eu.digitaleuro.prototype

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import eu.digitaleuro.prototype.ui.theme.*
import java.util.Locale

enum class ConsumerNavTab(val label: String) {
    HOME("Home"),
    PAY("Pay"),
    REQUEST("Request"),
    ACTIVITY("Activity"),
    ACCOUNT("Account")
}

fun formatEuroCents(cents: Long): String {
    val euros = cents / 100
    val rem = kotlin.math.abs(cents % 100)
    return String.format(Locale.GERMANY, "€%,d.%02d", euros, rem)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DigitalEuroTheme {
                DigitalEuroWalletApp()
            }
        }
    }
}

@Composable
fun DigitalEuroWalletApp() {
    var activeTab by remember { mutableStateOf(ConsumerNavTab.HOME) }
    var availableCents by remember { mutableStateOf(7000L) }
    var reservedCents by remember { mutableStateOf(0L) }
    var holdingLimitCents by remember { mutableStateOf(300000L) }

    Scaffold(
        containerColor = IvoryCanvas,
        topBar = {
            Column(modifier = Modifier.fillMaxWidth().background(MidnightBlue)) {
                Text(
                    text = "DEMONSTRATION — SIMULATED FUNDS · NOT OFFICIAL ECB",
                    color = RestrainedGold,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MidnightBlue, contentColor = Color.White) {
                ConsumerNavTab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = activeTab == tab,
                        onClick = { activeTab = tab },
                        icon = {
                            Icon(
                                imageVector = when (tab) {
                                    ConsumerNavTab.HOME -> Icons.Outlined.Home
                                    ConsumerNavTab.PAY -> Icons.Outlined.Send
                                    ConsumerNavTab.REQUEST -> Icons.Outlined.QrCode2
                                    ConsumerNavTab.ACTIVITY -> Icons.Outlined.ReceiptLong
                                    ConsumerNavTab.ACCOUNT -> Icons.Outlined.AccountCircle
                                },
                                contentDescription = tab.label
                            )
                        },
                        label = { Text(tab.label, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = RestrainedGold,
                            selectedTextColor = Color.White,
                            unselectedIconColor = Color(0xFFB8C4D9),
                            unselectedTextColor = Color(0xFFB8C4D9),
                            indicatorColor = EuropeanBlue
                        )
                    )
                }
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (activeTab) {
                ConsumerNavTab.HOME -> {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MidnightBlue)
                            .padding(20.dp)
                    ) {
                        Text("Available balance", color = Color(0xFFB8C4D9), fontSize = 12.sp)
                        Text(
                            text = formatEuroCents(availableCents),
                            color = Color.White,
                            fontSize = 36.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            text = "Reserved: ${formatEuroCents(reservedCents)} · Cap: ${formatEuroCents(holdingLimitCents)}",
                            color = RestrainedGold,
                            fontSize = 12.sp
                        )
                    }
                }
                ConsumerNavTab.PAY -> {
                    Column(
                        modifier = Modifier.fillMaxWidth().background(Color.White).border(1.dp, HairlineStone).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text("Pay Lifecycle", fontWeight = FontWeight.SemiBold, fontSize = 18.sp)
                        Text("1. Select recipient -> 2. Enter integer cents -> 3. Review -> 4. Step-up Authorise -> 5. Atomic Outcome")
                        Button(
                            onClick = { if (availableCents >= 1250L) availableCents -= 1250L },
                            colors = ButtonDefaults.buttonColors(containerColor = EuropeanBlue)
                        ) {
                            Text("Simulate €12.50 Authorise via /v1/payments/{id}/authorise")
                        }
                    }
                }
                ConsumerNavTab.REQUEST -> Text("Create P2P Payment Request (/v1/payment-requests)", fontSize = 16.sp)
                ConsumerNavTab.ACTIVITY -> Text("Consumer Payment History & Refunds (/v1/wallets/me/transactions)", fontSize = 16.sp)
                ConsumerNavTab.ACCOUNT -> Text("Bank Funding, Device Binding & Recovery (/v1/auth/devices)", fontSize = 16.sp)
            }
        }
    }
}
