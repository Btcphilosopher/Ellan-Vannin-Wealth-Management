'use client';

import { useState } from 'react';
import { AlertTriangle, Cpu, RefreshCw, ShieldAlert, Wifi, WifiOff } from 'lucide-react';
import { formatEuroCents, type LocaleCode, type OfflineWalletState } from '@/lib/core/types';

interface OfflineSimulatorViewProps {
  locale: LocaleCode;
  offlineSim: OfflineWalletState;
  onRefresh: () => Promise<void>;
}

export function OfflineSimulatorView({ locale, offlineSim, onRefresh }: OfflineSimulatorViewProps) {
  const [busy, setBusy] = useState(false);
  const [errMsg, setErrMsg] = useState<string | null>(null);

  async function trigger(action: string, amountCents?: number) {
    setBusy(true);
    setErrMsg(null);
    try {
      const res = await fetch('/v1/offline-sim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action, amountCents }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error?.message || 'Simulator action failed');
      await onRefresh();
    } catch (err) {
      setErrMsg(err instanceof Error ? err.message : 'Simulator error');
    } finally {
      setBusy(false);
    }
  }

  const remainingCents = offlineSim.allowanceCents - offlineSim.spentLocalCents;

  return (
    <div className="space-y-6">
      <div className="bg-[#0B1D3A] text-white p-6 border border-[#162D52] space-y-2">
        <p className="text-xs text-[#C9A227] font-medium">
          Isolated Research Sandbox · Outside Authoritative Online Ledger
        </p>
        <h2 className="font-[family-name:var(--font-display)] text-xl font-semibold">
          Offline-Payment Research Simulator
        </h2>
        <p className="text-xs text-slate-300 max-w-3xl">
          This module does NOT alter the authoritative online ledger and never labels a queued online transfer as an offline payment. It demonstrates allowance limits, duplicate spending risks on ordinary storage, device loss, and reconciliation conflicts.
        </p>
      </div>

      {errMsg && (
        <div className="border border-red-300 bg-red-50 p-4 text-sm text-red-950">{errMsg}</div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Simulator Controls */}
        <div className="lg:col-span-5 bg-white border border-[#E4DFD3] p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
            <div>
              <p className="text-xs text-[#4A5568]">Local Device Allowance Remaining</p>
              <p className="font-[family-name:var(--font-display)] text-3xl font-semibold tabular-nums text-[#0B1D3A]">
                {formatEuroCents(remainingCents, locale)}
              </p>
            </div>
            <div className="text-right text-xs">
              <span className="inline-flex items-center gap-1.5 font-semibold text-[#0B1D3A]">
                {offlineSim.connectivity === 'ONLINE' ? (
                  <Wifi className="h-4 w-4 text-emerald-700" />
                ) : (
                  <WifiOff className="h-4 w-4 text-amber-700" />
                )}
                {offlineSim.connectivity}
              </span>
              <p className="font-mono text-[#64748B] mt-1">
                Seq #{offlineSim.sequenceCounter} · {offlineSim.deviceLost ? 'DEVICE LOST' : 'Device Active'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-2.5">
            <button
              type="button"
              disabled={busy}
              onClick={() => trigger('TOGGLE_CONNECTIVITY')}
              className="border border-[#0B1D3A] px-4 py-2 text-xs font-medium text-[#0B1D3A] hover:bg-[#FAF8F3] text-left"
            >
              1. Toggle Connectivity (Currently {offlineSim.connectivity})
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => trigger('ALLOCATE_ALLOWANCE', 2000)}
              className="border border-[#D4CEC0] px-4 py-2 text-xs font-medium text-[#0B1D3A] hover:bg-[#FAF8F3] text-left"
            >
              2. Load +€20.00 Allowance (Requires ONLINE)
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => trigger('OFFLINE_SPEND', 1500)}
              className="bg-[#003399] text-white px-4 py-2 text-xs font-medium hover:bg-[#002673] text-left"
            >
              3. Execute €15.00 Offline Proximity Spend
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => trigger('ATTEMPT_DUPLICATE_SPEND', 4000)}
              className="border border-amber-400 bg-amber-50 text-amber-950 px-4 py-2 text-xs font-medium hover:bg-amber-100 text-left"
            >
              4. Simulate Cloned-Storage Duplicate Spend Attempt
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => trigger('SIMULATE_DEVICE_LOSS')}
              className="border border-red-300 bg-red-50 text-red-950 px-4 py-2 text-xs font-medium hover:bg-red-100 text-left"
            >
              5. Simulate Device Loss (Bearer-Like Cash Risk)
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => trigger('RECONNECT_AND_RECONCILE')}
              className="bg-[#0B1D3A] text-white px-4 py-2 text-xs font-medium hover:bg-[#132A4F] text-left"
            >
              6. Reconnect & Run Sync Reconciliation
            </button>
            <button
              type="button"
              disabled={busy}
              onClick={() => trigger('RESET_SANDBOX')}
              className="inline-flex items-center gap-1.5 text-xs text-[#4A5568] hover:text-[#0B1D3A] pt-1"
            >
              <RefreshCw className="h-3.5 w-3.5" />
              Reset Isolated Sandbox
            </button>
          </div>
        </div>

        {/* Event Log & Hardware Guarantee Documentation */}
        <div className="lg:col-span-7 space-y-6">
          <div className="bg-white border border-[#E4DFD3] p-6 space-y-3">
            <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
              Simulator Event Trace
            </h3>
            <div className="divide-y divide-[#EFECE4] max-h-72 overflow-y-auto text-xs">
              {offlineSim.localEvents.map((evt) => (
                <div key={evt.id} className="py-3 space-y-1">
                  <div className="flex items-center justify-between">
                    <span
                      className={`inline-flex items-center gap-1.5 font-semibold ${
                        evt.conflict ? 'text-red-800' : 'text-[#0B1D3A]'
                      }`}
                    >
                      {evt.conflict && <AlertTriangle className="h-3.5 w-3.5 text-red-700" />}
                      {evt.kind} · {evt.recipient}
                    </span>
                    <span className="font-mono tabular-nums">{formatEuroCents(evt.amountCents, locale)}</span>
                  </div>
                  <p className="text-[#4A5568]">{evt.note}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white border border-[#E4DFD3] p-6 space-y-3 text-xs text-[#4A5568]">
            <div className="flex items-center gap-2 text-[#0B1D3A] font-semibold text-sm">
              <Cpu className="h-4 w-4 text-[#003399]" />
              <span>Hardware & Scheme Guarantees Required Beyond Ordinary Local Storage</span>
            </div>
            <p>
              <strong>Why ordinary local storage fails:</strong> SQLite, SharedPreferences, or Keystore software files on a rooted or snapshotted device can be backed up, spent offline, and restored to the pre-spend state—enabling undetectable offline double spending until reconnection.
            </p>
            <p>
              <strong>Production requirements:</strong> Official ECB offline digital euro settlement requires tamper-resistant hardware Secure Elements (eSE / iSE / SIM) or certified Trusted Execution Environments (TEE) with hardware-enforced monotonic counters, remote device attestation, mutual proximity authentication, and an official Eurosystem certificate authority.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
