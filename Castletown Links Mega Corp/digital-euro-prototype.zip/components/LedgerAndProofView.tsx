'use client';

import { useState } from 'react';
import { BookOpen, CheckCircle2, FileCode2, Play, Scale, XCircle } from 'lucide-react';
import {
  formatEuroCents,
  type EcbResearchItem,
  type JournalTransactionView,
  type LedgerAccountSummary,
  type LocaleCode,
  type ReconciliationRecord,
} from '@/lib/core/types';
import type { DemoStepResult } from '@/lib/core/demo-scenario';

interface LedgerAndProofViewProps {
  locale: LocaleCode;
  accounts: LedgerAccountSummary[];
  journal: JournalTransactionView[];
  reconciliations: ReconciliationRecord[];
  ecbResearchMatrix: EcbResearchItem[];
  demoResult: {
    allPassed: boolean;
    steps: DemoStepResult[];
    finalBalances: {
      claraAvailableCents: number;
      lucasAvailableCents: number;
      cafeEuropaSettlementCents: number;
    };
  } | null;
  runningDemo: boolean;
  onRunTenStepDemo: () => Promise<void>;
}

export function LedgerAndProofView({
  locale,
  accounts,
  journal,
  reconciliations,
  ecbResearchMatrix,
  demoResult,
  runningDemo,
  onRunTenStepDemo,
}: LedgerAndProofViewProps) {
  const [section, setSection] = useState<'proof' | 'ledger' | 'ecb' | 'api'>('proof');
  const [openApiJson, setOpenApiJson] = useState<string | null>(null);

  async function loadOpenApi() {
    setSection('api');
    if (!openApiJson) {
      const res = await fetch('/v1/openapi.json');
      const data = await res.json();
      setOpenApiJson(JSON.stringify(data, null, 2));
    }
  }

  return (
    <div className="space-y-6">
      <div className="bg-[#0B1D3A] text-white p-6 border border-[#162D52] flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-xs text-[#C9A227] font-medium">
            Authoritative Accounting Core & Institutional Boundaries
          </p>
          <h2 className="mt-1 font-[family-name:var(--font-display)] text-xl font-semibold">
            Double-Entry Ledger, 10-Step Verification & ECB Research
          </h2>
          <p className="mt-1 text-xs text-slate-300 max-w-2xl">
            Append-only relational ledger with integer euro cents, database-level immutability triggers, idempotency keys, and zero blockchain requirement.
          </p>
        </div>
        <button
          type="button"
          disabled={runningDemo}
          onClick={onRunTenStepDemo}
          className="inline-flex items-center gap-2 bg-[#003399] hover:bg-[#0044CC] text-white px-5 py-2.5 text-sm font-medium disabled:opacity-50 whitespace-nowrap"
        >
          <Play className="h-4 w-4" />
          {runningDemo ? 'Running 10-Step Proof…' : 'Execute 10-Step Verification'}
        </button>
      </div>

      <div className="flex flex-wrap gap-1 border-b border-[#E4DFD3] pb-2">
        <button
          type="button"
          onClick={() => setSection('proof')}
          className={`px-3.5 py-2 text-xs font-medium whitespace-nowrap ${
            section === 'proof' ? 'bg-[#0B1D3A] text-white' : 'text-[#4A5568] hover:bg-[#F2EFE6]'
          }`}
        >
          10-Step Verification Suite
        </button>
        <button
          type="button"
          onClick={() => setSection('ledger')}
          className={`px-3.5 py-2 text-xs font-medium whitespace-nowrap ${
            section === 'ledger' ? 'bg-[#0B1D3A] text-white' : 'text-[#4A5568] hover:bg-[#F2EFE6]'
          }`}
        >
          Double-Entry Ledger ({journal.length} TX)
        </button>
        <button
          type="button"
          onClick={() => setSection('ecb')}
          className={`px-3.5 py-2 text-xs font-medium whitespace-nowrap ${
            section === 'ecb' ? 'bg-[#0B1D3A] text-white' : 'text-[#4A5568] hover:bg-[#F2EFE6]'
          }`}
        >
          ECB Research & Architecture Rationale
        </button>
        <button
          type="button"
          onClick={loadOpenApi}
          className={`px-3.5 py-2 text-xs font-medium whitespace-nowrap ${
            section === 'api' ? 'bg-[#0B1D3A] text-white' : 'text-[#4A5568] hover:bg-[#F2EFE6]'
          }`}
        >
          OpenAPI 3.1 Specification
        </button>
      </div>

      {/* 10-STEP VERIFICATION */}
      {section === 'proof' && (
        <div className="bg-white border border-[#E4DFD3] p-6 space-y-5">
          {!demoResult ? (
            <div className="py-8 text-center space-y-3">
              <p className="text-sm text-[#4A5568]">
                Click <strong>Execute 10-Step Verification</strong> to reset the synthetic fixture and run all 10 required proof steps through the live ACID ledger.
              </p>
            </div>
          ) : (
            <>
              <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#E4DFD3] pb-4">
                <div className="flex items-center gap-2">
                  {demoResult.allPassed ? (
                    <CheckCircle2 className="h-5 w-5 text-emerald-700" />
                  ) : (
                    <XCircle className="h-5 w-5 text-red-700" />
                  )}
                  <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                    {demoResult.allPassed
                      ? 'All 10 Verification Assertions Passed'
                      : 'Verification Incomplete'}
                  </h3>
                </div>
                <div className="flex flex-wrap gap-5 text-xs font-mono tabular-nums">
                  <span>Clara: {formatEuroCents(demoResult.finalBalances.claraAvailableCents, locale)}</span>
                  <span>Lucas: {formatEuroCents(demoResult.finalBalances.lucasAvailableCents, locale)}</span>
                  <span>Café Europa: {formatEuroCents(demoResult.finalBalances.cafeEuropaSettlementCents, locale)}</span>
                </div>
              </div>

              <div className="divide-y divide-[#EFECE4]">
                {demoResult.steps.map((s) => (
                  <div key={s.stepNumber} className="py-3.5 flex items-start justify-between gap-4">
                    <div className="flex items-start gap-3">
                      {s.passed ? (
                        <CheckCircle2 className="h-4 w-4 mt-0.5 text-emerald-700 shrink-0" />
                      ) : (
                        <XCircle className="h-4 w-4 mt-0.5 text-red-700 shrink-0" />
                      )}
                      <div>
                        <p className="text-sm font-semibold text-[#0B1D3A]">
                          {s.stepNumber}. {s.title}
                        </p>
                        <p className="text-xs text-[#4A5568] mt-0.5">{s.summary}</p>
                      </div>
                    </div>
                    <span className="font-mono text-xs text-[#64748B] shrink-0">
                      {s.passed ? 'PASS' : 'FAIL'}
                    </span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      )}

      {/* DOUBLE-ENTRY LEDGER EXPLORER */}
      {section === 'ledger' && (
        <div className="space-y-6">
          <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
              <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                Ledger Accounts (Integer Euro Cents)
              </h3>
              <Scale className="h-4 w-4 text-[#003399]" />
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="border-b border-[#E4DFD3] text-[#4A5568]">
                    <th className="py-2 pr-4 font-medium">Account Code</th>
                    <th className="py-2 pr-4 font-medium">Label</th>
                    <th className="py-2 pr-4 font-medium">Normal / Allow Neg</th>
                    <th className="py-2 text-right font-medium">Balance</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EFECE4]">
                  {accounts.map((acc) => (
                    <tr key={acc.id}>
                      <td className="py-2.5 pr-4 font-mono text-[#0B1D3A]">{acc.code}</td>
                      <td className="py-2.5 pr-4">{acc.ownerLabel}</td>
                      <td className="py-2.5 pr-4 font-mono text-[#4A5568]">
                        {acc.normalBalance} · {acc.allowNegative ? 'Negative Allowed' : 'Non-Negative'}
                      </td>
                      <td className="py-2.5 text-right font-mono font-semibold tabular-nums">
                        {formatEuroCents(acc.balanceCents, locale)} ({acc.balanceCents}¢)
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
            <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
              Append-Only Journal Transactions & Balanced Postings
            </h3>
            {journal.length === 0 ? (
              <p className="text-sm text-[#4A5568]">
                No journal entries posted yet. Run the 10-Step Verification or fund a wallet.
              </p>
            ) : (
              <div className="space-y-4">
                {journal.map((tx) => (
                  <div key={tx.id} className="border border-[#E4DFD3] bg-[#FAF8F3] p-4 space-y-2 text-xs">
                    <div className="flex flex-wrap justify-between gap-2">
                      <span className="font-semibold text-[#0B1D3A]">
                        {tx.txType} · {tx.description}
                      </span>
                      <span className="font-mono text-[#4A5568]">
                        {tx.id} · Debits {tx.totalDebitCents}¢ == Credits {tx.totalCreditCents}¢
                      </span>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                      {tx.postings.map((p) => (
                        <div key={p.id} className="bg-white border border-[#E4DFD3] px-3 py-2 flex justify-between font-mono">
                          <span className="truncate pr-2">{p.accountCode}</span>
                          <span className="tabular-nums shrink-0">
                            {p.debitCents > 0 ? `DR ${p.debitCents}¢` : `CR ${p.creditCents}¢`}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {reconciliations.length > 0 && (
            <div className="bg-white border border-[#E4DFD3] p-5 text-xs">
              <p className="font-semibold text-[#0B1D3A]">
                Latest Reconciliation: {reconciliations[0].status} · Discrepancy:{' '}
                {reconciliations[0].discrepancyCents}¢
              </p>
              <p className="font-mono text-[#4A5568] mt-1">
                {reconciliations[0].notes} · {reconciliations[0].createdAt}
              </p>
            </div>
          )}
        </div>
      )}

      {/* ECB RESEARCH & ARCHITECTURE RATIONALE */}
      {section === 'ecb' && (
        <div className="space-y-6">
          <div className="bg-white border border-[#E4DFD3] p-6 space-y-3 text-sm text-[#0B1D3A]">
            <div className="flex items-center gap-2 border-b border-[#E4DFD3] pb-3">
              <BookOpen className="h-4 w-4 text-[#003399]" />
              <h3 className="font-[family-name:var(--font-display)] text-base font-semibold">
                Why an Append-Only Relational Double-Entry Ledger (No Blockchain Required)
              </h3>
            </div>
            <p className="text-[#4A5568] leading-relaxed">
              A retail CBDC operated within a regulated European clearing and PSP model is a high-throughput, institutional-trust system rather than a permissionless consensus problem. An append-only PostgreSQL (or SQLite WAL in standalone preview) double-entry ledger provides deterministic finality in single-digit milliseconds, serializable concurrency locks (<code className="font-mono">SELECT ... FOR UPDATE</code> / <code className="font-mono">BEGIN IMMEDIATE</code>), native <code className="font-mono">CHECK</code> constraints preventing negative balances, trivial GDPR/PII separation from settlement postings, and full compliance auditability without proof-of-work or distributed consensus overhead.
            </p>
          </div>

          <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
            <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
              ECB Digital Euro Requirements vs Proposals vs Demonstration Assumptions
            </h3>
            <div className="divide-y divide-[#EFECE4]">
              {ecbResearchMatrix.map((item) => (
                <div key={item.topic} className="py-4 space-y-1.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h4 className="font-semibold text-sm text-[#0B1D3A]">{item.topic}</h4>
                    <span className="font-mono text-xs text-[#003399] font-medium">
                      {item.classification}
                    </span>
                  </div>
                  <p className="text-xs text-[#4A5568]">{item.summary}</p>
                  <p className="text-xs text-[#0B1D3A]">
                    <strong>Prototype implementation:</strong> {item.prototypeImplementation}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* OPENAPI SPEC */}
      {section === 'api' && (
        <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
            <div className="flex items-center gap-2">
              <FileCode2 className="h-4 w-4 text-[#003399]" />
              <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                Published OpenAPI 3.1 Specification (/v1/openapi.json)
              </h3>
            </div>
            <a
              href="/v1/openapi.json"
              target="_blank"
              rel="noreferrer"
              className="text-xs font-medium text-[#003399] hover:underline"
            >
              Open Raw JSON
            </a>
          </div>
          <pre className="bg-[#0B1D3A] text-slate-100 p-4 text-xs font-mono overflow-x-auto max-h-[500px]">
            {openApiJson || 'Loading OpenAPI specification…'}
          </pre>
        </div>
      )}
    </div>
  );
}
