'use client';

import { useEffect, useState } from 'react';
import {
  CheckCircle2,
  Clock,
  Download,
  QrCode,
  RefreshCw,
  RotateCcw,
  Store,
  XCircle,
} from 'lucide-react';
import {
  formatEuroCents,
  parseEuroInputToCents,
  type LocaleCode,
  type MerchantProfile,
  type PaymentRequestRecord,
} from '@/lib/core/types';
import { QrCodeGraphic } from './QrCodeGraphic';

interface MerchantCheckoutViewProps {
  locale: LocaleCode;
  merchants: MerchantProfile[];
  openPaymentRequests: PaymentRequestRecord[];
  merchantPayments: Array<Record<string, unknown>>;
  onRefresh: () => Promise<void>;
  onPayRequestInWallet: (requestId: string) => void;
}

export function MerchantCheckoutView({
  locale,
  merchants,
  openPaymentRequests,
  merchantPayments,
  onRefresh,
  onPayRequestInWallet,
}: MerchantCheckoutViewProps) {
  const [selectedMerchantId, setSelectedMerchantId] = useState(merchants[0]?.id ?? 'mrc_cafe_europa');
  const [amountInput, setAmountInput] = useState('12.50');
  const [description, setDescription] = useState('2x Espresso & Croissant');
  const [expirySeconds, setExpirySeconds] = useState(180);
  const [activeRequest, setActiveRequest] = useState<PaymentRequestRecord | null>(
    openPaymentRequests.find((r) => r.kind === 'MERCHANT_POS') ?? null
  );
  const [refundAmountInput, setRefundAmountInput] = useState('2.50');
  const [refundReason, setRefundReason] = useState('Croissant unavailable · partial refund');
  const [statusMsg, setStatusMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  // Merchant registration form
  const [showRegister, setShowRegister] = useState(false);
  const [newLegalName, setNewLegalName] = useState('Nordic Bookshop GmbH (Synthetic)');
  const [newDisplayName, setNewDisplayName] = useState('Nordic Bookshop Munich');
  const [newRegCode, setNewRegCode] = useState('HRB-SYN-90812');
  const [newCity, setNewCity] = useState('Munich');

  const activeMerchant = merchants.find((m) => m.id === selectedMerchantId) ?? merchants[0];

  // Authoritative backend polling for active QR payment request
  useEffect(() => {
    if (!activeRequest || activeRequest.status !== 'OPEN') return;
    const timer = setInterval(async () => {
      try {
        const res = await fetch(`/v1/payment-requests/${activeRequest.id}`);
        if (!res.ok) return;
        const data = await res.json();
        if (data.paymentRequest) {
          setActiveRequest(data.paymentRequest);
          if (data.paymentRequest.status !== 'OPEN') {
            await onRefresh();
          }
        }
      } catch {
        // Ignore transient polling failure
      }
    }, 2500);
    return () => clearInterval(timer);
  }, [activeRequest, onRefresh]);

  async function handleCreateQrRequest(e: React.FormEvent) {
    e.preventDefault();
    if (!activeMerchant) return;
    setBusy(true);
    setStatusMsg(null);
    try {
      const cents = parseEuroInputToCents(amountInput);
      if (!cents) throw new Error('Enter a valid positive euro amount');
      const res = await fetch('/v1/payment-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kind: 'MERCHANT_POS',
          merchantId: activeMerchant.id,
          amountCents: cents,
          description,
          expiresInSeconds: expirySeconds,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error?.message || 'Failed to create request');
      setActiveRequest(data.paymentRequest);
      setStatusMsg({
        kind: 'ok',
        text: `Issued expiring QR request ${data.paymentRequest.id}. Merchant POS is polling backend authority.`,
      });
      await onRefresh();
    } catch (err) {
      setStatusMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Request failed' });
    } finally {
      setBusy(false);
    }
  }

  async function handleIssueRefund(paymentId: string, maxRefundableCents: number) {
    if (!activeMerchant) return;
    setBusy(true);
    setStatusMsg(null);
    try {
      const cents = parseEuroInputToCents(refundAmountInput);
      if (!cents || cents > maxRefundableCents) {
        throw new Error(
          `Enter a valid refund up to ${formatEuroCents(maxRefundableCents, locale)}`
        );
      }
      const res = await fetch('/v1/refunds', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          idempotencyKey: `ref-ui-${paymentId}-${Date.now()}`,
          originalPaymentId: paymentId,
          merchantId: activeMerchant.id,
          amountCents: cents,
          reason: refundReason,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error?.message || 'Refund failed');
      setStatusMsg({
        kind: 'ok',
        text: `Refund ${data.refund.id} posted (${formatEuroCents(cents, locale)}). Linked journal TX: ${data.refund.journalTxId}`,
      });
      await onRefresh();
    } catch (err) {
      setStatusMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Refund error' });
    } finally {
      setBusy(false);
    }
  }

  async function handleRegisterMerchant(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setStatusMsg(null);
    try {
      const res = await fetch('/v1/merchants', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          legalName: newLegalName,
          displayName: newDisplayName,
          registrationCode: newRegCode,
          mcc: '5942',
          city: newCity,
          countryCode: 'DE',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error?.message || 'Registration failed');
      setSelectedMerchantId(data.merchant.id);
      setShowRegister(false);
      setStatusMsg({ kind: 'ok', text: `Registered synthetic merchant ${data.merchant.displayName}` });
      await onRefresh();
    } catch (err) {
      setStatusMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Merchant registration failed' });
    } finally {
      setBusy(false);
    }
  }

  const filteredPayments = merchantPayments.filter(
    (p) => String(p.payee_id) === activeMerchant?.id
  );

  return (
    <div className="space-y-6">
      {/* Merchant Header Summary */}
      <div className="bg-[#0B1D3A] text-white p-6 border border-[#162D52] flex flex-wrap items-center justify-between gap-6">
        <div>
          <p className="text-xs text-[#C9A227] font-medium">Merchant POS & Settlement Console</p>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            <select
              value={activeMerchant?.id ?? ''}
              onChange={(e) => setSelectedMerchantId(e.target.value)}
              className="bg-[#132A4F] border border-[#284574] px-3 py-2 text-sm text-white"
            >
              {merchants.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.displayName} ({m.city} · {m.registrationCode})
                </option>
              ))}
            </select>
            <button
              type="button"
              onClick={() => setShowRegister((v) => !v)}
              className="border border-[#2F4E80] bg-[#132A4F] px-3 py-2 text-xs font-medium text-white hover:bg-[#1B3A6B] whitespace-nowrap"
            >
              {showRegister ? 'Close Form' : 'Register Synthetic Merchant'}
            </button>
          </div>
          {activeMerchant && (
            <p className="mt-2 text-xs text-slate-300">
              {activeMerchant.legalName} · MCC {activeMerchant.mcc} · Verified Synthetic Registry
            </p>
          )}
        </div>
        {activeMerchant && (
          <div className="text-right">
            <p className="text-xs text-slate-300">Merchant Settlement Balance</p>
            <p className="mt-1 font-[family-name:var(--font-display)] text-3xl font-semibold tabular-nums">
              {formatEuroCents(activeMerchant.settlementBalanceCents, locale)}
            </p>
          </div>
        )}
      </div>

      {statusMsg && (
        <div
          className={`p-4 border text-sm flex items-center gap-2 ${
            statusMsg.kind === 'ok'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
              : 'bg-red-50 border-red-300 text-red-950'
          }`}
        >
          {statusMsg.kind === 'ok' ? (
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-700" />
          ) : (
            <XCircle className="h-4 w-4 shrink-0 text-red-700" />
          )}
          <span>{statusMsg.text}</span>
        </div>
      )}

      {showRegister && (
        <form onSubmit={handleRegisterMerchant} className="bg-white border border-[#E4DFD3] p-6 space-y-4">
          <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
            Register Synthetic Merchant
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <input
              value={newDisplayName}
              onChange={(e) => setNewDisplayName(e.target.value)}
              placeholder="Display Name"
              className="border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
              required
            />
            <input
              value={newLegalName}
              onChange={(e) => setNewLegalName(e.target.value)}
              placeholder="Legal Entity Name"
              className="border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
              required
            />
            <input
              value={newRegCode}
              onChange={(e) => setNewRegCode(e.target.value)}
              placeholder="Registration Code"
              className="border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm font-mono"
              required
            />
            <input
              value={newCity}
              onChange={(e) => setNewCity(e.target.value)}
              placeholder="City"
              className="border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
              required
            />
          </div>
          <button
            type="submit"
            disabled={busy}
            className="bg-[#003399] text-white px-5 py-2 text-sm font-medium hover:bg-[#002673]"
          >
            Create Merchant Account
          </button>
        </form>
      )}

      {/* POS Request Creator & Live Authoritative QR Display */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <form onSubmit={handleCreateQrRequest} className="lg:col-span-5 bg-white border border-[#E4DFD3] p-6 space-y-4">
          <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
            <h2 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
              Create Payment Request
            </h2>
            <Store className="h-4 w-4 text-[#003399]" />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#4A5568] mb-1">Amount (EUR)</label>
            <input
              value={amountInput}
              onChange={(e) => setAmountInput(e.target.value)}
              className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-lg font-mono tabular-nums"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#4A5568] mb-1">Basket / Reference</label>
            <input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#4A5568] mb-1">Expiry Window</label>
            <select
              value={expirySeconds}
              onChange={(e) => setExpirySeconds(Number(e.target.value))}
              className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
            >
              <option value={60}>60 seconds</option>
              <option value={180}>3 minutes</option>
              <option value={300}>5 minutes</option>
            </select>
          </div>

          <button
            type="submit"
            disabled={busy}
            className="w-full inline-flex items-center justify-center gap-2 bg-[#003399] text-white px-4 py-2.5 text-sm font-medium hover:bg-[#002673] disabled:opacity-50"
          >
            <QrCode className="h-4 w-4" />
            Generate Expiring Payment QR
          </button>
        </form>

        <div className="lg:col-span-7 bg-white border border-[#E4DFD3] p-6">
          <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
            <h2 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
              Customer Checkout QR & Backend Status
            </h2>
            <span className="text-xs text-[#4A5568]">Browser never declares settlement</span>
          </div>

          {!activeRequest ? (
            <p className="py-12 text-sm text-[#4A5568]">
              Generate a payment request on the left to display a signed, expiring Digital Euro QR code.
            </p>
          ) : (
            <div className="mt-5 flex flex-col sm:flex-row items-start gap-6">
              <div className="shrink-0">
                <QrCodeGraphic value={activeRequest.qrPayload} size={184} />
              </div>
              <div className="flex-1 space-y-2 text-sm min-w-0">
                <div className="flex items-center gap-2 font-semibold text-[#0B1D3A]">
                  {activeRequest.status === 'PAID' ? (
                    <CheckCircle2 className="h-4 w-4 text-emerald-700" />
                  ) : (
                    <Clock className="h-4 w-4 text-[#003399]" />
                  )}
                  <span>
                    Backend Status: {activeRequest.status}
                  </span>
                </div>
                <p className="font-mono text-2xl font-semibold tabular-nums text-[#0B1D3A]">
                  {formatEuroCents(activeRequest.amountCents, locale)}
                </p>
                <p className="text-xs text-[#4A5568]">{activeRequest.description}</p>
                <p className="font-mono text-[11px] text-[#64748B] break-all">
                  QR Payload: {activeRequest.qrPayload}
                </p>
                <p className="text-xs text-[#4A5568]">
                  Expires: {new Date(activeRequest.expiresAt).toLocaleTimeString()}
                </p>

                {activeRequest.status === 'OPEN' && (
                  <div className="pt-2 flex flex-wrap gap-2">
                    <button
                      type="button"
                      onClick={() => onPayRequestInWallet(activeRequest.id)}
                      className="bg-[#0B1D3A] text-white px-4 py-2 text-xs font-medium hover:bg-[#132A4F]"
                    >
                      Open in Consumer Wallet Pay
                    </button>
                    <button
                      type="button"
                      onClick={onRefresh}
                      className="inline-flex items-center gap-1 border border-[#D4CEC0] px-3 py-2 text-xs text-[#0B1D3A] hover:bg-[#FAF8F3]"
                    >
                      <RefreshCw className="h-3 w-3" />
                      Poll Backend
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Settled Receipts, Full & Partial Refunds, and Exports */}
      <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#E4DFD3] pb-3">
          <div>
            <h2 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
              Merchant Transactions, Receipts & Refunds
            </h2>
            <p className="text-xs text-[#4A5568]">
              Partial or full refunds create linked compensating journal entries without mutating settled postings.
            </p>
          </div>
          {activeMerchant && (
            <div className="flex items-center gap-3">
              <a
                href={`/v1/merchants/export?merchantId=${activeMerchant.id}&format=csv`}
                className="inline-flex items-center gap-1.5 border border-[#D4CEC0] px-3 py-1.5 text-xs font-medium text-[#0B1D3A] hover:bg-[#FAF8F3]"
              >
                <Download className="h-3.5 w-3.5" />
                Export CSV
              </a>
              <a
                href={`/v1/merchants/export?merchantId=${activeMerchant.id}&format=json`}
                className="inline-flex items-center gap-1.5 border border-[#D4CEC0] px-3 py-1.5 text-xs font-medium text-[#0B1D3A] hover:bg-[#FAF8F3]"
              >
                <Download className="h-3.5 w-3.5" />
                Export JSON
              </a>
            </div>
          )}
        </div>

        <div className="flex flex-wrap items-end gap-3 bg-[#FAF8F3] border border-[#E4DFD3] p-3 text-xs">
          <div>
            <label className="block text-[#4A5568] mb-1">Refund Amount (EUR)</label>
            <input
              value={refundAmountInput}
              onChange={(e) => setRefundAmountInput(e.target.value)}
              className="border border-[#D4CEC0] bg-white px-2.5 py-1.5 font-mono w-28"
            />
          </div>
          <div className="flex-1 min-w-[200px]">
            <label className="block text-[#4A5568] mb-1">Refund Reason</label>
            <input
              value={refundReason}
              onChange={(e) => setRefundReason(e.target.value)}
              className="w-full border border-[#D4CEC0] bg-white px-2.5 py-1.5"
            />
          </div>
        </div>

        {filteredPayments.length === 0 ? (
          <p className="py-6 text-sm text-[#4A5568]">
            No merchant payments yet. Generate a QR request above and pay it from the Consumer Wallet.
          </p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-[#E4DFD3] text-xs text-[#4A5568]">
                  <th className="py-2 pr-4 font-medium">Payment ID / Customer</th>
                  <th className="py-2 pr-4 font-medium">State</th>
                  <th className="py-2 pr-4 font-medium text-right">Settled</th>
                  <th className="py-2 pr-4 font-medium text-right">Refunded</th>
                  <th className="py-2 text-right font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EFECE4]">
                {filteredPayments.map((p) => {
                  const id = String(p.id);
                  const amount = Number(p.amount_cents);
                  const refunded = Number(p.refunded_cents);
                  const remaining = amount - refunded;
                  const state = String(p.state);
                  return (
                    <tr key={id} className="hover:bg-[#FAF8F3]">
                      <td className="py-3 pr-4">
                        <p className="font-medium text-[#0B1D3A]">{String(p.payer_name)}</p>
                        <p className="font-mono text-xs text-[#64748B]">
                          {id} · JTX: {p.journal_tx_id ? String(p.journal_tx_id) : '—'}
                        </p>
                      </td>
                      <td className="py-3 pr-4 text-xs font-medium">{state}</td>
                      <td className="py-3 pr-4 text-right font-mono tabular-nums">
                        {formatEuroCents(amount, locale)}
                      </td>
                      <td className="py-3 pr-4 text-right font-mono tabular-nums">
                        {refunded > 0 ? formatEuroCents(refunded, locale) : '—'}
                      </td>
                      <td className="py-3 text-right">
                        {state === 'POSTED' && remaining > 0 ? (
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => handleIssueRefund(id, remaining)}
                            className="inline-flex items-center gap-1 border border-[#0B1D3A] px-2.5 py-1 text-xs font-medium text-[#0B1D3A] hover:bg-[#F2EFE6]"
                          >
                            <RotateCcw className="h-3 w-3" />
                            Issue Refund
                          </button>
                        ) : (
                          <span className="text-xs text-[#64748B]">Closed</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
