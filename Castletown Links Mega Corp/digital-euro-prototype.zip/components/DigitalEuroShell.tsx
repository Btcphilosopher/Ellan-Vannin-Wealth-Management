'use client';

import Link from 'next/link';
import { useCallback, useEffect, useState } from 'react';
import {
  TRANSLATIONS,
  type AdminApprovalRequest,
  type AuditLogRecord,
  type ConsumerProfile,
  type DeviceRecord,
  type EcbResearchItem,
  type IncidentRecord,
  type JournalTransactionView,
  type LedgerAccountSummary,
  type LocaleCode,
  type MerchantProfile,
  type OfflineWalletState,
  type PaymentRecord,
  type PaymentRequestRecord,
  type ReconciliationRecord,
  type StaffRole,
} from '@/lib/core/types';
import type { DemoStepResult } from '@/lib/core/demo-scenario';
import { AdminConsoleView } from './AdminConsoleView';
import { ConsumerWalletView } from './ConsumerWalletView';
import { LedgerAndProofView } from './LedgerAndProofView';
import { MerchantCheckoutView } from './MerchantCheckoutView';
import { OfflineSimulatorView } from './OfflineSimulatorView';

type WorkspaceKey = 'consumer' | 'merchant' | 'admin' | 'ledger' | 'offline';

interface BootstrapData {
  consumers: ConsumerProfile[];
  merchants: MerchantProfile[];
  openPaymentRequests: PaymentRequestRecord[];
  merchantPayments: Array<Record<string, unknown>>;
  activeConsumer: ConsumerProfile | null;
  activeDevices: DeviceRecord[];
  activeActivity: {
    payments: PaymentRecord[];
    refunds: Array<{
      id: string;
      originalPaymentId: string;
      amountCents: number;
      reason: string;
      status: string;
      journalTxId: string | null;
      createdAt: string;
    }>;
    fundings: Array<Record<string, unknown>>;
    redemptions: Array<Record<string, unknown>>;
  } | null;
  adminOverview: {
    consumers: ConsumerProfile[];
    merchants: MerchantProfile[];
    accounts: LedgerAccountSummary[];
    journal: JournalTransactionView[];
    reconciliations: ReconciliationRecord[];
    approvals: AdminApprovalRequest[];
    incidents: IncidentRecord[];
    auditLogs: AuditLogRecord[];
    payments: Array<Record<string, unknown>>;
    refunds: Array<Record<string, unknown>>;
  };
  offlineSim: OfflineWalletState;
  ecbResearchMatrix: EcbResearchItem[];
}

export function DigitalEuroShell({ initialData }: { initialData: BootstrapData }) {
  const [workspace, setWorkspace] = useState<WorkspaceKey>('consumer');
  const [locale, setLocale] = useState<LocaleCode>('en');
  const [data, setData] = useState<BootstrapData>(initialData);
  const [activeConsumerId, setActiveConsumerId] = useState<string>(
    initialData.activeConsumer?.id ?? 'usr_clara'
  );
  const [consumerToken, setConsumerToken] = useState<string | null>(null);
  const [staffRole, setStaffRole] = useState<StaffRole>('OPERATOR');
  const [staffToken, setStaffToken] = useState<string | null>(null);
  const [preselectedRequestId, setPreselectedRequestId] = useState<string | null>(null);
  const [runningDemo, setRunningDemo] = useState(false);
  const [demoResult, setDemoResult] = useState<{
    allPassed: boolean;
    steps: DemoStepResult[];
    finalBalances: {
      claraAvailableCents: number;
      lucasAvailableCents: number;
      cafeEuropaSettlementCents: number;
    };
  } | null>(null);

  const t = TRANSLATIONS[locale];

  const issueDemoToken = useCallback(async (personaId: string): Promise<string | null> => {
    try {
      const res = await fetch('/v1/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ demoPersonaId: personaId }),
      });
      if (!res.ok) return null;
      const json = await res.json();
      return json.token ?? null;
    } catch {
      return null;
    }
  }, []);

  useEffect(() => {
    issueDemoToken('usr_clara').then((tok) => {
      if (tok) setConsumerToken(tok);
    });
    issueDemoToken('staff_operator').then((tok) => {
      if (tok) setStaffToken(tok);
    });
  }, [issueDemoToken]);

  const refreshAll = useCallback(
    async (overrideConsumerId?: string) => {
      const targetId = overrideConsumerId ?? activeConsumerId;
      const res = await fetch(`/v1/bootstrap?consumerId=${encodeURIComponent(targetId)}`);
      if (!res.ok) return;
      const json = (await res.json()) as BootstrapData;
      setData(json);
    },
    [activeConsumerId]
  );

  async function handleSwitchConsumer(userId: string) {
    setActiveConsumerId(userId);
    if (userId === 'usr_clara' || userId === 'usr_lucas') {
      const tok = await issueDemoToken(userId);
      if (tok) setConsumerToken(tok);
    }
    await refreshAll(userId);
  }

  async function handleSwitchStaffRole(role: StaffRole) {
    setStaffRole(role);
    const personaId = role === 'SUPERVISOR' ? 'staff_supervisor' : 'staff_operator';
    const tok = await issueDemoToken(personaId);
    if (tok) setStaffToken(tok);
  }

  async function handleRunTenStepDemo() {
    setRunningDemo(true);
    try {
      const res = await fetch('/v1/demo/run-scenario', { method: 'POST' });
      const json = await res.json();
      setDemoResult(json);
      setWorkspace('ledger');
      await refreshAll('usr_clara');
      setActiveConsumerId('usr_clara');
      const tok = await issueDemoToken('usr_clara');
      if (tok) setConsumerToken(tok);
    } finally {
      setRunningDemo(false);
    }
  }

  async function handleResetDemo() {
    await fetch('/v1/demo/reset', { method: 'POST' });
    setDemoResult(null);
    await handleSwitchConsumer('usr_clara');
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF8F3] text-[#0B1D3A]">
      {/* Strict 3-Zone Top Bar Contract */}
      <header className="bg-[#0B1D3A] text-white border-b border-[#1E3A66]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
          <Link
            href="/"
            className="font-[family-name:var(--font-display)] text-lg font-semibold tracking-tight text-white whitespace-nowrap shrink-0"
          >
            Digital Euro
          </Link>

          <nav aria-label="Primary workspaces" className="hidden md:flex items-center gap-6 text-sm font-medium">
            {(
              [
                ['consumer', 'Consumer Wallet'],
                ['merchant', 'Merchant POS'],
                ['admin', 'Admin Console'],
                ['ledger', 'Ledger & Proof'],
                ['offline', 'Offline Lab'],
              ] as Array<[WorkspaceKey, string]>
            ).map(([key, label]) => {
              const active = workspace === key;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setWorkspace(key)}
                  className={`py-1 transition-colors whitespace-nowrap shrink-0 border-b-2 ${
                    active
                      ? 'border-[#C9A227] text-white'
                      : 'border-transparent text-slate-300 hover:text-white'
                  }`}
                >
                  {label}
                </button>
              );
            })}
          </nav>

          <button
            type="button"
            disabled={runningDemo}
            onClick={handleRunTenStepDemo}
            className="bg-[#003399] hover:bg-[#0044CC] text-white px-4 py-2 text-xs font-medium transition-colors whitespace-nowrap shrink-0 disabled:opacity-50"
          >
            {runningDemo ? 'Running Proof…' : 'Run 10-Step Proof'}
          </button>
        </div>

        {/* Mobile compact workspace nav */}
        <div className="md:hidden border-t border-[#1E3A66] px-4 py-2 flex items-center gap-4 overflow-x-auto text-xs">
          {(
            [
              ['consumer', 'Wallet'],
              ['merchant', 'Merchant'],
              ['admin', 'Admin'],
              ['ledger', 'Ledger'],
              ['offline', 'Offline'],
            ] as Array<[WorkspaceKey, string]>
          ).map(([key, label]) => (
            <button
              key={key}
              type="button"
              onClick={() => setWorkspace(key)}
              className={`whitespace-nowrap shrink-0 pb-0.5 border-b-2 ${
                workspace === key ? 'border-[#C9A227] text-white font-semibold' : 'border-transparent text-slate-300'
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </header>

      {/* Prominent Simulation Notice & Locale Strip */}
      <div className="bg-[#F2EFE6] border-b border-[#E4DFD3]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-2 flex flex-wrap items-center justify-between gap-3 text-xs">
          <p className="font-semibold text-[#0B1D3A] tracking-tight">{t.banner}</p>
          <div className="flex items-center gap-4 shrink-0">
            <div className="flex items-center gap-1" role="group" aria-label="Language selection">
              {(['en', 'de', 'fr', 'es'] as LocaleCode[]).map((code) => (
                <button
                  key={code}
                  type="button"
                  onClick={() => setLocale(code)}
                  className={`px-2 py-0.5 uppercase font-mono text-[11px] transition-colors ${
                    locale === code
                      ? 'bg-[#0B1D3A] text-white font-semibold'
                      : 'text-[#4A5568] hover:text-[#0B1D3A]'
                  }`}
                >
                  {code}
                </button>
              ))}
            </div>
            <button
              type="button"
              onClick={handleResetDemo}
              className="text-[#003399] font-medium hover:underline whitespace-nowrap"
            >
              Reset Fixture
            </button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-8">
        {workspace === 'consumer' && (
          <ConsumerWalletView
            locale={locale}
            consumers={data.consumers}
            merchants={data.merchants}
            activeConsumer={data.activeConsumer}
            activeDevices={data.activeDevices}
            activeActivity={data.activeActivity}
            openPaymentRequests={data.openPaymentRequests}
            consumerToken={consumerToken}
            preselectedRequestId={preselectedRequestId}
            onClearPreselectedRequest={() => setPreselectedRequestId(null)}
            onSwitchConsumer={handleSwitchConsumer}
            onRefresh={() => refreshAll()}
            onTokenIssued={(_uid, tok) => setConsumerToken(tok)}
          />
        )}

        {workspace === 'merchant' && (
          <MerchantCheckoutView
            locale={locale}
            merchants={data.merchants}
            openPaymentRequests={data.openPaymentRequests}
            merchantPayments={data.merchantPayments}
            onRefresh={() => refreshAll()}
            onPayRequestInWallet={(reqId) => {
              setPreselectedRequestId(reqId);
              setWorkspace('consumer');
            }}
          />
        )}

        {workspace === 'admin' && (
          <AdminConsoleView
            locale={locale}
            adminOverview={data.adminOverview}
            staffRole={staffRole}
            staffToken={staffToken}
            onSwitchStaffRole={handleSwitchStaffRole}
            onRefresh={() => refreshAll()}
          />
        )}

        {workspace === 'ledger' && (
          <LedgerAndProofView
            locale={locale}
            accounts={data.adminOverview.accounts}
            journal={data.adminOverview.journal}
            reconciliations={data.adminOverview.reconciliations}
            ecbResearchMatrix={data.ecbResearchMatrix}
            demoResult={demoResult}
            runningDemo={runningDemo}
            onRunTenStepDemo={handleRunTenStepDemo}
          />
        )}

        {workspace === 'offline' && (
          <OfflineSimulatorView
            locale={locale}
            offlineSim={data.offlineSim}
            onRefresh={() => refreshAll()}
          />
        )}
      </main>

      <footer className="border-t border-[#E4DFD3] bg-white py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-wrap items-center justify-between gap-4 text-xs text-[#4A5568]">
          <span>
            Digital Euro Independent Research Prototype · Synthetic Identities & Simulated Funds Only
          </span>
          <div className="flex items-center gap-4">
            <a href="/v1/openapi.json" target="_blank" rel="noreferrer" className="text-[#003399] hover:underline">
              OpenAPI Spec
            </a>
            <a href="/v1/health" target="_blank" rel="noreferrer" className="text-[#003399] hover:underline">
              API Health
            </a>
          </div>
        </div>
      </footer>
    </div>
  );
}
