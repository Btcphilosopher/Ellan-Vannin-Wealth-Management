'use client';

import { useState } from 'react';
import {
  AlertOctagon,
  CheckCircle2,
  Download,
  FileSpreadsheet,
  Lock,
  Scale,
  ShieldAlert,
  Unlock,
  XCircle,
} from 'lucide-react';
import {
  formatEuroCents,
  type AdminApprovalRequest,
  type AuditLogRecord,
  type ConsumerProfile,
  type IncidentRecord,
  type LocaleCode,
  type MerchantProfile,
  type ReconciliationRecord,
  type StaffRole,
} from '@/lib/core/types';

interface AdminConsoleViewProps {
  locale: LocaleCode;
  adminOverview: {
    consumers: ConsumerProfile[];
    merchants: MerchantProfile[];
    reconciliations: ReconciliationRecord[];
    approvals: AdminApprovalRequest[];
    incidents: IncidentRecord[];
    auditLogs: AuditLogRecord[];
    payments: Array<Record<string, unknown>>;
    refunds: Array<Record<string, unknown>>;
  };
  staffRole: StaffRole;
  staffToken: string | null;
  onSwitchStaffRole: (role: StaffRole) => Promise<void>;
  onRefresh: () => Promise<void>;
}

export function AdminConsoleView({
  locale,
  adminOverview,
  staffRole,
  staffToken,
  onSwitchStaffRole,
  onRefresh,
}: AdminConsoleViewProps) {
  const [subTab, setSubTab] = useState<'directory' | 'approvals' | 'investigations' | 'reconciliation' | 'audit'>('directory');
  const [reasonInput, setReasonInput] = useState('Routine operational review and limit verification');
  const [holdingLimitEur, setHoldingLimitEur] = useState('3000.00');
  const [dailyLimitEur, setDailyLimitEur] = useState('1500.00');
  const [singleLimitEur, setSingleLimitEur] = useState('1000.00');
  const [selectedUserId, setSelectedUserId] = useState(adminOverview.consumers[0]?.id ?? 'usr_clara');
  const [adjustmentEur, setAdjustmentEur] = useState('5.00');
  const [incidentTitle, setIncidentTitle] = useState('Commercial bank adapter latency spike');
  const [incidentSeverity, setIncidentSeverity] = useState<'LOW' | 'MEDIUM' | 'HIGH'>('MEDIUM');
  const [msg, setMsg] = useState<{ kind: 'ok' | 'err'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  async function runAdminAction(
    action: string,
    targetId?: string,
    payload?: Record<string, unknown>
  ) {
    setBusy(true);
    setMsg(null);
    try {
      const res = await fetch('/v1/admin/actions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(staffToken ? { Authorization: `Bearer ${staffToken}` } : {}),
        },
        body: JSON.stringify({
          action,
          targetId,
          reason: reasonInput,
          payload,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error?.message || `HTTP ${res.status}`);
      setMsg({ kind: 'ok', text: data.message });
      await onRefresh();
    } catch (err) {
      setMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Admin action failed' });
    } finally {
      setBusy(false);
    }
  }

  async function handleDownloadAudit(format: 'csv' | 'json') {
    if (!staffToken) return;
    const res = await fetch(`/v1/admin/audit-export?format=${format}`, {
      headers: { Authorization: `Bearer ${staffToken}` },
    });
    const text = await res.text();
    const blob = new Blob([text], { type: format === 'csv' ? 'text/csv' : 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `digital-euro-audit-export.${format}`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="space-y-6">
      {/* Staff Role & Permission Banner */}
      <div className="bg-[#0B1D3A] text-white p-6 border border-[#162D52] flex flex-wrap items-center justify-between gap-4">
        <div>
          <p className="text-xs text-[#C9A227] font-medium">
            Administrative & Compliance Console · Four-Eyes Dual Control
          </p>
          <h2 className="mt-1 font-[family-name:var(--font-display)] text-xl font-semibold">
            Operations, Limits, Reconciliation & Audit
          </h2>
          <p className="mt-1 text-xs text-slate-300">
            Sensitive wallet freezes, limit updates, and compensating entries require recorded reasons and Supervisor approval.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-300 mr-1">Active Staff Role:</span>
          {(['OPERATOR', 'SUPERVISOR'] as StaffRole[]).map((role) => (
            <button
              key={role}
              type="button"
              onClick={() => onSwitchStaffRole(role)}
              className={`px-3 py-1.5 text-xs font-medium border transition-colors whitespace-nowrap ${
                staffRole === role
                  ? 'bg-[#003399] border-[#3366CC] text-white'
                  : 'bg-[#132A4F] border-[#284574] text-slate-200 hover:bg-[#1B3A6B]'
              }`}
            >
              {role === 'OPERATOR' ? 'Operator (Maker)' : 'Supervisor (Checker)'}
            </button>
          ))}
        </div>
      </div>

      {/* Mandatory Recorded Reason Input */}
      <div className="bg-white border border-[#E4DFD3] p-4 flex flex-wrap items-center gap-4">
        <label htmlFor="admin-reason" className="text-xs font-semibold text-[#0B1D3A] whitespace-nowrap">
          Recorded Action Reason (Mandatory):
        </label>
        <input
          id="admin-reason"
          value={reasonInput}
          onChange={(e) => setReasonInput(e.target.value)}
          className="flex-1 min-w-[260px] border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
          placeholder="Document operational justification..."
        />
      </div>

      {msg && (
        <div
          className={`p-4 border text-sm flex items-center gap-2 ${
            msg.kind === 'ok'
              ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
              : 'bg-red-50 border-red-300 text-red-950'
          }`}
        >
          {msg.kind === 'ok' ? (
            <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-700" />
          ) : (
            <XCircle className="h-4 w-4 shrink-0 text-red-700" />
          )}
          <span>{msg.text}</span>
        </div>
      )}

      {/* Sub-Navigation */}
      <div className="flex flex-wrap gap-1 border-b border-[#E4DFD3] pb-2">
        {(
          [
            ['directory', 'Customers, Wallets & Limits'],
            ['approvals', `Dual-Control Approvals (${adminOverview.approvals.filter((a) => a.status === 'PENDING').length})`],
            ['investigations', 'Payment & Refund Investigations'],
            ['reconciliation', 'Reconciliation & Incidents'],
            ['audit', 'Audit Log & Export'],
          ] as const
        ).map(([k, label]) => (
          <button
            key={k}
            type="button"
            onClick={() => setSubTab(k)}
            className={`px-3.5 py-2 text-xs font-medium whitespace-nowrap transition-colors ${
              subTab === k
                ? 'bg-[#0B1D3A] text-white'
                : 'text-[#4A5568] hover:text-[#0B1D3A] hover:bg-[#F2EFE6]'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {/* DIRECTORY & LIMITS */}
      {subTab === 'directory' && (
        <div className="space-y-6">
          <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
            <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
              Synthetic Consumer Wallets
            </h3>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-[#E4DFD3] text-xs text-[#4A5568]">
                    <th className="py-2 pr-4 font-medium">Customer</th>
                    <th className="py-2 pr-4 font-medium">Status</th>
                    <th className="py-2 pr-4 font-medium text-right">Available</th>
                    <th className="py-2 pr-4 font-medium text-right">Holding Cap (Demo)</th>
                    <th className="py-2 text-right font-medium">Propose Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EFECE4]">
                  {adminOverview.consumers.map((c) => (
                    <tr key={c.id} className="hover:bg-[#FAF8F3]">
                      <td className="py-3 pr-4">
                        <p className="font-medium text-[#0B1D3A]">{c.fullName}</p>
                        <p className="text-xs text-[#64748B] font-mono">
                          {c.handle} · {c.syntheticNationalId} · {c.walletId}
                        </p>
                      </td>
                      <td className="py-3 pr-4 text-xs font-medium">{c.walletStatus}</td>
                      <td className="py-3 pr-4 text-right font-mono tabular-nums">
                        {formatEuroCents(c.availableCents, locale)}
                      </td>
                      <td className="py-3 pr-4 text-right font-mono tabular-nums">
                        {formatEuroCents(c.holdingLimitCents, locale)}
                      </td>
                      <td className="py-3 text-right">
                        {c.walletStatus === 'ACTIVE' ? (
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => runAdminAction('REQUEST_WALLET_FREEZE', c.walletId)}
                            className="inline-flex items-center gap-1 border border-red-300 bg-red-50 px-2.5 py-1 text-xs font-medium text-red-900 hover:bg-red-100"
                          >
                            <Lock className="h-3 w-3" />
                            Propose Freeze
                          </button>
                        ) : (
                          <button
                            type="button"
                            disabled={busy}
                            onClick={() => runAdminAction('REQUEST_WALLET_UNFREEZE', c.walletId)}
                            className="inline-flex items-center gap-1 border border-emerald-300 bg-emerald-50 px-2.5 py-1 text-xs font-medium text-emerald-900 hover:bg-emerald-100"
                          >
                            <Unlock className="h-3 w-3" />
                            Propose Unfreeze
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
              <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                Propose Holding & Spend Limits (Demonstration Assumptions)
              </h3>
              <select
                value={selectedUserId}
                onChange={(e) => setSelectedUserId(e.target.value)}
                className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
              >
                {adminOverview.consumers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.fullName} ({c.walletId})
                  </option>
                ))}
              </select>
              <div className="grid grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-[#4A5568] mb-1">Holding Cap (€)</label>
                  <input
                    value={holdingLimitEur}
                    onChange={(e) => setHoldingLimitEur(e.target.value)}
                    className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-2.5 py-2 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[#4A5568] mb-1">Daily Limit (€)</label>
                  <input
                    value={dailyLimitEur}
                    onChange={(e) => setDailyLimitEur(e.target.value)}
                    className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-2.5 py-2 font-mono"
                  />
                </div>
                <div>
                  <label className="block text-[#4A5568] mb-1">Single TX (€)</label>
                  <input
                    value={singleLimitEur}
                    onChange={(e) => setSingleLimitEur(e.target.value)}
                    className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-2.5 py-2 font-mono"
                  />
                </div>
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={() =>
                  runAdminAction('REQUEST_LIMIT_UPDATE', selectedUserId, {
                    holdingLimitCents: Math.round(Number.parseFloat(holdingLimitEur) * 100),
                    dailySpendLimitCents: Math.round(Number.parseFloat(dailyLimitEur) * 100),
                    singleTxLimitCents: Math.round(Number.parseFloat(singleLimitEur) * 100),
                  })
                }
                className="bg-[#003399] text-white px-4 py-2 text-xs font-medium hover:bg-[#002673]"
              >
                Queue Limit Change for Supervisor Approval
              </button>
            </div>

            <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
              <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                Balanced Compensating Adjustment (No Direct DB Edits)
              </h3>
              <p className="text-xs text-[#4A5568]">
                Administrative balance corrections always create a balanced double-entry journal transaction from <code className="font-mono">SYS:ISSUER_RESERVE</code> upon Supervisor approval.
              </p>
              <div className="flex gap-3">
                <select
                  value={selectedUserId}
                  onChange={(e) => setSelectedUserId(e.target.value)}
                  className="flex-1 border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
                >
                  {adminOverview.consumers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.fullName}
                    </option>
                  ))}
                </select>
                <input
                  value={adjustmentEur}
                  onChange={(e) => setAdjustmentEur(e.target.value)}
                  className="w-28 border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm font-mono"
                />
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={() =>
                  runAdminAction('REQUEST_COMPENSATING_ADJUSTMENT', selectedUserId, {
                    amountCents: Math.round(Number.parseFloat(adjustmentEur) * 100),
                  })
                }
                className="bg-[#0B1D3A] text-white px-4 py-2 text-xs font-medium hover:bg-[#132A4F]"
              >
                Propose Balanced Adjustment
              </button>
            </div>
          </div>
        </div>
      )}

      {/* DUAL-CONTROL APPROVALS */}
      {subTab === 'approvals' && (
        <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
          <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
            Maker-Checker Approval Queue
          </h3>
          {adminOverview.approvals.length === 0 ? (
            <p className="text-sm text-[#4A5568]">
              No pending or historical dual-control requests. Propose a freeze, limit update, or adjustment from Customers & Wallets.
            </p>
          ) : (
            <div className="divide-y divide-[#EFECE4]">
              {adminOverview.approvals.map((a) => (
                <div key={a.id} className="py-4 flex flex-wrap items-center justify-between gap-4">
                  <div className="space-y-1 text-xs">
                    <p className="text-sm font-semibold text-[#0B1D3A]">
                      {a.actionType} · Target: <span className="font-mono">{a.targetId}</span>
                    </p>
                    <p className="text-[#4A5568]">Reason: {a.reason}</p>
                    <p className="font-mono text-[#64748B]">
                      Proposed by {a.requestedBy} ({a.requestedRole}) · Status: {a.status}
                    </p>
                  </div>
                  {a.status === 'PENDING' && (
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        disabled={busy || staffRole !== 'SUPERVISOR'}
                        onClick={() => runAdminAction('APPROVE_REQUEST', a.id)}
                        className="bg-[#003399] text-white px-3 py-1.5 text-xs font-medium hover:bg-[#002673] disabled:opacity-40"
                      >
                        Approve (Supervisor)
                      </button>
                      <button
                        type="button"
                        disabled={busy || staffRole !== 'SUPERVISOR'}
                        onClick={() => runAdminAction('REJECT_REQUEST', a.id)}
                        className="border border-red-300 bg-red-50 text-red-900 px-3 py-1.5 text-xs font-medium hover:bg-red-100 disabled:opacity-40"
                      >
                        Reject
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* PAYMENT & REFUND INVESTIGATIONS */}
      {subTab === 'investigations' && (
        <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
          <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
            Payment Lifecycle & Refund Review
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#E4DFD3] text-[#4A5568]">
                  <th className="py-2 pr-3 font-medium">Payment ID</th>
                  <th className="py-2 pr-3 font-medium">Payer → Payee</th>
                  <th className="py-2 pr-3 font-medium">State</th>
                  <th className="py-2 pr-3 font-medium text-right">Amount</th>
                  <th className="py-2 font-medium">Failure / Journal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EFECE4]">
                {adminOverview.payments.map((p) => (
                  <tr key={String(p.id)}>
                    <td className="py-2.5 pr-3 font-mono">{String(p.id)}</td>
                    <td className="py-2.5 pr-3">
                      {String(p.payer_name)} → {String(p.payee_name)}
                    </td>
                    <td className="py-2.5 pr-3 font-semibold">{String(p.state)}</td>
                    <td className="py-2.5 pr-3 text-right font-mono tabular-nums">
                      {formatEuroCents(Number(p.amount_cents), locale)}
                    </td>
                    <td className="py-2.5 font-mono text-[#4A5568]">
                      {p.failure_reason ? String(p.failure_reason) : p.journal_tx_id ? String(p.journal_tx_id) : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* RECONCILIATION & INCIDENTS */}
      {subTab === 'reconciliation' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
              <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                Ledger Reconciliation
              </h3>
              <Scale className="h-4 w-4 text-[#003399]" />
            </div>
            <button
              type="button"
              disabled={busy}
              onClick={() => runAdminAction('RUN_RECONCILIATION')}
              className="bg-[#003399] text-white px-4 py-2 text-xs font-medium hover:bg-[#002673]"
            >
              Run Trial-Balance & Clearing Reconciliation
            </button>
            <div className="divide-y divide-[#EFECE4] text-xs">
              {adminOverview.reconciliations.map((rec) => (
                <div key={rec.id} className="py-3 space-y-1">
                  <div className="flex justify-between font-semibold">
                    <span>{rec.status}</span>
                    <span className="font-mono">Discrepancy: {rec.discrepancyCents}¢</span>
                  </div>
                  <p className="font-mono text-[#4A5568]">
                    Debits {rec.totalDebitsCents}¢ == Credits {rec.totalCreditsCents}¢ · Clearing{' '}
                    {rec.totalClearingAssetCents}¢ == Wallet Liability {rec.totalWalletLiabilityCents}¢
                  </p>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
              <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                Incident Management
              </h3>
              <ShieldAlert className="h-4 w-4 text-amber-700" />
            </div>
            <div className="flex gap-2">
              <input
                value={incidentTitle}
                onChange={(e) => setIncidentTitle(e.target.value)}
                className="flex-1 border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-xs"
              />
              <select
                value={incidentSeverity}
                onChange={(e) => setIncidentSeverity(e.target.value as 'LOW' | 'MEDIUM' | 'HIGH')}
                className="border border-[#D4CEC0] bg-[#FAF8F3] px-2 py-2 text-xs"
              >
                <option value="LOW">LOW</option>
                <option value="MEDIUM">MEDIUM</option>
                <option value="HIGH">HIGH</option>
              </select>
              <button
                type="button"
                disabled={busy}
                onClick={() =>
                  runAdminAction('CREATE_INCIDENT', undefined, {
                    title: incidentTitle,
                    severity: incidentSeverity,
                    category: 'BANK_ADAPTER',
                  })
                }
                className="bg-[#0B1D3A] text-white px-3 py-2 text-xs font-medium"
              >
                Log
              </button>
            </div>
            <div className="divide-y divide-[#EFECE4] text-xs">
              {adminOverview.incidents.map((inc) => (
                <div key={inc.id} className="py-3 flex items-center justify-between gap-3">
                  <div>
                    <p className="font-semibold text-[#0B1D3A]">
                      [{inc.severity}] {inc.title} · {inc.status}
                    </p>
                    <p className="text-[#4A5568]">{inc.details}</p>
                  </div>
                  {inc.status !== 'RESOLVED' && (
                    <button
                      type="button"
                      onClick={() => runAdminAction('RESOLVE_INCIDENT', inc.id)}
                      className="border border-[#0B1D3A] px-2.5 py-1 text-xs font-medium whitespace-nowrap"
                    >
                      Resolve
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* AUDIT EXPORT */}
      {subTab === 'audit' && (
        <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#E4DFD3] pb-3">
            <div className="flex items-center gap-2">
              <FileSpreadsheet className="h-4 w-4 text-[#003399]" />
              <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                Immutable Redacted Audit Trail
              </h3>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => handleDownloadAudit('csv')}
                className="inline-flex items-center gap-1.5 border border-[#D4CEC0] px-3 py-1.5 text-xs font-medium hover:bg-[#FAF8F3]"
              >
                <Download className="h-3.5 w-3.5" />
                Export CSV
              </button>
              <button
                type="button"
                onClick={() => handleDownloadAudit('json')}
                className="inline-flex items-center gap-1.5 border border-[#D4CEC0] px-3 py-1.5 text-xs font-medium hover:bg-[#FAF8F3]"
              >
                <Download className="h-3.5 w-3.5" />
                Export JSON
              </button>
            </div>
          </div>
          <div className="divide-y divide-[#EFECE4] text-xs max-h-96 overflow-y-auto">
            {adminOverview.auditLogs.map((log) => (
              <div key={log.id} className="py-2.5 flex flex-wrap justify-between gap-2">
                <div>
                  <p className="font-semibold text-[#0B1D3A]">
                    {log.action} · {log.actorId} ({log.actorRole})
                  </p>
                  <p className="text-[#4A5568]">{log.reason}</p>
                </div>
                <span className="font-mono text-[#64748B]">{log.createdAt}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
