'use client';

import { useState } from 'react';
import {
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  Building2,
  CheckCircle2,
  Clock,
  KeyRound,
  Lock,
  RefreshCw,
  ShieldCheck,
  Smartphone,
  UserPlus,
  XCircle,
} from 'lucide-react';
import {
  formatEuroCents,
  parseEuroInputToCents,
  TRANSLATIONS,
  type ConsumerProfile,
  type DeviceRecord,
  type LocaleCode,
  type MerchantProfile,
  type PaymentRecord,
  type PaymentRequestRecord,
} from '@/lib/core/types';
import { QrCodeGraphic } from './QrCodeGraphic';

type ConsumerTab = 'home' | 'pay' | 'request' | 'activity' | 'account';
type PayStep = 1 | 2 | 3 | 4 | 5;

interface ConsumerWalletViewProps {
  locale: LocaleCode;
  consumers: ConsumerProfile[];
  merchants: MerchantProfile[];
  activeConsumer: ConsumerProfile | null;
  activeDevices: DeviceRecord[];
  activeActivity: {
    payments: PaymentRecord[];
    refunds: Array<{
      id: string;
      originalPaymentId: string;
      amountCents: number;
      reason: string;
      status: string;
      journalTxId: string | null;
      createdAt: string;
    }>;
    fundings: Array<Record<string, unknown>>;
    redemptions: Array<Record<string, unknown>>;
  } | null;
  openPaymentRequests: PaymentRequestRecord[];
  consumerToken: string | null;
  preselectedRequestId: string | null;
  onClearPreselectedRequest: () => void;
  onSwitchConsumer: (userId: string) => Promise<void>;
  onRefresh: () => Promise<void>;
  onTokenIssued: (userId: string, token: string) => void;
}

export function ConsumerWalletView({
  locale,
  consumers,
  merchants,
  activeConsumer,
  activeDevices,
  activeActivity,
  openPaymentRequests,
  consumerToken,
  preselectedRequestId,
  onClearPreselectedRequest,
  onSwitchConsumer,
  onRefresh,
  onTokenIssued,
}: ConsumerWalletViewProps) {
  const t = TRANSLATIONS[locale];
  const [tab, setTab] = useState<ConsumerTab>(preselectedRequestId ? 'pay' : 'home');
  const [bannerMsg, setBannerMsg] = useState<{ kind: 'ok' | 'err' | 'warn'; text: string } | null>(null);
  const [busy, setBusy] = useState(false);

  // Pay flow state (5 steps)
  const [payStep, setPayStep] = useState<PayStep>(preselectedRequestId ? 3 : 1);
  const [payeeKind, setPayeeKind] = useState<'MERCHANT' | 'CONSUMER'>('MERCHANT');
  const [payeeId, setPayeeId] = useState<string>(merchants[0]?.id ?? 'mrc_cafe_europa');
  const [selectedRequestId, setSelectedRequestId] = useState<string | null>(preselectedRequestId);
  const [amountInput, setAmountInput] = useState<string>('12.50');
  const [currentIntent, setCurrentIntent] = useState<PaymentRecord | null>(null);
  const [stepUpConfirmed, setStepUpConfirmed] = useState(false);
  const [simulateDrop, setSimulateDrop] = useState(false);
  const [droppedPaymentId, setDroppedPaymentId] = useState<string | null>(null);
  const [lastIdempotencyKey, setLastIdempotencyKey] = useState<string>('');

  // Request tab state
  const [reqAmountInput, setReqAmountInput] = useState('20.00');
  const [reqDescInput, setReqDescInput] = useState('Shared dinner split');

  // Account & funding state
  const [fundAmountInput, setFundAmountInput] = useState('100.00');
  const [redeemAmountInput, setRedeemAmountInput] = useState('10.00');
  const [lastFundingId, setLastFundingId] = useState<string | null>(null);
  const [recoveryPhrase, setRecoveryPhrase] = useState('amber-river-nordic-vault');
  const [newDeviceName, setNewDeviceName] = useState('Pixel 9 Pro Replacement');

  // Synthetic registration modal/panel
  const [showRegister, setShowRegister] = useState(false);
  const [regHandle, setRegHandle] = useState('@sofia.garcia');
  const [regName, setRegName] = useState('Sofía García');
  const [regNatId, setRegNatId] = useState('SYN-ES-7720194');
  const [regCountry, setRegCountry] = useState('ES');
  const [regPassword, setRegPassword] = useState('demo-pass-2026');
  const [createdRecoveryPhrase, setCreatedRecoveryPhrase] = useState<string | null>(null);

  // Selected receipt
  const [receiptPayment, setReceiptPayment] = useState<PaymentRecord | null>(null);

  const selectedRequest = openPaymentRequests.find((r) => r.id === selectedRequestId) ?? null;

  // Sync if parent navigated from Merchant POS "Open in Consumer Wallet"
  if (preselectedRequestId && selectedRequestId !== preselectedRequestId) {
    const found = openPaymentRequests.find((r) => r.id === preselectedRequestId);
    setSelectedRequestId(preselectedRequestId);
    if (found) {
      setPayeeKind(found.kind === 'MERCHANT_POS' ? 'MERCHANT' : 'CONSUMER');
      setPayeeId(found.merchantId ?? found.requesterUserId ?? '');
      setAmountInput((found.amountCents / 100).toFixed(2));
      setTab('pay');
      setPayStep(3);
    }
    onClearPreselectedRequest();
  }

  async function apiCall(url: string, options: RequestInit = {}) {
    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string> | undefined),
    };
    if (consumerToken) {
      headers.Authorization = `Bearer ${consumerToken}`;
    }
    const res = await fetch(url, { ...options, headers });
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data?.error?.message || `HTTP ${res.status}`);
    }
    return data;
  }

  async function handleCreatePaymentIntent() {
    if (!activeConsumer) return;
    setBusy(true);
    setBannerMsg(null);
    setDroppedPaymentId(null);
    try {
      const amountCents = selectedRequest
        ? selectedRequest.amountCents
        : parseEuroInputToCents(amountInput);

      if (!amountCents || amountCents <= 0) {
        throw new Error('Enter a valid positive euro amount (e.g. 12.50)');
      }

      const idempKey = `ui-pay-${crypto.randomUUID().slice(0, 12)}`;
      setLastIdempotencyKey(idempKey);

      const data = await apiCall('/v1/payments', {
        method: 'POST',
        headers: { 'Idempotency-Key': idempKey },
        body: JSON.stringify({
          idempotencyKey: idempKey,
          payeeKind: selectedRequest
            ? selectedRequest.kind === 'MERCHANT_POS'
              ? 'MERCHANT'
              : 'CONSUMER'
            : payeeKind,
          payeeId: selectedRequest
            ? selectedRequest.merchantId ?? selectedRequest.requesterUserId
            : payeeId,
          amountCents,
          paymentRequestId: selectedRequest?.id ?? null,
        }),
      });
      setCurrentIntent(data.payment);
      setStepUpConfirmed(false);
      setPayStep(4);
      await onRefresh();
    } catch (err) {
      setBannerMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Failed to create payment' });
    } finally {
      setBusy(false);
    }
  }

  async function handleAuthorisePayment(replayDuplicateIntent = false) {
    if (!currentIntent) return;
    setBusy(true);
    setBannerMsg(null);
    try {
      if (replayDuplicateIntent && lastIdempotencyKey) {
        // Re-submit the exact same payment creation + authorise with same idempotency key
        const replayRes = await apiCall('/v1/payments', {
          method: 'POST',
          headers: { 'Idempotency-Key': lastIdempotencyKey },
          body: JSON.stringify({
            idempotencyKey: lastIdempotencyKey,
            payeeKind: currentIntent.payeeKind,
            payeeId: currentIntent.payeeId,
            amountCents: currentIntent.amountCents,
            paymentRequestId: currentIntent.paymentRequestId,
          }),
        });
        setCurrentIntent(replayRes.payment);
        setBannerMsg({
          kind: 'ok',
          text: `Idempotent duplicate submission returned existing payment ${replayRes.payment.id} (${replayRes.payment.state}) without a second debit.`,
        });
        await onRefresh();
        return;
      }

      const res = await fetch(`/v1/payments/${currentIntent.id}/authorise`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(consumerToken ? { Authorization: `Bearer ${consumerToken}` } : {}),
          'Idempotency-Key': `auth-${currentIntent.id}`,
        },
        body: JSON.stringify({
          stepUpConfirmed,
          simulateLostResponse: simulateDrop,
        }),
      });
      const data = await res.json();
      if (res.status === 504) {
        setDroppedPaymentId(currentIntent.id);
        setPayStep(5);
        setBannerMsg({
          kind: 'warn',
          text: 'Network timeout simulated after server commit. Use "Check Authoritative Outcome" below—never submit a second payment.',
        });
        await onRefresh();
        return;
      }
      if (!res.ok) {
        throw new Error(data?.error?.message || 'Authorisation failed');
      }
      setCurrentIntent(data.payment);
      setPayStep(5);
      await onRefresh();
    } catch (err) {
      setBannerMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Authorisation failed' });
    } finally {
      setBusy(false);
    }
  }

  async function handleCheckPaymentOutcome(paymentId: string) {
    setBusy(true);
    setBannerMsg(null);
    try {
      const data = await apiCall(`/v1/payments/${paymentId}`);
      setCurrentIntent(data.payment);
      setDroppedPaymentId(null);
      setBannerMsg({
        kind: 'ok',
        text: `Recovered authoritative payment state via GET /v1/payments/${paymentId}: ${data.payment.state}`,
      });
      await onRefresh();
    } catch (err) {
      setBannerMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Outcome check failed' });
    } finally {
      setBusy(false);
    }
  }

  async function handleCancelIntent() {
    if (!currentIntent) return;
    setBusy(true);
    try {
      const data = await apiCall(`/v1/payments/${currentIntent.id}/cancel`, { method: 'POST' });
      setCurrentIntent(data.payment);
      setPayStep(5);
      await onRefresh();
    } catch (err) {
      setBannerMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Cancel failed' });
    } finally {
      setBusy(false);
    }
  }

  async function handleCreateP2PRequest() {
    if (!activeConsumer) return;
    setBusy(true);
    setBannerMsg(null);
    try {
      const cents = parseEuroInputToCents(reqAmountInput);
      if (!cents) throw new Error('Enter a valid positive euro amount');
      const data = await apiCall('/v1/payment-requests', {
        method: 'POST',
        body: JSON.stringify({
          kind: 'P2P_REQUEST',
          requesterUserId: activeConsumer.id,
          amountCents: cents,
          description: reqDescInput,
          expiresInSeconds: 300,
        }),
      });
      setBannerMsg({
        kind: 'ok',
        text: `Created P2P request ${data.paymentRequest.id} for ${formatEuroCents(cents, locale)}.`,
      });
      await onRefresh();
    } catch (err) {
      setBannerMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Request creation failed' });
    } finally {
      setBusy(false);
    }
  }

  async function handleFundingFlow(mode: 'REQUEST_ONLY' | 'SETTLE' | 'FAIL') {
    setBusy(true);
    setBannerMsg(null);
    try {
      const cents = parseEuroInputToCents(fundAmountInput);
      if (!cents) throw new Error('Enter a valid euro funding amount');

      let reqId = lastFundingId;
      if (mode === 'REQUEST_ONLY' || !reqId) {
        const res = await apiCall('/v1/funding-requests', {
          method: 'POST',
          body: JSON.stringify({
            idempotencyKey: `fund-ui-${crypto.randomUUID().slice(0, 10)}`,
            amountCents: cents,
            provider: 'rheinmain_demo_bank',
          }),
        });
        reqId = res.fundingRequest.id;
        setLastFundingId(reqId);
        if (mode === 'REQUEST_ONLY') {
          setBannerMsg({
            kind: 'warn',
            text: `Funding request ${reqId} submitted (PROVIDER_PENDING). Spendable balance remains unchanged until bank adapter confirms settlement.`,
          });
          await onRefresh();
          return;
        }
      }

      const simRes = await apiCall('/v1/providers/simulate-adapter', {
        method: 'POST',
        body: JSON.stringify({
          provider: 'rheinmain_demo_bank',
          requestKind: 'FUNDING',
          requestId: reqId,
          outcome: mode === 'FAIL' ? 'FAILED' : 'SETTLED',
        }),
      });
      setLastFundingId(null);
      setBannerMsg({
        kind: mode === 'FAIL' ? 'warn' : 'ok',
        text:
          mode === 'FAIL'
            ? `External bank declined funding ${reqId}. Zero spendable balance was created.`
            : `Bank settlement confirmed for ${reqId}. Ledger credited ${formatEuroCents(simRes.funding.amountCents, locale)}.`,
      });
      await onRefresh();
    } catch (err) {
      setBannerMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Funding flow failed' });
    } finally {
      setBusy(false);
    }
  }

  async function handleRedemptionFlow(outcome: 'SETTLED' | 'FAILED') {
    setBusy(true);
    setBannerMsg(null);
    try {
      const cents = parseEuroInputToCents(redeemAmountInput);
      if (!cents) throw new Error('Enter a valid redemption euro amount');

      const res = await apiCall('/v1/redemption-requests', {
        method: 'POST',
        body: JSON.stringify({
          idempotencyKey: `red-ui-${crypto.randomUUID().slice(0, 10)}`,
          amountCents: cents,
          provider: 'rheinmain_demo_bank',
        }),
      });

      await apiCall('/v1/providers/simulate-adapter', {
        method: 'POST',
        body: JSON.stringify({
          provider: 'rheinmain_demo_bank',
          requestKind: 'REDEMPTION',
          requestId: res.redemptionRequest.id,
          outcome,
        }),
      });

      setBannerMsg({
        kind: outcome === 'FAILED' ? 'warn' : 'ok',
        text:
          outcome === 'FAILED'
            ? `Bank payout failed; linked compensating reversal restored ${formatEuroCents(cents, locale)} to available balance.`
            : `Redemption settled: ${formatEuroCents(cents, locale)} debited to clearing and paid out to commercial bank.`,
      });
      await onRefresh();
    } catch (err) {
      setBannerMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Redemption failed' });
    } finally {
      setBusy(false);
    }
  }

  async function handleDeviceAction(
    action: 'BIND_NEW' | 'MARK_LOST' | 'REVOKE' | 'RECOVER_WALLET',
    deviceId?: string
  ) {
    setBusy(true);
    setBannerMsg(null);
    try {
      const data = await apiCall('/v1/auth/devices', {
        method: 'POST',
        body: JSON.stringify({
          action,
          deviceId,
          deviceName: newDeviceName,
          recoveryPhrase,
        }),
      });
      setBannerMsg({ kind: 'ok', text: data.recoveryMessage });
      await onRefresh();
    } catch (err) {
      setBannerMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Device action failed' });
    } finally {
      setBusy(false);
    }
  }

  async function handleRegisterConsumer(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setBannerMsg(null);
    try {
      const res = await fetch('/v1/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          handle: regHandle,
          fullName: regName,
          syntheticNationalId: regNatId,
          countryCode: regCountry,
          linkedBankName: 'Banco Ibérico Simulación SA',
          linkedBankIban: 'ES9121000418450200051332',
          password: regPassword,
          deviceName: 'Web Synthetic Device',
          platform: 'WEB_PASSKEY_DEMO',
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error?.message || 'Registration failed');
      setCreatedRecoveryPhrase(data.recoveryPhrase);
      onTokenIssued(data.userId, data.token);
      await onSwitchConsumer(data.userId);
      setShowRegister(false);
      setBannerMsg({
        kind: 'ok',
        text: `Registered synthetic consumer ${regName}. Save recovery phrase: ${data.recoveryPhrase}`,
      });
    } catch (err) {
      setBannerMsg({ kind: 'err', text: err instanceof Error ? err.message : 'Registration failed' });
    } finally {
      setBusy(false);
    }
  }

  const holdingPct = activeConsumer
    ? Math.min(100, Math.round((activeConsumer.availableCents / Math.max(1, activeConsumer.holdingLimitCents)) * 100))
    : 0;

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Deep Midnight-Blue Consumer Navigation Rail */}
      <aside className="lg:col-span-3">
        <div className="bg-[#0B1D3A] text-white p-5 border border-[#162D52]">
          <p className="text-xs text-[#C9A227] font-medium">Synthetic Consumer Wallet</p>
          <div className="mt-2">
            <label htmlFor="consumer-switcher" className="sr-only">
              Active consumer account
            </label>
            <select
              id="consumer-switcher"
              value={activeConsumer?.id ?? ''}
              onChange={(e) => onSwitchConsumer(e.target.value)}
              className="w-full bg-[#132A4F] border border-[#284574] px-3 py-2 text-sm text-white focus:outline-none focus:ring-2 focus:ring-[#C9A227]"
            >
              {consumers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.fullName} ({c.handle})
                </option>
              ))}
            </select>
          </div>

          {activeConsumer && (
            <div className="mt-4 pt-4 border-t border-[#1E3A66] text-xs text-slate-300 space-y-1">
              <div className="flex justify-between">
                <span>Status</span>
                <span className="font-medium text-white">{activeConsumer.walletStatus}</span>
              </div>
              <div className="flex justify-between">
                <span>KYC Tier</span>
                <span className="font-mono text-white">{activeConsumer.kycTier}</span>
              </div>
              <div className="flex justify-between">
                <span>Linked Bank</span>
                <span className="text-white truncate max-w-[140px]">{activeConsumer.linkedBankName}</span>
              </div>
            </div>
          )}

          {/* Required Consumer Navigation: Home · Pay · Request · Activity · Account */}
          <nav aria-label="Consumer wallet navigation" className="mt-6 space-y-1">
            {(
              [
                ['home', t.navHome],
                ['pay', t.navPay],
                ['request', t.navRequest],
                ['activity', t.navActivity],
                ['account', t.navAccount],
              ] as Array<[ConsumerTab, string]>
            ).map(([key, label]) => {
              const active = tab === key;
              return (
                <button
                  key={key}
                  type="button"
                  onClick={() => setTab(key)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-[#003399] text-white border border-[#3366CC]'
                      : 'text-slate-200 hover:bg-[#132A4F] hover:text-white'
                  }`}
                >
                  <span>{label}</span>
                  {active && <span className="h-1.5 w-1.5 bg-[#C9A227]" aria-hidden="true" />}
                </button>
              );
            })}
          </nav>

          <div className="mt-6 pt-4 border-t border-[#1E3A66]">
            <button
              type="button"
              onClick={() => setShowRegister((v) => !v)}
              className="w-full flex items-center justify-center gap-2 border border-[#2F4E80] bg-[#132A4F] px-3 py-2 text-xs font-medium text-white hover:bg-[#1A3766] transition-colors whitespace-nowrap"
            >
              <UserPlus className="h-3.5 w-3.5" />
              <span>{showRegister ? 'Close Registration' : 'Register Synthetic Consumer'}</span>
            </button>
          </div>
        </div>

        {createdRecoveryPhrase && (
          <div className="mt-4 bg-white border border-[#B58B1B] p-4 text-xs text-[#0B1D3A]">
            <p className="font-semibold">Synthetic Recovery Phrase Generated</p>
            <p className="mt-1 font-mono bg-[#FAF8F3] p-2 border border-[#E4DFD3] select-all">
              {createdRecoveryPhrase}
            </p>
          </div>
        )}
      </aside>

      {/* Main Consumer Viewport */}
      <section className="lg:col-span-9 space-y-6">
        {bannerMsg && (
          <div
            role="status"
            className={`flex items-start gap-3 p-4 border text-sm ${
              bannerMsg.kind === 'ok'
                ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
                : bannerMsg.kind === 'warn'
                  ? 'bg-amber-50 border-amber-300 text-amber-950'
                  : 'bg-red-50 border-red-300 text-red-950'
            }`}
          >
            {bannerMsg.kind === 'ok' ? (
              <CheckCircle2 className="h-4 w-4 mt-0.5 shrink-0 text-emerald-700" />
            ) : bannerMsg.kind === 'warn' ? (
              <AlertTriangle className="h-4 w-4 mt-0.5 shrink-0 text-amber-700" />
            ) : (
              <XCircle className="h-4 w-4 mt-0.5 shrink-0 text-red-700" />
            )}
            <p className="flex-1">{bannerMsg.text}</p>
          </div>
        )}

        {showRegister && (
          <form onSubmit={handleRegisterConsumer} className="bg-white border border-[#E4DFD3] p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
              <h2 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[#0B1D3A]">
                Synthetic Consumer Onboarding (Simulated KYC Tier 1)
              </h2>
              <span className="text-xs text-[#4A5568]">No real identity data</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#4A5568] mb-1">Full Name</label>
                <input
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#4A5568] mb-1">Wallet Handle</label>
                <input
                  value={regHandle}
                  onChange={(e) => setRegHandle(e.target.value)}
                  className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm font-mono"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#4A5568] mb-1">Synthetic National ID</label>
                <input
                  value={regNatId}
                  onChange={(e) => setRegNatId(e.target.value)}
                  className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm font-mono"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#4A5568] mb-1">Passcode (min 8 chars)</label>
                <input
                  type="password"
                  value={regPassword}
                  onChange={(e) => setRegPassword(e.target.value)}
                  className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
                  required
                />
              </div>
            </div>
            <div className="flex items-center justify-end gap-3">
              <button
                type="button"
                onClick={() => setShowRegister(false)}
                className="px-4 py-2 text-sm text-[#4A5568] hover:text-[#0B1D3A]"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={busy}
                className="bg-[#003399] text-white px-5 py-2 text-sm font-medium hover:bg-[#002673] disabled:opacity-50"
              >
                Create Synthetic Wallet
              </button>
            </div>
          </form>
        )}

        {/* HOME TAB */}
        {tab === 'home' && activeConsumer && (
          <div className="space-y-6">
            <div className="bg-[#0B1D3A] text-white p-7 border border-[#162D52]">
              <div className="flex flex-wrap items-start justify-between gap-4">
                <div>
                  <p className="text-xs text-[#C9A227] font-medium">
                    {activeConsumer.fullName} · {activeConsumer.handle} · Simulated Funds
                  </p>
                  <p className="mt-3 text-xs text-slate-300">{t.availableBalance}</p>
                  <p className="mt-1 font-[family-name:var(--font-display)] text-4xl sm:text-5xl font-semibold tracking-tight tabular-nums">
                    {formatEuroCents(activeConsumer.availableCents, locale)}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-300">{t.reservedBalance}</p>
                  <p className="mt-1 font-mono text-2xl font-medium tabular-nums text-[#E9D79E]">
                    {formatEuroCents(activeConsumer.reservedCents, locale)}
                  </p>
                  <p className="mt-2 text-xs text-slate-400 font-mono">
                    {activeConsumer.availableCents}¢ available
                  </p>
                </div>
              </div>

              <div className="mt-6 pt-5 border-t border-[#1E3A66]">
                <div className="flex items-center justify-between text-xs text-slate-300 mb-2">
                  <span>
                    {t.holdingCap}: {formatEuroCents(activeConsumer.holdingLimitCents, locale)} (Demo assumption)
                  </span>
                  <span className="font-mono tabular-nums">{holdingPct}%</span>
                </div>
                <div className="h-2 w-full bg-[#162D52] overflow-hidden">
                  <div
                    className="h-full bg-[#C9A227] transition-all duration-300"
                    style={{ width: `${holdingPct}%` }}
                  />
                </div>
              </div>

              <div className="mt-6 flex flex-wrap gap-3">
                <button
                  type="button"
                  onClick={() => {
                    setTab('pay');
                    setPayStep(1);
                  }}
                  className="bg-[#003399] hover:bg-[#0044CC] text-white px-5 py-2.5 text-sm font-medium transition-colors whitespace-nowrap"
                >
                  {t.sendPayment}
                </button>
                <button
                  type="button"
                  onClick={() => setTab('account')}
                  className="bg-[#132A4F] hover:bg-[#1B3A6B] border border-[#2F4E80] text-white px-4 py-2.5 text-sm font-medium transition-colors whitespace-nowrap"
                >
                  {t.fundWallet}
                </button>
                <button
                  type="button"
                  onClick={() => setTab('request')}
                  className="bg-[#132A4F] hover:bg-[#1B3A6B] border border-[#2F4E80] text-white px-4 py-2.5 text-sm font-medium transition-colors whitespace-nowrap"
                >
                  {t.navRequest}
                </button>
              </div>
            </div>

            {/* Open QR & P2P Payment Requests ready to pay */}
            <div className="bg-white border border-[#E4DFD3] p-6">
              <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
                <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                  Open Payment Requests
                </h3>
                <span className="text-xs text-[#4A5568]">Verified backend payloads</span>
              </div>
              {openPaymentRequests.filter((r) => r.status === 'OPEN').length === 0 ? (
                <p className="py-6 text-sm text-[#4A5568]">
                  No open QR or P2P requests right now. Create one in Merchant POS or the Request tab.
                </p>
              ) : (
                <div className="divide-y divide-[#EFECE4]">
                  {openPaymentRequests
                    .filter((r) => r.status === 'OPEN')
                    .map((req) => (
                      <div key={req.id} className="py-3.5 flex flex-wrap items-center justify-between gap-4">
                        <div>
                          <p className="text-sm font-medium text-[#0B1D3A]">{req.requesterName}</p>
                          <p className="text-xs text-[#4A5568]">
                            {req.description} · {req.kind} · Expires {new Date(req.expiresAt).toLocaleTimeString()}
                          </p>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="font-mono text-sm font-semibold tabular-nums text-[#0B1D3A]">
                            {formatEuroCents(req.amountCents, locale)}
                          </span>
                          <button
                            type="button"
                            onClick={() => {
                              setSelectedRequestId(req.id);
                              setPayeeKind(req.kind === 'MERCHANT_POS' ? 'MERCHANT' : 'CONSUMER');
                              setPayeeId(req.merchantId ?? req.requesterUserId ?? '');
                              setAmountInput((req.amountCents / 100).toFixed(2));
                              setTab('pay');
                              setPayStep(3);
                            }}
                            className="bg-[#003399] text-white px-3.5 py-1.5 text-xs font-medium hover:bg-[#002673] whitespace-nowrap"
                          >
                            Review & Pay
                          </button>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* PAY TAB: 5-Step Lifecycle */}
        {tab === 'pay' && activeConsumer && (
          <div className="bg-white border border-[#E4DFD3] p-6 space-y-6">
            <div className="border-b border-[#E4DFD3] pb-4">
              <h2 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[#0B1D3A]">
                Guided Payment Lifecycle
              </h2>
              <div className="mt-3 grid grid-cols-5 gap-2 text-xs">
                {(
                  [
                    [1, t.selectRecipient],
                    [2, t.enterAmount],
                    [3, t.reviewDetails],
                    [4, t.authorisePayment],
                    [5, t.paymentOutcome],
                  ] as Array<[PayStep, string]>
                ).map(([stepNum, label]) => (
                  <div
                    key={stepNum}
                    className={`p-2 border text-center truncate ${
                      payStep === stepNum
                        ? 'border-[#003399] bg-[#EEF3FC] text-[#003399] font-semibold'
                        : payStep > stepNum
                          ? 'border-[#B58B1B] bg-[#FAF8F3] text-[#0B1D3A]'
                          : 'border-[#E4DFD3] text-[#64748B]'
                    }`}
                  >
                    {stepNum}. {label}
                  </div>
                ))}
              </div>
            </div>

            {payStep === 1 && (
              <div className="space-y-4">
                <p className="text-sm text-[#4A5568]">
                  Choose a verified merchant, a peer consumer, or an open QR payment request.
                </p>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedRequestId(null);
                      setPayeeKind('MERCHANT');
                      setPayeeId(merchants[0]?.id ?? 'mrc_cafe_europa');
                    }}
                    className={`p-4 border text-left transition-colors ${
                      payeeKind === 'MERCHANT' && !selectedRequestId
                        ? 'border-[#003399] bg-[#EEF3FC]'
                        : 'border-[#E4DFD3] hover:bg-[#FAF8F3]'
                    }`}
                  >
                    <p className="text-sm font-semibold text-[#0B1D3A]">Verified Merchant Payment</p>
                    <p className="text-xs text-[#4A5568] mt-1">Pay Café Europa Berlin or registered POS merchant</p>
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedRequestId(null);
                      setPayeeKind('CONSUMER');
                      const other = consumers.find((c) => c.id !== activeConsumer.id);
                      setPayeeId(other?.id ?? '');
                    }}
                    className={`p-4 border text-left transition-colors ${
                      payeeKind === 'CONSUMER' && !selectedRequestId
                        ? 'border-[#003399] bg-[#EEF3FC]'
                        : 'border-[#E4DFD3] hover:bg-[#FAF8F3]'
                    }`}
                  >
                    <p className="text-sm font-semibold text-[#0B1D3A]">Person-to-Person Transfer</p>
                    <p className="text-xs text-[#4A5568] mt-1">Instant simulated digital euro transfer to a peer</p>
                  </button>
                </div>

                {!selectedRequestId && (
                  <div>
                    <label className="block text-xs font-medium text-[#4A5568] mb-1">Recipient</label>
                    <select
                      value={payeeId}
                      onChange={(e) => setPayeeId(e.target.value)}
                      className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
                    >
                      {payeeKind === 'MERCHANT'
                        ? merchants.map((m) => (
                            <option key={m.id} value={m.id}>
                              {m.displayName} ({m.city}, {m.countryCode} · {m.registrationCode})
                            </option>
                          ))
                        : consumers
                            .filter((c) => c.id !== activeConsumer.id)
                            .map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.fullName} ({c.handle})
                              </option>
                            ))}
                    </select>
                  </div>
                )}

                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={() => setPayStep(2)}
                    disabled={!payeeId}
                    className="bg-[#003399] text-white px-5 py-2 text-sm font-medium hover:bg-[#002673]"
                  >
                    Continue to Amount
                  </button>
                </div>
              </div>
            )}

            {payStep === 2 && (
              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-[#4A5568] mb-1">
                    Amount in EUR (converted to exact integer euro cents)
                  </label>
                  <input
                    value={amountInput}
                    onChange={(e) => setAmountInput(e.target.value)}
                    disabled={Boolean(selectedRequest)}
                    className="w-full max-w-xs border border-[#D4CEC0] bg-[#FAF8F3] px-4 py-3 text-2xl font-mono tabular-nums"
                  />
                  <p className="mt-2 text-xs text-[#4A5568]">
                    Available: {formatEuroCents(activeConsumer.availableCents, locale)} · Step-up confirmation required at €50.00+
                  </p>
                </div>
                <div className="flex justify-between">
                  <button
                    type="button"
                    onClick={() => setPayStep(1)}
                    className="px-4 py-2 text-sm text-[#4A5568] hover:text-[#0B1D3A]"
                  >
                    Back
                  </button>
                  <button
                    type="button"
                    onClick={() => setPayStep(3)}
                    className="bg-[#003399] text-white px-5 py-2 text-sm font-medium hover:bg-[#002673]"
                  >
                    Review Details
                  </button>
                </div>
              </div>
            )}

            {payStep === 3 && (
              <div className="space-y-4">
                <div className="bg-[#FAF8F3] border border-[#E4DFD3] p-5 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-[#4A5568]">Verified Payee</span>
                    <span className="font-semibold text-[#0B1D3A]">
                      {selectedRequest
                        ? selectedRequest.requesterName
                        : payeeKind === 'MERCHANT'
                          ? merchants.find((m) => m.id === payeeId)?.displayName
                          : consumers.find((c) => c.id === payeeId)?.fullName}
                    </span>
                  </div>
                  {payeeKind === 'MERCHANT' && (
                    <div className="flex justify-between">
                      <span className="text-[#4A5568]">Merchant Verification</span>
                      <span className="inline-flex items-center gap-1 text-emerald-800 font-medium">
                        <ShieldCheck className="h-4 w-4" />
                        {merchants.find((m) => m.id === payeeId)?.registrationCode ?? 'Verified'}
                      </span>
                    </div>
                  )}
                  <div className="flex justify-between">
                    <span className="text-[#4A5568]">Amount</span>
                    <span className="font-mono text-lg font-semibold tabular-nums text-[#0B1D3A]">
                      {formatEuroCents(
                        selectedRequest
                          ? selectedRequest.amountCents
                          : parseEuroInputToCents(amountInput) ?? 0,
                        locale
                      )}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#4A5568]">Currency & Scheme</span>
                    <span>EUR · Simulated Digital Euro Prototype</span>
                  </div>
                </div>

                <div className="flex justify-between">
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedRequestId(null);
                      setPayStep(2);
                    }}
                    className="px-4 py-2 text-sm text-[#4A5568] hover:text-[#0B1D3A]"
                  >
                    Edit Amount
                  </button>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handleCreatePaymentIntent}
                    className="bg-[#003399] text-white px-5 py-2 text-sm font-medium hover:bg-[#002673] disabled:opacity-50"
                  >
                    Create Payment Intent
                  </button>
                </div>
              </div>
            )}

            {payStep === 4 && currentIntent && (
              <div className="space-y-4">
                <div className="bg-[#FAF8F3] border border-[#E4DFD3] p-5 space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-[#4A5568]">Payment Identifier</span>
                    <span className="font-mono text-xs">{currentIntent.id}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#4A5568]">Lifecycle State</span>
                    <span className="font-semibold text-[#003399]">{currentIntent.state}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#4A5568]">Amount</span>
                    <span className="font-mono font-semibold tabular-nums">
                      {formatEuroCents(currentIntent.amountCents, locale)}
                    </span>
                  </div>
                </div>

                {currentIntent.stepUpRequired && (
                  <label className="flex items-start gap-3 p-4 border border-[#B58B1B] bg-[#FAF8F3] text-sm cursor-pointer">
                    <input
                      type="checkbox"
                      checked={stepUpConfirmed}
                      onChange={(e) => setStepUpConfirmed(e.target.checked)}
                      className="mt-1"
                    />
                    <span>
                      <strong>Step-Up Authorisation Required (€50.00+):</strong> Confirm simulated hardware device biometric/PIN approval before atomic reservation and ledger posting.
                    </span>
                  </label>
                )}

                <label className="flex items-start gap-3 p-3 border border-[#E4DFD3] text-xs text-[#4A5568] cursor-pointer">
                  <input
                    type="checkbox"
                    checked={simulateDrop}
                    onChange={(e) => setSimulateDrop(e.target.checked)}
                    className="mt-0.5"
                  />
                  <span>
                    Test Timeout Recovery: Simulate lost HTTP 504 response after server commit so you can verify outcome via <code className="font-mono">GET /v1/payments/{currentIntent.id}</code>.
                  </span>
                </label>

                <div className="flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handleCancelIntent}
                    className="px-4 py-2 text-sm border border-[#D4CEC0] text-[#4A5568] hover:text-[#0B1D3A]"
                  >
                    Cancel Payment
                  </button>
                  <button
                    type="button"
                    disabled={busy || (currentIntent.stepUpRequired && !stepUpConfirmed)}
                    onClick={() => handleAuthorisePayment(false)}
                    className="bg-[#003399] text-white px-6 py-2.5 text-sm font-medium hover:bg-[#002673] disabled:opacity-50"
                  >
                    Authorise & Post Atomically
                  </button>
                </div>
              </div>
            )}

            {payStep === 5 && currentIntent && (
              <div className="space-y-4">
                {droppedPaymentId ? (
                  <div className="border border-amber-300 bg-amber-50 p-5 space-y-3">
                    <div className="flex items-center gap-2 text-amber-900 font-semibold">
                      <Clock className="h-5 w-5" />
                      <span>Response Timeout — Outcome Unconfirmed in Client</span>
                    </div>
                    <p className="text-sm text-amber-900">
                      Do NOT submit a second payment. Query the authoritative payment status endpoint to recover the committed outcome.
                    </p>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleCheckPaymentOutcome(droppedPaymentId)}
                      className="bg-[#0B1D3A] text-white px-4 py-2 text-sm font-medium hover:bg-[#132A4F]"
                    >
                      Check Authoritative Outcome (GET /v1/payments/{droppedPaymentId})
                    </button>
                  </div>
                ) : (
                  <div
                    className={`border p-5 space-y-2 ${
                      currentIntent.state === 'POSTED'
                        ? 'border-emerald-300 bg-emerald-50'
                        : 'border-red-300 bg-red-50'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-base text-[#0B1D3A]">
                        Payment {currentIntent.state}
                      </span>
                      <span className="font-mono text-lg font-semibold tabular-nums">
                        {formatEuroCents(currentIntent.amountCents, locale)}
                      </span>
                    </div>
                    <p className="text-xs text-[#4A5568] font-mono">
                      Payment ID: {currentIntent.id} · Journal TX: {currentIntent.journalTxId ?? 'None'}
                    </p>
                    {currentIntent.failureReason && (
                      <p className="text-sm text-red-900">{currentIntent.failureReason}</p>
                    )}
                  </div>
                )}

                <div className="flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={() => handleAuthorisePayment(true)}
                    className="border border-[#0B1D3A] text-[#0B1D3A] px-4 py-2 text-xs font-medium hover:bg-[#F2EFE6]"
                  >
                    Test Idempotent Duplicate Retry (Same Key)
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setCurrentIntent(null);
                      setSelectedRequestId(null);
                      setPayStep(1);
                    }}
                    className="bg-[#003399] text-white px-5 py-2 text-sm font-medium hover:bg-[#002673]"
                  >
                    New Payment
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* REQUEST TAB */}
        {tab === 'request' && activeConsumer && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
              <h2 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[#0B1D3A]">
                Create P2P Payment Request
              </h2>
              <div>
                <label className="block text-xs font-medium text-[#4A5568] mb-1">Amount (EUR)</label>
                <input
                  value={reqAmountInput}
                  onChange={(e) => setReqAmountInput(e.target.value)}
                  className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm font-mono tabular-nums"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-[#4A5568] mb-1">Note</label>
                <input
                  value={reqDescInput}
                  onChange={(e) => setReqDescInput(e.target.value)}
                  className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-sm"
                />
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={handleCreateP2PRequest}
                className="w-full bg-[#003399] text-white px-4 py-2.5 text-sm font-medium hover:bg-[#002673]"
              >
                Generate Signed Request QR
              </button>
            </div>

            <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
              <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                Active P2P Requests
              </h3>
              {openPaymentRequests.filter((r) => r.kind === 'P2P_REQUEST').length === 0 ? (
                <p className="text-sm text-[#4A5568]">No P2P requests generated yet.</p>
              ) : (
                <div className="space-y-4">
                  {openPaymentRequests
                    .filter((r) => r.kind === 'P2P_REQUEST')
                    .slice(0, 3)
                    .map((r) => (
                      <div key={r.id} className="border border-[#E4DFD3] p-4 flex items-center gap-4">
                        <QrCodeGraphic value={r.qrPayload} size={96} />
                        <div className="min-w-0 flex-1 text-xs space-y-1">
                          <p className="font-semibold text-[#0B1D3A] text-sm">
                            {formatEuroCents(r.amountCents, locale)} · {r.status}
                          </p>
                          <p className="text-[#4A5568] truncate">{r.description}</p>
                          <p className="font-mono text-[11px] text-[#64748B] truncate">{r.id}</p>
                        </div>
                      </div>
                    ))}
                </div>
              )}
            </div>
          </div>
        )}

        {/* ACTIVITY TAB */}
        {tab === 'activity' && activeConsumer && (
          <div className="bg-white border border-[#E4DFD3] p-6 space-y-5">
            <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
              <div>
                <h2 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[#0B1D3A]">
                  {t.recentActivity}
                </h2>
                <p className="text-xs text-[#4A5568]">
                  Consumer payment history (kept distinct from internal double-entry ledger postings)
                </p>
              </div>
              <button
                type="button"
                onClick={onRefresh}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-[#003399] hover:underline"
              >
                <RefreshCw className="h-3.5 w-3.5" />
                Refresh
              </button>
            </div>

            {(!activeActivity ||
              (activeActivity.payments.length === 0 &&
                activeActivity.fundings.length === 0 &&
                activeActivity.refunds.length === 0)) && (
              <p className="py-8 text-sm text-[#4A5568]">
                No consumer activity recorded yet. Fund your wallet from Account or run the 10-Step Proof.
              </p>
            )}

            {activeActivity && activeActivity.payments.length > 0 && (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-sm">
                  <thead>
                    <tr className="border-b border-[#E4DFD3] text-xs text-[#4A5568]">
                      <th className="py-2 pr-4 font-medium">Direction / Counterparty</th>
                      <th className="py-2 pr-4 font-medium">State</th>
                      <th className="py-2 pr-4 font-medium">Refunded</th>
                      <th className="py-2 text-right font-medium">Amount</th>
                      <th className="py-2 pl-4 text-right font-medium">Receipt</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EFECE4]">
                    {activeActivity.payments.map((p) => {
                      const isOutgoing = p.payerUserId === activeConsumer.id;
                      return (
                        <tr key={p.id} className="hover:bg-[#FAF8F3]">
                          <td className="py-3 pr-4">
                            <div className="flex items-center gap-2 font-medium text-[#0B1D3A]">
                              {isOutgoing ? (
                                <ArrowUpRight className="h-4 w-4 text-[#0B1D3A]" />
                              ) : (
                                <ArrowDownLeft className="h-4 w-4 text-emerald-700" />
                              )}
                              <span>{isOutgoing ? p.payeeName : p.payerName}</span>
                            </div>
                            <p className="text-xs text-[#64748B] font-mono">
                              {p.id} · {p.kind}
                            </p>
                          </td>
                          <td className="py-3 pr-4 text-xs font-medium">{p.state}</td>
                          <td className="py-3 pr-4 font-mono text-xs tabular-nums">
                            {p.refundedCents > 0 ? formatEuroCents(p.refundedCents, locale) : '—'}
                          </td>
                          <td className="py-3 text-right font-mono font-medium tabular-nums">
                            {isOutgoing ? '-' : '+'}
                            {formatEuroCents(p.amountCents, locale)}
                          </td>
                          <td className="py-3 pl-4 text-right">
                            <button
                              type="button"
                              onClick={() => setReceiptPayment(p)}
                              className="text-xs text-[#003399] font-medium hover:underline"
                            >
                              View
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {activeActivity && activeActivity.refunds.length > 0 && (
              <div className="pt-4 border-t border-[#E4DFD3]">
                <h3 className="text-sm font-semibold text-[#0B1D3A] mb-2">Refunds Received</h3>
                <div className="divide-y divide-[#EFECE4] text-sm">
                  {activeActivity.refunds.map((ref) => (
                    <div key={ref.id} className="py-2.5 flex items-center justify-between">
                      <div>
                        <p className="font-medium text-[#0B1D3A]">Refund for {ref.originalPaymentId}</p>
                        <p className="text-xs text-[#4A5568]">
                          {ref.reason} · {ref.status}
                        </p>
                      </div>
                      <span className="font-mono font-semibold text-emerald-800 tabular-nums">
                        +{formatEuroCents(ref.amountCents, locale)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {receiptPayment && (
              <div className="border border-[#0B1D3A] bg-[#FAF8F3] p-5 space-y-2 text-xs">
                <div className="flex items-center justify-between">
                  <strong className="text-sm text-[#0B1D3A]">Payment Receipt · {receiptPayment.id}</strong>
                  <button
                    type="button"
                    onClick={() => setReceiptPayment(null)}
                    className="text-[#003399] font-medium hover:underline"
                  >
                    Close
                  </button>
                </div>
                <p>From: {receiptPayment.payerName} → To: {receiptPayment.payeeName}</p>
                <p>
                  Amount: {formatEuroCents(receiptPayment.amountCents, locale)} · Refunded:{' '}
                  {formatEuroCents(receiptPayment.refundedCents, locale)} · State: {receiptPayment.state}
                </p>
                <p className="font-mono text-[#4A5568]">
                  Settlement Journal TX: {receiptPayment.journalTxId ?? 'Not settled'} · Timestamp: {receiptPayment.updatedAt}
                </p>
              </div>
            )}
          </div>
        )}

        {/* ACCOUNT TAB: Funding, Redemption, Device Management, Recovery */}
        {tab === 'account' && activeConsumer && (
          <div className="space-y-6">
            {/* Commercial Bank Funding & Redemption Simulation */}
            <div className="bg-white border border-[#E4DFD3] p-6 space-y-5">
              <div className="flex items-start justify-between gap-4 border-b border-[#E4DFD3] pb-3">
                <div>
                  <h2 className="font-[family-name:var(--font-display)] text-lg font-semibold text-[#0B1D3A]">
                    Commercial Bank Funding & Redemption Simulation
                  </h2>
                  <p className="text-xs text-[#4A5568]">
                    {activeConsumer.linkedBankName} ({activeConsumer.linkedBankIbanMasked}) · Separate request → provider result → ledger posting
                  </p>
                </div>
                <Building2 className="h-5 w-5 text-[#003399] shrink-0" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-3 border border-[#E4DFD3] p-4 bg-[#FAF8F3]">
                  <h3 className="text-sm font-semibold text-[#0B1D3A]">1. Bank Funding (Commercial Bank → Wallet)</h3>
                  <input
                    value={fundAmountInput}
                    onChange={(e) => setFundAmountInput(e.target.value)}
                    className="w-full border border-[#D4CEC0] bg-white px-3 py-2 text-sm font-mono tabular-nums"
                  />
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleFundingFlow('REQUEST_ONLY')}
                      className="border border-[#0B1D3A] bg-white px-3 py-1.5 text-xs font-medium text-[#0B1D3A] hover:bg-[#F2EFE6]"
                    >
                      Submit Request Only (Pending)
                    </button>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleFundingFlow('SETTLE')}
                      className="bg-[#003399] text-white px-3 py-1.5 text-xs font-medium hover:bg-[#002673]"
                    >
                      Settle via Bank Adapter
                    </button>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleFundingFlow('FAIL')}
                      className="border border-red-300 bg-red-50 text-red-900 px-3 py-1.5 text-xs font-medium hover:bg-red-100"
                    >
                      Simulate Failed Funding
                    </button>
                  </div>
                </div>

                <div className="space-y-3 border border-[#E4DFD3] p-4 bg-[#FAF8F3]">
                  <h3 className="text-sm font-semibold text-[#0B1D3A]">2. Redemption (Wallet → Commercial Bank)</h3>
                  <input
                    value={redeemAmountInput}
                    onChange={(e) => setRedeemAmountInput(e.target.value)}
                    className="w-full border border-[#D4CEC0] bg-white px-3 py-2 text-sm font-mono tabular-nums"
                  />
                  <div className="flex flex-wrap gap-2">
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleRedemptionFlow('SETTLED')}
                      className="bg-[#0B1D3A] text-white px-3 py-1.5 text-xs font-medium hover:bg-[#132A4F]"
                    >
                      Redeem & Settle Payout
                    </button>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleRedemptionFlow('FAILED')}
                      className="border border-amber-400 bg-amber-50 text-amber-950 px-3 py-1.5 text-xs font-medium hover:bg-amber-100"
                    >
                      Simulate Payout Failure (Reversal)
                    </button>
                  </div>
                </div>
              </div>
            </div>

            {/* Device Management & Account Recovery */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
                  <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                    Device-Bound Credentials
                  </h3>
                  <Smartphone className="h-4 w-4 text-[#003399]" />
                </div>
                <div className="divide-y divide-[#EFECE4] text-xs">
                  {activeDevices.map((d) => (
                    <div key={d.id} className="py-3 flex items-center justify-between gap-3">
                      <div className="min-w-0">
                        <p className="font-semibold text-[#0B1D3A] text-sm truncate">{d.deviceName}</p>
                        <p className="font-mono text-[#4A5568] truncate">
                          {d.publicKeyFingerprint} · {d.status}
                        </p>
                      </div>
                      {d.status === 'ACTIVE' && (
                        <button
                          type="button"
                          onClick={() => handleDeviceAction('MARK_LOST', d.id)}
                          className="text-red-700 font-medium hover:underline whitespace-nowrap"
                        >
                          Mark Lost
                        </button>
                      )}
                    </div>
                  ))}
                </div>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => handleDeviceAction('BIND_NEW')}
                  className="w-full border border-[#0B1D3A] px-3 py-2 text-xs font-medium text-[#0B1D3A] hover:bg-[#FAF8F3]"
                >
                  Bind Secondary Device
                </button>
              </div>

              <div className="bg-white border border-[#E4DFD3] p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-[#E4DFD3] pb-3">
                  <h3 className="font-[family-name:var(--font-display)] text-base font-semibold text-[#0B1D3A]">
                    Account Recovery Demonstration
                  </h3>
                  <KeyRound className="h-4 w-4 text-[#B58B1B]" />
                </div>
                <p className="text-xs text-[#4A5568]">
                  Demonstrates revoking compromised/lost device keys and binding a new replacement device using synthetic recovery verification. (Seeded phrase for Clara: <code className="font-mono">amber-river-nordic-vault</code>; Lucas: <code className="font-mono">cedar-bridge-silver-horizon</code>)
                </p>
                <div>
                  <label className="block text-xs font-medium text-[#4A5568] mb-1">Recovery Phrase</label>
                  <input
                    value={recoveryPhrase}
                    onChange={(e) => setRecoveryPhrase(e.target.value)}
                    className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-xs font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-[#4A5568] mb-1">Replacement Device Name</label>
                  <input
                    value={newDeviceName}
                    onChange={(e) => setNewDeviceName(e.target.value)}
                    className="w-full border border-[#D4CEC0] bg-[#FAF8F3] px-3 py-2 text-xs"
                  />
                </div>
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => handleDeviceAction('RECOVER_WALLET')}
                  className="w-full inline-flex items-center justify-center gap-2 bg-[#0B1D3A] text-white px-4 py-2 text-xs font-medium hover:bg-[#132A4F]"
                >
                  <Lock className="h-3.5 w-3.5" />
                  Execute Recovery & Re-Bind Device
                </button>
              </div>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
