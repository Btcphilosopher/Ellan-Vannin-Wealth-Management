'use client';

import { useEffect, useState } from 'react';
import Image from 'next/image';
import QRCode from 'qrcode';

export function QrCodeGraphic({ value, size = 184 }: { value: string; size?: number }) {
  const [dataUrl, setDataUrl] = useState<string>('');

  useEffect(() => {
    let active = true;
    QRCode.toDataURL(value, {
      width: size,
      margin: 2,
      color: {
        dark: '#0B1D3A',
        light: '#FFFFFF',
      },
    })
      .then((url) => {
        if (active) setDataUrl(url);
      })
      .catch(() => {
        if (active) setDataUrl('');
      });
    return () => {
      active = false;
    };
  }, [value, size]);

  if (!dataUrl) {
    return (
      <div
        style={{ width: size, height: size }}
        className="flex items-center justify-center border border-[#E4DFD3] bg-[#F2EFE6] text-xs text-[#4A5568]"
      >
        Generating QR…
      </div>
    );
  }

  return (
    <Image
      src={dataUrl}
      alt="Digital Euro payment request QR code"
      width={size}
      height={size}
      referrerPolicy="no-referrer"
      className="border border-[#E4DFD3] bg-white p-1"
    />
  );
}
