# Digital Euro Independent Research Prototype — Architecture & ECB Research

> **Notice:** This software is an **independent demonstration prototype** using **synthetic identities and simulated funds**. It does not issue official digital euros, does not represent European Central Bank (ECB) or Eurosystem liabilities, and does not connect to Eurosystem infrastructure.

## 1. ECB Research Taxonomy

| Topic | Status | Summary & Prototype Handling |
| :--- | :--- | :--- |
| **Retail Holding Limits** | **Confirmed ECB Requirement** | Designed to prevent commercial bank disintermediation and digital bank runs; exact statutory figure will be calibrated post-legislation. Prototype enforces configurable integer-cent limits defaulting to €3,000.00 (demonstration assumption). |
| **Waterfall / Reverse-Waterfall Bank Linking** | **Proposed Rulebook Mechanism** | Draft Rulebook Development Group (RDG) specifications describe automatic overflow sweeps to a linked commercial bank account and automated gap-funding during checkout. |
| **Privacy & Settlement Pseudonymisation** | **Confirmed ECB Requirement** | Eurosystem settlement layer is designed not to inspect clear-text consumer identities; PSPs perform KYC/AML. Prototype keeps PII in `users` and references opaque account IDs in `journal_postings`. |
| **Merchant QR Standardisation** | **Proposed Rulebook Mechanism** | RDG specifies standardised QR payloads referencing authenticated payment requests bound to merchant, amount, currency, and expiry. Merchant browser polls backend and never self-declares settlement. |
| **Offline Cash-Like Payments** | **Confirmed ECB Requirement** | Offline payments operate without sharing logs with PSPs or Eurosystem, requiring certified hardware Secure Elements (SE/TEE). Kept strictly isolated in the Offline Research Simulator outside the online ledger. |
| **No Programmable Restrictions on Money** | **Confirmed ECB Requirement** | Digital euro remains fungible retail money; zero MCC or purchase-category restrictions exist in the prototype. |
| **Exact Numerical Caps (€3,000 / €50 Step-Up)** | **Demonstration Assumption** | Illustrative values configurable via dual-control Admin Console with recorded justification. |
| **Certified Hardware SE/TEE & PSP Licensing** | **Unresolved Production Requirement** | Requires certified smartphone Secure Elements, hardware attestation, TIPS-grade 24/7 rails, and EU statutory authorisation. |

## 2. Why an Append-Only Double-Entry Relational Ledger (No Blockchain)

A European retail CBDC operated by the Eurosystem and supervised PSPs relies on institutional trust rather than permissionless consensus. An append-only double-entry relational ledger (`ledger_accounts`, `journal_transactions`, `journal_postings`) with integer euro cents (`BIGINT`/`INTEGER`), database-level `CHECK` constraints, immutability triggers, and `SELECT ... FOR UPDATE` / `BEGIN IMMEDIATE` write serialization provides deterministic finality, strict double-spend prevention, zero floating-point rounding drift, and clear GDPR data separation without blockchain overhead.

## 3. Build, Deployment & Android Commands

- **Web & Live API (Port 3000):** `npm install && npm run build && npm run start`
- **Node.js Ledger & API Test Suite:** `node --test tests/digital-euro.test.mjs`
- **Python Ledger Test Suite:** `python3 -m unittest discover -s backend/tests -v`
- **Docker Compose Stack (PostgreSQL + FastAPI + Worker + Web):** `docker compose -f deploy/docker-compose.yml up --build`
- **Android Kotlin/Compose Wallet:** `cd android-wallet && ./gradlew assembleDebug testDebugUnitTest`
