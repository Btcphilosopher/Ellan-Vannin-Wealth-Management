import { DigitalEuroShell } from '@/components/DigitalEuroShell';
import {
  getAdminOverview,
  getConsumerProfiles,
  getDevicesForUser,
  getMerchantProfiles,
} from '@/lib/core/admin';
import { getDb } from '@/lib/core/db';
import { getOfflineSimulatorState } from '@/lib/core/offline-sim';
import { expireStalePaymentRequestsAndIntents, listConsumerActivity } from '@/lib/core/payments';
import { ECB_RESEARCH_MATRIX } from '@/lib/core/types';

export const dynamic = 'force-dynamic';

export default async function HomePage() {
  expireStalePaymentRequestsAndIntents();
  const db = getDb();
  const consumers = getConsumerProfiles();
  const merchants = getMerchantProfiles();
  const activeConsumer = consumers[0] ?? null;

  const openRequests = db
    .prepare(
      `SELECT * FROM payment_requests WHERE status IN ('OPEN', 'PAID', 'EXPIRED') ORDER BY created_at DESC LIMIT 20`
    )
    .all() as Array<Record<string, unknown>>;

  const merchantPayments = db
    .prepare(`SELECT * FROM payments WHERE payee_kind = 'MERCHANT' ORDER BY created_at DESC LIMIT 30`)
    .all() as Array<Record<string, unknown>>;

  const initialData = {
    consumers,
    merchants,
    openPaymentRequests: openRequests.map((r) => ({
      id: String(r.id),
      merchantId: r.merchant_id ? String(r.merchant_id) : null,
      requesterUserId: r.requester_user_id ? String(r.requester_user_id) : null,
      requesterName: String(r.requester_name),
      requesterVerified: Number(r.requester_verified) === 1,
      kind: r.kind as 'MERCHANT_POS' | 'P2P_REQUEST',
      amountCents: Number(r.amount_cents),
      currency: 'EUR' as const,
      description: String(r.description),
      qrPayload: String(r.qr_payload),
      status: r.status as 'OPEN' | 'PAID' | 'EXPIRED' | 'CANCELLED',
      paymentId: r.payment_id ? String(r.payment_id) : null,
      expiresAt: String(r.expires_at),
      createdAt: String(r.created_at),
    })),
    merchantPayments,
    activeConsumer,
    activeDevices: activeConsumer ? getDevicesForUser(activeConsumer.id) : [],
    activeActivity: activeConsumer ? listConsumerActivity(activeConsumer.id) : null,
    adminOverview: getAdminOverview(),
    offlineSim: getOfflineSimulatorState(),
    ecbResearchMatrix: ECB_RESEARCH_MATRIX,
  };

  return <DigitalEuroShell initialData={initialData} />;
}
