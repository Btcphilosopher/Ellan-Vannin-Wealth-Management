import { NextRequest } from 'next/server';
import { enforceRateLimit, jsonError, jsonOk } from '@/lib/core/http';
import { issueMerchantRefund } from '@/lib/core/payments';

export async function POST(req: NextRequest) {
  const limited = enforceRateLimit(req, 'refunds');
  if (limited) return limited;

  try {
    const body = await req.json();
    const idempotencyKey =
      req.headers.get('idempotency-key') || String(body.idempotencyKey ?? '');

    const refund = issueMerchantRefund({
      idempotencyKey,
      originalPaymentId: String(body.originalPaymentId ?? ''),
      merchantId: String(body.merchantId ?? 'mrc_cafe_europa'),
      amountCents: Number(body.amountCents),
      reason: String(body.reason ?? 'Merchant refund'),
      actorId: String(body.merchantId ?? 'mrc_cafe_europa'),
    });

    return jsonOk({ refund }, 201);
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Refund failed', 400, 'REFUND_ERROR');
  }
}
