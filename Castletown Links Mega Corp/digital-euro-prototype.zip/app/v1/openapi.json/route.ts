import { jsonOk } from '@/lib/core/http';
import { buildOpenApiSpec } from '@/lib/core/openapi';

export async function GET() {
  return jsonOk(buildOpenApiSpec());
}
