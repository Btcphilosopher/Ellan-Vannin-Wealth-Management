import { NextRequest } from 'next/server';
import { jsonError, jsonOk } from '@/lib/core/http';
import { getOfflineSimulatorState, runOfflineSimulatorAction } from '@/lib/core/offline-sim';

export async function GET() {
  return jsonOk({ offlineSim: getOfflineSimulatorState() });
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const offlineSim = runOfflineSimulatorAction({
      action: body.action,
      amountCents: body.amountCents !== undefined ? Number(body.amountCents) : undefined,
      recipient: body.recipient ? String(body.recipient) : undefined,
    });
    return jsonOk({ offlineSim });
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Offline simulator action failed', 400, 'OFFLINE_SIM_ERROR');
  }
}
