import { NextRequest } from 'next/server';
import { getMerchantProfiles } from '@/lib/core/admin';
import { enforceRateLimit, jsonError, jsonOk } from '@/lib/core/http';
import { registerMerchant } from '@/lib/core/payments';

export async function GET() {
  return jsonOk({ merchants: getMerchantProfiles() });
}

export async function POST(req: NextRequest) {
  const limited = enforceRateLimit(req, 'merchants');
  if (limited) return limited;

  try {
    const body = await req.json();
    const merchant = registerMerchant({
      legalName: String(body.legalName ?? ''),
      displayName: String(body.displayName ?? ''),
      registrationCode: String(body.registrationCode ?? ''),
      mcc: String(body.mcc ?? '5999'),
      city: String(body.city ?? 'Frankfurt'),
      countryCode: String(body.countryCode ?? 'DE'),
    });
    return jsonOk({ merchant }, 201);
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Merchant registration failed', 400, 'MERCHANT_ERROR');
  }
}
