import { NextRequest, NextResponse } from 'next/server';
import { getDb } from '@/lib/core/db';

export async function GET(req: NextRequest) {
  const merchantId = req.nextUrl.searchParams.get('merchantId') || 'mrc_cafe_europa';
  const format = req.nextUrl.searchParams.get('format') === 'json' ? 'json' : 'csv';
  const db = getDb();

  const rows = db
    .prepare(`
      SELECT id, kind, payer_name, amount_cents, refunded_cents, currency, state, journal_tx_id, created_at
      FROM payments
      WHERE payee_kind = 'MERCHANT' AND payee_id = ?
      ORDER BY created_at DESC
    `)
    .all(merchantId) as Array<Record<string, unknown>>;

  if (format === 'json') {
    return NextResponse.json({ merchantId, exportedAt: new Date().toISOString(), payments: rows });
  }

  const esc = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
  const csv = [
    'payment_id,kind,payer_name,amount_cents,refunded_cents,currency,state,journal_tx_id,created_at',
    ...rows.map((r) =>
      [
        r.id,
        r.kind,
        r.payer_name,
        r.amount_cents,
        r.refunded_cents,
        r.currency,
        r.state,
        r.journal_tx_id,
        r.created_at,
      ]
        .map(esc)
        .join(',')
    ),
  ].join('\n');

  return new NextResponse(csv, {
    status: 200,
    headers: {
      'Content-Type': 'text/csv; charset=utf-8',
      'Content-Disposition': `attachment; filename="merchant-${merchantId}-transactions.csv"`,
    },
  });
}
