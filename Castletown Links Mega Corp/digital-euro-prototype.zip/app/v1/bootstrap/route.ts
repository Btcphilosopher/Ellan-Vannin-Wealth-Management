import { NextRequest } from 'next/server';
import { getAdminOverview, getConsumerProfiles, getDevicesForUser, getMerchantProfiles } from '@/lib/core/admin';
import { verifyBearerToken } from '@/lib/core/auth';
import { getDb } from '@/lib/core/db';
import { jsonOk } from '@/lib/core/http';
import { getOfflineSimulatorState } from '@/lib/core/offline-sim';
import { expireStalePaymentRequestsAndIntents, listConsumerActivity } from '@/lib/core/payments';
import { ECB_RESEARCH_MATRIX } from '@/lib/core/types';

export async function GET(req: NextRequest) {
  expireStalePaymentRequestsAndIntents();
  const db = getDb();
  const claims = verifyBearerToken(req.headers.get('authorization'));

  const consumers = getConsumerProfiles();
  const merchants = getMerchantProfiles();
  const openRequests = db
    .prepare(`SELECT * FROM payment_requests WHERE status IN ('OPEN', 'PAID', 'EXPIRED') ORDER BY created_at DESC LIMIT 20`)
    .all() as Array<Record<string, unknown>>;

  const merchantPayments = db
    .prepare(`SELECT * FROM payments WHERE payee_kind = 'MERCHANT' ORDER BY created_at DESC LIMIT 30`)
    .all() as Array<Record<string, unknown>>;

  const activeUserId =
    claims && claims.role === 'CONSUMER'
      ? claims.sub
      : (req.nextUrl.searchParams.get('consumerId') || consumers[0]?.id || 'usr_clara');

  const activeConsumer = consumers.find((c) => c.id === activeUserId) ?? consumers[0] ?? null;
  const activeDevices = activeConsumer ? getDevicesForUser(activeConsumer.id) : [];
  const activeActivity = activeConsumer ? listConsumerActivity(activeConsumer.id) : null;
  const adminOverview = getAdminOverview();
  const offlineSim = getOfflineSimulatorState();

  return jsonOk({
    prototypeNotice: 'DEMONSTRATION — SIMULATED FUNDS · Independent Prototype · Not Official ECB / Eurosystem Infrastructure',
    consumers,
    merchants,
    openPaymentRequests: openRequests.map((r) => ({
      id: String(r.id),
      merchantId: r.merchant_id ? String(r.merchant_id) : null,
      requesterUserId: r.requester_user_id ? String(r.requester_user_id) : null,
      requesterName: String(r.requester_name),
      requesterVerified: Number(r.requester_verified) === 1,
      kind: String(r.kind),
      amountCents: Number(r.amount_cents),
      currency: 'EUR',
      description: String(r.description),
      qrPayload: String(r.qr_payload),
      status: String(r.status),
      paymentId: r.payment_id ? String(r.payment_id) : null,
      expiresAt: String(r.expires_at),
      createdAt: String(r.created_at),
    })),
    merchantPayments,
    activeConsumer,
    activeDevices,
    activeActivity,
    adminOverview,
    offlineSim,
    ecbResearchMatrix: ECB_RESEARCH_MATRIX,
  });
}
