import { NextRequest } from 'next/server';
import { jsonOk, requireAuth } from '@/lib/core/http';
import { listConsumerActivity } from '@/lib/core/payments';

export async function GET(req: NextRequest) {
  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  const activity = listConsumerActivity(auth.claims.sub);
  return jsonOk(activity);
}
