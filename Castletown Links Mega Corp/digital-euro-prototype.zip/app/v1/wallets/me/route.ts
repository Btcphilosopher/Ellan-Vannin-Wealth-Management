import { NextRequest } from 'next/server';
import { getConsumerProfileById, getDevicesForUser } from '@/lib/core/admin';
import { jsonError, jsonOk, requireAuth } from '@/lib/core/http';

export async function GET(req: NextRequest) {
  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  const profile = getConsumerProfileById(auth.claims.sub);
  if (!profile) {
    return jsonError('Consumer wallet not found', 404, 'NOT_FOUND');
  }

  return jsonOk({
    wallet: profile,
    devices: getDevicesForUser(auth.claims.sub),
    unit: 'EUR_CENTS_INTEGER',
  });
}
