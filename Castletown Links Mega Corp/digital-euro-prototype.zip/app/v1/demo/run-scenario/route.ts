import { runFullTenStepDemonstration } from '@/lib/core/demo-scenario';
import { jsonError, jsonOk } from '@/lib/core/http';

export async function POST() {
  try {
    const result = await runFullTenStepDemonstration();
    return jsonOk(result);
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Demo scenario failed', 500, 'DEMO_ERROR');
  }
}
