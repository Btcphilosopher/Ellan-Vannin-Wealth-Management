import { resetDatabaseForDemo } from '@/lib/core/db';
import { jsonOk } from '@/lib/core/http';

export async function POST() {
  resetDatabaseForDemo();
  return jsonOk({ status: 'reset', message: 'Synthetic consumers, merchant, and zeroed ledger restored.' });
}
