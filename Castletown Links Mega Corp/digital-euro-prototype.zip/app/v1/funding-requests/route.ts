import { NextRequest } from 'next/server';
import { createFundingRequest } from '@/lib/core/funding';
import { enforceRateLimit, jsonError, jsonOk, requireAuth } from '@/lib/core/http';

export async function POST(req: NextRequest) {
  const limited = enforceRateLimit(req, 'funding_req');
  if (limited) return limited;

  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  try {
    const body = await req.json();
    const idempotencyKey =
      req.headers.get('idempotency-key') || String(body.idempotencyKey ?? '');

    const funding = createFundingRequest({
      idempotencyKey,
      userId: auth.claims.sub,
      amountCents: Number(body.amountCents),
      provider: body.provider ? String(body.provider) : 'rheinmain_demo_bank',
    });

    return jsonOk({ fundingRequest: funding }, 201);
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Funding request failed', 400, 'FUNDING_ERROR');
  }
}
