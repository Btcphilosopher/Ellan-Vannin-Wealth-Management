import { NextRequest } from 'next/server';
import { jsonError, jsonOk } from '@/lib/core/http';
import { getPaymentRequestById } from '@/lib/core/payments';

export async function GET(
  _req: NextRequest,
  context: { params: Promise<{ request_id: string }> }
) {
  const { request_id } = await context.params;
  const record = getPaymentRequestById(request_id);
  if (!record) {
    return jsonError('Payment request not found', 404, 'NOT_FOUND');
  }
  return jsonOk({ paymentRequest: record });
}
