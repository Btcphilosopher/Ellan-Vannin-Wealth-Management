import { NextRequest } from 'next/server';
import { verifyBearerToken } from '@/lib/core/auth';
import { enforceRateLimit, jsonError, jsonOk } from '@/lib/core/http';
import { createPaymentRequest } from '@/lib/core/payments';

export async function POST(req: NextRequest) {
  const limited = enforceRateLimit(req, 'payment_requests');
  if (limited) return limited;

  try {
    const body = await req.json();
    const kind = body.kind === 'P2P_REQUEST' ? 'P2P_REQUEST' : 'MERCHANT_POS';

    let requesterUserId = body.requesterUserId ? String(body.requesterUserId) : undefined;
    if (kind === 'P2P_REQUEST') {
      const claims = verifyBearerToken(req.headers.get('authorization'));
      if (!claims) {
        return jsonError('Authentication required to create a P2P payment request', 401, 'UNAUTHENTICATED');
      }
      requesterUserId = claims.sub;
    }

    const requestRecord = createPaymentRequest({
      kind,
      merchantId: body.merchantId ? String(body.merchantId) : undefined,
      requesterUserId,
      amountCents: Number(body.amountCents),
      description: String(body.description ?? 'Digital Euro Payment'),
      expiresInSeconds: body.expiresInSeconds ? Number(body.expiresInSeconds) : 300,
    });

    return jsonOk({ paymentRequest: requestRecord }, 201);
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Failed to create payment request', 400, 'PAYMENT_REQUEST_ERROR');
  }
}
