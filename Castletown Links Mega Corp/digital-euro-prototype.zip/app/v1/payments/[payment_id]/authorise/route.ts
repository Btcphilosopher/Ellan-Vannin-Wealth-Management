import { NextRequest } from 'next/server';
import { enforceRateLimit, jsonError, jsonOk, requireAuth } from '@/lib/core/http';
import { authoriseAndPostPayment } from '@/lib/core/payments';

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ payment_id: string }> }
) {
  const limited = enforceRateLimit(req, 'payments_auth');
  if (limited) return limited;

  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  try {
    const { payment_id } = await context.params;
    const body = await req.json().catch(() => ({}));
    const idempotencyKey =
      req.headers.get('idempotency-key') ||
      String(body.authoriseIdempotencyKey ?? `auth_${payment_id}`);

    const result = authoriseAndPostPayment({
      paymentId: payment_id,
      actorUserId: auth.claims.sub,
      authoriseIdempotencyKey: idempotencyKey,
      stepUpConfirmed: Boolean(body.stepUpConfirmed),
      simulateLostResponse: Boolean(body.simulateLostResponse),
    });

    if (result.simulatedNetworkDrop) {
      return jsonError(
        'Simulated network timeout after server commit. Poll GET /v1/payments/{payment_id} to check outcome instead of submitting a second payment.',
        504,
        'SIMULATED_TIMEOUT_CHECK_OUTCOME'
      );
    }

    return jsonOk({ payment: result.payment });
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Authorisation failed', 400, 'AUTHORISE_ERROR');
  }
}
