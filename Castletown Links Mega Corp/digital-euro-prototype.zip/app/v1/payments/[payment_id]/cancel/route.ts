import { NextRequest } from 'next/server';
import { jsonError, jsonOk, requireAuth } from '@/lib/core/http';
import { cancelPaymentIntent } from '@/lib/core/payments';

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ payment_id: string }> }
) {
  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  try {
    const { payment_id } = await context.params;
    const payment = cancelPaymentIntent(payment_id, auth.claims.sub);
    return jsonOk({ payment });
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Cancellation failed', 400, 'CANCEL_ERROR');
  }
}
