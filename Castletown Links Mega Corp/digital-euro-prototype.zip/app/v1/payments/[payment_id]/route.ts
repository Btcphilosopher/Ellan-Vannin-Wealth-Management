import { NextRequest } from 'next/server';
import { jsonError, jsonOk, requireAuth } from '@/lib/core/http';
import { getPaymentById } from '@/lib/core/payments';

export async function GET(
  req: NextRequest,
  context: { params: Promise<{ payment_id: string }> }
) {
  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  const { payment_id } = await context.params;
  const payment = getPaymentById(payment_id);
  if (!payment) {
    return jsonError('Payment not found', 404, 'NOT_FOUND');
  }

  const isStaff = auth.claims.role === 'OPERATOR' || auth.claims.role === 'SUPERVISOR' || auth.claims.role === 'AUDITOR';
  const isParticipant =
    payment.payerUserId === auth.claims.sub ||
    (payment.payeeKind === 'CONSUMER' && payment.payeeId === auth.claims.sub);

  if (!isStaff && !isParticipant) {
    return jsonError('Forbidden: payment does not belong to authenticated account', 403, 'FORBIDDEN');
  }

  return jsonOk({ payment });
}
