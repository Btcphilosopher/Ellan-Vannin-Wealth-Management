import { NextRequest } from 'next/server';
import { enforceRateLimit, jsonError, jsonOk, requireAuth } from '@/lib/core/http';
import { createPaymentIntent } from '@/lib/core/payments';

export async function POST(req: NextRequest) {
  const limited = enforceRateLimit(req, 'payments_create');
  if (limited) return limited;

  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  try {
    const body = await req.json();
    const idempotencyKey =
      req.headers.get('idempotency-key') || String(body.idempotencyKey ?? '');

    const payment = createPaymentIntent({
      idempotencyKey,
      payerUserId: auth.claims.sub,
      payeeKind: body.payeeKind === 'MERCHANT' ? 'MERCHANT' : 'CONSUMER',
      payeeId: String(body.payeeId ?? ''),
      amountCents: Number(body.amountCents),
      paymentRequestId: body.paymentRequestId ? String(body.paymentRequestId) : null,
      expiresInSeconds: body.expiresInSeconds ? Number(body.expiresInSeconds) : undefined,
    });
    return jsonOk({ payment }, 201);
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Payment creation failed', 400, 'PAYMENT_CREATE_ERROR');
  }
}
