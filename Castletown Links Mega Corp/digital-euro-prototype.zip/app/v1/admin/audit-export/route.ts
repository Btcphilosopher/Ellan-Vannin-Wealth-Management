import { NextRequest, NextResponse } from 'next/server';
import { exportAuditLogs } from '@/lib/core/admin';
import { requireStaffRole } from '@/lib/core/auth';
import { jsonError, requireAuth } from '@/lib/core/http';

export async function GET(req: NextRequest) {
  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  const staffCheck = requireStaffRole(auth.claims, ['OPERATOR', 'SUPERVISOR', 'AUDITOR']);
  if (!staffCheck.ok) {
    return jsonError(staffCheck.error, staffCheck.status, 'FORBIDDEN');
  }

  const format = req.nextUrl.searchParams.get('format') === 'csv' ? 'csv' : 'json';
  const exported = exportAuditLogs(format);

  return new NextResponse(exported.body, {
    status: 200,
    headers: {
      'Content-Type': exported.contentType,
      'Content-Disposition': `attachment; filename="digital-euro-audit-export.${format}"`,
    },
  });
}
