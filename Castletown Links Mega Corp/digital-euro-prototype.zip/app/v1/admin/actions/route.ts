import { NextRequest } from 'next/server';
import { submitAdminAction } from '@/lib/core/admin';
import { requireStaffRole } from '@/lib/core/auth';
import { enforceRateLimit, jsonError, jsonOk, requireAuth } from '@/lib/core/http';
import type { StaffRole } from '@/lib/core/types';

export async function POST(req: NextRequest) {
  const limited = enforceRateLimit(req, 'admin_actions');
  if (limited) return limited;

  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  const staffCheck = requireStaffRole(auth.claims, ['OPERATOR', 'SUPERVISOR', 'AUDITOR']);
  if (!staffCheck.ok) {
    return jsonError(staffCheck.error, staffCheck.status, 'FORBIDDEN');
  }

  try {
    const body = await req.json();
    const res = submitAdminAction({
      actorId: auth.claims.sub,
      actorRole: auth.claims.role as StaffRole,
      action: body.action,
      targetId: body.targetId ? String(body.targetId) : undefined,
      reason: String(body.reason ?? ''),
      payload: body.payload && typeof body.payload === 'object' ? body.payload : undefined,
    });
    return jsonOk(res);
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Admin action failed', 400, 'ADMIN_ACTION_ERROR');
  }
}
