import { NextRequest } from 'next/server';
import { getAdminOverview } from '@/lib/core/admin';
import { requireStaffRole } from '@/lib/core/auth';
import { jsonError, jsonOk, requireAuth } from '@/lib/core/http';

export async function GET(req: NextRequest) {
  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  const staffCheck = requireStaffRole(auth.claims, ['OPERATOR', 'SUPERVISOR', 'AUDITOR']);
  if (!staffCheck.ok) {
    return jsonError(staffCheck.error, staffCheck.status, 'FORBIDDEN');
  }

  return jsonOk(getAdminOverview());
}
