import { getDb } from '@/lib/core/db';
import { jsonOk } from '@/lib/core/http';

export async function GET() {
  const db = getDb();
  const row = db.prepare('SELECT COUNT(*) as accounts FROM ledger_accounts').get() as { accounts: number };
  return jsonOk({
    status: 'ok',
    prototype: 'DEMONSTRATION_SIMULATED_FUNDS',
    officialEcbConnection: false,
    ledgerAccounts: row.accounts,
    timestamp: new Date().toISOString(),
  });
}
