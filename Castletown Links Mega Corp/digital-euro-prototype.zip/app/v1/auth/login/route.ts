import { NextRequest } from 'next/server';
import { appendAuditLog, signBearerToken, verifySecret } from '@/lib/core/auth';
import { getDb } from '@/lib/core/db';
import { enforceRateLimit, jsonError, jsonOk } from '@/lib/core/http';

const SEEDED_DEMO_IDS = new Set(['usr_clara', 'usr_lucas', 'staff_operator', 'staff_supervisor']);

export async function POST(req: NextRequest) {
  const limited = enforceRateLimit(req, 'auth_login');
  if (limited) return limited;

  try {
    const body = await req.json();
    const db = getDb();

    // Support synthetic persona switching for seeded demo accounts when demo mode is active
    if (body.demoPersonaId && process.env.DIGITAL_EURO_DEMO_MODE !== 'false') {
      const personaId = String(body.demoPersonaId);
      if (!SEEDED_DEMO_IDS.has(personaId)) {
        return jsonError('Unknown synthetic demo persona', 404, 'NOT_FOUND');
      }
      const user = db.prepare('SELECT id, role, full_name, handle FROM users WHERE id = ?').get(personaId) as
        | { id: string; role: 'CONSUMER' | 'OPERATOR' | 'SUPERVISOR'; full_name: string; handle: string }
        | undefined;
      if (!user) return jsonError('Persona not found', 404, 'NOT_FOUND');

      const device = db
        .prepare(`SELECT id FROM devices WHERE user_id = ? AND status = 'ACTIVE' ORDER BY bound_at DESC LIMIT 1`)
        .get(user.id) as { id: string } | undefined;

      const token = signBearerToken({
        sub: user.id,
        role: user.role,
        deviceId: device?.id ?? null,
      });

      return jsonOk({
        token,
        userId: user.id,
        role: user.role,
        fullName: user.full_name,
        handle: user.handle,
        deviceId: device?.id ?? null,
      });
    }

    const handle = String(body.handle ?? '').toLowerCase().trim();
    const password = String(body.password ?? '');
    if (!handle || !password) {
      return jsonError('Handle and password are required', 400, 'INVALID_CREDENTIALS');
    }

    const normalized = handle.startsWith('@') ? handle : `@${handle}`;
    const user = db.prepare('SELECT * FROM users WHERE handle = ?').get(normalized) as
      | { id: string; role: 'CONSUMER' | 'OPERATOR' | 'SUPERVISOR'; password_hash: string; full_name: string; handle: string }
      | undefined;

    if (!user || !verifySecret(password, user.password_hash)) {
      return jsonError('Invalid credentials', 401, 'UNAUTHENTICATED');
    }

    const device = db
      .prepare(`SELECT id FROM devices WHERE user_id = ? AND status = 'ACTIVE' ORDER BY bound_at DESC LIMIT 1`)
      .get(user.id) as { id: string } | undefined;

    const token = signBearerToken({
      sub: user.id,
      role: user.role,
      deviceId: device?.id ?? null,
    });

    appendAuditLog(db, {
      actorId: user.id,
      actorRole: user.role,
      action: 'SESSION_AUTHENTICATED',
      targetType: 'USER',
      targetId: user.id,
      reason: 'Authenticated via password verification.',
      metadata: { deviceId: device?.id ?? null },
    });

    return jsonOk({
      token,
      userId: user.id,
      role: user.role,
      fullName: user.full_name,
      handle: user.handle,
      deviceId: device?.id ?? null,
    });
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Login failed', 400, 'AUTH_ERROR');
  }
}
