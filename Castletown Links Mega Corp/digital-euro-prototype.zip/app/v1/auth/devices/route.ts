import { NextRequest } from 'next/server';
import { getDevicesForUser, manageConsumerDevice } from '@/lib/core/admin';
import { enforceRateLimit, jsonError, jsonOk, requireAuth } from '@/lib/core/http';

export async function GET(req: NextRequest) {
  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;
  return jsonOk({ devices: getDevicesForUser(auth.claims.sub) });
}

export async function POST(req: NextRequest) {
  const limited = enforceRateLimit(req, 'devices');
  if (limited) return limited;

  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  try {
    const body = await req.json();
    const res = manageConsumerDevice({
      userId: auth.claims.sub,
      action: body.action,
      deviceId: body.deviceId ? String(body.deviceId) : undefined,
      deviceName: body.deviceName ? String(body.deviceName) : undefined,
      recoveryPhrase: body.recoveryPhrase ? String(body.recoveryPhrase) : undefined,
    });
    return jsonOk(res);
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Device action failed', 400, 'DEVICE_ERROR');
  }
}
