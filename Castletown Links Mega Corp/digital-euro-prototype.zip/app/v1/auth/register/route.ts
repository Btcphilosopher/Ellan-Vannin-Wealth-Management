import { NextRequest } from 'next/server';
import { registerConsumerAccount } from '@/lib/core/auth';
import { enforceRateLimit, jsonError, jsonOk } from '@/lib/core/http';

export async function POST(req: NextRequest) {
  const limited = enforceRateLimit(req, 'auth_register');
  if (limited) return limited;

  try {
    const body = await req.json();
    const res = registerConsumerAccount({
      handle: String(body.handle ?? ''),
      fullName: String(body.fullName ?? ''),
      syntheticNationalId: String(body.syntheticNationalId ?? ''),
      countryCode: String(body.countryCode ?? 'DE'),
      linkedBankName: String(body.linkedBankName ?? 'RheinMain Demo Bank AG'),
      linkedBankIban: String(body.linkedBankIban ?? 'DE89370400440532013000'),
      password: String(body.password ?? ''),
      deviceName: String(body.deviceName ?? 'Web Prototype Device'),
      platform: body.platform === 'ANDROID_COMPOSE' ? 'ANDROID_COMPOSE' : 'WEB_PASSKEY_DEMO',
    });
    return jsonOk(res, 201);
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Registration failed', 400, 'REGISTRATION_ERROR');
  }
}
