import { NextRequest } from 'next/server';
import { processProviderEvent } from '@/lib/core/funding';
import { jsonError, jsonOk } from '@/lib/core/http';

export async function POST(
  req: NextRequest,
  context: { params: Promise<{ provider: string }> }
) {
  try {
    const { provider } = await context.params;
    const rawBody = await req.text();
    const signature = req.headers.get('x-provider-signature');

    const result = processProviderEvent({
      provider,
      rawBody,
      signatureHeader: signature,
    });

    return jsonOk(result);
  } catch (err) {
    const msg = err instanceof Error ? err.message : 'Provider event error';
    const status = msg.includes('signature') ? 401 : 400;
    return jsonError(msg, status, 'PROVIDER_EVENT_ERROR');
  }
}
