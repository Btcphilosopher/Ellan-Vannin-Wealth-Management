import crypto from 'node:crypto';
import { NextRequest } from 'next/server';
import { buildSignedProviderEvent, processProviderEvent } from '@/lib/core/funding';
import { jsonError, jsonOk, requireAuth } from '@/lib/core/http';

/**
 * Simulates the external commercial-bank adapter signing and dispatching a settlement
 * or decline event for a pending funding or redemption request.
 * The client never holds the HMAC webhook secret.
 */
export async function POST(req: NextRequest) {
  const auth = requireAuth(req);
  if ('response' in auth) return auth.response;

  try {
    const body = await req.json();
    const provider = String(body.provider ?? 'rheinmain_demo_bank');
    const requestKind = body.requestKind === 'REDEMPTION' ? 'REDEMPTION' : 'FUNDING';
    const requestId = String(body.requestId ?? '');
    const outcome = body.outcome === 'FAILED' ? 'FAILED' : 'SETTLED';
    const bankMessage = String(
      body.bankMessage ??
        (outcome === 'SETTLED'
          ? 'Simulated SEPA Instant bank transfer settled'
          : 'Simulated bank decline: insufficient bank source balance')
    );

    const signed = buildSignedProviderEvent({
      externalEventId: `sim_evt_${crypto.randomUUID().slice(0, 10)}`,
      requestKind,
      requestId,
      outcome,
      bankMessage,
    });

    const result = processProviderEvent({
      provider,
      rawBody: signed.bodyJson,
      signatureHeader: signed.signature,
    });

    return jsonOk(result);
  } catch (err) {
    return jsonError(err instanceof Error ? err.message : 'Bank adapter simulation failed', 400, 'ADAPTER_ERROR');
  }
}
