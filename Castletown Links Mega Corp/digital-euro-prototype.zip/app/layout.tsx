import type { Metadata } from 'next';
import { Plus_Jakarta_Sans, DM_Sans, JetBrains_Mono } from 'next/font/google';
import './globals.css';

const jakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['500', '600', '700'],
  variable: '--font-jakarta',
});

const dmSans = DM_Sans({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-dm-sans',
});

const jetbrainsMono = JetBrains_Mono({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-jetbrains-mono',
});

export const metadata: Metadata = {
  title: 'Digital Euro Prototype · Simulated Retail Payments & Ledger',
  description:
    'Independent digital-euro research prototype comprising a consumer wallet, merchant checkout, append-only double-entry ledger, and administrative console using simulated funds.',
  openGraph: {
    title: 'Digital Euro Prototype · Simulated Retail Payments & Ledger',
    description:
      'Independent digital-euro research prototype comprising a consumer wallet, merchant checkout, append-only double-entry ledger, and administrative console using simulated funds.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Digital Euro Prototype · Simulated Retail Payments & Ledger',
    description:
      'Independent digital-euro research prototype using synthetic identities and simulated funds.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`${jakarta.variable} ${dmSans.variable} ${jetbrainsMono.variable}`}
    >
      <body className="min-h-screen bg-[#FAF8F3] text-[#0B1D3A] antialiased" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
