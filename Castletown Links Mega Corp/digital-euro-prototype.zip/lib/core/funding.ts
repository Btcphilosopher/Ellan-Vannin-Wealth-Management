import crypto from 'node:crypto';
import { appendAuditLog, signProviderPayload, verifyProviderSignature } from './auth';
import { getDb } from './db';
import { getConsumerLedgerAccountIds, postJournalEntryInTx } from './ledger';
import type { FundingRequestRecord, RedemptionRequestRecord } from './types';

function mapFundingRow(r: Record<string, unknown>): FundingRequestRecord {
  return {
    id: String(r.id),
    idempotencyKey: String(r.idempotency_key),
    userId: String(r.user_id),
    provider: String(r.provider),
    amountCents: Number(r.amount_cents),
    state: r.state as FundingRequestRecord['state'],
    providerReference: r.provider_reference ? String(r.provider_reference) : null,
    providerMessage: r.provider_message ? String(r.provider_message) : null,
    journalTxId: r.journal_tx_id ? String(r.journal_tx_id) : null,
    createdAt: String(r.created_at),
    updatedAt: String(r.updated_at),
  };
}

function mapRedemptionRow(r: Record<string, unknown>): RedemptionRequestRecord {
  return {
    id: String(r.id),
    idempotencyKey: String(r.idempotency_key),
    userId: String(r.user_id),
    provider: String(r.provider),
    amountCents: Number(r.amount_cents),
    state: r.state as RedemptionRequestRecord['state'],
    providerReference: r.provider_reference ? String(r.provider_reference) : null,
    providerMessage: r.provider_message ? String(r.provider_message) : null,
    journalTxId: r.journal_tx_id ? String(r.journal_tx_id) : null,
    createdAt: String(r.created_at),
    updatedAt: String(r.updated_at),
  };
}

/**
 * Step 1 of Funding: Client submits a funding request.
 * CRITICAL RULE: Never create spendable balance merely because a client submitted a funding request!
 * Balance is only created once a signed external bank provider event confirms settlement.
 */
export function createFundingRequest(input: {
  idempotencyKey: string;
  userId: string;
  amountCents: number;
  provider?: string;
}): FundingRequestRecord {
  const db = getDb();
  if (!input.idempotencyKey || input.idempotencyKey.trim().length < 4) {
    throw new Error('idempotencyKey is required');
  }
  if (!Number.isSafeInteger(input.amountCents) || input.amountCents <= 0) {
    throw new Error('Funding amount must be a positive integer in euro cents');
  }

  const tx = db.transaction(() => {
    const existing = db
      .prepare('SELECT * FROM funding_requests WHERE idempotency_key = ?')
      .get(input.idempotencyKey.trim()) as Record<string, unknown> | undefined;
    if (existing) {
      return mapFundingRow(existing);
    }

    const wallet = db
      .prepare(`SELECT status, holding_limit_cents FROM wallets WHERE owner_type = 'CONSUMER' AND owner_id = ?`)
      .get(input.userId) as { status: string; holding_limit_cents: number } | undefined;
    if (!wallet) throw new Error('Consumer wallet not found');
    if (wallet.status !== 'ACTIVE') {
      throw new Error(`Cannot fund wallet with status ${wallet.status}`);
    }

    const id = `fund_${crypto.randomUUID().slice(0, 10)}`;
    const now = new Date().toISOString();
    const provider = input.provider?.trim() || 'rheinmain_demo_bank';

    db.prepare(`
      INSERT INTO funding_requests (
        id, idempotency_key, user_id, provider, amount_cents, state,
        provider_reference, provider_message, journal_tx_id, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, 'PROVIDER_PENDING', ?, 'Awaiting signed confirmation from fictional commercial bank adapter', NULL, ?, ?)
    `).run(
      id,
      input.idempotencyKey.trim(),
      input.userId,
      provider,
      input.amountCents,
      `RMB-${id.slice(5).toUpperCase()}`,
      now,
      now
    );

    appendAuditLog(db, {
      actorId: input.userId,
      actorRole: 'CONSUMER',
      action: 'FUNDING_REQUEST_CREATED',
      targetType: 'FUNDING_REQUEST',
      targetId: id,
      reason: 'Consumer requested simulated commercial-bank transfer; zero wallet credit issued pending provider event.',
      metadata: { amountCents: input.amountCents, provider },
    });

    const row = db.prepare('SELECT * FROM funding_requests WHERE id = ?').get(id) as Record<string, unknown>;
    return mapFundingRow(row);
  });

  return tx.immediate();
}

/**
 * Step 1 of Redemption: Consumer requests redemption back to commercial bank.
 * Atomically debits CONSUMER_AVAILABLE -> BANK_CLEARING_OUT (`LEDGER_DEBITED`),
 * awaiting external bank settlement event (`SETTLED` or compensating reversal on `FAILED`).
 */
export function createRedemptionRequest(input: {
  idempotencyKey: string;
  userId: string;
  amountCents: number;
  provider?: string;
}): RedemptionRequestRecord {
  const db = getDb();
  if (!input.idempotencyKey || input.idempotencyKey.trim().length < 4) {
    throw new Error('idempotencyKey is required');
  }
  if (!Number.isSafeInteger(input.amountCents) || input.amountCents <= 0) {
    throw new Error('Redemption amount must be a positive integer in euro cents');
  }

  const tx = db.transaction(() => {
    const existing = db
      .prepare('SELECT * FROM redemption_requests WHERE idempotency_key = ?')
      .get(input.idempotencyKey.trim()) as Record<string, unknown> | undefined;
    if (existing) {
      return mapRedemptionRow(existing);
    }

    const wallet = db
      .prepare(`SELECT status FROM wallets WHERE owner_type = 'CONSUMER' AND owner_id = ?`)
      .get(input.userId) as { status: string } | undefined;
    if (!wallet) throw new Error('Consumer wallet not found');
    if (wallet.status !== 'ACTIVE') {
      throw new Error(`Cannot redeem from wallet with status ${wallet.status}`);
    }

    const consumerAcc = getConsumerLedgerAccountIds(db, input.userId);
    const id = `red_${crypto.randomUUID().slice(0, 10)}`;
    const now = new Date().toISOString();
    const provider = input.provider?.trim() || 'rheinmain_demo_bank';

    const journalTx = postJournalEntryInTx(db, {
      idempotencyKey: `redemption:debit:${id}`,
      txType: 'REDEMPTION_LEDGER_DEBIT',
      referenceType: 'REDEMPTION_REQUEST',
      referenceId: id,
      description: `Debit consumer wallet to clearing account for bank redemption ${id}`,
      postings: [
        { accountId: consumerAcc.availableAccountId, debitCents: input.amountCents, creditCents: 0 },
        { accountId: 'acc_bank_clearing_out', debitCents: 0, creditCents: input.amountCents },
      ],
    });

    db.prepare(`
      INSERT INTO redemption_requests (
        id, idempotency_key, user_id, provider, amount_cents, state,
        provider_reference, provider_message, journal_tx_id, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, 'LEDGER_DEBITED', ?, 'Ledger debited to BANK_CLEARING_OUT; awaiting bank payout settlement', ?, ?, ?)
    `).run(
      id,
      input.idempotencyKey.trim(),
      input.userId,
      provider,
      input.amountCents,
      `RMB-OUT-${id.slice(4).toUpperCase()}`,
      journalTx.id,
      now,
      now
    );

    appendAuditLog(db, {
      actorId: input.userId,
      actorRole: 'CONSUMER',
      action: 'REDEMPTION_LEDGER_DEBITED',
      targetType: 'REDEMPTION_REQUEST',
      targetId: id,
      reason: 'Wallet debited to clearing account prior to simulated commercial bank payout.',
      metadata: { amountCents: input.amountCents, journalTxId: journalTx.id },
    });

    const row = db.prepare('SELECT * FROM redemption_requests WHERE id = ?').get(id) as Record<string, unknown>;
    return mapRedemptionRow(row);
  });

  return tx.immediate();
}

export interface ProviderEventPayload {
  externalEventId: string;
  requestKind: 'FUNDING' | 'REDEMPTION';
  requestId: string;
  outcome: 'SETTLED' | 'FAILED';
  bankMessage: string;
}

/**
 * Simulates the external bank adapter signing and dispatching a webhook event,
 * or verifies an external caller's HMAC signature on POST /v1/providers/{provider}/events.
 */
export function buildSignedProviderEvent(payload: ProviderEventPayload): {
  bodyJson: string;
  signature: string;
} {
  const bodyJson = JSON.stringify(payload);
  const signature = signProviderPayload(bodyJson);
  return { bodyJson, signature };
}

export function processProviderEvent(input: {
  provider: string;
  rawBody: string;
  signatureHeader: string | null;
}): {
  eventId: string;
  funding?: FundingRequestRecord;
  redemption?: RedemptionRequestRecord;
  duplicate: boolean;
} {
  if (!verifyProviderSignature(input.rawBody, input.signatureHeader)) {
    throw new Error('Invalid commercial-bank provider HMAC signature');
  }

  const parsed = JSON.parse(input.rawBody) as ProviderEventPayload;
  if (!parsed.externalEventId || !parsed.requestId || !parsed.requestKind || !parsed.outcome) {
    throw new Error('Malformed provider event payload');
  }

  const db = getDb();

  const tx = db.transaction(() => {
    const existingEvent = db
      .prepare('SELECT * FROM provider_events WHERE external_event_id = ?')
      .get(parsed.externalEventId) as { id: string } | undefined;

    if (existingEvent) {
      if (parsed.requestKind === 'FUNDING') {
        const f = db.prepare('SELECT * FROM funding_requests WHERE id = ?').get(parsed.requestId) as Record<string, unknown>;
        return { eventId: existingEvent.id, funding: mapFundingRow(f), duplicate: true };
      }
      const r = db.prepare('SELECT * FROM redemption_requests WHERE id = ?').get(parsed.requestId) as Record<string, unknown>;
      return { eventId: existingEvent.id, redemption: mapRedemptionRow(r), duplicate: true };
    }

    const eventId = `pevt_${crypto.randomUUID().slice(0, 10)}`;
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO provider_events (
        id, provider, external_event_id, request_kind, request_id, outcome, signature_verified, payload_redacted, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)
    `).run(
      eventId,
      input.provider,
      parsed.externalEventId,
      parsed.requestKind,
      parsed.requestId,
      parsed.outcome,
      JSON.stringify({ requestKind: parsed.requestKind, requestId: parsed.requestId, outcome: parsed.outcome }),
      now
    );

    if (parsed.requestKind === 'FUNDING') {
      const f = db.prepare('SELECT * FROM funding_requests WHERE id = ?').get(parsed.requestId) as
        | Record<string, unknown>
        | undefined;
      if (!f) throw new Error('Funding request not found');

      if (f.state === 'SETTLED' || f.state === 'FAILED') {
        return { eventId, funding: mapFundingRow(f), duplicate: true };
      }

      if (parsed.outcome === 'FAILED') {
        db.prepare(
          `UPDATE funding_requests SET state = 'FAILED', provider_message = ?, updated_at = ? WHERE id = ?`
        ).run(parsed.bankMessage || 'Bank transfer declined by RheinMain Demo Bank', now, parsed.requestId);

        appendAuditLog(db, {
          actorId: `provider:${input.provider}`,
          actorRole: 'PROVIDER_ADAPTER',
          action: 'FUNDING_FAILED_NO_CREDIT',
          targetType: 'FUNDING_REQUEST',
          targetId: parsed.requestId,
          reason: parsed.bankMessage || 'External bank transfer declined; zero wallet balance created.',
          metadata: { amountCents: Number(f.amount_cents) },
        });

        const updated = db.prepare('SELECT * FROM funding_requests WHERE id = ?').get(parsed.requestId) as Record<string, unknown>;
        return { eventId, funding: mapFundingRow(updated), duplicate: false };
      }

      // Check consumer holding limit before crediting
      const userId = String(f.user_id);
      const amountCents = Number(f.amount_cents);
      const wallet = db
        .prepare(`SELECT holding_limit_cents, waterfall_enabled FROM wallets WHERE owner_type = 'CONSUMER' AND owner_id = ?`)
        .get(userId) as { holding_limit_cents: number; waterfall_enabled: number };
      const consumerAcc = getConsumerLedgerAccountIds(db, userId);
      const availRow = db
        .prepare('SELECT balance_cents FROM ledger_accounts WHERE id = ?')
        .get(consumerAcc.availableAccountId) as { balance_cents: number };

      if (availRow.balance_cents + amountCents > wallet.holding_limit_cents) {
        db.prepare(
          `UPDATE funding_requests SET state = 'FAILED', provider_message = ?, updated_at = ? WHERE id = ?`
        ).run(
          `Funding rejected: exceeds simulated holding limit (${wallet.holding_limit_cents}¢)`,
          now,
          parsed.requestId
        );
        const updated = db.prepare('SELECT * FROM funding_requests WHERE id = ?').get(parsed.requestId) as Record<string, unknown>;
        return { eventId, funding: mapFundingRow(updated), duplicate: false };
      }

      const journalTx = postJournalEntryInTx(db, {
        idempotencyKey: `funding:settle:${parsed.requestId}`,
        txType: 'BANK_FUNDING_SETTLED',
        referenceType: 'FUNDING_REQUEST',
        referenceId: parsed.requestId,
        description: `Simulated commercial bank funding settled (${input.provider})`,
        postings: [
          { accountId: 'acc_bank_clearing_in', debitCents: amountCents, creditCents: 0 },
          { accountId: consumerAcc.availableAccountId, debitCents: 0, creditCents: amountCents },
        ],
      });

      db.prepare(
        `UPDATE funding_requests SET state = 'SETTLED', provider_message = ?, journal_tx_id = ?, updated_at = ? WHERE id = ?`
      ).run(parsed.bankMessage || 'Settled via RheinMain Demo Bank clearing', journalTx.id, now, parsed.requestId);

      appendAuditLog(db, {
        actorId: `provider:${input.provider}`,
        actorRole: 'PROVIDER_ADAPTER',
        action: 'FUNDING_SETTLED_LEDGER_CREDITED',
        targetType: 'FUNDING_REQUEST',
        targetId: parsed.requestId,
        reason: 'Signed bank settlement confirmed; consumer available account credited.',
        metadata: { amountCents, journalTxId: journalTx.id },
      });

      const updated = db.prepare('SELECT * FROM funding_requests WHERE id = ?').get(parsed.requestId) as Record<string, unknown>;
      return { eventId, funding: mapFundingRow(updated), duplicate: false };
    }

    // REDEMPTION outcome handling
    const r = db.prepare('SELECT * FROM redemption_requests WHERE id = ?').get(parsed.requestId) as
      | Record<string, unknown>
      | undefined;
    if (!r) throw new Error('Redemption request not found');
    if (r.state === 'SETTLED' || r.state === 'FAILED') {
      return { eventId, redemption: mapRedemptionRow(r), duplicate: true };
    }

    if (parsed.outcome === 'SETTLED') {
      db.prepare(
        `UPDATE redemption_requests SET state = 'SETTLED', provider_message = ?, updated_at = ? WHERE id = ?`
      ).run(parsed.bankMessage || 'Commercial bank account credited', now, parsed.requestId);

      appendAuditLog(db, {
        actorId: `provider:${input.provider}`,
        actorRole: 'PROVIDER_ADAPTER',
        action: 'REDEMPTION_SETTLED',
        targetType: 'REDEMPTION_REQUEST',
        targetId: parsed.requestId,
        reason: 'External commercial bank confirmed receipt of redeemed funds.',
        metadata: { amountCents: Number(r.amount_cents) },
      });
    } else {
      // Bank payout failed -> linked compensating reversal back to consumer available balance
      const consumerAcc = getConsumerLedgerAccountIds(db, String(r.user_id));
      postJournalEntryInTx(db, {
        idempotencyKey: `redemption:reversal:${parsed.requestId}`,
        txType: 'REDEMPTION_REVERSAL',
        referenceType: 'REDEMPTION_REQUEST',
        referenceId: parsed.requestId,
        parentTxId: r.journal_tx_id ? String(r.journal_tx_id) : null,
        description: `Compensating reversal for failed commercial bank payout ${parsed.requestId}`,
        postings: [
          { accountId: 'acc_bank_clearing_out', debitCents: Number(r.amount_cents), creditCents: 0 },
          { accountId: consumerAcc.availableAccountId, debitCents: 0, creditCents: Number(r.amount_cents) },
        ],
      });

      db.prepare(
        `UPDATE redemption_requests SET state = 'FAILED', provider_message = ?, updated_at = ? WHERE id = ?`
      ).run(parsed.bankMessage || 'Bank payout rejected; funds returned via compensating entry', now, parsed.requestId);
    }

    const updated = db.prepare('SELECT * FROM redemption_requests WHERE id = ?').get(parsed.requestId) as Record<string, unknown>;
    return { eventId, redemption: mapRedemptionRow(updated), duplicate: false };
  });

  return tx.immediate();
}
