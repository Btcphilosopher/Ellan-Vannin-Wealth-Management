import { getConsumerProfileById, getMerchantProfiles } from './admin';
import { getDb, resetDatabaseForDemo } from './db';
import { buildSignedProviderEvent, createFundingRequest, processProviderEvent } from './funding';
import { runLedgerReconciliation } from './ledger';
import {
  authoriseAndPostPayment,
  createPaymentIntent,
  createPaymentRequest,
  getPaymentById,
  issueMerchantRefund,
} from './payments';

export interface DemoStepResult {
  stepNumber: number;
  title: string;
  passed: boolean;
  summary: string;
  details: Record<string, unknown>;
}

/**
 * Executes the exact 10-step verification demonstration end-to-end against the
 * real SQLite ACID ledger and payment state machine.
 */
export async function runFullTenStepDemonstration(): Promise<{
  allPassed: boolean;
  steps: DemoStepResult[];
  finalBalances: {
    claraAvailableCents: number;
    lucasAvailableCents: number;
    cafeEuropaSettlementCents: number;
  };
}> {
  resetDatabaseForDemo();
  const db = getDb();
  const steps: DemoStepResult[] = [];

  // 1. Simulated funding of €100.00 (10000 cents)
  const fundReq = createFundingRequest({
    idempotencyKey: 'demo-step1-fund-100',
    userId: 'usr_clara',
    amountCents: 10000,
    provider: 'rheinmain_demo_bank',
  });
  const preCreditBal = getConsumerProfileById('usr_clara')!.availableCents;
  const fundEvent = buildSignedProviderEvent({
    externalEventId: 'evt-demo-step1-settled',
    requestKind: 'FUNDING',
    requestId: fundReq.id,
    outcome: 'SETTLED',
    bankMessage: 'SEPA Instant Demo Settlement Confirmed',
  });
  const settledFund = processProviderEvent({
    provider: 'rheinmain_demo_bank',
    rawBody: fundEvent.bodyJson,
    signatureHeader: fundEvent.signature,
  });
  const postFundBal = getConsumerProfileById('usr_clara')!.availableCents;
  steps.push({
    stepNumber: 1,
    title: 'Simulated funding of €100.00',
    passed: preCreditBal === 0 && settledFund.funding?.state === 'SETTLED' && postFundBal === 10000,
    summary: `Before bank event: €0.00 · After signed RheinMain Bank settlement: €${(postFundBal / 100).toFixed(2)}`,
    details: { fundingRequestId: fundReq.id, journalTxId: settledFund.funding?.journalTxId },
  });

  // 2. €12.50 (1250 cents) merchant payment (Café Europa Berlin)
  const posReq = createPaymentRequest({
    kind: 'MERCHANT_POS',
    merchantId: 'mrc_cafe_europa',
    amountCents: 1250,
    description: '2x Espresso & Croissant (Café Europa Berlin)',
    expiresInSeconds: 300,
  });
  const merchIntent = createPaymentIntent({
    idempotencyKey: 'demo-step2-merch-1250',
    payerUserId: 'usr_clara',
    payeeKind: 'MERCHANT',
    payeeId: 'mrc_cafe_europa',
    amountCents: 1250,
    paymentRequestId: posReq.id,
  });
  const merchAuth = authoriseAndPostPayment({
    paymentId: merchIntent.id,
    actorUserId: 'usr_clara',
    authoriseIdempotencyKey: 'demo-step2-auth',
  });
  const afterMerchBal = getConsumerProfileById('usr_clara')!.availableCents;
  steps.push({
    stepNumber: 2,
    title: '€12.50 merchant payment',
    passed: merchAuth.payment.state === 'POSTED' && afterMerchBal === 8750,
    summary: `Paid Café Europa Berlin €12.50 via QR request ${posReq.id}. Clara balance: €${(afterMerchBal / 100).toFixed(2)}`,
    details: { paymentId: merchIntent.id, requestId: posReq.id, journalTxId: merchAuth.payment.journalTxId },
  });

  // 3. €20.00 (2000 cents) person-to-person payment (Clara -> Lucas)
  const p2pIntent = createPaymentIntent({
    idempotencyKey: 'demo-step3-p2p-2000',
    payerUserId: 'usr_clara',
    payeeKind: 'CONSUMER',
    payeeId: 'usr_lucas',
    amountCents: 2000,
  });
  const p2pAuth = authoriseAndPostPayment({
    paymentId: p2pIntent.id,
    actorUserId: 'usr_clara',
    authoriseIdempotencyKey: 'demo-step3-auth',
  });
  const claraAfterP2P = getConsumerProfileById('usr_clara')!.availableCents;
  const lucasAfterP2P = getConsumerProfileById('usr_lucas')!.availableCents;
  steps.push({
    stepNumber: 3,
    title: '€20.00 person-to-person payment',
    passed: p2pAuth.payment.state === 'POSTED' && claraAfterP2P === 6750 && lucasAfterP2P === 2000,
    summary: `Transferred €20.00 to Lucas Moreau. Clara: €${(claraAfterP2P / 100).toFixed(2)} · Lucas: €${(lucasAfterP2P / 100).toFixed(2)}`,
    details: { paymentId: p2pIntent.id, journalTxId: p2pAuth.payment.journalTxId },
  });

  // 4. €2.50 (250 cents) partial merchant refund
  const refund = issueMerchantRefund({
    idempotencyKey: 'demo-step4-refund-250',
    originalPaymentId: merchIntent.id,
    merchantId: 'mrc_cafe_europa',
    amountCents: 250,
    reason: 'Croissant unavailable; partial refund issued',
    actorId: 'mrc_cafe_europa',
  });
  const claraAfterRefund = getConsumerProfileById('usr_clara')!.availableCents;
  const cafeAfterRefund = getMerchantProfiles().find((m) => m.id === 'mrc_cafe_europa')!.settlementBalanceCents;
  steps.push({
    stepNumber: 4,
    title: '€2.50 partial merchant refund',
    passed: refund.status === 'POSTED' && claraAfterRefund === 7000 && cafeAfterRefund === 1000,
    summary: `Café Europa refunded €2.50 (linked entry ${refund.journalTxId}). Merchant balance: €${(cafeAfterRefund / 100).toFixed(2)}`,
    details: { refundId: refund.id, journalTxId: refund.journalTxId },
  });

  // 5. Final consumer balance verification: €70.00
  steps.push({
    stepNumber: 5,
    title: 'Final consumer balance of €70.00',
    passed: claraAfterRefund === 7000,
    summary: `Verified integer balance: ${claraAfterRefund}¢ (€${(claraAfterRefund / 100).toFixed(2)})`,
    details: { availableCents: claraAfterRefund, reservedCents: getConsumerProfileById('usr_clara')!.reservedCents },
  });

  // 6. Duplicate payment submission without duplicate debit (Idempotency)
  const dupIntent = createPaymentIntent({
    idempotencyKey: 'demo-step3-p2p-2000', // same idempotency key as step 3
    payerUserId: 'usr_clara',
    payeeKind: 'CONSUMER',
    payeeId: 'usr_lucas',
    amountCents: 2000,
  });
  const dupAuth = authoriseAndPostPayment({
    paymentId: dupIntent.id,
    actorUserId: 'usr_clara',
    authoriseIdempotencyKey: 'demo-step3-auth',
  });
  const balAfterDup = getConsumerProfileById('usr_clara')!.availableCents;
  steps.push({
    stepNumber: 6,
    title: 'Duplicate payment submission without duplicate debit',
    passed: dupIntent.id === p2pIntent.id && dupAuth.payment.state === 'POSTED' && balAfterDup === 7000,
    summary: `Reused idempotency key returned original ${dupIntent.id}; balance remained €70.00.`,
    details: { originalPaymentId: p2pIntent.id, returnedPaymentId: dupIntent.id },
  });

  // 7. Concurrent spending attempts (two simultaneous €50.00 attempts against €70.00 balance; then cancelled/rolled back or tested with separate intents -> wait: if one succeeds we don't want to alter the €70.00 final proof? Let's test concurrency on Lucas or test on a temporary intent and refund/or test with two €75.00 vs two €50.00? Wait: step 5 already verified €70.00, OR we can test concurrent spending on Lucas's €20.00: two concurrent €15.00 attempts -> 1 succeeds (€5.00 left), 1 rejected, or refund back? Even better: test concurrent spending of two €15.00 attempts by Lucas -> exactly 1 succeeds and 1 rejects, keeping Clara at €70.00!)
  // Wait: let's check step 5 order vs step 7: in the prompt, step 5 is "A final consumer balance of €70.00", then 6-10 test duplicate, concurrent, lost response, failed funding, reconciliation.
  // If we test concurrent spending on Lucas (€20.00 balance, two concurrent €15.00 attempts to Café Europa -> 1 POSTED, 1 REJECTED, Lucas never goes negative, Clara stays €70.00!), AND then wait: does step 7 keep Clara at €70.00? YES! And total wallet liabilities stay 7000 + 500 + 2500 = 10000!
  const concA = createPaymentIntent({
    idempotencyKey: 'demo-step7-conc-a',
    payerUserId: 'usr_lucas',
    payeeKind: 'MERCHANT',
    payeeId: 'mrc_cafe_europa',
    amountCents: 1500,
  });
  const concB = createPaymentIntent({
    idempotencyKey: 'demo-step7-conc-b',
    payerUserId: 'usr_lucas',
    payeeKind: 'MERCHANT',
    payeeId: 'mrc_cafe_europa',
    amountCents: 1500,
  });
  const [resA, resB] = await Promise.all([
    Promise.resolve().then(() =>
      authoriseAndPostPayment({
        paymentId: concA.id,
        actorUserId: 'usr_lucas',
        authoriseIdempotencyKey: 'auth-conc-a',
      })
    ),
    Promise.resolve().then(() =>
      authoriseAndPostPayment({
        paymentId: concB.id,
        actorUserId: 'usr_lucas',
        authoriseIdempotencyKey: 'auth-conc-b',
      })
    ),
  ]);
  const states = [resA.payment.state, resB.payment.state].sort();
  const lucasAfterConc = getConsumerProfileById('usr_lucas')!.availableCents;
  steps.push({
    stepNumber: 7,
    title: 'Concurrent spending attempts (atomic lock)',
    passed: states[0] === 'POSTED' && states[1] === 'REJECTED' && lucasAfterConc === 500,
    summary: `Two simultaneous €15.00 spends against €20.00 balance -> 1 POSTED, 1 REJECTED. Remaining: €5.00 (no negative balance).`,
    details: { attemptA: resA.payment.state, attemptB: resB.payment.state, lucasBalanceCents: lucasAfterConc },
  });

  // 8. Lost payment response followed by status recovery (outcome checking)
  const lostIntent = createPaymentIntent({
    idempotencyKey: 'demo-step8-lost-resp',
    payerUserId: 'usr_lucas',
    payeeKind: 'MERCHANT',
    payeeId: 'mrc_cafe_europa',
    amountCents: 200,
  });
  const lostAuth = authoriseAndPostPayment({
    paymentId: lostIntent.id,
    actorUserId: 'usr_lucas',
    authoriseIdempotencyKey: 'auth-step8-lost',
    simulateLostResponse: true,
  });
  // Client experiences dropped HTTP response, so it queries GET /v1/payments/{payment_id}
  const recovered = getPaymentById(lostIntent.id);
  const lucasAfterLost = getConsumerProfileById('usr_lucas')!.availableCents;
  steps.push({
    stepNumber: 8,
    title: 'Lost payment response followed by status recovery',
    passed:
      lostAuth.simulatedNetworkDrop === true &&
      recovered !== null &&
      recovered.state === 'POSTED' &&
      lucasAfterLost === 300,
    summary: `Simulated response drop after commit; client polled GET /v1/payments/${lostIntent.id} -> recovered POSTED outcome without second payment.`,
    details: { paymentId: lostIntent.id, recoveredState: recovered?.state, journalTxId: recovered?.journalTxId },
  });

  // 9. Failed funding without balance creation
  const failFundReq = createFundingRequest({
    idempotencyKey: 'demo-step9-fail-fund',
    userId: 'usr_clara',
    amountCents: 25000,
    provider: 'rheinmain_demo_bank',
  });
  const failEvent = buildSignedProviderEvent({
    externalEventId: 'evt-demo-step9-failed',
    requestKind: 'FUNDING',
    requestId: failFundReq.id,
    outcome: 'FAILED',
    bankMessage: 'Insufficient funds on commercial bank source account (Simulated)',
  });
  const failedResult = processProviderEvent({
    provider: 'rheinmain_demo_bank',
    rawBody: failEvent.bodyJson,
    signatureHeader: failEvent.signature,
  });
  const claraAfterFailedFund = getConsumerProfileById('usr_clara')!.availableCents;
  steps.push({
    stepNumber: 9,
    title: 'Failed funding without balance creation',
    passed:
      failedResult.funding?.state === 'FAILED' &&
      failedResult.funding?.journalTxId === null &&
      claraAfterFailedFund === 7000,
    summary: `€250.00 bank transfer declined by provider; funding state FAILED, zero ledger credit, Clara balance unchanged at €70.00.`,
    details: { fundingRequestId: failFundReq.id, state: failedResult.funding?.state },
  });

  // 10. Ledger reconciliation
  const rec = runLedgerReconciliation(
    db,
    'staff_supervisor',
    'End-to-end 10-step verification reconciliation'
  );
  const finalCafe = getMerchantProfiles().find((m) => m.id === 'mrc_cafe_europa')!.settlementBalanceCents;
  steps.push({
    stepNumber: 10,
    title: 'Ledger reconciliation',
    passed:
      rec.status === 'BALANCED' &&
      rec.discrepancyCents === 0 &&
      rec.totalDebitsCents === rec.totalCreditsCents &&
      rec.totalClearingAssetCents === rec.totalWalletLiabilityCents,
    summary: `BALANCED · Debits ${rec.totalDebitsCents}¢ == Credits ${rec.totalCreditsCents}¢ · Clearing Assets ${rec.totalClearingAssetCents}¢ == Wallet Liabilities ${rec.totalWalletLiabilityCents}¢`,
    details: { reconciliationId: rec.id, discrepancyCents: rec.discrepancyCents },
  });

  return {
    allPassed: steps.every((s) => s.passed),
    steps,
    finalBalances: {
      claraAvailableCents: claraAfterFailedFund,
      lucasAvailableCents: lucasAfterLost,
      cafeEuropaSettlementCents: finalCafe,
    },
  };
}
