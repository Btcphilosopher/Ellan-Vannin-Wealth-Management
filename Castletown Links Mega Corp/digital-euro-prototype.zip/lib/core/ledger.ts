import crypto from 'node:crypto';
import type Database from 'better-sqlite3';
import { appendAuditLog } from './auth';
import type {
  JournalPostingView,
  JournalTransactionView,
  LedgerAccountSummary,
  ReconciliationRecord,
} from './types';

export interface PostingSpec {
  accountId: string;
  debitCents: number;
  creditCents: number;
}

interface RawLedgerAccount {
  id: string;
  code: string;
  owner_type: 'CONSUMER' | 'MERCHANT' | 'SYSTEM';
  owner_id: string | null;
  owner_label: string;
  account_type: string;
  normal_balance: 'LIABILITY' | 'ASSET';
  allow_negative: number;
  balance_cents: number;
}

/**
 * Executes an atomic, balanced double-entry journal transaction inside an existing
 * SQLite IMMEDIATE transaction (or starts one if needed).
 *
 * Accounting convention:
 * - Every journal transaction MUST satisfy SUM(debitCents) === SUM(creditCents) > 0.
 * - LIABILITY accounts (consumer available, consumer reserved, merchant settlement):
 *   balance_cents += creditCents - debitCents.
 * - ASSET accounts (bank clearing, issuer reserve):
 *   balance_cents += debitCents - creditCents.
 * - Accounts with allow_negative === 0 MUST NEVER drop below 0 cents.
 */
export function postJournalEntryInTx(
  db: Database.Database,
  params: {
    idempotencyKey: string;
    txType: string;
    referenceType: string;
    referenceId: string;
    parentTxId?: string | null;
    description: string;
    postings: PostingSpec[];
  }
): JournalTransactionView {
  const existing = db
    .prepare('SELECT id FROM journal_transactions WHERE idempotency_key = ?')
    .get(params.idempotencyKey) as { id: string } | undefined;

  if (existing) {
    return getJournalTransactionById(db, existing.id)!;
  }

  if (params.postings.length < 2) {
    throw new Error('A double-entry journal transaction requires at least two postings.');
  }

  let totalDebit = 0;
  let totalCredit = 0;
  for (const p of params.postings) {
    if (!Number.isSafeInteger(p.debitCents) || !Number.isSafeInteger(p.creditCents)) {
      throw new Error('Posting amounts must be safe integer euro cents.');
    }
    if (p.debitCents < 0 || p.creditCents < 0) {
      throw new Error('Posting amounts cannot be negative.');
    }
    if ((p.debitCents > 0 && p.creditCents > 0) || (p.debitCents === 0 && p.creditCents === 0)) {
      throw new Error('Each posting must specify strictly either debitCents > 0 or creditCents > 0.');
    }
    totalDebit += p.debitCents;
    totalCredit += p.creditCents;
  }

  if (totalDebit <= 0 || totalDebit !== totalCredit) {
    throw new Error(
      `Unbalanced journal transaction rejected: debits=${totalDebit}, credits=${totalCredit}`
    );
  }

  const now = new Date().toISOString();
  const journalTxId = `jtx_${crypto.randomUUID().slice(0, 12)}`;

  db.prepare(`
    INSERT INTO journal_transactions (
      id, idempotency_key, tx_type, reference_type, reference_id, parent_tx_id, description, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    journalTxId,
    params.idempotencyKey,
    params.txType,
    params.referenceType,
    params.referenceId,
    params.parentTxId ?? null,
    params.description,
    now
  );

  const selectAccount = db.prepare('SELECT * FROM ledger_accounts WHERE id = ?');
  const updateBalance = db.prepare('UPDATE ledger_accounts SET balance_cents = ? WHERE id = ?');
  const insertPosting = db.prepare(`
    INSERT INTO journal_postings (
      id, journal_tx_id, account_id, debit_cents, credit_cents, created_at
    ) VALUES (?, ?, ?, ?, ?, ?)
  `);

  for (const p of params.postings) {
    const account = selectAccount.get(p.accountId) as RawLedgerAccount | undefined;
    if (!account) {
      throw new Error(`Ledger account not found: ${p.accountId}`);
    }

    const delta =
      account.normal_balance === 'LIABILITY'
        ? p.creditCents - p.debitCents
        : p.debitCents - p.creditCents;

    const nextBalance = account.balance_cents + delta;
    if (account.allow_negative === 0 && nextBalance < 0) {
      throw new Error(
        `Insufficient funds on ${account.owner_label}: available ${account.balance_cents}¢, attempted change ${delta}¢`
      );
    }

    updateBalance.run(nextBalance, account.id);
    insertPosting.run(
      `jps_${crypto.randomUUID().slice(0, 12)}`,
      journalTxId,
      account.id,
      p.debitCents,
      p.creditCents,
      now
    );
  }

  return getJournalTransactionById(db, journalTxId)!;
}

export function getJournalTransactionById(
  db: Database.Database,
  txId: string
): JournalTransactionView | null {
  const row = db
    .prepare('SELECT * FROM journal_transactions WHERE id = ?')
    .get(txId) as {
    id: string;
    idempotency_key: string;
    tx_type: string;
    reference_type: string;
    reference_id: string;
    parent_tx_id: string | null;
    description: string;
    created_at: string;
  } | undefined;

  if (!row) return null;

  const postingsRows = db
    .prepare(`
      SELECT jp.id, jp.journal_tx_id, jp.account_id, la.code as account_code, la.owner_label as account_label,
             jp.debit_cents, jp.credit_cents
      FROM journal_postings jp
      JOIN ledger_accounts la ON la.id = jp.account_id
      WHERE jp.journal_tx_id = ?
      ORDER BY jp.debit_cents DESC, jp.id ASC
    `)
    .all(txId) as Array<{
    id: string;
    journal_tx_id: string;
    account_id: string;
    account_code: string;
    account_label: string;
    debit_cents: number;
    credit_cents: number;
  }>;

  const postings: JournalPostingView[] = postingsRows.map((p) => ({
    id: p.id,
    journalTxId: p.journal_tx_id,
    accountId: p.account_id,
    accountCode: p.account_code,
    accountLabel: p.account_label,
    debitCents: p.debit_cents,
    creditCents: p.credit_cents,
  }));

  const totalDebitCents = postings.reduce((acc, p) => acc + p.debitCents, 0);
  const totalCreditCents = postings.reduce((acc, p) => acc + p.creditCents, 0);

  return {
    id: row.id,
    idempotencyKey: row.idempotency_key,
    txType: row.tx_type,
    referenceType: row.reference_type,
    referenceId: row.reference_id,
    parentTxId: row.parent_tx_id,
    description: row.description,
    totalDebitCents,
    totalCreditCents,
    createdAt: row.created_at,
    postings,
  };
}

export function getConsumerLedgerAccountIds(
  db: Database.Database,
  userId: string
): { availableAccountId: string; reservedAccountId: string } {
  const avail = db
    .prepare(
      `SELECT id FROM ledger_accounts WHERE owner_type = 'CONSUMER' AND owner_id = ? AND account_type = 'CONSUMER_AVAILABLE'`
    )
    .get(userId) as { id: string } | undefined;
  const resv = db
    .prepare(
      `SELECT id FROM ledger_accounts WHERE owner_type = 'CONSUMER' AND owner_id = ? AND account_type = 'CONSUMER_RESERVED'`
    )
    .get(userId) as { id: string } | undefined;

  if (!avail || !resv) {
    throw new Error(`Consumer ledger accounts missing for user ${userId}`);
  }
  return { availableAccountId: avail.id, reservedAccountId: resv.id };
}

export function getMerchantSettlementAccountId(db: Database.Database, merchantId: string): string {
  const row = db
    .prepare(
      `SELECT id FROM ledger_accounts WHERE owner_type = 'MERCHANT' AND owner_id = ? AND account_type = 'MERCHANT_SETTLEMENT'`
    )
    .get(merchantId) as { id: string } | undefined;
  if (!row) {
    throw new Error(`Merchant settlement account missing for merchant ${merchantId}`);
  }
  return row.id;
}

export function listLedgerAccounts(db: Database.Database): LedgerAccountSummary[] {
  const rows = db
    .prepare('SELECT * FROM ledger_accounts ORDER BY owner_type DESC, code ASC')
    .all() as RawLedgerAccount[];

  return rows.map((r) => ({
    id: r.id,
    code: r.code,
    ownerType: r.owner_type,
    ownerId: r.owner_id,
    ownerLabel: r.owner_label,
    accountType: r.account_type as LedgerAccountSummary['accountType'],
    normalBalance: r.normal_balance,
    allowNegative: r.allow_negative === 1,
    balanceCents: r.balance_cents,
  }));
}

export function listRecentJournalTransactions(
  db: Database.Database,
  limit = 60
): JournalTransactionView[] {
  const rows = db
    .prepare('SELECT id FROM journal_transactions ORDER BY created_at DESC, rowid DESC LIMIT ?')
    .all(limit) as Array<{ id: string }>;

  return rows
    .map((r) => getJournalTransactionById(db, r.id))
    .filter((v): v is JournalTransactionView => v !== null);
}

export function runLedgerReconciliation(
  db: Database.Database,
  checkedBy: string,
  notes = 'Automated trial-balance and clearing-backing invariant check'
): ReconciliationRecord {
  const tx = db.transaction(() => {
    const totals = db
      .prepare(
        `SELECT COALESCE(SUM(debit_cents), 0) as total_debits, COALESCE(SUM(credit_cents), 0) as total_credits FROM journal_postings`
      )
      .get() as { total_debits: number; total_credits: number };

    // Verify per-account stored balance matches posting sum
    const accounts = db.prepare('SELECT * FROM ledger_accounts').all() as RawLedgerAccount[];
    let postingMismatchCount = 0;

    for (const acc of accounts) {
      const sumRow = db
        .prepare(
          `SELECT COALESCE(SUM(debit_cents), 0) as debits, COALESCE(SUM(credit_cents), 0) as credits FROM journal_postings WHERE account_id = ?`
        )
        .get(acc.id) as { debits: number; credits: number };

      const derived =
        acc.normal_balance === 'LIABILITY'
          ? sumRow.credits - sumRow.debits
          : sumRow.debits - sumRow.credits;

      if (derived !== acc.balance_cents) {
        postingMismatchCount += 1;
      }
    }

    const totalClearingAsset = accounts
      .filter((a) => a.normal_balance === 'ASSET')
      .reduce((sum, a) => sum + a.balance_cents, 0);

    const totalWalletLiability = accounts
      .filter((a) => a.normal_balance === 'LIABILITY')
      .reduce((sum, a) => sum + a.balance_cents, 0);

    const debitCreditDiff = totals.total_debits - totals.total_credits;
    const assetLiabilityDiff = totalClearingAsset - totalWalletLiability;
    const discrepancyCents = Math.abs(debitCreditDiff) + Math.abs(assetLiabilityDiff) + postingMismatchCount;
    const status = discrepancyCents === 0 ? 'BALANCED' : 'MISMATCH';

    const id = `rec_${crypto.randomUUID().slice(0, 10)}`;
    const now = new Date().toISOString();

    db.prepare(`
      INSERT INTO reconciliation_records (
        id, status, total_debits_cents, total_credits_cents, total_clearing_asset_cents,
        total_wallet_liability_cents, discrepancy_cents, checked_by, notes, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      status,
      totals.total_debits,
      totals.total_credits,
      totalClearingAsset,
      totalWalletLiability,
      discrepancyCents,
      checkedBy,
      notes,
      now
    );

    appendAuditLog(db, {
      actorId: checkedBy,
      actorRole: checkedBy.startsWith('staff_') ? 'SUPERVISOR' : 'SYSTEM',
      action: 'LEDGER_RECONCILIATION_RUN',
      targetType: 'RECONCILIATION',
      targetId: id,
      reason: notes,
      metadata: {
        status,
        totalDebitsCents: totals.total_debits,
        totalCreditsCents: totals.total_credits,
        totalClearingAssetCents: totalClearingAsset,
        totalWalletLiabilityCents: totalWalletLiability,
        discrepancyCents,
      },
    });

    return {
      id,
      status,
      totalDebitsCents: totals.total_debits,
      totalCreditsCents: totals.total_credits,
      totalClearingAssetCents: totalClearingAsset,
      totalWalletLiabilityCents: totalWalletLiability,
      discrepancyCents,
      checkedBy,
      notes,
      createdAt: now,
    } satisfies ReconciliationRecord;
  });

  return tx.immediate();
}
