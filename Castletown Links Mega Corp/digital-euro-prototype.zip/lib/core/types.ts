export type LocaleCode = 'en' | 'de' | 'fr' | 'es';

export type WalletStatus = 'ACTIVE' | 'FROZEN' | 'RECOVERY_PENDING' | 'CLOSED';

export type AccountType =
  | 'CONSUMER_AVAILABLE'
  | 'CONSUMER_RESERVED'
  | 'MERCHANT_SETTLEMENT'
  | 'BANK_CLEARING_IN'
  | 'BANK_CLEARING_OUT'
  | 'ISSUER_RESERVE';

export type AccountNormalBalance = 'LIABILITY' | 'ASSET';

export type PaymentLifecycleState =
  | 'CREATED'
  | 'AWAITING_AUTHORISATION'
  | 'RESERVED'
  | 'POSTED'
  | 'REJECTED'
  | 'EXPIRED'
  | 'CANCELLED';

export type PaymentKind = 'MERCHANT_PAYMENT' | 'P2P_PAYMENT' | 'P2P_REQUEST_PAYMENT';

export type FundingState = 'REQUESTED' | 'PROVIDER_PENDING' | 'SETTLED' | 'FAILED';

export type RedemptionState = 'REQUESTED' | 'LEDGER_DEBITED' | 'SETTLED' | 'FAILED';

export type StaffRole = 'OPERATOR' | 'SUPERVISOR' | 'AUDITOR';

export type EcbClassification =
  | 'CONFIRMED_ECB'
  | 'PROPOSED_RULEBOOK'
  | 'DEMO_ASSUMPTION'
  | 'UNRESOLVED_PRODUCTION';

export interface ConsumerProfile {
  id: string;
  handle: string;
  fullName: string;
  syntheticNationalId: string;
  countryCode: string;
  kycTier: 'TIER_1_SYNTHETIC' | 'TIER_2_SYNTHETIC';
  linkedBankName: string;
  linkedBankIbanMasked: string;
  walletId: string;
  walletStatus: WalletStatus;
  availableCents: number;
  reservedCents: number;
  holdingLimitCents: number;
  dailySpendLimitCents: number;
  singleTxLimitCents: number;
  waterfallEnabled: boolean;
  reverseWaterfallEnabled: boolean;
  createdAt: string;
}

export interface DeviceRecord {
  id: string;
  userId: string;
  deviceName: string;
  platform: 'ANDROID_COMPOSE' | 'WEB_PASSKEY_DEMO';
  publicKeyFingerprint: string;
  status: 'ACTIVE' | 'REVOKED' | 'LOST';
  boundAt: string;
  lastSeenAt: string;
}

export interface MerchantProfile {
  id: string;
  legalName: string;
  displayName: string;
  registrationCode: string;
  mcc: string;
  city: string;
  countryCode: string;
  verified: boolean;
  walletId: string;
  settlementBalanceCents: number;
  createdAt: string;
}

export interface PaymentRequestRecord {
  id: string;
  merchantId: string | null;
  requesterUserId: string | null;
  requesterName: string;
  requesterVerified: boolean;
  kind: 'MERCHANT_POS' | 'P2P_REQUEST';
  amountCents: number;
  currency: 'EUR';
  description: string;
  qrPayload: string;
  status: 'OPEN' | 'PAID' | 'EXPIRED' | 'CANCELLED';
  paymentId: string | null;
  expiresAt: string;
  createdAt: string;
}

export interface PaymentRecord {
  id: string;
  idempotencyKey: string;
  kind: PaymentKind;
  payerUserId: string;
  payerName: string;
  payeeKind: 'MERCHANT' | 'CONSUMER';
  payeeId: string;
  payeeName: string;
  paymentRequestId: string | null;
  amountCents: number;
  refundedCents: number;
  currency: 'EUR';
  state: PaymentLifecycleState;
  stepUpRequired: boolean;
  stepUpVerified: boolean;
  failureReason: string | null;
  journalTxId: string | null;
  expiresAt: string;
  createdAt: string;
  updatedAt: string;
}

export interface RefundRecord {
  id: string;
  idempotencyKey: string;
  originalPaymentId: string;
  merchantId: string;
  consumerUserId: string;
  amountCents: number;
  reason: string;
  status: 'PENDING_REVIEW' | 'POSTED' | 'REJECTED';
  journalTxId: string | null;
  createdAt: string;
}

export interface FundingRequestRecord {
  id: string;
  idempotencyKey: string;
  userId: string;
  provider: string;
  amountCents: number;
  state: FundingState;
  providerReference: string | null;
  providerMessage: string | null;
  journalTxId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface RedemptionRequestRecord {
  id: string;
  idempotencyKey: string;
  userId: string;
  provider: string;
  amountCents: number;
  state: RedemptionState;
  providerReference: string | null;
  providerMessage: string | null;
  journalTxId: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface LedgerAccountSummary {
  id: string;
  code: string;
  ownerType: 'CONSUMER' | 'MERCHANT' | 'SYSTEM';
  ownerId: string | null;
  ownerLabel: string;
  accountType: AccountType;
  normalBalance: AccountNormalBalance;
  allowNegative: boolean;
  balanceCents: number;
}

export interface JournalPostingView {
  id: string;
  journalTxId: string;
  accountId: string;
  accountCode: string;
  accountLabel: string;
  debitCents: number;
  creditCents: number;
}

export interface JournalTransactionView {
  id: string;
  idempotencyKey: string;
  txType: string;
  referenceType: string;
  referenceId: string;
  parentTxId: string | null;
  description: string;
  totalDebitCents: number;
  totalCreditCents: number;
  createdAt: string;
  postings: JournalPostingView[];
}

export interface ReconciliationRecord {
  id: string;
  status: 'BALANCED' | 'MISMATCH';
  totalDebitsCents: number;
  totalCreditsCents: number;
  totalClearingAssetCents: number;
  totalWalletLiabilityCents: number;
  discrepancyCents: number;
  checkedBy: string;
  notes: string;
  createdAt: string;
}

export interface AdminApprovalRequest {
  id: string;
  actionType: 'LIMIT_UPDATE' | 'WALLET_FREEZE' | 'WALLET_UNFREEZE' | 'COMPENSATING_ADJUSTMENT' | 'REFUND_REVIEW';
  targetId: string;
  payloadJson: string;
  reason: string;
  requestedBy: string;
  requestedRole: StaffRole;
  status: 'PENDING' | 'APPROVED' | 'REJECTED';
  reviewedBy: string | null;
  reviewNote: string | null;
  createdAt: string;
  reviewedAt: string | null;
}

export interface IncidentRecord {
  id: string;
  severity: 'LOW' | 'MEDIUM' | 'HIGH';
  category: string;
  title: string;
  details: string;
  status: 'OPEN' | 'INVESTIGATING' | 'RESOLVED';
  reportedBy: string;
  resolutionNote: string | null;
  createdAt: string;
  resolvedAt: string | null;
}

export interface AuditLogRecord {
  id: string;
  actorId: string;
  actorRole: string;
  action: string;
  targetType: string;
  targetId: string;
  reason: string;
  metadataRedacted: string;
  createdAt: string;
}

export interface OfflineWalletState {
  deviceId: string;
  ownerName: string;
  allowanceCents: number;
  spentLocalCents: number;
  sequenceCounter: number;
  connectivity: 'ONLINE' | 'OFFLINE';
  deviceLost: boolean;
  localEvents: Array<{
    id: string;
    kind: 'ALLOWANCE_LOAD' | 'OFFLINE_SPEND' | 'DUPLICATE_ATTEMPT' | 'DEVICE_LOSS' | 'RECONCILIATION_CONFLICT';
    amountCents: number;
    recipient: string;
    note: string;
    conflict: boolean;
    createdAt: string;
  }>;
}

export function formatEuroCents(cents: number, locale: LocaleCode = 'en'): string {
  const safeCents = Number.isFinite(cents) ? Math.trunc(cents) : 0;
  const sign = safeCents < 0 ? '-' : '';
  const abs = Math.abs(safeCents);
  const euros = Math.floor(abs / 100);
  const rem = abs % 100;
  const padded = rem.toString().padStart(2, '0');
  const localeMap: Record<LocaleCode, string> = {
    en: 'en-IE',
    de: 'de-DE',
    fr: 'fr-FR',
    es: 'es-ES',
  };
  const formattedWhole = euros.toLocaleString(localeMap[locale]);
  if (locale === 'de' || locale === 'fr' || locale === 'es') {
    return `${sign}${formattedWhole},${padded} €`;
  }
  return `${sign}€${formattedWhole}.${padded}`;
}

export function parseEuroInputToCents(input: string): number | null {
  const cleaned = input.trim().replace(/€/g, '').replace(/\s+/g, '');
  if (!cleaned) return null;
  const normalized = cleaned.includes(',') && !cleaned.includes('.')
    ? cleaned.replace(',', '.')
    : cleaned.replace(/,/g, '');
  if (!/^\d+(\.\d{1,2})?$/.test(normalized)) {
    return null;
  }
  const [wholeStr, fracStr = ''] = normalized.split('.');
  const whole = Number.parseInt(wholeStr, 10);
  const frac = Number.parseInt(fracStr.padEnd(2, '0'), 10);
  if (!Number.isSafeInteger(whole) || !Number.isSafeInteger(frac)) {
    return null;
  }
  return whole * 100 + frac;
}

export const TRANSLATIONS: Record<LocaleCode, {
  banner: string;
  navHome: string;
  navPay: string;
  navRequest: string;
  navActivity: string;
  navAccount: string;
  availableBalance: string;
  reservedBalance: string;
  holdingCap: string;
  sendPayment: string;
  fundWallet: string;
  redeemToBank: string;
  recentActivity: string;
  selectRecipient: string;
  enterAmount: string;
  reviewDetails: string;
  authorisePayment: string;
  paymentOutcome: string;
}> = {
  en: {
    banner: 'DEMONSTRATION — SIMULATED FUNDS · Independent Prototype · Not Official ECB / Eurosystem Infrastructure',
    navHome: 'Home',
    navPay: 'Pay',
    navRequest: 'Request',
    navActivity: 'Activity',
    navAccount: 'Account',
    availableBalance: 'Available balance',
    reservedBalance: 'Reserved balance',
    holdingCap: 'Simulated holding limit',
    sendPayment: 'Send payment',
    fundWallet: 'Fund from bank',
    redeemToBank: 'Redeem to bank',
    recentActivity: 'Payment activity',
    selectRecipient: 'Select recipient',
    enterAmount: 'Enter amount',
    reviewDetails: 'Review details',
    authorisePayment: 'Authorise',
    paymentOutcome: 'Outcome',
  },
  de: {
    banner: 'DEMONSTRATION — SIMULIERTE MITTEL · Unabhängiger Prototyp · Keine offizielle EZB-/Eurosystem-Infrastruktur',
    navHome: 'Start',
    navPay: 'Zahlen',
    navRequest: 'Anfordern',
    navActivity: 'Aktivität',
    navAccount: 'Konto',
    availableBalance: 'Verfügbares Guthaben',
    reservedBalance: 'Reserviertes Guthaben',
    holdingCap: 'Simuliertes Haltungslimit',
    sendPayment: 'Zahlung senden',
    fundWallet: 'Vom Bankkonto laden',
    redeemToBank: 'Auf Bankkonto auszahlen',
    recentActivity: 'Zahlungsaktivität',
    selectRecipient: 'Empfänger wählen',
    enterAmount: 'Betrag eingeben',
    reviewDetails: 'Details prüfen',
    authorisePayment: 'Autorisieren',
    paymentOutcome: 'Ergebnis',
  },
  fr: {
    banner: 'DÉMONSTRATION — FONDS SIMULÉS · Prototype indépendant · Hors infrastructure officielle BCE / Eurosystème',
    navHome: 'Accueil',
    navPay: 'Payer',
    navRequest: 'Demander',
    navActivity: 'Activité',
    navAccount: 'Compte',
    availableBalance: 'Solde disponible',
    reservedBalance: 'Solde réservé',
    holdingCap: 'Plafond de détention simulé',
    sendPayment: 'Envoyer un paiement',
    fundWallet: 'Alimenter par banque',
    redeemToBank: 'Transférer vers banque',
    recentActivity: 'Historique des paiements',
    selectRecipient: 'Choisir le bénéficiaire',
    enterAmount: 'Saisir le montant',
    reviewDetails: 'Vérifier les détails',
    authorisePayment: 'Autoriser',
    paymentOutcome: 'Résultat',
  },
  es: {
    banner: 'DEMOSTRACIÓN — FONDOS SIMULADOS · Prototipo independiente · No es infraestructura oficial del BCE / Eurosistema',
    navHome: 'Inicio',
    navPay: 'Pagar',
    navRequest: 'Solicitar',
    navActivity: 'Actividad',
    navAccount: 'Cuenta',
    availableBalance: 'Saldo disponible',
    reservedBalance: 'Saldo reservado',
    holdingCap: 'Límite de tenencia simulado',
    sendPayment: 'Enviar pago',
    fundWallet: 'Cargar desde banco',
    redeemToBank: 'Transferir al banco',
    recentActivity: 'Actividad de pagos',
    selectRecipient: 'Seleccionar destinatario',
    enterAmount: 'Introducir importe',
    reviewDetails: 'Revisar detalles',
    authorisePayment: 'Autorizar',
    paymentOutcome: 'Resultado',
  },
};

export interface EcbResearchItem {
  topic: string;
  classification: EcbClassification;
  summary: string;
  prototypeImplementation: string;
}

export const ECB_RESEARCH_MATRIX: EcbResearchItem[] = [
  {
    topic: 'Retail holding limit per user',
    classification: 'CONFIRMED_ECB',
    summary:
      'ECB design mandates a per-user holding limit to prevent bank disintermediation and store-of-value hoarding; exact euro figure is calibrated post-legislation.',
    prototypeImplementation:
      'Enforces configurable integer-cent holding limits on consumer available balance; defaults to €3,000.00 (300,000 cents) as a documented demonstration assumption.',
  },
  {
    topic: 'Waterfall & reverse-waterfall bank linking',
    classification: 'PROPOSED_RULEBOOK',
    summary:
      'Draft Digital Euro Rulebook specifies automated overflow (waterfall) to a linked commercial bank account and automated gap-funding (reverse waterfall) during payments.',
    prototypeImplementation:
      'Configurable per wallet in Account settings; demonstrates explicit clearing-account transfers between RheinMain Demo Bank and consumer wallet.',
  },
  {
    topic: 'High privacy & PII separation from settlement ledger',
    classification: 'CONFIRMED_ECB',
    summary:
      'Eurosystem settlement layer does not require clear-text consumer identities; PSPs handle KYC/AML while settlement operates on pseudonymous account identifiers.',
    prototypeImplementation:
      'Consumer names, national IDs, and IBANs reside in identity/customer tables; double-entry journal postings reference opaque account IDs only.',
  },
  {
    topic: 'Merchant QR standardisation & mandatory verification',
    classification: 'PROPOSED_RULEBOOK',
    summary:
      'Rulebook Development Group standardises QR/pay-by-link payloads referencing an authenticated payment request bound to merchant, amount, currency, and expiry.',
    prototypeImplementation:
      'Merchant POS generates HMAC-signed request references (deuro-demo://pay?req=...&sig=...); merchant browser polls backend and cannot declare success.',
  },
  {
    topic: 'Offline cash-like proximity payments',
    classification: 'CONFIRMED_ECB',
    summary:
      'Offline digital euro is designed for face-to-face resilience without sharing transaction logs with PSPs or Eurosystem; requires certified secure hardware.',
    prototypeImplementation:
      'Strictly isolated in the Offline-Payment Research Simulator outside the authoritative online ledger; explicitly documents why local storage alone cannot prevent double spending.',
  },
  {
    topic: 'Exact €3,000 holding cap & €500 step-up threshold',
    classification: 'DEMO_ASSUMPTION',
    summary:
      'Specific numerical caps used in public discussion (€500–€3,000) are illustrative calibrations rather than finalised statutory numbers.',
    prototypeImplementation:
      'Exposed as admin-configurable limits with dual-control maker/checker approval and explicit reason logging.',
  },
  {
    topic: 'No programmable money purchase restrictions',
    classification: 'CONFIRMED_ECB',
    summary:
      'ECB and EU legislative proposals specify the digital euro must remain fungible retail money, never programmable vouchers restricting ordinary purchases.',
    prototypeImplementation:
      'Zero category/MCC purchase restrictions on ordinary digital euro transfers; any future conditional-payment workflow is kept strictly separate and disabled.',
  },
  {
    topic: 'Hardware Secure Element / TEE & PSP licensing',
    classification: 'UNRESOLVED_PRODUCTION',
    summary:
      'Production deployment requires certified smartphone Secure Elements / SE/TEE device attestation, qualified trust services, TIPS-like 24/7 settlement rails, and PSD2/AML supervision.',
    prototypeImplementation:
      'Simulated via software ECDSA/HMAC key fingerprints and synthetic KYC tiers; clearly documented as non-production.',
  },
];
