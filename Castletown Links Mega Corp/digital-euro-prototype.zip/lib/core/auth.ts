import crypto from 'node:crypto';
import type Database from 'better-sqlite3';
import { getDb } from './db';
import type { StaffRole } from './types';

// Ephemeral fallback secret generated once per runtime process when env var is unset
const EPHEMERAL_SESSION_KEY = crypto.randomBytes(32).toString('hex');
const EPHEMERAL_WEBHOOK_KEY = crypto.randomBytes(32).toString('hex');

function getSessionSecret(): string {
  const configured = process.env.DIGITAL_EURO_SESSION_SECRET;
  if (configured && configured.trim().length >= 16) {
    return configured.trim();
  }
  return EPHEMERAL_SESSION_KEY;
}

export function getBankWebhookSecret(): string {
  const configured = process.env.BANK_WEBHOOK_SECRET;
  if (configured && configured.trim().length >= 16) {
    return configured.trim();
  }
  return EPHEMERAL_WEBHOOK_KEY;
}

export function hashSecret(secret: string): string {
  const salt = 'deuro-proto-salt-v1';
  return crypto.scryptSync(secret, salt, 32).toString('hex');
}

export function verifySecret(secret: string, expectedHash: string): boolean {
  const actual = hashSecret(secret);
  const a = Buffer.from(actual, 'hex');
  const b = Buffer.from(expectedHash, 'hex');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export interface SessionClaims {
  sub: string;
  role: 'CONSUMER' | 'OPERATOR' | 'SUPERVISOR' | 'AUDITOR' | 'MERCHANT';
  deviceId: string | null;
  exp: number;
}

export function signBearerToken(claims: Omit<SessionClaims, 'exp'>, ttlSeconds = 3600 * 8): string {
  const payload: SessionClaims = {
    ...claims,
    exp: Math.floor(Date.now() / 1000) + ttlSeconds,
  };
  const encoded = Buffer.from(JSON.stringify(payload), 'utf8').toString('base64url');
  const sig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encoded)
    .digest('base64url');
  return `${encoded}.${sig}`;
}

export function verifyBearerToken(authHeader: string | null): SessionClaims | null {
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return null;
  }
  const token = authHeader.slice('Bearer '.length).trim();
  const parts = token.split('.');
  if (parts.length !== 2) return null;
  const [encoded, providedSig] = parts;
  const expectedSig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(encoded)
    .digest('base64url');

  const a = Buffer.from(providedSig, 'utf8');
  const b = Buffer.from(expectedSig, 'utf8');
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return null;
  }

  try {
    const parsed = JSON.parse(Buffer.from(encoded, 'base64url').toString('utf8')) as SessionClaims;
    if (!parsed.sub || !parsed.role || parsed.exp < Math.floor(Date.now() / 1000)) {
      return null;
    }
    return parsed;
  } catch {
    return null;
  }
}

export function signQrPayload(requestId: string, amountCents: number, expiresAt: string): string {
  const msg = `${requestId}:${amountCents}:EUR:${expiresAt}`;
  const sig = crypto
    .createHmac('sha256', getSessionSecret())
    .update(msg)
    .digest('hex')
    .slice(0, 24);
  return `deuro-demo://pay?req=${encodeURIComponent(requestId)}&sig=${sig}`;
}

export function signProviderPayload(bodyJson: string): string {
  return crypto
    .createHmac('sha256', getBankWebhookSecret())
    .update(bodyJson)
    .digest('hex');
}

export function verifyProviderSignature(bodyJson: string, signatureHex: string | null): boolean {
  if (!signatureHex) return false;
  const expected = signProviderPayload(bodyJson);
  const a = Buffer.from(signatureHex, 'utf8');
  const b = Buffer.from(expected, 'utf8');
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

// Redact PII and credentials before storing logs or audit metadata
const SENSITIVE_KEYS = new Set([
  'password',
  'passcode',
  'token',
  'secret',
  'iban',
  'recoveryphrase',
  'authorization',
  'signature',
  'nationalid',
]);

export function redactObject(value: unknown): unknown {
  if (value === null || value === undefined) return value;
  if (typeof value === 'string') {
    if (value.length > 8 && /^[A-Z]{2}\d{2}/.test(value)) {
      return `${value.slice(0, 4)} **** **** ${value.slice(-4)}`;
    }
    return value;
  }
  if (Array.isArray(value)) {
    return value.map(redactObject);
  }
  if (typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (SENSITIVE_KEYS.has(k.toLowerCase())) {
        out[k] = '[REDACTED]';
      } else {
        out[k] = redactObject(v);
      }
    }
    return out;
  }
  return value;
}

export function appendAuditLog(
  db: Database.Database,
  params: {
    actorId: string;
    actorRole: string;
    action: string;
    targetType: string;
    targetId: string;
    reason: string;
    metadata?: Record<string, unknown>;
  }
): void {
  const id = `aud_${crypto.randomUUID().slice(0, 12)}`;
  const now = new Date().toISOString();
  const safeMeta = JSON.stringify(redactObject(params.metadata ?? {}));
  db.prepare(`
    INSERT INTO audit_logs (
      id, actor_id, actor_role, action, target_type, target_id, reason, metadata_redacted, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id,
    params.actorId,
    params.actorRole,
    params.action,
    params.targetType,
    params.targetId,
    params.reason,
    safeMeta,
    now
  );
}

// Simple sliding-window rate limiter per key (memory-backed)
const rateBuckets = new Map<string, number[]>();

export function checkRateLimit(key: string, maxRequests = 60, windowMs = 60_000): boolean {
  const now = Date.now();
  const cutoff = now - windowMs;
  const timestamps = (rateBuckets.get(key) ?? []).filter((t) => t > cutoff);
  if (timestamps.length >= maxRequests) {
    rateBuckets.set(key, timestamps);
    return false;
  }
  timestamps.push(now);
  rateBuckets.set(key, timestamps);
  return true;
}

export function requireStaffRole(
  claims: SessionClaims | null,
  allowed: StaffRole[]
): { ok: true; claims: SessionClaims } | { ok: false; status: number; error: string } {
  if (!claims) {
    return { ok: false, status: 401, error: 'Authentication required' };
  }
  if (!allowed.includes(claims.role as StaffRole)) {
    return { ok: false, status: 403, error: `Insufficient staff role (${claims.role})` };
  }
  return { ok: true, claims };
}

export function registerConsumerAccount(input: {
  handle: string;
  fullName: string;
  syntheticNationalId: string;
  countryCode: string;
  linkedBankName: string;
  linkedBankIban: string;
  password: string;
  deviceName: string;
  platform: 'ANDROID_COMPOSE' | 'WEB_PASSKEY_DEMO';
}): {
  userId: string;
  walletId: string;
  deviceId: string;
  recoveryPhrase: string;
  token: string;
} {
  const db = getDb();
  const normalizedHandle = input.handle.startsWith('@')
    ? input.handle.toLowerCase().trim()
    : `@${input.handle.toLowerCase().trim()}`;

  if (!/^@[a-z0-9._-]{3,32}$/.test(normalizedHandle)) {
    throw new Error('Handle must be 3-32 characters (letters, numbers, ., _, -)');
  }
  if (!input.fullName.trim() || !input.syntheticNationalId.trim()) {
    throw new Error('Full name and synthetic national ID are required');
  }
  if (input.password.length < 8) {
    throw new Error('Passcode must be at least 8 characters');
  }

  const userId = `usr_${crypto.randomUUID().slice(0, 8)}`;
  const walletId = `wal_${crypto.randomUUID().slice(0, 8)}`;
  const deviceId = `dev_${crypto.randomUUID().slice(0, 8)}`;
  const availAccId = `acc_${userId}_avail`;
  const resvAccId = `acc_${userId}_resv`;
  const recoveryPhrase = `${crypto.randomBytes(2).toString('hex')}-${crypto.randomBytes(2).toString('hex')}-${crypto.randomBytes(2).toString('hex')}-euro`;
  const now = new Date().toISOString();

  const cleanIban = input.linkedBankIban.replace(/\s+/g, '').toUpperCase();
  const ibanMasked =
    cleanIban.length >= 8
      ? `${cleanIban.slice(0, 4)} **** **** ${cleanIban.slice(-4)}`
      : 'DE00 **** **** 0000';

  const tx = db.transaction(() => {
    const existing = db.prepare('SELECT id FROM users WHERE handle = ?').get(normalizedHandle);
    if (existing) {
      throw new Error('Handle is already registered');
    }

    db.prepare(`
      INSERT INTO users (
        id, handle, email_redacted, full_name, synthetic_national_id, country_code, kyc_tier,
        password_hash, role, linked_bank_name, linked_bank_iban_masked, recovery_phrase_hash, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      userId,
      normalizedHandle,
      `${normalizedHandle.slice(1, 3)}***@synthetic.example`,
      input.fullName.trim(),
      input.syntheticNationalId.trim(),
      (input.countryCode || 'DE').toUpperCase().slice(0, 2),
      'TIER_1_SYNTHETIC',
      hashSecret(input.password),
      'CONSUMER',
      input.linkedBankName.trim() || 'RheinMain Demo Bank AG',
      ibanMasked,
      hashSecret(recoveryPhrase),
      now
    );

    db.prepare(`
      INSERT INTO wallets (
        id, owner_type, owner_id, status, holding_limit_cents, daily_spend_limit_cents,
        single_tx_limit_cents, waterfall_enabled, reverse_waterfall_enabled, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(walletId, 'CONSUMER', userId, 'ACTIVE', 300000, 150000, 100000, 1, 0, now);

    db.prepare(`
      INSERT INTO ledger_accounts (
        id, code, owner_type, owner_id, owner_label, account_type, normal_balance, allow_negative, balance_cents, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      availAccId,
      `CON:${userId}:AVAIL`,
      'CONSUMER',
      userId,
      `${input.fullName.trim()} · Available`,
      'CONSUMER_AVAILABLE',
      'LIABILITY',
      0,
      0,
      now
    );

    db.prepare(`
      INSERT INTO ledger_accounts (
        id, code, owner_type, owner_id, owner_label, account_type, normal_balance, allow_negative, balance_cents, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      resvAccId,
      `CON:${userId}:RESV`,
      'CONSUMER',
      userId,
      `${input.fullName.trim()} · Reserved`,
      'CONSUMER_RESERVED',
      'LIABILITY',
      0,
      0,
      now
    );

    const pubFp = `SHA256:${crypto.randomBytes(8).toString('hex')}`;
    db.prepare(`
      INSERT INTO devices (
        id, user_id, device_name, platform, public_key_fingerprint, device_secret_hash, status, bound_at, last_seen_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      deviceId,
      userId,
      input.deviceName.trim() || 'Web Demonstration Device',
      input.platform,
      pubFp,
      hashSecret(`dev-${deviceId}`),
      'ACTIVE',
      now,
      now
    );

    appendAuditLog(db, {
      actorId: userId,
      actorRole: 'CONSUMER',
      action: 'CONSUMER_REGISTERED_SYNTHETIC_KYC',
      targetType: 'USER',
      targetId: userId,
      reason: 'Synthetic consumer identity verified and bound to new device.',
      metadata: { handle: normalizedHandle, walletId, deviceId },
    });
  });

  tx.immediate();

  const token = signBearerToken({ sub: userId, role: 'CONSUMER', deviceId });
  return { userId, walletId, deviceId, recoveryPhrase, token };
}
