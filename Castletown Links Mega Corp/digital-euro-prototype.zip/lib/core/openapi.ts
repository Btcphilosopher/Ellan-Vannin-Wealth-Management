export function buildOpenApiSpec() {
  return {
    openapi: '3.1.0',
    info: {
      title: 'Digital Euro Research Prototype API',
      version: '0.1.0-demo',
      description:
        'Independent digital-euro research prototype API using synthetic identities and simulated funds. Not official ECB or Eurosystem infrastructure.',
    },
    servers: [{ url: '/v1', description: 'Local prototype API server' }],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'HMAC-JWT',
        },
        providerHmac: {
          type: 'apiKey',
          in: 'header',
          name: 'X-Provider-Signature',
        },
      },
    },
    paths: {
      '/wallets/me': {
        get: {
          summary: 'Get authenticated consumer wallet balances and limits (integer euro cents)',
          security: [{ bearerAuth: [] }],
          responses: { '200': { description: 'Wallet summary' }, '401': { description: 'Unauthenticated' } },
        },
      },
      '/wallets/me/transactions': {
        get: {
          summary: 'List consumer payment history, refunds, funding, and redemptions (distinct from raw ledger postings)',
          security: [{ bearerAuth: [] }],
          responses: { '200': { description: 'Consumer transaction history' } },
        },
      },
      '/payments': {
        post: {
          summary: 'Create an idempotent payment intent (CREATED -> AWAITING_AUTHORISATION)',
          security: [{ bearerAuth: [] }],
          responses: { '201': { description: 'Payment intent created or returned idempotently' } },
        },
      },
      '/payments/{payment_id}': {
        get: {
          summary: 'Authoritative payment outcome-checking endpoint for timeout and network recovery',
          security: [{ bearerAuth: [] }],
          parameters: [{ name: 'payment_id', in: 'path', required: true, schema: { type: 'string' } }],
          responses: { '200': { description: 'Authoritative payment state' } },
        },
      },
      '/payments/{payment_id}/authorise': {
        post: {
          summary: 'Step-up authorise, atomically reserve, and post double-entry ledger settlement',
          security: [{ bearerAuth: [] }],
          parameters: [{ name: 'payment_id', in: 'path', required: true, schema: { type: 'string' } }],
          responses: { '200': { description: 'Payment outcome (POSTED or REJECTED)' } },
        },
      },
      '/payment-requests': {
        post: {
          summary: 'Create an expiring merchant POS or P2P payment request with signed QR reference',
          responses: { '201': { description: 'Expiring payment request created' } },
        },
      },
      '/payment-requests/{request_id}': {
        get: {
          summary: 'Fetch verified merchant/requester details and authoritative backend settlement status',
          parameters: [{ name: 'request_id', in: 'path', required: true, schema: { type: 'string' } }],
          responses: { '200': { description: 'Payment request details' } },
        },
      },
      '/refunds': {
        post: {
          summary: 'Issue a full or partial merchant refund via linked compensating ledger postings',
          responses: { '201': { description: 'Refund posted' } },
        },
      },
      '/funding-requests': {
        post: {
          summary: 'Request simulated commercial-bank funding (creates NO spendable balance until provider event)',
          security: [{ bearerAuth: [] }],
          responses: { '201': { description: 'Funding request pending external bank adapter' } },
        },
      },
      '/redemption-requests': {
        post: {
          summary: 'Request redemption back to commercial bank (atomically debits wallet to clearing account)',
          security: [{ bearerAuth: [] }],
          responses: { '201': { description: 'Redemption ledger-debited pending external payout' } },
        },
      },
      '/providers/{provider}/events': {
        post: {
          summary: 'Receive HMAC-SHA256 verified commercial-bank adapter settlement or failure event',
          security: [{ providerHmac: [] }],
          parameters: [{ name: 'provider', in: 'path', required: true, schema: { type: 'string' } }],
          responses: { '200': { description: 'Provider event processed idempotently' } },
        },
      },
    },
  };
}
