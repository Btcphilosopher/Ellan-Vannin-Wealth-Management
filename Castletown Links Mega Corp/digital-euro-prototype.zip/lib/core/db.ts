import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

let dbInstance: Database.Database | null = null;
let currentDbPath: string | null = null;

export function getDbPath(): string {
  if (process.env.DATABASE_PATH && process.env.DATABASE_PATH.trim().length > 0) {
    return path.resolve(process.env.DATABASE_PATH.trim());
  }
  return path.resolve(process.cwd(), '.data', 'digital_euro.db');
}

export function getDb(): Database.Database {
  const targetPath = getDbPath();
  if (dbInstance && currentDbPath === targetPath) {
    return dbInstance;
  }
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }

  const dir = path.dirname(targetPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const db = new Database(targetPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');
  db.pragma('busy_timeout = 5000');

  applySchema(db);
  seedIfEmpty(db);

  dbInstance = db;
  currentDbPath = targetPath;
  return db;
}

export function resetDatabaseForDemo(customPath?: string): Database.Database {
  if (customPath) {
    process.env.DATABASE_PATH = customPath;
  }
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
  const targetPath = getDbPath();
  for (const suffix of ['', '-wal', '-shm']) {
    const f = `${targetPath}${suffix}`;
    if (fs.existsSync(f)) {
      fs.unlinkSync(f);
    }
  }
  return getDb();
}

export function applySchema(db: Database.Database): void {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      handle TEXT NOT NULL UNIQUE,
      email_redacted TEXT NOT NULL,
      full_name TEXT NOT NULL,
      synthetic_national_id TEXT NOT NULL,
      country_code TEXT NOT NULL DEFAULT 'DE',
      kyc_tier TEXT NOT NULL DEFAULT 'TIER_1_SYNTHETIC',
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'CONSUMER',
      linked_bank_name TEXT NOT NULL,
      linked_bank_iban_masked TEXT NOT NULL,
      recovery_phrase_hash TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS devices (
      id TEXT PRIMARY KEY,
      user_id TEXT NOT NULL REFERENCES users(id),
      device_name TEXT NOT NULL,
      platform TEXT NOT NULL,
      public_key_fingerprint TEXT NOT NULL,
      device_secret_hash TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('ACTIVE', 'REVOKED', 'LOST')),
      bound_at TEXT NOT NULL,
      last_seen_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS wallets (
      id TEXT PRIMARY KEY,
      owner_type TEXT NOT NULL CHECK (owner_type IN ('CONSUMER', 'MERCHANT')),
      owner_id TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('ACTIVE', 'FROZEN', 'RECOVERY_PENDING', 'CLOSED')),
      holding_limit_cents INTEGER NOT NULL CHECK (holding_limit_cents >= 0),
      daily_spend_limit_cents INTEGER NOT NULL CHECK (daily_spend_limit_cents >= 0),
      single_tx_limit_cents INTEGER NOT NULL CHECK (single_tx_limit_cents >= 0),
      waterfall_enabled INTEGER NOT NULL DEFAULT 1,
      reverse_waterfall_enabled INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS merchants (
      id TEXT PRIMARY KEY,
      legal_name TEXT NOT NULL,
      display_name TEXT NOT NULL,
      registration_code TEXT NOT NULL UNIQUE,
      mcc TEXT NOT NULL,
      city TEXT NOT NULL,
      country_code TEXT NOT NULL,
      verified INTEGER NOT NULL DEFAULT 1,
      wallet_id TEXT NOT NULL REFERENCES wallets(id),
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS ledger_accounts (
      id TEXT PRIMARY KEY,
      code TEXT NOT NULL UNIQUE,
      owner_type TEXT NOT NULL CHECK (owner_type IN ('CONSUMER', 'MERCHANT', 'SYSTEM')),
      owner_id TEXT,
      owner_label TEXT NOT NULL,
      account_type TEXT NOT NULL CHECK (
        account_type IN (
          'CONSUMER_AVAILABLE',
          'CONSUMER_RESERVED',
          'MERCHANT_SETTLEMENT',
          'BANK_CLEARING_IN',
          'BANK_CLEARING_OUT',
          'ISSUER_RESERVE'
        )
      ),
      normal_balance TEXT NOT NULL CHECK (normal_balance IN ('LIABILITY', 'ASSET')),
      allow_negative INTEGER NOT NULL CHECK (allow_negative IN (0, 1)),
      balance_cents INTEGER NOT NULL,
      created_at TEXT NOT NULL,
      CHECK (allow_negative = 1 OR balance_cents >= 0)
    );

    CREATE TABLE IF NOT EXISTS journal_transactions (
      id TEXT PRIMARY KEY,
      idempotency_key TEXT NOT NULL UNIQUE,
      tx_type TEXT NOT NULL,
      reference_type TEXT NOT NULL,
      reference_id TEXT NOT NULL,
      parent_tx_id TEXT REFERENCES journal_transactions(id),
      description TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS journal_postings (
      id TEXT PRIMARY KEY,
      journal_tx_id TEXT NOT NULL REFERENCES journal_transactions(id),
      account_id TEXT NOT NULL REFERENCES ledger_accounts(id),
      debit_cents INTEGER NOT NULL CHECK (debit_cents >= 0),
      credit_cents INTEGER NOT NULL CHECK (credit_cents >= 0),
      created_at TEXT NOT NULL,
      CHECK ((debit_cents > 0 AND credit_cents = 0) OR (credit_cents > 0 AND debit_cents = 0))
    );

    CREATE TRIGGER IF NOT EXISTS trg_journal_tx_no_update
    BEFORE UPDATE ON journal_transactions
    BEGIN
      SELECT RAISE(ABORT, 'Append-only ledger transactions cannot be modified');
    END;

    CREATE TRIGGER IF NOT EXISTS trg_journal_tx_no_delete
    BEFORE DELETE ON journal_transactions
    BEGIN
      SELECT RAISE(ABORT, 'Append-only ledger transactions cannot be deleted');
    END;

    CREATE TRIGGER IF NOT EXISTS trg_journal_postings_no_update
    BEFORE UPDATE ON journal_postings
    BEGIN
      SELECT RAISE(ABORT, 'Append-only ledger postings cannot be modified');
    END;

    CREATE TRIGGER IF NOT EXISTS trg_journal_postings_no_delete
    BEFORE DELETE ON journal_postings
    BEGIN
      SELECT RAISE(ABORT, 'Append-only ledger postings cannot be deleted');
    END;

    CREATE TABLE IF NOT EXISTS payment_requests (
      id TEXT PRIMARY KEY,
      merchant_id TEXT REFERENCES merchants(id),
      requester_user_id TEXT REFERENCES users(id),
      requester_name TEXT NOT NULL,
      requester_verified INTEGER NOT NULL DEFAULT 1,
      kind TEXT NOT NULL CHECK (kind IN ('MERCHANT_POS', 'P2P_REQUEST')),
      amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
      currency TEXT NOT NULL CHECK (currency = 'EUR'),
      description TEXT NOT NULL,
      qr_payload TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('OPEN', 'PAID', 'EXPIRED', 'CANCELLED')),
      payment_id TEXT,
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS payments (
      id TEXT PRIMARY KEY,
      idempotency_key TEXT NOT NULL UNIQUE,
      kind TEXT NOT NULL CHECK (kind IN ('MERCHANT_PAYMENT', 'P2P_PAYMENT', 'P2P_REQUEST_PAYMENT')),
      payer_user_id TEXT NOT NULL REFERENCES users(id),
      payer_name TEXT NOT NULL,
      payee_kind TEXT NOT NULL CHECK (payee_kind IN ('MERCHANT', 'CONSUMER')),
      payee_id TEXT NOT NULL,
      payee_name TEXT NOT NULL,
      payment_request_id TEXT REFERENCES payment_requests(id),
      amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
      refunded_cents INTEGER NOT NULL DEFAULT 0 CHECK (refunded_cents >= 0),
      currency TEXT NOT NULL CHECK (currency = 'EUR'),
      state TEXT NOT NULL CHECK (
        state IN ('CREATED', 'AWAITING_AUTHORISATION', 'RESERVED', 'POSTED', 'REJECTED', 'EXPIRED', 'CANCELLED')
      ),
      step_up_required INTEGER NOT NULL DEFAULT 0,
      step_up_verified INTEGER NOT NULL DEFAULT 0,
      failure_reason TEXT,
      journal_tx_id TEXT REFERENCES journal_transactions(id),
      reservation_tx_id TEXT REFERENCES journal_transactions(id),
      expires_at TEXT NOT NULL,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS refunds (
      id TEXT PRIMARY KEY,
      idempotency_key TEXT NOT NULL UNIQUE,
      original_payment_id TEXT NOT NULL REFERENCES payments(id),
      merchant_id TEXT NOT NULL REFERENCES merchants(id),
      consumer_user_id TEXT NOT NULL REFERENCES users(id),
      amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
      reason TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('PENDING_REVIEW', 'POSTED', 'REJECTED')),
      journal_tx_id TEXT REFERENCES journal_transactions(id),
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS funding_requests (
      id TEXT PRIMARY KEY,
      idempotency_key TEXT NOT NULL UNIQUE,
      user_id TEXT NOT NULL REFERENCES users(id),
      provider TEXT NOT NULL,
      amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
      state TEXT NOT NULL CHECK (state IN ('REQUESTED', 'PROVIDER_PENDING', 'SETTLED', 'FAILED')),
      provider_reference TEXT,
      provider_message TEXT,
      journal_tx_id TEXT REFERENCES journal_transactions(id),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS redemption_requests (
      id TEXT PRIMARY KEY,
      idempotency_key TEXT NOT NULL UNIQUE,
      user_id TEXT NOT NULL REFERENCES users(id),
      provider TEXT NOT NULL,
      amount_cents INTEGER NOT NULL CHECK (amount_cents > 0),
      state TEXT NOT NULL CHECK (state IN ('REQUESTED', 'LEDGER_DEBITED', 'SETTLED', 'FAILED')),
      provider_reference TEXT,
      provider_message TEXT,
      journal_tx_id TEXT REFERENCES journal_transactions(id),
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS provider_events (
      id TEXT PRIMARY KEY,
      provider TEXT NOT NULL,
      external_event_id TEXT NOT NULL UNIQUE,
      request_kind TEXT NOT NULL CHECK (request_kind IN ('FUNDING', 'REDEMPTION')),
      request_id TEXT NOT NULL,
      outcome TEXT NOT NULL CHECK (outcome IN ('SETTLED', 'FAILED')),
      signature_verified INTEGER NOT NULL,
      payload_redacted TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS reconciliation_records (
      id TEXT PRIMARY KEY,
      status TEXT NOT NULL CHECK (status IN ('BALANCED', 'MISMATCH')),
      total_debits_cents INTEGER NOT NULL,
      total_credits_cents INTEGER NOT NULL,
      total_clearing_asset_cents INTEGER NOT NULL,
      total_wallet_liability_cents INTEGER NOT NULL,
      discrepancy_cents INTEGER NOT NULL,
      checked_by TEXT NOT NULL,
      notes TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TABLE IF NOT EXISTS admin_approval_requests (
      id TEXT PRIMARY KEY,
      action_type TEXT NOT NULL,
      target_id TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      reason TEXT NOT NULL,
      requested_by TEXT NOT NULL,
      requested_role TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('PENDING', 'APPROVED', 'REJECTED')),
      reviewed_by TEXT,
      review_note TEXT,
      created_at TEXT NOT NULL,
      reviewed_at TEXT
    );

    CREATE TABLE IF NOT EXISTS incidents (
      id TEXT PRIMARY KEY,
      severity TEXT NOT NULL CHECK (severity IN ('LOW', 'MEDIUM', 'HIGH')),
      category TEXT NOT NULL,
      title TEXT NOT NULL,
      details TEXT NOT NULL,
      status TEXT NOT NULL CHECK (status IN ('OPEN', 'INVESTIGATING', 'RESOLVED')),
      reported_by TEXT NOT NULL,
      resolution_note TEXT,
      created_at TEXT NOT NULL,
      resolved_at TEXT
    );

    CREATE TABLE IF NOT EXISTS audit_logs (
      id TEXT PRIMARY KEY,
      actor_id TEXT NOT NULL,
      actor_role TEXT NOT NULL,
      action TEXT NOT NULL,
      target_type TEXT NOT NULL,
      target_id TEXT NOT NULL,
      reason TEXT NOT NULL,
      metadata_redacted TEXT NOT NULL,
      created_at TEXT NOT NULL
    );

    CREATE TRIGGER IF NOT EXISTS trg_audit_logs_no_update
    BEFORE UPDATE ON audit_logs
    BEGIN
      SELECT RAISE(ABORT, 'Audit logs are immutable');
    END;

    CREATE TABLE IF NOT EXISTS offline_simulator_state (
      id TEXT PRIMARY KEY,
      device_id TEXT NOT NULL,
      owner_name TEXT NOT NULL,
      allowance_cents INTEGER NOT NULL,
      spent_local_cents INTEGER NOT NULL,
      sequence_counter INTEGER NOT NULL,
      connectivity TEXT NOT NULL CHECK (connectivity IN ('ONLINE', 'OFFLINE')),
      device_lost INTEGER NOT NULL DEFAULT 0,
      events_json TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);
}

function hashDemoSecret(secret: string): string {
  const salt = 'deuro-proto-salt-v1';
  return crypto.scryptSync(secret, salt, 32).toString('hex');
}

function seedIfEmpty(db: Database.Database): void {
  const existing = db.prepare('SELECT COUNT(*) as cnt FROM users').get() as { cnt: number };
  if (existing.cnt > 0) return;

  const now = new Date().toISOString();

  const insertUser = db.prepare(`
    INSERT INTO users (
      id, handle, email_redacted, full_name, synthetic_national_id, country_code, kyc_tier,
      password_hash, role, linked_bank_name, linked_bank_iban_masked, recovery_phrase_hash, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertWallet = db.prepare(`
    INSERT INTO wallets (
      id, owner_type, owner_id, status, holding_limit_cents, daily_spend_limit_cents,
      single_tx_limit_cents, waterfall_enabled, reverse_waterfall_enabled, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertAccount = db.prepare(`
    INSERT INTO ledger_accounts (
      id, code, owner_type, owner_id, owner_label, account_type, normal_balance, allow_negative, balance_cents, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const insertDevice = db.prepare(`
    INSERT INTO devices (
      id, user_id, device_name, platform, public_key_fingerprint, device_secret_hash, status, bound_at, last_seen_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const tx = db.transaction(() => {
    // Consumers
    insertUser.run(
      'usr_clara',
      '@clara.weber',
      'c***@berlin-synthetic.example',
      'Clara Weber',
      'SYN-DE-8841209',
      'DE',
      'TIER_2_SYNTHETIC',
      hashDemoSecret('demo-clara-pass'),
      'CONSUMER',
      'RheinMain Demo Bank AG',
      'DE89 3704 **** **** 0130 00',
      hashDemoSecret('amber-river-nordic-vault'),
      now
    );

    insertUser.run(
      'usr_lucas',
      '@lucas.moreau',
      'l***@lyon-synthetic.example',
      'Lucas Moreau',
      'SYN-FR-5519034',
      'FR',
      'TIER_2_SYNTHETIC',
      hashDemoSecret('demo-lucas-pass'),
      'CONSUMER',
      'Banque Loire Simulation SA',
      'FR76 3000 **** **** 9912 41',
      hashDemoSecret('cedar-bridge-silver-horizon'),
      now
    );

    // Staff roles (Maker + Checker)
    insertUser.run(
      'staff_operator',
      '@ops.maker',
      'ops***@proto-psp.example',
      'Elena Rossi (Operator)',
      'STAFF-OPS-01',
      'IT',
      'TIER_2_SYNTHETIC',
      hashDemoSecret('demo-ops-pass'),
      'OPERATOR',
      'N/A',
      'N/A',
      hashDemoSecret('staff-ops-recovery'),
      now
    );

    insertUser.run(
      'staff_supervisor',
      '@sup.checker',
      'sup***@proto-psp.example',
      'Hendrik Van Dijk (Supervisor)',
      'STAFF-SUP-02',
      'NL',
      'TIER_2_SYNTHETIC',
      hashDemoSecret('demo-sup-pass'),
      'SUPERVISOR',
      'N/A',
      'N/A',
      hashDemoSecret('staff-sup-recovery'),
      now
    );

    // Consumer wallets (holding limit 300,000 cents = EUR 3,000.00 demonstration assumption)
    insertWallet.run('wal_clara', 'CONSUMER', 'usr_clara', 'ACTIVE', 300000, 150000, 100000, 1, 0, now);
    insertWallet.run('wal_lucas', 'CONSUMER', 'usr_lucas', 'ACTIVE', 300000, 150000, 100000, 1, 0, now);

    // Consumer devices
    insertDevice.run(
      'dev_clara_pixel',
      'usr_clara',
      'Pixel 9 Pro (Simulated Keystore)',
      'ANDROID_COMPOSE',
      'SHA256:9f84c2a1b04e77d3',
      hashDemoSecret('dev-secret-clara-1'),
      'ACTIVE',
      now,
      now
    );
    insertDevice.run(
      'dev_lucas_galaxy',
      'usr_lucas',
      'Galaxy S25 (Simulated Keystore)',
      'ANDROID_COMPOSE',
      'SHA256:4a11e9d8c210f3b7',
      hashDemoSecret('dev-secret-lucas-1'),
      'ACTIVE',
      now,
      now
    );

    // Merchant: Cafe Europa Berlin
    insertWallet.run('wal_cafe_europa', 'MERCHANT', 'mrc_cafe_europa', 'ACTIVE', 50000000, 10000000, 5000000, 0, 0, now);
    db.prepare(`
      INSERT INTO merchants (
        id, legal_name, display_name, registration_code, mcc, city, country_code, verified, wallet_id, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'mrc_cafe_europa',
      'Café Europa Hospitality GmbH (Synthetic)',
      'Café Europa Berlin',
      'HRB-SYN-40219',
      '5812',
      'Berlin',
      'DE',
      1,
      'wal_cafe_europa',
      now
    );

    // Ledger accounts
    insertAccount.run('acc_bank_clearing_in', 'SYS:BANK_CLEARING_IN', 'SYSTEM', 'rheinmain_bank', 'Commercial Bank Clearing In (RheinMain)', 'BANK_CLEARING_IN', 'ASSET', 1, 0, now);
    insertAccount.run('acc_bank_clearing_out', 'SYS:BANK_CLEARING_OUT', 'SYSTEM', 'rheinmain_bank', 'Commercial Bank Clearing Out (RheinMain)', 'BANK_CLEARING_OUT', 'ASSET', 1, 0, now);
    insertAccount.run('acc_issuer_reserve', 'SYS:ISSUER_RESERVE', 'SYSTEM', 'euro_sim_core', 'Simulated Issuance Reserve Account', 'ISSUER_RESERVE', 'ASSET', 1, 0, now);

    insertAccount.run('acc_clara_avail', 'CON:usr_clara:AVAIL', 'CONSUMER', 'usr_clara', 'Clara Weber · Available', 'CONSUMER_AVAILABLE', 'LIABILITY', 0, 0, now);
    insertAccount.run('acc_clara_resv', 'CON:usr_clara:RESV', 'CONSUMER', 'usr_clara', 'Clara Weber · Reserved', 'CONSUMER_RESERVED', 'LIABILITY', 0, 0, now);

    insertAccount.run('acc_lucas_avail', 'CON:usr_lucas:AVAIL', 'CONSUMER', 'usr_lucas', 'Lucas Moreau · Available', 'CONSUMER_AVAILABLE', 'LIABILITY', 0, 0, now);
    insertAccount.run('acc_lucas_resv', 'CON:usr_lucas:RESV', 'CONSUMER', 'usr_lucas', 'Lucas Moreau · Reserved', 'CONSUMER_RESERVED', 'LIABILITY', 0, 0, now);

    insertAccount.run('acc_cafe_settle', 'MRC:mrc_cafe_europa:SETTLE', 'MERCHANT', 'mrc_cafe_europa', 'Café Europa Berlin · Settlement', 'MERCHANT_SETTLEMENT', 'LIABILITY', 0, 0, now);

    // Offline simulator isolated state
    db.prepare(`
      INSERT INTO offline_simulator_state (
        id, device_id, owner_name, allowance_cents, spent_local_cents, sequence_counter, connectivity, device_lost, events_json, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'off_clara_sim',
      'dev_clara_pixel',
      'Clara Weber (Isolated Research Sandbox)',
      5000,
      0,
      0,
      'OFFLINE',
      0,
      JSON.stringify([
        {
          id: 'off_evt_init',
          kind: 'ALLOWANCE_LOAD',
          amountCents: 5000,
          recipient: 'Local Sandbox Allowance',
          note: 'Allocated €50.00 research allowance (not backed by authoritative online ledger)',
          conflict: false,
          createdAt: now,
        },
      ]),
      now
    );

    // Initial audit entry
    db.prepare(`
      INSERT INTO audit_logs (
        id, actor_id, actor_role, action, target_type, target_id, reason, metadata_redacted, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      'aud_seed_1',
      'system_bootstrap',
      'SYSTEM',
      'SYNTHETIC_FIXTURE_SEED',
      'SYSTEM',
      'all',
      'Initialised two synthetic consumers, one verified merchant, and simulated clearing accounts with zero initial balances.',
      JSON.stringify({ consumers: 2, merchants: 1, initialBalanceCents: 0 }),
      now
    );
  });

  tx();
}
