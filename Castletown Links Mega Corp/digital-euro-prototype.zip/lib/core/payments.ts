import crypto from 'node:crypto';
import { appendAuditLog, signQrPayload } from './auth';
import { getDb } from './db';
import {
  getConsumerLedgerAccountIds,
  getMerchantSettlementAccountId,
  postJournalEntryInTx,
} from './ledger';
import type {
  MerchantProfile,
  PaymentKind,
  PaymentLifecycleState,
  PaymentRecord,
  PaymentRequestRecord,
  RefundRecord,
} from './types';

function mapPaymentRow(row: Record<string, unknown>): PaymentRecord {
  return {
    id: String(row.id),
    idempotencyKey: String(row.idempotency_key),
    kind: row.kind as PaymentKind,
    payerUserId: String(row.payer_user_id),
    payerName: String(row.payer_name),
    payeeKind: row.payee_kind as 'MERCHANT' | 'CONSUMER',
    payeeId: String(row.payee_id),
    payeeName: String(row.payee_name),
    paymentRequestId: row.payment_request_id ? String(row.payment_request_id) : null,
    amountCents: Number(row.amount_cents),
    refundedCents: Number(row.refunded_cents),
    currency: 'EUR',
    state: row.state as PaymentLifecycleState,
    stepUpRequired: Number(row.step_up_required) === 1,
    stepUpVerified: Number(row.step_up_verified) === 1,
    failureReason: row.failure_reason ? String(row.failure_reason) : null,
    journalTxId: row.journal_tx_id ? String(row.journal_tx_id) : null,
    expiresAt: String(row.expires_at),
    createdAt: String(row.created_at),
    updatedAt: String(row.updated_at),
  };
}

function mapPaymentRequestRow(row: Record<string, unknown>): PaymentRequestRecord {
  return {
    id: String(row.id),
    merchantId: row.merchant_id ? String(row.merchant_id) : null,
    requesterUserId: row.requester_user_id ? String(row.requester_user_id) : null,
    requesterName: String(row.requester_name),
    requesterVerified: Number(row.requester_verified) === 1,
    kind: row.kind as 'MERCHANT_POS' | 'P2P_REQUEST',
    amountCents: Number(row.amount_cents),
    currency: 'EUR',
    description: String(row.description),
    qrPayload: String(row.qr_payload),
    status: row.status as 'OPEN' | 'PAID' | 'EXPIRED' | 'CANCELLED',
    paymentId: row.payment_id ? String(row.payment_id) : null,
    expiresAt: String(row.expires_at),
    createdAt: String(row.created_at),
  };
}

export function expireStalePaymentRequestsAndIntents(): { expiredRequests: number; expiredPayments: number } {
  const db = getDb();
  const now = new Date().toISOString();

  const tx = db.transaction(() => {
    const reqRes = db
      .prepare(`UPDATE payment_requests SET status = 'EXPIRED' WHERE status = 'OPEN' AND expires_at < ?`)
      .run(now);

    const stalePayments = db
      .prepare(
        `SELECT * FROM payments WHERE state IN ('CREATED', 'AWAITING_AUTHORISATION', 'RESERVED') AND expires_at < ?`
      )
      .all(now) as Array<Record<string, unknown>>;

    for (const p of stalePayments) {
      if (p.state === 'RESERVED') {
        const payerAcc = getConsumerLedgerAccountIds(db, String(p.payer_user_id));
        postJournalEntryInTx(db, {
          idempotencyKey: `release:expiry:${String(p.id)}`,
          txType: 'RESERVATION_RELEASE',
          referenceType: 'PAYMENT',
          referenceId: String(p.id),
          parentTxId: p.reservation_tx_id ? String(p.reservation_tx_id) : null,
          description: `Release reserved funds for expired payment ${String(p.id)}`,
          postings: [
            { accountId: payerAcc.reservedAccountId, debitCents: Number(p.amount_cents), creditCents: 0 },
            { accountId: payerAcc.availableAccountId, debitCents: 0, creditCents: Number(p.amount_cents) },
          ],
        });
      }
      db.prepare(
        `UPDATE payments SET state = 'EXPIRED', failure_reason = 'Authorisation window expired', updated_at = ? WHERE id = ?`
      ).run(now, String(p.id));
    }

    return { expiredRequests: reqRes.changes, expiredPayments: stalePayments.length };
  });

  return tx.immediate();
}

export function registerMerchant(input: {
  legalName: string;
  displayName: string;
  registrationCode: string;
  mcc: string;
  city: string;
  countryCode: string;
}): MerchantProfile {
  const db = getDb();
  if (!input.legalName.trim() || !input.displayName.trim() || !input.registrationCode.trim()) {
    throw new Error('Legal name, display name, and registration code are required');
  }

  const merchantId = `mrc_${crypto.randomUUID().slice(0, 8)}`;
  const walletId = `wal_${crypto.randomUUID().slice(0, 8)}`;
  const settleAccId = `acc_${merchantId}_settle`;
  const now = new Date().toISOString();

  const tx = db.transaction(() => {
    const existing = db
      .prepare('SELECT id FROM merchants WHERE registration_code = ?')
      .get(input.registrationCode.trim());
    if (existing) {
      throw new Error('Merchant registration code already exists');
    }

    db.prepare(`
      INSERT INTO wallets (
        id, owner_type, owner_id, status, holding_limit_cents, daily_spend_limit_cents,
        single_tx_limit_cents, waterfall_enabled, reverse_waterfall_enabled, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(walletId, 'MERCHANT', merchantId, 'ACTIVE', 50000000, 10000000, 5000000, 0, 0, now);

    db.prepare(`
      INSERT INTO merchants (
        id, legal_name, display_name, registration_code, mcc, city, country_code, verified, wallet_id, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      merchantId,
      input.legalName.trim(),
      input.displayName.trim(),
      input.registrationCode.trim().toUpperCase(),
      input.mcc.trim() || '5999',
      input.city.trim() || 'Frankfurt',
      (input.countryCode || 'DE').toUpperCase().slice(0, 2),
      1,
      walletId,
      now
    );

    db.prepare(`
      INSERT INTO ledger_accounts (
        id, code, owner_type, owner_id, owner_label, account_type, normal_balance, allow_negative, balance_cents, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      settleAccId,
      `MRC:${merchantId}:SETTLE`,
      'MERCHANT',
      merchantId,
      `${input.displayName.trim()} · Settlement`,
      'MERCHANT_SETTLEMENT',
      'LIABILITY',
      0,
      0,
      now
    );

    appendAuditLog(db, {
      actorId: merchantId,
      actorRole: 'MERCHANT',
      action: 'MERCHANT_REGISTERED',
      targetType: 'MERCHANT',
      targetId: merchantId,
      reason: 'Synthetic merchant onboarded for QR payment acceptance.',
      metadata: { displayName: input.displayName.trim(), registrationCode: input.registrationCode.trim() },
    });
  });

  tx.immediate();

  return {
    id: merchantId,
    legalName: input.legalName.trim(),
    displayName: input.displayName.trim(),
    registrationCode: input.registrationCode.trim().toUpperCase(),
    mcc: input.mcc.trim() || '5999',
    city: input.city.trim() || 'Frankfurt',
    countryCode: (input.countryCode || 'DE').toUpperCase().slice(0, 2),
    verified: true,
    walletId,
    settlementBalanceCents: 0,
    createdAt: now,
  };
}

export function createPaymentRequest(input: {
  kind: 'MERCHANT_POS' | 'P2P_REQUEST';
  merchantId?: string;
  requesterUserId?: string;
  amountCents: number;
  description: string;
  expiresInSeconds?: number;
}): PaymentRequestRecord {
  const db = getDb();
  if (!Number.isSafeInteger(input.amountCents) || input.amountCents <= 0) {
    throw new Error('Payment request amount must be a positive integer in euro cents');
  }

  const ttl = Math.max(30, Math.min(3600, input.expiresInSeconds ?? 300));
  const nowDate = new Date();
  const now = nowDate.toISOString();
  const expiresAt = new Date(nowDate.getTime() + ttl * 1000).toISOString();
  const id = `preq_${crypto.randomUUID().slice(0, 10)}`;

  let requesterName = '';
  let requesterVerified = 1;
  let merchantId: string | null = null;
  let requesterUserId: string | null = null;

  if (input.kind === 'MERCHANT_POS') {
    if (!input.merchantId) throw new Error('merchantId is required for merchant payment requests');
    const merchant = db.prepare('SELECT * FROM merchants WHERE id = ?').get(input.merchantId) as
      | { id: string; display_name: string; verified: number }
      | undefined;
    if (!merchant) throw new Error('Merchant not found');
    merchantId = merchant.id;
    requesterName = merchant.display_name;
    requesterVerified = merchant.verified;
  } else {
    if (!input.requesterUserId) throw new Error('requesterUserId is required for P2P payment requests');
    const user = db.prepare('SELECT id, full_name FROM users WHERE id = ?').get(input.requesterUserId) as
      | { id: string; full_name: string }
      | undefined;
    if (!user) throw new Error('Requester user not found');
    requesterUserId = user.id;
    requesterName = user.full_name;
    requesterVerified = 1;
  }

  const qrPayload = signQrPayload(id, input.amountCents, expiresAt);

  db.prepare(`
    INSERT INTO payment_requests (
      id, merchant_id, requester_user_id, requester_name, requester_verified, kind,
      amount_cents, currency, description, qr_payload, status, payment_id, expires_at, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, 'EUR', ?, ?, 'OPEN', NULL, ?, ?)
  `).run(
    id,
    merchantId,
    requesterUserId,
    requesterName,
    requesterVerified,
    input.kind,
    input.amountCents,
    input.description.trim() || 'Digital Euro Payment',
    qrPayload,
    expiresAt,
    now
  );

  const created = db.prepare('SELECT * FROM payment_requests WHERE id = ?').get(id) as Record<string, unknown>;
  return mapPaymentRequestRow(created);
}

export function getPaymentRequestById(requestId: string): PaymentRequestRecord | null {
  expireStalePaymentRequestsAndIntents();
  const db = getDb();
  const row = db.prepare('SELECT * FROM payment_requests WHERE id = ?').get(requestId) as
    | Record<string, unknown>
    | undefined;
  return row ? mapPaymentRequestRow(row) : null;
}

export function createPaymentIntent(input: {
  idempotencyKey: string;
  payerUserId: string;
  payeeKind: 'MERCHANT' | 'CONSUMER';
  payeeId: string;
  amountCents: number;
  paymentRequestId?: string | null;
  expiresInSeconds?: number;
}): PaymentRecord {
  const db = getDb();
  expireStalePaymentRequestsAndIntents();

  if (!input.idempotencyKey || input.idempotencyKey.trim().length < 4) {
    throw new Error('idempotencyKey (min 4 chars) is required');
  }
  if (!Number.isSafeInteger(input.amountCents) || input.amountCents <= 0) {
    throw new Error('amountCents must be a positive integer');
  }

  const tx = db.transaction(() => {
    const existing = db
      .prepare('SELECT * FROM payments WHERE idempotency_key = ?')
      .get(input.idempotencyKey.trim()) as Record<string, unknown> | undefined;
    if (existing) {
      return mapPaymentRow(existing);
    }

    const payer = db.prepare('SELECT * FROM users WHERE id = ?').get(input.payerUserId) as
      | { id: string; full_name: string }
      | undefined;
    if (!payer) throw new Error('Payer user not found');

    const payerWallet = db
      .prepare(`SELECT * FROM wallets WHERE owner_type = 'CONSUMER' AND owner_id = ?`)
      .get(payer.id) as { id: string; status: string; single_tx_limit_cents: number } | undefined;
    if (!payerWallet) throw new Error('Payer wallet not found');
    if (payerWallet.status !== 'ACTIVE') {
      throw new Error(`Payer wallet is ${payerWallet.status} and cannot initiate payments`);
    }

    let payeeName = '';
    let kind: PaymentKind = input.payeeKind === 'MERCHANT' ? 'MERCHANT_PAYMENT' : 'P2P_PAYMENT';
    let resolvedAmountCents = input.amountCents;
    let resolvedPayeeId = input.payeeId;

    if (input.paymentRequestId) {
      const req = db
        .prepare('SELECT * FROM payment_requests WHERE id = ?')
        .get(input.paymentRequestId) as Record<string, unknown> | undefined;
      if (!req) throw new Error('Referenced payment request not found');
      if (req.status !== 'OPEN') {
        throw new Error(`Payment request is ${String(req.status)}`);
      }
      resolvedAmountCents = Number(req.amount_cents);
      if (req.kind === 'MERCHANT_POS') {
        kind = 'MERCHANT_PAYMENT';
        resolvedPayeeId = String(req.merchant_id);
      } else {
        kind = 'P2P_REQUEST_PAYMENT';
        resolvedPayeeId = String(req.requester_user_id);
      }
    }

    if (input.payeeKind === 'MERCHANT') {
      const merchant = db.prepare('SELECT id, display_name FROM merchants WHERE id = ?').get(resolvedPayeeId) as
        | { id: string; display_name: string }
        | undefined;
      if (!merchant) throw new Error('Merchant not found');
      payeeName = merchant.display_name;
    } else {
      if (resolvedPayeeId === payer.id) {
        throw new Error('Cannot send a payment to the same wallet');
      }
      const peer = db.prepare('SELECT id, full_name FROM users WHERE id = ?').get(resolvedPayeeId) as
        | { id: string; full_name: string }
        | undefined;
      if (!peer) throw new Error('Recipient consumer not found');
      payeeName = peer.full_name;
    }

    // Step-up authorisation threshold (demonstration assumption: >= EUR 50.00 = 5000 cents)
    const stepUpRequired = resolvedAmountCents >= 5000 ? 1 : 0;
    const nowDate = new Date();
    const now = nowDate.toISOString();
    const ttl = Math.max(20, Math.min(900, input.expiresInSeconds ?? 180));
    const expiresAt = new Date(nowDate.getTime() + ttl * 1000).toISOString();
    const paymentId = `pay_${crypto.randomUUID().slice(0, 10)}`;

    db.prepare(`
      INSERT INTO payments (
        id, idempotency_key, kind, payer_user_id, payer_name, payee_kind, payee_id, payee_name,
        payment_request_id, amount_cents, refunded_cents, currency, state, step_up_required,
        step_up_verified, failure_reason, journal_tx_id, reservation_tx_id, expires_at, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, 'EUR', 'AWAITING_AUTHORISATION', ?, 0, NULL, NULL, NULL, ?, ?, ?)
    `).run(
      paymentId,
      input.idempotencyKey.trim(),
      kind,
      payer.id,
      payer.full_name,
      input.payeeKind,
      resolvedPayeeId,
      payeeName,
      input.paymentRequestId ?? null,
      resolvedAmountCents,
      stepUpRequired,
      expiresAt,
      now,
      now
    );

    const row = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId) as Record<string, unknown>;
    return mapPaymentRow(row);
  });

  return tx.immediate();
}

export function getPaymentById(paymentId: string): PaymentRecord | null {
  expireStalePaymentRequestsAndIntents();
  const db = getDb();
  const row = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId) as
    | Record<string, unknown>
    | undefined;
  return row ? mapPaymentRow(row) : null;
}

/**
 * Authorises a payment intent, reserves funds atomically, and posts the double-entry settlement.
 * Supports:
 * - Idempotency (retrying authorisation returns existing settled outcome without double debit)
 * - Concurrency serialization via SQLite IMMEDIATE lock
 * - Step-up verification check when amount >= EUR 50.00
 * - Simulated network timeout after commit (`simulateLostResponse: true`) so clients can verify
 *   outcome via GET /v1/payments/{id} without issuing a second payment.
 */
export function authoriseAndPostPayment(input: {
  paymentId: string;
  actorUserId: string;
  authoriseIdempotencyKey: string;
  stepUpConfirmed?: boolean;
  simulateLostResponse?: boolean;
}): { payment: PaymentRecord; simulatedNetworkDrop: boolean } {
  const db = getDb();
  expireStalePaymentRequestsAndIntents();

  const tx = db.transaction(() => {
    const row = db.prepare('SELECT * FROM payments WHERE id = ?').get(input.paymentId) as
      | Record<string, unknown>
      | undefined;
    if (!row) {
      throw new Error('Payment not found');
    }
    if (String(row.payer_user_id) !== input.actorUserId) {
      throw new Error('Forbidden: payment belongs to another consumer');
    }

    const currentState = String(row.state) as PaymentLifecycleState;
    if (currentState === 'POSTED' || currentState === 'REJECTED' || currentState === 'EXPIRED' || currentState === 'CANCELLED') {
      return mapPaymentRow(row);
    }

    const amountCents = Number(row.amount_cents);
    const stepUpRequired = Number(row.step_up_required) === 1;
    if (stepUpRequired && !input.stepUpConfirmed) {
      throw new Error('Step-up biometric/PIN confirmation is required for payments of €50.00 or more');
    }

    const payerWallet = db
      .prepare(`SELECT * FROM wallets WHERE owner_type = 'CONSUMER' AND owner_id = ?`)
      .get(input.actorUserId) as {
      id: string;
      status: string;
      holding_limit_cents: number;
      daily_spend_limit_cents: number;
      single_tx_limit_cents: number;
    };

    const now = new Date().toISOString();

    if (payerWallet.status !== 'ACTIVE') {
      db.prepare(
        `UPDATE payments SET state = 'REJECTED', failure_reason = ?, updated_at = ? WHERE id = ?`
      ).run(`Wallet is ${payerWallet.status}`, now, input.paymentId);
      const updated = db.prepare('SELECT * FROM payments WHERE id = ?').get(input.paymentId) as Record<string, unknown>;
      return mapPaymentRow(updated);
    }

    if (amountCents > payerWallet.single_tx_limit_cents) {
      db.prepare(
        `UPDATE payments SET state = 'REJECTED', failure_reason = ?, updated_at = ? WHERE id = ?`
      ).run(
        `Exceeds single transaction limit (${payerWallet.single_tx_limit_cents}¢)`,
        now,
        input.paymentId
      );
      const updated = db.prepare('SELECT * FROM payments WHERE id = ?').get(input.paymentId) as Record<string, unknown>;
      return mapPaymentRow(updated);
    }

    // Check daily spend limit
    const dayPrefix = now.slice(0, 10);
    const spentTodayRow = db
      .prepare(
        `SELECT COALESCE(SUM(amount_cents), 0) as total FROM payments WHERE payer_user_id = ? AND state = 'POSTED' AND created_at LIKE ?`
      )
      .get(input.actorUserId, `${dayPrefix}%`) as { total: number };
    if (spentTodayRow.total + amountCents > payerWallet.daily_spend_limit_cents) {
      db.prepare(
        `UPDATE payments SET state = 'REJECTED', failure_reason = ?, updated_at = ? WHERE id = ?`
      ).run(
        `Exceeds daily spend limit (${payerWallet.daily_spend_limit_cents}¢)`,
        now,
        input.paymentId
      );
      const updated = db.prepare('SELECT * FROM payments WHERE id = ?').get(input.paymentId) as Record<string, unknown>;
      return mapPaymentRow(updated);
    }

    const payerAcc = getConsumerLedgerAccountIds(db, input.actorUserId);
    const availAcc = db
      .prepare('SELECT balance_cents FROM ledger_accounts WHERE id = ?')
      .get(payerAcc.availableAccountId) as { balance_cents: number };

    if (availAcc.balance_cents < amountCents) {
      db.prepare(
        `UPDATE payments SET state = 'REJECTED', failure_reason = ?, updated_at = ? WHERE id = ?`
      ).run(
        `Insufficient available balance (${availAcc.balance_cents}¢ < ${amountCents}¢)`,
        now,
        input.paymentId
      );
      const updated = db.prepare('SELECT * FROM payments WHERE id = ?').get(input.paymentId) as Record<string, unknown>;
      return mapPaymentRow(updated);
    }

    // Resolve recipient settlement/available account & verify recipient wallet if consumer
    let recipientAccountId = '';
    if (row.payee_kind === 'MERCHANT') {
      recipientAccountId = getMerchantSettlementAccountId(db, String(row.payee_id));
    } else {
      const peerAcc = getConsumerLedgerAccountIds(db, String(row.payee_id));
      const peerWallet = db
        .prepare(`SELECT holding_limit_cents, status FROM wallets WHERE owner_type = 'CONSUMER' AND owner_id = ?`)
        .get(String(row.payee_id)) as { holding_limit_cents: number; status: string };
      if (peerWallet.status !== 'ACTIVE') {
        db.prepare(
          `UPDATE payments SET state = 'REJECTED', failure_reason = ?, updated_at = ? WHERE id = ?`
        ).run(`Recipient wallet is ${peerWallet.status}`, now, input.paymentId);
        const updated = db.prepare('SELECT * FROM payments WHERE id = ?').get(input.paymentId) as Record<string, unknown>;
        return mapPaymentRow(updated);
      }
      const peerAvail = db
        .prepare('SELECT balance_cents FROM ledger_accounts WHERE id = ?')
        .get(peerAcc.availableAccountId) as { balance_cents: number };
      if (peerAvail.balance_cents + amountCents > peerWallet.holding_limit_cents) {
        db.prepare(
          `UPDATE payments SET state = 'REJECTED', failure_reason = ?, updated_at = ? WHERE id = ?`
        ).run(
          `Recipient holding limit (${peerWallet.holding_limit_cents}¢) would be exceeded`,
          now,
          input.paymentId
        );
        const updated = db.prepare('SELECT * FROM payments WHERE id = ?').get(input.paymentId) as Record<string, unknown>;
        return mapPaymentRow(updated);
      }
      recipientAccountId = peerAcc.availableAccountId;
    }

    // Phase 1: Reserve funds (CONSUMER_AVAILABLE -> CONSUMER_RESERVED)
    const reserveTx = postJournalEntryInTx(db, {
      idempotencyKey: `reserve:${input.paymentId}:${input.authoriseIdempotencyKey}`,
      txType: 'PAYMENT_RESERVATION',
      referenceType: 'PAYMENT',
      referenceId: input.paymentId,
      description: `Reserve €${(amountCents / 100).toFixed(2)} for payment ${input.paymentId}`,
      postings: [
        { accountId: payerAcc.availableAccountId, debitCents: amountCents, creditCents: 0 },
        { accountId: payerAcc.reservedAccountId, debitCents: 0, creditCents: amountCents },
      ],
    });

    db.prepare(
      `UPDATE payments SET state = 'RESERVED', step_up_verified = ?, reservation_tx_id = ?, updated_at = ? WHERE id = ?`
    ).run(stepUpRequired ? 1 : 0, reserveTx.id, now, input.paymentId);

    // Phase 2: Atomic Settlement (CONSUMER_RESERVED -> PAYEE_ACCOUNT)
    const settleTx = postJournalEntryInTx(db, {
      idempotencyKey: `settle:${input.paymentId}:${input.authoriseIdempotencyKey}`,
      txType: String(row.kind),
      referenceType: 'PAYMENT',
      referenceId: input.paymentId,
      parentTxId: reserveTx.id,
      description: `Settle ${String(row.kind)} ${input.paymentId}`,
      postings: [
        { accountId: payerAcc.reservedAccountId, debitCents: amountCents, creditCents: 0 },
        { accountId: recipientAccountId, debitCents: 0, creditCents: amountCents },
      ],
    });

    db.prepare(
      `UPDATE payments SET state = 'POSTED', journal_tx_id = ?, updated_at = ? WHERE id = ?`
    ).run(settleTx.id, now, input.paymentId);

    if (row.payment_request_id) {
      db.prepare(
        `UPDATE payment_requests SET status = 'PAID', payment_id = ? WHERE id = ?`
      ).run(input.paymentId, String(row.payment_request_id));
    }

    appendAuditLog(db, {
      actorId: input.actorUserId,
      actorRole: 'CONSUMER',
      action: 'PAYMENT_AUTHORISED_AND_POSTED',
      targetType: 'PAYMENT',
      targetId: input.paymentId,
      reason: 'Authorised payment settled atomically via double-entry ledger.',
      metadata: {
        amountCents,
        payeeKind: row.payee_kind,
        payeeId: row.payee_id,
        journalTxId: settleTx.id,
      },
    });

    const finalRow = db.prepare('SELECT * FROM payments WHERE id = ?').get(input.paymentId) as Record<string, unknown>;
    return mapPaymentRow(finalRow);
  });

  const payment = tx.immediate();
  return {
    payment,
    simulatedNetworkDrop: Boolean(input.simulateLostResponse),
  };
}

export function cancelPaymentIntent(paymentId: string, actorUserId: string): PaymentRecord {
  const db = getDb();
  const tx = db.transaction(() => {
    const row = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId) as
      | Record<string, unknown>
      | undefined;
    if (!row) throw new Error('Payment not found');
    if (String(row.payer_user_id) !== actorUserId) {
      throw new Error('Forbidden: payment belongs to another consumer');
    }
    const state = String(row.state) as PaymentLifecycleState;
    if (state === 'POSTED') {
      throw new Error('Settled payments cannot be cancelled; use a merchant refund');
    }
    if (state === 'CANCELLED' || state === 'EXPIRED' || state === 'REJECTED') {
      return mapPaymentRow(row);
    }

    const now = new Date().toISOString();
    if (state === 'RESERVED') {
      const payerAcc = getConsumerLedgerAccountIds(db, actorUserId);
      postJournalEntryInTx(db, {
        idempotencyKey: `release:cancel:${paymentId}`,
        txType: 'RESERVATION_RELEASE',
        referenceType: 'PAYMENT',
        referenceId: paymentId,
        parentTxId: row.reservation_tx_id ? String(row.reservation_tx_id) : null,
        description: `Cancel and release reserved funds for ${paymentId}`,
        postings: [
          { accountId: payerAcc.reservedAccountId, debitCents: Number(row.amount_cents), creditCents: 0 },
          { accountId: payerAcc.availableAccountId, debitCents: 0, creditCents: Number(row.amount_cents) },
        ],
      });
    }

    db.prepare(
      `UPDATE payments SET state = 'CANCELLED', failure_reason = 'Cancelled by consumer before settlement', updated_at = ? WHERE id = ?`
    ).run(now, paymentId);

    const updated = db.prepare('SELECT * FROM payments WHERE id = ?').get(paymentId) as Record<string, unknown>;
    return mapPaymentRow(updated);
  });

  return tx.immediate();
}

export function issueMerchantRefund(input: {
  idempotencyKey: string;
  originalPaymentId: string;
  merchantId: string;
  amountCents: number;
  reason: string;
  actorId: string;
}): RefundRecord {
  const db = getDb();
  if (!input.idempotencyKey || input.idempotencyKey.trim().length < 4) {
    throw new Error('idempotencyKey is required for refunds');
  }
  if (!Number.isSafeInteger(input.amountCents) || input.amountCents <= 0) {
    throw new Error('Refund amount must be a positive integer in euro cents');
  }

  const tx = db.transaction(() => {
    const existing = db
      .prepare('SELECT * FROM refunds WHERE idempotency_key = ?')
      .get(input.idempotencyKey.trim()) as Record<string, unknown> | undefined;
    if (existing) {
      return {
        id: String(existing.id),
        idempotencyKey: String(existing.idempotency_key),
        originalPaymentId: String(existing.original_payment_id),
        merchantId: String(existing.merchant_id),
        consumerUserId: String(existing.consumer_user_id),
        amountCents: Number(existing.amount_cents),
        reason: String(existing.reason),
        status: existing.status as RefundRecord['status'],
        journalTxId: existing.journal_tx_id ? String(existing.journal_tx_id) : null,
        createdAt: String(existing.created_at),
      };
    }

    const payment = db
      .prepare('SELECT * FROM payments WHERE id = ?')
      .get(input.originalPaymentId) as Record<string, unknown> | undefined;
    if (!payment) throw new Error('Original payment not found');
    if (String(payment.state) !== 'POSTED') {
      throw new Error('Only POSTED payments can be refunded');
    }
    if (String(payment.payee_kind) !== 'MERCHANT' || String(payment.payee_id) !== input.merchantId) {
      throw new Error('Payment does not belong to the specified merchant');
    }

    const remainingRefundable = Number(payment.amount_cents) - Number(payment.refunded_cents);
    if (input.amountCents > remainingRefundable) {
      throw new Error(
        `Refund amount (${input.amountCents}¢) exceeds remaining refundable amount (${remainingRefundable}¢)`
      );
    }

    const merchantAccId = getMerchantSettlementAccountId(db, input.merchantId);
    const consumerAcc = getConsumerLedgerAccountIds(db, String(payment.payer_user_id));

    const refundId = `ref_${crypto.randomUUID().slice(0, 10)}`;
    const now = new Date().toISOString();

    const journalTx = postJournalEntryInTx(db, {
      idempotencyKey: `refund:${input.idempotencyKey.trim()}`,
      txType: 'MERCHANT_REFUND',
      referenceType: 'REFUND',
      referenceId: refundId,
      parentTxId: payment.journal_tx_id ? String(payment.journal_tx_id) : null,
      description: `Refund ${input.amountCents}¢ for payment ${input.originalPaymentId}: ${input.reason}`,
      postings: [
        { accountId: merchantAccId, debitCents: input.amountCents, creditCents: 0 },
        { accountId: consumerAcc.availableAccountId, debitCents: 0, creditCents: input.amountCents },
      ],
    });

    db.prepare(`
      INSERT INTO refunds (
        id, idempotency_key, original_payment_id, merchant_id, consumer_user_id,
        amount_cents, reason, status, journal_tx_id, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'POSTED', ?, ?)
    `).run(
      refundId,
      input.idempotencyKey.trim(),
      input.originalPaymentId,
      input.merchantId,
      String(payment.payer_user_id),
      input.amountCents,
      input.reason.trim() || 'Merchant refund',
      journalTx.id,
      now
    );

    db.prepare(
      `UPDATE payments SET refunded_cents = refunded_cents + ?, updated_at = ? WHERE id = ?`
    ).run(input.amountCents, now, input.originalPaymentId);

    appendAuditLog(db, {
      actorId: input.actorId,
      actorRole: 'MERCHANT',
      action: 'MERCHANT_REFUND_POSTED',
      targetType: 'REFUND',
      targetId: refundId,
      reason: input.reason.trim() || 'Merchant partial/full refund',
      metadata: {
        originalPaymentId: input.originalPaymentId,
        amountCents: input.amountCents,
        journalTxId: journalTx.id,
      },
    });

    return {
      id: refundId,
      idempotencyKey: input.idempotencyKey.trim(),
      originalPaymentId: input.originalPaymentId,
      merchantId: input.merchantId,
      consumerUserId: String(payment.payer_user_id),
      amountCents: input.amountCents,
      reason: input.reason.trim() || 'Merchant refund',
      status: 'POSTED',
      journalTxId: journalTx.id,
      createdAt: now,
    } satisfies RefundRecord;
  });

  return tx.immediate();
}

export function listConsumerActivity(userId: string) {
  expireStalePaymentRequestsAndIntents();
  const db = getDb();

  const payments = db
    .prepare(
      `SELECT * FROM payments WHERE payer_user_id = ? OR (payee_kind = 'CONSUMER' AND payee_id = ?) ORDER BY created_at DESC, rowid DESC`
    )
    .all(userId, userId) as Array<Record<string, unknown>>;

  const refunds = db
    .prepare(`SELECT * FROM refunds WHERE consumer_user_id = ? ORDER BY created_at DESC, rowid DESC`)
    .all(userId) as Array<Record<string, unknown>>;

  const fundings = db
    .prepare(`SELECT * FROM funding_requests WHERE user_id = ? ORDER BY created_at DESC, rowid DESC`)
    .all(userId) as Array<Record<string, unknown>>;

  const redemptions = db
    .prepare(`SELECT * FROM redemption_requests WHERE user_id = ? ORDER BY created_at DESC, rowid DESC`)
    .all(userId) as Array<Record<string, unknown>>;

  return {
    payments: payments.map(mapPaymentRow),
    refunds: refunds.map((r) => ({
      id: String(r.id),
      idempotencyKey: String(r.idempotency_key),
      originalPaymentId: String(r.original_payment_id),
      merchantId: String(r.merchant_id),
      consumerUserId: String(r.consumer_user_id),
      amountCents: Number(r.amount_cents),
      reason: String(r.reason),
      status: r.status as RefundRecord['status'],
      journalTxId: r.journal_tx_id ? String(r.journal_tx_id) : null,
      createdAt: String(r.created_at),
    })),
    fundings,
    redemptions,
  };
}
