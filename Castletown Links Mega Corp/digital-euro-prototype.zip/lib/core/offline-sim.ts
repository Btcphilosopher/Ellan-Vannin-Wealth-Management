import crypto from 'node:crypto';
import { getDb } from './db';
import type { OfflineWalletState } from './types';

/**
 * ISOLATED OFFLINE-PAYMENT RESEARCH SIMULATOR
 *
 * Architectural boundary:
 * - Completely isolated from `ledger_accounts` and `journal_transactions`.
 * - Never labels a queued online transfer as an offline payment.
 * - Explicitly demonstrates why ordinary smartphone storage alone CANNOT prevent
 *   double spending or cloned state without hardware Secure Elements (SE),
 *   Trusted Execution Environments (TEE), cryptographic device attestation,
 *   and an official Eurosystem scheme certificate hierarchy.
 */
export function getOfflineSimulatorState(): OfflineWalletState {
  const db = getDb();
  const row = db
    .prepare('SELECT * FROM offline_simulator_state WHERE id = ?')
    .get('off_clara_sim') as Record<string, unknown>;

  return {
    deviceId: String(row.device_id),
    ownerName: String(row.owner_name),
    allowanceCents: Number(row.allowance_cents),
    spentLocalCents: Number(row.spent_local_cents),
    sequenceCounter: Number(row.sequence_counter),
    connectivity: row.connectivity as 'ONLINE' | 'OFFLINE',
    deviceLost: Number(row.device_lost) === 1,
    localEvents: JSON.parse(String(row.events_json)),
  };
}

export function runOfflineSimulatorAction(input: {
  action:
    | 'TOGGLE_CONNECTIVITY'
    | 'ALLOCATE_ALLOWANCE'
    | 'OFFLINE_SPEND'
    | 'ATTEMPT_DUPLICATE_SPEND'
    | 'SIMULATE_DEVICE_LOSS'
    | 'RECONNECT_AND_RECONCILE'
    | 'RESET_SANDBOX';
  amountCents?: number;
  recipient?: string;
}): OfflineWalletState {
  const db = getDb();
  const state = getOfflineSimulatorState();
  const now = new Date().toISOString();

  let allowanceCents = state.allowanceCents;
  let spentLocalCents = state.spentLocalCents;
  let sequenceCounter = state.sequenceCounter;
  let connectivity = state.connectivity;
  let deviceLost = state.deviceLost;
  const events = [...state.localEvents];

  if (input.action === 'RESET_SANDBOX') {
    allowanceCents = 5000;
    spentLocalCents = 0;
    sequenceCounter = 0;
    connectivity = 'OFFLINE';
    deviceLost = false;
    events.splice(0, events.length, {
      id: 'off_evt_init',
      kind: 'ALLOWANCE_LOAD',
      amountCents: 5000,
      recipient: 'Local Sandbox Allowance',
      note: 'Reset €50.00 isolated research allowance (not connected to authoritative online ledger).',
      conflict: false,
      createdAt: now,
    });
  } else if (input.action === 'TOGGLE_CONNECTIVITY') {
    connectivity = connectivity === 'OFFLINE' ? 'ONLINE' : 'OFFLINE';
  } else if (input.action === 'ALLOCATE_ALLOWANCE') {
    const add = input.amountCents ?? 2000;
    if (connectivity !== 'ONLINE') {
      throw new Error('Loading an offline allowance requires ONLINE connectivity to an issuer node.');
    }
    allowanceCents += add;
    events.unshift({
      id: `off_${crypto.randomUUID().slice(0, 6)}`,
      kind: 'ALLOWANCE_LOAD',
      amountCents: add,
      recipient: 'Device Allowance Top-up',
      note: `Loaded €${(add / 100).toFixed(2)} simulated device allowance while ONLINE.`,
      conflict: false,
      createdAt: now,
    });
  } else if (input.action === 'OFFLINE_SPEND') {
    if (deviceLost) {
      throw new Error('Simulated device is marked LOST; local credentials unavailable.');
    }
    const amt = input.amountCents ?? 1500;
    const remaining = allowanceCents - spentLocalCents;
    if (amt > remaining) {
      throw new Error(`Insufficient local device allowance (${remaining}¢ remaining).`);
    }
    spentLocalCents += amt;
    sequenceCounter += 1;
    events.unshift({
      id: `off_${crypto.randomUUID().slice(0, 6)}`,
      kind: 'OFFLINE_SPEND',
      amountCents: amt,
      recipient: input.recipient || 'Local Bakery Terminal (NFC Sim)',
      note: `Signed proximity token #${sequenceCounter} while ${connectivity}. Cannot prevent state rollback without Secure Element monotonic counter.`,
      conflict: false,
      createdAt: now,
    });
  } else if (input.action === 'ATTEMPT_DUPLICATE_SPEND') {
    const amt = input.amountCents ?? 4000;
    // Demonstrates what happens when a cloned/rolled-back ordinary storage device tries to double-spend
    events.unshift({
      id: `off_${crypto.randomUUID().slice(0, 6)}`,
      kind: 'DUPLICATE_ATTEMPT',
      amountCents: amt,
      recipient: 'Second Offline Merchant (Cloned Token Replay)',
      note: 'WARNING: Ordinary local storage can be snapshotted and replayed offline. Only hardware SE/TEE monotonic counters + proximity mutual attestation can block this before settlement.',
      conflict: true,
      createdAt: now,
    });
  } else if (input.action === 'SIMULATE_DEVICE_LOSS') {
    deviceLost = true;
    events.unshift({
      id: `off_${crypto.randomUUID().slice(0, 6)}`,
      kind: 'DEVICE_LOSS',
      amountCents: allowanceCents - spentLocalCents,
      recipient: 'Unrecovered Hardware Balance',
      note: 'Simulated device loss: unspent bearer-like offline allowance (€' +
        ((allowanceCents - spentLocalCents) / 100).toFixed(2) +
        ') cannot be remotely swept while device remains offline, mimicking physical cash loss.',
      conflict: true,
      createdAt: now,
    });
  } else if (input.action === 'RECONNECT_AND_RECONCILE') {
    connectivity = 'ONLINE';
    const hasDup = events.some((e) => e.kind === 'DUPLICATE_ATTEMPT');
    events.unshift({
      id: `off_${crypto.randomUUID().slice(0, 6)}`,
      kind: 'RECONCILIATION_CONFLICT',
      amountCents: spentLocalCents,
      recipient: 'Central Settlement Reconciliation',
      note: hasDup
        ? 'RECONCILIATION CONFLICT DETECTED: Duplicate sequence counter #1 submitted by two offline merchants. Requires PSP fraud investigation & hardware attestation audit.'
        : `Reconnected cleanly: ${sequenceCounter} offline proximity token(s) totalling €${(spentLocalCents / 100).toFixed(2)} queued for scheme settlement verification.`,
      conflict: hasDup,
      createdAt: now,
    });
  }

  db.prepare(`
    UPDATE offline_simulator_state
    SET allowance_cents = ?, spent_local_cents = ?, sequence_counter = ?,
        connectivity = ?, device_lost = ?, events_json = ?, updated_at = ?
    WHERE id = 'off_clara_sim'
  `).run(
    allowanceCents,
    spentLocalCents,
    sequenceCounter,
    connectivity,
    deviceLost ? 1 : 0,
    JSON.stringify(events.slice(0, 25)),
    now
  );

  return getOfflineSimulatorState();
}
