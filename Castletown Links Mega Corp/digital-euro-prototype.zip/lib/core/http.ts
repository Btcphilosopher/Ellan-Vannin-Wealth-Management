import { NextRequest, NextResponse } from 'next/server';
import { checkRateLimit, verifyBearerToken, type SessionClaims } from './auth';

export function jsonOk(data: unknown, status = 200): NextResponse {
  return NextResponse.json(data, { status });
}

export function jsonError(message: string, status = 400, code = 'BAD_REQUEST'): NextResponse {
  return NextResponse.json({ error: { code, message } }, { status });
}

export function enforceRateLimit(req: NextRequest, scope = 'api'): NextResponse | null {
  const ip = req.headers.get('x-forwarded-for') ?? 'local';
  const ok = checkRateLimit(`${scope}:${ip}`, 120, 60_000);
  if (!ok) {
    return jsonError('Rate limit exceeded. Please wait before retrying.', 429, 'RATE_LIMITED');
  }
  return null;
}

export function requireAuth(req: NextRequest): { claims: SessionClaims } | { response: NextResponse } {
  const claims = verifyBearerToken(req.headers.get('authorization'));
  if (!claims) {
    return { response: jsonError('Missing or invalid Bearer token', 401, 'UNAUTHENTICATED') };
  }
  return { claims };
}
