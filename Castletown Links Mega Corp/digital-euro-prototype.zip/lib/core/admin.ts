import crypto from 'node:crypto';
import { appendAuditLog, hashSecret, verifySecret } from './auth';
import { getDb } from './db';
import {
  getConsumerLedgerAccountIds,
  listLedgerAccounts,
  listRecentJournalTransactions,
  postJournalEntryInTx,
  runLedgerReconciliation,
} from './ledger';
import type {
  AdminApprovalRequest,
  AuditLogRecord,
  ConsumerProfile,
  DeviceRecord,
  IncidentRecord,
  MerchantProfile,
  ReconciliationRecord,
  StaffRole,
  WalletStatus,
} from './types';

export function getConsumerProfiles(): ConsumerProfile[] {
  const db = getDb();
  const rows = db
    .prepare(`
      SELECT u.*, w.id as wallet_id, w.status as wallet_status,
             w.holding_limit_cents, w.daily_spend_limit_cents, w.single_tx_limit_cents,
             w.waterfall_enabled, w.reverse_waterfall_enabled,
             COALESCE(avail.balance_cents, 0) as available_cents,
             COALESCE(resv.balance_cents, 0) as reserved_cents
      FROM users u
      JOIN wallets w ON w.owner_type = 'CONSUMER' AND w.owner_id = u.id
      LEFT JOIN ledger_accounts avail ON avail.owner_type = 'CONSUMER' AND avail.owner_id = u.id AND avail.account_type = 'CONSUMER_AVAILABLE'
      LEFT JOIN ledger_accounts resv ON resv.owner_type = 'CONSUMER' AND resv.owner_id = u.id AND resv.account_type = 'CONSUMER_RESERVED'
      WHERE u.role = 'CONSUMER'
      ORDER BY u.created_at ASC
    `)
    .all() as Array<Record<string, unknown>>;

  return rows.map((r) => ({
    id: String(r.id),
    handle: String(r.handle),
    fullName: String(r.full_name),
    syntheticNationalId: String(r.synthetic_national_id),
    countryCode: String(r.country_code),
    kycTier: r.kyc_tier as ConsumerProfile['kycTier'],
    linkedBankName: String(r.linked_bank_name),
    linkedBankIbanMasked: String(r.linked_bank_iban_masked),
    walletId: String(r.wallet_id),
    walletStatus: r.wallet_status as WalletStatus,
    availableCents: Number(r.available_cents),
    reservedCents: Number(r.reserved_cents),
    holdingLimitCents: Number(r.holding_limit_cents),
    dailySpendLimitCents: Number(r.daily_spend_limit_cents),
    singleTxLimitCents: Number(r.single_tx_limit_cents),
    waterfallEnabled: Number(r.waterfall_enabled) === 1,
    reverseWaterfallEnabled: Number(r.reverse_waterfall_enabled) === 1,
    createdAt: String(r.created_at),
  }));
}

export function getConsumerProfileById(userId: string): ConsumerProfile | null {
  return getConsumerProfiles().find((c) => c.id === userId) ?? null;
}

export function getDevicesForUser(userId: string): DeviceRecord[] {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM devices WHERE user_id = ? ORDER BY bound_at DESC')
    .all(userId) as Array<Record<string, unknown>>;

  return rows.map((r) => ({
    id: String(r.id),
    userId: String(r.user_id),
    deviceName: String(r.device_name),
    platform: r.platform as DeviceRecord['platform'],
    publicKeyFingerprint: String(r.public_key_fingerprint),
    status: r.status as DeviceRecord['status'],
    boundAt: String(r.bound_at),
    lastSeenAt: String(r.last_seen_at),
  }));
}

export function manageConsumerDevice(input: {
  userId: string;
  action: 'BIND_NEW' | 'MARK_LOST' | 'REVOKE' | 'RECOVER_WALLET';
  deviceId?: string;
  deviceName?: string;
  recoveryPhrase?: string;
}): { devices: DeviceRecord[]; recoveryMessage: string } {
  const db = getDb();
  const now = new Date().toISOString();

  const tx = db.transaction(() => {
    if (input.action === 'BIND_NEW') {
      const newId = `dev_${crypto.randomUUID().slice(0, 8)}`;
      const fp = `SHA256:${crypto.randomBytes(8).toString('hex')}`;
      db.prepare(`
        INSERT INTO devices (
          id, user_id, device_name, platform, public_key_fingerprint, device_secret_hash, status, bound_at, last_seen_at
        ) VALUES (?, ?, ?, 'WEB_PASSKEY_DEMO', ?, ?, 'ACTIVE', ?, ?)
      `).run(
        newId,
        input.userId,
        input.deviceName?.trim() || 'Secondary Verified Device',
        fp,
        hashSecret(`dev-${newId}`),
        now,
        now
      );
      appendAuditLog(db, {
        actorId: input.userId,
        actorRole: 'CONSUMER',
        action: 'DEVICE_BOUND',
        targetType: 'DEVICE',
        targetId: newId,
        reason: 'Consumer registered a new device-bound credential.',
        metadata: { publicKeyFingerprint: fp },
      });
      return 'New device bound with hardware-style key fingerprint.';
    }

    if (input.action === 'MARK_LOST' || input.action === 'REVOKE') {
      if (!input.deviceId) throw new Error('deviceId is required');
      const nextStatus = input.action === 'MARK_LOST' ? 'LOST' : 'REVOKED';
      const res = db
        .prepare('UPDATE devices SET status = ? WHERE id = ? AND user_id = ?')
        .run(nextStatus, input.deviceId, input.userId);
      if (res.changes === 0) throw new Error('Device not found for this consumer');
      appendAuditLog(db, {
        actorId: input.userId,
        actorRole: 'CONSUMER',
        action: `DEVICE_${nextStatus}`,
        targetType: 'DEVICE',
        targetId: input.deviceId,
        reason: `Consumer marked device ${input.deviceId} as ${nextStatus}.`,
        metadata: {},
      });
      return `Device ${input.deviceId} marked ${nextStatus}.`;
    }

    // RECOVER_WALLET: verify recovery phrase (or allow demo shortcut if matching seeded phrase)
    const user = db
      .prepare('SELECT id, recovery_phrase_hash FROM users WHERE id = ?')
      .get(input.userId) as { id: string; recovery_phrase_hash: string } | undefined;
    if (!user) throw new Error('Consumer not found');
    if (!input.recoveryPhrase || !verifySecret(input.recoveryPhrase.trim(), user.recovery_phrase_hash)) {
      throw new Error('Recovery phrase verification failed (synthetic check)');
    }

    db.prepare(`UPDATE devices SET status = 'REVOKED' WHERE user_id = ? AND status = 'ACTIVE'`).run(
      input.userId
    );
    const recoveredDevId = `dev_rec_${crypto.randomUUID().slice(0, 6)}`;
    const fp = `SHA256:${crypto.randomBytes(8).toString('hex')}`;
    db.prepare(`
      INSERT INTO devices (
        id, user_id, device_name, platform, public_key_fingerprint, device_secret_hash, status, bound_at, last_seen_at
      ) VALUES (?, ?, ?, 'ANDROID_COMPOSE', ?, ?, 'ACTIVE', ?, ?)
    `).run(
      recoveredDevId,
      input.userId,
      input.deviceName?.trim() || 'Recovered Replacement Phone',
      fp,
      hashSecret(`dev-${recoveredDevId}`),
      now,
      now
    );

    db.prepare(`UPDATE wallets SET status = 'ACTIVE' WHERE owner_type = 'CONSUMER' AND owner_id = ?`).run(
      input.userId
    );

    appendAuditLog(db, {
      actorId: input.userId,
      actorRole: 'CONSUMER',
      action: 'ACCOUNT_RECOVERY_COMPLETED',
      targetType: 'USER',
      targetId: input.userId,
      reason: 'Synthetic recovery ceremony verified; prior devices revoked and new device bound.',
      metadata: { newDeviceId: recoveredDevId },
    });

    return `Recovery verified. Prior devices revoked and ${recoveredDevId} bound.`;
  });

  const recoveryMessage = tx.immediate();
  return { devices: getDevicesForUser(input.userId), recoveryMessage };
}

export function getMerchantProfiles(): MerchantProfile[] {
  const db = getDb();
  const rows = db
    .prepare(`
      SELECT m.*, COALESCE(la.balance_cents, 0) as settlement_cents
      FROM merchants m
      LEFT JOIN ledger_accounts la ON la.owner_type = 'MERCHANT' AND la.owner_id = m.id AND la.account_type = 'MERCHANT_SETTLEMENT'
      ORDER BY m.created_at ASC
    `)
    .all() as Array<Record<string, unknown>>;

  return rows.map((r) => ({
    id: String(r.id),
    legalName: String(r.legal_name),
    displayName: String(r.display_name),
    registrationCode: String(r.registration_code),
    mcc: String(r.mcc),
    city: String(r.city),
    countryCode: String(r.country_code),
    verified: Number(r.verified) === 1,
    walletId: String(r.wallet_id),
    settlementBalanceCents: Number(r.settlement_cents),
    createdAt: String(r.created_at),
  }));
}

export function getAdminOverview() {
  const db = getDb();
  const consumers = getConsumerProfiles();
  const merchants = getMerchantProfiles();
  const accounts = listLedgerAccounts(db);
  const journal = listRecentJournalTransactions(db, 40);

  const reconciliations = db
    .prepare('SELECT * FROM reconciliation_records ORDER BY created_at DESC, rowid DESC LIMIT 15')
    .all() as Array<Record<string, unknown>>;

  const approvals = db
    .prepare('SELECT * FROM admin_approval_requests ORDER BY created_at DESC, rowid DESC LIMIT 30')
    .all() as Array<Record<string, unknown>>;

  const incidents = db
    .prepare('SELECT * FROM incidents ORDER BY created_at DESC, rowid DESC LIMIT 30')
    .all() as Array<Record<string, unknown>>;

  const auditLogs = db
    .prepare('SELECT * FROM audit_logs ORDER BY created_at DESC, rowid DESC LIMIT 60')
    .all() as Array<Record<string, unknown>>;

  const allPayments = db
    .prepare('SELECT * FROM payments ORDER BY created_at DESC, rowid DESC LIMIT 40')
    .all() as Array<Record<string, unknown>>;

  const allRefunds = db
    .prepare('SELECT * FROM refunds ORDER BY created_at DESC, rowid DESC LIMIT 30')
    .all() as Array<Record<string, unknown>>;

  return {
    consumers,
    merchants,
    accounts,
    journal,
    reconciliations: reconciliations.map((r) => ({
      id: String(r.id),
      status: r.status as ReconciliationRecord['status'],
      totalDebitsCents: Number(r.total_debits_cents),
      totalCreditsCents: Number(r.total_credits_cents),
      totalClearingAssetCents: Number(r.total_clearing_asset_cents),
      totalWalletLiabilityCents: Number(r.total_wallet_liability_cents),
      discrepancyCents: Number(r.discrepancy_cents),
      checkedBy: String(r.checked_by),
      notes: String(r.notes),
      createdAt: String(r.created_at),
    })),
    approvals: approvals.map((a) => ({
      id: String(a.id),
      actionType: a.action_type as AdminApprovalRequest['actionType'],
      targetId: String(a.target_id),
      payloadJson: String(a.payload_json),
      reason: String(a.reason),
      requestedBy: String(a.requested_by),
      requestedRole: a.requested_role as StaffRole,
      status: a.status as AdminApprovalRequest['status'],
      reviewedBy: a.reviewed_by ? String(a.reviewed_by) : null,
      reviewNote: a.review_note ? String(a.review_note) : null,
      createdAt: String(a.created_at),
      reviewedAt: a.reviewed_at ? String(a.reviewed_at) : null,
    })),
    incidents: incidents.map((i) => ({
      id: String(i.id),
      severity: i.severity as IncidentRecord['severity'],
      category: String(i.category),
      title: String(i.title),
      details: String(i.details),
      status: i.status as IncidentRecord['status'],
      reportedBy: String(i.reported_by),
      resolutionNote: i.resolution_note ? String(i.resolution_note) : null,
      createdAt: String(i.created_at),
      resolvedAt: i.resolved_at ? String(i.resolved_at) : null,
    })),
    auditLogs: auditLogs.map((l) => ({
      id: String(l.id),
      actorId: String(l.actor_id),
      actorRole: String(l.actor_role),
      action: String(l.action),
      targetType: String(l.target_type),
      targetId: String(l.target_id),
      reason: String(l.reason),
      metadataRedacted: String(l.metadata_redacted),
      createdAt: String(l.created_at),
    })),
    payments: allPayments,
    refunds: allRefunds,
  };
}

export function submitAdminAction(input: {
  actorId: string;
  actorRole: StaffRole;
  action:
    | 'REQUEST_WALLET_FREEZE'
    | 'REQUEST_WALLET_UNFREEZE'
    | 'REQUEST_LIMIT_UPDATE'
    | 'REQUEST_COMPENSATING_ADJUSTMENT'
    | 'APPROVE_REQUEST'
    | 'REJECT_REQUEST'
    | 'RUN_RECONCILIATION'
    | 'CREATE_INCIDENT'
    | 'RESOLVE_INCIDENT';
  targetId?: string;
  reason: string;
  payload?: Record<string, unknown>;
}): { message: string; approvalId?: string; reconciliation?: ReconciliationRecord } {
  const db = getDb();
  if (!input.reason || input.reason.trim().length < 5) {
    throw new Error('A recorded reason (minimum 5 characters) is mandatory for all administrative actions');
  }

  if (input.action === 'RUN_RECONCILIATION') {
    const rec = runLedgerReconciliation(db, input.actorId, input.reason.trim());
    return {
      message: `Reconciliation completed: ${rec.status} (discrepancy: ${rec.discrepancyCents}¢)`,
      reconciliation: rec,
    };
  }

  const now = new Date().toISOString();

  if (
    input.action === 'REQUEST_WALLET_FREEZE' ||
    input.action === 'REQUEST_WALLET_UNFREEZE' ||
    input.action === 'REQUEST_LIMIT_UPDATE' ||
    input.action === 'REQUEST_COMPENSATING_ADJUSTMENT'
  ) {
    if (input.actorRole === 'AUDITOR') {
      throw new Error('AUDITOR role is read-only and cannot propose state changes');
    }
    if (!input.targetId) throw new Error('targetId is required');

    const mapType: Record<string, AdminApprovalRequest['actionType']> = {
      REQUEST_WALLET_FREEZE: 'WALLET_FREEZE',
      REQUEST_WALLET_UNFREEZE: 'WALLET_UNFREEZE',
      REQUEST_LIMIT_UPDATE: 'LIMIT_UPDATE',
      REQUEST_COMPENSATING_ADJUSTMENT: 'COMPENSATING_ADJUSTMENT',
    };

    const approvalId = `apr_${crypto.randomUUID().slice(0, 10)}`;
    const tx = db.transaction(() => {
      db.prepare(`
        INSERT INTO admin_approval_requests (
          id, action_type, target_id, payload_json, reason, requested_by, requested_role, status, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING', ?)
      `).run(
        approvalId,
        mapType[input.action],
        input.targetId,
        JSON.stringify(input.payload ?? {}),
        input.reason.trim(),
        input.actorId,
        input.actorRole,
        now
      );

      appendAuditLog(db, {
        actorId: input.actorId,
        actorRole: input.actorRole,
        action: `ADMIN_${input.action}_PROPOSED`,
        targetType: 'APPROVAL_REQUEST',
        targetId: approvalId,
        reason: input.reason.trim(),
        metadata: { targetId: input.targetId, payload: input.payload ?? {} },
      });
    });

    tx.immediate();
    return {
      message: `Sensitive action queued for Supervisor dual-control approval (${approvalId}).`,
      approvalId,
    };
  }

  if (input.action === 'APPROVE_REQUEST' || input.action === 'REJECT_REQUEST') {
    if (input.actorRole !== 'SUPERVISOR') {
      throw new Error('Only SUPERVISOR role can approve or reject sensitive administrative requests');
    }
    if (!input.targetId) throw new Error('Approval request ID is required');

    const tx = db.transaction(() => {
      const req = db
        .prepare('SELECT * FROM admin_approval_requests WHERE id = ?')
        .get(input.targetId) as Record<string, unknown> | undefined;
      if (!req) throw new Error('Approval request not found');
      if (req.status !== 'PENDING') throw new Error(`Request is already ${String(req.status)}`);
      if (String(req.requested_by) === input.actorId) {
        throw new Error('Four-eyes dual control: proposer cannot approve their own request');
      }

      if (input.action === 'REJECT_REQUEST') {
        db.prepare(
          `UPDATE admin_approval_requests SET status = 'REJECTED', reviewed_by = ?, review_note = ?, reviewed_at = ? WHERE id = ?`
        ).run(input.actorId, input.reason.trim(), now, input.targetId);

        appendAuditLog(db, {
          actorId: input.actorId,
          actorRole: input.actorRole,
          action: 'ADMIN_REQUEST_REJECTED',
          targetType: 'APPROVAL_REQUEST',
          targetId: input.targetId!,
          reason: input.reason.trim(),
          metadata: {},
        });
        return 'Approval request rejected.';
      }

      const payload = JSON.parse(String(req.payload_json || '{}')) as Record<string, unknown>;
      const actionType = String(req.action_type);
      const target = String(req.target_id);

      if (actionType === 'WALLET_FREEZE' || actionType === 'WALLET_UNFREEZE') {
        const nextStatus = actionType === 'WALLET_FREEZE' ? 'FROZEN' : 'ACTIVE';
        const res = db
          .prepare('UPDATE wallets SET status = ? WHERE id = ? OR owner_id = ?')
          .run(nextStatus, target, target);
        if (res.changes === 0) throw new Error('Target wallet not found');
      } else if (actionType === 'LIMIT_UPDATE') {
        const holding = Number(payload.holdingLimitCents ?? 300000);
        const daily = Number(payload.dailySpendLimitCents ?? 150000);
        const single = Number(payload.singleTxLimitCents ?? 100000);
        if (holding < 0 || daily < 0 || single < 0) {
          throw new Error('Limits must be non-negative integers');
        }
        const res = db
          .prepare(
            `UPDATE wallets SET holding_limit_cents = ?, daily_spend_limit_cents = ?, single_tx_limit_cents = ? WHERE id = ? OR owner_id = ?`
          )
          .run(holding, daily, single, target, target);
        if (res.changes === 0) throw new Error('Target wallet not found');
      } else if (actionType === 'COMPENSATING_ADJUSTMENT') {
        // Balanced compensating journal transaction using issuer/clearing reserve (never direct SQL balance edit!)
        const amountCents = Number(payload.amountCents ?? 0);
        if (!Number.isSafeInteger(amountCents) || amountCents <= 0) {
          throw new Error('Adjustment amountCents must be a positive integer');
        }
        const consumerAcc = getConsumerLedgerAccountIds(db, target);
        postJournalEntryInTx(db, {
          idempotencyKey: `admin:adj:${String(req.id)}`,
          txType: 'ADMIN_COMPENSATING_ADJUSTMENT',
          referenceType: 'APPROVAL_REQUEST',
          referenceId: String(req.id),
          description: `Supervisor-approved compensating adjustment (${String(req.reason)})`,
          postings: [
            { accountId: 'acc_issuer_reserve', debitCents: amountCents, creditCents: 0 },
            { accountId: consumerAcc.availableAccountId, debitCents: 0, creditCents: amountCents },
          ],
        });
      }

      db.prepare(
        `UPDATE admin_approval_requests SET status = 'APPROVED', reviewed_by = ?, review_note = ?, reviewed_at = ? WHERE id = ?`
      ).run(input.actorId, input.reason.trim(), now, input.targetId);

      appendAuditLog(db, {
        actorId: input.actorId,
        actorRole: input.actorRole,
        action: `ADMIN_${actionType}_EXECUTED`,
        targetType: 'APPROVAL_REQUEST',
        targetId: input.targetId!,
        reason: input.reason.trim(),
        metadata: { originalReason: req.reason, target },
      });

      return `Approved and executed ${actionType} on ${target}.`;
    });

    return { message: tx.immediate() };
  }

  if (input.action === 'CREATE_INCIDENT') {
    if (input.actorRole === 'AUDITOR') throw new Error('AUDITOR role is read-only');
    const id = `inc_${crypto.randomUUID().slice(0, 8)}`;
    const severity = (input.payload?.severity as string) || 'MEDIUM';
    const category = (input.payload?.category as string) || 'OPERATIONAL';
    const title = (input.payload?.title as string) || 'Operational review item';

    db.prepare(`
      INSERT INTO incidents (
        id, severity, category, title, details, status, reported_by, created_at
      ) VALUES (?, ?, ?, ?, ?, 'OPEN', ?, ?)
    `).run(id, severity, category, title, input.reason.trim(), input.actorId, now);

    appendAuditLog(db, {
      actorId: input.actorId,
      actorRole: input.actorRole,
      action: 'INCIDENT_CREATED',
      targetType: 'INCIDENT',
      targetId: id,
      reason: input.reason.trim(),
      metadata: { severity, category, title },
    });

    return { message: `Incident ${id} logged.` };
  }

  if (input.action === 'RESOLVE_INCIDENT') {
    if (input.actorRole !== 'SUPERVISOR' && input.actorRole !== 'OPERATOR') {
      throw new Error('Staff permission required');
    }
    if (!input.targetId) throw new Error('Incident ID required');
    db.prepare(
      `UPDATE incidents SET status = 'RESOLVED', resolution_note = ?, resolved_at = ? WHERE id = ?`
    ).run(input.reason.trim(), now, input.targetId);

    appendAuditLog(db, {
      actorId: input.actorId,
      actorRole: input.actorRole,
      action: 'INCIDENT_RESOLVED',
      targetType: 'INCIDENT',
      targetId: input.targetId,
      reason: input.reason.trim(),
      metadata: {},
    });

    return { message: `Incident ${input.targetId} resolved.` };
  }

  throw new Error('Unsupported admin action');
}

export function exportAuditLogs(format: 'json' | 'csv'): { contentType: string; body: string } {
  const db = getDb();
  const rows = db
    .prepare('SELECT * FROM audit_logs ORDER BY created_at DESC, rowid DESC')
    .all() as Array<Record<string, unknown>>;

  const mapped: AuditLogRecord[] = rows.map((l) => ({
    id: String(l.id),
    actorId: String(l.actor_id),
    actorRole: String(l.actor_role),
    action: String(l.action),
    targetType: String(l.target_type),
    targetId: String(l.target_id),
    reason: String(l.reason),
    metadataRedacted: String(l.metadata_redacted),
    createdAt: String(l.created_at),
  }));

  if (format === 'json') {
    return {
      contentType: 'application/json',
      body: JSON.stringify({ exportedAt: new Date().toISOString(), count: mapped.length, records: mapped }, null, 2),
    };
  }

  const escapeCsv = (s: string) => `"${s.replace(/"/g, '""')}"`;
  const lines = [
    'id,created_at,actor_id,actor_role,action,target_type,target_id,reason,metadata_redacted',
    ...mapped.map((r) =>
      [
        r.id,
        r.createdAt,
        r.actorId,
        r.actorRole,
        r.action,
        r.targetType,
        r.targetId,
        r.reason,
        r.metadataRedacted,
      ]
        .map(escapeCsv)
        .join(',')
    ),
  ];

  return {
    contentType: 'text/csv; charset=utf-8',
    body: lines.join('\n'),
  };
}
