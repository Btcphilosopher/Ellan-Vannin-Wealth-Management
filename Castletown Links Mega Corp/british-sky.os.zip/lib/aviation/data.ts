import { Airport, Flight, FlightSegment, RouteInformation, TimetableSlot, FareTier } from './types';
import { UK_AIRPORTS, getAirportByCode, LONDON_AIRPORT_CODES } from './airports';
import { UK_AIRLINES, AIRCRAFT_MODELS, getAirlineByCode } from './airlines';

export const MAJOR_ROUTES: RouteInformation[] = [
  {
    id: 'LON-EDI',
    originCode: 'LON',
    originCity: 'London',
    destinationCode: 'EDI',
    destinationCity: 'Edinburgh',
    distanceKm: 535,
    typicalDurationMins: 85,
    directFlightsPerDay: 32,
    airlinesOperating: ['BA', 'U2', 'FR', 'LM'],
    firstDeparture: '06:15',
    lastDeparture: '21:40',
    lowestPriceGbp: 42,
    avgPriceGbp: 78,
    co2FlightKg: 64,
    co2RailKg: 14,
    railDurationMins: 260, // 4h 20m via LNER Azuma from King's Cross
    railOperator: 'LNER (London King\'s Cross)',
  },
  {
    id: 'LON-GLA',
    originCode: 'LON',
    originCity: 'London',
    destinationCode: 'GLA',
    destinationCity: 'Glasgow',
    distanceKm: 550,
    typicalDurationMins: 85,
    directFlightsPerDay: 26,
    airlinesOperating: ['BA', 'U2', 'LM'],
    firstDeparture: '06:30',
    lastDeparture: '21:30',
    lowestPriceGbp: 46,
    avgPriceGbp: 82,
    co2FlightKg: 66,
    co2RailKg: 15,
    railDurationMins: 275, // 4h 35m via Avanti West Coast from Euston
    railOperator: 'Avanti West Coast (London Euston)',
  },
  {
    id: 'LON-BFS',
    originCode: 'LON',
    originCity: 'London',
    destinationCode: 'BFS',
    destinationCity: 'Belfast',
    distanceKm: 518,
    typicalDurationMins: 80,
    directFlightsPerDay: 28,
    airlinesOperating: ['BA', 'U2', 'FR', 'EI'],
    firstDeparture: '06:20',
    lastDeparture: '21:15',
    lowestPriceGbp: 38,
    avgPriceGbp: 72,
    co2FlightKg: 62,
    co2RailKg: 38, // Sea link required
    railDurationMins: 480, // Rail + Ferry via Cairnryan
    railOperator: 'Avanti + Stena Line Ferry',
  },
  {
    id: 'LON-ABZ',
    originCode: 'LON',
    originCity: 'London',
    destinationCode: 'ABZ',
    destinationCity: 'Aberdeen',
    distanceKm: 645,
    typicalDurationMins: 95,
    directFlightsPerDay: 16,
    airlinesOperating: ['BA', 'U2', 'LM', 'T3'],
    firstDeparture: '06:40',
    lastDeparture: '20:50',
    lowestPriceGbp: 58,
    avgPriceGbp: 104,
    co2FlightKg: 78,
    co2RailKg: 21,
    railDurationMins: 430, // 7h 10m
    railOperator: 'LNER / Caledonian Sleeper',
  },
  {
    id: 'LON-INV',
    originCode: 'LON',
    originCity: 'London',
    destinationCode: 'INV',
    destinationCity: 'Inverness',
    distanceKm: 715,
    typicalDurationMins: 100,
    directFlightsPerDay: 10,
    airlinesOperating: ['BA', 'U2', 'LM'],
    firstDeparture: '06:55',
    lastDeparture: '19:45',
    lowestPriceGbp: 52,
    avgPriceGbp: 96,
    co2FlightKg: 85,
    co2RailKg: 24,
    railDurationMins: 490, // 8h 10m
    railOperator: 'LNER Highland Chieftain',
  },
  {
    id: 'LON-NCL',
    originCode: 'LON',
    originCity: 'London',
    destinationCode: 'NCL',
    destinationCity: 'Newcastle',
    distanceKm: 405,
    typicalDurationMins: 70,
    directFlightsPerDay: 8,
    airlinesOperating: ['BA', 'LM'],
    firstDeparture: '07:05',
    lastDeparture: '20:15',
    lowestPriceGbp: 54,
    avgPriceGbp: 89,
    co2FlightKg: 49,
    co2RailKg: 10,
    railDurationMins: 175, // 2h 55m
    railOperator: 'LNER (London King\'s Cross)',
  },
  {
    id: 'LON-MAN',
    originCode: 'LON',
    originCity: 'London',
    destinationCode: 'MAN',
    destinationCity: 'Manchester',
    distanceKm: 260,
    typicalDurationMins: 60,
    directFlightsPerDay: 12,
    airlinesOperating: ['BA'],
    firstDeparture: '06:45',
    lastDeparture: '21:05',
    lowestPriceGbp: 62,
    avgPriceGbp: 94,
    co2FlightKg: 35,
    co2RailKg: 6,
    railDurationMins: 128, // 2h 08m
    railOperator: 'Avanti West Coast (London Euston)',
  },
  {
    id: 'LON-NQY',
    originCode: 'LON',
    originCity: 'London',
    destinationCode: 'NQY',
    destinationCity: 'Newquay',
    distanceKm: 350,
    typicalDurationMins: 75,
    directFlightsPerDay: 6,
    airlinesOperating: ['LM', 'T3', 'U2'],
    firstDeparture: '08:10',
    lastDeparture: '19:20',
    lowestPriceGbp: 48,
    avgPriceGbp: 86,
    co2FlightKg: 44,
    co2RailKg: 12,
    railDurationMins: 310, // 5h 10m Great Western Railway
    railOperator: 'Great Western Railway (London Paddington)',
  },
  {
    id: 'LON-JER',
    originCode: 'LON',
    originCity: 'London',
    destinationCode: 'JER',
    destinationCity: 'Jersey',
    distanceKm: 290,
    typicalDurationMins: 60,
    directFlightsPerDay: 14,
    airlinesOperating: ['BA', 'U2', 'SI'],
    firstDeparture: '07:00',
    lastDeparture: '20:30',
    lowestPriceGbp: 39,
    avgPriceGbp: 75,
    co2FlightKg: 36,
    co2RailKg: 28, // Ferry combo
    railDurationMins: 360,
    railOperator: 'SWR + Condor Ferries via Poole',
  },
  {
    id: 'MAN-ABZ',
    originCode: 'MAN',
    originCity: 'Manchester',
    destinationCode: 'ABZ',
    destinationCity: 'Aberdeen',
    distanceKm: 420,
    typicalDurationMins: 70,
    directFlightsPerDay: 6,
    airlinesOperating: ['LM', 'T3'],
    firstDeparture: '07:15',
    lastDeparture: '18:40',
    lowestPriceGbp: 68,
    avgPriceGbp: 110,
    co2FlightKg: 52,
    co2RailKg: 16,
    railDurationMins: 330,
    railOperator: 'TransPennine Express & ScotRail',
  },
  {
    id: 'MAN-BFS',
    originCode: 'MAN',
    originCity: 'Manchester',
    destinationCode: 'BFS',
    destinationCity: 'Belfast',
    distanceKm: 275,
    typicalDurationMins: 55,
    directFlightsPerDay: 12,
    airlinesOperating: ['U2', 'FR', 'EI'],
    firstDeparture: '06:50',
    lastDeparture: '21:00',
    lowestPriceGbp: 32,
    avgPriceGbp: 58,
    co2FlightKg: 34,
    co2RailKg: 32,
    railDurationMins: 420,
    railOperator: 'Rail + Cairnryan Ferry',
  },
  {
    id: 'BHX-EDI',
    originCode: 'BHX',
    originCity: 'Birmingham',
    destinationCode: 'EDI',
    destinationCity: 'Edinburgh',
    distanceKm: 420,
    typicalDurationMins: 70,
    directFlightsPerDay: 8,
    airlinesOperating: ['U2', 'LM'],
    firstDeparture: '06:40',
    lastDeparture: '20:10',
    lowestPriceGbp: 44,
    avgPriceGbp: 76,
    co2FlightKg: 51,
    co2RailKg: 13,
    railDurationMins: 250,
    railOperator: 'CrossCountry Trains (New Street to Waverley)',
  },
  {
    id: 'BHX-BFS',
    originCode: 'BHX',
    originCity: 'Birmingham',
    destinationCode: 'BFS',
    destinationCity: 'Belfast',
    distanceKm: 340,
    typicalDurationMins: 60,
    directFlightsPerDay: 8,
    airlinesOperating: ['U2', 'FR', 'EI'],
    firstDeparture: '07:05',
    lastDeparture: '20:45',
    lowestPriceGbp: 34,
    avgPriceGbp: 62,
    co2FlightKg: 42,
    co2RailKg: 36,
    railDurationMins: 460,
    railOperator: 'Rail + Ferry',
  },
  {
    id: 'BRS-EDI',
    originCode: 'BRS',
    originCity: 'Bristol',
    destinationCode: 'EDI',
    destinationCity: 'Edinburgh',
    distanceKm: 510,
    typicalDurationMins: 75,
    directFlightsPerDay: 8,
    airlinesOperating: ['U2', 'LM'],
    firstDeparture: '06:30',
    lastDeparture: '20:30',
    lowestPriceGbp: 45,
    avgPriceGbp: 79,
    co2FlightKg: 61,
    co2RailKg: 18,
    railDurationMins: 360, // 6 hours
    railOperator: 'CrossCountry Trains',
  },
  {
    id: 'BRS-BFS',
    originCode: 'BRS',
    originCity: 'Bristol',
    destinationCode: 'BFS',
    destinationCity: 'Belfast',
    distanceKm: 375,
    typicalDurationMins: 65,
    directFlightsPerDay: 6,
    airlinesOperating: ['U2', 'EI'],
    firstDeparture: '07:15',
    lastDeparture: '19:50',
    lowestPriceGbp: 38,
    avgPriceGbp: 66,
    co2FlightKg: 46,
    co2RailKg: 36,
    railDurationMins: 450,
    railOperator: 'Rail + Ferry',
  },
  {
    id: 'EDI-KOI',
    originCode: 'EDI',
    originCity: 'Edinburgh',
    destinationCode: 'KOI',
    destinationCity: 'Kirkwall (Orkney)',
    distanceKm: 350,
    typicalDurationMins: 80,
    directFlightsPerDay: 4,
    airlinesOperating: ['LM'],
    firstDeparture: '08:30',
    lastDeparture: '17:40',
    lowestPriceGbp: 88,
    avgPriceGbp: 135,
    co2FlightKg: 42,
    co2RailKg: 34,
    railDurationMins: 540, // Train to Thurso/Scrabster + NorthLink Ferry
    railOperator: 'ScotRail Far North Line + NorthLink Ferries',
  },
  {
    id: 'EDI-LSI',
    originCode: 'EDI',
    originCity: 'Edinburgh',
    destinationCode: 'LSI',
    destinationCity: 'Sumburgh (Shetland)',
    distanceKm: 470,
    typicalDurationMins: 90,
    directFlightsPerDay: 4,
    airlinesOperating: ['LM'],
    firstDeparture: '08:00',
    lastDeparture: '17:15',
    lowestPriceGbp: 95,
    avgPriceGbp: 148,
    co2FlightKg: 56,
    co2RailKg: 42,
    railDurationMins: 780, // Overnight ferry from Aberdeen
    railOperator: 'ScotRail + NorthLink Overnight Ferry',
  },
  {
    id: 'GLA-SYY',
    originCode: 'GLA',
    originCity: 'Glasgow',
    destinationCode: 'SYY',
    destinationCity: 'Stornoway (Lewis)',
    distanceKm: 300,
    typicalDurationMins: 60,
    directFlightsPerDay: 4,
    airlinesOperating: ['LM'],
    firstDeparture: '08:45',
    lastDeparture: '17:30',
    lowestPriceGbp: 82,
    avgPriceGbp: 126,
    co2FlightKg: 36,
    co2RailKg: 30,
    railDurationMins: 420,
    railOperator: 'ScotRail to Ullapool + CalMac Ferry',
  }
];

function generateFareTiers(basePrice: number): FareTier[] {
  return [
    {
      type: 'economy_light',
      title: 'Economy Light',
      price: basePrice,
      cabinBag: '1 small underseat personal item included',
      checkedBag: 'Not included (from £24.00)',
      seatSelection: 'Paid from £6.00 or auto-assigned at check-in',
      changes: 'Flight change fee £35.00 + fare difference',
      refunds: 'Non-refundable',
      boardingPriority: 'Standard',
      loungeAccess: false,
      tierDescription: 'Best for passengers travelling light with essentials only.',
    },
    {
      type: 'economy_standard',
      title: 'Economy Standard',
      price: Math.round(basePrice + 24),
      cabinBag: '1 personal item + 1 standard overhead cabin bag (up to 23kg)',
      checkedBag: '1 checked bag (23kg) included',
      seatSelection: 'Standard seat selection from 24h prior to departure',
      changes: 'Change with fare difference only (no fee)',
      refunds: 'Non-refundable (airline credit voucher voucher minus fee)',
      boardingPriority: 'Group 3',
      loungeAccess: false,
      tierDescription: 'The balanced domestic travel fare with full baggage included.',
    },
    {
      type: 'economy_flex',
      title: 'Economy Flex',
      price: Math.round(basePrice + 58),
      cabinBag: '1 personal item + 1 large cabin bag (23kg)',
      checkedBag: '1 checked bag (23kg) included',
      seatSelection: 'Complimentary seat choice at time of booking',
      changes: 'Unlimited free changes up to 1 hour before departure',
      refunds: 'Fully refundable up to 24h before departure',
      boardingPriority: 'Priority',
      loungeAccess: false,
      tierDescription: 'Maximum domestic flexibility with free changes and refundable tickets.',
    },
    {
      type: 'club_domestic',
      title: 'Club Domestic / Business',
      price: Math.round(basePrice * 1.85 + 40),
      cabinBag: '2 cabin bags (23kg each) + personal item',
      checkedBag: '2 checked bags (32kg each) included',
      seatSelection: 'Complimentary front row / extra legroom seats',
      changes: 'Unlimited changes anytime without administrative penalty',
      refunds: '100% full refund at any time',
      boardingPriority: 'Group 1',
      loungeAccess: true,
      tierDescription: 'Dedicated airport lounge access, fast-track security, premium catering & front-of-cabin seating.',
    },
  ];
}

// Generates scheduled flights with high fidelity
export function generateSyntheticFlightDatabase(): Flight[] {
  const flights: Flight[] = [];
  let flightIdCounter = 1000;

  // 1. London <-> Edinburgh Corridor (Flagship)
  const lhrEdiSchedules = [
    { dep: '06:40', arr: '08:05', flightNo: 'BA1432', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 74, gate: 'A14', term: 'Terminal 5' },
    { dep: '07:20', arr: '08:45', flightNo: 'BA1434', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 82, gate: 'A18', term: 'Terminal 5' },
    { dep: '08:15', arr: '09:40', flightNo: 'BA1436', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A321neo, base: 89, gate: 'A22', term: 'Terminal 5' },
    { dep: '09:30', arr: '10:55', flightNo: 'BA1440', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 94, gate: 'A12', term: 'Terminal 5' },
    { dep: '11:00', arr: '12:25', flightNo: 'BA1444', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 78, gate: 'A08', term: 'Terminal 5' },
    { dep: '13:15', arr: '14:40', flightNo: 'BA1448', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A321neo, base: 69, gate: 'A19', term: 'Terminal 5' },
    { dep: '15:20', arr: '16:45', flightNo: 'BA1452', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 86, gate: 'A15', term: 'Terminal 5' },
    { dep: '17:10', arr: '18:35', flightNo: 'BA1456', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 108, gate: 'A20', term: 'Terminal 5' },
    { dep: '18:40', arr: '20:05', flightNo: 'BA1460', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 115, gate: 'A11', term: 'Terminal 5' },
    { dep: '20:15', arr: '21:40', flightNo: 'BA1464', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 66, gate: 'A17', term: 'Terminal 5' },
    // London City -> Edinburgh
    { dep: '07:05', arr: '08:30', flightNo: 'BA8700', airline: 'BA', airport: 'LCY', aircraft: AIRCRAFT_MODELS.E190, base: 98, gate: 'Gate 4', term: 'Main Terminal' },
    { dep: '09:00', arr: '10:25', flightNo: 'BA8702', airline: 'BA', airport: 'LCY', aircraft: AIRCRAFT_MODELS.E190, base: 104, gate: 'Gate 6', term: 'Main Terminal' },
    { dep: '16:45', arr: '18:10', flightNo: 'BA8710', airline: 'BA', airport: 'LCY', aircraft: AIRCRAFT_MODELS.E190, base: 112, gate: 'Gate 2', term: 'Main Terminal' },
    { dep: '19:10', arr: '20:35', flightNo: 'BA8714', airline: 'BA', airport: 'LCY', aircraft: AIRCRAFT_MODELS.E190, base: 92, gate: 'Gate 5', term: 'Main Terminal' },
    // Gatwick -> Edinburgh
    { dep: '06:15', arr: '07:45', flightNo: 'U2802', airline: 'U2', airport: 'LGW', aircraft: AIRCRAFT_MODELS.A320neo, base: 42, gate: '54', term: 'North Terminal' },
    { dep: '08:35', arr: '10:05', flightNo: 'U2804', airline: 'U2', airport: 'LGW', aircraft: AIRCRAFT_MODELS.A320neo, base: 54, gate: '58', term: 'North Terminal' },
    { dep: '12:40', arr: '14:10', flightNo: 'U2808', airline: 'U2', airport: 'LGW', aircraft: AIRCRAFT_MODELS.A321neo, base: 49, gate: '49', term: 'North Terminal' },
    { dep: '16:15', arr: '17:45', flightNo: 'U2812', airline: 'U2', airport: 'LGW', aircraft: AIRCRAFT_MODELS.A320neo, base: 76, gate: '52', term: 'North Terminal' },
    { dep: '19:40', arr: '21:10', flightNo: 'U2816', airline: 'U2', airport: 'LGW', aircraft: AIRCRAFT_MODELS.A320neo, base: 58, gate: '55', term: 'North Terminal' },
    // Luton -> Edinburgh
    { dep: '07:15', arr: '08:35', flightNo: 'U22391', airline: 'U2', airport: 'LTN', aircraft: AIRCRAFT_MODELS.A320neo, base: 44, gate: '12', term: 'Main Terminal' },
    { dep: '14:20', arr: '15:40', flightNo: 'U22395', airline: 'U2', airport: 'LTN', aircraft: AIRCRAFT_MODELS.A320neo, base: 46, gate: '14', term: 'Main Terminal' },
    { dep: '18:55', arr: '20:15', flightNo: 'U22399', airline: 'U2', airport: 'LTN', aircraft: AIRCRAFT_MODELS.A320neo, base: 64, gate: '16', term: 'Main Terminal' },
    // Stansted -> Edinburgh
    { dep: '06:50', arr: '08:10', flightNo: 'U23201', airline: 'U2', airport: 'STN', aircraft: AIRCRAFT_MODELS.A320neo, base: 39, gate: '42', term: 'Main Terminal' },
    { dep: '15:10', arr: '16:30', flightNo: 'FR812', airline: 'FR', airport: 'STN', aircraft: AIRCRAFT_MODELS.B737_800, base: 34, gate: '38', term: 'Main Terminal' },
    { dep: '20:25', arr: '21:45', flightNo: 'FR818', airline: 'FR', airport: 'STN', aircraft: AIRCRAFT_MODELS.B737_800, base: 38, gate: '40', term: 'Main Terminal' },
  ];

  lhrEdiSchedules.forEach((s) => {
    flightIdCounter++;
    const origin = getAirportByCode(s.airport)!;
    const dest = getAirportByCode('EDI')!;
    const airline = getAirlineByCode(s.airline)!;
    const taxDuty = 21.00; // UK Domestic APD + Airport charges
    const total = s.base + taxDuty;

    const segment: FlightSegment = {
      flightNumber: s.flightNo,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originName: origin.name,
      originTerminal: s.term,
      destinationCode: dest.code,
      destinationName: dest.name,
      destinationTerminal: 'Main Terminal',
      departureTime: s.dep,
      arrivalTime: s.arr,
      durationMinutes: 85,
      aircraft: s.aircraft,
      status: 'Scheduled',
      delayMinutes: 0,
      gate: s.gate,
      altitudeFt: 34000,
      speedKts: 440,
      co2Kg: Math.round(535 * s.aircraft.co2PerKmKg),
    };

    flights.push({
      id: `FL-${flightIdCounter}`,
      flightNumber: s.flightNo,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originCity: origin.city,
      originName: origin.name,
      originTerminal: s.term,
      destinationCode: dest.code,
      destinationCity: dest.city,
      destinationName: dest.name,
      destinationTerminal: 'Main Terminal',
      departureTime: s.dep,
      arrivalTime: s.arr,
      durationMinutes: 85,
      isDirect: true,
      stops: 0,
      aircraft: s.aircraft,
      baseFare: s.base,
      taxesAndCharges: taxDuty,
      totalPrice: total,
      fareTiers: generateFareTiers(s.base),
      availableSeats: Math.floor(Math.random() * 25) + 4,
      status: 'Scheduled',
      departureDelayMins: 0,
      gate: s.gate,
      co2Kg: Math.round(535 * s.aircraft.co2PerKmKg),
      operatesDays: [1, 2, 3, 4, 5, 6, 7],
      segments: [segment],
    });
  });

  // Reverse Edinburgh -> London
  lhrEdiSchedules.forEach((s, idx) => {
    flightIdCounter++;
    const dest = getAirportByCode(s.airport)!;
    const origin = getAirportByCode('EDI')!;
    const airline = getAirlineByCode(s.airline)!;
    const taxDuty = 21.00;
    const total = s.base + taxDuty;

    // Shift times roughly 2 hours for return leg
    const depHour = (parseInt(s.dep.split(':')[0]) + 2) % 24;
    const depMins = s.dep.split(':')[1];
    const arrHour = (parseInt(s.arr.split(':')[0]) + 2) % 24;
    const arrMins = s.arr.split(':')[1];
    const depTime = `${String(depHour).padStart(2, '0')}:${depMins}`;
    const arrTime = `${String(arrHour).padStart(2, '0')}:${arrMins}`;

    const segment: FlightSegment = {
      flightNumber: `${s.airline}${parseInt(s.flightNo.replace(/[^\d]/g, '')) + 1}`,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originName: origin.name,
      originTerminal: 'Main Terminal',
      destinationCode: dest.code,
      destinationName: dest.name,
      destinationTerminal: s.term,
      departureTime: depTime,
      arrivalTime: arrTime,
      durationMinutes: 85,
      aircraft: s.aircraft,
      status: 'Scheduled',
      delayMinutes: 0,
      gate: `Gate ${10 + (idx % 12)}`,
      co2Kg: Math.round(535 * s.aircraft.co2PerKmKg),
    };

    flights.push({
      id: `FL-${flightIdCounter}`,
      flightNumber: segment.flightNumber,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originCity: origin.city,
      originName: origin.name,
      originTerminal: 'Main Terminal',
      destinationCode: dest.code,
      destinationCity: dest.city,
      destinationName: dest.name,
      destinationTerminal: s.term,
      departureTime: depTime,
      arrivalTime: arrTime,
      durationMinutes: 85,
      isDirect: true,
      stops: 0,
      aircraft: s.aircraft,
      baseFare: s.base,
      taxesAndCharges: taxDuty,
      totalPrice: total,
      fareTiers: generateFareTiers(s.base),
      availableSeats: Math.floor(Math.random() * 25) + 3,
      status: 'Scheduled',
      departureDelayMins: 0,
      gate: segment.gate,
      co2Kg: Math.round(535 * s.aircraft.co2PerKmKg),
      operatesDays: [1, 2, 3, 4, 5, 6, 7],
      segments: [segment],
    });
  });

  // 2. London <-> Glasgow Corridor
  const lonGlaSchedules = [
    { dep: '07:00', arr: '08:25', flightNo: 'BA1472', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 79, gate: 'A10', term: 'Terminal 5' },
    { dep: '08:40', arr: '10:05', flightNo: 'BA1476', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 88, gate: 'A16', term: 'Terminal 5' },
    { dep: '12:10', arr: '13:35', flightNo: 'BA1482', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 72, gate: 'A07', term: 'Terminal 5' },
    { dep: '15:45', arr: '17:10', flightNo: 'BA1488', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A321neo, base: 92, gate: 'A21', term: 'Terminal 5' },
    { dep: '18:25', arr: '19:50', flightNo: 'BA1492', airline: 'BA', airport: 'LHR', aircraft: AIRCRAFT_MODELS.A320neo, base: 106, gate: 'A14', term: 'Terminal 5' },
    { dep: '07:25', arr: '08:50', flightNo: 'BA8720', airline: 'BA', airport: 'LCY', aircraft: AIRCRAFT_MODELS.E190, base: 102, gate: 'Gate 7', term: 'Main Terminal' },
    { dep: '06:30', arr: '08:00', flightNo: 'U2862', airline: 'U2', airport: 'LGW', aircraft: AIRCRAFT_MODELS.A320neo, base: 46, gate: '56', term: 'North Terminal' },
    { dep: '11:50', arr: '13:20', flightNo: 'U2866', airline: 'U2', airport: 'LGW', aircraft: AIRCRAFT_MODELS.A320neo, base: 52, gate: '51', term: 'North Terminal' },
    { dep: '17:35', arr: '19:05', flightNo: 'U2870', airline: 'U2', airport: 'LGW', aircraft: AIRCRAFT_MODELS.A320neo, base: 74, gate: '57', term: 'North Terminal' },
    { dep: '07:40', arr: '09:05', flightNo: 'U22383', airline: 'U2', airport: 'LTN', aircraft: AIRCRAFT_MODELS.A320neo, base: 45, gate: '11', term: 'Main Terminal' },
    { dep: '18:10', arr: '19:35', flightNo: 'U22387', airline: 'U2', airport: 'LTN', aircraft: AIRCRAFT_MODELS.A320neo, base: 62, gate: '15', term: 'Main Terminal' },
    { dep: '08:05', arr: '09:25', flightNo: 'U23215', airline: 'U2', airport: 'STN', aircraft: AIRCRAFT_MODELS.A320neo, base: 41, gate: '44', term: 'Main Terminal' },
  ];

  lonGlaSchedules.forEach((s) => {
    flightIdCounter++;
    const origin = getAirportByCode(s.airport)!;
    const dest = getAirportByCode('GLA')!;
    const airline = getAirlineByCode(s.airline)!;
    const taxDuty = 21.00;
    const total = s.base + taxDuty;

    const segment: FlightSegment = {
      flightNumber: s.flightNo,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originName: origin.name,
      originTerminal: s.term,
      destinationCode: dest.code,
      destinationName: dest.name,
      destinationTerminal: 'Terminal 1',
      departureTime: s.dep,
      arrivalTime: s.arr,
      durationMinutes: 85,
      aircraft: s.aircraft,
      status: 'Scheduled',
      delayMinutes: 0,
      gate: s.gate,
      altitudeFt: 36000,
      speedKts: 445,
      co2Kg: Math.round(550 * s.aircraft.co2PerKmKg),
    };

    flights.push({
      id: `FL-${flightIdCounter}`,
      flightNumber: s.flightNo,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originCity: origin.city,
      originName: origin.name,
      originTerminal: s.term,
      destinationCode: dest.code,
      destinationCity: dest.city,
      destinationName: dest.name,
      destinationTerminal: 'Terminal 1',
      departureTime: s.dep,
      arrivalTime: s.arr,
      durationMinutes: 85,
      isDirect: true,
      stops: 0,
      aircraft: s.aircraft,
      baseFare: s.base,
      taxesAndCharges: taxDuty,
      totalPrice: total,
      fareTiers: generateFareTiers(s.base),
      availableSeats: Math.floor(Math.random() * 22) + 4,
      status: 'Scheduled',
      departureDelayMins: 0,
      gate: s.gate,
      co2Kg: Math.round(550 * s.aircraft.co2PerKmKg),
      operatesDays: [1, 2, 3, 4, 5, 6, 7],
      segments: [segment],
    });
  });

  // 3. London <-> Belfast (BFS & BHD)
  const lonBfsSchedules = [
    { dep: '07:10', arr: '08:30', flightNo: 'BA1414', airline: 'BA', airport: 'LHR', destAirport: 'BHD', aircraft: AIRCRAFT_MODELS.A320neo, base: 76, gate: 'A15', term: 'Terminal 5' },
    { dep: '09:45', arr: '11:05', flightNo: 'BA1418', airline: 'BA', airport: 'LHR', destAirport: 'BHD', aircraft: AIRCRAFT_MODELS.A320neo, base: 84, gate: 'A11', term: 'Terminal 5' },
    { dep: '14:30', arr: '15:50', flightNo: 'BA1422', airline: 'BA', airport: 'LHR', destAirport: 'BHD', aircraft: AIRCRAFT_MODELS.A320neo, base: 71, gate: 'A17', term: 'Terminal 5' },
    { dep: '18:50', arr: '20:10', flightNo: 'BA1426', airline: 'BA', airport: 'LHR', destAirport: 'BHD', aircraft: AIRCRAFT_MODELS.A320neo, base: 98, gate: 'A20', term: 'Terminal 5' },
    { dep: '06:45', arr: '08:05', flightNo: 'EI3680', airline: 'EI', airport: 'LHR', destAirport: 'BHD', aircraft: AIRCRAFT_MODELS.ATR72, base: 68, gate: 'B08', term: 'Terminal 2' },
    { dep: '06:20', arr: '07:40', flightNo: 'U2821', airline: 'U2', airport: 'LGW', destAirport: 'BFS', aircraft: AIRCRAFT_MODELS.A320neo, base: 38, gate: '48', term: 'North Terminal' },
    { dep: '13:05', arr: '14:25', flightNo: 'U2825', airline: 'U2', airport: 'LGW', destAirport: 'BFS', aircraft: AIRCRAFT_MODELS.A320neo, base: 44, gate: '53', term: 'North Terminal' },
    { dep: '17:50', arr: '19:10', flightNo: 'U2829', airline: 'U2', airport: 'LGW', destAirport: 'BFS', aircraft: AIRCRAFT_MODELS.A320neo, base: 65, gate: '59', term: 'North Terminal' },
    { dep: '07:30', arr: '08:45', flightNo: 'FR841', airline: 'FR', airport: 'STN', destAirport: 'BFS', aircraft: AIRCRAFT_MODELS.B737_800, base: 29, gate: '32', term: 'Main Terminal' },
    { dep: '19:15', arr: '20:30', flightNo: 'FR847', airline: 'FR', airport: 'STN', destAirport: 'BFS', aircraft: AIRCRAFT_MODELS.B737_800, base: 36, gate: '35', term: 'Main Terminal' },
    { dep: '08:20', arr: '09:40', flightNo: 'LM862', airline: 'LM', airport: 'LCY', destAirport: 'BHD', aircraft: AIRCRAFT_MODELS.ATR72, base: 94, gate: 'Gate 3', term: 'Main Terminal' },
  ];

  lonBfsSchedules.forEach((s) => {
    flightIdCounter++;
    const origin = getAirportByCode(s.airport)!;
    const dest = getAirportByCode(s.destAirport)!;
    const airline = getAirlineByCode(s.airline)!;
    const taxDuty = 21.00;
    const total = s.base + taxDuty;

    const segment: FlightSegment = {
      flightNumber: s.flightNo,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originName: origin.name,
      originTerminal: s.term,
      destinationCode: dest.code,
      destinationName: dest.name,
      destinationTerminal: 'Main Concourse',
      departureTime: s.dep,
      arrivalTime: s.arr,
      durationMinutes: 80,
      aircraft: s.aircraft,
      status: 'Scheduled',
      delayMinutes: 0,
      gate: s.gate,
      altitudeFt: 32000,
      speedKts: 420,
      co2Kg: Math.round(518 * s.aircraft.co2PerKmKg),
    };

    flights.push({
      id: `FL-${flightIdCounter}`,
      flightNumber: s.flightNo,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originCity: origin.city,
      originName: origin.name,
      originTerminal: s.term,
      destinationCode: dest.code,
      destinationCity: dest.city,
      destinationName: dest.name,
      destinationTerminal: 'Main Concourse',
      departureTime: s.dep,
      arrivalTime: s.arr,
      durationMinutes: 80,
      isDirect: true,
      stops: 0,
      aircraft: s.aircraft,
      baseFare: s.base,
      taxesAndCharges: taxDuty,
      totalPrice: total,
      fareTiers: generateFareTiers(s.base),
      availableSeats: Math.floor(Math.random() * 20) + 5,
      status: 'Scheduled',
      departureDelayMins: 0,
      gate: s.gate,
      co2Kg: Math.round(518 * s.aircraft.co2PerKmKg),
      operatesDays: [1, 2, 3, 4, 5, 6, 7],
      segments: [segment],
    });
  });

  // 4. London <-> Aberdeen, Inverness, Manchester, Newcastle, Newquay, Jersey, Guernsey, Isle of Man
  const otherLondonRoutes = [
    { orig: 'LHR', dest: 'ABZ', dep: '07:35', arr: '09:10', flightNo: 'BA1304', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 86, term: 'Terminal 5', gate: 'A13' },
    { orig: 'LHR', dest: 'ABZ', dep: '13:45', arr: '15:20', flightNo: 'BA1312', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 79, term: 'Terminal 5', gate: 'A09' },
    { orig: 'LHR', dest: 'ABZ', dep: '18:15', arr: '19:50', flightNo: 'BA1316', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 110, term: 'Terminal 5', gate: 'A18' },
    { orig: 'LGW', dest: 'ABZ', dep: '08:20', arr: '10:00', flightNo: 'U2841', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 58, term: 'North Terminal', gate: '52' },
    { orig: 'LCY', dest: 'ABZ', dep: '07:15', arr: '08:55', flightNo: 'LM820', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 118, term: 'Main Terminal', gate: 'Gate 2' },

    { orig: 'LHR', dest: 'INV', dep: '09:40', arr: '11:20', flightNo: 'BA1468', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 92, term: 'Terminal 5', gate: 'A16' },
    { orig: 'LHR', dest: 'INV', dep: '16:50', arr: '18:30', flightNo: 'BA1470', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 104, term: 'Terminal 5', gate: 'A21' },
    { orig: 'LGW', dest: 'INV', dep: '06:55', arr: '08:35', flightNo: 'U2853', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 52, term: 'North Terminal', gate: '55' },
    { orig: 'LTN', dest: 'INV', dep: '13:30', arr: '15:10', flightNo: 'U22405', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 49, term: 'Main Terminal', gate: '18' },

    { orig: 'LHR', dest: 'NCL', dep: '07:05', arr: '08:15', flightNo: 'BA1324', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 64, term: 'Terminal 5', gate: 'A06' },
    { orig: 'LHR', dest: 'NCL', dep: '13:10', arr: '14:20', flightNo: 'BA1328', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 58, term: 'Terminal 5', gate: 'A12' },
    { orig: 'LHR', dest: 'NCL', dep: '19:40', arr: '20:50', flightNo: 'BA1336', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 78, term: 'Terminal 5', gate: 'A15' },

    { orig: 'LHR', dest: 'MAN', dep: '06:45', arr: '07:45', flightNo: 'BA1382', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 68, term: 'Terminal 5', gate: 'A08' },
    { orig: 'LHR', dest: 'MAN', dep: '11:20', arr: '12:20', flightNo: 'BA1388', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 62, term: 'Terminal 5', gate: 'A14' },
    { orig: 'LHR', dest: 'MAN', dep: '16:30', arr: '17:30', flightNo: 'BA1394', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 84, term: 'Terminal 5', gate: 'A17' },
    { orig: 'LHR', dest: 'MAN', dep: '20:05', arr: '21:05', flightNo: 'BA1402', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 72, term: 'Terminal 5', gate: 'A11' },

    { orig: 'LGW', dest: 'NQY', dep: '08:40', arr: '09:55', flightNo: 'T3412', airline: 'T3', aircraft: AIRCRAFT_MODELS.ATR72, base: 54, term: 'South Terminal', gate: '22' },
    { orig: 'LGW', dest: 'NQY', dep: '17:15', arr: '18:30', flightNo: 'T3418', airline: 'T3', aircraft: AIRCRAFT_MODELS.ATR72, base: 68, term: 'South Terminal', gate: '24' },
    { orig: 'LGW', dest: 'NQY', dep: '12:30', arr: '13:45', flightNo: 'U2835', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 48, term: 'North Terminal', gate: '50' },

    { orig: 'LHR', dest: 'JER', dep: '08:20', arr: '09:20', flightNo: 'BA2770', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, base: 64, term: 'Terminal 5', gate: 'A04' },
    { orig: 'LGW', dest: 'JER', dep: '07:00', arr: '08:00', flightNo: 'U2891', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 39, term: 'North Terminal', gate: '53' },
    { orig: 'LGW', dest: 'GCI', dep: '08:15', arr: '09:25', flightNo: 'GR671', airline: 'GR', aircraft: AIRCRAFT_MODELS.ATR72, base: 56, term: 'South Terminal', gate: '26' },
    { orig: 'LCY', dest: 'IOM', dep: '08:00', arr: '09:15', flightNo: 'LM612', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 84, term: 'Main Terminal', gate: 'Gate 5' },
    { orig: 'LGW', dest: 'IOM', dep: '14:10', arr: '15:25', flightNo: 'U2857', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 46, term: 'North Terminal', gate: '58' },
  ];

  otherLondonRoutes.forEach((s) => {
    flightIdCounter++;
    const origin = getAirportByCode(s.orig)!;
    const dest = getAirportByCode(s.dest)!;
    const airline = getAirlineByCode(s.airline)!;
    const taxDuty = 18.00;
    const total = s.base + taxDuty;

    const segment: FlightSegment = {
      flightNumber: s.flightNo,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originName: origin.name,
      originTerminal: s.term,
      destinationCode: dest.code,
      destinationName: dest.name,
      destinationTerminal: 'Main Terminal',
      departureTime: s.dep,
      arrivalTime: s.arr,
      durationMinutes: 70,
      aircraft: s.aircraft,
      status: 'Scheduled',
      delayMinutes: 0,
      gate: s.gate,
      co2Kg: 48,
    };

    flights.push({
      id: `FL-${flightIdCounter}`,
      flightNumber: s.flightNo,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originCity: origin.city,
      originName: origin.name,
      originTerminal: s.term,
      destinationCode: dest.code,
      destinationCity: dest.city,
      destinationName: dest.name,
      destinationTerminal: 'Main Terminal',
      departureTime: s.dep,
      arrivalTime: s.arr,
      durationMinutes: 70,
      isDirect: true,
      stops: 0,
      aircraft: s.aircraft,
      baseFare: s.base,
      taxesAndCharges: taxDuty,
      totalPrice: total,
      fareTiers: generateFareTiers(s.base),
      availableSeats: Math.floor(Math.random() * 20) + 4,
      status: 'Scheduled',
      departureDelayMins: 0,
      gate: s.gate,
      co2Kg: 48,
      operatesDays: [1, 2, 3, 4, 5, 6, 7],
      segments: [segment],
    });
  });

  // 5. Cross-Country Regional Domestic Flights (Manchester, Birmingham, Bristol, Scotland Highlands)
  const regionalSchedules = [
    // Manchester <-> Aberdeen
    { orig: 'MAN', dest: 'ABZ', dep: '07:15', arr: '08:25', flightNo: 'LM521', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 68 },
    { orig: 'MAN', dest: 'ABZ', dep: '14:30', arr: '15:40', flightNo: 'LM525', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 74 },
    { orig: 'MAN', dest: 'ABZ', dep: '18:40', arr: '19:50', flightNo: 'LM529', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 82 },
    // Manchester <-> Belfast
    { orig: 'MAN', dest: 'BFS', dep: '06:50', arr: '07:45', flightNo: 'U2131', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 32 },
    { orig: 'MAN', dest: 'BFS', dep: '12:15', arr: '13:10', flightNo: 'U2135', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 38 },
    { orig: 'MAN', dest: 'BFS', dep: '18:30', arr: '19:25', flightNo: 'FR552', airline: 'FR', aircraft: AIRCRAFT_MODELS.B737_800, base: 28 },
    { orig: 'MAN', dest: 'BHD', dep: '08:10', arr: '09:05', flightNo: 'EI3610', airline: 'EI', aircraft: AIRCRAFT_MODELS.ATR72, base: 49 },
    // Manchester <-> Isle of Man
    { orig: 'MAN', dest: 'IOM', dep: '08:00', arr: '08:45', flightNo: 'LM672', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 52 },
    { orig: 'MAN', dest: 'IOM', dep: '16:45', arr: '17:30', flightNo: 'LM676', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 58 },
    // Birmingham <-> Edinburgh
    { orig: 'BHX', dest: 'EDI', dep: '06:40', arr: '07:50', flightNo: 'U2281', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 44 },
    { orig: 'BHX', dest: 'EDI', dep: '13:50', arr: '15:00', flightNo: 'LM412', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 62 },
    { orig: 'BHX', dest: 'EDI', dep: '18:15', arr: '19:25', flightNo: 'U2285', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 56 },
    // Birmingham <-> Glasgow
    { orig: 'BHX', dest: 'GLA', dep: '07:10', arr: '08:20', flightNo: 'U2291', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 46 },
    { orig: 'BHX', dest: 'GLA', dep: '17:40', arr: '18:50', flightNo: 'U2295', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 58 },
    // Birmingham <-> Belfast
    { orig: 'BHX', dest: 'BFS', dep: '07:05', arr: '08:05', flightNo: 'U2191', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 34 },
    { orig: 'BHX', dest: 'BHD', dep: '11:30', arr: '12:30', flightNo: 'EI3632', airline: 'EI', aircraft: AIRCRAFT_MODELS.ATR72, base: 48 },
    { orig: 'BHX', dest: 'BFS', dep: '19:20', arr: '20:20', flightNo: 'FR664', airline: 'FR', aircraft: AIRCRAFT_MODELS.B737_800, base: 31 },
    // Birmingham <-> Jersey & Guernsey
    { orig: 'BHX', dest: 'JER', dep: '09:15', arr: '10:20', flightNo: 'SI412', airline: 'SI', aircraft: AIRCRAFT_MODELS.ATR72, base: 64 },
    { orig: 'BHX', dest: 'GCI', dep: '11:45', arr: '12:55', flightNo: 'GR684', airline: 'GR', aircraft: AIRCRAFT_MODELS.ATR72, base: 69 },
    // Bristol <-> Edinburgh
    { orig: 'BRS', dest: 'EDI', dep: '06:30', arr: '07:45', flightNo: 'U2421', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 45 },
    { orig: 'BRS', dest: 'EDI', dep: '14:15', arr: '15:30', flightNo: 'U2425', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 52 },
    { orig: 'BRS', dest: 'EDI', dep: '19:00', arr: '20:15', flightNo: 'U2429', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 68 },
    // Bristol <-> Glasgow
    { orig: 'BRS', dest: 'GLA', dep: '07:00', arr: '08:15', flightNo: 'U2431', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 48 },
    { orig: 'BRS', dest: 'GLA', dep: '18:20', arr: '19:35', flightNo: 'U2437', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 64 },
    // Bristol <-> Belfast
    { orig: 'BRS', dest: 'BFS', dep: '07:15', arr: '08:20', flightNo: 'U2451', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 38 },
    { orig: 'BRS', dest: 'BHD', dep: '16:10', arr: '17:15', flightNo: 'EI3654', airline: 'EI', aircraft: AIRCRAFT_MODELS.ATR72, base: 52 },
    // Bristol <-> Newcastle
    { orig: 'BRS', dest: 'NCL', dep: '08:45', arr: '09:50', flightNo: 'LM712', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 66 },
    // Newcastle <-> Belfast
    { orig: 'NCL', dest: 'BFS', dep: '07:30', arr: '08:25', flightNo: 'U2561', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 36 },
    { orig: 'NCL', dest: 'BFS', dep: '17:45', arr: '18:40', flightNo: 'U2565', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, base: 48 },
    // Highlands & Islands (Scotland Lifeline Network)
    { orig: 'EDI', dest: 'KOI', dep: '08:30', arr: '09:50', flightNo: 'LM342', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 88 },
    { orig: 'EDI', dest: 'KOI', dep: '16:20', arr: '17:40', flightNo: 'LM348', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 94 },
    { orig: 'EDI', dest: 'LSI', dep: '08:00', arr: '09:30', flightNo: 'LM372', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 95 },
    { orig: 'EDI', dest: 'LSI', dep: '15:45', arr: '17:15', flightNo: 'LM376', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 102 },
    { orig: 'GLA', dest: 'SYY', dep: '08:45', arr: '09:45', flightNo: 'LM472', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 82 },
    { orig: 'GLA', dest: 'SYY', dep: '16:30', arr: '17:30', flightNo: 'LM478', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 89 },
    { orig: 'GLA', dest: 'INV', dep: '09:10', arr: '10:00', flightNo: 'LM231', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, base: 58 },
  ];

  regionalSchedules.forEach((s) => {
    flightIdCounter++;
    const origin = getAirportByCode(s.orig);
    const dest = getAirportByCode(s.dest);
    if (!origin || !dest) return;
    const airline = getAirlineByCode(s.airline)!;
    const taxDuty = 16.00;
    const total = s.base + taxDuty;

    const segment: FlightSegment = {
      flightNumber: s.flightNo,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originName: origin.name,
      originTerminal: origin.terminals[0] || 'Main Terminal',
      destinationCode: dest.code,
      destinationName: dest.name,
      destinationTerminal: dest.terminals[0] || 'Main Terminal',
      departureTime: s.dep,
      arrivalTime: s.arr,
      durationMinutes: 70,
      aircraft: s.aircraft,
      status: 'Scheduled',
      delayMinutes: 0,
      gate: `Gate ${Math.floor(Math.random() * 15) + 1}`,
      co2Kg: 45,
    };

    flights.push({
      id: `FL-${flightIdCounter}`,
      flightNumber: s.flightNo,
      airlineCode: airline.code,
      airlineName: airline.name,
      originCode: origin.code,
      originCity: origin.city,
      originName: origin.name,
      originTerminal: origin.terminals[0] || 'Main Terminal',
      destinationCode: dest.code,
      destinationCity: dest.city,
      destinationName: dest.name,
      destinationTerminal: dest.terminals[0] || 'Main Terminal',
      departureTime: s.dep,
      arrivalTime: s.arr,
      durationMinutes: 70,
      isDirect: true,
      stops: 0,
      aircraft: s.aircraft,
      baseFare: s.base,
      taxesAndCharges: taxDuty,
      totalPrice: total,
      fareTiers: generateFareTiers(s.base),
      availableSeats: Math.floor(Math.random() * 18) + 3,
      status: 'Scheduled',
      departureDelayMins: 0,
      gate: segment.gate,
      co2Kg: 45,
      operatesDays: [1, 2, 3, 4, 5, 6, 7],
      segments: [segment],
    });
  });

  // 6. Connecting Flights (e.g. London -> Manchester -> Aberdeen, Southampton/Cardiff -> London -> Inverness)
  const connectingRoutes = [
    {
      seg1: { orig: 'LHR', dest: 'MAN', dep: '06:45', arr: '07:45', flightNo: 'BA1382', airline: 'BA', aircraft: AIRCRAFT_MODELS.A320neo, term: 'Terminal 5' },
      seg2: { orig: 'MAN', dest: 'ABZ', dep: '09:15', arr: '10:25', flightNo: 'LM523', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, term: 'Terminal 3' },
      base: 115,
      isProtected: true,
    },
    {
      seg1: { orig: 'LGW', dest: 'EDI', dep: '06:15', arr: '07:45', flightNo: 'U2802', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, term: 'North Terminal' },
      seg2: { orig: 'EDI', dest: 'KOI', dep: '09:40', arr: '11:00', flightNo: 'LM344', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, term: 'Main Terminal' },
      base: 128,
      isProtected: false, // Self-transfer
    },
    {
      seg1: { orig: 'LHR', dest: 'EDI', dep: '08:15', arr: '09:40', flightNo: 'BA1436', airline: 'BA', aircraft: AIRCRAFT_MODELS.A321neo, term: 'Terminal 5' },
      seg2: { orig: 'EDI', dest: 'LSI', dep: '11:20', arr: '12:50', flightNo: 'LM374', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, term: 'Main Terminal' },
      base: 142,
      isProtected: true,
    },
    {
      seg1: { orig: 'BRS', dest: 'EDI', dep: '06:30', arr: '07:45', flightNo: 'U2421', airline: 'U2', aircraft: AIRCRAFT_MODELS.A320neo, term: 'Main Terminal' },
      seg2: { orig: 'EDI', dest: 'KOI', dep: '09:40', arr: '11:00', flightNo: 'LM344', airline: 'LM', aircraft: AIRCRAFT_MODELS.ATR72, term: 'Main Terminal' },
      base: 134,
      isProtected: false,
    }
  ];

  connectingRoutes.forEach((c) => {
    flightIdCounter++;
    const origAirport = getAirportByCode(c.seg1.orig)!;
    const midAirport = getAirportByCode(c.seg1.dest)!;
    const destAirport = getAirportByCode(c.seg2.dest)!;
    const air1 = getAirlineByCode(c.seg1.airline)!;
    const air2 = getAirlineByCode(c.seg2.airline)!;

    const seg1: FlightSegment = {
      flightNumber: c.seg1.flightNo,
      airlineCode: air1.code,
      airlineName: air1.name,
      originCode: origAirport.code,
      originName: origAirport.name,
      originTerminal: c.seg1.term,
      destinationCode: midAirport.code,
      destinationName: midAirport.name,
      destinationTerminal: 'Terminal 1',
      departureTime: c.seg1.dep,
      arrivalTime: c.seg1.arr,
      durationMinutes: 60,
      aircraft: c.seg1.aircraft,
      status: 'Scheduled',
      delayMinutes: 0,
      co2Kg: 35,
    };

    const seg2: FlightSegment = {
      flightNumber: c.seg2.flightNo,
      airlineCode: air2.code,
      airlineName: air2.name,
      originCode: midAirport.code,
      originName: midAirport.name,
      originTerminal: c.seg2.term,
      destinationCode: destAirport.code,
      destinationName: destAirport.name,
      destinationTerminal: 'Main Terminal',
      departureTime: c.seg2.dep,
      arrivalTime: c.seg2.arr,
      durationMinutes: 70,
      aircraft: c.seg2.aircraft,
      status: 'Scheduled',
      delayMinutes: 0,
      co2Kg: 42,
    };

    const totalDuration = 220; // 3h 40m
    const taxDuty = 24.00;
    const total = c.base + taxDuty;

    flights.push({
      id: `FL-${flightIdCounter}`,
      flightNumber: `${c.seg1.flightNo} / ${c.seg2.flightNo}`,
      airlineCode: air1.code,
      airlineName: air1.code === air2.code ? air1.name : `${air1.name} + ${air2.name}`,
      originCode: origAirport.code,
      originCity: origAirport.city,
      originName: origAirport.name,
      originTerminal: c.seg1.term,
      destinationCode: destAirport.code,
      destinationCity: destAirport.city,
      destinationName: destAirport.name,
      destinationTerminal: 'Main Terminal',
      departureTime: c.seg1.dep,
      arrivalTime: c.seg2.arr,
      durationMinutes: totalDuration,
      isDirect: false,
      stops: 1,
      stopoverAirportCode: midAirport.code,
      stopoverAirportName: midAirport.name,
      stopoverDurationMins: 90,
      isProtectedConnection: c.isProtected,
      requiresAirportTransfer: false,
      aircraft: c.seg1.aircraft,
      baseFare: c.base,
      taxesAndCharges: taxDuty,
      totalPrice: total,
      fareTiers: generateFareTiers(c.base),
      availableSeats: 6,
      status: 'Scheduled',
      departureDelayMins: 0,
      gate: `Gate ${Math.floor(Math.random() * 12) + 1}`,
      co2Kg: 77,
      operatesDays: [1, 2, 3, 4, 5, 6, 7],
      segments: [seg1, seg2],
    });
  });

  return flights;
}

// Extract timetable slots from flight schedules
export function getTimetableForRoute(originCode: string, destCode: string, dayOfWeek: number = 1): TimetableSlot[] {
  const allFlights = generateSyntheticFlightDatabase();
  const isLonOrigin = originCode === 'LON';
  const isLonDest = destCode === 'LON';

  return allFlights
    .filter(f => {
      const matchOrigin = isLonOrigin ? LONDON_AIRPORT_CODES.includes(f.originCode) : f.originCode === originCode;
      const matchDest = isLonDest ? LONDON_AIRPORT_CODES.includes(f.destinationCode) : f.destinationCode === destCode;
      return matchOrigin && matchDest && f.isDirect;
    })
    .map(f => ({
      flightNumber: f.flightNumber,
      airlineCode: f.airlineCode,
      airlineName: f.airlineName,
      originCode: f.originCode,
      destinationCode: f.destinationCode,
      departureTime: f.departureTime,
      arrivalTime: f.arrivalTime,
      durationMinutes: f.durationMinutes,
      aircraftModel: f.aircraft.model,
      operatingDays: f.operatesDays,
      frequencyWeekly: 7,
      typicalOnTimePct: Math.floor(Math.random() * 12) + 84,
      baseFareGbp: f.baseFare,
    }))
    .sort((a, b) => a.departureTime.localeCompare(b.departureTime));
}
