import { Flight, PriceAlert, SavedJourney, SearchFilterState, SearchQuery, TimetableSlot } from './types';
import { generateSyntheticFlightDatabase, MAJOR_ROUTES } from './data';
import { LONDON_AIRPORT_CODES, UK_AIRPORTS } from './airports';

export interface SimulationEngineState {
  flights: Flight[];
  demandMultiplier: number; // 1.0 default
  weatherDelayAirports: string[];
  cancelledFlightNumbers: string[];
  delayedFlightMap: Record<string, { mins: number; reason: string }>;
  searchCount: number;
  lastQueryLatencyMs: number;
  cacheHitCount: number;
  engineStartedAt: number;
}

let globalSimulationState: SimulationEngineState | null = null;

export function getSimulationState(): SimulationEngineState {
  if (typeof window === 'undefined') {
    return {
      flights: generateSyntheticFlightDatabase(),
      demandMultiplier: 1.0,
      weatherDelayAirports: [],
      cancelledFlightNumbers: [],
      delayedFlightMap: {},
      searchCount: 1420,
      lastQueryLatencyMs: 19,
      cacheHitCount: 948,
      engineStartedAt: Date.now() - 3600000 * 24,
    };
  }

  if (!globalSimulationState) {
    const raw = localStorage.getItem('british_sky_simulation_v2');
    if (raw) {
      try {
        globalSimulationState = JSON.parse(raw);
      } catch {
        globalSimulationState = null;
      }
    }

    if (!globalSimulationState) {
      globalSimulationState = {
        flights: generateSyntheticFlightDatabase(),
        demandMultiplier: 1.0,
        weatherDelayAirports: [],
        cancelledFlightNumbers: [],
        delayedFlightMap: {
          'BA1456': { mins: 25, reason: 'Air traffic control slot restriction in London airspace' },
          'U2812': { mins: 15, reason: 'Late inbound aircraft arrival from Belfast' },
        },
        searchCount: 1420,
        lastQueryLatencyMs: 18,
        cacheHitCount: 948,
        engineStartedAt: Date.now() - 3600000 * 24,
      };
      saveSimulationState(globalSimulationState);
    }
  }

  return globalSimulationState;
}

export function saveSimulationState(state: SimulationEngineState): void {
  globalSimulationState = state;
  if (typeof window !== 'undefined') {
    localStorage.setItem('british_sky_simulation_v2', JSON.stringify(state));
  }
}

// Search Flight Engine
export function searchFlights(query: SearchQuery): { results: Flight[]; searchLatencyMs: number } {
  const startTime = Date.now();
  const state = getSimulationState();
  const allFlights = state.flights.length > 0 ? state.flights : generateSyntheticFlightDatabase();

  const isLonOrigin = query.originCode === 'LON';
  const isLonDest = query.destinationCode === 'LON';

  // Deterministic price curve modifier based on search date
  const searchDateObj = new Date(query.departDate || '2026-10-18');
  const dayOfWeek = searchDateObj.getDay(); // 0 = Sun, 5 = Fri, 6 = Sat
  const isWeekend = dayOfWeek === 0 || dayOfWeek === 5 || dayOfWeek === 6;
  const weekendFactor = isWeekend ? 1.15 : 1.0;
  const multiplier = state.demandMultiplier * weekendFactor;

  const matched = allFlights
    .filter(f => {
      const matchOrigin = isLonOrigin ? LONDON_AIRPORT_CODES.includes(f.originCode) : f.originCode === query.originCode;
      const matchDest = isLonDest ? LONDON_AIRPORT_CODES.includes(f.destinationCode) : f.destinationCode === query.destinationCode;
      if (query.directOnly && !f.isDirect) return false;
      return matchOrigin && matchDest;
    })
    .map(f => {
      const customDelay = state.delayedFlightMap[f.flightNumber];
      const isCancelled = state.cancelledFlightNumbers.includes(f.flightNumber);
      const isOriginWeatherImpacted = state.weatherDelayAirports.includes(f.originCode);

      let flightStatus = f.status;
      let delayMins = f.departureDelayMins;

      if (isCancelled) {
        flightStatus = 'Cancelled';
      } else if (customDelay) {
        flightStatus = 'Delayed';
        delayMins = customDelay.mins;
      } else if (isOriginWeatherImpacted) {
        flightStatus = 'Delayed';
        delayMins = 35;
      }

      // Dynamic price calculation
      const calculatedBase = Math.round(f.baseFare * multiplier);
      const calculatedTotal = calculatedBase + f.taxesAndCharges;

      const adjustedTiers = f.fareTiers.map(tier => {
        let tierPrice = calculatedTotal;
        if (tier.type === 'economy_standard') tierPrice = calculatedTotal + 24;
        if (tier.type === 'economy_flex') tierPrice = calculatedTotal + 58;
        if (tier.type === 'club_domestic') tierPrice = Math.round(calculatedTotal * 1.85 + 35);
        return { ...tier, price: tierPrice };
      });

      return {
        ...f,
        baseFare: calculatedBase,
        totalPrice: calculatedTotal,
        fareTiers: adjustedTiers,
        status: flightStatus,
        departureDelayMins: delayMins,
      };
    });

  const latency = Math.floor(Math.random() * 10) + 14; // 14-24ms financial-grade response
  state.searchCount += 1;
  state.cacheHitCount += 1;
  state.lastQueryLatencyMs = latency;
  saveSimulationState(state);

  return { results: matched, searchLatencyMs: latency };
}

// Filter and Sort Flights
export function applyFiltersAndSort(flights: Flight[], filters: SearchFilterState): Flight[] {
  let filtered = flights.filter(f => {
    if (filters.directOnly && !f.isDirect) return false;
    if (f.totalPrice > filters.maxPrice) return false;
    if (f.durationMinutes > filters.maxDurationMins) return false;

    const depHour = parseInt(f.departureTime.split(':')[0], 10);
    if (depHour < filters.minDepartureHour || depHour > filters.maxDepartureHour) return false;

    if (filters.selectedAirlines.length > 0 && !filters.selectedAirlines.includes(f.airlineCode)) {
      return false;
    }

    if (filters.selectedDepartureAirports.length > 0 && !filters.selectedDepartureAirports.includes(f.originCode)) {
      return false;
    }

    if (filters.selectedArrivalAirports.length > 0 && !filters.selectedArrivalAirports.includes(f.destinationCode)) {
      return false;
    }

    if (filters.hasBaggageIncluded) {
      const hasBagIncluded = f.airlineCode === 'BA' || f.airlineCode === 'LM' || f.airlineCode === 'T3';
      if (!hasBagIncluded) return false;
    }

    return true;
  });

  // Sort
  filtered.sort((a, b) => {
    switch (filters.sortBy) {
      case 'price_low':
        return a.totalPrice - b.totalPrice;
      case 'duration_fast':
        return a.durationMinutes - b.durationMinutes;
      case 'departure_early':
        return a.departureTime.localeCompare(b.departureTime);
      case 'departure_late':
        return b.departureTime.localeCompare(a.departureTime);
      case 'fewest_stops':
        return a.stops - b.stops || a.totalPrice - b.totalPrice;
      case 'recommended':
      default:
        // Balanced score: Direct flights prioritized, then price/duration efficiency
        const scoreA = (a.isDirect ? 0 : 200) + a.totalPrice + a.durationMinutes * 0.4;
        const scoreB = (b.isDirect ? 0 : 200) + b.totalPrice + b.durationMinutes * 0.4;
        return scoreA - scoreB;
    }
  });

  return filtered;
}

// Price calendar matrix generator (7 or 14 days around target date)
export interface DatePricePoint {
  date: string; // YYYY-MM-DD
  dayLabel: string; // "Fri 18 Oct"
  lowestPriceGbp: number;
  flightCount: number;
  isCheapest: boolean;
  isTargetDate: boolean;
}

export function generateDatePriceCalendar(originCode: string, destCode: string, targetDateStr: string): DatePricePoint[] {
  const target = new Date(targetDateStr || '2026-10-18');
  const points: DatePricePoint[] = [];

  const baseRoutePrice = MAJOR_ROUTES.find(
    r => (r.originCode === originCode || (originCode === 'LON' && r.originCode === 'LON')) && r.destinationCode === destCode
  )?.lowestPriceGbp || 54;

  let minPrice = Infinity;

  for (let offset = -3; offset <= 3; offset++) {
    const d = new Date(target);
    d.setDate(target.getDate() + offset);
    const dateIso = d.toISOString().split('T')[0];
    const dayOfWeek = d.getDay(); // 0 = Sun, 5 = Fri, 6 = Sat

    // Deterministic fluctuations
    let multiplier = 1.0;
    if (dayOfWeek === 5) multiplier = 1.25; // Friday peak
    if (dayOfWeek === 0) multiplier = 1.18; // Sunday peak
    if (dayOfWeek === 2 || dayOfWeek === 3) multiplier = 0.88; // Tuesday/Wednesday bargain

    // Add pseudo-random deterministic variation based on date char codes
    const dateHash = dateIso.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
    const varOffset = (dateHash % 14) - 7;

    const price = Math.round(baseRoutePrice * multiplier + varOffset);
    if (price < minPrice) minPrice = price;

    const dayName = d.toLocaleDateString('en-GB', { weekday: 'short' });
    const dayNum = d.getDate();
    const monthName = d.toLocaleDateString('en-GB', { month: 'short' });

    points.push({
      date: dateIso,
      dayLabel: `${dayName} ${dayNum} ${monthName}`,
      lowestPriceGbp: price,
      flightCount: Math.floor((dateHash % 12) + 18),
      isCheapest: false,
      isTargetDate: offset === 0,
    });
  }

  points.forEach(p => {
    if (p.lowestPriceGbp === minPrice) p.isCheapest = true;
  });

  return points;
}

// "Where Can I Fly?" destination reach calculator
export interface DirectReachDestination {
  airport: (typeof UK_AIRPORTS)[0];
  lowestPriceGbp: number;
  flightDurationMins: number;
  dailyFrequency: number;
  airlines: string[];
}

export function getDirectDestinationsFrom(airportCode: string): DirectReachDestination[] {
  const allFlights = generateSyntheticFlightDatabase();
  const isLonOrigin = airportCode === 'LON' || LONDON_AIRPORT_CODES.includes(airportCode);

  const matched = allFlights.filter(f => {
    if (!f.isDirect) return false;
    return isLonOrigin ? LONDON_AIRPORT_CODES.includes(f.originCode) : f.originCode === airportCode;
  });

  const destMap = new Map<string, DirectReachDestination>();

  matched.forEach(f => {
    if (isLonOrigin && LONDON_AIRPORT_CODES.includes(f.destinationCode)) return;
    if (f.destinationCode === airportCode) return;

    const existing = destMap.get(f.destinationCode);
    const destAirport = UK_AIRPORTS.find(a => a.code === f.destinationCode);
    if (!destAirport) return;

    if (!existing) {
      destMap.set(f.destinationCode, {
        airport: destAirport,
        lowestPriceGbp: f.totalPrice,
        flightDurationMins: f.durationMinutes,
        dailyFrequency: 1,
        airlines: [f.airlineName],
      });
    } else {
      existing.dailyFrequency += 1;
      if (f.totalPrice < existing.lowestPriceGbp) {
        existing.lowestPriceGbp = f.totalPrice;
      }
      if (!existing.airlines.includes(f.airlineName)) {
        existing.airlines.push(f.airlineName);
      }
    }
  });

  return Array.from(destMap.values()).sort((a, b) => a.lowestPriceGbp - b.lowestPriceGbp);
}

// User local storage helpers
export function getSavedJourneys(): SavedJourney[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem('british_sky_saved_journeys');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function saveJourney(item: SavedJourney): void {
  if (typeof window === 'undefined') return;
  const current = getSavedJourneys().filter(j => j.id !== item.id);
  current.unshift(item);
  localStorage.setItem('british_sky_saved_journeys', JSON.stringify(current));
}

export function removeSavedJourney(id: string): void {
  if (typeof window === 'undefined') return;
  const current = getSavedJourneys().filter(j => j.id !== id);
  localStorage.setItem('british_sky_saved_journeys', JSON.stringify(current));
}

export function getPriceAlerts(): PriceAlert[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem('british_sky_price_alerts');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

export function createPriceAlert(alert: PriceAlert): void {
  if (typeof window === 'undefined') return;
  const current = getPriceAlerts();
  current.unshift(alert);
  localStorage.setItem('british_sky_price_alerts', JSON.stringify(current));
}

export function removePriceAlert(id: string): void {
  if (typeof window === 'undefined') return;
  const current = getPriceAlerts().filter(a => a.id !== id);
  localStorage.setItem('british_sky_price_alerts', JSON.stringify(current));
}
