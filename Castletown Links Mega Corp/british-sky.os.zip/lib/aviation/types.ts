export type CabinClass = 'economy' | 'economy_flex' | 'business';

export type FlightStatusType =
  | 'Scheduled'
  | 'CheckIn'
  | 'Boarding'
  | 'Departed'
  | 'Airborne'
  | 'Approaching'
  | 'Landed'
  | 'Delayed'
  | 'Cancelled';

export interface Airport {
  code: string;
  name: string;
  city: string;
  region: 'London' | 'England North' | 'England Midlands' | 'England South' | 'Scotland' | 'Northern Ireland' | 'Wales' | 'Crown Dependencies';
  country: 'United Kingdom' | 'Isle of Man' | 'Jersey' | 'Guernsey';
  latitude: number;
  longitude: number;
  terminals: string[];
  hubAirlines: string[];
  groundTransport: {
    rail: string;
    underground?: string;
    bus: string;
    cityCenterTimeMins: number;
    transferCostEstGbp: number;
  };
  securityWaitMins: number;
  runways: number;
  annualPassengersM: number;
  isLondonCluster?: boolean;
}

export interface Airline {
  code: string;
  name: string;
  callsign: string;
  country: string;
  logoText: string;
  brandColor: string;
  accentColor: string;
  hubs: string[];
  fleetOverview: string;
  baggagePolicy: {
    cabinBagIncluded: string;
    holdBagCostFrom: number;
    maxCabinDimensions: string;
  };
  punctualityScorePct: number;
  domesticRoutesCount: number;
  website: string;
}

export interface Aircraft {
  model: string;
  manufacturer: 'Airbus' | 'Boeing' | 'ATR' | 'Embraer' | 'De Havilland' | 'Viking Air';
  capacity: number;
  cruisingSpeedKmh: number;
  cruisingAltitudeFt: number;
  co2PerKmKg: number;
  seatPitchInches: number;
}

export interface FareTier {
  type: 'economy_light' | 'economy_standard' | 'economy_flex' | 'club_domestic';
  title: string;
  price: number;
  cabinBag: string;
  checkedBag: string;
  seatSelection: string;
  changes: string;
  refunds: string;
  boardingPriority: 'Standard' | 'Group 3' | 'Group 1' | 'Priority';
  loungeAccess: boolean;
  tierDescription: string;
}

export interface FlightSegment {
  flightNumber: string;
  airlineCode: string;
  airlineName: string;
  originCode: string;
  originName: string;
  originTerminal?: string;
  destinationCode: string;
  destinationName: string;
  destinationTerminal?: string;
  departureTime: string; // e.g. "07:20"
  arrivalTime: string;   // e.g. "08:45"
  durationMinutes: number;
  aircraft: Aircraft;
  status: FlightStatusType;
  delayMinutes: number;
  gate?: string;
  altitudeFt?: number;
  speedKts?: number;
  co2Kg: number;
}

export interface Flight {
  id: string;
  flightNumber: string;
  airlineCode: string;
  airlineName: string;
  originCode: string;
  originCity: string;
  originName: string;
  originTerminal?: string;
  destinationCode: string;
  destinationCity: string;
  destinationName: string;
  destinationTerminal?: string;
  departureTime: string; // "07:20"
  arrivalTime: string;   // "08:45"
  durationMinutes: number;
  isDirect: boolean;
  stops: number;
  stopoverAirportCode?: string;
  stopoverAirportName?: string;
  stopoverDurationMins?: number;
  isProtectedConnection?: boolean;
  requiresAirportTransfer?: boolean;
  airportTransferNote?: string;
  aircraft: Aircraft;
  baseFare: number;
  taxesAndCharges: number;
  totalPrice: number;
  fareTiers: FareTier[];
  availableSeats: number;
  status: FlightStatusType;
  departureDelayMins: number;
  gate?: string;
  co2Kg: number;
  operatesDays: number[]; // 1 = Mon, 7 = Sun
  segments: FlightSegment[];
}

export interface TimetableSlot {
  flightNumber: string;
  airlineCode: string;
  airlineName: string;
  originCode: string;
  destinationCode: string;
  departureTime: string;
  arrivalTime: string;
  durationMinutes: number;
  aircraftModel: string;
  operatingDays: number[];
  frequencyWeekly: number;
  typicalOnTimePct: number;
  baseFareGbp: number;
}

export interface RouteInformation {
  id: string;
  originCode: string;
  originCity: string;
  destinationCode: string;
  destinationCity: string;
  distanceKm: number;
  typicalDurationMins: number;
  directFlightsPerDay: number;
  airlinesOperating: string[];
  firstDeparture: string;
  lastDeparture: string;
  lowestPriceGbp: number;
  avgPriceGbp: number;
  co2FlightKg: number;
  co2RailKg: number;
  railDurationMins: number;
  railOperator: string;
}

export interface PriceAlert {
  id: string;
  originCode: string;
  destinationCode: string;
  targetPriceGbp: number;
  currentLowestPriceGbp: number;
  date: string;
  createdAt: string;
  passengerEmail: string;
  trend: 'falling' | 'stable' | 'rising';
}

export interface SavedJourney {
  id: string;
  flightId: string;
  originCode: string;
  destinationCode: string;
  date: string;
  fareSelected: string;
  price: number;
  savedAt: string;
  flightNumber: string;
  airlineName: string;
  departureTime: string;
}

export interface SearchQuery {
  originCode: string; // 'LON' for all London or specific airport code
  destinationCode: string;
  departDate: string; // YYYY-MM-DD
  returnDate?: string;
  isReturn: boolean;
  adults: number;
  cabin: CabinClass;
  directOnly: boolean;
}

export interface SearchFilterState {
  selectedAirlines: string[];
  selectedDepartureAirports: string[];
  selectedArrivalAirports: string[];
  maxPrice: number;
  minDepartureHour: number;
  maxDepartureHour: number;
  maxDurationMins: number;
  directOnly: boolean;
  hasBaggageIncluded: boolean;
  hasFreeCancellation: boolean;
  cabin: CabinClass | 'all';
  sortBy: 'recommended' | 'price_low' | 'duration_fast' | 'departure_early' | 'departure_late' | 'fewest_stops';
}
