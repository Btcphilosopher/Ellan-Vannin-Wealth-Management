import { NextRequest, NextResponse } from 'next/server';
import { MAJOR_ROUTES, getTimetableForRoute } from '@/lib/aviation/data';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get('id');
  const from = searchParams.get('from');
  const to = searchParams.get('to');

  if (id) {
    const r = MAJOR_ROUTES.find(route => route.id.toLowerCase() === id.toLowerCase());
    if (!r) return NextResponse.json({ error: 'Route not found' }, { status: 404 });
    return NextResponse.json(r);
  }

  if (from && to) {
    const timetable = getTimetableForRoute(from.toUpperCase(), to.toUpperCase());
    return NextResponse.json({
      from: from.toUpperCase(),
      to: to.toUpperCase(),
      servicesCount: timetable.length,
      timetable,
    });
  }

  return NextResponse.json(MAJOR_ROUTES);
}
