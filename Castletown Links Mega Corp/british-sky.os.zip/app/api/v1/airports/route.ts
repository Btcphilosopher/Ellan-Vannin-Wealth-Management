import { NextRequest, NextResponse } from 'next/server';
import { UK_AIRPORTS, searchAirports, getAirportByCode } from '@/lib/aviation/airports';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const code = searchParams.get('code');
  const query = searchParams.get('q');

  if (code) {
    const airport = getAirportByCode(code);
    if (!airport) {
      return NextResponse.json({ error: 'Airport not found' }, { status: 404 });
    }
    return NextResponse.json(airport);
  }

  if (query) {
    return NextResponse.json(searchAirports(query));
  }

  return NextResponse.json(UK_AIRPORTS);
}
