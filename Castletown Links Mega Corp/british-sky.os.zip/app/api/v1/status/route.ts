import { NextRequest, NextResponse } from 'next/server';
import { generateSyntheticFlightDatabase } from '@/lib/aviation/data';
import { getSimulationState } from '@/lib/aviation/simulator';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const flightNo = searchParams.get('flight');
  const from = searchParams.get('from');
  const to = searchParams.get('to');

  const state = getSimulationState();
  const allFlights = state.flights.length > 0 ? state.flights : generateSyntheticFlightDatabase();

  if (flightNo) {
    const cleanNo = flightNo.replace(/\s+/g, '').toUpperCase();
    const flight = allFlights.find(f => f.flightNumber.replace(/\s+/g, '').toUpperCase() === cleanNo);
    if (!flight) {
      return NextResponse.json({ error: `Flight ${flightNo} not found in UK domestic system.` }, { status: 404 });
    }
    return NextResponse.json(flight);
  }

  if (from && to) {
    const matched = allFlights.filter(
      f => f.originCode.toUpperCase() === from.toUpperCase() && f.destinationCode.toUpperCase() === to.toUpperCase()
    );
    return NextResponse.json(matched);
  }

  return NextResponse.json(allFlights.slice(0, 30));
}
