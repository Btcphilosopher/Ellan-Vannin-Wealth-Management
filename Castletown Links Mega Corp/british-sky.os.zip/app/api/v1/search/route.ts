import { NextRequest, NextResponse } from 'next/server';
import { searchFlights } from '@/lib/aviation/simulator';
import { SearchQuery } from '@/lib/aviation/types';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const from = searchParams.get('from') || 'LON';
  const to = searchParams.get('to') || 'EDI';
  const date = searchParams.get('date') || '2026-10-18';
  const returnDate = searchParams.get('returnDate') || undefined;
  const directOnly = searchParams.get('directOnly') === 'true';
  const cabin = (searchParams.get('cabin') as any) || 'economy';
  const adults = parseInt(searchParams.get('adults') || '1', 10);

  const query: SearchQuery = {
    originCode: from.toUpperCase(),
    destinationCode: to.toUpperCase(),
    departDate: date,
    returnDate: returnDate,
    isReturn: Boolean(returnDate),
    adults,
    cabin,
    directOnly,
  };

  const { results, searchLatencyMs } = searchFlights(query);

  return NextResponse.json({
    origin: from.toUpperCase(),
    destination: to.toUpperCase(),
    date,
    returnDate,
    cabin,
    adults,
    searchLatencyMs,
    count: results.length,
    results,
  });
}
