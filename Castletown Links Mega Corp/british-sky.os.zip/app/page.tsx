'use client';

import React, { useState, useEffect } from 'react';
import { Navbar, ActiveTab } from '@/components/Navbar';
import { HeroSearch } from '@/components/HeroSearch';
import { FlightResults } from '@/components/FlightResults';
import { TimetableView } from '@/components/TimetableView';
import { FlightStatusTracker } from '@/components/FlightStatusTracker';
import { NetworkMap } from '@/components/NetworkMap';
import { AirportDirectory } from '@/components/AirportDirectory';
import { AirlinesDirectory } from '@/components/AirlinesDirectory';
import { MyBritishSky } from '@/components/MyBritishSky';
import { AdminConsole } from '@/components/AdminConsole';
import { Flight, SearchQuery, SavedJourney } from '@/lib/aviation/types';
import { searchFlights, getSavedJourneys, saveJourney, getPriceAlerts } from '@/lib/aviation/simulator';
import { Plane, ShieldCheck, ArrowRight, ExternalLink } from 'lucide-react';

export default function Home() {
  const [activeTab, setActiveTab] = useState<ActiveTab>('search');
  const [currentQuery, setCurrentQuery] = useState<SearchQuery>({
    originCode: 'LON',
    destinationCode: 'EDI',
    departDate: '2026-10-18',
    isReturn: false,
    adults: 1,
    cabin: 'economy',
    directOnly: false,
  });

  const [flights, setFlights] = useState<Flight[]>(() => {
    const { results } = searchFlights({
      originCode: 'LON',
      destinationCode: 'EDI',
      departDate: '2026-10-18',
      isReturn: false,
      adults: 1,
      cabin: 'economy',
      directOnly: false,
    });
    return results;
  });

  const [searchLatencyMs, setSearchLatencyMs] = useState<number>(18);
  const [savedCount, setSavedCount] = useState<number>(() => getSavedJourneys().length);
  const [alertsCount, setAlertsCount] = useState<number>(() => getPriceAlerts().length);
  const [savedFlightIds, setSavedFlightIds] = useState<string[]>(() => getSavedJourneys().map(j => j.flightId));

  const updateCounters = () => {
    const journeys = getSavedJourneys();
    const alerts = getPriceAlerts();
    setSavedCount(journeys.length);
    setAlertsCount(alerts.length);
    setSavedFlightIds(journeys.map(j => j.flightId));
  };

  const handleSearch = (newQuery: SearchQuery) => {
    setCurrentQuery(newQuery);
    const { results, searchLatencyMs: latency } = searchFlights(newQuery);
    setFlights(results);
    setSearchLatencyMs(latency);
    setActiveTab('search');
  };

  const handleDateChange = (newDate: string) => {
    const updated = { ...currentQuery, departDate: newDate };
    setCurrentQuery(updated);
    const { results, searchLatencyMs: latency } = searchFlights(updated);
    setFlights(results);
    setSearchLatencyMs(latency);
  };

  const handleSaveFlight = (flight: Flight) => {
    const isAlreadySaved = savedFlightIds.includes(flight.id);
    if (!isAlreadySaved) {
      const item: SavedJourney = {
        id: `saved-${Date.now()}`,
        flightId: flight.id,
        originCode: flight.originCode,
        destinationCode: flight.destinationCode,
        date: currentQuery.departDate,
        fareSelected: flight.fareTiers[0].title,
        price: flight.totalPrice,
        savedAt: new Date().toISOString().split('T')[0],
        flightNumber: flight.flightNumber,
        airlineName: flight.airlineName,
        departureTime: flight.departureTime,
      };
      saveJourney(item);
      updateCounters();
    }
  };

  const handleSelectRouteFromMap = (originCode: string, destCode: string) => {
    const updated = {
      ...currentQuery,
      originCode,
      destinationCode: destCode,
    };
    setCurrentQuery(updated);
    const { results, searchLatencyMs: latency } = searchFlights(updated);
    setFlights(results);
    setSearchLatencyMs(latency);
    setActiveTab('search');
  };

  return (
    <div className="min-h-screen bg-[#FAFAFC] dark:bg-[#070D1E] text-slate-900 dark:text-slate-100 flex flex-col font-sans antialiased selection:bg-sky-500 selection:text-white">
      {/* Top Bar */}
      <Navbar
        activeTab={activeTab}
        onTabChange={setActiveTab}
        savedCount={savedCount}
        alertsCount={alertsCount}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {activeTab === 'search' && (
          <>
            <HeroSearch
              currentQuery={currentQuery}
              onSearch={handleSearch}
            />
            <FlightResults
              rawFlights={flights}
              query={currentQuery}
              searchLatencyMs={searchLatencyMs}
              onDateChange={handleDateChange}
              onSaveFlight={handleSaveFlight}
              savedFlightIds={savedFlightIds}
            />
          </>
        )}

        {activeTab === 'timetable' && (
          <TimetableView />
        )}

        {activeTab === 'status' && (
          <FlightStatusTracker />
        )}

        {activeTab === 'network' && (
          <NetworkMap onSelectRoute={handleSelectRouteFromMap} />
        )}

        {activeTab === 'airports' && (
          <AirportDirectory
            onSearchFromAirport={(code) => {
              handleSelectRouteFromMap(code, code === 'EDI' ? 'LON' : 'EDI');
            }}
          />
        )}

        {activeTab === 'airlines' && (
          <AirlinesDirectory />
        )}

        {activeTab === 'mysky' && (
          <MyBritishSky
            onSearchRoute={(orig, dest) => handleSelectRouteFromMap(orig, dest)}
            onRefreshCounts={updateCounters}
          />
        )}

        {activeTab === 'admin' && (
          <AdminConsole
            onStateUpdated={() => {
              const { results, searchLatencyMs: latency } = searchFlights(currentQuery);
              setFlights(results);
              setSearchLatencyMs(latency);
            }}
          />
        )}
      </main>

      {/* Institutional Restrained Footer */}
      <footer className="bg-[#0B132B] text-slate-400 border-t border-slate-800 text-xs py-12 px-4 sm:px-6 lg:px-8 mt-16">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 rounded bg-slate-800 border border-slate-700 flex items-center justify-center text-sky-400">
                <Plane className="w-3.5 h-3.5 transform -rotate-45" />
              </div>
              <span className="font-bold text-white uppercase tracking-wider font-mono">
                BRITISH SKY
              </span>
            </div>
            <p className="text-slate-400 text-xs leading-relaxed">
              The national domestic aviation search, timetable, and fare-transparency infrastructure for the United Kingdom.
            </p>
          </div>

          <div>
            <h4 className="font-bold text-white uppercase font-mono tracking-wider text-[11px] mb-3">
              Corridors & Timetables
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button
                  type="button"
                  onClick={() => handleSelectRouteFromMap('LON', 'EDI')}
                  className="hover:text-white transition-colors"
                >
                  London → Edinburgh (LHR/LGW/LCY)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleSelectRouteFromMap('LON', 'GLA')}
                  className="hover:text-white transition-colors"
                >
                  London → Glasgow (LHR/LGW/LTN)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleSelectRouteFromMap('LON', 'BFS')}
                  className="hover:text-white transition-colors"
                >
                  London → Belfast (LHR/LGW/STN)
                </button>
              </li>
              <li>
                <button
                  type="button"
                  onClick={() => handleSelectRouteFromMap('MAN', 'ABZ')}
                  className="hover:text-white transition-colors"
                >
                  Manchester → Aberdeen (MAN/ABZ)
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white uppercase font-mono tracking-wider text-[11px] mb-3">
              Aviation Standards
            </h4>
            <ul className="space-y-2 text-xs">
              <li>UK Air Passenger Duty (APD) Compliance</li>
              <li>Civil Aviation Authority (CAA) Neutrality</li>
              <li>Real-time Flight Telemetry Feeds</li>
              <li>Zero Commercial Search Surcharges</li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white uppercase font-mono tracking-wider text-[11px] mb-3">
              Institutional Guarantee
            </h4>
            <p className="text-slate-400 text-xs leading-relaxed">
              British Sky is a non-booking intermediary. All flight purchases are completed directly on verified airline partner checkouts.
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pt-6 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
          <p>© {new Date().getFullYear()} BRITISH SKY.OS · National Domestic Flight Search & Aviation Intelligence Platform.</p>
          <div className="flex items-center gap-4">
            <span>Airspace Data: CAA & NATS Synthetic Simulation</span>
            <span>·</span>
            <span>UK Domestic APD Included</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
