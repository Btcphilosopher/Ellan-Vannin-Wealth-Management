import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'BRITISH SKY.OS — National Domestic Flight Search & Aviation Platform',
  description: 'National domestic flight search, fare comparison, timetables, and aviation information system for the United Kingdom.',
  openGraph: {
    title: 'BRITISH SKY.OS — National Domestic Flight Search & Aviation Platform',
    description: 'National domestic flight search, fare comparison, timetables, and aviation information system for the United Kingdom.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'BRITISH SKY.OS — National Domestic Flight Search & Aviation Platform',
    description: 'National domestic flight search, fare comparison, timetables, and aviation information system for the United Kingdom.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
