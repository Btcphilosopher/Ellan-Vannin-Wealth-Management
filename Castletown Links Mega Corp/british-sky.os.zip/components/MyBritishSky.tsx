'use client';

import React, { useState, useEffect } from 'react';
import { SavedJourney, PriceAlert } from '@/lib/aviation/types';
import { getSavedJourneys, removeSavedJourney, getPriceAlerts, removePriceAlert } from '@/lib/aviation/simulator';
import { Bookmark, Bell, Trash2, ArrowRight, Plane, TrendingDown, Clock, ShieldCheck } from 'lucide-react';

interface MyBritishSkyProps {
  onSearchRoute: (originCode: string, destCode: string) => void;
  onRefreshCounts: () => void;
}

export const MyBritishSky: React.FC<MyBritishSkyProps> = ({ onSearchRoute, onRefreshCounts }) => {
  const [savedJourneys, setSavedJourneys] = useState<SavedJourney[]>(() => getSavedJourneys());
  const [priceAlerts, setPriceAlerts] = useState<PriceAlert[]>(() => getPriceAlerts());

  const handleDeleteJourney = (id: string) => {
    removeSavedJourney(id);
    setSavedJourneys(getSavedJourneys());
    onRefreshCounts();
  };

  const handleDeleteAlert = (id: string) => {
    removePriceAlert(id);
    setPriceAlerts(getPriceAlerts());
    onRefreshCounts();
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="pb-6 mb-8 border-b border-slate-200 dark:border-slate-800">
        <span className="text-xs font-mono uppercase tracking-widest text-sky-600 dark:text-sky-400">
          Passenger Intelligence Console
        </span>
        <h1 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight mt-1">
          My British Sky
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
          Your saved domestic flights, monitored fare alerts, recent itinerary queries, and notification preferences.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Saved Flights Section */}
        <div className="lg:col-span-7 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <h2 className="text-base font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider flex items-center gap-2">
              <Bookmark className="w-4 h-4 text-sky-500" />
              <span>Saved Journeys ({savedJourneys.length})</span>
            </h2>
          </div>

          {savedJourneys.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-8 text-center text-xs text-slate-500">
              <p className="font-semibold text-slate-700 dark:text-slate-300 mb-1">
                No flights bookmarked yet
              </p>
              <p>When browsing flights, click &quot;Save&quot; on any result card to bookmark it here for quick access.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {savedJourneys.map(j => (
                <div
                  key={j.id}
                  className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm flex items-center justify-between gap-4"
                >
                  <div>
                    <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                      <span className="font-mono font-bold text-slate-900 dark:text-white">{j.flightNumber}</span>
                      <span>·</span>
                      <span>{j.airlineName}</span>
                      <span>·</span>
                      <span>{j.date}</span>
                    </div>
                    <p className="text-base font-bold text-slate-900 dark:text-white">
                      {j.originCode} → {j.destinationCode} ({j.departureTime})
                    </p>
                    <p className="text-xs text-slate-500 mt-0.5">
                      {j.fareSelected} · Total <span className="font-mono font-bold text-slate-900 dark:text-white">£{j.price}</span>
                    </p>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onSearchRoute(j.originCode, j.destinationCode)}
                      className="px-3 py-1.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs transition-colors"
                    >
                      View Live Fare
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteJourney(j.id)}
                      className="p-2 rounded-lg text-slate-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/30 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Monitored Price Alerts Section */}
        <div className="lg:col-span-5 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <h2 className="text-base font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider flex items-center gap-2">
              <Bell className="w-4 h-4 text-sky-500" />
              <span>Fare Trackers ({priceAlerts.length})</span>
            </h2>
          </div>

          {priceAlerts.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-8 text-center text-xs text-slate-500">
              <p className="font-semibold text-slate-700 dark:text-slate-300 mb-1">
                No active route fare watchers
              </p>
              <p>Click &quot;Watch Fares for this Route&quot; on search results to receive alerts when prices fall below your target threshold.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {priceAlerts.map(a => (
                <div
                  key={a.id}
                  className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="font-bold text-sm text-slate-900 dark:text-white">
                      {a.originCode} → {a.destinationCode}
                    </span>
                    <button
                      type="button"
                      onClick={() => handleDeleteAlert(a.id)}
                      className="p-1 text-slate-400 hover:text-rose-500"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs py-2 border-y border-slate-100 dark:border-slate-800 my-2">
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase font-mono block">Current Lowest</span>
                      <span className="font-mono font-bold text-slate-900 dark:text-white text-base">
                        £{a.currentLowestPriceGbp}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 text-[10px] uppercase font-mono block">Target Alert Threshold</span>
                      <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400 text-base">
                        £{a.targetPriceGbp}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center justify-between text-[11px] text-slate-500">
                    <span>Active for {a.date}</span>
                    <span className="text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                      <TrendingDown className="w-3 h-3" /> Tracking Active
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
