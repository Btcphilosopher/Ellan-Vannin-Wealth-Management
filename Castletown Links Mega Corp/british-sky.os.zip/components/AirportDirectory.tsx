'use client';

import React, { useState } from 'react';
import { UK_AIRPORTS, searchAirports } from '@/lib/aviation/airports';
import { Airport } from '@/lib/aviation/types';
import { Search, Building2, Train, Clock, ShieldCheck, ExternalLink, MapPin } from 'lucide-react';

interface AirportDirectoryProps {
  onSearchFromAirport?: (code: string) => void;
}

export const AirportDirectory: React.FC<AirportDirectoryProps> = ({ onSearchFromAirport }) => {
  const [query, setQuery] = useState('');
  const [selectedAirport, setSelectedAirport] = useState<Airport>(UK_AIRPORTS[0]);

  const airports = searchAirports(query);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="pb-6 mb-6 border-b border-slate-200 dark:border-slate-800">
        <span className="text-xs font-mono uppercase tracking-widest text-sky-600 dark:text-sky-400">
          UK Civil Aviation Infrastructure
        </span>
        <h1 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight mt-1">
          British Domestic Airports Directory
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
          Terminal guides, ground transport connections, fast-track security queue wait times, and domestic hub infrastructure.
        </p>
      </div>

      {/* Search Input */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm mb-8">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 transform -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search by airport name, city or IATA code (e.g. Heathrow, EDI, Manchester, Newquay)..."
            className="w-full pl-10 pr-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm focus:outline-none focus:ring-2 focus:ring-sky-500"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Airport list column */}
        <div className="lg:col-span-4 space-y-2 max-h-[700px] overflow-y-auto pr-2">
          {airports.map(a => (
            <button
              key={a.code}
              type="button"
              onClick={() => setSelectedAirport(a)}
              className={`w-full text-left p-3.5 rounded-xl border transition-all ${
                selectedAirport.code === a.code
                  ? 'bg-slate-900 text-white border-slate-900 dark:bg-sky-950 dark:border-sky-500 shadow-md ring-1 ring-sky-400'
                  : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-400 text-slate-800 dark:text-slate-200'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-mono font-bold text-sm tracking-tight">{a.code}</span>
                <span className={`text-[11px] font-medium ${selectedAirport.code === a.code ? 'text-sky-300' : 'text-slate-500'}`}>
                  {a.region}
                </span>
              </div>
              <p className="text-xs font-semibold mt-1 truncate">{a.name}</p>
              <p className={`text-[11px] mt-0.5 ${selectedAirport.code === a.code ? 'text-slate-300' : 'text-slate-500'}`}>
                {a.city} · {a.terminals.length} {a.terminals.length === 1 ? 'Terminal' : 'Terminals'}
              </p>
            </button>
          ))}
        </div>

        {/* Selected Airport Dossier */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 p-6 sm:p-8 shadow-sm space-y-6">
          <div className="flex flex-wrap items-start justify-between gap-4 pb-6 border-b border-slate-200 dark:border-slate-800">
            <div>
              <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-sky-600 dark:text-sky-400">
                <span>{selectedAirport.region}</span>
                <span>·</span>
                <span>{selectedAirport.country}</span>
              </div>
              <h2 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
                {selectedAirport.name}
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                IATA: <span className="font-mono font-bold text-slate-800 dark:text-slate-200">{selectedAirport.code}</span> · {selectedAirport.annualPassengersM}M Annual Passengers
              </p>
            </div>

            {onSearchFromAirport && (
              <button
                type="button"
                onClick={() => onSearchFromAirport(selectedAirport.code)}
                className="px-4 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs transition-colors shadow-sm"
              >
                Search Flights from {selectedAirport.code}
              </button>
            )}
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80">
              <span className="text-slate-500 text-[10px] font-mono uppercase">Security Queue</span>
              <p className="text-lg font-bold font-mono text-emerald-600 dark:text-emerald-400 mt-1">
                ~{selectedAirport.securityWaitMins} mins
              </p>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80">
              <span className="text-slate-500 text-[10px] font-mono uppercase">Active Runways</span>
              <p className="text-lg font-bold font-mono text-slate-900 dark:text-white mt-1">
                {selectedAirport.runways} Operational
              </p>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80">
              <span className="text-slate-500 text-[10px] font-mono uppercase">City Center Transit</span>
              <p className="text-lg font-bold font-mono text-slate-900 dark:text-white mt-1">
                {selectedAirport.groundTransport.cityCenterTimeMins} mins
              </p>
            </div>
            <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80">
              <span className="text-slate-500 text-[10px] font-mono uppercase">Est. Transfer Fare</span>
              <p className="text-lg font-bold font-mono text-slate-900 dark:text-white mt-1">
                £{selectedAirport.groundTransport.transferCostEstGbp.toFixed(2)}
              </p>
            </div>
          </div>

          {/* Terminals & Concourse Layout */}
          <div>
            <h3 className="text-xs font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider mb-2">
              Passenger Terminals & Concourses
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
              {selectedAirport.terminals.map(t => (
                <div key={t} className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 text-slate-800 dark:text-slate-200 font-medium flex items-center gap-2">
                  <Building2 className="w-4 h-4 text-sky-500 shrink-0" />
                  <span>{t}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Ground Transport & Rail Links */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50/60 dark:bg-slate-800/40 text-xs space-y-2">
            <h3 className="font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider flex items-center gap-2">
              <Train className="w-4 h-4 text-slate-600 dark:text-slate-300" />
              <span>Ground Transport & Rail Connectivity</span>
            </h3>
            <p className="text-slate-700 dark:text-slate-300">
              <span className="font-semibold text-slate-900 dark:text-white">Rail & Express Links:</span> {selectedAirport.groundTransport.rail}
            </p>
            {selectedAirport.groundTransport.underground && (
              <p className="text-slate-700 dark:text-slate-300">
                <span className="font-semibold text-slate-900 dark:text-white">Underground / Metro:</span> {selectedAirport.groundTransport.underground}
              </p>
            )}
            <p className="text-slate-700 dark:text-slate-300">
              <span className="font-semibold text-slate-900 dark:text-white">Coach & Bus:</span> {selectedAirport.groundTransport.bus}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
