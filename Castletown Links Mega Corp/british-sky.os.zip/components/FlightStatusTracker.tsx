'use client';

import React, { useState, useMemo } from 'react';
import { generateSyntheticFlightDatabase } from '@/lib/aviation/data';
import { Flight, FlightStatusType } from '@/lib/aviation/types';
import { Search, Activity, Plane, Clock, AlertTriangle, CheckCircle, ArrowRight, Gauge, MapPin } from 'lucide-react';
import { UK_AIRPORTS, getAirportByCode } from '@/lib/aviation/airports';

export const FlightStatusTracker: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState<string>('BA1434');
  const [selectedAirportCode, setSelectedAirportCode] = useState<string>('LHR');
  const [boardType, setBoardType] = useState<'departures' | 'arrivals'>('departures');

  const allFlights = useMemo(() => generateSyntheticFlightDatabase(), []);

  // Filtered target flight
  const targetFlight: Flight | undefined = useMemo(() => {
    if (!searchQuery.trim()) return allFlights[0];
    const clean = searchQuery.replace(/\s+/g, '').toUpperCase();
    return allFlights.find(f => f.flightNumber.replace(/\s+/g, '').toUpperCase() === clean) || allFlights[0];
  }, [allFlights, searchQuery]);

  // Terminal Board Flights
  const terminalBoardFlights = useMemo(() => {
    return allFlights.filter(f => {
      if (boardType === 'departures') {
        return f.originCode === selectedAirportCode;
      } else {
        return f.destinationCode === selectedAirportCode;
      }
    });
  }, [allFlights, selectedAirportCode, boardType]);

  const stages: { type: FlightStatusType; label: string; desc: string }[] = [
    { type: 'Scheduled', label: 'Scheduled', desc: 'Flight on schedule' },
    { type: 'CheckIn', label: 'Check-in Open', desc: 'Desks & Bag Drop Active' },
    { type: 'Boarding', label: 'Boarding Gate', desc: 'Gate B32 Open' },
    { type: 'Departed', label: 'Departed', desc: 'Pushback from Stand' },
    { type: 'Airborne', label: 'Cruising Airborne', desc: 'FL340 · 440 kts' },
    { type: 'Approaching', label: 'Descent Approach', desc: 'ILS Lock Active' },
    { type: 'Landed', label: 'Landed & Arrived', desc: 'On Stand' },
  ];

  const currentStageIndex = 4; // Simulated Airborne state for demo

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="pb-6 mb-6 border-b border-slate-200 dark:border-slate-800">
        <span className="text-xs font-mono uppercase tracking-widest text-sky-600 dark:text-sky-400">
          UK Domestic Airspace Telemetry
        </span>
        <h1 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight mt-1">
          Live Domestic Flight Status & Radar
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
          Real-time flight radar tracking, gate assignments, on-time status and live terminal departures across the United Kingdom.
        </p>
      </div>

      {/* Flight Search Input Bar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 shadow-sm mb-8">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 transform -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Enter flight number (e.g. BA1434, U2804, LM342, T3412)..."
              className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-mono font-medium focus:outline-none focus:ring-2 focus:ring-sky-500"
            />
          </div>

          <div className="flex items-center gap-1.5 w-full sm:w-auto overflow-x-auto pb-1 sm:pb-0 text-xs">
            <span className="text-slate-400 text-[11px] font-mono uppercase mr-1">Quick lookups:</span>
            {['BA1434', 'U2804', 'LM521', 'FR841', 'T3412'].map((no) => (
              <button
                key={no}
                type="button"
                onClick={() => setSearchQuery(no)}
                className="px-2.5 py-1 rounded bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-300 font-mono font-semibold"
              >
                {no}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Active Flight Radar Tracking Card */}
      {targetFlight && (
        <div className="bg-slate-950 text-white rounded-2xl border border-slate-800 p-6 sm:p-8 shadow-2xl mb-12 relative overflow-hidden">
          {/* Subtle radar sweep background */}
          <div className="absolute top-0 right-0 w-96 h-96 bg-sky-500/5 rounded-full blur-3xl pointer-events-none" />

          <div className="relative z-10">
            <div className="flex flex-wrap items-center justify-between gap-4 pb-6 border-b border-slate-800">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono tracking-widest text-sky-400 uppercase">
                  <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
                  <span>Airborne Radar Feed · {targetFlight.airlineName}</span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-bold font-mono tracking-tight mt-1">
                  Flight {targetFlight.flightNumber}
                </h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  {targetFlight.aircraft.model} · Callsign: {targetFlight.airlineCode === 'BA' ? 'SPEEDBIRD' : 'LOGANAIR'} {targetFlight.flightNumber.replace(/[^\d]/g, '')}
                </p>
              </div>

              <div className="text-right">
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                  Current Status
                </span>
                <p className="text-lg font-bold text-emerald-400 font-mono mt-0.5">
                  EN ROUTE / ON SCHEDULE
                </p>
                <p className="text-xs text-slate-400">
                  Estimated Arrival {targetFlight.arrivalTime}
                </p>
              </div>
            </div>

            {/* Flight Path Graphic */}
            <div className="my-8">
              <div className="grid grid-cols-1 sm:grid-cols-3 items-center gap-4">
                <div>
                  <span className="text-xs font-mono text-slate-400 uppercase">Departure</span>
                  <p className="text-3xl font-bold font-mono text-white mt-1">
                    {targetFlight.departureTime}
                  </p>
                  <p className="text-sm font-semibold text-slate-200">
                    {targetFlight.originCity} ({targetFlight.originCode})
                  </p>
                  <p className="text-xs text-slate-400">
                    {targetFlight.originTerminal || 'Terminal 5'} · {targetFlight.gate || 'Gate A18'}
                  </p>
                </div>

                <div className="text-center px-4">
                  <div className="text-xs font-mono text-sky-400 mb-1">
                    34,000 ft · 440 kts · 38m remaining
                  </div>
                  <div className="relative my-2">
                    <div className="h-1 bg-slate-800 rounded-full overflow-hidden">
                      <div className="h-full bg-sky-500 w-3/5 rounded-full" />
                    </div>
                    <div className="absolute top-1/2 left-3/5 transform -translate-x-1/2 -translate-y-1/2 bg-sky-400 p-1.5 rounded-full shadow-lg">
                      <Plane className="w-3.5 h-3.5 text-slate-950 transform rotate-90" />
                    </div>
                  </div>
                  <span className="text-[11px] text-slate-400 font-mono">
                    Direct · {targetFlight.durationMinutes}m duration
                  </span>
                </div>

                <div className="sm:text-right">
                  <span className="text-xs font-mono text-slate-400 uppercase">Scheduled Arrival</span>
                  <p className="text-3xl font-bold font-mono text-white mt-1">
                    {targetFlight.arrivalTime}
                  </p>
                  <p className="text-sm font-semibold text-slate-200">
                    {targetFlight.destinationCity} ({targetFlight.destinationCode})
                  </p>
                  <p className="text-xs text-slate-400">
                    {targetFlight.destinationTerminal || 'Main Concourse'} · Baggage Belt 3
                  </p>
                </div>
              </div>
            </div>

            {/* Flight Progression Timeline */}
            <div className="pt-6 border-t border-slate-800">
              <span className="text-xs font-mono uppercase tracking-wider text-slate-400 block mb-4">
                Operational Milestones
              </span>

              <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                {stages.map((stage, idx) => {
                  const isPassed = idx <= currentStageIndex;
                  const isCurrent = idx === currentStageIndex;

                  return (
                    <div
                      key={stage.type}
                      className={`p-3 rounded-lg border text-left text-xs ${
                        isCurrent
                          ? 'bg-sky-950/80 border-sky-500 text-white'
                          : isPassed
                          ? 'bg-slate-900 border-slate-700 text-slate-300'
                          : 'bg-slate-900/40 border-slate-800 text-slate-600'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 mb-1">
                        {isPassed ? (
                          <CheckCircle className={`w-3 h-3 ${isCurrent ? 'text-sky-400' : 'text-emerald-500'}`} />
                        ) : (
                          <Clock className="w-3 h-3 text-slate-600" />
                        )}
                        <span className="font-bold">{stage.label}</span>
                      </div>
                      <p className="text-[10px] text-slate-400 truncate">{stage.desc}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Terminal Live Departures / Arrivals Boards */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <h2 className="text-base font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider">
              Airport Terminal Flight Board
            </h2>
            <select
              value={selectedAirportCode}
              onChange={(e) => setSelectedAirportCode(e.target.value)}
              className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs font-semibold focus:outline-none cursor-pointer"
            >
              {UK_AIRPORTS.map(a => (
                <option key={a.code} value={a.code}>
                  {a.code} — {a.name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-lg text-xs">
            <button
              type="button"
              onClick={() => setBoardType('departures')}
              className={`px-3 py-1.5 rounded font-medium ${
                boardType === 'departures'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white font-bold shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Departures
            </button>
            <button
              type="button"
              onClick={() => setBoardType('arrivals')}
              className={`px-3 py-1.5 rounded font-medium ${
                boardType === 'arrivals'
                  ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white font-bold shadow-sm'
                  : 'text-slate-600 dark:text-slate-400'
              }`}
            >
              Arrivals
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-mono uppercase text-[11px]">
                <th className="py-3 px-4">Time</th>
                <th className="py-3 px-4">Flight</th>
                <th className="py-3 px-4">Destination / Origin</th>
                <th className="py-3 px-4">Airline</th>
                <th className="py-3 px-4">Terminal</th>
                <th className="py-3 px-4">Gate</th>
                <th className="py-3 px-4 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {terminalBoardFlights.slice(0, 15).map((f) => {
                const targetAirport = getAirportByCode(boardType === 'departures' ? f.destinationCode : f.originCode);
                return (
                  <tr key={f.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                    <td className="py-3 px-4 font-mono font-bold text-slate-900 dark:text-white">
                      {boardType === 'departures' ? f.departureTime : f.arrivalTime}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-700 dark:text-slate-300 font-semibold">
                      {f.flightNumber}
                    </td>
                    <td className="py-3 px-4 text-slate-900 dark:text-white">
                      {targetAirport?.name.replace(' Airport', '') || f.destinationCity} ({boardType === 'departures' ? f.destinationCode : f.originCode})
                    </td>
                    <td className="py-3 px-4 text-slate-600 dark:text-slate-400">
                      {f.airlineName}
                    </td>
                    <td className="py-3 px-4 text-slate-500 font-mono">
                      {f.originTerminal || 'Main'}
                    </td>
                    <td className="py-3 px-4 text-slate-500 font-mono">
                      {f.gate || 'TBD'}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <span className="font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                        ON TIME
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
