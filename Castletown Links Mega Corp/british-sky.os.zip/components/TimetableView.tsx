'use client';

import React, { useState, useMemo } from 'react';
import { MAJOR_ROUTES, getTimetableForRoute } from '@/lib/aviation/data';
import { TimetableSlot } from '@/lib/aviation/types';
import { Calendar, Clock, Plane, Filter, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { UK_AIRPORTS, getAirportByCode } from '@/lib/aviation/airports';

export const TimetableView: React.FC = () => {
  const [selectedRouteId, setSelectedRouteId] = useState<string>('LON-EDI');
  const [selectedDay, setSelectedDay] = useState<number>(1); // 1 = Mon
  const [selectedBank, setSelectedBank] = useState<'all' | 'morning' | 'midday' | 'afternoon' | 'evening'>('all');

  const activeRoute = useMemo(() => {
    return MAJOR_ROUTES.find(r => r.id === selectedRouteId) || MAJOR_ROUTES[0];
  }, [selectedRouteId]);

  const slots: TimetableSlot[] = useMemo(() => {
    const raw = getTimetableForRoute(activeRoute.originCode, activeRoute.destinationCode, selectedDay);
    if (selectedBank === 'all') return raw;
    return raw.filter(s => {
      const hour = parseInt(s.departureTime.split(':')[0], 10);
      if (selectedBank === 'morning') return hour >= 6 && hour < 9;
      if (selectedBank === 'midday') return hour >= 9 && hour < 14;
      if (selectedBank === 'afternoon') return hour >= 14 && hour < 18;
      if (selectedBank === 'evening') return hour >= 18;
      return true;
    });
  }, [activeRoute, selectedDay, selectedBank]);

  const daysOfWeek = [
    { num: 1, label: 'Monday' },
    { num: 2, label: 'Tuesday' },
    { num: 3, label: 'Wednesday' },
    { num: 4, label: 'Thursday' },
    { num: 5, label: 'Friday' },
    { num: 6, label: 'Saturday' },
    { num: 7, label: 'Sunday' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Editorial Header */}
      <div className="pb-6 mb-6 border-b border-slate-200 dark:border-slate-800">
        <span className="text-xs font-mono uppercase tracking-widest text-sky-600 dark:text-sky-400">
          UK Domestic Aviation Timetable Master Index
        </span>
        <h1 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight mt-1">
          Scheduled Domestic Flight Timetables
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
          Complete recurring operational timetable and aircraft deployment across Britain&apos;s scheduled air corridors.
        </p>
      </div>

      {/* Corridor & Day Selector */}
      <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm mb-6">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          {/* Corridor Selection */}
          <div className="md:col-span-6">
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-500 mb-1">
              Select UK Scheduled Corridor
            </label>
            <select
              value={selectedRouteId}
              onChange={(e) => setSelectedRouteId(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer"
            >
              {MAJOR_ROUTES.map(r => (
                <option key={r.id} value={r.id}>
                  {r.originCity} ({r.originCode}) ⇄ {r.destinationCity} ({r.destinationCode}) · {r.directFlightsPerDay} Daily Services
                </option>
              ))}
            </select>
          </div>

          {/* Time Bank Filter */}
          <div className="md:col-span-6">
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-500 mb-1">
              Departure Bank
            </label>
            <div className="flex items-center gap-1 overflow-x-auto p-1 bg-slate-100 dark:bg-slate-800 rounded-lg text-xs">
              {[
                { id: 'all', label: 'All Services' },
                { id: 'morning', label: 'Early (06-09)' },
                { id: 'midday', label: 'Midday (09-14)' },
                { id: 'afternoon', label: 'Afternoon (14-18)' },
                { id: 'evening', label: 'Evening (18+)' },
              ].map(b => (
                <button
                  key={b.id}
                  type="button"
                  onClick={() => setSelectedBank(b.id as any)}
                  className={`px-3 py-1.5 rounded-md font-medium transition-colors whitespace-nowrap ${
                    selectedBank === b.id
                      ? 'bg-white dark:bg-slate-700 text-slate-900 dark:text-white shadow-sm font-bold'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
                  }`}
                >
                  {b.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Days of Week Rail */}
        <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center gap-2 overflow-x-auto">
          <span className="text-xs font-mono uppercase tracking-wider text-slate-500 mr-2 shrink-0">
            Day:
          </span>
          {daysOfWeek.map(d => (
            <button
              key={d.num}
              type="button"
              onClick={() => setSelectedDay(d.num)}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-medium transition-colors whitespace-nowrap ${
                selectedDay === d.num
                  ? 'bg-slate-900 dark:bg-sky-500 text-white dark:text-slate-950 font-bold'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              {d.label}
            </button>
          ))}
        </div>
      </div>

      {/* Corridor Summary Intelligence Bar */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 text-xs">
          <span className="text-slate-500 uppercase tracking-wider font-mono text-[10px]">
            Daily Direct Services
          </span>
          <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
            {activeRoute.directFlightsPerDay} Flights
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 text-xs">
          <span className="text-slate-500 uppercase tracking-wider font-mono text-[10px]">
            First / Last Departure
          </span>
          <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
            {activeRoute.firstDeparture} / {activeRoute.lastDeparture}
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 text-xs">
          <span className="text-slate-500 uppercase tracking-wider font-mono text-[10px]">
            Flight Time vs Intercity Rail
          </span>
          <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
            {activeRoute.typicalDurationMins}m <span className="text-xs font-normal text-slate-500">vs {Math.floor(activeRoute.railDurationMins / 60)}h{activeRoute.railDurationMins % 60}m train</span>
          </p>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 text-xs">
          <span className="text-slate-500 uppercase tracking-wider font-mono text-[10px]">
            Indicative Base Fare
          </span>
          <p className="text-xl font-bold font-mono text-slate-900 dark:text-white mt-1">
            from £{activeRoute.lowestPriceGbp}
          </p>
        </div>
      </div>

      {/* Timetable Table */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider">
            {activeRoute.originCity} ({activeRoute.originCode}) → {activeRoute.destinationCity} ({activeRoute.destinationCode}) Timetable
          </h2>
          <span className="text-xs text-slate-500 font-mono">
            {slots.length} Scheduled Services
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 dark:bg-slate-800/60 border-b border-slate-200 dark:border-slate-800 text-slate-500 font-mono uppercase text-[11px]">
                <th className="py-3 px-4">Departure</th>
                <th className="py-3 px-4">Arrival</th>
                <th className="py-3 px-4">Airline / Operator</th>
                <th className="py-3 px-4">Flight</th>
                <th className="py-3 px-4">Departure Airport</th>
                <th className="py-3 px-4">Aircraft</th>
                <th className="py-3 px-4">Punctuality</th>
                <th className="py-3 px-4 text-right">Typical Fare</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {slots.map((slot) => {
                const originAirport = getAirportByCode(slot.originCode);
                return (
                  <tr key={slot.flightNumber} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-bold text-slate-900 dark:text-white text-sm">
                      {slot.departureTime}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-700 dark:text-slate-300 text-sm">
                      {slot.arrivalTime}
                    </td>
                    <td className="py-3.5 px-4 font-semibold text-slate-900 dark:text-white">
                      {slot.airlineName}
                    </td>
                    <td className="py-3.5 px-4 font-mono text-slate-500">
                      {slot.flightNumber}
                    </td>
                    <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                      {originAirport?.name.replace(' Airport', '') || slot.originCode} ({slot.originCode})
                    </td>
                    <td className="py-3.5 px-4 text-slate-500 font-mono text-[11px]">
                      {slot.aircraftModel}
                    </td>
                    <td className="py-3.5 px-4">
                      <span className="font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                        {slot.typicalOnTimePct}% on-time
                      </span>
                    </td>
                    <td className="py-3.5 px-4 text-right font-mono font-bold text-slate-900 dark:text-white">
                      £{slot.baseFareGbp}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
