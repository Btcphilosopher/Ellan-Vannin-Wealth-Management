'use client';

import React, { useState } from 'react';
import { getSimulationState, saveSimulationState, SimulationEngineState } from '@/lib/aviation/simulator';
import { generateSyntheticFlightDatabase } from '@/lib/aviation/data';
import { SlidersHorizontal, Activity, RefreshCw, AlertTriangle, Zap, CheckCircle2, Server } from 'lucide-react';

interface AdminConsoleProps {
  onStateUpdated: () => void;
}

export const AdminConsole: React.FC<AdminConsoleProps> = ({ onStateUpdated }) => {
  const [state, setState] = useState<SimulationEngineState>(getSimulationState());
  const [message, setMessage] = useState<string | null>(null);

  const handleToggleWeatherDelay = (airportCode: string) => {
    const nextAirports = state.weatherDelayAirports.includes(airportCode)
      ? state.weatherDelayAirports.filter(c => c !== airportCode)
      : [...state.weatherDelayAirports, airportCode];

    const updated = { ...state, weatherDelayAirports: nextAirports };
    saveSimulationState(updated);
    setState(updated);
    onStateUpdated();
    showNotification(`Weather delay status updated for ${airportCode}`);
  };

  const handleToggleCancelFlight = (flightNo: string) => {
    const nextCancelled = state.cancelledFlightNumbers.includes(flightNo)
      ? state.cancelledFlightNumbers.filter(f => f !== flightNo)
      : [...state.cancelledFlightNumbers, flightNo];

    const updated = { ...state, cancelledFlightNumbers: nextCancelled };
    saveSimulationState(updated);
    setState(updated);
    onStateUpdated();
    showNotification(`Flight ${flightNo} cancellation toggled`);
  };

  const handleSetDemandMultiplier = (val: number) => {
    const updated = { ...state, demandMultiplier: val };
    saveSimulationState(updated);
    setState(updated);
    onStateUpdated();
    showNotification(`Dynamic demand factor set to ${val}x`);
  };

  const handleReset = () => {
    const fresh: SimulationEngineState = {
      flights: generateSyntheticFlightDatabase(),
      demandMultiplier: 1.0,
      weatherDelayAirports: [],
      cancelledFlightNumbers: [],
      delayedFlightMap: {},
      searchCount: 1420,
      lastQueryLatencyMs: 18,
      cacheHitCount: 948,
      engineStartedAt: 1727270400000,
    };
    saveSimulationState(fresh);
    setState(fresh);
    onStateUpdated();
    showNotification('Synthetic aviation simulation reset to baseline defaults.');
  };

  const showNotification = (msg: string) => {
    setMessage(msg);
    setTimeout(() => setMessage(null), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 mb-6 border-b border-slate-200 dark:border-slate-800 gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-sky-600 dark:text-sky-400">
            <Server className="w-4 h-4" />
            <span>Developer & Flight Operations Console</span>
          </div>
          <h1 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight mt-1">
            Simulation & Observability Controls
          </h1>
          <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">
            Mutate synthetic flight schedules, inject airspace delay events, adjust pricing multipliers, and inspect engine metrics.
          </p>
        </div>

        <button
          type="button"
          onClick={handleReset}
          className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors flex items-center gap-2"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>Reset Simulation</span>
        </button>
      </div>

      {message && (
        <div className="mb-6 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs font-medium flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
          <span>{message}</span>
        </div>
      )}

      {/* Engine Telemetry Metrics */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
        <div className="bg-slate-950 text-white border border-slate-800 rounded-xl p-4">
          <span className="text-slate-400 text-[10px] font-mono uppercase">Search Query Latency</span>
          <p className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            {state.lastQueryLatencyMs}ms
          </p>
          <span className="text-[10px] text-slate-500 font-mono">P99 SLA: 32ms</span>
        </div>

        <div className="bg-slate-950 text-white border border-slate-800 rounded-xl p-4">
          <span className="text-slate-400 text-[10px] font-mono uppercase">Synthetic Schedules</span>
          <p className="text-2xl font-bold font-mono text-sky-400 mt-1">
            142 Services
          </p>
          <span className="text-[10px] text-slate-500 font-mono">Active UK Matrix</span>
        </div>

        <div className="bg-slate-950 text-white border border-slate-800 rounded-xl p-4">
          <span className="text-slate-400 text-[10px] font-mono uppercase">Total Queries Served</span>
          <p className="text-2xl font-bold font-mono text-white mt-1">
            {state.searchCount.toLocaleString()}
          </p>
          <span className="text-[10px] text-slate-500 font-mono">Deterministic Session</span>
        </div>

        <div className="bg-slate-950 text-white border border-slate-800 rounded-xl p-4">
          <span className="text-slate-400 text-[10px] font-mono uppercase">Cache Hit Rate</span>
          <p className="text-2xl font-bold font-mono text-emerald-400 mt-1">
            98.4%
          </p>
          <span className="text-[10px] text-slate-500 font-mono">In-Memory Store</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Airspace Delay & Weather Injection */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm space-y-4">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-amber-500" />
            <span>Airspace Congestion & Weather Injections</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Inject ground delays into specific airports. All departing search results from the affected airport will reflect a +35m delay in real time.
          </p>

          <div className="space-y-2">
            {[
              { code: 'LHR', name: 'London Heathrow (LHR) — Morning Fog Restriction' },
              { code: 'LGW', name: 'London Gatwick (LGW) — Air Traffic Slot Control' },
              { code: 'EDI', name: 'Edinburgh (EDI) — High Wind Velocity' },
              { code: 'MAN', name: 'Manchester (MAN) — Runway Maintenance Slot' },
            ].map(item => {
              const isActive = state.weatherDelayAirports.includes(item.code);
              return (
                <button
                  key={item.code}
                  type="button"
                  onClick={() => handleToggleWeatherDelay(item.code)}
                  className={`w-full text-left p-3 rounded-lg border text-xs font-semibold flex items-center justify-between transition-colors ${
                    isActive
                      ? 'bg-amber-500/10 border-amber-500 text-amber-600 dark:text-amber-400'
                      : 'border-slate-200 dark:border-slate-800 hover:border-slate-400 text-slate-700 dark:text-slate-300'
                  }`}
                >
                  <span>{item.name}</span>
                  <span className="font-mono text-[10px] uppercase font-bold">
                    {isActive ? 'Active Delay' : 'Inject'}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Pricing Engine & Surge Demand Simulator */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm space-y-4">
          <h2 className="text-sm font-bold text-slate-900 dark:text-white font-mono uppercase tracking-wider flex items-center gap-2">
            <Zap className="w-4 h-4 text-sky-500" />
            <span>Synthetic Pricing Curve Multiplier</span>
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400">
            Adjust the macroeconomic demand pressure index to test price surges across all domestic routes.
          </p>

          <div className="space-y-3 pt-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-500">Demand Multiplier:</span>
              <span className="font-bold text-slate-900 dark:text-white">{state.demandMultiplier.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.75"
              max="1.75"
              step="0.05"
              value={state.demandMultiplier}
              onChange={(e) => handleSetDemandMultiplier(parseFloat(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 font-mono">
              <span>0.75x (Off-Peak Low Season)</span>
              <span>1.0x (Standard)</span>
              <span>1.75x (Bank Holiday Peak)</span>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
            <h3 className="text-xs font-bold text-slate-900 dark:text-white mb-2">
              Specific Flight Cancellations
            </h3>
            <div className="space-y-2 text-xs">
              {['BA1432', 'U2804', 'LM521'].map(fNo => {
                const isCancelled = state.cancelledFlightNumbers.includes(fNo);
                return (
                  <button
                    key={fNo}
                    type="button"
                    onClick={() => handleToggleCancelFlight(fNo)}
                    className={`w-full text-left p-2.5 rounded-lg border flex items-center justify-between font-mono ${
                      isCancelled
                        ? 'bg-rose-500/10 border-rose-500 text-rose-600 dark:text-rose-400 font-bold'
                        : 'border-slate-200 dark:border-slate-800 text-slate-700 dark:text-slate-300'
                    }`}
                  >
                    <span>Flight {fNo}</span>
                    <span className="text-[10px] uppercase">
                      {isCancelled ? 'Cancelled (Click to Restore)' : 'Click to Cancel'}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
