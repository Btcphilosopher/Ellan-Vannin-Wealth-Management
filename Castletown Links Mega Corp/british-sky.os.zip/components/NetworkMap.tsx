'use client';

import React, { useState, useMemo } from 'react';
import { UK_AIRPORTS, LONDON_AIRPORT_CODES, getAirportByCode } from '@/lib/aviation/airports';
import { getDirectDestinationsFrom, DirectReachDestination } from '@/lib/aviation/simulator';
import { MAJOR_ROUTES } from '@/lib/aviation/data';
import { SearchQuery } from '@/lib/aviation/types';
import { MapPin, Plane, ArrowRight, Compass, Info, Check } from 'lucide-react';

interface NetworkMapProps {
  onSelectRoute: (originCode: string, destCode: string) => void;
}

// Convert Lat/Lon to SVG canvas coordinates for UK projection (approx bounds: Lat 49.0 to 60.5, Lon -8.0 to 2.5)
function projectCoordinates(lat: number, lon: number): { x: number; y: number } {
  const minLat = 49.0;
  const maxLat = 60.5;
  const minLon = -8.0;
  const maxLon = 2.5;

  const width = 600;
  const height = 750;

  const x = ((lon - minLon) / (maxLon - minLon)) * width;
  const y = height - ((lat - minLat) / (maxLat - minLat)) * height;

  return { x, y };
}

export const NetworkMap: React.FC<NetworkMapProps> = ({ onSelectRoute }) => {
  const [selectedOrigin, setSelectedOrigin] = useState<string>('BHX'); // Birmingham by default for signature journey #2
  const [hoveredAirport, setHoveredAirport] = useState<string | null>(null);

  const directDestinations: DirectReachDestination[] = useMemo(() => {
    return getDirectDestinationsFrom(selectedOrigin);
  }, [selectedOrigin]);

  const originAirport = getAirportByCode(selectedOrigin);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="pb-6 mb-6 border-b border-slate-200 dark:border-slate-800">
        <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-sky-600 dark:text-sky-400">
          <Compass className="w-3.5 h-3.5" />
          <span>Interactive Domestic Network Explorer</span>
        </div>
        <h1 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight mt-1">
          Where Can I Fly? Britain’s Domestic Air Map
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
          Select any UK origin airport to discover non-stop domestic routes, journey durations, starting fares and flight frequencies.
        </p>
      </div>

      {/* Main Interactive Map & Direct Reach Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Side: Custom Vector SVG Map of Great Britain */}
        <div className="lg:col-span-7 bg-[#0B132B] rounded-2xl border border-slate-800 p-6 shadow-2xl relative overflow-hidden">
          <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-800 text-xs text-slate-400">
            <span className="font-mono uppercase text-sky-400 font-bold">
              UK DOMESTIC AIRWAYS GRID
            </span>
            <span>Click any node to change origin</span>
          </div>

          <div className="relative w-full aspect-[4/5] flex items-center justify-center">
            <svg
              viewBox="0 0 600 750"
              className="w-full h-full max-h-[680px] drop-shadow-md select-none"
            >
              {/* Subtle background UK land outline reference path */}
              <path
                d="M 280,720 Q 320,700 360,680 Q 420,670 450,620 Q 490,560 480,500 Q 440,460 420,400 Q 390,320 370,250 Q 340,160 300,100 Q 260,120 220,160 Q 200,240 220,320 Q 230,400 210,480 Q 180,560 210,640 Z"
                fill="#0F1E36"
                stroke="#1B2D4F"
                strokeWidth="1.5"
                opacity="0.6"
              />

              {/* Northern Ireland land shape */}
              <ellipse cx="105" cy="380" rx="35" ry="30" fill="#0F1E36" stroke="#1B2D4F" strokeWidth="1.5" opacity="0.6" />

              {/* Connecting Arcs from Selected Origin */}
              {originAirport &&
                directDestinations.map(dest => {
                  const p1 = projectCoordinates(originAirport.latitude, originAirport.longitude);
                  const p2 = projectCoordinates(dest.airport.latitude, dest.airport.longitude);

                  // Curve control point
                  const midX = (p1.x + p2.x) / 2;
                  const midY = (p1.y + p2.y) / 2 - 25;

                  return (
                    <g key={dest.airport.code} className="transition-opacity duration-300">
                      <path
                        d={`M ${p1.x} ${p1.y} Q ${midX} ${midY} ${p2.x} ${p2.y}`}
                        fill="none"
                        stroke="#38BDF8"
                        strokeWidth="1.8"
                        strokeDasharray="4 2"
                        opacity="0.75"
                        className="animate-pulse"
                      />
                      {/* Midpoint price badge on map */}
                      <circle cx={midX} cy={midY} r="3" fill="#38BDF8" />
                    </g>
                  );
                })}

              {/* Airport Nodes */}
              {UK_AIRPORTS.map(airport => {
                const { x, y } = projectCoordinates(airport.latitude, airport.longitude);
                const isOrigin = airport.code === selectedOrigin || (selectedOrigin === 'LON' && airport.isLondonCluster);
                const isHovered = hoveredAirport === airport.code;
                const isReachable = directDestinations.some(d => d.airport.code === airport.code);

                return (
                  <g
                    key={airport.code}
                    className="cursor-pointer group"
                    onClick={() => setSelectedOrigin(airport.code)}
                    onMouseEnter={() => setHoveredAirport(airport.code)}
                    onMouseLeave={() => setHoveredAirport(null)}
                  >
                    {/* Pulsing ring for active origin */}
                    {isOrigin && (
                      <circle
                        cx={x}
                        cy={y}
                        r="14"
                        fill="none"
                        stroke="#38BDF8"
                        strokeWidth="1.5"
                        opacity="0.8"
                        className="animate-ping"
                      />
                    )}

                    {/* Node circle */}
                    <circle
                      cx={x}
                      cy={y}
                      r={isOrigin ? 6 : isReachable ? 5 : 3.5}
                      fill={isOrigin ? '#38BDF8' : isReachable ? '#F59E0B' : '#64748B'}
                      stroke="#0B132B"
                      strokeWidth="1.5"
                    />

                    {/* Node Text Label */}
                    <text
                      x={x + 8}
                      y={y + 3}
                      fill={isOrigin ? '#38BDF8' : isReachable ? '#FFFFFF' : '#94A3B8'}
                      fontSize={isOrigin ? '11' : '9.5'}
                      fontFamily="monospace"
                      fontWeight={isOrigin || isReachable ? 'bold' : 'normal'}
                      className="pointer-events-none drop-shadow"
                    >
                      {airport.code}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          {/* Map Legend */}
          <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between text-[11px] text-slate-400 font-mono">
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-400" /> Selected Origin
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400" /> Direct Destination
              </span>
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-slate-500" /> Other Airport
              </span>
            </div>
          </div>
        </div>

        {/* Right Side: "Where Can I Fly?" Reach Cards */}
        <div className="lg:col-span-5 space-y-4">
          {/* Origin Switcher Header */}
          <div className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 shadow-sm">
            <label className="block text-xs font-mono uppercase tracking-wider text-slate-500 mb-1">
              Select Origin City
            </label>
            <select
              value={selectedOrigin}
              onChange={(e) => setSelectedOrigin(e.target.value)}
              className="w-full px-3 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-sm font-bold focus:outline-none focus:ring-2 focus:ring-sky-500 cursor-pointer mb-3"
            >
              <option value="BHX">Birmingham (BHX)</option>
              <option value="LON">London (All Airports - LON)</option>
              <option value="MAN">Manchester (MAN)</option>
              <option value="BRS">Bristol (BRS)</option>
              <option value="EDI">Edinburgh (EDI)</option>
              <option value="GLA">Glasgow (GLA)</option>
              <option value="NCL">Newcastle (NCL)</option>
              <option value="BFS">Belfast (BFS)</option>
              <option value="ABZ">Aberdeen (ABZ)</option>
              <option value="INV">Inverness (INV)</option>
            </select>

            <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100 dark:border-slate-800">
              <span>{directDestinations.length} Direct Domestic Destinations</span>
              <span className="font-mono text-emerald-600 dark:text-emerald-400 font-semibold">
                from £{directDestinations[0]?.lowestPriceGbp || 39}
              </span>
            </div>
          </div>

          {/* List of Direct Reach Destinations */}
          <div className="space-y-3 max-h-[580px] overflow-y-auto pr-1">
            {directDestinations.map(dest => (
              <div
                key={dest.airport.code}
                className="bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-4 shadow-sm hover:border-sky-400 dark:hover:border-sky-500 transition-all group"
              >
                <div className="flex items-center justify-between mb-2">
                  <div>
                    <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors">
                      {dest.airport.city} ({dest.airport.code})
                    </h3>
                    <p className="text-xs text-slate-500 dark:text-slate-400">
                      {dest.airport.name} · {dest.airport.region}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] font-mono text-slate-400 uppercase">From</span>
                    <p className="text-xl font-bold font-mono text-slate-900 dark:text-white">
                      £{dest.lowestPriceGbp}
                    </p>
                  </div>
                </div>

                <div className="flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-2">
                    <span className="font-mono">{dest.flightDurationMins}m flight</span>
                    <span>·</span>
                    <span>{dest.airlines.slice(0, 2).join(', ')}</span>
                  </div>

                  <button
                    type="button"
                    onClick={() => onSelectRoute(selectedOrigin, dest.airport.code)}
                    className="px-3 py-1.5 rounded-md bg-slate-900 hover:bg-sky-500 text-white hover:text-slate-950 font-bold text-xs transition-colors flex items-center gap-1"
                  >
                    <span>Search Flights</span>
                    <ArrowRight className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
