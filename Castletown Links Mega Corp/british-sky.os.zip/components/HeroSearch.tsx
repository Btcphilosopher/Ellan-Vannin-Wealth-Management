'use client';

import React, { useState } from 'react';
import { Plane, ArrowRightLeft, Calendar, User, ShieldCheck, ChevronDown, Check, ArrowRight } from 'lucide-react';
import { CabinClass, SearchQuery } from '@/lib/aviation/types';
import { UK_AIRPORTS, LONDON_AIRPORT_CODES } from '@/lib/aviation/airports';

interface HeroSearchProps {
  onSearch: (query: SearchQuery) => void;
  currentQuery: SearchQuery;
}

export const HeroSearch: React.FC<HeroSearchProps> = ({ onSearch, currentQuery }) => {
  const [origin, setOrigin] = useState<string>(currentQuery.originCode || 'LON');
  const [destination, setDestination] = useState<string>(currentQuery.destinationCode || 'EDI');
  const [departDate, setDepartDate] = useState<string>(currentQuery.departDate || '2026-10-18');
  const [returnDate, setReturnDate] = useState<string>(currentQuery.returnDate || '2026-10-20');
  const [isReturn, setIsReturn] = useState<boolean>(currentQuery.isReturn ?? false);
  const [adults, setAdults] = useState<number>(currentQuery.adults || 1);
  const [cabin, setCabin] = useState<CabinClass>(currentQuery.cabin || 'economy');
  const [directOnly, setDirectOnly] = useState<boolean>(currentQuery.directOnly || false);

  const [passengerDropdownOpen, setPassengerDropdownOpen] = useState<boolean>(false);

  const handleSwapAirports = () => {
    const temp = origin;
    setOrigin(destination === 'LON' ? 'LHR' : destination);
    setDestination(temp);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch({
      originCode: origin,
      destinationCode: destination,
      departDate,
      returnDate: isReturn ? returnDate : undefined,
      isReturn,
      adults,
      cabin,
      directOnly,
    });
  };

  const popularCorridors = [
    { from: 'LON', to: 'EDI', label: 'London → Edinburgh', price: 'from £42' },
    { from: 'LON', to: 'GLA', label: 'London → Glasgow', price: 'from £46' },
    { from: 'LON', to: 'BFS', label: 'London → Belfast', price: 'from £38' },
    { from: 'MAN', to: 'ABZ', label: 'Manchester → Aberdeen', price: 'from £68' },
    { from: 'BHX', to: 'EDI', label: 'Birmingham → Edinburgh', price: 'from £44' },
    { from: 'BRS', to: 'BFS', label: 'Bristol → Belfast', price: 'from £38' },
    { from: 'LON', to: 'NQY', label: 'London → Newquay', price: 'from £48' },
    { from: 'LON', to: 'JER', label: 'London → Jersey', price: 'from £39' },
  ];

  return (
    <section className="relative bg-[#0B132B] text-white pt-10 pb-16 px-4 sm:px-6 lg:px-8 border-b border-slate-800">
      {/* Background hero photograph with restrained contrast scrim */}
      <div
        className="absolute inset-0 z-0 bg-cover bg-center opacity-25 mix-blend-luminosity pointer-events-none"
        style={{
          backgroundImage: `url('/images/hero_aviation_skyline_1790342303592.jpg')`,
        }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-[#0B132B]/90 via-[#0B132B]/95 to-[#0B132B] z-0 pointer-events-none" />

      <div className="relative z-10 max-w-6xl mx-auto">
        {/* Editorial headline hierarchy */}
        <div className="text-center max-w-3xl mx-auto mb-8">
          <span className="text-xs font-mono tracking-widest text-sky-400 uppercase">
            UK National Domestic Aviation Index
          </span>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-semibold tracking-tight text-white mt-2 mb-3">
            Fly Across Britain.
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Neutral search, transparent fare breakdown, and real-time schedules across all UK airlines and airports.
          </p>
        </div>

        {/* Search Module Box */}
        <div className="bg-[#111C38] border border-slate-700/80 rounded-xl p-4 sm:p-6 shadow-2xl backdrop-blur-md">
          {/* Trip mode controls */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 mb-4 border-b border-slate-700/60 text-xs">
            <div className="flex items-center gap-2 bg-[#0B132B] p-1 rounded-lg border border-slate-700">
              <button
                type="button"
                onClick={() => setIsReturn(false)}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  !isReturn ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                One Way
              </button>
              <button
                type="button"
                onClick={() => setIsReturn(true)}
                className={`px-3 py-1.5 rounded-md font-medium transition-colors ${
                  isReturn ? 'bg-slate-700 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                Return Flight
              </button>
            </div>

            <div className="flex items-center gap-4">
              <label className="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white transition-colors">
                <input
                  type="checkbox"
                  checked={directOnly}
                  onChange={(e) => setDirectOnly(e.target.checked)}
                  className="rounded border-slate-600 bg-slate-800 text-sky-500 focus:ring-sky-400"
                />
                <span>Direct flights only</span>
              </label>

              <div className="hidden sm:flex items-center gap-2 text-slate-400">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Zero commercial bias</span>
              </div>
            </div>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-3 items-center">
              {/* Origin Selection */}
              <div className="lg:col-span-3 bg-[#0B132B] border border-slate-700 rounded-lg p-3 hover:border-slate-500 transition-colors">
                <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                  From (Departure)
                </label>
                <select
                  value={origin}
                  onChange={(e) => setOrigin(e.target.value)}
                  className="w-full bg-transparent text-white font-medium text-sm focus:outline-none cursor-pointer"
                >
                  <optgroup label="Multi-Airport Metropolitan Group">
                    <option value="LON" className="bg-slate-900 text-white font-semibold">
                      LON — All London Airports (LHR, LGW, LCY, LTN, STN, SEN)
                    </option>
                  </optgroup>
                  <optgroup label="London Individual Airports">
                    {UK_AIRPORTS.filter(a => a.isLondonCluster).map(a => (
                      <option key={a.code} value={a.code} className="bg-slate-900 text-white">
                        {a.code} — {a.name}
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="Regional UK Airports">
                    {UK_AIRPORTS.filter(a => !a.isLondonCluster).map(a => (
                      <option key={a.code} value={a.code} className="bg-slate-900 text-white">
                        {a.code} — {a.city} ({a.name})
                      </option>
                    ))}
                  </optgroup>
                </select>
              </div>

              {/* Swap Button */}
              <div className="hidden lg:flex lg:col-span-1 justify-center">
                <button
                  type="button"
                  onClick={handleSwapAirports}
                  title="Swap Origin and Destination"
                  className="p-2.5 rounded-full bg-slate-800 border border-slate-600 hover:border-sky-400 hover:text-sky-400 transition-all text-slate-300"
                >
                  <ArrowRightLeft className="w-4 h-4" />
                </button>
              </div>

              {/* Destination Selection */}
              <div className="lg:col-span-3 bg-[#0B132B] border border-slate-700 rounded-lg p-3 hover:border-slate-500 transition-colors">
                <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                  To (Arrival)
                </label>
                <select
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  className="w-full bg-transparent text-white font-medium text-sm focus:outline-none cursor-pointer"
                >
                  <optgroup label="London Metropolitan Area">
                    <option value="LON" className="bg-slate-900 text-white">
                      LON — All London Airports
                    </option>
                  </optgroup>
                  <optgroup label="Scotland">
                    {UK_AIRPORTS.filter(a => a.region === 'Scotland').map(a => (
                      <option key={a.code} value={a.code} className="bg-slate-900 text-white">
                        {a.code} — {a.city} ({a.name})
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="Northern Ireland">
                    {UK_AIRPORTS.filter(a => a.region === 'Northern Ireland').map(a => (
                      <option key={a.code} value={a.code} className="bg-slate-900 text-white">
                        {a.code} — {a.city} ({a.name})
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="England North & Midlands">
                    {UK_AIRPORTS.filter(a => a.region === 'England North' || a.region === 'England Midlands').map(a => (
                      <option key={a.code} value={a.code} className="bg-slate-900 text-white">
                        {a.code} — {a.city} ({a.name})
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="England South & Wales">
                    {UK_AIRPORTS.filter(a => a.region === 'England South' || a.region === 'Wales').map(a => (
                      <option key={a.code} value={a.code} className="bg-slate-900 text-white">
                        {a.code} — {a.city} ({a.name})
                      </option>
                    ))}
                  </optgroup>
                  <optgroup label="Crown Dependencies (Islands)">
                    {UK_AIRPORTS.filter(a => a.region === 'Crown Dependencies').map(a => (
                      <option key={a.code} value={a.code} className="bg-slate-900 text-white">
                        {a.code} — {a.city} ({a.name})
                      </option>
                    ))}
                  </optgroup>
                </select>
              </div>

              {/* Date Pickers */}
              <div className="lg:col-span-3 grid grid-cols-2 gap-2">
                <div className="bg-[#0B132B] border border-slate-700 rounded-lg p-3 hover:border-slate-500 transition-colors">
                  <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                    Depart
                  </label>
                  <input
                    type="date"
                    value={departDate}
                    onChange={(e) => setDepartDate(e.target.value)}
                    className="w-full bg-transparent text-white text-xs sm:text-sm font-medium focus:outline-none cursor-pointer"
                  />
                </div>

                <div className={`bg-[#0B132B] border rounded-lg p-3 transition-colors ${
                  isReturn ? 'border-slate-700 hover:border-slate-500' : 'border-slate-800 opacity-50'
                }`}>
                  <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                    Return
                  </label>
                  <input
                    type="date"
                    disabled={!isReturn}
                    value={returnDate}
                    onChange={(e) => setReturnDate(e.target.value)}
                    className="w-full bg-transparent text-white text-xs sm:text-sm font-medium focus:outline-none cursor-pointer disabled:cursor-not-allowed"
                  />
                </div>
              </div>

              {/* Passengers & Cabin Dropdown */}
              <div className="lg:col-span-2 relative">
                <div
                  onClick={() => setPassengerDropdownOpen(!passengerDropdownOpen)}
                  className="bg-[#0B132B] border border-slate-700 rounded-lg p-3 hover:border-slate-500 transition-colors cursor-pointer"
                >
                  <label className="block text-[11px] font-mono uppercase tracking-wider text-slate-400 mb-1">
                    Traveller & Class
                  </label>
                  <div className="flex items-center justify-between text-xs sm:text-sm font-medium text-white truncate">
                    <span>{adults} Adult · {cabin === 'economy' ? 'Economy' : cabin === 'economy_flex' ? 'Economy Flex' : 'Club Domestic'}</span>
                    <ChevronDown className="w-3.5 h-3.5 text-slate-400 ml-1 shrink-0" />
                  </div>
                </div>

                {passengerDropdownOpen && (
                  <div className="absolute right-0 top-full mt-2 w-72 bg-[#0B132B] border border-slate-700 rounded-xl p-4 shadow-2xl z-50 text-xs">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-semibold text-white">Adults</p>
                          <p className="text-[11px] text-slate-400">Age 16+</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <button
                            type="button"
                            onClick={() => setAdults(Math.max(1, adults - 1))}
                            className="w-7 h-7 rounded border border-slate-700 flex items-center justify-center text-slate-300 hover:text-white"
                          >
                            -
                          </button>
                          <span className="font-mono text-white text-sm font-bold w-4 text-center">{adults}</span>
                          <button
                            type="button"
                            onClick={() => setAdults(Math.min(9, adults + 1))}
                            className="w-7 h-7 rounded border border-slate-700 flex items-center justify-center text-slate-300 hover:text-white"
                          >
                            +
                          </button>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-800">
                        <p className="font-semibold text-white mb-2">Cabin Class</p>
                        <div className="space-y-1.5">
                          {[
                            { id: 'economy', label: 'Economy', desc: 'Standard cabin' },
                            { id: 'economy_flex', label: 'Economy Flex', desc: 'Free changes & refundable' },
                            { id: 'business', label: 'Club Domestic / Business', desc: 'Lounge access & priority' },
                          ].map(c => (
                            <button
                              key={c.id}
                              type="button"
                              onClick={() => setCabin(c.id as CabinClass)}
                              className={`w-full text-left p-2 rounded-lg flex items-center justify-between ${
                                cabin === c.id ? 'bg-slate-800 text-sky-400 font-semibold' : 'text-slate-300 hover:bg-slate-800/50'
                              }`}
                            >
                              <div>
                                <p className="text-xs">{c.label}</p>
                                <p className="text-[10px] text-slate-400 font-normal">{c.desc}</p>
                              </div>
                              {cabin === c.id && <Check className="w-3.5 h-3.5 text-sky-400" />}
                            </button>
                          ))}
                        </div>
                      </div>

                      <button
                        type="button"
                        onClick={() => setPassengerDropdownOpen(false)}
                        className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-semibold"
                      >
                        Done
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-3">
              {/* Flexible date quick buttons */}
              <div className="flex items-center gap-1.5 text-xs text-slate-400 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
                <span className="font-mono text-[10px] uppercase text-slate-500 mr-1">Quick Dates:</span>
                <button
                  type="button"
                  onClick={() => setDepartDate('2026-10-18')}
                  className="px-2.5 py-1 rounded bg-[#0B132B] hover:bg-slate-800 border border-slate-700 text-slate-300 whitespace-nowrap"
                >
                  Sun 18 Oct
                </button>
                <button
                  type="button"
                  onClick={() => setDepartDate('2026-10-19')}
                  className="px-2.5 py-1 rounded bg-[#0B132B] hover:bg-slate-800 border border-slate-700 text-slate-300 whitespace-nowrap"
                >
                  Mon 19 Oct
                </button>
                <button
                  type="button"
                  onClick={() => setDepartDate('2026-10-23')}
                  className="px-2.5 py-1 rounded bg-[#0B132B] hover:bg-slate-800 border border-slate-700 text-slate-300 whitespace-nowrap"
                >
                  Next Weekend
                </button>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                className="w-full sm:w-auto px-8 py-3.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-sm rounded-lg transition-all shadow-lg hover:shadow-sky-500/20 flex items-center justify-center gap-2"
              >
                <span>SEARCH FLIGHTS</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        </div>

        {/* Popular UK Domestic Corridors Strip */}
        <div className="mt-6 pt-4 border-t border-slate-800/80">
          <div className="flex items-center justify-between mb-3 text-xs">
            <span className="text-slate-400 font-medium">Major British Domestic Corridors</span>
            <span className="text-[11px] text-slate-500 font-mono">Live Indicative Fares</span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2">
            {popularCorridors.map((c) => (
              <button
                key={`${c.from}-${c.to}`}
                type="button"
                onClick={() => {
                  setOrigin(c.from);
                  setDestination(c.to);
                  onSearch({
                    originCode: c.from,
                    destinationCode: c.to,
                    departDate,
                    returnDate: isReturn ? returnDate : undefined,
                    isReturn,
                    adults,
                    cabin,
                    directOnly,
                  });
                }}
                className="p-2.5 rounded-lg bg-[#0B132B]/80 hover:bg-slate-800 border border-slate-800 hover:border-slate-600 text-left transition-colors group"
              >
                <p className="text-[11px] font-semibold text-slate-200 group-hover:text-white truncate">
                  {c.from} → {c.to}
                </p>
                <p className="text-[10px] text-sky-400 font-mono mt-0.5">{c.price}</p>
              </button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
