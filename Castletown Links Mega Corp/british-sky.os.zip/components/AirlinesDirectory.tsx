'use client';

import React from 'react';
import { UK_AIRLINES } from '@/lib/aviation/airlines';
import { Plane, ShieldCheck, Luggage, ExternalLink, Activity } from 'lucide-react';

export const AirlinesDirectory: React.FC = () => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="pb-6 mb-6 border-b border-slate-200 dark:border-slate-800">
        <span className="text-xs font-mono uppercase tracking-widest text-sky-600 dark:text-sky-400">
          UK Domestic Air Operators
        </span>
        <h1 className="text-3xl font-bold text-slate-900 dark:text-white tracking-tight mt-1">
          British Domestic Airlines & Carriers
        </h1>
        <p className="text-sm text-slate-600 dark:text-slate-400 mt-1 max-w-2xl">
          Neutral overview of UK domestic airlines, operating fleets, cabin baggage dimensions, and verified punctuality metrics.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {UK_AIRLINES.map(airline => (
          <div
            key={airline.code}
            className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-sm flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs text-white font-mono shadow-sm"
                    style={{ backgroundColor: airline.brandColor }}
                  >
                    {airline.logoText.slice(0, 3)}
                  </div>
                  <div>
                    <h2 className="font-bold text-slate-900 dark:text-white text-base">
                      {airline.name}
                    </h2>
                    <p className="text-[11px] font-mono text-slate-400 uppercase">
                      Callsign: {airline.callsign} · IATA: {airline.code}
                    </p>
                  </div>
                </div>
              </div>

              <div className="space-y-3 text-xs pt-3 border-t border-slate-100 dark:border-slate-800">
                <div>
                  <span className="text-slate-400 uppercase font-mono text-[10px] block">
                    Domestic Fleet
                  </span>
                  <p className="font-medium text-slate-800 dark:text-slate-200 mt-0.5">
                    {airline.fleetOverview}
                  </p>
                </div>

                <div>
                  <span className="text-slate-400 uppercase font-mono text-[10px] block">
                    Domestic Hubs
                  </span>
                  <div className="flex flex-wrap gap-1.5 mt-1 font-mono">
                    {airline.hubs.map(h => (
                      <span key={h} className="bg-slate-100 dark:bg-slate-800 px-2 py-0.5 rounded text-[11px] font-semibold text-slate-700 dark:text-slate-300">
                        {h}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="text-slate-400 uppercase font-mono text-[10px] block">
                    Cabin Baggage Standard
                  </span>
                  <p className="font-medium text-slate-700 dark:text-slate-300 mt-0.5">
                    {airline.baggagePolicy.cabinBagIncluded}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800">
                  <span className="text-slate-500">On-Time Performance</span>
                  <span className="font-mono font-bold text-emerald-600 dark:text-emerald-400">
                    {airline.punctualityScorePct}% Punctual
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-mono">
                {airline.domesticRoutesCount} Scheduled Routes
              </span>
              <a
                href={airline.website}
                target="_blank"
                rel="noreferrer noopener"
                className="text-sky-600 dark:text-sky-400 hover:underline font-semibold flex items-center gap-1"
              >
                <span>Direct Site</span>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
