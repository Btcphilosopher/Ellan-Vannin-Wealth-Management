'use client';

import React from 'react';
import { Plane, Calendar, Activity, MapPin, Building2, Bookmark, SlidersHorizontal, Sparkles } from 'lucide-react';

export type ActiveTab = 'search' | 'timetable' | 'status' | 'network' | 'airports' | 'airlines' | 'mysky' | 'admin';

interface NavbarProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  savedCount: number;
  alertsCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  onTabChange,
  savedCount,
  alertsCount,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full bg-[#0B132B] text-white border-b border-slate-800 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Zone 1: Single Brand Wordmark */}
        <button
          onClick={() => onTabChange('search')}
          className="flex items-center gap-3 text-left group focus:outline-none focus-visible:ring-2 focus-visible:ring-sky-400 rounded-sm"
          aria-label="British Sky Home"
        >
          <div className="w-8 h-8 rounded bg-slate-800 border border-slate-700 flex items-center justify-center text-sky-400 group-hover:border-sky-400 transition-colors">
            <Plane className="w-4 h-4 transform -rotate-45" />
          </div>
          <div>
            <span className="text-base font-semibold tracking-wider font-sans uppercase text-slate-100 group-hover:text-white">
              BRITISH SKY
            </span>
            <span className="text-[10px] tracking-widest text-sky-400 ml-2 font-mono uppercase">
              DOMESTIC AVIATION
            </span>
          </div>
        </button>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2 text-sm font-medium text-slate-300">
          <button
            onClick={() => onTabChange('search')}
            className={`px-3 py-2 rounded-md transition-colors flex items-center gap-1.5 ${
              activeTab === 'search'
                ? 'bg-slate-800 text-white font-semibold'
                : 'hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Plane className="w-3.5 h-3.5" />
            <span>Search Flights</span>
          </button>

          <button
            onClick={() => onTabChange('timetable')}
            className={`px-3 py-2 rounded-md transition-colors flex items-center gap-1.5 ${
              activeTab === 'timetable'
                ? 'bg-slate-800 text-white font-semibold'
                : 'hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Timetables</span>
          </button>

          <button
            onClick={() => onTabChange('status')}
            className={`px-3 py-2 rounded-md transition-colors flex items-center gap-1.5 ${
              activeTab === 'status'
                ? 'bg-slate-800 text-white font-semibold'
                : 'hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Activity className="w-3.5 h-3.5" />
            <span>Flight Status</span>
          </button>

          <button
            onClick={() => onTabChange('network')}
            className={`px-3 py-2 rounded-md transition-colors flex items-center gap-1.5 ${
              activeTab === 'network'
                ? 'bg-slate-800 text-white font-semibold'
                : 'hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>Where Can I Fly?</span>
          </button>

          <button
            onClick={() => onTabChange('airports')}
            className={`px-3 py-2 rounded-md transition-colors flex items-center gap-1.5 ${
              activeTab === 'airports'
                ? 'bg-slate-800 text-white font-semibold'
                : 'hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Airports</span>
          </button>

          <button
            onClick={() => onTabChange('airlines')}
            className={`hidden lg:flex px-3 py-2 rounded-md transition-colors items-center gap-1.5 ${
              activeTab === 'airlines'
                ? 'bg-slate-800 text-white font-semibold'
                : 'hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <span>Airlines</span>
          </button>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            onClick={() => onTabChange('mysky')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors flex items-center gap-2 border ${
              activeTab === 'mysky'
                ? 'bg-slate-800 text-white border-slate-600'
                : 'border-slate-700 text-slate-300 hover:text-white hover:border-slate-500'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden sm:inline">My British Sky</span>
            {(savedCount > 0 || alertsCount > 0) && (
              <span className="text-[10px] font-mono font-bold bg-sky-500/20 text-sky-300 px-1.5 py-0.5 rounded">
                {savedCount + alertsCount}
              </span>
            )}
          </button>

          <button
            onClick={() => onTabChange('admin')}
            title="Flight Operations & Simulation Console"
            className={`p-2 rounded-md border text-slate-400 hover:text-white transition-colors ${
              activeTab === 'admin'
                ? 'bg-slate-800 border-slate-600 text-sky-400'
                : 'border-slate-800 hover:border-slate-700'
            }`}
            aria-label="Simulation Console"
          >
            <SlidersHorizontal className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mobile subnav */}
      <div className="md:hidden flex items-center justify-around border-t border-slate-800 py-2 px-3 text-xs text-slate-300 overflow-x-auto gap-2">
        <button
          onClick={() => onTabChange('search')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${activeTab === 'search' ? 'bg-slate-800 text-white font-semibold' : ''}`}
        >
          Flights
        </button>
        <button
          onClick={() => onTabChange('timetable')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${activeTab === 'timetable' ? 'bg-slate-800 text-white font-semibold' : ''}`}
        >
          Timetables
        </button>
        <button
          onClick={() => onTabChange('status')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${activeTab === 'status' ? 'bg-slate-800 text-white font-semibold' : ''}`}
        >
          Status
        </button>
        <button
          onClick={() => onTabChange('network')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${activeTab === 'network' ? 'bg-slate-800 text-white font-semibold' : ''}`}
        >
          Map
        </button>
        <button
          onClick={() => onTabChange('airports')}
          className={`px-2.5 py-1 rounded whitespace-nowrap ${activeTab === 'airports' ? 'bg-slate-800 text-white font-semibold' : ''}`}
        >
          Airports
        </button>
      </div>
    </header>
  );
};
