'use client';

import React from 'react';
import { generateDatePriceCalendar, DatePricePoint } from '@/lib/aviation/simulator';
import { Calendar as CalendarIcon, TrendingDown } from 'lucide-react';

interface PriceCalendarProps {
  originCode: string;
  destCode: string;
  currentDate: string;
  onSelectDate: (date: string) => void;
}

export const PriceCalendar: React.FC<PriceCalendarProps> = ({
  originCode,
  destCode,
  currentDate,
  onSelectDate,
}) => {
  const points: DatePricePoint[] = generateDatePriceCalendar(originCode, destCode, currentDate);
  const lowestPriceOverall = Math.min(...points.map(p => p.lowestPriceGbp));

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 shadow-sm mb-6">
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <CalendarIcon className="w-4 h-4 text-slate-500" />
          <h2 className="text-sm font-semibold text-slate-900 dark:text-slate-100">
            Flexible Date Fare Matrix
          </h2>
          <span className="text-xs text-slate-400">·</span>
          <span className="text-xs text-slate-500 dark:text-slate-400">
            Direct & connecting domestic fares
          </span>
        </div>

        <div className="flex items-center gap-2 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
          <TrendingDown className="w-3.5 h-3.5" />
          <span>Cheapest flight: £{lowestPriceOverall}</span>
        </div>
      </div>

      {/* Date-Price Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2">
        {points.map((p) => {
          const isSelected = p.isTargetDate || p.date === currentDate;
          return (
            <button
              key={p.date}
              type="button"
              onClick={() => onSelectDate(p.date)}
              className={`p-3 rounded-lg border text-left transition-all relative ${
                isSelected
                  ? 'bg-slate-900 text-white border-slate-900 dark:bg-sky-950 dark:border-sky-500 shadow-md ring-1 ring-sky-400'
                  : p.isCheapest
                  ? 'bg-emerald-50/70 border-emerald-300 dark:bg-emerald-950/30 dark:border-emerald-800 hover:border-emerald-400'
                  : 'bg-slate-50 dark:bg-slate-800/60 border-slate-200 dark:border-slate-700/80 hover:border-slate-400 dark:hover:border-slate-600'
              }`}
            >
              {p.isCheapest && (
                <span className="absolute top-1.5 right-1.5 text-[9px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-300 bg-emerald-100 dark:bg-emerald-900/60 px-1 py-0.5 rounded">
                  Low
                </span>
              )}

              <p className={`text-xs font-medium ${isSelected ? 'text-slate-200' : 'text-slate-600 dark:text-slate-400'}`}>
                {p.dayLabel}
              </p>

              <div className="mt-1 flex items-baseline justify-between">
                <span className={`text-lg font-bold font-mono tracking-tight ${isSelected ? 'text-white' : p.isCheapest ? 'text-emerald-700 dark:text-emerald-300' : 'text-slate-900 dark:text-white'}`}>
                  £{p.lowestPriceGbp}
                </span>
                <span className={`text-[10px] ${isSelected ? 'text-slate-300' : 'text-slate-400'}`}>
                  {p.flightCount} flts
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
