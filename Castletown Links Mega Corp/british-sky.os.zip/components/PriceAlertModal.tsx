'use client';

import React, { useState } from 'react';
import { PriceAlert, SearchQuery } from '@/lib/aviation/types';
import { Bell, X, Check, ShieldCheck } from 'lucide-react';
import { createPriceAlert } from '@/lib/aviation/simulator';

interface PriceAlertModalProps {
  query: SearchQuery;
  currentLowestPrice: number;
  onClose: () => void;
  onCreated: (alert: PriceAlert) => void;
}

export const PriceAlertModal: React.FC<PriceAlertModalProps> = ({
  query,
  currentLowestPrice,
  onClose,
  onCreated,
}) => {
  const [targetPrice, setTargetPrice] = useState<number>(Math.max(20, Math.round(currentLowestPrice * 0.85)));
  const [email, setEmail] = useState<string>('tom@ahyx.org');
  const [saved, setSaved] = useState<boolean>(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newAlert: PriceAlert = {
      id: `alert-${Date.now()}`,
      originCode: query.originCode,
      destinationCode: query.destinationCode,
      targetPriceGbp: targetPrice,
      currentLowestPriceGbp: currentLowestPrice,
      date: query.departDate,
      createdAt: new Date().toISOString().split('T')[0],
      passengerEmail: email,
      trend: 'falling',
    };

    createPriceAlert(newAlert);
    onCreated(newAlert);
    setSaved(true);
    setTimeout(() => {
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-md w-full p-6 shadow-2xl">
        <div className="flex items-start justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-sky-100 dark:bg-sky-950 flex items-center justify-center text-sky-600 dark:text-sky-400">
              <Bell className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-bold text-slate-900 dark:text-white text-base">
                Track Domestic Route Price
              </h3>
              <p className="text-xs text-slate-500">
                {query.originCode} → {query.destinationCode} · {query.departDate}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {saved ? (
          <div className="py-8 text-center space-y-2">
            <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
              <Check className="w-6 h-6" />
            </div>
            <p className="font-bold text-slate-900 dark:text-white">Price Alert Active</p>
            <p className="text-xs text-slate-500">
              We will notify you at {email} when fares drop below £{targetPrice}.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4 my-4">
            <div>
              <div className="flex justify-between text-xs mb-1">
                <span className="text-slate-600 dark:text-slate-400">Current lowest fare:</span>
                <span className="font-bold font-mono text-slate-900 dark:text-white">£{currentLowestPrice}</span>
              </div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mt-3 mb-1">
                Alert me if fare drops to or below:
              </label>
              <div className="flex items-center gap-2">
                <span className="text-lg font-bold text-slate-500">£</span>
                <input
                  type="number"
                  min="15"
                  max={currentLowestPrice}
                  value={targetPrice}
                  onChange={(e) => setTargetPrice(parseInt(e.target.value, 10) || 20)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white font-mono font-bold text-base focus:outline-none focus:ring-2 focus:ring-sky-500"
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Suggested target: £{Math.round(currentLowestPrice * 0.85)} (15% reduction)
              </p>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 dark:text-slate-300 mb-1">
                Notification Email
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="passenger@example.co.uk"
                className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white text-xs focus:outline-none focus:ring-2 focus:ring-sky-500"
              />
            </div>

            <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex gap-2">
              <button
                type="button"
                onClick={onClose}
                className="w-1/3 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-300"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="w-2/3 py-2.5 rounded-lg bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs shadow-md"
              >
                Set Price Watch
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
