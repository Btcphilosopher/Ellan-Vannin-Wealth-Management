'use client';

import React from 'react';
import { FareTier, Flight } from '@/lib/aviation/types';
import { Check, X, ShieldAlert, Sparkles, Briefcase, RefreshCw, Armchair } from 'lucide-react';

interface FareFamilyComparisonProps {
  flight: Flight;
  onSelectFare: (tier: FareTier) => void;
  onClose: () => void;
}

export const FareFamilyComparison: React.FC<FareFamilyComparisonProps> = ({
  flight,
  onSelectFare,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/70 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-5xl w-full p-6 sm:p-8 shadow-2xl my-8">
        {/* Header */}
        <div className="flex items-start justify-between pb-6 border-b border-slate-200 dark:border-slate-800">
          <div>
            <span className="text-xs font-mono uppercase tracking-widest text-sky-600 dark:text-sky-400">
              Fare Family Specification
            </span>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white mt-1">
              {flight.airlineName} · {flight.flightNumber}
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
              {flight.originCity} ({flight.originCode}) → {flight.destinationCity} ({flight.destinationCode}) · {flight.departureTime}–{flight.arrivalTime} ({flight.durationMinutes}m)
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Fare Family Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          {flight.fareTiers.map((tier) => {
            const isClub = tier.type === 'club_domestic';
            const isFlex = tier.type === 'economy_flex';
            const isStandard = tier.type === 'economy_standard';

            return (
              <div
                key={tier.type}
                className={`rounded-xl border p-5 flex flex-col justify-between transition-all ${
                  isClub
                    ? 'bg-slate-950 text-white border-sky-600/60 shadow-lg relative'
                    : isFlex
                    ? 'bg-sky-50/40 dark:bg-sky-950/20 border-sky-300 dark:border-sky-800'
                    : 'bg-slate-50 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700'
                }`}
              >
                <div>
                  {isClub && (
                    <div className="mb-2 text-[10px] font-mono tracking-widest text-sky-400 uppercase font-semibold">
                      Flagship Tier
                    </div>
                  )}

                  <h3 className={`text-base font-bold ${isClub ? 'text-white' : 'text-slate-900 dark:text-white'}`}>
                    {tier.title}
                  </h3>

                  <div className="mt-3 mb-4">
                    <div className="flex items-baseline gap-1">
                      <span className={`text-3xl font-bold font-mono tracking-tight ${isClub ? 'text-sky-400' : 'text-slate-900 dark:text-white'}`}>
                        £{tier.price}
                      </span>
                      <span className={`text-xs ${isClub ? 'text-slate-400' : 'text-slate-500'}`}>
                        / passenger
                      </span>
                    </div>
                    <p className={`text-[11px] mt-1 ${isClub ? 'text-slate-300' : 'text-slate-600 dark:text-slate-400'}`}>
                      {tier.tierDescription}
                    </p>
                  </div>

                  <div className="space-y-3 pt-4 border-t border-slate-200/80 dark:border-slate-700/60 text-xs">
                    {/* Cabin Baggage */}
                    <div>
                      <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                        Cabin Baggage
                      </p>
                      <p className={`font-medium mt-0.5 ${isClub ? 'text-slate-200' : 'text-slate-700 dark:text-slate-300'}`}>
                        {tier.cabinBag}
                      </p>
                    </div>

                    {/* Checked Baggage */}
                    <div>
                      <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                        Checked Baggage
                      </p>
                      <p className={`font-medium mt-0.5 ${isClub ? 'text-slate-200' : 'text-slate-700 dark:text-slate-300'}`}>
                        {tier.checkedBag}
                      </p>
                    </div>

                    {/* Seat Selection */}
                    <div>
                      <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                        Seat Assignment
                      </p>
                      <p className={`font-medium mt-0.5 ${isClub ? 'text-slate-200' : 'text-slate-700 dark:text-slate-300'}`}>
                        {tier.seatSelection}
                      </p>
                    </div>

                    {/* Ticket Changes */}
                    <div>
                      <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                        Ticket Flexibility
                      </p>
                      <p className={`font-medium mt-0.5 ${isClub ? 'text-slate-200' : 'text-slate-700 dark:text-slate-300'}`}>
                        {tier.changes}
                      </p>
                    </div>

                    {/* Cancellation & Refunds */}
                    <div>
                      <p className="text-[10px] font-mono uppercase tracking-wider text-slate-400">
                        Refund Terms
                      </p>
                      <p className={`font-medium mt-0.5 ${isClub ? 'text-slate-200' : 'text-slate-700 dark:text-slate-300'}`}>
                        {tier.refunds}
                      </p>
                    </div>

                    {/* Priority & Lounge */}
                    <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/40">
                      <div className="flex items-center justify-between py-1">
                        <span className="text-slate-500 dark:text-slate-400">Boarding</span>
                        <span className={`font-semibold ${isClub ? 'text-sky-400' : 'text-slate-700 dark:text-slate-300'}`}>
                          {tier.boardingPriority}
                        </span>
                      </div>
                      <div className="flex items-center justify-between py-1">
                        <span className="text-slate-500 dark:text-slate-400">Airport Lounge</span>
                        <span className="font-semibold">
                          {tier.loungeAccess ? (
                            <span className="text-emerald-500 flex items-center gap-1">
                              <Check className="w-3.5 h-3.5" /> Included
                            </span>
                          ) : (
                            <span className="text-slate-400">None</span>
                          )}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="mt-6 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      onSelectFare(tier);
                      onClose();
                    }}
                    className={`w-full py-2.5 px-4 rounded-lg font-bold text-xs transition-all shadow-sm ${
                      isClub
                        ? 'bg-sky-500 hover:bg-sky-400 text-slate-950'
                        : isFlex
                        ? 'bg-slate-900 dark:bg-sky-600 hover:bg-slate-800 dark:hover:bg-sky-500 text-white'
                        : 'bg-slate-800 hover:bg-slate-700 text-white'
                    }`}
                  >
                    Select {tier.title} · £{tier.price}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Institutional disclosure */}
        <div className="mt-8 pt-4 border-t border-slate-200 dark:border-slate-800 text-xs text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p>
            All listed fares include UK Air Passenger Duty (APD) and mandatory airport security charges.
          </p>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            Close Comparison
          </button>
        </div>
      </div>
    </div>
  );
};
