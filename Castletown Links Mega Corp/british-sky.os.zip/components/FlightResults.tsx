'use client';

import React, { useState, useMemo } from 'react';
import { Flight, FareTier, SearchFilterState, SearchQuery } from '@/lib/aviation/types';
import { applyFiltersAndSort } from '@/lib/aviation/simulator';
import { PriceCalendar } from './PriceCalendar';
import { FareFamilyComparison } from './FareFamilyComparison';
import { BookingHandoffModal } from './BookingHandoffModal';
import { FlightDetailModal } from './FlightDetailModal';
import { PriceAlertModal } from './PriceAlertModal';
import {
  Plane,
  Clock,
  ArrowUpDown,
  Filter,
  ChevronDown,
  ChevronUp,
  Bookmark,
  Bell,
  Check,
  ShieldCheck,
  AlertTriangle,
  Info,
  Sliders,
  ExternalLink,
  Luggage,
} from 'lucide-react';
import { UK_AIRLINES } from '@/lib/aviation/airlines';
import { getAirportByCode } from '@/lib/aviation/airports';

interface FlightResultsProps {
  rawFlights: Flight[];
  query: SearchQuery;
  searchLatencyMs: number;
  onDateChange: (newDate: string) => void;
  onSaveFlight: (flight: Flight) => void;
  savedFlightIds: string[];
}

export const FlightResults: React.FC<FlightResultsProps> = ({
  rawFlights,
  query,
  searchLatencyMs,
  onDateChange,
  onSaveFlight,
  savedFlightIds,
}) => {
  // Filters state
  const [filters, setFilters] = useState<SearchFilterState>({
    selectedAirlines: [],
    selectedDepartureAirports: [],
    selectedArrivalAirports: [],
    maxPrice: 300,
    minDepartureHour: 0,
    maxDepartureHour: 24,
    maxDurationMins: 360,
    directOnly: query.directOnly || false,
    hasBaggageIncluded: false,
    hasFreeCancellation: false,
    cabin: query.cabin || 'all',
    sortBy: 'recommended',
  });

  const [expandedBreakdownId, setExpandedBreakdownId] = useState<string | null>(null);
  const [selectedFlightForFares, setSelectedFlightForFares] = useState<Flight | null>(null);
  const [selectedFlightForDetails, setSelectedFlightForDetails] = useState<Flight | null>(null);
  const [selectedFlightForBooking, setSelectedFlightForBooking] = useState<{ flight: Flight; tier?: FareTier } | null>(null);
  const [isAlertModalOpen, setIsAlertModalOpen] = useState<boolean>(false);
  const [filterDrawerOpenMobile, setFilterDrawerOpenMobile] = useState<boolean>(false);

  // Filtered flights calculation
  const filteredFlights = useMemo(() => {
    return applyFiltersAndSort(rawFlights, filters);
  }, [rawFlights, filters]);

  const lowestPriceAvailable = useMemo(() => {
    if (rawFlights.length === 0) return 0;
    return Math.min(...rawFlights.map(f => f.totalPrice));
  }, [rawFlights]);

  const uniqueAirlines = useMemo(() => {
    const codes = Array.from(new Set(rawFlights.map(f => f.airlineCode)));
    return codes.map(c => UK_AIRLINES.find(a => a.code === c)).filter(Boolean);
  }, [rawFlights]);

  const uniqueOriginAirports = useMemo(() => {
    const codes = Array.from(new Set(rawFlights.map(f => f.originCode)));
    return codes.map(c => getAirportByCode(c)).filter(Boolean);
  }, [rawFlights]);

  const toggleAirlineFilter = (code: string) => {
    setFilters(prev => {
      const exists = prev.selectedAirlines.includes(code);
      return {
        ...prev,
        selectedAirlines: exists
          ? prev.selectedAirlines.filter(c => c !== code)
          : [...prev.selectedAirlines, code],
      };
    });
  };

  const toggleOriginAirportFilter = (code: string) => {
    setFilters(prev => {
      const exists = prev.selectedDepartureAirports.includes(code);
      return {
        ...prev,
        selectedDepartureAirports: exists
          ? prev.selectedDepartureAirports.filter(c => c !== code)
          : [...prev.selectedDepartureAirports, code],
      };
    });
  };

  const originName = query.originCode === 'LON' ? 'London (All Airports)' : getAirportByCode(query.originCode)?.city || query.originCode;
  const destName = query.destinationCode === 'LON' ? 'London (All Airports)' : getAirportByCode(query.destinationCode)?.city || query.destinationCode;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Route Header Banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between pb-6 mb-6 border-b border-slate-200 dark:border-slate-800 gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-widest text-slate-500 dark:text-slate-400 mb-1">
            <span>Domestic Flight Index</span>
            <span>·</span>
            <span>UK National Aviation Infrastructure</span>
            <span>·</span>
            <span className="text-emerald-600 dark:text-emerald-400 font-bold">{searchLatencyMs}ms query</span>
          </div>

          <h1 className="text-2xl sm:text-3xl font-bold text-slate-900 dark:text-white tracking-tight">
            {originName} → {destName}
          </h1>

          <div className="flex flex-wrap items-center gap-3 text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
            <span>{query.departDate}</span>
            <span aria-hidden="true">·</span>
            <span>{query.adults} {query.adults === 1 ? 'Adult' : 'Adults'}</span>
            <span aria-hidden="true">·</span>
            <span className="capitalize">{query.cabin.replace('_', ' ')}</span>
            <span aria-hidden="true">·</span>
            <span className="font-semibold text-slate-900 dark:text-white">
              {filteredFlights.length} of {rawFlights.length} Services Available
            </span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={() => setIsAlertModalOpen(true)}
            className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 hover:bg-slate-50 dark:hover:bg-slate-800 text-xs font-semibold text-slate-700 dark:text-slate-200 transition-colors flex items-center gap-2 shadow-sm"
          >
            <Bell className="w-3.5 h-3.5 text-sky-500" />
            <span>Watch Fares for this Route</span>
          </button>

          <button
            type="button"
            onClick={() => setFilterDrawerOpenMobile(!filterDrawerOpenMobile)}
            className="lg:hidden px-4 py-2 rounded-lg bg-slate-900 text-white dark:bg-slate-800 text-xs font-semibold flex items-center gap-2"
          >
            <Filter className="w-3.5 h-3.5" />
            <span>Filters</span>
          </button>
        </div>
      </div>

      {/* Flexible Date Heatmap Strip */}
      <PriceCalendar
        originCode={query.originCode}
        destCode={query.destinationCode}
        currentDate={query.departDate}
        onSelectDate={onDateChange}
      />

      {/* Main Results Layout: 2 Columns (Filter Rail + Flight Stream) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Filter Rail (Desktop) */}
        <aside
          className={`lg:col-span-3 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 p-5 space-y-6 ${
            filterDrawerOpenMobile ? 'block' : 'hidden lg:block'
          }`}
        >
          <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
            <h2 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider font-mono">
              Search Filters
            </h2>
            <button
              type="button"
              onClick={() =>
                setFilters({
                  selectedAirlines: [],
                  selectedDepartureAirports: [],
                  selectedArrivalAirports: [],
                  maxPrice: 300,
                  minDepartureHour: 0,
                  maxDepartureHour: 24,
                  maxDurationMins: 360,
                  directOnly: false,
                  hasBaggageIncluded: false,
                  hasFreeCancellation: false,
                  cabin: 'all',
                  sortBy: 'recommended',
                })
              }
              className="text-xs text-sky-600 dark:text-sky-400 hover:underline font-medium"
            >
              Reset all
            </button>
          </div>

          {/* Stops Filter */}
          <div>
            <h3 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider text-slate-400 mb-2 font-mono">
              Flight Stops
            </h3>
            <div className="space-y-1.5 text-xs">
              <label className="flex items-center justify-between p-2 rounded hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={filters.directOnly}
                    onChange={(e) => setFilters(prev => ({ ...prev, directOnly: e.target.checked }))}
                    className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                  />
                  <span className="text-slate-700 dark:text-slate-300">Direct flights only</span>
                </div>
                <span className="text-slate-400 font-mono">
                  {rawFlights.filter(f => f.isDirect).length}
                </span>
              </label>
            </div>
          </div>

          {/* Price Range Slider */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <h3 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider text-slate-400 font-mono">
                Maximum Price
              </h3>
              <span className="font-mono text-xs font-bold text-slate-900 dark:text-white">
                £{filters.maxPrice}
              </span>
            </div>
            <input
              type="range"
              min="30"
              max="250"
              step="5"
              value={filters.maxPrice}
              onChange={(e) => setFilters(prev => ({ ...prev, maxPrice: parseInt(e.target.value, 10) }))}
              className="w-full accent-sky-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-400 mt-1">
              <span>£30</span>
              <span>£250</span>
            </div>
          </div>

          {/* Airlines Filter */}
          <div>
            <h3 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider text-slate-400 mb-2 font-mono">
              Airlines
            </h3>
            <div className="space-y-1.5 text-xs">
              {uniqueAirlines.map(airline => {
                if (!airline) return null;
                const isSelected = filters.selectedAirlines.includes(airline.code);
                const count = rawFlights.filter(f => f.airlineCode === airline.code).length;
                return (
                  <label
                    key={airline.code}
                    className="flex items-center justify-between p-2 rounded hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer"
                  >
                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleAirlineFilter(airline.code)}
                        className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                      />
                      <span className="text-slate-700 dark:text-slate-300 font-medium">{airline.name}</span>
                    </div>
                    <span className="text-slate-400 font-mono">{count}</span>
                  </label>
                );
              })}
            </div>
          </div>

          {/* Departure Airport Filter (especially London multi-airport) */}
          {uniqueOriginAirports.length > 1 && (
            <div>
              <h3 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider text-slate-400 mb-2 font-mono">
                Departure Airports
              </h3>
              <div className="space-y-1.5 text-xs">
                {uniqueOriginAirports.map(airport => {
                  if (!airport) return null;
                  const isSelected = filters.selectedDepartureAirports.includes(airport.code);
                  const count = rawFlights.filter(f => f.originCode === airport.code).length;
                  return (
                    <label
                      key={airport.code}
                      className="flex items-center justify-between p-2 rounded hover:bg-slate-50 dark:hover:bg-slate-800/50 cursor-pointer"
                    >
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={isSelected}
                          onChange={() => toggleOriginAirportFilter(airport.code)}
                          className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                        />
                        <span className="text-slate-700 dark:text-slate-300">
                          {airport.code} — {airport.name.replace(' Airport', '')}
                        </span>
                      </div>
                      <span className="text-slate-400 font-mono">{count}</span>
                    </label>
                  );
                })}
              </div>
            </div>
          )}

          {/* Departure Time of Day */}
          <div>
            <h3 className="text-xs font-semibold text-slate-900 dark:text-white uppercase tracking-wider text-slate-400 mb-2 font-mono">
              Departure Time
            </h3>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <button
                type="button"
                onClick={() => setFilters(prev => ({ ...prev, minDepartureHour: 6, maxDepartureHour: 12 }))}
                className="p-2 rounded border border-slate-200 dark:border-slate-800 hover:border-sky-400 text-left"
              >
                <span className="font-semibold block text-slate-900 dark:text-white">Morning</span>
                <span className="text-[10px] text-slate-400 font-mono">06:00 – 12:00</span>
              </button>
              <button
                type="button"
                onClick={() => setFilters(prev => ({ ...prev, minDepartureHour: 12, maxDepartureHour: 18 }))}
                className="p-2 rounded border border-slate-200 dark:border-slate-800 hover:border-sky-400 text-left"
              >
                <span className="font-semibold block text-slate-900 dark:text-white">Afternoon</span>
                <span className="text-[10px] text-slate-400 font-mono">12:00 – 18:00</span>
              </button>
              <button
                type="button"
                onClick={() => setFilters(prev => ({ ...prev, minDepartureHour: 18, maxDepartureHour: 23 }))}
                className="p-2 rounded border border-slate-200 dark:border-slate-800 hover:border-sky-400 text-left"
              >
                <span className="font-semibold block text-slate-900 dark:text-white">Evening</span>
                <span className="text-[10px] text-slate-400 font-mono">18:00 – 23:00</span>
              </button>
              <button
                type="button"
                onClick={() => setFilters(prev => ({ ...prev, minDepartureHour: 0, maxDepartureHour: 24 }))}
                className="p-2 rounded border border-slate-200 dark:border-slate-800 hover:border-sky-400 text-left"
              >
                <span className="font-semibold block text-slate-900 dark:text-white">All Day</span>
                <span className="text-[10px] text-slate-400 font-mono">Any time</span>
              </button>
            </div>
          </div>

          {/* Baggage filter */}
          <div className="pt-2 border-t border-slate-200 dark:border-slate-800">
            <label className="flex items-center gap-2 text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
              <input
                type="checkbox"
                checked={filters.hasBaggageIncluded}
                onChange={(e) => setFilters(prev => ({ ...prev, hasBaggageIncluded: e.target.checked }))}
                className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
              />
              <span>Full cabin baggage included</span>
            </label>
          </div>
        </aside>

        {/* Right Flight Stream */}
        <main className="lg:col-span-9 space-y-4">
          {/* Sorting Bar */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-2 sm:p-3 flex flex-wrap items-center justify-between gap-2 shadow-sm text-xs">
            <div className="flex items-center gap-1 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
              <span className="text-slate-500 uppercase tracking-wider font-mono mr-1 hidden sm:inline">
                Sort:
              </span>
              {[
                { id: 'recommended', label: 'Recommended' },
                { id: 'price_low', label: 'Lowest Price' },
                { id: 'duration_fast', label: 'Fastest' },
                { id: 'departure_early', label: 'Earliest' },
                { id: 'departure_late', label: 'Latest' },
                { id: 'fewest_stops', label: 'Fewest Stops' },
              ].map((s) => (
                <button
                  key={s.id}
                  type="button"
                  onClick={() => setFilters(prev => ({ ...prev, sortBy: s.id as any }))}
                  className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-colors ${
                    filters.sortBy === s.id
                      ? 'bg-slate-900 text-white dark:bg-sky-500 dark:text-slate-950 font-bold shadow-sm'
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>

            <div className="text-slate-500 text-[11px] font-mono hidden md:block">
              Total price includes UK APD & mandatory fees
            </div>
          </div>

          {/* Results List */}
          {filteredFlights.length === 0 ? (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-12 text-center">
              <Plane className="w-10 h-10 text-slate-300 dark:text-slate-700 mx-auto mb-3" />
              <h3 className="text-base font-bold text-slate-900 dark:text-white">
                No domestic flights match your current filters
              </h3>
              <p className="text-xs text-slate-500 dark:text-slate-400 max-w-sm mx-auto mt-1 mb-4">
                Try widening your price limit or clearing specific airline/airport constraints.
              </p>
              <button
                type="button"
                onClick={() =>
                  setFilters(prev => ({
                    ...prev,
                    selectedAirlines: [],
                    selectedDepartureAirports: [],
                    maxPrice: 300,
                    directOnly: false,
                  }))
                }
                className="px-4 py-2 rounded-lg bg-slate-900 text-white text-xs font-semibold"
              >
                Clear all filters
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredFlights.map((flight) => {
                const isSaved = savedFlightIds.includes(flight.id);
                const isExpanded = expandedBreakdownId === flight.id;
                const originAirport = getAirportByCode(flight.originCode);
                const destAirport = getAirportByCode(flight.destinationCode);

                return (
                  <div
                    key={flight.id}
                    className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-4 sm:p-5 shadow-sm hover:border-slate-300 dark:hover:border-slate-700 transition-all"
                  >
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                      {/* Left: Flight Times & Trajectory */}
                      <div className="flex-1">
                        {/* Airline & Status Bar */}
                        <div className="flex items-center gap-3 mb-3 text-xs">
                          <span className="font-bold text-slate-900 dark:text-white uppercase tracking-wider font-mono">
                            {flight.airlineName}
                          </span>
                          <span className="text-slate-400">·</span>
                          <span className="font-mono text-slate-500 dark:text-slate-400">
                            {flight.flightNumber}
                          </span>
                          <span className="text-slate-400">·</span>
                          <span className="text-slate-500 dark:text-slate-400">
                            {flight.aircraft.model}
                          </span>

                          {flight.status === 'Delayed' && (
                            <span className="text-amber-600 dark:text-amber-400 font-semibold flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" />
                              Delayed (+{flight.departureDelayMins}m)
                            </span>
                          )}

                          {flight.status === 'Cancelled' && (
                            <span className="text-rose-600 dark:text-rose-400 font-semibold">
                              Cancelled
                            </span>
                          )}
                        </div>

                        {/* Core Timetable Info */}
                        <div className="grid grid-cols-1 sm:grid-cols-3 items-center gap-2">
                          {/* Departure */}
                          <div>
                            <div className="flex items-baseline gap-2">
                              <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
                                {flight.departureTime}
                              </span>
                              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 font-mono">
                                {flight.originCode}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                              {originAirport?.name || flight.originName}
                            </p>
                          </div>

                          {/* Duration Graphic */}
                          <div className="text-center px-2 my-1 sm:my-0">
                            <span className="text-[11px] font-mono text-slate-500 dark:text-slate-400 block">
                              {flight.durationMinutes}m · {flight.isDirect ? 'Direct' : `${flight.stops} Stop (${flight.stopoverAirportCode})`}
                            </span>
                            <div className="relative my-1">
                              <div className="h-0.5 bg-slate-200 dark:bg-slate-700 w-full" />
                              <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white dark:bg-slate-900 px-1.5">
                                <Plane className="w-3.5 h-3.5 text-slate-400" />
                              </div>
                            </div>
                            <span className="text-[10px] text-emerald-600 dark:text-emerald-400">
                              {flight.isDirect ? 'Direct non-stop' : flight.isProtectedConnection ? 'Protected transfer' : 'Self-connect'}
                            </span>
                          </div>

                          {/* Arrival */}
                          <div className="sm:text-right">
                            <div className="flex items-baseline gap-2 sm:justify-end">
                              <span className="text-xs font-bold text-slate-700 dark:text-slate-300 font-mono">
                                {flight.destinationCode}
                              </span>
                              <span className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
                                {flight.arrivalTime}
                              </span>
                            </div>
                            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">
                              {destAirport?.name || flight.destinationName}
                            </p>
                          </div>
                        </div>

                        {/* Extra metadata */}
                        <div className="flex flex-wrap items-center gap-3 mt-3 pt-2 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-500 dark:text-slate-400">
                          <span className="flex items-center gap-1">
                            <Luggage className="w-3 h-3 text-slate-400" />
                            {flight.airlineCode === 'BA' || flight.airlineCode === 'LM'
                              ? 'Hand bag + cabin bag included'
                              : 'Personal underseat bag included'}
                          </span>
                          <span>·</span>
                          <span>{flight.availableSeats} seats remaining</span>
                          <span>·</span>
                          <button
                            type="button"
                            onClick={() => setSelectedFlightForFares(flight)}
                            className="text-sky-600 dark:text-sky-400 hover:underline font-semibold"
                          >
                            Compare Fare Families →
                          </button>
                        </div>
                      </div>

                      {/* Right: Price & CTA Box */}
                      <div className="md:w-52 md:border-l md:border-slate-200 md:dark:border-slate-800 md:pl-5 flex flex-col justify-between items-start md:items-end pt-3 md:pt-0 border-t md:border-t-0 border-slate-100 dark:border-slate-800">
                        <div className="w-full md:text-right">
                          <span className="text-[10px] font-mono text-slate-400 uppercase">
                            Total Payable
                          </span>
                          <div className="flex items-baseline md:justify-end gap-1">
                            <span className="text-3xl font-bold font-mono text-slate-900 dark:text-white tracking-tight">
                              £{flight.totalPrice}
                            </span>
                          </div>
                          <button
                            type="button"
                            onClick={() => setExpandedBreakdownId(isExpanded ? null : flight.id)}
                            className="text-[11px] text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center md:justify-end gap-1 mt-0.5"
                          >
                            <span>Price breakdown</span>
                            {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                          </button>
                        </div>

                        {/* Actions */}
                        <div className="w-full space-y-2 mt-4">
                          <button
                            type="button"
                            onClick={() => setSelectedFlightForBooking({ flight })}
                            className="w-full py-2.5 px-4 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-lg transition-all shadow-sm flex items-center justify-center gap-1.5"
                          >
                            <span>CONTINUE TO BOOK</span>
                            <ExternalLink className="w-3.5 h-3.5" />
                          </button>

                          <div className="grid grid-cols-2 gap-1.5 w-full">
                            <button
                              type="button"
                              onClick={() => setSelectedFlightForDetails(flight)}
                              className="py-1.5 px-2 text-[11px] rounded border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 font-medium text-center"
                            >
                              Flight Info
                            </button>
                            <button
                              type="button"
                              onClick={() => onSaveFlight(flight)}
                              className={`py-1.5 px-2 text-[11px] rounded border font-medium text-center transition-colors ${
                                isSaved
                                  ? 'border-sky-500 text-sky-500 bg-sky-50/50 dark:bg-sky-950/40'
                                  : 'border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800'
                              }`}
                            >
                              {isSaved ? 'Saved' : 'Save'}
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>

                    {/* Expandable Price Breakdown Drawer */}
                    {isExpanded && (
                      <div className="mt-4 pt-3 border-t border-slate-200 dark:border-slate-800 text-xs bg-slate-50 dark:bg-slate-800/40 p-3.5 rounded-lg space-y-1.5">
                        <div className="flex justify-between text-slate-600 dark:text-slate-400">
                          <span>Base Air Fare</span>
                          <span className="font-mono">£{flight.baseFare}</span>
                        </div>
                        <div className="flex justify-between text-slate-600 dark:text-slate-400">
                          <span>UK Air Passenger Duty (APD) & Airport Security</span>
                          <span className="font-mono">£{flight.taxesAndCharges}</span>
                        </div>
                        <div className="flex justify-between font-bold text-slate-900 dark:text-white pt-1.5 border-t border-slate-200 dark:border-slate-700">
                          <span>Total Mandatory Fare</span>
                          <span className="font-mono">£{flight.totalPrice}</span>
                        </div>
                        <div className="text-[10px] text-slate-500 pt-1">
                          Optional extras: 23kg Checked Bag from £{flight.fareTiers[1]?.price - flight.totalPrice || 24} · Seat Selection from £6.00
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </main>
      </div>

      {/* Fare Family Comparison Modal */}
      {selectedFlightForFares && (
        <FareFamilyComparison
          flight={selectedFlightForFares}
          onClose={() => setSelectedFlightForFares(null)}
          onSelectFare={(tier) => {
            setSelectedFlightForBooking({
              flight: selectedFlightForFares,
              tier,
            });
            setSelectedFlightForFares(null);
          }}
        />
      )}

      {/* Flight Detail Inspection Modal */}
      {selectedFlightForDetails && (
        <FlightDetailModal
          flight={selectedFlightForDetails}
          isSaved={savedFlightIds.includes(selectedFlightForDetails.id)}
          onClose={() => setSelectedFlightForDetails(null)}
          onBook={(flight) => {
            setSelectedFlightForBooking({ flight });
            setSelectedFlightForDetails(null);
          }}
          onSave={onSaveFlight}
        />
      )}

      {/* Official Booking Handoff Modal */}
      {selectedFlightForBooking && (
        <BookingHandoffModal
          flight={selectedFlightForBooking.flight}
          selectedTier={selectedFlightForBooking.tier}
          onClose={() => setSelectedFlightForBooking(null)}
        />
      )}

      {/* Price Alert Subscription Modal */}
      {isAlertModalOpen && (
        <PriceAlertModal
          query={query}
          currentLowestPrice={lowestPriceAvailable}
          onClose={() => setIsAlertModalOpen(false)}
          onCreated={() => {}}
        />
      )}
    </div>
  );
};
