'use client';

import React, { useState } from 'react';
import { Flight, FareTier } from '@/lib/aviation/types';
import { ExternalLink, ShieldCheck, CheckCircle2, ArrowRight, X, Lock } from 'lucide-react';

interface BookingHandoffModalProps {
  flight: Flight;
  selectedTier?: FareTier;
  onClose: () => void;
}

export const BookingHandoffModal: React.FC<BookingHandoffModalProps> = ({
  flight,
  selectedTier,
  onClose,
}) => {
  const [isRedirecting, setIsRedirecting] = useState(false);
  const fare = selectedTier || flight.fareTiers[0];
  const totalPrice = fare.price;

  const handleProceedToAirline = () => {
    setIsRedirecting(true);
    setTimeout(() => {
      // Direct airline simulation link or external website
      let url = 'https://www.britishairways.com';
      if (flight.airlineCode === 'U2') url = 'https://www.easyjet.com';
      if (flight.airlineCode === 'LM') url = 'https://www.loganair.co.uk';
      if (flight.airlineCode === 'T3') url = 'https://www.easternairways.com';
      if (flight.airlineCode === 'FR') url = 'https://www.ryanair.com';
      if (flight.airlineCode === 'EI') url = 'https://www.aerlingus.com';
      if (flight.airlineCode === 'LS') url = 'https://www.jet2.com';

      window.open(url, '_blank', 'noopener,noreferrer');
      setIsRedirecting(false);
      onClose();
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/75 backdrop-blur-sm">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-xl w-full p-6 sm:p-8 shadow-2xl">
        <div className="flex items-start justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-sky-600 dark:text-sky-400">
              <Lock className="w-3.5 h-3.5" />
              <span>Official Airline Booking Handoff</span>
            </div>
            <h2 className="text-xl font-bold text-slate-900 dark:text-white mt-1">
              Proceed to {flight.airlineName}
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Flight summary card */}
        <div className="my-6 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700">
          <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400 mb-2">
            <span className="font-semibold text-slate-900 dark:text-white">{flight.flightNumber}</span>
            <span>{fare.title}</span>
          </div>

          <div className="flex items-baseline justify-between mb-3">
            <div>
              <p className="text-2xl font-bold text-slate-900 dark:text-white font-mono">
                {flight.departureTime}
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                {flight.originCity} ({flight.originCode})
              </p>
            </div>

            <div className="text-center px-4">
              <span className="text-[11px] text-slate-400 font-mono">
                {flight.durationMinutes}m · {flight.isDirect ? 'Direct' : '1 Stop'}
              </span>
              <div className="w-24 h-px bg-slate-300 dark:bg-slate-600 my-1" />
              <span className="text-[10px] text-slate-400">{flight.aircraft.model}</span>
            </div>

            <div className="text-right">
              <p className="text-2xl font-bold text-slate-900 dark:text-white font-mono">
                {flight.arrivalTime}
              </p>
              <p className="text-xs text-slate-600 dark:text-slate-400">
                {flight.destinationCity} ({flight.destinationCode})
              </p>
            </div>
          </div>

          {/* Full price transparency breakdown */}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-700/80 text-xs space-y-1.5">
            <div className="flex justify-between text-slate-600 dark:text-slate-400">
              <span>Base Air Fare</span>
              <span className="font-mono">£{flight.baseFare}</span>
            </div>
            <div className="flex justify-between text-slate-600 dark:text-slate-400">
              <span>UK Air Passenger Duty (APD) & Security</span>
              <span className="font-mono">£{flight.taxesAndCharges}</span>
            </div>
            {selectedTier && selectedTier.type !== 'economy_light' && (
              <div className="flex justify-between text-slate-600 dark:text-slate-400">
                <span>{selectedTier.title} Bundle Supplement</span>
                <span className="font-mono">£{selectedTier.price - flight.totalPrice}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-slate-900 dark:text-white pt-2 border-t border-slate-200 dark:border-slate-700 text-sm">
              <span>Total Payable to Airline</span>
              <span className="font-mono text-base text-sky-600 dark:text-sky-400">
                £{totalPrice}
              </span>
            </div>
          </div>
        </div>

        {/* Institutional Guarantee Box */}
        <div className="p-3.5 rounded-lg bg-sky-50/60 dark:bg-sky-950/30 border border-sky-200 dark:border-sky-900 text-xs text-slate-700 dark:text-slate-300 mb-6 flex gap-3 items-start">
          <ShieldCheck className="w-5 h-5 text-sky-600 dark:text-sky-400 shrink-0 mt-0.5" />
          <div>
            <p className="font-semibold text-slate-900 dark:text-white mb-0.5">
              Direct Airline Booking Guarantee
            </p>
            <p className="text-[11px] leading-relaxed text-slate-600 dark:text-slate-400">
              British Sky is a non-commercial aviation search infrastructure. We charge zero booking fees, markups or hidden surcharges. You will be transferred directly to the carrier’s secure checkout.
            </p>
          </div>
        </div>

        {/* Action button */}
        <div className="flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="w-1/3 py-3 rounded-lg border border-slate-300 dark:border-slate-700 font-medium text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={handleProceedToAirline}
            disabled={isRedirecting}
            className="w-2/3 py-3 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-lg transition-all flex items-center justify-center gap-2 shadow-lg disabled:opacity-50"
          >
            {isRedirecting ? (
              <span>Connecting to {flight.airlineName}...</span>
            ) : (
              <>
                <span>CONTINUE TO {flight.airlineName.toUpperCase()}</span>
                <ExternalLink className="w-4 h-4" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
