'use client';

import React from 'react';
import { Flight } from '@/lib/aviation/types';
import { X, Plane, Clock, ShieldCheck, MapPin, Gauge, Leaf, AlertCircle, ArrowRight, Bookmark } from 'lucide-react';
import { getAirportByCode } from '@/lib/aviation/airports';

interface FlightDetailModalProps {
  flight: Flight;
  onClose: () => void;
  onBook: (flight: Flight) => void;
  onSave: (flight: Flight) => void;
  isSaved?: boolean;
}

export const FlightDetailModal: React.FC<FlightDetailModalProps> = ({
  flight,
  onClose,
  onBook,
  onSave,
  isSaved,
}) => {
  const originAirport = getAirportByCode(flight.originCode);
  const destAirport = getAirportByCode(flight.destinationCode);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-slate-950/75 backdrop-blur-sm overflow-y-auto">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-3xl w-full p-6 sm:p-8 shadow-2xl my-8">
        {/* Header */}
        <div className="flex items-start justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-sky-600 dark:text-sky-400">
              <span>UK Domestic Service Dossier</span>
              <span>·</span>
              <span>Flight {flight.flightNumber}</span>
            </div>
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
              {flight.originCity} ({flight.originCode}) → {flight.destinationCity} ({flight.destinationCode})
            </h2>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => onSave(flight)}
              title="Save to My British Sky"
              className={`p-2 rounded-lg border transition-colors ${
                isSaved
                  ? 'bg-sky-50 dark:bg-sky-950/40 border-sky-400 text-sky-600 dark:text-sky-400'
                  : 'border-slate-200 dark:border-slate-700 text-slate-500 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Bookmark className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Flight Journey Strip */}
        <div className="my-6 p-5 rounded-xl bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
            {/* Origin */}
            <div>
              <p className="text-3xl font-bold text-slate-900 dark:text-white font-mono">
                {flight.departureTime}
              </p>
              <p className="text-sm font-semibold text-slate-900 dark:text-white mt-0.5">
                {originAirport?.name || flight.originName}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {flight.originTerminal || 'Main Concourse'} {flight.gate ? `· Gate ${flight.gate}` : ''}
              </p>
            </div>

            {/* Trajectory */}
            <div className="text-center px-4">
              <span className="text-xs font-mono font-medium text-slate-600 dark:text-slate-300">
                {flight.durationMinutes} minutes {flight.isDirect ? '· Non-stop' : '· Connecting'}
              </span>
              <div className="relative my-2">
                <div className="h-0.5 bg-slate-300 dark:bg-slate-600 w-full" />
                <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white dark:bg-slate-800 px-2">
                  <Plane className="w-4 h-4 text-sky-500" />
                </div>
              </div>
              <span className="text-[11px] text-slate-500 font-mono">
                {flight.airlineName} ({flight.airlineCode})
              </span>
            </div>

            {/* Destination */}
            <div className="text-right">
              <p className="text-3xl font-bold text-slate-900 dark:text-white font-mono">
                {flight.arrivalTime}
              </p>
              <p className="text-sm font-semibold text-slate-900 dark:text-white mt-0.5">
                {destAirport?.name || flight.destinationName}
              </p>
              <p className="text-xs text-slate-500 dark:text-slate-400">
                {flight.destinationTerminal || 'Main Concourse'}
              </p>
            </div>
          </div>

          {/* If connecting flight, show segment details */}
          {!flight.isDirect && flight.segments && (
            <div className="mt-4 pt-4 border-t border-slate-200 dark:border-slate-700/80">
              <div className="flex items-center gap-2 text-xs font-semibold text-slate-900 dark:text-white mb-2">
                <AlertCircle className="w-3.5 h-3.5 text-amber-500" />
                <span>
                  {flight.isProtectedConnection ? 'Protected Domestic Connection' : 'Self-Transfer Connection'} at {flight.stopoverAirportName} ({flight.stopoverAirportCode}) · {flight.stopoverDurationMins}m layover
                </span>
              </div>
              <div className="space-y-2">
                {flight.segments.map((seg, i) => (
                  <div key={seg.flightNumber} className="text-xs flex items-center justify-between bg-white dark:bg-slate-900 p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
                    <span className="font-mono font-semibold">Leg {i + 1}: {seg.flightNumber} ({seg.originCode} → {seg.destinationCode})</span>
                    <span className="text-slate-500">{seg.departureTime} – {seg.arrivalTime} ({seg.durationMinutes}m)</span>
                    <span className="text-slate-400 font-mono">{seg.aircraft.model}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Technical & Environmental Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          {/* Aircraft Specifications */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <Gauge className="w-4 h-4 text-slate-500" />
              <span>Aircraft & Operating Fleet</span>
            </h3>
            <div className="space-y-2 text-slate-600 dark:text-slate-400">
              <div className="flex justify-between">
                <span>Aircraft Type</span>
                <span className="font-mono text-slate-900 dark:text-white font-medium">{flight.aircraft.model}</span>
              </div>
              <div className="flex justify-between">
                <span>Manufacturer</span>
                <span className="text-slate-900 dark:text-white">{flight.aircraft.manufacturer}</span>
              </div>
              <div className="flex justify-between">
                <span>Typical Capacity</span>
                <span className="font-mono text-slate-900 dark:text-white">{flight.aircraft.capacity} seats</span>
              </div>
              <div className="flex justify-between">
                <span>Cruising Speed / Altitude</span>
                <span className="font-mono text-slate-900 dark:text-white">{flight.aircraft.cruisingSpeedKmh} km/h · FL370</span>
              </div>
              <div className="flex justify-between">
                <span>Economy Seat Pitch</span>
                <span className="font-mono text-slate-900 dark:text-white">{flight.aircraft.seatPitchInches} inches</span>
              </div>
            </div>
          </div>

          {/* Environmental Carbon Benchmark */}
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs">
            <h3 className="font-bold text-slate-900 dark:text-white mb-3 flex items-center gap-2">
              <Leaf className="w-4 h-4 text-emerald-500" />
              <span>Carbon & Rail Benchmark</span>
            </h3>
            <div className="space-y-2 text-slate-600 dark:text-slate-400">
              <div className="flex justify-between">
                <span>Flight CO₂ Estimate</span>
                <span className="font-mono text-slate-900 dark:text-white font-medium">{flight.co2Kg} kg CO₂ / pax</span>
              </div>
              <div className="flex justify-between">
                <span>Equivalent Intercity Rail</span>
                <span className="font-mono text-emerald-600 dark:text-emerald-400 font-medium">~14 kg CO₂ / pax</span>
              </div>
              <div className="flex justify-between">
                <span>Rail Journey Time</span>
                <span className="font-mono text-slate-900 dark:text-white">~4h 20m (LNER Azuma)</span>
              </div>
              <p className="text-[11px] text-slate-500 dark:text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
                UK Domestic aviation is subject to the UK Emissions Trading Scheme (ETS) and Sustainable Aviation Fuel (SAF) blending mandates.
              </p>
            </div>
          </div>
        </div>

        {/* Airport Ground Transfer Notice for London multi-airports */}
        {flight.requiresAirportTransfer && (
          <div className="p-3.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-200 mb-6">
            <p className="font-bold mb-0.5">London Airport Transfer Required</p>
            <p>{flight.airportTransferNote || 'Connecting between different London airports requires self-arranged ground transfer via Thameslink or express coach.'}</p>
          </div>
        )}

        {/* Footer CTA */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800">
          <div>
            <span className="text-xs text-slate-500">Starting from</span>
            <p className="text-2xl font-bold font-mono text-slate-900 dark:text-white">
              £{flight.totalPrice} <span className="text-xs text-slate-500 font-normal">total</span>
            </p>
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 font-medium text-xs text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              Close
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onBook(flight);
              }}
              className="px-6 py-2.5 bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs rounded-lg transition-all flex items-center gap-2 shadow-md"
            >
              <span>CONTINUE TO BOOKING</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
