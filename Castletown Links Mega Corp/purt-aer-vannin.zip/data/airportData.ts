export interface Flight {
  id: string;
  flightNumber: string;
  airline: string;
  airlineCode: string;
  airportName: string;
  airportCode: string;
  scheduledTime: string;
  actualTime?: string;
  status: 'On Time' | 'Delayed' | 'Boarding' | 'Gate Open' | 'Departed' | 'Landed' | 'Baggage Claim' | 'Scheduled';
  gate?: string;
  terminal: string;
  checkInDesk?: string;
  baggageCarousel?: string;
  type: 'departure' | 'arrival';
}

export interface Destination {
  id: string;
  name: string;
  code: string;
  country: string;
  airlines: string[];
  description: string;
  image: string;
  duration: string;
  frequency: string;
  popularFor: string;
}

export interface ParkingProduct {
  id: 'short-stay' | 'long-stay' | 'premium';
  name: string;
  pricePerDay: number;
  walkingTime: string;
  description: string;
  features: string[];
  availabilityIndicator: 'high' | 'medium' | 'limited' | 'full';
}

export interface ShopRestaurant {
  id: string;
  name: string;
  type: 'shop' | 'dine';
  location: string;
  hours: string;
  description: string;
  image: string;
}

export interface Career {
  id: string;
  title: string;
  department: string;
  type: 'Full-time' | 'Part-time' | 'Contract';
  salary: string;
  description: string;
  requirements: string[];
}

export interface Lounge {
  id: string;
  name: string;
  price: number;
  description: string;
  features: string[];
  hours: string;
  image: string;
}

// Highly realistic mock data representing airport operations in 2026
export const mockFlights: Flight[] = [
  // Departures
  {
    id: 'dep-1',
    flightNumber: 'LM0682',
    airline: 'Loganair',
    airlineCode: 'LM',
    airportName: 'London Heathrow',
    airportCode: 'LHR',
    scheduledTime: '07:00',
    status: 'Departed',
    actualTime: '07:03',
    gate: 'Gate 3',
    terminal: 'T2',
    checkInDesk: 'Desk 1-3',
    type: 'departure'
  },
  {
    id: 'dep-2',
    flightNumber: 'EZY0132',
    airline: 'easyJet',
    airlineCode: 'EZY',
    airportName: 'Liverpool',
    airportCode: 'LPL',
    scheduledTime: '08:15',
    status: 'Departed',
    actualTime: '08:12',
    gate: 'Gate 5',
    terminal: 'T1',
    checkInDesk: 'Desk 4-6',
    type: 'departure'
  },
  {
    id: 'dep-3',
    flightNumber: 'EI3215',
    airline: 'Aer Lingus',
    airlineCode: 'EI',
    airportName: 'Dublin',
    airportCode: 'DUB',
    scheduledTime: '09:40',
    status: 'Landed', // Since local time is 13:22, early flights are landed/departed
    actualTime: '09:38',
    gate: 'Gate 2',
    terminal: 'T1',
    checkInDesk: 'Desk 7',
    type: 'departure'
  },
  {
    id: 'dep-4',
    flightNumber: 'EZY0454',
    airline: 'easyJet',
    airlineCode: 'EZY',
    airportName: 'Belfast International',
    airportCode: 'BFS',
    scheduledTime: '13:45',
    status: 'Boarding',
    gate: 'Gate 6',
    terminal: 'T1',
    checkInDesk: 'Desk 4-6',
    type: 'departure'
  },
  {
    id: 'dep-5',
    flightNumber: 'LM0684',
    airline: 'Loganair',
    airlineCode: 'LM',
    airportName: 'London City',
    airportCode: 'LCY',
    scheduledTime: '14:15',
    status: 'Gate Open',
    gate: 'Gate 4',
    terminal: 'T1',
    checkInDesk: 'Desk 1-3',
    type: 'departure'
  },
  {
    id: 'dep-6',
    flightNumber: 'EZY0326',
    airline: 'easyJet',
    airlineCode: 'EZY',
    airportName: 'Manchester',
    airportCode: 'MAN',
    scheduledTime: '15:30',
    status: 'On Time',
    gate: 'Gate 8',
    terminal: 'T1',
    checkInDesk: 'Desk 4-6',
    type: 'departure'
  },
  {
    id: 'dep-7',
    flightNumber: 'LM0722',
    airline: 'Loganair',
    airlineCode: 'LM',
    airportName: 'Edinburgh',
    airportCode: 'EDI',
    scheduledTime: '16:45',
    status: 'On Time',
    gate: 'Gate 1',
    terminal: 'T1',
    checkInDesk: 'Desk 1-3',
    type: 'departure'
  },
  {
    id: 'dep-8',
    flightNumber: 'EZY0218',
    airline: 'easyJet',
    airlineCode: 'EZY',
    airportName: 'London Gatwick',
    airportCode: 'LGW',
    scheduledTime: '18:10',
    status: 'Delayed', // A delayed flight for realistic variety
    gate: 'Gate 7',
    terminal: 'T1',
    checkInDesk: 'Desk 4-6',
    type: 'departure'
  },
  {
    id: 'dep-9',
    flightNumber: 'LM0412',
    airline: 'Loganair',
    airlineCode: 'LM',
    airportName: 'Birmingham',
    airportCode: 'BHX',
    scheduledTime: '19:30',
    status: 'On Time',
    gate: 'Gate 2',
    terminal: 'T1',
    checkInDesk: 'Desk 1-3',
    type: 'departure'
  },

  // Arrivals
  {
    id: 'arr-1',
    flightNumber: 'LM0681',
    airline: 'Loganair',
    airlineCode: 'LM',
    airportName: 'London Heathrow',
    airportCode: 'LHR',
    scheduledTime: '08:30',
    status: 'Landed',
    actualTime: '08:24',
    terminal: 'T1',
    baggageCarousel: 'Carousel 1',
    type: 'arrival'
  },
  {
    id: 'arr-2',
    flightNumber: 'EZY0131',
    airline: 'easyJet',
    airlineCode: 'EZY',
    airportName: 'Liverpool',
    airportCode: 'LPL',
    scheduledTime: '09:45',
    status: 'Landed',
    actualTime: '09:51',
    terminal: 'T1',
    baggageCarousel: 'Carousel 2',
    type: 'arrival'
  },
  {
    id: 'arr-3',
    flightNumber: 'EI3214',
    airline: 'Aer Lingus',
    airlineCode: 'EI',
    airportName: 'Dublin',
    airportCode: 'DUB',
    scheduledTime: '11:15',
    status: 'Landed',
    actualTime: '11:10',
    terminal: 'T1',
    baggageCarousel: 'Carousel 1',
    type: 'arrival'
  },
  {
    id: 'arr-4',
    flightNumber: 'EZY0325',
    airline: 'easyJet',
    airlineCode: 'EZY',
    airportName: 'Manchester',
    airportCode: 'MAN',
    scheduledTime: '13:10',
    status: 'Baggage Claim',
    actualTime: '13:07',
    terminal: 'T1',
    baggageCarousel: 'Carousel 2',
    type: 'arrival'
  },
  {
    id: 'arr-5',
    flightNumber: 'LM0683',
    airline: 'Loganair',
    airlineCode: 'LM',
    airportName: 'London City',
    airportCode: 'LCY',
    scheduledTime: '13:55',
    status: 'On Time',
    terminal: 'T1',
    baggageCarousel: 'Carousel 1',
    type: 'arrival'
  },
  {
    id: 'arr-6',
    flightNumber: 'EZY0453',
    airline: 'easyJet',
    airlineCode: 'EZY',
    airportName: 'Belfast International',
    airportCode: 'BFS',
    scheduledTime: '15:10',
    status: 'On Time',
    terminal: 'T1',
    baggageCarousel: 'Carousel 2',
    type: 'arrival'
  },
  {
    id: 'arr-7',
    flightNumber: 'LM0721',
    airline: 'Loganair',
    airlineCode: 'LM',
    airportName: 'Edinburgh',
    airportCode: 'EDI',
    scheduledTime: '18:15',
    status: 'On Time',
    terminal: 'T1',
    baggageCarousel: 'Carousel 1',
    type: 'arrival'
  },
  {
    id: 'arr-8',
    flightNumber: 'EZY0217',
    airline: 'easyJet',
    airlineCode: 'EZY',
    airportName: 'London Gatwick',
    airportCode: 'LGW',
    scheduledTime: '19:45',
    status: 'On Time',
    terminal: 'T1',
    baggageCarousel: 'Carousel 2',
    type: 'arrival'
  }
];

export const mockDestinations: Destination[] = [
  {
    id: 'dest-london',
    name: 'London',
    code: 'LHR / LGW / LCY',
    country: 'United Kingdom',
    airlines: ['Loganair', 'easyJet'],
    description: 'Connect directly to London Heathrow, Gatwick, or City Airport. Perfect for global transfers, financial business, or premium leisure trips to the capital.',
    image: 'https://picsum.photos/seed/london_eye_iom/1000/600',
    duration: '1h 15m',
    frequency: 'Multiple flights daily',
    popularFor: 'Business, culture, and global onward connections.'
  },
  {
    id: 'dest-manchester',
    name: 'Manchester',
    code: 'MAN',
    country: 'United Kingdom',
    airlines: ['easyJet', 'Loganair'],
    description: 'The cultural and economic powerhouse of the North, offering robust local business links and over 200 global route options via Manchester Airport terminals.',
    image: 'https://picsum.photos/seed/manchester_skyline/1000/600',
    duration: '50m',
    frequency: 'Daily operations',
    popularFor: 'Media, commerce, university travel, and soccer matches.'
  },
  {
    id: 'dest-liverpool',
    name: 'Liverpool',
    code: 'LPL',
    country: 'United Kingdom',
    airlines: ['easyJet'],
    description: 'The closest maritime hub to the Isle of Man, renowned for its rich musical heritage, world-class architecture, and outstanding local shopping.',
    image: 'https://picsum.photos/seed/liverpool_albert_dock/1000/600',
    duration: '40m',
    frequency: '1-2 flights daily',
    popularFor: 'Shopping, music history, and convenient ferry-airline multi-modal travel.'
  },
  {
    id: 'dest-dublin',
    name: 'Dublin',
    code: 'DUB',
    country: 'Ireland',
    airlines: ['Aer Lingus'],
    description: 'Your premium gateway to Ireland and excellent transatlantic pre-clearance. Fly directly to Dublin and clear US customs before crossing the Atlantic.',
    image: 'https://picsum.photos/seed/dublin_bridge/1000/600',
    duration: '45m',
    frequency: 'Daily operations',
    popularFor: 'Tech hub business, weekend breaks, and direct US flight pre-clearance.'
  },
  {
    id: 'dest-edinburgh',
    name: 'Edinburgh',
    code: 'EDI',
    country: 'Scotland',
    airlines: ['Loganair'],
    description: 'Fly to Scotland’s stunning capital city, where historic castles meet a vibrant contemporary food and arts scene. An elegant northern gateway.',
    image: 'https://picsum.photos/seed/edinburgh_castle_sky/1000/600',
    duration: '1h 05m',
    frequency: '4x weekly',
    popularFor: 'History, festivals, premium spirits, and majestic Highlands nature.'
  },
  {
    id: 'dest-belfast',
    name: 'Belfast',
    code: 'BFS / BHD',
    country: 'Northern Ireland',
    airlines: ['easyJet', 'Aer Lingus'],
    description: 'Discover Northern Ireland’s capital, packed with industrial history, fine Victorian architecture, and scenic coastal road connections.',
    image: 'https://picsum.photos/seed/belfast_titanic/1000/600',
    duration: '40m',
    frequency: 'Daily operations',
    popularFor: 'Shipbuilding history, Titanic exhibitions, and Giant’s Causeway links.'
  },
  {
    id: 'dest-jersey',
    name: 'Jersey',
    code: 'JER',
    country: 'Channel Islands',
    airlines: ['Loganair'],
    description: 'Connect directly to our sister Crown Dependency. Excellent for international finance cooperation, sunny beaches, and boutique premium hospitality.',
    image: 'https://picsum.photos/seed/jersey_island/1000/600',
    duration: '1h 30m (seasonal/direct)',
    frequency: 'Weekly departures',
    popularFor: 'Offshore finance networking, maritime cuisine, and warmer island sun.'
  },
  {
    id: 'dest-geneva',
    name: 'European Connections',
    code: 'GVA / PMO / ALC',
    country: 'Europe Hubs',
    airlines: ['easyJet'],
    description: 'Seasonal flights and direct charters linking the Isle of Man to elite alpine ski runs in Geneva, summer sun spots in Alicante, and key European transit points.',
    image: 'https://picsum.photos/seed/swiss_alps/1000/600',
    duration: '2h 15m',
    frequency: 'Seasonal / Charter schedules',
    popularFor: 'Alpine skiing, Mediterranean holidays, and luxury continental travel.'
  }
];

export const mockParkingProducts: ParkingProduct[] = [
  {
    id: 'short-stay',
    name: 'Short Stay Parking',
    pricePerDay: 15,
    walkingTime: '1-2 mins walk',
    description: 'Perfect for quick visits, picking up or dropping off passengers. Directly in front of the terminal building.',
    features: [
      'Located directly opposite terminal main entrance',
      'First 15 minutes absolutely free',
      'CCTV monitoring and 24/7 airport patrols',
      'Extremely wide, well-lit spaces'
    ],
    availabilityIndicator: 'high'
  },
  {
    id: 'long-stay',
    name: 'Long Stay Parking',
    pricePerDay: 7,
    walkingTime: '3-5 mins walk',
    description: 'Our most popular and cost-effective option. Perfect for business trips, family holidays, or weekend breaks.',
    features: [
      'Highly secure fenced perimeter',
      'Automatic Number Plate Recognition (ANPR)',
      'Substantial savings when booked in advance',
      'Clean tarmac pathways directly to Departures'
    ],
    availabilityIndicator: 'medium'
  },
  {
    id: 'premium',
    name: 'Premium Valet Parking',
    pricePerDay: 28,
    walkingTime: '0 mins walk (Terminal drop-off)',
    description: 'The ultimate airport parking experience. Hand your keys to our staff at the terminal, and we will do the rest.',
    features: [
      'Drop off directly at the main terminal lane',
      'Your vehicle is stored in our ultra-secure indoor garage',
      'Complimentary fast-track security voucher included',
      'Your car is heated, defrosted, and waiting on arrival'
    ],
    availabilityIndicator: 'limited'
  }
];

export const mockShopsRestaurants: ShopRestaurant[] = [
  {
    id: 'sr-1',
    name: 'Manx Duty Free',
    type: 'shop',
    location: 'Departures Lounge (Post-Security)',
    hours: '05:30 - Last Flight',
    description: 'Premium duty-free shopping featuring exclusive Isle of Man whiskies, local Okell’s gin, boutique perfumes, and high-end confectionery.',
    image: 'https://picsum.photos/seed/duty_free/600/400'
  },
  {
    id: 'sr-2',
    name: 'The Runway Bar & Grill',
    type: 'dine',
    location: 'Departures Lounge (Post-Security)',
    hours: '06:00 - 20:00',
    description: 'Gourmet dining showcasing outstanding Manx beef, fresh local queenies (scallops), British airport breakfast, and craft beers with runway panoramic views.',
    image: 'https://picsum.photos/seed/airport_bar/600/400'
  },
  {
    id: 'sr-3',
    name: 'Isle of Man Market Emporium',
    type: 'shop',
    location: 'Main Terminal (Pre-Security)',
    hours: '07:00 - 19:30',
    description: 'Bespoke island crafts, world-renowned Laxey Glen wool jumpers, Davisons chocolates, Manx honey, and traditional Celtic jewelry.',
    image: 'https://picsum.photos/seed/craft_shop/600/400'
  },
  {
    id: 'sr-4',
    name: 'Ellan Vannin Coffee Co.',
    type: 'dine',
    location: 'Main Terminal & Post-Security',
    hours: '05:00 - Last Flight',
    description: 'Artisanal local coffee roasted on-island. Paired with fresh pastries, gourmet sandwiches, and traditional Manx soda breads.',
    image: 'https://picsum.photos/seed/coffee_shop/600/400'
  }
];

export const mockLounges: Lounge[] = [
  {
    id: 'lounge-halcyon',
    name: 'The Halcyon Executive Lounge',
    price: 35,
    description: 'Discover an oasis of absolute calm away from the busy terminal. Experience quiet luxury with local gourmet treats, quiet working pods, and exceptional runway vistas.',
    features: [
      'Premium complimentary wines, local spirits, and craft beers',
      'Freshly prepared hot and cold buffet featuring Manx local produce',
      'Ultra-fast private Wi-Fi and ergonomic workspaces with print/scan facilities',
      'Dedicated premium flight status monitors and quiet ambient zones',
      'Complimentary luxury newspapers, aviation logs, and travel magazines'
    ],
    hours: '05:30 - 20:00 Daily',
    image: 'https://picsum.photos/seed/premium_lounge/800/500'
  }
];

export const mockCareers: Career[] = [
  {
    id: 'car-1',
    title: 'Aviation Security Officer',
    department: 'Security & Terminal Operations',
    type: 'Full-time',
    salary: '£28,500 - £32,000 per annum',
    description: 'Ensure the absolute safety of passengers, crew, and airport infrastructure. You will be responsible for security screening, bag inspections, and providing a reassuring, highly professional presence in the terminal.',
    requirements: [
      'Excellent communication and premium customer-service skills',
      'Impeccable attention to detail and calm demeanour under high pressure',
      'Must pass a comprehensive 5-year background history check and aviation vetting',
      'Full, intensive training will be provided on-site'
    ]
  },
  {
    id: 'car-2',
    title: 'Air Traffic Control Officer (ATCO)',
    department: 'Aviation Services & Towers',
    type: 'Full-time',
    salary: '£65,000 - £82,000 (Based on experience)',
    description: 'Direct the movement of aircraft within the Isle of Man controlled airspace and on the terminal apron. Maintain supreme safety standards at one of the British Isles’ most strategically positioned regional towers.',
    requirements: [
      'Valid UK CAA ATCO License with ADI and APP ratings',
      'Class 1 Medical Certificate certification',
      'Proven record of exceptional spatial awareness and communication accuracy',
      'Passionate about joining a highly collaborative, safety-focused island team'
    ]
  },
  {
    id: 'car-3',
    title: 'Passenger Service Coordinator',
    department: 'Terminal Operations',
    type: 'Contract',
    salary: '£14.50 per hour',
    description: 'Represent the friendly face of Purt Aer Vannin. Assist passengers with boarding gate flows, special mobility assistance, check-in validation, and general information query support.',
    requirements: [
      'Previous experience in premium hospitality, airlines, or customer-facing operations',
      'Warm, welcoming attitude representing Manx hospitality',
      'Ability to walk and stand comfortably during peak flight times',
      'Fluent in English; additional European language skills are a premium advantage'
    ]
  }
];
