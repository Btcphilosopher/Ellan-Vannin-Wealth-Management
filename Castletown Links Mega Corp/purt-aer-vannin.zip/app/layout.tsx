import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Purt Aer Vannin — Isle of Man International Airport',
  description: 'Official website of Purt Aer Vannin, Isle of Man International Airport. Connect with direct flights across the UK, Ireland, and Europe.',
  openGraph: {
    title: 'Purt Aer Vannin — Isle of Man International Airport',
    description: 'Official website of Purt Aer Vannin, Isle of Man International Airport. Connect with direct flights across the UK, Ireland, and Europe.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Purt Aer Vannin — Isle of Man International Airport',
    description: 'Official website of Purt Aer Vannin, Isle of Man International Airport. Connect with direct flights across the UK, Ireland, and Europe.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
