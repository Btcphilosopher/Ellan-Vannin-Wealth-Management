'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/layout/Header';
import Footer from '@/components/layout/Footer';
import FlightSearch from '@/components/search/FlightSearch';
import FlightBoard from '@/components/flights/FlightBoard';
import DestinationGrid from '@/components/destinations/DestinationGrid';
import ParkingBooking from '@/components/parking/ParkingBooking';

// Icons for practical layouts
import {
  Plane,
  Car,
  Clock,
  Shield,
  Coffee,
  Briefcase,
  Luggage,
  Map,
  Sparkles,
  ArrowRight,
  ArrowUpRight,
  Award,
  Globe,
  Compass,
  Phone,
  Mail,
  HelpCircle,
  Accessibility,
  Users,
  CheckCircle,
  FileText,
  BadgeAlert,
  MapPin,
  Calendar,
  X,
  Eye,
  Camera,
  Heart
} from 'lucide-react';

import {
  mockDestinations,
  mockFlights,
  mockShopsRestaurants,
  mockCareers,
  mockLounges,
  Flight as FlightType,
  Destination as DestType
} from '@/data/airportData';

export default function Page() {
  const [activePage, setActivePage] = useState<string>('home');
  const [searchOverlayData, setSearchOverlayData] = useState<any>(null);

  // States for interactive modals or application forms
  const [appliedJob, setAppliedJob] = useState<any>(null);
  const [isApplyModalOpen, setIsApplyModalOpen] = useState(false);
  const [jobFormName, setJobFormName] = useState('');
  const [jobFormEmail, setJobFormEmail] = useState('');
  const [jobFormCV, setJobFormCV] = useState('CV_Lord_Passenger_2026.pdf');
  const [jobSuccess, setJobSuccess] = useState(false);

  // Contact States
  const [contactName, setContactName] = useState('');
  const [contactEmail, setContactEmail] = useState('');
  const [contactMsg, setContactMsg] = useState('');
  const [contactSuccess, setContactSuccess] = useState(false);

  // Business Quote Form
  const [bizCompany, setBizCompany] = useState('');
  const [bizEmail, setBizEmail] = useState('');
  const [bizService, setBizService] = useState('cargo');
  const [bizSuccess, setBizSuccess] = useState(false);

  // Scroll to top when activePage changes
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [activePage]);

  // Handle Search Results from homepage overlay
  const handleSearchActive = (results: any) => {
    setSearchOverlayData(results);
    if (results) {
      // Automatically redirect to the Flight Board / Flights tab to inspect
      setActivePage('flights');
    }
  };

  const handleApplyJob = (job: any) => {
    setAppliedJob(job);
    setIsApplyModalOpen(true);
    setJobSuccess(false);
  };

  const submitJobApplication = (e: React.FormEvent) => {
    e.preventDefault();
    if (!jobFormName || !jobFormEmail) {
      alert("Please complete all required fields.");
      return;
    }
    setJobSuccess(true);
    setTimeout(() => {
      setIsApplyModalOpen(false);
      setJobFormName('');
      setJobFormEmail('');
      alert(`Application for ${appliedJob.title} successfully submitted! Tracking ID: IOM-CAREER-${Math.floor(Math.random() * 90000)}`);
    }, 1500);
  };

  return (
    <div id="app-viewport" className="min-h-screen bg-navy-deep text-warm-ivory selection:bg-gold-premium selection:text-navy-deep flex flex-col justify-between">
      
      {/* Sticky Header */}
      <Header activePage={activePage} setActivePage={setActivePage} />

      {/* RENDER DYNAMIC PAGES */}
      <main className="flex-grow pt-24">
        
        {/* HOMEPAGE VIEW */}
        {activePage === 'home' && (
          <div id="home-view" className="animate-fade-in">
            
            {/* Cinematic Hero Section */}
            <section
              id="hero-banner"
              className="relative min-h-[85vh] flex flex-col justify-center items-center px-6 text-center border-b border-navy-steel/25"
            >
              {/* High-quality cinematic airport background image */}
              <div
                className="absolute inset-0 bg-cover bg-center z-0"
                style={{
                  backgroundImage: "url('https://picsum.photos/seed/airport_sunset_sky/1920/1085')",
                  backgroundBlendMode: 'overlay',
                }}
              />
              {/* Subtle dark navy overlay to protect high contrast text readability */}
              <div className="absolute inset-0 bg-navy-deep/75 z-10" />

              {/* Hero Copy (Foreground Content) */}
              <div className="relative z-20 max-w-4xl mx-auto flex flex-col items-center gap-5 mt-12 mb-20">
                <span className="text-[10px] md:text-xs uppercase font-bold tracking-widest text-gold-premium animate-pulse bg-navy-deep/60 px-4 py-1.5 rounded-full border border-gold-premium/30">
                  CONNECTING THE ISLE TO THE WORLD
                </span>
                
                <h1 className="font-serif text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight text-warm-ivory leading-tight">
                  Purt Aer Vannin
                </h1>
                <h2 className="text-lg md:text-xl font-medium tracking-wide text-blue-aviation/90 max-w-2xl leading-relaxed">
                  Isle of Man International Airport. Modern facilities. A warm welcome. Your next journey starts here.
                </h2>

                <div className="flex flex-wrap items-center justify-center gap-4 mt-2">
                  <button
                    onClick={() => setActivePage('flights')}
                    className="px-6 py-3.5 bg-gold-premium hover:bg-gold-premium/85 text-navy-deep font-bold rounded text-xs uppercase tracking-widest transition-all duration-200 flex items-center gap-2 shadow-lg shadow-gold-premium/10"
                  >
                    <span>Explore Flights</span>
                    <ArrowRight size={13} />
                  </button>
                  <button
                    onClick={() => setActivePage('parking')}
                    className="px-6 py-3.5 border border-navy-steel/50 hover:border-warm-ivory text-warm-ivory font-bold rounded text-xs uppercase tracking-widest transition-all"
                  >
                    Book Parking
                  </button>
                </div>
              </div>

              {/* Overlapping Search Panel */}
              <div className="absolute bottom-0 translate-y-1/2 left-0 right-0 z-30">
                <FlightSearch onSearchActive={handleSearchActive} />
              </div>
            </section>

            {/* Gap filler for overlapping search widget */}
            <div className="h-44 md:h-32 lg:h-24 bg-navy-deep" />

            {/* Quick Access Services Section */}
            <section id="quick-access" className="py-16 bg-navy-deep border-b border-navy-steel/20">
              <div className="max-w-7xl mx-auto px-6">
                <div className="grid grid-cols-1 md:grid-cols-5 divide-y md:divide-y-0 md:divide-x divide-navy-steel/25 border border-navy-steel/20 rounded-lg overflow-hidden bg-navy-dark shadow-xl">
                  
                  {/* Service 1 */}
                  <div className="p-6 flex flex-col justify-between group hover:bg-navy-deep/40 transition-colors">
                    <div>
                      <Plane className="text-gold-premium mb-4 group-hover:scale-110 transition-transform" size={24} />
                      <h3 className="text-xs font-bold uppercase tracking-widest text-warm-ivory mb-2">
                        Flights & Routes
                      </h3>
                      <p className="text-xs text-blue-aviation/80 leading-relaxed mb-6">
                        Direct routes across the UK, Ireland, Europe and beyond.
                      </p>
                    </div>
                    <button
                      onClick={() => setActivePage('destinations')}
                      className="text-[11px] font-bold text-gold-premium uppercase tracking-widest flex items-center gap-1 hover:underline text-left"
                    >
                      <span>Destinations</span>
                      <ArrowRight size={12} />
                    </button>
                  </div>

                  {/* Service 2 */}
                  <div className="p-6 flex flex-col justify-between group hover:bg-navy-deep/40 transition-colors">
                    <div>
                      <Car className="text-gold-premium mb-4 group-hover:scale-110 transition-transform" size={24} />
                      <h3 className="text-xs font-bold uppercase tracking-widest text-warm-ivory mb-2">
                        Airport Parking
                      </h3>
                      <p className="text-xs text-blue-aviation/80 leading-relaxed mb-6">
                        Convenient, secure and great value airport parking.
                      </p>
                    </div>
                    <button
                      onClick={() => setActivePage('parking')}
                      className="text-[11px] font-bold text-gold-premium uppercase tracking-widest flex items-center gap-1 hover:underline text-left"
                    >
                      <span>Book Space</span>
                      <ArrowRight size={12} />
                    </button>
                  </div>

                  {/* Service 3 */}
                  <div className="p-6 flex flex-col justify-between group hover:bg-navy-deep/40 transition-colors">
                    <div>
                      <Luggage className="text-gold-premium mb-4 group-hover:scale-110 transition-transform" size={24} />
                      <h3 className="text-xs font-bold uppercase tracking-widest text-warm-ivory mb-2">
                        Travel Information
                      </h3>
                      <p className="text-xs text-blue-aviation/80 leading-relaxed mb-6">
                        Security rules, baggage limits, and custom travel checks.
                      </p>
                    </div>
                    <button
                      onClick={() => setActivePage('travel-info')}
                      className="text-[11px] font-bold text-gold-premium uppercase tracking-widest flex items-center gap-1 hover:underline text-left"
                    >
                      <span>Travel Guide</span>
                      <ArrowRight size={12} />
                    </button>
                  </div>

                  {/* Service 4 */}
                  <div className="p-6 flex flex-col justify-between group hover:bg-navy-deep/40 transition-colors">
                    <div>
                      <Coffee className="text-gold-premium mb-4 group-hover:scale-110 transition-transform" size={24} />
                      <h3 className="text-xs font-bold uppercase tracking-widest text-warm-ivory mb-2">
                        Lounges & Dining
                      </h3>
                      <p className="text-xs text-blue-aviation/80 leading-relaxed mb-6">
                        Relax before you fly in our premium passenger lounges.
                      </p>
                    </div>
                    <button
                      onClick={() => setActivePage('airport')}
                      className="text-[11px] font-bold text-gold-premium uppercase tracking-widest flex items-center gap-1 hover:underline text-left"
                    >
                      <span>View Lounges</span>
                      <ArrowRight size={12} />
                    </button>
                  </div>

                  {/* Service 5 */}
                  <div className="p-6 flex flex-col justify-between group hover:bg-navy-deep/40 transition-colors">
                    <div>
                      <Briefcase className="text-gold-premium mb-4 group-hover:scale-110 transition-transform" size={24} />
                      <h3 className="text-xs font-bold uppercase tracking-widest text-warm-ivory mb-2">
                        Business & Cargo
                      </h3>
                      <p className="text-xs text-blue-aviation/80 leading-relaxed mb-6">
                        Supporting trade, logistics, and corporate aviation growth.
                      </p>
                    </div>
                    <button
                      onClick={() => setActivePage('business')}
                      className="text-[11px] font-bold text-gold-premium uppercase tracking-widest flex items-center gap-1 hover:underline text-left"
                    >
                      <span>Learn More</span>
                      <ArrowRight size={12} />
                    </button>
                  </div>

                </div>
              </div>
            </section>

            {/* Live Flights Table Section */}
            <section id="live-flights" className="py-20 bg-navy-deep">
              <div className="max-w-7xl mx-auto px-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-8">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                      Real-time Airspace logs
                    </span>
                    <h2 className="font-serif text-3xl md:text-4xl font-bold text-warm-ivory mt-1">
                      Live flights
                    </h2>
                    <p className="text-sm text-blue-aviation/80 mt-1">
                      Arrivals and departures at Purt Aer Vannin. Check active gate codes.
                    </p>
                  </div>
                  <button
                    onClick={() => setActivePage('flights')}
                    className="text-xs font-bold text-gold-premium hover:underline uppercase tracking-wider flex items-center gap-1"
                  >
                    <span>View Full Flight Board</span>
                    <ArrowRight size={14} />
                  </button>
                </div>

                {/* Shared Flight Board Widget */}
                <FlightBoard />
              </div>
            </section>

            {/* Editorial Destination Section */}
            <section id="editorial-destinations" className="py-20 bg-navy-dark border-y border-navy-steel/20">
              <div className="max-w-7xl mx-auto px-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-10">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                      Curated Journeys
                    </span>
                    <h2 className="font-serif text-3xl md:text-4xl font-bold text-warm-ivory mt-1">
                      Where will you go next?
                    </h2>
                    <p className="text-sm text-blue-aviation/80 mt-1">
                      Explore popular direct routes linking the Isle of Man to metropolitan capitals and vacation hubs.
                    </p>
                  </div>
                  <button
                    onClick={() => setActivePage('destinations')}
                    className="text-xs font-bold text-gold-premium hover:underline uppercase tracking-wider flex items-center gap-1"
                  >
                    <span>Explore All Destinations</span>
                    <ArrowRight size={14} />
                  </button>
                </div>

                {/* Curated Grid Selection */}
                <DestinationGrid />
              </div>
            </section>

            {/* Premium Parking Comparison Section */}
            <section id="parking-promo" className="py-20 bg-navy-deep">
              <div className="max-w-7xl mx-auto px-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 mb-10">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                      Secure Airport Parking
                    </span>
                    <h2 className="font-serif text-3xl md:text-4xl font-bold text-warm-ivory mt-1">
                      Arrive with ease
                    </h2>
                    <p className="text-sm text-blue-aviation/80 mt-1">
                      Compare Short Stay, Long Stay, or Premium Valet parking. Guarantee your space below.
                    </p>
                  </div>
                  <button
                    onClick={() => setActivePage('parking')}
                    className="text-xs font-bold text-gold-premium hover:underline uppercase tracking-wider flex items-center gap-1"
                  >
                    <span>Open Rate Calculator</span>
                    <ArrowRight size={14} />
                  </button>
                </div>

                <ParkingBooking />
              </div>
            </section>

            {/* Travel Guide Directory Overview */}
            <section id="travel-guide-directory" className="py-20 bg-navy-dark border-t border-navy-steel/20">
              <div className="max-w-7xl mx-auto px-6">
                <div className="text-center max-w-2xl mx-auto mb-12">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                    Terminal Checkpoints
                  </span>
                  <h2 className="font-serif text-3xl font-bold text-warm-ivory mt-1">
                    Before you travel
                  </h2>
                  <p className="text-xs md:text-sm text-blue-aviation/80 mt-1 leading-relaxed">
                    Access our comprehensive guidelines to ensure a flawless check-in and transit experience.
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                  
                  {/* Item 1 */}
                  <div
                    onClick={() => setActivePage('travel-info')}
                    className="bg-navy-deep border border-navy-steel/25 p-6 rounded hover:border-gold-premium/45 transition-all cursor-pointer flex flex-col gap-4"
                  >
                    <CheckCircle className="text-gold-premium" size={24} />
                    <div>
                      <h4 className="font-serif text-base font-bold text-warm-ivory">Check-in Window</h4>
                      <p className="text-xs text-muted-grey mt-1.5 leading-relaxed">
                        Arrive at least 2 hours before regional flights. Review online boarding procedures.
                      </p>
                    </div>
                  </div>

                  {/* Item 2 */}
                  <div
                    onClick={() => setActivePage('travel-info')}
                    className="bg-navy-deep border border-navy-steel/25 p-6 rounded hover:border-gold-premium/45 transition-all cursor-pointer flex flex-col gap-4"
                  >
                    <Shield className="text-gold-premium" size={24} />
                    <div>
                      <h4 className="font-serif text-base font-bold text-warm-ivory">Security Guidance</h4>
                      <p className="text-xs text-muted-grey mt-1.5 leading-relaxed">
                        Understand liquid limitations (100ml containers) and fast-track baggage protocols.
                      </p>
                    </div>
                  </div>

                  {/* Item 3 */}
                  <div
                    onClick={() => setActivePage('travel-info')}
                    className="bg-navy-deep border border-navy-steel/25 p-6 rounded hover:border-gold-premium/45 transition-all cursor-pointer flex flex-col gap-4"
                  >
                    <Luggage className="text-gold-premium" size={24} />
                    <div>
                      <h4 className="font-serif text-base font-bold text-warm-ivory">Baggage Allowances</h4>
                      <p className="text-xs text-muted-grey mt-1.5 leading-relaxed">
                        Verify weight dimensions with easyJet and Loganair. Avoid unexpected baggage surcharges.
                      </p>
                    </div>
                  </div>

                  {/* Item 4 */}
                  <div
                    onClick={() => setActivePage('travel-info')}
                    className="bg-navy-deep border border-navy-steel/25 p-6 rounded hover:border-gold-premium/45 transition-all cursor-pointer flex flex-col gap-4"
                  >
                    <Accessibility className="text-gold-premium" size={24} />
                    <div>
                      <h4 className="font-serif text-base font-bold text-warm-ivory">Special Assistance</h4>
                      <p className="text-xs text-muted-grey mt-1.5 leading-relaxed">
                        Dedicated mobility support and discrete Sunflower Lanyard programs for travelers.
                      </p>
                    </div>
                  </div>

                </div>
              </div>
            </section>

            {/* Editorial Airport Experience section */}
            <section id="airport-exp-promo" className="relative py-24 bg-navy-deep overflow-hidden">
              <div className="absolute inset-0 bg-cover bg-center opacity-20" style={{ backgroundImage: "url('https://picsum.photos/seed/terminal_interior/1500/800')" }} />
              <div className="max-w-7xl mx-auto px-6 relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                <div className="flex flex-col gap-6">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                    Ronaldsway Welcome
                  </span>
                  <h2 className="font-serif text-3xl md:text-4xl font-bold text-warm-ivory leading-tight">
                    More than a departure point
                  </h2>
                  <p className="text-sm text-blue-aviation/90 leading-relaxed">
                    Purt Aer Vannin is the gateway between the Isle of Man and the wider world. Designed around a smoother, more welcoming journey, the airport connects passengers, businesses and communities across the British Isles and beyond.
                  </p>
                  <p className="text-xs text-muted-grey leading-relaxed">
                    Enjoy our high-end craft emporiums, dining, and the executive Halcyon lounge overlooking the Southern sea cliffs.
                  </p>
                  <div className="flex flex-wrap gap-4 pt-2">
                    <button
                      onClick={() => setActivePage('airport')}
                      className="px-5 py-3 bg-gold-premium hover:bg-gold-premium/85 text-navy-deep font-bold text-xs uppercase tracking-widest rounded transition-all"
                    >
                      Explore The Airport →
                    </button>
                    <button
                      onClick={() => setActivePage('airport')}
                      className="px-5 py-3 border border-navy-steel/50 hover:border-warm-ivory text-warm-ivory font-bold text-xs uppercase tracking-widest rounded transition-all"
                    >
                      Services & Facilities →
                    </button>
                  </div>
                </div>

                <div className="relative rounded-lg overflow-hidden shadow-2xl border border-navy-steel/30 group">
                  <img
                    src="https://picsum.photos/seed/iom_coast_cliffs/800/500"
                    alt="Isle of Man coastal runway"
                    className="w-full object-cover h-80 transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-navy-deep/20" />
                </div>
              </div>
            </section>

            {/* Strategic Business overview */}
            <section id="business-summary" className="py-20 bg-navy-dark border-t border-navy-steel/20">
              <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-3 gap-12 items-center">
                
                <div className="lg:col-span-1">
                  <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                    Isle of Man Commerce
                  </span>
                  <h2 className="font-serif text-3xl font-bold text-warm-ivory leading-tight mt-1">
                    Connecting business to opportunity
                  </h2>
                  <p className="text-xs md:text-sm text-blue-aviation/85 leading-relaxed mt-4 mb-6">
                    We serve as vital strategic infrastructure backing Isle of Man tourism, modern business aviation, cargo logistics, and global finance investments.
                  </p>
                  <button
                    onClick={() => setActivePage('business')}
                    className="px-5 py-3 bg-navy-deep border border-gold-premium/50 hover:bg-gold-premium hover:text-navy-deep rounded text-xs font-bold uppercase tracking-widest text-gold-premium transition-all"
                  >
                    Business at the Airport →
                  </button>
                </div>

                {/* stats grid */}
                <div className="lg:col-span-2 grid grid-cols-1 sm:grid-cols-3 gap-6">
                  
                  <div className="bg-navy-deep border border-navy-steel/35 p-6 rounded text-center hover:border-gold-premium/30 transition-all">
                    <div className="font-serif text-3xl font-bold text-gold-premium mb-1">IOM</div>
                    <div className="text-xs text-warm-ivory font-semibold uppercase tracking-wider">Gateway</div>
                    <p className="text-[11px] text-muted-grey mt-2">
                      Isle of Man’s primary international gateway.
                    </p>
                  </div>

                  <div className="bg-navy-deep border border-navy-steel/35 p-6 rounded text-center hover:border-gold-premium/30 transition-all">
                    <div className="font-serif text-3xl font-bold text-gold-premium mb-1">24/7</div>
                    <div className="text-xs text-warm-ivory font-semibold uppercase tracking-wider">Operational</div>
                    <p className="text-[11px] text-muted-grey mt-2">
                      Full weather and runway support capabilities.
                    </p>
                  </div>

                  <div className="bg-navy-deep border border-navy-steel/35 p-6 rounded text-center hover:border-gold-premium/30 transition-all">
                    <div className="font-serif text-3xl font-bold text-gold-premium mb-1">UK & IRE</div>
                    <div className="text-xs text-warm-ivory font-semibold uppercase tracking-wider">Connectivity</div>
                    <p className="text-[11px] text-muted-grey mt-2">
                      Robust, scheduled metropolitan hubs networks.
                    </p>
                  </div>

                </div>

              </div>
            </section>

            {/* Spectatular Isle of Man promotional section */}
            <section id="island-promotional" className="relative py-28 flex flex-col justify-center items-center text-center">
              <div className="absolute inset-0 bg-cover bg-center z-0" style={{ backgroundImage: "url('https://picsum.photos/seed/manx_coast_prom/1920/800')" }} />
              <div className="absolute inset-0 bg-navy-deep/80 z-10" />

              <div className="relative z-20 max-w-3xl mx-auto px-6 flex flex-col items-center gap-5">
                <Award className="text-gold-premium" size={32} />
                <h2 className="font-editorial font-serif text-4xl sm:text-5xl font-bold text-warm-ivory">
                  Small Island. Global Connections.
                </h2>
                <p className="text-sm md:text-base text-blue-aviation/95 max-w-2xl leading-relaxed">
                  Discover an island of extraordinary coastal landscapes, rich Celtic history, legendary motorsport, and premier financial opportunities.
                </p>
                <div className="flex flex-wrap gap-4 mt-2">
                  <a
                    href="https://www.visitisleofman.com"
                    target="_blank"
                    rel="noreferrer"
                    className="px-6 py-3 bg-gold-premium text-navy-deep font-bold text-xs uppercase tracking-widest rounded hover:bg-warm-ivory transition-colors flex items-center gap-1.5"
                  >
                    <span>Discover The Isle of Man</span>
                    <ArrowUpRight size={12} />
                  </a>
                  <button
                    onClick={() => setActivePage('travel-info')}
                    className="px-6 py-3 border border-navy-steel/50 hover:border-warm-ivory text-warm-ivory font-bold text-xs uppercase tracking-widest rounded transition-all"
                  >
                    Plan Your Visit
                  </button>
                </div>
              </div>
            </section>

          </div>
        )}

        {/* FLIGHTS PAGE VIEW */}
        {activePage === 'flights' && (
          <section className="py-12 bg-navy-deep animate-fade-in">
            <div className="max-w-7xl mx-auto px-6">
              
              <div className="mb-10 text-center max-w-3xl mx-auto">
                <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                  Aviation Terminal Operations
                </span>
                <h1 className="font-serif text-3xl md:text-5xl font-bold text-warm-ivory mt-1">
                  Flight Terminal logs
                </h1>
                <p className="text-xs md:text-sm text-blue-aviation/85 mt-2">
                  Inspect real-time aircraft arrivals, boarding schedules, delayed alerts, and baggage carousel assignments at Ronaldsway.
                </p>
              </div>

              {/* Shared Component */}
              <FlightBoard />

              {/* Passenger FAQ Accordion block */}
              <div className="mt-16 bg-navy-dark border border-navy-steel/30 rounded-lg p-6 lg:p-8">
                <h3 className="font-serif text-lg font-bold text-warm-ivory border-b border-navy-steel/20 pb-3 mb-4">
                  Flight Board FAQ
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-blue-aviation">
                  <div>
                    <h5 className="font-bold text-warm-ivory mb-1">How accurate is the Live Flight Board?</h5>
                    <p className="leading-relaxed text-muted-grey">
                      Our logs update directly from regional Air Traffic Control transmitters. Times are synchronized instantly to local ATC feeds.
                    </p>
                  </div>
                  <div>
                    <h5 className="font-bold text-warm-ivory mb-1">What does Delayed status mean for easyJet/Loganair?</h5>
                    <p className="leading-relaxed text-muted-grey">
                      Delays occur due to weather congestion or airspace control over the Irish Sea. Please remain in the Departures Lounge for immediate boarding announcements.
                    </p>
                  </div>
                </div>
              </div>

            </div>
          </section>
        )}

        {/* DESTINATIONS PAGE VIEW */}
        {activePage === 'destinations' && (
          <section className="py-12 bg-navy-deep animate-fade-in">
            <div className="max-w-7xl mx-auto px-6">
              
              <div className="mb-10 text-center max-w-3xl mx-auto">
                <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                  Explore Direct Connections
                </span>
                <h1 className="font-serif text-3xl md:text-5xl font-bold text-warm-ivory mt-1">
                  Our route network
                </h1>
                <p className="text-xs md:text-sm text-blue-aviation/85 mt-2">
                  Check flight durations, operator schedules, and global connecting hubs available directly from Ronaldsway IOM.
                </p>
              </div>

              {/* Shared Component */}
              <DestinationGrid />

              {/* Connecting flight banner */}
              <div className="mt-16 bg-navy-dark border border-navy-steel/45 rounded-lg p-8 grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
                <div className="lg:col-span-2">
                  <h4 className="font-serif text-xl font-bold text-gold-premium mb-2">Transatlantic US Clearance via Dublin</h4>
                  <p className="text-xs text-blue-aviation leading-relaxed">
                    By flying to Dublin (DUB) with Aer Lingus Regional, passengers can clear US Customs & Border Protection (CBP) directly in Ireland. Land in the USA as a domestic arrival, bypassing long queues completely.
                  </p>
                </div>
                <div className="text-right">
                  <button
                    onClick={() => {
                      alert("Opening Transatlantic pre-clearance info kit.");
                    }}
                    className="px-5 py-3 bg-gold-premium text-navy-deep font-bold text-xs uppercase tracking-widest rounded hover:bg-warm-ivory transition-colors w-full lg:w-auto"
                  >
                    US pre-clearance guide
                  </button>
                </div>
              </div>

            </div>
          </section>
        )}

        {/* PARKING PAGE VIEW */}
        {activePage === 'parking' && (
          <section className="py-12 bg-navy-deep animate-fade-in">
            <div className="max-w-7xl mx-auto px-6">
              
              <div className="mb-10 text-center max-w-3xl mx-auto">
                <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                  Pre-Book to Secure Rates
                </span>
                <h1 className="font-serif text-3xl md:text-5xl font-bold text-warm-ivory mt-1">
                  Airport Parking Solutions
                </h1>
                <p className="text-xs md:text-sm text-blue-aviation/85 mt-2">
                  Whether dropping off for 15 minutes or taking a fortnight cruise, Ronaldsway provides exceptionally safe, well-lit spaces equipped with plate scanning access.
                </p>
              </div>

              {/* Shared Component */}
              <ParkingBooking />

              {/* Directions & Maps */}
              <div className="mt-16 grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
                <div className="bg-navy-dark border border-navy-steel/30 rounded-lg p-6 lg:p-8 flex flex-col justify-between">
                  <div>
                    <h4 className="font-serif text-lg font-bold text-warm-ivory mb-3">ANPR Gate Guide</h4>
                    <p className="text-xs text-blue-aviation leading-relaxed mb-4">
                      Our system registers your car plate on booking. When you arrive:
                    </p>
                    <ol className="text-xs text-muted-grey space-y-2 list-decimal pl-4">
                      <li>Drive up slowly to the parking barrier.</li>
                      <li>Our high-definition camera scanner reads your license plate.</li>
                      <li>The barrier automatically raises and prints a confirmation stub.</li>
                      <li>Park in any open spot matching your booked package.</li>
                    </ol>
                  </div>
                  <div className="text-[10px] text-gold-premium font-semibold mt-4">
                    Need Help? Press the assistance buzzer at the gate for immediate desk support.
                  </div>
                </div>

                <div className="bg-navy-dark border border-navy-steel/30 rounded-lg p-6 lg:p-8 flex flex-col justify-between">
                  <div>
                    <h4 className="font-serif text-lg font-bold text-warm-ivory mb-3 font-semibold">Drop-off & Pick-up Rules</h4>
                    <p className="text-xs text-blue-aviation leading-relaxed mb-4">
                      Picking up friends or family? Short Stay Parking offers the first 15 minutes absolutely free.
                    </p>
                    <p className="text-xs text-muted-grey leading-relaxed">
                      Stopping or parking directly in the terminal access lane is strictly prohibited for security clearance. Please utilize the designated Drop-Off zone located in the Short Stay loop.
                    </p>
                  </div>
                  <div className="border-t border-navy-steel/15 pt-4 flex justify-between items-center text-xs">
                    <span className="font-bold text-warm-ivory">Drop Zone Access Cost:</span>
                    <span className="font-bold text-green-400">FREE (Under 15 mins)</span>
                  </div>
                </div>
              </div>

            </div>
          </section>
        )}

        {/* TRAVEL INFO PAGE VIEW */}
        {activePage === 'travel-info' && (
          <section className="py-12 bg-navy-deep animate-fade-in">
            <div className="max-w-7xl mx-auto px-6">
              
              <div className="mb-12 text-center max-w-3xl mx-auto">
                <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                  Guidelines & Security Rules
                </span>
                <h1 className="font-serif text-3xl md:text-5xl font-bold text-warm-ivory mt-1">
                  Passenger travel guide
                </h1>
                <p className="text-xs md:text-sm text-blue-aviation/85 mt-2">
                  Stay secure and travel smart. Access everything you need regarding liquids, hand luggage restrictions, customs, and documentation.
                </p>
              </div>

              {/* Structured Checklist Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                
                {/* Left: General Guidelines */}
                <div className="lg:col-span-2 flex flex-col gap-6">
                  
                  {/* Security Panel */}
                  <div className="bg-navy-dark border border-navy-steel/40 rounded-lg p-6 lg:p-8">
                    <h3 className="font-serif text-lg font-bold text-gold-premium mb-4 flex items-center gap-2">
                      <Shield size={18} />
                      <span>Liquid & Security Restrictions</span>
                    </h3>
                    <p className="text-xs text-blue-aviation leading-relaxed mb-4">
                      In accordance with UK Civil Aviation Authority standards:
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs text-muted-grey">
                      <div className="bg-navy-deep p-4 rounded border border-navy-steel/20">
                        <span className="font-bold text-warm-ivory block mb-1">Liquids under 100ml</span>
                        All liquids, pastes, gels, and creams must reside in containers of 100ml or less, packed inside a clear, resealable plastic bag.
                      </div>
                      <div className="bg-navy-deep p-4 rounded border border-navy-steel/20">
                        <span className="font-bold text-warm-ivory block mb-1">Electronics & Devices</span>
                        Laptops, tablets, kindle readers, and chargers must be removed from your hand luggage and placed separately in airport screening trays.
                      </div>
                    </div>
                  </div>

                  {/* Baggage Panel */}
                  <div className="bg-navy-dark border border-navy-steel/40 rounded-lg p-6 lg:p-8">
                    <h3 className="font-serif text-lg font-bold text-warm-ivory mb-4 flex items-center gap-2">
                      <Luggage size={18} className="text-gold-premium" />
                      <span>Baggage drop procedures</span>
                    </h3>
                    <p className="text-xs text-blue-aviation leading-relaxed mb-4">
                      Airlines operating at Ronaldsway (Loganair, easyJet, Aer Lingus) handle their own boarding thresholds. Please confirm with your airline operator:
                    </p>
                    <div className="flex flex-col gap-3 text-xs">
                      <div className="flex justify-between items-center border-b border-navy-steel/15 pb-2">
                        <span className="font-bold text-warm-ivory">easyJet Baggage Weight limit</span>
                        <span className="text-muted-grey font-mono">15kg or 23kg Options</span>
                      </div>
                      <div className="flex justify-between items-center border-b border-navy-steel/15 pb-2">
                        <span className="font-bold text-warm-ivory">Loganair Checked baggage allowance</span>
                        <span className="text-muted-grey font-mono">15kg Included on standard fares</span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-warm-ivory">Aer Lingus Regional hand baggage size</span>
                        <span className="text-muted-grey font-mono">Max 10kg cabin bag (55 x 40 x 24 cm)</span>
                      </div>
                    </div>
                  </div>

                </div>

                {/* Right: Quick Action Travel Checklist */}
                <div className="lg:col-span-1 bg-navy-dark border border-gold-premium/25 rounded-lg p-6 lg:p-8 flex flex-col justify-between">
                  <div>
                    <h4 className="font-serif text-lg font-bold text-warm-ivory mb-2">Travel Checklist</h4>
                    <p className="text-xs text-blue-aviation leading-relaxed mb-6">
                      Double check these essential details before departing for the Ronaldsway terminal.
                    </p>

                    <div className="flex flex-col gap-4 text-xs">
                      <div className="flex items-start gap-2.5 text-muted-grey">
                        <input type="checkbox" defaultChecked className="mt-1 rounded text-gold-premium focus:ring-0" />
                        <div>
                          <span className="font-bold text-warm-ivory block">Valid Passport / Photo ID</span>
                          A photo ID is mandatory for all domestic flights inside the UK/Ireland Common Travel Area.
                        </div>
                      </div>

                      <div className="flex items-start gap-2.5 text-muted-grey">
                        <input type="checkbox" className="mt-1 rounded text-gold-premium focus:ring-0" />
                        <div>
                          <span className="font-bold text-warm-ivory block">Mobile Boarding Passes</span>
                          Load your mobile boarding card on your device or prepare a legible printed receipt.
                        </div>
                      </div>

                      <div className="flex items-start gap-2.5 text-muted-grey">
                        <input type="checkbox" className="mt-1 rounded text-gold-premium focus:ring-0" />
                        <div>
                          <span className="font-bold text-warm-ivory block">Parking plate confirmation</span>
                          Make sure you booked parking to ensure automated plate scanning at Short/Long gates.
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="border-t border-navy-steel/20 pt-6 mt-8">
                    <button
                      onClick={() => alert("Printing traveler info pack.")}
                      className="w-full py-3 bg-gold-premium text-navy-deep font-bold rounded text-xs uppercase tracking-widest hover:bg-warm-ivory transition-colors"
                    >
                      Download Traveler Pack
                    </button>
                  </div>
                </div>

              </div>

            </div>
          </section>
        )}

        {/* AIRPORT EXPERIENCE PAGE VIEW */}
        {activePage === 'airport' && (
          <section className="py-12 bg-navy-deep animate-fade-in">
            <div className="max-w-7xl mx-auto px-6">
              
              <div className="mb-12 text-center max-w-3xl mx-auto">
                <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                  Duty Free & Dining
                </span>
                <h1 className="font-serif text-3xl md:text-5xl font-bold text-warm-ivory mt-1">
                  Airport terminal experience
                </h1>
                <p className="text-xs md:text-sm text-blue-aviation/85 mt-2">
                  Explore outstanding local Manx shops, gourmet restaurants overlooking the apron, and pre-book the premium executive Halcyon Lounge.
                </p>
              </div>

              {/* Halcyon executive lounge spotlight */}
              <div className="bg-navy-dark border border-gold-premium/30 rounded-lg overflow-hidden grid grid-cols-1 lg:grid-cols-2 gap-8 items-stretch shadow-2xl mb-16">
                <div className="h-72 lg:h-auto bg-cover bg-center" style={{ backgroundImage: `url('${mockLounges[0].image}')` }} />
                <div className="p-6 lg:p-10 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] text-gold-premium font-mono uppercase tracking-widest font-bold">
                      Premium Passengers Oasis
                    </span>
                    <h3 className="font-serif text-2xl md:text-3xl font-bold text-warm-ivory mt-1 mb-3">
                      {mockLounges[0].name}
                    </h3>
                    <p className="text-xs md:text-sm text-blue-aviation leading-relaxed mb-6">
                      {mockLounges[0].description}
                    </p>

                    <h5 className="text-xs font-bold text-warm-ivory uppercase tracking-wider mb-2">Lounge Features Include:</h5>
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-muted-grey mb-6">
                      {mockLounges[0].features.slice(0, 4).map((feat, i) => (
                        <li key={i} className="flex items-start gap-1.5">
                          <span className="text-gold-premium font-bold">•</span>
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="border-t border-navy-steel/15 pt-6 flex flex-col sm:flex-row justify-between items-center gap-4">
                    <div>
                      <span className="text-[10px] uppercase text-muted-grey font-bold block">Entry Passes</span>
                      <span className="text-xl font-bold text-gold-premium font-serif">£{mockLounges[0].price} <span className="text-xs text-muted-grey">/ guest</span></span>
                    </div>
                    <button
                      onClick={() => alert(`Passing to executive Halcyon Lounge booking for ${mockLounges[0].name}.`)}
                      className="px-6 py-3 bg-gold-premium text-navy-deep font-bold text-xs uppercase tracking-widest rounded hover:bg-warm-ivory transition-colors w-full sm:w-auto"
                    >
                      Pre-Book Lounge Access
                    </button>
                  </div>
                </div>
              </div>

              {/* Dining and shopping directory list */}
              <h3 className="font-serif text-xl md:text-2xl font-bold text-warm-ivory mb-6 border-b border-navy-steel/20 pb-3">
                Shopping & dining directory
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
                {mockShopsRestaurants.map((sr) => (
                  <div key={sr.id} className="bg-navy-dark border border-navy-steel/25 rounded-lg overflow-hidden hover:border-gold-premium/40 transition-all flex flex-col justify-between">
                    <img src={sr.image} alt={sr.name} className="h-44 w-full object-cover" referrerPolicy="no-referrer" />
                    <div className="p-5 flex-grow flex flex-col justify-between">
                      <div>
                        <span className="text-[9px] text-gold-premium font-mono uppercase tracking-widest font-bold">
                          {sr.type === 'shop' ? 'Crafts & Retail' : 'Dining & Bar'}
                        </span>
                        <h4 className="font-serif text-base font-bold text-warm-ivory mt-0.5">{sr.name}</h4>
                        <p className="text-[11px] text-muted-grey leading-relaxed mt-2">{sr.description}</p>
                      </div>
                      <div className="border-t border-navy-steel/15 pt-3 mt-4 text-[10px] text-blue-aviation flex justify-between">
                        <span>Location: {sr.location.split(' ')[0]}</span>
                        <span className="font-semibold text-warm-ivory">{sr.hours}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Terminal Map mock visual block */}
              <div className="bg-navy-dark border border-navy-steel/30 rounded-lg p-6 lg:p-8 text-center max-w-3xl mx-auto">
                <Map className="text-gold-premium mx-auto mb-3" size={32} />
                <h4 className="font-serif text-lg font-bold text-warm-ivory mb-2">Looking for the Terminal Map?</h4>
                <p className="text-xs text-blue-aviation max-w-lg mx-auto leading-relaxed mb-6">
                  Purt Aer Vannin features a highly consolidated, single-terminal layout. Check-in desks, security clearance, and departure gates are all within 3 minutes walking distance.
                </p>
                <button
                  onClick={() => alert("High-resolution terminal layout Map PDF is loading in mock folder.")}
                  className="px-5 py-2.5 border border-navy-steel/50 hover:border-warm-ivory rounded text-xs font-bold text-warm-ivory uppercase tracking-wider"
                >
                  View high-res layout
                </button>
              </div>

            </div>
          </section>
        )}

        {/* BUSINESS & CARGO PAGE VIEW */}
        {activePage === 'business' && (
          <section className="py-12 bg-navy-deep animate-fade-in">
            <div className="max-w-7xl mx-auto px-6">
              
              <div className="mb-12 text-center max-w-3xl mx-auto">
                <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                  Trade, Logistics, & Investment
                </span>
                <h1 className="font-serif text-3xl md:text-5xl font-bold text-warm-ivory mt-1">
                  Business & cargo operations
                </h1>
                <p className="text-xs md:text-sm text-blue-aviation/85 mt-2">
                  A crucial commercial infrastructure node connecting Manx commerce, property development, commercial cargo, and elite private aviation.
                </p>
              </div>

              {/* Commercial blocks */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
                
                {/* Block 1 */}
                <div className="bg-navy-dark border border-navy-steel/25 p-6 rounded hover:border-gold-premium/30 transition-all flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] uppercase text-gold-premium tracking-widest block font-bold mb-1">Aviation Logistics</span>
                    <h4 className="font-serif text-base font-bold text-warm-ivory mb-2">Scheduled Cargo Networks</h4>
                    <p className="text-xs text-muted-grey leading-relaxed">
                      Ensuring rapid delivery of medical equipment, mail, e-commerce packages, and critical machinery to the Isle of Man 24 hours a day.
                    </p>
                  </div>
                  <span className="text-[10px] text-blue-aviation uppercase tracking-wider mt-4">Capacity: 1400 tonnes annually</span>
                </div>

                {/* Block 2 */}
                <div className="bg-navy-dark border border-navy-steel/25 p-6 rounded hover:border-gold-premium/30 transition-all flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] uppercase text-gold-premium tracking-widest block font-bold mb-1">FBO Services</span>
                    <h4 className="font-serif text-base font-bold text-warm-ivory mb-2">Private Executive Aviation</h4>
                    <p className="text-xs text-muted-grey leading-relaxed">
                      Custom handling protocols, hangar housing, rapid refueling, and exclusive crew lounges available for private and corporate charter arrivals.
                    </p>
                  </div>
                  <span className="text-[10px] text-blue-aviation uppercase tracking-wider mt-4">24-hour landing slots clearance</span>
                </div>

                {/* Block 3 */}
                <div className="bg-navy-dark border border-navy-steel/25 p-6 rounded hover:border-gold-premium/30 transition-all flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] uppercase text-gold-premium tracking-widest block font-bold mb-1">Real Estate</span>
                    <h4 className="font-serif text-base font-bold text-warm-ivory mb-2">Property & Development</h4>
                    <p className="text-xs text-muted-grey leading-relaxed">
                      Commercial development land plots surrounding Ronaldsway runway are open for aviation and technical manufacturing investment leases.
                    </p>
                  </div>
                  <span className="text-[10px] text-blue-aviation uppercase tracking-wider mt-4">Over 45 hectares available</span>
                </div>

              </div>

              {/* Inquiry form */}
              <div className="bg-navy-dark border border-navy-steel/40 rounded-lg p-6 lg:p-10 max-w-xl mx-auto shadow-2xl">
                <div className="text-center mb-6">
                  <h3 className="font-serif text-xl font-bold text-warm-ivory">Contact Airport Business Unit</h3>
                  <p className="text-xs text-blue-aviation mt-1">
                    Request custom slots rates, property prospectus leases, or cargo logistics coordination.
                  </p>
                </div>

                {bizSuccess ? (
                  <div className="p-4 bg-green-950/30 border border-green-500/20 text-green-300 rounded text-xs text-center">
                    <CheckCircle className="mx-auto text-green-400 mb-2" size={24} />
                    <p className="font-bold">Inquiry Successfully Registered</p>
                    <p className="mt-1">Our commercial manager will contact your office in 24 business hours.</p>
                  </div>
                ) : (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!bizCompany || !bizEmail) {
                        alert("Please provide your company name and email.");
                        return;
                      }
                      setBizSuccess(true);
                    }}
                    className="flex flex-col gap-4 text-xs"
                  >
                    <div className="flex flex-col gap-1.5">
                      <label className="font-bold text-muted-grey uppercase tracking-wider">Company Name</label>
                      <input
                        type="text"
                        placeholder="e.g. Manx Logistics Corp"
                        value={bizCompany}
                        onChange={(e) => setBizCompany(e.target.value)}
                        className="bg-navy-deep border border-navy-steel/40 rounded p-3 text-xs text-warm-ivory outline-none focus:border-gold-premium"
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="font-bold text-muted-grey uppercase tracking-wider">Corporate Email</label>
                      <input
                        type="email"
                        placeholder="logistics@company.com"
                        value={bizEmail}
                        onChange={(e) => setBizEmail(e.target.value)}
                        className="bg-navy-deep border border-navy-steel/40 rounded p-3 text-xs text-warm-ivory outline-none focus:border-gold-premium"
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="font-bold text-muted-grey uppercase tracking-wider">Requested Commercial Sector</label>
                      <select
                        value={bizService}
                        onChange={(e) => setBizService(e.target.value)}
                        className="bg-navy-deep border border-navy-steel/40 rounded p-3 text-xs text-warm-ivory outline-none focus:border-gold-premium"
                      >
                        <option value="cargo">Scheduled Cargo & Shipping</option>
                        <option value="fbo">FBO Private Ground Slots</option>
                        <option value="property">Property Lease & Development</option>
                        <option value="advertising">Terminal Advertising spaces</option>
                      </select>
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3.5 bg-gold-premium text-navy-deep font-bold rounded uppercase tracking-widest hover:bg-warm-ivory transition-all"
                    >
                      Submit Corporate Inquiry
                    </button>
                  </form>
                )}
              </div>

            </div>
          </section>
        )}

        {/* ABOUT PAGE VIEW */}
        {activePage === 'about' && (
          <section className="py-12 bg-navy-deep animate-fade-in">
            <div className="max-w-7xl mx-auto px-6">
              
              <div className="mb-12 text-center max-w-3xl mx-auto">
                <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                  Corporate Governance
                </span>
                <h1 className="font-serif text-3xl md:text-5xl font-bold text-warm-ivory mt-1">
                  About Purt Aer Vannin
                </h1>
                <p className="text-xs md:text-sm text-blue-aviation/85 mt-2">
                  Learn about the historical milestones of Ronaldsway, our commitment to green carbon neutrality, and active career openings at the airport.
                </p>
              </div>

              {/* History & Sustainability columns */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-16">
                
                {/* Left */}
                <div className="bg-navy-dark border border-navy-steel/30 rounded-lg p-6 lg:p-8">
                  <h3 className="font-serif text-xl font-bold text-gold-premium mb-3">Ronaldsway Legacy</h3>
                  <p className="text-xs md:text-sm text-blue-aviation/90 leading-relaxed mb-4">
                    Airport operations in Ronaldsway first commenced in 1928, later serving as an important military Royal Naval Air Station (HMS Urley) during World War II.
                  </p>
                  <p className="text-xs text-muted-grey leading-relaxed">
                    Today, the airport undergoes substantial upgrades to modernise runway instrumentation, visual landing beacons, and passenger baggage scanning systems. This secures Ronaldsway as a premium, future-ready travel hub for the 2030s.
                  </p>
                </div>

                {/* Right */}
                <div className="bg-navy-dark border border-navy-steel/30 rounded-lg p-6 lg:p-8">
                  <h3 className="font-serif text-xl font-bold text-gold-premium mb-3">Eco & Sustainability Targets</h3>
                  <p className="text-xs md:text-sm text-blue-aviation/90 leading-relaxed mb-4">
                    Purt Aer Vannin is fully aligned with the Isle of Man Government’s strategic Net Zero carbon commitment:
                  </p>
                  <ul className="text-xs text-muted-grey flex flex-col gap-2">
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-gold-premium" />
                      <span>100% of terminal light systems are low-power LED matrices.</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-gold-premium" />
                      <span>Carbon emission offsets targeting airport vehicle fleets.</span>
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-gold-premium" />
                      <span>Investigating on-site solar farms to generate clean grid power.</span>
                    </li>
                  </ul>
                </div>

              </div>

              {/* Careers Open Roles section */}
              <h3 className="font-serif text-xl md:text-2xl font-bold text-warm-ivory mb-6 border-b border-navy-steel/20 pb-3">
                Careers at the Airport
              </h3>
              <p className="text-xs text-blue-aviation max-w-2xl leading-relaxed mb-8">
                Join an elite, safety-focused crew of security professionals, engineering technicians, and air traffic coordinators. We offer exceptional pension programs and continuous technical certification.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
                {mockCareers.map((car) => (
                  <div key={car.id} className="bg-navy-dark border border-navy-steel/25 p-6 rounded-lg flex flex-col justify-between hover:border-gold-premium/45 transition-all">
                    <div>
                      <span className="text-[10px] uppercase text-gold-premium tracking-widest block font-bold mb-1">{car.department}</span>
                      <h4 className="font-serif text-base font-bold text-warm-ivory">{car.title}</h4>
                      <p className="text-[11px] text-muted-grey leading-relaxed mt-2.5 mb-4 line-clamp-3">{car.description}</p>
                    </div>

                    <div className="border-t border-navy-steel/15 pt-4 mt-4">
                      <div className="flex justify-between text-xs mb-3">
                        <span className="text-blue-aviation">{car.type}</span>
                        <span className="font-bold text-warm-ivory font-mono">{car.salary.split(' ')[0]}</span>
                      </div>
                      <button
                        onClick={() => handleApplyJob(car)}
                        className="w-full py-2 bg-navy-deep border border-gold-premium/50 text-gold-premium text-[11px] font-bold uppercase tracking-widest rounded hover:bg-gold-premium hover:text-navy-deep transition-all"
                      >
                        Apply for Role
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Contact / Feedback Section */}
              <div id="contact-panel" className="bg-navy-dark border border-navy-steel/30 rounded-lg p-6 lg:p-10 max-w-xl mx-auto shadow-xl">
                <div className="text-center mb-6">
                  <h3 className="font-serif text-xl font-bold text-warm-ivory">Airport feedback desk</h3>
                  <p className="text-xs text-blue-aviation mt-1">
                    Have an inquiry, lost property question, or constructive criticism? Let us know.
                  </p>
                </div>

                {contactSuccess ? (
                  <div className="p-4 bg-green-950/35 border border-green-500/20 text-green-300 rounded text-xs text-center">
                    <CheckCircle className="mx-auto text-green-400 mb-2" size={24} />
                    <p className="font-bold">Message successfully logged</p>
                    <p className="mt-1">We will respond within 48 business hours to {contactEmail}.</p>
                  </div>
                ) : (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault();
                      if (!contactName || !contactEmail || !contactMsg) {
                        alert("Please complete all form fields.");
                        return;
                      }
                      setContactSuccess(true);
                    }}
                    className="flex flex-col gap-4 text-xs"
                  >
                    <div className="flex flex-col gap-1.5">
                      <label className="font-bold text-muted-grey uppercase tracking-wider">Your Name</label>
                      <input
                        type="text"
                        placeholder="Lord / Lady Passenger"
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        className="bg-navy-deep border border-navy-steel/40 rounded p-3 text-xs text-warm-ivory outline-none focus:border-gold-premium"
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="font-bold text-muted-grey uppercase tracking-wider">Your Email</label>
                      <input
                        type="email"
                        placeholder="passenger@manx.net"
                        value={contactEmail}
                        onChange={(e) => setContactEmail(e.target.value)}
                        className="bg-navy-deep border border-navy-steel/40 rounded p-3 text-xs text-warm-ivory outline-none focus:border-gold-premium"
                      />
                    </div>
                    <div className="flex flex-col gap-1.5">
                      <label className="font-bold text-muted-grey uppercase tracking-wider">Inquiry Details</label>
                      <textarea
                        rows={4}
                        placeholder="Please write your inquiry here..."
                        value={contactMsg}
                        onChange={(e) => setContactMsg(e.target.value)}
                        className="bg-navy-deep border border-navy-steel/40 rounded p-3 text-xs text-warm-ivory outline-none focus:border-gold-premium resize-none"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3.5 bg-gold-premium text-navy-deep font-bold rounded uppercase tracking-widest hover:bg-warm-ivory transition-all"
                    >
                      Submit Feedback File
                    </button>
                  </form>
                )}
              </div>

            </div>
          </section>
        )}

      </main>

      {/* JOBS MODAL */}
      {isApplyModalOpen && appliedJob && (
        <div className="fixed inset-0 bg-navy-deep/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-navy-dark border border-gold-premium/40 rounded-lg max-w-md w-full shadow-2xl p-6 relative">
            <button
              onClick={() => setIsApplyModalOpen(false)}
              className="absolute right-4 top-4 text-muted-grey hover:text-warm-ivory"
            >
              <X size={18} />
            </button>

            <h3 className="font-serif text-lg font-bold text-warm-ivory border-b border-navy-steel/20 pb-3 mb-4">
              Apply: {appliedJob.title}
            </h3>

            <form onSubmit={submitJobApplication} className="flex flex-col gap-4 text-xs">
              <div className="flex flex-col gap-1.5">
                <label className="font-bold text-muted-grey uppercase tracking-wider">Full Name</label>
                <input
                  type="text"
                  placeholder="Lord Passenger"
                  value={jobFormName}
                  required
                  onChange={(e) => setJobFormName(e.target.value)}
                  className="bg-navy-deep border border-navy-steel/45 rounded p-3 text-xs text-warm-ivory outline-none focus:border-gold-premium"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="font-bold text-muted-grey uppercase tracking-wider">Email</label>
                <input
                  type="email"
                  placeholder="passenger@manx.net"
                  value={jobFormEmail}
                  required
                  onChange={(e) => setJobFormEmail(e.target.value)}
                  className="bg-navy-deep border border-navy-steel/45 rounded p-3 text-xs text-warm-ivory outline-none focus:border-gold-premium"
                />
              </div>

              <div className="flex flex-col gap-1.5">
                <label className="font-bold text-muted-grey uppercase tracking-wider">Attach Resume/CV (Mock File)</label>
                <input
                  type="text"
                  value={jobFormCV}
                  readOnly
                  className="bg-navy-deep border border-navy-steel/45 rounded p-3 text-xs text-muted-grey cursor-not-allowed outline-none font-mono"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-gold-premium text-navy-deep font-bold rounded uppercase tracking-widest hover:bg-warm-ivory transition-colors mt-2"
              >
                Send Official Application
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Persistent Footer */}
      <Footer setActivePage={setActivePage} />

    </div>
  );
}
