'use client';

import React, { useState } from 'react';
import { Search, PlaneTakeoff, PlaneLanding, Filter, RefreshCw, Clock, ArrowRight, Shield, X } from 'lucide-react';
import { mockFlights, Flight } from '@/data/airportData';

export default function FlightBoard() {
  const [activeTab, setActiveTab] = useState<'departure' | 'arrival'>('departure');
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [selectedFlight, setSelectedFlight] = useState<Flight | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleRefresh = () => {
    setIsLoading(true);
    setTimeout(() => {
      setIsLoading(false);
    }, 600);
  };

  const filteredFlights = mockFlights.filter((flight) => {
    if (flight.type !== activeTab) return false;

    const matchesSearch =
      flight.flightNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      flight.airportName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      flight.airportCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      flight.airline.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'ALL' || flight.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: Flight['status']) => {
    switch (status) {
      case 'Departed':
      case 'Landed':
        return 'text-muted-grey bg-navy-steel/20 border-navy-steel/40';
      case 'Boarding':
        return 'text-gold-premium bg-gold-premium/10 border-gold-premium/30';
      case 'Gate Open':
        return 'text-green-400 bg-green-500/10 border-green-500/20';
      case 'Delayed':
        return 'text-red-400 bg-red-500/10 border-red-500/20';
      case 'On Time':
      case 'Scheduled':
        return 'text-blue-aviation bg-blue-aviation/10 border-blue-aviation/20';
      case 'Baggage Claim':
        return 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      default:
        return 'text-warm-ivory bg-navy-steel/10';
    }
  };

  return (
    <div id="flight-board" className="bg-navy-dark border border-navy-steel/30 rounded-lg p-6 lg:p-8 shadow-xl font-interface">
      {/* Header with Switcher and Search */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 mb-8 border-b border-navy-steel/20 pb-6">
        <div>
          <h2 className="text-xl md:text-2xl font-serif text-warm-ivory font-bold flex items-center gap-3">
            <span>Operational Display System</span>
            <span className="text-xs font-mono uppercase bg-navy-steel/40 px-2 py-0.5 rounded text-gold-premium tracking-wider border border-gold-premium/15 font-sans">
              Live Feed
            </span>
          </h2>
          <p className="text-xs text-blue-aviation/75 mt-1">
            Official flight logs for Ronaldsway Airport. Scheduled intervals are local GMT/BST times.
          </p>
        </div>

        {/* Tab switchers */}
        <div className="flex bg-navy-deep p-1 rounded-md border border-navy-steel/40 w-full lg:w-auto">
          <button
            onClick={() => {
              setActiveTab('departure');
              setStatusFilter('ALL');
            }}
            className={`flex-1 lg:flex-none flex items-center justify-center gap-2 px-5 py-2 rounded text-xs font-bold uppercase tracking-wider transition-all duration-150 ${
              activeTab === 'departure'
                ? 'bg-gold-premium text-navy-deep shadow'
                : 'text-blue-aviation hover:text-warm-ivory'
            }`}
          >
            <PlaneTakeoff size={14} />
            <span>Departures</span>
          </button>
          <button
            onClick={() => {
              setActiveTab('arrival');
              setStatusFilter('ALL');
            }}
            className={`flex-1 lg:flex-none flex items-center justify-center gap-2 px-5 py-2 rounded text-xs font-bold uppercase tracking-wider transition-all duration-150 ${
              activeTab === 'arrival'
                ? 'bg-gold-premium text-navy-deep shadow'
                : 'text-blue-aviation hover:text-warm-ivory'
            }`}
          >
            <PlaneLanding size={14} />
            <span>Arrivals</span>
          </button>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {/* Search Input */}
        <div className="relative flex items-center bg-navy-deep border border-navy-steel/35 rounded px-3.5 py-2">
          <Search size={15} className="text-gold-premium shrink-0 mr-2.5" />
          <input
            type="text"
            placeholder="Search destination, flight, airline..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent border-none outline-none text-xs w-full text-warm-ivory placeholder-muted-grey"
          />
        </div>

        {/* Status Filter */}
        <div className="relative flex items-center bg-navy-deep border border-navy-steel/35 rounded px-3.5 py-2">
          <Filter size={14} className="text-gold-premium shrink-0 mr-2.5" />
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="bg-transparent border-none outline-none text-xs w-full text-warm-ivory cursor-pointer focus:ring-0"
          >
            <option value="ALL" className="bg-navy-dark">All Statuses</option>
            {activeTab === 'departure' ? (
              <>
                <option value="On Time" className="bg-navy-dark">On Time</option>
                <option value="Delayed" className="bg-navy-dark">Delayed</option>
                <option value="Boarding" className="bg-navy-dark">Boarding</option>
                <option value="Gate Open" className="bg-navy-dark">Gate Open</option>
                <option value="Departed" className="bg-navy-dark">Departed</option>
              </>
            ) : (
              <>
                <option value="On Time" className="bg-navy-dark">On Time</option>
                <option value="Delayed" className="bg-navy-dark">Delayed</option>
                <option value="Landed" className="bg-navy-dark">Landed</option>
                <option value="Baggage Claim" className="bg-navy-dark">Baggage Claim</option>
              </>
            )}
          </select>
        </div>

        {/* Refresh Button */}
        <button
          onClick={handleRefresh}
          className="flex items-center justify-center gap-2.5 bg-navy-deep border border-navy-steel/35 rounded py-2 text-xs font-bold uppercase tracking-wider text-warm-ivory hover:border-gold-premium hover:text-gold-premium transition-all"
        >
          <RefreshCw size={14} className={isLoading ? 'animate-spin' : ''} />
          <span>Refresh Terminal Log</span>
        </button>
      </div>

      {/* Flight Board Content */}
      {isLoading ? (
        <div className="text-center py-24 bg-navy-deep border border-navy-steel/15 rounded flex flex-col items-center justify-center">
          <div className="relative w-12 h-12 flex items-center justify-center mb-4">
            <div className="w-10 h-10 border-4 border-gold-premium border-t-transparent rounded-full animate-spin" />
          </div>
          <p className="text-sm text-blue-aviation">Reloading operational database flight feeds...</p>
        </div>
      ) : filteredFlights.length > 0 ? (
        <>
          {/* Desktop Tabular View (Large screens) */}
          <div className="hidden md:block overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-navy-steel/25 text-[10px] uppercase tracking-widest font-bold text-muted-grey">
                  <th className="py-4 px-4">Time</th>
                  <th className="py-4 px-4">Flight</th>
                  <th className="py-4 px-4">{activeTab === 'departure' ? 'Destination' : 'Origin'}</th>
                  <th className="py-4 px-4">Airline</th>
                  <th className="py-4 px-4">Terminal Gate</th>
                  <th className="py-4 px-4 text-right">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-navy-steel/10">
                {filteredFlights.map((flight) => (
                  <tr
                    key={flight.id}
                    onClick={() => setSelectedFlight(flight)}
                    className="hover:bg-navy-deep/60 transition-all cursor-pointer border-b border-navy-steel/10 last:border-0"
                  >
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        <Clock size={13} className="text-gold-premium" />
                        <span className="font-mono font-bold text-warm-ivory text-sm">{flight.scheduledTime}</span>
                      </div>
                    </td>
                    <td className="py-4 px-4 font-mono font-bold text-gold-premium">{flight.flightNumber}</td>
                    <td className="py-4 px-4">
                      <div>
                        <span className="font-bold text-warm-ivory text-sm">{flight.airportName}</span>
                        <span className="text-[10px] bg-navy-steel/40 text-blue-aviation font-bold px-1.5 py-0.5 rounded ml-2 uppercase">
                          {flight.airportCode}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-xs font-semibold text-blue-aviation/90">{flight.airline}</td>
                    <td className="py-4 px-4 font-mono text-xs text-muted-grey">
                      {activeTab === 'departure' ? (
                        flight.gate || 'Assigning...'
                      ) : (
                        flight.baggageCarousel || 'Waiting Bag...'
                      )}
                    </td>
                    <td className="py-4 px-4 text-right">
                      <span className={`inline-block px-3 py-1 rounded text-xs font-bold border ${getStatusColor(flight.status)}`}>
                        {flight.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Mobile Card Grid View */}
          <div className="md:hidden flex flex-col gap-3">
            {filteredFlights.map((flight) => (
              <div
                key={flight.id}
                onClick={() => setSelectedFlight(flight)}
                className="bg-navy-deep border border-navy-steel/25 rounded p-4 flex flex-col gap-3 hover:border-gold-premium/45 transition-all cursor-pointer"
              >
                <div className="flex justify-between items-center border-b border-navy-steel/15 pb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-bold text-warm-ivory text-sm">{flight.scheduledTime}</span>
                    <span className="text-[10px] text-gold-premium font-mono font-semibold">{flight.flightNumber}</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${getStatusColor(flight.status)}`}>
                    {flight.status}
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <div>
                    <div className="font-bold text-warm-ivory">{flight.airportName}</div>
                    <div className="text-[10px] text-blue-aviation/70">{flight.airline}</div>
                  </div>
                  <div className="text-right text-muted-grey font-mono text-[10px]">
                    {activeTab === 'departure' ? `Gate: ${flight.gate || 'Assigning...'}` : `Baggage: ${flight.baggageCarousel || 'Waiting'}`}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      ) : (
        <div className="text-center py-20 bg-navy-deep border border-navy-steel/15 rounded text-blue-aviation/80">
          <p className="text-sm">No scheduled flight records match your active search terms.</p>
          <p className="text-xs text-muted-grey mt-1">Please try searching with standard keywords (e.g. London, Dublin).</p>
        </div>
      )}

      {/* Flight Detail Overlay Modal */}
      {selectedFlight && (
        <div className="fixed inset-0 bg-navy-deep/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-navy-dark border border-gold-premium/30 rounded-lg max-w-lg w-full shadow-2xl p-6 relative animate-scale-up">
            <button
              onClick={() => setSelectedFlight(null)}
              className="absolute right-4 top-4 text-muted-grey hover:text-warm-ivory p-1.5 rounded-full bg-navy-deep/50 hover:bg-navy-steel/20"
              aria-label="Close details"
            >
              <X size={18} />
            </button>

            <div className="flex items-center gap-3 border-b border-navy-steel/20 pb-4 mb-5">
              <span className="bg-gold-premium text-navy-deep p-2 rounded-md">
                {selectedFlight.type === 'departure' ? <PlaneTakeoff size={18} /> : <PlaneLanding size={18} />}
              </span>
              <div>
                <h3 className="text-sm font-bold text-gold-premium tracking-widest uppercase font-mono">
                  {selectedFlight.flightNumber} Detailed Logs
                </h3>
                <p className="text-xs text-blue-aviation/70">Terminal Operations Feed</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-6">
              <div className="bg-navy-deep p-3 rounded border border-navy-steel/20">
                <div className="text-[10px] font-bold text-muted-grey uppercase tracking-wider mb-0.5">Route Information</div>
                <div className="text-sm font-bold text-warm-ivory">
                  {selectedFlight.type === 'departure' ? 'Isle of Man (IOM) →' : '→ Isle of Man (IOM)'}
                </div>
                <div className="text-xs text-blue-aviation font-semibold mt-1">
                  {selectedFlight.airportName} ({selectedFlight.airportCode})
                </div>
              </div>

              <div className="bg-navy-deep p-3 rounded border border-navy-steel/20">
                <div className="text-[10px] font-bold text-muted-grey uppercase tracking-wider mb-0.5">Airline / Operator</div>
                <div className="text-sm font-bold text-warm-ivory">{selectedFlight.airline}</div>
                <div className="text-xs text-blue-aviation font-mono font-semibold mt-1">Code: {selectedFlight.airlineCode}</div>
              </div>

              <div className="bg-navy-deep p-3 rounded border border-navy-steel/20">
                <div className="text-[10px] font-bold text-muted-grey uppercase tracking-wider mb-0.5">Scheduled Time</div>
                <div className="text-sm font-bold text-warm-ivory font-mono">{selectedFlight.scheduledTime}</div>
                {selectedFlight.actualTime && (
                  <div className="text-[10px] text-gold-premium font-mono mt-0.5">Actual: {selectedFlight.actualTime}</div>
                )}
              </div>

              <div className="bg-navy-deep p-3 rounded border border-navy-steel/20">
                <div className="text-[10px] font-bold text-muted-grey uppercase tracking-wider mb-0.5">Current Status</div>
                <div className="mt-1">
                  <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold border ${getStatusColor(selectedFlight.status)}`}>
                    {selectedFlight.status}
                  </span>
                </div>
              </div>
            </div>

            {/* Extra details (Gate, check-in, carousel) */}
            <div className="bg-navy-deep/60 border border-navy-steel/25 rounded p-4 mb-6 text-xs text-blue-aviation flex flex-col gap-2.5">
              <div className="flex justify-between items-center border-b border-navy-steel/15 pb-2">
                <span className="font-semibold text-warm-ivory">Terminal Infrastructure Details</span>
                <span className="text-[9px] bg-navy-steel/40 px-1.5 py-0.5 rounded uppercase">Terminal 1</span>
              </div>
              {selectedFlight.type === 'departure' ? (
                <>
                  <div className="flex justify-between">
                    <span>Check-In Desks:</span>
                    <span className="font-bold text-warm-ivory">{selectedFlight.checkInDesk || 'Desk 4-6'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Boarding Gate:</span>
                    <span className="font-bold text-gold-premium">{selectedFlight.gate || 'Gate 4'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Baggage drop window:</span>
                    <span className="font-semibold text-warm-ivory">05:00 - 06:15</span>
                  </div>
                </>
              ) : (
                <>
                  <div className="flex justify-between">
                    <span>Baggage Carousel:</span>
                    <span className="font-bold text-gold-premium">{selectedFlight.baggageCarousel || 'Carousel 1'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Customs Checkpoint:</span>
                    <span className="font-semibold text-warm-ivory">Exit Zone A</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Average bag release speed:</span>
                    <span className="font-semibold text-warm-ivory">14 minutes</span>
                  </div>
                </>
              )}
            </div>

            <div className="flex justify-end gap-2 text-xs">
              <button
                onClick={() => setSelectedFlight(null)}
                className="px-4 py-2 border border-navy-steel/40 hover:border-warm-ivory rounded text-warm-ivory font-bold uppercase tracking-wider transition-colors"
              >
                Close Details
              </button>
              <button
                onClick={() => {
                  alert(`Connecting to Live Flight SMS tracking notifications for ${selectedFlight.flightNumber}.`);
                  setSelectedFlight(null);
                }}
                className="px-4 py-2 bg-gold-premium text-navy-deep font-bold rounded uppercase tracking-wider hover:bg-warm-ivory transition-colors"
              >
                Track Live Feed
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
