'use client';

import React, { useState, useEffect } from 'react';
import { Search, Globe, ChevronDown, Menu, X, Plane, ShieldCheck, MapPin } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HeaderProps {
  activePage: string;
  setActivePage: (page: string) => void;
}

export default function Header({ activePage, setActivePage }: HeaderProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isLangOpen, setIsLangOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 20) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { id: 'flights', label: 'Flights' },
    { id: 'destinations', label: 'Destinations' },
    { id: 'parking', label: 'Parking' },
    { id: 'travel-info', label: 'Travel Info' },
    { id: 'airport', label: 'Airport Experience' },
    { id: 'business', label: 'Business & Cargo' },
    { id: 'about', label: 'About' },
  ];

  return (
    <header
      id="main-header"
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out font-interface',
        isScrolled
          ? 'bg-navy-deep/95 backdrop-blur-md py-4 border-b border-navy-steel/35 shadow-lg shadow-black/30'
          : 'bg-gradient-to-b from-navy-deep/70 to-transparent py-6'
      )}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        {/* Logo Area */}
        <button
          id="logo-button"
          onClick={() => setActivePage('home')}
          className="flex items-center gap-3 text-left group focus-visible:outline-none"
        >
          {/* Stylized aviation triskelion SVG */}
          <div className="w-10 h-10 flex items-center justify-center relative transition-transform duration-500 group-hover:rotate-12">
            <svg
              viewBox="0 0 100 100"
              className="w-full h-full fill-none stroke-gold-premium"
              strokeWidth="5"
              strokeLinecap="round"
            >
              {/* Three stylized wings/legs representing triskelion */}
              <path d="M50,50 C50,25 30,15 20,25 C10,35 15,50 35,50" />
              <path d="M50,50 C70,35 80,15 85,30 C90,45 75,55 60,55" />
              <path d="M50,50 C40,70 25,85 40,90 C55,95 65,75 60,60" />
              {/* Central turbine core */}
              <circle cx="50" cy="50" r="6" className="fill-gold-premium" />
            </svg>
          </div>
          <div>
            <div className="font-serif text-lg md:text-xl font-bold tracking-wide text-warm-ivory group-hover:text-gold-premium transition-colors">
              PURT AER VANNIN
            </div>
            <div className="text-[9px] md:text-[10px] tracking-widest text-blue-aviation font-bold uppercase whitespace-nowrap">
              Isle of Man International Airport
            </div>
          </div>
        </button>

        {/* Desktop Navigation */}
        <nav id="desktop-nav" className="hidden lg:flex items-center gap-1 xl:gap-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              id={`nav-link-${item.id}`}
              onClick={() => setActivePage(item.id)}
              className={cn(
                'px-3 py-2 text-sm tracking-wide font-medium transition-all duration-200 relative whitespace-nowrap',
                activePage === item.id
                  ? 'text-gold-premium'
                  : 'text-blue-aviation hover:text-warm-ivory'
              )}
            >
              {item.label}
              {activePage === item.id && (
                <span className="absolute bottom-0 left-3 right-3 h-0.5 bg-gold-premium animate-fade-in" />
              )}
            </button>
          ))}
        </nav>

        {/* Right Controls */}
        <div id="header-controls" className="hidden md:flex items-center gap-4">
          {/* Search trigger */}
          <div className="relative">
            {isSearchOpen ? (
              <div className="flex items-center bg-navy-dark/90 border border-navy-steel/50 rounded px-2 py-1 text-sm text-warm-ivory">
                <input
                  type="text"
                  placeholder="Flight, country..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      setActivePage('flights');
                      setIsSearchOpen(false);
                    }
                  }}
                  className="bg-transparent border-none outline-none text-xs w-32 focus:ring-0"
                  autoFocus
                />
                <button onClick={() => setIsSearchOpen(false)} className="text-muted-grey hover:text-warm-ivory">
                  <X size={14} />
                </button>
              </div>
            ) : (
              <button
                id="search-btn"
                onClick={() => setIsSearchOpen(true)}
                className="text-blue-aviation hover:text-gold-premium transition-colors p-2"
                aria-label="Search flights or services"
              >
                <Search size={18} />
              </button>
            )}
          </div>

          <span className="w-px h-5 bg-navy-steel/30" />

          {/* Language Selector */}
          <div className="relative">
            <button
              id="language-selector"
              onClick={() => setIsLangOpen(!isLangOpen)}
              className="flex items-center gap-1.5 text-xs text-blue-aviation hover:text-warm-ivory transition-colors uppercase tracking-widest font-bold py-2 px-1 focus:outline-none"
            >
              <Globe size={14} className="text-gold-premium" />
              <span>EN</span>
              <ChevronDown size={12} className={cn('transition-transform', isLangOpen && 'rotate-180')} />
            </button>

            {isLangOpen && (
              <div className="absolute right-0 mt-2 w-32 bg-navy-dark border border-navy-steel/40 shadow-xl rounded py-1 z-50">
                <button
                  onClick={() => setIsLangOpen(false)}
                  className="w-full text-left px-3 py-1.5 text-xs text-warm-ivory bg-navy-steel/20 hover:text-gold-premium"
                >
                  English (EN)
                </button>
                <button
                  onClick={() => {
                    setIsLangOpen(false);
                    alert("Manx language (Gaelg) localization is loaded as placeholder.");
                  }}
                  className="w-full text-left px-3 py-1.5 text-xs text-blue-aviation hover:text-gold-premium"
                >
                  Gaelg (GV)
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Mobile Menu Buttons */}
        <div className="flex lg:hidden items-center gap-4">
          <button
            id="mobile-search-btn"
            onClick={() => {
              setActivePage('flights');
            }}
            className="text-blue-aviation hover:text-warm-ivory p-1"
            aria-label="Search"
          >
            <Search size={20} />
          </button>
          <button
            id="mobile-menu-toggle"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="text-warm-ivory hover:text-gold-premium transition-colors p-1"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Navigation */}
      {isMobileMenuOpen && (
        <div className="lg:hidden fixed inset-x-0 top-[73px] bottom-0 bg-navy-deep/98 z-40 border-t border-navy-steel/20 animate-slide-down flex flex-col justify-between p-6">
          <nav className="flex flex-col gap-3">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  setActivePage(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className={cn(
                  'text-left py-3 px-4 rounded-md text-base tracking-wide font-medium transition-colors flex items-center justify-between',
                  activePage === item.id
                    ? 'bg-navy-dark border-l-2 border-gold-premium text-gold-premium'
                    : 'text-blue-aviation hover:bg-navy-dark/40 hover:text-warm-ivory'
                )}
              >
                <span>{item.label}</span>
                <span className="text-[10px] text-muted-grey uppercase tracking-widest font-serif">IOM</span>
              </button>
            ))}
          </nav>

          <div className="border-t border-navy-steel/20 pt-6 flex flex-col gap-4">
            <div className="flex justify-between items-center px-4">
              <span className="text-xs text-muted-grey uppercase tracking-wider">Language Selection</span>
              <div className="flex gap-2 text-xs">
                <span className="text-gold-premium font-bold">English (EN)</span>
                <span className="text-muted-grey">/</span>
                <button
                  onClick={() => alert("Gaelg language loaded.")}
                  className="text-blue-aviation hover:text-warm-ivory"
                >
                  Gaelg (GV)
                </button>
              </div>
            </div>
            <div className="bg-navy-dark/60 p-4 rounded border border-navy-steel/20 text-xs text-blue-aviation text-center">
              Purt Aer Vannin • Isle of Man International Gateway
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
