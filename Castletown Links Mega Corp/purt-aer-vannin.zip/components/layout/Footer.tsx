'use client';

import React, { useState, useEffect } from 'react';
import { CloudRain, Wind, Compass, Phone, Mail, MapPin, Eye, ExternalLink } from 'lucide-react';

interface FooterProps {
  setActivePage: (page: string) => void;
}

export default function Footer({ setActivePage }: FooterProps) {
  // Local weather simulation for IOM
  const [weather, setWeather] = useState({
    temp: 14,
    condition: 'Light Rain',
    windSpeed: '18 mph',
    windDir: 'WSW',
    visibility: '10 km (Good)',
    updated: 'Just now'
  });

  const footerLinks = {
    flights: {
      title: 'Flights',
      items: [
        { label: 'Live Departures', id: 'flights' },
        { label: 'Live Arrivals', id: 'flights' },
        { label: 'Destination Directory', id: 'destinations' },
        { label: 'Airlines & Operators', id: 'about' }
      ]
    },
    travel: {
      title: 'Travel Info',
      items: [
        { label: 'Check-in Guide', id: 'travel-info' },
        { label: 'Security & Liquid Limits', id: 'travel-info' },
        { label: 'Baggage Allowance', id: 'travel-info' },
        { label: 'Special Assistance', id: 'travel-info' },
        { label: 'Airport Parking', id: 'parking' }
      ]
    },
    airport: {
      title: 'Airport Experience',
      items: [
        { label: 'Executive Lounges', id: 'airport' },
        { label: 'Shops & Duty Free', id: 'airport' },
        { label: 'Food & Dining', id: 'airport' },
        { label: 'Terminal Map', id: 'airport' },
        { label: 'Airport Careers', id: 'about' }
      ]
    },
    business: {
      title: 'Business & Corp',
      items: [
        { label: 'Cargo & Logistics', id: 'business' },
        { label: 'Commercial Property', id: 'business' },
        { label: 'Aviation Partners', id: 'business' },
        { label: 'Sustainability Goals', id: 'about' },
        { label: 'Contact Business Unit', id: 'business' }
      ]
    }
  };

  return (
    <footer id="main-footer" className="bg-navy-dark border-t border-navy-steel/40 text-blue-aviation font-interface pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-12 mb-16">
        
        {/* Brand Column & Airport Status Card */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <svg
                viewBox="0 0 100 100"
                className="w-8 h-8 fill-none stroke-gold-premium"
                strokeWidth="6"
              >
                <path d="M50,50 C50,25 30,15 20,25 C10,35 15,50 35,50" />
                <path d="M50,50 C70,35 80,15 85,30 C90,45 75,55 60,55" />
                <path d="M50,50 C40,70 25,85 40,90 C55,95 65,75 60,60" />
              </svg>
              <span className="font-serif text-xl font-bold text-warm-ivory tracking-wide">
                PURT AER VANNIN
              </span>
            </div>
            <p className="text-xs text-muted-grey tracking-wider font-semibold uppercase">
              Isle of Man International Airport
            </p>
          </div>

          <p className="text-sm text-blue-aviation/80 leading-relaxed max-w-sm">
            Strategically bridging the Irish Sea, Purt Aer Vannin is the premier aviation gateway connecting the Isle of Man to London, Dublin, Edinburgh, and beyond.
          </p>

          {/* Quick Real-time Weather Widget for Aviation */}
          <div className="bg-navy-deep border border-navy-steel/30 rounded p-4 flex flex-col gap-3 max-w-sm">
            <div className="flex justify-between items-center border-b border-navy-steel/20 pb-2">
              <span className="text-[10px] uppercase font-bold tracking-widest text-gold-premium">
                IOM Meteorological Report (METAR)
              </span>
              <span className="text-[9px] text-muted-grey bg-navy-steel/30 px-1.5 py-0.5 rounded">
                Active Desk
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <CloudRain className="text-blue-aviation animate-bounce" size={24} />
                <div>
                  <div className="text-lg font-bold text-warm-ivory font-serif">{weather.temp}°C</div>
                  <div className="text-xs text-blue-aviation/70">{weather.condition}</div>
                </div>
              </div>
              <div className="text-right text-xs">
                <div className="flex items-center gap-1 justify-end font-semibold text-warm-ivory">
                  <Wind size={12} className="text-gold-premium" />
                  <span>{weather.windSpeed} ({weather.windDir})</span>
                </div>
                <div className="text-[10px] text-muted-grey mt-0.5 flex items-center gap-1 justify-end">
                  <Eye size={10} />
                  <span>Vis: {weather.visibility}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Dynamic Nav Columns */}
        {Object.values(footerLinks).map((col) => (
          <div key={col.title} className="flex flex-col gap-4">
            <h3 className="text-xs font-bold uppercase text-warm-ivory tracking-widest border-l-2 border-gold-premium pl-2">
              {col.title}
            </h3>
            <ul className="flex flex-col gap-2.5 text-sm">
              {col.items.map((item) => (
                <li key={item.label}>
                  <button
                    onClick={() => setActivePage(item.id)}
                    className="text-blue-aviation/85 hover:text-gold-premium hover:underline text-left transition-all duration-150 text-xs md:text-sm flex items-center gap-1 group"
                  >
                    <span>{item.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      {/* Address & Emergency bar */}
      <div className="max-w-7xl mx-auto px-6 border-t border-navy-steel/25 pt-10 pb-8 grid grid-cols-1 md:grid-cols-3 gap-6 text-xs text-muted-grey">
        <div className="flex items-start gap-2.5">
          <MapPin size={16} className="text-gold-premium shrink-0" />
          <div>
            <div className="font-bold text-warm-ivory mb-0.5">Physical Address</div>
            <address className="not-italic leading-relaxed">
              Purt Aer Vannin, Ronaldsway, Ballasalla,<br />
              Isle of Man, IM9 2AS
            </address>
          </div>
        </div>
        <div className="flex items-start gap-2.5">
          <Phone size={16} className="text-gold-premium shrink-0" />
          <div>
            <div className="font-bold text-warm-ivory mb-0.5">Contact Support</div>
            <p className="leading-relaxed">
              Main Airport Desk: +44 (0) 1624 821600<br />
              Airport Security Control: +44 (0) 1624 821611
            </p>
          </div>
        </div>
        <div className="flex items-start gap-2.5">
          <Mail size={16} className="text-gold-premium shrink-0" />
          <div>
            <div className="font-bold text-warm-ivory mb-0.5">Digital Desk</div>
            <p className="leading-relaxed">
              Enquiries: info@airport.im<br />
              Corporate Communications: pr@airport.im
            </p>
          </div>
        </div>
      </div>

      {/* Bottom Legal & Accreditations */}
      <div className="max-w-7xl mx-auto px-6 border-t border-navy-steel/20 pt-6 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-muted-grey/85">
        <div className="flex flex-wrap justify-center md:justify-start gap-x-6 gap-y-2">
          <button onClick={() => alert("Privacy policy page loaded.")} className="hover:text-gold-premium transition-colors">Privacy Policy</button>
          <button onClick={() => alert("Accessibility Statement: Fully compliant with WCAG 2.1 AA.")} className="hover:text-gold-premium transition-colors">Accessibility Statement</button>
          <button onClick={() => alert("Cookie settings panel loaded.")} className="hover:text-gold-premium transition-colors">Cookie Policy</button>
          <button onClick={() => alert("Terms of service loaded.")} className="hover:text-gold-premium transition-colors">Terms of Use</button>
        </div>
        <div className="text-center md:text-right text-[11px]">
          © 2026 Purt Aer Vannin — Isle of Man International Airport. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
