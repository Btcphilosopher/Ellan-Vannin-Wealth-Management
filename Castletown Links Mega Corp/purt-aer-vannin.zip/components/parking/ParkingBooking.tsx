'use client';

import React, { useState, useEffect } from 'react';
import { Calendar, Clock, ShieldCheck, Ticket, Car, CheckCircle2, RefreshCw, ChevronRight, Download, Printer } from 'lucide-react';
import { mockParkingProducts, ParkingProduct } from '@/data/airportData';

export default function ParkingBooking() {
  const [entryDate, setEntryDate] = useState('2026-09-12');
  const [entryTime, setEntryTime] = useState('08:00');
  const [exitDate, setExitDate] = useState('2026-09-15');
  const [exitTime, setExitTime] = useState('18:00');
  
  const [step, setStep] = useState<1 | 2 | 3>(1); // 1: Choose & Calculate, 2: Fill Details, 3: Ticket Summary
  const [selectedProduct, setSelectedProduct] = useState<ParkingProduct | null>(null);

  // Form details
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [carReg, setCarReg] = useState('');
  const [formError, setFormError] = useState('');

  // Generate confirmation details
  const [bookingRef, setBookingRef] = useState('');

  // Calculate booking duration in days directly during render
  const d1 = new Date(`${entryDate}T${entryTime}:00`);
  const d2 = new Date(`${exitDate}T${exitTime}:00`);
  const diffMs = d2.getTime() - d1.getTime();
  const bookingDays = diffMs > 0 ? Math.ceil(diffMs / (1000 * 60 * 60 * 24)) || 1 : 1;

  const handleSelectProduct = (product: ParkingProduct) => {
    setSelectedProduct(product);
    setStep(2);
  };

  const handleSubmitDetails = (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!fullName || !email || !carReg) {
      setFormError('Please complete all fields (Full Name, Email, and Vehicle Registration).');
      return;
    }

    if (!email.includes('@')) {
      setFormError('Please enter a valid email address.');
      return;
    }

    // Generate standard booking details
    const refPrefix = selectedProduct?.id === 'short-stay' ? 'IOMSS' : selectedProduct?.id === 'premium' ? 'IOMPR' : 'IOMLS';
    const randNum = Math.floor(100000 + Math.random() * 900000);
    setBookingRef(`${refPrefix}-${randNum}`);
    setStep(3);
  };

  const handleReset = () => {
    setStep(1);
    setSelectedProduct(null);
    setFullName('');
    setEmail('');
    setCarReg('');
    setFormError('');
    setBookingRef('');
  };

  const getAvailabilityColor = (status: ParkingProduct['availabilityIndicator']) => {
    switch (status) {
      case 'high':
        return 'text-green-400 bg-green-500/10 border-green-500/20';
      case 'medium':
        return 'text-blue-aviation bg-blue-aviation/10 border-blue-aviation/20';
      case 'limited':
        return 'text-gold-premium bg-gold-premium/10 border-gold-premium/30 animate-pulse';
      case 'full':
        return 'text-red-400 bg-red-500/10 border-red-500/20';
      default:
        return 'text-warm-ivory';
    }
  };

  return (
    <div id="parking-booking-system" className="font-interface">
      {/* Step Indicator Panel */}
      <div className="flex justify-center items-center gap-2 mb-8 md:mb-12">
        <span className={`text-xs uppercase font-bold tracking-widest px-3 py-1.5 rounded border transition-all ${
          step === 1 ? 'border-gold-premium text-gold-premium bg-navy-dark' : 'border-navy-steel/20 text-muted-grey'
        }`}>
          1. Rates & Options
        </span>
        <ChevronRight size={14} className="text-navy-steel/50" />
        <span className={`text-xs uppercase font-bold tracking-widest px-3 py-1.5 rounded border transition-all ${
          step === 2 ? 'border-gold-premium text-gold-premium bg-navy-dark' : 'border-navy-steel/20 text-muted-grey'
        }`}>
          2. Personal Details
        </span>
        <ChevronRight size={14} className="text-navy-steel/50" />
        <span className={`text-xs uppercase font-bold tracking-widest px-3 py-1.5 rounded border transition-all ${
          step === 3 ? 'border-green-500 text-green-400 bg-navy-dark' : 'border-navy-steel/20 text-muted-grey'
        }`}>
          3. Complete Ticket
        </span>
      </div>

      {/* STEP 1: Comparison & Date Select */}
      {step === 1 && (
        <div className="flex flex-col gap-8">
          {/* Dates configuration panel */}
          <div className="bg-navy-dark border border-navy-steel/40 rounded-lg p-5 lg:p-6 grid grid-cols-1 md:grid-cols-5 gap-4 items-end shadow-lg">
            <div className="flex flex-col gap-1 md:col-span-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-muted-grey flex items-center gap-1.5">
                <Calendar size={11} className="text-gold-premium" />
                <span>Entry (Date & Time)</span>
              </label>
              <div className="grid grid-cols-2 gap-2 mt-1">
                <input
                  type="date"
                  value={entryDate}
                  min="2026-09-12"
                  onChange={(e) => setEntryDate(e.target.value)}
                  className="bg-navy-deep border border-navy-steel/30 rounded p-2 text-xs font-semibold text-warm-ivory outline-none focus:border-gold-premium"
                />
                <input
                  type="time"
                  value={entryTime}
                  onChange={(e) => setEntryTime(e.target.value)}
                  className="bg-navy-deep border border-navy-steel/30 rounded p-2 text-xs font-semibold text-warm-ivory outline-none focus:border-gold-premium"
                />
              </div>
            </div>

            <div className="flex flex-col gap-1 md:col-span-2">
              <label className="text-[10px] uppercase tracking-widest font-bold text-muted-grey flex items-center gap-1.5">
                <Calendar size={11} className="text-gold-premium animate-pulse" />
                <span>Exit (Date & Time)</span>
              </label>
              <div className="grid grid-cols-2 gap-2 mt-1">
                <input
                  type="date"
                  value={exitDate}
                  min={entryDate}
                  onChange={(e) => setExitDate(e.target.value)}
                  className="bg-navy-deep border border-navy-steel/30 rounded p-2 text-xs font-semibold text-warm-ivory outline-none focus:border-gold-premium"
                />
                <input
                  type="time"
                  value={exitTime}
                  onChange={(e) => setExitTime(e.target.value)}
                  className="bg-navy-deep border border-navy-steel/30 rounded p-2 text-xs font-semibold text-warm-ivory outline-none focus:border-gold-premium"
                />
              </div>
            </div>

            <div className="bg-navy-deep border border-navy-steel/40 rounded p-3 text-center md:col-span-1">
              <div className="text-[9px] font-bold text-muted-grey uppercase tracking-widest mb-0.5">Calculated Days</div>
              <div className="text-lg font-bold text-gold-premium font-mono">{bookingDays} {bookingDays === 1 ? 'Day' : 'Days'}</div>
            </div>
          </div>

          {/* Product cards grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {mockParkingProducts.map((p) => {
              const totalCost = p.pricePerDay * bookingDays;
              return (
                <div
                  key={p.id}
                  className="bg-navy-dark border border-navy-steel/30 rounded-lg p-6 lg:p-8 flex flex-col justify-between shadow-xl hover:border-gold-premium/40 transition-all group"
                >
                  <div>
                    {/* Top Info */}
                    <div className="flex justify-between items-start mb-4 border-b border-navy-steel/15 pb-4">
                      <div>
                        <h3 className="font-serif text-lg font-bold text-warm-ivory group-hover:text-gold-premium transition-colors">
                          {p.name}
                        </h3>
                        <span className="text-[10px] text-blue-aviation font-semibold flex items-center gap-1 mt-1">
                          <Car size={11} className="text-gold-premium" />
                          {p.walkingTime}
                        </span>
                      </div>
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase tracking-wider ${getAvailabilityColor(p.availabilityIndicator)}`}>
                        {p.availabilityIndicator === 'high' ? 'Spaces Available' : p.availabilityIndicator}
                      </span>
                    </div>

                    <p className="text-xs text-blue-aviation/85 leading-relaxed mb-6 h-12">
                      {p.description}
                    </p>

                    {/* Bullet list of specs */}
                    <ul className="flex flex-col gap-2 mb-8 text-[11px] text-muted-grey border-t border-navy-steel/10 pt-4">
                      {p.features.map((feat, idx) => (
                        <li key={idx} className="flex items-start gap-1.5">
                          <span className="text-gold-premium font-bold shrink-0">•</span>
                          <span>{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Price & Action Button */}
                  <div className="border-t border-navy-steel/20 pt-6">
                    <div className="flex justify-between items-end mb-4">
                      <div>
                        <div className="text-[9px] uppercase font-bold text-muted-grey">Daily Rate</div>
                        <div className="text-sm font-bold text-warm-ivory">£{p.pricePerDay} <span className="text-[10px] text-muted-grey">/ day</span></div>
                      </div>
                      <div className="text-right">
                        <div className="text-[9px] uppercase font-bold text-gold-premium">Est. Total for {bookingDays} Days</div>
                        <div className="text-xl font-bold text-gold-premium font-serif">£{totalCost}</div>
                      </div>
                    </div>

                    <button
                      onClick={() => handleSelectProduct(p)}
                      className="w-full py-3 bg-navy-deep border border-gold-premium/50 hover:bg-gold-premium hover:text-navy-deep rounded text-xs font-bold uppercase tracking-widest text-gold-premium transition-all duration-200"
                    >
                      Book Parking →
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* STEP 2: Client details form */}
      {step === 2 && selectedProduct && (
        <div className="max-w-xl mx-auto bg-navy-dark border border-navy-steel/45 rounded-lg p-6 lg:p-8 shadow-xl">
          <div className="flex justify-between items-center border-b border-navy-steel/25 pb-4 mb-6">
            <div>
              <h3 className="font-serif text-lg font-bold text-warm-ivory">Confirm Parking Choice</h3>
              <p className="text-xs text-blue-aviation/70 mt-1">Package: <span className="font-bold text-gold-premium">{selectedProduct.name}</span></p>
            </div>
            <button
              onClick={() => setStep(1)}
              className="text-xs font-bold text-blue-aviation hover:text-gold-premium underline"
            >
              Change Option
            </button>
          </div>

          <form onSubmit={handleSubmitDetails} className="flex flex-col gap-4">
            <div className="bg-navy-deep p-4 rounded border border-navy-steel/20 flex justify-between items-center text-xs mb-2">
              <div>
                <div className="text-muted-grey font-semibold">Total Stay Duration:</div>
                <div className="font-bold text-warm-ivory mt-0.5">{entryDate} to {exitDate}</div>
              </div>
              <div className="text-right">
                <div className="text-muted-grey font-semibold">Total Price:</div>
                <div className="font-bold text-gold-premium text-base font-serif">£{selectedProduct.pricePerDay * bookingDays}</div>
              </div>
            </div>

            {/* Form Inputs */}
            <div className="flex flex-col gap-1.5 text-xs">
              <label className="font-bold text-muted-grey uppercase tracking-wider">Full Name</label>
              <input
                type="text"
                placeholder="Lord / Lady Passenger"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="bg-navy-deep border border-navy-steel/45 rounded p-3 text-xs font-semibold text-warm-ivory outline-none focus:border-gold-premium"
              />
            </div>

            <div className="flex flex-col gap-1.5 text-xs">
              <label className="font-bold text-muted-grey uppercase tracking-wider">Email Address (For Confirmation)</label>
              <input
                type="email"
                placeholder="passenger@manx.net"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-navy-deep border border-navy-steel/45 rounded p-3 text-xs font-semibold text-warm-ivory outline-none focus:border-gold-premium"
              />
            </div>

            <div className="flex flex-col gap-1.5 text-xs">
              <label className="font-bold text-muted-grey uppercase tracking-wider flex justify-between">
                <span>Vehicle Registration Plate</span>
                <span className="text-gold-premium text-[10px] lowercase italic">Required for automatic gate entry</span>
              </label>
              <input
                type="text"
                placeholder="MANX 415"
                value={carReg}
                onChange={(e) => setCarReg(e.target.value.toUpperCase())}
                className="bg-navy-deep border border-navy-steel/45 rounded p-3 text-xs font-semibold text-warm-ivory outline-none focus:border-gold-premium font-mono uppercase tracking-wider text-center text-sm"
              />
            </div>

            {formError && (
              <div className="p-3 bg-red-950/30 border border-red-500/20 rounded text-red-200 text-xs mt-2">
                {formError}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-3.5 bg-gold-premium text-navy-deep font-bold rounded text-xs uppercase tracking-widest hover:bg-warm-ivory transition-colors mt-4"
            >
              Generate Terminal Ticket →
            </button>
          </form>
        </div>
      )}

      {/* STEP 3: Print Voucher */}
      {step === 3 && selectedProduct && (
        <div className="max-w-2xl mx-auto bg-navy-dark border border-green-500/30 rounded-lg shadow-2xl p-6 lg:p-8 animate-slide-up">
          
          <div className="text-center mb-6">
            <span className="inline-block p-2 rounded-full bg-green-500/10 text-green-400 mb-2">
              <CheckCircle2 size={32} />
            </span>
            <h3 className="font-serif text-2xl font-bold text-warm-ivory">Booking Successfully Confirmed</h3>
            <p className="text-xs text-blue-aviation/80 mt-1">
              Your registration plate is active in our Ronaldsway database. Simply drive up to the barrier.
            </p>
          </div>

          {/* Stylized Ticket Pass */}
          <div className="bg-navy-deep border border-navy-steel/30 rounded-lg p-5 relative overflow-hidden mb-6">
            <div className="absolute right-0 top-0 w-24 h-24 bg-gold-premium/5 rounded-full blur-xl" />
            
            {/* Ticket Header */}
            <div className="flex justify-between items-start border-b border-navy-steel/20 pb-4 mb-4">
              <div>
                <span className="text-[10px] text-gold-premium font-mono uppercase tracking-widest font-bold">
                  Ronaldsway Official Parking Ticket
                </span>
                <div className="text-sm font-bold text-warm-ivory mt-0.5">{selectedProduct.name}</div>
              </div>
              <div className="text-right">
                <span className="text-[10px] text-muted-grey font-bold uppercase tracking-wider block">Reference</span>
                <span className="font-mono font-bold text-warm-ivory text-xs bg-navy-dark px-2 py-0.5 rounded">
                  {bookingRef}
                </span>
              </div>
            </div>

            {/* Ticket Details */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-y-4 gap-x-6 text-xs mb-5">
              <div>
                <span className="text-muted-grey block">Vehicle Reg Plate</span>
                <span className="font-mono font-bold text-warm-ivory text-sm tracking-widest">{carReg}</span>
              </div>
              <div>
                <span className="text-muted-grey block">Passenger Name</span>
                <span className="font-bold text-warm-ivory">{fullName}</span>
              </div>
              <div>
                <span className="text-muted-grey block">Registered Email</span>
                <span className="font-bold text-blue-aviation truncate block max-w-[150px]">{email}</span>
              </div>
              <div>
                <span className="text-muted-grey block">Entry Date & Time</span>
                <span className="font-bold text-warm-ivory">{entryDate} @ {entryTime}</span>
              </div>
              <div>
                <span className="text-muted-grey block">Exit Date & Time</span>
                <span className="font-bold text-warm-ivory">{exitDate} @ {exitTime}</span>
              </div>
              <div>
                <span className="text-muted-grey block">Paid Receipt Amount</span>
                <span className="font-bold text-gold-premium font-serif text-sm">£{selectedProduct.pricePerDay * bookingDays}</span>
              </div>
            </div>

            {/* Barcode representation */}
            <div className="border-t border-navy-steel/20 pt-4 flex flex-col items-center justify-center gap-2">
              {/* Fake Barcode Lines */}
              <div className="h-10 bg-warm-ivory w-full max-w-[320px] rounded flex items-stretch gap-1 px-3 py-1.5 opacity-90">
                <div className="w-1 bg-black" /><div className="w-2 bg-black" /><div className="w-0.5 bg-black" /><div className="w-1 bg-black" />
                <div className="w-3 bg-black" /><div className="w-1 bg-black" /><div className="w-0.5 bg-black" /><div className="w-2 bg-black" />
                <div className="w-1 bg-black" /><div className="w-1.5 bg-black" /><div className="w-3 bg-black" /><div className="w-0.5 bg-black" />
                <div className="w-1 bg-black" /><div className="w-2 bg-black" /><div className="w-0.5 bg-black" /><div className="w-1 bg-black" />
                <div className="w-3 bg-black" /><div className="w-1 bg-black" /><div className="w-0.5 bg-black" /><div className="w-2 bg-black" />
                <div className="w-1 bg-black" /><div className="w-1.5 bg-black" /><div className="w-3 bg-black" /><div className="w-0.5 bg-black" />
              </div>
              <span className="font-mono text-[9px] tracking-widest text-muted-grey">*{bookingRef}*</span>
            </div>
          </div>

          {/* Print/Download and Reset Actions */}
          <div className="flex flex-wrap items-center justify-between gap-4 border-t border-navy-steel/20 pt-6">
            <span className="text-[10px] text-muted-grey/85 flex items-center gap-1">
              <ShieldCheck size={12} className="text-green-400" />
              <span>Complimentary Fast-Track security voucher is activated for Lord {fullName.split(' ')[0]}</span>
            </span>
            <div className="flex gap-2">
              <button
                onClick={() => alert('Voucher PDF print layout loaded.')}
                className="px-4 py-2 border border-navy-steel/50 text-xs font-bold uppercase tracking-wider text-warm-ivory hover:border-warm-ivory rounded flex items-center gap-1.5"
              >
                <Printer size={13} />
                <span>Print Ticket</span>
              </button>
              <button
                onClick={handleReset}
                className="px-4 py-2 bg-gold-premium text-navy-deep text-xs font-bold uppercase tracking-wider hover:bg-warm-ivory rounded transition-colors"
              >
                Book Another Space
              </button>
            </div>
          </div>

        </div>
      )}
    </div>
  );
}
