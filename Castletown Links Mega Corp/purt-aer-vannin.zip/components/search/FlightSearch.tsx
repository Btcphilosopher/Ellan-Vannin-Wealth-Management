'use client';

import React, { useState } from 'react';
import { Plane, Calendar, Users, ArrowRight, AlertCircle, Sparkles, Clock, CheckCircle } from 'lucide-react';
import { mockDestinations, mockFlights, Flight } from '@/data/airportData';

interface FlightSearchProps {
  onSearchActive: (results: { flights: Flight[]; passengers: number; date: string; to: string } | null) => void;
}

export default function FlightSearch({ onSearchActive }: FlightSearchProps) {
  const [from, setFrom] = useState('Isle of Man (IOM)');
  const [to, setTo] = useState('');
  const [departDate, setDepartDate] = useState('2026-09-11');
  const [passengers, setPassengers] = useState(1);
  const [error, setError] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [searchResults, setSearchResults] = useState<Flight[]>([]);

  const [isDestDropdownOpen, setIsDestDropdownOpen] = useState(false);
  const [isPassDropdownOpen, setIsPassDropdownOpen] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!to) {
      setError('Please select a destination airport.');
      return;
    }

    // Filter matching departures from mock flights
    const matches = mockFlights.filter(
      (f) =>
        f.type === 'departure' &&
        (f.airportName.toLowerCase().includes(to.toLowerCase()) ||
          f.airportCode.toLowerCase().includes(to.toLowerCase()))
    );

    setSearchResults(matches);
    setHasSearched(true);

    onSearchActive({
      flights: matches,
      passengers,
      date: departDate,
      to: to
    });
  };

  const handleReset = () => {
    setTo('');
    setPassengers(1);
    setSearchResults([]);
    setHasSearched(false);
    onSearchActive(null);
  };

  return (
    <div id="flight-search-container" className="relative w-full max-w-6xl mx-auto z-20 px-4 md:px-0 font-interface">
      <form
        id="flight-search-form"
        onSubmit={handleSearch}
        className="bg-navy-dark border border-navy-steel/50 rounded-lg shadow-2xl p-6 lg:p-8 flex flex-col gap-6"
      >
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 border-b border-navy-steel/20 pb-4">
          <div className="flex items-center gap-2">
            <Sparkles className="text-gold-premium" size={16} />
            <span className="text-xs uppercase font-bold tracking-widest text-warm-ivory">
              Premium Gateway Booking System
            </span>
          </div>
          <div className="flex gap-4 text-xs text-blue-aviation">
            <span className="font-semibold text-gold-premium">One-Way / Direct Routes</span>
            <span>•</span>
            <span>Guaranteed Lowest Local Parking Rates</span>
          </div>
        </div>

        {/* Form Fields Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* From Field (Read Only or swap-capable) */}
          <div className="relative bg-navy-deep border border-navy-steel/30 rounded p-3 flex flex-col hover:border-gold-premium/45 transition-colors">
            <label className="text-[10px] uppercase tracking-widest font-bold text-muted-grey flex items-center gap-1.5 mb-1">
              <Plane size={11} className="text-gold-premium rotate-45" />
              <span>From (Origin)</span>
            </label>
            <input
              type="text"
              value={from}
              readOnly
              className="bg-transparent text-warm-ivory text-sm font-semibold outline-none cursor-not-allowed"
            />
            <span className="text-[10px] text-blue-aviation/60 mt-0.5">Purt Aer Vannin Gateways</span>
          </div>

          {/* To Field with Dynamic Dropdown */}
          <div className="relative bg-navy-deep border border-navy-steel/30 rounded p-3 flex flex-col hover:border-gold-premium/45 transition-colors">
            <label className="text-[10px] uppercase tracking-widest font-bold text-muted-grey flex items-center gap-1.5 mb-1">
              <Plane size={11} className="text-gold-premium" />
              <span>To (Destination)</span>
            </label>
            <div className="relative">
              <button
                type="button"
                onClick={() => setIsDestDropdownOpen(!isDestDropdownOpen)}
                className="w-full text-left bg-transparent text-warm-ivory text-sm font-semibold outline-none flex justify-between items-center"
              >
                <span className={to ? 'text-warm-ivory' : 'text-blue-aviation/50'}>
                  {to || 'Select Destination'}
                </span>
                <span className="text-[10px] text-gold-premium uppercase tracking-widest">Select</span>
              </button>

              {isDestDropdownOpen && (
                <div className="absolute left-0 right-0 top-10 bg-navy-dark border border-navy-steel/40 shadow-2xl rounded-md py-1.5 z-30 max-h-56 overflow-y-auto">
                  {mockDestinations.map((dest) => (
                    <button
                      key={dest.id}
                      type="button"
                      onClick={() => {
                        setTo(`${dest.name} (${dest.code.split(' ')[0]})`);
                        setIsDestDropdownOpen(false);
                        setError('');
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-navy-steel/20 text-xs text-warm-ivory flex justify-between items-center border-b border-navy-steel/10 last:border-0"
                    >
                      <div>
                        <div className="font-bold">{dest.name}</div>
                        <div className="text-[10px] text-blue-aviation/70">{dest.country}</div>
                      </div>
                      <span className="bg-navy-deep px-1.5 py-0.5 rounded text-[10px] font-mono text-gold-premium font-semibold">
                        {dest.code.split(' / ')[0]}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Date Picker Field */}
          <div className="relative bg-navy-deep border border-navy-steel/30 rounded p-3 flex flex-col hover:border-gold-premium/45 transition-colors">
            <label className="text-[10px] uppercase tracking-widest font-bold text-muted-grey flex items-center gap-1.5 mb-1">
              <Calendar size={11} className="text-gold-premium" />
              <span>Depart Date</span>
            </label>
            <input
              type="date"
              value={departDate}
              onChange={(e) => setDepartDate(e.target.value)}
              min="2026-09-11"
              className="bg-transparent text-warm-ivory text-sm font-semibold outline-none focus:text-gold-premium"
            />
          </div>

          {/* Passenger Count Selector */}
          <div className="relative bg-navy-deep border border-navy-steel/30 rounded p-3 flex flex-col hover:border-gold-premium/45 transition-colors">
            <label className="text-[10px] uppercase tracking-widest font-bold text-muted-grey flex items-center gap-1.5 mb-1">
              <Users size={11} className="text-gold-premium" />
              <span>Passengers</span>
            </label>
            <div className="flex items-center justify-between">
              <span className="text-warm-ivory text-sm font-semibold">{passengers} {passengers === 1 ? 'Adult' : 'Adults'}</span>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() => setPassengers(Math.max(1, passengers - 1))}
                  className="w-6 h-6 rounded bg-navy-steel/35 flex items-center justify-center text-xs text-warm-ivory hover:bg-gold-premium hover:text-navy-deep transition-all"
                >
                  -
                </button>
                <button
                  type="button"
                  onClick={() => setPassengers(Math.min(9, passengers + 1))}
                  className="w-6 h-6 rounded bg-navy-steel/35 flex items-center justify-center text-xs text-warm-ivory hover:bg-gold-premium hover:text-navy-deep transition-all"
                >
                  +
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Error / Feedback Area */}
        {error && (
          <div className="flex items-center gap-2 bg-red-950/40 border border-red-500/30 text-red-200 p-3 rounded text-xs">
            <AlertCircle size={14} className="text-red-400 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 mt-2">
          <p className="text-xs text-blue-aviation/75 leading-relaxed max-w-md">
            Connecting schedules are direct and subject to airport METAR clearance. Please check in online at least 2 hours prior to departure.
          </p>
          <div className="flex gap-2">
            {hasSearched && (
              <button
                type="button"
                onClick={handleReset}
                className="px-5 py-3 border border-navy-steel/50 hover:border-warm-ivory rounded text-xs font-bold text-warm-ivory uppercase tracking-wider transition-colors"
              >
                Clear Results
              </button>
            )}
            <button
              type="submit"
              className="px-6 py-3 bg-gold-premium hover:bg-gold-premium/85 text-navy-deep font-bold rounded text-xs uppercase tracking-widest transition-all duration-200 flex items-center gap-2"
            >
              <span>Search Flights</span>
              <ArrowRight size={14} />
            </button>
          </div>
        </div>
      </form>

      {/* Results View Panel */}
      {hasSearched && (
        <div className="mt-6 bg-navy-dark border border-navy-steel/40 rounded-lg p-6 shadow-2xl animate-slide-up">
          <h3 className="text-xs font-bold uppercase tracking-widest text-gold-premium mb-4 flex items-center gap-1.5">
            <CheckCircle size={14} />
            <span>Available Departures for {departDate} to {to}</span>
          </h3>

          {searchResults.length > 0 ? (
            <div className="flex flex-col gap-3">
              {searchResults.map((f) => {
                // Generate a consistent mock price based on flight id
                const price = f.id === 'dep-4' ? 49 : f.id === 'dep-5' ? 119 : f.id === 'dep-6' ? 59 : 79;
                return (
                  <div
                    key={f.id}
                    className="bg-navy-deep border border-navy-steel/20 rounded p-4 flex flex-col md:flex-row justify-between items-center gap-4 hover:border-navy-steel/60 transition-all"
                  >
                    <div className="flex items-center gap-4 w-full md:w-auto">
                      <div className="bg-navy-dark p-2.5 rounded border border-navy-steel/30 text-center font-bold text-gold-premium w-16 text-xs">
                        {f.airlineCode}
                      </div>
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-warm-ivory">{f.flightNumber}</span>
                          <span className="text-[10px] bg-navy-steel/30 px-1.5 py-0.5 rounded text-blue-aviation">
                            {f.airline}
                          </span>
                        </div>
                        <div className="text-xs text-blue-aviation/70 mt-1 flex items-center gap-3">
                          <span className="flex items-center gap-1">
                            <Clock size={11} className="text-gold-premium" />
                            Scheduled: {f.scheduledTime}
                          </span>
                          <span>•</span>
                          <span>Terminal {f.terminal}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between md:justify-end gap-8 w-full md:w-auto border-t md:border-t-0 border-navy-steel/15 pt-3 md:pt-0">
                      <div className="text-right">
                        <div className="text-[9px] uppercase font-bold text-muted-grey">Total Cost ({passengers} Pax)</div>
                        <div className="text-base font-bold text-gold-premium font-serif">
                          £{price * passengers}
                        </div>
                        <div className="text-[10px] text-blue-aviation/60">Taxes & Fees Included</div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          alert(`Thank you! Proceeding to external mock booking for ${f.flightNumber} to ${f.airportName}.\nPassengers: ${passengers}\nDate: ${departDate}`);
                        }}
                        className="px-4 py-2 bg-gold-premium text-navy-deep font-bold rounded text-xs uppercase tracking-wider hover:bg-warm-ivory transition-colors whitespace-nowrap"
                      >
                        Book Now →
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8 text-blue-aviation/80">
              <Plane size={24} className="mx-auto text-navy-steel mb-2 animate-pulse" />
              <p className="text-sm">No direct flights match this search criteria for the selected date.</p>
              <p className="text-xs text-muted-grey mt-1">Please try searching for Belfast, Manchester, or London.</p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
