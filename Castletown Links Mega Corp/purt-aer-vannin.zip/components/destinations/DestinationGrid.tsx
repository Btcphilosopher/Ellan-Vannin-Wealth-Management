'use client';

import React, { useState } from 'react';
import { Search, MapPin, Compass, Clock, ShieldCheck, Tag, X, Plane } from 'lucide-react';
import { mockDestinations, Destination } from '@/data/airportData';

export default function DestinationGrid() {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'ALL' | 'UK' | 'IRE' | 'EUR'>('ALL');
  const [selectedDest, setSelectedDest] = useState<Destination | null>(null);

  const filterCategories = [
    { id: 'ALL', label: 'All Destinations' },
    { id: 'UK', label: 'United Kingdom' },
    { id: 'IRE', label: 'Ireland' },
    { id: 'EUR', label: 'Europe Hubs' }
  ];

  const filteredDestinations = mockDestinations.filter((dest) => {
    // Category mapping
    const matchesCategory =
      activeFilter === 'ALL' ||
      (activeFilter === 'UK' && dest.country === 'United Kingdom') ||
      (activeFilter === 'IRE' && dest.country === 'Ireland') ||
      (activeFilter === 'EUR' && dest.country === 'Europe Hubs');

    const matchesSearch =
      dest.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dest.code.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dest.country.toLowerCase().includes(searchQuery.toLowerCase()) ||
      dest.airlines.some((air) => air.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCategory && matchesSearch;
  });

  return (
    <div id="destination-directory" className="font-interface">
      {/* Search and Filters Bar */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-center mb-8">
        {/* Category Toggles */}
        <div className="flex flex-wrap gap-2 bg-navy-dark p-1.5 rounded-lg border border-navy-steel/20 w-full md:w-auto">
          {filterCategories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveFilter(cat.id as any)}
              className={`px-4 py-2 rounded text-xs font-bold uppercase tracking-wider transition-all duration-150 ${
                activeFilter === cat.id
                  ? 'bg-gold-premium text-navy-deep'
                  : 'text-blue-aviation hover:text-warm-ivory'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>

        {/* Search Query */}
        <div className="relative flex items-center bg-navy-dark border border-navy-steel/40 rounded px-3.5 py-2 w-full md:w-80">
          <Search size={15} className="text-gold-premium mr-2.5 shrink-0" />
          <input
            type="text"
            placeholder="Search city, code or operator..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="bg-transparent border-none outline-none text-xs w-full text-warm-ivory placeholder-muted-grey"
          />
        </div>
      </div>

      {/* Grid of Route Cards */}
      {filteredDestinations.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredDestinations.map((dest) => (
            <div
              key={dest.id}
              onClick={() => setSelectedDest(dest)}
              className="group relative h-96 rounded-lg overflow-hidden border border-navy-steel/20 shadow-lg cursor-pointer bg-navy-dark"
            >
              {/* Dynamic Image with Scale on Hover */}
              <div className="absolute inset-0 z-0 bg-cover bg-center transition-transform duration-700 ease-out group-hover:scale-105"
                style={{ backgroundImage: `url(${dest.image})` }}
              />

              {/* Gradient Overlay for Editorial Contrast */}
              <div className="absolute inset-0 z-10 bg-gradient-to-t from-navy-deep via-navy-deep/40 to-navy-deep/10 transition-opacity duration-300 group-hover:opacity-90" />

              {/* Content Panel */}
              <div className="absolute inset-0 z-20 p-5 flex flex-col justify-end">
                <span className="text-[10px] text-gold-premium font-mono uppercase tracking-widest font-bold mb-1">
                  {dest.country}
                </span>
                <h3 className="font-serif text-xl font-bold text-warm-ivory group-hover:text-gold-premium transition-colors mb-1">
                  {dest.name}
                </h3>
                <div className="text-[11px] font-mono font-bold text-blue-aviation bg-navy-deep/80 px-2 py-0.5 rounded self-start border border-navy-steel/40 mb-3 uppercase">
                  IOM → {dest.code}
                </div>
                
                {/* Micro details rising slightly on hover */}
                <p className="text-xs text-muted-grey/90 line-clamp-2 max-h-0 opacity-0 group-hover:max-h-12 group-hover:opacity-100 transition-all duration-300 leading-relaxed mb-3">
                  {dest.description}
                </p>

                <div className="flex justify-between items-center text-xs text-blue-aviation border-t border-navy-steel/25 pt-3">
                  <span className="flex items-center gap-1 font-semibold text-[11px]">
                    <Clock size={11} className="text-gold-premium" />
                    {dest.duration}
                  </span>
                  <span className="text-gold-premium font-bold text-[11px] group-hover:underline flex items-center gap-1 uppercase tracking-wider">
                    <span>Route Details</span>
                    <span>→</span>
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-20 bg-navy-dark border border-navy-steel/20 rounded-lg text-blue-aviation/85">
          <Compass size={32} className="mx-auto text-navy-steel mb-3 animate-pulse" />
          <p className="text-sm">No scheduled flight destinations match your active search filter.</p>
          <p className="text-xs text-muted-grey mt-1">Please try searching with standard filters or queries.</p>
        </div>
      )}

      {/* Destination Detail Overlay Modal */}
      {selectedDest && (
        <div className="fixed inset-0 bg-navy-deep/85 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-navy-dark border border-gold-premium/30 rounded-lg max-w-xl w-full shadow-2xl relative overflow-hidden animate-scale-up">
            
            {/* Splash Image Header */}
            <div className="h-48 bg-cover bg-center relative" style={{ backgroundImage: `url(${selectedDest.image})` }}>
              <div className="absolute inset-0 bg-gradient-to-t from-navy-dark via-navy-dark/45 to-transparent" />
              <button
                onClick={() => setSelectedDest(null)}
                className="absolute right-4 top-4 text-warm-ivory hover:text-gold-premium p-1.5 rounded-full bg-navy-deep/60 backdrop-blur-sm border border-navy-steel/30"
                aria-label="Close details"
              >
                <X size={16} />
              </button>
              <div className="absolute bottom-4 left-6">
                <span className="text-[10px] text-gold-premium font-mono uppercase tracking-widest font-bold bg-navy-deep/80 px-2 py-0.5 rounded border border-navy-steel/30">
                  {selectedDest.country}
                </span>
                <h3 className="font-serif text-2xl md:text-3xl font-bold text-warm-ivory mt-1">
                  {selectedDest.name}
                </h3>
              </div>
            </div>

            {/* Modal Content */}
            <div className="p-6 md:p-8">
              <p className="text-sm text-blue-aviation/90 leading-relaxed mb-6 font-medium">
                {selectedDest.description}
              </p>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-navy-deep p-3.5 rounded border border-navy-steel/20 text-xs">
                  <div className="font-bold text-muted-grey uppercase tracking-wider mb-1">Direct Flight Code</div>
                  <div className="font-mono font-bold text-gold-premium text-sm">{selectedDest.code}</div>
                </div>
                <div className="bg-navy-deep p-3.5 rounded border border-navy-steel/20 text-xs">
                  <div className="font-bold text-muted-grey uppercase tracking-wider mb-1">Average Flight Time</div>
                  <div className="font-bold text-warm-ivory text-sm flex items-center gap-1.5">
                    <Clock size={13} className="text-gold-premium" />
                    <span>{selectedDest.duration}</span>
                  </div>
                </div>
                <div className="bg-navy-deep p-3.5 rounded border border-navy-steel/20 text-xs">
                  <div className="font-bold text-muted-grey uppercase tracking-wider mb-1">Flight Frequency</div>
                  <div className="font-bold text-warm-ivory text-sm">{selectedDest.frequency}</div>
                </div>
                <div className="bg-navy-deep p-3.5 rounded border border-navy-steel/20 text-xs">
                  <div className="font-bold text-muted-grey uppercase tracking-wider mb-1">Active Partners</div>
                  <div className="font-bold text-warm-ivory text-sm flex gap-2">
                    {selectedDest.airlines.map((a, i) => (
                      <span key={i} className="bg-navy-steel/30 px-1.5 py-0.5 rounded text-[10px]">
                        {a}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Travel insights */}
              <div className="bg-navy-deep/60 border border-navy-steel/25 rounded p-4 mb-6 text-xs text-blue-aviation leading-relaxed">
                <div className="font-bold text-warm-ivory mb-1 uppercase tracking-wider flex items-center gap-1.5">
                  <Tag size={12} className="text-gold-premium" />
                  <span>Destination Insight</span>
                </div>
                <p>{selectedDest.popularFor}</p>
                <p className="text-muted-grey text-[11px] mt-2 italic">
                  Note: Schedule departures are operational daily. Real-time slot bookings available at Check-in desks.
                </p>
              </div>

              <div className="flex justify-between items-center text-xs">
                <span className="text-blue-aviation/75 flex items-center gap-1 font-semibold">
                  <ShieldCheck size={14} className="text-gold-premium" />
                  <span>IOM Aviation Security Cleared</span>
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => setSelectedDest(null)}
                    className="px-4 py-2 border border-navy-steel/45 hover:border-warm-ivory rounded text-warm-ivory font-bold uppercase tracking-wider transition-colors"
                  >
                    Back
                  </button>
                  <button
                    onClick={() => {
                      alert(`Loading booking portal for flights to ${selectedDest.name}.`);
                      setSelectedDest(null);
                    }}
                    className="px-4 py-2 bg-gold-premium text-navy-deep font-bold rounded uppercase tracking-wider hover:bg-warm-ivory transition-colors"
                  >
                    Search Direct Flights
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
