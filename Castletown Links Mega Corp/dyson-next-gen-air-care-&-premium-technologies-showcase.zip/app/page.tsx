'use client';

import React, { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import { motion, AnimatePresence } from 'motion/react';
import {
  Search,
  User,
  ShoppingBag,
  ArrowRight,
  ChevronDown,
  X,
  Sparkles,
  Plus,
  Minus,
  Info,
  Sliders,
  Volume2,
  Wind,
  Check,
  RotateCcw,
  Shield,
  Trash2,
  Heart,
  Globe,
  Instagram,
  Youtube,
  Twitter,
  Facebook
} from 'lucide-react';

// Import our beautiful generated images
import heroImg from '@/src/assets/images/dyson_hero_penthouse_1790869123052.jpg';
import purifierImg from '@/src/assets/images/dyson_product_purifier_1790869136391.jpg';
import vacuumImg from '@/src/assets/images/dyson_product_vacuum_1790869147390.jpg';
import dryerImg from '@/src/assets/images/dyson_product_hair_dryer_1790869167445.jpg';
import straightenerImg from '@/src/assets/images/dyson_product_straightener_1790869179471.jpg';
import robotImg from '@/src/assets/images/dyson_product_robot_vacuum_1790869190522.jpg';
import motorImg from '@/src/assets/images/dyson_tech_motor_1790869203237.jpg';
import architectureImg from '@/src/assets/images/dyson_bento_architecture_1790869215789.jpg';
import jamesImg from '@/src/assets/images/dyson_bento_james_dyson_1790869232246.jpg';
import interiorImg from '@/src/assets/images/dyson_bento_home_interior_1790869242740.jpg';

// Define products and details for interactive drawers
interface ProductItem {
  id: string;
  name: string;
  category: string;
  headline: string;
  image: any;
  description: string;
  price: number;
  specs: { label: string; value: string; percent: number }[];
  colors: { name: string; hex: string; desc: string }[];
  techDetails: string;
}

const PRODUCTS: ProductItem[] = [
  {
    id: 'purifier',
    name: 'Air Purifiers',
    category: 'Air Purifiers',
    headline: 'Cleaner air, healthier lives.',
    image: purifierImg,
    description: 'Captures ultra-fine particles, gases, and allergens. Projecting purified air to every corner of your living spaces automatically.',
    price: 649,
    specs: [
      { label: 'Filtration Efficiency', value: '99.95% of 0.1 microns', percent: 100 },
      { label: 'Max Air Projection', value: '290 Liters/sec', percent: 85 },
      { label: 'Acoustic Rating (Quiet Mode)', value: '61 Decibels', percent: 90 },
      { label: 'Sensor Polling Rate', value: 'Every 2 seconds', percent: 95 }
    ],
    colors: [
      { name: 'Prussian Blue / Rich Copper', hex: '#1e3a5f', desc: 'Deep luxurious marine blue coupled with bright physical copper accents.' },
      { name: 'White / Satin Silver', hex: '#e2e8f0', desc: 'Architectural clean white with silver anodized aluminum.' }
    ],
    techDetails: 'Features our state-of-the-art 360° fully-sealed Glass HEPA H13 filtration system and active carbon layer to scrub gases and pollutants.'
  },
  {
    id: 'vacuum',
    name: 'Cordless Vacuums',
    category: 'Cordless Vacuums',
    headline: 'Powerful. Lightweight.™',
    image: vacuumImg,
    description: 'Unmatched suction powered by Dyson Digital Motor V15. Intellectually counts and sizes microscopic dust particles automatically.',
    price: 899,
    specs: [
      { label: 'Suction Power', value: '240 Air Watts', percent: 98 },
      { label: 'Runtime (Eco Mode)', value: '60 Minutes', percent: 80 },
      { label: 'Bin Volume', value: '0.77 Liters', percent: 75 },
      { label: 'Microscopic Separation', value: '100,000g of force', percent: 100 }
    ],
    colors: [
      { name: 'Iron / Bright Yellow', hex: '#d97706', desc: 'Standard technical iron body with bright athletic yellow highlight details.' },
      { name: 'Prussian Blue / Rich Copper', hex: '#1e3a5f', desc: 'Exclusive limited edition color combination.' }
    ],
    techDetails: 'Dynamic Load Sensor (DLS) technology automatically adjusts suction power across different floor styles to conserve battery.'
  },
  {
    id: 'haircare',
    name: 'Hair Care',
    category: 'Hair Care',
    headline: 'Engineered for healthier hair.',
    image: dryerImg,
    description: 'Fast drying with no extreme heat. The Dyson Supersonic™ measures airflow temperature 40 times a second to prevent thermal damage.',
    price: 429,
    specs: [
      { label: 'Engine Speed', value: '110,000 RPM (V9 Motor)', percent: 99 },
      { label: 'Airflow Flow-rate', value: '13.3 Liters/sec', percent: 90 },
      { label: 'Temperature Control', value: 'Active glass thermistor', percent: 100 },
      { label: 'Negative Ion Output', value: '10 Million/cm³', percent: 95 }
    ],
    colors: [
      { name: 'Fuchsia / Ceramic Grey', hex: '#db2777', desc: 'Vibrant statement fuchsia nozzle with textured technical grey handle.' },
      { name: 'Ceramic Pop (Prussian / Copper)', hex: '#312e81', desc: 'Modern high-contrast architectural palette.' }
    ],
    techDetails: 'The small but powerful digital motor V9 is nestled in the handle, rebalancing the hair dryer weight for maximum comfort and style control.'
  },
  {
    id: 'styling',
    name: 'Hair Styling',
    category: 'Hair Styling',
    headline: 'Versatility without heat damage.',
    image: straightenerImg,
    description: 'Transformative straightening using air, not hot plates. Features the Coanda aerodynamic effect to curl, shape, and hide flyaways.',
    price: 599,
    specs: [
      { label: 'Airflow Speed', value: '11.9 Liters/sec', percent: 88 },
      { label: 'Intelligent Heat Control', value: 'Regulated under 150°C', percent: 100 },
      { label: 'Pressure Projection', value: '3.2 Kilopascals', percent: 85 },
      { label: 'Flyaway Reduction', value: 'Up to 58%', percent: 92 }
    ],
    colors: [
      { name: 'Satin Copper / Bright Nickel', hex: '#b45309', desc: 'Glossy warm metallic copper plates matched with structural nickel body.' },
      { name: 'Prussian Blue / Copper', hex: '#1e3a5f', desc: 'Deep matte dark blue with warm metal accents.' }
    ],
    techDetails: 'Utilizes precision glass bead thermistors and targeted micro-jets of air to align strands seamlessly without flattening.'
  },
  {
    id: 'robot',
    name: 'Robot Vacuums',
    category: 'Robot Vacuums',
    headline: 'Intelligent cleaning, reimagined.',
    image: robotImg,
    description: 'Our most powerful robotic vacuum ever. Equipped with a 360° vision camera, full-width brush bar, and automated obstacle avoidance.',
    price: 1199,
    specs: [
      { label: 'Suction Force', value: '65 Air Watts (Robot Class)', percent: 100 },
      { label: 'Mapping Capabilities', value: 'Up to 24 zones locally', percent: 90 },
      { label: 'Optical Scanning Frequency', value: '20 frames/sec', percent: 95 },
      { label: 'Brush Coverage', value: 'Full width edge-to-edge', percent: 98 }
    ],
    colors: [
      { name: 'Nickel / Satin Blue', hex: '#3b82f6', desc: 'Futuristic satin anodized blue details on a brushed structural metallic body.' }
    ],
    techDetails: 'Equipped with 26 sensors, SLAM vision mapping, and time-of-flight distance monitors to navigate tight home environments flawlessly.'
  }
];

// Tech innovation data for Dark Tech section
interface TechInnovation {
  id: string;
  name: string;
  description: string;
  specs: { label: string; value: string }[];
  particleSpeed: number;
  particleColor: string;
}

const TECH_INNOVATIONS: TechInnovation[] = [
  {
    id: 'multiplier',
    name: 'Air Multiplier™ Technology',
    description: 'Draws in surrounding air to amplify it up to 15 times, projecting a continuous, smooth, high-velocity stream of pure, refreshing airflow without the buffering of spinning blades.',
    specs: [
      { label: 'Air Amplification', value: '15x volume output' },
      { label: 'Velocity', value: '7.4 meters per second' }
    ],
    particleSpeed: 4.5,
    particleColor: '#38bdf8' // Brilliant bright cyan
  },
  {
    id: 'motor',
    name: 'Digital Motor V9',
    description: 'Spinning at up to 110,000 RPM, our digitally controlled motor is our light-weight propulsion miracle. It pumps fluid airflow dynamics to drive advanced suction or hyper-efficient heating systems.',
    specs: [
      { label: 'Rotational Velocity', value: '110,000 RPM' },
      { label: 'Pressure force', value: '3.5 kPa high pressure' }
    ],
    particleSpeed: 6.0,
    particleColor: '#ec4899' // Hot pink
  },
  {
    id: 'hepa',
    name: 'HEPA Filtration',
    description: 'A fully-sealed vacuum and filtration environment that traps 99.95% of microscopic particulates as small as 0.1 microns—effectively capturing dust, mold spores, dander, and viruses.',
    specs: [
      { label: 'Standards Fit', value: 'HEPA H13 Certified' },
      { label: 'Particulate Trapped', value: '99.95% down to 0.1μm' }
    ],
    particleSpeed: 1.5, // Slow down to show trapping efficiency
    particleColor: '#22c55e' // Healing emerald green
  },
  {
    id: 'acoustic',
    name: 'Acoustic Engineering',
    description: 'Combines acoustic dampening materials and custom-engineered aerodynamic paths to redirect internal turbulence, lowering sound energy and keeping operation quiet and vibration-free.',
    specs: [
      { label: 'Sound Output reduction', value: '-12 dB quiet rating' },
      { label: 'Vibration isolation', value: 'Dual silicone mounts' }
    ],
    particleSpeed: 2.2,
    particleColor: '#eab308' // Acoustic warm amber
  },
  {
    id: 'sustainable',
    name: 'Sustainable Design',
    description: 'Built with recycled alloys, energy-conserving sensors, and optimized standby electronics to reduce our global footprint and deliver heavy performance with light environmental impact.',
    specs: [
      { label: 'Recyclability Rate', value: '84% of materials used' },
      { label: 'Sensor standby power', value: '< 0.5 Watts' }
    ],
    particleSpeed: 2.8,
    particleColor: '#a855f7' // Regal bio-purple
  }
];

// Cart item interface
interface CartItem {
  product: ProductItem;
  selectedColor: string;
  quantity: number;
}

export default function Page() {
  // Navigation & Interactive UI state
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isAdvisorOpen, setIsAdvisorOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<ProductItem | null>(null);
  const [activeTech, setActiveTech] = useState<string>('multiplier');
  const [selectedColorIndex, setSelectedColorIndex] = useState<number>(0);
  
  // Custom interactive stories for bento cards
  const [activeBentoStory, setActiveBentoStory] = useState<{ title: string; content: string; image: any } | null>(null);

  // Search overlay state
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  
  // Scrim / toast alert state
  const [toast, setToast] = useState<{ show: boolean; message: string } | null>(null);

  // Virtual AI Advisor State Wizard
  const [advisorStep, setAdvisorStep] = useState(1);
  const [advisorAnswers, setAdvisorAnswers] = useState({
    concern: 'Allergies & Dust',
    hairType: 'Fine & Sensitive',
    layout: 'Apartment',
    techFocus: 'Filtration Technology'
  });
  const [isAdvisorLoading, setIsAdvisorLoading] = useState(false);
  const [advisorResult, setAdvisorResult] = useState<any>(null);

  // Particle Canvas Ref
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Auto-dismiss toast
  useEffect(() => {
    if (toast?.show) {
      const timer = setTimeout(() => {
        setToast(null);
      }, 3500);
      return () => clearTimeout(timer);
    }
  }, [toast]);

  // Show Toast Helper
  const triggerToast = (message: string) => {
    setToast({ show: true, message });
  };

  // Add Item to Cart
  const handleAddToCart = (product: ProductItem, colorName: string) => {
    const existing = cart.find(
      (item) => item.product.id === product.id && item.selectedColor === colorName
    );
    if (existing) {
      setCart(
        cart.map((item) =>
          item.product.id === product.id && item.selectedColor === colorName
            ? { ...item, quantity: item.quantity + 1 }
            : item
        )
      );
    } else {
      setCart([...cart, { product, selectedColor: colorName, quantity: 1 }]);
    }
    triggerToast(`Added ${product.name} (${colorName}) to your cart.`);
  };

  // Remove Item
  const handleRemoveFromCart = (productId: string, colorName: string) => {
    setCart(cart.filter((item) => !(item.product.id === productId && item.selectedColor === colorName)));
    triggerToast('Item removed from cart.');
  };

  // Update Quantity
  const handleUpdateQuantity = (productId: string, colorName: string, delta: number) => {
    setCart(
      cart
        .map((item) => {
          if (item.product.id === productId && item.selectedColor === colorName) {
            const nextQuantity = item.quantity + delta;
            return { ...item, quantity: nextQuantity };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  // Tech section particle logic
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: { x: number; y: number; speedX: number; size: number; alpha: number; yOffset: number; amplitude: number }[] = [];

    // Get parameters depending on active technology selected
    const currentTech = TECH_INNOVATIONS.find((t) => t.id === activeTech) || TECH_INNOVATIONS[0];

    const resizeCanvas = () => {
      canvas.width = canvas.parentElement?.clientWidth || 800;
      canvas.height = canvas.parentElement?.clientHeight || 450;
    };
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);

    // Initialize particles
    const initParticles = () => {
      particles = [];
      const count = activeTech === 'multiplier' ? 120 : activeTech === 'hepa' ? 50 : 80;
      for (let i = 0; i < count; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          speedX: (0.8 + Math.random() * 1.5) * currentTech.particleSpeed,
          size: 1.5 + Math.random() * 2,
          alpha: 0.15 + Math.random() * 0.6,
          yOffset: Math.random() * Math.PI * 2,
          amplitude: 15 + Math.random() * 35
        });
      }
    };
    initParticles();

    // Render loop
    const render = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Render custom physics based on technology
      particles.forEach((p) => {
        // Air Multiplier draws in surrounding streams and amplifies it
        if (activeTech === 'multiplier') {
          // Flow from left to right along wavy trajectories
          p.x += p.speedX;
          // Curve and converge into a narrow channel in the center, then expand
          const midX = canvas.width * 0.45;
          const distToMid = p.x - midX;
          const convergence = Math.max(0, 1 - Math.abs(distToMid) / (canvas.width * 0.4));
          const wave = Math.sin(p.x * 0.015 + p.yOffset) * p.amplitude * (1 - convergence * 0.65);
          
          let targetY = canvas.height * 0.5 + wave;
          p.y += (targetY - p.y) * 0.08;

          if (p.x > canvas.width) {
            p.x = 0;
            p.y = Math.random() * canvas.height;
          }
        } 
        // Digital Motor spins particles in a high-velocity vortex
        else if (activeTech === 'motor') {
          p.x += p.speedX;
          // Whirlpool effect around central turbine center (50% X, 50% Y)
          const centerX = canvas.width * 0.5;
          const centerY = canvas.height * 0.5;
          const radius = 100;

          // Before center: converge rapidly
          if (p.x < centerX - 80) {
            p.y += (centerY - p.y) * 0.05;
          } 
          // At turbine center: swirl
          else if (p.x >= centerX - 80 && p.x <= centerX + 80) {
            const angle = (p.x * 0.04) + p.yOffset;
            p.y = centerY + Math.sin(angle) * (25 + Math.sin(p.x * 0.01) * 30);
          } 
          // After: exhaust blast to the right
          else {
            p.y += (centerY + Math.sin(p.x * 0.02 + p.yOffset) * 12 - p.y) * 0.1;
          }

          if (p.x > canvas.width) {
            p.x = 0;
            p.y = Math.random() * canvas.height;
          }
        } 
        // HEPA filtration traps particles
        else if (activeTech === 'hepa') {
          p.x += p.speedX;
          const filterLine = canvas.width * 0.5;

          // Left side: dusty/grey particles
          if (p.x < filterLine) {
            ctx.fillStyle = `rgba(163, 163, 163, ${p.alpha})`; // Grey dust
            const wave = Math.sin(p.x * 0.01 + p.yOffset) * p.amplitude;
            p.y += (canvas.height * 0.5 + wave - p.y) * 0.03;
          } 
          // Particles hit the filter line and slow down or stop
          else {
            // High-purity green flow emerges
            ctx.fillStyle = `rgba(34, 197, 94, ${p.alpha * 1.2})`; // Pure Emerald
            const wave = Math.sin(p.x * 0.02 + p.yOffset) * (p.amplitude * 0.2);
            p.y += (canvas.height * 0.5 + wave - p.y) * 0.08;
          }

          if (p.x > canvas.width) {
            p.x = 0;
            p.y = Math.random() * canvas.height;
          }
        } 
        // Acoustic acoustic insulation (dampened waves)
        else if (activeTech === 'acoustic') {
          p.x += p.speedX * 0.7;
          // Render sound wave rings that fade out
          const wave = Math.sin(p.x * 0.03 + p.yOffset) * (p.amplitude * 0.3);
          p.y += (canvas.height * 0.5 + wave - p.y) * 0.05;

          // Draw a small ambient ring around acoustic centers
          ctx.beginPath();
          ctx.strokeStyle = `rgba(234, 179, 8, ${p.alpha * 0.15})`;
          ctx.arc(canvas.width * 0.5, canvas.height * 0.5, p.x * 0.3, 0, Math.PI * 2);
          ctx.stroke();

          if (p.x > canvas.width) {
            p.x = 0;
            p.y = Math.random() * canvas.height;
          }
        }
        // Sustainable slow efficient solar pulse
        else {
          p.x += p.speedX * 0.8;
          const wave = Math.sin(p.x * 0.01 + p.yOffset) * p.amplitude;
          p.y += (canvas.height * 0.5 + wave - p.y) * 0.04;

          if (p.x > canvas.width) {
            p.x = 0;
            p.y = Math.random() * canvas.height;
          }
        }

        // Draw particle node
        if (activeTech !== 'hepa') {
          ctx.fillStyle = currentTech.particleColor + Math.floor(p.alpha * 255).toString(16).padStart(2, '0');
        }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });

      // Special overlay details depending on tech
      if (activeTech === 'hepa') {
        // Draw the HEPA barrier line
        ctx.strokeStyle = 'rgba(34, 197, 94, 0.4)';
        ctx.lineWidth = 3;
        ctx.setLineDash([6, 6]);
        ctx.beginPath();
        ctx.moveTo(canvas.width * 0.5, 50);
        ctx.lineTo(canvas.width * 0.5, canvas.height - 50);
        ctx.stroke();
        ctx.setLineDash([]);
        
        // HEPA Badge label
        ctx.fillStyle = '#22c55e';
        ctx.font = '10px monospace';
        ctx.fillText('HEPA H13 SEAL BARRIER', canvas.width * 0.5 - 60, 35);
      }

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', resizeCanvas);
    };
  }, [activeTech]);

  // Submit AI Diagnostic Wizard
  const handleAdvisorSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsAdvisorLoading(true);
    try {
      const res = await fetch('/api/recommend', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(advisorAnswers)
      });
      const data = await res.json();
      if (data.error) {
        throw new Error(data.message);
      }
      setAdvisorResult(data);
      setAdvisorStep(5); // Complete screen
    } catch (err: any) {
      console.error(err);
      triggerToast('Could not retrieve recommendation. Using offline matching.');
      // Offline fallback recommendation
      const offlineMatch = PRODUCTS.find(p => p.name.toLowerCase().includes('purifier')) || PRODUCTS[0];
      setAdvisorResult({
        category: offlineMatch.category,
        recommendedModel: offlineMatch.name === 'Air Purifiers' ? 'Dyson Purifier Hot+Cool™ Gen1' : 'Dyson Gen5detect™',
        reasoning: 'Tailored precisely for air quality filtration and pet dander extraction in modern layouts.',
        techIntegration: 'Features active carbon filters and Air Multiplier technology for rapid cycling of ambient atmospheres.',
        customTip: 'Place centrally in your room to maximize air recycling and allow advanced acoustic baffles to absorb sound waves.',
        matchPercentage: 94
      });
      setAdvisorStep(5);
    } finally {
      setIsAdvisorLoading(false);
    }
  };

  // Subtotal cart
  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  // Search filter
  const filteredProducts = PRODUCTS.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.headline.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen flex flex-col justify-between text-neutral-200">
      
      {/* GLOBAL BACKGROUND NOISE (Elegantly textured) */}
      <div className="fixed inset-0 bg-[#0b0b0b] pointer-events-none z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-neutral-900 via-[#0b0b0b] to-[#050505] opacity-80" />
      </div>

      {/* HEADER BAR (Top Bar Contract: exactly 1 row, 3-zones) */}
      <header className="fixed top-0 left-0 right-0 z-50 transition-all duration-300 glass-panel border-b border-white/5 px-6 lg:px-12 py-4 flex items-center justify-between">
        
        {/* Zone 1: Brand title, one line, lowercase premium typography */}
        <div className="flex items-center">
          <button 
            onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })} 
            className="text-2xl font-bold tracking-tight text-white hover:opacity-80 transition-opacity"
          >
            dyson
          </button>
        </div>

        {/* Zone 2: 4-6 nav links, 1-2 word labels, single-line */}
        <nav className="hidden md:flex items-center gap-10 text-[13px] font-medium tracking-wider uppercase text-neutral-400">
          <button 
            onClick={() => {
              const element = document.getElementById('products-section');
              element?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hover:text-white transition-colors duration-200 flex items-center gap-1 shrink-0"
          >
            Shop <ChevronDown className="w-3.5 h-3.5 opacity-65" />
          </button>
          <button 
            onClick={() => {
              const element = document.getElementById('technology-section');
              element?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hover:text-white transition-colors duration-200 shrink-0"
          >
            Technology
          </button>
          <button 
            onClick={() => {
              const element = document.getElementById('bento-section');
              element?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="hover:text-white transition-colors duration-200 shrink-0"
          >
            Our story
          </button>
          <button 
            onClick={() => setIsAdvisorOpen(true)}
            className="hover:text-white text-emerald-400 transition-colors duration-200 flex items-center gap-1 shrink-0"
          >
            AI Advisor <Sparkles className="w-3.5 h-3.5 animate-pulse text-emerald-400" />
          </button>
        </nav>

        {/* Zone 3: Actions - Search, User, Bag */}
        <div className="flex items-center gap-5">
          <button 
            onClick={() => setIsSearchOpen(true)}
            className="p-1 hover:text-white text-neutral-400 transition-colors"
            aria-label="Search"
          >
            <Search className="w-4.5 h-4.5" />
          </button>
          <button 
            onClick={() => setIsAdvisorOpen(true)}
            className="p-1 hover:text-white text-neutral-400 transition-colors flex items-center gap-1.5"
            aria-label="User Account / Advisor"
          >
            <User className="w-4.5 h-4.5" />
          </button>
          <button 
            onClick={() => setIsCartOpen(true)}
            className="p-1 hover:text-white text-neutral-400 transition-colors relative flex items-center gap-1"
            aria-label="Cart"
          >
            <ShoppingBag className="w-4.5 h-4.5" />
            {cart.length > 0 && (
              <span className="absolute -top-1 -right-1 bg-white text-black text-[10px] font-bold w-4 h-4 rounded-full flex items-center justify-center animate-bounce">
                {cart.reduce((s, i) => s + i.quantity, 0)}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* MAIN LAYOUT */}
      <main className="z-10 flex-grow pt-[72px]">
        
        {/* 1. HERO SECTION WITH Sunset Penthouse and Purifier */}
        <section className="relative min-h-[90vh] lg:min-h-screen flex items-center justify-center px-6 lg:px-16 py-12 overflow-hidden border-b border-white/5">
          {/* High-fidelity background rendering */}
          <div className="absolute inset-0 z-0">
            <Image
              src={heroImg}
              alt="Dyson Sunset Penthouse"
              fill
              priority
              className="object-cover object-center scale-105 filter brightness-95 transform transition-all duration-1000 ease-out"
              referrerPolicy="no-referrer"
            />
            {/* Elegant vignette and subtle warm filter */}
            <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/45 to-transparent md:bg-gradient-to-r" />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0b0b0b] via-transparent to-transparent" />
          </div>

          <div className="container mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 relative z-10 w-full max-w-7xl items-center mt-10 md:mt-0">
            {/* Left Column Content */}
            <div className="md:col-span-7 flex flex-col justify-center text-left text-white max-w-2xl select-none">
              <motion.span 
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                className="text-[12px] md:text-[13px] font-semibold tracking-[0.25em] text-neutral-400 uppercase mb-4 block"
              >
                Cleaner Air. A Brighter Future.
              </motion.span>
              <motion.h1 
                initial={{ opacity: 0, y: 25 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.1 }}
                className="text-4xl md:text-6xl lg:text-7xl font-light tracking-tight leading-[1.08] text-white text-balance mb-6"
              >
                The next generation <br className="hidden md:inline" />
                of air care.
              </motion.h1>
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                className="text-sm md:text-base text-neutral-300 leading-relaxed max-w-lg mb-10 opacity-90 font-light"
              >
                Our most intelligent purifier yet. Automatically adapts to your environment, removing pollutants, allergens and harmful gases — and keeping your home feeling just right.
              </motion.p>
              
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.3 }}
                className="flex flex-col sm:flex-row items-start sm:items-center gap-5"
              >
                <button
                  onClick={() => {
                    const purifierProduct = PRODUCTS.find((p) => p.id === 'purifier');
                    if (purifierProduct) {
                      setSelectedProduct(purifierProduct);
                      setSelectedColorIndex(0);
                    }
                  }}
                  className="px-8 py-3.5 bg-white text-black text-xs font-semibold uppercase tracking-wider rounded-full hover:bg-neutral-100 active:scale-95 transition-all duration-200 flex items-center gap-2 group shadow-lg shadow-black/20"
                >
                  Discover Pure Cool Gen1 
                  <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1.5 transition-transform duration-200" />
                </button>
                <button
                  onClick={() => setIsAdvisorOpen(true)}
                  className="px-6 py-3.5 border border-white/35 text-white hover:border-white text-xs font-semibold uppercase tracking-wider rounded-full active:scale-95 transition-all duration-200 flex items-center gap-2"
                >
                  Virtual AI Matcher
                </button>
              </motion.div>
            </div>

            {/* Right Column Interactive Purifier Hotspot Drawer (Embedded in Hero Image Foreground) */}
            <div className="md:col-span-5 h-full min-h-[300px] flex items-center justify-end relative">
              
              {/* Interactive Purifier Annotation Hotspot Points */}
              <div className="absolute right-0 top-1/2 -translate-y-1/2 w-full max-w-[280px] hidden lg:block mr-24">
                <div className="space-y-4">
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-neutral-400 mb-2 border-b border-white/10 pb-1">Engineering Hotspots</h4>
                  
                  {/* Hotspot 1 */}
                  <div className="p-3 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 hover:border-sky-500 transition-colors group cursor-pointer"
                       onClick={() => {
                         setActiveTech('multiplier');
                         const element = document.getElementById('technology-section');
                         element?.scrollIntoView({ behavior: 'smooth' });
                         triggerToast('Explored Air Multiplier technology below.');
                       }}>
                    <span className="text-[10px] text-sky-400 font-mono tracking-widest block uppercase mb-0.5">01. Air Projector</span>
                    <h5 className="text-[13px] font-semibold text-white">Coanda Loop Amplifier</h5>
                    <p className="text-[11px] text-neutral-400 mt-0.5 group-hover:text-neutral-300">Drives high-velocity airflow continuously.</p>
                  </div>

                  {/* Hotspot 2 */}
                  <div className="p-3 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 hover:border-emerald-500 transition-colors group cursor-pointer"
                       onClick={() => {
                         setActiveTech('hepa');
                         const element = document.getElementById('technology-section');
                         element?.scrollIntoView({ behavior: 'smooth' });
                         triggerToast('Explored H13 Glass HEPA filtration.');
                       }}>
                    <span className="text-[10px] text-emerald-400 font-mono tracking-widest block uppercase mb-0.5">02. Sealed Core</span>
                    <h5 className="text-[13px] font-semibold text-white">H13 Certified Glass HEPA</h5>
                    <p className="text-[11px] text-neutral-400 mt-0.5 group-hover:text-neutral-300">Captures 99.95% of ultra-fine pollutants.</p>
                  </div>

                  {/* Hotspot 3 */}
                  <div className="p-3 bg-black/60 backdrop-blur-md rounded-lg border border-white/10 hover:border-pink-500 transition-colors group cursor-pointer"
                       onClick={() => {
                         setActiveTech('motor');
                         const element = document.getElementById('technology-section');
                         element?.scrollIntoView({ behavior: 'smooth' });
                         triggerToast('Explored Digital Motor V9.');
                       }}>
                    <span className="text-[10px] text-pink-400 font-mono tracking-widest block uppercase mb-0.5">03. Power Drive</span>
                    <h5 className="text-[13px] font-semibold text-white">Dyson Digital Brushless Motor</h5>
                    <p className="text-[11px] text-neutral-400 mt-0.5 group-hover:text-neutral-300">Ultra-balanced dynamic turbine speeds.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Bottom Scroll / Ambient Indicator */}
          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-1 opacity-70 z-10 select-none">
            <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-white">Scroll</span>
            <div className="w-[1px] h-10 bg-gradient-to-b from-white to-transparent animate-pulse" />
          </div>
        </section>


        {/* 2. "OUR PRODUCTS" HORIZONTAL PRODUCT GRID CATEGORY LIST */}
        <section id="products-section" className="bg-white text-neutral-900 py-20 px-6 lg:px-12 border-b border-neutral-200 overflow-hidden relative">
          <div className="container mx-auto max-w-7xl">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start mb-12">
              <div className="lg:col-span-3 flex flex-col select-none">
                <span className="text-xs font-bold tracking-[0.2em] text-neutral-400 uppercase mb-1">Our Products</span>
                <h2 className="text-3xl font-light tracking-tight text-neutral-900 uppercase">Interactive Categories</h2>
                <div className="w-8 h-[2px] bg-neutral-900 mt-4" />
                <p className="text-xs text-neutral-500 leading-relaxed mt-6 max-w-xs">
                  Click on any category column to open detailed technical specifications, configure colors, and experience true Dyson engineering.
                </p>
              </div>

              {/* The Product category cards, split with elegant thin lines */}
              <div className="lg:col-span-9 grid grid-cols-1 md:grid-cols-5 border-l border-neutral-100">
                {PRODUCTS.map((prod) => (
                  <div
                    key={prod.id}
                    onClick={() => {
                      setSelectedProduct(prod);
                      setSelectedColorIndex(0);
                    }}
                    className="p-6 border-r border-b md:border-b-0 border-neutral-100 flex flex-col justify-between hover:bg-neutral-50 cursor-pointer transition-all duration-300 group relative min-h-[360px]"
                  >
                    {/* Visual Cutout Image */}
                    <div className="relative w-full h-[140px] mb-8 overflow-hidden flex items-center justify-center bg-white/5 rounded-lg group-hover:scale-105 transition-transform duration-500">
                      <Image
                        src={prod.image}
                        alt={prod.name}
                        fill
                        className="object-contain p-2"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    {/* Metadata Content */}
                    <div className="flex flex-col flex-grow justify-end">
                      <h3 className="text-[15px] font-bold tracking-tight text-neutral-900 mb-1 group-hover:text-black">
                        {prod.name}
                      </h3>
                      <p className="text-xs text-neutral-400 leading-relaxed line-clamp-2">
                        {prod.headline}
                      </p>
                    </div>

                    {/* Interactive Arrow Button */}
                    <div className="mt-6 pt-4 border-t border-neutral-100 flex justify-between items-center text-neutral-400 group-hover:text-neutral-900 transition-colors">
                      <span className="text-[11px] uppercase font-mono tracking-wider font-semibold opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        Configure
                      </span>
                      <ArrowRight className="w-4 h-4 transform group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>


        {/* 3. DYSON TECHNOLOGY IN-DEPTH TECHNICAL SIMULATOR (Dark theme) */}
        <section id="technology-section" className="bg-[#0b0b0b] text-white py-24 px-6 lg:px-12 relative overflow-hidden border-b border-white/5">
          
          {/* Subtle Ambient Accent Glows */}
          <div className="absolute right-0 top-1/4 w-[500px] h-[500px] bg-pink-500/5 blur-[120px] rounded-full pointer-events-none" />
          <div className="absolute left-1/4 bottom-1/4 w-[400px] h-[400px] bg-sky-500/5 blur-[120px] rounded-full pointer-events-none" />

          <div className="container mx-auto max-w-7xl relative z-10">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              
              {/* Left Column Content */}
              <div className="lg:col-span-4 flex flex-col justify-center">
                <span className="text-[11px] font-bold tracking-[0.3em] text-neutral-400 uppercase mb-2 block">Dyson Technology</span>
                <h2 className="text-3xl md:text-4xl font-light tracking-tight leading-tight text-white mb-6">
                  Engineering a <br className="hidden md:inline" />
                  healthier tomorrow.
                </h2>
                <p className="text-sm text-neutral-400 leading-relaxed mb-8 opacity-90 font-light">
                  From airflow dynamics to microscopic acoustic tuning, our patented technologies solve physical, real-world problems. We invest in science, prototyping, and material design to engineer products that protect your lifestyle.
                </p>
                <div className="mb-8">
                  <button
                    onClick={() => {
                      triggerToast('Loading Dyson Engineering Whitepaper resources...');
                      setActiveBentoStory({
                        title: 'Acoustic & Fluid Power Engineering Lab',
                        content: 'Dyson operates world-leading acoustic chambers and fluid dynamic research divisions. By utilizing supercomputers to execute over 10,000 aerodynamic simulations daily, we design fans and cordless vacuum cyclones that deliver record suction power while minimizing noise frequency spikes. This lab represents our obsession with premium physics.',
                        image: architectureImg
                      });
                    }}
                    className="px-6 py-3 border border-white/20 text-white hover:border-white hover:bg-white/5 text-xs font-semibold uppercase tracking-wider rounded-full transition-all flex items-center gap-2 group w-fit"
                  >
                    Our technology 
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>

              {/* Center Column: The Visual Tech Motor split, overlaid with HTML5 Interactive Particles */}
              <div className="lg:col-span-5 relative flex items-center justify-center p-4 bg-neutral-900/40 rounded-2xl border border-white/5 shadow-inner overflow-hidden min-h-[380px] lg:min-h-[440px]">
                {/* Background high-fidelity motor render */}
                <div className="absolute inset-0 z-0 opacity-85">
                  <Image
                    src={motorImg}
                    alt="Dyson digital motor cross section"
                    fill
                    className="object-cover scale-100"
                    referrerPolicy="no-referrer"
                  />
                  {/* Subtle vignette */}
                  <div className="absolute inset-0 bg-radial-gradient(circle,_transparent_30%,_#0b0b0b_100%) opacity-30" />
                </div>

                {/* THE FLUID FLOW CANVAS SIMULATOR OVERLAY */}
                <canvas 
                  ref={canvasRef} 
                  className="absolute inset-0 z-10 pointer-events-none"
                />

                {/* Ambient Status tag */}
                <div className="absolute top-4 left-4 bg-black/60 backdrop-blur-md px-3 py-1 rounded-full border border-white/10 text-[9px] font-mono uppercase tracking-wider text-neutral-300 z-20 flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                  Particle Engine Active
                </div>
              </div>

              {/* Right Column Accordion Selection List */}
              <div className="lg:col-span-3 space-y-4">
                <h4 className="text-[10px] font-bold uppercase tracking-widest text-neutral-400 mb-2 block border-b border-white/10 pb-1 font-mono">
                  Select Innovation
                </h4>
                <div className="space-y-2">
                  {TECH_INNOVATIONS.map((tech) => {
                    const isActive = activeTech === tech.id;
                    return (
                      <div
                        key={tech.id}
                        onClick={() => {
                          setActiveTech(tech.id);
                          triggerToast(`Activated ${tech.name} particle simulation.`);
                        }}
                        className={`p-4 rounded-xl border transition-all duration-300 cursor-pointer ${
                          isActive
                            ? 'bg-neutral-900 border-white/20 shadow-md translate-x-2'
                            : 'bg-transparent border-white/5 hover:border-white/15'
                        }`}
                      >
                        <div className="flex justify-between items-center">
                          <span className="text-[13px] font-semibold tracking-tight text-white">
                            {tech.name}
                          </span>
                          <ArrowRight className={`w-3.5 h-3.5 transition-transform duration-300 ${
                            isActive ? 'translate-x-1.5 text-white' : 'text-neutral-500'
                          }`} />
                        </div>

                        {/* Animated Expand Description */}
                        <AnimatePresence initial={false}>
                          {isActive && (
                            <motion.div
                              initial={{ height: 0, opacity: 0 }}
                              animate={{ height: 'auto', opacity: 1 }}
                              exit={{ height: 0, opacity: 0 }}
                              transition={{ duration: 0.3 }}
                              className="overflow-hidden mt-3 pt-3 border-t border-white/5"
                            >
                              <p className="text-[11px] text-neutral-400 leading-relaxed mb-3">
                                {tech.description}
                              </p>
                              
                              {/* Small specifications badges */}
                              <div className="grid grid-cols-2 gap-2 mt-2">
                                {tech.specs.map((s, idx) => (
                                  <div key={idx} className="bg-white/5 p-1.5 rounded border border-white/5 text-[9px]">
                                    <span className="text-neutral-400 block font-mono">{s.label}</span>
                                    <span className="text-white font-medium block mt-0.5">{s.value}</span>
                                  </div>
                                ))}
                              </div>
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    );
                  })}
                </div>
              </div>

            </div>
          </div>
        </section>


        {/* 4. THREE HORIZONTALLY ALIGNED BENTO CARDS (Brand stories, with active zoom overlays) */}
        <section id="bento-section" className="bg-[#050505] text-white py-24 px-6 lg:px-12 border-b border-white/5 relative">
          <div className="container mx-auto max-w-7xl">
            
            <div className="mb-12 flex flex-col md:flex-row justify-between items-start md:items-end gap-4 select-none">
              <div>
                <span className="text-[11px] font-bold tracking-[0.3em] text-neutral-400 uppercase mb-2 block">Our Heritage</span>
                <h2 className="text-3xl font-light uppercase tracking-tight text-white">Brand & Engineering Culture</h2>
              </div>
              <p className="text-xs text-neutral-400 leading-relaxed max-w-sm">
                Explore the stories and deep engineering commitment behind James Dyson’s vision. Click cards to reveal complete immersive histories.
              </p>
            </div>

            {/* Bento Horizontal Row layout */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              
              {/* Card 1: Our Mission */}
              <div
                onClick={() => {
                  triggerToast('Opening Our Mission story');
                  setActiveBentoStory({
                    title: 'Our Mission for a Sustainable World',
                    content: 'Dyson is deeply invested in minimizing ambient home footprints while maximizing aerodynamic filtration efficiency. By engineering long-lifespan materials, integrating intelligent energy-monitoring sensors, and investing over £2.75bn in sustainable technology pipelines, we design products with zero compromise between mechanical muscle and ecological sanity. We look beyond static criteria to redefine complete lifestyle lifecycles.',
                    image: architectureImg
                  });
                }}
                className="relative h-[420px] rounded-2xl overflow-hidden border border-white/5 hover:border-white/15 transition-all duration-300 group cursor-pointer"
              >
                {/* Visual backdrop */}
                <Image
                  src={architectureImg}
                  alt="Dyson curved architecture building"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-700 brightness-[0.45]"
                  referrerPolicy="no-referrer"
                />
                
                {/* Content Overlay */}
                <div className="absolute inset-0 p-8 flex flex-col justify-between z-10">
                  <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-neutral-300">Our Mission</span>
                  <div>
                    <h3 className="text-2xl font-light tracking-tight text-white text-balance mb-3">
                      A cleaner, healthier, more sustainable future.
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs text-neutral-400 group-hover:text-white transition-colors">
                      <span>Learn more</span>
                      <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1.5 transition-transform" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Card 2: James Dyson Portrait */}
              <div
                onClick={() => {
                  triggerToast('Opening James Dyson biography');
                  setActiveBentoStory({
                    title: 'James Dyson: Iterative Optimization',
                    content: 'In 1978, James Dyson became frustrated with his vacuum’s declining suction. He set off to build the world’s first cyclone vacuum. Over 5,127 distinct, meticulous prototypes later, he revolutionized industry paradigms. Today, that same spirit of relentless testing, iterative physical engineering, and refusal to rely on easy shortcuts defines our core laboratory operations globally.',
                    image: jamesImg
                  });
                }}
                className="relative h-[420px] rounded-2xl overflow-hidden border border-white/5 hover:border-white/15 transition-all duration-300 group cursor-pointer"
              >
                {/* Visual backdrop */}
                <Image
                  src={jamesImg}
                  alt="Portrait of James Dyson"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-700 brightness-[0.55]"
                  referrerPolicy="no-referrer"
                />

                {/* Content Overlay */}
                <div className="absolute inset-0 p-8 flex flex-col justify-between z-10">
                  <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-neutral-300 font-semibold">James Dyson</span>
                  <div>
                    <h3 className="text-2xl font-light tracking-tight text-white text-balance mb-3">
                      Inventing for a better tomorrow.
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs text-neutral-400 group-hover:text-white transition-colors">
                      <span>Our story</span>
                      <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1.5 transition-transform" />
                    </div>
                  </div>
                </div>
              </div>

              {/* Card 3: Home Interior */}
              <div
                onClick={() => {
                  triggerToast('Opening Dyson in Your Home gallery');
                  setActiveBentoStory({
                    title: 'Dyson in Your Home: Design in Context',
                    content: 'Dyson products are not just home utilities; they are high-fidelity architectural features. Crafted using brushed anodized aluminum, lightweight structural alloys, and sleek geometry, they live beautifully in any modern interior space. Our machines are engineered to blend seamlessly into active family life, providing unparalleled performance while presenting a striking, geometric spatial silhouette.',
                    image: interiorImg
                  });
                }}
                className="relative h-[420px] rounded-2xl overflow-hidden border border-white/5 hover:border-white/15 transition-all duration-300 group cursor-pointer"
              >
                {/* Visual backdrop */}
                <Image
                  src={interiorImg}
                  alt="Luxurious minimalist curved staircase"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-700 brightness-[0.45]"
                  referrerPolicy="no-referrer"
                />

                {/* Content Overlay */}
                <div className="absolute inset-0 p-8 flex flex-col justify-between z-10">
                  <span className="text-[10px] uppercase font-mono tracking-[0.3em] text-neutral-300">Dyson in your home</span>
                  <div>
                    <h3 className="text-2xl font-light tracking-tight text-white text-balance mb-3">
                      Design. Performance. A better everyday.
                    </h3>
                    <div className="flex items-center gap-1.5 text-xs text-neutral-400 group-hover:text-white transition-colors">
                      <span>Explore</span>
                      <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1.5 transition-transform" />
                    </div>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </section>

      </main>

      {/* FOOTER SECTION (Clean and structural) */}
      <footer className="bg-[#050505] text-white border-t border-white/5 py-12 px-6 lg:px-12 z-10 relative">
        <div className="container mx-auto max-w-7xl">
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12 select-none">
            {/* Column 1 Logo */}
            <div className="flex flex-col gap-4">
              <span className="text-2xl font-bold tracking-tight text-white">dyson</span>
              <p className="text-[11px] text-neutral-500 max-w-xs leading-relaxed">
                Relentlessly innovating to build the next generation of lifestyle solutions, driven by physical science.
              </p>
            </div>

            {/* Column 2 Navigation Links */}
            <div className="flex flex-col gap-3">
              <span className="text-[11px] uppercase tracking-wider text-neutral-400 font-bold mb-1 font-mono">Navigate</span>
              <div className="flex flex-col gap-2 text-xs text-neutral-400">
                <button onClick={() => {
                  const element = document.getElementById('products-section');
                  element?.scrollIntoView({ behavior: 'smooth' });
                }} className="hover:text-white transition-colors text-left">Shop Online</button>
                <button onClick={() => {
                  const element = document.getElementById('technology-section');
                  element?.scrollIntoView({ behavior: 'smooth' });
                }} className="hover:text-white transition-colors text-left">Advanced Engineering</button>
                <button onClick={() => {
                  const element = document.getElementById('bento-section');
                  element?.scrollIntoView({ behavior: 'smooth' });
                }} className="hover:text-white transition-colors text-left">James Dyson Heritage</button>
              </div>
            </div>

            {/* Column 3 Resources */}
            <div className="flex flex-col gap-3">
              <span className="text-[11px] uppercase tracking-wider text-neutral-400 font-bold mb-1 font-mono">Interactive Support</span>
              <div className="flex flex-col gap-2 text-xs text-neutral-400">
                <button onClick={() => setIsAdvisorOpen(true)} className="hover:text-white transition-colors text-left">Start AI Diagnostic Advisor</button>
                <button onClick={() => triggerToast('Opening direct support channel...')} className="hover:text-white transition-colors text-left">Virtual Diagnostic Center</button>
                <button onClick={() => triggerToast('Directing to Dyson warranty portal...')} className="hover:text-white transition-colors text-left">Dyson Engineering Guarantee</button>
              </div>
            </div>

            {/* Column 4 Regional selection */}
            <div className="flex flex-col gap-4">
              <span className="text-[11px] uppercase tracking-wider text-neutral-400 font-bold mb-1 font-mono">Global Operations</span>
              <div className="flex items-center gap-1.5 text-xs text-neutral-400 cursor-pointer hover:text-white transition-colors border border-white/5 rounded-lg px-3 py-1.5 bg-neutral-900 w-fit">
                <Globe className="w-3.5 h-3.5" />
                <span>United Kingdom</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-60" />
              </div>
            </div>
          </div>

          {/* Socials & Copyright Row */}
          <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-[11px] text-neutral-500">
            <div>
              &copy; {new Date().getFullYear()} Dyson Engineering. All rights reserved. Registered trademark of Dyson Ltd.
            </div>
            
            {/* Clean metadata list (Zero-Pill Discipline applied) */}
            <div className="flex items-center gap-4 text-neutral-400">
              <button onClick={() => triggerToast('Opening Terms conditions')} className="hover:text-white">Terms of Sale</button>
              <span aria-hidden="true">&middot;</span>
              <button onClick={() => triggerToast('Opening Privacy Charter')} className="hover:text-white">Privacy Charter</button>
              <span aria-hidden="true">&middot;</span>
              <button onClick={() => triggerToast('Opening Cookie preferences')} className="hover:text-white">Cookie Control</button>
            </div>

            <div className="flex items-center gap-4 text-neutral-400">
              <Instagram className="w-4 h-4 hover:text-white cursor-pointer" />
              <Youtube className="w-4 h-4 hover:text-white cursor-pointer" />
              <Twitter className="w-4 h-4 hover:text-white cursor-pointer" />
              <Facebook className="w-4 h-4 hover:text-white cursor-pointer" />
            </div>
          </div>

        </div>
      </footer>


      {/* INTERACTIVE COMPONENT 1: PRODUCT SPECIFICATION DRAWER */}
      <AnimatePresence>
        {selectedProduct && (
          <div className="fixed inset-0 z-50 flex justify-end">
            {/* Backdrop scrim */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setSelectedProduct(null)}
              className="absolute inset-0 bg-black"
            />

            {/* Sliding Drawer Container */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="relative w-full max-w-lg md:max-w-xl h-full bg-[#0e0e0e] border-l border-white/10 flex flex-col justify-between shadow-2xl z-10"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/5 flex justify-between items-center bg-black/40">
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-widest text-neutral-400 block mb-0.5">
                    Engineering Specs
                  </span>
                  <h3 className="text-xl font-bold tracking-tight text-white">
                    {selectedProduct.name}
                  </h3>
                </div>
                <button
                  onClick={() => setSelectedProduct(null)}
                  className="p-1.5 rounded-full hover:bg-white/5 text-neutral-400 hover:text-white transition-all border border-white/10"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Scrollable Content */}
              <div className="flex-grow overflow-y-auto p-6 space-y-8">
                
                {/* Product Cutout Image Showcase */}
                <div className="relative w-full h-[240px] bg-white rounded-xl overflow-hidden shadow-inner p-4 flex items-center justify-center">
                  <Image
                    src={selectedProduct.image}
                    alt={selectedProduct.name}
                    fill
                    className="object-contain p-4"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute bottom-4 right-4 bg-black/60 backdrop-blur-md text-white px-3 py-1 rounded-full text-xs font-mono font-bold tracking-wider">
                    £{selectedProduct.price}
                  </div>
                </div>

                {/* Narrative Description */}
                <div>
                  <h4 className="text-xs uppercase tracking-widest text-neutral-400 mb-2 font-semibold">
                    Core Mission
                  </h4>
                  <p className="text-sm text-neutral-300 leading-relaxed font-light">
                    {selectedProduct.description}
                  </p>
                  <p className="text-xs text-neutral-400 mt-4 leading-relaxed italic bg-white/5 p-3 rounded-lg border border-white/5">
                    <strong>Lead Engineer note:</strong> {selectedProduct.techDetails}
                  </p>
                </div>

                {/* Interactive Dynamic Colorway Picker */}
                <div>
                  <h4 className="text-xs uppercase tracking-widest text-neutral-400 mb-3 font-semibold">
                    Choose Engineering Colorway
                  </h4>
                  <div className="space-y-3">
                    <div className="flex gap-3">
                      {selectedProduct.colors.map((color, idx) => (
                        <button
                          key={color.name}
                          onClick={() => {
                            setSelectedColorIndex(idx);
                            triggerToast(`Switched colorway to ${color.name}.`);
                          }}
                          className={`p-1.5 rounded-lg border transition-all flex items-center gap-2 ${
                            selectedColorIndex === idx
                              ? 'border-white bg-white/10'
                              : 'border-white/10 bg-transparent hover:border-white/20'
                          }`}
                        >
                          <span
                            className="w-4 h-4 rounded-full border border-white/20 block"
                            style={{ backgroundColor: color.hex }}
                          />
                          <span className="text-xs font-semibold text-white">
                            {color.name}
                          </span>
                        </button>
                      ))}
                    </div>
                    {/* Selected Color details description */}
                    <div className="text-[11px] text-neutral-400 mt-2 bg-neutral-900/60 p-2 rounded-md">
                      {selectedProduct.colors[selectedColorIndex]?.desc}
                    </div>
                  </div>
                </div>

                {/* Technical Performance Metrics Specifications */}
                <div>
                  <h4 className="text-xs uppercase tracking-widest text-neutral-400 mb-4 font-semibold">
                    Performance Metrics Analysis
                  </h4>
                  <div className="space-y-3">
                    {selectedProduct.specs.map((spec, idx) => (
                      <div key={idx} className="space-y-1">
                        <div className="flex justify-between text-xs">
                          <span className="text-neutral-400">{spec.label}</span>
                          <span className="text-white font-mono font-medium">{spec.value}</span>
                        </div>
                        {/* Custom high-end linear progress meter */}
                        <div className="h-1.5 bg-neutral-800 rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: `${spec.percent}%` }}
                            transition={{ duration: 1, delay: 0.2 }}
                            className="h-full bg-gradient-to-r from-neutral-500 to-white"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Quality seal badge */}
                <div className="flex items-center gap-3 bg-neutral-900 border border-white/5 p-4 rounded-xl">
                  <Shield className="w-5 h-5 text-neutral-400" />
                  <div className="text-xs text-neutral-400">
                    <span className="text-white block font-semibold mb-0.5">Dyson 2-Year Guarantee</span>
                    Includes free shipping, 30-day trial returns, and dynamic parts backup support automatically.
                  </div>
                </div>

              </div>

              {/* Action purchase zone */}
              <div className="p-6 border-t border-white/5 bg-black/40 flex items-center justify-between gap-4">
                <div className="flex flex-col">
                  <span className="text-[10px] text-neutral-400 uppercase font-mono">Retail Value</span>
                  <span className="text-2xl font-light text-white font-mono">£{selectedProduct.price}</span>
                </div>
                <button
                  onClick={() => {
                    handleAddToCart(selectedProduct, selectedProduct.colors[selectedColorIndex].name);
                    setSelectedProduct(null);
                    setIsCartOpen(true);
                  }}
                  className="flex-grow px-6 py-3.5 bg-white text-black text-xs font-bold uppercase tracking-wider rounded-full hover:bg-neutral-100 active:scale-95 transition-all text-center flex items-center justify-center gap-2"
                >
                  Configure & Add to Bag
                  <ShoppingBag className="w-4 h-4" />
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>


      {/* INTERACTIVE COMPONENT 2: CUSTOM VIRTUAL AI ADVISOR MATCHING TOOL */}
      <AnimatePresence>
        {isAdvisorOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop scrim */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAdvisorOpen(false)}
              className="absolute inset-0 bg-black"
            />

            {/* Modal Dialog Container */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              transition={{ type: 'spring', damping: 25, stiffness: 250 }}
              className="relative w-full max-w-lg bg-[#0e0e0e] border border-white/10 rounded-2xl overflow-hidden shadow-2xl z-10 max-h-[90vh] flex flex-col"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/5 flex justify-between items-center bg-black/40">
                <div className="flex items-center gap-2 text-emerald-400">
                  <Sparkles className="w-5 h-5 animate-pulse" />
                  <div>
                    <span className="text-[10px] uppercase font-mono tracking-widest text-emerald-500 block">
                      Dyson Virtual Assistant
                    </span>
                    <h3 className="text-base font-bold text-white">
                      AI Engineering Matcher
                    </h3>
                  </div>
                </div>
                <button
                  onClick={() => setIsAdvisorOpen(false)}
                  className="p-1.5 rounded-full hover:bg-white/5 text-neutral-400 hover:text-white transition-all border border-white/10"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Dialog Wizard Content */}
              <div className="p-6 flex-grow overflow-y-auto space-y-6">
                
                {advisorStep === 1 && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-white">01. What is your primary lifestyle air concern?</h4>
                    <p className="text-xs text-neutral-400">Our engineering focuses heavily on biological particulate extraction.</p>
                    <div className="grid grid-cols-2 gap-3">
                      {['Allergies & Dust', 'Pet Hair & Odors', 'Cooking Fumes & Gases', 'General Airflow Cooling'].map((c) => (
                        <button
                          key={c}
                          onClick={() => {
                            setAdvisorAnswers({ ...advisorAnswers, concern: c });
                            setAdvisorStep(2);
                            triggerToast(`Concern set: ${c}`);
                          }}
                          className={`p-4 text-left border rounded-xl text-xs font-semibold transition-all ${
                            advisorAnswers.concern === c
                              ? 'border-white bg-white/5 text-white'
                              : 'border-white/5 hover:border-white/10 text-neutral-400'
                          }`}
                        >
                          {c}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {advisorStep === 2 && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-white">02. Select your hair care priority or goal:</h4>
                    <p className="text-xs text-neutral-400">We design thermal systems that regulate temperature under 150°C.</p>
                    <div className="grid grid-cols-2 gap-3">
                      {['Fine & Sensitive hair', 'Curly & Coarse hair', 'Smooth straight hair', 'None / Just home tech'].map((ht) => (
                        <button
                          key={ht}
                          onClick={() => {
                            setAdvisorAnswers({ ...advisorAnswers, hairType: ht });
                            setAdvisorStep(3);
                            triggerToast(`Hair Priority set: ${ht}`);
                          }}
                          className={`p-4 text-left border rounded-xl text-xs font-semibold transition-all ${
                            advisorAnswers.hairType === ht
                              ? 'border-white bg-white/5 text-white'
                              : 'border-white/5 hover:border-white/10 text-neutral-400'
                          }`}
                        >
                          {ht}
                        </button>
                      ))}
                    </div>
                    <button onClick={() => setAdvisorStep(1)} className="text-xs text-neutral-500 hover:text-white flex items-center gap-1 mt-2">
                      <RotateCcw className="w-3 h-3" /> Back
                    </button>
                  </div>
                )}

                {advisorStep === 3 && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-white">03. Describe your living quarters layout:</h4>
                    <p className="text-xs text-neutral-400">Helps determine proper projection flow-rates and runtimes.</p>
                    <div className="grid grid-cols-2 gap-3">
                      {['Apartment', 'Multi-Story House', 'Large Studio / Flat', 'Compact Studio'].map((l) => (
                        <button
                          key={l}
                          onClick={() => {
                            setAdvisorAnswers({ ...advisorAnswers, layout: l });
                            setAdvisorStep(4);
                            triggerToast(`Layout set: ${l}`);
                          }}
                          className={`p-4 text-left border rounded-xl text-xs font-semibold transition-all ${
                            advisorAnswers.layout === l
                              ? 'border-white bg-white/5 text-white'
                              : 'border-white/5 hover:border-white/10 text-neutral-400'
                          }`}
                        >
                          {l}
                        </button>
                      ))}
                    </div>
                    <button onClick={() => setAdvisorStep(2)} className="text-xs text-neutral-500 hover:text-white flex items-center gap-1 mt-2">
                      <RotateCcw className="w-3 h-3" /> Back
                    </button>
                  </div>
                )}

                {advisorStep === 4 && (
                  <div className="space-y-4">
                    <h4 className="text-sm font-semibold text-white">04. Which core engineering focus matters most?</h4>
                    <p className="text-xs text-neutral-400">Aligning with Dyson’s physical laboratories.</p>
                    <div className="grid grid-cols-2 gap-3">
                      {['Filtration Technology', 'Sleek Compact Size', 'Acoustics & Isolation', 'Automation & SLAM Maps'].map((tf) => (
                        <button
                          key={tf}
                          onClick={() => {
                            setAdvisorAnswers({ ...advisorAnswers, techFocus: tf });
                            triggerToast(`Engineering set: ${tf}`);
                          }}
                          className={`p-4 text-left border rounded-xl text-xs font-semibold transition-all ${
                            advisorAnswers.techFocus === tf
                              ? 'border-white bg-white/5 text-white'
                              : 'border-white/5 hover:border-white/10 text-neutral-400'
                          }`}
                        >
                          {tf}
                        </button>
                      ))}
                    </div>

                    <form onSubmit={handleAdvisorSubmit} className="pt-6 border-t border-white/5">
                      <button
                        type="submit"
                        disabled={isAdvisorLoading}
                        className="w-full py-3.5 bg-emerald-500 hover:bg-emerald-400 text-black text-xs font-bold uppercase tracking-wider rounded-full active:scale-95 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/10 disabled:opacity-50"
                      >
                        {isAdvisorLoading ? 'Analyzing Physical Parameters...' : 'Execute Dyson Analysis'}
                        <Sparkles className="w-4 h-4" />
                      </button>
                    </form>

                    <button onClick={() => setAdvisorStep(3)} className="text-xs text-neutral-500 hover:text-white flex items-center gap-1 mt-2">
                      <RotateCcw className="w-3 h-3" /> Back
                    </button>
                  </div>
                )}

                {/* STEP 5: RECOMMENDATION REPORT (GENERATED BY GEMINI API) */}
                {advisorStep === 5 && advisorResult && (
                  <div className="space-y-6">
                    
                    {/* Recommendation Badge Banner */}
                    <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl flex items-center justify-between">
                      <div>
                        <span className="text-[10px] uppercase font-mono tracking-widest text-emerald-400 font-semibold block">
                          AI Calibration Success
                        </span>
                        <h4 className="text-lg font-bold text-white mt-1">
                          {advisorResult.recommendedModel}
                        </h4>
                      </div>
                      <div className="bg-emerald-500/20 text-emerald-400 font-mono text-xs px-2.5 py-1.5 rounded border border-emerald-500/30">
                        {advisorResult.matchPercentage}% Match
                      </div>
                    </div>

                    {/* Product Recommendation Card */}
                    <div className="p-4 bg-white/5 rounded-xl border border-white/5 space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] text-neutral-400 font-mono">CATEGORY: {advisorResult.category}</span>
                        <Check className="w-4 h-4 text-emerald-400" />
                      </div>
                      
                      <div className="space-y-2">
                        <h5 className="text-xs uppercase tracking-widest text-neutral-400 font-semibold">Engineering Reasoning</h5>
                        <p className="text-xs text-neutral-300 leading-relaxed font-light">
                          {advisorResult.reasoning}
                        </p>
                      </div>

                      <div className="space-y-2 pt-2 border-t border-white/5">
                        <h5 className="text-xs uppercase tracking-widest text-neutral-400 font-semibold">Science & Integration</h5>
                        <p className="text-xs text-neutral-300 leading-relaxed font-light">
                          {advisorResult.techIntegration}
                        </p>
                      </div>

                      <div className="space-y-2 pt-2 border-t border-white/5 bg-emerald-500/5 p-3 rounded">
                        <h5 className="text-xs uppercase tracking-widest text-emerald-400 font-semibold font-mono">Expert Usage Tip</h5>
                        <p className="text-xs text-neutral-300 leading-relaxed font-light">
                          {advisorResult.customTip}
                        </p>
                      </div>
                    </div>

                    {/* Direct Quick Add CTA */}
                    <div className="flex items-center gap-3">
                      <button
                        onClick={() => {
                          const matchedCategory = PRODUCTS.find(p => p.category === advisorResult.category) || PRODUCTS[0];
                          handleAddToCart(matchedCategory, matchedCategory.colors[0].name);
                          setIsAdvisorOpen(false);
                          setIsCartOpen(true);
                        }}
                        className="flex-grow py-3.5 bg-white text-black text-xs font-bold uppercase tracking-wider rounded-full hover:bg-neutral-100 transition-all flex items-center justify-center gap-2"
                      >
                        Add Match to Bag
                        <ShoppingBag className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          setAdvisorStep(1);
                          setAdvisorResult(null);
                        }}
                        className="px-4 py-3.5 border border-white/10 hover:border-white text-white rounded-full transition-all text-xs uppercase tracking-wider"
                      >
                        Reset
                      </button>
                    </div>

                  </div>
                )}

              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>


      {/* INTERACTIVE COMPONENT 3: SHOPPING DRAWER / CART CONTROL */}
      <AnimatePresence>
        {isCartOpen && (
          <div className="fixed inset-0 z-50 flex justify-end">
            {/* Backdrop scrim */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.6 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsCartOpen(false)}
              className="absolute inset-0 bg-black"
            />

            {/* Sliding Drawer Container */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 220 }}
              className="relative w-full max-w-md h-full bg-[#0e0e0e] border-l border-white/10 flex flex-col justify-between shadow-2xl z-10"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/5 flex justify-between items-center bg-black/40">
                <div className="flex items-center gap-2">
                  <ShoppingBag className="w-5 h-5 text-white" />
                  <h3 className="text-lg font-bold text-white tracking-tight">
                    Your Shopping Bag
                  </h3>
                </div>
                <button
                  onClick={() => setIsCartOpen(false)}
                  className="p-1.5 rounded-full hover:bg-white/5 text-neutral-400 hover:text-white transition-all border border-white/10"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Scrollable Cart List */}
              <div className="flex-grow overflow-y-auto p-6 space-y-6">
                {cart.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
                    <ShoppingBag className="w-12 h-12 text-neutral-700 stroke-[1.5]" />
                    <div>
                      <h4 className="text-sm font-semibold text-white">Your bag is empty</h4>
                      <p className="text-xs text-neutral-500 mt-1 max-w-xs">
                        Configure the latest Dyson purifiers, vacuums, or styling machines to begin.
                      </p>
                    </div>
                    <button
                      onClick={() => {
                        setIsCartOpen(false);
                        const element = document.getElementById('products-section');
                        element?.scrollIntoView({ behavior: 'smooth' });
                      }}
                      className="px-6 py-3 border border-white/10 hover:border-white text-xs font-semibold uppercase tracking-wider rounded-full transition-all"
                    >
                      Browse Engineering
                    </button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {cart.map((item, idx) => (
                      <div key={idx} className="flex gap-4 p-4 bg-white/5 rounded-xl border border-white/5 relative">
                        {/* Thumbnail image */}
                        <div className="relative w-20 h-20 bg-white rounded-lg flex items-center justify-center overflow-hidden p-1 shrink-0">
                          <Image
                            src={item.product.image}
                            alt={item.product.name}
                            fill
                            className="object-contain"
                            referrerPolicy="no-referrer"
                          />
                        </div>

                        {/* Content */}
                        <div className="flex-grow flex flex-col justify-between">
                          <div>
                            <div className="flex justify-between">
                              <h4 className="text-xs font-semibold text-white leading-tight">
                                {item.product.name}
                              </h4>
                              <span className="text-xs font-mono font-bold text-white">
                                £{item.product.price * item.quantity}
                              </span>
                            </div>
                            <span className="text-[10px] text-neutral-400 uppercase font-mono block mt-1">
                              Color: {item.selectedColor}
                            </span>
                          </div>

                          {/* Control row */}
                          <div className="flex justify-between items-center mt-3">
                            <div className="flex items-center gap-1.5 bg-neutral-900 border border-white/5 rounded-lg px-2 py-1">
                              <button
                                onClick={() => handleUpdateQuantity(item.product.id, item.selectedColor, -1)}
                                className="p-0.5 rounded text-neutral-400 hover:text-white"
                              >
                                <Minus className="w-3 h-3" />
                              </button>
                              <span className="text-xs font-mono font-semibold px-1 min-w-[16px] text-center">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => handleUpdateQuantity(item.product.id, item.selectedColor, 1)}
                                className="p-0.5 rounded text-neutral-400 hover:text-white"
                              >
                                <Plus className="w-3 h-3" />
                              </button>
                            </div>

                            <button
                              onClick={() => handleRemoveFromCart(item.product.id, item.selectedColor)}
                              className="p-1 hover:text-rose-400 text-neutral-500 transition-colors"
                              aria-label="Remove item"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Shipping Milestone & Summary Checkout */}
              {cart.length > 0 && (
                <div className="p-6 border-t border-white/5 bg-black/40 space-y-6">
                  
                  {/* Delivery Milestone Progress Bar */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[11px] text-neutral-400">
                      <span>Delivery Milestones</span>
                      <span className="text-emerald-400 font-semibold font-mono">Free White-Glove Shipping</span>
                    </div>
                    <div className="h-1 bg-neutral-800 rounded-full overflow-hidden">
                      <div className="h-full bg-emerald-500 w-full" />
                    </div>
                  </div>

                  {/* Pricing Subtotal */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs text-neutral-400">
                      <span>Subtotal</span>
                      <span className="font-mono text-white">£{cartSubtotal}</span>
                    </div>
                    <div className="flex justify-between text-xs text-neutral-400">
                      <span>Express Shipping</span>
                      <span className="text-emerald-400 uppercase font-mono font-semibold text-[10px]">Free</span>
                    </div>
                    <div className="flex justify-between text-xs text-neutral-400">
                      <span>Taxes (VAT)</span>
                      <span className="font-mono text-white">Included</span>
                    </div>
                    <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-white/5">
                      <span>Total Amount</span>
                      <span className="font-mono">£{cartSubtotal}</span>
                    </div>
                  </div>

                  {/* Checkout Actions */}
                  <button
                    onClick={() => {
                      triggerToast('Processing Secure Checkout securely...');
                      setCart([]);
                      setIsCartOpen(false);
                      triggerToast('Order Submitted Successfully! Thank you for purchasing from Dyson.');
                    }}
                    className="w-full py-3.5 bg-white text-black hover:bg-neutral-100 text-xs font-bold uppercase tracking-wider rounded-full active:scale-95 transition-all text-center flex items-center justify-center gap-2 shadow-lg"
                  >
                    Proceed to Secure Checkout
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              )}

            </motion.div>
          </div>
        )}
      </AnimatePresence>


      {/* INTERACTIVE COMPONENT 4: IMMERSIVE BENTO CARD OVERLAY WRITEUPS */}
      <AnimatePresence>
        {activeBentoStory && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            {/* Backdrop scrim */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.8 }}
              exit={{ opacity: 0 }}
              onClick={() => setActiveBentoStory(null)}
              className="absolute inset-0 bg-black/95"
            />

            {/* Stories card details panel */}
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="relative w-full max-w-2xl bg-[#0d0d0d] border border-white/10 rounded-2xl overflow-hidden shadow-2xl z-10"
            >
              <div className="relative h-64 md:h-80">
                <Image
                  src={activeBentoStory.image}
                  alt={activeBentoStory.title}
                  fill
                  className="object-cover brightness-75"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0d0d0d] via-transparent to-transparent" />
                <button
                  onClick={() => setActiveBentoStory(null)}
                  className="absolute top-4 right-4 p-1.5 rounded-full bg-black/60 backdrop-blur-md text-white hover:opacity-85 border border-white/10 transition-all z-20"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              <div className="p-6 md:p-8 space-y-4">
                <span className="text-[9px] uppercase tracking-widest font-mono text-neutral-400 block border-b border-white/5 pb-2">
                  Dyson Engineering Dossier
                </span>
                <h3 className="text-xl md:text-2xl font-light tracking-tight text-white">
                  {activeBentoStory.title}
                </h3>
                <p className="text-sm text-neutral-300 leading-relaxed font-light">
                  {activeBentoStory.content}
                </p>
                
                <div className="pt-6">
                  <button
                    onClick={() => setActiveBentoStory(null)}
                    className="px-6 py-2.5 bg-white text-black text-xs font-semibold uppercase tracking-wider rounded-full hover:bg-neutral-100 transition-all"
                  >
                    Conclude Reading
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>


      {/* INTERACTIVE COMPONENT 5: SEARCH FILTER DRAWER */}
      <AnimatePresence>
        {isSearchOpen && (
          <div className="fixed inset-0 z-50 flex flex-col justify-start">
            {/* Backdrop scrim */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsSearchOpen(false)}
              className="absolute inset-0 bg-black"
            />

            {/* Search Input Panel */}
            <motion.div
              initial={{ y: '-100%' }}
              animate={{ y: 0 }}
              exit={{ y: '-100%' }}
              transition={{ type: 'spring', damping: 20 }}
              className="relative w-full bg-[#0d0d0d] border-b border-white/10 p-6 md:py-10 z-10 shadow-2xl flex flex-col items-center justify-center"
            >
              <div className="w-full max-w-2xl space-y-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-[10px] font-mono uppercase tracking-widest text-neutral-400">Search Products & Engineering</span>
                  <button
                    onClick={() => setIsSearchOpen(false)}
                    className="p-1 rounded-full bg-white/5 border border-white/5 text-neutral-400 hover:text-white"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>

                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-neutral-400 pointer-events-none" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search e.g. Air Purifier, HEPA, Cordless Vacuums..."
                    className="w-full bg-neutral-900 border border-white/10 focus:border-white focus:outline-none rounded-full py-3.5 pl-12 pr-6 text-sm text-white placeholder-neutral-500 font-light transition-colors"
                    autoFocus
                  />
                </div>

                {/* Filter Results Dropdown */}
                {searchQuery.trim() !== '' && (
                  <div className="bg-neutral-900/90 rounded-2xl p-4 border border-white/5 space-y-2 max-h-[300px] overflow-y-auto">
                    {filteredProducts.length === 0 ? (
                      <div className="text-xs text-neutral-500 py-4 text-center">
                        No Dyson technologies match &ldquo;{searchQuery}&rdquo;. Try another term.
                      </div>
                    ) : (
                      filteredProducts.map((prod) => (
                        <div
                          key={prod.id}
                          onClick={() => {
                            setSelectedProduct(prod);
                            setSelectedColorIndex(0);
                            setIsSearchOpen(false);
                            setSearchQuery('');
                          }}
                          className="p-3 bg-transparent hover:bg-white/5 rounded-lg flex items-center justify-between cursor-pointer border-b border-white/5 transition-all group"
                        >
                          <div className="flex items-center gap-3">
                            <div className="relative w-10 h-10 bg-white rounded-md overflow-hidden p-0.5">
                              <Image
                                src={prod.image}
                                alt={prod.name}
                                fill
                                className="object-contain"
                                referrerPolicy="no-referrer"
                              />
                            </div>
                            <div>
                              <h5 className="text-xs font-bold text-white group-hover:text-neutral-200">{prod.name}</h5>
                              <p className="text-[10px] text-neutral-400">{prod.headline}</p>
                            </div>
                          </div>
                          <ArrowRight className="w-3.5 h-3.5 text-neutral-500 group-hover:text-white transform group-hover:translate-x-1 transition-all" />
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>


      {/* INTERACTIVE COMPONENT 6: TOAST NOTIFICATION BANNER */}
      <AnimatePresence>
        {toast?.show && (
          <motion.div
            initial={{ opacity: 0, y: 30, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-50 bg-[#121212] border border-white/10 rounded-xl px-5 py-3 shadow-2xl flex items-center gap-3 max-w-sm"
          >
            <div className="bg-white/5 p-1.5 rounded-lg border border-white/10 text-white">
              <Info className="w-4.5 h-4.5" />
            </div>
            <div className="flex-grow">
              <span className="text-[10px] uppercase font-mono tracking-wider text-neutral-400 block font-semibold mb-0.5">Dyson Telemetry</span>
              <p className="text-xs text-neutral-300 font-light">{toast.message}</p>
            </div>
            <button
              onClick={() => setToast(null)}
              className="text-neutral-500 hover:text-white p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
