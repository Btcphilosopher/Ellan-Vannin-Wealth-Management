import type {Metadata} from 'next';
import { Plus_Jakarta_Sans } from 'next/font/google';
import './globals.css'; // Global styles

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  weight: ['300', '400', '500', '600', '700'],
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Dyson | Next-Generation Home Engineering & Air Care',
  description: 'Experience the future of home engineering. Interactive Dyson product discoveries, digital motor aerodynamic simulations, customized virtual advisor, and elegant design.',
  openGraph: {
    title: 'Dyson | Next-Generation Home Engineering & Air Care',
    description: 'Experience the future of home engineering. Interactive Dyson product discoveries, digital motor aerodynamic simulations, customized virtual advisor, and elegant design.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Dyson | Next-Generation Home Engineering & Air Care',
    description: 'Experience the future of home engineering. Interactive Dyson product discoveries, digital motor aerodynamic simulations, customized virtual advisor, and elegant design.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className="scroll-smooth">
      <body className={`${plusJakarta.className} bg-[#0b0b0b] text-white antialiased selection:bg-neutral-800 selection:text-white`} suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
