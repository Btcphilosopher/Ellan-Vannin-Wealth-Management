import { GoogleGenAI, Type } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";

// Initialize Gemini SDK with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { concern, hairType, layout, techFocus } = await req.json();

    const prompt = `You are the lead engineering advisor at Dyson. Based on the user's living conditions and desires, recommend the absolute best Dyson product and provide custom technical advice.
    
    User Parameters:
    - Primary Home/Air Concern: ${concern}
    - Hair Type/Interest: ${hairType}
    - Home Layout/Size: ${layout}
    - Technical/Engineering Focus: ${techFocus}

    Your response must be in JSON format matching the following schema. Keep descriptions concise, luxurious, engineering-minded, and direct. Do not mention any competitor products.

    Schema:
    {
      "category": "Air Purifiers" | "Cordless Vacuums" | "Hair Care" | "Hair Styling" | "Robot Vacuums",
      "recommendedModel": "Specific actual high-end Dyson product model (e.g. Dyson Purifier Cool Gen1, Dyson Gen5detect™, Dyson Supersonic Nural™, Dyson Airwrap™ Multi-styler, Dyson 360 Vis Nav™)",
      "reasoning": "A highly persuasive, professional explanation (max 3 sentences) in Dyson's brand voice (focused on science, design, and problem-solving).",
      "techIntegration": "Explain how the specified technology (e.g., HEPA H13 filtration, Acoustic Tuning, Radial Root Cyclone, digital motor V9) works to solve their precise problem.",
      "customTip": "An exclusive, high-value maintenance or usage tip for maximizing this machine's performance.",
      "matchPercentage": number between 85 and 99
    }`;

    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            category: {
              type: Type.STRING,
              description: "The main category of the recommended product."
            },
            recommendedModel: {
              type: Type.STRING,
              description: "The exact name of the Dyson model."
            },
            reasoning: {
              type: Type.STRING,
              description: "Elegant professional reasoning behind the recommendation."
            },
            techIntegration: {
              type: Type.STRING,
              description: "How the physics/engineering of the machine addresses the user's concerns."
            },
            customTip: {
              type: Type.STRING,
              description: "A professional tip for operation or care."
            },
            matchPercentage: {
              type: Type.INTEGER,
              description: "A calculated match score out of 100 based on the fit."
            }
          },
          required: ["category", "recommendedModel", "reasoning", "techIntegration", "customTip", "matchPercentage"]
        }
      }
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error("No response generated from Gemini API.");
    }

    const data = JSON.parse(resultText.trim());
    return NextResponse.json(data);
  } catch (error: any) {
    console.error("Gemini Recommendation Error:", error);
    return NextResponse.json({
      error: true,
      message: error.message || "Failed to generate personalized Dyson recommendation."
    }, { status: 500 });
  }
}
