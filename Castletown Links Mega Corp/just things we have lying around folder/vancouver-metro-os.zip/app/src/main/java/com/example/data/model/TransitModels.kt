package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// Station / Stop model
data class Station(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val lines: List<String>,
    val accessibility: String = "Step-free Access",
    val elevators: Int = 1,
    val bikeFacilities: String = "Standard Bike Racks",
    val municipality: String = "Vancouver"
)

// Active Route model
data class TransitRoute(
    val id: String,
    val name: String,
    val mode: String, // SkyTrain, Bus, SeaBus, CommuterRail
    val color: String, // Hex color string
    val frequencyMin: Double,
    val stations: List<String>,
    val status: String = "Normal Service"
)

// Real-time Vehicle position model
data class VehiclePosition(
    val vehicleId: String,
    val routeId: String,
    val latitude: Double,
    val longitude: Double,
    val currentStopId: String,
    val nextStopId: String,
    val progress: Float, // 0.0f to 1.0f
    val delaySec: Int,
    val timestamp: Long,
    val source: String = "GTFS-Realtime"
)

// Departure Board Item model
data class Departure(
    val lineName: String,
    val destination: String,
    val scheduledMin: Int,
    val estimatedMin: Int,
    val delayMin: Int,
    val status: String, // Scheduled, Estimated, Realtime
    val isAccessible: Boolean = true
)

// Service Alert model
data class ServiceAlert(
    val id: String,
    val severity: String, // INFO, WARNING, CRITICAL
    val title: String,
    val description: String,
    val affectedRoutes: List<String>,
    val affectedStops: List<String>,
    val start: String,
    val end: String,
    val source: String = "TransLink Feed"
)

// Journey Leg (multimodal path piece)
data class JourneyLeg(
    val mode: String, // walk, skytrain, bus, seabus, rail
    val type: String, // walk, ride, transfer, board, alight
    val routeId: String,
    val fromNodeId: String,
    val fromNodeName: String,
    val toNodeId: String,
    val toNodeName: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMin: Double,
    val distanceMeters: Double
)

// Multi-modal planned journey response
data class JourneyPlan(
    val originName: String,
    val destinationName: String,
    val startTime: String,
    val endTime: String,
    val durationMin: Double,
    val walkingTimeMin: Double,
    val waitingTimeMin: Double,
    val transitTimeMin: Double,
    val transfers: Int,
    val distanceMeters: Double,
    val legs: List<JourneyLeg>,
    val provenance: String = "Metro Vancouver OS Routing Engine"
)

// Room Entity for saved Favourites
@Entity(tableName = "favourites")
data class Favourite(
    @PrimaryKey val id: String,
    val name: String,
    val type: String, // station, route, journey
    val detail: String = "" // Line info or destination
)

// Room Entity for Recent Journeys
@Entity(tableName = "recent_journeys")
data class RecentJourney(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originId: String,
    val originName: String,
    val destinationId: String,
    val destinationName: String,
    val timestamp: Long = System.currentTimeMillis()
)
