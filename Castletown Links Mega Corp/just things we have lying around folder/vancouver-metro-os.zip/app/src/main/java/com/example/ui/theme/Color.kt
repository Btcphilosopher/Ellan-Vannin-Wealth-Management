package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Infrastructure Dark Theme Colors
val VancouverPrimaryDark = Color(0xFF102A43) // Deep Ocean Blue
val VancouverSecondaryDark = Color(0xFF243B53) // Muted Slate
val VancouverBackgroundDark = Color(0xFF0F172A) // Slate-900 (Night Sky)
val VancouverSurfaceDark = Color(0xFF1E293B) // Slate-800
val VancouverAccentBlue = Color(0xFF38BDF8) // High-visibility Cyan

// Transit Line Colors
val ColorExpoLine = Color(0xFF003893)      // Expo Blue
val ColorMillenniumLine = Color(0xFFF9A825) // Millennium Gold
val ColorCanadaLine = Color(0xFF0083B0)     // Canada Cyan
val ColorSeaBus = Color(0xFF005C8A)         // SeaBus Teal
val ColorBusRapid = Color(0xFFEF6C00)       // RapidBus Orange
val ColorWestCoastExpress = Color(0xFF8B0000)// WCE Crimson

// Status indicators
val ColorOnTime = Color(0xFF22C55E)  // Green
val ColorDelayed = Color(0xFFEF4444) // Red
val ColorWarning = Color(0xFFF59E0B) // Amber
val ColorWalk = Color(0xFF64748B)    // Gray
