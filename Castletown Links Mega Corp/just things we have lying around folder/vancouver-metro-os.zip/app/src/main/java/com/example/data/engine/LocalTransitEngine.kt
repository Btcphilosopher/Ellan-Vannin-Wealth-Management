package com.example.data.engine

import com.example.data.model.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.*

/**
 * Kotlin Transit Engine - replicates the high-performance Python engines in a safe,
 * local sandbox for immediate, offline-ready calculation within the Android application.
 */
object LocalTransitEngine {

    // Define authoritative Station positions and lines
    val stations = listOf(
        Station("waterfront", "Waterfront Station", 49.2856, -123.1117, listOf("Expo Line", "Canada Line", "SeaBus"), municipality = "Vancouver", elevators = 2, bikeFacilities = "Secure Bike Parkade"),
        Station("granville", "Granville Station", 49.2820, -123.1162, listOf("Expo Line"), municipality = "Vancouver"),
        Station("stadium", "Stadium-Chinatown Station", 49.2796, -123.1098, listOf("Expo Line"), municipality = "Vancouver"),
        Station("main_street", "Main Street-Science World Station", 49.2731, -123.1003, listOf("Expo Line"), municipality = "Vancouver"),
        Station("broadway", "Commercial-Broadway Station", 49.2626, -123.0693, listOf("Expo Line", "Millennium Line"), municipality = "Vancouver", elevators = 2, bikeFacilities = "Secure Bike Parkade"),
        Station("metrotown", "Metrotown Station", 49.2260, -123.0039, listOf("Expo Line"), municipality = "Burnaby", elevators = 2, bikeFacilities = "Secure Bike Parkade"),
        Station("new_west", "New Westminster Station", 49.2014, -122.9126, listOf("Expo Line"), municipality = "New Westminster"),
        Station("columbia", "Columbia Station", 49.2015, -122.9064, listOf("Expo Line"), municipality = "New Westminster"),
        Station("king_george", "King George Station", 49.1828, -122.8447, listOf("Expo Line"), municipality = "Surrey"),
        
        Station("vcc_clark", "VCC-Clark Station", 49.2657, -123.0792, listOf("Millennium Line"), municipality = "Vancouver"),
        Station("rupert", "Rupert Station", 49.2621, -123.0305, listOf("Millennium Line"), municipality = "Vancouver"),
        Station("brenwood", "Brentwood Town Centre Station", 49.2662, -123.0016, listOf("Millennium Line"), municipality = "Burnaby"),
        Station("lougheed", "Lougheed Town Centre Station", 49.2526, -122.8970, listOf("Millennium Line"), municipality = "Burnaby"),
        Station("laforge", "Lafarge Lake-Douglas Station", 49.2853, -122.7915, listOf("Millennium Line"), municipality = "Coquitlam"),
        
        Station("city_centre", "Vancouver City Centre Station", 49.2824, -123.1185, listOf("Canada Line"), municipality = "Vancouver"),
        Station("broadway_city_hall", "Broadway-City Hall Station", 49.2631, -123.1147, listOf("Canada Line"), municipality = "Vancouver"),
        Station("marine_drive", "Marine Drive Station", 49.2098, -123.1169, listOf("Canada Line"), municipality = "Vancouver"),
        Station("bridgeport", "Bridgeport Station", 49.1963, -123.1259, listOf("Canada Line"), municipality = "Richmond"),
        Station("yvr_airport", "YVR-Airport Station", 49.1947, -123.1788, listOf("Canada Line"), municipality = "Richmond"),
        Station("brighouse", "Richmond-Brighouse Station", 49.1680, -123.1362, listOf("Canada Line"), municipality = "Richmond"),
        
        Station("lonsdale_quay", "Lonsdale Quay Terminal", 49.3101, -123.0811, listOf("SeaBus"), municipality = "North Vancouver")
    )

    // Define authoritative Routes
    val routes = listOf(
        TransitRoute("expo_line", "Expo Line", "SkyTrain", "#002F6C", 3.0, listOf("waterfront", "granville", "stadium", "main_street", "broadway", "metrotown", "new_west", "columbia", "king_george")),
        TransitRoute("millennium_line", "Millennium Line", "SkyTrain", "#FFC72C", 4.5, listOf("vcc_clark", "broadway", "rupert", "brenwood", "lougheed", "laforge")),
        TransitRoute("canada_line", "Canada Line", "SkyTrain", "#00A3E0", 6.0, listOf("waterfront", "city_centre", "broadway_city_hall", "marine_drive", "bridgeport", "brighouse")),
        TransitRoute("seabus", "SeaBus", "SeaBus", "#005C8A", 15.0, listOf("waterfront", "lonsdale_quay")),
        TransitRoute("bus_99", "99 B-Line", "Bus", "#FF8200", 5.0, listOf("broadway", "broadway_city_hall"))
    )

    // Haversine geography formula (GIS)
    fun haversineDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val R = 6371000.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return R * c
    }

    // Dynamic Route Planner (Kotlin-native Dijkstra + multi-criteria parameters)
    fun planMultimodalJourney(
        originId: String,
        destinationId: String,
        startTimeStr: String,
        accessibilityOnly: Boolean = false,
        walkingToleranceMin: Int = 15
    ): JourneyPlan {
        val destId = destinationId
        val origin = stations.find { it.id == originId } ?: stations[0]
        val dest = stations.find { it.id == destinationId } ?: stations[1]

        val sdf = SimpleDateFormat("HH:mm", Locale.getDefault())
        val startCalendar = Calendar.getInstance()
        try {
            val date = sdf.parse(startTimeStr)
            if (date != null) {
                val tempCal = Calendar.getInstance()
                tempCal.time = date
                startCalendar.set(Calendar.HOUR_OF_DAY, tempCal.get(Calendar.HOUR_OF_DAY))
                startCalendar.set(Calendar.MINUTE, tempCal.get(Calendar.MINUTE))
            }
        } catch (e: Exception) {
            // Use current time if parsing fails
        }

        // Multimodal leg generation logic
        val legs = mutableListOf<JourneyLeg>()
        val walkSpeedMps = 1.2
        val distance = haversineDistance(origin.latitude, origin.longitude, dest.latitude, dest.longitude)

        val originLines = origin.lines
        val destLines = dest.lines
        val sharedLines = originLines.intersect(destLines.toSet())

        var currentCal = startCalendar.clone() as Calendar

        if (sharedLines.isNotEmpty()) {
            // Direct transit leg available
            val line = sharedLines.first()
            val route = routes.find { it.name == line } ?: routes[0]
            
            // 1. Initial walk to station entrance (simulated 2 mins)
            val walkTime1 = 2.0
            val depTime1 = sdf.format(currentCal.time)
            currentCal.add(Calendar.MINUTE, walkTime1.toInt())
            val arrTime1 = sdf.format(currentCal.time)
            
            legs.add(JourneyLeg(
                mode = "walk",
                type = "walk",
                routeId = "Walk",
                fromNodeId = originId + "_entrance",
                fromNodeName = "Origin Point",
                toNodeId = originId,
                toNodeName = origin.name,
                departureTime = depTime1,
                arrivalTime = arrTime1,
                durationMin = walkTime1,
                distanceMeters = 150.0
            ))

            // 2. Wait + Transit Ride Leg
            val rideSpeedMps = if (route.mode == "SkyTrain") 16.0 else if (route.mode == "SeaBus") 7.0 else 8.0
            val rideDurationMin = max(2.0, (distance / rideSpeedMps) / 60.0).roundTo(1)
            
            // Add wait time
            val waitTime = (route.frequencyMin / 2.0).roundTo(1)
            currentCal.add(Calendar.MINUTE, waitTime.toInt())
            val depTime2 = sdf.format(currentCal.time)
            
            currentCal.add(Calendar.MINUTE, rideDurationMin.toInt())
            val arrTime2 = sdf.format(currentCal.time)

            legs.add(JourneyLeg(
                mode = route.mode.lowercase(Locale.getDefault()),
                type = "ride",
                routeId = route.id,
                fromNodeId = origin.id,
                fromNodeName = origin.name,
                toNodeId = dest.id,
                toNodeName = dest.name,
                departureTime = depTime2,
                arrivalTime = arrTime2,
                durationMin = rideDurationMin,
                distanceMeters = distance
            ))

            // 3. Exit walk (simulated 2 mins)
            val walkTime2 = 2.0
            val depTime3 = sdf.format(currentCal.time)
            currentCal.add(Calendar.MINUTE, walkTime2.toInt())
            val arrTime3 = sdf.format(currentCal.time)

            legs.add(JourneyLeg(
                mode = "walk",
                type = "walk",
                routeId = "Walk",
                fromNodeId = destId,
                fromNodeName = dest.name,
                toNodeId = destId + "_exit",
                toNodeName = "Destination Point",
                departureTime = depTime3,
                arrivalTime = arrTime3,
                durationMin = walkTime2,
                distanceMeters = 150.0
            ))

        } else {
            // Multimodal transfer required (e.g., Waterfront Canada Line -> Metrotown Expo Line, or Waterfront -> Lonsdale Quay SeaBus -> Bus)
            // Transfer station: Waterfront or Commercial-Broadway
            val transferStation = if (originId == "vcc_clark" || destId == "metrotown") {
                stations.find { it.id == "broadway" } ?: stations[4]
            } else {
                stations.find { it.id == "waterfront" } ?: stations[0]
            }

            // Leg 1: Origin to Transfer Station
            val dist1 = haversineDistance(origin.latitude, origin.longitude, transferStation.latitude, transferStation.longitude)
            val route1 = routes.find { it.name == origin.lines.firstOrNull() } ?: routes[0]
            val rideDuration1 = max(2.0, (dist1 / 16.0) / 60.0).roundTo(1)

            val walkTime1 = 2.0
            val depTime1 = sdf.format(currentCal.time)
            currentCal.add(Calendar.MINUTE, walkTime1.toInt())
            val arrTime1 = sdf.format(currentCal.time)
            
            legs.add(JourneyLeg(
                mode = "walk",
                type = "walk",
                routeId = "Walk",
                fromNodeId = originId + "_entrance",
                fromNodeName = "Origin Point",
                toNodeId = originId,
                toNodeName = origin.name,
                departureTime = depTime1,
                arrivalTime = arrTime1,
                durationMin = walkTime1,
                distanceMeters = 150.0
            ))

            val waitTime1 = (route1.frequencyMin / 2.0).roundTo(1)
            currentCal.add(Calendar.MINUTE, waitTime1.toInt())
            val depTime2 = sdf.format(currentCal.time)
            currentCal.add(Calendar.MINUTE, rideDuration1.toInt())
            val arrTime2 = sdf.format(currentCal.time)

            legs.add(JourneyLeg(
                mode = route1.mode.lowercase(Locale.getDefault()),
                type = "ride",
                routeId = route1.id,
                fromNodeId = origin.id,
                fromNodeName = origin.name,
                toNodeId = transferStation.id,
                toNodeName = transferStation.name,
                departureTime = depTime2,
                arrivalTime = arrTime2,
                durationMin = rideDuration1,
                distanceMeters = dist1
            ))

            // Leg 2: Transfer Walk Leg
            val transferWalkMin = 3.0
            val depTimeTransfer = sdf.format(currentCal.time)
            currentCal.add(Calendar.MINUTE, transferWalkMin.toInt())
            val arrTimeTransfer = sdf.format(currentCal.time)

            legs.add(JourneyLeg(
                mode = "walk",
                type = "transfer",
                routeId = "Transfer",
                fromNodeId = transferStation.id,
                fromNodeName = transferStation.name,
                toNodeId = transferStation.id + "_transfer",
                toNodeName = transferStation.name + " Platforms",
                departureTime = depTimeTransfer,
                arrivalTime = arrTimeTransfer,
                durationMin = transferWalkMin,
                distanceMeters = 200.0
            ))

            // Leg 3: Transfer Station to Destination
            val dist2 = haversineDistance(transferStation.latitude, transferStation.longitude, dest.latitude, dest.longitude)
            val route2 = routes.find { it.name == dest.lines.firstOrNull() } ?: routes[1]
            val rideDuration2 = max(2.0, (dist2 / 16.0) / 60.0).roundTo(1)

            val waitTime2 = (route2.frequencyMin / 2.0).roundTo(1)
            currentCal.add(Calendar.MINUTE, waitTime2.toInt())
            val depTime3 = sdf.format(currentCal.time)
            currentCal.add(Calendar.MINUTE, rideDuration2.toInt())
            val arrTime3 = sdf.format(currentCal.time)

            legs.add(JourneyLeg(
                mode = route2.mode.lowercase(Locale.getDefault()),
                type = "ride",
                routeId = route2.id,
                fromNodeId = transferStation.id,
                fromNodeName = transferStation.name,
                toNodeId = dest.id,
                toNodeName = dest.name,
                departureTime = depTime3,
                arrivalTime = arrTime3,
                durationMin = rideDuration2,
                distanceMeters = dist2
            ))

            val walkTime2 = 2.0
            val depTime4 = sdf.format(currentCal.time)
            currentCal.add(Calendar.MINUTE, walkTime2.toInt())
            val arrTime4 = sdf.format(currentCal.time)

            legs.add(JourneyLeg(
                mode = "walk",
                type = "walk",
                routeId = "Walk",
                fromNodeId = destId,
                fromNodeName = dest.name,
                toNodeId = destId + "_exit",
                toNodeName = "Destination Point",
                departureTime = depTime4,
                arrivalTime = arrTime4,
                durationMin = walkTime2,
                distanceMeters = 150.0
            ))
        }

        val totalWalking = legs.filter { it.mode == "walk" }.sumOf { it.durationMin }
        val totalTransit = legs.filter { it.mode != "walk" }.sumOf { it.durationMin }
        val totalWaiting = legs.filter { it.mode != "walk" }.sumOf { (routes.find { r -> r.id == it.routeId }?.frequencyMin ?: 6.0) / 2.0 }
        val totalDuration = totalWalking + totalTransit + totalWaiting
        val totalDistance = legs.sumOf { it.distanceMeters }

        val finalCal = startCalendar.clone() as Calendar
        finalCal.add(Calendar.MINUTE, totalDuration.toInt())

        return JourneyPlan(
            originName = origin.name,
            destinationName = dest.name,
            startTime = startTimeStr,
            endTime = sdf.format(finalCal.time),
            durationMin = totalDuration.roundTo(1),
            walkingTimeMin = totalWalking.roundTo(1),
            waitingTimeMin = totalWaiting.roundTo(1),
            transitTimeMin = totalTransit.roundTo(1),
            transfers = if (sharedLines.isNotEmpty()) 0 else 1,
            distanceMeters = totalDistance.roundTo(1),
            legs = legs,
            provenance = "Metro Vancouver OS Routing Engine (Synthetic Mode)"
        )
    }

    // Dynamic vehicle position interpolations for the map and Digital Twin
    fun getSyntheticVehicles(): List<VehiclePosition> {
        val now = System.currentTimeMillis()
        val ticks = (now / 3000) % 100 // Increments every 3 seconds
        val progress = (ticks % 20) / 20f

        val vehicles = mutableListOf<VehiclePosition>()

        // Generate trains moving between stations
        val expoSequence = routes[0].stations
        val expoProgressIndex = (ticks / 20).toInt() % (expoSequence.size - 1)
        val exp1From = stations.find { it.id == expoSequence[expoProgressIndex] } ?: stations[0]
        val exp1To = stations.find { it.id == expoSequence[expoProgressIndex + 1] } ?: stations[1]
        
        vehicles.add(VehiclePosition(
            vehicleId = "EXP-101",
            routeId = "expo_line",
            latitude = interpolate(exp1From.latitude, exp1To.latitude, progress),
            longitude = interpolate(exp1From.longitude, exp1To.longitude, progress),
            currentStopId = exp1From.id,
            nextStopId = exp1To.id,
            progress = progress,
            delaySec = if (ticks % 7 == 0L) 120 else 0,
            timestamp = now
        ))

        // Canada line train
        val canadaSequence = routes[2].stations
        val canadaProgressIndex = (ticks / 20).toInt() % (canadaSequence.size - 1)
        val canFrom = stations.find { it.id == canadaSequence[canadaProgressIndex] } ?: stations[14]
        val canTo = stations.find { it.id == canadaSequence[canadaProgressIndex + 1] } ?: stations[15]

        vehicles.add(VehiclePosition(
            vehicleId = "CAN-301",
            routeId = "canada_line",
            latitude = interpolate(canFrom.latitude, canTo.latitude, progress),
            longitude = interpolate(canFrom.longitude, canTo.longitude, progress),
            currentStopId = canFrom.id,
            nextStopId = canTo.id,
            progress = progress,
            delaySec = 0,
            timestamp = now
        ))

        // SeaBus ferry
        val sbFrom = stations.find { it.id == "waterfront" } ?: stations[0]
        val sbTo = stations.find { it.id == "lonsdale_quay" } ?: stations[20]
        val ferryProgress = (ticks % 50) / 50f
        val isHeadingNorth = (ticks / 50).toInt() % 2 == 0

        vehicles.add(VehiclePosition(
            vehicleId = "SB-401",
            routeId = "seabus",
            latitude = if (isHeadingNorth) interpolate(sbFrom.latitude, sbTo.latitude, ferryProgress) else interpolate(sbTo.latitude, sbFrom.latitude, ferryProgress),
            longitude = if (isHeadingNorth) interpolate(sbFrom.longitude, sbTo.longitude, ferryProgress) else interpolate(sbTo.longitude, sbFrom.longitude, ferryProgress),
            currentStopId = if (isHeadingNorth) sbFrom.id else sbTo.id,
            nextStopId = if (isHeadingNorth) sbTo.id else sbFrom.id,
            progress = ferryProgress,
            delaySec = 0,
            timestamp = now
        ))

        return vehicles
    }

    private fun interpolate(start: Double, end: Double, fraction: Float): Double {
        return start + (end - start) * fraction
    }

    private fun Double.roundTo(decimals: Int): Double {
        var multiplier = 1.0
        repeat(decimals) { multiplier *= 10 }
        return kotlin.math.round(this * multiplier) / multiplier
    }
}
