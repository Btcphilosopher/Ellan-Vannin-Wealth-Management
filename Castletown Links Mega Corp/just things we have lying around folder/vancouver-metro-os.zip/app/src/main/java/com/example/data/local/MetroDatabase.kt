package com.example.data.local

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.RoomDatabase
import com.example.data.model.Favourite
import com.example.data.model.RecentJourney
import kotlinx.coroutines.flow.Flow

@Dao
interface FavouriteDao {
    @Query("SELECT * FROM favourites")
    fun getAllFavourites(): Flow<List<Favourite>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavourite(favourite: Favourite)

    @Delete
    suspend fun deleteFavourite(favourite: Favourite)

    @Query("SELECT EXISTS(SELECT * FROM favourites WHERE id = :id)")
    fun isFavourite(id: String): Flow<Boolean>
}

@Dao
interface RecentJourneyDao {
    @Query("SELECT * FROM recent_journeys ORDER BY timestamp DESC LIMIT 10")
    fun getRecentJourneys(): Flow<List<RecentJourney>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecentJourney(journey: RecentJourney)

    @Query("DELETE FROM recent_journeys")
    suspend fun clearHistory()
}

@Database(entities = [Favourite::class, RecentJourney::class], version = 1, exportSchema = false)
abstract class MetroDatabase : RoomDatabase() {
    abstract fun favouriteDao(): FavouriteDao
    abstract fun recentJourneyDao(): RecentJourneyDao
}
