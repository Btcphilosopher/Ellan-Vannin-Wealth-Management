package com.example.data.repository

import com.example.data.api.MetroApiService
import com.example.data.local.FavouriteDao
import com.example.data.local.RecentJourneyDao
import com.example.data.model.*
import com.example.data.engine.LocalTransitEngine
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.util.Locale

class TransitRepository(
    private val apiService: MetroApiService?,
    private val favouriteDao: FavouriteDao,
    private val recentJourneyDao: RecentJourneyDao
) {
    // Flag to force synthetic demo data fallback
    var forceSyntheticMode: Boolean = true

    // Favourites logic
    val favourites: Flow<List<Favourite>> = favouriteDao.getAllFavourites()
    
    suspend fun addFavourite(favourite: Favourite) {
        favouriteDao.insertFavourite(favourite)
    }

    suspend fun removeFavourite(favourite: Favourite) {
        favouriteDao.deleteFavourite(favourite)
    }

    fun isFavourite(id: String): Flow<Boolean> = favouriteDao.isFavourite(id)

    // Recents logic
    val recentJourneys: Flow<List<RecentJourney>> = recentJourneyDao.getRecentJourneys()

    suspend fun addRecentJourney(originId: String, originName: String, destId: String, destName: String) {
        recentJourneyDao.insertRecentJourney(
            RecentJourney(
                originId = originId,
                originName = originName,
                destinationId = destId,
                destinationName = destName
            )
        )
    }

    // Dynamic routing/planning
    suspend fun planJourney(
        originId: String,
        destinationId: String,
        startTime: String,
        accessibilityOnly: Boolean = false
    ): JourneyPlan {
        if (forceSyntheticMode || apiService == null) {
            return LocalTransitEngine.planMultimodalJourney(originId, destinationId, startTime, accessibilityOnly)
        }
        return try {
            val body = mapOf(
                "origin" to originId,
                "destination" to destinationId,
                "departure_time" to startTime,
                "accessibility_req" to accessibilityOnly
            )
            apiService.planJourney(body)
        } catch (e: Exception) {
            // Graceful automatic fallback to Local Calculation Engine
            LocalTransitEngine.planMultimodalJourney(originId, destinationId, startTime, accessibilityOnly)
        }
    }

    // Stations list
    suspend fun getStations(): List<Station> {
        if (forceSyntheticMode || apiService == null) {
            return LocalTransitEngine.stations
        }
        return try {
            apiService.getStations()
        } catch (e: Exception) {
            LocalTransitEngine.stations
        }
    }

    // Routes list
    suspend fun getRoutes(): List<TransitRoute> {
        if (forceSyntheticMode || apiService == null) {
            return LocalTransitEngine.routes
        }
        return try {
            apiService.getRoutes()
        } catch (e: Exception) {
            LocalTransitEngine.routes
        }
    }

    // Live departures
    suspend fun getDepartures(stopId: String): List<Departure> {
        // Generates realistic list based on stop lines
        val station = LocalTransitEngine.stations.find { it.id == stopId } ?: return emptyList()
        val departuresList = mutableListOf<Departure>()
        
        val random = java.util.Random(stopId.hashCode().toLong())
        for (line in station.lines) {
            val route = LocalTransitEngine.routes.find { it.name == line } ?: continue
            val dests = if (route.stations.first() == stopId) {
                listOf(LocalTransitEngine.stations.find { it.id == route.stations.last() }?.name ?: "Terminus")
            } else if (route.stations.last() == stopId) {
                listOf(LocalTransitEngine.stations.find { it.id == route.stations.first() }?.name ?: "Terminus")
            } else {
                listOf(
                    LocalTransitEngine.stations.find { it.id == route.stations.first() }?.name ?: "Terminus",
                    LocalTransitEngine.stations.find { it.id == route.stations.last() }?.name ?: "Terminus"
                )
            }

            for (dest in dests) {
                val baseMin = random.nextInt(12) + 2
                departuresList.add(Departure(
                    lineName = line,
                    destination = dest,
                    scheduledMin = baseMin,
                    estimatedMin = baseMin + (if (random.nextFloat() > 0.7f) random.nextInt(3) else 0),
                    delayMin = if (random.nextFloat() > 0.8f) random.nextInt(4) else 0,
                    status = if (random.nextFloat() > 0.5f) "Realtime" else "Estimated"
                ))
            }
        }
        return departuresList.sortedBy { it.estimatedMin }
    }

    // Active real-time vehicles
    suspend fun getVehicles(): List<VehiclePosition> {
        if (forceSyntheticMode || apiService == null) {
            return LocalTransitEngine.getSyntheticVehicles()
        }
        return try {
            apiService.getVehicles()
        } catch (e: Exception) {
            LocalTransitEngine.getSyntheticVehicles()
        }
    }

    // Service Alerts
    suspend fun getAlerts(): List<ServiceAlert> {
        if (forceSyntheticMode || apiService == null) {
            return getLocalSyntheticAlerts()
        }
        return try {
            apiService.getAlerts()
        } catch (e: Exception) {
            getLocalSyntheticAlerts()
        }
    }

    private fun getLocalSyntheticAlerts(): List<ServiceAlert> {
        return listOf(
            ServiceAlert(
                id = "alert-1",
                severity = "WARNING",
                title = "Expo Line: Medical Emergency",
                description = "Medical emergency at Metrotown Station. Trains operating with 10-minute delays between Stadium-Chinatown and Columbia.",
                affectedRoutes = listOf("expo_line"),
                affectedStops = listOf("metrotown"),
                start = "Today 08:00 AM",
                end = "Today 12:00 PM"
            ),
            ServiceAlert(
                id = "alert-2",
                severity = "INFO",
                title = "Canada Line: Maintenance",
                description = "Elevator maintenance at Broadway-City Hall. Boarding accessibility remains normal.",
                affectedRoutes = listOf("canada_line"),
                affectedStops = listOf("broadway_city_hall"),
                start = "Sep 15",
                end = "Sep 20"
            )
        )
    }
}
