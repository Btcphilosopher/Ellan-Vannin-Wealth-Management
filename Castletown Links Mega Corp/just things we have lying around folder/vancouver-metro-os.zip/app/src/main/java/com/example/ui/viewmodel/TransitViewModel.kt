package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.repository.TransitRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class TransitViewModel(private val repository: TransitRepository) : ViewModel() {

    // Global settings and state
    val forceSyntheticMode = MutableStateFlow(repository.forceSyntheticMode)
    val serverUrl = MutableStateFlow("http://10.0.2.2:8000") // Default android emulator loopback

    // Repository bindings
    val favourites: StateFlow<List<Favourite>> = repository.favourites
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentJourneys: StateFlow<List<RecentJourney>> = repository.recentJourneys
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Interactive States
    val stations = MutableStateFlow<List<Station>>(emptyList())
    val routes = MutableStateFlow<List<TransitRoute>>(emptyList())
    val alerts = MutableStateFlow<List<ServiceAlert>>(emptyList())
    
    // Live polling states
    val activeVehicles = MutableStateFlow<List<VehiclePosition>>(emptyList())
    val departures = MutableStateFlow<List<Departure>>(emptyList())
    val selectedStation = MutableStateFlow<Station?>(null)
    val selectedRoute = MutableStateFlow<TransitRoute?>(null)

    // Routing planner states
    val planOrigin = MutableStateFlow<Station?>(null)
    val planDestination = MutableStateFlow<Station?>(null)
    val journeyPlanResult = MutableStateFlow<JourneyPlan?>(null)
    val planningLoading = MutableStateFlow(false)
    val planTimeStr = MutableStateFlow("08:30")

    private var vehiclePollingJob: Job? = null

    init {
        loadStaticTransitData()
        startVehicleTracking()
    }

    fun toggleSyntheticMode(enabled: Boolean) {
        repository.forceSyntheticMode = enabled
        forceSyntheticMode.value = enabled
        loadStaticTransitData()
    }

    private fun loadStaticTransitData() {
        viewModelScope.launch {
            stations.value = repository.getStations()
            routes.value = repository.getRoutes()
            alerts.value = repository.getAlerts()
            
            // Set default stations for planning
            if (stations.value.isNotEmpty()) {
                planOrigin.value = stations.value.find { it.id == "waterfront" } ?: stations.value[0]
                planDestination.value = stations.value.find { it.id == "metrotown" } ?: stations.value.getOrNull(5)
            }
        }
    }

    private fun startVehicleTracking() {
        vehiclePollingJob?.cancel()
        vehiclePollingJob = viewModelScope.launch {
            while (true) {
                activeVehicles.value = repository.getVehicles()
                
                // If there's an active selected station, reload departures periodically
                selectedStation.value?.let {
                    departures.value = repository.getDepartures(it.id)
                }
                
                delay(3000) // Poll real-time values every 3 seconds (sub-second processing matching digital twin speeds)
            }
        }
    }

    fun selectStation(station: Station) {
        selectedStation.value = station
        viewModelScope.launch {
            departures.value = repository.getDepartures(station.id)
        }
    }

    fun selectRoute(route: TransitRoute) {
        selectedRoute.value = route
    }

    fun executeJourneyPlan() {
        val orig = planOrigin.value ?: return
        val dest = planDestination.value ?: return
        
        viewModelScope.launch {
            planningLoading.value = true
            journeyPlanResult.value = null
            
            // Re-simulate the route planning logic
            val plan = repository.planJourney(
                originId = orig.id,
                destinationId = dest.id,
                startTime = planTimeStr.value + ":00"
            )
            
            journeyPlanResult.value = plan
            planningLoading.value = false
            
            // Add to database recents list
            repository.addRecentJourney(orig.id, orig.name, dest.id, dest.name)
        }
    }

    fun toggleFavourite(station: Station) {
        viewModelScope.launch {
            val isFav = favourites.value.any { it.id == station.id }
            if (isFav) {
                repository.removeFavourite(Favourite(station.id, station.name, "station", station.lines.joinToString()))
            } else {
                repository.addFavourite(Favourite(station.id, station.name, "station", station.lines.joinToString()))
            }
        }
    }

    fun isStationFavourite(stationId: String): Boolean {
        return favourites.value.any { it.id == stationId }
    }

    override fun onCleared() {
        super.onCleared()
        vehiclePollingJob?.cancel()
    }
}
