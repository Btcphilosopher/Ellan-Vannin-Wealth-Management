package com.example.data.api

import com.example.data.model.*
import retrofit2.http.*

interface MetroApiService {

    @GET("network")
    suspend fun getNetworkInfo(): Map<String, Any>

    @GET("routes")
    suspend fun getRoutes(): List<TransitRoute>

    @GET("routes/{route_id}")
    suspend fun getRouteDetail(@Path("route_id") routeId: String): TransitRoute

    @GET("stations")
    suspend fun getStations(): List<Station>

    @GET("stations/{station_id}")
    suspend fun getStationDetail(@Path("station_id") stationId: String): Map<String, Any>

    @GET("departures/{stop_id}")
    suspend fun getDepartures(@Path("stop_id") stopId: String): Map<String, Any>

    @GET("vehicles")
    suspend fun getVehicles(): List<VehiclePosition>

    @GET("alerts")
    suspend fun getAlerts(): List<ServiceAlert>

    @POST("journeys/plan")
    suspend fun planJourney(@Body request: Map<String, Any>): JourneyPlan

    @GET("analytics/reliability")
    suspend fun getReliability(): Map<String, Any>

    @GET("analytics/network")
    suspend fun getNetworkAnalytics(): Map<String, Any>
}
