package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.ui.Modifier
import androidx.room.Room
import com.example.data.api.MetroApiService
import com.example.data.local.MetroDatabase
import com.example.data.repository.TransitRepository
import com.example.ui.screens.MetroMainScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.TransitViewModel
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize local Room SQLite Database (complying with room-database-integration skill)
        val database = Room.databaseBuilder(
            applicationContext,
            MetroDatabase::class.java,
            "vancouver-metro-os-db"
        ).fallbackToDestructiveMigration().build()

        // 2. Initialize Retrofit HTTP Client pointing to local FastAPI python server
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        val okHttpClient = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .build()

        val retrofit = Retrofit.Builder()
            .baseUrl("http://10.0.2.2:8000/") // Emulator loopback address
            .client(okHttpClient)
            .addConverterFactory(MoshiConverterFactory.create())
            .build()

        val apiService = try {
            retrofit.create(MetroApiService::class.java)
        } catch (e: Exception) {
            null
        }

        // 3. Initialize repository coordinating API and Room DB
        val repository = TransitRepository(
            apiService = apiService,
            favouriteDao = database.favouriteDao(),
            recentJourneyDao = database.recentJourneyDao()
        )

        // 4. Instantiate primary MVVM ViewModel
        val viewModel = TransitViewModel(repository)

        setContent {
            MyApplicationTheme {
                MetroMainScreen(viewModel = viewModel)
            }
        }
    }
}
