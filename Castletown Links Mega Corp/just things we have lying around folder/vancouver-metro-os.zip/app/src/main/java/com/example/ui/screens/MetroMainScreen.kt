package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.engine.LocalTransitEngine
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.TransitViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetroMainScreen(viewModel: TransitViewModel) {
    var activeTab by remember { mutableStateOf("home") }

    // State flows from viewmodel
    val forceSynthetic by viewModel.forceSyntheticMode.collectAsState()
    val stationsList by viewModel.stations.collectAsState()
    val routesList by viewModel.routes.collectAsState()
    val alertsList by viewModel.alerts.collectAsState()
    val activeVehiclesList by viewModel.activeVehicles.collectAsState()
    val favouritesList by viewModel.favourites.collectAsState()
    val recentJourneysList by viewModel.recentJourneys.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth().padding(end = 12.dp)
                    ) {
                        Column {
                            Text(
                                "VANCOUVER METRO OS",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                letterSpacing = 1.5.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                "Next-Gen Regional Transit Core",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        
                        // Provenance / Synthetic Flag badge
                        Surface(
                            color = if (forceSynthetic) MaterialTheme.colorScheme.surfaceVariant else ColorExpoLine,
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.testTag("synthetic_badge")
                        ) {
                            Text(
                                text = if (forceSynthetic) "DEMO / SYNTHETIC DATA" else "LIVE SYSTEMS ACTIVE",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (forceSynthetic) MaterialTheme.colorScheme.onSurfaceVariant else Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                val tabs = listOf(
                    Triple("home", "Home", Icons.Default.Home),
                    Triple("plan", "Plan", Icons.Default.Route),
                    Triple("map", "Live Radar", Icons.Default.Radar),
                    Triple("departures", "Departures", Icons.Default.DepartureBoard),
                    Triple("system", "OS Console", Icons.Default.Terminal)
                )
                tabs.forEach { (id, label, icon) ->
                    NavigationBarItem(
                        selected = activeTab == id,
                        onClick = { activeTab = id },
                        label = { Text(label, fontSize = 10.sp, fontWeight = FontWeight.Medium) },
                        icon = { Icon(icon, contentDescription = label) },
                        modifier = Modifier.testTag("nav_tab_$id")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (activeTab) {
                "home" -> HomeScreen(viewModel, onPlanClick = { activeTab = "plan" }, onStationSelect = { activeTab = "departures" })
                "plan" -> PlanScreen(viewModel)
                "map" -> MapScreen(viewModel)
                "departures" -> DeparturesScreen(viewModel)
                "system" -> SystemConsoleScreen(viewModel)
            }
        }
    }
}

// ----------------------------------------------------------------------------------
// 1. HOME SCREEN
// ----------------------------------------------------------------------------------
@Composable
fun HomeScreen(viewModel: TransitViewModel, onPlanClick: () -> Unit, onStationSelect: () -> Unit) {
    val stationsList by viewModel.stations.collectAsState()
    val favouritesList by viewModel.favourites.collectAsState()
    val recentJourneysList by viewModel.recentJourneys.collectAsState()
    val alertsList by viewModel.alerts.collectAsState()

    var showFromSearch by remember { mutableStateOf(false) }
    var showToSearch by remember { mutableStateOf(false) }

    val planOrigin by viewModel.planOrigin.collectAsState()
    val planDestination by viewModel.planDestination.collectAsState()

    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(vertical = 16.dp)
    ) {
        // Hero / Where are you going Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Where are you going?",
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // From Selection
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { showFromSearch = true }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.MyLocation, "From", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("FROM", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = planOrigin?.name ?: "Select Starting Station",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // To Selection
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { showToSearch = true }
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Place, "To", tint = ColorDelayed, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("TO", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = planDestination?.name ?: "Select Destination Station",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            viewModel.executeJourneyPlan()
                            onPlanClick()
                        },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("plan_journey_btn"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.DirectionsTransit, "Plan")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Calculate Multimodal Journey", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Active Service Alerts
        if (alertsList.isNotEmpty()) {
            item {
                Column {
                    SectionHeader("CRITICAL SYSTEM ALERTS", Icons.Default.Warning, ColorWarning)
                    Spacer(modifier = Modifier.height(8.dp))
                    alertsList.forEach { alert ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0x11EF4444)),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).border(1.dp, Color(0x33EF4444), RoundedCornerShape(8.dp)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.Top) {
                                Icon(Icons.Default.ErrorOutline, "Alert", tint = ColorDelayed, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(alert.title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.White)
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(alert.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Favourite Stations
        item {
            Column {
                SectionHeader("FAVOURITE STATIONS", Icons.Default.Star, ColorMillenniumLine)
                Spacer(modifier = Modifier.height(8.dp))
                if (favouritesList.isEmpty()) {
                    Text(
                        "No stations starred. Open OS Console -> Stations to star your daily terminals.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                } else {
                    favouritesList.forEach { fav ->
                        val station = stationsList.find { it.id == fav.id }
                        Card(
                            onClick = {
                                if (station != null) {
                                    viewModel.selectStation(station)
                                    onStationSelect()
                                }
                            },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp).fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Star, "Fav", tint = ColorMillenniumLine, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(fav.name, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text(fav.detail, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Icon(Icons.Default.ChevronRight, "Inspect", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        // Recent Journeys
        if (recentJourneysList.isNotEmpty()) {
            item {
                Column {
                    SectionHeader("RECENT JOURNEYS", Icons.Default.History, ColorWalk)
                    Spacer(modifier = Modifier.height(8.dp))
                    recentJourneysList.forEach { rec ->
                        Card(
                            onClick = {
                                val sOrig = stationsList.find { it.id == rec.originId }
                                val sDest = stationsList.find { it.id == rec.destinationId }
                                if (sOrig != null && sDest != null) {
                                    viewModel.planOrigin.value = sOrig
                                    viewModel.planDestination.value = sDest
                                    viewModel.executeJourneyPlan()
                                    onPlanClick()
                                }
                            },
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Directions, "Route", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = "${rec.originName} ➔ ${rec.destinationName}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal Search Overlays
    if (showFromSearch) {
        StationSelectionDialog(
            title = "Choose Origin Station",
            stations = stationsList,
            onDismiss = { showFromSearch = false },
            onSelect = {
                viewModel.planOrigin.value = it
                showFromSearch = false
            }
        )
    }

    if (showToSearch) {
        StationSelectionDialog(
            title = "Choose Destination Station",
            stations = stationsList,
            onDismiss = { showToSearch = false },
            onSelect = {
                viewModel.planDestination.value = it
                showToSearch = false
            }
        )
    }
}

// Helper Dialog for Station selection
@Composable
fun StationSelectionDialog(
    title: String,
    stations: List<Station>,
    onDismiss: () -> Unit,
    onSelect: (Station) -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Box(modifier = Modifier.height(300.dp).fillMaxWidth()) {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(stations) { station ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .clickable { onSelect(station) }
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.DirectionsSubway, "Station", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(station.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text(station.municipality, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

// ----------------------------------------------------------------------------------
// 2. JOURNEY PLANNER SCREEN
// ----------------------------------------------------------------------------------
@Composable
fun PlanScreen(viewModel: TransitViewModel) {
    val planOrigin by viewModel.planOrigin.collectAsState()
    val planDestination by viewModel.planDestination.collectAsState()
    val planResult by viewModel.journeyPlanResult.collectAsState()
    val loading by viewModel.planningLoading.collectAsState()
    val timeStr by viewModel.planTimeStr.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Quick Header info
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${planOrigin?.name ?: "Origin"} ➔ ${planDestination?.name ?: "Destination"}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "Departing at scheduled $timeStr (Now)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Button(
                        onClick = { viewModel.executeJourneyPlan() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Refresh, "Recalculate", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Recalculate", fontSize = 11.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (loading) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (planResult == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Tap 'Calculate Multimodal Journey' to run transit pathing algorithms.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            val result = planResult!!
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Leg Analytics Block
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("JOURNEY DURATION", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text("${result.durationMin} MIN", fontSize = 24.sp, fontWeight = FontWeight.Black, color = ColorOnTime)
                                }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Text(
                                        text = "${result.transfers} TRANSFERS",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Divider()
                            Spacer(modifier = Modifier.height(12.dp))

                            // Timeline analytics breakdown
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                MetricColumn("Walking", "${result.walkingTimeMin}m", Icons.Default.DirectionsWalk)
                                MetricColumn("Waiting", "${result.waitingTimeMin}m", Icons.Default.AccessTime)
                                MetricColumn("Transit", "${result.transitTimeMin}m", Icons.Default.DirectionsSubway)
                                MetricColumn("Distance", String.format(Locale.US, "%.2f km", result.distanceMeters / 1000.0), Icons.Default.Map)
                            }
                        }
                    }
                }

                // Journey Timeline Steps (Section 46. JOURNEY TIMELINE)
                item {
                    Text(
                        "MULTIMODAL PATH TIMELINE",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                }

                items(result.legs) { leg ->
                    TimelineLegItem(leg)
                }

                // Data Provenance Block
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, "Provenance", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Source: ${result.provenance} • Algorithm: Time-Dependent Multi-Criteria Dijkstra",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Medium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TimelineLegItem(leg: JourneyLeg) {
    val modeColor = when (leg.routeId) {
        "expo_line" -> ColorExpoLine
        "millennium_line" -> ColorMillenniumLine
        "canada_line" -> ColorCanadaLine
        "seabus" -> ColorSeaBus
        "bus_99" -> ColorBusRapid
        else -> ColorWalk
    }

    val icon = when (leg.mode) {
        "walk" -> Icons.Default.DirectionsWalk
        "seabus" -> Icons.Default.DirectionsBoat
        "bus" -> Icons.Default.DirectionsBus
        else -> Icons.Default.DirectionsTransit
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Line Left Accent Indicator
            Box(
                modifier = Modifier
                    .width(4.dp)
                    .height(48.dp)
                    .clip(RoundedCornerShape(2.dp))
                    .background(modeColor)
            )

            Spacer(modifier = Modifier.width(12.dp))

            // Time and Mode info
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(icon, "Mode", tint = modeColor, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (leg.type == "walk") "Walk to Station" else if (leg.type == "transfer") "Transfer Walk" else leg.routeId.uppercase(Locale.getDefault()).replace("_", " "),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    Text(
                        text = "${leg.departureTime} - ${leg.arrivalTime}",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Sector Locations
                Text(
                    text = "${leg.fromNodeName} ➔ ${leg.toNodeName}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                
                Text(
                    text = "${leg.durationMin} min • ${(leg.distanceMeters).toInt()} meters",
                    fontSize = 9.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun MetricColumn(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, label, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.height(4.dp))
        Text(value, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ----------------------------------------------------------------------------------
// 3. MAP SCREEN (Section 13. REAL TRANSIT MAP)
// ----------------------------------------------------------------------------------
@Composable
fun MapScreen(viewModel: TransitViewModel) {
    val activeVehicles by viewModel.activeVehicles.collectAsState()
    val stationsList by viewModel.stations.collectAsState()

    Box(modifier = Modifier.fillMaxSize()) {
        // High fidelity geographic transit drawing canvas
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0B132B)) // Midnight ocean canvas
        ) {
            val width = size.width
            val height = size.height

            // Scale mapping for Vancouver bounding coordinates
            // lat: [49.15 to 49.33], lon: [-123.19 to -122.78]
            val latMin = 49.15
            val latMax = 49.33
            val lonMin = -123.19
            val lonMax = -122.78

            fun getScreenCoords(lat: Double, lon: Double): Offset {
                val x = ((lon - lonMin) / (lonMax - lonMin)) * width
                // Invert y since coordinates increase upwards but screen pixels go downwards
                val y = (1.0 - (lat - latMin) / (latMax - latMin)) * height
                return Offset(x.toFloat(), y.toFloat())
            }

            // Draw Burrard Inlet & water polygons
            val burrardInletPath = Path().apply {
                val p1 = getScreenCoords(49.31, -123.19)
                moveTo(p1.x, p1.y)
                val p2 = getScreenCoords(49.31, -123.08)
                lineTo(p2.x, p2.y)
                val p3 = getScreenCoords(49.29, -123.05)
                lineTo(p3.x, p3.y)
                val p4 = getScreenCoords(49.29, -123.19)
                lineTo(p4.x, p4.y)
                close()
            }
            drawPath(burrardInletPath, Color(0xFF1E293B)) // Muted water

            // Draw Fraser River
            val fraserRiverPath = Path().apply {
                val p1 = getScreenCoords(49.20, -123.19)
                moveTo(p1.x, p1.y)
                val p2 = getScreenCoords(49.19, -123.10)
                lineTo(p2.x, p2.y)
                val p3 = getScreenCoords(49.20, -122.90)
                lineTo(p3.x, p3.y)
                val p4 = getScreenCoords(49.18, -122.90)
                lineTo(p4.x, p4.y)
                val p5 = getScreenCoords(49.17, -123.19)
                lineTo(p5.x, p5.y)
                close()
            }
            drawPath(fraserRiverPath, Color(0xFF131A2A))

            // Draw SkyTrain / SeaBus Lines (Track Sections)
            // Expo Line
            val expoTrack = listOf(
                "waterfront", "granville", "stadium", "main_street", "broadway", "metrotown", "new_west", "columbia", "king_george"
            )
            for (i in 0 until expoTrack.size - 1) {
                val s1 = stationsList.find { it.id == expoTrack[i] }
                val s2 = stationsList.find { it.id == expoTrack[i+1] }
                if (s1 != null && s2 != null) {
                    drawLine(
                        color = ColorExpoLine,
                        start = getScreenCoords(s1.latitude, s1.longitude),
                        end = getScreenCoords(s2.latitude, s2.longitude),
                        strokeWidth = 6f
                    )
                }
            }

            // Millennium Line
            val millenniumTrack = listOf(
                "vcc_clark", "broadway", "rupert", "brenwood", "lougheed", "laforge"
            )
            for (i in 0 until millenniumTrack.size - 1) {
                val s1 = stationsList.find { it.id == millenniumTrack[i] }
                val s2 = stationsList.find { it.id == millenniumTrack[i+1] }
                if (s1 != null && s2 != null) {
                    drawLine(
                        color = ColorMillenniumLine,
                        start = getScreenCoords(s1.latitude, s1.longitude),
                        end = getScreenCoords(s2.latitude, s2.longitude),
                        strokeWidth = 6f
                    )
                }
            }

            // Canada Line
            val canadaTrack = listOf(
                "waterfront", "city_centre", "broadway_city_hall", "marine_drive", "bridgeport", "brighouse"
            )
            for (i in 0 until canadaTrack.size - 1) {
                val s1 = stationsList.find { it.id == canadaTrack[i] }
                val s2 = stationsList.find { it.id == canadaTrack[i+1] }
                if (s1 != null && s2 != null) {
                    drawLine(
                        color = ColorCanadaLine,
                        start = getScreenCoords(s1.latitude, s1.longitude),
                        end = getScreenCoords(s2.latitude, s2.longitude),
                        strokeWidth = 6f
                    )
                }
            }

            // SeaBus Track (Burrard Crossing)
            val sWaterfront = stationsList.find { it.id == "waterfront" }
            val sLonsdale = stationsList.find { it.id == "lonsdale_quay" }
            if (sWaterfront != null && sLonsdale != null) {
                drawLine(
                    color = ColorSeaBus,
                    start = getScreenCoords(sWaterfront.latitude, sWaterfront.longitude),
                    end = getScreenCoords(sLonsdale.latitude, sLonsdale.longitude),
                    strokeWidth = 4f,
                    pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                )
            }

            // Draw Station Rings / Stops
            stationsList.forEach { station ->
                val coords = getScreenCoords(station.latitude, station.longitude)
                drawCircle(
                    color = Color.White,
                    radius = 8f,
                    center = coords
                )
                drawCircle(
                    color = Color(0xFF0B132B),
                    radius = 4f,
                    center = coords
                )
            }

            // Draw Moving Vehicles (Real-time updates)
            activeVehicles.forEach { vehicle ->
                val coords = getScreenCoords(vehicle.latitude, vehicle.longitude)
                val lineCol = when (vehicle.routeId) {
                    "expo_line" -> ColorExpoLine
                    "millennium_line" -> ColorMillenniumLine
                    "canada_line" -> ColorCanadaLine
                    "seabus" -> ColorSeaBus
                    else -> ColorBusRapid
                }
                
                // Draw vehicle radar glow
                drawCircle(
                    color = lineCol.copy(alpha = 0.4f),
                    radius = 16f,
                    center = coords
                )
                drawCircle(
                    color = Color.White,
                    radius = 6f,
                    center = coords
                )
                drawCircle(
                    color = lineCol,
                    radius = 4f,
                    center = coords
                )
            }
        }

        // Overlay Legend / Stats
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .width(180.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text("TRANSIT LEGEND", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.height(6.dp))
                LegendRow("Expo Line", ColorExpoLine)
                LegendRow("Millennium Line", ColorMillenniumLine)
                LegendRow("Canada Line", ColorCanadaLine)
                LegendRow("SeaBus Crossing", ColorSeaBus)
                LegendRow("Active Train", Color.White)
            }
        }

        // Live stats overlay
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.9f)),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 24.dp, start = 16.dp, end = 16.dp)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(ColorOnTime))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("ACTIVE TRANSIT TWIN MONITORING", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
                Text("Vessels Tracked: ${activeVehicles.size}", fontSize = 10.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun LegendRow(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(8.dp))
        Text(label, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ----------------------------------------------------------------------------------
// 4. DEPARTURES BOARD SCREEN
// ----------------------------------------------------------------------------------
@Composable
fun DeparturesScreen(viewModel: TransitViewModel) {
    val stationsList by viewModel.stations.collectAsState()
    val departuresList by viewModel.departures.collectAsState()
    val selectedStation by viewModel.selectedStation.collectAsState()

    var showStationSelector by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        // Stop Selector Bar
        Card(
            onClick = { showStationSelector = true },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
        ) {
            Row(
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DepartureBoard, "Station", tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("ACTIVE TERMINAL", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = selectedStation?.name ?: "Select Departure Terminal",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
                Icon(Icons.Default.ArrowDropDown, "Select")
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (selectedStation == null) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("Select a departure terminal to inspect scheduled vs real-time boards.", textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "DEPARTURES BOARD",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp,
                    color = MaterialTheme.colorScheme.primary
                )
                
                // Star Button for Favourites
                val isFav = viewModel.isStationFavourite(selectedStation!!.id)
                IconButton(onClick = { viewModel.toggleFavourite(selectedStation!!) }) {
                    Icon(
                        imageVector = if (isFav) Icons.Default.Star else Icons.Outlined.StarOutline,
                        contentDescription = "Star",
                        tint = if (isFav) ColorMillenniumLine else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            if (departuresList.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No departures currently tracked for this stop.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(departuresList) { dep ->
                        DepartureBoardRow(dep)
                    }
                }
            }
        }
    }

    if (showStationSelector) {
        StationSelectionDialog(
            title = "Select Departure Station",
            stations = stationsList,
            onDismiss = { showStationSelector = false },
            onSelect = {
                viewModel.selectStation(it)
                showStationSelector = false
            }
        )
    }
}

@Composable
fun DepartureBoardRow(departure: Departure) {
    val lineCol = when (departure.lineName) {
        "Expo Line" -> ColorExpoLine
        "Millennium Line" -> ColorMillenniumLine
        "Canada Line" -> ColorCanadaLine
        "SeaBus" -> ColorSeaBus
        else -> ColorBusRapid
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Line badge color block
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(lineCol)
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(departure.destination, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(departure.lineName, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = if (departure.estimatedMin <= 0) "BOARD" else "${departure.estimatedMin} MIN",
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        color = if (departure.delayMin > 0) ColorDelayed else ColorOnTime
                    )
                    
                    Text(
                        text = if (departure.delayMin > 0) "Delayed +${departure.delayMin}m" else "On Time (Live)",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (departure.delayMin > 0) ColorDelayed else ColorWalk
                    )
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------------
// 5. SYSTEM CONSOLE HUB (Section 6. PRIMARY NAVIGATION DRAWER)
// ----------------------------------------------------------------------------------
@Composable
fun SystemConsoleScreen(viewModel: TransitViewModel) {
    var subSection by remember { mutableStateOf("hub") }

    AnimatedContent(targetState = subSection) { target ->
        when (target) {
            "hub" -> ConsoleHubView(onSelect = { subSection = it })
            "routes" -> RoutesConsoleView(viewModel, onBack = { subSection = "hub" })
            "stations" -> StationsConsoleView(viewModel, onBack = { subSection = "hub" })
            "alerts" -> AlertsConsoleView(viewModel, onBack = { subSection = "hub" })
            "network" -> NetworkConsoleView(viewModel, onBack = { subSection = "hub" })
            "settings" -> SettingsConsoleView(viewModel, onBack = { subSection = "hub" })
        }
    }
}

@Composable
fun ConsoleHubView(onSelect: (String) -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text(
            "METRO OS CONSOLE",
            fontWeight = FontWeight.Black,
            fontSize = 18.sp,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            "Canadian Metropolitan Transit Core Configuration Utility",
            fontSize = 11.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Grid Options
        val options = listOf(
            Triple("routes", "Routes Directory", Icons.Default.Route),
            Triple("stations", "Station Models", Icons.Default.DirectionsSubway),
            Triple("alerts", "Service Alerts Engine", Icons.Default.NotificationImportant),
            Triple("network", "Network Graph Analytics", Icons.Default.Hub),
            Triple("settings", "OS Systems Settings", Icons.Default.Settings)
        )

        options.forEach { (id, label, icon) ->
            Card(
                onClick = { onSelect(id) },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(icon, label, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(label, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                    Icon(Icons.Default.ChevronRight, "Inspect", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
    }
}

// Sub-Console Views
@Composable
fun RoutesConsoleView(viewModel: TransitViewModel, onBack: () -> Unit) {
    val routesList by viewModel.routes.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Routes Directory", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(routesList) { route ->
                val lineCol = when (route.id) {
                    "expo_line" -> ColorExpoLine
                    "millennium_line" -> ColorMillenniumLine
                    "canada_line" -> ColorCanadaLine
                    "seabus" -> ColorSeaBus
                    else -> ColorBusRapid
                }
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(lineCol))
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(route.name, fontWeight = FontWeight.Black, fontSize = 15.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Transit Mode: ${route.mode}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Frequency: Every ${route.frequencyMin} minutes", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Operational Stops: ${route.stations.size}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        // Progress schematic track
                        Row(modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                            route.stations.forEachIndexed { idx, stId ->
                                val stName = LocalTransitEngine.stations.find { it.id == stId }?.name ?: stId
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(horizontal = 4.dp)) {
                                    Box(modifier = Modifier.size(6.dp).clip(CircleShape).background(lineCol))
                                    Text(stName.substringBefore(" "), fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
                                }
                                if (idx < route.stations.size - 1) {
                                    Box(modifier = Modifier.width(24.dp).height(1.dp).background(lineCol).align(Alignment.CenterVertically))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StationsConsoleView(viewModel: TransitViewModel, onBack: () -> Unit) {
    val stationsList by viewModel.stations.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Station Digital Twins", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(stationsList) { station ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(station.name, fontWeight = FontWeight.Black, fontSize = 14.sp)
                            
                            // Star Fav inside directories list
                            val isFav = viewModel.isStationFavourite(station.id)
                            IconButton(onClick = { viewModel.toggleFavourite(station) }, modifier = Modifier.size(24.dp)) {
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Star else Icons.Outlined.StarOutline,
                                    contentDescription = "Star",
                                    tint = if (isFav) ColorMillenniumLine else MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                        Text("Location: ${station.municipality} • (${station.latitude}, ${station.longitude})", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("Elevators Available: ${station.elevators} • Facilities: ${station.bikeFacilities}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        Row {
                            station.lines.forEach { line ->
                                val bCol = when (line) {
                                    "Expo Line" -> ColorExpoLine
                                    "Millennium Line" -> ColorMillenniumLine
                                    "Canada Line" -> ColorCanadaLine
                                    "SeaBus" -> ColorSeaBus
                                    else -> ColorBusRapid
                                }
                                Box(
                                    modifier = Modifier
                                        .padding(end = 6.dp)
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(bCol)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(line, fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AlertsConsoleView(viewModel: TransitViewModel, onBack: () -> Unit) {
    val alertsList by viewModel.alerts.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Service Alerts Engine", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        if (alertsList.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("All regional lines are operating normally. No active alerts.")
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(alertsList) { alert ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth().border(1.dp, Color(0x33EF4444), RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, "Warning", tint = ColorWarning, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(alert.title, fontWeight = FontWeight.Black, fontSize = 14.sp)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(alert.description, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Active: ${alert.start} to ${alert.end}", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun NetworkConsoleView(viewModel: TransitViewModel, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("Network Graph Analytics", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text("Graph Centrality & Node Topology Indeces", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(12.dp))

        // Waterfront Node Card
        CentralityCard(
            title = "Waterfront Station (Burrard Inlet Gateway)",
            rank = "Rank 1 Hub",
            degree = "0.95",
            betweenness = "0.88",
            desc = "Primary intermodal terminus connecting Expo Line, Canada Line, SeaBus, and West Coast Express Commuter Rail.",
            color = ColorExpoLine
        )

        // Commercial Broadway Card
        CentralityCard(
            title = "Commercial-Broadway Station",
            rank = "Rank 2 Hub",
            degree = "0.82",
            betweenness = "0.76",
            desc = "Primary regional transfer junction joining Expo Line, Millennium Line, and high-frequency bus lines.",
            color = ColorMillenniumLine
        )

        // Bridgeport Card
        CentralityCard(
            title = "Bridgeport Station (Lulu Branch)",
            rank = "Rank 3 Hub",
            degree = "0.65",
            betweenness = "0.55",
            desc = "Y-Junction separating South Richmond Canada Line branch from airport terminal branches.",
            color = ColorCanadaLine
        )
    }
}

@Composable
fun CentralityCard(title: String, rank: String, degree: String, betweenness: String, desc: String, color: Color) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(color).padding(horizontal = 6.dp, vertical = 2.dp)) {
                    Text(rank, fontSize = 8.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("DEGREE CENTRALITY", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(degree, fontSize = 18.sp, fontWeight = FontWeight.Black)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("BETWEENNESS INDICES", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(betweenness, fontSize = 18.sp, fontWeight = FontWeight.Black)
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(desc, fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
fun SettingsConsoleView(viewModel: TransitViewModel, onBack: () -> Unit) {
    val forceSynthetic by viewModel.forceSyntheticMode.collectAsState()
    val serverUrl by viewModel.serverUrl.collectAsState()

    var urlInput by remember { mutableStateOf(serverUrl) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Back") }
            Text("OS System Settings", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Force Offline Synthetic Mode", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Fallback to local simulation calculations", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = forceSynthetic,
                        onCheckedChange = { viewModel.toggleSyntheticMode(it) },
                        modifier = Modifier.testTag("synthetic_switch")
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider()
                Spacer(modifier = Modifier.height(16.dp))

                Text("Python Translink API Backend URL", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedTextField(
                    value = urlInput,
                    onValueChange = {
                        urlInput = it
                        viewModel.serverUrl.value = it
                    },
                    modifier = Modifier.fillMaxWidth().testTag("server_url_input"),
                    singleLine = true,
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                )
            }
        }
    }
}

@Composable
fun SectionHeader(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, title, tint = color, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = title,
            fontWeight = FontWeight.Black,
            fontSize = 11.sp,
            letterSpacing = 1.sp,
            color = MaterialTheme.colorScheme.onBackground
        )
    }
}
