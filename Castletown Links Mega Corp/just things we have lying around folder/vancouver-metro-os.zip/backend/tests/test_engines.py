import pytest
from app.engines.routing_engine import TransitRoutingEngine
from app.engines.gis_engine import GISEngine
from app.engines.delay_engine import DelayPropagationEngine
from app.engines.analytics_engine import ReliabilityEngine

def test_routing_engine_valid_journeys():
    engine = TransitRoutingEngine()
    
    # Test a direct journey Waterfront -> Metrotown
    result = engine.calculate_route("waterfront", "metrotown", "08:30:00")
    
    assert "legs" in result
    assert result["duration_min"] > 0
    assert result["transfers"] == 0
    assert result["legs"][0]["mode"] == "skytrain"
    assert result["legs"][0]["route_id"] == "expo_line"

def test_routing_engine_time_constraints():
    engine = TransitRoutingEngine()
    result = engine.calculate_route("waterfront", "lonsdale_quay", "12:00:00")
    
    assert "legs" in result
    assert result["legs"][0]["route_id"] == "seabus"
    assert result["legs"][0]["mode"] == "seabus"

def test_gis_haversine_accuracy():
    gis = GISEngine()
    # Distance between Waterfront and Granville (approx 450 meters)
    dist = gis.haversine_distance(49.2856, -123.1117, 49.2820, -123.1162)
    assert 400 < dist < 500

def test_delay_propagation():
    delay_eng = DelayPropagationEngine()
    scheduled_stops = [
        {"stop_id": "waterfront", "seq": 1},
        {"stop_id": "granville", "seq": 2},
        {"stop_id": "stadium", "seq": 3}
    ]
    
    # Propagate 300 seconds delay from Granville
    updated = delay_eng.propagate_trip_delay(scheduled_stops, initial_delay_sec=300, disrupted_stop_index=1)
    
    assert updated[0]["estimated_arrival_delay_sec"] == 0
    assert updated[1]["estimated_arrival_delay_sec"] == 300
    assert updated[2]["estimated_arrival_delay_sec"] == 295 # Recovered 5 seconds buffer

def test_headway_regularity():
    rel_eng = ReliabilityEngine()
    observed_arrivals = [10.0, 16.0, 22.1, 28.2, 34.0] # Every ~6 minutes
    
    analysis = rel_eng.calculate_headway_regularity(scheduled_headway_min=6.0, observed_arrivals_min=observed_arrivals)
    
    assert analysis["regularity_state"] == "REGULAR"
    assert analysis["bunching_detected"] is False
