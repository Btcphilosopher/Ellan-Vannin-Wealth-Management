import time
import random
from typing import Dict, List, Any

class RealtimeTransitEngine:
    """
    Ingests and processes GTFS-Realtime feeds (TripUpdates, VehiclePositions, ServiceAlerts).
    Maintains active system operational state.
    """
    def __init__(self):
        self.vehicle_state: Dict[str, Dict[str, Any]] = {}
        self.trip_state: Dict[str, Dict[str, Any]] = {}
        self.active_alerts: List[Dict[str, Any]] = []
        self._initialize_synthetic_data()

    def _initialize_synthetic_data(self):
        """
        Populates high-fidelity real-time simulation data for Vancouver SkyTrain lines and SeaBus
        to support synthetic demo operations.
        """
        # Base fleet list
        self.active_trains = [
            # Expo Line trains
            {"id": "EXP-101", "route_id": "expo_line", "from": "waterfront", "to": "granville", "progress": 0.3},
            {"id": "EXP-102", "route_id": "expo_line", "from": "broadway", "to": "metrotown", "progress": 0.75},
            {"id": "EXP-103", "route_id": "expo_line", "from": "new_west", "to": "columbia", "progress": 0.15},
            # Millennium Line trains
            {"id": "MIL-201", "route_id": "millennium_line", "from": "vcc_clark", "to": "broadway", "progress": 0.5},
            {"id": "MIL-202", "route_id": "millennium_line", "from": "brenwood", "to": "lougheed", "progress": 0.8},
            # Canada Line trains
            {"id": "CAN-301", "route_id": "canada_line", "from": "waterfront", "to": "city_centre", "progress": 0.45},
            {"id": "CAN-302", "route_id": "canada_line", "from": "bridgeport", "to": "brighouse", "progress": 0.6},
            # SeaBus
            {"id": "SB-401", "route_id": "seabus", "from": "waterfront", "to": "lonsdale_quay", "progress": 0.2}
        ]

    def update_vehicle_positions(self) -> List[Dict[str, Any]]:
        """
        Simulates progress of vehicles in real-time along lines, calculating delays,
        headways, and positions. Driven by active clock ticks.
        """
        updated_vehicles = []
        for train in self.active_trains:
            # Advance progress
            train["progress"] += 0.05
            if train["progress"] >= 1.0:
                train["progress"] = 0.0
                # Move to next simulated sector
                train["from"] = train["to"]
                # Simulataneous circular routes
                sectors = {
                    "waterfront": "granville", "granville": "broadway", "broadway": "metrotown",
                    "metrotown": "new_west", "new_west": "columbia", "columbia": "king_george",
                    "king_george": "waterfront", "vcc_clark": "broadway", "lougheed": "laforge",
                    "laforge": "vcc_clark", "city_centre": "broadway_city_hall", "broadway_city_hall": "bridgeport",
                    "bridgeport": "brighouse", "brighouse": "waterfront", "lonsdale_quay": "waterfront"
                }
                train["to"] = sectors.get(train["from"], "waterfront")

            # Calculate mock latitude/longitude interpolation
            # Note: Used to provide realistic markers on the map screen
            lat_offsets = {"waterfront": 49.2856, "granville": 49.2820, "broadway": 49.2626, "metrotown": 49.2260}
            lon_offsets = {"waterfront": -123.1117, "granville": -123.1162, "broadway": -123.0693, "metrotown": -123.0039}
            
            lat = lat_offsets.get(train["from"], 49.25) + (lat_offsets.get(train["to"], 49.25) - lat_offsets.get(train["from"], 49.25)) * train["progress"]
            lon = lon_offsets.get(train["from"], -123.1) + (lon_offsets.get(train["to"], -123.1) - lon_offsets.get(train["from"], -123.1)) * train["progress"]

            # Add random delays for demonstration
            delay_sec = 0 if random.random() > 0.3 else random.randint(30, 240)

            v_state = {
                "vehicle_id": train["id"],
                "route_id": train["route_id"],
                "latitude": round(lat, 5),
                "longitude": round(lon, 5),
                "current_stop_id": train["from"],
                "next_stop_id": train["to"],
                "progress": round(train["progress"], 2),
                "delay_sec": delay_sec,
                "timestamp": int(time.time()),
                "source": "GTFS-Realtime (Synthetic / Simulator)"
            }
            self.vehicle_state[train["id"]] = v_state
            updated_vehicles.append(v_state)

        return updated_vehicles

    def get_service_alerts(self) -> List[Dict[str, Any]]:
        """
        Returns active alerts for Metro Vancouver OS.
        """
        return [
            {
                "id": "alert-1",
                "severity": "WARNING",
                "title": "Expo Line Delay",
                "description": "Medical emergency at Metrotown Station. Trains operating with 10-minute delays.",
                "affected_routes": ["expo_line"],
                "affected_stops": ["metrotown"],
                "start": "2026-09-18T00:00:00",
                "end": "2026-09-18T06:00:00",
                "source": "TransLink Service Alerts Feed"
            },
            {
                "id": "alert-2",
                "severity": "INFO",
                "title": "Canada Line Elevator Outage",
                "description": "Elevator maintenance at Broadway-City Hall Station. Accessible boarding is normal.",
                "affected_routes": ["canada_line"],
                "affected_stops": ["broadway_city_hall"],
                "start": "2026-09-15T08:00:00",
                "end": "2026-09-20T17:00:00",
                "source": "TransLink Service Alerts Feed"
            }
        ]
