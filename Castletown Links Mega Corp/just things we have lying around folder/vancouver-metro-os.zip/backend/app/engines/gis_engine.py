import math
from typing import Dict, List, Tuple, Any

class GISEngine:
    """
    Geospatial engine representing municipalities, stations, and coordinate networks
    for Metro Vancouver.
    """
    def __init__(self):
        # Municipal centers
        self.municipalities = {
            "Vancouver": (49.2827, -123.1207),
            "Burnaby": (49.2488, -122.9805),
            "Richmond": (49.1666, -123.1336),
            "New Westminster": (49.2057, -122.9110),
            "Surrey": (49.1913, -122.8490),
            "Coquitlam": (49.2838, -122.7933),
            "Port Moody": (49.2775, -122.8680),
            "North Vancouver": (49.3198, -123.0724),
            "West Vancouver": (49.3248, -123.1554),
            "Delta": (49.0847, -123.0586),
            "Langley": (49.1042, -122.6575),
            "Maple Ridge": (49.2192, -122.6013),
            "Pitt Meadows": (49.2230, -122.6908),
            "White Rock": (49.0120, -122.8028)
        }

    @staticmethod
    def haversine_distance(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
        """
        Calculates the great-circle distance between two points on the Earth's surface in meters.
        """
        R = 6371000.0 # Earth radius in meters
        phi1 = math.radians(lat1)
        phi2 = math.radians(lat2)
        delta_phi = math.radians(lat2 - lat1)
        delta_lambda = math.radians(lon2 - lon1)

        a = (math.sin(delta_phi / 2.0) ** 2 +
             math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2.0) ** 2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
        return R * c

    def get_municipality_from_coords(self, lat: float, lon: float) -> str:
        """
        Resolves municipal bounds for coordinates by finding the closest municipality.
        In a PostGIS system, this would be an ST_Contains polygon lookup.
        """
        closest_municipality = "Metro Vancouver"
        min_dist = float('inf')
        for mun, m_coords in self.municipalities.items():
            dist = self.haversine_distance(lat, lon, m_coords[0], m_coords[1])
            if dist < min_dist:
                min_dist = dist
                closest_municipality = mun
        return closest_municipality

    def calculate_walk_details(self, lat1: float, lon1: float, lat2: float, lon2: float) -> Dict[str, Any]:
        """
        Computes geographic distance and estimated walk times at standard 1.2 m/s walk speed.
        """
        dist_m = self.haversine_distance(lat1, lon1, lat2, lon2)
        walk_speed = 1.2 # m/s (average adult walking speed)
        duration_sec = dist_m / walk_speed
        return {
            "distance_m": round(dist_m, 1),
            "duration_sec": round(duration_sec, 0),
            "duration_min": round(duration_sec / 60.0, 1),
            "provenance": "Haversine GIS Engine"
        }
