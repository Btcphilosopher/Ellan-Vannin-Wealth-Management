import math
from typing import List, Dict, Any

class DelayPropagationEngine:
    """
    Simulates delay propagation across scheduled trips and tracks downstream impact.
    Performs delay distribution calculations (Mean, Median, P90, P95).
    """
    def __init__(self):
        pass

    def propagate_trip_delay(self, scheduled_stop_times: List[Dict[str, Any]], 
                             initial_delay_sec: int, 
                             disrupted_stop_index: int) -> List[Dict[str, Any]]:
        """
        Propagates delay down a sequence of stop times.
        Simulates how delay propagates (or is recovered through buffer time) at subsequent stations.
        """
        updated_stop_times = []
        current_delay = initial_delay_sec

        for i, stop_time in enumerate(scheduled_stop_times):
            if i < disrupted_stop_index:
                # No delay yet
                stop_time["estimated_arrival_delay_sec"] = 0
                stop_time["estimated_departure_delay_sec"] = 0
            else:
                # Apply delay and partial recovery (e.g., 5 seconds buffer recovery per stop)
                recovery = 5 # seconds
                if i > disrupted_stop_index:
                    current_delay = max(0, current_delay - recovery)
                
                stop_time["estimated_arrival_delay_sec"] = current_delay
                # High dwell times can cause additional delay
                stop_time["estimated_departure_delay_sec"] = current_delay

            stop_time["is_realtime"] = True
            updated_stop_times.append(stop_time)

        return updated_stop_times

    def calculate_delay_distribution(self, delays_sec: List[int]) -> Dict[str, float]:
        """
        Calculates mathematical delay distribution metrics.
        """
        if not delays_sec:
            return {"mean": 0.0, "median": 0.0, "p90": 0.0, "p95": 0.0}

        sorted_delays = sorted(delays_sec)
        n = len(sorted_delays)

        # Mean
        mean_val = sum(sorted_delays) / n

        # Median
        if n % 2 == 1:
            median_val = sorted_delays[n // 2]
        else:
            median_val = (sorted_delays[n // 2 - 1] + sorted_delays[n // 2]) / 2.0

        # Percentiles
        p90_idx = max(0, min(n - 1, math.ceil(n * 0.90) - 1))
        p95_idx = max(0, min(n - 1, math.ceil(n * 0.95) - 1))

        return {
            "mean": round(mean_val, 1),
            "median": round(median_val, 1),
            "p90": float(sorted_delays[p90_idx]),
            "p95": float(sorted_delays[p95_idx]),
            "unit": "seconds"
        }
