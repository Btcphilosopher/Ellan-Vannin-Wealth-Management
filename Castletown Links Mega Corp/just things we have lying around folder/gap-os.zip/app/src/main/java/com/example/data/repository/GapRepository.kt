package com.example.data.repository

import com.example.data.local.GapDatabase
import com.example.data.local.entity.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull
import java.text.SimpleDateFormat
import java.util.*

class GapRepository(private val db: GapDatabase) {

    val allProducts: Flow<List<ProductEntity>> = db.productDao().getAllProducts()
    val allStores: Flow<List<StoreEntity>> = db.storeDao().getAllStores()
    val allCampaigns: Flow<List<CampaignEntity>> = db.campaignDao().getAllCampaigns()
    val liveCampaigns: Flow<List<CampaignEntity>> = db.campaignDao().getLiveCampaigns()
    val publishedContent: Flow<List<ContentBlockEntity>> = db.contentDao().getPublishedContent()
    val currentCustomer: Flow<CustomerEntity?> = db.customerDao().getCurrentCustomer()
    val allCustomers: Flow<List<CustomerEntity>> = db.customerDao().getAllCustomers()
    val cartItems: Flow<List<CartItemEntity>> = db.cartDao().getCartItems()
    val allOrders: Flow<List<OrderEntity>> = db.orderDao().getAllOrders()
    val auditLogs: Flow<List<AuditLogEntity>> = db.auditDao().getAllAuditLogs()

    suspend fun getProductById(id: String): ProductEntity? = db.productDao().getProductById(id)
    suspend fun getProductBySku(sku: String): ProductEntity? = db.productDao().getProductBySku(sku)
    fun getVariantsForProduct(productId: String): Flow<List<ProductVariantEntity>> = db.productDao().getVariantsForProduct(productId)
    fun getStoreStock(storeId: String): Flow<List<StoreStockEntity>> = db.storeDao().getStockForStore(storeId)

    suspend fun addToCart(
        sku: String,
        productId: String,
        productName: String,
        color: String,
        size: String,
        price: Double,
        imageUrl: String
    ) {
        val cartId = "${sku}_${color.replace(" ", "")}_${size}"
        val existing = db.cartDao().getCartItems().firstOrNull()?.find { it.id == cartId }
        if (existing != null) {
            db.cartDao().updateQuantity(cartId, existing.quantity + 1)
        } else {
            db.cartDao().insertCartItem(
                CartItemEntity(
                    id = cartId,
                    sku = sku,
                    productId = productId,
                    productName = productName,
                    color = color,
                    size = size,
                    price = price,
                    imageUrl = imageUrl,
                    quantity = 1
                )
            )
        }
    }

    suspend fun updateCartQuantity(cartItemId: String, quantity: Int) {
        if (quantity <= 0) {
            db.cartDao().deleteCartItem(cartItemId)
        } else {
            db.cartDao().updateQuantity(cartItemId, quantity)
        }
    }

    suspend fun removeFromCart(cartItemId: String) {
        db.cartDao().deleteCartItem(cartItemId)
    }

    suspend fun clearCart() {
        db.cartDao().clearCart()
    }

    suspend fun placeOrder(
        shippingAddress: String = "742 Evergreen Terrace, New York, NY 10001",
        paymentMethod: String = "Apple Pay"
    ): OrderEntity? {
        val currentCart = db.cartDao().getCartItems().firstOrNull() ?: return null
        if (currentCart.isEmpty()) return null

        val customer = db.customerDao().getCurrentCustomer().firstOrNull() ?: return null
        val subtotal = currentCart.sumOf { it.price * it.quantity }
        val deliveryFee = if (subtotal > 50.0) 0.0 else 7.00
        val totalAmount = subtotal + deliveryFee

        val orderNum = "#" + (48292 + (0..999).random()).toString()
        val orderId = "order_${System.currentTimeMillis()}"

        val itemsJsonBuilder = StringBuilder("[")
        currentCart.forEachIndexed { index, item ->
            itemsJsonBuilder.append("""{"name":"${item.productName}","sku":"${item.sku}","color":"${item.color}","size":"${item.size}","qty":${item.quantity},"price":${item.price}}""")
            if (index < currentCart.size - 1) itemsJsonBuilder.append(",")
            // Decrement inventory stock
            db.productDao().decrementStockForSku(item.sku, item.quantity)
        }
        itemsJsonBuilder.append("]")

        val newOrder = OrderEntity(
            id = orderId,
            orderNumber = orderNum,
            customerId = customer.id,
            customerName = customer.name,
            totalAmount = totalAmount,
            itemsCount = currentCart.sumOf { it.quantity },
            status = "PREPARING",
            channel = "ONLINE",
            dateTimestamp = System.currentTimeMillis(),
            itemsJson = itemsJsonBuilder.toString(),
            shippingAddress = shippingAddress,
            paymentMethod = paymentMethod,
            trackingNumber = "GAP-TRK-" + (10000..99999).random()
        )

        db.orderDao().insertOrder(newOrder)
        db.cartDao().clearCart()

        // Update Customer Spend & Rewards
        val pointsEarned = (totalAmount * 10).toInt()
        val updatedCustomer = customer.copy(
            totalSpend = customer.totalSpend + totalAmount,
            totalOrders = customer.totalOrders + 1,
            points = customer.points + pointsEarned
        )
        db.customerDao().updateCustomer(updatedCustomer)

        // Add Audit Log
        addAuditLog(
            userRole = "CUSTOMER",
            action = "PLACE_ORDER",
            targetObject = "Order $orderNum ($customer.name)",
            oldValue = "-",
            newValue = "$${String.format("%.2f", totalAmount)} (${currentCart.size} items)"
        )

        return newOrder
    }

    suspend fun toggleSavedItem(sku: String) {
        val customer = db.customerDao().getCurrentCustomer().firstOrNull() ?: return
        val currentSkus = customer.savedItemSkusJson.split(",").map { it.trim() }.filter { it.isNotEmpty() }.toMutableList()
        if (currentSkus.contains(sku)) {
            currentSkus.remove(sku)
        } else {
            currentSkus.add(sku)
        }
        db.customerDao().updateCustomer(customer.copy(savedItemSkusJson = currentSkus.joinToString(",")))
    }

    // HQ Actions
    suspend fun updateProductPrice(productId: String, newPrice: Double, userRole: String = "MERCHANDISER") {
        val product = db.productDao().getProductById(productId) ?: return
        val oldPriceStr = "$${String.format("%.2f", product.price)}"
        val newPriceStr = "$${String.format("%.2f", newPrice)}"
        
        db.productDao().updateProductPrice(productId, newPrice)
        addAuditLog(
            userRole = userRole,
            action = "PRICE_UPDATE",
            targetObject = "Product ${product.sku} (${product.name})",
            oldValue = oldPriceStr,
            newValue = newPriceStr
        )
    }

    suspend fun updateStockOnHand(sku: String, storeId: String, newStock: Int, userRole: String = "INVENTORY_MANAGER") {
        val store = db.storeDao().getStoreById(storeId)
        val storeName = store?.name ?: "Global Warehouse"
        val existingStock = db.storeDao().getStoreStockForSku(storeId, sku)
        val oldStockStr = (existingStock?.stockOnHand ?: 0).toString()

        db.storeDao().updateStoreStock(storeId, sku, newStock)
        addAuditLog(
            userRole = userRole,
            action = "INVENTORY_ADJUSTMENT",
            targetObject = "SKU $sku @ $storeName",
            oldValue = "$oldStockStr units",
            newValue = "$newStock units"
        )
    }

    suspend fun publishCampaign(campaignId: String, isLive: Boolean, userRole: String = "MARKETING") {
        val status = if (isLive) "LIVE" else "DRAFT"
        db.campaignDao().updateCampaignStatus(campaignId, status)
        addAuditLog(
            userRole = userRole,
            action = "CAMPAIGN_STATUS_CHANGE",
            targetObject = "Campaign $campaignId",
            oldValue = if (isLive) "DRAFT/REVIEW" else "LIVE",
            newValue = status
        )
    }

    suspend fun createCampaign(
        name: String,
        title: String,
        subtitle: String,
        imageUrl: String,
        targetCategory: String,
        budget: Double,
        startDate: String,
        endDate: String,
        userRole: String = "MARKETING"
    ) {
        val campaignId = "camp_" + System.currentTimeMillis()
        val campaign = CampaignEntity(
            id = campaignId,
            name = name,
            title = title,
            subtitle = subtitle,
            imageUrl = imageUrl.ifEmpty { "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=1200&q=80" },
            targetCategory = targetCategory,
            targetMarket = "North America",
            startDate = startDate.ifEmpty { "2026-09-23" },
            endDate = endDate.ifEmpty { "2026-11-30" },
            budget = budget,
            status = "LIVE",
            performanceRevenue = 0.0,
            performanceOrders = 0
        )
        db.campaignDao().insertCampaign(campaign)
        addAuditLog(
            userRole = userRole,
            action = "CAMPAIGN_CREATED_&_PUBLISHED",
            targetObject = "Campaign $name",
            oldValue = "None",
            newValue = "LIVE ($${String.format("%.2f", budget)} budget)"
        )
    }

    suspend fun updateOrderStatus(orderId: String, newStatus: String, userRole: String = "OPERATIONS") {
        val orders = db.orderDao().getAllOrders().firstOrNull()
        val order = orders?.find { it.id == orderId } ?: return
        val oldStatus = order.status
        db.orderDao().updateOrderStatus(orderId, newStatus)
        addAuditLog(
            userRole = userRole,
            action = "ORDER_FULFILLMENT_UPDATE",
            targetObject = "Order ${order.orderNumber}",
            oldValue = oldStatus,
            newValue = newStatus
        )
    }

    private suspend fun addAuditLog(
        userRole: String,
        action: String,
        targetObject: String,
        oldValue: String,
        newValue: String
    ) {
        val timeStr = SimpleDateFormat("HH:mm:ss 'EDT'", Locale.US).format(Date())
        db.auditDao().insertAuditLog(
            AuditLogEntity(
                timestamp = timeStr,
                userRole = userRole,
                action = action,
                targetObject = targetObject,
                oldValue = oldValue,
                newValue = newValue
            )
        )
    }
}
