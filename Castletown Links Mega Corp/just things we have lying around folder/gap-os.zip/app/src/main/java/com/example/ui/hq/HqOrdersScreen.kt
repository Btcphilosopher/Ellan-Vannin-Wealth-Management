package com.example.ui.hq

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.OrderEntity
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun HqOrdersScreen(viewModel: MainViewModel) {
    val orders by viewModel.allOrders.collectAsState()

    var statusFilter by remember { mutableStateOf("ALL") }
    var selectedOrder by remember { mutableStateOf<OrderEntity?>(null) }

    val filteredOrders = if (statusFilter == "ALL") orders else orders.filter { it.status == statusFilter }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .padding(16.dp)
    ) {
        Text(
            text = "HQ ORDER MANAGEMENT & FULFILLMENT",
            color = HqTextBright,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Text(
            text = "LIVE FEED FROM GAP CUSTOMER APP",
            color = HqTextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Status Filter Chips
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val filters = listOf("ALL", "PREPARING", "SHIPPED", "DELIVERED")
            filters.forEach { filter ->
                val isSelected = statusFilter == filter
                FilterChip(
                    selected = isSelected,
                    onClick = { statusFilter = filter },
                    label = { Text(filter, fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GapAccentBlue,
                        selectedLabelColor = Color.White,
                        containerColor = HqSurfaceDark,
                        labelColor = HqTextMuted
                    ),
                    shape = RoundedCornerShape(0.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Orders Table
        Surface(
            color = HqSurfaceDark,
            border = BorderStroke(1.dp, HqSurfaceBorder),
            modifier = Modifier.weight(1f).testTag("hq_orders_table")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.3f))
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text("ORDER #", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("CUSTOMER", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                    Text("ITEMS", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                    Text("VALUE", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("STATUS", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("ACTION", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                }

                filteredOrders.forEach { ord ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(ord.orderNumber, color = GapAccentBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(ord.customerName, color = HqTextBright, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                        Text("${ord.itemsCount} pcs", color = HqTextMuted, fontSize = 11.sp, modifier = Modifier.weight(0.8f))
                        Text("$${String.format("%.2f", ord.totalAmount)}", color = HqTextBright, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))

                        Surface(
                            color = when (ord.status) {
                                "PREPARING" -> StatusWarning.copy(alpha = 0.2f)
                                "SHIPPED" -> StatusInfo.copy(alpha = 0.2f)
                                else -> StatusSuccess.copy(alpha = 0.2f)
                            },
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = ord.status,
                                color = when (ord.status) {
                                    "PREPARING" -> StatusWarning
                                    "SHIPPED" -> StatusInfo
                                    else -> StatusSuccess
                                },
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }

                        // Fulfillment Action Button
                        Button(
                            onClick = {
                                val nextStatus = when (ord.status) {
                                    "PREPARING" -> "SHIPPED"
                                    "SHIPPED" -> "DELIVERED"
                                    else -> "DELIVERED"
                                }
                                viewModel.updateOrderStatus(ord.id, nextStatus)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GapAccentBlue),
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(1.2f).height(28.dp).testTag("advance_order_${ord.orderNumber}")
                        ) {
                            Text(if (ord.status == "PREPARING") "SHIP ORDER" else "COMPLETE", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Divider(color = HqSurfaceBorder, thickness = 0.5.dp)
                }
            }
        }
    }
}
