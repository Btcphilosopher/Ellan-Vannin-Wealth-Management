package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Gap Brand Colors
val GapBlue = Color(0xFF001C42)
val GapBlueLight = Color(0xFF1E3A8A)
val GapDenimBlue = Color(0xFF2563EB)
val GapAccentBlue = Color(0xFF3B82F6)

val GapWhite = Color(0xFFFFFFFF)
val GapOffWhite = Color(0xFFF8FAFC)
val GapWarmGrey = Color(0xFFF1F5F9)
val GapBorderGrey = Color(0xFFE2E8F0)
val GapTextDark = Color(0xFF0F172A)
val GapTextMuted = Color(0xFF64748B)

// Gap HQ Operational Theme Colors
val HqDarkBackground = Color(0xFF0F172A)
val HqSurfaceDark = Color(0xFF1E293B)
val HqSurfaceBorder = Color(0xFF334155)
val HqTextBright = Color(0xFFF8FAFC)
val HqTextMuted = Color(0xFF94A3B8)

// Status Colors
val StatusSuccess = Color(0xFF10B981)
val StatusWarning = Color(0xFFF59E0B)
val StatusDanger = Color(0xFFEF4444)
val StatusInfo = Color(0xFF06B6D4)
