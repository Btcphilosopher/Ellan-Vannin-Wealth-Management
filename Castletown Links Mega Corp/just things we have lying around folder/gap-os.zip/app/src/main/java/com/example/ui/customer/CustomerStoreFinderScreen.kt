package com.example.ui.customer

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.StoreEntity
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun CustomerStoreFinderScreen(viewModel: MainViewModel) {
    val stores by viewModel.stores.collectAsState()
    val products by viewModel.products.collectAsState()
    val selectedStoreId by viewModel.selectedStoreId.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedStore by remember { mutableStateOf(stores.find { it.id == selectedStoreId } ?: stores.firstOrNull()) }
    var productStockQuery by remember { mutableStateOf("90s Loose Jeans") }

    val filteredStores = stores.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
        it.city.contains(searchQuery, ignoreCase = true) ||
        it.postcode.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GapWhite)
    ) {
        // Search Header
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "FIND A GAP STORE",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = GapTextDark
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search by City, Postcode, or Location...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier.fillMaxWidth().testTag("store_search_input"),
                shape = RoundedCornerShape(0.dp)
            )
        }

        Divider(color = GapBorderGrey, thickness = 1.dp)

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Selected Store Detail Header (13 - STORE PAGE)
            selectedStore?.let { store ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = GapBlue),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier.fillMaxWidth().testTag("store_page_card_${store.id}")
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = store.name.uppercase(),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )

                            Surface(color = StatusSuccess, shape = RoundedCornerShape(2.dp)) {
                                Text(
                                    text = "OPEN • ${store.openingHours}",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = store.address,
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )

                        Text(
                            text = "Phone: ${store.phone} • ${store.distanceMiles} miles away",
                            fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.7f)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "AVAILABLE SERVICES: ${store.availableServices}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        // In-Store Inventory Checker (13 - STORE PAGE feature)
                        Surface(
                            color = Color.White.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(0.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "CHECK IN-STORE STOCK AVAILABILITY",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = Color.White
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    OutlinedTextField(
                                        value = productStockQuery,
                                        onValueChange = { productStockQuery = it },
                                        placeholder = { Text("Search item (e.g. Jeans)") },
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedContainerColor = Color.White,
                                            unfocusedContainerColor = Color.White,
                                            focusedTextColor = GapTextDark,
                                            unfocusedTextColor = GapTextDark
                                        ),
                                        modifier = Modifier.weight(1f).height(46.dp),
                                        shape = RoundedCornerShape(0.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                val matchProduct = products.find { it.name.contains(productStockQuery, ignoreCase = true) } ?: products.firstOrNull()
                                if (matchProduct != null) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(16.dp))
                                        Text(
                                            text = "IN STOCK AT ${store.name} (${matchProduct.name} - 42 units on shelf)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.White
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
            }

            Text("ALL GAP STORE LOCATIONS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GapTextMuted)
            Spacer(modifier = Modifier.height(8.dp))

            filteredStores.forEach { st ->
                val isSelected = st.id == selectedStore?.id
                Surface(
                    onClick = { selectedStore = st },
                    color = if (isSelected) GapWarmGrey else GapWhite,
                    border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) GapBlue else GapBorderGrey),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).testTag("store_item_${st.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(st.name, fontWeight = FontWeight.Black, fontSize = 14.sp, color = GapTextDark)
                            Text("${st.address} • ${st.distanceMiles} mi", fontSize = 12.sp, color = GapTextMuted)
                            Text("Services: ${st.availableServices}", fontSize = 10.sp, color = GapTextMuted)
                        }
                        Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = GapBlue)
                    }
                }
            }
        }
    }
}
