package com.example.ui.customer

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.entity.CampaignEntity
import com.example.data.local.entity.ProductEntity
import com.example.data.ui.CustomerScreen
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun CustomerHomeScreen(viewModel: MainViewModel) {
    val liveCampaigns by viewModel.liveCampaigns.collectAsState()
    val products by viewModel.products.collectAsState()
    val contentBlocks by viewModel.contentBlocks.collectAsState()

    val featuredHero = liveCampaigns.firstOrNull() ?: CampaignEntity(
        id = "hero_fallback",
        name = "NEW GAP",
        title = "NEW GAP",
        subtitle = "NEW SEASON",
        imageUrl = "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=1200&q=80",
        targetCategory = "DENIM",
        targetMarket = "North America",
        startDate = "",
        endDate = "",
        budget = 0.0,
        status = "LIVE"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GapWhite)
            .verticalScroll(rememberScrollState())
    ) {
        // Category Navigation Header Bar
        val categories = listOf("WOMEN", "MEN", "KIDS", "BABY", "DENIM", "SALE")
        ScrollableTabRow(
            selectedTabIndex = 0,
            edgePadding = 16.dp,
            containerColor = GapWhite,
            contentColor = GapTextDark,
            divider = { Divider(color = GapBorderGrey, thickness = 0.5.dp) }
        ) {
            categories.forEach { cat ->
                Tab(
                    selected = false,
                    onClick = { viewModel.selectCategory(cat) },
                    modifier = Modifier.testTag("category_tab_$cat")
                ) {
                    Text(
                        text = cat,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp),
                        color = if (cat == "SALE") StatusDanger else GapTextDark
                    )
                }
            }
        }

        // Hero Campaign Banner (Live-Synced with HQ!)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(420.dp)
                .testTag("homepage_hero_banner")
        ) {
            AsyncImage(
                model = featuredHero.imageUrl,
                contentDescription = featuredHero.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Dark gradient overlay for typography clarity
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.35f))
            )

            Column(
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(24.dp)
            ) {
                Surface(
                    color = Color.White.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text(
                        text = "LIVE CAMPAIGN",
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = featuredHero.title.uppercase(),
                    color = Color.White,
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    lineHeight = 42.sp
                )

                Text(
                    text = featuredHero.subtitle,
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.5.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Button(
                        onClick = { viewModel.selectCategory("WOMEN") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = GapBlue),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.testTag("shop_women_btn")
                    ) {
                        Text(
                            text = "SHOP WOMEN",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 1.sp
                        )
                    }

                    Button(
                        onClick = { viewModel.selectCategory("MEN") },
                        colors = ButtonDefaults.buttonColors(containerColor = GapBlue, contentColor = Color.White),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.testTag("shop_men_btn")
                    ) {
                        Text(
                            text = "SHOP MEN",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // New Arrivals Section
        SectionHeader(title = "NEW ARRIVALS") {
            viewModel.navigateCustomer(CustomerScreen.SHOP)
        }

        val newArrivals = products.filter { it.isNewArrival }
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(newArrivals) { product ->
                ProductCardCompact(
                    product = product,
                    onProductClick = { viewModel.viewProductDetail(product.id) },
                    onFavoriteClick = { viewModel.toggleSavedItem(product.sku) }
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // Denim Feature Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .height(200.dp)
                .clip(RoundedCornerShape(0.dp))
                .clickable { viewModel.selectCategory("DENIM") }
        ) {
            AsyncImage(
                model = "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=1000&q=80",
                contentDescription = "Gap Denim Collection",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(GapBlue.copy(alpha = 0.5f))
            )
            Column(
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(24.dp)
            ) {
                Text(
                    text = "THE DENIM COLLECTION",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.5.sp
                )
                Text(
                    text = "100% Organic Cotton. Crafted to last decades.",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "EXPLORE DENIM →",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.sp
                )
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        // All Products Grid Header
        SectionHeader(title = "ESSENTIAL GAP SELECTIONS") {
            viewModel.navigateCustomer(CustomerScreen.SHOP)
        }

        Column(modifier = Modifier.padding(horizontal = 16.dp)) {
            val productPairs = products.chunked(2)
            productPairs.forEach { pair ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    pair.forEach { prod ->
                        Box(modifier = Modifier.weight(1f)) {
                            ProductCardCompact(
                                product = prod,
                                onProductClick = { viewModel.viewProductDetail(prod.id) },
                                onFavoriteClick = { viewModel.toggleSavedItem(prod.sku) }
                            )
                        }
                    }
                    if (pair.size == 1) {
                        Spacer(modifier = Modifier.weight(1f))
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
fun SectionHeader(title: String, onViewAllClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = title,
            color = GapTextDark,
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        TextButton(onClick = onViewAllClick) {
            Text(
                text = "VIEW ALL",
                color = GapBlue,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun ProductCardCompact(
    product: ProductEntity,
    onProductClick: () -> Unit,
    onFavoriteClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .width(160.dp)
            .clickable { onProductClick() }
            .testTag("product_card_${product.sku}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .background(GapWarmGrey)
        ) {
            AsyncImage(
                model = product.mainImage,
                contentDescription = product.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            IconButton(
                onClick = onFavoriteClick,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.FavoriteBorder,
                    contentDescription = "Save Item",
                    tint = GapTextDark
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = product.name,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = GapTextDark,
            maxLines = 1
        )

        Text(
            text = product.colorsJson.split(",").firstOrNull() ?: "Classic",
            fontSize = 11.sp,
            color = GapTextMuted
        )

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = "$${String.format("%.2f", product.price)}",
            fontSize = 13.sp,
            fontWeight = FontWeight.Black,
            color = GapBlue
        )
    }
}
