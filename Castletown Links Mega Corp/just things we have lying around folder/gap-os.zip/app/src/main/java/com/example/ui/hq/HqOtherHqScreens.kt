package com.example.ui.hq

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

// 23 - STORE OPERATIONS & 24 - STORE HQ
@Composable
fun HqStoreOperationsScreen(viewModel: MainViewModel) {
    val stores by viewModel.stores.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("GAP STORE OPERATIONS & HQ COMMAND", color = HqTextBright, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text("STORE NETWORK REALTIME STATUS", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(16.dp))

        stores.forEach { store ->
            Surface(
                color = HqSurfaceDark,
                border = BorderStroke(1.dp, HqSurfaceBorder),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).testTag("hq_store_card_${store.id}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(store.name.uppercase(), color = HqTextBright, fontSize = 15.sp, fontWeight = FontWeight.Black)
                        Surface(
                            color = if (store.operationalStatus == "NORMAL") StatusSuccess.copy(alpha = 0.2f) else StatusWarning.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(store.operationalStatus, color = if (store.operationalStatus == "NORMAL") StatusSuccess else StatusWarning, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Code: ${store.code} • ${store.city}, ${store.country}", color = HqTextMuted, fontSize = 12.sp)

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("TODAY'S SALES", color = HqTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("$${String.format("%,.2f", store.dailySales)}", color = HqTextBright, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }
                        Column {
                            Text("FOOT TRAFFIC", color = HqTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("${store.dailyTraffic} visitors", color = HqTextBright, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }
                        Column {
                            Text("CONVERSION", color = HqTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("${store.conversionRate}%", color = StatusSuccess, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }
                        Column {
                            Text("STAFF ON SHIFT", color = HqTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            Text("${store.staffCount} staff", color = HqTextBright, fontSize = 14.sp, fontWeight = FontWeight.Black)
                        }
                    }
                }
            }
        }
    }
}

// 20 - MERCHANDISING
@Composable
fun HqMerchandisingScreen(viewModel: MainViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("MERCHANDISING & ASSORTMENT ANALYTICS", color = HqTextBright, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text("SELL-THROUGH, MARGINS & WEEKS OF SUPPLY", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(16.dp))

        val merchData = listOf(
            Triple("DENIM", "$842,100", "69.3% Margin • 78% Sell-through • 4.2 WOS"),
            Triple("TOPS & TEES", "$512,400", "75.9% Margin • 82% Sell-through • 3.8 WOS"),
            Triple("OUTERWEAR", "$310,900", "70.7% Margin • 64% Sell-through • 5.1 WOS"),
            Triple("BOTTOMS / KHAKIS", "$280,000", "71.6% Margin • 71% Sell-through • 4.5 WOS")
        )

        merchData.forEach { (cat, rev, stats) ->
            Surface(
                color = HqSurfaceDark,
                border = BorderStroke(1.dp, HqSurfaceBorder),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(cat, color = GapAccentBlue, fontSize = 15.sp, fontWeight = FontWeight.Black)
                        Text(stats, color = HqTextMuted, fontSize = 12.sp)
                    }
                    Text(rev, color = HqTextBright, fontSize = 16.sp, fontWeight = FontWeight.Black)
                }
            }
        }
    }
}

// 25 - ONLINE COMMERCE
@Composable
fun HqEcommerceScreen(viewModel: MainViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("ONLINE ECOMMERCE CONTROL ROOM", color = HqTextBright, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text("LIVE SESSIONS, CART ABANDONMENT & CONVERSION", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HqMetricCard("LIVE SESSIONS", "14,820", "Active Now", true, Modifier.weight(1f))
            HqMetricCard("CART ABANDON", "21.4%", "-2.1% improvement", true, Modifier.weight(1f))
            HqMetricCard("AOV", "$112.40", "+$4.20 vs avg", true, Modifier.weight(1f))
        }
    }
}

// 27 - CUSTOMER HQ & 28 - CUSTOMER ANALYTICS
@Composable
fun HqCustomersScreen(viewModel: MainViewModel) {
    val customers by viewModel.allCustomers.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("CUSTOMER DATABASE & INSIGHTS", color = HqTextBright, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text("GAP ENCORE MEMBERS & PURCHASE HISTORY", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(16.dp))

        customers.forEach { cust ->
            Surface(
                color = HqSurfaceDark,
                border = BorderStroke(1.dp, HqSurfaceBorder),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(cust.name, color = HqTextBright, fontSize = 15.sp, fontWeight = FontWeight.Black)
                        Surface(color = GapAccentBlue, shape = RoundedCornerShape(2.dp)) {
                            Text(cust.memberTier, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                    Text(cust.email, color = HqTextMuted, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Total Spend: $${String.format("%.2f", cust.totalSpend)} • Orders: ${cust.totalOrders} • Points: ${cust.points}", color = HqTextBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// 31 - CONTENT MANAGEMENT
@Composable
fun HqContentScreen(viewModel: MainViewModel) {
    val contentBlocks by viewModel.contentBlocks.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("GAP APP CONTENT & BANNER MANAGEMENT", color = HqTextBright, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text("MODIFY HOMEPAGE HERO & EDITORIAL STYLING", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(16.dp))

        contentBlocks.forEach { block ->
            Surface(
                color = HqSurfaceDark,
                border = BorderStroke(1.dp, HqSurfaceBorder),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Type: ${block.blockType}", color = GapAccentBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(block.title, color = HqTextBright, fontSize = 16.sp, fontWeight = FontWeight.Black)
                    Text(block.subtitle, color = HqTextMuted, fontSize = 12.sp)
                }
            }
        }
    }
}

// 42 - CUSTOMER EXPERIENCE MONITOR
@Composable
fun HqCustomerExperienceScreen(viewModel: MainViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text("CUSTOMER EXPERIENCE & SYSTEM HEALTH", color = HqTextBright, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text("REALTIME COMMERCE PIPELINE & GATEWAYS", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold)

        Spacer(modifier = Modifier.height(16.dp))

        val services = listOf(
            "Customer App Uptime" to "100.0% • Operational",
            "Checkout & Cart Engine" to "100.0% • Operational",
            "Apple Pay / Card Gateway" to "Latency 42ms • Operational",
            "Gap HQ Live Data Sync" to "Active • Connected"
        )

        services.forEach { (srv, status) ->
            Surface(
                color = HqSurfaceDark,
                border = BorderStroke(1.dp, HqSurfaceBorder),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(srv, color = HqTextBright, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text(status, color = StatusSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
