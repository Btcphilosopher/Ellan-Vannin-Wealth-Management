package com.example.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun CustomerSearchScreen(viewModel: MainViewModel) {
    val searchQuery by viewModel.searchQuery.collectAsState()
    val products by viewModel.products.collectAsState()

    var activeFilter by remember { mutableStateOf("ALL") }

    val searchResults = products.filter { prod ->
        val textMatch = prod.name.contains(searchQuery, ignoreCase = true) ||
                prod.category.contains(searchQuery, ignoreCase = true) ||
                prod.subcategory.contains(searchQuery, ignoreCase = true) ||
                prod.colorsJson.contains(searchQuery, ignoreCase = true) ||
                prod.sku.contains(searchQuery, ignoreCase = true)

        val filterMatch = when (activeFilter) {
            "DENIM" -> prod.isDenim
            "TOPS" -> prod.subcategory.equals("Tops", ignoreCase = true)
            "UNDER_$50" -> prod.price <= 50.0
            else -> true
        }

        textMatch && filterMatch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GapWhite)
    ) {
        // Search Input Header Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setSearchQuery(it) },
                placeholder = { Text("Search jeans, white shirt, hoodie, jacket...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = GapBlue) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.setSearchQuery("") }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear")
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("global_search_input"),
                shape = RoundedCornerShape(0.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Quick Filters
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val filters = listOf("ALL", "DENIM", "TOPS", "UNDER_$50")
                filters.forEach { filter ->
                    val isSelected = activeFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { activeFilter = filter },
                        label = { Text(filter.replace("_", " "), fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = GapBlue,
                            selectedLabelColor = Color.White
                        ),
                        shape = RoundedCornerShape(0.dp)
                    )
                }
            }
        }

        Divider(color = GapBorderGrey, thickness = 1.dp)

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (searchQuery.isEmpty()) "POPULAR GAP SEARCHES" else "SEARCH RESULTS FOR \"$searchQuery\"",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                color = GapTextDark
            )
            Text(
                text = "${searchResults.size} ITEMS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = GapTextMuted
            )
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            if (searchResults.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No matching Gap products found.", color = GapTextMuted)
                }
            } else {
                val chunks = searchResults.chunked(2)
                chunks.forEach { row ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        row.forEach { prod ->
                            Box(modifier = Modifier.weight(1f)) {
                                ProductGridCard(
                                    product = prod,
                                    onViewProduct = { viewModel.viewProductDetail(prod.id) },
                                    onQuickAdd = {
                                        val col = prod.colorsJson.split(",").firstOrNull() ?: "Default"
                                        val sz = prod.sizesJson.split(",").firstOrNull() ?: "M"
                                        viewModel.addToCart(prod.sku, prod.id, prod.name, col, sz, prod.price, prod.mainImage)
                                    },
                                    onFavoriteClick = { viewModel.toggleSavedItem(prod.sku) }
                                )
                            }
                        }
                        if (row.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }
}
