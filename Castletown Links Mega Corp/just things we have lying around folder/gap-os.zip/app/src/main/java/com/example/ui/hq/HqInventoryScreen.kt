package com.example.ui.hq

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun HqInventoryScreen(viewModel: MainViewModel) {
    val products by viewModel.products.collectAsState()
    val stores by viewModel.stores.collectAsState()

    var selectedRegion by remember { mutableStateOf("NORTH AMERICA / USA / CALIFORNIA / SAN FRANCISCO") }
    var editingSkuStock by remember { mutableStateOf<String?>(null) }
    var newStockText by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        // Header
        Text(
            text = "GLOBAL INVENTORY ENGINE & MAP",
            color = HqTextBright,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Text(
            text = "REALTIME AVAILABLE STOCK = ON HAND - RESERVED",
            color = HqTextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Inventory Engine Totals (40 - INVENTORY ENGINE)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HqMetricCard("TOTAL UNITS", "184,920", "On Hand", true, Modifier.weight(1f))
            HqMetricCard("RESERVED", "12,410", "Pending Cart/Orders", false, Modifier.weight(1f))
            HqMetricCard("AVAILABLE", "172,510", "Ready to sell", true, Modifier.weight(1f))
            HqMetricCard("IN TRANSIT", "24,800", "En route to stores", true, Modifier.weight(1f))
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Geographic Region Hierarchy Map Selector (22 - INVENTORY MAP)
        Surface(
            color = HqSurfaceDark,
            border = BorderStroke(1.dp, HqSurfaceBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("GEOGRAPHIC INVENTORY DRILLDOWN", color = GapAccentBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("NORTH AMERICA", color = HqTextBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = HqTextMuted, modifier = Modifier.size(14.dp))
                    Text("UNITED STATES", color = HqTextBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = HqTextMuted, modifier = Modifier.size(14.dp))
                    Text("CALIFORNIA", color = HqTextBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Icon(Icons.Default.ChevronRight, contentDescription = null, tint = HqTextMuted, modifier = Modifier.size(14.dp))
                    Text("SAN FRANCISCO", color = StatusSuccess, fontSize = 12.sp, fontWeight = FontWeight.Black)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Inventory Stock Table by SKU & Location
        Surface(
            color = HqSurfaceDark,
            border = BorderStroke(1.dp, HqSurfaceBorder),
            modifier = Modifier.fillMaxWidth().testTag("hq_inventory_table")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("STORE & WAREHOUSE SKU STOCK LEVELS", color = HqTextBright, fontSize = 13.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(12.dp))

                products.forEach { prod ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1.5f)) {
                            Text(prod.name, color = HqTextBright, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("SKU: ${prod.sku} • Category: ${prod.category}", color = HqTextMuted, fontSize = 11.sp)
                        }

                        val onHand = 480
                        val reserved = 28
                        val available = onHand - reserved

                        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                            Text("$available UNITS AVAIL", color = StatusSuccess, fontSize = 12.sp, fontWeight = FontWeight.Black)
                            Text("On hand: $onHand | Reserved: $reserved", color = HqTextMuted, fontSize = 10.sp)
                        }

                        Button(
                            onClick = {
                                editingSkuStock = prod.sku
                                newStockText = "500"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GapAccentBlue),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.padding(start = 12.dp).height(28.dp)
                        ) {
                            Text("ADJUST", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Divider(color = HqSurfaceBorder, thickness = 0.5.dp)
                }
            }
        }

        // Adjust Stock Modal
        editingSkuStock?.let { sku ->
            AlertDialog(
                onDismissRequest = { editingSkuStock = null },
                containerColor = HqSurfaceDark,
                title = { Text("ADJUST STOCK — SKU $sku", color = HqTextBright, fontSize = 16.sp, fontWeight = FontWeight.Black) },
                text = {
                    Column {
                        Text("Location: Gap SoHo (New York)", color = HqTextMuted, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = newStockText,
                            onValueChange = { newStockText = it },
                            label = { Text("New Stock On Hand") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = HqDarkBackground,
                                unfocusedContainerColor = HqDarkBackground,
                                focusedTextColor = HqTextBright,
                                unfocusedTextColor = HqTextBright
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("adjust_stock_input")
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val newStk = newStockText.toIntOrNull() ?: 500
                            viewModel.updateStockOnHand(sku, "store_soho", newStk)
                            editingSkuStock = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GapAccentBlue)
                    ) {
                        Text("SAVE STOCK ADJUSTMENT", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { editingSkuStock = null }) {
                        Text("CANCEL", color = HqTextMuted)
                    }
                }
            )
        }
    }
}
