package com.example.ui.customer

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ui.CustomerScreen
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun CustomerCheckoutScreen(viewModel: MainViewModel) {
    val cartItems by viewModel.cartItems.collectAsState()
    val customer by viewModel.currentCustomer.collectAsState()

    var checkoutStep by remember { mutableStateOf(2) } // 1: BAG, 2: DELIVERY, 3: PAYMENT, 4: CONFIRM
    var shippingAddress by remember { mutableStateOf(customer?.defaultAddress ?: "742 Evergreen Terrace, New York, NY 10001") }
    var selectedPaymentMethod by remember { mutableStateOf(customer?.defaultPaymentMethod ?: "Apple Pay") }

    val subtotal = cartItems.sumOf { it.price * it.quantity }
    val delivery = if (subtotal > 50.0) 0.0 else 7.00
    val total = subtotal + delivery

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GapWhite)
    ) {
        // Checkout Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateCustomer(CustomerScreen.BAG) },
                modifier = Modifier.testTag("checkout_back_btn")
            ) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = GapTextDark)
            }
            Text(
                text = "EXPRESS CHECKOUT",
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = GapTextDark
            )
        }

        // Stepper Progress Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            val steps = listOf("BAG", "DELIVERY", "PAYMENT", "CONFIRM")
            steps.forEachIndexed { index, stepName ->
                val stepNum = index + 1
                val isCompleted = stepNum < checkoutStep
                val isCurrent = stepNum == checkoutStep

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { if (stepNum <= checkoutStep) checkoutStep = stepNum }
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isCompleted || isCurrent -> GapBlue
                                    else -> GapWarmGrey
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                        } else {
                            Text(
                                text = stepNum.toString(),
                                color = if (isCurrent) Color.White else GapTextMuted,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = stepName,
                        fontSize = 9.sp,
                        fontWeight = if (isCurrent) FontWeight.Black else FontWeight.Bold,
                        color = if (isCurrent) GapBlue else GapTextMuted
                    )
                }
            }
        }

        Divider(color = GapBorderGrey, thickness = 1.dp)

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            when (checkoutStep) {
                2 -> {
                    // Stage 2: Delivery Address
                    Text("1. DELIVERY ADDRESS", fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = shippingAddress,
                        onValueChange = { shippingAddress = it },
                        label = { Text("Shipping Address") },
                        modifier = Modifier.fillMaxWidth().testTag("shipping_address_input"),
                        shape = RoundedCornerShape(0.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("DELIVERY METHOD", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GapTextMuted)
                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        color = GapWarmGrey,
                        border = BorderStroke(1.dp, GapBlue),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Standard Express Shipping", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("Delivered in 2-3 business days", fontSize = 11.sp, color = GapTextMuted)
                            }
                            Text(if (delivery == 0.0) "FREE" else "$${String.format("%.2f", delivery)}", fontWeight = FontWeight.Black, color = GapBlue)
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = { checkoutStep = 3 },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("continue_to_payment_btn"),
                        shape = RoundedCornerShape(0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GapBlue)
                    ) {
                        Text("CONTINUE TO PAYMENT →", fontWeight = FontWeight.Bold)
                    }
                }

                3 -> {
                    // Stage 3: Payment Method
                    Text("2. PAYMENT METHOD", fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    val paymentMethods = listOf("Apple Pay", "Credit Card (•••• 4921)", "PayPal", "Gap Inc. Credit Card")
                    paymentMethods.forEach { method ->
                        val isSelected = selectedPaymentMethod == method
                        Surface(
                            onClick = { selectedPaymentMethod = method },
                            color = if (isSelected) GapWarmGrey else GapWhite,
                            border = BorderStroke(if (isSelected) 2.dp else 1.dp, if (isSelected) GapBlue else GapBorderGrey),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp).testTag("payment_option_$method")
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                RadioButton(selected = isSelected, onClick = { selectedPaymentMethod = method })
                                Text(text = method, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = { checkoutStep = 4 },
                        modifier = Modifier.fillMaxWidth().height(48.dp).testTag("continue_to_confirm_btn"),
                        shape = RoundedCornerShape(0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GapBlue)
                    ) {
                        Text("REVIEW ORDER →", fontWeight = FontWeight.Bold)
                    }
                }

                4 -> {
                    // Stage 4: Confirm Order
                    Text("3. ORDER CONFIRMATION", fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(color = GapWarmGrey, modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text("DELIVERING TO", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GapTextMuted)
                            Text(shippingAddress, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("PAYMENT METHOD", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GapTextMuted)
                            Text(selectedPaymentMethod, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("ITEMS IN ORDER (${cartItems.sumOf { it.quantity }})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GapTextMuted)
                    Spacer(modifier = Modifier.height(8.dp))

                    cartItems.forEach { item ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${item.productName} (${item.size}, x${item.quantity})", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            Text("$${String.format("%.2f", item.price * item.quantity)}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = GapBorderGrey, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TOTAL AMOUNT DUE", fontSize = 14.sp, fontWeight = FontWeight.Black)
                        Text("$${String.format("%.2f", total)}", fontSize = 20.sp, fontWeight = FontWeight.Black, color = GapBlue)
                    }

                    Spacer(modifier = Modifier.height(24.dp))

                    Button(
                        onClick = { viewModel.placeOrder(shippingAddress, selectedPaymentMethod) },
                        modifier = Modifier.fillMaxWidth().height(52.dp).testTag("place_order_btn"),
                        shape = RoundedCornerShape(0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GapBlue)
                    ) {
                        Text("PLACE ORDER NOW • $${String.format("%.2f", total)}", fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    }
                }
            }
        }
    }
}
