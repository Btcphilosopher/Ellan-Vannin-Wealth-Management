package com.example.ui.hq

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun HqAuditLogScreen(viewModel: MainViewModel) {
    val logs by viewModel.auditLogs.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .padding(16.dp)
    ) {
        Text(
            text = "GAP HQ SYSTEM AUDIT LOG",
            color = HqTextBright,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 1.sp
        )
        Text(
            text = "REALTIME OPERATIONAL ACTION TRACKING",
            color = HqTextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(16.dp))

        Surface(
            color = HqSurfaceDark,
            border = BorderStroke(1.dp, HqSurfaceBorder),
            modifier = Modifier.weight(1f).testTag("hq_audit_log_table")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.3f))
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text("TIMESTAMP", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("ROLE", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("ACTION", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                    Text("OBJECT", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.8f))
                    Text("CHANGE (OLD → NEW)", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.8f))
                }

                logs.forEach { log ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(log.timestamp, color = HqTextMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text(log.userRole, color = GapAccentBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(log.action, color = HqTextBright, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                        Text(log.targetObject, color = HqTextBright, fontSize = 11.sp, modifier = Modifier.weight(1.8f))
                        Text("${log.oldValue} → ${log.newValue}", color = StatusSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.8f))
                    }
                    Divider(color = HqSurfaceBorder, thickness = 0.5.dp)
                }
            }
        }
    }
}
