package com.example.ui.hq

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ui.HqScreen
import com.example.ui.theme.*

@Composable
fun HqTopNav(
    activeScreen: HqScreen,
    onNavigate: (HqScreen) -> Unit
) {
    val navItems = listOf(
        "TODAY" to HqScreen.GAP_TODAY,
        "PRODUCT" to HqScreen.PRODUCT,
        "MERCHANDISING" to HqScreen.MERCHANDISING,
        "INVENTORY" to HqScreen.INVENTORY,
        "STORES" to HqScreen.STORES,
        "ECOMMERCE" to HqScreen.ECOMMERCE,
        "ORDERS" to HqScreen.ORDERS,
        "CUSTOMERS" to HqScreen.CUSTOMERS,
        "CAMPAIGNS" to HqScreen.CAMPAIGNS,
        "CONTENT" to HqScreen.CONTENT,
        "AUDIT LOG" to HqScreen.AUDIT_LOG,
        "HEALTH" to HqScreen.CUSTOMER_EXPERIENCE
    )

    ScrollableTabRow(
        selectedTabIndex = navItems.indexOfFirst { it.second == activeScreen }.coerceAtLeast(0),
        edgePadding = 12.dp,
        containerColor = HqSurfaceDark,
        contentColor = GapAccentBlue,
        divider = { Divider(color = HqSurfaceBorder, thickness = 1.dp) }
    ) {
        navItems.forEach { (label, screen) ->
            val isSelected = screen == activeScreen
            Tab(
                selected = isSelected,
                onClick = { onNavigate(screen) },
                modifier = Modifier.testTag("hq_nav_$label")
            ) {
                Text(
                    text = label,
                    fontSize = 11.sp,
                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                    color = if (isSelected) GapAccentBlue else HqTextMuted,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(vertical = 12.dp, horizontal = 10.dp)
                )
            }
        }
    }
}
