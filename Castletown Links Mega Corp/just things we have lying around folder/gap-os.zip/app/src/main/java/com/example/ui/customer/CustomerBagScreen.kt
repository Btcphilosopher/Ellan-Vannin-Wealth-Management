package com.example.ui.customer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.entity.CartItemEntity
import com.example.data.ui.CustomerScreen
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun CustomerBagScreen(viewModel: MainViewModel) {
    val cartItems by viewModel.cartItems.collectAsState()

    val subtotal = cartItems.sumOf { it.price * it.quantity }
    val delivery = if (subtotal > 50.0 || subtotal == 0.0) 0.0 else 7.00
    val total = subtotal + delivery

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GapWhite)
    ) {
        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "YOUR BAG (${cartItems.sumOf { it.quantity }})",
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = GapTextDark
            )

            if (cartItems.isNotEmpty()) {
                TextButton(onClick = { viewModel.navigateCustomer(CustomerScreen.SHOP) }) {
                    Text("CONTINUE SHOPPING", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = GapBlue)
                }
            }
        }

        Divider(color = GapBorderGrey, thickness = 1.dp)

        if (cartItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "YOUR BAG IS EMPTY",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = GapTextDark
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Items added to your bag will appear here.",
                        fontSize = 13.sp,
                        color = GapTextMuted
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { viewModel.navigateCustomer(CustomerScreen.SHOP) },
                        shape = RoundedCornerShape(0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GapBlue)
                    ) {
                        Text("SHOP NEW ARRIVALS", fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                cartItems.forEach { item ->
                    CartItemRow(
                        item = item,
                        onQuantityChange = { qty -> viewModel.updateCartQuantity(item.id, qty) },
                        onRemove = { viewModel.removeFromCart(item.id) }
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Divider(color = GapBorderGrey, thickness = 0.5.dp)
                    Spacer(modifier = Modifier.height(16.dp))
                }

                // Delivery Perks Notice
                Surface(
                    color = GapWarmGrey,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("🚚", fontSize = 16.sp)
                        Text(
                            text = if (subtotal >= 50.0) "YOU'RE ELIGIBLE FOR FREE EXPRESS DELIVERY!" else "Add $${String.format("%.2f", 50.0 - subtotal)} more for FREE Delivery!",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = GapTextDark
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Order Summary Footer
            Surface(
                color = GapWhite,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("SUBTOTAL", fontSize = 12.sp, color = GapTextMuted, fontWeight = FontWeight.Bold)
                        Text("$${String.format("%.2f", subtotal)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GapTextDark)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("DELIVERY", fontSize = 12.sp, color = GapTextMuted, fontWeight = FontWeight.Bold)
                        Text(if (delivery == 0.0) "FREE" else "$${String.format("%.2f", delivery)}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GapTextDark)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = GapBorderGrey, thickness = 1.dp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TOTAL", fontSize = 16.sp, fontWeight = FontWeight.Black, color = GapTextDark)
                        Text("$${String.format("%.2f", total)}", fontSize = 18.sp, fontWeight = FontWeight.Black, color = GapBlue)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { viewModel.navigateCustomer(CustomerScreen.CHECKOUT) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("proceed_to_checkout_btn"),
                        shape = RoundedCornerShape(0.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = GapBlue)
                    ) {
                        Text("CHECKOUT • $${String.format("%.2f", total)}", fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun CartItemRow(
    item: CartItemEntity,
    onQuantityChange: (Int) -> Unit,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("cart_row_${item.sku}")
    ) {
        Box(
            modifier = Modifier
                .size(90.dp, 110.dp)
                .background(GapWarmGrey)
        ) {
            AsyncImage(
                model = item.imageUrl,
                contentDescription = item.productName,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = item.productName,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = GapTextDark,
                    modifier = Modifier.weight(1f)
                )

                IconButton(onClick = onRemove, modifier = Modifier.size(24.dp)) {
                    Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Remove", tint = GapTextMuted)
                }
            }

            Text(
                text = "Colour: ${item.color} • Size: ${item.size}",
                fontSize = 11.sp,
                color = GapTextMuted
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quantity Selector
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.border(1.dp, GapBorderGrey)
                ) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clickable { onQuantityChange(item.quantity - 1) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(12.dp))
                    }

                    Text(
                        text = item.quantity.toString(),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clickable { onQuantityChange(item.quantity + 1) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(imageVector = Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(12.dp))
                    }
                }

                Text(
                    text = "$${String.format("%.2f", item.price * item.quantity)}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = GapBlue
                )
            }
        }
    }
}
