package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val GapLightColorScheme = lightColorScheme(
    primary = GapBlue,
    onPrimary = GapWhite,
    primaryContainer = GapBlueLight,
    onPrimaryContainer = GapWhite,
    secondary = GapDenimBlue,
    onSecondary = GapWhite,
    background = GapOffWhite,
    onBackground = GapTextDark,
    surface = GapWhite,
    onSurface = GapTextDark,
    surfaceVariant = GapWarmGrey,
    onSurfaceVariant = GapTextMuted,
    outline = GapBorderGrey
)

private val GapHqDarkColorScheme = darkColorScheme(
    primary = GapAccentBlue,
    onPrimary = GapWhite,
    primaryContainer = GapBlueLight,
    onPrimaryContainer = GapWhite,
    secondary = GapDenimBlue,
    onSecondary = GapWhite,
    background = HqDarkBackground,
    onBackground = HqTextBright,
    surface = HqSurfaceDark,
    onSurface = HqTextBright,
    surfaceVariant = HqSurfaceDark,
    onSurfaceVariant = HqTextMuted,
    outline = HqSurfaceBorder
)

@Composable
fun GapOSTheme(
    isHqMode: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (isHqMode) GapHqDarkColorScheme else GapLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
