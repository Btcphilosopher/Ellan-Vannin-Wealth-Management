package com.example.ui.hq

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.ProductEntity
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun HqProductManagementScreen(viewModel: MainViewModel) {
    val products by viewModel.products.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedProductForDetail by remember { mutableStateOf<ProductEntity?>(null) }
    var editingPriceText by remember { mutableStateOf("") }

    val filteredProducts = products.filter {
        it.name.contains(searchQuery, ignoreCase = true) ||
        it.sku.contains(searchQuery, ignoreCase = true) ||
        it.category.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .padding(16.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PRODUCT CATALOG MANAGEMENT",
                    color = HqTextBright,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "SHARED REALTIME SINGLE SOURCE OF TRUTH",
                    color = HqTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search product by SKU, Name or Category...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = GapAccentBlue) },
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = HqSurfaceDark,
                unfocusedContainerColor = HqSurfaceDark,
                focusedTextColor = HqTextBright,
                unfocusedTextColor = HqTextBright
            ),
            modifier = Modifier.fillMaxWidth().testTag("hq_product_search_input"),
            shape = RoundedCornerShape(0.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Product Table
        Surface(
            color = HqSurfaceDark,
            border = BorderStroke(1.dp, HqSurfaceBorder),
            modifier = Modifier.weight(1f)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
            ) {
                // Table Header Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color.Black.copy(alpha = 0.3f))
                        .padding(horizontal = 12.dp, vertical = 10.dp)
                ) {
                    Text("SKU", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("PRODUCT", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.8f))
                    Text("CATEGORY", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("RETAIL", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("COST", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("ACTION", color = HqTextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                }

                filteredProducts.forEach { prod ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                selectedProductForDetail = prod
                                editingPriceText = prod.price.toString()
                            }
                            .padding(horizontal = 12.dp, vertical = 12.dp)
                            .testTag("hq_product_row_${prod.sku}"),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(prod.sku, color = GapAccentBlue, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text(prod.name, color = HqTextBright, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.8f))
                        Text(prod.category, color = HqTextBright, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text("$${String.format("%.2f", prod.price)}", color = HqTextBright, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                        Text("$${String.format("%.2f", prod.cost)}", color = HqTextMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))

                        Button(
                            onClick = {
                                selectedProductForDetail = prod
                                editingPriceText = prod.price.toString()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = GapAccentBlue),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.weight(0.8f).height(28.dp).testTag("edit_product_${prod.sku}")
                        ) {
                            Text("EDIT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Divider(color = HqSurfaceBorder, thickness = 0.5.dp)
                }
            }
        }

        // Product Detail & Price Edit Modal (19 - PRODUCT DETAIL HQ)
        selectedProductForDetail?.let { prod ->
            AlertDialog(
                onDismissRequest = { selectedProductForDetail = null },
                containerColor = HqSurfaceDark,
                title = {
                    Text(
                        text = "HQ PRODUCT DETAIL — ${prod.name.uppercase()}",
                        color = HqTextBright,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Black
                    )
                },
                text = {
                    Column {
                        Text("SKU: ${prod.sku} • Category: ${prod.category}", color = HqTextMuted, fontSize = 12.sp)
                        Text("Material: ${prod.material}", color = HqTextMuted, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(12.dp))

                        Text("RETAIL PRICE ADJUSTMENT (LIVE SYNC):", color = HqTextBright, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(4.dp))

                        OutlinedTextField(
                            value = editingPriceText,
                            onValueChange = { editingPriceText = it },
                            label = { Text("Price ($)") },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = HqDarkBackground,
                                unfocusedContainerColor = HqDarkBackground,
                                focusedTextColor = HqTextBright,
                                unfocusedTextColor = HqTextBright
                            ),
                            modifier = Modifier.fillMaxWidth().testTag("edit_price_input"),
                            shape = RoundedCornerShape(0.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Modifying retail price generates an operational Audit Log entry and immediately updates product listing in Gap App.",
                            color = GapAccentBlue,
                            fontSize = 10.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val newP = editingPriceText.toDoubleOrNull()
                            if (newP != null) {
                                viewModel.updateProductPrice(prod.id, newP)
                                selectedProductForDetail = null
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GapAccentBlue),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.testTag("save_price_btn")
                    ) {
                        Text("UPDATE PRICE & PUBLISH", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedProductForDetail = null }) {
                        Text("CANCEL", color = HqTextMuted)
                    }
                }
            )
        }
    }
}
