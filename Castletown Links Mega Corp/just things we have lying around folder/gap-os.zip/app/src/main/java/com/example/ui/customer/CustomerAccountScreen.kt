package com.example.ui.customer

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.entity.OrderEntity
import com.example.data.ui.CustomerScreen
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun CustomerAccountScreen(viewModel: MainViewModel) {
    val customer by viewModel.currentCustomer.collectAsState()
    val orders by viewModel.allOrders.collectAsState()
    val products by viewModel.products.collectAsState()

    var activeTab by remember { mutableStateOf("ORDERS") } // ORDERS, REWARDS, SAVED, ADDRESSES

    val savedSkus = customer?.savedItemSkusJson?.split(",")?.map { it.trim() }?.filter { it.isNotEmpty() } ?: emptyList()
    val savedProducts = products.filter { savedSkus.contains(it.sku) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GapWhite)
    ) {
        // Customer Profile Banner
        Surface(
            color = GapBlue,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .border(2.dp, Color.White, CircleShape)
                    ) {
                        AsyncImage(
                            model = customer?.avatarUrl ?: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=80",
                            contentDescription = customer?.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Column {
                        Text(
                            text = customer?.name ?: "Alex Mercer",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                color = GapDenimBlue,
                                shape = RoundedCornerShape(2.dp)
                            ) {
                                Text(
                                    text = customer?.memberTier ?: "ENCORE MEMBER",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Text(
                                text = "${customer?.points ?: 1420} POINTS",
                                color = Color.White.copy(alpha = 0.9f),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Navigation Tabs: ORDERS, REWARDS, SAVED, ADDRESSES
        val accountTabs = listOf("ORDERS", "REWARDS", "SAVED ITEMS", "ADDRESSES")
        ScrollableTabRow(
            selectedTabIndex = accountTabs.indexOf(if (activeTab == "SAVED") "SAVED ITEMS" else activeTab).coerceAtLeast(0),
            edgePadding = 16.dp,
            containerColor = GapWhite,
            contentColor = GapBlue,
            divider = { Divider(color = GapBorderGrey, thickness = 1.dp) }
        ) {
            accountTabs.forEach { tabName ->
                val key = if (tabName == "SAVED ITEMS") "SAVED" else tabName
                val isSelected = activeTab == key
                Tab(
                    selected = isSelected,
                    onClick = { activeTab = key },
                    modifier = Modifier.testTag("account_tab_$key")
                ) {
                    Text(
                        text = tabName,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                        color = if (isSelected) GapBlue else GapTextMuted,
                        modifier = Modifier.padding(vertical = 12.dp, horizontal = 8.dp)
                    )
                }
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            when (activeTab) {
                "ORDERS" -> {
                    Text("MY ORDERS", fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    if (orders.isEmpty()) {
                        Text("No orders placed yet.", color = GapTextMuted, fontSize = 13.sp)
                    } else {
                        orders.forEach { order ->
                            OrderCard(order = order)
                            Spacer(modifier = Modifier.height(12.dp))
                        }
                    }
                }

                "REWARDS" -> {
                    // Gap Encore Loyalty Rewards (10 - GAP REWARDS)
                    Text("GAP ENCORE LOYALTY PROGRAMME", fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Card(
                        colors = CardDefaults.cardColors(containerColor = GapBlue),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text("ENCORE STATUS", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text("MEMBER TIER", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black)
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("POINTS BALANCE", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                                    Text("${customer?.points ?: 1420}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                                }
                                Column {
                                    Text("REWARDS CREDIT", color = Color.White.copy(alpha = 0.8f), fontSize = 10.sp)
                                    Text("$${String.format("%.2f", customer?.rewardsBalance ?: 25.00)}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("AVAILABLE OFFERS & BENEFITS", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GapTextDark)
                    Spacer(modifier = Modifier.height(8.dp))

                    val offers = listOf(
                        "$10 Off Any Purchase of $50+" to "Expires in 14 days",
                        "Free Express Delivery on All Denim" to "Encore Member Perk",
                        "20% Off Birthday Month Reward" to "Applied automatically at checkout"
                    )

                    offers.forEach { (title, desc) ->
                        Surface(
                            color = GapWarmGrey,
                            border = BorderStroke(1.dp, GapBorderGrey),
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = GapTextDark)
                                    Text(desc, fontSize = 11.sp, color = GapTextMuted)
                                }
                                Button(
                                    onClick = { },
                                    colors = ButtonDefaults.buttonColors(containerColor = GapBlue),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    shape = RoundedCornerShape(0.dp)
                                ) {
                                    Text("APPLY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                "SAVED" -> {
                    // Saved Items (11 - SAVED ITEMS)
                    Text("SAVED ITEMS", fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    if (savedProducts.isEmpty()) {
                        Text("No saved items yet.", color = GapTextMuted, fontSize = 13.sp)
                    } else {
                        val chunks = savedProducts.chunked(2)
                        chunks.forEach { rowItems ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                rowItems.forEach { prod ->
                                    Box(modifier = Modifier.weight(1f)) {
                                        ProductGridCard(
                                            product = prod,
                                            onViewProduct = { viewModel.viewProductDetail(prod.id) },
                                            onQuickAdd = {
                                                val col = prod.colorsJson.split(",").firstOrNull() ?: "Default"
                                                val sz = prod.sizesJson.split(",").firstOrNull() ?: "M"
                                                viewModel.addToCart(prod.sku, prod.id, prod.name, col, sz, prod.price, prod.mainImage)
                                            },
                                            onFavoriteClick = { viewModel.toggleSavedItem(prod.sku) }
                                        )
                                    }
                                }
                                if (rowItems.size == 1) {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }
                }

                "ADDRESSES" -> {
                    Text("SAVED ADDRESSES", fontSize = 14.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        color = GapWarmGrey,
                        border = BorderStroke(1.dp, GapBlue),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("DEFAULT ADDRESS", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = GapBlue)
                                Text("EDIT", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = GapBlue)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(customer?.defaultAddress ?: "742 Evergreen Terrace, New York, NY 10001", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OrderCard(order: OrderEntity) {
    Surface(
        color = GapWhite,
        border = BorderStroke(1.dp, GapBorderGrey),
        modifier = Modifier.fillMaxWidth().testTag("order_card_${order.orderNumber}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ORDER ${order.orderNumber}",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black,
                    color = GapTextDark
                )

                // Status Badge
                val (statusColor, statusBg) = when (order.status) {
                    "PREPARING" -> StatusWarning to StatusWarning.copy(alpha = 0.15f)
                    "SHIPPED", "OUT_FOR_DELIVERY" -> StatusInfo to StatusInfo.copy(alpha = 0.15f)
                    "DELIVERED" -> StatusSuccess to StatusSuccess.copy(alpha = 0.15f)
                    else -> GapTextMuted to GapWarmGrey
                }

                Surface(
                    color = statusBg,
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text(
                        text = order.status,
                        color = statusColor,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "${order.itemsCount} ITEMS • TOTAL: $${String.format("%.2f", order.totalAmount)}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = GapTextDark
            )

            if (order.trackingNumber.isNotEmpty()) {
                Text(
                    text = "Tracking: ${order.trackingNumber}",
                    fontSize = 11.sp,
                    color = GapTextMuted
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { },
                    shape = RoundedCornerShape(0.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                ) {
                    Text("TRACK ORDER", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                OutlinedButton(
                    onClick = { },
                    shape = RoundedCornerShape(0.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                ) {
                    Text("VIEW RECEIPT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
