package com.example.ui.customer

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ui.CustomerScreen
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun CustomerProductDetailScreen(viewModel: MainViewModel) {
    val selectedProductId by viewModel.selectedProductId.collectAsState()
    val products by viewModel.products.collectAsState()
    val stores by viewModel.stores.collectAsState()

    val product = products.find { it.id == selectedProductId } ?: products.firstOrNull()

    if (product == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Product not found.")
        }
        return
    }

    val imagesList = product.imagesJson.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    var selectedImageIndex by remember { mutableStateOf(0) }

    val colorsList = product.colorsJson.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    var selectedColor by remember { mutableStateOf(colorsList.firstOrNull() ?: "Medium Wash") }

    val sizesList = product.sizesJson.split(",").map { it.trim() }.filter { it.isNotEmpty() }
    var selectedSize by remember { mutableStateOf(sizesList.firstOrNull() ?: "32x32") }

    var expandedTab by remember { mutableStateOf<String?>("FIT") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GapWhite)
            .verticalScroll(rememberScrollState())
    ) {
        // Back Navigation Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { viewModel.navigateCustomer(CustomerScreen.SHOP) },
                modifier = Modifier.testTag("back_to_shop")
            ) {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back", tint = GapTextDark)
            }
            Text(
                text = "${product.category} / ${product.subcategory}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = GapTextMuted
            )
        }

        // Main Large Product Image Display
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(420.dp)
                .background(GapWarmGrey)
        ) {
            AsyncImage(
                model = imagesList.getOrElse(selectedImageIndex) { product.mainImage },
                contentDescription = product.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Save Item Favorite Icon
            IconButton(
                onClick = { viewModel.toggleSavedItem(product.sku) },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.FavoriteBorder,
                    contentDescription = "Save Item",
                    tint = GapTextDark
                )
            }

            // Image Perspective Label Overlay (front, back, side, detail, model)
            val perspectives = listOf("Front", "Back", "Side", "Detail", "Model")
            Surface(
                color = Color.Black.copy(alpha = 0.6f),
                shape = RoundedCornerShape(2.dp),
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
            ) {
                Text(
                    text = perspectives.getOrElse(selectedImageIndex) { "View" }.uppercase(),
                    color = Color.White,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
        }

        // Horizontal Gallery Thumbnails
        if (imagesList.size > 1) {
            LazyRow(
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(imagesList.size) { idx ->
                    val isSelected = idx == selectedImageIndex
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .border(
                                width = if (isSelected) 2.dp else 0.5.dp,
                                color = if (isSelected) GapBlue else GapBorderGrey
                            )
                            .clickable { selectedImageIndex = idx }
                    ) {
                        AsyncImage(
                            model = imagesList[idx],
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }

        // Product Header Info
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = product.name.uppercase(),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = GapTextDark,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "SKU: ${product.sku} • $selectedColor",
                        fontSize = 12.sp,
                        color = GapTextMuted,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "$${String.format("%.2f", product.price)}",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = GapBlue
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // COLOUR SELECTOR
            Text(
                text = "COLOUR: ${selectedColor.uppercase()}",
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                colorsList.forEach { col ->
                    val isSelected = col == selectedColor
                    Box(
                        modifier = Modifier
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) GapBlue else GapBorderGrey
                            )
                            .background(if (isSelected) GapWarmGrey else GapWhite)
                            .clickable { selectedColor = col }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                            .testTag("color_select_$col")
                    ) {
                        Text(
                            text = col,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = GapTextDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // SIZE SELECTOR
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SIZE: ${selectedSize.uppercase()}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "SIZE GUIDE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = GapBlue,
                    modifier = Modifier.clickable { }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                sizesList.forEach { sz ->
                    val isSelected = sz == selectedSize
                    Box(
                        modifier = Modifier
                            .size(height = 40.dp, width = 60.dp)
                            .border(
                                width = if (isSelected) 2.dp else 1.dp,
                                color = if (isSelected) GapBlue else GapBorderGrey
                            )
                            .background(if (isSelected) GapBlue else GapWhite)
                            .clickable { selectedSize = sz }
                            .testTag("size_select_$sz"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = sz,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else GapTextDark
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ADD TO BAG BUTTON
            Button(
                onClick = {
                    viewModel.addToCart(
                        sku = product.sku,
                        productId = product.id,
                        productName = product.name,
                        color = selectedColor,
                        size = selectedSize,
                        price = product.price,
                        imageUrl = product.mainImage
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("add_to_bag_button"),
                shape = RoundedCornerShape(0.dp),
                colors = ButtonDefaults.buttonColors(containerColor = GapBlue, contentColor = Color.White)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Outlined.ShoppingBag, contentDescription = null)
                    Text(
                        text = "ADD TO BAG • $${String.format("%.2f", product.price)}",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // PICKUP IN STORE AVAILABILITY CHECKER
            val defaultStore = stores.firstOrNull { it.isSoHo } ?: stores.firstOrNull()
            Surface(
                color = GapWarmGrey,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Storefront,
                        contentDescription = null,
                        tint = GapBlue
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "STORE PICKUP AT ${defaultStore?.name ?: "GAP SOHO"}",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = GapTextDark
                        )
                        Text(
                            text = "AVAILABLE FOR SAME-DAY PICKUP",
                            fontSize = 11.sp,
                            color = StatusSuccess,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    TextButton(onClick = { viewModel.navigateCustomer(CustomerScreen.STORES) }) {
                        Text("CHANGE STORE", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = GapBlue)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // ACCORDION DETAILS (FIT, DETAILS, MATERIAL, DELIVERY)
            AccordionItem(title = "FIT", content = product.fit, isExpanded = expandedTab == "FIT") {
                expandedTab = if (expandedTab == "FIT") null else "FIT"
            }

            AccordionItem(title = "DETAILS", content = product.details, isExpanded = expandedTab == "DETAILS") {
                expandedTab = if (expandedTab == "DETAILS") null else "DETAILS"
            }

            AccordionItem(title = "MATERIAL & CARE", content = product.material, isExpanded = expandedTab == "MATERIAL") {
                expandedTab = if (expandedTab == "MATERIAL") null else "MATERIAL"
            }

            AccordionItem(
                title = "DELIVERY & RETURNS",
                content = "Free standard delivery on orders over $50.00 for Gap Encore Members. 30-day hassle-free returns online or at any Gap store location.",
                isExpanded = expandedTab == "DELIVERY"
            ) {
                expandedTab = if (expandedTab == "DELIVERY") null else "DELIVERY"
            }

            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun AccordionItem(title: String, content: String, isExpanded: Boolean, onToggle: () -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onToggle() }
                .padding(vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = GapTextDark
            )
            Icon(
                imageVector = if (isExpanded) Icons.Default.Remove else Icons.Default.Add,
                contentDescription = null,
                tint = GapTextDark
            )
        }

        AnimatedVisibility(visible = isExpanded) {
            Text(
                text = content,
                fontSize = 13.sp,
                color = GapTextMuted,
                lineHeight = 18.sp,
                modifier = Modifier.padding(bottom = 14.dp)
            )
        }

        Divider(color = GapBorderGrey, thickness = 0.5.dp)
    }
}
