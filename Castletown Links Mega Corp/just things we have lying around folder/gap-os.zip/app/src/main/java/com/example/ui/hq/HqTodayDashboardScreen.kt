package com.example.ui.hq

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ui.HqScreen
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun HqTodayDashboardScreen(viewModel: MainViewModel) {
    val orders by viewModel.allOrders.collectAsState()
    val products by viewModel.products.collectAsState()
    val stores by viewModel.stores.collectAsState()
    val campaigns by viewModel.campaigns.collectAsState()

    val totalRevenue = orders.sumOf { it.totalAmount } + 428950.00
    val totalOrderCount = orders.size + 3842
    val totalUnitsSold = orders.sumOf { it.itemsCount } + 11490

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Dashboard Title Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "GAP TODAY — EXECUTIVE COMMAND CENTER",
                    color = HqTextBright,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "GLOBAL RETAIL OPERATIONS • LIVE FEED",
                    color = HqTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Surface(color = StatusSuccess.copy(alpha = 0.2f), shape = RoundedCornerShape(4.dp)) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Box(modifier = Modifier.size(6.dp).background(StatusSuccess, shape = RoundedCornerShape(3.dp)))
                    Text("SYSTEMS OPERATIONAL", color = StatusSuccess, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Key Metrics Summary Cards Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HqMetricCard(
                title = "NET SALES",
                value = "$${String.format("%,.2f", totalRevenue)}",
                change = "+12.4% vs LY",
                isPositive = true,
                modifier = Modifier.weight(1f)
            )
            HqMetricCard(
                title = "ORDERS",
                value = String.format("%,d", totalOrderCount),
                change = "+8.2% vs LY",
                isPositive = true,
                modifier = Modifier.weight(1f)
            )
            HqMetricCard(
                title = "UNITS SOLD",
                value = String.format("%,d", totalUnitsSold),
                change = "+10.1%",
                isPositive = true,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HqMetricCard(
                title = "GROSS MARGIN",
                value = "58.4%",
                change = "+1.2% target",
                isPositive = true,
                modifier = Modifier.weight(1f)
            )
            HqMetricCard(
                title = "ONLINE CONV.",
                value = "3.82%",
                change = "+0.45%",
                isPositive = true,
                modifier = Modifier.weight(1f)
            )
            HqMetricCard(
                title = "INV TURN",
                value = "4.2x",
                change = "Optimal",
                isPositive = true,
                modifier = Modifier.weight(1f)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Top Products Performance Table Section
        Surface(
            color = HqSurfaceDark,
            border = BorderStroke(1.dp, HqSurfaceBorder),
            modifier = Modifier.fillMaxWidth().testTag("hq_top_products_table")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("TOP PERFORMING PRODUCTS TODAY", color = HqTextBright, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
                    TextButton(onClick = { viewModel.navigateHq(HqScreen.PRODUCT) }) {
                        Text("VIEW ALL PRODUCTS →", color = GapAccentBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Table Header
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(HqDarkBackground)
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                ) {
                    Text("SKU", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                    Text("PRODUCT", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                    Text("PRICE", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                    Text("MARGIN", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                    Text("STATUS", color = HqTextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                }

                products.take(4).forEach { prod ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(prod.sku, color = GapAccentBlue, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                        Text(prod.name, color = HqTextBright, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.5f))
                        Text("$${String.format("%.2f", prod.price)}", color = HqTextBright, fontSize = 11.sp, modifier = Modifier.weight(0.8f))
                        Text("${prod.marginPercentage}%", color = StatusSuccess, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(0.8f))
                        Text("Active", color = HqTextBright, fontSize = 11.sp, modifier = Modifier.weight(0.8f))
                    }
                    Divider(color = HqSurfaceBorder, thickness = 0.5.dp)
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Store Operations Snapshot
        Surface(
            color = HqSurfaceDark,
            border = BorderStroke(1.dp, HqSurfaceBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("STORE OPERATIONS SNAPSHOT", color = HqTextBright, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp)
                Spacer(modifier = Modifier.height(12.dp))

                stores.forEach { st ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(st.name, color = HqTextBright, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("${st.city} • ${st.dailyTraffic} visitors today", color = HqTextMuted, fontSize = 11.sp)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("$${String.format("%,.2f", st.dailySales)}", color = HqTextBright, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Surface(
                                color = if (st.operationalStatus == "NORMAL") StatusSuccess.copy(alpha = 0.2f) else StatusWarning.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(2.dp)
                            ) {
                                Text(
                                    text = st.operationalStatus,
                                    color = if (st.operationalStatus == "NORMAL") StatusSuccess else StatusWarning,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                    Divider(color = HqSurfaceBorder, thickness = 0.5.dp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun HqMetricCard(
    title: String,
    value: String,
    change: String,
    isPositive: Boolean,
    modifier: Modifier = Modifier
) {
    Surface(
        color = HqSurfaceDark,
        border = BorderStroke(1.dp, HqSurfaceBorder),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(title, color = HqTextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, color = HqTextBright, fontSize = 16.sp, fontWeight = FontWeight.Black)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = change,
                color = if (isPositive) StatusSuccess else StatusDanger,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
