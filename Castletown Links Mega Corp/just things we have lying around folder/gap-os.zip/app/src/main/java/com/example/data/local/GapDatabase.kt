package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.local.dao.*
import com.example.data.local.entity.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        ProductEntity::class,
        ProductVariantEntity::class,
        StoreEntity::class,
        StoreStockEntity::class,
        CampaignEntity::class,
        ContentBlockEntity::class,
        CustomerEntity::class,
        CartItemEntity::class,
        OrderEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class GapDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun storeDao(): StoreDao
    abstract fun campaignDao(): CampaignDao
    abstract fun contentDao(): ContentDao
    abstract fun customerDao(): CustomerDao
    abstract fun cartDao(): CartDao
    abstract fun orderDao(): OrderDao
    abstract fun auditDao(): AuditDao

    companion object {
        @Volatile
        private var INSTANCE: GapDatabase? = null

        fun getDatabase(context: Context): GapDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GapDatabase::class.java,
                    "gap_os_db"
                )
                .addCallback(GapDatabaseCallback(context))
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class GapDatabaseCallback(private val context: Context) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(db: GapDatabase) {
            // Products & Variants
            val products = listOf(
                ProductEntity(
                    id = "prod_90s_loose_jeans",
                    sku = "GAP-4921",
                    name = "90s Loose Jeans",
                    category = "DENIM",
                    subcategory = "Denim",
                    price = 79.95,
                    cost = 24.50,
                    marginPercentage = 69.3,
                    mainImage = "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800&q=80",
                    imagesJson = "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=800&q=80,https://images.unsplash.com/photo-1582552938357-32b906df40cb?w=800&q=80,https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=800&q=80",
                    colorsJson = "Medium Wash,Dark Wash,Light Wash,Black",
                    sizesJson = "28x30,30x30,32x32,34x32,36x32",
                    fit = "90s Loose Fit. Sits lower on the waist with a relaxed leg and subtle vintage taper.",
                    details = "Classic 5-pocket styling. Zip fly with button closure. Signature vintage indigo dye.",
                    material = "100% Rigid Organic Cotton. Non-stretch durable denim.",
                    isNewArrival = true,
                    isDenim = true,
                    rating = 4.9f,
                    reviewsCount = 428
                ),
                ProductEntity(
                    id = "prod_pocket_t",
                    sku = "GAP-2841",
                    name = "Heavyweight Pocket T-Shirt",
                    category = "MEN",
                    subcategory = "Tops",
                    price = 29.95,
                    cost = 7.20,
                    marginPercentage = 75.9,
                    mainImage = "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&q=80",
                    imagesJson = "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=800&q=80,https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=800&q=80",
                    colorsJson = "Optic White,Gap Navy,Heather Grey,Black",
                    sizesJson = "XS,S,M,L,XL,XXL",
                    fit = "Relaxed classic fit through body and chest. Ribbed crew neck.",
                    details = "Left chest patch pocket. Double-needle stitched hem for maximum durability.",
                    material = "100% Soft Combed Cotton. 220 GSM heavyweight jersey.",
                    isNewArrival = false,
                    isDenim = false,
                    rating = 4.7f,
                    reviewsCount = 1820
                ),
                ProductEntity(
                    id = "prod_icon_jacket",
                    sku = "GAP-8421",
                    name = "Icon Denim Trucker Jacket",
                    category = "DENIM",
                    subcategory = "Outerwear",
                    price = 129.95,
                    cost = 38.00,
                    marginPercentage = 70.7,
                    mainImage = "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=800&q=80",
                    imagesJson = "https://images.unsplash.com/photo-1576995853123-5a10305d93c0?w=800&q=80,https://images.unsplash.com/photo-1543076447-215ad9ba6923?w=800&q=80",
                    colorsJson = "Authentic Dark Indigo,Medium Stonewash",
                    sizesJson = "S,M,L,XL,XXL",
                    fit = "Standard fit designed to sit at the hip. Roomy for effortless layering.",
                    details = "Button front with Gap branded brass shank buttons. Button-flap chest pockets.",
                    material = "100% Cotton Denim. Crafted with water-saving Washwell techniques.",
                    isNewArrival = true,
                    isDenim = true,
                    rating = 4.8f,
                    reviewsCount = 310
                ),
                ProductEntity(
                    id = "prod_poplin_shirt",
                    sku = "GAP-7723",
                    name = "Big Shirt in Crisp Poplin",
                    category = "WOMEN",
                    subcategory = "Tops",
                    price = 49.95,
                    cost = 12.50,
                    marginPercentage = 74.9,
                    mainImage = "https://images.unsplash.com/photo-1598554747436-c9293d6a588f?w=800&q=80",
                    imagesJson = "https://images.unsplash.com/photo-1598554747436-c9293d6a588f?w=800&q=80,https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&q=80",
                    colorsJson = "Pure White,Classic Navy Stripe,French Blue",
                    sizesJson = "XXS,XS,S,M,L,XL",
                    fit = "Oversized relaxed silhouette with dropped shoulders and longer curved back hem.",
                    details = "Point collar, button cuffs, chest pocket. Looks effortless buttoned or open.",
                    material = "100% Cotton Poplin. Breathable and smooth crisp handfeel.",
                    isNewArrival = true,
                    isDenim = false,
                    rating = 4.8f,
                    reviewsCount = 640
                ),
                ProductEntity(
                    id = "prod_logo_hoodie",
                    sku = "GAP-1102",
                    name = "Arch Logo Fleece Hoodie",
                    category = "WOMEN",
                    subcategory = "Tops",
                    price = 59.95,
                    cost = 16.00,
                    marginPercentage = 73.3,
                    mainImage = "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&q=80",
                    imagesJson = "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=800&q=80",
                    colorsJson = "Gap Navy,Heather Grey,Oatmeal Heather,Vintage Black",
                    sizesJson = "XS,S,M,L,XL",
                    fit = "Easy comfortable fit. Ribbed hem and cuffs.",
                    details = "Iconic embroidered Gap arch logo across chest. Front kangaroo pocket.",
                    material = "77% Cotton, 23% Polyester soft brushed fleece.",
                    isNewArrival = false,
                    isDenim = false,
                    rating = 4.9f,
                    reviewsCount = 2140
                ),
                ProductEntity(
                    id = "prod_khaki_chinos",
                    sku = "GAP-3910",
                    name = "Modern Straight Essential Khakis",
                    category = "MEN",
                    subcategory = "Bottoms",
                    price = 69.95,
                    cost = 19.80,
                    marginPercentage = 71.6,
                    mainImage = "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=800&q=80",
                    imagesJson = "https://images.unsplash.com/photo-1473966968600-fa801b869a1a?w=800&q=80",
                    colorsJson = "Khaki,Gap Navy,Olive,Stone",
                    sizesJson = "30x30,32x30,32x32,34x32,36x32",
                    fit = "Straight fit through hip and thigh with a classic leg opening.",
                    details = "GapFlex stretch technology for maximum mobility. Front slash pockets.",
                    material = "98% Cotton, 2% Elastane. Washwell water-conscious finish.",
                    isNewArrival = false,
                    isDenim = false,
                    rating = 4.6f,
                    reviewsCount = 890
                ),
                ProductEntity(
                    id = "prod_kids_jean",
                    sku = "GAP-8823",
                    name = "Kids Stretch Original Jeans",
                    category = "KIDS",
                    subcategory = "Bottoms",
                    price = 39.95,
                    cost = 11.00,
                    marginPercentage = 72.4,
                    mainImage = "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=800&q=80",
                    imagesJson = "https://images.unsplash.com/photo-1519238263530-99bdd11df2ea?w=800&q=80",
                    colorsJson = "Medium Indigo,Dark Stonewash",
                    sizesJson = "4T,5T,6,7,8,10,12",
                    fit = "Adjustable waistband for custom comfort as kids grow.",
                    details = "Concealed snap closure. Durable reinforced knee construction.",
                    material = "99% Cotton, 1% Spandex comfortable stretch denim.",
                    isNewArrival = true,
                    isDenim = true,
                    rating = 4.9f,
                    reviewsCount = 185
                ),
                ProductEntity(
                    id = "prod_baby_romper",
                    sku = "GAP-9912",
                    name = "Baby Soft-Knit Branded One-Piece",
                    category = "BABY",
                    subcategory = "Accessories",
                    price = 24.95,
                    cost = 6.00,
                    marginPercentage = 75.9,
                    mainImage = "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=800&q=80",
                    imagesJson = "https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=800&q=80",
                    colorsJson = "Sky Blue,Powder Pink,Heather Grey",
                    sizesJson = "0-3M,3-6M,6-12M,12-18M,18-24M",
                    fit = "Gentle stretch fit designed for easy diaper changing.",
                    details = "Snap inseam closures. Lap shoulders for easy dressing over baby's head.",
                    material = "100% Organic Super-Soft Combed Cotton.",
                    isNewArrival = true,
                    isDenim = false,
                    rating = 5.0f,
                    reviewsCount = 412
                )
            )

            db.productDao().insertProducts(products)

            // Variants
            val variants = mutableListOf<ProductVariantEntity>()
            products.forEach { p ->
                val colors = p.colorsJson.split(",")
                val sizes = p.sizesJson.split(",")
                colors.forEach { col ->
                    sizes.forEach { sz ->
                        variants.add(
                            ProductVariantEntity(
                                id = "${p.sku}_${col.trim().replace(" ", "_")}_${sz.trim()}",
                                productId = p.id,
                                sku = p.sku,
                                color = col.trim(),
                                size = sz.trim(),
                                stockOnHand = (100..800).random(),
                                stockReserved = (5..30).random(),
                                stockInTransit = (50..150).random()
                            )
                        )
                    }
                }
            }
            db.productDao().insertVariants(variants)

            // Stores
            val stores = listOf(
                StoreEntity(
                    id = "store_soho",
                    code = "GAP-101",
                    name = "Gap SoHo Flagship",
                    city = "New York",
                    postcode = "10012",
                    country = "United States",
                    address = "528 Broadway, New York, NY 10012",
                    openingHours = "10:00 – 20:00",
                    phone = "(212) 995-2010",
                    distanceMiles = 0.8,
                    availableServices = "Shop In Store, Curbside Pickup, In-Store Returns, Denim Tailoring",
                    isSoHo = true,
                    dailySales = 42890.00,
                    dailyTraffic = 3820,
                    conversionRate = 4.25,
                    staffCount = 38,
                    operationalStatus = "NORMAL"
                ),
                StoreEntity(
                    id = "store_union_square",
                    code = "GAP-202",
                    name = "Gap Union Square",
                    city = "San Francisco",
                    postcode = "94108",
                    country = "United States",
                    address = "890 Market St, San Francisco, CA 94108",
                    openingHours = "10:00 – 19:30",
                    phone = "(415) 788-7800",
                    distanceMiles = 1.2,
                    availableServices = "Shop In Store, Same-Day Pickup, Store Returns",
                    isSoHo = false,
                    dailySales = 34500.00,
                    dailyTraffic = 2950,
                    conversionRate = 3.90,
                    staffCount = 28,
                    operationalStatus = "NORMAL"
                ),
                StoreEntity(
                    id = "store_michigan_ave",
                    code = "GAP-303",
                    name = "Gap Michigan Avenue",
                    city = "Chicago",
                    postcode = "60611",
                    country = "United States",
                    address = "555 N Michigan Ave, Chicago, IL 60611",
                    openingHours = "10:00 – 20:00",
                    phone = "(312) 642-1200",
                    distanceMiles = 2.4,
                    availableServices = "Shop In Store, Pickup, Returns",
                    isSoHo = false,
                    dailySales = 28900.00,
                    dailyTraffic = 2410,
                    conversionRate = 3.75,
                    staffCount = 24,
                    operationalStatus = "ATTENTION"
                ),
                StoreEntity(
                    id = "store_grove",
                    code = "GAP-404",
                    name = "Gap The Grove",
                    city = "Los Angeles",
                    postcode = "90036",
                    country = "United States",
                    address = "189 The Grove Dr, Los Angeles, CA 90036",
                    openingHours = "10:00 – 21:00",
                    phone = "(323) 938-1020",
                    distanceMiles = 3.1,
                    availableServices = "Shop In Store, Pickup, Personal Stylist, Fitting Rooms",
                    isSoHo = false,
                    dailySales = 39200.00,
                    dailyTraffic = 3400,
                    conversionRate = 4.10,
                    staffCount = 32,
                    operationalStatus = "NORMAL"
                )
            )
            db.storeDao().insertStores(stores)

            // Store stock
            val storeStockList = mutableListOf<StoreStockEntity>()
            stores.forEach { s ->
                products.forEach { p ->
                    storeStockList.add(
                        StoreStockEntity(
                            id = "${s.id}_${p.sku}",
                            storeId = s.id,
                            sku = p.sku,
                            stockOnHand = (40..250).random(),
                            stockReserved = (2..12).random()
                        )
                    )
                }
            }
            db.storeDao().insertStoreStock(storeStockList)

            // Campaigns
            val campaigns = listOf(
                CampaignEntity(
                    id = "camp_001",
                    name = "NEW GAP — NEW SEASON 2026",
                    title = "NEW GAP",
                    subtitle = "NEW SEASON ARCH DENIM & ESSENTIAL ELEVATION",
                    imageUrl = "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=1200&q=80",
                    targetCategory = "DENIM",
                    targetMarket = "Global / North America",
                    startDate = "2026-09-01",
                    endDate = "2026-10-31",
                    budget = 1250000.00,
                    status = "LIVE",
                    performanceRevenue = 842100.00,
                    performanceOrders = 9820
                ),
                CampaignEntity(
                    id = "camp_002",
                    name = "90s LOOSE DENIM REVIVAL",
                    title = "DENIM REINVENTED",
                    subtitle = "Relaxed fits, authentic washes, 100% organic cotton",
                    imageUrl = "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?w=1200&q=80",
                    targetCategory = "DENIM",
                    targetMarket = "North America",
                    startDate = "2026-09-15",
                    endDate = "2026-11-15",
                    budget = 750000.00,
                    status = "LIVE",
                    performanceRevenue = 412000.00,
                    performanceOrders = 5100
                ),
                CampaignEntity(
                    id = "camp_003",
                    name = "FALL SOFT FLEECE & HOODIES",
                    title = "THE ARCH LOGO",
                    subtitle = "Comfort engineering for modern everyday lifestyle",
                    imageUrl = "https://images.unsplash.com/photo-1556905055-8f358a7a47b2?w=1200&q=80",
                    targetCategory = "WOMEN",
                    targetMarket = "Global",
                    startDate = "2026-10-01",
                    endDate = "2026-12-15",
                    budget = 500000.00,
                    status = "APPROVED",
                    performanceRevenue = 0.0,
                    performanceOrders = 0
                )
            )
            db.campaignDao().insertCampaigns(campaigns)

            // Content Blocks
            val contentBlocks = listOf(
                ContentBlockEntity(
                    id = "content_hero_1",
                    blockType = "HERO",
                    title = "NEW GAP",
                    subtitle = "NEW SEASON",
                    ctaText = "SHOP WOMEN",
                    ctaCategory = "WOMEN",
                    imageUrl = "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=1200&q=80",
                    isPublished = true
                ),
                ContentBlockEntity(
                    id = "content_editorial_1",
                    blockType = "EDITORIAL",
                    title = "THE DENIM ARCHIVE",
                    subtitle = "Rooted in 1969 American heritage, crafted for today.",
                    ctaText = "EXPLORE DENIM",
                    ctaCategory = "DENIM",
                    imageUrl = "https://images.unsplash.com/photo-1582552938357-32b906df40cb?w=1200&q=80",
                    isPublished = true
                )
            )
            db.contentDao().insertContentBlocks(contentBlocks)

            // Customer
            val customer = CustomerEntity(
                id = "cust_88491",
                name = "Alex Mercer",
                email = "alex.mercer@gap.com",
                avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&q=80",
                memberTier = "ENCORE MEMBER",
                points = 1420,
                totalSpend = 680.50,
                totalOrders = 8,
                rewardsBalance = 25.00,
                savedItemSkusJson = "GAP-4921,GAP-8421",
                defaultAddress = "742 Evergreen Terrace, New York, NY 10001",
                defaultPaymentMethod = "Apple Pay (•••• 4921)"
            )
            db.customerDao().insertCustomers(listOf(customer))

            // Initial Synthetic Orders
            val orders = listOf(
                OrderEntity(
                    id = "order_48291",
                    orderNumber = "#48291",
                    customerId = customer.id,
                    customerName = customer.name,
                    totalAmount = 109.90,
                    itemsCount = 2,
                    status = "PREPARING",
                    channel = "ONLINE",
                    dateTimestamp = System.currentTimeMillis() - 3600000 * 2,
                    itemsJson = "[{\"name\":\"90s Loose Jeans\",\"sku\":\"GAP-4921\",\"color\":\"Medium Wash\",\"size\":\"32x32\",\"qty\":1,\"price\":79.95},{\"name\":\"Heavyweight Pocket T-Shirt\",\"sku\":\"GAP-2841\",\"color\":\"Optic White\",\"size\":\"L\",\"qty\":1,\"price\":29.95}]",
                    shippingAddress = customer.defaultAddress,
                    paymentMethod = "Apple Pay",
                    trackingNumber = "GAP-TRK-90821"
                ),
                OrderEntity(
                    id = "order_48288",
                    orderNumber = "#48288",
                    customerId = customer.id,
                    customerName = customer.name,
                    totalAmount = 129.95,
                    itemsCount = 1,
                    status = "SHIPPED",
                    channel = "ONLINE",
                    dateTimestamp = System.currentTimeMillis() - 3600000 * 24 * 2,
                    itemsJson = "[{\"name\":\"Icon Denim Trucker Jacket\",\"sku\":\"GAP-8421\",\"color\":\"Authentic Dark Indigo\",\"size\":\"L\",\"qty\":1,\"price\":129.95}]",
                    shippingAddress = customer.defaultAddress,
                    paymentMethod = "Visa ending 4921",
                    trackingNumber = "GAP-TRK-88120"
                ),
                OrderEntity(
                    id = "order_48102",
                    orderNumber = "#48102",
                    customerId = customer.id,
                    customerName = customer.name,
                    totalAmount = 49.95,
                    itemsCount = 1,
                    status = "DELIVERED",
                    channel = "ONLINE",
                    dateTimestamp = System.currentTimeMillis() - 3600000 * 24 * 7,
                    itemsJson = "[{\"name\":\"Big Shirt in Crisp Poplin\",\"sku\":\"GAP-7723\",\"color\":\"Pure White\",\"size\":\"M\",\"qty\":1,\"price\":49.95}]",
                    shippingAddress = customer.defaultAddress,
                    paymentMethod = "PayPal",
                    trackingNumber = "GAP-TRK-77102"
                )
            )
            db.orderDao().insertOrders(orders)

            // Initial Audit Log
            val auditLog = AuditLogEntity(
                timestamp = "14:32:05 EDT",
                userRole = "MERCHANDISER",
                action = "PRICE_UPDATE",
                targetObject = "Product GAP-4921 (90s Loose Jeans)",
                oldValue = "$89.95",
                newValue = "$79.95"
            )
            db.auditDao().insertAuditLog(auditLog)
        }
    }
}
