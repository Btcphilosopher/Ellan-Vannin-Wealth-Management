package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ui.AppMode
import com.example.data.ui.CustomerScreen
import com.example.data.ui.HqScreen
import com.example.data.ui.MainViewModel
import com.example.ui.components.DualAppTopBar
import com.example.ui.customer.*
import com.example.ui.hq.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val appMode by viewModel.appMode.collectAsState()
            val customerScreen by viewModel.customerScreen.collectAsState()
            val hqScreen by viewModel.hqScreen.collectAsState()
            val cartItems by viewModel.cartItems.collectAsState()
            val toastMsg by viewModel.toastMessage.collectAsState()

            val isHq = appMode == AppMode.HQ

            GapOSTheme(isHqMode = isHq) {
                val snackbarHostState = remember { SnackbarHostState() }

                LaunchedEffect(toastMsg) {
                    toastMsg?.let {
                        snackbarHostState.showSnackbar(it)
                        viewModel.clearToast()
                    }
                }

                Scaffold(
                    topBar = {
                        DualAppTopBar(
                            viewModel = viewModel,
                            appMode = appMode,
                            cartCount = cartItems.sumOf { it.quantity },
                            onCartClick = { viewModel.navigateCustomer(CustomerScreen.BAG) }
                        )
                    },
                    snackbarHost = {
                        SnackbarHost(hostState = snackbarHostState) { data ->
                            Snackbar(
                                snackbarData = data,
                                containerColor = if (isHq) GapAccentBlue else GapBlue,
                                contentColor = Color.White
                            )
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                            .background(if (isHq) HqDarkBackground else GapWhite)
                    ) {
                        if (appMode == AppMode.CUSTOMER) {
                            // GAP CUSTOMER APP CONTENT
                            when (customerScreen) {
                                CustomerScreen.HOME -> CustomerHomeScreen(viewModel = viewModel)
                                CustomerScreen.SHOP -> CustomerShopScreen(viewModel = viewModel)
                                CustomerScreen.PRODUCT_DETAIL -> CustomerProductDetailScreen(viewModel = viewModel)
                                CustomerScreen.BAG -> CustomerBagScreen(viewModel = viewModel)
                                CustomerScreen.CHECKOUT -> CustomerCheckoutScreen(viewModel = viewModel)
                                CustomerScreen.ACCOUNT -> CustomerAccountScreen(viewModel = viewModel)
                                CustomerScreen.REWARDS -> CustomerAccountScreen(viewModel = viewModel)
                                CustomerScreen.STORES -> CustomerStoreFinderScreen(viewModel = viewModel)
                                CustomerScreen.SEARCH -> CustomerSearchScreen(viewModel = viewModel)
                            }
                        } else {
                            // GAP HQ OPERATING SYSTEM CONTENT
                            Column(modifier = Modifier.fillMaxSize()) {
                                HqTopNav(
                                    activeScreen = hqScreen,
                                    onNavigate = { viewModel.navigateHq(it) }
                                )

                                Box(modifier = Modifier.weight(1f)) {
                                    when (hqScreen) {
                                        HqScreen.GAP_TODAY -> HqTodayDashboardScreen(viewModel = viewModel)
                                        HqScreen.PRODUCT -> HqProductManagementScreen(viewModel = viewModel)
                                        HqScreen.MERCHANDISING -> HqMerchandisingScreen(viewModel = viewModel)
                                        HqScreen.INVENTORY -> HqInventoryScreen(viewModel = viewModel)
                                        HqScreen.STORES -> HqStoreOperationsScreen(viewModel = viewModel)
                                        HqScreen.ECOMMERCE -> HqEcommerceScreen(viewModel = viewModel)
                                        HqScreen.ORDERS -> HqOrdersScreen(viewModel = viewModel)
                                        HqScreen.CUSTOMERS -> HqCustomersScreen(viewModel = viewModel)
                                        HqScreen.CAMPAIGNS -> HqCampaignsScreen(viewModel = viewModel)
                                        HqScreen.CONTENT -> HqContentScreen(viewModel = viewModel)
                                        HqScreen.AUDIT_LOG -> HqAuditLogScreen(viewModel = viewModel)
                                        HqScreen.CUSTOMER_EXPERIENCE -> HqCustomerExperienceScreen(viewModel = viewModel)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
