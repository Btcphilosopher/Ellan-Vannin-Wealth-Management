package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ui.AppMode
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun DualAppTopBar(
    viewModel: MainViewModel,
    appMode: AppMode,
    cartCount: Int,
    onCartClick: () -> Unit
) {
    val hqRole by viewModel.hqUserRole.collectAsState()
    var roleDropdownExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (appMode == AppMode.HQ) HqDarkBackground else GapBlue)
            .statusBarsPadding()
    ) {
        // Platform Switcher Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Live Platform Indicator
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(StatusSuccess)
                )
                Text(
                    text = "GAP PLATFORM v3.6 • REALTIME DATA SYNC",
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }

            // Mode Selector Pill Switcher
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.15f))
                    .padding(2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Customer Button
                Box(
                    modifier = Modifier
                        .testTag("switch_to_customer_app")
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (appMode == AppMode.CUSTOMER) Color.White else Color.Transparent)
                        .clickable { viewModel.setAppMode(AppMode.CUSTOMER) }
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "GAP APP",
                        color = if (appMode == AppMode.CUSTOMER) GapBlue else Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 0.5.sp
                    )
                }

                // HQ Button
                Box(
                    modifier = Modifier
                        .testTag("switch_to_gap_hq")
                        .clip(RoundedCornerShape(18.dp))
                        .background(if (appMode == AppMode.HQ) GapDenimBlue else Color.Transparent)
                        .clickable { viewModel.setAppMode(AppMode.HQ) }
                        .padding(horizontal = 12.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "GAP HQ",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 0.5.sp
                        )
                    }
                }
            }
        }

        Divider(color = Color.White.copy(alpha = 0.1f), thickness = 1.dp)

        // Sub Bar depending on Mode
        if (appMode == AppMode.CUSTOMER) {
            // Customer Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color.White)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "GAP",
                    color = GapBlue,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 2.sp,
                    modifier = Modifier
                        .clickable { viewModel.navigateCustomer(com.example.data.ui.CustomerScreen.HOME) }
                        .testTag("gap_logo_brand")
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    IconButton(
                        onClick = { viewModel.navigateCustomer(com.example.data.ui.CustomerScreen.SEARCH) },
                        modifier = Modifier.testTag("icon_search")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = "Search",
                            tint = GapTextDark
                        )
                    }

                    IconButton(
                        onClick = { viewModel.navigateCustomer(com.example.data.ui.CustomerScreen.ACCOUNT) },
                        modifier = Modifier.testTag("icon_account")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Account",
                            tint = GapTextDark
                        )
                    }

                    Box {
                        IconButton(
                            onClick = onCartClick,
                            modifier = Modifier.testTag("icon_shopping_bag")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShoppingBag,
                                contentDescription = "Shopping Bag",
                                tint = GapTextDark
                            )
                        }
                        if (cartCount > 0) {
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .clip(CircleShape)
                                    .background(GapBlue)
                                    .align(Alignment.TopEnd),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = cartCount.toString(),
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // HQ Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(HqDarkBackground)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "GAP HQ",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(HqSurfaceBorder)
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "RETAIL OS",
                            color = HqTextMuted,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Role Selector Dropdown
                Box {
                    Surface(
                        onClick = { roleDropdownExpanded = true },
                        color = HqSurfaceDark,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.testTag("hq_role_selector")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Badge,
                                contentDescription = null,
                                tint = GapAccentBlue,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = hqRole,
                                color = Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = null,
                                tint = HqTextMuted,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = roleDropdownExpanded,
                        onDismissRequest = { roleDropdownExpanded = false },
                        modifier = Modifier.background(HqSurfaceDark)
                    ) {
                        val roles = listOf("HQ ADMIN", "MERCHANDISER", "STORE MANAGER", "MARKETING", "ECOMMERCE", "INVENTORY", "ANALYST")
                        roles.forEach { role ->
                            DropdownMenuItem(
                                text = { Text(role, color = Color.White, fontSize = 12.sp) },
                                onClick = {
                                    viewModel.setHqUserRole(role)
                                    roleDropdownExpanded = false
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
