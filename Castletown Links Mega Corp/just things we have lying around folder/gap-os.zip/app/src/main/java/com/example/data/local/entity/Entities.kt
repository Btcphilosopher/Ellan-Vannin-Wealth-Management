package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val sku: String,
    val name: String,
    val category: String, // WOMEN, MEN, KIDS, BABY, DENIM, SALE
    val subcategory: String, // Tops, Bottoms, Denim, Outerwear, Dresses, Accessories
    val price: Double,
    val cost: Double,
    val marginPercentage: Double,
    val mainImage: String,
    val imagesJson: String, // Comma separated list of images (front, back, side, detail, model, fabric)
    val colorsJson: String, // Comma separated list of color names
    val sizesJson: String, // Comma separated list of sizes
    val fit: String,
    val details: String,
    val material: String,
    val isNewArrival: Boolean = false,
    val isDenim: Boolean = false,
    val isActive: Boolean = true,
    val rating: Float = 4.8f,
    val reviewsCount: Int = 124
)

@Entity(tableName = "product_variants")
data class ProductVariantEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val sku: String,
    val color: String,
    val size: String,
    val stockOnHand: Int,
    val stockReserved: Int,
    val stockInTransit: Int
)

@Entity(tableName = "stores")
data class StoreEntity(
    @PrimaryKey val id: String,
    val code: String,
    val name: String,
    val city: String,
    val postcode: String,
    val country: String,
    val address: String,
    val openingHours: String,
    val phone: String,
    val distanceMiles: Double,
    val availableServices: String, // Pickup, Returns, Fitting, Customization
    val isSoHo: Boolean = false,
    val dailySales: Double,
    val dailyTraffic: Int,
    val conversionRate: Double,
    val staffCount: Int,
    val operationalStatus: String // NORMAL, ATTENTION, DELAYED, INCIDENT
)

@Entity(tableName = "store_stock")
data class StoreStockEntity(
    @PrimaryKey val id: String,
    val storeId: String,
    val sku: String,
    val stockOnHand: Int,
    val stockReserved: Int
)

@Entity(tableName = "campaigns")
data class CampaignEntity(
    @PrimaryKey val id: String,
    val name: String,
    val title: String,
    val subtitle: String,
    val imageUrl: String,
    val targetCategory: String,
    val targetMarket: String,
    val startDate: String,
    val endDate: String,
    val budget: Double,
    val status: String, // DRAFT, REVIEW, APPROVED, LIVE
    val performanceRevenue: Double = 0.0,
    val performanceOrders: Int = 0
)

@Entity(tableName = "content_blocks")
data class ContentBlockEntity(
    @PrimaryKey val id: String,
    val blockType: String, // HERO, BANNER, EDITORIAL
    val title: String,
    val subtitle: String,
    val ctaText: String,
    val ctaCategory: String,
    val imageUrl: String,
    val isPublished: Boolean = true
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey val id: String,
    val name: String,
    val email: String,
    val avatarUrl: String,
    val memberTier: String, // ENCORE MEMBER, ENCORE VIP, ENCORE ICON
    val points: Int,
    val totalSpend: Double,
    val totalOrders: Int,
    val rewardsBalance: Double,
    val savedItemSkusJson: String, // Comma separated SKUs
    val defaultAddress: String,
    val defaultPaymentMethod: String,
    val region: String = "North America / USA"
)

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey val id: String,
    val sku: String,
    val productId: String,
    val productName: String,
    val color: String,
    val size: String,
    val price: Double,
    val imageUrl: String,
    val quantity: Int
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String,
    val orderNumber: String,
    val customerId: String,
    val customerName: String,
    val totalAmount: Double,
    val itemsCount: Int,
    val status: String, // PREPARING, SHIPPED, OUT_FOR_DELIVERY, DELIVERED, RETURNED
    val channel: String, // ONLINE, IN_STORE
    val dateTimestamp: Long,
    val itemsJson: String, // JSON array string or formatted items
    val shippingAddress: String,
    val paymentMethod: String,
    val trackingNumber: String = ""
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val timestamp: String,
    val userRole: String,
    val action: String,
    val targetObject: String,
    val oldValue: String,
    val newValue: String
)
