package com.example.data.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.GapDatabase
import com.example.data.local.entity.*
import com.example.data.repository.GapRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppMode { CUSTOMER, HQ }

enum class CustomerScreen {
    HOME, SHOP, PRODUCT_DETAIL, BAG, CHECKOUT, ACCOUNT, REWARDS, STORES, SEARCH
}

enum class HqScreen {
    GAP_TODAY, PRODUCT, MERCHANDISING, INVENTORY, STORES, ECOMMERCE, ORDERS, CUSTOMERS, CAMPAIGNS, CONTENT, AUDIT_LOG, CUSTOMER_EXPERIENCE
}

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository: GapRepository

    // App Mode
    private val _appMode = MutableStateFlow(AppMode.CUSTOMER)
    val appMode: StateFlow<AppMode> = _appMode.asStateFlow()

    // Customer Navigation
    private val _customerScreen = MutableStateFlow(CustomerScreen.HOME)
    val customerScreen: StateFlow<CustomerScreen> = _customerScreen.asStateFlow()

    private val _selectedCategory = MutableStateFlow("DENIM")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedProductId = MutableStateFlow<String?>("prod_90s_loose_jeans")
    val selectedProductId: StateFlow<String?> = _selectedProductId.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedStoreId = MutableStateFlow<String?>("store_soho")
    val selectedStoreId: StateFlow<String?> = _selectedStoreId.asStateFlow()

    // HQ Navigation & Roles
    private val _hqScreen = MutableStateFlow(HqScreen.GAP_TODAY)
    val hqScreen: StateFlow<HqScreen> = _hqScreen.asStateFlow()

    private val _hqUserRole = MutableStateFlow("MERCHANDISER")
    val hqUserRole: StateFlow<String> = _hqUserRole.asStateFlow()

    // Toast and Animation feedback
    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private val _latestOrderPlaced = MutableStateFlow<OrderEntity?>(null)
    val latestOrderPlaced: StateFlow<OrderEntity?> = _latestOrderPlaced.asStateFlow()

    // Reactive Data Flows from Repository
    val products: StateFlow<List<ProductEntity>>
    val stores: StateFlow<List<StoreEntity>>
    val campaigns: StateFlow<List<CampaignEntity>>
    val liveCampaigns: StateFlow<List<CampaignEntity>>
    val contentBlocks: StateFlow<List<ContentBlockEntity>>
    val currentCustomer: StateFlow<CustomerEntity?>
    val allCustomers: StateFlow<List<CustomerEntity>>
    val cartItems: StateFlow<List<CartItemEntity>>
    val allOrders: StateFlow<List<OrderEntity>>
    val auditLogs: StateFlow<List<AuditLogEntity>>

    init {
        val db = GapDatabase.getDatabase(application)
        repository = GapRepository(db)

        products = repository.allProducts.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
        stores = repository.allStores.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
        campaigns = repository.allCampaigns.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
        liveCampaigns = repository.liveCampaigns.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
        contentBlocks = repository.publishedContent.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
        currentCustomer = repository.currentCustomer.stateIn(viewModelScope, SharingStarted.Lazily, null)
        allCustomers = repository.allCustomers.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
        cartItems = repository.cartItems.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
        allOrders = repository.allOrders.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
        auditLogs = repository.auditLogs.stateIn(viewModelScope, SharingStarted.Lazily, emptyList())
    }

    fun setAppMode(mode: AppMode) {
        _appMode.value = mode
    }

    fun navigateCustomer(screen: CustomerScreen) {
        _customerScreen.value = screen
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
        _customerScreen.value = CustomerScreen.SHOP
    }

    fun viewProductDetail(productId: String) {
        _selectedProductId.value = productId
        _customerScreen.value = CustomerScreen.PRODUCT_DETAIL
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
        if (query.isNotEmpty() && _customerScreen.value != CustomerScreen.SEARCH) {
            _customerScreen.value = CustomerScreen.SEARCH
        }
    }

    fun selectStore(storeId: String) {
        _selectedStoreId.value = storeId
        _customerScreen.value = CustomerScreen.STORES
    }

    fun navigateHq(screen: HqScreen) {
        _hqScreen.value = screen
    }

    fun setHqUserRole(role: String) {
        _hqUserRole.value = role
        showToast("Switched role to $role")
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    // Customer Actions
    fun addToCart(sku: String, productId: String, productName: String, color: String, size: String, price: Double, imageUrl: String) {
        viewModelScope.launch {
            repository.addToCart(sku, productId, productName, color, size, price, imageUrl)
            showToast("Added $productName ($size) to Bag!")
        }
    }

    fun updateCartQuantity(cartItemId: String, qty: Int) {
        viewModelScope.launch {
            repository.updateCartQuantity(cartItemId, qty)
        }
    }

    fun removeFromCart(cartItemId: String) {
        viewModelScope.launch {
            repository.removeFromCart(cartItemId)
        }
    }

    fun placeOrder(shippingAddress: String, paymentMethod: String) {
        viewModelScope.launch {
            val order = repository.placeOrder(shippingAddress, paymentMethod)
            if (order != null) {
                _latestOrderPlaced.value = order
                _customerScreen.value = CustomerScreen.ACCOUNT
                showToast("Order ${order.orderNumber} placed successfully!")
            }
        }
    }

    fun toggleSavedItem(sku: String) {
        viewModelScope.launch {
            repository.toggleSavedItem(sku)
            showToast("Updated Saved Items")
        }
    }

    // HQ Actions
    fun updateProductPrice(productId: String, newPrice: Double) {
        viewModelScope.launch {
            repository.updateProductPrice(productId, newPrice, _hqUserRole.value)
            showToast("Updated price to $$newPrice. Live in Customer App!")
        }
    }

    fun updateStockOnHand(sku: String, storeId: String, newStock: Int) {
        viewModelScope.launch {
            repository.updateStockOnHand(sku, storeId, newStock, _hqUserRole.value)
            showToast("Updated stock to $newStock units. Refreshed across platform.")
        }
    }

    fun publishCampaign(campaignId: String, isLive: Boolean) {
        viewModelScope.launch {
            repository.publishCampaign(campaignId, isLive, _hqUserRole.value)
            showToast(if (isLive) "Campaign PUBLISHED live to Gap App!" else "Campaign moved to DRAFT.")
        }
    }

    fun createCampaign(name: String, title: String, subtitle: String, imageUrl: String, targetCategory: String, budget: Double, startDate: String, endDate: String) {
        viewModelScope.launch {
            repository.createCampaign(name, title, subtitle, imageUrl, targetCategory, budget, startDate, endDate, _hqUserRole.value)
            showToast("New Campaign '$name' Created & Published!")
        }
    }

    fun updateOrderStatus(orderId: String, newStatus: String) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, newStatus, _hqUserRole.value)
            showToast("Order status updated to $newStatus.")
        }
    }
}
