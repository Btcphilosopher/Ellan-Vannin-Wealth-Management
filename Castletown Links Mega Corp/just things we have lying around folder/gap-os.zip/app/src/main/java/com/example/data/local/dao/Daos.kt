package com.example.data.local.dao

import androidx.room.*
import com.example.data.local.entity.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products WHERE isActive = 1")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :id LIMIT 1")
    suspend fun getProductById(id: String): ProductEntity?

    @Query("SELECT * FROM products WHERE sku = :sku LIMIT 1")
    suspend fun getProductBySku(sku: String): ProductEntity?

    @Query("SELECT * FROM products WHERE category = :category AND isActive = 1")
    fun getProductsByCategory(category: String): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)

    @Update
    suspend fun updateProduct(product: ProductEntity)

    @Query("UPDATE products SET price = :newPrice WHERE id = :productId")
    suspend fun updateProductPrice(productId: String, newPrice: Double)

    @Query("SELECT * FROM product_variants WHERE productId = :productId")
    fun getVariantsForProduct(productId: String): Flow<List<ProductVariantEntity>>

    @Query("SELECT * FROM product_variants WHERE sku = :sku")
    suspend fun getVariantsBySku(sku: String): List<ProductVariantEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVariants(variants: List<ProductVariantEntity>)

    @Query("UPDATE product_variants SET stockOnHand = :newStock WHERE sku = :sku AND color = :color AND size = :size")
    suspend fun updateVariantStock(sku: String, color: String, size: String, newStock: Int)

    @Query("UPDATE product_variants SET stockOnHand = CASE WHEN stockOnHand >= :qty THEN stockOnHand - :qty ELSE 0 END, stockReserved = stockReserved + :qty WHERE sku = :sku")
    suspend fun decrementStockForSku(sku: String, qty: Int)
}

@Dao
interface StoreDao {
    @Query("SELECT * FROM stores")
    fun getAllStores(): Flow<List<StoreEntity>>

    @Query("SELECT * FROM stores WHERE id = :id LIMIT 1")
    suspend fun getStoreById(id: String): StoreEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStores(stores: List<StoreEntity>)

    @Query("SELECT * FROM store_stock WHERE storeId = :storeId")
    fun getStockForStore(storeId: String): Flow<List<StoreStockEntity>>

    @Query("SELECT * FROM store_stock WHERE storeId = :storeId AND sku = :sku LIMIT 1")
    suspend fun getStoreStockForSku(storeId: String, sku: String): StoreStockEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStoreStock(stock: List<StoreStockEntity>)

    @Query("UPDATE store_stock SET stockOnHand = :newStock WHERE storeId = :storeId AND sku = :sku")
    suspend fun updateStoreStock(storeId: String, sku: String, newStock: Int)
}

@Dao
interface CampaignDao {
    @Query("SELECT * FROM campaigns")
    fun getAllCampaigns(): Flow<List<CampaignEntity>>

    @Query("SELECT * FROM campaigns WHERE status = 'LIVE'")
    fun getLiveCampaigns(): Flow<List<CampaignEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCampaign(campaign: CampaignEntity)

    @Query("UPDATE campaigns SET status = :status WHERE id = :id")
    suspend fun updateCampaignStatus(id: String, status: String)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCampaigns(campaigns: List<CampaignEntity>)
}

@Dao
interface ContentDao {
    @Query("SELECT * FROM content_blocks WHERE isPublished = 1")
    fun getPublishedContent(): Flow<List<ContentBlockEntity>>

    @Query("SELECT * FROM content_blocks")
    fun getAllContent(): Flow<List<ContentBlockEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContentBlocks(blocks: List<ContentBlockEntity>)

    @Update
    suspend fun updateContentBlock(block: ContentBlockEntity)
}

@Dao
interface CustomerDao {
    @Query("SELECT * FROM customers")
    fun getAllCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getCustomerById(id: String): CustomerEntity?

    @Query("SELECT * FROM customers LIMIT 1")
    fun getCurrentCustomer(): Flow<CustomerEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomers(customers: List<CustomerEntity>)

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)
}

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<CartItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: CartItemEntity)

    @Query("UPDATE cart_items SET quantity = :quantity WHERE id = :id")
    suspend fun updateQuantity(id: String, quantity: Int)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItem(id: String)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY dateTimestamp DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE customerId = :customerId ORDER BY dateTimestamp DESC")
    fun getCustomerOrders(customerId: String): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrders(orders: List<OrderEntity>)

    @Query("UPDATE orders SET status = :newStatus WHERE id = :orderId")
    suspend fun updateOrderStatus(orderId: String, newStatus: String)
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_logs ORDER BY id DESC")
    fun getAllAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity)
}
