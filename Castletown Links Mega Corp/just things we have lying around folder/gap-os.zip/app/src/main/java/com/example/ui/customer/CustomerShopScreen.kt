package com.example.ui.customer

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.local.entity.ProductEntity
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun CustomerShopScreen(viewModel: MainViewModel) {
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val products by viewModel.products.collectAsState()

    var selectedSubcategory by remember { mutableStateOf("All") }

    val categories = listOf("WOMEN", "MEN", "KIDS", "BABY", "DENIM", "SALE")
    val subcategories = listOf("All", "New Arrivals", "Denim", "Tops", "Bottoms", "Outerwear", "Accessories")

    val filteredProducts = products.filter { prod ->
        val categoryMatch = if (selectedCategory == "SALE") prod.price < 50.0 else prod.category == selectedCategory || (selectedCategory == "DENIM" && prod.isDenim)
        val subcategoryMatch = when (selectedSubcategory) {
            "All" -> true
            "New Arrivals" -> prod.isNewArrival
            else -> prod.subcategory.equals(selectedSubcategory, ignoreCase = true)
        }
        categoryMatch && subcategoryMatch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(GapWhite)
    ) {
        // Main Category Tabs
        ScrollableTabRow(
            selectedTabIndex = categories.indexOf(selectedCategory).coerceAtLeast(0),
            edgePadding = 16.dp,
            containerColor = GapWhite,
            contentColor = GapBlue,
            divider = { Divider(color = GapBorderGrey, thickness = 1.dp) }
        ) {
            categories.forEach { cat ->
                val isSelected = cat == selectedCategory
                Tab(
                    selected = isSelected,
                    onClick = { viewModel.selectCategory(cat) },
                    modifier = Modifier.testTag("shop_category_$cat")
                ) {
                    Text(
                        text = cat,
                        fontSize = 13.sp,
                        fontWeight = if (isSelected) FontWeight.Black else FontWeight.Bold,
                        color = if (isSelected) GapBlue else GapTextMuted,
                        modifier = Modifier.padding(vertical = 14.dp, horizontal = 10.dp)
                    )
                }
            }
        }

        // Subcategory Pills Filter
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            subcategories.forEach { sub ->
                val isSelected = sub == selectedSubcategory
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedSubcategory = sub },
                    label = { Text(sub, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = GapBlue,
                        selectedLabelColor = Color.White,
                        containerColor = GapWarmGrey,
                        labelColor = GapTextDark
                    ),
                    shape = RoundedCornerShape(0.dp),
                    border = null,
                    modifier = Modifier.testTag("shop_subcategory_$sub")
                )
            }
        }

        Divider(color = GapBorderGrey, thickness = 0.5.dp)

        // Products Header Count
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$selectedCategory ${if (selectedSubcategory != "All") "• $selectedSubcategory" else ""}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                color = GapTextDark
            )
            Text(
                text = "${filteredProducts.size} PRODUCTS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = GapTextMuted
            )
        }

        // 2-Column Product Grid
        if (filteredProducts.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No products found in this collection.", color = GapTextMuted, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { selectedSubcategory = "All" },
                        colors = ButtonDefaults.buttonColors(containerColor = GapBlue)
                    ) {
                        Text("RESET FILTERS")
                    }
                }
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                val chunks = filteredProducts.chunked(2)
                chunks.forEach { rowItems ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        rowItems.forEach { product ->
                            Box(modifier = Modifier.weight(1f)) {
                                ProductGridCard(
                                    product = product,
                                    onViewProduct = { viewModel.viewProductDetail(product.id) },
                                    onQuickAdd = {
                                        val firstColor = product.colorsJson.split(",").firstOrNull()?.trim() ?: "Default"
                                        val firstSize = product.sizesJson.split(",").firstOrNull()?.trim() ?: "M"
                                        viewModel.addToCart(
                                            sku = product.sku,
                                            productId = product.id,
                                            productName = product.name,
                                            color = firstColor,
                                            size = firstSize,
                                            price = product.price,
                                            imageUrl = product.mainImage
                                        )
                                    },
                                    onFavoriteClick = { viewModel.toggleSavedItem(product.sku) }
                                )
                            }
                        }
                        if (rowItems.size == 1) {
                            Spacer(modifier = Modifier.weight(1f))
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
fun ProductGridCard(
    product: ProductEntity,
    onViewProduct: () -> Unit,
    onQuickAdd: () -> Unit,
    onFavoriteClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("shop_item_${product.sku}")
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(240.dp)
                .background(GapWarmGrey)
                .clickable { onViewProduct() }
        ) {
            AsyncImage(
                model = product.mainImage,
                contentDescription = product.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )

            // Favorite Icon
            IconButton(
                onClick = onFavoriteClick,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
            ) {
                Icon(
                    imageVector = Icons.Outlined.FavoriteBorder,
                    contentDescription = "Favorite",
                    tint = GapTextDark
                )
            }

            if (product.isNewArrival) {
                Surface(
                    color = GapBlue,
                    modifier = Modifier.align(Alignment.TopStart)
                ) {
                    Text(
                        text = "NEW",
                        color = Color.White,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Black,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = product.name,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = GapTextDark,
            maxLines = 1,
            modifier = Modifier.clickable { onViewProduct() }
        )

        Text(
            text = product.colorsJson,
            fontSize = 11.sp,
            color = GapTextMuted,
            maxLines = 1
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "$${String.format("%.2f", product.price)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Black,
                color = GapBlue
            )

            // Quick Add Button
            OutlinedButton(
                onClick = onQuickAdd,
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                shape = RoundedCornerShape(0.dp),
                border = BorderStroke(1.dp, GapBlue),
                modifier = Modifier
                    .height(28.dp)
                    .testTag("quick_add_${product.sku}")
            ) {
                Text(
                    text = "QUICK ADD",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = GapBlue
                )
            }
        }
    }
}
