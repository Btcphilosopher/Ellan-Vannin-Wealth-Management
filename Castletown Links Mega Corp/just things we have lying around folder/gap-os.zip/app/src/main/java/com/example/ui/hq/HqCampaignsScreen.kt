package com.example.ui.hq

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ui.MainViewModel
import com.example.ui.theme.*

@Composable
fun HqCampaignsScreen(viewModel: MainViewModel) {
    val campaigns by viewModel.campaigns.collectAsState()

    var showCreateDialog by remember { mutableStateOf(false) }
    var campName by remember { mutableStateOf("ICONIC DENIM 2026") }
    var campTitle by remember { mutableStateOf("NEW DENIM") }
    var campSubtitle by remember { mutableStateOf("RELAXED FITS & VINTAGE WASHES") }
    var campImageUrl by remember { mutableStateOf("https://images.unsplash.com/photo-1582552938357-32b906df40cb?w=1200&q=80") }
    var campCategory by remember { mutableStateOf("DENIM") }
    var campBudget by remember { mutableStateOf("500000") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(HqDarkBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "CAMPAIGN MANAGEMENT & BUILDER",
                    color = HqTextBright,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "PUBLISHED CAMPAIGN FEEDS DIRECTLY TO GAP CUSTOMER APP",
                    color = HqTextMuted,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { showCreateDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = GapAccentBlue),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier.testTag("create_campaign_btn")
            ) {
                Text("+ BUILD CAMPAIGN", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Campaign List
        Surface(
            color = HqSurfaceDark,
            border = BorderStroke(1.dp, HqSurfaceBorder),
            modifier = Modifier.fillMaxWidth().testTag("hq_campaigns_table")
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("MARKET CAMPAIGNS", color = HqTextBright, fontSize = 13.sp, fontWeight = FontWeight.Black)
                Spacer(modifier = Modifier.height(12.dp))

                campaigns.forEach { camp ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.5f)) {
                            Text(camp.name, color = HqTextBright, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("${camp.targetCategory} • Budget: $${String.format("%,.0f", camp.budget)}", color = HqTextMuted, fontSize = 11.sp)
                        }

                        Surface(
                            color = if (camp.status == "LIVE") StatusSuccess.copy(alpha = 0.2f) else HqSurfaceBorder,
                            shape = RoundedCornerShape(2.dp)
                        ) {
                            Text(
                                text = camp.status,
                                color = if (camp.status == "LIVE") StatusSuccess else HqTextMuted,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                            )
                        }

                        Button(
                            onClick = {
                                val makeLive = camp.status != "LIVE"
                                viewModel.publishCampaign(camp.id, makeLive)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (camp.status == "LIVE") StatusDanger else GapAccentBlue
                            ),
                            shape = RoundedCornerShape(2.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                            modifier = Modifier.padding(start = 12.dp).height(28.dp).testTag("toggle_campaign_${camp.id}")
                        ) {
                            Text(if (camp.status == "LIVE") "UNPUBLISH" else "PUBLISH LIVE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Divider(color = HqSurfaceBorder, thickness = 0.5.dp)
                }
            }
        }

        // Campaign Builder Modal (30 - CAMPAIGN BUILDER)
        if (showCreateDialog) {
            AlertDialog(
                onDismissRequest = { showCreateDialog = false },
                containerColor = HqSurfaceDark,
                title = { Text("BUILD NEW GAP CAMPAIGN", color = HqTextBright, fontSize = 16.sp, fontWeight = FontWeight.Black) },
                text = {
                    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                        OutlinedTextField(
                            value = campName,
                            onValueChange = { campName = it },
                            label = { Text("Campaign Internal Name") },
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = HqTextBright, unfocusedTextColor = HqTextBright),
                            modifier = Modifier.fillMaxWidth().testTag("camp_name_input")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = campTitle,
                            onValueChange = { campTitle = it },
                            label = { Text("Hero Title (Shown in Gap App)") },
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = HqTextBright, unfocusedTextColor = HqTextBright),
                            modifier = Modifier.fillMaxWidth().testTag("camp_title_input")
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = campSubtitle,
                            onValueChange = { campSubtitle = it },
                            label = { Text("Subtitle") },
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = HqTextBright, unfocusedTextColor = HqTextBright),
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = campImageUrl,
                            onValueChange = { campImageUrl = it },
                            label = { Text("Photography Image URL") },
                            colors = OutlinedTextFieldDefaults.colors(focusedTextColor = HqTextBright, unfocusedTextColor = HqTextBright),
                            modifier = Modifier.fillMaxWidth().testTag("camp_image_input")
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.createCampaign(
                                name = campName,
                                title = campTitle,
                                subtitle = campSubtitle,
                                imageUrl = campImageUrl,
                                targetCategory = campCategory,
                                budget = campBudget.toDoubleOrNull() ?: 500000.0,
                                startDate = "2026-09-23",
                                endDate = "2026-12-31"
                            )
                            showCreateDialog = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GapAccentBlue),
                        modifier = Modifier.testTag("publish_new_campaign_btn")
                    ) {
                        Text("PUBLISH LIVE TO GAP APP", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showCreateDialog = false }) {
                        Text("CANCEL", color = HqTextMuted)
                    }
                }
            )
        }
    }
}
