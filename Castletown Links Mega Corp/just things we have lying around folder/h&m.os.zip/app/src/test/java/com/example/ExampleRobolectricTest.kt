package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34]) // Robolectric runs stable on SDK 34/35
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("H&M.OS", appName)
  }

  @Test
  fun `verify loyalty points calculation`() {
    // 1 spent = 1 point
    val orderTotal = 59.98
    val earnedPoints = orderTotal.toInt()
    assertEquals(59, earnedPoints)
  }

  @Test
  fun `verify voucher points threshold logic`() {
    // every 100 points crossed converts into 1 voucher, leaving the remainder
    val initialPoints = 342
    val pointsEarned = 78
    
    val totalPoints = initialPoints + pointsEarned // 420
    val newVouchers = totalPoints / 100 // 4
    val remainingPoints = totalPoints % 100 // 20
    
    assertEquals(420, totalPoints)
    assertEquals(4, newVouchers)
    assertEquals(20, remainingPoints)
  }
}
