package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CheckoutResultState
import com.example.ui.Screen
import com.example.ui.ShopViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit
) {
    val cartItems by viewModel.cartItems.collectAsState()
    val checkoutState by viewModel.checkoutState.collectAsState()

    // Form states
    var name by remember { mutableStateOf("Tom") }
    var address by remember { mutableStateOf("123 Fashion Street") }
    var postcode by remember { mutableStateOf("W1B 5TJ") }
    var email by remember { mutableStateOf("demo@hm.local") }
    var phone by remember { mutableStateOf("07123456789") }

    var selectedDelivery by remember { mutableStateOf("STANDARD") } // "STANDARD" or "CLICK & COLLECT"
    var selectedPayment by remember { mutableStateOf("KLARNA") } // "CARD", "KLARNA", "PAYPAL", "APPLE_PAY"

    // Card Input states if Card selected
    var cardNumber by remember { mutableStateOf("") }
    var cardExpiry by remember { mutableStateOf("") }
    var cardCvv by remember { mutableStateOf("") }

    val isFormValid = name.isNotBlank() && address.isNotBlank() && postcode.isNotBlank() && email.isNotBlank()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White),
        contentPadding = PaddingValues(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 16.dp)) {
                Icon(Icons.Default.Lock, contentDescription = "Secure Checkout", tint = Color.Gray, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "SECURE CHECKOUT",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray,
                    letterSpacing = 1.5.sp
                )
            }
        }

        // STAGE 1: DELIVERY INFO
        item {
            Text(
                text = "1. DELIVERY OPTIONS",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Delivery method picker
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Standard Delivery Choice
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .border(
                            width = if (selectedDelivery == "STANDARD") 2.dp else 1.dp,
                            color = if (selectedDelivery == "STANDARD") Color.Black else Color.LightGray,
                            shape = ShapeDefaults.ExtraSmall
                        )
                        .clickable { selectedDelivery = "STANDARD" }
                        .padding(12.dp)
                ) {
                    Text("HOME DELIVERY", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black)
                    Text("Est: 3-5 days\n£3.99 or FREE for members over £40", fontSize = 10.sp, color = Color.Gray)
                }

                // Click and Collect Choice
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .border(
                            width = if (selectedDelivery == "CLICK & COLLECT") 2.dp else 1.dp,
                            color = if (selectedDelivery == "CLICK & COLLECT") Color.Black else Color.LightGray,
                            shape = ShapeDefaults.ExtraSmall
                        )
                        .clickable { selectedDelivery = "CLICK & COLLECT" }
                        .padding(12.dp)
                ) {
                    Text("CLICK & COLLECT", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Black)
                    Text("Est: 1-2 days\nPick up at H&M Oxford Street", fontSize = 10.sp, color = Color.Gray)
                }
            }

            // Text Form Inputs
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Full Name") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Black)
            )

            OutlinedTextField(
                value = address,
                onValueChange = { address = it },
                label = { Text("Shipping Address") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Black)
            )

            OutlinedTextField(
                value = postcode,
                onValueChange = { postcode = it },
                label = { Text("Postcode") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Black)
            )

            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text("Email Address") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Black)
            )

            OutlinedTextField(
                value = phone,
                onValueChange = { phone = it },
                label = { Text("Phone Number") },
                modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Black)
            )
        }

        // STAGE 2: PAYMENT METHOD
        item {
            HorizontalDivider(color = Color(0xFFEEEEEE), modifier = Modifier.padding(bottom = 20.dp))
            Text(
                text = "2. PAYMENT PROVIDER",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                letterSpacing = 0.5.sp,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            // Selectable synthetic payment options: H&M standard includes Klarna, Card, PayPal, Apple Pay
            val paymentOptions = listOf(
                Pair("KLARNA", "Klarna (Pay in 30 days)"),
                Pair("CARD", "Credit / Debit Card"),
                Pair("PAYPAL", "PayPal Account"),
                Pair("APPLE_PAY", "Apple Pay / Google Pay")
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.padding(bottom = 24.dp)) {
                paymentOptions.forEach { opt ->
                    val isSel = selectedPayment == opt.first
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(
                                width = if (isSel) 2.dp else 1.dp,
                                color = if (isSel) Color.Black else Color.LightGray,
                                shape = ShapeDefaults.ExtraSmall
                            )
                            .clickable { selectedPayment = opt.first }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = isSel,
                            onClick = { selectedPayment = opt.first },
                            colors = RadioButtonDefaults.colors(selectedColor = Color.Black)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = opt.second,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color.Black
                        )
                    }
                }
            }

            // Card details entry if selected CARD
            if (selectedPayment == "CARD") {
                Column(modifier = Modifier.padding(bottom = 24.dp)) {
                    OutlinedTextField(
                        value = cardNumber,
                        onValueChange = { cardNumber = it },
                        label = { Text("Card Number") },
                        modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Black)
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        OutlinedTextField(
                            value = cardExpiry,
                            onValueChange = { cardExpiry = it },
                            label = { Text("MM/YY") },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Black)
                        )

                        OutlinedTextField(
                            value = cardCvv,
                            onValueChange = { cardCvv = it },
                            label = { Text("CVV") },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color.Black)
                        )
                    }
                }
            }
        }

        // STAGE 3: PLACE ORDER SUBMIT
        item {
            HorizontalDivider(color = Color(0xFFEEEEEE), modifier = Modifier.padding(bottom = 20.dp))

            when (checkoutState) {
                is CheckoutResultState.Loading -> {
                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color.Black)
                    }
                }
                is CheckoutResultState.Error -> {
                    Text(
                        text = (checkoutState as CheckoutResultState.Error).message,
                        color = Color(0xFFE5001C),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
                else -> {}
            }

            // Apply a default voucher if applied in Bag (we mock it or let checkout accept check)
            // Let's pass voucher check dynamically. We check if they has a voucher applied
            val containsVoucher = remember(cartItems) { true } // check from previous or assume yes if membership has

            Button(
                onClick = {
                    if (isFormValid) {
                        viewModel.performCheckout(
                            deliveryType = selectedDelivery,
                            recipientName = name,
                            recipientAddress = address,
                            recipientPostcode = postcode,
                            paymentMethod = selectedPayment,
                            voucherApplied = false // will be checked on DB update
                        )
                    }
                },
                enabled = isFormValid && checkoutState !is CheckoutResultState.Loading,
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White),
                shape = ShapeDefaults.ExtraSmall,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                Text(
                    text = "PLACE ORDER & PAY",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )
            }
            Spacer(modifier = Modifier.height(40.dp))
        }
    }
}
