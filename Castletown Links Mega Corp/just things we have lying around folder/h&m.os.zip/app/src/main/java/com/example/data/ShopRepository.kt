package com.example.data

import android.content.Context
import androidx.room.Room
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import java.util.UUID
import kotlin.random.Random

class ShopRepository(private val context: Context) {

    private val db: AppDatabase by lazy {
        Room.databaseBuilder(
            context.applicationContext,
            AppDatabase::class.java,
            "hm_os_database"
        ).build()
    }

    private val productDao = db.productDao()
    private val cartDao = db.cartDao()
    private val savedDao = db.savedDao()
    private val membershipDao = db.membershipDao()
    private val orderDao = db.orderDao()
    private val storeDao = db.storeDao()

    // Expose flows to the UI
    val cartItems: Flow<List<CartItemEntity>> = cartDao.getCartItems()
    val savedItems: Flow<List<SavedItemEntity>> = savedDao.getSavedItems()
    val allOrders: Flow<List<OrderEntity>> = orderDao.getAllOrders()
    val allStores: Flow<List<StoreEntity>> = storeDao.getAllStores()

    fun getMembership(email: String = "demo@hm.local"): Flow<MembershipEntity?> =
        membershipDao.getMembership(email)

    fun getProductsByCategory(category: String): Flow<List<ProductEntity>> = flow {
        if (category.equals("New In", ignoreCase = true)) {
            productDao.getAllProducts().collect { list ->
                emit(list.filter { it.isNewIn })
            }
        } else if (category.equals("Sale", ignoreCase = true)) {
            productDao.getAllProducts().collect { list ->
                emit(list.filter { it.category == "Sale" || it.price < 25.0 }) // mock sale
            }
        } else {
            productDao.getProductsByCategory(category).collect { emit(it) }
        }
    }

    fun getProductsBySubCategory(subCategory: String): Flow<List<ProductEntity>> =
        productDao.getProductsBySubCategory(subCategory)

    fun searchProducts(query: String): Flow<List<ProductEntity>> = flow {
        productDao.getAllProducts().collect { list ->
            if (query.isBlank()) {
                emit(list.take(20))
            } else {
                emit(list.filter { 
                    it.name.contains(query, ignoreCase = true) || 
                    it.description.contains(query, ignoreCase = true) ||
                    it.subCategory.contains(query, ignoreCase = true)
                })
            }
        }
    }

    suspend fun getProductById(id: String): ProductEntity? = withContext(Dispatchers.IO) {
        productDao.getProductById(id)
    }

    fun getVariantsForProduct(productId: String): Flow<List<ProductVariantEntity>> =
        productDao.getVariantsForProduct(productId)

    fun isProductSaved(productId: String): Flow<Boolean> =
        savedDao.isProductSaved(productId)

    // Saved Items Actions
    suspend fun toggleSavedItem(productId: String) = withContext(Dispatchers.IO) {
        val currentlySaved = savedDao.getSavedItems().first().any { it.productId == productId }
        if (currentlySaved) {
            savedDao.unsaveProduct(productId)
        } else {
            savedDao.saveProduct(SavedItemEntity(productId))
        }
    }

    // Cart Actions
    suspend fun addToCart(variantId: String, productId: String, colour: String, size: String, quantity: Int) = withContext(Dispatchers.IO) {
        val existing = cartDao.getCartItemByVariant(variantId)
        if (existing != null) {
            cartDao.updateCartItem(existing.copy(quantity = existing.quantity + quantity))
        } else {
            cartDao.insertCartItem(CartItemEntity(
                variantId = variantId,
                productId = productId,
                colour = colour,
                size = size,
                quantity = quantity
            ))
        }
    }

    suspend fun updateCartQuantity(cartItemId: Int, newQty: Int) = withContext(Dispatchers.IO) {
        if (newQty <= 0) {
            cartDao.deleteCartItem(cartItemId)
        } else {
            val items = cartDao.getCartItems().first()
            val item = items.find { it.id == cartItemId }
            if (item != null) {
                cartDao.updateCartItem(item.copy(quantity = newQty))
            }
        }
    }

    suspend fun removeFromCart(cartItemId: Int) = withContext(Dispatchers.IO) {
        cartDao.deleteCartItem(cartItemId)
    }

    suspend fun getVariantById(variantId: String): ProductVariantEntity? = withContext(Dispatchers.IO) {
        productDao.getVariantById(variantId)
    }

    // Checkout & Order creation
    suspend fun processCheckout(
        deliveryType: String,
        recipientName: String,
        recipientAddress: String,
        recipientPostcode: String,
        paymentMethod: String,
        voucherApplied: Boolean = false
    ): Map<String, Any> = withContext(Dispatchers.IO) {
        val cartList = cartDao.getCartItems().first()
        if (cartList.isEmpty()) {
            throw IllegalStateException("Cart is empty")
        }

        var subtotal = 0.0
        val itemsToInsert = mutableListOf<OrderItemEntity>()
        val orderId = "HM-" + Random.nextInt(10000, 99999).toString()

        for (cartItem in cartList) {
            val product = productDao.getProductById(cartItem.productId) ?: continue
            val variant = productDao.getVariantById(cartItem.variantId) ?: continue

            if (variant.stock < cartItem.quantity) {
                throw IllegalStateException("Insufficient stock for ${product.name} (${variant.size})")
            }

            subtotal += product.price * cartItem.quantity
            itemsToInsert.add(OrderItemEntity(
                orderId = orderId,
                productId = cartItem.productId,
                productName = product.name,
                colour = cartItem.colour,
                size = cartItem.size,
                price = product.price,
                quantity = cartItem.quantity,
                imageUrl = product.images.split(",").firstOrNull() ?: ""
            ))

            // Decrement Stock
            productDao.updateVariantStock(variant.id, variant.stock - cartItem.quantity)
        }

        var discount = 0.0
        if (voucherApplied) {
            discount = 3.0 // £3 bonus voucher
        }

        val deliveryFee = if (subtotal > 40.0) 0.0 else 3.99
        val total = (subtotal - discount + deliveryFee).coerceAtLeast(0.0)

        // Save order
        val order = OrderEntity(
            id = orderId,
            total = total,
            date = System.currentTimeMillis(),
            status = "CONFIRMED",
            deliveryType = deliveryType,
            recipientName = recipientName,
            recipientAddress = recipientAddress,
            recipientPostcode = recipientPostcode,
            paymentMethod = paymentMethod
        )
        orderDao.insertOrder(order)
        orderDao.insertOrderItems(itemsToInsert)

        // Clear cart
        cartDao.clearCart()

        // Update Membership Points
        val membership = membershipDao.getMembershipSync("demo@hm.local")
        if (membership != null) {
            val spentValue = total.toInt()
            val pointsEarned = spentValue // £1 spent = 1 point
            var newPoints = membership.points + pointsEarned
            var newVouchers = membership.voucherCount

            if (voucherApplied) {
                newVouchers = (newVouchers - 1).coerceAtLeast(0)
            }

            // Convert points to vouchers (every 100 points -> +1 £3 voucher)
            // But let's check standard UK rules: 100 points -> 1 voucher. Let's say we check if we crossed a threshold.
            // Simplified: if newPoints >= 100, we subtract 100 and add 1 voucher
            while (newPoints >= 100) {
                newPoints -= 100
                newVouchers += 1
            }

            membershipDao.saveMembership(membership.copy(
                points = newPoints,
                voucherCount = newVouchers
            ))
        }

        return@withContext mapOf(
            "orderId" to orderId,
            "status" to "CONFIRMED",
            "total" to total,
            "subtotal" to subtotal,
            "discount" to discount,
            "delivery" to deliveryFee
        )
    }

    // Seeder
    suspend fun seedDatabaseIfNeeded() = withContext(Dispatchers.IO) {
        val existingCount = productDao.getAllProducts().first().size
        if (existingCount > 0) return@withContext

        // Initialize membership
        membershipDao.saveMembership(MembershipEntity(
            id = "demo@hm.local",
            name = "Tom",
            email = "demo@hm.local",
            points = 342,
            voucherCount = 1
        ))

        // Initialize stores
        val initialStores = listOf(
            StoreEntity("st-1", "H&M Oxford Street", "261-271 Oxford St, London W1C 2DK", "09:00 - 21:00", "LADIES, MEN, KIDS, BEAUTY, HOME, SCAN & BUY"),
            StoreEntity("st-2", "H&M Regent Street", "174-176 Regent St, London W1B 5TJ", "10:00 - 20:00", "LADIES, MEN, HOME, IN-STORE PICKUP"),
            StoreEntity("st-3", "H&M Westfield Stratford", "The Arcade, London E20 1EL", "10:00 - 21:00", "LADIES, MEN, KIDS, CLICK & COLLECT")
        )
        storeDao.insertStores(initialStores)

        // Let's create products programmatically to populate the database with substantial inventory (~150-300 items)
        val categories = listOf("Women", "Men", "Kids", "Home", "Beauty")
        val subCategoriesMap = mapOf(
            "Women" to listOf("Jeans", "Knitwear", "Dresses", "Tops", "Jackets & Coats", "Shoes", "Accessories"),
            "Men" to listOf("Jeans", "Knitwear", "Tops", "Jackets & Coats", "Shoes", "Accessories"),
            "Kids" to listOf("Dresses", "Tops", "Jackets & Coats", "Shoes", "Accessories"),
            "Home" to listOf("Accessories"),
            "Beauty" to listOf("Accessories")
        )

        val productNamesMap = mapOf(
            "Women-Jeans" to listOf("Wide-Leg High Jeans", "Mom Fit Ultra Jeans", "Straight Regular Jeans", "Skinny High Denim", "Flared Vintage Trousers", "90s Baggy Fit Jeans"),
            "Women-Knitwear" to listOf("Rib-Knit Wool Cardigan", "Oversized Cashmere Jumper", "Cable-Knit Sweater", "Fine-Knit Turtleneck", "Cropped V-Neck Knit"),
            "Women-Dresses" to listOf("Soft Cotton Jersey Dress", "Satin Midi Slip Dress", "Linen-Blend Wrap Dress", "Pleated Floral Dress", "Ribbed Bodycon Dress"),
            "Women-Tops" to listOf("Relaxed Linen-Blend Shirt", "Ribbed Crop Long-sleeve", "Silk Blend Blouse", "Boxy Organic Tee", "High-neck Sleeveless Top"),
            "Women-Jackets & Coats" to listOf("Oversized Wool Blend Coat", "Water-Repellent Puffer Jacket", "Double-Breasted Trench", "Classic Faux Leather Biker"),
            "Women-Shoes" to listOf("Minimalist Leather Loafers", "Chunky Chelsea Boots", "Classic Canvas Trainers", "Pointed Ankle Heels"),
            "Women-Accessories" to listOf("Structured Leather Shoulder Bag", "Soft Ribbed Beanie", "Retro Cat-Eye Sunglasses", "Gold Hoop Earrings"),
            
            "Men-Jeans" to listOf("Straight Regular Denim", "Slim Fit Stretch Jeans", "Relaxed Cargo Jeans", "Skinny Clean Cut Jeans", "Tapered Utility Denim"),
            "Men-Knitwear" to listOf("Fine-Knit Merino Crewneck", "Ribbed Cotton Cardigan", "Half-Zip Wool Jumper", "Oversized Cable Knit"),
            "Men-Tops" to listOf("Linen-Blend Oxford Shirt", "Heavyweight Cotton Hoodie", "Relaxed Fit Jersey Tee", "Classic Polo Shirt", "Flannel Checked Shacket"),
            "Men-Jackets & Coats" to listOf("Classic Denim Shacket", "Lightweight Puffer Jacket", "Wool-Blend Overcoat", "Waterproof Shell Jacket"),
            "Men-Shoes" to listOf("Suede Chelsea Boots", "Minimalist White Sneakers", "Leather Derby Shoes", "Comfort Slippers"),
            "Men-Accessories" to listOf("Canvas Weekend Tote", "Leather Classic Belt", "Wool Blend Scarf", "Sporty Baseball Cap"),
            
            "Kids-Dresses" to listOf("Floral Tiered Cotton Dress", "Spun Jersey Holiday Dress", "Ribbed Knit Dress"),
            "Kids-Tops" to listOf("Organic Cotton Graphic Tee", "Super-Soft Fleece Hoodie", "Checked Flannel Shirt"),
            "Kids-Jackets & Coats" to listOf("Faux Fur Trimmed Parka", "Waterproof Puffer Jacket", "Lightweight Denim Jacket"),
            "Kids-Shoes" to listOf("Velcro Strap Canvas Sneakers", "Comfy Fleece Lined Boots", "Shiny Party Flats"),
            "Kids-Accessories" to listOf("Ribbed Beanie & Mittens Set", "Fun Character Hair Clip Set", "Cute Animal Pattern Socks"),
            
            "Home-Accessories" to listOf("Pure Linen Cushion Cover", "Scented Candle in Glass Jar", "Woven Cotton Storage Basket", "Ceramic Decorative Vase", "Soft Waffle-Weave Bath Towel"),
            "Beauty-Accessories" to listOf("Long-Lasting Glossy Nail Polish", "Hydrating Face Mask Set", "Nourishing Shea Butter Hand Cream", "Volume Boosting Mascara", "Satin Pillowcase & Sleep Mask Set")
        )

        val imageMap = mapOf(
            "Women-Jeans" to "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=600&q=80",
            "Women-Knitwear" to "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=600&q=80",
            "Women-Dresses" to "https://images.unsplash.com/photo-1595777457583-95e059d581b8?auto=format&fit=crop&w=600&q=80",
            "Women-Tops" to "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=600&q=80",
            "Women-Jackets & Coats" to "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=600&q=80",
            "Women-Shoes" to "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=600&q=80",
            "Women-Accessories" to "https://images.unsplash.com/photo-1523779917675-45dc89ec157b?auto=format&fit=crop&w=600&q=80",
            
            "Men-Jeans" to "https://images.unsplash.com/photo-1488161628813-04466f872be2?auto=format&fit=crop&w=600&q=80",
            "Men-Knitwear" to "https://images.unsplash.com/photo-1614975058789-41316d0e2e9c?auto=format&fit=crop&w=600&q=80",
            "Men-Tops" to "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=600&q=80",
            "Men-Jackets & Coats" to "https://images.unsplash.com/photo-1551028719-00167b16eac5?auto=format&fit=crop&w=600&q=80",
            "Men-Shoes" to "https://images.unsplash.com/photo-1531310197839-ccf54634509e?auto=format&fit=crop&w=600&q=80",
            "Men-Accessories" to "https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?auto=format&fit=crop&w=600&q=80",
            
            "Kids-Dresses" to "https://images.unsplash.com/photo-1519457431-44ccd64a579b?auto=format&fit=crop&w=600&q=80",
            "Kids-Tops" to "https://images.unsplash.com/photo-1503919545889-aef636e10ad4?auto=format&fit=crop&w=600&q=80",
            "Kids-Jackets & Coats" to "https://images.unsplash.com/photo-1471286174243-e7a4dbf3bc9c?auto=format&fit=crop&w=600&q=80",
            "Kids-Shoes" to "https://images.unsplash.com/photo-1514989940723-e8e5163ccbe8?auto=format&fit=crop&w=600&q=80",
            "Kids-Accessories" to "https://images.unsplash.com/photo-1519457431-44ccd64a579b?auto=format&fit=crop&w=600&q=80",
            
            "Home-Accessories" to "https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80",
            "Beauty-Accessories" to "https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&w=600&q=80"
        )

        // Standard details
        val materialsSeed = "100% Organic Cotton, Recycled Polyester blend"
        val careSeed = "Machine wash at 40°C, line dry, warm iron"
        val deliverySeed = "Free standard delivery for members over £40. Next day delivery available for £5.99."
        val returnsSeed = "Free returns online or in-store within 30 days."

        val productsToInsert = mutableListOf<ProductEntity>()
        val variantsToInsert = mutableListOf<ProductVariantEntity>()

        // Unique item count
        var productIndex = 1

        for (category in categories) {
            val subs = subCategoriesMap[category] ?: emptyList()
            for (sub in subs) {
                val names = productNamesMap["$category-$sub"] ?: listOf("$category $sub Basic")
                val baseImg = imageMap["$category-$sub"] ?: "https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=600&q=80"
                
                // Add signature scan item
                var listToProcess = names
                if (category == "Men" && sub == "Tops" && !names.contains("Linen-Blend Shirt")) {
                    listToProcess = names + "Linen-Blend Shirt"
                }

                for (name in listToProcess) {
                    val price = when(sub) {
                        "Jackets & Coats" -> Random.nextInt(59, 129) + 0.99
                        "Shoes" -> Random.nextInt(39, 89) + 0.99
                        "Accessories" -> Random.nextInt(8, 29) + 0.99
                        else -> Random.nextInt(14, 49) + 0.99
                    }

                    // Secondary image for hover-fading effect simulation
                    val secondaryImg = baseImg.replace("w=600", "w=601") // slight variation

                    val prodId = "hm-${productIndex}"
                    productIndex++

                    val isNew = Random.nextBoolean()
                    val isTrend = Random.nextBoolean()

                    productsToInsert.add(ProductEntity(
                        id = prodId,
                        name = name,
                        description = "High-quality, stylish $name featuring clean tailoring and a premium design philosophy. A wardrobe staple that pairs easily with modern minimalist styles.",
                        category = category,
                        subCategory = sub,
                        price = price,
                        images = "$baseImg,$secondaryImg",
                        materials = materialsSeed,
                        care = careSeed,
                        delivery = deliverySeed,
                        returns = returnsSeed,
                        isNewIn = isNew,
                        isTrending = isTrend
                    ))

                    // Variants: Colours & Sizes
                    val colours = if (category == "Home" || category == "Beauty") {
                        listOf(
                            Pair("Cream", "#FDFBF7"),
                            Pair("Charcoal", "#2B2B2B")
                        )
                    } else {
                        listOf(
                            Pair("Black", "#000000"),
                            Pair("Cream", "#FAF6F0"),
                            Pair("Grey Melange", "#A6A6A6"),
                            Pair("Denim Blue", "#4B6B94")
                        )
                    }

                    val sizes = if (category == "Home" || category == "Beauty") {
                        listOf("ONE SIZE")
                    } else {
                        listOf("XS", "S", "M", "L", "XL")
                    }

                    for (colour in colours) {
                        for (size in sizes) {
                            val vId = "$prodId-${colour.first.uppercase()}-${size}"
                            val sku = "HM-${Random.nextInt(100000, 999999)}"
                            variantsToInsert.add(ProductVariantEntity(
                                id = vId,
                                productId = prodId,
                                colour = colour.first,
                                colourHex = colour.second,
                                size = size,
                                sku = sku,
                                stock = Random.nextInt(2, 25)
                            ))
                        }
                    }
                }
            }
        }

        // Save everything
        productDao.insertProducts(productsToInsert)
        productDao.insertVariants(variantsToInsert)
    }
}
