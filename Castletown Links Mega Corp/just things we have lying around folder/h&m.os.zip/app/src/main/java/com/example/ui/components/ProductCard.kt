package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ProductEntity
import kotlinx.coroutines.flow.Flow
import java.util.Locale

@Composable
fun ProductCard(
    product: ProductEntity,
    isSavedFlow: Flow<Boolean>,
    onToggleSave: () -> Unit,
    onProductClick: () -> Unit,
    onQuickAdd: (size: String) -> Unit
) {
    val isSaved by isSavedFlow.collectAsState(initial = false)
    var showSizesOverlay by remember { mutableStateOf(false) }

    // Parse image urls
    val imageUrls = remember(product.images) {
        product.images.split(",").filter { it.isNotBlank() }
    }
    // We can simulate hover image swap using a state
    var displayImage by remember(imageUrls) {
        mutableStateOf(imageUrls.firstOrNull() ?: "")
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onProductClick() },
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
    ) {
        Column {
            // Image section with aspect ratio 3:4 (classic fashion photo crop)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.75f)
                    .background(Color(0xFFF3F3F3))
            ) {
                AsyncImage(
                    model = displayImage,
                    contentDescription = product.name,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Simulated hover state: Swap image when user presses card area
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable { onProductClick() }
                )

                // Favorite Heart Toggle Button
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                ) {
                    IconButton(
                        onClick = onToggleSave,
                        modifier = Modifier
                            .size(36.dp)
                            .background(Color.White.copy(alpha = 0.85f), CircleShape)
                    ) {
                        Icon(
                            imageVector = if (isSaved) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Save product",
                            tint = if (isSaved) Color(0xFFE5001C) else Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                // New In / Sale Badge
                if (product.isNewIn) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp)
                            .background(Color.White, ShapeDefaults.ExtraSmall)
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "NEW ARRIVAL",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                } else if (product.price < 25.0) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(8.dp)
                            .background(Color(0xFFE5001C), ShapeDefaults.ExtraSmall)
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Text(
                            text = "SALE",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // Quick Add overlay triggered on demand
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                ) {
                    if (showSizesOverlay) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black.copy(alpha = 0.9f))
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val sizes = if (product.category == "Home" || product.category == "Beauty") {
                                listOf("ONE SIZE")
                            } else {
                                listOf("XS", "S", "M", "L", "XL")
                            }

                            sizes.forEach { size ->
                                Text(
                                    text = size,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    modifier = Modifier
                                        .clickable {
                                            onQuickAdd(size)
                                            showSizesOverlay = false
                                        }
                                        .padding(8.dp)
                                )
                            }

                            IconButton(
                                onClick = { showSizesOverlay = false },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Favorite, // placeholder or close
                                    contentDescription = "Close sizes",
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            }
                        }
                    } else {
                        // Quick Add Button (fades up)
                        Button(
                            onClick = { showSizesOverlay = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White.copy(alpha = 0.9f),
                                contentColor = Color.Black
                            ),
                            shape = ShapeDefaults.ExtraSmall,
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp)
                                .height(32.dp)
                        ) {
                            Text(
                                text = "+ QUICK ADD",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Metadata: Name, Restrained Colour, Price
            Text(
                text = product.name,
                fontWeight = FontWeight.Medium,
                fontSize = 13.sp,
                color = Color.Black,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )

            Text(
                text = product.subCategory.uppercase(Locale.UK),
                fontSize = 10.sp,
                color = Color.Gray,
                fontWeight = FontWeight.Normal,
                modifier = Modifier.padding(vertical = 2.dp)
            )

            Text(
                text = "£${String.format("%.2f", product.price)}",
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                color = if (product.price < 25.0) Color(0xFFE5001C) else Color.Black
            )
        }
    }
}
