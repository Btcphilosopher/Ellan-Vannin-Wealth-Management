package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.OrderEntity
import com.example.data.ProductEntity
import com.example.ui.Screen
import com.example.ui.ShopViewModel
import com.example.ui.components.ProductCard
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun AccountScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit,
    onQuickAdd: (ProductEntity, String) -> Unit
) {
    val membership by viewModel.membership.collectAsState()
    val orders by viewModel.allOrders.collectAsState()
    val savedItemsList by viewModel.savedItems.collectAsState()

    // Load matching products for saved items list
    var resolvedSavedProducts by remember { mutableStateOf<List<ProductEntity>>(emptyList()) }

    LaunchedEffect(savedItemsList) {
        val prods = mutableListOf<ProductEntity>()
        for (item in savedItemsList) {
            val p = viewModel.loadProductById(item.productId)
            if (p != null) {
                prods.add(p)
            }
        }
        resolvedSavedProducts = prods
    }

    var selectedTab by remember { mutableStateOf(0) } // 0: Membership, 1: Orders, 2: Saved (♡)
    val tabs = listOf("MEMBERSHIP", "MY ORDERS", "SAVED ♡")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // Tab Headers
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = Color.White,
            contentColor = Color.Black,
            indicator = { tabPositions ->
                if (selectedTab < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = Color.Black
                    )
                }
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp
                        )
                    }
                )
            }
        }

        // Tab Contents
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
        ) {
            when (selectedTab) {
                0 -> MembershipTabContent(membership)
                1 -> OrdersTabContent(orders)
                2 -> SavedTabContent(resolvedSavedProducts, viewModel, onNavigate, onQuickAdd)
            }
        }
    }
}

@Composable
fun MembershipTabContent(membership: com.example.data.MembershipEntity?) {
    if (membership == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.Black)
        }
        return
    }

    // Points calculation: every 100 points rewards £3 voucher.
    // e.g. 342 points -> 42 points in current tier, 58 points to go
    val progressPoints = membership.points % 100
    val pointsToGo = 100 - progressPoints
    val progressPct = progressPoints / 100f

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Total Points card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.Black),
                shape = ShapeDefaults.ExtraSmall
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "H&M MEMBERSHIP",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.LightGray,
                        letterSpacing = 2.sp
                    )

                    Text(
                        text = "${membership.points} POINTS",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    // Progress indicator for next reward
                    LinearProgressIndicator(
                        progress = { progressPct },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .background(Color.DarkGray, RoundedCornerShape(3.dp)),
                        color = Color(0xFFE5001C) // H&M Red
                    )

                    Text(
                        text = "$pointsToGo POINTS TO GO UNTIL YOUR NEXT £3 BONUS VOUCHER",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.LightGray,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
            }
        }

        // Vouchers / Offers section
        item {
            Text(
                text = "YOUR ACTIVE BONUS VOUCHERS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            if (membership.voucherCount > 0) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFAFAF7)),
                    shape = ShapeDefaults.ExtraSmall,
                    border = CardDefaults.outlinedCardBorder()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .background(Color(0xFFE5001C), ShapeDefaults.ExtraSmall)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = "£3",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 18.sp,
                                color = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text(
                                text = "£3 BONUS VOUCHER",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = Color.Black
                            )
                            Text(
                                text = "Available on any checkout order. Automatically claimable in shopping bag.",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, Color.LightGray, ShapeDefaults.ExtraSmall)
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "NO VOUCHERS AVAILABLE\nEarn 100 points to claim a bonus voucher.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // Digital Membership QR Code
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF9F9F7))
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "DIGITAL MEMBERSHIP CARD",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color.Gray,
                    letterSpacing = 1.5.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Beautiful synthetic barcode using Custom Canvas
                Box(
                    modifier = Modifier
                        .width(220.dp)
                        .height(80.dp)
                        .background(Color.White)
                        .border(1.dp, Color.LightGray)
                        .padding(8.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val barWidth = 4f
                        val gap = 4f
                        var currentX = 0f
                        val random = Random(12345) // Seeded random for consistent look

                        while (currentX < size.width) {
                            val isBar = random.nextBoolean()
                            val width = if (random.nextBoolean()) barWidth * 2 else barWidth
                            if (isBar) {
                                drawRect(
                                    color = Color.Black,
                                    topLeft = Offset(currentX, 0f),
                                    size = androidx.compose.ui.geometry.Size(width, size.height)
                                )
                            }
                            currentX += width + gap
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "MEMBER ID: 87192-34200",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black
                )

                Text(
                    text = membership.name.uppercase(Locale.UK),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black,
                    modifier = Modifier.padding(top = 4.dp)
                )
            }
        }
    }
}

@Composable
fun OrdersTabContent(orders: List<OrderEntity>) {
    if (orders.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Outlined.ShoppingBag, contentDescription = null, modifier = Modifier.size(48.dp), tint = Color.LightGray)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "NO ORDERS FOUND",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.Black
                )
                Text(
                    text = "You haven't completed any checkouts yet.",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(orders, key = { it.id }) { ord ->
            val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.UK)
            val dateStr = sdf.format(Date(ord.date))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = CardDefaults.outlinedCardBorder(),
                shape = ShapeDefaults.ExtraSmall
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "ORDER ID: ${ord.id}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = Color.Black
                        )
                        Text(
                            text = ord.status,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color(0xFF2E7D32)
                        )
                    }

                    Text(
                        text = dateStr,
                        fontSize = 11.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                    )

                    HorizontalDivider(color = Color(0xFFF0F0F0))

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("SHIPPING TYPE", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Text(ord.deliveryType, fontSize = 12.sp, color = Color.Black)
                        }

                        Column {
                            Text("PAYMENT", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Text(ord.paymentMethod, fontSize = 12.sp, color = Color.Black)
                        }

                        Column {
                            Text("TOTAL PAID", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                            Text("£${String.format("%.2f", ord.total)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SavedTabContent(
    savedProducts: List<ProductEntity>,
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit,
    onQuickAdd: (ProductEntity, String) -> Unit
) {
    if (savedProducts.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "YOUR SAVED ITEMS IS EMPTY",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.Black,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Tap the heart (♡) on products to save them.",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
            }
        }
        return
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 160.dp),
        contentPadding = PaddingValues(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp),
        verticalArrangement = Arrangement.spacedBy(24.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(savedProducts, key = { it.id }) { prod ->
            ProductCard(
                product = prod,
                isSavedFlow = viewModel.getProductFlowSaved(prod.id),
                onToggleSave = { viewModel.toggleSaved(prod.id) },
                onProductClick = { onNavigate(Screen.ProductDetail(prod.id)) },
                onQuickAdd = { size -> onQuickAdd(prod, size) }
            )
        }
    }
}
