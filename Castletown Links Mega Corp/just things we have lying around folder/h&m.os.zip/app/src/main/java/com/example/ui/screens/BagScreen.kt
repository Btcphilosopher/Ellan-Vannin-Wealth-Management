package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.CartItemEntity
import com.example.data.ProductEntity
import com.example.ui.Screen
import com.example.ui.ShopViewModel

@Composable
fun BagScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit
) {
    val cartList by viewModel.cartItems.collectAsState()
    val membership by viewModel.membership.collectAsState()

    // Loaded product lookup map to quickly resolve cartItem productId to product properties
    var resolvedProducts by remember { mutableStateOf<Map<String, ProductEntity>>(emptyMap()) }
    var voucherApplied by remember { mutableStateOf(false) }

    // Load matching products for the cart items
    LaunchedEffect(cartList) {
        val updatedMap = resolvedProducts.toMutableMap()
        for (item in cartList) {
            if (!updatedMap.containsKey(item.productId)) {
                val prod = viewModel.loadProductById(item.productId)
                if (prod != null) {
                    updatedMap[item.productId] = prod
                }
            }
        }
        resolvedProducts = updatedMap
    }

    if (cartList.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "YOUR BAG IS EMPTY",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.Black,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Nothing here yet.",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = { onNavigate(Screen.Home) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White),
                    shape = ShapeDefaults.ExtraSmall,
                    modifier = Modifier.height(46.dp)
                ) {
                    Text("START SHOPPING", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
        return
    }

    // Calculations
    var subtotal = 0.0
    for (item in cartList) {
        val prod = resolvedProducts[item.productId]
        if (prod != null) {
            subtotal += prod.price * item.quantity
        }
    }

    val freeDeliveryThreshold = 40.0
    val deliveryFee = if (subtotal >= freeDeliveryThreshold) 0.0 else 3.99
    val discount = if (voucherApplied) 3.0 else 0.0
    val finalTotal = (subtotal - discount + deliveryFee).coerceAtLeast(0.0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // Main Screen Scroll Content
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(16.dp)
        ) {
            item {
                Text(
                    text = "SHOPPING BAG (${cartList.sumOf { it.quantity }})",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Black,
                    letterSpacing = 0.5.sp,
                    modifier = Modifier.padding(bottom = 16.dp)
                )
            }

            // Cart Items List
            items(cartList, key = { it.id }) { cartItem ->
                val prod = resolvedProducts[cartItem.productId]
                if (prod != null) {
                    CartItemRow(
                        cartItem = cartItem,
                        product = prod,
                        onUpdateQty = { delta -> viewModel.updateQty(cartItem.id, delta) },
                        onRemove = { viewModel.removeItem(cartItem.id) },
                        onSaveForLater = {
                            viewModel.toggleSaved(prod.id)
                            viewModel.removeItem(cartItem.id)
                        }
                    )
                }
            }

            // Delivery Status
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFFFAFAF7))
                        .padding(16.dp)
                ) {
                    if (subtotal >= freeDeliveryThreshold) {
                        Text(
                            text = "YOU HAVE FREE STANDARD DELIVERY!",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color(0xFF2E7D32),
                            letterSpacing = 0.5.sp
                        )
                    } else {
                        val remaining = freeDeliveryThreshold - subtotal
                        Text(
                            text = "SPEND £${String.format("%.2f", remaining)} MORE FOR FREE DELIVERY",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color.Black,
                            letterSpacing = 0.5.sp
                        )
                    }
                    Text(
                        text = "Standard Home Delivery is free for members on orders over £40.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            // Membership Voucher Application
            item {
                val voucherCount = membership?.voucherCount ?: 0
                if (voucherCount > 0) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
                        shape = ShapeDefaults.ExtraSmall
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "LOYALTY OFFER AVAILABLE",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFC62828),
                                    letterSpacing = 0.5.sp
                                )
                                Text(
                                    text = "You have a £3.00 Bonus Voucher!",
                                    fontSize = 12.sp,
                                    color = Color.Black,
                                    fontWeight = FontWeight.Medium
                                )
                            }

                            Button(
                                onClick = { voucherApplied = !voucherApplied },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (voucherApplied) Color.Black else Color(0xFFC62828),
                                    contentColor = Color.White
                                ),
                                shape = ShapeDefaults.ExtraSmall,
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                modifier = Modifier.height(34.dp)
                            ) {
                                Text(
                                    text = if (voucherApplied) "APPLIED ✓" else "APPLY",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // Price Details Summary
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "ORDER SUMMARY",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = Color.Black,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Order Subtotal", fontSize = 13.sp, color = Color.Gray)
                    Text("£${String.format("%.2f", subtotal)}", fontSize = 13.sp, color = Color.Black)
                }

                if (voucherApplied) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Bonus Voucher Applied", fontSize = 13.sp, color = Color(0xFFC62828))
                        Text("-£3.00", fontSize = 13.sp, color = Color(0xFFC62828), fontWeight = FontWeight.Bold)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Delivery Fee", fontSize = 13.sp, color = Color.Gray)
                    Text(
                        text = if (deliveryFee == 0.0) "FREE" else "£${String.format("%.2f", deliveryFee)}",
                        fontSize = 13.sp,
                        color = if (deliveryFee == 0.0) Color(0xFF2E7D32) else Color.Black,
                        fontWeight = if (deliveryFee == 0.0) FontWeight.Bold else FontWeight.Normal
                    )
                }

                HorizontalDivider(color = Color(0xFFEEEEEE), modifier = Modifier.padding(vertical = 12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 24.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Total Price", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                    Text("£${String.format("%.2f", finalTotal)}", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.Black)
                }
            }
        }

        // Persistent bottom checkout bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .navigationBarsPadding()
                .padding(16.dp)
        ) {
            Button(
                onClick = { onNavigate(Screen.Checkout) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White),
                shape = ShapeDefaults.ExtraSmall
            ) {
                Text(
                    text = "PROCEED TO CHECKOUT",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
fun CartItemRow(
    cartItem: CartItemEntity,
    product: ProductEntity,
    onUpdateQty: (delta: Int) -> Unit,
    onRemove: () -> Unit,
    onSaveForLater: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        // Thumbnail Image
        AsyncImage(
            model = product.images.split(",").firstOrNull(),
            contentDescription = product.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(width = 80.dp, height = 110.dp)
                .background(Color(0xFFF5F5F5))
        )

        Spacer(modifier = Modifier.width(16.dp))

        // Product Metadata & Adjusters
        Column(modifier = Modifier.weight(1f)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    text = product.name,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.Black,
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )

                IconButton(
                    onClick = onRemove,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Remove Item",
                        tint = Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Text(
                text = "${cartItem.colour} / Size ${cartItem.size}",
                fontSize = 12.sp,
                color = Color.Gray,
                modifier = Modifier.padding(vertical = 2.dp)
            )

            Text(
                text = "£${String.format("%.2f", product.price)}",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            // Adjusters Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Quantity Counter Box
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.border(1.dp, Color.LightGray, ShapeDefaults.ExtraSmall)
                ) {
                    Text(
                        text = "−",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        modifier = Modifier
                            .clickable { onUpdateQty(-1) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )

                    Text(
                        text = "${cartItem.quantity}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )

                    Text(
                        text = "+",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black,
                        modifier = Modifier
                            .clickable { onUpdateQty(1) }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                // Save for later trigger
                Text(
                    text = "Save for later",
                    fontSize = 11.sp,
                    color = Color.Gray,
                    textDecoration = TextDecoration.Underline,
                    modifier = Modifier.clickable { onSaveForLater() }
                )
            }
        }
    }
    HorizontalDivider(color = Color(0xFFF9F9F9))
}
