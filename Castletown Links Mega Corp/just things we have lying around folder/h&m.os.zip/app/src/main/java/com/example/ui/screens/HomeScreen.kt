package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ProductEntity
import com.example.ui.Screen
import com.example.ui.ShopViewModel
import com.example.ui.components.ProductCard

@Composable
fun HomeScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit,
    onQuickAdd: (ProductEntity, String) -> Unit
) {
    val newInProducts by viewModel.categoryProducts.collectAsState()

    // Query New In items on screen load
    LaunchedEffect(Unit) {
        viewModel.setCategory("New In")
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // 1. Primary Editorial Hero Campaign
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.8f) // Vertical, confident framing
                    .background(Color(0xFFF3F3F3))
            ) {
                AsyncImage(
                    model = "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=1200&q=80",
                    contentDescription = "The City Wardrobe Campaign",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                // Campaign copy overlay: Minimal, elegant, centered
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .background(Color.Black.copy(alpha = 0.25f))
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "THE CITY WARDROBE",
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.Bold,
                        fontSize = 26.sp,
                        color = Color.White,
                        letterSpacing = 2.sp,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        text = "Autumn staples built for contemporary urban living.",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.9f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 6.dp, bottom = 16.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.setCategory("Women")
                                onNavigate(Screen.Category("Women"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                            shape = ShapeDefaults.ExtraSmall,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("SHOP WOMEN", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        Button(
                            onClick = {
                                viewModel.setCategory("Men")
                                onNavigate(Screen.Category("Men"))
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                            shape = ShapeDefaults.ExtraSmall,
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("SHOP MEN", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // 2. Horizontal Quick Categories / Navigation shortcuts
        item {
            val quickCategories = listOf("Women", "Men", "Kids", "Home", "Beauty")
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp, horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceAround
            ) {
                quickCategories.forEach { cat ->
                    Text(
                        text = cat.uppercase(),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color.Black,
                        letterSpacing = 1.sp,
                        modifier = Modifier
                            .clickable {
                                viewModel.setCategory(cat)
                                onNavigate(Screen.Category(cat))
                            }
                            .padding(8.dp)
                    )
                }
            }
        }

        // 3. New Arrivals section (Horizontal scrolling grid cards)
        item {
            Column(modifier = Modifier.padding(vertical = 8.dp)) {
                Text(
                    text = "NEW IN",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = Color.Black,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, bottom = 12.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    items(newInProducts.take(8)) { prod ->
                        Box(modifier = Modifier.width(160.dp)) {
                            ProductCard(
                                product = prod,
                                isSavedFlow = viewModel.getProductFlowSaved(prod.id),
                                onToggleSave = { viewModel.toggleSaved(prod.id) },
                                onProductClick = { onNavigate(Screen.ProductDetail(prod.id)) },
                                onQuickAdd = { size -> onQuickAdd(prod, size) }
                            )
                        }
                    }
                }
            }
        }

        // 4. Secondary Editorial Hero (H&M STUDIO)
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.9f)
                    .background(Color(0xFFEEEEEE))
            ) {
                AsyncImage(
                    model = "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=1200&q=80",
                    contentDescription = "H&M Studio Campaign",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.Center)
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "H&M STUDIO",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 32.sp,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        letterSpacing = 3.sp
                    )
                    Text(
                        text = "A bold collection designed for high-end self expression.",
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.95f),
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp, bottom = 20.dp)
                    )

                    Button(
                        onClick = {
                            viewModel.setCategory("Women", "Dresses")
                            onNavigate(Screen.Category("Women", "Dresses"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White),
                        shape = ShapeDefaults.ExtraSmall,
                        modifier = Modifier.widthIn(min = 160.dp)
                    ) {
                        Text("DISCOVER THE COLLECTION", fontWeight = FontWeight.Bold, fontSize = 11.sp, letterSpacing = 1.sp)
                    }
                }
            }
        }

        // 5. Bottom editorial teaser
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFFAFAF7))
                    .padding(vertical = 40.dp, horizontal = 24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "H&M MEMBERSHIP",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color.Black,
                    letterSpacing = 2.sp
                )
                Text(
                    text = "Become a member to get 10% off your first purchase, earn reward points, and claim exclusive bonus vouchers.",
                    fontSize = 12.sp,
                    color = Color.DarkGray,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 8.dp, bottom = 16.dp)
                )
                Button(
                    onClick = { onNavigate(Screen.Account) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                    shape = ShapeDefaults.ExtraSmall,
                    border = ButtonDefaults.outlinedButtonBorder
                ) {
                    Text("JOIN NOW", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}
