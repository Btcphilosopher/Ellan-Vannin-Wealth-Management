package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ProductEntity
import com.example.data.ProductVariantEntity
import com.example.ui.Screen
import com.example.ui.ShopViewModel
import java.util.Locale

@Composable
fun ProductDetailScreen(
    productId: String,
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit,
    onAddProductToBag: (ProductEntity, String, String) -> Unit
) {
    var product by remember { mutableStateOf<ProductEntity?>(null) }
    var variants by remember { mutableStateOf<List<ProductVariantEntity>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    val isSaved by viewModel.getProductFlowSaved(productId).collectAsState(initial = false)

    // Selection states
    var selectedColour by remember { mutableStateOf("") }
    var selectedColourHex by remember { mutableStateOf("#FFFFFF") }
    var selectedSize by remember { mutableStateOf("") }

    // Load product details on launch
    LaunchedEffect(productId) {
        loading = true
        val loaded = viewModel.loadProductById(productId)
        if (loaded != null) {
            product = loaded
            viewModel.getProductVariantsFlow(productId).collect { list ->
                variants = list
                if (list.isNotEmpty()) {
                    // Pick first variant colour as default
                    val firstV = list.first()
                    selectedColour = firstV.colour
                    selectedColourHex = firstV.colourHex
                }
                loading = false
            }
        } else {
            loading = false
        }
    }

    // Accordion Expansion states
    var detailsExpanded by remember { mutableStateOf(false) }
    var materialsExpanded by remember { mutableStateOf(false) }
    var careExpanded by remember { mutableStateOf(false) }
    var deliveryExpanded by remember { mutableStateOf(false) }

    if (loading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.Black)
        }
        return
    }

    val currentProduct = product
    if (currentProduct == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("PRODUCT NOT FOUND", fontWeight = FontWeight.Bold, color = Color.Black)
                Spacer(modifier = Modifier.height(8.dp))
                Button(onClick = { onNavigate(Screen.Home) }) {
                    Text("GO HOME")
                }
            }
        }
        return
    }

    // Extract product images
    val images = remember(currentProduct.images) {
        currentProduct.images.split(",").filter { it.isNotBlank() }
    }

    // Filter sizes available for selected colour
    val sizesForColour = remember(variants, selectedColour) {
        variants.filter { it.colour.equals(selectedColour, ignoreCase = true) }
    }

    val selectedVariant = remember(sizesForColour, selectedSize) {
        sizesForColour.find { it.size.equals(selectedSize, ignoreCase = true) }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // 1. Large Split Image Gallery
        item {
            Column {
                // If we have 2 images, show them side by side on tablets, stacked on mobile
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(380.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    items(images) { img ->
                        AsyncImage(
                            model = img,
                            contentDescription = currentProduct.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxHeight()
                                .width(280.dp)
                        )
                    }
                }
            }
        }

        // 2. Info Section
        item {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = currentProduct.name,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                        Text(
                            text = currentProduct.subCategory.uppercase(Locale.UK),
                            fontSize = 11.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }

                    IconButton(onClick = { viewModel.toggleSaved(currentProduct.id) }) {
                        Icon(
                            imageVector = if (isSaved) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            contentDescription = "Save Item",
                            tint = if (isSaved) Color(0xFFE5001C) else Color.Black
                        )
                    }
                }

                Text(
                    text = "£${String.format("%.2f", currentProduct.price)}",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.Black,
                    modifier = Modifier.padding(top = 4.dp, bottom = 16.dp)
                )

                // 3. Colour Selection Row
                Text(
                    text = "COLOUR: ${selectedColour.uppercase(Locale.UK)}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color.Black,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Get unique colours
                val uniqueColours = variants.distinctBy { it.colour }.map { Pair(it.colour, it.colourHex) }
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.padding(bottom = 24.dp)
                ) {
                    uniqueColours.forEach { item ->
                        val isSel = item.first.equals(selectedColour, ignoreCase = true)
                        val hexColor = try {
                            Color(android.graphics.Color.parseColor(item.second))
                        } catch (e: Exception) {
                            Color.DarkGray
                        }

                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .border(
                                    width = if (isSel) 2.dp else 1.dp,
                                    color = if (isSel) Color.Black else Color.LightGray,
                                    shape = CircleShape
                                )
                                .padding(4.dp)
                                .background(hexColor, CircleShape)
                                .clickable {
                                    selectedColour = item.first
                                    selectedColourHex = item.second
                                    // Reset size selection if not available in new colour
                                    selectedSize = ""
                                }
                        )
                    }
                }

                // 4. Size Selection List
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SELECT SIZE",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color.Black,
                        letterSpacing = 1.sp
                    )

                    Text(
                        text = "SIZE GUIDE",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textDecoration = TextDecoration.Underline,
                        modifier = Modifier.clickable { }
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 12.dp)
                ) {
                    sizesForColour.forEach { v ->
                        val isSizeSel = v.size.equals(selectedSize, ignoreCase = true)
                        val isOutOfStock = v.stock <= 0

                        val containerColor = when {
                            isSizeSel -> Color.Black
                            isOutOfStock -> Color(0xFFF0F0F0)
                            else -> Color.White
                        }
                        val contentColor = when {
                            isSizeSel -> Color.White
                            isOutOfStock -> Color.LightGray
                            else -> Color.Black
                        }

                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .border(
                                    width = if (isSizeSel) 2.dp else 1.dp,
                                    color = if (isSizeSel) Color.Black else Color.LightGray,
                                    shape = ShapeDefaults.ExtraSmall
                                )
                                  // Can click if stock is available
                                .background(containerColor, ShapeDefaults.ExtraSmall)
                                .clickable(enabled = !isOutOfStock) {
                                    selectedSize = v.size
                                }
                        ) {
                            Row(
                                modifier = Modifier.fillMaxSize(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = v.size,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = contentColor
                                )
                                if (isSizeSel) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Selected",
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Inventory warning
                if (selectedVariant != null) {
                    if (selectedVariant.stock in 1..4) {
                        Text(
                            text = "LOW STOCK: Only ${selectedVariant.stock} items remaining!",
                            color = Color(0xFFE5001C),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                    } else if (selectedVariant.stock <= 0) {
                        Text(
                            text = "OUT OF STOCK",
                            color = Color.Gray,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 16.dp)
                        )
                    }
                }

                // 5. Add To Bag Button
                Button(
                    onClick = {
                        if (selectedSize.isBlank()) {
                            // Prompt size selection (can highlight sizes visually)
                        } else {
                            onAddProductToBag(currentProduct, selectedColour, selectedSize)
                        }
                    },
                    enabled = selectedSize.isNotBlank() && (selectedVariant?.stock ?: 0) > 0,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.Black,
                        contentColor = Color.White,
                        disabledContainerColor = Color.LightGray,
                        disabledContentColor = Color.Gray
                    ),
                    shape = ShapeDefaults.ExtraSmall
                ) {
                    Text(
                        text = if (selectedSize.isBlank()) "SELECT SIZE TO ADD" else "ADD TO BAG",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        letterSpacing = 1.sp
                    )
                }
            }
        }

        // 6. Accordions (Details, Materials, Care, Delivery, Returns)
        item {
            HorizontalDivider(color = Color(0xFFF0F0F0))
            AccordionItem(
                title = "DETAILS",
                content = currentProduct.description,
                isExpanded = detailsExpanded,
                onToggle = { detailsExpanded = !detailsExpanded }
            )

            HorizontalDivider(color = Color(0xFFF0F0F0))
            AccordionItem(
                title = "MATERIALS",
                content = currentProduct.materials,
                isExpanded = materialsExpanded,
                onToggle = { materialsExpanded = !materialsExpanded }
            )

            HorizontalDivider(color = Color(0xFFF0F0F0))
            AccordionItem(
                title = "CARE",
                content = currentProduct.care,
                isExpanded = careExpanded,
                onToggle = { careExpanded = !careExpanded }
            )

            HorizontalDivider(color = Color(0xFFF0F0F0))
            AccordionItem(
                title = "DELIVERY & RETURNS",
                content = "${currentProduct.delivery}\n\n${currentProduct.returns}",
                isExpanded = deliveryExpanded,
                onToggle = { deliveryExpanded = !deliveryExpanded }
            )
            HorizontalDivider(color = Color(0xFFF0F0F0))
            Spacer(modifier = Modifier.height(32.dp))
        }
    }
}

@Composable
fun AccordionItem(
    title: String,
    content: String,
    isExpanded: Boolean,
    onToggle: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onToggle() }
            .padding(vertical = 12.dp, horizontal = 16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                color = Color.Black,
                letterSpacing = 1.sp
            )
            Icon(
                imageVector = Icons.Default.ArrowDropDown,
                contentDescription = if (isExpanded) "Collapse" else "Expand",
                tint = Color.Black,
                modifier = Modifier.size(20.dp) // rotate accordingly or keep simple
            )
        }

        AnimatedVisibility(
            visible = isExpanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Text(
                text = content,
                fontSize = 12.sp,
                color = Color.DarkGray,
                lineHeight = 18.sp,
                modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
            )
        }
    }
}
