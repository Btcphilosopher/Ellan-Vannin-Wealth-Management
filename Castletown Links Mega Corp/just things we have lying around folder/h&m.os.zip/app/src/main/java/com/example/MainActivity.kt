package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ProductEntity
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.Screen
import com.example.ui.ShopViewModel
import com.example.ui.components.HAndMHeader
import com.example.ui.screens.*
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    private val viewModel: ShopViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                val dbReady by viewModel.isDbReady.collectAsState()
                if (!dbReady) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.White),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = Color.Black)
                    }
                    return@MyApplicationTheme
                }

                val currentScreen by viewModel.currentScreen.collectAsState()
                val cartItems by viewModel.cartItems.collectAsState()
                val savedItems by viewModel.savedItems.collectAsState()
                val searchQuery by viewModel.searchQuery.collectAsState()
                val isAddBagAnimating by viewModel.isAddBagAnimating.collectAsState()
                val addBagMessage by viewModel.addBagMessage.collectAsState()

                val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
                val scope = rememberCoroutineScope()

                // Intercept hardware back button to navigate back through our ViewModel's backstack
                BackHandler {
                    val handled = viewModel.navigateBack()
                    if (!handled) {
                        finish()
                    }
                }

                // Add to bag animation variables
                var animatingProductImage by remember { mutableStateOf<String?>(null) }
                var showAddBagDialog by remember { mutableStateOf(false) }

                // Responsive drawer options
                ModalNavigationDrawer(
                    drawerState = drawerState,
                    drawerContent = {
                        ModalDrawerSheet(
                            drawerContainerColor = Color.White,
                            modifier = Modifier.width(280.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(24.dp)
                            ) {
                                Text(
                                    text = "H&M",
                                    fontSize = 28.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFE5001C)
                                )
                                Spacer(modifier = Modifier.height(32.dp))

                                val mainCategories = listOf("Women", "Men", "Kids", "Home", "Beauty")
                                mainCategories.forEach { cat ->
                                    NavigationDrawerItem(
                                        label = { Text(cat.uppercase(), fontWeight = FontWeight.Bold, fontSize = 13.sp) },
                                        selected = false,
                                        onClick = {
                                            viewModel.setCategory(cat)
                                            viewModel.navigateTo(Screen.Category(cat))
                                            scope.launch { drawerState.close() }
                                        },
                                        colors = NavigationDrawerItemDefaults.colors(unselectedContainerColor = Color.White)
                                    )
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp))

                                NavigationDrawerItem(
                                    label = { Text("STORE LOCATOR", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                                    selected = false,
                                    onClick = {
                                        viewModel.navigateTo(Screen.StoreLocator)
                                        scope.launch { drawerState.close() }
                                    },
                                    colors = NavigationDrawerItemDefaults.colors(unselectedContainerColor = Color.White)
                                )

                                NavigationDrawerItem(
                                    label = { Text("SCAN AN ITEM", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                                    selected = false,
                                    onClick = {
                                        viewModel.navigateTo(Screen.Scanner)
                                        scope.launch { drawerState.close() }
                                    },
                                    colors = NavigationDrawerItemDefaults.colors(unselectedContainerColor = Color.White)
                                )
                            }
                        }
                    }
                ) {
                    Scaffold(
                        topBar = {
                            // Render Header with proper action integrations
                            HAndMHeader(
                                currentScreen = currentScreen,
                                cartCount = cartItems.sumOf { it.quantity },
                                savedCount = savedItems.size,
                                searchQuery = searchQuery,
                                onSearchChange = { viewModel.setSearchQuery(it) },
                                onNavigate = { viewModel.navigateTo(it) },
                                onBack = { viewModel.navigateBack() },
                                onMenuToggle = { scope.launch { drawerState.open() } }
                            )
                        },
                        bottomBar = {
                            // Responsive Material 3 Bottom Navigation bar for mobile screens
                            NavigationBar(
                                containerColor = Color.White,
                                contentColor = Color.Black,
                                modifier = Modifier.height(64.dp)
                            ) {
                                val homeActive = currentScreen is Screen.Home
                                val shopActive = currentScreen is Screen.Category
                                val scanActive = currentScreen is Screen.Scanner
                                val storeActive = currentScreen is Screen.StoreLocator
                                val accActive = currentScreen is Screen.Account

                                NavigationBarItem(
                                    selected = homeActive,
                                    onClick = { viewModel.resetToHome() },
                                    icon = { Icon(if (homeActive) Icons.Filled.Home else Icons.Outlined.Home, "Home") },
                                    label = { Text("HOME", fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.Black,
                                        selectedTextColor = Color.Black,
                                        indicatorColor = Color(0xFFF0F0F0)
                                    )
                                )

                                NavigationBarItem(
                                    selected = shopActive,
                                    onClick = {
                                        viewModel.setCategory("Women")
                                        viewModel.navigateTo(Screen.Category("Women"))
                                    },
                                    icon = { Icon(if (shopActive) Icons.Filled.ShoppingBag else Icons.Outlined.ShoppingBag, "Shop") },
                                    label = { Text("SHOP", fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.Black,
                                        selectedTextColor = Color.Black,
                                        indicatorColor = Color(0xFFF0F0F0)
                                    )
                                )

                                NavigationBarItem(
                                    selected = scanActive,
                                    onClick = { viewModel.navigateTo(Screen.Scanner) },
                                    icon = { Icon(if (scanActive) Icons.Filled.QrCodeScanner else Icons.Outlined.QrCodeScanner, "Scan") },
                                    label = { Text("SCAN", fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.Black,
                                        selectedTextColor = Color.Black,
                                        indicatorColor = Color(0xFFF0F0F0)
                                    )
                                )

                                NavigationBarItem(
                                    selected = storeActive,
                                    onClick = { viewModel.navigateTo(Screen.StoreLocator) },
                                    icon = { Icon(if (storeActive) Icons.Filled.LocationOn else Icons.Outlined.LocationOn, "Stores") },
                                    label = { Text("STORES", fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.Black,
                                        selectedTextColor = Color.Black,
                                        indicatorColor = Color(0xFFF0F0F0)
                                    )
                                )

                                NavigationBarItem(
                                    selected = accActive,
                                    onClick = { viewModel.navigateTo(Screen.Account) },
                                    icon = { Icon(if (accActive) Icons.Filled.Person else Icons.Outlined.Person, "Account") },
                                    label = { Text("ACCOUNT", fontSize = 9.sp, fontWeight = FontWeight.Bold) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = Color.Black,
                                        selectedTextColor = Color.Black,
                                        indicatorColor = Color(0xFFF0F0F0)
                                    )
                                )
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            // Multi-screen animated routing selector
                            AnimatedContent(
                                targetState = currentScreen,
                                transitionSpec = {
                                    (fadeIn(animationSpec = tween(220)) + slideInHorizontally(animationSpec = tween(220), initialOffsetX = { 100 }))
                                        .togetherWith(fadeOut(animationSpec = tween(220)) + slideOutHorizontally(animationSpec = tween(220), targetOffsetX = { -100 }))
                                },
                                label = "ScreenTransition"
                            ) { target ->
                                when (target) {
                                    is Screen.Home -> {
                                        HomeScreen(
                                            viewModel = viewModel,
                                            onNavigate = { viewModel.navigateTo(it) },
                                            onQuickAdd = { prod, size ->
                                                animatingProductImage = prod.images.split(",").firstOrNull()
                                                viewModel.addProductToBag(prod.id, "Cream", size, 1)
                                                showAddBagDialog = true
                                            }
                                        )
                                    }
                                    is Screen.Category -> {
                                        CategoryScreen(
                                            viewModel = viewModel,
                                            onNavigate = { viewModel.navigateTo(it) },
                                            onQuickAdd = { prod, size ->
                                                animatingProductImage = prod.images.split(",").firstOrNull()
                                                viewModel.addProductToBag(prod.id, "Cream", size, 1)
                                                showAddBagDialog = true
                                            }
                                        )
                                    }
                                    is Screen.ProductDetail -> {
                                        ProductDetailScreen(
                                            productId = target.productId,
                                            viewModel = viewModel,
                                            onNavigate = { viewModel.navigateTo(it) },
                                            onAddProductToBag = { prod, col, size ->
                                                animatingProductImage = prod.images.split(",").firstOrNull()
                                                viewModel.addProductToBag(prod.id, col, size, 1)
                                                showAddBagDialog = true
                                            }
                                        )
                                    }
                                    is Screen.Bag -> {
                                        BagScreen(
                                            viewModel = viewModel,
                                            onNavigate = { viewModel.navigateTo(it) }
                                        )
                                    }
                                    is Screen.Checkout -> {
                                        CheckoutScreen(
                                            viewModel = viewModel,
                                            onNavigate = { viewModel.navigateTo(it) }
                                        )
                                    }
                                    is Screen.OrderConfirmed -> {
                                        OrderConfirmationScreen(
                                            orderId = target.orderId,
                                            total = target.total,
                                            subtotal = target.subtotal,
                                            discount = target.discount,
                                            delivery = target.delivery,
                                            onNavigate = { viewModel.navigateTo(it) }
                                        )
                                    }
                                    is Screen.Account -> {
                                        AccountScreen(
                                            viewModel = viewModel,
                                            onNavigate = { viewModel.navigateTo(it) },
                                            onQuickAdd = { prod, size ->
                                                animatingProductImage = prod.images.split(",").firstOrNull()
                                                viewModel.addProductToBag(prod.id, "Cream", size, 1)
                                                showAddBagDialog = true
                                            }
                                        )
                                    }
                                    is Screen.StoreLocator -> {
                                        StoreLocatorScreen(
                                            viewModel = viewModel,
                                            onNavigate = { viewModel.navigateTo(it) }
                                        )
                                    }
                                    is Screen.Scanner -> {
                                        ScannerScreen(
                                            viewModel = viewModel,
                                            onNavigate = { viewModel.navigateTo(it) },
                                            onQuickAdd = { prod, size ->
                                                animatingProductImage = prod.images.split(",").firstOrNull()
                                                viewModel.addProductToBag(prod.id, "Cream", size, 1)
                                                showAddBagDialog = true
                                            }
                                        )
                                    }
                                }
                            }

                            // SIGNATURE ADD TO BAG PHYSICAL INTERACTION ANIMATION OVERLAY
                            if (isAddBagAnimating && animatingProductImage != null) {
                                var scaleState by remember { mutableStateOf(1f) }
                                val offsetAnim = remember { Animatable(Offset(200f, 600f), Offset.VectorConverter) }
                                val scaleAnim by animateFloatAsState(
                                    targetValue = if (offsetAnim.value.y < 300f) 0.1f else 0.8f,
                                    animationSpec = tween(800, easing = LinearOutSlowInEasing),
                                    label = "ScaleItem"
                                )

                                LaunchedEffect(Unit) {
                                    // Start from center of screen and fly toward top right bag icon (approx x=900, y=100)
                                    offsetAnim.animateTo(
                                        targetValue = Offset(900f, 100f),
                                        animationSpec = spring(
                                            dampingRatio = Spring.DampingRatioLowBouncy,
                                            stiffness = Spring.StiffnessLow
                                        )
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Transparent)
                                ) {
                                    AsyncImage(
                                        model = animatingProductImage,
                                        contentDescription = "Animating tag",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier
                                            .offset {
                                                IntOffset(
                                                    offsetAnim.value.x.roundToInt(),
                                                    offsetAnim.value.y.roundToInt()
                                                )
                                            }
                                            .size(100.dp)
                                            .scale(scaleAnim)
                                            .clip(CircleShape)
                                            .background(Color.White)
                                            .border(1.dp, Color.LightGray, CircleShape)
                                    )
                                }
                            }

                            // Minimal added confirmation bottom sheet modal
                            if (showAddBagDialog && addBagMessage != null) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .background(Color.Black.copy(alpha = 0.35f))
                                        .clickable { showAddBagDialog = false },
                                    contentAlignment = Alignment.BottomCenter
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(Color.White)
                                            .padding(24.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = "ADDED TO BAG ✓",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp,
                                            color = Color(0xFF2E7D32),
                                            letterSpacing = 1.sp
                                        )
                                        Spacer(modifier = Modifier.height(16.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                                        ) {
                                            OutlinedButton(
                                                onClick = { showAddBagDialog = false },
                                                shape = ShapeDefaults.ExtraSmall,
                                                modifier = Modifier.weight(1f),
                                                border = ButtonDefaults.outlinedButtonBorder
                                            ) {
                                                Text("CONTINUE SHOPPING", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                            }

                                            Button(
                                                onClick = {
                                                    showAddBagDialog = false
                                                    viewModel.navigateTo(Screen.Bag)
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White),
                                                shape = ShapeDefaults.ExtraSmall,
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Text("VIEW BAG", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                            }
                                        }
                                        Spacer(modifier = Modifier.height(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
