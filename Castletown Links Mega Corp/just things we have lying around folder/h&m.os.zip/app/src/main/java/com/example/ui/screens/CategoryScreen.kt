package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ProductEntity
import com.example.ui.Screen
import com.example.ui.ShopViewModel
import com.example.ui.components.ProductCard
import java.util.Locale

@Composable
fun CategoryScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit,
    onQuickAdd: (ProductEntity, String) -> Unit
) {
    val category by viewModel.selectedCategory.collectAsState()
    val activeSub by viewModel.selectedSubCategory.collectAsState()
    val activeSort by viewModel.selectedSort.collectAsState()
    val products by viewModel.categoryProducts.collectAsState()

    var showSortMenu by remember { mutableStateOf(false) }

    // Subcategory definitions for the top row
    val subCategories = remember(category) {
        listOf(
            "ALL",
            "Jeans",
            "Knitwear",
            "Dresses",
            "Tops",
            "Jackets & Coats",
            "Shoes",
            "Accessories"
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
    ) {
        // Category Title Bar
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                text = category.uppercase(Locale.UK),
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                letterSpacing = 1.sp
            )

            // Subcategory Selection Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(vertical = 12.dp)
            ) {
                items(subCategories) { sub ->
                    val isSelected = (sub == "ALL" && activeSub == null) || (sub == activeSub)
                    val containerColor = if (isSelected) Color.Black else Color(0xFFF5F5F5)
                    val contentColor = if (isSelected) Color.White else Color.Black

                    Box(
                        modifier = Modifier
                            .background(containerColor, ShapeDefaults.ExtraSmall)
                            .clickable {
                                if (sub == "ALL") {
                                    viewModel.setCategory(category, null)
                                } else {
                                    viewModel.setCategory(category, sub)
                                }
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = sub.uppercase(Locale.UK),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = contentColor,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // Filter & Sort Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${products.size} items",
                    fontSize = 12.sp,
                    color = Color.Gray,
                    fontWeight = FontWeight.Normal
                )

                // Dropdown Sort Selector
                Box {
                    Row(
                        modifier = Modifier
                            .clickable { showSortMenu = true }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SORT: ${activeSort.uppercase(Locale.UK)}",
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = Color.Black,
                            letterSpacing = 0.5.sp
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = "Sort Options",
                            tint = Color.Black
                        )
                    }

                    DropdownMenu(
                        expanded = showSortMenu,
                        onDismissRequest = { showSortMenu = false },
                        modifier = Modifier.background(Color.White)
                    ) {
                        listOf("Recommended", "Price Low-High", "Price High-Low").forEach { option ->
                            DropdownMenuItem(
                                text = { Text(option, fontSize = 13.sp) },
                                onClick = {
                                    viewModel.setSort(option)
                                    showSortMenu = false
                                }
                            )
                        }
                    }
                }
            }
        }

        HorizontalDivider(color = Color(0xFFF0F0F0))

        // Main Grid: Uses adaptive cell sizes (2 cols on mobile, scales to 3 or 4 on tablets)
        if (products.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "NO PRODUCTS FOUND",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = Color.Black
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "We couldn't find items in this collection right now.",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 160.dp), // Auto columns responsive layout!
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(products, key = { it.id }) { prod ->
                    ProductCard(
                        product = prod,
                        isSavedFlow = viewModel.getProductFlowSaved(prod.id),
                        onToggleSave = { viewModel.toggleSaved(prod.id) },
                        onProductClick = { onNavigate(Screen.ProductDetail(prod.id)) },
                        onQuickAdd = { size -> onQuickAdd(prod, size) }
                    )
                }
            }
        }
    }
}
