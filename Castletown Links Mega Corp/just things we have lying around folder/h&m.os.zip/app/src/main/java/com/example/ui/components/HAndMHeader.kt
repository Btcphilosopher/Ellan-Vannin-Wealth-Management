package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HAndMHeader(
    currentScreen: Screen,
    cartCount: Int,
    savedCount: Int,
    searchQuery: String,
    onSearchChange: (String) -> Unit,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit,
    onMenuToggle: () -> Unit
) {
    var searchExpanded by remember { mutableStateOf(false) }
    val keyboardController = LocalSoftwareKeyboardController.current

    val isRoot = currentScreen is Screen.Home

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.White)
            .statusBarsPadding()
    ) {
        // Main Logo & Top Actions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left Action: Back or Menu
            if (isRoot) {
                IconButton(onClick = onMenuToggle) {
                    Icon(
                        imageVector = Icons.Default.Menu,
                        contentDescription = "Menu",
                        tint = Color.Black
                    )
                }
            } else {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.Outlined.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.Black
                    )
                }
            }

            // H&M Logo - Minimal Red Scandinavian typography
            Text(
                text = "H&M",
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Bold,
                fontSize = 32.sp,
                color = Color(0xFFE5001C), // H&M Red
                letterSpacing = (-1).sp,
                textAlign = TextAlign.Center,
                modifier = Modifier
                    .clickable { onNavigate(Screen.Home) }
                    .padding(horizontal = 8.dp)
            )

            // Right Actions
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { searchExpanded = !searchExpanded }) {
                    Icon(
                        imageVector = if (searchExpanded) Icons.Default.Close else Icons.Default.Search,
                        contentDescription = "Search",
                        tint = Color.Black
                    )
                }

                IconButton(onClick = { onNavigate(Screen.Account) }) {
                    Icon(
                        imageVector = Icons.Outlined.Person,
                        contentDescription = "Account",
                        tint = Color.Black
                    )
                }

                Box(contentAlignment = Alignment.TopEnd) {
                    IconButton(onClick = { onNavigate(Screen.Account) }) { // Account holds saved items
                        Icon(
                            imageVector = Icons.Outlined.FavoriteBorder,
                            contentDescription = "Saved Items",
                            tint = Color.Black
                        )
                    }
                    if (savedCount > 0) {
                        Badge(
                            containerColor = Color(0xFFE5001C),
                            contentColor = Color.White,
                            modifier = Modifier.offset(x = (-4).dp, y = 4.dp)
                        ) {
                            Text(text = "$savedCount", fontSize = 10.sp)
                        }
                    }
                }

                Box(contentAlignment = Alignment.TopEnd) {
                    IconButton(onClick = { onNavigate(Screen.Bag) }) {
                        Icon(
                            imageVector = Icons.Outlined.ShoppingBag,
                            contentDescription = "Shopping Bag",
                            tint = Color.Black
                        )
                    }
                    if (cartCount > 0) {
                        Badge(
                            containerColor = Color.Black,
                            contentColor = Color.White,
                            modifier = Modifier.offset(x = (-4).dp, y = 4.dp)
                        ) {
                            Text(text = "$cartCount", fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // Animated Search Expansion
        AnimatedVisibility(
            visible = searchExpanded,
            enter = expandVertically() + fadeIn(),
            exit = shrinkVertically() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFFF9F9F9))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = onSearchChange,
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("What are you looking for?", color = Color.Gray) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Black,
                        unfocusedBorderColor = Color.LightGray,
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = {
                        keyboardController?.hide()
                    }),
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { onSearchChange("") }) {
                                Icon(Icons.Default.Close, "Clear search", tint = Color.Gray)
                            }
                        }
                    }
                )

                // Quick Popular Search Tags
                Text(
                    text = "POPULAR SEARCHES",
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    color = Color.Gray,
                    modifier = Modifier.padding(top = 12.dp, bottom = 4.dp)
                )

                val quickSearches = listOf("Jeans", "Linen", "Jackets", "Dresses", "Knitwear")
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(bottom = 8.dp)
                ) {
                    items(quickSearches) { term ->
                        SuggestionChip(
                            onClick = {
                                onSearchChange(term)
                                keyboardController?.hide()
                            },
                            label = { Text(term, fontSize = 12.sp, color = Color.Black) },
                            colors = SuggestionChipDefaults.suggestionChipColors(
                                containerColor = Color.White
                            ),
                            border = SuggestionChipDefaults.suggestionChipBorder(
                                enabled = true,
                                borderColor = Color.LightGray
                            )
                        )
                    }
                }
            }
        }

        // Minimal Divider line
        HorizontalDivider(color = Color(0xFFEEEEEE), thickness = 1.dp)
    }
}
