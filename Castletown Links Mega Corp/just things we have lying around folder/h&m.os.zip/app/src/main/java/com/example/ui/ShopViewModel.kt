package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed interface Screen {
    object Home : Screen
    data class Category(val name: String, val selectedSub: String? = null) : Screen
    data class ProductDetail(val productId: String) : Screen
    object Bag : Screen
    object Checkout : Screen
    data class OrderConfirmed(
        val orderId: String,
        val total: Double,
        val subtotal: Double,
        val discount: Double,
        val delivery: Double
    ) : Screen
    object Account : Screen
    object StoreLocator : Screen
    object Scanner : Screen
}

class ShopViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ShopRepository(application)

    // Navigation State
    private val _backstack = MutableStateFlow<List<Screen>>(listOf(Screen.Home))
    val currentScreen: StateFlow<Screen> = _backstack
        .map { it.lastOrNull() ?: Screen.Home }
        .stateIn(viewModelScope, SharingStarted.Eagerly, Screen.Home)

    // DB loaded indicator
    private val _isDbReady = MutableStateFlow(false)
    val isDbReady: StateFlow<Boolean> = _isDbReady.asStateFlow()

    // Search Query and results
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchResults: StateFlow<List<ProductEntity>> = _searchQuery
        .debounce(300)
        .flatMapLatest { query ->
            repository.searchProducts(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Cart and Saved Items
    val cartItems: StateFlow<List<CartItemEntity>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedItems: StateFlow<List<SavedItemEntity>> = repository.savedItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allOrders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allStores: StateFlow<List<StoreEntity>> = repository.allStores
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val membership: StateFlow<MembershipEntity?> = repository.getMembership()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Store Locator Search Query
    private val _storeSearchQuery = MutableStateFlow("")
    val storeSearchQuery: StateFlow<String> = _storeSearchQuery.asStateFlow()

    val filteredStores: StateFlow<List<StoreEntity>> = combine(allStores, _storeSearchQuery) { stores, query ->
        if (query.isBlank()) {
            stores
        } else {
            stores.filter {
                it.name.contains(query, ignoreCase = true) ||
                it.address.contains(query, ignoreCase = true)
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Animation / Interaction States
    private val _isAddBagAnimating = MutableStateFlow(false)
    val isAddBagAnimating: StateFlow<Boolean> = _isAddBagAnimating.asStateFlow()

    private val _addBagMessage = MutableStateFlow<String?>(null)
    val addBagMessage: StateFlow<String?> = _addBagMessage.asStateFlow()

    // Active Category Filter/Sort
    private val _selectedCategory = MutableStateFlow("Women")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedSubCategory = MutableStateFlow<String?>(null)
    val selectedSubCategory: StateFlow<String?> = _selectedSubCategory.asStateFlow()

    private val _selectedSort = MutableStateFlow("Recommended") // "Recommended", "Price Low-High", "Price High-Low"
    val selectedSort: StateFlow<String> = _selectedSort.asStateFlow()

    val categoryProducts: StateFlow<List<ProductEntity>> = combine(
        _selectedCategory, _selectedSubCategory, _selectedSort
    ) { cat, sub, sort ->
        var list = if (sub != null) {
            // If we filter by sub, load sub category
            repository.getProductsBySubCategory(sub).first()
        } else {
            repository.getProductsByCategory(cat).first()
        }

        // Apply Sort
        list = when (sort) {
            "Price Low-High" -> list.sortedBy { it.price }
            "Price High-Low" -> list.sortedByDescending { it.price }
            else -> list // Recommended
        }

        list
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.seedDatabaseIfNeeded()
            _isDbReady.value = true
        }
    }

    // Navigation Actions
    fun navigateTo(screen: Screen) {
        viewModelScope.launch {
            val currentList = _backstack.value.toMutableList()
            currentList.add(screen)
            _backstack.value = currentList
        }
    }

    fun navigateBack(): Boolean {
        val currentList = _backstack.value.toMutableList()
        if (currentList.size > 1) {
            currentList.removeAt(currentList.lastIndex)
            _backstack.value = currentList
            return true
        }
        return false
    }

    fun resetToHome() {
        _backstack.value = listOf(Screen.Home)
    }

    // Category / Filter actions
    fun setCategory(category: String, subCategory: String? = null) {
        _selectedCategory.value = category
        _selectedSubCategory.value = subCategory
    }

    fun setSort(sort: String) {
        _selectedSort.value = sort
    }

    fun setStoreSearchQuery(query: String) {
        _storeSearchQuery.value = query
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // Cart operations
    fun addProductToBag(productId: String, colour: String, size: String, quantity: Int = 1) {
        viewModelScope.launch {
            val variantId = "$productId-${colour.uppercase()}-$size"
            // Start elegant animation sequence
            _isAddBagAnimating.value = true
            
            repository.addToCart(variantId, productId, colour, size, quantity)
            
            // Wait slightly for visual confirmation
            _addBagMessage.value = "ADDED TO BAG"
            kotlinx.coroutines.delay(1200)
            _isAddBagAnimating.value = false
            _addBagMessage.value = null
        }
    }

    fun updateQty(cartItemId: Int, delta: Int) {
        viewModelScope.launch {
            val currentItems = cartItems.value
            val item = currentItems.find { it.id == cartItemId } ?: return@launch
            val targetQty = item.quantity + delta
            repository.updateCartQuantity(cartItemId, targetQty)
        }
    }

    fun removeItem(cartItemId: Int) {
        viewModelScope.launch {
            repository.removeFromCart(cartItemId)
        }
    }

    // Saved Items operations
    fun toggleSaved(productId: String) {
        viewModelScope.launch {
            repository.toggleSavedItem(productId)
        }
    }

    fun getProductFlowSaved(productId: String): Flow<Boolean> {
        return repository.isProductSaved(productId)
    }

    fun getProductVariantsFlow(productId: String): Flow<List<ProductVariantEntity>> {
        return repository.getVariantsForProduct(productId)
    }

    suspend fun loadProductById(productId: String): ProductEntity? {
        return repository.getProductById(productId)
    }

    // Barcode scanner logic simulation
    private val _scannedProduct = MutableStateFlow<ProductEntity?>(null)
    val scannedProduct: StateFlow<ProductEntity?> = _scannedProduct.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    fun simulateBarcodeScan() {
        viewModelScope.launch {
            _isScanning.value = true
            _scannedProduct.value = null
            kotlinx.coroutines.delay(2000) // loading / scanning simulation
            
            // Find "Linen-Blend Shirt" (scanned item) from seeded products
            repository.getProductsByCategory("Men").first().find { 
                it.name.contains("Linen", ignoreCase = true) 
            }?.let { found ->
                _scannedProduct.value = found
            }
            _isScanning.value = false
        }
    }

    fun clearScannedProduct() {
        _scannedProduct.value = null
    }

    // Checkout processing state
    private val _checkoutState = MutableStateFlow<CheckoutResultState>(CheckoutResultState.Idle)
    val checkoutState: StateFlow<CheckoutResultState> = _checkoutState.asStateFlow()

    fun performCheckout(
        deliveryType: String,
        recipientName: String,
        recipientAddress: String,
        recipientPostcode: String,
        paymentMethod: String,
        voucherApplied: Boolean = false
    ) {
        viewModelScope.launch {
            _checkoutState.value = CheckoutResultState.Loading
            try {
                val res = repository.processCheckout(
                    deliveryType,
                    recipientName,
                    recipientAddress,
                    recipientPostcode,
                    paymentMethod,
                    voucherApplied
                )
                
                _checkoutState.value = CheckoutResultState.Success(
                    orderId = res["orderId"] as String,
                    total = res["total"] as Double,
                    subtotal = res["subtotal"] as Double,
                    discount = res["discount"] as Double,
                    delivery = res["delivery"] as Double
                )
                
                // Navigate to Order Confirmation
                navigateTo(Screen.OrderConfirmed(
                    orderId = res["orderId"] as String,
                    total = res["total"] as Double,
                    subtotal = res["subtotal"] as Double,
                    discount = res["discount"] as Double,
                    delivery = res["delivery"] as Double
                ))
                
                _checkoutState.value = CheckoutResultState.Idle // Reset
            } catch (e: Exception) {
                _checkoutState.value = CheckoutResultState.Error(e.message ?: "An unexpected payment/stock error occurred")
            }
        }
    }
}

sealed interface CheckoutResultState {
    object Idle : CheckoutResultState
    object Loading : CheckoutResultState
    data class Success(
        val orderId: String,
        val total: Double,
        val subtotal: Double,
        val discount: Double,
        val delivery: Double
    ) : CheckoutResultState
    data class Error(val message: String) : CheckoutResultState
}
