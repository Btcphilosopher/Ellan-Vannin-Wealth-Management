package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

// ==========================================
// 1. ENTITIES
// ==========================================

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val id: String,
    val name: String,
    val description: String,
    val category: String, // "Women", "Men", "Kids", "Home", "Beauty", "Sale"
    val subCategory: String, // "Jeans", "Knitwear", "Dresses", "Tops", "Jackets & Coats", "Shoes", "Accessories"
    val price: Double,
    val images: String, // Comma-separated list of image URLs
    val materials: String,
    val care: String,
    val delivery: String,
    val returns: String,
    val isNewIn: Boolean = false,
    val isTrending: Boolean = false
)

@Entity(tableName = "product_variants")
data class ProductVariantEntity(
    @PrimaryKey val id: String, // e.g. "PROD_ID-COLOUR-SIZE"
    val productId: String,
    val colour: String,
    val colourHex: String,
    val size: String, // "XS", "S", "M", "L", "XL"
    val sku: String,
    val stock: Int
)

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val variantId: String,
    val productId: String,
    val colour: String,
    val size: String,
    val quantity: Int
)

@Entity(tableName = "saved_items")
data class SavedItemEntity(
    @PrimaryKey val productId: String,
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "membership")
data class MembershipEntity(
    @PrimaryKey val id: String, // e.g. "demo@hm.local"
    val name: String,
    val email: String,
    val points: Int,
    val voucherCount: Int = 0
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String, // e.g. "HM-20481"
    val total: Double,
    val date: Long,
    val status: String, // "CONFIRMED", "SHIPPED", "DELIVERED"
    val deliveryType: String, // "STANDARD", "CLICK & COLLECT"
    val recipientName: String,
    val recipientAddress: String,
    val recipientPostcode: String,
    val paymentMethod: String
)

@Entity(tableName = "order_items")
data class OrderItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val orderId: String,
    val productId: String,
    val productName: String,
    val colour: String,
    val size: String,
    val price: Double,
    val quantity: Int,
    val imageUrl: String
)

@Entity(tableName = "stores")
data class StoreEntity(
    @PrimaryKey val id: String,
    val name: String,
    val address: String,
    val hours: String,
    val services: String
)

// ==========================================
// 2. DAOS
// ==========================================

@Dao
interface ProductDao {
    @Query("SELECT * FROM products")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getProductById(id: String): ProductEntity?

    @Query("SELECT * FROM products WHERE category = :category")
    fun getProductsByCategory(category: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE subCategory = :subCategory")
    fun getProductsBySubCategory(subCategory: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM product_variants WHERE productId = :productId")
    fun getVariantsForProduct(productId: String): Flow<List<ProductVariantEntity>>

    @Query("SELECT * FROM product_variants WHERE id = :id")
    suspend fun getVariantById(id: String): ProductVariantEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVariants(variants: List<ProductVariantEntity>)

    @Query("UPDATE product_variants SET stock = :newStock WHERE id = :variantId")
    suspend fun updateVariantStock(variantId: String, newStock: Int)
}

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<CartItemEntity>>

    @Query("SELECT * FROM cart_items WHERE variantId = :variantId LIMIT 1")
    suspend fun getCartItemByVariant(variantId: String): CartItemEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: CartItemEntity)

    @Update
    suspend fun updateCartItem(item: CartItemEntity)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItem(id: Int)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()
}

@Dao
interface SavedDao {
    @Query("SELECT * FROM saved_items")
    fun getSavedItems(): Flow<List<SavedItemEntity>>

    @Query("SELECT EXISTS(SELECT 1 FROM saved_items WHERE productId = :productId)")
    fun isProductSaved(productId: String): Flow<Boolean>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProduct(item: SavedItemEntity)

    @Query("DELETE FROM saved_items WHERE productId = :productId")
    suspend fun unsaveProduct(productId: String)
}

@Dao
interface MembershipDao {
    @Query("SELECT * FROM membership WHERE id = :id LIMIT 1")
    fun getMembership(id: String): Flow<MembershipEntity?>

    @Query("SELECT * FROM membership WHERE id = :id LIMIT 1")
    suspend fun getMembershipSync(id: String): MembershipEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveMembership(membership: MembershipEntity)
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY date DESC")
    fun getAllOrders(): Flow<List<OrderEntity>>

    @Query("SELECT * FROM orders WHERE id = :id LIMIT 1")
    fun getOrderById(id: String): Flow<OrderEntity?>

    @Query("SELECT * FROM order_items WHERE orderId = :orderId")
    suspend fun getItemsForOrder(orderId: String): List<OrderItemEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: OrderEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrderItems(items: List<OrderItemEntity>)
}

@Dao
interface StoreDao {
    @Query("SELECT * FROM stores")
    fun getAllStores(): Flow<List<StoreEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStores(stores: List<StoreEntity>)
}

// ==========================================
// 3. DATABASE
// ==========================================

@Database(
    entities = [
        ProductEntity::class,
        ProductVariantEntity::class,
        CartItemEntity::class,
        SavedItemEntity::class,
        MembershipEntity::class,
        OrderEntity::class,
        OrderItemEntity::class,
        StoreEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun cartDao(): CartDao
    abstract fun savedDao(): SavedDao
    abstract fun membershipDao(): MembershipDao
    abstract fun orderDao(): OrderDao
    abstract fun storeDao(): StoreDao
}
