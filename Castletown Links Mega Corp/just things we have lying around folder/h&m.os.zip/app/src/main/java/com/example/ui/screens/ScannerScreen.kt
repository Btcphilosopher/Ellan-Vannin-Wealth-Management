package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.ProductEntity
import com.example.ui.Screen
import com.example.ui.ShopViewModel

@Composable
fun ScannerScreen(
    viewModel: ShopViewModel,
    onNavigate: (Screen) -> Unit,
    onQuickAdd: (ProductEntity, String) -> Unit
) {
    val scannedProduct by viewModel.scannedProduct.collectAsState()
    val isScanning by viewModel.isScanning.collectAsState()

    var selectedSize by remember { mutableStateOf("") }
    var inStoreCheckResult by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.White)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "IN-STORE SCANNER",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Black,
                letterSpacing = 1.sp
            )
            if (scannedProduct != null) {
                IconButton(onClick = { viewModel.clearScannedProduct(); selectedSize = ""; inStoreCheckResult = false }) {
                    Icon(Icons.Default.Close, contentDescription = "Clear scan")
                }
            }
        }

        if (scannedProduct == null) {
            // VIEWPORT BOX FOR BARCODE SCANNING SIMULATION
            Spacer(modifier = Modifier.weight(0.1f))

            Text(
                text = "SCAN A GARMENT TAG",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                letterSpacing = 1.5.sp,
                textAlign = TextAlign.Center
            )

            Text(
                text = "Point your camera at any H&M barcode to immediately check online sizes, fabrics, care, and local store availability.",
                fontSize = 12.sp,
                color = Color.DarkGray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 4.dp, bottom = 24.dp)
            )

            // Stylized Viewfinder Box
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .border(width = 2.dp, color = Color.Black)
                    .background(Color(0xFFFAFAF7)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.CameraAlt,
                        contentDescription = "Camera simulation",
                        tint = Color.LightGray,
                        modifier = Modifier.size(64.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "PLACE BARCODE HERE",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.LightGray,
                        letterSpacing = 1.sp
                    )
                }

                // Center animated scan bar line simulation
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(2.dp)
                        .background(Color(0xFFE5001C))
                        .align(Alignment.Center)
                )
            }

            Spacer(modifier = Modifier.weight(0.1f))

            if (isScanning) {
                CircularProgressIndicator(color = Color.Black, modifier = Modifier.padding(bottom = 24.dp))
            } else {
                Button(
                    onClick = { viewModel.simulateBarcodeScan() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White),
                    shape = ShapeDefaults.ExtraSmall
                ) {
                    Text("SIMULATE BARCODE SCAN", fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
                }
            }
            Spacer(modifier = Modifier.weight(0.1f))
        } else {
            // GARMENT FOUND DISPLAY
            val prod = scannedProduct!!
            val parsedImages = prod.images.split(",").filter { it.isNotBlank() }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text(
                        text = "GARMENT FOUND ✓",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = Color(0xFF2E7D32),
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                }

                // Product details row
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFFAFAF7))
                            .border(1.dp, Color.LightGray, ShapeDefaults.ExtraSmall)
                            .padding(12.dp)
                    ) {
                        AsyncImage(
                            model = parsedImages.firstOrNull(),
                            contentDescription = prod.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(width = 80.dp, height = 110.dp)
                                .background(Color.White)
                        )

                        Spacer(modifier = Modifier.width(16.dp))

                        Column {
                            Text(
                                text = prod.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = Color.Black
                            )
                            Text(
                                text = "SKU: HM-SCAN-LINEN",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                            Text(
                                text = "£${String.format("%.2f", prod.price)}",
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 15.sp,
                                color = Color.Black
                            )

                            Row(
                                modifier = Modifier.padding(top = 8.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .background(Color(0xFFE8F5E9))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("AVAILABLE ONLINE", fontSize = 9.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Selector size for Quick Add
                item {
                    Text(
                        text = "SELECT SIZE TO PURCHASE ONLINE",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        color = Color.Black,
                        letterSpacing = 1.sp,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Start
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    val sizes = listOf("XS", "S", "M", "L", "XL")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        sizes.forEach { size ->
                            val isSel = size == selectedSize
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .height(42.dp)
                                    .border(
                                        width = if (isSel) 2.dp else 1.dp,
                                        color = if (isSel) Color.Black else Color.LightGray,
                                        shape = ShapeDefaults.ExtraSmall
                                    )
                                    .background(if (isSel) Color.Black else Color.White, ShapeDefaults.ExtraSmall)
                                    .clickable { selectedSize = size }
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxSize(),
                                    horizontalArrangement = Arrangement.Center,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = size,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = if (isSel) Color.White else Color.Black
                                    )
                                }
                            }
                        }
                    }
                }

                // Actions: Add to bag
                item {
                    Button(
                        onClick = {
                            if (selectedSize.isNotBlank()) {
                                onQuickAdd(prod, selectedSize)
                            }
                        },
                        enabled = selectedSize.isNotBlank(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Black, contentColor = Color.White),
                        shape = ShapeDefaults.ExtraSmall
                    ) {
                        Text("ADD ONLINE TO BAG", fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.sp)
                    }
                }

                // Find in Store simulated check
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFF9F9F7)),
                        shape = ShapeDefaults.ExtraSmall,
                        border = CardDefaults.outlinedCardBorder()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "CHECK LOCAL STORE STOCK",
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                color = Color.Gray,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Query nearby physical retail stores in London for stock availability of this garment.",
                                fontSize = 11.sp,
                                color = Color.DarkGray
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            if (inStoreCheckResult) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("H&M Oxford Street", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("IN STOCK (4 left)", fontSize = 12.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("H&M Regent Street", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("IN STOCK (9 left)", fontSize = 12.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                    }
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("H&M Westfield Stratford", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text("OUT OF STOCK", fontSize = 12.sp, color = Color.Gray)
                                    }
                                }
                            } else {
                                Button(
                                    onClick = { inStoreCheckResult = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                                    shape = ShapeDefaults.ExtraSmall,
                                    border = ButtonDefaults.outlinedButtonBorder,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("FIND IN-STORE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
