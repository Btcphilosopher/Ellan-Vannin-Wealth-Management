from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Optional
import datetime

app = FastAPI(title="easyJet Demo Airline API", version="1.0.0")

class FlightSearchRequest(BaseModel, extra="allow"):
    origin: str
    destination: str
    date: str
    passengers: int

class BookingCreate(BaseModel, extra="allow"):
    passenger_name: str
    origin: str
    destination: str
    flight_number: str
    flight_date: str
    total_price: float
    baggage_type: str

FIXTURE_FLIGHTS = [
    {
        "flight_id": "EZ-LGW-BCN-1",
        "flight_number": "U2 8451",
        "origin": "LGW",
        "destination": "BCN",
        "departure_time": "07:10",
        "arrival_time": "10:20",
        "duration": "2h 10m",
        "price": 64.99
    },
    {
        "flight_id": "EZ-LGW-BCN-2",
        "flight_number": "U2 8453",
        "origin": "LGW",
        "destination": "BCN",
        "departure_time": "14:35",
        "arrival_time": "17:45",
        "duration": "2h 10m",
        "price": 79.99
    }
]

BOOKINGS_STORE = [
    {
        "booking_ref": "EZ9482X",
        "passenger_name": "Alex Morgan",
        "origin": "LGW",
        "destination": "BCN",
        "flight_number": "DEMO 204",
        "flight_date": "18 SEP 2027",
        "departure_time": "07:10",
        "boarding_time": "06:30",
        "seat": "12A",
        "gate": "-",
        "baggage_type": "Small underseat bag",
        "status": "CONFIRMED",
        "total_price": 144.98
    }
]

@app.get("/api/health")
def health_check():
    return {"status": "healthy", "timestamp": datetime.datetime.utcnow().isoformat()}

@app.post("/api/flights/search")
def search_flights(req: FlightSearchRequest):
    return {
        "origin": req.origin,
        "destination": req.destination,
        "date": req.date,
        "outbound_flights": FIXTURE_FLIGHTS
    }

@app.get("/api/bookings")
def get_bookings():
    return BOOKINGS_STORE

@app.post("/api/bookings")
def create_booking(booking: BookingCreate):
    import random
    ref = f"EZ{random.randint(1000, 9999)}X"
    new_b = {
        "booking_ref": ref,
        "passenger_name": booking.passenger_name,
        "origin": booking.origin,
        "destination": booking.destination,
        "flight_number": booking.flight_number,
        "flight_date": booking.flight_date,
        "departure_time": "07:10",
        "boarding_time": "06:30",
        "seat": "12A",
        "gate": "-",
        "baggage_type": booking.baggage_type,
        "status": "CONFIRMED",
        "total_price": booking.total_price
    }
    BOOKINGS_STORE.insert(0, new_b)
    return new_b

@app.post("/api/staff/inject-delay")
def inject_delay(delay_minutes: int):
    for b in BOOKINGS_STORE:
        b["status"] = "DELAYED"
        b["delay_minutes"] = delay_minutes
    return {"status": "success", "delayed_count": len(BOOKINGS_STORE), "delay_minutes": delay_minutes}
