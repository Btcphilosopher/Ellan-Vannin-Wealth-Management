package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AirlineRepository
import com.example.model.Flight
import com.example.ui.theme.EasyJetCharcoal
import com.example.ui.theme.EasyJetOrange
import com.example.ui.theme.EasyJetSurface

@Composable
fun FlightResultsScreen(
  onBackClicked: () -> Unit,
  onFlightSelected: (Flight) -> Unit
) {
  val flights = AirlineRepository.fixtureOutboundFlights

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(EasyJetOrange)
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBackClicked) {
        Icon(
          imageVector = Icons.Default.ArrowBack,
          contentDescription = "Back",
          tint = Color.White
        )
      }
      Text(
        text = "Choose your flight",
        color = Color.White,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 8.dp)
      )
    }

    // Content container with white background and rounded top corners
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .weight(1f),
      shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
      color = EasyJetSurface
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp)
      ) {
        // Route info summary
        Text(
          text = "London Gatwick → Barcelona",
          color = EasyJetCharcoal,
          fontSize = 20.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
          text = "18 September 2027 • 1 adult",
          color = Color.Gray,
          fontSize = 14.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Flight Cards
        flights.forEach { flight ->
          FlightCard(
            flight = flight,
            onSelect = {
              AirlineRepository.selectOutbound(flight)
              onFlightSelected(flight)
            }
          )
          Spacer(modifier = Modifier.height(16.dp))
        }

        Spacer(modifier = Modifier.height(8.dp))

        // "Make it your trip" banner
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF2EB))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Luggage,
              contentDescription = "Baggage and seats",
              tint = EasyJetOrange,
              modifier = Modifier.size(36.dp)
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Make it your trip",
                color = EasyJetCharcoal,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "Compare cabin bags, seats and fare options before you pay.",
                color = Color.DarkGray,
                fontSize = 13.sp
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Footer note
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.Center
        ) {
          Text(
            text = "ⓘ Illustrative fares",
            color = Color.Gray,
            fontSize = 12.sp
          )
        }
      }
    }
  }
}

@Composable
fun FlightCard(
  flight: Flight,
  onSelect: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(20.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Times & Route
        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = flight.departureTime,
              color = EasyJetCharcoal,
              fontSize = 24.sp,
              fontWeight = FontWeight.Bold
            )
            Text(
              text = " → ",
              color = Color.Gray,
              fontSize = 20.sp
            )
            Text(
              text = flight.arrivalTime,
              color = EasyJetCharcoal,
              fontSize = 24.sp,
              fontWeight = FontWeight.Bold
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = flight.origin,
              color = Color.Gray,
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = flight.destination,
              color = Color.Gray,
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = "•",
              color = Color.Gray,
              fontSize = 14.sp
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = flight.flightNumber,
              color = Color.Gray,
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium
            )
          }
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = "Direct • ${flight.duration}",
            color = Color.DarkGray,
            fontSize = 14.sp
          )
        }

        // Price
        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "£${String.format("%.2f", flight.price)}",
            color = EasyJetOrange,
            fontSize = 26.sp,
            fontWeight = FontWeight.ExtraBold
          )
          Text(
            text = "One-way fare • 1 adult",
            color = Color.Gray,
            fontSize = 11.sp
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Divider(color = Color(0xFFF0F0F0), thickness = 1.dp)

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.Luggage,
          contentDescription = "Baggage",
          tint = Color.Gray,
          modifier = Modifier.size(18.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = flight.includedBag,
          color = Color.DarkGray,
          fontSize = 13.sp
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Button(
        onClick = onSelect,
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("select_flight_${flight.flightId}"),
        shape = RoundedCornerShape(24.dp),
        colors = ButtonDefaults.buttonColors(containerColor = EasyJetOrange)
      ) {
        Text(
          text = "Select flight",
          color = Color.White,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold
        )
      }
    }
  }
}
