package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AirlineRepository
import com.example.ui.theme.EasyJetCharcoal
import com.example.ui.theme.EasyJetOrange
import com.example.ui.theme.EasyJetSurface

@Composable
fun AccountScreen(
  onOpenStaffConsole: () -> Unit
) {
  var delayMinutesInput by remember { mutableStateOf("45") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(EasyJetOrange)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 20.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Account & Staff",
        color = Color.White,
        fontSize = 28.sp,
        fontWeight = FontWeight.ExtraBold
      )
    }

    Surface(
      modifier = Modifier
        .fillMaxSize()
        .weight(1f),
      shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
      color = EasyJetSurface
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp)
      ) {
        // User Profile Card
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FA))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
              shape = RoundedCornerShape(50.dp),
              color = EasyJetOrange,
              modifier = Modifier.size(50.dp)
            ) {
              Box(contentAlignment = Alignment.Center) {
                Icon(imageVector = Icons.Default.Person, contentDescription = "User", tint = Color.White)
              }
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
              Text(
                text = "Alex Morgan",
                color = EasyJetCharcoal,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = "alex.morgan@example.com • easyJet Plus",
                color = Color.Gray,
                fontSize = 13.sp
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
          text = "Demonstration Staff Console",
          color = EasyJetCharcoal,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF2EB))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.Warning, contentDescription = "Disruption", tint = EasyJetOrange)
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "Inject Flight Delay / Disruption",
                color = EasyJetCharcoal,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
              )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "Test disruption handling, notification banners, and status updates on bookings.",
              color = Color.DarkGray,
              fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
              value = delayMinutesInput,
              onValueChange = { delayMinutesInput = it },
              label = { Text("Delay duration (minutes)") },
              modifier = Modifier.fillMaxWidth(),
              shape = RoundedCornerShape(12.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Button(
              onClick = {
                val mins = delayMinutesInput.toIntOrNull() ?: 45
                AirlineRepository.injectDelay("ALL", mins)
              },
              modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .testTag("inject_delay_button"),
              shape = RoundedCornerShape(22.dp),
              colors = ButtonDefaults.buttonColors(containerColor = EasyJetOrange)
            ) {
              Text(
                text = "Inject Delay to All Bookings",
                color = Color.White,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
          onClick = onOpenStaffConsole,
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("open_staff_console_button"),
          shape = RoundedCornerShape(26.dp),
          colors = ButtonDefaults.buttonColors(containerColor = EasyJetCharcoal)
        ) {
          Icon(imageVector = Icons.Default.AdminPanelSettings, contentDescription = "Staff Console", tint = Color.White)
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "Open Full Staff Control Console",
            color = Color.White,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
