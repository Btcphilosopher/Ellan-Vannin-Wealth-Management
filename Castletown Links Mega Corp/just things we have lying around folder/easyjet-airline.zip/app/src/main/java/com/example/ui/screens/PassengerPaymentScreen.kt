package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AirlineRepository
import com.example.model.Booking
import com.example.ui.theme.EasyJetCharcoal
import com.example.ui.theme.EasyJetOrange
import com.example.ui.theme.EasyJetSurface

@Composable
fun PassengerPaymentScreen(
  cabinBag: String,
  seat: String,
  onBackClicked: () -> Unit,
  onBookingConfirmed: (String) -> Unit
) {
  var firstName by remember { mutableStateOf("Alex") }
  var lastName by remember { mutableStateOf("Morgan") }
  var email by remember { mutableStateOf("alex.morgan@example.com") }
  var phone by remember { mutableStateOf("+44 7700 900077") }
  var cardNumber by remember { mutableStateOf("•••• •••• •••• 4242") }
  var expiry by remember { mutableStateOf("12/28") }
  var cvv by remember { mutableStateOf("123") }
  var isProcessing by remember { mutableStateOf(false) }

  val flight = AirlineRepository.selectedOutboundFlight.value
  val basePrice = flight?.price ?: 64.99
  val extraCost = if (cabinBag.contains("Large")) 15.99 else 0.0
  val seatCost = if (seat.contains("7.50")) 7.50 else if (seat.contains("5.00")) 5.0 else 0.0
  val total = basePrice + extraCost + seatCost

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(EasyJetOrange)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBackClicked) {
        Icon(
          imageVector = Icons.Default.ArrowBack,
          contentDescription = "Back",
          tint = Color.White
        )
      }
      Text(
        text = "Passenger & Payment",
        color = Color.White,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 8.dp)
      )
    }

    Surface(
      modifier = Modifier
        .fillMaxSize()
        .weight(1f),
      shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
      color = EasyJetSurface
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp)
      ) {
        Text(
          text = "Passenger 1 (Adult)",
          color = EasyJetCharcoal,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = firstName,
          onValueChange = { firstName = it },
          label = { Text("First name") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
          value = lastName,
          onValueChange = { lastName = it },
          label = { Text("Last name") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
          value = email,
          onValueChange = { email = it },
          label = { Text("Email address") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        OutlinedTextField(
          value = phone,
          onValueChange = { phone = it },
          label = { Text("Mobile phone") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp)
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
          text = "Payment (Simulator)",
          color = EasyJetCharcoal,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = cardNumber,
          onValueChange = { cardNumber = it },
          label = { Text("Card number") },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          OutlinedTextField(
            value = expiry,
            onValueChange = { expiry = it },
            label = { Text("MM/YY") },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp)
          )
          OutlinedTextField(
            value = cvv,
            onValueChange = { cvv = it },
            label = { Text("CVV") },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp)
          )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Price Review Card
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FA))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Price Review",
              color = EasyJetCharcoal,
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            PriceRow("Flight (${flight?.flightNumber ?: "U2 8451"})", "£${String.format("%.2f", basePrice)}")
            if (extraCost > 0) {
              PriceRow("Baggage option", "£${String.format("%.2f", extraCost)}")
            }
            if (seatCost > 0) {
              PriceRow("Seat selection", "£${String.format("%.2f", seatCost)}")
            }
            Divider(color = Color(0xFFDDDDDD), modifier = Modifier.padding(vertical = 8.dp))
            PriceRow("Total amount", "£${String.format("%.2f", total)}", isBold = true)
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
          onClick = {
            isProcessing = true
            val newRef = "EZ" + (1000..9999).random() + "X"
            val newBooking = Booking(
              bookingRef = newRef,
              passengerName = "$firstName $lastName",
              origin = flight?.origin ?: "LGW",
              destination = flight?.destination ?: "BCN",
              flightNumber = flight?.flightNumber ?: "U2 8451",
              flightDate = "18 SEP 2027",
              departureTime = flight?.departureTime ?: "07:10",
              boardingTime = "06:30",
              seat = if (seat.contains("12A")) "12A" else "12C",
              gate = "-",
              baggageType = cabinBag,
              status = "CONFIRMED",
              totalPrice = total,
              isDemo = true
            )
            AirlineRepository.addBooking(newBooking)
            onBookingConfirmed(newRef)
          },
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("pay_and_book_button"),
          shape = RoundedCornerShape(26.dp),
          colors = ButtonDefaults.buttonColors(containerColor = EasyJetOrange),
          enabled = !isProcessing
        ) {
          if (isProcessing) {
            CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
          } else {
            Icon(imageVector = Icons.Default.Lock, contentDescription = "Secure", tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Pay £${String.format("%.2f", total)} & Book",
              color = Color.White,
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }
  }
}

@Composable
fun PriceRow(label: String, amount: String, isBold: Boolean = false) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(
      text = label,
      color = if (isBold) EasyJetCharcoal else Color.DarkGray,
      fontSize = if (isBold) 16.sp else 14.sp,
      fontWeight = if (isBold) FontWeight.Bold else FontWeight.Normal
    )
    Text(
      text = amount,
      color = if (isBold) EasyJetOrange else EasyJetCharcoal,
      fontSize = if (isBold) 18.sp else 14.sp,
      fontWeight = if (isBold) FontWeight.ExtraBold else FontWeight.SemiBold
    )
  }
}
