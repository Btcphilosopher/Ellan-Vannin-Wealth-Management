package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EasyJetOrange = Color(0xFFFF6200)
val EasyJetOrangeDark = Color(0xFFD65200)
val EasyJetCharcoal = Color(0xFF1B1B1B)
val EasyJetSurface = Color(0xFFFFFFFF)
val EasyJetBackground = Color(0xFFF8F9FA)
val EasyJetGrey = Color(0xFF707070)
val EasyJetLightGrey = Color(0xFFEFEFEF)
val EasyJetGreen = Color(0xFF00875A)
val EasyJetRed = Color(0xFFDE350B)
