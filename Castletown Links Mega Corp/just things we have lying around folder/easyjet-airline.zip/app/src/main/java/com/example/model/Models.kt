package com.example.model

data class Flight(
  val flightId: String,
  val marketingCarrier: String = "U2",
  val operatingCarrier: String = "easyJet Europe",
  val flightNumber: String,
  val origin: String,
  val destination: String,
  val originCity: String,
  val destinationCity: String,
  val departureTime: String,
  val arrivalTime: String,
  val duration: String,
  val price: Double,
  val isDirect: Boolean = true,
  val includedBag: String = "Small underseat bag included",
  val date: String = "18 September 2027"
)

data class Booking(
  val bookingRef: String,
  val passengerName: String,
  val origin: String,
  val destination: String,
  val flightNumber: String,
  val flightDate: String,
  val departureTime: String,
  val boardingTime: String,
  val seat: String,
  val gate: String,
  val baggageType: String,
  val status: String, // CONFIRMED, CHECKED_IN, DELAYED, CANCELLED
  val totalPrice: Double,
  val isDemo: Boolean = true,
  val delayMinutes: Int = 0
)

data class Passenger(
  val firstName: String,
  val lastName: String,
  val title: String = "Mr",
  val email: String,
  val phone: String
)

data class AncillarySelection(
  val cabinBag: String = "Standard", // Standard, Upgraded Cabin Bag (+£9.99)
  val holdBag: String = "None", // None, 15kg (+£21.99), 23kg (+£29.99)
  val selectedSeat: String = "12A" // 12A (+£7.50) or None
)
