package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AirlineRepository
import com.example.ui.theme.EasyJetCharcoal
import com.example.ui.theme.EasyJetOrange
import com.example.ui.theme.EasyJetSurface

@Composable
fun StaffConsoleScreen(
  onBackClicked: () -> Unit
) {
  val bookings by AirlineRepository.bookings.collectAsState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(EasyJetCharcoal)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBackClicked) {
        Icon(
          imageVector = Icons.Default.ArrowBack,
          contentDescription = "Back",
          tint = Color.White
        )
      }
      Text(
        text = "Staff Administration Console",
        color = Color.White,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 8.dp)
      )
    }

    Surface(
      modifier = Modifier
        .fillMaxSize()
        .weight(1f),
      shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
      color = EasyJetSurface
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp)
      ) {
        Text(
          text = "Active Fixture Bookings (${bookings.size})",
          color = EasyJetCharcoal,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        bookings.forEach { b ->
          Card(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 6.dp),
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FA))
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
              ) {
                Text(
                  text = "Ref: ${b.bookingRef}",
                  color = EasyJetOrange,
                  fontWeight = FontWeight.Bold
                )
                Text(
                  text = b.status,
                  color = if (b.status == "CONFIRMED") EasyJetOrange else Color.Gray,
                  fontWeight = FontWeight.Bold
                )
              }
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "${b.passengerName} • ${b.origin} to ${b.destination}",
                color = EasyJetCharcoal,
                fontSize = 14.sp
              )
              Text(
                text = "Flight ${b.flightNumber} • Seat ${b.seat} • £${b.totalPrice}",
                color = Color.Gray,
                fontSize = 13.sp
              )
            }
          }
        }
      }
    }
  }
}
