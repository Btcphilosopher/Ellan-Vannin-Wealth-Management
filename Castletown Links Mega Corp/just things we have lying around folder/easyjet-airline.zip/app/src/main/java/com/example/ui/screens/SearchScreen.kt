package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EasyJetCharcoal
import com.example.ui.theme.EasyJetOrange
import com.example.ui.theme.EasyJetSurface

@Composable
fun SearchScreen(
  onSearchClicked: () -> Unit
) {
  var origin by remember { mutableStateOf("London Gatwick (LGW)") }
  var destination by remember { mutableStateOf("Barcelona (BCN)") }
  var dates by remember { mutableStateOf("18–22 September 2027") }
  var passengers by remember { mutableStateOf("1 adult") }
  var isReturn by remember { mutableStateOf(true) }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(EasyJetOrange)
      .verticalScroll(rememberScrollState())
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp, vertical = 16.dp),
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "easyJet",
        color = Color.White,
        fontSize = 32.sp,
        fontWeight = FontWeight.ExtraBold,
        letterSpacing = (-1).sp
      )
    }

    // "Where next?" title
    Text(
      text = "Where next?",
      color = Color.White,
      fontSize = 32.sp,
      fontWeight = FontWeight.Bold,
      modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
    )

    Spacer(modifier = Modifier.height(16.dp))

    // White Search Box Card
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = EasyJetSurface),
      elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        // One-way / Return toggle
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFFF0F0F0), RoundedCornerShape(50.dp))
            .padding(4.dp),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          TabButton(
            text = "Return",
            selected = isReturn,
            onClick = { isReturn = true },
            modifier = Modifier.weight(1f)
          )
          TabButton(
            text = "One-way",
            selected = !isReturn,
            onClick = { isReturn = false },
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // From field
        SearchFieldItem(
          icon = Icons.Default.FlightTakeoff,
          label = "From",
          value = origin,
          onClick = { /* Picker */ }
        )

        Divider(color = Color(0xFFEEEEEE), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

        // To field
        SearchFieldItem(
          icon = Icons.Default.FlightLand,
          label = "To",
          value = destination,
          onClick = { /* Picker */ }
        )

        Divider(color = Color(0xFFEEEEEE), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

        // Dates field
        SearchFieldItem(
          icon = Icons.Default.DateRange,
          label = "Dates",
          value = dates,
          onClick = { /* Picker */ }
        )

        Divider(color = Color(0xFFEEEEEE), thickness = 1.dp, modifier = Modifier.padding(vertical = 8.dp))

        // Passengers field
        SearchFieldItem(
          icon = Icons.Default.Person,
          label = "Passengers",
          value = passengers,
          onClick = { /* Picker */ }
        )

        Spacer(modifier = Modifier.height(24.dp))

        // Search flights button
        Button(
          onClick = onSearchClicked,
          modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .testTag("search_flights_button"),
          shape = RoundedCornerShape(28.dp),
          colors = ButtonDefaults.buttonColors(containerColor = EasyJetOrange)
        ) {
          Text(
            text = "Search flights",
            color = Color.White,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(24.dp))

    // Destination Inspiration Card
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp)
        .clickable { onSearchClicked() },
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = EasyJetSurface)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "A little sunshine awaits",
              color = EasyJetCharcoal,
              fontSize = 20.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Discover direct flights from London Gatwick to Barcelona from £64.99.",
              color = Color.Gray,
              fontSize = 14.sp
            )
          }
          Surface(
            shape = RoundedCornerShape(50.dp),
            color = EasyJetOrange,
            modifier = Modifier.size(40.dp)
          ) {
            Box(contentAlignment = Alignment.Center) {
              Icon(
                imageVector = Icons.Default.ArrowForward,
                contentDescription = "View inspiration",
                tint = Color.White
              )
            }
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(32.dp))
  }
}

@Composable
fun TabButton(
  text: String,
  selected: Boolean,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val backgroundColor = if (selected) EasyJetSurface else Color.Transparent
  val textColor = if (selected) EasyJetCharcoal else Color.Gray
  val fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal

  Box(
    modifier = modifier
      .clip(RoundedCornerShape(50.dp))
      .background(backgroundColor)
      .clickable(onClick = onClick)
      .padding(vertical = 10.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = text,
      color = textColor,
      fontSize = 14.sp,
      fontWeight = fontWeight
    )
  }
}

@Composable
fun SearchFieldItem(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  value: String,
  onClick: () -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(vertical = 8.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      imageVector = icon,
      contentDescription = label,
      tint = EasyJetCharcoal,
      modifier = Modifier.size(24.dp)
    )
    Spacer(modifier = Modifier.width(16.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(
        text = label,
        color = Color.Gray,
        fontSize = 12.sp
      )
      Text(
        text = value,
        color = EasyJetCharcoal,
        fontSize = 16.sp,
        fontWeight = FontWeight.SemiBold
      )
    }
    Icon(
      imageVector = Icons.Default.ChevronRight,
      contentDescription = "Edit $label",
      tint = Color.Gray
    )
  }
}
