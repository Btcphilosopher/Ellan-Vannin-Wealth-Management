package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardTravel
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AirlineRepository
import com.example.model.Booking
import com.example.ui.theme.EasyJetCharcoal
import com.example.ui.theme.EasyJetOrange
import com.example.ui.theme.EasyJetSurface

@Composable
fun TripsScreen(
  onOpenBoardingPass: (String) -> Unit,
  onCheckInClicked: (String) -> Unit
) {
  val bookings by AirlineRepository.bookings.collectAsState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(EasyJetOrange)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 20.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "My Trips",
        color = Color.White,
        fontSize = 28.sp,
        fontWeight = FontWeight.ExtraBold
      )
    }

    Surface(
      modifier = Modifier
        .fillMaxSize()
        .weight(1f),
      shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
      color = EasyJetSurface
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp)
      ) {
        if (bookings.isEmpty()) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 60.dp),
            contentAlignment = Alignment.Center
          ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
              Icon(
                imageVector = Icons.Default.CardTravel,
                contentDescription = "No trips",
                tint = Color.LightGray,
                modifier = Modifier.size(64.dp)
              )
              Spacer(modifier = Modifier.height(16.dp))
              Text(
                text = "No upcoming trips found",
                color = Color.Gray,
                fontSize = 16.sp
              )
            }
          }
        } else {
          bookings.forEach { booking ->
            BookingCard(
              booking = booking,
              onBoardingPassClick = { onOpenBoardingPass(booking.bookingRef) },
              onCheckInClick = { onCheckInClicked(booking.bookingRef) }
            )
            Spacer(modifier = Modifier.height(16.dp))
          }
        }
      }
    }
  }
}

@Composable
fun BookingCard(
  booking: Booking,
  onBoardingPassClick: () -> Unit,
  onCheckInClick: () -> Unit
) {
  Card(
    modifier = Modifier.fillMaxWidth(),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = Color.White),
    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(20.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "Ref: ${booking.bookingRef}",
          color = EasyJetOrange,
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold
        )
        Surface(
          shape = RoundedCornerShape(50.dp),
          color = if (booking.status == "CHECKED_IN") Color(0xFF00875A) else if (booking.status == "DELAYED") Color(0xFFDE350B) else EasyJetOrange
        ) {
          Text(
            text = booking.status,
            color = Color.White,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "${booking.origin} → ${booking.destination}",
            color = EasyJetCharcoal,
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Flight ${booking.flightNumber} • ${booking.flightDate}",
            color = Color.Gray,
            fontSize = 14.sp
          )
        }
      }

      if (booking.delayMinutes > 0 || booking.status == "DELAYED") {
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "⚠️ Flight delayed by ${booking.delayMinutes} mins. Check airport info.",
          color = Color(0xFFDE350B),
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold
        )
      }

      Spacer(modifier = Modifier.height(16.dp))
      Divider(color = Color(0xFFF0F0F0))
      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text(
            text = "Passenger",
            color = Color.Gray,
            fontSize = 11.sp
          )
          Text(
            text = booking.passengerName,
            color = EasyJetCharcoal,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
        Column(horizontalAlignment = Alignment.End) {
          Text(
            text = "Seat",
            color = Color.Gray,
            fontSize = 11.sp
          )
          Text(
            text = booking.seat,
            color = EasyJetCharcoal,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        if (booking.status != "CHECKED_IN") {
          Button(
            onClick = {
              AirlineRepository.completeCheckIn(booking.bookingRef, booking.seat)
            },
            modifier = Modifier
              .weight(1f)
              .height(44.dp)
              .testTag("check_in_button_${booking.bookingRef}"),
            shape = RoundedCornerShape(22.dp),
            colors = ButtonDefaults.buttonColors(containerColor = EasyJetOrange)
          ) {
            Text(
              text = "Check in",
              color = Color.White,
              fontSize = 14.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Button(
          onClick = onBoardingPassClick,
          modifier = Modifier
            .weight(1f)
            .height(44.dp)
            .testTag("view_boarding_pass_${booking.bookingRef}"),
          shape = RoundedCornerShape(22.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = if (booking.status == "CHECKED_IN") EasyJetCharcoal else Color.LightGray
          )
        ) {
          Icon(
            imageVector = Icons.Default.ConfirmationNumber,
            contentDescription = "Boarding pass",
            tint = Color.White,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Boarding pass",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
