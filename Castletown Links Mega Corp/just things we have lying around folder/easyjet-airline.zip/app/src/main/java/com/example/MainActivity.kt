package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardTravel
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.example.ui.screens.*
import com.example.ui.theme.EasyJetTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      EasyJetTheme {
        MainAppContent()
      }
    }
  }
}

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
  object Search : Screen("search", "Search", Icons.Default.Search)
  object Trips : Screen("trips", "Trips", Icons.Default.CardTravel)
  object BoardingPass : Screen("boarding_pass", "Boarding passes", Icons.Default.ConfirmationNumber)
  object Account : Screen("account", "Account", Icons.Default.Person)
}

@Composable
fun MainAppContent() {
  var currentTab by remember { mutableStateOf<String>("search") }
  var subScreen by remember { mutableStateOf<String?>(null) }
  var selectedCabinBag by remember { mutableStateOf("Small underseat bag") }
  var selectedSeat by remember { mutableStateOf("12A") }
  var activeBookingRef by remember { mutableStateOf("EZ9482X") }

  val items = listOf(Screen.Search, Screen.Trips, Screen.BoardingPass, Screen.Account)

  Scaffold(
    modifier = Modifier.fillMaxSize(),
    bottomBar = {
      if (subScreen == null) {
        NavigationBar(
          containerColor = MaterialTheme.colorScheme.surface,
          contentColor = MaterialTheme.colorScheme.onSurface
        ) {
          items.forEach { screen ->
            NavigationBarItem(
              icon = { Icon(screen.icon, contentDescription = screen.title) },
              label = { Text(screen.title) },
              selected = currentTab == screen.route,
              onClick = { currentTab = screen.route },
              colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                selectedTextColor = MaterialTheme.colorScheme.primary,
                unselectedIconColor = Color.Gray,
                unselectedTextColor = Color.Gray
              )
            )
          }
        }
      }
    }
  ) { innerPadding ->
    Box(modifier = Modifier.padding(innerPadding)) {
      if (subScreen != null) {
        when (subScreen) {
          "results" -> FlightResultsScreen(
            onBackClicked = { subScreen = null },
            onFlightSelected = { flight -> subScreen = "bags_seats" }
          )
          "bags_seats" -> BagAndSeatScreen(
            onBackClicked = { subScreen = "results" },
            onContinueToPassenger = { bag, seat ->
              selectedCabinBag = bag
              selectedSeat = seat
              subScreen = "passenger_payment"
            }
          )
          "passenger_payment" -> PassengerPaymentScreen(
            cabinBag = selectedCabinBag,
            seat = selectedSeat,
            onBackClicked = { subScreen = "bags_seats" },
            onBookingConfirmed = { ref ->
              activeBookingRef = ref
              subScreen = null
              currentTab = "boarding_pass"
            }
          )
          "staff_console" -> StaffConsoleScreen(
            onBackClicked = { subScreen = null }
          )
        }
      } else {
        when (currentTab) {
          "search" -> SearchScreen(
            onSearchClicked = { subScreen = "results" }
          )
          "trips" -> TripsScreen(
            onOpenBoardingPass = { ref ->
              activeBookingRef = ref
              currentTab = "boarding_pass"
            },
            onCheckInClicked = { ref ->
              activeBookingRef = ref
              currentTab = "boarding_pass"
            }
          )
          "boarding_pass" -> BoardingPassScreen(
            bookingRef = activeBookingRef,
            onViewTripDetails = { currentTab = "trips" }
          )
          "account" -> AccountScreen(
            onOpenStaffConsole = { subScreen = "staff_console" }
          )
        }
      }
    }
  }
}
