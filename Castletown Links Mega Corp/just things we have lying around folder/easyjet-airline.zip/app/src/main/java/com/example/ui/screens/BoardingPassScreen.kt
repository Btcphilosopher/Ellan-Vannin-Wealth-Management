package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.AirlineRepository
import com.example.ui.theme.EasyJetCharcoal
import com.example.ui.theme.EasyJetOrange
import com.example.ui.theme.EasyJetSurface

@Composable
fun BoardingPassScreen(
  bookingRef: String = "EZ9482X",
  onViewTripDetails: () -> Unit
) {
  val bookings by AirlineRepository.bookings.collectAsState()
  val booking = bookings.find { it.bookingRef == bookingRef } ?: bookings.firstOrNull()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(EasyJetOrange)
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 16.dp),
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "easyJet",
        color = Color.White,
        fontSize = 32.sp,
        fontWeight = FontWeight.ExtraBold
      )
    }

    Text(
      text = "Ready for take-off",
      color = Color.White,
      fontSize = 28.sp,
      fontWeight = FontWeight.Bold,
      modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
    )

    Spacer(modifier = Modifier.height(16.dp))

    // Main Boarding Pass Card Container
    Surface(
      modifier = Modifier
        .fillMaxSize()
        .weight(1f),
      shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
      color = EasyJetSurface
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // DEMO NOTICE BANNER
        Surface(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          color = EasyJetCharcoal
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.Info,
              contentDescription = "Demo info",
              tint = Color.White,
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "DEMO — NOT VALID FOR TRAVEL",
              color = Color.White,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Passenger Name
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FA))
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "PASSENGER",
              color = Color.Gray,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = booking?.passengerName ?: "ALEX MORGAN",
              color = EasyJetCharcoal,
              fontSize = 20.sp,
              fontWeight = FontWeight.ExtraBold
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Flight Origin -> Destination Card
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FA))
        ) {
          Column(modifier = Modifier.padding(20.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text(
                  text = booking?.origin ?: "LGW",
                  color = EasyJetCharcoal,
                  fontSize = 32.sp,
                  fontWeight = FontWeight.Black
                )
                Text(
                  text = "London Gatwick",
                  color = Color.Gray,
                  fontSize = 12.sp
                )
              }
              Text(
                text = "→",
                color = EasyJetOrange,
                fontSize = 28.sp,
                fontWeight = FontWeight.Bold
              )
              Column(horizontalAlignment = Alignment.End) {
                Text(
                  text = booking?.destination ?: "BCN",
                  color = EasyJetCharcoal,
                  fontSize = 32.sp,
                  fontWeight = FontWeight.Black
                )
                Text(
                  text = "Barcelona",
                  color = Color.Gray,
                  fontSize = 12.sp
                )
              }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Divider(color = Color(0xFFE0E0E0))
            Spacer(modifier = Modifier.height(16.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text(text = "18 SEP 2027", color = EasyJetCharcoal, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(text = "Flight Date", color = Color.Gray, fontSize = 11.sp)
              }
              Column {
                Text(text = "06:30", color = EasyJetCharcoal, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(text = "Boarding", color = Color.Gray, fontSize = 11.sp)
              }
              Column {
                Text(text = booking?.seat ?: "12A", color = EasyJetCharcoal, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(text = "Seat", color = Color.Gray, fontSize = 11.sp)
              }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text(text = "DEMO 204", color = EasyJetCharcoal, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(text = "Flight", color = Color.Gray, fontSize = 11.sp)
              }
              Column {
                Text(text = booking?.departureTime ?: "07:10", color = EasyJetCharcoal, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(text = "Departure", color = Color.Gray, fontSize = 11.sp)
              }
              Column {
                Text(text = booking?.gate ?: "-", color = EasyJetCharcoal, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(text = "Gate", color = Color.Gray, fontSize = 11.sp)
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Check airport displays notice
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(imageVector = Icons.Default.Info, contentDescription = "Info", tint = Color.Gray, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "Check airport displays for gate updates.", color = Color.Gray, fontSize = 12.sp)
        }

        Spacer(modifier = Modifier.height(20.dp))

        // SAMPLE BARCODE GRAPHIC
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          border = BorderStroke(1.dp, Color(0xFFEFEFEF))
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Text(
              text = "|||| ||||| |||| ||||| ||||||| ||||| ||||",
              color = EasyJetCharcoal,
              fontSize = 24.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 4.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "SAMPLE",
              color = EasyJetCharcoal,
              fontSize = 20.sp,
              fontWeight = FontWeight.ExtraBold,
              letterSpacing = 8.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "|||| ||||| |||| ||||| ||||||| ||||| ||||",
              color = EasyJetCharcoal,
              fontSize = 24.sp,
              fontWeight = FontWeight.Black,
              letterSpacing = 4.sp
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Baggage shortcut card
        Card(
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = Color(0xFFF8F9FA))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(imageVector = Icons.Default.Luggage, contentDescription = "Baggage", tint = EasyJetCharcoal, modifier = Modifier.size(24.dp))
            Spacer(modifier = Modifier.width(16.dp))
            Text(
              text = booking?.baggageType ?: "Small underseat bag",
              color = EasyJetCharcoal,
              fontSize = 15.sp,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.weight(1f)
            )
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
          onClick = onViewTripDetails,
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("view_trip_details_button"),
          shape = RoundedCornerShape(26.dp),
          colors = ButtonDefaults.buttonColors(containerColor = EasyJetOrange)
        ) {
          Text(
            text = "View trip details",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
