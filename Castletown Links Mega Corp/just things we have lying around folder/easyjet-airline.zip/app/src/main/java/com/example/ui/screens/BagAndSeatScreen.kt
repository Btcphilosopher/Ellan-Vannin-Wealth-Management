package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Chair
import androidx.compose.material.icons.filled.Luggage
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.EasyJetCharcoal
import com.example.ui.theme.EasyJetOrange
import com.example.ui.theme.EasyJetSurface

@Composable
fun BagAndSeatScreen(
  onBackClicked: () -> Unit,
  onContinueToPassenger: (String, String) -> Unit
) {
  var selectedCabinBag by remember { mutableStateOf("Small underseat bag (Included)") }
  var selectedSeat by remember { mutableStateOf("12A (£7.50)") }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(EasyJetOrange)
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBackClicked) {
        Icon(
          imageVector = Icons.Default.ArrowBack,
          contentDescription = "Back",
          tint = Color.White
        )
      }
      Text(
        text = "Bags & Seats",
        color = Color.White,
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 8.dp)
      )
    }

    Surface(
      modifier = Modifier
        .fillMaxSize()
        .weight(1f),
      shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
      color = EasyJetSurface
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(20.dp)
      ) {
        Text(
          text = "Cabin baggage",
          color = EasyJetCharcoal,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        BaggageOptionCard(
          title = "Small underseat bag",
          description = "Max 45 x 36 x 20 cm. Must fit under the seat in front of you.",
          price = "Included",
          selected = selectedCabinBag.contains("Small"),
          onClick = { selectedCabinBag = "Small underseat bag (Included)" }
        )

        Spacer(modifier = Modifier.height(12.dp))

        BaggageOptionCard(
          title = "Large cabin bag + underseat bag",
          description = "Max 56 x 45 x 25 cm for overhead locker + underseat bag.",
          price = "+ £15.99",
          selected = selectedCabinBag.contains("Large"),
          onClick = { selectedCabinBag = "Large cabin bag (+£15.99)" }
        )

        Spacer(modifier = Modifier.height(24.dp))

        Text(
          text = "Seat selection",
          color = EasyJetCharcoal,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(12.dp))

        SeatOptionCard(
          seatName = "12A - Window (Extra legroom)",
          price = "£7.50",
          selected = selectedSeat.contains("12A"),
          onClick = { selectedSeat = "12A (£7.50)" }
        )

        Spacer(modifier = Modifier.height(12.dp))

        SeatOptionCard(
          seatName = "12C - Aisle",
          price = "£5.00",
          selected = selectedSeat.contains("12C"),
          onClick = { selectedSeat = "12C (£5.00)" }
        )

        Spacer(modifier = Modifier.height(12.dp))

        SeatOptionCard(
          seatName = "Random seat allocation",
          price = "Free",
          selected = selectedSeat.contains("Random"),
          onClick = { selectedSeat = "Random (Free)" }
        )

        Spacer(modifier = Modifier.height(32.dp))

        Button(
          onClick = { onContinueToPassenger(selectedCabinBag, selectedSeat) },
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("continue_to_passenger_button"),
          shape = RoundedCornerShape(26.dp),
          colors = ButtonDefaults.buttonColors(containerColor = EasyJetOrange)
        ) {
          Text(
            text = "Continue to passenger details",
            color = Color.White,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}

@Composable
fun BaggageOptionCard(
  title: String,
  description: String,
  price: String,
  selected: Boolean,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (selected) Color(0xFFFFF2EB) else Color.White
    ),
    border = if (selected) BorderStroke(2.dp, EasyJetOrange) else BorderStroke(1.dp, Color(0xFFEFEFEF))
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = Icons.Default.Luggage,
        contentDescription = title,
        tint = if (selected) EasyJetOrange else Color.Gray,
        modifier = Modifier.size(28.dp)
      )
      Spacer(modifier = Modifier.width(16.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          color = EasyJetCharcoal,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = description,
          color = Color.Gray,
          fontSize = 12.sp
        )
      }
      Spacer(modifier = Modifier.width(12.dp))
      Text(
        text = price,
        color = if (selected) EasyJetOrange else EasyJetCharcoal,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold
      )
    }
  }
}

@Composable
fun SeatOptionCard(
  seatName: String,
  price: String,
  selected: Boolean,
  onClick: () -> Unit
) {
  Card(
    modifier = Modifier
      .fillMaxWidth()
      .clickable(onClick = onClick),
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (selected) Color(0xFFFFF2EB) else Color.White
    ),
    border = if (selected) BorderStroke(2.dp, EasyJetOrange) else BorderStroke(1.dp, Color(0xFFEFEFEF))
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = Icons.Default.Chair,
        contentDescription = seatName,
        tint = if (selected) EasyJetOrange else Color.Gray,
        modifier = Modifier.size(28.dp)
      )
      Spacer(modifier = Modifier.width(16.dp))
      Text(
        text = seatName,
        color = EasyJetCharcoal,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier.weight(1f)
      )
      Text(
        text = price,
        color = if (selected) EasyJetOrange else EasyJetCharcoal,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold
      )
    }
  }
}
