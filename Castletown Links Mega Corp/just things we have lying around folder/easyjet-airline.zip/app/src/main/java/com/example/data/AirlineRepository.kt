package com.example.data

import com.example.model.Booking
import com.example.model.Flight
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

object AirlineRepository {

  val fixtureOutboundFlights = listOf(
    Flight(
      flightId = "EZ-LGW-BCN-1",
      flightNumber = "U2 8451",
      origin = "LGW",
      destination = "BCN",
      originCity = "London Gatwick",
      destinationCity = "Barcelona",
      departureTime = "07:10",
      arrivalTime = "10:20",
      duration = "2h 10m",
      price = 64.99,
      date = "18 September 2027"
    ),
    Flight(
      flightId = "EZ-LGW-BCN-2",
      flightNumber = "U2 8453",
      origin = "LGW",
      destination = "BCN",
      originCity = "London Gatwick",
      destinationCity = "Barcelona",
      departureTime = "14:35",
      arrivalTime = "17:45",
      duration = "2h 10m",
      price = 79.99,
      date = "18 September 2027"
    )
  )

  val fixtureReturnFlights = listOf(
    Flight(
      flightId = "EZ-BCN-LGW-1",
      flightNumber = "U2 8452",
      origin = "BCN",
      destination = "LGW",
      originCity = "Barcelona",
      destinationCity = "London Gatwick",
      departureTime = "11:15",
      arrivalTime = "12:30",
      duration = "2h 15m",
      price = 79.99,
      date = "22 September 2027"
    )
  )

  private val initialBookings = listOf(
    Booking(
      bookingRef = "EZ9482X",
      passengerName = "Alex Morgan",
      origin = "LGW",
      destination = "BCN",
      flightNumber = "DEMO 204",
      flightDate = "18 SEP 2027",
      departureTime = "07:10",
      boardingTime = "06:30",
      seat = "12A",
      gate = "-",
      baggageType = "Small underseat bag",
      status = "CONFIRMED",
      totalPrice = 144.98,
      isDemo = true
    )
  )

  private val _bookings = MutableStateFlow<List<Booking>>(initialBookings)
  val bookings: StateFlow<List<Booking>> = _bookings.asStateFlow()

  private val _selectedOutboundFlight = MutableStateFlow<Flight?>(fixtureOutboundFlights[0])
  val selectedOutboundFlight: StateFlow<Flight?> = _selectedOutboundFlight.asStateFlow()

  private val _selectedReturnFlight = MutableStateFlow<Flight?>(fixtureReturnFlights[0])
  val selectedReturnFlight: StateFlow<Flight?> = _selectedReturnFlight.asStateFlow()

  fun selectOutbound(flight: Flight) {
    _selectedOutboundFlight.value = flight
  }

  fun selectReturn(flight: Flight) {
    _selectedReturnFlight.value = flight
  }

  fun addBooking(booking: Booking) {
    _bookings.update { current -> listOf(booking) + current }
  }

  fun completeCheckIn(bookingRef: String, seat: String) {
    _bookings.update { current ->
      current.map { b ->
        if (b.bookingRef == bookingRef) {
          b.copy(status = "CHECKED_IN", seat = seat, gate = "A14")
        } else b
      }
    }
  }

  fun injectDelay(bookingRef: String, delayMinutes: Int) {
    _bookings.update { current ->
      current.map { b ->
        if (b.bookingRef == bookingRef || bookingRef == "ALL") {
          b.copy(status = "DELAYED", delayMinutes = if (delayMinutes > 0) delayMinutes else b.delayMinutes)
        } else b
      }
    }
  }

  fun cancelBooking(bookingRef: String) {
    _bookings.update { current ->
      current.map { b ->
        if (b.bookingRef == bookingRef) {
          b.copy(status = "CANCELLED")
        } else b
      }
    }
  }
}
