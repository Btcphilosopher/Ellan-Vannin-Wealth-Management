# Security & Privacy Safeguards

McDelivery incorporates architectural standards to protect consumer information and simulate highly secure checkout networks.

---

### 1. Payment Security Abstraction
The application defines a strict abstraction around card data processing:
*   **Zero Raw Card Storage**: Card numbers are never persisted raw. They are masked (e.g. `**** **** **** 1882`) upon entry and before insertion into the database.
*   **Tokenization Simulation**: Payment states follow a strict state transition model:
    `CREATED → AUTHORISING → AUTHORISED → CAPTURED`
*   **Idempotency Protection**: Every checkout dispatches an idempotent transaction key to prevent double charging on poor network handshakes.

### 2. PII (Personally Identifiable Information) Safeguards
*   **Local-Only Sandbox**: Fictional address markers are stored inside the client's sandboxed Room SQLite database rather than external shared databases, protecting user home coordinates.
*   **Logging Masking**: System logs never output user CVVs, credit card expiry details, or raw delivery instructions containing lock-box codes or gate pins.
