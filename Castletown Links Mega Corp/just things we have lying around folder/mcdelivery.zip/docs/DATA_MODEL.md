# Data Model & Relational Schemas

McDelivery persists critical user state, cart, and historical order data locally using an on-device SQLite database backed by Android **Room Persistence**.

---

### Room Tables & Fields

#### 1. `addresses` (AddressEntity)
*   `id`: `Int` (PrimaryKey, AutoGenerate)
*   `label`: `String` (e.g. "Home", "Work", "Other")
*   `houseNumber`: `String`
*   `street`: `String`
*   `city`: `String`
*   `postcode`: `String`
*   `deliveryInstructions`: `String`

#### 2. `payment_cards` (CardEntity)
*   `id`: `Int` (PrimaryKey, AutoGenerate)
*   `cardholderName`: `String`
*   `cardNumber`: `String` (Masked for privacy)
*   `expiryDate`: `String`
*   `cvv`: `String`
*   `cardType`: `String` (e.g. "Visa", "Mastercard")

#### 3. `cart_items` (CartItemEntity)
*   `id`: `Int` (PrimaryKey, AutoGenerate)
*   `menuItemId`: `String`
*   `name`: `String`
*   `priceMinor`: `Int` (Prices in Minor Units/Pence to prevent floating point errors)
*   `quantity`: `Int`
*   `customizationsJson`: `String` (Applied modifiers encoded as JSON string)
*   `imageResourceUrl`: `String`

#### 4. `orders` (OrderEntity)
*   `id`: `String` (PrimaryKey, e.g. "MD-20481")
*   `trackingNumber`: `String`
*   `status`: `String`
*   `timestamp`: `Long`
*   `subtotalMinor`: `Int`
*   `deliveryFeeMinor`: `Int`
*   `serviceFeeMinor`: `Int`
*   `totalMinor`: `Int`
*   `addressJson`: `String` (Full Address representation encoded in JSON)
*   `itemsJson`: `String` (Itemized Cart list encoded in JSON)
*   `courierName`: `String`
*   `courierPhone`: `String`
*   `courierLat`: `Double`
*   `courierLng`: `Double`
*   `restaurantId`: `String`
*   `restaurantName`: `String`
*   `etaMinutes`: `Int`
*   `elapsedSimulatedSeconds`: `Int`

#### 5. `support_cases` (SupportCaseEntity)
*   `id`: `String` (PrimaryKey, e.g. "CASE-4911")
*   `orderId`: `String`
*   `category`: `String` (e.g. "Missing item")
*   `description`: `String`
*   `status`: `String` ("OPEN", "RESOLVED", "CLOSED")
*   `createdAt`: `Long`
*   `resolution`: `String`
