# Local Development Guide

Get started with developing or compiling the **McDelivery** Android applet on your local system.

---

### Prerequisites
*   **Java Development Kit (JDK)**: JDK 17 or JDK 21 (JDK 17 recommended for Gradle 8.x)
*   **Gradle**: Configured automatically by the top-level wrapper settings.
*   **Android SDK**: Command-line tools and platform APIs 34+.

---

### Folder Structures & Layout
The project is organized as a unified clean code monorepo:
*   `app/src/main/java/com/example/data`: Database entities, DAOs, Moshi JSON converters, and logistics simulator algorithms.
*   `app/src/main/java/com/example/ui/components`: Reusable Material 3 Design System elements (buttons, map canvas, progress timeline, status indicators).
*   `app/src/main/java/com/example/ui`: Screen layouts (Checkout, Live Tracker, Home Grid, Kitchen Ops Console) and McDeliveryViewModel flow controller.
*   `app/src/test/`: JVM and Robolectric test runners.

---

### Standard Compilation & Assembly Commands

1.  **Clean build artifacts**:
    ```bash
    gradle clean
    ```
2.  **Compile & Verify Syntax**:
    ```bash
    gradle compileDebugKotlin
    ```
3.  **Run Robolectric E2E Tests**:
    ```bash
    gradle :app:testDebugUnitTest
    ```
4.  **Assemble Debug APK**:
    ```bash
    gradle assembleDebug
    ```
    The compiled binary will be located under `app/build/outputs/apk/debug/app-debug.apk`.
