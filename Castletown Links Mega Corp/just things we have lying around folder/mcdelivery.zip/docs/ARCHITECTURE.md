# Architecture Blueprints

The **McDelivery** architecture leverages modern Android engineering patterns to produce an offline-capable, reactive, and highly operational food ordering experience.

```mermaid
graph TD
    UI[Jetpack Compose Screens] -->|Observe State| VM[McDeliveryViewModel]
    VM -->|Dispatches Events| Repository[AppRepository]
    Repository -->|Performs Queries| DAO[Room DAOs]
    DAO -->|Reads/Writes| DB[(Room SQLite Database)]
    DS[DeliverySimulator] -->|Ticks Status updates| DB
```

### 1. Architectural Highlights

*   **Model-View-ViewModel (MVVM)**: Establishes a clean unidirectional data flow. The UI observes the StateFlows exposed by the `McDeliveryViewModel` and translates state variations into re-compositions.
*   **Repository Pattern**: Isolates data collection strategies from the view model layer. The `AppRepository` coordinates access to different Room entities, allowing database logic to change without impacting the presentation layer.
*   **Reactive Flow Binding**: DAO queries return Kotlin `Flow<List<T>>`. This means updates initiated by background logistics simulators propagate immediately up to the active UI views.
*   **Built-in Simulation Engine**: Decouples logistics operations so developers can observe entire, complex delivery workflows without requiring live backend connections or hardware GPS signals.
