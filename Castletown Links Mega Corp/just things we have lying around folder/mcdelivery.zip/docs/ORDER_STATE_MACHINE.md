# Order State Machine Blueprints

The core engine of the McDelivery application is a fully trace-timestamped, deterministic State Machine. It manages the exact path of the order from cart placement to customer arrival.

```text
    [CREATED]
        ↓
    [PAYMENT_AUTHORISED]
        ↓
    [RESTAURANT_RECEIVED]
        ↓
    [RESTAURANT_ACCEPTED] (Kitchen can accept)
        ↓
    [PREPARING] (Kitchen cooks/assembles)
        ↓
    [COOKING]
        ↓
    [PACKING] (Order wrapped in bag)
        ↓
    [READY_FOR_COLLECTION]
        ↓
    [COURIER_ASSIGNED] (Rider assigned & approaches)
        ↓
    [COURIER_AT_RESTAURANT]
        ↓
    [ORDER_COLLECTED]
        ↓
    [OUT_FOR_DELIVERY] (Rider traveling path on map)
        ↓
    [ARRIVING] (Rider at gate/door)
        ↓
    [DELIVERED] (Order completed!)
```

### State Definitions & Trigger Points

1.  **CREATED**: The order is persisted locally in the SQLite database.
2.  **PAYMENT_AUTHORISED**: Payment tokens are validated and verified.
3.  **RESTAURANT_RECEIVED**: Store kitchen alerts.
4.  **RESTAURANT_ACCEPTED**: The restaurant accepted the order manually or automatically.
5.  **PREPARING / COOKING / PACKING**: Kitchen assembly and packaging.
6.  **READY_FOR_COLLECTION**: Bags are prepared for collection.
7.  **COURIER_ASSIGNED**: Dispatch engine selects courier.
8.  **COURIER_AT_RESTAURANT**: Rider arrives to collect the order.
9.  **ORDER_COLLECTED**: Food is secured in the rider's thermal delivery bag.
10. **OUT_FOR_DELIVERY / ARRIVING**: Coordinates change dynamically on the map screen.
11. **DELIVERED**: Handed over to the customer.

### Fail-Safe Handling

The following states represent termination failures:
*   **RESTAURANT_REJECTED**: Order rejected due to ingredients unavailability.
*   **PAYMENT_FAILED**: Card authorization failed.
*   **CUSTOMER_CANCELLED**: Cancelled before preparation starts.
*   **DELIVERY_FAILED**: Courier unable to locate the customer or hand over.
*   **REFUNDED**: Resolved support case claims.
