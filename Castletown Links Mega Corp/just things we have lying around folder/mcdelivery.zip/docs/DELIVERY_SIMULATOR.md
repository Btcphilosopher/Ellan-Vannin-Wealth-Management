# Logistics & Delivery Simulator

To showcase real-world operational flows, McDelivery includes a state-of-the-art **Logistics & Courier Simulator**.

### Coordinate System & Grid Translation

The simulator operates on a coordinates grid matching the **London Victoria** station area:
*   **Restaurant (McDonald's Victoria)**: `51.4963, -0.1431`
*   **Customer Location (12 Example Street)**: `51.5015, -0.1419`
*   **Courier Initial Spawn**: `51.4900, -0.1450`

### Ticking Calculations & Map Feedback

As simulated seconds accumulate:
1.  **Rider approach to Store**: Courier coordinates interpolate linearly from initial spawn `(51.4900, -0.1450)` to the restaurant `(51.4963, -0.1431)`.
2.  **Rider approach to Home**: Upon `ORDER_COLLECTED`, coordinates interpolate linearly from the restaurant to the customer's coordinates `(51.5015, -0.1419)`.
3.  **UI Canvas Map**: The custom Compose `Canvas` renders a highly polished vector styled map showing roadways, golden arches store pin, home destination pin, and a smoothly moving courier circle updating instantly.

### Time Warp Modes

To help developers verify journeys in seconds rather than minutes:
*   **Normal Mode**: 1 real second = 5 simulated seconds.
*   **Turbo Time Warp Mode**: 1 real second = 30 simulated seconds. Fully completes a 12-minute journey in exactly 24 real-world seconds!
