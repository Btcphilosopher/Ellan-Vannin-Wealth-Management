# Public REST API Design

To support future backend scaling or cloud integration, McDelivery isolates network interactions using clean RESTful endpoints. The mobile companion's data providers map to these specific interfaces:

---

### REST Resource Routes

#### 1. `GET /api/v1/restaurants`
Retrieves a list of participating stores near the user's delivery geocode.
*   **Request Params**: `latitude=51.5015&longitude=-0.1419`
*   **Response**: List of Restaurants (name, delivery time ranges, distance, and fees).

#### 2. `GET /api/v1/menu`
Fetches the complete catalog.
*   **Response**: Category-mapped items with ingredients, allergens, prices, and available customizer modifiers.

#### 3. `POST /api/v1/baskets`
Saves or synchronizes active shopping carts across devices.

#### 4. `POST /api/v1/orders`
Places a new delivery order.
*   **Request Payload**:
    ```json
    {
      "restaurant_id": "demo-london-victoria",
      "basket_id": "basket-9411",
      "delivery_address_id": "address-102",
      "payment_method_id": "card-812"
    }
    ```
*   **Response (201 Created)**:
    ```json
    {
      "order_id": "MD-20481",
      "status": "CREATED",
      "estimated_delivery_minutes": 24,
      "total_minor": 1966,
      "currency": "GBP"
    }
    ```

#### 5. `GET /api/v1/orders/{id}/tracking`
Websocket or Server-Sent Events (SSE) route streaming live coordinate packets.
*   **Response**:
    ```json
    {
      "courier_lat": 51.4981,
      "courier_lng": -0.1425,
      "status": "OUT_FOR_DELIVERY",
      "eta_minutes": 8
    }
    ```
