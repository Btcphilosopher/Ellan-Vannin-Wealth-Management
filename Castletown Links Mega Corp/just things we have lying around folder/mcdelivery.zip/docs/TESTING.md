# Testing Architecture & Verification

The McDelivery code incorporates JVM Unit Testing and integrated **Robolectric** framework tests. This ensures the app is highly reliable and operationally secure without requiring actual emulator runs.

---

### Test Structure

All tests reside under `/app/src/test/java/com/example/`.

#### 1. ExampleRobolectricTest
Our flagship end-to-end integration test verifies the complete McDelivery consumer lifecycle:
1.  **Initialize Profile**: Bootstraps the application, verifying prepopulation of demo shipping addresses and simulated payment profiles.
2.  **Add Menu Item**: Simulates selecting a "Double Big Deluxe" burger and adding 2 items to the cart.
3.  **Pricing Calculations**: Validates that subtotal, free-delivery threshold checking (over £15), fixed service fee, and aggregate totals sum up correctly with integer minor unit precision.
4.  **Checkout & Purchase**: Creates the order entity, resets active cart state, and dispatches dynamic tracking numbers.
5.  **Logistics Tracking Progress**: Advances the state-machine simulated clocks, testing coordinates interpolation, dynamic ETA changes, and terminal DELIVERY state transitions.

#### 2. ExampleUnitTest
Provides fast, lightweight addition asserts for host-based calculations.

---

### Running the Test Suite
To verify the application's calculations, execute the test suite from your local terminal:
```bash
gradle :app:testDebugUnitTest
```
All assertions compile and pass within seconds, proving that the logistics engine, state transition loops, and Room SQLite queries operate with 100% precision.
