# McDelivery — McDonald's Delivery Operational Prototype

McDelivery is a high-fidelity, consumer-focused Android application built with Jetpack Compose, Kotlin, and Room. Designed as a modern, world-class mobile commerce and logistics prototype, it mimics the real-world operational lifecycle of ordering and tracking McDonald's deliveries.

**ORDER → PREPARE → DISPATCH → DELIVER → ENJOY**

---

## 🚀 Key Features

*   **Location Selection**: Select and manage fictional delivery addresses across London.
*   **Dynamic Digital Menu**: Full McDonald's-style catalog including burgers, chicken, fries, drinks, desserts, and Happy Meals.
*   **Advanced Customizer**: Customize individual items by adding extras (cheese, beef patty) or removing standard ingredients (mustard, pickles) with real-time price updates.
*   **Sophisticated Cart & Checkout**: Real-time pricing calculations, service fees, and automatic free delivery rules over £15.
*   **Operational Dispatch & Simulator**: Watch orders transition through the 14-state life-cycle in real-time.
*   **Accelerated Time (Warp Mode)**: Accelerate the courier traveling path (1 real second = 30 simulated seconds) to rapidly observe delivery progress.
*   **Interactive Vector Logistics Map**: Custom-drawn canvas map showing streets, store locations, customer pins, and smooth real-time courier position tracking.
*   **Kitchen Operations Console**: A simulator panel representing how a store kitchen crew views, accepts, and dispatches prepared orders.
*   **Customer Support Desk**: Topic-linked complaint submission with reactive state tracking.

---

## 🛠 Tech Stack & Architecture

*   **Language**: Kotlin 100%
*   **UI Framework**: Jetpack Compose with Material Design 3
*   **Local Persistence**: Room SQLite Database
*   **JSON Serialization**: Moshi JSON Parser
*   **Asynchronous Flow**: Kotlin Coroutines & Reactive Flows
*   **Image Loading**: Coil Compose Async Loading
*   **Testing**: JVM Unit Testing & Robolectric Integration

---

## 📚 Supporting Documentation

For deep technical insights and blueprints, refer to our comprehensive documentation:

1.  **[ARCHITECTURE.md](docs/ARCHITECTURE.md)**: System design and modular composition.
2.  **[ORDER_STATE_MACHINE.md](docs/ORDER_STATE_MACHINE.md)**: Transition flows and timing structures.
3.  **[DELIVERY_SIMULATOR.md](docs/DELIVERY_SIMULATOR.md)**: Logistics dispatching and coordinate translation.
4.  **[DATA_MODEL.md](docs/DATA_MODEL.md)**: Relational tables and schemas.
5.  **[SECURITY.md](docs/SECURITY.md)**: Payment abstractions and token safeguards.
6.  **[TESTING.md](docs/TESTING.md)**: Workflow verification test suites.
7.  **[LOCAL_DEVELOPMENT.md](docs/LOCAL_DEVELOPMENT.md)**: Setup, build, and runner guidelines.
