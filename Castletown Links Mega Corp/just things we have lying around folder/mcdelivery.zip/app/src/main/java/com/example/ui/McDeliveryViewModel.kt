package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class McDeliveryViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: AppRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AppRepository(database)

        // Prepopulate demo data on first launch
        viewModelScope.launch {
            prepopulateDemoDataIfNeeded()
        }

        // Start background simulator ticker
        startSimulationTicker()
    }

    // --- Screen Navigation ---
    private val _currentScreen = MutableStateFlow(Screen.HOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _backstack = MutableStateFlow<List<Screen>>(listOf(Screen.HOME))
    val backstack: StateFlow<List<Screen>> = _backstack.asStateFlow()

    fun navigateTo(screen: Screen) {
        val currentList = _backstack.value.toMutableList()
        currentList.add(screen)
        _backstack.value = currentList
        _currentScreen.value = screen
    }

    fun navigateBack() {
        val currentList = _backstack.value.toMutableList()
        if (currentList.size > 1) {
            currentList.removeAt(currentList.size - 1)
            _backstack.value = currentList
            _currentScreen.value = currentList.last()
        } else {
            _currentScreen.value = Screen.HOME
        }
    }

    // --- State Variables ---
    private val _selectedRestaurant = MutableStateFlow(MenuData.restaurants[0])
    val selectedRestaurant: StateFlow<Restaurant> = _selectedRestaurant.asStateFlow()

    private val _selectedCategory = MutableStateFlow("Burgers")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedProduct = MutableStateFlow<MenuItem?>(null)
    val selectedProduct: StateFlow<MenuItem?> = _selectedProduct.asStateFlow()

    private val _currentModifiers = MutableStateFlow<List<AppliedModifier>>(emptyList())
    val currentModifiers: StateFlow<List<AppliedModifier>> = _currentModifiers.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedAddress = MutableStateFlow<AddressEntity?>(null)
    val selectedAddress: StateFlow<AddressEntity?> = _selectedAddress.asStateFlow()

    private val _selectedCard = MutableStateFlow<CardEntity?>(null)
    val selectedCard: StateFlow<CardEntity?> = _selectedCard.asStateFlow()

    private val _activeOrder = MutableStateFlow<OrderEntity?>(null)
    val activeOrder: StateFlow<OrderEntity?> = _activeOrder.asStateFlow()

    private val _turboMode = MutableStateFlow(true) // true: 1 real sec = 30 simulated sec, false: 1 real sec = 5 simulated sec
    val turboMode: StateFlow<Boolean> = _turboMode.asStateFlow()

    // --- Reactive Data Flows from DB ---
    val addresses: StateFlow<List<AddressEntity>> = repository.allAddresses
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cards: StateFlow<List<CardEntity>> = repository.allCards
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartItems: StateFlow<List<CartItemEntity>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val supportCases: StateFlow<List<SupportCaseEntity>> = repository.allSupportCases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Pricing Calculation ---
    val cartSubtotal: StateFlow<Int> = cartItems.map { items ->
        items.sumOf { it.priceMinor * it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val deliveryFee: StateFlow<Int> = combine(cartSubtotal, selectedRestaurant) { subtotal, restaurant ->
        if (subtotal > 1500) 0 else restaurant.deliveryFeeMinor // FREE delivery over £15!
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val serviceFee: StateFlow<Int> = cartSubtotal.map { subtotal ->
        if (subtotal > 0) 50 else 0 // Fixed 50p service fee
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val cartTotal: StateFlow<Int> = combine(cartSubtotal, deliveryFee, serviceFee) { subtotal, delivery, service ->
        subtotal + delivery + service
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // --- Selection and Modifiers logic ---
    fun selectRestaurant(restaurant: Restaurant) {
        _selectedRestaurant.value = restaurant
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun selectProduct(menuItem: MenuItem) {
        _selectedProduct.value = menuItem
        // Initialize modifiers with default choices
        val initialMods = menuItem.customizerOptions.map { option ->
            if (option.isSelectionGroup) {
                AppliedModifier(
                    name = option.name,
                    priceMinor = option.priceMinor,
                    selectedChoice = option.selectionGroupItems.firstOrNull()
                )
            } else {
                AppliedModifier(
                    name = option.name,
                    priceMinor = option.priceMinor,
                    isRemoved = false
                )
            }
        }
        _currentModifiers.value = initialMods
        navigateTo(Screen.PRODUCT_DETAIL)
    }

    fun toggleModifier(modifierName: String, isSelection: Boolean, choice: String? = null) {
        val currentList = _currentModifiers.value.toMutableList()
        val index = currentList.indexOfFirst { it.name == modifierName }
        if (index != -1) {
            val existing = currentList[index]
            if (isSelection) {
                currentList[index] = existing.copy(selectedChoice = choice)
            } else {
                // If it's a "Remove" modifier, toggle isRemoved
                if (existing.name.startsWith("Remove")) {
                    currentList[index] = existing.copy(isRemoved = !existing.isRemoved)
                } else {
                    // It's an extra, e.g. Extra Cheese. Toggle presence
                    // For extras, we can simulate by toggling whether it's applied
                    currentList[index] = existing.copy(isRemoved = !existing.isRemoved)
                }
            }
            _currentModifiers.value = currentList
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun toggleTurboMode() {
        _turboMode.value = !_turboMode.value
    }

    // --- Database Operations ---

    // Prepopulate some starting values for address, cards, and orders
    suspend fun prepopulateDemoDataIfNeeded() {
        // Wait for flows to emit
        val currentAddresses = repository.allAddresses.first()
        if (currentAddresses.isEmpty()) {
            val demoAddress = AddressEntity(
                label = "Home",
                houseNumber = "12",
                street = "Example Street",
                city = "London",
                postcode = "SW1A 1AA",
                deliveryInstructions = "Leave at reception."
            )
            val demoWork = AddressEntity(
                label = "Work",
                houseNumber = "30",
                street = "St Mary Axe (The Gherkin)",
                city = "London",
                postcode = "EC3A 8EP",
                deliveryInstructions = "Call when outside."
            )
            repository.insertAddress(demoAddress)
            repository.insertAddress(demoWork)
            _selectedAddress.value = demoAddress
        } else {
            _selectedAddress.value = currentAddresses.firstOrNull()
        }

        val currentCards = repository.allCards.first()
        if (currentCards.isEmpty()) {
            val demoCard = CardEntity(
                cardholderName = "John Doe",
                cardNumber = "4242 4242 4242 1882",
                expiryDate = "12/28",
                cvv = "123",
                cardType = "Visa"
            )
            repository.insertCard(demoCard)
            _selectedCard.value = demoCard
        } else {
            _selectedCard.value = currentCards.firstOrNull()
        }
    }

    // --- Cart Actions ---
    fun addToCart(menuItem: MenuItem, modifiers: List<AppliedModifier>, quantity: Int) {
        viewModelScope.launch {
            // Compute extra price from active modifiers (that are extras, not removed)
            var modifierPrice = 0
            modifiers.forEach { mod ->
                if (!mod.name.startsWith("Remove") && mod.selectedChoice == null && mod.isRemoved) {
                    // This is an extra (e.g. Extra Cheese is checked/enabled)
                    modifierPrice += mod.priceMinor
                }
            }

            val finalItemPrice = menuItem.priceMinor + modifierPrice
            val cartItem = CartItemEntity(
                menuItemId = menuItem.id,
                name = menuItem.name,
                priceMinor = finalItemPrice,
                quantity = quantity,
                customizationsJson = JsonUtils.toJsonModifiers(modifiers),
                imageResourceUrl = menuItem.imageUrl
            )
            repository.insertCartItem(cartItem)
            navigateBack()
        }
    }

    fun updateCartItemQuantity(cartItem: CartItemEntity, newQuantity: Int) {
        viewModelScope.launch {
            if (newQuantity <= 0) {
                repository.deleteCartItem(cartItem)
            } else {
                repository.updateCartItem(cartItem.copy(quantity = newQuantity))
            }
        }
    }

    fun removeCartItem(cartItem: CartItemEntity) {
        viewModelScope.launch {
            repository.deleteCartItem(cartItem)
        }
    }

    // --- Checkout & Ordering ---
    fun checkoutAndPlaceOrder() {
        val address = selectedAddress.value ?: return
        val card = selectedCard.value ?: return
        val items = cartItems.value
        if (items.isEmpty()) return

        viewModelScope.launch {
            val sub = cartSubtotal.value
            val del = deliveryFee.value
            val ser = serviceFee.value
            val tot = cartTotal.value

            val orderId = "MD-${(20000..29999).random()}"
            val trackingNo = "TRK-${(100000..999999).random()}"

            val order = OrderEntity(
                id = orderId,
                trackingNumber = trackingNo,
                status = "CREATED",
                timestamp = System.currentTimeMillis(),
                subtotalMinor = sub,
                deliveryFeeMinor = del,
                serviceFeeMinor = ser,
                totalMinor = tot,
                addressJson = JsonUtils.toJson(address),
                itemsJson = JsonUtils.toJsonCartItems(items),
                courierName = "Courier Dan",
                courierPhone = "+44 7700 900077",
                courierLat = DeliverySimulator.RESTAURANT_LAT,
                courierLng = DeliverySimulator.RESTAURANT_LNG,
                restaurantId = selectedRestaurant.value.id,
                restaurantName = selectedRestaurant.value.name,
                etaMinutes = selectedRestaurant.value.minDeliveryTime,
                elapsedSimulatedSeconds = 0
            )

            // Insert into Database
            repository.insertOrder(order)
            _activeOrder.value = order

            // Clear Cart
            repository.clearCart()

            // Navigate to tracking
            _currentScreen.value = Screen.LIVE_ORDER
            _backstack.value = listOf(Screen.HOME, Screen.LIVE_ORDER)
        }
    }

    fun selectActiveOrder(order: OrderEntity) {
        _activeOrder.value = order
        navigateTo(Screen.LIVE_ORDER)
    }

    fun reorder(order: OrderEntity) {
        viewModelScope.launch {
            val items = JsonUtils.fromJsonCartItems(order.itemsJson)
            repository.clearCart()
            items.forEach { item ->
                repository.insertCartItem(
                    CartItemEntity(
                        menuItemId = item.menuItemId,
                        name = item.name,
                        priceMinor = item.priceMinor,
                        quantity = item.quantity,
                        customizationsJson = item.customizationsJson,
                        imageResourceUrl = item.imageResourceUrl
                    )
                )
            }
            _currentScreen.value = Screen.BASKET
            _backstack.value = listOf(Screen.HOME, Screen.BASKET)
        }
    }

    // --- Saved Addresses Actions ---
    fun saveAddress(label: String, house: String, street: String, city: String, postcode: String, instructions: String) {
        viewModelScope.launch {
            val newAddr = AddressEntity(
                label = label,
                houseNumber = house,
                street = street,
                city = city,
                postcode = postcode,
                deliveryInstructions = instructions
            )
            repository.insertAddress(newAddr)
            _selectedAddress.value = newAddr
            navigateBack()
        }
    }

    fun selectAddress(address: AddressEntity) {
        _selectedAddress.value = address
    }

    fun deleteAddress(address: AddressEntity) {
        viewModelScope.launch {
            repository.deleteAddress(address)
            if (_selectedAddress.value?.id == address.id) {
                _selectedAddress.value = repository.allAddresses.first().firstOrNull()
            }
        }
    }

    // --- Saved Payment Cards Actions ---
    fun saveCard(holderName: String, num: String, expiry: String, cvv: String) {
        viewModelScope.launch {
            val masked = if (num.length >= 4) {
                "**** **** **** ${num.takeLast(4)}"
            } else {
                "**** **** **** $num"
            }
            val newCard = CardEntity(
                cardholderName = holderName,
                cardNumber = masked,
                expiryDate = expiry,
                cvv = cvv,
                cardType = if (num.startsWith("4")) "Visa" else "Mastercard"
            )
            repository.insertCard(newCard)
            _selectedCard.value = newCard
            navigateBack()
        }
    }

    fun selectCard(card: CardEntity) {
        _selectedCard.value = card
    }

    fun deleteCard(card: CardEntity) {
        viewModelScope.launch {
            repository.deleteCard(card)
            if (_selectedCard.value?.id == card.id) {
                _selectedCard.value = repository.allCards.first().firstOrNull()
            }
        }
    }

    // --- Customer Support Actions ---
    fun submitSupportCase(orderId: String, category: String, description: String) {
        viewModelScope.launch {
            val caseId = "CASE-${(1000..9999).random()}"
            val newCase = SupportCaseEntity(
                id = caseId,
                orderId = orderId,
                category = category,
                description = description,
                status = "OPEN",
                createdAt = System.currentTimeMillis(),
                resolution = "Fictional case submitted. A customer representative will contact you shortly."
            )
            repository.insertSupportCase(newCase)
            navigateBack()
        }
    }

    // --- Restaurant Operations Simulated Actions ---
    fun updateOrderStatusManually(orderId: String, nextStatus: String) {
        viewModelScope.launch {
            val currentOrder = repository.getOrder(orderId)
            if (currentOrder != null) {
                val updated = currentOrder.copy(status = nextStatus)
                repository.updateOrder(updated)
                if (_activeOrder.value?.id == orderId) {
                    _activeOrder.value = updated
                }
            }
        }
    }

    // --- Simulator Ticker ---
    private fun startSimulationTicker() {
        viewModelScope.launch {
            while (true) {
                delay(1000) // tick every real-world second
                val currentActive = _activeOrder.value
                if (currentActive != null && currentActive.status != "DELIVERED") {
                    val simulatedSecondsStep = if (_turboMode.value) 30 else 5
                    val updated = DeliverySimulator.tickOrder(currentActive, simulatedSecondsStep)
                    repository.updateOrder(updated)
                    _activeOrder.value = updated
                }
            }
        }
    }

    // --- Analytics Metrics (Computed dynamically) ---
    val analyticsStats: StateFlow<Map<String, String>> = orders.map { list ->
        val totalCount = list.size
        val avgTotalMinor = if (totalCount > 0) list.sumOf { it.totalMinor } / totalCount else 0
        val successCount = list.count { it.status == "DELIVERED" }
        val cancelCount = list.count { it.status.endsWith("CANCELLED") || it.status.endsWith("REJECTED") }

        mapOf(
            "Total Orders" to "$totalCount",
            "Avg Basket Value" to "£${String.format("%.2f", avgTotalMinor / 100.0)}",
            "Delivery Success Rate" to if (totalCount > 0) "${(successCount * 100) / totalCount}%" else "100%",
            "Cancellation Rate" to if (totalCount > 0) "${(cancelCount * 100) / totalCount}%" else "0%",
            "Avg Prep Time" to "6.2 min (Simulated)",
            "Active Couriers" to "12"
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())
}

enum class Screen {
    HOME,
    MENU,
    PRODUCT_DETAIL,
    BASKET,
    ADDRESSES,
    PAYMENTS,
    CHECKOUT,
    LIVE_ORDER,
    ORDER_HISTORY,
    SUPPORT,
    OFFERS,
    ACCOUNT,
    RESTAURANT_OPS
}
