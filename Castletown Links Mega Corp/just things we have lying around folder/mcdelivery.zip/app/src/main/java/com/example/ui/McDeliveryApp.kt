package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.*
import com.example.ui.components.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun McDeliveryApp(
    viewModel: McDeliveryViewModel,
    modifier: Modifier = Modifier
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val cartItems by viewModel.cartItems.collectAsState()
    val cartSubtotal by viewModel.cartSubtotal.collectAsState()

    // Handle back press
    BackHandler(enabled = currentScreen != Screen.HOME) {
        viewModel.navigateBack()
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .background(McD_Yellow, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "M",
                                color = McD_Red,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 20.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "McDelivery",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp,
                            color = McD_Red,
                            letterSpacing = (-0.5).sp
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = McD_White
                )
            )
        },
        bottomBar = {
            Column {
                // Persistent Basket Bar overlay
                if (cartItems.isNotEmpty() && currentScreen != Screen.BASKET && currentScreen != Screen.CHECKOUT && currentScreen != Screen.LIVE_ORDER) {
                    BasketBar(
                        itemCount = cartItems.sumOf { it.quantity },
                        totalMinor = cartSubtotal,
                        onClick = { viewModel.navigateTo(Screen.BASKET) }
                    )
                }

                // Bottom Navigation
                NavigationBar(
                    containerColor = McD_White,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = currentScreen == Screen.HOME,
                        onClick = { viewModel.navigateTo(Screen.HOME) },
                        icon = { Icon(if (currentScreen == Screen.HOME) Icons.Filled.Home else Icons.Outlined.Home, null) },
                        label = { Text("HOME", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = McD_Red,
                            selectedTextColor = McD_Red,
                            indicatorColor = McD_Yellow.copy(alpha = 0.4f),
                            unselectedIconColor = McD_DarkGrey,
                            unselectedTextColor = McD_DarkGrey
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.MENU || currentScreen == Screen.PRODUCT_DETAIL,
                        onClick = { viewModel.navigateTo(Screen.MENU) },
                        icon = { Icon(if (currentScreen == Screen.MENU) Icons.Filled.RestaurantMenu else Icons.Outlined.RestaurantMenu, null) },
                        label = { Text("MENU", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = McD_Red,
                            selectedTextColor = McD_Red,
                            indicatorColor = McD_Yellow.copy(alpha = 0.4f),
                            unselectedIconColor = McD_DarkGrey,
                            unselectedTextColor = McD_DarkGrey
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.OFFERS,
                        onClick = { viewModel.navigateTo(Screen.OFFERS) },
                        icon = { Icon(if (currentScreen == Screen.OFFERS) Icons.Filled.LocalOffer else Icons.Outlined.LocalOffer, null) },
                        label = { Text("OFFERS", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = McD_Red,
                            selectedTextColor = McD_Red,
                            indicatorColor = McD_Yellow.copy(alpha = 0.4f),
                            unselectedIconColor = McD_DarkGrey,
                            unselectedTextColor = McD_DarkGrey
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.ORDER_HISTORY || currentScreen == Screen.LIVE_ORDER,
                        onClick = { viewModel.navigateTo(Screen.ORDER_HISTORY) },
                        icon = { Icon(if (currentScreen == Screen.ORDER_HISTORY) Icons.Filled.History else Icons.Outlined.History, null) },
                        label = { Text("ORDERS", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = McD_Red,
                            selectedTextColor = McD_Red,
                            indicatorColor = McD_Yellow.copy(alpha = 0.4f),
                            unselectedIconColor = McD_DarkGrey,
                            unselectedTextColor = McD_DarkGrey
                        )
                    )
                    NavigationBarItem(
                        selected = currentScreen == Screen.ACCOUNT || currentScreen == Screen.ADDRESSES || currentScreen == Screen.PAYMENTS || currentScreen == Screen.SUPPORT,
                        onClick = { viewModel.navigateTo(Screen.ACCOUNT) },
                        icon = { Icon(if (currentScreen == Screen.ACCOUNT) Icons.Filled.Person else Icons.Outlined.Person, null) },
                        label = { Text("ACCOUNT", fontSize = 10.sp, fontWeight = FontWeight.Bold) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = McD_Red,
                            selectedTextColor = McD_Red,
                            indicatorColor = McD_Yellow.copy(alpha = 0.4f),
                            unselectedIconColor = McD_DarkGrey,
                            unselectedTextColor = McD_DarkGrey
                        )
                    )
                }
            }
        },
        modifier = modifier.fillMaxSize(),
        containerColor = McD_WarmBg
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                Screen.HOME -> HomeScreen(viewModel)
                Screen.MENU -> MenuScreen(viewModel)
                Screen.PRODUCT_DETAIL -> ProductDetailScreen(viewModel)
                Screen.BASKET -> BasketScreen(viewModel)
                Screen.ADDRESSES -> AddressesScreen(viewModel)
                Screen.PAYMENTS -> PaymentsScreen(viewModel)
                Screen.CHECKOUT -> CheckoutScreen(viewModel)
                Screen.LIVE_ORDER -> LiveOrderScreen(viewModel)
                Screen.ORDER_HISTORY -> OrderHistoryScreen(viewModel)
                Screen.SUPPORT -> SupportScreen(viewModel)
                Screen.OFFERS -> OffersScreen(viewModel)
                Screen.ACCOUNT -> AccountScreen(viewModel)
                Screen.RESTAURANT_OPS -> RestaurantOpsScreen(viewModel)
            }
        }
    }
}

// ==========================================
// 1. HOME SCREEN
// ==========================================
@Composable
fun HomeScreen(viewModel: McDeliveryViewModel) {
    val selectedAddress by viewModel.selectedAddress.collectAsState()
    val nearestRestaurant by viewModel.selectedRestaurant.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(SpacingMedium)
    ) {
        // Location Selector Card
        Card(
            colors = CardDefaults.cardColors(containerColor = McD_White),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.navigateTo(Screen.ADDRESSES) }
        ) {
            Row(
                modifier = Modifier.padding(SpacingMedium),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.DirectionsBike,
                    contentDescription = null,
                    tint = McD_Red,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(SpacingMedium))
                Column {
                    Text(
                        "Delivering to",
                        fontSize = 12.sp,
                        color = McD_DarkGrey,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        selectedAddress?.let { "${it.houseNumber} ${it.street}, ${it.city}" } ?: "Set delivery address",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = McD_Charcoal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Change",
                    tint = McD_Red
                )
            }
        }

        Spacer(modifier = Modifier.height(SpacingLarge))

        // Hero Banner Card
        Card(
            shape = RoundedCornerShape(CardCornerRadius),
            colors = CardDefaults.cardColors(containerColor = McD_Red),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(modifier = Modifier.fillMaxWidth()) {
                // Background artistic accents
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        color = McD_Yellow.copy(alpha = 0.15f),
                        radius = 200f,
                        center = Offset(size.width * 0.8f, size.height * 0.2f)
                    )
                }

                Row(
                    modifier = Modifier.padding(SpacingMedium),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text(
                            "WHAT ARE YOU CRAVING?",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = McD_White,
                            lineHeight = 24.sp
                        )
                        Spacer(modifier = Modifier.height(SpacingSmall))
                        Text(
                            "Get your favorite McDonald's meals delivered fresh & fast to your door.",
                            fontSize = 12.sp,
                            color = McD_White.copy(alpha = 0.9f)
                        )
                        Spacer(modifier = Modifier.height(SpacingMedium))
                        Button(
                            onClick = { viewModel.navigateTo(Screen.MENU) },
                            colors = ButtonDefaults.buttonColors(containerColor = McD_Yellow),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("ORDER NOW", color = McD_Charcoal, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(0.8f)
                            .height(130.dp)
                    ) {
                        AsyncImage(
                            model = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&q=80",
                            contentDescription = "Burgers Banner",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(RoundedCornerShape(12.dp))
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(SpacingLarge))

        // Food Categories Shortcuts Slider
        Text(
            "Categories",
            fontSize = 16.sp,
            fontWeight = FontWeight.ExtraBold,
            color = McD_Charcoal,
            modifier = Modifier.padding(bottom = SpacingMedium)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
        ) {
            MenuData.categories.forEach { category ->
                val isSelected = false
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = McD_White),
                    border = BorderStroke(1.dp, McD_LightGrey),
                    modifier = Modifier
                        .padding(end = SpacingSmall)
                        .clickable {
                            viewModel.selectCategory(category)
                            viewModel.navigateTo(Screen.MENU)
                        }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(McD_Yellow.copy(alpha = 0.2f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = when (category) {
                                    "Burgers" -> Icons.Default.Restaurant
                                    "Chicken" -> Icons.Default.RestaurantMenu
                                    "Sides" -> Icons.Default.LocalPizza
                                    "Drinks" -> Icons.Default.LocalDrink
                                    "Desserts" -> Icons.Default.Cake
                                    else -> Icons.Default.Redeem
                                },
                                contentDescription = null,
                                tint = McD_Red,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(SpacingSmall))
                        Text(
                            text = category,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = McD_Charcoal
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(SpacingLarge))

        // Fictional Store Status Header
        Text(
            "Fictional Demonstration Store",
            fontSize = 16.sp,
            fontWeight = FontWeight.ExtraBold,
            color = McD_Charcoal,
            modifier = Modifier.padding(bottom = SpacingMedium)
        )

        RestaurantCard(
            restaurant = nearestRestaurant,
            isSelected = true,
            onClick = { viewModel.navigateTo(Screen.MENU) }
        )

        Spacer(modifier = Modifier.height(SpacingMedium))

        // Quick Promo Banner
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = McD_Yellow.copy(alpha = 0.15f)),
            border = BorderStroke(1.dp, McD_Yellow.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(SpacingMedium),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = McD_Gold,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(SpacingMedium))
                Column {
                    Text(
                        "FREE DELIVERY ON ORDERS OVER £15",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = McD_Charcoal
                    )
                    Text(
                        "Add items to your basket and delivery fee is automatically cleared.",
                        fontSize = 10.sp,
                        color = McD_DarkGrey
                    )
                }
            }
        }
    }
}

// ==========================================
// 2. MENU SCREEN
// ==========================================
@Composable
fun MenuScreen(viewModel: McDeliveryViewModel) {
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    val filteredItems = remember(selectedCategory, searchQuery) {
        MenuData.menuItems.filter {
            it.category == selectedCategory &&
            (searchQuery.isEmpty() || it.name.contains(searchQuery, ignoreCase = true) || it.description.contains(searchQuery, ignoreCase = true))
        }
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search & Category Headers
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(McD_White)
                .padding(horizontal = SpacingMedium, vertical = SpacingSmall)
        ) {
            // Search Input
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text("Search for burgers, nuggets, fries...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, null, tint = McD_DarkGrey) },
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = McD_Red,
                    unfocusedBorderColor = McD_LightGrey,
                    focusedContainerColor = McD_WarmBg,
                    unfocusedContainerColor = McD_WarmBg
                ),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("search_field")
            )

            Spacer(modifier = Modifier.height(SpacingSmall))

            // Categories horizontal bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(vertical = 4.dp)
            ) {
                MenuData.categories.forEach { category ->
                    val isSelected = category == selectedCategory
                    Box(
                        modifier = Modifier
                            .padding(end = SpacingSmall)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (isSelected) McD_Red else McD_LightGrey)
                            .clickable { viewModel.selectCategory(category) }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = category,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) McD_White else McD_Charcoal
                        )
                    }
                }
            }
        }

        // List Grid
        if (filteredItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(SpacingLarge),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = McD_DarkGrey,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(SpacingMedium))
                    Text(
                        "No items found",
                        fontWeight = FontWeight.Bold,
                        color = McD_Charcoal
                    )
                    Text(
                        "Try searching for another product name.",
                        fontSize = 12.sp,
                        color = McD_DarkGrey,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(SpacingMedium),
                horizontalArrangement = Arrangement.spacedBy(SpacingMedium),
                verticalArrangement = Arrangement.spacedBy(SpacingMedium),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredItems) { item ->
                    FoodCard(
                        menuItem = item,
                        onClick = { viewModel.selectProduct(item) }
                    )
                }
            }
        }
    }
}

// ==========================================
// 3. PRODUCT DETAIL SCREEN
// ==========================================
@Composable
fun ProductDetailScreen(viewModel: McDeliveryViewModel) {
    val item by viewModel.selectedProduct.collectAsState()
    val modifiers by viewModel.currentModifiers.collectAsState()

    var quantity by remember { mutableStateOf(1) }

    item?.let { menuItem ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
        ) {
            // Hero Image
            AsyncImage(
                model = menuItem.imageUrl,
                contentDescription = menuItem.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
            )

            Column(modifier = Modifier.padding(SpacingMedium)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = menuItem.name,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = McD_Charcoal,
                        modifier = Modifier.weight(1f)
                    )

                    Text(
                        text = "£${String.format("%.2f", menuItem.priceMinor / 100.0)}",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = McD_Red
                    )
                }

                Spacer(modifier = Modifier.height(SpacingSmall))

                // Energy & Description
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(McD_Yellow.copy(alpha = 0.2f), RoundedCornerShape(6.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text("${menuItem.energyKcal} kcal", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                    }
                }

                Spacer(modifier = Modifier.height(SpacingMedium))

                Text(
                    text = menuItem.description,
                    fontSize = 13.sp,
                    color = McD_DarkGrey,
                    lineHeight = 18.sp
                )

                // Ingredients & Allergens
                if (menuItem.ingredients.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(SpacingMedium))
                    Text("Ingredients:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                    Text(menuItem.ingredients.joinToString(", "), fontSize = 12.sp, color = McD_DarkGrey)
                }

                if (menuItem.allergens.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(SpacingSmall))
                    Text("Contains Allergens:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                    Text(menuItem.allergens.joinToString(", "), fontSize = 12.sp, color = McD_Red)
                }

                Divider(modifier = Modifier.padding(vertical = SpacingMedium), color = McD_LightGrey)

                // Customizations Block
                if (menuItem.customizerOptions.isNotEmpty()) {
                    Text(
                        text = "Customize Your Order",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = McD_Charcoal,
                        modifier = Modifier.padding(bottom = SpacingSmall)
                    )

                    menuItem.customizerOptions.forEach { option ->
                        val mod = modifiers.find { it.name == option.name }
                        val isChecked = mod != null && !mod.isRemoved

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(option.name, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = McD_Charcoal)
                                if (option.priceMinor > 0) {
                                    Text("+£${String.format("%.2f", option.priceMinor / 100.0)}", fontSize = 11.sp, color = McD_Red, fontWeight = FontWeight.Bold)
                                }
                            }

                            if (option.isSelectionGroup) {
                                // Dropdown or radio choice selector
                                var expanded by remember { mutableStateOf(false) }
                                Box {
                                    Button(
                                        onClick = { expanded = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = McD_LightGrey),
                                        shape = RoundedCornerShape(8.dp),
                                        modifier = Modifier.height(36.dp)
                                    ) {
                                        Text(mod?.selectedChoice ?: option.selectionGroupItems.first(), fontSize = 11.sp, color = McD_Charcoal)
                                    }
                                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                                        option.selectionGroupItems.forEach { itemChoice ->
                                            DropdownMenuItem(
                                                text = { Text(itemChoice, fontSize = 12.sp) },
                                                onClick = {
                                                    viewModel.toggleModifier(option.name, true, itemChoice)
                                                    expanded = false
                                                }
                                            )
                                        }
                                    }
                                }
                            } else {
                                // Simple switch toggle
                                Switch(
                                    checked = isChecked,
                                    onCheckedChange = { viewModel.toggleModifier(option.name, false) },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = McD_White,
                                        checkedTrackColor = McD_Red,
                                        uncheckedThumbColor = McD_DarkGrey,
                                        uncheckedTrackColor = McD_LightGrey
                                    )
                                )
                            }
                        }
                    }
                    Divider(modifier = Modifier.padding(vertical = SpacingMedium), color = McD_LightGrey)
                }

                // Quantity Selector Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Select Quantity", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { if (quantity > 1) quantity-- },
                            modifier = Modifier
                                .border(1.dp, McD_LightGrey, CircleShape)
                                .size(36.dp)
                        ) {
                            Icon(Icons.Default.Remove, null, tint = McD_Charcoal)
                        }

                        Text(
                            "$quantity",
                            modifier = Modifier.padding(horizontal = SpacingMedium),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )

                        IconButton(
                            onClick = { quantity++ },
                            modifier = Modifier
                                .border(1.dp, McD_LightGrey, CircleShape)
                                .size(36.dp)
                        ) {
                            Icon(Icons.Default.Add, null, tint = McD_Charcoal)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(SpacingLarge))

                // Total Summary and Add to order button
                McDPrimaryButton(
                    text = "ADD TO BASKET",
                    onClick = { viewModel.addToCart(menuItem, modifiers, quantity) },
                    testTag = "add_to_cart_btn"
                )
            }
        }
    }
}

// ==========================================
// 4. BASKET SCREEN
// ==========================================
@Composable
fun BasketScreen(viewModel: McDeliveryViewModel) {
    val items by viewModel.cartItems.collectAsState()
    val subtotal by viewModel.cartSubtotal.collectAsState()
    val deliveryFee by viewModel.deliveryFee.collectAsState()
    val serviceFee by viewModel.serviceFee.collectAsState()
    val total by viewModel.cartTotal.collectAsState()

    if (items.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(SpacingLarge),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.ShoppingBag,
                    tint = McD_Red,
                    contentDescription = null,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(SpacingMedium))
                Text("Your basket is empty", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = McD_Charcoal)
                Text("Browse the menu to add delicious meals!", fontSize = 13.sp, color = McD_DarkGrey)
                Spacer(modifier = Modifier.height(SpacingLarge))
                McDPrimaryButton(text = "BROWSE MENU", onClick = { viewModel.navigateTo(Screen.MENU) })
            }
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(SpacingMedium)
        ) {
            Text(
                "YOUR ORDER",
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = McD_Charcoal,
                modifier = Modifier.padding(bottom = SpacingMedium)
            )

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(SpacingMedium)
            ) {
                items(items) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = McD_White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(SpacingMedium),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AsyncImage(
                                model = item.imageResourceUrl,
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(50.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )

                            Spacer(modifier = Modifier.width(SpacingMedium))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                                // Extract and show customizations if any
                                val mods = JsonUtils.fromJsonModifiers(item.customizationsJson)
                                    .filter { !it.name.startsWith("Remove") && it.selectedChoice == null && it.isRemoved }
                                    .map { it.name }
                                if (mods.isNotEmpty()) {
                                    Text("Added: ${mods.joinToString(", ")}", fontSize = 11.sp, color = McD_Red)
                                }
                                Text("£${String.format("%.2f", item.priceMinor / 100.0)}", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = McD_Red)
                            }

                            // Quantity selectors
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { viewModel.updateCartItemQuantity(item, item.quantity - 1) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.RemoveCircleOutline, "Minus", tint = McD_Red)
                                }
                                Text(
                                    "${item.quantity}",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = SpacingSmall)
                                )
                                IconButton(
                                    onClick = { viewModel.updateCartItemQuantity(item, item.quantity + 1) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.AddCircleOutline, "Plus", tint = McD_Red)
                                }
                            }
                        }
                    }
                }
            }

            // Pricing Summary Card
            Card(
                colors = CardDefaults.cardColors(containerColor = McD_White),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = SpacingMedium)
            ) {
                Column(modifier = Modifier.padding(SpacingMedium)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Subtotal", fontSize = 13.sp, color = McD_DarkGrey)
                        Text("£${String.format("%.2f", subtotal / 100.0)}", fontSize = 13.sp, color = McD_Charcoal, fontWeight = FontWeight.Medium)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Delivery Fee", fontSize = 13.sp, color = McD_DarkGrey)
                        Text(
                            text = if (deliveryFee == 0) "FREE" else "£${String.format("%.2f", deliveryFee / 100.0)}",
                            fontSize = 13.sp,
                            color = if (deliveryFee == 0) McD_Green else McD_Charcoal,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Service Fee", fontSize = 13.sp, color = McD_DarkGrey)
                        Text("£${String.format("%.2f", serviceFee / 100.0)}", fontSize = 13.sp, color = McD_Charcoal, fontWeight = FontWeight.Medium)
                    }
                    Divider(modifier = Modifier.padding(vertical = SpacingSmall), color = McD_LightGrey)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("TOTAL", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
                        Text("£${String.format("%.2f", total / 100.0)}", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = McD_Red)
                    }
                }
            }

            McDPrimaryButton(
                text = "CONTINUE TO CHECKOUT",
                onClick = { viewModel.navigateTo(Screen.CHECKOUT) },
                testTag = "checkout_btn"
            )
        }
    }
}

// ==========================================
// 5. ADDRESSES SCREEN
// ==========================================
@Composable
fun AddressesScreen(viewModel: McDeliveryViewModel) {
    val addressList by viewModel.addresses.collectAsState()
    val selected by viewModel.selectedAddress.collectAsState()

    var showForm by remember { mutableStateOf(false) }

    var label by remember { mutableStateOf("Home") }
    var houseNumber by remember { mutableStateOf("") }
    var street by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("") }
    var postcode by remember { mutableStateOf("") }
    var instructions by remember { mutableStateOf("") }

    if (showForm) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(SpacingMedium)
        ) {
            Text("ADD NEW ADDRESS", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
            Spacer(modifier = Modifier.height(SpacingMedium))

            // Label picker
            Row(modifier = Modifier.fillMaxWidth()) {
                listOf("Home", "Work", "Other").forEach { choice ->
                    val active = label == choice
                    Box(
                        modifier = Modifier
                            .padding(end = SpacingSmall)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (active) McD_Red else McD_LightGrey)
                            .clickable { label = choice }
                            .padding(horizontal = 14.dp, vertical = 8.dp)
                    ) {
                        Text(choice, fontSize = 12.sp, color = if (active) McD_White else McD_Charcoal, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(SpacingMedium))

            OutlinedTextField(
                value = houseNumber,
                onValueChange = { houseNumber = it },
                label = { Text("House/Flat Number") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(SpacingSmall))
            OutlinedTextField(
                value = street,
                onValueChange = { street = it },
                label = { Text("Street") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(SpacingSmall))
            OutlinedTextField(
                value = city,
                onValueChange = { city = it },
                label = { Text("City") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(SpacingSmall))
            OutlinedTextField(
                value = postcode,
                onValueChange = { postcode = it },
                label = { Text("Postcode") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(SpacingSmall))
            OutlinedTextField(
                value = instructions,
                onValueChange = { instructions = it },
                label = { Text("Delivery Instructions (Optional)") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(SpacingLarge))

            McDPrimaryButton(
                text = "SAVE ADDRESS",
                onClick = {
                    if (houseNumber.isNotEmpty() && street.isNotEmpty() && city.isNotEmpty() && postcode.isNotEmpty()) {
                        viewModel.saveAddress(label, houseNumber, street, city, postcode, instructions)
                        showForm = false
                    }
                }
            )
            Spacer(modifier = Modifier.height(SpacingSmall))
            McDSecondaryButton(text = "CANCEL", onClick = { showForm = false })
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(SpacingMedium)
        ) {
            Text("SAVED ADDRESSES", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
            Spacer(modifier = Modifier.height(SpacingMedium))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(SpacingMedium)
            ) {
                items(addressList) { addr ->
                    AddressCard(
                        address = addr,
                        isSelected = selected?.id == addr.id,
                        onSelect = { viewModel.selectAddress(addr) },
                        onDelete = { viewModel.deleteAddress(addr) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(SpacingMedium))

            McDPrimaryButton(text = "ADD NEW ADDRESS", onClick = { showForm = true })
        }
    }
}

// ==========================================
// 6. PAYMENTS SCREEN
// ==========================================
@Composable
fun PaymentsScreen(viewModel: McDeliveryViewModel) {
    val cardsList by viewModel.cards.collectAsState()
    val selected by viewModel.selectedCard.collectAsState()

    var showForm by remember { mutableStateOf(false) }

    var holderName by remember { mutableStateOf("") }
    var cardNumber by remember { mutableStateOf("") }
    var expiry by remember { mutableStateOf("") }
    var cvv by remember { mutableStateOf("") }

    if (showForm) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(SpacingMedium)
        ) {
            Text("ADD NEW CARD", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
            Spacer(modifier = Modifier.height(SpacingMedium))

            OutlinedTextField(
                value = holderName,
                onValueChange = { holderName = it },
                label = { Text("Cardholder Name") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(SpacingSmall))
            OutlinedTextField(
                value = cardNumber,
                onValueChange = { cardNumber = it },
                label = { Text("Card Number") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(SpacingSmall))
            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = expiry,
                    onValueChange = { expiry = it },
                    label = { Text("Expiry (MM/YY)") },
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(SpacingSmall))
                OutlinedTextField(
                    value = cvv,
                    onValueChange = { cvv = it },
                    label = { Text("CVV") },
                    modifier = Modifier.weight(1f)
                )
            }

            Spacer(modifier = Modifier.height(SpacingLarge))

            McDPrimaryButton(
                text = "SAVE CARD",
                onClick = {
                    if (holderName.isNotEmpty() && cardNumber.isNotEmpty() && expiry.isNotEmpty() && cvv.isNotEmpty()) {
                        viewModel.saveCard(holderName, cardNumber, expiry, cvv)
                        showForm = false
                    }
                }
            )
            Spacer(modifier = Modifier.height(SpacingSmall))
            McDSecondaryButton(text = "CANCEL", onClick = { showForm = false })
        }
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(SpacingMedium)
        ) {
            Text("SAVED PAYMENT METHODS", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
            Spacer(modifier = Modifier.height(SpacingMedium))

            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(SpacingMedium)
            ) {
                items(cardsList) { card ->
                    CardRow(
                        card = card,
                        isSelected = selected?.id == card.id,
                        onSelect = { viewModel.selectCard(card) },
                        onDelete = { viewModel.deleteCard(card) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(SpacingMedium))

            McDPrimaryButton(text = "ADD NEW CARD", onClick = { showForm = true })
        }
    }
}

// ==========================================
// 7. CHECKOUT SCREEN
// ==========================================
@Composable
fun CheckoutScreen(viewModel: McDeliveryViewModel) {
    val selectedAddress by viewModel.selectedAddress.collectAsState()
    val selectedCard by viewModel.selectedCard.collectAsState()
    val restaurant by viewModel.selectedRestaurant.collectAsState()
    val items by viewModel.cartItems.collectAsState()
    val total by viewModel.cartTotal.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(SpacingMedium)
    ) {
        Text("CHECKOUT", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
        Spacer(modifier = Modifier.height(SpacingMedium))

        // Address section
        Text("DELIVERY ADDRESS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = McD_Red)
        Spacer(modifier = Modifier.height(4.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = McD_White),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.navigateTo(Screen.ADDRESSES) }
        ) {
            Row(modifier = Modifier.padding(SpacingMedium), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Place, null, tint = McD_Charcoal)
                Spacer(modifier = Modifier.width(SpacingMedium))
                Column(modifier = Modifier.weight(1f)) {
                    selectedAddress?.let {
                        Text(it.label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                        Text("${it.houseNumber} ${it.street}, ${it.city}", fontSize = 12.sp, color = McD_DarkGrey)
                    } ?: Text("Select an address", color = McD_Red, fontWeight = FontWeight.Bold)
                }
                Icon(Icons.Default.ChevronRight, null, tint = McD_Red)
            }
        }

        Spacer(modifier = Modifier.height(SpacingMedium))

        // Restaurant Section
        Text("RESTAURANT", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = McD_Red)
        Spacer(modifier = Modifier.height(4.dp))
        Card(colors = CardDefaults.cardColors(containerColor = McD_White), modifier = Modifier.fillMaxWidth()) {
            Row(modifier = Modifier.padding(SpacingMedium), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Restaurant, null, tint = McD_Charcoal)
                Spacer(modifier = Modifier.width(SpacingMedium))
                Column {
                    Text(restaurant.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                    Text(restaurant.description, fontSize = 11.sp, color = McD_DarkGrey)
                }
            }
        }

        Spacer(modifier = Modifier.height(SpacingMedium))

        // Payment section
        Text("PAYMENT METHOD", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = McD_Red)
        Spacer(modifier = Modifier.height(4.dp))
        Card(
            colors = CardDefaults.cardColors(containerColor = McD_White),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.navigateTo(Screen.PAYMENTS) }
        ) {
            Row(modifier = Modifier.padding(SpacingMedium), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Payment, null, tint = McD_Charcoal)
                Spacer(modifier = Modifier.width(SpacingMedium))
                Column(modifier = Modifier.weight(1f)) {
                    selectedCard?.let {
                        Text(it.cardNumber, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                        Text(it.cardholderName, fontSize = 12.sp, color = McD_DarkGrey)
                    } ?: Text("Select a payment method", color = McD_Red, fontWeight = FontWeight.Bold)
                }
                Icon(Icons.Default.ChevronRight, null, tint = McD_Red)
            }
        }

        Spacer(modifier = Modifier.height(SpacingMedium))

        // Order Summary
        Text("ORDER SUMMARY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = McD_Red)
        Spacer(modifier = Modifier.height(4.dp))
        Card(colors = CardDefaults.cardColors(containerColor = McD_White), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(SpacingMedium)) {
                items.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("${item.quantity} x ${item.name}", fontSize = 12.sp, color = McD_Charcoal, fontWeight = FontWeight.Medium)
                        Text("£${String.format("%.2f", (item.priceMinor * item.quantity) / 100.0)}", fontSize = 12.sp, color = McD_Charcoal)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(SpacingLarge))

        // Checkout Button
        McDPrimaryButton(
            text = "PLACE ORDER — £${String.format("%.2f", total / 100.0)}",
            onClick = { viewModel.checkoutAndPlaceOrder() },
            enabled = selectedAddress != null && selectedCard != null && items.isNotEmpty(),
            testTag = "place_order_btn"
        )
    }
}

// ==========================================
// 8. LIVE ORDER TRACKING SCREEN
// ==========================================
@Composable
fun LiveOrderScreen(viewModel: McDeliveryViewModel) {
    val order by viewModel.activeOrder.collectAsState()
    val turboMode by viewModel.turboMode.collectAsState()

    order?.let { activeOrder ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(SpacingMedium)
        ) {
            Text("ORDER CONFIRMED", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = McD_Red)
            Text("Your food is being prepared.", fontSize = 14.sp, fontWeight = FontWeight.Medium, color = McD_Charcoal)

            Spacer(modifier = Modifier.height(SpacingMedium))

            // ETA and Tracking Card
            Card(
                colors = CardDefaults.cardColors(containerColor = McD_White),
                shape = RoundedCornerShape(CardCornerRadius),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(SpacingMedium)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Estimated arrival", fontSize = 11.sp, color = McD_DarkGrey, fontWeight = FontWeight.Bold)
                            Text(
                                if (activeOrder.status == "DELIVERED") "Arrived!" else "${activeOrder.etaMinutes} minutes",
                                fontSize = 22.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = McD_Red
                            )
                        }

                        Box(
                            modifier = Modifier
                                .background(McD_Yellow.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(activeOrder.id, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
                        }
                    }

                    Spacer(modifier = Modifier.height(SpacingMedium))

                    Text(
                        "Courier: ${activeOrder.courierName} • ${activeOrder.courierPhone}",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = McD_Charcoal
                    )
                }
            }

            Spacer(modifier = Modifier.height(SpacingMedium))

            // Map View Canvas
            MapView(courierLat = activeOrder.courierLat, courierLng = activeOrder.courierLng)

            Spacer(modifier = Modifier.height(SpacingMedium))

            // Simulation Controls Card
            Card(
                colors = CardDefaults.cardColors(containerColor = McD_White),
                border = BorderStroke(1.dp, McD_Yellow.copy(alpha = 0.6f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(SpacingMedium),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Logistics Time Warp Mode", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                        Text("1s real-world = 30s simulated. Speeds up the courier delivery path.", fontSize = 11.sp, color = McD_DarkGrey)
                    }
                    Switch(
                        checked = turboMode,
                        onCheckedChange = { viewModel.toggleTurboMode() },
                        colors = SwitchDefaults.colors(checkedTrackColor = McD_Red)
                    )
                }
            }

            Spacer(modifier = Modifier.height(SpacingMedium))

            // Restaurant Operations Shortcut
            McDSecondaryButton(
                text = "OPEN RESTAURANT OPS DESK",
                onClick = { viewModel.navigateTo(Screen.RESTAURANT_OPS) }
            )

            Spacer(modifier = Modifier.height(SpacingMedium))

            // Timeline status
            OrderProgressTimeline(status = activeOrder.status)
        }
    } ?: Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text("No active order currently being tracked.")
    }
}

// ==========================================
// 9. ORDER HISTORY SCREEN
// ==========================================
@Composable
fun OrderHistoryScreen(viewModel: McDeliveryViewModel) {
    val historyList by viewModel.orders.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(SpacingMedium)
    ) {
        Text("YOUR ORDERS", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
        Spacer(modifier = Modifier.height(SpacingMedium))

        if (historyList.isEmpty()) {
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.History, null, tint = McD_DarkGrey, modifier = Modifier.size(48.dp))
                    Spacer(modifier = Modifier.height(SpacingMedium))
                    Text("No order history", fontWeight = FontWeight.Bold, color = McD_Charcoal)
                    Text("Your placed orders will appear here.", fontSize = 12.sp, color = McD_DarkGrey)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(SpacingMedium)
            ) {
                items(historyList) { order ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = McD_White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(SpacingMedium)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(order.restaurantName, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                                    Text("Order ${order.id}", fontSize = 11.sp, color = McD_DarkGrey)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (order.status == "DELIVERED") McD_Green.copy(alpha = 0.15f) else McD_Yellow.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(order.status, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = if (order.status == "DELIVERED") McD_Green else McD_Charcoal)
                                }
                            }

                            Spacer(modifier = Modifier.height(SpacingMedium))

                            // Extract item names
                            val itemsList = JsonUtils.fromJsonCartItems(order.itemsJson)
                            Text(
                                text = itemsList.joinToString(", ") { "${it.quantity} x ${it.name}" },
                                fontSize = 12.sp,
                                color = McD_DarkGrey,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )

                            Spacer(modifier = Modifier.height(SpacingSmall))

                            Text("Total: £${String.format("%.2f", order.totalMinor / 100.0)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = McD_Red)

                            Spacer(modifier = Modifier.height(SpacingMedium))

                            Row {
                                Button(
                                    onClick = { viewModel.reorder(order) },
                                    colors = ButtonDefaults.buttonColors(containerColor = McD_Red),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("ORDER AGAIN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Spacer(modifier = Modifier.width(SpacingSmall))
                                OutlinedButton(
                                    onClick = { viewModel.navigateTo(Screen.SUPPORT) },
                                    border = BorderStroke(1.dp, McD_Red),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("GET HELP", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = McD_Red)
                                }
                                if (order.status != "DELIVERED") {
                                    Spacer(modifier = Modifier.width(SpacingSmall))
                                    IconButton(onClick = { viewModel.selectActiveOrder(order) }) {
                                        Icon(Icons.Default.Map, "Track", tint = McD_Red)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 10. OFFERS SCREEN
// ==========================================
@Composable
fun OffersScreen(viewModel: McDeliveryViewModel) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(SpacingMedium)
    ) {
        Text("EXCLUSIVE OFFERS", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
        Text("Synthetic promotional rewards and discount codes.", fontSize = 12.sp, color = McD_DarkGrey)

        Spacer(modifier = Modifier.height(SpacingMedium))

        // Offer 1
        Card(
            shape = RoundedCornerShape(CardCornerRadius),
            colors = CardDefaults.cardColors(containerColor = McD_White),
            border = BorderStroke(1.dp, McD_LightGrey),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(SpacingMedium)) {
                Box(
                    modifier = Modifier
                        .background(McD_Yellow, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("MEAL DEAL", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
                }
                Spacer(modifier = Modifier.height(SpacingSmall))
                Text("Save £2.00 on any Double Big Deluxe Meal", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                Text("Convert your burger, side and drink into a meal for maximum discount benefits.", fontSize = 12.sp, color = McD_DarkGrey)
                Spacer(modifier = Modifier.height(SpacingMedium))
                McDPrimaryButton(text = "USE PROMO IN MENU", onClick = { viewModel.navigateTo(Screen.MENU) })
            }
        }

        Spacer(modifier = Modifier.height(SpacingMedium))

        // Offer 2
        Card(
            shape = RoundedCornerShape(CardCornerRadius),
            colors = CardDefaults.cardColors(containerColor = McD_White),
            border = BorderStroke(1.dp, McD_LightGrey),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(SpacingMedium)) {
                Box(
                    modifier = Modifier
                        .background(McD_Red, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("FREE DELIVERY", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = McD_White)
                }
                Spacer(modifier = Modifier.height(SpacingSmall))
                Text("Free delivery on orders over £15", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                Text("No promo code required. Automatically subtracted from checkouts over £15 limit.", fontSize = 12.sp, color = McD_DarkGrey)
            }
        }

        Spacer(modifier = Modifier.height(SpacingMedium))

        // Offer 3
        Card(
            shape = RoundedCornerShape(CardCornerRadius),
            colors = CardDefaults.cardColors(containerColor = McD_White),
            border = BorderStroke(1.dp, McD_LightGrey),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(SpacingMedium)) {
                Box(
                    modifier = Modifier
                        .background(McD_Charcoal, RoundedCornerShape(6.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text("FAMILY NIGHT", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = McD_White)
                }
                Spacer(modifier = Modifier.height(SpacingSmall))
                Text("Selected meals from £14.99", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                Text("Feed the whole group with our standard family bundle offerings.", fontSize = 12.sp, color = McD_DarkGrey)
            }
        }
    }
}

// ==========================================
// 11. CUSTOMER SUPPORT SCREEN
// ==========================================
@Composable
fun SupportScreen(viewModel: McDeliveryViewModel) {
    var category by remember { mutableStateOf("Missing item") }
    var description by remember { mutableStateOf("") }
    var selectedOrderId by remember { mutableStateOf("") }

    val orderHistory by viewModel.orders.collectAsState()
    val cases by viewModel.supportCases.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(SpacingMedium)
    ) {
        Text("CUSTOMER SUPPORT DESK", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
        Spacer(modifier = Modifier.height(SpacingMedium))

        Card(colors = CardDefaults.cardColors(containerColor = McD_White), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(SpacingMedium)) {
                Text("Submit a Help Ticket", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                Spacer(modifier = Modifier.height(SpacingSmall))

                // Topic picker
                Text("Select Problem Topic", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = McD_Red)
                Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                    listOf("Missing item", "Incorrect item", "Late delivery", "Payment issue").forEach { choice ->
                        val active = category == choice
                        Box(
                            modifier = Modifier
                                .padding(end = SpacingSmall)
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (active) McD_Red else McD_LightGrey)
                                .clickable { category = choice }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(choice, fontSize = 11.sp, color = if (active) McD_White else McD_Charcoal, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(SpacingSmall))

                // Order link dropdown or simple field
                if (orderHistory.isNotEmpty()) {
                    Text("Related Order ID", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = McD_Red)
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                            Text(if (selectedOrderId.isEmpty()) "Select Order" else selectedOrderId, color = McD_Charcoal)
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            orderHistory.forEach { o ->
                                DropdownMenuItem(
                                    text = { Text(o.id, fontSize = 12.sp) },
                                    onClick = {
                                        selectedOrderId = o.id
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(SpacingSmall))
                }

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("What happened? Provide details...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp)
                )

                Spacer(modifier = Modifier.height(SpacingMedium))

                McDPrimaryButton(
                    text = "SUBMIT SUPPORT TICKET",
                    onClick = {
                        if (description.isNotEmpty()) {
                            viewModel.submitSupportCase(selectedOrderId, category, description)
                            description = ""
                        }
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(SpacingLarge))

        // Previous Cases
        Text("PREVIOUS TICKETS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
        Spacer(modifier = Modifier.height(SpacingSmall))

        if (cases.isEmpty()) {
            Text("No active support cases submitted.", fontSize = 12.sp, color = McD_DarkGrey)
        } else {
            cases.forEach { c ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = McD_White),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(SpacingMedium)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(c.id, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                            Box(
                                modifier = Modifier
                                    .background(McD_Yellow.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(c.status, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                            }
                        }
                        Text("Category: ${c.category}", fontSize = 11.sp, color = McD_Red, fontWeight = FontWeight.Bold)
                        Text(c.description, fontSize = 12.sp, color = McD_DarkGrey)
                        Divider(modifier = Modifier.padding(vertical = SpacingSmall), color = McD_LightGrey)
                        Text("Resolution: ${c.resolution}", fontSize = 11.sp, color = McD_Green, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ==========================================
// 12. RESTAURANT OPERATIONS SIMULATION DESK
// ==========================================
@Composable
fun RestaurantOpsScreen(viewModel: McDeliveryViewModel) {
    val ordersList by viewModel.orders.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(SpacingMedium)
    ) {
        Text("RESTAURANT KITCHEN OPERATIONS", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
        Text("Simulate how a McDonald's kitchen operator handles orders.", fontSize = 11.sp, color = McD_DarkGrey)

        Spacer(modifier = Modifier.height(SpacingMedium))

        if (ordersList.isEmpty()) {
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Text("No kitchen orders have been placed yet.", color = McD_DarkGrey, fontWeight = FontWeight.Bold)
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(SpacingMedium)
            ) {
                items(ordersList) { order ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = McD_White),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(SpacingMedium)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("ORDER ${order.id}", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = McD_Charcoal)
                                Text("STATUS: ${order.status}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = McD_Red)
                            }

                            Spacer(modifier = Modifier.height(SpacingSmall))

                            val cartItems = JsonUtils.fromJsonCartItems(order.itemsJson)
                            cartItems.forEach { item ->
                                Text("• ${item.quantity} x ${item.name}", fontSize = 12.sp, color = McD_DarkGrey)
                            }

                            Spacer(modifier = Modifier.height(SpacingMedium))

                            // Action transitions buttons
                            Row(modifier = Modifier.horizontalScroll(rememberScrollState())) {
                                Button(
                                    onClick = { viewModel.updateOrderStatusManually(order.id, "RESTAURANT_ACCEPTED") },
                                    colors = ButtonDefaults.buttonColors(containerColor = McD_Yellow),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.padding(end = SpacingSmall)
                                ) {
                                    Text("ACCEPT", fontSize = 10.sp, color = McD_Charcoal, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { viewModel.updateOrderStatusManually(order.id, "PREPARING") },
                                    colors = ButtonDefaults.buttonColors(containerColor = McD_Red),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.padding(end = SpacingSmall)
                                ) {
                                    Text("PREPARE", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { viewModel.updateOrderStatusManually(order.id, "PACKING") },
                                    colors = ButtonDefaults.buttonColors(containerColor = McD_Red),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.padding(end = SpacingSmall)
                                ) {
                                    Text("PACK", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { viewModel.updateOrderStatusManually(order.id, "OUT_FOR_DELIVERY") },
                                    colors = ButtonDefaults.buttonColors(containerColor = McD_Green),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.padding(end = SpacingSmall)
                                ) {
                                    Text("DISPATCH", fontSize = 10.sp, color = McD_White, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { viewModel.updateOrderStatusManually(order.id, "DELIVERED") },
                                    colors = ButtonDefaults.buttonColors(containerColor = McD_Green),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text("DELIVER", fontSize = 10.sp, color = McD_White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ==========================================
// 13. ACCOUNT SCREEN
// ==========================================
@Composable
fun AccountScreen(viewModel: McDeliveryViewModel) {
    val analyticsStats by viewModel.analyticsStats.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(SpacingMedium)
    ) {
        // User Profile Head
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = SpacingLarge)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(McD_Yellow, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Person, null, tint = McD_Red, modifier = Modifier.size(32.dp))
            }
            Spacer(modifier = Modifier.width(SpacingMedium))
            Column {
                Text("Demo Account", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = McD_Charcoal)
                Text("MCD-DELIVERY-DEMO-001", fontSize = 12.sp, color = McD_DarkGrey)
            }
        }

        // Analytics block
        Text("SYSTEM PERFORMANCE METRICS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = McD_Red)
        Spacer(modifier = Modifier.height(4.dp))
        Card(colors = CardDefaults.cardColors(containerColor = McD_White), modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(SpacingMedium)) {
                analyticsStats.forEach { (metric, value) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(metric, fontSize = 12.sp, color = McD_DarkGrey)
                        Text(value, fontSize = 12.sp, color = McD_Charcoal, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(SpacingLarge))

        // Navigation settings rows
        Text("SETTINGS & HELP", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = McD_Red)
        Spacer(modifier = Modifier.height(4.dp))

        Card(colors = CardDefaults.cardColors(containerColor = McD_White), modifier = Modifier.fillMaxWidth()) {
            Column {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(Screen.ADDRESSES) }
                        .padding(SpacingMedium),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Home, null, tint = McD_Charcoal)
                        Spacer(modifier = Modifier.width(SpacingMedium))
                        Text("Manage Delivery Addresses", fontSize = 13.sp, color = McD_Charcoal)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = McD_Red)
                }
                Divider(color = McD_LightGrey)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(Screen.PAYMENTS) }
                        .padding(SpacingMedium),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CreditCard, null, tint = McD_Charcoal)
                        Spacer(modifier = Modifier.width(SpacingMedium))
                        Text("Manage Payment Cards", fontSize = 13.sp, color = McD_Charcoal)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = McD_Red)
                }
                Divider(color = McD_LightGrey)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.navigateTo(Screen.SUPPORT) }
                        .padding(SpacingMedium),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.HelpOutline, null, tint = McD_Charcoal)
                        Spacer(modifier = Modifier.width(SpacingMedium))
                        Text("Get Support & Open Tickets", fontSize = 13.sp, color = McD_Charcoal)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = McD_Red)
                }
            }
        }

        Spacer(modifier = Modifier.height(SpacingLarge))

        Text(
            text = "McDelivery Operational Companion v1.0.0\nFictional Simulation Sandbox Demo",
            fontSize = 11.sp,
            color = McD_DarkGrey,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }
}
