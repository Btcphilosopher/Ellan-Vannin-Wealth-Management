package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = McD_Yellow,
    secondary = McD_Red,
    tertiary = McD_White,
    background = McD_Charcoal,
    surface = McD_DarkGrey,
    onPrimary = McD_Charcoal,
    onSecondary = McD_White,
    onBackground = McD_WarmBg,
    onSurface = McD_WarmBg
)

private val LightColorScheme = lightColorScheme(
    primary = McD_Red,
    secondary = McD_Yellow,
    tertiary = McD_Charcoal,
    background = McD_WarmBg,
    surface = McD_White,
    onPrimary = McD_White,
    onSecondary = McD_Charcoal,
    onBackground = McD_Charcoal,
    onSurface = McD_Charcoal
)

@Composable
fun McDeliveryTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
