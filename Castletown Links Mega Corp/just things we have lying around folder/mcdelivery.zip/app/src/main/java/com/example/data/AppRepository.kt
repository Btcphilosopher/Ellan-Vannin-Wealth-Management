package com.example.data

import kotlinx.coroutines.flow.Flow

class AppRepository(private val database: AppDatabase) {

    val addressDao = database.addressDao()
    val cardDao = database.cardDao()
    val cartDao = database.cartDao()
    val orderDao = database.orderDao()
    val supportCaseDao = database.supportCaseDao()

    // --- Addresses ---
    val allAddresses: Flow<List<AddressEntity>> = addressDao.getAllAddresses()

    suspend fun insertAddress(address: AddressEntity) {
        addressDao.insertAddress(address)
    }

    suspend fun deleteAddress(address: AddressEntity) {
        addressDao.deleteAddress(address)
    }

    suspend fun getAddressById(id: Int): AddressEntity? {
        return addressDao.getAddressById(id)
    }

    // --- Cards ---
    val allCards: Flow<List<CardEntity>> = cardDao.getAllCards()

    suspend fun insertCard(card: CardEntity) {
        cardDao.insertCard(card)
    }

    suspend fun deleteCard(card: CardEntity) {
        cardDao.deleteCard(card)
    }

    // --- Cart ---
    val cartItems: Flow<List<CartItemEntity>> = cartDao.getCartItems()

    suspend fun insertCartItem(item: CartItemEntity) {
        cartDao.insertCartItem(item)
    }

    suspend fun updateCartItem(item: CartItemEntity) {
        cartDao.updateCartItem(item)
    }

    suspend fun deleteCartItem(item: CartItemEntity) {
        cartDao.deleteCartItem(item)
    }

    suspend fun clearCart() {
        cartDao.clearCart()
    }

    // --- Orders ---
    val allOrders: Flow<List<OrderEntity>> = orderDao.getAllOrders()

    fun getOrderFlow(orderId: String): Flow<OrderEntity?> {
        return orderDao.getOrderFlow(orderId)
    }

    suspend fun getOrder(orderId: String): OrderEntity? {
        return orderDao.getOrder(orderId)
    }

    suspend fun insertOrder(order: OrderEntity) {
        orderDao.insertOrder(order)
    }

    suspend fun updateOrder(order: OrderEntity) {
        orderDao.updateOrder(order)
    }

    // --- Support Cases ---
    val allSupportCases: Flow<List<SupportCaseEntity>> = supportCaseDao.getAllSupportCases()

    suspend fun insertSupportCase(case: SupportCaseEntity) {
        supportCaseDao.insertSupportCase(case)
    }
}
