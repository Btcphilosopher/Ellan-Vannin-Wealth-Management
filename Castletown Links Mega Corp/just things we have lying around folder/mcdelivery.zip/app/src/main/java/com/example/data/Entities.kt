package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "addresses")
data class AddressEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val label: String, // Home, Work, Other
    val houseNumber: String,
    val street: String,
    val city: String,
    val postcode: String,
    val deliveryInstructions: String
)

@Entity(tableName = "payment_cards")
data class CardEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val cardholderName: String,
    val cardNumber: String, // Masked as **** **** **** 1234
    val expiryDate: String,
    val cvv: String,
    val cardType: String // Visa, Mastercard, AMEX
)

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val menuItemId: String,
    val name: String,
    val priceMinor: Int, // in pence, e.g. 449 for £4.49
    val quantity: Int,
    val customizationsJson: String, // list of custom additions/removals
    val imageResourceUrl: String
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val id: String, // e.g. MD-20481
    val trackingNumber: String,
    val status: String, // CREATED, PREPARING, OUT_FOR_DELIVERY, DELIVERED, etc.
    val timestamp: Long,
    val subtotalMinor: Int,
    val deliveryFeeMinor: Int,
    val serviceFeeMinor: Int,
    val totalMinor: Int,
    val addressJson: String, // Full delivery address as JSON
    val itemsJson: String, // Full itemized cart list as JSON
    val courierName: String,
    val courierPhone: String,
    val courierLat: Double,
    val courierLng: Double,
    val restaurantId: String,
    val restaurantName: String,
    val etaMinutes: Int,
    val elapsedSimulatedSeconds: Int = 0
)

@Entity(tableName = "support_cases")
data class SupportCaseEntity(
    @PrimaryKey val id: String, // case_id
    val orderId: String,
    val category: String,
    val description: String,
    val status: String, // OPEN, IN_REVIEW, RESOLVED, CLOSED
    val createdAt: Long,
    val resolution: String
)
