package com.example.data

data class MenuItem(
    val id: String,
    val name: String,
    val category: String, // Burgers, Chicken, Sides, Drinks, Desserts, HappyMeal
    val description: String,
    val priceMinor: Int,
    val imageUrl: String,
    val ingredients: List<String> = emptyList(),
    val allergens: List<String> = emptyList(),
    val energyKcal: Int = 0,
    val customizerOptions: List<CustomizerOption> = emptyList()
)

data class CustomizerOption(
    val name: String,
    val priceMinor: Int = 0,
    val isRemovable: Boolean = false,
    val isAddedByDefault: Boolean = false,
    val isSelectionGroup: Boolean = false,
    val selectionGroupItems: List<String> = emptyList()
)

data class AppliedModifier(
    val name: String,
    val priceMinor: Int = 0,
    val isRemoved: Boolean = false,
    val selectedChoice: String? = null
)

data class Restaurant(
    val id: String,
    val name: String,
    val distanceMiles: Double,
    val minDeliveryTime: Int,
    val maxDeliveryTime: Int,
    val deliveryFeeMinor: Int,
    val minOrderMinor: Int,
    val status: String, // OPEN, BUSY, TEMPORARILY_UNAVAILABLE, CLOSED
    val description: String
)

object MenuData {
    val restaurants = listOf(
        Restaurant(
            id = "demo-london-victoria",
            name = "McDonald's London Victoria",
            distanceMiles = 0.8,
            minDeliveryTime = 25,
            maxDeliveryTime = 35,
            deliveryFeeMinor = 299,
            minOrderMinor = 500,
            status = "OPEN",
            description = "Fictional Demo Restaurant - London Victoria Station"
        ),
        Restaurant(
            id = "demo-london-bridge",
            name = "McDonald's London Bridge",
            distanceMiles = 1.4,
            minDeliveryTime = 20,
            maxDeliveryTime = 30,
            deliveryFeeMinor = 199,
            minOrderMinor = 500,
            status = "BUSY",
            description = "Fictional Demo Restaurant - London Bridge"
        ),
        Restaurant(
            id = "demo-kings-cross",
            name = "McDonald's King's Cross",
            distanceMiles = 2.5,
            minDeliveryTime = 30,
            maxDeliveryTime = 40,
            deliveryFeeMinor = 349,
            minOrderMinor = 500,
            status = "OPEN",
            description = "Fictional Demo Restaurant - King's Cross St Pancras"
        ),
        Restaurant(
            id = "demo-manchester-central",
            name = "McDonald's Manchester Central",
            distanceMiles = 0.3,
            minDeliveryTime = 15,
            maxDeliveryTime = 25,
            deliveryFeeMinor = 99,
            minOrderMinor = 500,
            status = "OPEN",
            description = "Fictional Demo Restaurant - Manchester Central"
        ),
        Restaurant(
            id = "demo-birmingham-central",
            name = "McDonald's Birmingham Central",
            distanceMiles = 1.9,
            minDeliveryTime = 20,
            maxDeliveryTime = 35,
            deliveryFeeMinor = 249,
            minOrderMinor = 500,
            status = "TEMPORARILY_UNAVAILABLE",
            description = "Fictional Demo Restaurant - Birmingham Central"
        )
    )

    val categories = listOf(
        "Burgers", "Chicken", "Sides", "Drinks", "Desserts", "Happy Meal"
    )

    val menuItems = listOf(
        // === Burgers ===
        MenuItem(
            id = "b1",
            name = "Double Big Deluxe",
            category = "Burgers",
            description = "Two 100% beef patties, crisp shredded lettuce, cheddar cheese, pickles and onions, with a creamy special sauce on a toasted sesame seed bun.",
            priceMinor = 499,
            imageUrl = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&q=80",
            ingredients = listOf("Beef Patty", "Special Sauce", "Lettuce", "Cheese", "Pickles", "Onions"),
            allergens = listOf("Gluten (Wheat)", "Milk", "Eggs", "Sesame"),
            energyKcal = 540,
            customizerOptions = listOf(
                CustomizerOption("Extra Cheese", 50),
                CustomizerOption("Extra Beef Patty", 120),
                CustomizerOption("Remove Pickles", isRemovable = true, isAddedByDefault = true),
                CustomizerOption("Remove Onions", isRemovable = true, isAddedByDefault = true),
                CustomizerOption("Remove Special Sauce", isRemovable = true, isAddedByDefault = true)
            )
        ),
        MenuItem(
            id = "b2",
            name = "Quarter Cheese Classic",
            category = "Burgers",
            description = "A quarter-pounder 100% beef patty with two slices of melted cheddar cheese, slivered onions, and tangy pickles on a sesame seed bun.",
            priceMinor = 469,
            imageUrl = "https://images.unsplash.com/photo-1550547660-d9450f859349?w=400&q=80",
            ingredients = listOf("Beef Patty", "Cheddar Cheese", "Onions", "Pickles", "Ketchup", "Mustard"),
            allergens = listOf("Gluten (Wheat)", "Milk", "Mustard", "Sesame"),
            energyKcal = 510,
            customizerOptions = listOf(
                CustomizerOption("Extra Cheese", 50),
                CustomizerOption("Extra Beef Patty", 150),
                CustomizerOption("Remove Mustard", isRemovable = true, isAddedByDefault = true),
                CustomizerOption("Remove Ketchup", isRemovable = true, isAddedByDefault = true)
            )
        ),
        MenuItem(
            id = "b3",
            name = "Double Cheeseburger",
            category = "Burgers",
            description = "Two slices of melted cheddar cheese on two 100% beef patties, with pickles, onions, ketchup and mustard.",
            priceMinor = 249,
            imageUrl = "https://images.unsplash.com/photo-1525164286253-04e11415ec60?w=400&q=80",
            ingredients = listOf("Beef Patty x2", "Cheddar Cheese x2", "Pickles", "Onions", "Ketchup", "Mustard"),
            allergens = listOf("Gluten (Wheat)", "Milk", "Mustard"),
            energyKcal = 445,
            customizerOptions = listOf(
                CustomizerOption("Extra Cheese", 50),
                CustomizerOption("Remove Pickles", isRemovable = true, isAddedByDefault = true),
                CustomizerOption("Remove Mustard", isRemovable = true, isAddedByDefault = true)
            )
        ),
        MenuItem(
            id = "b4",
            name = "Classic Cheeseburger",
            category = "Burgers",
            description = "A simple classic: 100% beef patty with melted cheese, pickles, mustard, and ketchup.",
            priceMinor = 189,
            imageUrl = "https://images.unsplash.com/photo-1544025162-d76694265947?w=400&q=80",
            ingredients = listOf("Beef Patty", "Cheddar Cheese", "Pickles", "Ketchup", "Mustard"),
            allergens = listOf("Gluten (Wheat)", "Milk", "Mustard"),
            energyKcal = 301,
            customizerOptions = listOf(
                CustomizerOption("Extra Cheese", 50),
                CustomizerOption("Remove Pickles", isRemovable = true, isAddedByDefault = true)
            )
        ),
        MenuItem(
            id = "b5",
            name = "The Deluxe Veggie",
            category = "Burgers",
            description = "Crispy vegetable patty made with red pepper, pestos, split peas, and crisp shredded lettuce with sandwich sauce on a sesame bun.",
            priceMinor = 399,
            imageUrl = "https://images.unsplash.com/photo-1585238342024-78d387f4a707?w=400&q=80",
            ingredients = listOf("Veggie Patty", "Lettuce", "Sandwich Sauce"),
            allergens = listOf("Gluten (Wheat)", "Eggs", "Sesame"),
            energyKcal = 369,
            customizerOptions = listOf(
                CustomizerOption("Extra Cheese", 50),
                CustomizerOption("Remove Lettuce", isRemovable = true, isAddedByDefault = true)
            )
        ),

        // === Chicken ===
        MenuItem(
            id = "c1",
            name = "Crispy Chicken Sandwich",
            category = "Chicken",
            description = "Crispy, juicy chicken breast fillet with shredded lettuce and creamy mayo on a toasted sesame seed bun.",
            priceMinor = 499,
            imageUrl = "https://images.unsplash.com/photo-1627662236973-4f8259fa2441?w=400&q=80",
            ingredients = listOf("Crispy Chicken", "Lettuce", "Mayo"),
            allergens = listOf("Gluten (Wheat)", "Milk", "Eggs", "Sesame"),
            energyKcal = 480,
            customizerOptions = listOf(
                CustomizerOption("Extra Cheese", 50),
                CustomizerOption("Remove Mayo", isRemovable = true, isAddedByDefault = true)
            )
        ),
        MenuItem(
            id = "c2",
            name = "Chicken McNuggets (6-piece)",
            category = "Chicken",
            description = "Six tender, crispy McNuggets made with 100% chicken breast, served with your choice of dipping sauce.",
            priceMinor = 429,
            imageUrl = "https://images.unsplash.com/photo-1562967914-608f82629710?w=400&q=80",
            ingredients = listOf("Chicken Breast McNuggets"),
            allergens = listOf("Gluten (Wheat)"),
            energyKcal = 259,
            customizerOptions = listOf(
                CustomizerOption("Dipping Sauce", isSelectionGroup = true, selectionGroupItems = listOf("Sweet & Sour", "BBQ", "Sweet Curry", "Ketchup"))
            )
        ),
        MenuItem(
            id = "c3",
            name = "Chicken McNuggets (9-piece)",
            category = "Chicken",
            description = "Nine tender, crispy McNuggets made with 100% chicken breast, served with your choice of dipping sauce.",
            priceMinor = 499,
            imageUrl = "https://images.unsplash.com/photo-1562967914-608f82629710?w=400&q=80",
            ingredients = listOf("Chicken Breast McNuggets"),
            allergens = listOf("Gluten (Wheat)"),
            energyKcal = 388,
            customizerOptions = listOf(
                CustomizerOption("Dipping Sauce", isSelectionGroup = true, selectionGroupItems = listOf("Sweet & Sour", "BBQ", "Sweet Curry", "Ketchup"))
            )
        ),

        // === Sides ===
        MenuItem(
            id = "s1",
            name = "Fries (Medium)",
            category = "Sides",
            description = "World-famous fries, golden on the outside, fluffy on the inside. Perfectly salted.",
            priceMinor = 189,
            imageUrl = "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400&q=80",
            ingredients = listOf("Potatoes", "Salt"),
            allergens = emptyList(),
            energyKcal = 337,
            customizerOptions = listOf(
                CustomizerOption("Salt Preference", isSelectionGroup = true, selectionGroupItems = listOf("Standard Salt", "No Salt"))
            )
        ),
        MenuItem(
            id = "s2",
            name = "Fries (Large)",
            category = "Sides",
            description = "Super-sized portion of world-famous golden fries. Perfect for sharing (or not!).",
            priceMinor = 219,
            imageUrl = "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400&q=80",
            ingredients = listOf("Potatoes", "Salt"),
            allergens = emptyList(),
            energyKcal = 444,
            customizerOptions = listOf(
                CustomizerOption("Salt Preference", isSelectionGroup = true, selectionGroupItems = listOf("Standard Salt", "No Salt"))
            )
        ),
        MenuItem(
            id = "s3",
            name = "Mozzarella Style Bites",
            category = "Sides",
            description = "Crispy breaded bites filled with gooey, melted mozzarella cheese, served with a tangy tomato dip.",
            priceMinor = 249,
            imageUrl = "https://images.unsplash.com/photo-1531749668029-2db88e4b76c0?w=400&q=80",
            ingredients = listOf("Mozzarella", "Breadcrumbs"),
            allergens = listOf("Gluten (Wheat)", "Milk"),
            energyKcal = 288
        ),

        // === Drinks ===
        MenuItem(
            id = "d1",
            name = "Classic Cola (Medium)",
            category = "Drinks",
            description = "A cold, refreshing glass of classic Coca-Cola.",
            priceMinor = 169,
            imageUrl = "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400&q=80",
            energyKcal = 170,
            customizerOptions = listOf(
                CustomizerOption("Ice Option", isSelectionGroup = true, selectionGroupItems = listOf("Standard Ice", "No Ice", "Extra Ice"))
            )
        ),
        MenuItem(
            id = "d2",
            name = "Diet Cola (Medium)",
            category = "Drinks",
            description = "Classic crisp taste, with zero sugar and zero calories.",
            priceMinor = 159,
            imageUrl = "https://images.unsplash.com/photo-1543257580-7269da773bf5?w=400&q=80",
            energyKcal = 1,
            customizerOptions = listOf(
                CustomizerOption("Ice Option", isSelectionGroup = true, selectionGroupItems = listOf("Standard Ice", "No Ice", "Extra Ice"))
            )
        ),
        MenuItem(
            id = "d3",
            name = "Chocolate Milkshake (Medium)",
            category = "Drinks",
            description = "Creamy, smooth dairy milkshake with rich chocolate syrup.",
            priceMinor = 219,
            imageUrl = "https://images.unsplash.com/photo-1572490122747-3968b75cc699?w=400&q=80",
            allergens = listOf("Milk"),
            energyKcal = 380
        ),

        // === Desserts ===
        MenuItem(
            id = "e1",
            name = "McFlurry Chocolate",
            category = "Desserts",
            description = "Soft-serve dairy ice cream with milk chocolate pieces and smooth chocolate sauce.",
            priceMinor = 199,
            imageUrl = "https://images.unsplash.com/photo-1579954115545-a95591f28bfc?w=400&q=80",
            allergens = listOf("Milk", "Soy"),
            energyKcal = 320
        ),
        MenuItem(
            id = "e2",
            name = "Hot Apple Pie",
            category = "Desserts",
            description = "Crispy golden pastry filled with warm, sweet apple filling.",
            priceMinor = 149,
            imageUrl = "https://images.unsplash.com/photo-1519869325930-281384150729?w=400&q=80",
            allergens = listOf("Gluten (Wheat)"),
            energyKcal = 250
        ),

        // === Happy Meal ===
        MenuItem(
            id = "h1",
            name = "Chicken McNuggets Happy Meal",
            category = "Happy Meal",
            description = "Four pieces of crispy McNuggets, a side, a drink, and a retro space collectible toy!",
            priceMinor = 349,
            imageUrl = "https://images.unsplash.com/photo-1606755962773-d324e0a13086?w=400&q=80",
            allergens = listOf("Gluten (Wheat)"),
            energyKcal = 350,
            customizerOptions = listOf(
                CustomizerOption("Select Side", isSelectionGroup = true, selectionGroupItems = listOf("Small Fries", "Fruit Bag")),
                CustomizerOption("Select Drink", isSelectionGroup = true, selectionGroupItems = listOf("Organic Milk", "Apple Juice Box", "Mineral Water")),
                CustomizerOption("Select Toy Preference", isSelectionGroup = true, selectionGroupItems = listOf("Space Scooter Toy", "Adventure Comic Book"))
            )
        )
    )
}
