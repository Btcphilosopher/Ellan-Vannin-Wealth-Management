package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.data.*
import com.example.ui.theme.*

// --- Spacing & Dimensions ---
val SpacingSmall = 8.dp
val SpacingMedium = 16.dp
val SpacingLarge = 24.dp
val ButtonCornerRadius = 16.dp
val CardCornerRadius = 20.dp

// --- Buttons ---
@Composable
fun McDPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    testTag: String = ""
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = McD_Red,
            contentColor = McD_White,
            disabledContainerColor = McD_LightGrey,
            disabledContentColor = McD_DarkGrey
        ),
        shape = RoundedCornerShape(ButtonCornerRadius),
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .testTag(testTag),
        enabled = enabled
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun McDSecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    testTag: String = ""
) {
    OutlinedButton(
        onClick = onClick,
        border = BorderStroke(2.dp, McD_Red),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = McD_Red
        ),
        shape = RoundedCornerShape(ButtonCornerRadius),
        modifier = modifier
            .fillMaxWidth()
            .heightIn(min = 52.dp)
            .testTag(testTag),
        enabled = enabled
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

// --- Cards ---
@Composable
fun RestaurantCard(
    restaurant: Restaurant,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) McD_LightGrey else McD_White
        ),
        shape = RoundedCornerShape(CardCornerRadius),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) McD_Red else McD_LightGrey
        ),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("restaurant_card_${restaurant.id}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(SpacingMedium),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(McD_Yellow),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Restaurant,
                    contentDescription = null,
                    tint = McD_Red,
                    modifier = Modifier.size(28.dp)
                )
            }

            Spacer(modifier = Modifier.width(SpacingMedium))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = restaurant.name,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = McD_Charcoal,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    StatusBadge(status = restaurant.status)
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.DirectionsRun,
                        contentDescription = null,
                        tint = McD_DarkGrey,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "${restaurant.distanceMiles} miles",
                        fontSize = 12.sp,
                        color = McD_DarkGrey
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = null,
                        tint = McD_DarkGrey,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "${restaurant.minDeliveryTime}-${restaurant.maxDeliveryTime} mins",
                        fontSize = 12.sp,
                        color = McD_DarkGrey
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "Delivery £${String.format("%.2f", restaurant.deliveryFeeMinor / 100.0)} • Min. Order £${String.format("%.2f", restaurant.minOrderMinor / 100.0)}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = McD_Red
                )
            }
        }
    }
}

@Composable
fun FoodCard(
    menuItem: MenuItem,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = McD_White),
        shape = RoundedCornerShape(CardCornerRadius),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .testTag("food_card_${menuItem.id}")
    ) {
        Column {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current)
                    .data(menuItem.imageUrl)
                    .crossfade(true)
                    .build(),
                contentDescription = menuItem.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(topStart = CardCornerRadius, topEnd = CardCornerRadius))
            )

            Column(modifier = Modifier.padding(SpacingMedium)) {
                Text(
                    text = menuItem.name,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = McD_Charcoal,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = menuItem.description,
                    fontSize = 11.sp,
                    color = McD_DarkGrey,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 14.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "£${String.format("%.2f", menuItem.priceMinor / 100.0)}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = McD_Red
                    )

                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .background(McD_Yellow, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Add",
                            tint = McD_Charcoal,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val bgColor = when (status) {
        "OPEN" -> McD_Green.copy(alpha = 0.15f)
        "BUSY" -> McD_Yellow.copy(alpha = 0.25f)
        "TEMPORARILY_UNAVAILABLE" -> McD_Red.copy(alpha = 0.15f)
        else -> McD_DarkGrey.copy(alpha = 0.15f)
    }

    val textColor = when (status) {
        "OPEN" -> McD_Green
        "BUSY" -> McD_Charcoal
        "TEMPORARILY_UNAVAILABLE" -> McD_Red
        else -> McD_DarkGrey
    }

    val label = when (status) {
        "OPEN" -> "OPEN"
        "BUSY" -> "BUSY"
        "TEMPORARILY_UNAVAILABLE" -> "UNAVAILABLE"
        else -> "CLOSED"
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

// --- List Items / Rows ---
@Composable
fun AddressCard(
    address: AddressEntity,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = McD_White),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) McD_Red else McD_LightGrey
        ),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .testTag("address_card_${address.id}")
    ) {
        Row(
            modifier = Modifier.padding(SpacingMedium),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = when (address.label) {
                    "Home" -> Icons.Default.Home
                    "Work" -> Icons.Default.Work
                    else -> Icons.Default.Place
                },
                contentDescription = null,
                tint = if (isSelected) McD_Red else McD_DarkGrey,
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.width(SpacingMedium))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = address.label,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = McD_Charcoal
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "${address.houseNumber} ${address.street}, ${address.city}",
                    fontSize = 12.sp,
                    color = McD_DarkGrey
                )
                Text(
                    text = address.postcode,
                    fontSize = 12.sp,
                    color = McD_DarkGrey,
                    fontWeight = FontWeight.Medium
                )
                if (address.deliveryInstructions.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "“${address.deliveryInstructions}”",
                        fontSize = 11.sp,
                        color = McD_Red,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = McD_Red.copy(alpha = 0.7f)
                )
            }
        }
    }
}

@Composable
fun CardRow(
    card: CardEntity,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = McD_White),
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) McD_Red else McD_LightGrey
        ),
        modifier = modifier
            .fillMaxWidth()
            .clickable(onClick = onSelect)
            .testTag("card_row_${card.id}")
    ) {
        Row(
            modifier = Modifier.padding(SpacingMedium),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (card.cardType == "Visa") Icons.Default.Payment else Icons.Default.CreditCard,
                contentDescription = null,
                tint = if (isSelected) McD_Red else McD_Charcoal,
                modifier = Modifier.size(24.dp)
            )

            Spacer(modifier = Modifier.width(SpacingMedium))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = card.cardNumber,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = McD_Charcoal
                )
                Text(
                    text = "${card.cardholderName} • Expires ${card.expiryDate}",
                    fontSize = 12.sp,
                    color = McD_DarkGrey
                )
            }

            IconButton(onClick = onDelete) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = McD_Red.copy(alpha = 0.7f)
                )
            }
        }
    }
}

// --- Order Timeline & Progress ---
@Composable
fun OrderProgressTimeline(status: String) {
    val states = listOf(
        "Received" to listOf("CREATED", "PAYMENT_AUTHORISED", "RESTAURANT_RECEIVED"),
        "Accepted" to listOf("RESTAURANT_ACCEPTED"),
        "Preparing" to listOf("PREPARING", "COOKING", "PACKING"),
        "Ready" to listOf("READY_FOR_COLLECTION", "COURIER_ASSIGNED"),
        "On the Way" to listOf("COURIER_AT_RESTAURANT", "ORDER_COLLECTED", "OUT_FOR_DELIVERY", "ARRIVING"),
        "Delivered" to listOf("DELIVERED")
    )

    // Find current index
    var currentIndex = 0
    for ((index, pair) in states.withIndex()) {
        if (pair.second.contains(status)) {
            currentIndex = index
            break
        }
    }
    if (status == "DELIVERED") {
        currentIndex = 5
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(McD_White, RoundedCornerShape(CardCornerRadius))
            .padding(SpacingMedium)
    ) {
        Text(
            text = "Delivery Status Timeline",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = McD_Charcoal,
            modifier = Modifier.padding(bottom = SpacingMedium)
        )

        states.forEachIndexed { index, pair ->
            val isCompleted = index <= currentIndex
            val isCurrent = index == currentIndex

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(36.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(18.dp)
                        .background(
                            color = if (isCompleted) McD_Red else McD_LightGrey,
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isCompleted) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = McD_White,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(SpacingMedium))

                Text(
                    text = pair.first,
                    fontSize = 13.sp,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                    color = if (isCurrent) McD_Red else if (isCompleted) McD_Charcoal else McD_DarkGrey
                )

                if (isCurrent) {
                    Spacer(modifier = Modifier.weight(1f))
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .background(McD_Yellow, CircleShape)
                    )
                }
            }
        }
    }
}

// --- MapView (Beautiful Canvas Road Representation) ---
@Composable
fun MapView(
    courierLat: Double,
    courierLng: Double,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(CardCornerRadius),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8ECE9)), // Classic map background
        border = BorderStroke(1.dp, McD_LightGrey),
        modifier = modifier
            .fillMaxWidth()
            .height(220.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val canvasWidth = size.width
                val canvasHeight = size.height

                // Draw some grid roads (London Victoria Style)
                val roadColor = Color.White
                val roadWidth = 24f

                // Horizontal Roads
                drawLine(
                    color = roadColor,
                    start = Offset(0f, canvasHeight * 0.25f),
                    end = Offset(canvasWidth, canvasHeight * 0.25f),
                    strokeWidth = roadWidth
                )
                drawLine(
                    color = roadColor,
                    start = Offset(0f, canvasHeight * 0.75f),
                    end = Offset(canvasWidth, canvasHeight * 0.75f),
                    strokeWidth = roadWidth
                )

                // Vertical Roads
                drawLine(
                    color = roadColor,
                    start = Offset(canvasWidth * 0.25f, 0f),
                    end = Offset(canvasWidth * 0.25f, canvasHeight),
                    strokeWidth = roadWidth
                )
                drawLine(
                    color = roadColor,
                    start = Offset(canvasWidth * 0.75f, 0f),
                    end = Offset(canvasWidth * 0.75f, canvasHeight),
                    strokeWidth = roadWidth
                )

                // Diagonal shortcut road
                drawLine(
                    color = roadColor,
                    start = Offset(0f, 0f),
                    end = Offset(canvasWidth, canvasHeight),
                    strokeWidth = roadWidth
                )

                // Draw central park area
                drawRect(
                    color = Color(0xFFC8E6C9), // Beautiful light green park
                    topLeft = Offset(canvasWidth * 0.35f, canvasHeight * 0.35f),
                    size = androidx.compose.ui.geometry.Size(canvasWidth * 0.3f, canvasHeight * 0.3f)
                )

                // Fictional restaurant coordinates mapping
                // RESTAURANT_LAT = 51.4963, RESTAURANT_LNG = -0.1431 (Map to bottom left area of canvas)
                val restX = canvasWidth * 0.25f
                val restY = canvasHeight * 0.75f

                // CUSTOMER_LAT = 51.5015, CUSTOMER_LNG = -0.1419 (Map to top right area of canvas)
                val custX = canvasWidth * 0.75f
                val custY = canvasHeight * 0.25f

                // Draw delivery route connection (dotted line)
                drawLine(
                    color = McD_Red.copy(alpha = 0.5f),
                    start = Offset(restX, restY),
                    end = Offset(custX, custY),
                    strokeWidth = 6f,
                    pathEffect = androidx.compose.ui.graphics.PathEffect.dashPathEffect(floatArrayOf(15f, 15f), 0f)
                )

                // Map courier position relative to progress
                // Let's interpolate courier position based on its coordinates
                // Lat range: 51.4900 (bottom) to 51.5020 (top)
                // Lng range: -0.1460 (left) to -0.1410 (right)
                val latMin = 51.4900
                val latMax = 51.5020
                val lngMin = -0.1460
                val lngMax = -0.1410

                val courierX = canvasWidth * ((courierLng - lngMin) / (lngMax - lngMin)).toFloat().coerceIn(0f, 1f)
                val courierY = canvasHeight * (1f - ((courierLat - latMin) / (latMax - latMin)).toFloat()).coerceIn(0f, 1f)

                // Draw Restaurant icon node
                drawCircle(
                    color = McD_Yellow,
                    radius = 24f,
                    center = Offset(restX, restY)
                )
                drawCircle(
                    color = McD_Red,
                    radius = 18f,
                    center = Offset(restX, restY),
                    style = Stroke(width = 4f)
                )

                // Draw Customer icon node
                drawCircle(
                    color = McD_Red,
                    radius = 24f,
                    center = Offset(custX, custY)
                )
                drawCircle(
                    color = McD_White,
                    radius = 12f,
                    center = Offset(custX, custY)
                )

                // Draw Courier (Red moving circle)
                drawCircle(
                    color = McD_Charcoal,
                    radius = 20f,
                    center = Offset(courierX, courierY)
                )
                drawCircle(
                    color = McD_Yellow,
                    radius = 10f,
                    center = Offset(courierX, courierY)
                )
            }

            // Text Labels Overlay
            Box(
                modifier = Modifier
                    .offset(x = 10.dp, y = 145.dp)
                    .background(McD_Charcoal, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("Victoria Store", fontSize = 10.sp, color = McD_White, fontWeight = FontWeight.Bold)
            }

            Box(
                modifier = Modifier
                    .offset(x = 240.dp, y = 25.dp)
                    .background(McD_Red, RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("Your Home", fontSize = 10.sp, color = McD_White, fontWeight = FontWeight.Bold)
            }

            Box(
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(SpacingSmall)
                    .background(McD_Charcoal.copy(alpha = 0.8f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text("Logistics Simulator Active", fontSize = 9.sp, color = McD_Yellow, fontWeight = FontWeight.Medium)
            }
        }
    }
}

// --- Basket Bottom Bar ---
@Composable
fun BasketBar(
    itemCount: Int,
    totalMinor: Int,
    onClick: () -> Unit
) {
    AnimatedVisibility(
        visible = itemCount > 0,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Surface(
            color = McD_Red,
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
            modifier = Modifier
                .fillMaxWidth()
                .clickable(onClick = onClick)
                .testTag("basket_bar")
        ) {
            Row(
                modifier = Modifier
                    .padding(horizontal = SpacingMedium, vertical = 14.dp)
                    .navigationBarsPadding(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .background(McD_Yellow, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "$itemCount",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = McD_Charcoal
                        )
                    }
                    Spacer(modifier = Modifier.width(SpacingMedium))
                    Text(
                        text = "View your basket",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = McD_White
                    )
                }

                Text(
                    text = "£${String.format("%.2f", totalMinor / 100.0)}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = McD_White
                )
            }
        }
    }
}
