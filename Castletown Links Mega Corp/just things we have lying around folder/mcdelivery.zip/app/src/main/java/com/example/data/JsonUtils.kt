package com.example.data

import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

object JsonUtils {
    private val moshi = Moshi.Builder()
        .addLast(KotlinJsonAdapterFactory())
        .build()

    fun toJson(address: AddressEntity): String {
        val adapter = moshi.adapter(AddressEntity::class.java)
        return adapter.toJson(address)
    }

    fun fromJsonAddress(json: String): AddressEntity? {
        if (json.isEmpty()) return null
        return try {
            val adapter = moshi.adapter(AddressEntity::class.java)
            adapter.fromJson(json)
        } catch (e: Exception) {
            null
        }
    }

    fun toJsonCartItems(items: List<CartItemEntity>): String {
        val type = Types.newParameterizedType(List::class.java, CartItemEntity::class.java)
        val adapter = moshi.adapter<List<CartItemEntity>>(type)
        return adapter.toJson(items)
    }

    fun fromJsonCartItems(json: String): List<CartItemEntity> {
        if (json.isEmpty()) return emptyList()
        return try {
            val type = Types.newParameterizedType(List::class.java, CartItemEntity::class.java)
            val adapter = moshi.adapter<List<CartItemEntity>>(type)
            adapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun toJsonModifiers(modifiers: List<AppliedModifier>): String {
        val type = Types.newParameterizedType(List::class.java, AppliedModifier::class.java)
        val adapter = moshi.adapter<List<AppliedModifier>>(type)
        return adapter.toJson(modifiers)
    }

    fun fromJsonModifiers(json: String): List<AppliedModifier> {
        if (json.isEmpty()) return emptyList()
        return try {
            val type = Types.newParameterizedType(List::class.java, AppliedModifier::class.java)
            val adapter = moshi.adapter<List<AppliedModifier>>(type)
            adapter.fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }
}
