package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.example.ui.McDeliveryApp
import com.example.ui.McDeliveryViewModel
import com.example.ui.theme.McDeliveryTheme

class MainActivity : ComponentActivity() {
    private val viewModel: McDeliveryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            McDeliveryTheme {
                Surface(
                    modifier = Modifier.fillMaxSize()
                ) {
                    McDeliveryApp(viewModel = viewModel)
                }
            }
        }
    }
}
