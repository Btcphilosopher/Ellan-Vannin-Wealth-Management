package com.example.data

import android.util.Log

object DeliverySimulator {

    // Fictional Coordinates (London Victoria area)
    const val RESTAURANT_LAT = 51.4963
    const val RESTAURANT_LNG = -0.1431

    const val CUSTOMER_LAT = 51.5015
    const val CUSTOMER_LNG = -0.1419

    // The order state machine transitions
    val ORDER_STATES = listOf(
        "CREATED",
        "PAYMENT_AUTHORISED",
        "RESTAURANT_RECEIVED",
        "RESTAURANT_ACCEPTED",
        "PREPARING",
        "COOKING",
        "PACKING",
        "READY_FOR_COLLECTION",
        "COURIER_ASSIGNED",
        "COURIER_AT_RESTAURANT",
        "ORDER_COLLECTED",
        "OUT_FOR_DELIVERY",
        "ARRIVING",
        "DELIVERED"
    )

    /**
     * Ticks the order simulation by a given number of simulated seconds.
     * Returns the updated OrderEntity, or null if no updates are needed.
     */
    fun tickOrder(order: OrderEntity, simulatedSecondsElapsed: Int): OrderEntity {
        if (order.status == "DELIVERED" || order.status.endsWith("REJECTED") || order.status.endsWith("FAILED") || order.status.endsWith("CANCELLED")) {
            return order
        }

        val totalTimeNeededSeconds = 12 * 60 // 12 minutes total for simulation transitions (720 seconds)
        val newElapsedSeconds = order.elapsedSimulatedSeconds + simulatedSecondsElapsed

        // Map elapsed seconds to state transitions (14 states)
        // Let's divide 720 seconds across states 0 to 13
        val stateDuration = 50 // roughly 50 simulated seconds per state
        val stateIndex = (newElapsedSeconds / stateDuration).coerceAtMost(ORDER_STATES.size - 1)
        val newStatus = ORDER_STATES[stateIndex]

        // Calculate courier positions
        var courierLat = RESTAURANT_LAT
        var courierLng = RESTAURANT_LNG

        when (newStatus) {
            "COURIER_ASSIGNED" -> {
                // Courier is heading to restaurant. Starts at distance and moves closer
                val progress = ((newElapsedSeconds % stateDuration).toDouble() / stateDuration).coerceAtIn(0.0, 1.0)
                // Start at Lat: 51.4900, Lng: -0.1450 and move to restaurant
                courierLat = 51.4900 + (RESTAURANT_LAT - 51.4900) * progress
                courierLng = -0.1450 + (RESTAURANT_LNG - (-0.1450)) * progress
            }
            "COURIER_AT_RESTAURANT", "ORDER_COLLECTED" -> {
                // Courier is at the restaurant
                courierLat = RESTAURANT_LAT
                courierLng = RESTAURANT_LNG
            }
            "OUT_FOR_DELIVERY", "ARRIVING" -> {
                // Courier is traveling from restaurant to customer
                // Let's combine these states' progress
                val outForDeliveryStateIndex = ORDER_STATES.indexOf("OUT_FOR_DELIVERY")
                val totalSecondsFromOutToArriving = stateDuration * 2
                val currentSecondsInOut = (newElapsedSeconds - (outForDeliveryStateIndex * stateDuration))
                    .coerceAtLeast(0)
                val progress = (currentSecondsInOut.toDouble() / totalSecondsFromOutToArriving).coerceAtIn(0.0, 1.0)

                courierLat = RESTAURANT_LAT + (CUSTOMER_LAT - RESTAURANT_LAT) * progress
                courierLng = RESTAURANT_LNG + (CUSTOMER_LNG - RESTAURANT_LNG) * progress
            }
            "DELIVERED" -> {
                courierLat = CUSTOMER_LAT
                courierLng = CUSTOMER_LNG
            }
        }

        // Calculate dynamic ETA
        val remainingSeconds = (totalTimeNeededSeconds - newElapsedSeconds).coerceAtLeast(0)
        val dynamicEtaMinutes = (remainingSeconds / 60) + 1

        return order.copy(
            status = newStatus,
            elapsedSimulatedSeconds = newElapsedSeconds,
            courierLat = courierLat,
            courierLng = courierLng,
            etaMinutes = if (newStatus == "DELIVERED") 0 else dynamicEtaMinutes
        )
    }

    private fun Double.coerceAtIn(min: Double, max: Double): Double {
        return if (this < min) min else if (this > max) max else this
    }
}
