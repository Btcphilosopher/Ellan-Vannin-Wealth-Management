package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// McDonald's Brand Colors
val McD_Red = Color(0xFFDA291C)
val McD_Yellow = Color(0xFFFFC72C)
val McD_Charcoal = Color(0xFF27251F)
val McD_DarkGrey = Color(0xFF4A4947)
val McD_LightGrey = Color(0xFFF2F2F2)
val McD_WarmBg = Color(0xFFF9F7F5)
val McD_Green = Color(0xFF1F8A43) // status/success
val McD_White = Color(0xFFFFFFFF)
val McD_Gold = Color(0xFFD4AF37)
