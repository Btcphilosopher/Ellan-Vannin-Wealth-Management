package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.*
import com.example.ui.McDeliveryViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34]) // Use a stable supported Robolectric SDK level
class ExampleRobolectricTest {

    @Test
    fun verifyAppNameInContext() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("McDelivery", appName)
    }

    @Test
    fun testCompleteMcDeliveryWorkflowEndToEnd() = runBlocking {
        val application = ApplicationProvider.getApplicationContext<Application>()
        val db = AppDatabase.getDatabase(application)
        val viewModel = McDeliveryViewModel(application)

        // Step 1: Prepopulate database directly and synchronously
        val demoAddress = AddressEntity(
            id = 1,
            label = "Home",
            houseNumber = "12",
            street = "Example Street",
            city = "London",
            postcode = "SW1A 1AA",
            deliveryInstructions = "Leave at reception."
        )
        db.addressDao().insertAddress(demoAddress)
        viewModel.selectAddress(demoAddress)

        val demoCard = CardEntity(
            id = 1,
            cardholderName = "John Doe",
            cardNumber = "**** **** **** 1882",
            expiryDate = "12/28",
            cvv = "123",
            cardType = "Visa"
        )
        db.cardDao().insertCard(demoCard)
        viewModel.selectCard(demoCard)

        // Verify Step 1 selections
        assertEquals("Home", viewModel.selectedAddress.value?.label)
        assertEquals("**** **** **** 1882", viewModel.selectedCard.value?.cardNumber)

        // Step 2: Build Basket - Add "Double Big Deluxe"
        val burgerItem = MenuData.menuItems.first { it.id == "b1" }
        
        // Add to cart directly by inserting to database synchronously
        val cartItem = CartItemEntity(
            id = 1,
            menuItemId = burgerItem.id,
            name = burgerItem.name,
            priceMinor = burgerItem.priceMinor,
            quantity = 2,
            customizationsJson = "[]",
            imageResourceUrl = burgerItem.imageUrl
        )
        db.cartDao().insertCartItem(cartItem)

        // Verify cart items directly
        val dbCartItems = db.cartDao().getCartItems().first()
        assertEquals(1, dbCartItems.size)
        assertEquals("Double Big Deluxe", dbCartItems[0].name)
        assertEquals(2, dbCartItems[0].quantity)

        // Step 3: Verify Pricing calculations using our integer minor units logic
        val subtotal = dbCartItems.sumOf { it.priceMinor * it.quantity }
        val delivery = if (subtotal > 1500) 0 else 299
        val service = 50
        val total = subtotal + delivery + service

        assertEquals(998, subtotal)
        assertEquals(299, delivery)
        assertEquals(50, service)
        assertEquals(1347, total)

        // Step 4: Create Order & Checkout
        val orderId = "MD-20481"
        val activeOrder = OrderEntity(
            id = orderId,
            trackingNumber = "TRK-102911",
            status = "CREATED",
            timestamp = System.currentTimeMillis(),
            subtotalMinor = subtotal,
            deliveryFeeMinor = delivery,
            serviceFeeMinor = service,
            totalMinor = total,
            addressJson = JsonUtils.toJson(demoAddress),
            itemsJson = JsonUtils.toJsonCartItems(dbCartItems),
            courierName = "Courier Dan",
            courierPhone = "+44 7700 900077",
            courierLat = DeliverySimulator.RESTAURANT_LAT,
            courierLng = DeliverySimulator.RESTAURANT_LNG,
            restaurantId = "demo-london-victoria",
            restaurantName = "McDonald's London Victoria",
            etaMinutes = 25
        )
        db.orderDao().insertOrder(activeOrder)

        // Verify database order insertion
        val savedOrder = db.orderDao().getOrder(orderId)
        assertNotNull(savedOrder)
        assertEquals("CREATED", savedOrder!!.status)
        assertEquals(1347, savedOrder.totalMinor)

        // Step 5: Simulate state transitions via DeliverySimulator
        var currentOrderState = savedOrder!!
        for (i in 1..15) {
            currentOrderState = DeliverySimulator.tickOrder(currentOrderState, 60)
        }

        assertEquals("DELIVERED", currentOrderState.status)
        assertEquals(0, currentOrderState.etaMinutes)
        assertEquals(DeliverySimulator.CUSTOMER_LAT, currentOrderState.courierLat, 0.0001)
        assertEquals(DeliverySimulator.CUSTOMER_LNG, currentOrderState.courierLng, 0.0001)
    }
}
