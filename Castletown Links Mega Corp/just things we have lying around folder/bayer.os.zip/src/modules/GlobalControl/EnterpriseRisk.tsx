import React, { useState } from 'react';
import { AlertOctagon, ShieldAlert, UserCheck, CheckCircle2, DollarSign, Clock } from 'lucide-react';
import { RiskEvent } from '../../types';

interface EnterpriseRiskProps {
  riskEvents: RiskEvent[];
  onAssignRiskOwner: (riskId: string, owner: string, mitigationPlan: string) => Promise<any>;
}

export const EnterpriseRisk: React.FC<EnterpriseRiskProps> = ({ riskEvents, onAssignRiskOwner }) => {
  const [selectedRisk, setSelectedRisk] = useState<RiskEvent | null>(riskEvents[0] || null);
  const [ownerInput, setOwnerInput] = useState<string>('');
  const [mitigationInput, setMitigationInput] = useState<string>('');
  const [isSaving, setIsSaving] = useState<boolean>(false);

  const totalExposure = riskEvents.reduce((sum, r) => sum + r.exposureEUR, 0);

  const handleSaveAssignment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRisk || !ownerInput || !mitigationInput) return;
    setIsSaving(true);
    try {
      await onAssignRiskOwner(selectedRisk.id, ownerInput, mitigationInput);
      alert('Risk mitigation action owner assigned and audit event recorded.');
    } catch (err: any) {
      alert('Error assigning owner: ' + err.message);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="p-6 space-y-6 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* Header */}
      <div className="p-4 bg-[#121826] rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-mono text-white">ENTERPRISE RISK MATRIX & EXPOSURE CONTROL</h1>
          <p className="text-xs text-slate-400">Cross-Division Supply, Quality, Regulatory and Geopolitical Risk Governance</p>
        </div>
        <div className="font-mono text-xs text-right">
          <span className="text-slate-400 block text-[10px]">TOTAL RISK EXPOSURE:</span>
          <span className="text-rose-400 font-bold text-lg">€{totalExposure.toLocaleString()}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Risk Events Table */}
        <div className="lg:col-span-2 bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 font-mono text-xs">
            <span className="text-slate-300 font-bold uppercase">ACTIVE ENTERPRISE RISKS ({riskEvents.length})</span>
            <span className="text-rose-400">ACTION REQUIRED</span>
          </div>

          <div className="space-y-2">
            {riskEvents.map((risk) => (
              <div
                key={risk.id}
                onClick={() => {
                  setSelectedRisk(risk);
                  setOwnerInput(risk.assignedOwner.includes('Unassigned') ? '' : risk.assignedOwner);
                  setMitigationInput(risk.mitigationPlan);
                }}
                className={`p-3.5 rounded border transition cursor-pointer font-mono text-xs space-y-1.5 ${
                  selectedRisk?.id === risk.id
                    ? 'bg-slate-800 border-amber-500 shadow-sm'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-1.5 py-0.5 rounded bg-slate-950 text-slate-300 border border-slate-700 text-[10px]">
                      {risk.riskCode}
                    </span>
                    <span className="font-bold text-white font-sans">{risk.title}</span>
                  </div>
                  <span className="text-rose-400 font-bold">€{risk.exposureEUR.toLocaleString()}</span>
                </div>

                <div className="text-[11px] text-slate-400 font-sans">{risk.mitigationPlan}</div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800/80">
                  <span>CATEGORY: {risk.category}</span>
                  <span>OWNER: {risk.assignedOwner}</span>
                  <span className={`px-1.5 py-0.2 rounded font-bold ${
                    risk.status === 'RESOLVED' ? 'text-emerald-400' : 'text-amber-400'
                  }`}>
                    {risk.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Risk Mitigation Action Assignment Panel */}
        {selectedRisk ? (
          <form onSubmit={handleSaveAssignment} className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-4 font-sans text-xs">
            <div className="border-b border-slate-800 pb-3">
              <span className="text-[10px] font-mono text-amber-400 uppercase font-bold">MITIGATION WORKFLOW</span>
              <h2 className="text-sm font-bold font-mono text-white mt-1">{selectedRisk.title}</h2>
              <p className="text-slate-400 text-xs font-mono">Risk Code: {selectedRisk.riskCode}</p>
            </div>

            <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1 font-mono text-[11px]">
              <div className="text-slate-400">FINANCIAL EXPOSURE ESTIMATE:</div>
              <div className="text-rose-400 text-base font-bold">€{selectedRisk.exposureEUR.toLocaleString()}</div>
              <div className="text-slate-400 text-[10px] pt-1">
                PROBABILITY: {selectedRisk.probability} | IMPACT: {selectedRisk.impact}
              </div>
            </div>

            <div>
              <label className="block text-slate-300 font-mono font-bold mb-1">ASSIGNED ACTION OWNER:</label>
              <input
                type="text"
                value={ownerInput}
                onChange={(e) => setOwnerInput(e.target.value)}
                placeholder="e.g. Dr. H. Weber (QA Director)"
                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-mono font-bold mb-1">MITIGATION STRATEGY & ACTION PLAN:</label>
              <textarea
                rows={4}
                value={mitigationInput}
                onChange={(e) => setMitigationInput(e.target.value)}
                placeholder="Detail emergency sourcing, buffer stock activation, or regulatory submission response..."
                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white text-xs focus:outline-none focus:border-amber-500"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isSaving}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold rounded text-xs transition disabled:opacity-50"
            >
              {isSaving ? 'RECORDING ASSIGNMENT...' : 'SAVE ASSIGNMENT & LOG AUDIT EVENT'}
            </button>
          </form>
        ) : (
          <div className="bg-[#121826] p-5 rounded-lg border border-slate-800 flex items-center justify-center text-slate-500 font-mono text-xs">
            Select a risk event from the matrix to assign action owners.
          </div>
        )}
      </div>
    </div>
  );
};
