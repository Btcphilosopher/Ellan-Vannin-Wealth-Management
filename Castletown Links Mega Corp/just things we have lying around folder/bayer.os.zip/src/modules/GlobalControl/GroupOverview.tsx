import React from 'react';
import { 
  Building2, 
  Factory, 
  FlaskConical, 
  AlertTriangle, 
  Activity, 
  ShieldCheck, 
  ChevronRight, 
  ArrowUpRight, 
  Zap, 
  Droplet, 
  Leaf, 
  DollarSign, 
  CheckCircle2,
  MapPin,
  Clock
} from 'lucide-react';
import { Site, Batch, DivisionId } from '../../types';

interface GroupOverviewProps {
  overviewData: any;
  sites: Site[];
  batches: Batch[];
  onSelectSite: (siteId: string) => void;
  onSelectDivision: (division: DivisionId) => void;
  onTriggerSimulateDelay: () => void;
}

export const GroupOverview: React.FC<GroupOverviewProps> = ({
  overviewData,
  sites,
  batches,
  onSelectSite,
  onSelectDivision,
  onTriggerSimulateDelay,
}) => {
  const [selectedDivisionTab, setSelectedDivisionTab] = React.useState<DivisionId>('PHARMA');

  const filteredSites = sites.filter((s) => s.division === selectedDivisionTab);

  return (
    <div className="p-6 space-y-6 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* Top Banner & Control Status */}
      <div className="p-4 bg-[#121826] rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4 shadow-sm">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono tracking-tight text-white">GROUP OVERVIEW & ENTERPRISE COMMAND</h1>
            <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-mono text-[10px] border border-emerald-500/30 font-bold">
              OPERATIONAL
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Unified operating picture connecting Pharmaceuticals, Crop Science, Consumer Health and Global Supply Networks.
          </p>
        </div>
        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="px-3 py-1.5 bg-slate-900 rounded border border-slate-800 text-slate-300">
            <span className="text-slate-500 block text-[9px]">LAST SYNC:</span>
            <span>{new Date().toLocaleTimeString()}</span>
          </div>
          <button
            onClick={onTriggerSimulateDelay}
            className="px-3 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 rounded border border-amber-500/40 font-bold text-xs flex items-center gap-1.5 transition"
          >
            <AlertTriangle className="w-3.5 h-3.5" />
            <span>Simulate Disruption</span>
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3 font-mono">
        <div className="p-3.5 bg-[#121826] rounded border border-slate-800 relative overflow-hidden">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">OPERATING SITES</div>
          <div className="text-2xl font-bold text-white mt-1">{overviewData.totalSites || 12}</div>
          <div className="text-[9px] text-slate-500 mt-1 flex items-center justify-between">
            <span>EMEA / AMER / APAC</span>
            <span className="text-emerald-400 font-bold">100% ONLINE</span>
          </div>
        </div>

        <div className="p-3.5 bg-[#121826] rounded border border-slate-800">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">ACTIVE MFG PLANTS</div>
          <div className="text-2xl font-bold text-sky-400 mt-1">{overviewData.activeManufacturing || 8}</div>
          <div className="text-[9px] text-slate-500 mt-1 flex items-center justify-between">
            <span>OEE AVG: 91.2%</span>
            <span className="text-sky-400 font-bold">NOMINAL</span>
          </div>
        </div>

        <div className="p-3.5 bg-[#121826] rounded border border-slate-800">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">ACTIVE BATCHES</div>
          <div className="text-2xl font-bold text-slate-100 mt-1">{overviewData.activeBatchesCount || 14}</div>
          <div className="text-[9px] text-slate-500 mt-1 flex items-center justify-between">
            <span>IN-PROCESS: 12</span>
            <span className="text-amber-400 font-bold">{overviewData.delayedBatchesCount || 0} HOLD</span>
          </div>
        </div>

        <div className="p-3.5 bg-[#121826] rounded border border-slate-800">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">RESEARCH R&D</div>
          <div className="text-2xl font-bold text-emerald-400 mt-1">{overviewData.activeResearchProgrammes || 18}</div>
          <div className="text-[9px] text-slate-500 mt-1 flex items-center justify-between">
            <span>PHASE III: 4</span>
            <span className="text-emerald-400 font-bold">ON TRACK</span>
          </div>
        </div>

        <div className="p-3.5 bg-[#121826] rounded border border-slate-800">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">QMS EVENTS</div>
          <div className="text-2xl font-bold text-amber-400 mt-1">{overviewData.openQualityIncidents || 2}</div>
          <div className="text-[9px] text-slate-500 mt-1 flex items-center justify-between">
            <span>TRIAGE REQUIRED</span>
            <span className="text-amber-400 font-bold">ACTIVE</span>
          </div>
        </div>

        <div className="p-3.5 bg-[#121826] rounded border border-slate-800">
          <div className="text-[10px] text-slate-400 uppercase tracking-wider">RISK EXPOSURE</div>
          <div className="text-xl font-bold text-rose-400 mt-1">€4.2M</div>
          <div className="text-[9px] text-slate-500 mt-1 flex items-center justify-between">
            <span>2 CRITICAL RISKS</span>
            <span className="text-rose-400 font-bold">MITIGATING</span>
          </div>
        </div>
      </div>

      {/* Organizational Hierarchy & Division Breakdown Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Organisational Hierarchy Panel */}
        <div className="lg:col-span-2 bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <h2 className="text-sm font-bold font-mono tracking-wide text-white">ORGANISATIONAL OPERATING HIERARCHY</h2>
              <p className="text-xs text-slate-400">Drill down from Division to Sites, Assets, and Active Batches</p>
            </div>
            <div className="flex items-center gap-1.5 bg-slate-900 p-1 rounded border border-slate-800">
              <button
                onClick={() => setSelectedDivisionTab('PHARMA')}
                className={`px-2.5 py-1 text-xs font-mono font-medium rounded transition ${
                  selectedDivisionTab === 'PHARMA' ? 'bg-sky-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Pharmaceuticals
              </button>
              <button
                onClick={() => setSelectedDivisionTab('CROP_SCIENCE')}
                className={`px-2.5 py-1 text-xs font-mono font-medium rounded transition ${
                  selectedDivisionTab === 'CROP_SCIENCE' ? 'bg-amber-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Crop Science
              </button>
              <button
                onClick={() => setSelectedDivisionTab('CONSUMER_HEALTH')}
                className={`px-2.5 py-1 text-xs font-mono font-medium rounded transition ${
                  selectedDivisionTab === 'CONSUMER_HEALTH' ? 'bg-rose-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Consumer Health
              </button>
            </div>
          </div>

          {/* Sites Grid for Selected Division */}
          <div className="space-y-3">
            {filteredSites.map((site) => (
              <div
                key={site.id}
                onClick={() => onSelectSite(site.id)}
                className="p-4 bg-slate-900/90 hover:bg-slate-800/90 rounded border border-slate-800 hover:border-slate-700 transition cursor-pointer flex flex-wrap items-center justify-between gap-3 group"
              >
                <div className="flex items-start gap-3">
                  <div className="p-2.5 rounded bg-slate-800 text-emerald-400 group-hover:bg-emerald-500/10 transition">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold font-mono text-sm text-white group-hover:text-emerald-300 transition">
                        {site.name}
                      </span>
                      <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                        {site.code}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-slate-500" />
                        {site.city}, {site.country}
                      </span>
                      <span>•</span>
                      <span>{site.type}</span>
                    </div>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {site.capabilities.slice(0, 3).map((cap, i) => (
                        <span key={i} className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-950 text-slate-300 border border-slate-800">
                          {cap}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-right font-mono text-xs">
                  <div>
                    <span className="text-slate-500 block text-[10px]">WORKFORCE:</span>
                    <span className="text-slate-200 font-bold">{site.workforceCount.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block text-[10px]">RISK SCORE:</span>
                    <span className={`font-bold ${site.riskScore > 30 ? 'text-amber-400' : 'text-emerald-400'}`}>
                      {site.riskScore}/100
                    </span>
                  </div>
                  <ChevronRight className="w-5 h-5 text-slate-600 group-hover:text-white transition" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Global Operational Activity Stream & Sustainability Summary */}
        <div className="space-y-6">
          {/* Active Batches Stream */}
          <div className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-3">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h2 className="text-xs font-bold font-mono text-slate-300 uppercase tracking-wider">ACTIVE BATCH MONITORING</h2>
              <span className="text-[10px] font-mono text-emerald-400">REAL-TIME SCADA</span>
            </div>

            <div className="space-y-2 font-mono text-xs">
              {batches.map((batch) => (
                <div
                  key={batch.id}
                  className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-white">{batch.batchNumber}</span>
                    <span
                      className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                        batch.status === 'DELAYED' || batch.status === 'QUALITY_HOLD'
                          ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                          : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      }`}
                    >
                      {batch.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-300 font-sans truncate">{batch.productName}</div>
                  <div className="text-[10px] text-slate-400 flex items-center justify-between pt-1">
                    <span>{batch.siteName.split(' ')[0]}</span>
                    <span>PROGRESS: {batch.progressPercent}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Environmental Resource Summary */}
          <div className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <h2 className="text-xs font-bold text-slate-300 uppercase tracking-wider">SUSTAINABILITY SNAPSHOT</h2>
              <Leaf className="w-4 h-4 text-emerald-400" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between p-2 bg-slate-900 rounded">
                <span className="text-slate-400 text-[11px]">ENERGY CONSUMPTION:</span>
                <span className="text-slate-100 font-bold">425.5 MWh</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-900 rounded">
                <span className="text-slate-400 text-[11px]">RENEWABLE ENERGY SHARE:</span>
                <span className="text-emerald-400 font-bold">78.4%</span>
              </div>
              <div className="flex items-center justify-between p-2 bg-slate-900 rounded">
                <span className="text-slate-400 text-[11px]">WATER INTENSITY:</span>
                <span className="text-sky-400 font-bold">59,800 m³</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
