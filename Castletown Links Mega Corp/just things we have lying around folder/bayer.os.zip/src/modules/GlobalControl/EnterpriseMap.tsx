import React, { useState } from 'react';
import { MapPin, Building2, Factory, Activity, AlertTriangle, ShieldCheck, Zap, Droplet, Users, ChevronRight, X } from 'lucide-react';
import { Site, DivisionId } from '../../types';

interface EnterpriseMapProps {
  sites: Site[];
  onSelectSite: (siteId: string) => void;
}

export const EnterpriseMap: React.FC<EnterpriseMapProps> = ({ sites, onSelectSite }) => {
  const [selectedDivisionFilter, setSelectedDivisionFilter] = useState<string>('ALL');
  const [selectedSite, setSelectedSite] = useState<Site | null>(sites[0] || null);

  const filteredSites = sites.filter((site) => {
    if (selectedDivisionFilter !== 'ALL' && site.division !== selectedDivisionFilter) return false;
    return true;
  });

  return (
    <div className="p-6 space-y-6 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* Top Controls */}
      <div className="p-4 bg-[#121826] rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-mono text-white">ENTERPRISE DIGITAL TWIN MAP</h1>
          <p className="text-xs text-slate-400">Global Operating Network • Research Labs, Manufacturing Sites, & Logistics Nodes</p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-400">FILTER DIVISION:</span>
          <select
            value={selectedDivisionFilter}
            onChange={(e) => setSelectedDivisionFilter(e.target.value)}
            className="bg-slate-900 text-slate-200 border border-slate-700 rounded px-3 py-1.5 font-mono text-xs focus:outline-none"
          >
            <option value="ALL">All Divisions (12 Sites)</option>
            <option value="PHARMA">Pharmaceuticals Division</option>
            <option value="CROP_SCIENCE">Crop Science Division</option>
            <option value="CONSUMER_HEALTH">Consumer Health Division</option>
          </select>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Technical SVG World Grid Map Representation */}
        <div className="lg:col-span-2 bg-[#0B132B] p-5 rounded-lg border border-slate-800 space-y-4 relative min-h-[480px]">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3 font-mono text-xs">
            <span className="text-slate-400">GLOBAL GEOPATIAL GRID [WGS-84]</span>
            <span className="text-emerald-400">ACTIVE NODES: {filteredSites.length}</span>
          </div>

          {/* SVG Technical World Map Representation */}
          <div className="relative w-full h-[400px] bg-[#0d1733] rounded border border-slate-800/80 overflow-hidden flex items-center justify-center">
            {/* World Grid Lines */}
            <svg className="absolute inset-0 w-full h-full opacity-20 pointer-events-none" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#38bdf8" strokeWidth="0.5" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid)" />
            </svg>

            {/* Simulated Continents Outlines */}
            <svg className="absolute inset-0 w-full h-full opacity-30 text-slate-600 fill-current" viewBox="0 0 1000 500">
              {/* Europe */}
              <path d="M450,120 Q500,100 550,140 T520,200 T440,180 Z" />
              {/* North America */}
              <path d="M150,100 Q250,80 320,180 T200,280 T120,180 Z" />
              {/* Asia */}
              <path d="M600,100 Q800,80 880,220 T700,300 T580,180 Z" />
              {/* Latin America */}
              <path d="M280,300 Q350,320 320,440 T240,400 Z" />
            </svg>

            {/* Site Plot Nodes */}
            {filteredSites.map((site) => {
              // Convert lat/lng to approximate SVG % coordinates
              const x = ((site.coordinates[1] + 180) / 360) * 100;
              const y = ((90 - site.coordinates[0]) / 180) * 100;
              const isSelected = selectedSite?.id === site.id;

              return (
                <button
                  key={site.id}
                  onClick={() => setSelectedSite(site)}
                  style={{ left: `${x}%`, top: `${y}%` }}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 group z-10"
                >
                  <span className={`relative flex h-4 w-4`}>
                    {isSelected && (
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                    )}
                    <span
                      className={`relative inline-flex rounded-full h-4 w-4 border-2 ${
                        isSelected
                          ? 'bg-emerald-500 border-white shadow-lg shadow-emerald-500/50'
                          : site.riskScore > 20
                          ? 'bg-amber-500 border-slate-900'
                          : 'bg-sky-500 border-slate-900'
                      }`}
                    />
                  </span>
                  {/* Tooltip on Hover */}
                  <div className="absolute left-1/2 bottom-full mb-2 -translate-x-1/2 hidden group-hover:flex flex-col items-center pointer-events-none z-30">
                    <div className="bg-slate-900 text-slate-100 font-mono text-[10px] px-2 py-1 rounded border border-slate-700 shadow-xl whitespace-nowrap">
                      {site.name} ({site.code})
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 text-xs font-mono flex items-center justify-between text-slate-400">
            <span>MAP LEGEND:</span>
            <div className="flex items-center gap-4 text-[11px]">
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-sky-500" /> Optimal Site</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> Elevated Risk</span>
              <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> Selected Twin</span>
            </div>
          </div>
        </div>

        {/* Selected Site Digital Twin Operational Panel */}
        {selectedSite ? (
          <div className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-4 font-sans text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                  {selectedSite.code}
                </span>
                <h2 className="text-base font-bold font-mono text-white mt-1">{selectedSite.name}</h2>
                <p className="text-slate-400 text-xs">{selectedSite.city}, {selectedSite.country} ({selectedSite.region})</p>
              </div>
            </div>

            <div className="space-y-3 font-mono text-xs">
              <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1">
                <div className="text-slate-400 text-[10px]">OPERATIONAL STATE:</div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">{selectedSite.type}</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    selectedSite.status === 'DISRUPTED' ? 'bg-rose-500/20 text-rose-300' : 'bg-emerald-500/20 text-emerald-300'
                  }`}>
                    {selectedSite.status}
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">WORKFORCE:</span>
                  <span className="text-slate-100 font-bold">{selectedSite.workforceCount.toLocaleString()}</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">ACTIVE LINES:</span>
                  <span className="text-sky-400 font-bold">{selectedSite.activeLinesCount}</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">ENERGY (kWh):</span>
                  <span className="text-slate-100 font-bold">{selectedSite.energyConsumptionKWh.toLocaleString()}</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">RISK SCORE:</span>
                  <span className={`font-bold ${selectedSite.riskScore > 20 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {selectedSite.riskScore}/100
                  </span>
                </div>
              </div>

              <div>
                <span className="text-slate-400 block text-[10px] mb-1">PLANT CAPABILITIES & CERTIFICATIONS:</span>
                <div className="flex flex-wrap gap-1">
                  {selectedSite.capabilities.map((cap, i) => (
                    <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                      {cap}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800">
              <button
                onClick={() => onSelectSite(selectedSite.id)}
                className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold rounded text-xs transition flex items-center justify-center gap-2"
              >
                <span>OPEN FULL SITE DIGITAL TWIN</span>
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        ) : (
          <div className="bg-[#121826] p-5 rounded-lg border border-slate-800 flex items-center justify-center text-slate-500 font-mono text-xs">
            Select a site node on the grid to open its operational twin.
          </div>
        )}
      </div>
    </div>
  );
};
