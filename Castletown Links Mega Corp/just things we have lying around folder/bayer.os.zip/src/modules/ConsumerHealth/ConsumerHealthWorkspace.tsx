import React from 'react';
import { Package, TrendingUp, ShoppingBag, CheckCircle2 } from 'lucide-react';
import { ConsumerHealthProduct } from '../../types';

interface ConsumerHealthWorkspaceProps {
  products: ConsumerHealthProduct[];
}

export const ConsumerHealthWorkspace: React.FC<ConsumerHealthWorkspaceProps> = ({ products }) => {
  return (
    <div className="p-6 space-y-6 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* Header */}
      <div className="p-4 bg-[#121826] rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-mono text-white">CONSUMER HEALTH BRAND PORTFOLIO</h1>
          <p className="text-xs text-slate-400">Aleve, Bepanthen, Claritin, Berocca & Global OTC Market Supply</p>
        </div>

        <div className="font-mono text-xs text-right text-slate-400">
          <span>GLOBAL OTC AVAILABILITY: </span>
          <span className="text-rose-400 font-bold text-sm">92+ COUNTRIES</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {products.map((prod) => (
          <div key={prod.id} className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 text-[10px] font-bold">
                {prod.category}
              </span>
              <span className="text-emerald-400 font-bold">{prod.marketAvailabilityCountries} Countries</span>
            </div>

            <div>
              <h2 className="text-base font-sans font-bold text-white">{prod.brandName}</h2>
              <p className="text-xs text-slate-400 mt-0.5">{prod.primaryActiveIngredient}</p>
            </div>

            <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1.5 text-[11px]">
              <div className="flex justify-between">
                <span className="text-slate-400">MONTHLY DEMAND VELOCITY:</span>
                <span className="text-sky-400 font-bold">{(prod.monthlyDemandUnits / 1000000).toFixed(1)}M Units</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">INVENTORY COVERAGE:</span>
                <span className="text-emerald-400 font-bold">{prod.inventoryCoverageDays} Days</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">MFG PLANT:</span>
                <span className="text-slate-200">{prod.manufacturingSite.split(' ')[0]}</span>
              </div>
            </div>

            <div>
              <span className="text-[10px] text-slate-400 block mb-1">PACKAGING VARIANTS:</span>
              <div className="flex flex-wrap gap-1">
                {prod.packagingVariants.map((v, i) => (
                  <span key={i} className="text-[10px] px-2 py-0.5 rounded bg-slate-900 text-slate-300 border border-slate-800">
                    {v}
                  </span>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
