import React, { useState } from 'react';
import { 
  Factory, 
  Workflow, 
  GitBranch, 
  AlertTriangle, 
  ShieldCheck, 
  Activity, 
  Zap, 
  CheckCircle2, 
  Clock, 
  ChevronRight,
  Sliders,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { Site, ProductionLine, Batch, Asset } from '../../types';

interface ManufacturingDigitalTwinProps {
  sites: Site[];
  productionLines: ProductionLine[];
  batches: Batch[];
  selectedSiteId?: string;
  onSelectSite: (siteId: string) => void;
  onTriggerSimulateDelay: (batchId: string) => void;
}

export const ManufacturingDigitalTwin: React.FC<ManufacturingDigitalTwinProps> = ({
  sites,
  productionLines,
  batches,
  selectedSiteId = 'SITE-LEV-01',
  onSelectSite,
  onTriggerSimulateDelay,
}) => {
  const [activeLineId, setActiveLineId] = useState<string>('LINE-LEV-ALPHA');
  const [activeTab, setActiveTab] = useState<'LINE_TWIN' | 'BATCH_TRACEABILITY' | 'ASSETS'>('LINE_TWIN');

  const selectedSite = sites.find((s) => s.id === selectedSiteId) || sites[0];
  const siteLines = productionLines.filter((l) => l.siteId === selectedSite.id);
  const activeLine = siteLines.find((l) => l.id === activeLineId) || siteLines[0] || productionLines[0];
  const activeBatch = batches.find((b) => b.id === activeLine?.currentBatchId) || batches[0];

  return (
    <div className="p-6 space-y-6 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* Top Header & Site Switcher */}
      <div className="p-4 bg-[#121826] rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold font-mono text-white">INDUSTRIAL OPERATIONS & SITE DIGITAL TWIN</h1>
            <span className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 font-mono text-[10px] font-bold border border-sky-500/30">
              SCADA PLC CONNECTED
            </span>
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-Time Production Line Telemetry, Asset Health Sensors, and Batch Traceability
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-400">SELECT SITE:</span>
            <select
              value={selectedSite.id}
              onChange={(e) => onSelectSite(e.target.value)}
              className="bg-slate-900 text-slate-200 border border-slate-700 rounded px-3 py-1.5 font-mono text-xs focus:outline-none"
            >
              {sites.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.code})
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => onTriggerSimulateDelay(activeBatch?.id || 'BATCH-BAY-2026-X9402')}
            className="px-3.5 py-1.5 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/40 rounded font-mono font-bold text-xs flex items-center gap-1.5 transition"
          >
            <AlertTriangle className="w-4 h-4 text-amber-400" />
            <span>Simulate Delay on Active Batch</span>
          </button>
        </div>
      </div>

      {/* View Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-2 font-mono text-xs">
        <button
          onClick={() => setActiveTab('LINE_TWIN')}
          className={`px-4 py-2 rounded transition font-bold flex items-center gap-2 ${
            activeTab === 'LINE_TWIN' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Workflow className="w-4 h-4" />
          <span>Production Line Process Flow</span>
        </button>
        <button
          onClick={() => setActiveTab('BATCH_TRACEABILITY')}
          className={`px-4 py-2 rounded transition font-bold flex items-center gap-2 ${
            activeTab === 'BATCH_TRACEABILITY' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <GitBranch className="w-4 h-4" />
          <span>Batch Traceability Chain</span>
        </button>
        <button
          onClick={() => setActiveTab('ASSETS')}
          className={`px-4 py-2 rounded transition font-bold flex items-center gap-2 ${
            activeTab === 'ASSETS' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-slate-400 hover:text-white'
          }`}
        >
          <Zap className="w-4 h-4" />
          <span>Line Equipment & Telemetry</span>
        </button>
      </div>

      {/* Production Line Selection Selector Bar */}
      {siteLines.length > 0 && (
        <div className="p-3 bg-[#121826] rounded-lg border border-slate-800 flex items-center gap-3 overflow-x-auto font-mono text-xs">
          <span className="text-slate-400 shrink-0">LINES:</span>
          {siteLines.map((line) => (
            <button
              key={line.id}
              onClick={() => setActiveLineId(line.id)}
              className={`px-3 py-1.5 rounded border transition shrink-0 flex items-center gap-2 ${
                activeLine?.id === line.id
                  ? 'bg-slate-800 border-emerald-500 text-white font-bold'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>{line.name}</span>
              <span
                className={`w-2 h-2 rounded-full ${
                  line.status === 'DELAYED_DISRUPTED' ? 'bg-amber-400 animate-ping' : 'bg-emerald-400'
                }`}
              />
            </button>
          ))}
        </div>
      )}

      {/* TAB 1: PRODUCTION LINE PROCESS FLOW DIAGRAM */}
      {activeTab === 'LINE_TWIN' && activeLine && (
        <div className="space-y-6">
          {/* Active Batch Summary Banner */}
          {activeBatch && (
            <div className="p-4 bg-slate-900/90 rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
              <div>
                <span className="text-[10px] text-slate-400 block">ACTIVE BATCH ON LINE:</span>
                <span className="text-base font-bold text-white">{activeBatch.batchNumber} - {activeBatch.productName}</span>
              </div>
              <div className="flex items-center gap-4">
                <div>
                  <span className="text-slate-400 block text-[10px]">PROGRESS:</span>
                  <span className="text-sky-400 font-bold text-sm">{activeBatch.progressPercent}%</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">STATUS:</span>
                  <span
                    className={`px-2 py-0.5 rounded font-bold ${
                      activeBatch.status === 'DELAYED' ? 'bg-amber-500/20 text-amber-300' : 'bg-emerald-500/20 text-emerald-300'
                    }`}
                  >
                    {activeBatch.status}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Interactive Technical Stage Process Flow Diagram */}
          <div className="bg-[#0B132B] p-6 rounded-lg border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 font-mono text-xs">
              <span className="text-slate-300 font-bold">STAGES: RAW INTAKE → REACTION → ULTRAFILTRATION → LYOPHILIZATION → FILLING → INSPECTION → RELEASE</span>
              <span className="text-emerald-400">OEE: {activeLine.efficiencyOEE}%</span>
            </div>

            {/* Stages Grid Flow */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
              {activeLine.stages.map((stage) => {
                const isCompleted = stage.status === 'COMPLETED';
                const isInProgress = stage.status === 'IN_PROGRESS';
                const isDelayed = stage.status === 'CRITICAL_DELAY';

                return (
                  <div
                    key={stage.stageNumber}
                    className={`p-3 rounded border transition font-mono text-xs flex flex-col justify-between space-y-2 ${
                      isDelayed
                        ? 'bg-amber-500/10 border-amber-500 text-amber-200 animate-pulse'
                        : isInProgress
                        ? 'bg-sky-500/10 border-sky-500 text-white'
                        : isCompleted
                        ? 'bg-slate-900 border-slate-800 text-slate-300'
                        : 'bg-slate-950 border-slate-900 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[10px]">
                      <span className="font-bold">STAGE 0{stage.stageNumber}</span>
                      <span
                        className={`w-2 h-2 rounded-full ${
                          isDelayed
                            ? 'bg-amber-400'
                            : isInProgress
                            ? 'bg-sky-400 animate-ping'
                            : isCompleted
                            ? 'bg-emerald-400'
                            : 'bg-slate-700'
                        }`}
                      />
                    </div>

                    <div className="font-sans font-bold text-xs leading-snug">{stage.name}</div>

                    <div className="pt-2 border-t border-slate-800/80 text-[10px] space-y-0.5 text-slate-400 font-mono">
                      {stage.temperatureCelsius !== undefined && (
                        <div>TEMP: {stage.temperatureCelsius}°C</div>
                      )}
                      {stage.pressureBar !== undefined && (
                        <div>PRESS: {stage.pressureBar} bar</div>
                      )}
                      <div>STATUS: {stage.status}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: BATCH TRACEABILITY CHAIN & MATERIALS */}
      {activeTab === 'BATCH_TRACEABILITY' && activeBatch && (
        <div className="space-y-6">
          <div className="p-5 bg-[#121826] rounded-lg border border-slate-800 space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold">CRYPTO TRACEABILITY HASH</span>
                <h2 className="text-base font-bold font-mono text-white">{activeBatch.traceabilityHash}</h2>
              </div>
              <span className="px-3 py-1 rounded bg-slate-900 text-slate-300 font-mono text-xs border border-slate-800">
                BATCH #{activeBatch.batchNumber}
              </span>
            </div>

            {/* Material Inputs Table */}
            <div className="space-y-2">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase">1. VERIFIED RAW MATERIAL INPUTS & LOTS</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left font-mono text-xs">
                  <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="p-2.5">MATERIAL CODE</th>
                      <th className="p-2.5">NAME</th>
                      <th className="p-2.5">SUPPLIER</th>
                      <th className="p-2.5">LOT NUMBER</th>
                      <th className="p-2.5">QTY USED</th>
                      <th className="p-2.5">QC CERT</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {activeBatch.materialInputs.map((mat) => (
                      <tr key={mat.materialId} className="hover:bg-slate-900/50">
                        <td className="p-2.5 font-bold text-sky-400">{mat.code}</td>
                        <td className="p-2.5 text-slate-200 font-sans">{mat.name}</td>
                        <td className="p-2.5 text-slate-300">{mat.supplierName}</td>
                        <td className="p-2.5 text-emerald-400 font-bold">{mat.lotNumber}</td>
                        <td className="p-2.5 text-slate-300">{mat.quantityUsedKg} kg</td>
                        <td className="p-2.5">
                          <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                            VERIFIED
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Quality Checkpoints Table */}
            <div className="space-y-2 pt-2">
              <h3 className="text-xs font-mono font-bold text-slate-300 uppercase">2. QUALITY CONTROL RELEASE CHECKPOINTS</h3>
              <div className="overflow-x-auto">
                <table className="w-full text-left font-mono text-xs">
                  <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
                    <tr>
                      <th className="p-2.5">CHECKPOINT</th>
                      <th className="p-2.5">STAGE</th>
                      <th className="p-2.5">PARAMETER SPECIFICATION</th>
                      <th className="p-2.5">MEASURED VALUE</th>
                      <th className="p-2.5">STATUS</th>
                      <th className="p-2.5">TESTED BY</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/80">
                    {activeBatch.qualityCheckpoints.map((qc) => (
                      <tr key={qc.checkpointId} className="hover:bg-slate-900/50">
                        <td className="p-2.5 font-bold text-white">{qc.name}</td>
                        <td className="p-2.5 text-slate-400">{qc.stageName}</td>
                        <td className="p-2.5 text-slate-300">{qc.parameter}</td>
                        <td className="p-2.5 text-sky-400 font-bold">{qc.measuredValue}</td>
                        <td className="p-2.5">
                          <span
                            className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                              qc.status === 'PASS' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-amber-500/20 text-amber-300'
                            }`}
                          >
                            {qc.status}
                          </span>
                        </td>
                        <td className="p-2.5 text-slate-400">{qc.testedBy}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: LINE ASSETS & SENSOR TELEMETRY */}
      {activeTab === 'ASSETS' && activeLine && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {activeLine.assets.map((ast) => (
            <div key={ast.id} className="p-4 bg-[#121826] rounded-lg border border-slate-800 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-sky-400 font-bold">{ast.assetCode}</span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                  HEALTH: {ast.healthScore}%
                </span>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-white">{ast.name}</h3>
                <p className="text-[11px] text-slate-400">{ast.manufacturer} • {ast.assetType}</p>
              </div>

              <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">VIBRATION SENSOR:</span>
                  <span className="text-slate-200 font-bold">{ast.vibrationMmS} mm/s</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">OPERATING TEMP:</span>
                  <span className="text-slate-200 font-bold">{ast.operatingTempC}°C</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">FAILURE RISK:</span>
                  <span className="text-emerald-400 font-bold">{(ast.failureRiskProbability * 100).toFixed(1)}%</span>
                </div>
              </div>

              <div className="text-[10px] text-slate-500 pt-1 flex justify-between">
                <span>NEXT MAINT: {ast.nextScheduledMaintenance}</span>
                <span>WORK ORDERS: {ast.openWorkOrdersCount}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
