import React, { useState } from 'react';
import { Database, BrainCircuit, Microscope, Sparkles, CheckCircle2 } from 'lucide-react';
import { ScientificDataset, AIModelRecord } from '../../types';

interface ScienceAndAnalyticsWorkspaceProps {
  datasets: ScientificDataset[];
  aiModels: AIModelRecord[];
}

export const ScienceAndAnalyticsWorkspace: React.FC<ScienceAndAnalyticsWorkspaceProps> = ({
  datasets,
  aiModels,
}) => {
  const [activeTab, setActiveTab] = useState<'DATASETS' | 'AI_MODELS'>('DATASETS');

  return (
    <div className="p-6 space-y-6 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* Header */}
      <div className="p-4 bg-[#121826] rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-mono text-white">SCIENCE, DATA & AI MODEL GOVERNANCE</h1>
          <p className="text-xs text-slate-400">High-Throughput Genomic Datasets, Molecular Graphs & Predictive AI Registry</p>
        </div>

        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded border border-slate-800 font-mono text-xs">
          <button
            onClick={() => setActiveTab('DATASETS')}
            className={`px-3 py-1.5 rounded transition ${
              activeTab === 'DATASETS' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Scientific Datasets ({datasets.length})
          </button>
          <button
            onClick={() => setActiveTab('AI_MODELS')}
            className={`px-3 py-1.5 rounded transition ${
              activeTab === 'AI_MODELS' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            AI Models Registry ({aiModels.length})
          </button>
        </div>
      </div>

      {activeTab === 'DATASETS' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {datasets.map((ds) => (
            <div key={ds.id} className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-sky-400 font-bold">{ds.datasetCode}</span>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                  {ds.domain}
                </span>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-white">{ds.title}</h3>
                <p className="text-[11px] text-slate-400">Lead: {ds.leadScientist}</p>
              </div>

              <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">RECORD COUNT:</span>
                  <span className="text-slate-100 font-bold">{ds.recordsCount.toLocaleString()}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">PROVENANCE:</span>
                  <span className="text-slate-200 font-bold">{ds.provenanceSource}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">LAST UPDATED:</span>
                  <span className="text-slate-300">{ds.lastUpdated}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'AI_MODELS' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {aiModels.map((model) => (
            <div key={model.id} className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-emerald-400 font-bold">{model.modelCode}</span>
                <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">
                  VER: {model.modelVersion}
                </span>
              </div>

              <div>
                <h3 className="font-sans font-bold text-sm text-white">{model.name}</h3>
                <p className="text-[11px] text-slate-400">Domain: {model.domain}</p>
              </div>

              <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1.5 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">ACCURACY METRIC:</span>
                  <span className="text-emerald-400 font-bold">{model.accuracyMetric}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">DRIFT STATUS:</span>
                  <span className="text-sky-400 font-bold">{model.driftIndicator}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">DEPLOYMENT:</span>
                  <span className="text-amber-400 font-bold">{model.deploymentStatus}</span>
                </div>
              </div>

              <div className="p-2.5 bg-slate-900/90 rounded border border-slate-800 text-[11px] text-slate-300 font-sans">
                <span className="font-mono text-slate-400 block text-[10px] mb-0.5">EXPLAINABILITY SUMMARY:</span>
                {model.explainabilitySummary}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
