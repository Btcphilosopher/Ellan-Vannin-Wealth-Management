import React, { useState } from 'react';
import { ShieldCheck, AlertTriangle, FileCheck2, UserCheck, CheckCircle2, Clock } from 'lucide-react';
import { QualityEvent } from '../../types';

interface QualityManagementSystemProps {
  qualityEvents: QualityEvent[];
  onTriageQualityEvent: (eventId: string, status: QualityEvent['status'], rootCause: string, owner: string) => Promise<any>;
}

export const QualityManagementSystem: React.FC<QualityManagementSystemProps> = ({
  qualityEvents,
  onTriageQualityEvent,
}) => {
  const [selectedEvent, setSelectedEvent] = useState<QualityEvent | null>(qualityEvents[0] || null);
  const [statusInput, setStatusInput] = useState<QualityEvent['status']>(selectedEvent?.status || 'TRIAGE');
  const [rootCauseInput, setRootCauseInput] = useState<string>(selectedEvent?.rootCauseAnalysis || '');
  const [ownerInput, setOwnerInput] = useState<string>(selectedEvent?.assignedOwner || '');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);

  const handleTriageSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedEvent) return;
    setIsSubmitting(true);
    try {
      await onTriageQualityEvent(selectedEvent.id, statusInput, rootCauseInput, ownerInput);
      alert('QMS Quality Event triaged and audit event recorded.');
    } catch (err: any) {
      alert('Error triaging quality event: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="p-6 space-y-6 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* Header */}
      <div className="p-4 bg-[#121826] rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-mono text-white">QUALITY MANAGEMENT SYSTEM (QMS & CAPA)</h1>
          <p className="text-xs text-slate-400">cGMP / Annex 11 Compliant Quality Deviations, Investigations & CAPA Workflows</p>
        </div>

        <div className="font-mono text-xs text-amber-400 font-bold">
          TOTAL QUALITY INCIDENTS: {qualityEvents.length}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quality Events List */}
        <div className="lg:col-span-2 bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 font-mono text-xs">
            <span className="text-slate-300 font-bold">QUALITY DEVIATIONS & INCIDENTS</span>
            <span className="text-emerald-400">cGMP AUDITABLE</span>
          </div>

          <div className="space-y-2">
            {qualityEvents.map((evt) => (
              <div
                key={evt.id}
                onClick={() => {
                  setSelectedEvent(evt);
                  setStatusInput(evt.status);
                  setRootCauseInput(evt.rootCauseAnalysis);
                  setOwnerInput(evt.assignedOwner);
                }}
                className={`p-3.5 rounded border transition cursor-pointer font-mono text-xs space-y-2 ${
                  selectedEvent?.id === evt.id
                    ? 'bg-slate-800 border-sky-500 shadow-sm'
                    : 'bg-slate-900 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="text-sky-400 font-bold">{evt.eventNumber}</span>
                    <span className="font-sans font-bold text-white text-xs">{evt.title}</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    evt.severity === 'CRITICAL' ? 'bg-rose-500/20 text-rose-300' : 'bg-amber-500/20 text-amber-300'
                  }`}>
                    {evt.severity}
                  </span>
                </div>

                <div className="text-[11px] text-slate-400 font-sans">{evt.rootCauseAnalysis}</div>

                <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-800">
                  <span>SITE: {evt.originSite}</span>
                  <span>OWNER: {evt.assignedOwner}</span>
                  <span className="text-emerald-400 font-bold">STATUS: {evt.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quality Triage Workflow Form */}
        {selectedEvent ? (
          <form onSubmit={handleTriageSubmit} className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-4 font-sans text-xs">
            <div className="border-b border-slate-800 pb-3">
              <span className="text-[10px] font-mono text-sky-400 uppercase font-bold">QMS TRIAGE WORKFLOW</span>
              <h2 className="text-sm font-bold font-mono text-white mt-1">{selectedEvent.eventNumber}: {selectedEvent.title}</h2>
              <p className="text-slate-400 text-xs">Origin Site: {selectedEvent.originSite}</p>
            </div>

            <div>
              <label className="block text-slate-300 font-mono font-bold mb-1">QUALITY WORKFLOW STATUS:</label>
              <select
                value={statusInput}
                onChange={(e) => setStatusInput(e.target.value as QualityEvent['status'])}
                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-sky-500"
              >
                <option value="OPENED">OPENED</option>
                <option value="TRIAGE">TRIAGE & ASSIGNMENT</option>
                <option value="INVESTIGATION">INVESTIGATION IN PROGRESS</option>
                <option value="ACTION_PLAN">CAPA ACTION PLAN DEFINED</option>
                <option value="REVIEW">QA FINAL REVIEW</option>
                <option value="CLOSED">CLOSED & RELEASED</option>
              </select>
            </div>

            <div>
              <label className="block text-slate-300 font-mono font-bold mb-1">ASSIGNED QUALITY ASSURANCE LEAD:</label>
              <input
                type="text"
                value={ownerInput}
                onChange={(e) => setOwnerInput(e.target.value)}
                placeholder="e.g. Dr. M. Schneider (Lead QA Auditor)"
                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-sky-500"
                required
              />
            </div>

            <div>
              <label className="block text-slate-300 font-mono font-bold mb-1">ROOT CAUSE ANALYSIS & CAPA PLAN:</label>
              <textarea
                rows={4}
                value={rootCauseInput}
                onChange={(e) => setRootCauseInput(e.target.value)}
                placeholder="Detail sterile micro-excursion investigation, environmental sampling results, and corrective action..."
                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white text-xs focus:outline-none focus:border-sky-500"
                required
              />
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold rounded text-xs transition disabled:opacity-50"
            >
              {isSubmitting ? 'TRIAGING INCIDENT...' : 'UPDATE QMS RECORD & LOG AUDIT EVENT'}
            </button>
          </form>
        ) : (
          <div className="bg-[#121826] p-5 rounded-lg border border-slate-800 flex items-center justify-center text-slate-500 font-mono text-xs">
            Select a quality deviation event to perform QMS triage.
          </div>
        )}
      </div>
    </div>
  );
};
