import React, { useState } from 'react';
import { Sprout, Sun, Droplet, Wind, MapPin, Activity, AlertTriangle, ShieldCheck } from 'lucide-react';
import { CropTrial } from '../../types';

interface CropScienceWorkspaceProps {
  cropTrials: CropTrial[];
}

export const CropScienceWorkspace: React.FC<CropScienceWorkspaceProps> = ({ cropTrials }) => {
  const [selectedCrop, setSelectedCrop] = useState<string>('ALL');

  const filteredTrials = cropTrials.filter((t) => selectedCrop === 'ALL' || t.cropType === selectedCrop);

  return (
    <div className="p-6 space-y-6 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* Header */}
      <div className="p-4 bg-[#121826] rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-mono text-white">CROP SCIENCE & AGRONOMIC INTELLIGENCE</h1>
          <p className="text-xs text-slate-400">Short-Stature Corn, Intacta 2 Soybean Traits, Digital Phenotyping & Field Trial Grid</p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-400">SELECT CROP TYPE:</span>
          <select
            value={selectedCrop}
            onChange={(e) => setSelectedCrop(e.target.value)}
            className="bg-slate-900 text-slate-200 border border-slate-700 rounded px-3 py-1.5 font-mono text-xs focus:outline-none"
          >
            <option value="ALL">All Crops (Iowa & Mato Grosso)</option>
            <option value="CORN_MAIZE">Short-Stature Corn (Preceon)</option>
            <option value="SOYBEAN">Intacta 2 Xtend Soybeans</option>
          </select>
        </div>
      </div>

      {/* Field Trials Workspace */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredTrials.map((trial) => (
          <div key={trial.id} className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-4 font-mono text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-2">
              <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold">
                {trial.trialCode}
              </span>
              <span className="text-emerald-400 font-bold">{trial.country}</span>
            </div>

            <div>
              <h2 className="text-base font-sans font-bold text-white">{trial.locationName}</h2>
              <p className="text-xs text-amber-400 mt-0.5">{trial.varietyOrTrait}</p>
            </div>

            {/* Yield Visualizer Box */}
            <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-2">
              <div className="flex items-center justify-between text-[11px]">
                <span className="text-slate-400">ACTUAL YIELD vs BENCHMARK:</span>
                <span className="text-emerald-400 font-bold">
                  +{((trial.yieldBuPerAcreActual - trial.yieldBuPerAcreBenchmark) / trial.yieldBuPerAcreBenchmark * 100).toFixed(1)}% ADVANTAGE
                </span>
              </div>

              {/* Progress Bar Visualizer */}
              <div className="w-full h-3 bg-slate-800 rounded-full overflow-hidden flex">
                <div
                  style={{ width: `${(trial.yieldBuPerAcreBenchmark / 300) * 100}%` }}
                  className="bg-slate-600 h-full"
                  title="Regional Benchmark Yield"
                />
                <div
                  style={{ width: `${((trial.yieldBuPerAcreActual - trial.yieldBuPerAcreBenchmark) / 300) * 100}%` }}
                  className="bg-emerald-500 h-full"
                  title="BAYER Trait Yield Lift"
                />
              </div>

              <div className="flex justify-between text-[10px] text-slate-400 pt-1">
                <span>Benchmark: {trial.yieldBuPerAcreBenchmark} Bu/Acre</span>
                <span className="text-white font-bold">Actual: {trial.yieldBuPerAcreActual} Bu/Acre</span>
              </div>
            </div>

            {/* Weather & Soil Sensor Readings */}
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">SOIL CHARACTERISTICS:</span>
                <span className="text-slate-200 font-bold font-sans">{trial.soilType}</span>
              </div>
              <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">SOIL MOISTURE %:</span>
                <span className="text-sky-400 font-bold">{trial.soilMoisturePct}%</span>
              </div>
            </div>

            <div className="p-2.5 bg-slate-900/90 rounded border border-slate-800 text-[11px] text-slate-300 font-sans">
              <span className="font-mono text-slate-400 block text-[10px] mb-0.5">AGRONOMIC WEATHER NOTES:</span>
              {trial.weatherConditionSummary}
            </div>

            <div className="text-[10px] text-slate-500 border-t border-slate-800 pt-2 flex items-center justify-between">
              <span>PROVENANCE: {trial.dataProvenance}</span>
              <span className="text-emerald-400">SYNTHETIC FEED OK</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
