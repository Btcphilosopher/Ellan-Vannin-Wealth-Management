import React, { useState } from 'react';
import { GitBranch, ShieldAlert, Truck, Thermometer, MapPin, ChevronRight, AlertTriangle } from 'lucide-react';
import { SupplyNode, SupplyRoute, SupplyScenario } from '../../types';

interface SupplyNetworkGraphProps {
  supplyNodes: SupplyNode[];
  supplyRoutes: SupplyRoute[];
  supplyScenarios: SupplyScenario[];
}

export const SupplyNetworkGraph: React.FC<SupplyNetworkGraphProps> = ({
  supplyNodes,
  supplyRoutes,
  supplyScenarios,
}) => {
  const [selectedScenario, setSelectedScenario] = useState<SupplyScenario | null>(supplyScenarios[0] || null);

  return (
    <div className="p-6 space-y-6 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* Header */}
      <div className="p-4 bg-[#121826] rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-mono text-white">GLOBAL SUPPLY NETWORK & DISRUPTION LABORATORY</h1>
          <p className="text-xs text-slate-400">Upstream Raw APIs, Trans-Oceanic Cold Chain Lanes & Regional Distribution Hubs</p>
        </div>

        <div className="font-mono text-xs text-emerald-400 font-bold">
          SUPPLY NETWORK NODES: {supplyNodes.length} | ACTIVE ROUTES: {supplyRoutes.length}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Network Nodes Table */}
        <div className="lg:col-span-2 bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2 font-mono text-xs">
            <span className="text-slate-300 font-bold">GLOBAL SUPPLY NETWORK NODES</span>
            <span className="text-sky-400">LIVE COLD-CHAIN TELEMETRY</span>
          </div>

          <div className="space-y-2">
            {supplyNodes.map((node) => (
              <div key={node.id} className="p-3.5 bg-slate-900 rounded border border-slate-800 space-y-2 font-mono text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-slate-950 text-slate-300 border border-slate-700 text-[10px] font-bold">
                      {node.type}
                    </span>
                    <span className="font-bold text-white font-sans">{node.name}</span>
                  </div>
                  <span className="text-sky-400">{node.location}</span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-[11px] pt-1">
                  <div className="p-2 bg-slate-950 rounded border border-slate-800">
                    <span className="text-slate-500 block text-[9px]">STATUS:</span>
                    <span className={`font-bold ${node.status === 'HEALTHY' ? 'text-emerald-400' : 'text-amber-400'}`}>
                      {node.status}
                    </span>
                  </div>
                  <div className="p-2 bg-slate-950 rounded border border-slate-800">
                    <span className="text-slate-500 block text-[9px]">INVENTORY LEVEL:</span>
                    <span className="text-sky-400 font-bold">{node.inventoryLevelPct}%</span>
                  </div>
                  <div className="p-2 bg-slate-950 rounded border border-slate-800">
                    <span className="text-slate-500 block text-[9px]">LEAD TIME:</span>
                    <span className="text-slate-200 font-bold">{node.leadTimeDays} Days</span>
                  </div>
                  <div className="p-2 bg-slate-950 rounded border border-slate-800">
                    <span className="text-slate-500 block text-[9px]">SINGLE SOURCE:</span>
                    <span className="text-amber-400 font-bold">{node.singleSourceDependency ? 'YES' : 'NO'}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Disruption Scenario Laboratory Panel */}
        {selectedScenario ? (
          <div className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-4 font-sans text-xs">
            <div className="border-b border-slate-800 pb-3">
              <span className="text-[10px] font-mono text-amber-400 uppercase font-bold">SCENARIO LABORATORY</span>
              <h2 className="text-sm font-bold font-mono text-white mt-1">{selectedScenario.title}</h2>
              <span className="text-slate-400 text-xs">Location: {selectedScenario.affectedLocation}</span>
            </div>

            <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1 font-mono text-[11px]">
              <div className="text-slate-400">ESTIMATED FINANCIAL IMPACT:</div>
              <div className="text-rose-400 text-base font-bold">
                €{(selectedScenario.financialImpactEUR / 1000000).toFixed(1)}M
              </div>
              <div className="text-slate-400 text-[10px] pt-1">
                ESTIMATED DELAY: {selectedScenario.estimatedDelayDays} DAYS
              </div>
            </div>

            <div>
              <span className="font-mono text-slate-400 text-[10px] block mb-1">AFFECTED PRODUCTS:</span>
              <div className="flex flex-wrap gap-1">
                {selectedScenario.affectedProducts.map((prod: string, i: number) => (
                  <span key={i} className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-slate-200 border border-slate-800">
                    {prod}
                  </span>
                ))}
              </div>
            </div>

            <div className="p-3 bg-slate-900/90 rounded border border-slate-800 space-y-1 font-mono text-[11px] text-slate-300">
              <span className="text-emerald-400 font-bold block mb-1">RECOMMENDED MITIGATION STRATEGY:</span>
              <p className="font-sans text-xs leading-relaxed">{selectedScenario.mitigationStrategy}</p>
            </div>
          </div>
        ) : (
          <div className="bg-[#121826] p-5 rounded-lg border border-slate-800 flex items-center justify-center text-slate-500 font-mono text-xs">
            Select a scenario to evaluate supply disruption mitigations.
          </div>
        )}
      </div>
    </div>
  );
};
