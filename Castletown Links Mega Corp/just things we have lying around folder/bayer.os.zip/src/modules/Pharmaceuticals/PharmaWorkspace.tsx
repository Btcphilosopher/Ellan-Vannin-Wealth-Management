import React, { useState } from 'react';
import { Dna, Microscope, FileCheck2, CheckCircle2, Clock, AlertTriangle, Layers, ChevronRight } from 'lucide-react';
import { PharmaResearchProgramme, ClinicalStudy, RegulatorySubmission } from '../../types';

interface PharmaWorkspaceProps {
  researchProgrammes: PharmaResearchProgramme[];
  clinicalStudies: ClinicalStudy[];
  regulatorySubmissions: RegulatorySubmission[];
}

export const PharmaWorkspace: React.FC<PharmaWorkspaceProps> = ({
  researchProgrammes,
  clinicalStudies,
  regulatorySubmissions,
}) => {
  const [activeTab, setActiveTab] = useState<'RESEARCH' | 'CLINICAL' | 'REGULATORY'>('RESEARCH');

  return (
    <div className="p-6 space-y-6 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* Header */}
      <div className="p-4 bg-[#121826] rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-mono text-white">PHARMACEUTICALS DIVISION WORKSPACE</h1>
          <p className="text-xs text-slate-400">Cardiology, Oncology, Ophthalmology, Radiology & Cell/Gene Therapy R&D Pipeline</p>
        </div>

        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded border border-slate-800 font-mono text-xs">
          <button
            onClick={() => setActiveTab('RESEARCH')}
            className={`px-3 py-1.5 rounded transition ${
              activeTab === 'RESEARCH' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Research Portfolio ({researchProgrammes.length})
          </button>
          <button
            onClick={() => setActiveTab('CLINICAL')}
            className={`px-3 py-1.5 rounded transition ${
              activeTab === 'CLINICAL' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Clinical Studies ({clinicalStudies.length})
          </button>
          <button
            onClick={() => setActiveTab('REGULATORY')}
            className={`px-3 py-1.5 rounded transition ${
              activeTab === 'REGULATORY' ? 'bg-sky-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Regulatory Dossiers ({regulatorySubmissions.length})
          </button>
        </div>
      </div>

      {/* R&D Research Portfolio Tab */}
      {activeTab === 'RESEARCH' && (
        <div className="space-y-4">
          <div className="p-3 bg-slate-900/80 rounded border border-slate-800 text-xs font-mono text-slate-400 flex items-center justify-between">
            <span>R&D DRUG DEVELOPMENT TIMELINE: DISCOVERY → PRECLINICAL → PHASE I → PHASE II → PHASE III → APPROVAL</span>
            <span className="text-sky-400">VERIFIED DATA PROVENANCE</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {researchProgrammes.map((prog) => (
              <div key={prog.id} className="p-4 bg-[#121826] rounded-lg border border-slate-800 hover:border-slate-700 transition space-y-3 font-sans">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="px-2 py-0.5 rounded bg-sky-500/20 text-sky-300 font-mono text-[10px] font-bold">
                    {prog.code}
                  </span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 font-mono text-[10px]">
                    {prog.phase}
                  </span>
                </div>

                <div>
                  <h3 className="font-bold text-sm text-white font-mono">{prog.name}</h3>
                  <span className="text-[11px] text-sky-400 font-mono block mt-0.5">{prog.therapeuticArea}</span>
                </div>

                <p className="text-xs text-slate-300 leading-relaxed bg-slate-900/80 p-2.5 rounded border border-slate-800">
                  {prog.hypothesis}
                </p>

                <div className="space-y-1 font-mono text-[11px] text-slate-400">
                  <div className="flex justify-between">
                    <span>PROBABILITY OF SUCCESS:</span>
                    <span className="text-emerald-400 font-bold">{prog.probabilityOfSuccessPct}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span>BUDGET ALLOCATION:</span>
                    <span className="text-slate-200 font-bold">€{(prog.budgetAllocationEUR / 1000000).toFixed(1)}M</span>
                  </div>
                  <div className="flex justify-between">
                    <span>RESEARCH SITE:</span>
                    <span className="text-slate-300">{prog.researchSite.split(' ')[0]}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Clinical Studies Tab */}
      {activeTab === 'CLINICAL' && (
        <div className="space-y-4">
          {clinicalStudies.map((study) => (
            <div key={study.id} className="p-4 bg-[#121826] rounded-lg border border-slate-800 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div className="flex items-center gap-2">
                  <span className="text-sky-400 font-bold text-sm">{study.protocolNumber}</span>
                  <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 text-[10px]">{study.phase}</span>
                </div>
                <span className="text-emerald-400 font-bold">DATA QUALITY: {study.dataQualityScore}%</span>
              </div>

              <h3 className="text-sm font-sans font-bold text-white">{study.title}</h3>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-[11px]">
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">INDICATION:</span>
                  <span className="text-slate-200 font-bold font-sans">{study.indication}</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">ACTIVE CLINICAL SITES:</span>
                  <span className="text-sky-400 font-bold">{study.activeStudySitesCount} Sites</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">PATIENT ENROLLMENT:</span>
                  <span className="text-emerald-400 font-bold">{study.recruitmentCurrent} / {study.recruitmentTarget}</span>
                </div>
                <div className="p-2.5 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">PROTOCOL VERSION:</span>
                  <span className="text-slate-200 font-bold">{study.protocolVersion}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Regulatory Dossiers Tab */}
      {activeTab === 'REGULATORY' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {regulatorySubmissions.map((reg) => (
              <div key={reg.id} className="p-4 bg-[#121826] rounded-lg border border-slate-800 space-y-3 font-mono text-xs">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-sky-400 font-bold">{reg.submissionCode}</span>
                  <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                    AUTHORITY: {reg.authority}
                  </span>
                </div>

                <h3 className="font-sans font-bold text-sm text-white">{reg.productName}</h3>

                <div className="space-y-1.5 text-[11px] text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">COUNTRY / REGION:</span>
                    <span>{reg.countryRegion}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">DOSSIER COMPLETENESS:</span>
                    <span className="text-emerald-400 font-bold">{reg.dossierCompletenessPct}%</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">TARGET APPROVAL DATE:</span>
                    <span className="text-slate-200 font-bold">{reg.targetDate}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
