import React, { useState } from 'react';
import { Leaf, DollarSign, Sliders, Activity, CheckCircle2, ShieldCheck } from 'lucide-react';
import { SustainabilityMetric, FinancialPlan } from '../../types';

interface CorporateFunctionsWorkspaceProps {
  sustainabilityMetrics: SustainabilityMetric[];
  financePlans: FinancialPlan[];
}

export const CorporateFunctionsWorkspace: React.FC<CorporateFunctionsWorkspaceProps> = ({
  sustainabilityMetrics,
  financePlans,
}) => {
  const [activeTab, setActiveTab] = useState<'SUSTAINABILITY' | 'FINANCE' | 'GOVERNANCE'>('SUSTAINABILITY');

  return (
    <div className="p-6 space-y-6 font-sans text-slate-100 max-w-7xl mx-auto">
      {/* Header */}
      <div className="p-4 bg-[#121826] rounded-lg border border-slate-800 flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold font-mono text-white">CORPORATE FUNCTIONS & SYSTEM GOVERNANCE</h1>
          <p className="text-xs text-slate-400">Decarbonization Targets, Capital Expenditure Pipelines & Kernel Governance</p>
        </div>

        <div className="flex items-center gap-1 bg-slate-900 p-1 rounded border border-slate-800 font-mono text-xs">
          <button
            onClick={() => setActiveTab('SUSTAINABILITY')}
            className={`px-3 py-1.5 rounded transition ${
              activeTab === 'SUSTAINABILITY' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Sustainability Ops ({sustainabilityMetrics.length})
          </button>
          <button
            onClick={() => setActiveTab('FINANCE')}
            className={`px-3 py-1.5 rounded transition ${
              activeTab === 'FINANCE' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Finance & CapEx ({financePlans.length})
          </button>
          <button
            onClick={() => setActiveTab('GOVERNANCE')}
            className={`px-3 py-1.5 rounded transition ${
              activeTab === 'GOVERNANCE' ? 'bg-emerald-600 text-white font-bold' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Kernel Governance
          </button>
        </div>
      </div>

      {activeTab === 'SUSTAINABILITY' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {sustainabilityMetrics.map((sus) => (
            <div key={sus.siteId} className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-white text-sm font-sans">{sus.siteName}</span>
                <span className="text-emerald-400 font-bold">{sus.targetCompliance}</span>
              </div>

              <div className="grid grid-cols-2 gap-3 text-[11px]">
                <div className="p-3 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">CO2e SCOPE 1 & 2:</span>
                  <span className="text-white font-bold">{sus.carbonScope1And2MT.toLocaleString()} MT</span>
                </div>
                <div className="p-3 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">RENEWABLE ENERGY %:</span>
                  <span className="text-emerald-400 font-bold">{sus.renewableEnergySharePct}%</span>
                </div>
                <div className="p-3 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">WATER CONSUMPTION:</span>
                  <span className="text-sky-400 font-bold">{sus.waterConsumptionM3.toLocaleString()} m³</span>
                </div>
                <div className="p-3 bg-slate-900 rounded border border-slate-800">
                  <span className="text-slate-400 block text-[10px]">WASTE RECYCLED %:</span>
                  <span className="text-amber-400 font-bold">{sus.wasteRecycledPct}%</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'FINANCE' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {financePlans.map((fin) => (
            <div key={fin.division} className="bg-[#121826] p-5 rounded-lg border border-slate-800 space-y-3 font-mono text-xs">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="font-bold text-white text-sm font-sans">{fin.divisionName}</span>
                <span className="text-sky-400 font-bold">ANNUAL BUDGET</span>
              </div>

              <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1.5 text-[11px]">
                <div className="flex justify-between">
                  <span className="text-slate-400">DIVISION BUDGET:</span>
                  <span className="text-emerald-400 font-bold">€{(fin.budgetEUR / 1000000000).toFixed(2)}B</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">R&D EXPENDITURE:</span>
                  <span className="text-sky-400 font-bold">€{(fin.researchExpenditureEUR / 1000000000).toFixed(2)}B</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">CAPEX PIPELINE:</span>
                  <span className="text-slate-200 font-bold">€{(fin.capexPipelineEUR / 1000000000).toFixed(2)}B</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'GOVERNANCE' && (
        <div className="p-6 bg-[#121826] rounded-lg border border-slate-800 space-y-4 font-mono text-xs">
          <div className="border-b border-slate-800 pb-3">
            <h2 className="text-sm font-bold text-white uppercase">BAYER.OS KERNEL GOVERNANCE & HEALTH</h2>
            <p className="text-slate-400 text-xs font-sans mt-0.5">Automated System Auditing & Operational Integrity Monitor</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="p-3 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">KERNEL VERSION:</span>
              <span className="text-white font-bold">v2.4.0-Enterprise</span>
            </div>
            <div className="p-3 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">AUDIT CHAIN STATUS:</span>
              <span className="text-emerald-400 font-bold">INTEGRITY OK</span>
            </div>
            <div className="p-3 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">SCADA TELEMETRY SYNC:</span>
              <span className="text-sky-400 font-bold">12ms LATENCY</span>
            </div>
            <div className="p-3 bg-slate-900 rounded border border-slate-800">
              <span className="text-slate-400 block text-[10px]">DATA PROVENANCE:</span>
              <span className="text-amber-300 font-bold">SYNTHETIC ENGINE</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
