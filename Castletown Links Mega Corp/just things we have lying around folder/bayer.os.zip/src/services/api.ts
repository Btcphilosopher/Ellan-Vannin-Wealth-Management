/**
 * BAYER.OS REST API Service Client
 * Interacts with /api/v1 endpoints served by the Express backend.
 */

import {
  Site,
  ProductionLine,
  Batch,
  SupplyNode,
  SupplyRoute,
  SupplyScenario,
  PharmaResearchProgramme,
  ClinicalStudy,
  RegulatorySubmission,
  CropTrial,
  ConsumerHealthProduct,
  QualityEvent,
  RiskEvent,
  ScientificDataset,
  AIModelRecord,
  SustainabilityMetric,
  FinancialPlan,
  AuditEvent,
  OperationalRegime,
  OperationalReport,
} from '../types';

async function fetchApi<T>(endpoint: string, options?: RequestInit): Promise<T> {
  const res = await fetch(endpoint, {
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    ...options,
  });
  if (!res.ok) {
    throw new Error(`API Error ${res.status}: ${res.statusText}`);
  }
  const json = await res.json();
  return json.data as T;
}

export const bayerApi = {
  // Group Overview
  getGroupOverview: () => fetchApi<any>('/api/v1/group/overview'),

  // Sites
  getSites: (division?: string) => fetchApi<Site[]>(`/api/v1/sites${division ? `?division=${division}` : ''}`),
  getSiteDetail: (siteId: string) => fetchApi<{
    site: Site;
    productionLines: ProductionLine[];
    activeBatches: Batch[];
    qualityEvents: QualityEvent[];
  }>(`/api/v1/sites/${siteId}`),

  // Manufacturing
  getProductionLines: () => fetchApi<ProductionLine[]>('/api/v1/manufacturing/lines'),
  getBatches: () => fetchApi<Batch[]>('/api/v1/manufacturing/batches'),
  getBatchDetail: (batchId: string) => fetchApi<Batch>(`/api/v1/manufacturing/batches/${batchId}`),

  // Simulate Delay (Vertical Slice Core Action)
  simulateProductionDelay: (batchId: string, delayDays: number, reason: string, actor?: string) =>
    fetchApi<{
      updatedBatch: Batch;
      newRiskEvent: RiskEvent;
      newQualityEvent: QualityEvent;
      auditEvent: AuditEvent;
      impactSummary: {
        affectedDestinationMarkets: string[];
        inventoryDaysReduction: number;
        estimatedFinancialExposureEUR: number;
      };
    }>('/api/v1/manufacturing/simulate-delay', {
      method: 'POST',
      body: JSON.stringify({ batchId, delayDays, reason, actor }),
    }),

  // Pharmaceuticals
  getResearchProgrammes: () => fetchApi<PharmaResearchProgramme[]>('/api/v1/research/programmes'),
  getClinicalProgrammes: () => fetchApi<ClinicalStudy[]>('/api/v1/clinical/programmes'),
  getRegulatorySubmissions: () => fetchApi<RegulatorySubmission[]>('/api/v1/regulatory/submissions'),

  // Crop Science
  getCropTrials: () => fetchApi<CropTrial[]>('/api/v1/crop-science/trials'),

  // Consumer Health
  getConsumerHealthProducts: () => fetchApi<ConsumerHealthProduct[]>('/api/v1/consumer-health/products'),

  // Supply Chain
  getSupplyNetwork: () => fetchApi<{ nodes: SupplyNode[]; routes: SupplyRoute[] }>('/api/v1/supply-chain/network'),
  getSupplyScenarios: () => fetchApi<SupplyScenario[]>('/api/v1/supply-chain/scenarios'),

  // Quality Management
  getQualityEvents: () => fetchApi<QualityEvent[]>('/api/v1/quality/events'),
  triageQualityEvent: (eventId: string, status: QualityEvent['status'], rootCause: string, owner: string) =>
    fetchApi<QualityEvent>(`/api/v1/quality/events/${eventId}/triage`, {
      method: 'POST',
      body: JSON.stringify({ status, rootCause, owner }),
    }),

  // Science & Analytics
  getDatasets: () => fetchApi<ScientificDataset[]>('/api/v1/scientific/datasets'),
  getAIModels: () => fetchApi<AIModelRecord[]>('/api/v1/analytics/models'),

  // Sustainability & Finance
  getSustainabilityMetrics: () => fetchApi<SustainabilityMetric[]>('/api/v1/sustainability/observations'),
  getFinancePlans: () => fetchApi<FinancialPlan[]>('/api/v1/finance/plans'),

  // Risk Management
  getRiskEvents: () => fetchApi<RiskEvent[]>('/api/v1/risk/events'),
  assignRiskOwner: (riskId: string, owner: string, mitigationPlan: string) =>
    fetchApi<RiskEvent>(`/api/v1/risk/events/${riskId}/assign`, {
      method: 'POST',
      body: JSON.stringify({ owner, mitigationPlan }),
    }),

  // Audit Events & Operational Reports
  getAuditLog: () => fetchApi<AuditEvent[]>('/api/v1/audit/events'),
  generateOperationalReport: () => fetchApi<OperationalReport>('/api/v1/reports/operational-summary'),

  // Governance Regime Shift
  setOperationalRegime: (regime: OperationalRegime, actor?: string) =>
    fetchApi<{ regime: OperationalRegime; overview: any }>('/api/v1/governance/regime', {
      method: 'POST',
      body: JSON.stringify({ regime, actor }),
    }),
};
