/**
 * BAYER.OS Synthetic Data Engine & Persistent State Store
 * Deterministic synthetic data generator representing global Life Sciences operations.
 * ALL DATA IS FICTIONAL, SYNTHETIC, AND CLEARLY LABELLED FOR DEMONSTRATION.
 */

import {
  Site,
  ProductionLine,
  Asset,
  Batch,
  SupplyNode,
  SupplyRoute,
  SupplyScenario,
  PharmaResearchProgramme,
  ClinicalStudy,
  RegulatorySubmission,
  CropTrial,
  ConsumerHealthProduct,
  QualityEvent,
  RiskEvent,
  ScientificDataset,
  AIModelRecord,
  SustainabilityMetric,
  FinancialPlan,
  AuditEvent,
  OperationalRegime,
  UserRole,
  OperationalReport,
} from '../types';

function generateHash(str: string): string {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash |= 0;
  }
  return '0x' + Math.abs(hash).toString(16).padStart(8, '0') + Math.abs(hash * 31).toString(16).padStart(8, '0');
}

// Initial deterministic operating sites
const INITIAL_SITES: Site[] = [
  {
    id: 'SITE-LEV-01',
    name: 'Leverkusen Chempark & Biotech Center',
    code: 'LEV-GER-01',
    city: 'Leverkusen',
    country: 'Germany',
    region: 'Europe (EMEA)',
    coordinates: [51.0303, 6.9843],
    division: 'PHARMA',
    type: 'MANUFACTURING',
    status: 'OPTIMAL',
    activeLinesCount: 8,
    activeBatchesCount: 14,
    workforceCount: 4200,
    energyConsumptionKWh: 148500,
    waterUsageM3: 12400,
    carbonEmissionsMT: 42.8,
    capabilities: ['Active Pharmaceutical Ingredients (API)', 'Sterile Injectables', 'Lyophilization', 'Tableting'],
    openQualityIncidents: 1,
    riskScore: 12,
    lastAuditDate: '2026-08-14',
  },
  {
    id: 'SITE-MON-02',
    name: 'Monheim Agronomic Research & Seeds Hub',
    code: 'MON-GER-02',
    city: 'Monheim am Rhein',
    country: 'Germany',
    region: 'Europe (EMEA)',
    coordinates: [51.0894, 6.8886],
    division: 'CROP_SCIENCE',
    type: 'AGRONOMIC_STATION',
    status: 'OPTIMAL',
    activeLinesCount: 4,
    activeBatchesCount: 9,
    workforceCount: 2800,
    energyConsumptionKWh: 82000,
    waterUsageM3: 28500,
    carbonEmissionsMT: 22.1,
    capabilities: ['Trait Breeding', 'Fungicide Formulation', 'Biological Seed Protection', 'Digital Phenotyping'],
    openQualityIncidents: 0,
    riskScore: 8,
    lastAuditDate: '2026-07-28',
  },
  {
    id: 'SITE-WUP-03',
    name: 'Wuppertal-Elberfeld Research Institute',
    code: 'WUP-GER-03',
    city: 'Wuppertal',
    country: 'Germany',
    region: 'Europe (EMEA)',
    coordinates: [51.2562, 7.1508],
    division: 'PHARMA',
    type: 'RESEARCH_LAB',
    status: 'OPTIMAL',
    activeLinesCount: 3,
    activeBatchesCount: 5,
    workforceCount: 1900,
    energyConsumptionKWh: 61000,
    waterUsageM3: 4100,
    carbonEmissionsMT: 15.4,
    capabilities: ['Cardiology HTS', 'Oncology Lead Optimization', 'NMR Spectroscopy', 'Mass Spectrometry'],
    openQualityIncidents: 0,
    riskScore: 5,
    lastAuditDate: '2026-09-02',
  },
  {
    id: 'SITE-BER-04',
    name: 'Bergkamen Chemical API Manufacturing',
    code: 'BER-GER-04',
    city: 'Bergkamen',
    country: 'Germany',
    region: 'Europe (EMEA)',
    coordinates: [51.6186, 7.6339],
    division: 'PHARMA',
    type: 'MANUFACTURING',
    status: 'OPTIMAL',
    activeLinesCount: 6,
    activeBatchesCount: 11,
    workforceCount: 1600,
    energyConsumptionKWh: 195000,
    waterUsageM3: 18900,
    carbonEmissionsMT: 58.2,
    capabilities: ['Hormone Synthesis', 'Steroid Fermentation', 'Continuous Crystallization', 'Solvent Recovery'],
    openQualityIncidents: 2,
    riskScore: 24,
    lastAuditDate: '2026-08-01',
  },
  {
    id: 'SITE-STL-05',
    name: 'St. Louis Biotechnology & Crop Research Center',
    code: 'STL-USA-05',
    city: 'St. Louis',
    country: 'United States',
    region: 'North America',
    coordinates: [38.6270, -90.1994],
    division: 'CROP_SCIENCE',
    type: 'AGRONOMIC_STATION',
    status: 'OPTIMAL',
    activeLinesCount: 7,
    activeBatchesCount: 18,
    workforceCount: 3500,
    energyConsumptionKWh: 132000,
    waterUsageM3: 31000,
    carbonEmissionsMT: 39.5,
    capabilities: ['Genomic Mapping', 'Herbicide Tolerant Seed Production', 'Gene Editing Lab', 'Greenhouse Testing'],
    openQualityIncidents: 1,
    riskScore: 18,
    lastAuditDate: '2026-08-20',
  },
  {
    id: 'SITE-PIT-06',
    name: 'Pittsburgh Consumer Health Facility',
    code: 'PIT-USA-06',
    city: 'Pittsburgh',
    country: 'United States',
    region: 'North America',
    coordinates: [40.4406, -79.9959],
    division: 'CONSUMER_HEALTH',
    type: 'MANUFACTURING',
    status: 'OPTIMAL',
    activeLinesCount: 5,
    activeBatchesCount: 12,
    workforceCount: 1200,
    energyConsumptionKWh: 74000,
    waterUsageM3: 6500,
    carbonEmissionsMT: 18.1,
    capabilities: ['Effervescent Tablet Pressing', 'Ointment Filling', 'Blister Packaging', 'Consumer Quality QC'],
    openQualityIncidents: 0,
    riskScore: 10,
    lastAuditDate: '2026-09-01',
  },
  {
    id: 'SITE-SHA-07',
    name: 'Shanghai Innovation & Pharma Packaging Hub',
    code: 'SHA-CHN-07',
    city: 'Shanghai',
    country: 'China',
    region: 'Asia-Pacific',
    coordinates: [31.2304, 121.4737],
    division: 'PHARMA',
    type: 'DISTRIBUTION_CENTER',
    status: 'OPTIMAL',
    activeLinesCount: 4,
    activeBatchesCount: 8,
    workforceCount: 1400,
    energyConsumptionKWh: 58000,
    waterUsageM3: 3800,
    carbonEmissionsMT: 14.2,
    capabilities: ['Radiology Contrast Media Packaging', 'Cold-Chain Storage (-20C)', 'Apac Regulatory Labeling'],
    openQualityIncidents: 1,
    riskScore: 15,
    lastAuditDate: '2026-08-10',
  },
  {
    id: 'SITE-SAO-08',
    name: 'São Paulo Crop Protection & Logistics',
    code: 'SAO-BRA-08',
    city: 'São Paulo',
    country: 'Brazil',
    region: 'Latin America',
    coordinates: [-23.5505, -46.6333],
    division: 'CROP_SCIENCE',
    type: 'MANUFACTURING',
    status: 'OPTIMAL',
    activeLinesCount: 5,
    activeBatchesCount: 10,
    workforceCount: 1800,
    energyConsumptionKWh: 89000,
    waterUsageM3: 14200,
    carbonEmissionsMT: 26.3,
    capabilities: ['Soybean Fungicide Blending', 'Emulsifiable Concentrates', 'LatAm Regional Distribution'],
    openQualityIncidents: 0,
    riskScore: 14,
    lastAuditDate: '2026-07-15',
  },
];

// Production Lines for Leverkusen API & Pharma Plant
const INITIAL_PRODUCTION_LINES: ProductionLine[] = [
  {
    id: 'LINE-LEV-ALPHA',
    siteId: 'SITE-LEV-01',
    name: 'Aseptic Injectables Line Alpha (Biologics)',
    lineCode: 'LEV-PL-01',
    category: 'Sterile Biologics & Cardiovascular APIs',
    status: 'RUNNING',
    currentBatchId: 'BATCH-BAY-2026-X9402',
    throughputUnitsPerHour: 12500,
    efficiencyOEE: 91.4,
    queueLengthBatches: 3,
    plannedDowntimeHours: 4,
    activePowerKW: 420,
    stages: [
      { stageNumber: 1, name: 'Raw Material Intake & Sterilization', status: 'COMPLETED', durationMinutes: 45, temperatureCelsius: 121.5, pressureBar: 2.1 },
      { stageNumber: 2, name: 'Bioreactor Fermentation & Dosing', status: 'COMPLETED', durationMinutes: 180, temperatureCelsius: 37.0, phLevel: 7.2 },
      { stageNumber: 3, name: 'Ultrafiltration & Concentration', status: 'IN_PROGRESS', durationMinutes: 90, pressureBar: 4.2 },
      { stageNumber: 4, name: 'Lyophilization / Freeze-Drying', status: 'PENDING', durationMinutes: 240, temperatureCelsius: -45.0 },
      { stageNumber: 5, name: 'Vial Filling & Nitrogen Purging', status: 'PENDING', durationMinutes: 60 },
      { stageNumber: 6, name: 'Automated Visual Inspection (AI)', status: 'PENDING', durationMinutes: 30 },
      { stageNumber: 7, name: 'Final Release & Cold Store Transfer', status: 'PENDING', durationMinutes: 20 },
    ],
    assets: [
      {
        id: 'AST-BIO-101',
        siteId: 'SITE-LEV-01',
        lineId: 'LINE-LEV-ALPHA',
        name: 'Single-Use Bioreactor 2000L',
        assetCode: 'EQ-LEV-BIO-2K',
        manufacturer: 'Eppendorf Scientific',
        assetType: 'Bioreactor',
        state: 'OPERATIONAL',
        healthScore: 96,
        vibrationMmS: 0.8,
        operatingTempC: 37.0,
        lastInspectionDate: '2026-09-01',
        nextScheduledMaintenance: '2026-10-15',
        failureRiskProbability: 0.02,
        openWorkOrdersCount: 0,
      },
      {
        id: 'AST-LYO-202',
        siteId: 'SITE-LEV-01',
        lineId: 'LINE-LEV-ALPHA',
        name: 'Industrial Lyophilizer CryoChamber',
        assetCode: 'EQ-LEV-LYO-02',
        manufacturer: 'GEA Pharma Systems',
        assetType: 'Lyophilizer',
        state: 'OPERATIONAL',
        healthScore: 92,
        vibrationMmS: 1.2,
        operatingTempC: -45.0,
        lastInspectionDate: '2026-08-22',
        nextScheduledMaintenance: '2026-10-01',
        failureRiskProbability: 0.04,
        openWorkOrdersCount: 0,
      },
      {
        id: 'AST-FIL-303',
        siteId: 'SITE-LEV-01',
        lineId: 'LINE-LEV-ALPHA',
        name: 'High-Speed Aseptic Vial Filler',
        assetCode: 'EQ-LEV-FIL-01',
        manufacturer: 'Bosch Packaging Tech',
        assetType: 'Vial Filler',
        state: 'OPERATIONAL',
        healthScore: 89,
        vibrationMmS: 1.6,
        operatingTempC: 22.4,
        lastInspectionDate: '2026-08-30',
        nextScheduledMaintenance: '2026-09-28',
        failureRiskProbability: 0.05,
        openWorkOrdersCount: 1,
      },
    ],
  },
  {
    id: 'LINE-LEV-BETA',
    siteId: 'SITE-LEV-01',
    name: 'Oral Solid Dosage Tablet Line Beta',
    lineCode: 'LEV-PL-02',
    category: 'Cardiology Oral Formulations',
    status: 'RUNNING',
    currentBatchId: 'BATCH-BAY-2026-C8819',
    throughputUnitsPerHour: 45000,
    efficiencyOEE: 88.2,
    queueLengthBatches: 2,
    plannedDowntimeHours: 2,
    activePowerKW: 310,
    stages: [
      { stageNumber: 1, name: 'API Micronization & Milling', status: 'COMPLETED', durationMinutes: 60 },
      { stageNumber: 2, name: 'Fluid Bed Granulation', status: 'COMPLETED', durationMinutes: 120 },
      { stageNumber: 3, name: 'Rotary Tablet Pressing', status: 'IN_PROGRESS', durationMinutes: 150 },
      { stageNumber: 4, name: 'Film Coating & Drying', status: 'PENDING', durationMinutes: 90 },
      { stageNumber: 5, name: 'Blister Thermoforming Packaging', status: 'PENDING', durationMinutes: 60 },
    ],
    assets: [],
  },
  {
    id: 'LINE-MON-AGRO',
    siteId: 'SITE-MON-02',
    name: 'Biological Seed Coating & Treatment Line 01',
    lineCode: 'MON-PL-01',
    category: 'Crop Science Biological Protection',
    status: 'RUNNING',
    currentBatchId: 'BATCH-BAY-2026-CS501',
    throughputUnitsPerHour: 8500,
    efficiencyOEE: 94.0,
    queueLengthBatches: 4,
    plannedDowntimeHours: 0,
    activePowerKW: 180,
    stages: [
      { stageNumber: 1, name: 'Seed Sorting & Cleaning', status: 'COMPLETED', durationMinutes: 30 },
      { stageNumber: 2, name: 'Biological Inoculant Dosing', status: 'IN_PROGRESS', durationMinutes: 45 },
      { stageNumber: 3, name: 'Polymer Polymerization Coating', status: 'PENDING', durationMinutes: 60 },
      { stageNumber: 4, name: 'Fluidized Bed Drying', status: 'PENDING', durationMinutes: 40 },
    ],
    assets: [],
  },
];

// Initial Batches
const INITIAL_BATCHES: Batch[] = [
  {
    id: 'BATCH-BAY-2026-X9402',
    batchNumber: 'BAY-2026-X9402',
    productName: 'Factor Xa Inhibitor (Aseptic Biologic)',
    productId: 'PRD-PHA-CARDIO-01',
    division: 'PHARMA',
    siteId: 'SITE-LEV-01',
    siteName: 'Leverkusen Chempark & Biotech Center',
    productionLineId: 'LINE-LEV-ALPHA',
    status: 'PROCESSING',
    plannedStartDate: '2026-09-21T06:00:00Z',
    actualStartDate: '2026-09-21T06:15:00Z',
    estimatedCompletionDate: '2026-09-23T18:00:00Z',
    quantityUnits: 50000,
    unitMeasurement: 'Vials (10mg)',
    progressPercent: 58,
    materialInputs: [
      {
        materialId: 'MAT-API-FXA-01',
        code: 'FXA-RAW-402',
        name: 'Factor Xa Active Compound Concentrate',
        supplierName: 'Bergkamen Chemical API Complex',
        supplierId: 'SITE-BER-04',
        lotNumber: 'LOT-BER-88401',
        quantityUsedKg: 125.4,
        qualityCertificateVerified: true,
        status: 'VERIFIED',
        originCountry: 'Germany',
      },
      {
        materialId: 'MAT-EXC-TRE-09',
        code: 'EXC-TREHALOSE-USP',
        name: 'Pharma Grade Trehalose Dihydrate (Cryoprotectant)',
        supplierName: 'Merck Millipore BioSupplies',
        supplierId: 'SUP-MM-GER',
        lotNumber: 'LOT-MM-90112',
        quantityUsedKg: 450.0,
        qualityCertificateVerified: true,
        status: 'VERIFIED',
        originCountry: 'Germany',
      },
      {
        materialId: 'MAT-PKG-VIA-20',
        code: 'PKG-BORO-VIAL-10ML',
        name: 'Type I Borosilicate Glass Vials (Sterile)',
        supplierName: 'Schott Pharmaceutical Packaging',
        supplierId: 'SUP-SCHOTT-01',
        lotNumber: 'LOT-SCH-7731',
        quantityUsedKg: 52000,
        qualityCertificateVerified: true,
        status: 'VERIFIED',
        originCountry: 'Germany',
      },
    ],
    qualityCheckpoints: [
      { checkpointId: 'QC-101', name: 'Raw Material Identity & Infrared Assay', stageName: 'Raw Material Intake', parameter: 'Purity > 99.8%', specification: '> 99.8%', measuredValue: '99.92%', status: 'PASS', testedBy: 'Dr. H. Weber (QC Lead)', timestamp: '2026-09-21T07:10:00Z' },
      { checkpointId: 'QC-102', name: 'Bioreactor Bioburden & Endotoxin Test', stageName: 'Fermentation', parameter: 'Endotoxin < 0.15 EU/mL', specification: '< 0.15 EU/mL', measuredValue: '0.04 EU/mL', status: 'PASS', testedBy: 'L. Schneider (Microbiology)', timestamp: '2026-09-21T14:30:00Z' },
      { checkpointId: 'QC-103', name: 'Ultrafiltration Permeate Conductance', stageName: 'Ultrafiltration', parameter: 'Conductivity < 2.5 µS/cm', specification: '< 2.5 µS/cm', measuredValue: '1.82 µS/cm', status: 'PASS', testedBy: 'K. Fischer (QC Analyst)', timestamp: '2026-09-22T01:15:00Z' },
      { checkpointId: 'QC-104', name: 'HPLC Active Potency Assay', stageName: 'Lyophilization', parameter: 'Target 10.0 mg ± 2%', specification: '10.0 mg ± 2%', measuredValue: 'Pending', status: 'IN_REVIEW', testedBy: 'Automated HPLC System 4', timestamp: '2026-09-22T02:40:00Z' },
    ],
    deviationsCount: 0,
    traceabilityHash: generateHash('BATCH-BAY-2026-X9402-INITIAL'),
  },
  {
    id: 'BATCH-BAY-2026-C8819',
    batchNumber: 'BAY-2026-C8819',
    productName: 'Rivaroxaban 20mg Oral Tablets',
    productId: 'PRD-PHA-CARDIO-02',
    division: 'PHARMA',
    siteId: 'SITE-LEV-01',
    siteName: 'Leverkusen Chempark & Biotech Center',
    productionLineId: 'LINE-LEV-BETA',
    status: 'PROCESSING',
    plannedStartDate: '2026-09-21T12:00:00Z',
    actualStartDate: '2026-09-21T12:00:00Z',
    estimatedCompletionDate: '2026-09-22T22:00:00Z',
    quantityUnits: 450000,
    unitMeasurement: 'Tablets',
    progressPercent: 72,
    materialInputs: [],
    qualityCheckpoints: [],
    deviationsCount: 0,
    traceabilityHash: generateHash('BATCH-BAY-2026-C8819'),
  },
  {
    id: 'BATCH-BAY-2026-CS501',
    batchNumber: 'BAY-2026-CS501',
    productName: 'Acceleron Elite Corn Trait Seed Treatment',
    productId: 'PRD-CS-SEED-101',
    division: 'CROP_SCIENCE',
    siteId: 'SITE-MON-02',
    siteName: 'Monheim Agronomic Research & Seeds Hub',
    productionLineId: 'LINE-MON-AGRO',
    status: 'PROCESSING',
    plannedStartDate: '2026-09-20T08:00:00Z',
    actualStartDate: '2026-09-20T08:00:00Z',
    estimatedCompletionDate: '2026-09-23T12:00:00Z',
    quantityUnits: 18000,
    unitMeasurement: 'Bagged Units (80,000 kernels)',
    progressPercent: 65,
    materialInputs: [],
    qualityCheckpoints: [],
    deviationsCount: 0,
    traceabilityHash: generateHash('BATCH-BAY-2026-CS501'),
  },
];

// Initial Supply Network
const INITIAL_SUPPLY_NODES: SupplyNode[] = [
  { id: 'NODE-BER-API', name: 'Bergkamen API Primary Chemical Plant', type: 'MANUFACTURING_SITE', location: 'Germany', lat: 51.6186, lng: 7.6339, inventoryLevelPct: 88, status: 'HEALTHY', leadTimeDays: 3, singleSourceDependency: false },
  { id: 'NODE-SCHOTT-PKG', name: 'Schott Glassware Packaging Complex', type: 'SUPPLIER', location: 'Mainz, Germany', lat: 50.0000, lng: 8.2711, inventoryLevelPct: 92, status: 'HEALTHY', leadTimeDays: 5, singleSourceDependency: true },
  { id: 'NODE-LEV-HUB', name: 'Leverkusen Biotech & Logistics Hub', type: 'MANUFACTURING_SITE', location: 'Leverkusen, Germany', lat: 51.0303, lng: 6.9843, inventoryLevelPct: 84, status: 'HEALTHY', leadTimeDays: 2, singleSourceDependency: false },
  { id: 'NODE-FRA-AIR', name: 'Frankfurt Airport Cold-Chain Pharma Gate', type: 'DISTRIBUTION_HUB', location: 'Frankfurt, Germany', lat: 50.0379, lng: 8.5622, inventoryLevelPct: 95, status: 'HEALTHY', leadTimeDays: 1, singleSourceDependency: false },
  { id: 'NODE-JFK-USA', name: 'JFK New York Pharma Regional Depot', type: 'WAREHOUSE', location: 'New York, USA', lat: 40.6413, lng: -73.7781, inventoryLevelPct: 78, status: 'HEALTHY', leadTimeDays: 4, singleSourceDependency: false },
  { id: 'NODE-SHA-CENTRAL', name: 'Shanghai Pudong Cold Chain Logistics', type: 'WAREHOUSE', location: 'Shanghai, China', lat: 31.1443, lng: 121.8083, inventoryLevelPct: 81, status: 'HEALTHY', leadTimeDays: 6, singleSourceDependency: false },
];

const INITIAL_SUPPLY_ROUTES: SupplyRoute[] = [
  { id: 'RTE-01', fromNodeId: 'NODE-BER-API', toNodeId: 'NODE-LEV-HUB', materialOrProduct: 'Factor Xa API Liquid Bulk', transportMode: 'COLD_CHAIN_TRUCK', transitDays: 1, status: 'ON_SCHEDULE', temperatureRangeMinC: 2.0, temperatureRangeMaxC: 8.0, currentTempC: 4.8 },
  { id: 'RTE-02', fromNodeId: 'NODE-SCHOTT-PKG', toNodeId: 'NODE-LEV-HUB', materialOrProduct: 'Type 1 Borosilicate Vials', transportMode: 'COLD_CHAIN_TRUCK', transitDays: 1, status: 'ON_SCHEDULE', temperatureRangeMinC: 10.0, temperatureRangeMaxC: 30.0, currentTempC: 21.2 },
  { id: 'RTE-03', fromNodeId: 'NODE-LEV-HUB', toNodeId: 'NODE-FRA-AIR', materialOrProduct: 'Cardiology Biologic Vials', transportMode: 'COLD_CHAIN_TRUCK', transitDays: 1, status: 'ON_SCHEDULE', temperatureRangeMinC: 2.0, temperatureRangeMaxC: 8.0, currentTempC: 5.1 },
  { id: 'RTE-04', fromNodeId: 'NODE-FRA-AIR', toNodeId: 'NODE-JFK-USA', materialOrProduct: 'Finished Pharma Shipments', transportMode: 'AIR_FREIGHT', transitDays: 2, status: 'ON_SCHEDULE', temperatureRangeMinC: 2.0, temperatureRangeMaxC: 8.0, currentTempC: 4.2 },
];

const INITIAL_SUPPLY_SCENARIOS: SupplyScenario[] = [
  {
    id: 'SCENARIO-01',
    scenarioType: 'COLD_CHAIN_EXCURSION',
    title: 'Trans-Atlantic Air Freight Temperature Spike (+14.2°C)',
    affectedLocation: 'Frankfurt to JFK Cargo Route RTE-04',
    estimatedDelayDays: 5,
    financialImpactEUR: 420000,
    mitigationStrategy: 'Reroute emergency stock via Luxembourg Air Hub with verified thermal blanket isolation',
    affectedProducts: ['Factor Xa Inhibitor', 'Eylea Ophthalmic Injectables'],
    riskSeverity: 'HIGH',
  },
  {
    id: 'SCENARIO-02',
    scenarioType: 'SUPPLIER_SHUTDOWN',
    title: 'Packaging Supplier Secondary Inspection Hold',
    affectedLocation: 'Schott Packaging Complex Mainz',
    estimatedDelayDays: 8,
    financialImpactEUR: 780000,
    mitigationStrategy: 'Activate secondary qualified vendor Gerresheimer AG for 10ml borosilicate vial buffer stock',
    affectedProducts: ['Factor Xa Inhibitor', 'Radiology Contrast Vials'],
    riskSeverity: 'CRITICAL',
  },
  {
    id: 'SCENARIO-03',
    scenarioType: 'PORT_CLOSURE',
    title: 'Hamburg Maritime Container Port Congestion',
    affectedLocation: 'Hamburg Harbor Terminal',
    estimatedDelayDays: 12,
    financialImpactEUR: 1250000,
    mitigationStrategy: 'Shift LatAm Crop Protection exports to Rotterdam rail-linked container feeder network',
    affectedProducts: ['Fox Xpro Soybean Fungicide', 'Proline Crop Protection'],
    riskSeverity: 'MEDIUM',
  },
];

// Initial Research Programmes
const INITIAL_RESEARCH_PROGRAMMES: PharmaResearchProgramme[] = [
  {
    id: 'RES-CARDIO-801',
    code: 'BAY-3283115',
    name: 'Asundexian (Factor XIa Inhibitor)',
    therapeuticArea: 'CARDIOLOGY',
    hypothesis: 'Selective Factor XIa inhibition prevents secondary stroke without increasing systemic bleeding risk.',
    objective: 'Demonstrate superior anti-thrombotic safety profile vs. standard FXa inhibitors in Phase III clinical trial cohort.',
    phase: 'PHASE_III',
    leadInvestigator: 'Prof. Dr. M. von Bergmann',
    researchSite: 'Wuppertal-Elberfeld Research Institute',
    targetMilestoneDate: '2026-12-15',
    probabilityOfSuccessPct: 78,
    budgetAllocationEUR: 85000000,
    riskClassification: 'LOW',
    dataQualityStatus: 'VERIFIED_AUDITED',
  },
  {
    id: 'RES-ONCO-902',
    code: 'BAY-2413555',
    name: 'Targeted Thorium Conjugate (TTC) Biologic',
    therapeuticArea: 'ONCOLOGY',
    hypothesis: 'Alpha-emitting targeted radiopharmaceutical selectively eradicates PSMA-positive metastatic prostate lesions.',
    objective: 'Complete Phase I/II dose escalation and bio-distribution safety validation in patients.',
    phase: 'PHASE_II',
    leadInvestigator: 'Dr. S. Chen (Oncology Lead)',
    researchSite: 'Leverkusen Chempark & Biotech Center',
    targetMilestoneDate: '2027-04-30',
    probabilityOfSuccessPct: 62,
    budgetAllocationEUR: 112000000,
    riskClassification: 'MEDIUM',
    dataQualityStatus: 'VERIFIED_AUDITED',
  },
  {
    id: 'RES-CELL-103',
    code: 'BAY-CGT-004',
    name: 'Stem Cell-Derived Dopaminergic Neurons (Bemdaneprocel)',
    therapeuticArea: 'CELL_GENE_THERAPY',
    hypothesis: 'Surgical transplantation of pluripotent dopaminergic progenitor cells restores motor circuit function in Parkinson’s disease.',
    objective: '18-month Phase Ib engraftment survival and PET scan dopamine transporter signal confirmation.',
    phase: 'PHASE_I',
    leadInvestigator: 'Dr. E. Thorne (Cell Therapy Director)',
    researchSite: 'Wuppertal & BlueRock Therapeutics Lab',
    targetMilestoneDate: '2027-01-20',
    probabilityOfSuccessPct: 54,
    budgetAllocationEUR: 68000000,
    riskClassification: 'HIGH',
    dataQualityStatus: 'VERIFIED_AUDITED',
  },
];

// Initial Clinical Studies
const INITIAL_CLINICAL_STUDIES: ClinicalStudy[] = [
  {
    id: 'CLN-CARDIO-301',
    protocolNumber: 'NCT05517226 (OCEANIC-STROKE)',
    title: 'Phase III Randomized Multicenter Trial of FXIa Inhibitor Asundexian',
    indication: 'Non-cardioembolic Ischemic Stroke Prevention',
    phase: 'PHASE_III',
    geographicRegions: ['EU-27', 'North America', 'Japan', 'China'],
    activeStudySitesCount: 420,
    recruitmentTarget: 18000,
    recruitmentCurrent: 16420,
    protocolVersion: 'v4.2 (EMA/FDA Approved)',
    dataQualityScore: 98.4,
    operationalRisk: 'STABLE',
  },
  {
    id: 'CLN-ONCO-402',
    protocolNumber: 'NCT04809987 (ARANOTE)',
    title: 'Phase III Trial of Darolutamide in Metastatic Hormone-Sensitive Prostate Cancer',
    indication: 'mHSPC Radiographic Progression-Free Survival',
    phase: 'PHASE_III',
    geographicRegions: ['EU-27', 'USA', 'Latin America', 'APAC'],
    activeStudySitesCount: 310,
    recruitmentTarget: 6200,
    recruitmentCurrent: 6200,
    protocolVersion: 'v3.1 Final',
    dataQualityScore: 99.1,
    operationalRisk: 'STABLE',
  },
];

// Initial Regulatory Submissions
const INITIAL_REGULATORY_SUBMISSIONS: RegulatorySubmission[] = [
  {
    id: 'REG-EMA-2026-01',
    submissionCode: 'EMA/MAA/884910',
    productName: 'Eylea 8mg High-Dose Intravitreal Injection',
    authority: 'EMA',
    countryRegion: 'European Union (27 Member States)',
    submissionType: 'MAA',
    targetDate: '2026-10-30',
    approvalStatus: 'UNDER_REVIEW',
    dossierCompletenessPct: 96,
    auditTrailReference: 'AUD-REG-EMA-9901',
  },
  {
    id: 'REG-FDA-2026-02',
    submissionCode: 'FDA/NDA-215882',
    productName: 'Kerendia (Finerenone) Heart Failure Expansion',
    authority: 'FDA',
    countryRegion: 'United States',
    submissionType: 'SUPPLEMENT',
    targetDate: '2026-11-15',
    approvalStatus: 'UNDER_REVIEW',
    dossierCompletenessPct: 100,
    auditTrailReference: 'AUD-REG-FDA-8812',
  },
];

// Initial Crop Science Field Trials
const INITIAL_CROP_TRIALS: CropTrial[] = [
  {
    id: 'TRIAL-CS-2026-IA',
    trialCode: 'TRL-US-IA-2026-C01',
    locationName: 'Ames Agronomic Station, Iowa',
    country: 'United States',
    cropType: 'CORN_MAIZE',
    varietyOrTrait: 'Short-Stature Corn Hybrid (Preceon System)',
    soilType: 'Clarion-Nicollet-Webster Clay Loam',
    plantingDate: '2026-05-02',
    harvestDate: '2026-10-10',
    yieldBuPerAcreActual: 248.5,
    yieldBuPerAcreBenchmark: 212.0,
    pestPressureIndex: 'LOW',
    soilMoisturePct: 28.4,
    weatherConditionSummary: 'Favorable early precipitation, low wind lodging disruption',
    dataProvenance: 'Monheim Agronomic Digital Twin Sensor Grid 04',
  },
  {
    id: 'TRIAL-CS-2026-BR',
    trialCode: 'TRL-BR-MT-2026-S02',
    locationName: 'Sorriso Field Trial Facility, Mato Grosso',
    country: 'Brazil',
    cropType: 'SOYBEAN',
    varietyOrTrait: 'Intacta 2 Xtend Soybeans',
    soilType: 'Oxisol (Latosol) Deep Clay',
    plantingDate: '2026-02-15',
    harvestDate: '2026-06-20',
    yieldBuPerAcreActual: 72.8,
    yieldBuPerAcreBenchmark: 61.5,
    pestPressureIndex: 'MODERATE',
    soilMoisturePct: 32.1,
    weatherConditionSummary: 'Controlled fungicide application against Asian Soybean Rust',
    dataProvenance: 'São Paulo Agronomic Center Satellite Synthetic Feed',
  },
];

// Initial Consumer Health Products
const INITIAL_CONSUMER_HEALTH: ConsumerHealthProduct[] = [
  {
    id: 'PRD-CH-ALEVE',
    sku: 'SKU-ALEVE-220MG-100',
    brandName: 'Aleve (Naproxen Sodium 220mg)',
    category: 'ANALGESICS',
    primaryActiveIngredient: 'Naproxen Sodium',
    marketAvailabilityCountries: 64,
    manufacturingSite: 'Pittsburgh Consumer Health Facility',
    monthlyDemandUnits: 3800000,
    inventoryCoverageDays: 42,
    packagingVariants: ['Caplets 100s', 'Liquid Gels 80s', 'Back & Muscle 50s'],
    qualityHoldStatus: 'CLEAR',
    lifecycleStage: 'MATURE',
  },
  {
    id: 'PRD-CH-BEPANTHEN',
    sku: 'SKU-BEPANTHEN-OINT-100G',
    brandName: 'Bepanthen Protective Baby Ointment',
    category: 'DERMATOLOGY',
    primaryActiveIngredient: 'Dexpanthenol (Pro-Vitamin B5)',
    marketAvailabilityCountries: 92,
    manufacturingSite: 'Grenzach Consumer Health Site',
    monthlyDemandUnits: 5200000,
    inventoryCoverageDays: 38,
    packagingVariants: ['100g Tube', '50g Tube', 'Nappy Care Lotion 200ml'],
    qualityHoldStatus: 'CLEAR',
    lifecycleStage: 'GROWTH',
  },
  {
    id: 'PRD-CH-CLARITIN',
    sku: 'SKU-CLARITIN-10MG-30',
    brandName: 'Claritin 24-Hour Non-Drowsy Allergy (Loratadine)',
    category: 'ALLERGY',
    primaryActiveIngredient: 'Loratadine 10mg',
    marketAvailabilityCountries: 88,
    manufacturingSite: 'Pittsburgh Consumer Health Facility',
    monthlyDemandUnits: 6100000,
    inventoryCoverageDays: 48,
    packagingVariants: ['RediTabs 30s', 'Tablets 45s', 'Children Liquid 120ml'],
    qualityHoldStatus: 'CLEAR',
    lifecycleStage: 'MATURE',
  },
];

// Initial Quality Events
const INITIAL_QUALITY_EVENTS: QualityEvent[] = [
  {
    id: 'QEV-2026-081',
    eventNumber: 'QEV-LEV-2026-081',
    title: 'Bioreactor Filter Differential Pressure Micro-Excursion',
    severity: 'MINOR',
    originSite: 'Leverkusen Chempark & Biotech Center',
    division: 'PHARMA',
    relatedBatchId: 'BATCH-BAY-2026-X9402',
    relatedProductId: 'PRD-PHA-CARDIO-01',
    assignedOwner: 'Dr. H. Weber (QA Manager)',
    creationDate: '2026-09-21T08:30:00Z',
    dueDate: '2026-09-28T17:00:00Z',
    status: 'INVESTIGATION',
    rootCauseAnalysis: 'Pre-filter loading spike during initial buffer flush. Secondary 0.22µm sterile filter integrity validated intact.',
    correctiveActions: [
      'Perform integrity testing on secondary sterile filter assembly',
      'Update buffer flush pressure alert threshold in SCADA PLC 4',
    ],
    auditHistory: [
      '2026-09-21T08:30:00Z: Event created automatically by SCADA telemetry monitoring.',
      '2026-09-21T10:15:00Z: Assigned to Dr. H. Weber. Severity classified as MINOR.',
    ],
  },
  {
    id: 'QEV-2026-044',
    eventNumber: 'QEV-BER-2026-044',
    title: 'Solvent Recovery Distillation Temperature Variance',
    severity: 'MAJOR',
    originSite: 'Bergkamen Chemical API Manufacturing',
    division: 'PHARMA',
    assignedOwner: 'M. Becker (EHS & Quality Lead)',
    creationDate: '2026-09-18T14:20:00Z',
    dueDate: '2026-09-25T17:00:00Z',
    status: 'ACTION_PLAN',
    rootCauseAnalysis: 'Heat exchanger fouling on Column 3 steam jacket.',
    correctiveActions: [
      'Schedule clean-in-place (CIP) descaling procedure',
      'Inspect temperature sensor TC-308 calibration curve',
    ],
    auditHistory: [
      '2026-09-18T14:20:00Z: Event created during batch distillation cycle.',
    ],
  },
];

// Initial Risk Matrix Events
const INITIAL_RISK_EVENTS: RiskEvent[] = [
  {
    id: 'RSK-2026-102',
    riskCode: 'RSK-SUP-01',
    title: 'Single-Source Borosilicate Glass Vial Supply Concentration',
    category: 'SUPPLY_DISRUPTION',
    probability: 'MEDIUM',
    impact: 'SEVERE',
    exposureEUR: 4200000,
    assignedOwner: 'G. Richter (VP Global Procurement)',
    status: 'MITIGATION_IN_PROGRESS',
    mitigationPlan: 'Dual-qualify secondary glass packaging supplier in North America and establish 60-day buffer inventory in Leverkusen warehouse.',
    createdTimestamp: '2026-08-10T09:00:00Z',
    associatedBatchOrSite: 'SITE-LEV-01',
  },
  {
    id: 'RSK-2026-204',
    riskCode: 'RSK-REG-02',
    title: 'EMA Information Request on Intravitreal High-Dose Polymer Impurity Limits',
    category: 'REGULATORY_DELAY',
    probability: 'LOW',
    impact: 'MODERATE',
    exposureEUR: 1800000,
    assignedOwner: 'Dr. C. Fischer (Regulatory Affairs Lead)',
    status: 'ACTIVE_MONITORING',
    mitigationPlan: 'Submit extended 12-month stability analysis and NMR spectroscopic identity profile within 30-day response window.',
    createdTimestamp: '2026-09-01T11:30:00Z',
  },
];

// Scientific Datasets & AI Models
const INITIAL_DATASETS: ScientificDataset[] = [
  {
    id: 'DS-CARDIO-901',
    datasetCode: 'DS-WUP-HTS-2026',
    title: '1.2M Compound HTS Screen for FXIa Allosteric Binding',
    domain: 'HIGH_THROUGHPUT_SCREENING',
    recordsCount: 1240000,
    dataQualityFlags: ['COMPLETE', 'AUDITED_ALM_100%'],
    lastUpdated: '2026-09-15',
    leadScientist: 'Dr. K. Neumann',
    provenanceSource: 'Wuppertal Automated Robotics Screening Platform 02',
    linkedEntities: ['RES-CARDIO-801', 'BAY-3283115'],
  },
  {
    id: 'DS-AGRO-402',
    datasetCode: 'DS-MON-PHEN-2026',
    title: 'Multispectral UAV Canopy Index & Short-Stature Corn Phenotyping',
    domain: 'AGRONOMIC_FIELD_GENOMICS',
    recordsCount: 850000,
    dataQualityFlags: ['GEO_REFERENCED', 'REAL_TIME_SAT_SYNC'],
    lastUpdated: '2026-09-18',
    leadScientist: 'Dr. M. Santos',
    provenanceSource: 'Monheim & Iowa Field Trial Sensor Grid',
    linkedEntities: ['TRIAL-CS-2026-IA'],
  },
];

const INITIAL_AI_MODELS: AIModelRecord[] = [
  {
    id: 'MDL-MAINT-01',
    modelCode: 'MDL-PRED-MAINT-V4',
    name: 'Vibration & Thermal Anomaly Predictive Maintenance Model',
    domain: 'PREDICTIVE_MAINTENANCE',
    modelVersion: 'v4.2.1-prod',
    accuracyMetric: '96.8% Precision / 94.1% Recall',
    driftIndicator: 'HEALTHY',
    deploymentStatus: 'PRODUCTION',
    modelOwner: 'Industrial Digital Twin Analytics Team',
    explainabilitySummary: 'XGBoost ensemble analyzing 100Hz accelerometer FFT harmonics and thermocouple gradient trends.',
    syntheticDataLabel: 'SYNTHETIC DEMONSTRATION MODEL • BENCHMARK EVALUATED',
  },
  {
    id: 'MDL-DEMAND-02',
    modelCode: 'MDL-DEMAND-FCST-V3',
    name: 'Global Life-Sciences Multi-Horizon Demand Forecasting Engine',
    domain: 'DEMAND_FORECASTING',
    modelVersion: 'v3.8.0',
    accuracyMetric: '92.4% WAPE',
    driftIndicator: 'STABLE',
    deploymentStatus: 'PRODUCTION',
    modelOwner: 'Supply Chain AI Office',
    explainabilitySummary: 'Temporal Fusion Transformer combining epidemiological trends, weather patterns, and seasonal distributor purchase velocity.',
    syntheticDataLabel: 'SYNTHETIC DEMONSTRATION MODEL • BENCHMARK EVALUATED',
  },
];

// Sustainability & Financial Metrics
const INITIAL_SUSTAINABILITY: SustainabilityMetric[] = [
  { siteId: 'SITE-LEV-01', siteName: 'Leverkusen Chempark & Biotech Center', division: 'PHARMA', energyTotalKWh: 148500, renewableEnergySharePct: 78.4, waterConsumptionM3: 12400, wasteRecycledPct: 91.2, carbonScope1And2MT: 42.8, carbonScope3MT: 112.5, targetCompliance: 'ON_TRACK' },
  { siteId: 'SITE-MON-02', siteName: 'Monheim Agronomic Research & Seeds Hub', division: 'CROP_SCIENCE', energyTotalKWh: 82000, renewableEnergySharePct: 88.0, waterConsumptionM3: 28500, wasteRecycledPct: 94.5, carbonScope1And2MT: 22.1, carbonScope3MT: 65.0, targetCompliance: 'ON_TRACK' },
  { siteId: 'SITE-BER-04', siteName: 'Bergkamen Chemical API Manufacturing', division: 'PHARMA', energyTotalKWh: 195000, renewableEnergySharePct: 62.5, waterConsumptionM3: 18900, wasteRecycledPct: 84.0, carbonScope1And2MT: 58.2, carbonScope3MT: 145.0, targetCompliance: 'AT_RISK' },
];

const INITIAL_FINANCE_PLANS: FinancialPlan[] = [
  { division: 'PHARMA', divisionName: 'Pharmaceuticals Division', budgetEUR: 18400000000, actualSpentEUR: 13200000000, forecastEUR: 18250000000, variancePercent: -0.8, researchExpenditureEUR: 3200000000, capexPipelineEUR: 1400000000, mfgCostPerUnitEUR: 14.20 },
  { division: 'CROP_SCIENCE', divisionName: 'Crop Science Division', budgetEUR: 23200000000, actualSpentEUR: 16800000000, forecastEUR: 23100000000, variancePercent: -0.4, researchExpenditureEUR: 2800000000, capexPipelineEUR: 1100000000, mfgCostPerUnitEUR: 22.50 },
  { division: 'CONSUMER_HEALTH', divisionName: 'Consumer Health Division', budgetEUR: 6100000000, actualSpentEUR: 4300000000, forecastEUR: 6150000000, variancePercent: 0.8, researchExpenditureEUR: 450000000, capexPipelineEUR: 320000000, mfgCostPerUnitEUR: 2.80 },
];

// Initial Audit Trail
const INITIAL_AUDIT_LOG: AuditEvent[] = [
  {
    id: 'AUD-2026-0001',
    timestamp: '2026-09-22T02:00:00Z',
    action: 'SYSTEM_INITIALIZATION',
    actor: 'SYSTEM_KERNEL',
    role: 'SYSTEM_ADMIN',
    entityType: 'ENTERPRISE_KERNEL',
    entityId: 'BAYER-OS-V2026',
    details: 'BAYER.OS Kernel initialized. Synthetic deterministic data engine loaded across 12 sites, 3 divisions, 14 active batches.',
    traceabilityHash: generateHash('AUD-2026-0001-SYSTEM_INITIALIZATION'),
  },
  {
    id: 'AUD-2026-0002',
    timestamp: '2026-09-22T02:15:00Z',
    action: 'BATCH_RELEASE_INSPECTION',
    actor: 'Dr. H. Weber',
    role: 'QUALITY_MANAGER',
    entityType: 'BATCH',
    entityId: 'BATCH-BAY-2026-X9402',
    details: 'Quality checkpoint QC-101 and QC-102 verified PASS. Batch progress registered at 58%.',
    traceabilityHash: generateHash('AUD-2026-0002-BATCH_RELEASE_INSPECTION'),
  },
];

// In-Memory Database State Container
class SyntheticDatabase {
  private regime: OperationalRegime = 'NORMAL';
  private activeRole: UserRole = 'GROUP_EXECUTIVE';
  private sites: Site[] = [...INITIAL_SITES];
  private productionLines: ProductionLine[] = [...INITIAL_PRODUCTION_LINES];
  private batches: Batch[] = [...INITIAL_BATCHES];
  private supplyNodes: SupplyNode[] = [...INITIAL_SUPPLY_NODES];
  private supplyRoutes: SupplyRoute[] = [...INITIAL_SUPPLY_ROUTES];
  private supplyScenarios: SupplyScenario[] = [...INITIAL_SUPPLY_SCENARIOS];
  private researchProgrammes: PharmaResearchProgramme[] = [...INITIAL_RESEARCH_PROGRAMMES];
  private clinicalStudies: ClinicalStudy[] = [...INITIAL_CLINICAL_STUDIES];
  private regulatorySubmissions: RegulatorySubmission[] = [...INITIAL_REGULATORY_SUBMISSIONS];
  private cropTrials: CropTrial[] = [...INITIAL_CROP_TRIALS];
  private consumerHealthProducts: ConsumerHealthProduct[] = [...INITIAL_CONSUMER_HEALTH];
  private qualityEvents: QualityEvent[] = [...INITIAL_QUALITY_EVENTS];
  private riskEvents: RiskEvent[] = [...INITIAL_RISK_EVENTS];
  private scientificDatasets: ScientificDataset[] = [...INITIAL_DATASETS];
  private aiModels: AIModelRecord[] = [...INITIAL_AI_MODELS];
  private sustainabilityMetrics: SustainabilityMetric[] = [...INITIAL_SUSTAINABILITY];
  private financePlans: FinancialPlan[] = [...INITIAL_FINANCE_PLANS];
  private auditLog: AuditEvent[] = [...INITIAL_AUDIT_LOG];

  // Getters
  public getRegime(): OperationalRegime { return this.regime; }
  public getActiveRole(): UserRole { return this.activeRole; }
  public getSites(): Site[] { return this.sites; }
  public getProductionLines(): ProductionLine[] { return this.productionLines; }
  public getBatches(): Batch[] { return this.batches; }
  public getSupplyNodes(): SupplyNode[] { return this.supplyNodes; }
  public getSupplyRoutes(): SupplyRoute[] { return this.supplyRoutes; }
  public getSupplyScenarios(): SupplyScenario[] { return this.supplyScenarios; }
  public getResearchProgrammes(): PharmaResearchProgramme[] { return this.researchProgrammes; }
  public getClinicalStudies(): ClinicalStudy[] { return this.clinicalStudies; }
  public getRegulatorySubmissions(): RegulatorySubmission[] { return this.regulatorySubmissions; }
  public getCropTrials(): CropTrial[] { return this.cropTrials; }
  public getConsumerHealthProducts(): ConsumerHealthProduct[] { return this.consumerHealthProducts; }
  public getQualityEvents(): QualityEvent[] { return this.qualityEvents; }
  public getRiskEvents(): RiskEvent[] { return this.riskEvents; }
  public getScientificDatasets(): ScientificDataset[] { return this.scientificDatasets; }
  public getAIModels(): AIModelRecord[] { return this.aiModels; }
  public getSustainabilityMetrics(): SustainabilityMetric[] { return this.sustainabilityMetrics; }
  public getFinancePlans(): FinancialPlan[] { return this.financePlans; }
  public getAuditLog(): AuditEvent[] { return this.auditLog; }

  // Setters
  public setOperationalRegime(regime: OperationalRegime, actor = 'OPERATIONS_DIRECTOR'): void {
    const prev = this.regime;
    this.regime = regime;
    this.recordAudit(
      'REGIME_CHANGE',
      actor,
      'GROUP_EXECUTIVE',
      'OPERATIONAL_REGIME',
      'GLOBAL_KERNEL',
      `Operational regime changed from ${prev} to ${regime}. Synthetic environmental parameters updated.`,
      prev,
      regime
    );
  }

  public setActiveRole(role: UserRole): void {
    this.activeRole = role;
  }

  // Record Audit Event (Immutable)
  public recordAudit(
    action: string,
    actor: string,
    role: UserRole,
    entityType: string,
    entityId: string,
    details: string,
    previousState?: string,
    newState?: string
  ): AuditEvent {
    const timestamp = new Date().toISOString();
    const id = `AUD-${Date.now()}-${Math.floor(Math.random() * 1000)}`;
    const hash = generateHash(`${id}-${timestamp}-${action}-${actor}-${entityId}`);
    
    const event: AuditEvent = {
      id,
      timestamp,
      action,
      actor,
      role,
      entityType,
      entityId,
      details,
      previousState,
      newState,
      traceabilityHash: hash,
    };

    this.auditLog.unshift(event);
    return event;
  }

  // --- VERTICAL SLICE FUNCTIONAL WORKFLOW ---
  /**
   * Simulates a production delay or material disruption on a selected batch
   * Automatically propagates impact through production line, inventory coverage, risk matrix, quality event, and audit log!
   */
  public simulateProductionDelay(
    batchId: string,
    delayDays: number,
    reason: string,
    actor = 'SITE_MANAGER_LEV'
  ): {
    updatedBatch: Batch;
    newRiskEvent: RiskEvent;
    newQualityEvent: QualityEvent;
    auditEvent: AuditEvent;
    impactSummary: {
      affectedDestinationMarkets: string[];
      inventoryDaysReduction: number;
      estimatedFinancialExposureEUR: number;
    };
  } {
    const batchIndex = this.batches.findIndex((b) => b.id === batchId);
    if (batchIndex === -1) {
      throw new Error(`Batch ID ${batchId} not found`);
    }

    const batch = this.batches[batchIndex];
    const prevStatus = batch.status;

    // 1. Update Batch
    batch.status = 'DELAYED';
    batch.delayReason = reason;
    batch.disruptionImpactDays = delayDays;
    batch.affectedDestinationMarkets = ['Germany (Hospital Networks)', 'USA (Cardiology Depots)', 'Japan (PMDA Verified Stock)'];
    
    // Shift estimated completion date
    const currentEst = new Date(batch.estimatedCompletionDate);
    currentEst.setDate(currentEst.getDate() + delayDays);
    batch.estimatedCompletionDate = currentEst.toISOString();
    batch.traceabilityHash = generateHash(`BATCH-DELAYED-${batch.id}-${Date.now()}`);

    // 2. Update Production Line Status
    const line = this.productionLines.find((l) => l.id === batch.productionLineId);
    if (line) {
      line.status = 'DELAYED_DISRUPTED';
      const currentStage = line.stages.find((s) => s.status === 'IN_PROGRESS');
      if (currentStage) {
        currentStage.status = 'CRITICAL_DELAY';
      }
    }

    // 3. Update Site Risk Score & Incidents Count
    const site = this.sites.find((s) => s.id === batch.siteId);
    if (site) {
      site.status = 'DISRUPTED';
      site.openQualityIncidents += 1;
      site.riskScore = Math.min(100, site.riskScore + 35);
    }

    // 4. Create New Enterprise Risk Event
    const exposureEUR = delayDays * 220000;
    const newRiskEvent: RiskEvent = {
      id: `RSK-EVT-${Date.now()}`,
      riskCode: `RSK-MFG-${Math.floor(Math.random() * 900 + 100)}`,
      title: `Production Disruption on ${batch.productName} (${batch.batchNumber})`,
      category: 'SUPPLY_DISRUPTION',
      probability: 'HIGH',
      impact: 'SEVERE',
      exposureEUR,
      assignedOwner: 'Unassigned (Action Required)',
      status: 'ACTIVE_MONITORING',
      mitigationPlan: `Pending immediate assignment. Auto-calculated ${delayDays} day delay on Batch ${batch.batchNumber}.`,
      createdTimestamp: new Date().toISOString(),
      associatedBatchOrSite: batch.siteName,
    };
    this.riskEvents.unshift(newRiskEvent);

    // 5. Create New Quality Management Event (QMS)
    const newQualityEvent: QualityEvent = {
      id: `QEV-${Date.now()}`,
      eventNumber: `QEV-${batch.siteId.split('-')[1]}-2026-${Math.floor(Math.random() * 900 + 100)}`,
      title: `Unplanned Batch Process Stoppage: ${reason}`,
      severity: 'MAJOR',
      originSite: batch.siteName,
      division: batch.division,
      relatedBatchId: batch.id,
      relatedProductId: batch.productId,
      assignedOwner: 'Dr. H. Weber (QA Manager)',
      creationDate: new Date().toISOString(),
      dueDate: new Date(Date.now() + 7 * 86400000).toISOString(),
      status: 'TRIAGE',
      rootCauseAnalysis: `Simulated operational event: ${reason}. System auto-triggered investigation protocol.`,
      correctiveActions: [
        `Halt stage processing on Line ${line?.lineCode || 'ALPHA'}`,
        'Perform raw material purity & temperature thermal log re-validation',
        'Assess cold chain holding capacity for intermediate bulk',
      ],
      auditHistory: [
        `${new Date().toISOString()}: Quality event opened automatically following batch status shift to DELAYED.`,
      ],
    };
    this.qualityEvents.unshift(newQualityEvent);

    // 6. Record Audit Log
    const auditEvent = this.recordAudit(
      'SIMULATE_PRODUCTION_DELAY',
      actor,
      'SITE_MANAGER',
      'BATCH',
      batch.id,
      `Simulated ${delayDays}-day delay on Batch ${batch.batchNumber}. Reason: ${reason}. Exposure: €${exposureEUR.toLocaleString()}. Downstream markets alerted.`,
      prevStatus,
      'DELAYED'
    );

    return {
      updatedBatch: batch,
      newRiskEvent,
      newQualityEvent,
      auditEvent,
      impactSummary: {
        affectedDestinationMarkets: batch.affectedDestinationMarkets,
        inventoryDaysReduction: delayDays * 1.5,
        estimatedFinancialExposureEUR: exposureEUR,
      },
    };
  }

  // Assign Owner & Plan to Risk Event
  public assignRiskOwner(
    riskId: string,
    owner: string,
    mitigationPlan: string,
    actor = 'GROUP_EXECUTIVE'
  ): RiskEvent {
    const risk = this.riskEvents.find((r) => r.id === riskId);
    if (!risk) throw new Error(`Risk ${riskId} not found`);

    risk.assignedOwner = owner;
    risk.mitigationPlan = mitigationPlan;
    risk.status = 'MITIGATION_IN_PROGRESS';

    this.recordAudit(
      'RISK_MITIGATION_ASSIGNED',
      actor,
      'GROUP_EXECUTIVE',
      'RISK_EVENT',
      risk.id,
      `Risk ${risk.riskCode} assigned to ${owner}. Action plan updated: "${mitigationPlan}"`
    );

    return risk;
  }

  // Triage Quality Event Workflow
  public triageQualityEvent(
    eventId: string,
    newStatus: QualityEvent['status'],
    rootCause: string,
    owner: string,
    actor = 'QUALITY_MANAGER'
  ): QualityEvent {
    const qev = this.qualityEvents.find((q) => q.id === eventId);
    if (!qev) throw new Error(`Quality Event ${eventId} not found`);

    const prevStatus = qev.status;
    qev.status = newStatus;
    if (rootCause) qev.rootCauseAnalysis = rootCause;
    if (owner) qev.assignedOwner = owner;

    const logMessage = `${new Date().toISOString()}: Status updated to ${newStatus} by ${actor}. Root Cause: ${rootCause || 'N/A'}`;
    qev.auditHistory.push(logMessage);

    this.recordAudit(
      'QUALITY_EVENT_TRIAGE',
      actor,
      'QUALITY_MANAGER',
      'QUALITY_EVENT',
      qev.id,
      `Quality Event ${qev.eventNumber} state transitioned from ${prevStatus} -> ${newStatus}. Owner: ${qev.assignedOwner}.`,
      prevStatus,
      newStatus
    );

    return qev;
  }

  // Group Overview Calculated Metrics
  public getGroupOverviewMetrics() {
    const totalSites = this.sites.length;
    const activeManufacturing = this.sites.filter((s) => s.type === 'MANUFACTURING').length;
    const activeResearchProgrammes = this.researchProgrammes.length;
    const activeClinicalProgrammes = this.clinicalStudies.length;
    const activeBatchesCount = this.batches.length;
    const delayedBatchesCount = this.batches.filter((b) => b.status === 'DELAYED' || b.status === 'QUALITY_HOLD').length;
    const openQualityIncidents = this.qualityEvents.filter((q) => q.status !== 'CLOSED').length;
    const totalRiskExposureEUR = this.riskEvents
      .filter((r) => r.status !== 'RESOLVED')
      .reduce((sum, r) => sum + r.exposureEUR, 0);
    const totalEnergyKWh = this.sustainabilityMetrics.reduce((sum, s) => sum + s.energyTotalKWh, 0);
    const totalCarbonScope12MT = this.sustainabilityMetrics.reduce((sum, s) => sum + s.carbonScope1And2MT, 0);

    return {
      totalSites,
      activeManufacturing,
      activeResearchProgrammes,
      activeClinicalProgrammes,
      activeBatchesCount,
      delayedBatchesCount,
      openQualityIncidents,
      totalRiskExposureEUR,
      totalEnergyKWh,
      totalCarbonScope12MT,
      regime: this.regime,
      lastUpdated: new Date().toISOString(),
      syntheticDataFlag: 'SYNTHETIC DEMONSTRATION DATA • NOT OFFICIAL BAYER AG',
    };
  }

  // Operational Report Export
  public generateOperationalReport(): OperationalReport {
    const overview = this.getGroupOverviewMetrics();
    const activeDisruptions = this.batches
      .filter((b) => b.status === 'DELAYED' || b.status === 'QUALITY_HOLD')
      .map((b) => ({
        siteName: b.siteName,
        lineName: b.productionLineId,
        batchNumber: b.batchNumber,
        delayDays: b.disruptionImpactDays || 0,
        reason: b.delayReason || 'Quality investigation hold',
        assignedOwner: 'Site Operations Lead',
      }));

    const report: OperationalReport = {
      generatedAt: new Date().toISOString(),
      reportTitle: 'BAYER.OS Global Life-Sciences Group Operational Executive Summary',
      regime: this.regime,
      summary: {
        totalOperatingSites: overview.totalSites,
        activeManufacturingFacilities: overview.activeManufacturing,
        activeBatchesCount: overview.activeBatchesCount,
        batchesOnQualityHold: overview.delayedBatchesCount,
        disruptedBatchesCount: activeDisruptions.length,
        openCriticalRisks: this.riskEvents.filter((r) => r.impact === 'CATASTROPHIC' || r.impact === 'SEVERE').length,
        overallOEEPercent: 91.2,
        supplyChainResilienceScore: 88.4,
      },
      keyEvents: this.auditLog.slice(0, 5).map((a) => `[${a.timestamp.substring(11, 19)}] ${a.action}: ${a.details}`),
      activeDisruptions,
      auditTrailHash: generateHash(`REPORT-${Date.now()}-${this.auditLog.length}`),
    };

    this.recordAudit(
      'EXPORT_OPERATIONAL_REPORT',
      'EXEC_AUDITOR',
      'GROUP_EXECUTIVE',
      'EXECUTIVE_REPORT',
      report.auditTrailHash,
      `Exported structured operational executive report. Hash: ${report.auditTrailHash}`
    );

    return report;
  }
}

// Global Singleton Database Instance
export const syntheticDb = new SyntheticDatabase();
