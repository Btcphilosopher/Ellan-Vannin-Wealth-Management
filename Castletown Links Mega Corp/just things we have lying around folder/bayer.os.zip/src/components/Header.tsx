import React from 'react';
import { 
  ShieldCheck, 
  Activity, 
  FileText, 
  Layers, 
  User, 
  AlertTriangle,
  Clock,
  Sparkles
} from 'lucide-react';
import { DivisionId, OperationalRegime, UserRole } from '../types';

interface HeaderProps {
  selectedDivision: DivisionId;
  onSelectDivision: (div: DivisionId) => void;
  regime: OperationalRegime;
  onChangeRegime: (r: OperationalRegime) => void;
  role: UserRole;
  onChangeRole: (role: UserRole) => void;
  auditCount: number;
  onOpenAuditLog: () => void;
  onOpenReportModal: () => void;
  onTriggerDelayModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  selectedDivision,
  onSelectDivision,
  regime,
  onChangeRegime,
  role,
  onChangeRole,
  auditCount,
  onOpenAuditLog,
  onOpenReportModal,
  onTriggerDelayModal,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-[#121826] text-slate-100 border-b border-slate-800 shadow-md">
      {/* Synthetic Data Banner */}
      <div className="bg-[#0B132B] px-4 py-1 text-[11px] font-mono tracking-wider text-emerald-400 border-b border-slate-800/80 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
          <span className="font-semibold text-slate-300">BAYER.OS KERNEL v2.4.0</span>
          <span className="text-slate-500">•</span>
          <span className="text-amber-300 font-sans font-medium">SYNTHETIC DEMONSTRATION ENVIRONMENT</span>
          <span className="text-slate-500">•</span>
          <span className="text-slate-400 font-sans hidden md:inline">NOT OFFICIAL BAYER AG SYSTEM • NO REAL OPERATIONAL DATA USED</span>
        </div>
        <div className="flex items-center gap-3 font-mono text-[10px] text-slate-400">
          <span>LATENCY: 12ms</span>
          <span>SYNC: REAL-TIME</span>
          <span>SYS_HASH: 0x98F42A1</span>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="px-4 py-2.5 flex flex-wrap items-center justify-between gap-3">
        {/* Logo & Title */}
        <div className="flex items-center gap-3">
          <div className="flex items-center justify-center w-8 h-8 rounded bg-gradient-to-br from-emerald-600 to-teal-800 text-white font-bold font-mono text-sm tracking-tighter border border-emerald-400/30 shadow-inner">
            BOS
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-bold tracking-wider font-mono text-white">BAYER.OS</h1>
              <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700">
                SUPERMODERNIST ENTERPRISE
              </span>
            </div>
            <p className="text-[11px] text-slate-400">Global Life-Sciences Operating Network</p>
          </div>
        </div>

        {/* Division Switcher */}
        <div className="flex items-center bg-slate-900/90 rounded p-0.5 border border-slate-800">
          <button
            onClick={() => onSelectDivision('GROUP')}
            className={`px-3 py-1 text-xs font-medium rounded transition-all ${
              selectedDivision === 'GROUP'
                ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Group Overview
          </button>
          <button
            onClick={() => onSelectDivision('PHARMA')}
            className={`px-3 py-1 text-xs font-medium rounded transition-all ${
              selectedDivision === 'PHARMA'
                ? 'bg-sky-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Pharmaceuticals
          </button>
          <button
            onClick={() => onSelectDivision('CROP_SCIENCE')}
            className={`px-3 py-1 text-xs font-medium rounded transition-all ${
              selectedDivision === 'CROP_SCIENCE'
                ? 'bg-amber-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Crop Science
          </button>
          <button
            onClick={() => onSelectDivision('CONSUMER_HEALTH')}
            className={`px-3 py-1 text-xs font-medium rounded transition-all ${
              selectedDivision === 'CONSUMER_HEALTH'
                ? 'bg-rose-600 text-white font-semibold shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            Consumer Health
          </button>
        </div>

        {/* Quick Action Controls */}
        <div className="flex items-center gap-2.5">
          {/* Vertical Slice Simulation Trigger Button */}
          <button
            onClick={onTriggerDelayModal}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-amber-500/10 text-amber-300 hover:bg-amber-500/20 border border-amber-500/30 rounded text-xs font-medium transition"
            title="Simulate a production batch delay and propagate downstream risk"
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            <span>Simulate Disruption</span>
          </button>

          {/* Operational Regime Selector */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded px-2 py-1 text-xs">
            <Activity className="w-3.5 h-3.5 text-emerald-400" />
            <select
              value={regime}
              onChange={(e) => onChangeRegime(e.target.value as OperationalRegime)}
              className="bg-transparent text-slate-200 text-xs font-mono focus:outline-none cursor-pointer"
            >
              <option value="NORMAL">Regime: Normal Operations</option>
              <option value="HIGH_DEMAND">Regime: Peak Market Demand</option>
              <option value="MANUFACTURING_DISRUPTION">Regime: Mfg Disruption</option>
              <option value="SUPPLY_SHORTAGE">Regime: Material Shortage</option>
              <option value="REGULATORY_DELAY">Regime: Regulatory Review</option>
              <option value="SEVERE_WEATHER">Regime: Extreme Agronomic Weather</option>
            </select>
          </div>

          {/* User Role Selector */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded px-2 py-1 text-xs">
            <User className="w-3.5 h-3.5 text-sky-400" />
            <select
              value={role}
              onChange={(e) => onChangeRole(e.target.value as UserRole)}
              className="bg-transparent text-slate-200 text-xs focus:outline-none cursor-pointer"
            >
              <option value="GROUP_EXECUTIVE">Group Executive</option>
              <option value="DIVISION_DIRECTOR">Division Director</option>
              <option value="SITE_MANAGER">Site Manager (Leverkusen)</option>
              <option value="QUALITY_MANAGER">Quality QA/QC Lead</option>
              <option value="SUPPLY_CHAIN_ANALYST">Supply Chain Lead</option>
              <option value="RESEARCH_LEAD">Research Scientist</option>
            </select>
          </div>

          {/* Operational Report Button */}
          <button
            onClick={onOpenReportModal}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs border border-slate-700 font-medium transition"
          >
            <FileText className="w-3.5 h-3.5 text-sky-400" />
            <span className="hidden sm:inline">Exec Report</span>
          </button>

          {/* Audit Log Drawer Toggle */}
          <button
            onClick={onOpenAuditLog}
            className="relative flex items-center gap-1.5 px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs border border-slate-700 font-mono transition"
            title="View Immutable Audit Trail Log"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
            <span className="hidden md:inline text-[11px]">AUDIT LOG</span>
            <span className="ml-1 px-1.5 py-0.2 bg-emerald-500/20 text-emerald-300 rounded-full text-[10px] font-bold">
              {auditCount}
            </span>
          </button>
        </div>
      </div>
    </header>
  );
};
