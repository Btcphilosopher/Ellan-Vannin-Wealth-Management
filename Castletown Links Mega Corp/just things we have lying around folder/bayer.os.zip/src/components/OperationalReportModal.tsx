import React from 'react';
import { X, FileText, Download, CheckCircle2, AlertTriangle, ShieldCheck, Printer } from 'lucide-react';
import { OperationalReport } from '../types';

interface OperationalReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  report: OperationalReport | null;
}

export const OperationalReportModal: React.FC<OperationalReportModalProps> = ({
  isOpen,
  onClose,
  report,
}) => {
  if (!isOpen || !report) return null;

  const handleDownloadJson = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(report, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `BAYER_OS_Operational_Report_${Date.now()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 backdrop-blur-xs p-4">
      <div className="w-full max-w-3xl bg-[#0B132B] text-slate-100 rounded-lg border border-slate-800 shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-[#121826] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-sky-500/10 text-sky-400 rounded border border-sky-500/20">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold font-mono tracking-wide text-white">EXECUTIVE OPERATIONAL REPORT</h2>
              <p className="text-xs text-slate-400">Structured Group Performance & Disruption Impact Statement</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Report Body */}
        <div className="p-6 overflow-y-auto space-y-6 font-sans text-xs">
          {/* Metadata Banner */}
          <div className="p-3.5 bg-slate-900 rounded border border-slate-800 grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-[11px]">
            <div>
              <span className="text-slate-400 block">GENERATED AT:</span>
              <span className="text-slate-200 font-semibold">{new Date(report.generatedAt).toLocaleString()}</span>
            </div>
            <div>
              <span className="text-slate-400 block">OPERATIONAL REGIME:</span>
              <span className="text-emerald-400 font-semibold">{report.regime}</span>
            </div>
            <div>
              <span className="text-slate-400 block">AUDIT CHAIN HASH:</span>
              <span className="text-sky-400 font-semibold">{report.auditTrailHash.substring(0, 12)}...</span>
            </div>
            <div>
              <span className="text-slate-400 block">SOURCE CLASSIFICATION:</span>
              <span className="text-amber-300 font-semibold">SYNTHETIC DEMO</span>
            </div>
          </div>

          {/* Key Metrics Summary Cards */}
          <div>
            <h3 className="text-xs font-bold font-mono text-slate-300 uppercase tracking-wider mb-2">OPERATIONAL KPIS SUMMARY</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-slate-900 rounded border border-slate-800 text-center">
                <span className="text-slate-400 block text-[10px]">OPERATING SITES</span>
                <span className="text-lg font-bold font-mono text-white">{report.summary.totalOperatingSites}</span>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800 text-center">
                <span className="text-slate-400 block text-[10px]">ACTIVE MFG PLANTS</span>
                <span className="text-lg font-bold font-mono text-white">{report.summary.activeManufacturingFacilities}</span>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800 text-center">
                <span className="text-slate-400 block text-[10px]">TOTAL ACTIVE BATCHES</span>
                <span className="text-lg font-bold font-mono text-sky-400">{report.summary.activeBatchesCount}</span>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800 text-center">
                <span className="text-slate-400 block text-[10px]">DISRUPTED / DELAYED</span>
                <span className="text-lg font-bold font-mono text-amber-400">{report.summary.disruptedBatchesCount}</span>
              </div>
            </div>
          </div>

          {/* Active Disruptions Section */}
          <div>
            <h3 className="text-xs font-bold font-mono text-slate-300 uppercase tracking-wider mb-2 flex items-center justify-between">
              <span>ACTIVE MANUFACTURING DISRUPTIONS & HOLDS</span>
              <span className="text-amber-400 font-normal">{report.activeDisruptions.length} ACTIVE</span>
            </h3>
            {report.activeDisruptions.length === 0 ? (
              <div className="p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 rounded text-center font-mono">
                No active manufacturing delays or holds registered in current operational cycle.
              </div>
            ) : (
              <div className="space-y-2">
                {report.activeDisruptions.map((dis, i) => (
                  <div key={i} className="p-3 bg-slate-900 rounded border border-slate-800 flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 font-mono text-xs font-bold text-white">
                        <AlertTriangle className="w-4 h-4 text-amber-400" />
                        <span>{dis.siteName}</span>
                        <span className="text-slate-500">•</span>
                        <span className="text-sky-400">{dis.batchNumber}</span>
                      </div>
                      <p className="text-slate-300 text-xs mt-1">{dis.reason}</p>
                    </div>
                    <div className="text-right font-mono">
                      <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold text-xs block">
                        +{dis.delayDays} DAYS DELAY
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Recent Audit Trail Events */}
          <div>
            <h3 className="text-xs font-bold font-mono text-slate-300 uppercase tracking-wider mb-2">AUDIT TRAIL LOG SNAPSHOT</h3>
            <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1.5 font-mono text-[11px] text-slate-300">
              {report.keyEvents.map((evt, i) => (
                <div key={i} className="border-b border-slate-800/60 pb-1 last:border-none">
                  {evt}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 border-t border-slate-800 bg-[#121826] flex items-center justify-between">
          <div className="flex items-center gap-2 text-slate-400 font-mono text-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>VERIFIED AUDITABLE EXPORT</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadJson}
              className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded font-medium text-xs shadow transition"
            >
              <Download className="w-4 h-4" />
              <span>Download JSON Report</span>
            </button>
            <button
              onClick={() => window.print()}
              className="flex items-center gap-1.5 px-3 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-medium text-xs border border-slate-700 transition"
            >
              <Printer className="w-4 h-4" />
              <span>Print</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
