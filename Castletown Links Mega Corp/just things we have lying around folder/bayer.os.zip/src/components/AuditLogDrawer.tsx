import React from 'react';
import { X, ShieldCheck, Hash, User, Clock, FileCode2, Copy, Check } from 'lucide-react';
import { AuditEvent } from '../types';

interface AuditLogDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  auditEvents: AuditEvent[];
}

export const AuditLogDrawer: React.FC<AuditLogDrawerProps> = ({ isOpen, onClose, auditEvents }) => {
  const [copiedId, setCopiedId] = React.useState<string | null>(null);

  if (!isOpen) return null;

  const copyHash = (hash: string, id: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-900/60 backdrop-blur-xs transition-opacity">
      <div className="w-full max-w-xl bg-[#121826] text-slate-100 h-full border-l border-slate-800 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b border-slate-800 bg-[#0B132B] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <div>
              <h2 className="text-sm font-bold font-mono tracking-wide text-white">IMMUTABLE ENTERPRISE AUDIT TRAIL</h2>
              <p className="text-xs text-slate-400">Cryptographically Hashed Record of All State Modifications</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Audit Disclaimer */}
        <div className="px-5 py-2.5 bg-slate-900/90 text-xs font-mono text-slate-300 border-b border-slate-800 flex items-center justify-between">
          <span>TOTAL LOGGED EVENTS: {auditEvents.length}</span>
          <span className="text-emerald-400 font-semibold">VERIFIED HASH CHAIN: OK</span>
        </div>

        {/* Audit Log Entries List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 font-mono">
          {auditEvents.map((evt) => (
            <div
              key={evt.id}
              className="p-3.5 bg-slate-900/80 rounded border border-slate-800 hover:border-slate-700 transition text-xs space-y-2"
            >
              <div className="flex items-center justify-between text-[11px] text-slate-400">
                <div className="flex items-center gap-1.5 font-bold text-emerald-400">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{new Date(evt.timestamp).toLocaleTimeString()}</span>
                  <span className="text-slate-600">•</span>
                  <span>{new Date(evt.timestamp).toLocaleDateString()}</span>
                </div>
                <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700 font-bold">
                  {evt.action}
                </span>
              </div>

              <p className="text-slate-200 font-sans text-xs leading-relaxed">{evt.details}</p>

              <div className="pt-2 border-t border-slate-800/80 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-400">
                <div className="flex items-center gap-1">
                  <User className="w-3 h-3 text-sky-400" />
                  <span>{evt.actor} ({evt.role})</span>
                </div>
                <div className="flex items-center gap-1.5 bg-slate-950 px-2 py-1 rounded border border-slate-800 font-mono text-[10px]">
                  <Hash className="w-3 h-3 text-emerald-400" />
                  <span className="text-slate-300">{evt.traceabilityHash.substring(0, 14)}...</span>
                  <button
                    onClick={() => copyHash(evt.traceabilityHash, evt.id)}
                    className="text-slate-400 hover:text-white ml-1"
                    title="Copy full cryptographic hash"
                  >
                    {copiedId === evt.id ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Footer */}
        <div className="p-3 border-t border-slate-800 bg-[#0B132B] text-center font-mono text-[11px] text-slate-500">
          BAYER.OS AUDIT ENGINE • COMPLIANT WITH FDA 21 CFR PART 11 / EU ANNEX 11 LOGGING SPECIFICATIONS
        </div>
      </div>
    </div>
  );
};
