import React, { useState } from 'react';
import { X, AlertTriangle, ShieldAlert, ArrowRight, CheckCircle2, Factory, PackageCheck } from 'lucide-react';
import { Batch } from '../types';

interface SimulateDelayModalProps {
  isOpen: boolean;
  onClose: () => void;
  batches: Batch[];
  onExecuteSimulation: (batchId: string, delayDays: number, reason: string) => Promise<any>;
}

export const SimulateDelayModal: React.FC<SimulateDelayModalProps> = ({
  isOpen,
  onClose,
  batches,
  onExecuteSimulation,
}) => {
  const [selectedBatchId, setSelectedBatchId] = useState<string>(batches[0]?.id || '');
  const [delayDays, setDelayDays] = useState<number>(3);
  const [reason, setReason] = useState<string>('Bioreactor Sterile Lyophilizer Temperature Micro-Excursion');
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [simulationResult, setSimulationResult] = useState<any | null>(null);

  if (!isOpen) return null;

  const handleRun = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedBatchId) return;
    setIsSubmitting(true);
    try {
      const res = await onExecuteSimulation(selectedBatchId, delayDays, reason);
      setSimulationResult(res);
    } catch (err: any) {
      alert('Error simulating delay: ' + err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setSimulationResult(null);
  };

  const selectedBatch = batches.find((b) => b.id === selectedBatchId) || batches[0];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/75 backdrop-blur-xs p-4">
      <div className="w-full max-w-2xl bg-[#0B132B] text-slate-100 rounded-lg border border-slate-800 shadow-2xl overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-800 bg-[#121826] flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 text-amber-400 rounded border border-amber-500/20">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-bold font-mono tracking-wide text-white">SIMULATE PRODUCTION & SUPPLY DISRUPTION</h2>
              <p className="text-xs text-slate-400">Vertical Slice Step 10: Automatic Downstream Risk & Quality Propagation</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Form or Result View */}
        {!simulationResult ? (
          <form onSubmit={handleRun} className="p-6 space-y-5 font-sans text-xs">
            <div>
              <label className="block text-slate-300 font-mono font-bold mb-1">SELECT TARGET PRODUCTION BATCH:</label>
              <select
                value={selectedBatchId}
                onChange={(e) => setSelectedBatchId(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-amber-500"
              >
                {batches.map((b) => (
                  <option key={b.id} value={b.id}>
                    {b.batchNumber} - {b.productName} ({b.siteName})
                  </option>
                ))}
              </select>
            </div>

            {selectedBatch && (
              <div className="p-3 bg-slate-900/90 rounded border border-slate-800 font-mono text-[11px] space-y-1">
                <div className="text-slate-400">CURRENT BATCH STATE:</div>
                <div className="text-white font-bold">{selectedBatch.productName}</div>
                <div className="text-slate-300">Site: {selectedBatch.siteName} | Line: {selectedBatch.productionLineId}</div>
                <div className="text-emerald-400">Status: {selectedBatch.status} | Progress: {selectedBatch.progressPercent}%</div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-slate-300 font-mono font-bold mb-1">SCHEDULE DELAY (DAYS):</label>
                <input
                  type="number"
                  min={1}
                  max={30}
                  value={delayDays}
                  onChange={(e) => setDelayDays(Number(e.target.value))}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                />
              </div>
              <div>
                <label className="block text-slate-300 font-mono font-bold mb-1">ROOT CAUSE CATEGORY:</label>
                <select
                  value={reason}
                  onChange={(e) => setReason(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded px-3 py-2 text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                >
                  <option value="Bioreactor Sterile Lyophilizer Temperature Micro-Excursion">Bioreactor Lyophilizer Temp Excursion</option>
                  <option value="Raw Material Active API Purity Hold in Quality Testing">API Quality Testing Hold</option>
                  <option value="Aseptic Vial Filling Line Mechanical Seal Replacement">Filling Line Seal Failure</option>
                  <option value="Cold Chain Air Freight Thermal Excursion Incident">Trans-Atlantic Thermal Excursion</option>
                </select>
              </div>
            </div>

            <div className="p-3 bg-amber-500/10 border border-amber-500/20 text-amber-300 rounded font-mono text-[11px] space-y-1">
              <div className="font-bold flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-amber-400" />
                <span>WHAT WILL HAPPEN UPON EXECUTION:</span>
              </div>
              <ul className="list-disc list-inside space-y-0.5 text-slate-300 pl-1">
                <li>Batch status shifts to <span className="text-amber-400 font-bold">DELAYED</span> & completion date adjusts</li>
                <li>Production Line stage sets to <span className="text-rose-400 font-bold">CRITICAL_DELAY</span></li>
                <li>Creates new <span className="text-sky-400 font-bold">QMS Quality Deviation Event</span></li>
                <li>Calculates <span className="text-rose-400 font-bold">Enterprise Risk Exposure (€{delayDays * 220000})</span></li>
                <li>Logs immutable <span className="text-emerald-400 font-bold">Audit Event with cryptographic hash</span></li>
              </ul>
            </div>

            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-medium text-xs transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="flex items-center gap-2 px-5 py-2 bg-amber-600 hover:bg-amber-500 text-white rounded font-bold font-mono text-xs shadow transition disabled:opacity-50"
              >
                <span>{isSubmitting ? 'PROPAGATING DISRUPTION...' : 'EXECUTE SIMULATION'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        ) : (
          /* Simulation Result View */
          <div className="p-6 space-y-5 font-sans text-xs">
            <div className="p-4 bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 rounded flex items-center gap-3">
              <CheckCircle2 className="w-6 h-6 text-emerald-400 shrink-0" />
              <div>
                <h3 className="font-bold font-mono text-sm text-white">DISRUPTION PROPAGATED SUCCESSFULLY</h3>
                <p className="text-xs text-slate-300">All enterprise modules updated in real time with persisted state.</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 font-mono text-xs">
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">UPDATED BATCH:</span>
                <span className="text-white font-bold">{simulationResult.updatedBatch.batchNumber}</span>
                <span className="text-amber-400 block text-[11px] font-bold mt-1">
                  STATUS: {simulationResult.updatedBatch.status} (+{simulationResult.updatedBatch.disruptionImpactDays} DAYS)
                </span>
              </div>
              <div className="p-3 bg-slate-900 rounded border border-slate-800">
                <span className="text-slate-400 block text-[10px]">ENTERPRISE FINANCIAL EXPOSURE:</span>
                <span className="text-rose-400 font-bold text-sm block mt-1">
                  €{simulationResult.impactSummary.estimatedFinancialExposureEUR.toLocaleString()}
                </span>
              </div>
            </div>

            <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-2 font-mono text-[11px]">
              <div className="text-sky-400 font-bold">CREATED QMS EVENT:</div>
              <div className="text-white">{simulationResult.newQualityEvent.eventNumber}: {simulationResult.newQualityEvent.title}</div>
              <div className="text-slate-400">Assigned QA Owner: {simulationResult.newQualityEvent.assignedOwner}</div>
            </div>

            <div className="p-3 bg-slate-900 rounded border border-slate-800 space-y-1 font-mono text-[11px]">
              <div className="text-emerald-400 font-bold">IMMUTABLE AUDIT LOGGED:</div>
              <div className="text-slate-300 truncate">Hash: {simulationResult.auditEvent.traceabilityHash}</div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <button
                onClick={handleReset}
                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded font-mono text-xs"
              >
                Simulate Another Batch
              </button>
              <button
                onClick={onClose}
                className="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded text-xs transition"
              >
                Close & Inspect Dashboard
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
