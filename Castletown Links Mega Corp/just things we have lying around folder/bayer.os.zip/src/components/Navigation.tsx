import React from 'react';
import { 
  Globe, 
  MapPin, 
  TrendingUp, 
  AlertOctagon, 
  Dna, 
  Microscope, 
  FileCheck2, 
  Sprout, 
  Sun, 
  Package, 
  Factory, 
  Workflow, 
  GitBranch, 
  Database, 
  BrainCircuit, 
  Leaf, 
  DollarSign, 
  Sliders,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';

export type NavViewId = 
  // Global Control
  | 'GROUP_OVERVIEW' 
  | 'ENTERPRISE_MAP' 
  | 'CORPORATE_PERFORMANCE' 
  | 'ENTERPRISE_RISK' 
  // Pharmaceuticals
  | 'PHARMA_RESEARCH' 
  | 'PHARMA_CLINICAL' 
  | 'PHARMA_REGULATORY' 
  // Crop Science
  | 'CROP_PORTFOLIO' 
  | 'CROP_FIELD_TRIALS' 
  | 'CROP_DIGITAL_TWIN' 
  // Consumer Health
  | 'CONSUMER_PORTFOLIO' 
  | 'CONSUMER_DEMAND' 
  // Industrial Operations
  | 'MFG_SITES_TWIN' 
  | 'MFG_PRODUCTION_LINES' 
  | 'MFG_BATCH_TRACEABILITY' 
  // Supply Network
  | 'SUPPLY_NETWORK_GRAPH' 
  | 'SUPPLY_SCENARIOS_LAB' 
  // Science & Data
  | 'SCIENCE_KNOWLEDGE_GRAPH' 
  | 'SCIENCE_AI_REGISTRY' 
  // Corporate Functions
  | 'CORP_SUSTAINABILITY' 
  | 'CORP_FINANCE' 
  | 'CORP_GOVERNANCE';

interface NavigationProps {
  activeView: NavViewId;
  onSelectView: (view: NavViewId) => void;
  openRisksCount: number;
  openQualityEventsCount: number;
  delayedBatchesCount: number;
}

export const Navigation: React.FC<NavigationProps> = ({
  activeView,
  onSelectView,
  openRisksCount,
  openQualityEventsCount,
  delayedBatchesCount,
}) => {
  const sections = [
    {
      title: 'GLOBAL CONTROL',
      items: [
        { id: 'GROUP_OVERVIEW' as NavViewId, label: 'Group Overview', icon: Globe },
        { id: 'ENTERPRISE_MAP' as NavViewId, label: 'Enterprise Map & Twin', icon: MapPin },
        { id: 'CORPORATE_PERFORMANCE' as NavViewId, label: 'Corporate Performance', icon: TrendingUp },
        { id: 'ENTERPRISE_RISK' as NavViewId, label: 'Enterprise Risk Matrix', icon: AlertOctagon, badge: openRisksCount, badgeColor: 'bg-rose-500/20 text-rose-300' },
      ],
    },
    {
      title: 'PHARMACEUTICALS',
      items: [
        { id: 'PHARMA_RESEARCH' as NavViewId, label: 'Research Portfolio', icon: Dna },
        { id: 'PHARMA_CLINICAL' as NavViewId, label: 'Clinical Programmes', icon: Microscope },
        { id: 'PHARMA_REGULATORY' as NavViewId, label: 'Regulatory Affairs', icon: FileCheck2 },
      ],
    },
    {
      title: 'CROP SCIENCE',
      items: [
        { id: 'CROP_PORTFOLIO' as NavViewId, label: 'Crop Portfolio & Traits', icon: Sprout },
        { id: 'CROP_FIELD_TRIALS' as NavViewId, label: 'Field Trials Workspace', icon: Sun },
        { id: 'CROP_DIGITAL_TWIN' as NavViewId, label: 'Agronomic Digital Twin', icon: MapPin },
      ],
    },
    {
      title: 'CONSUMER HEALTH',
      items: [
        { id: 'CONSUMER_PORTFOLIO' as NavViewId, label: 'Brand Portfolio', icon: Package },
        { id: 'CONSUMER_DEMAND' as NavViewId, label: 'Demand & Availability', icon: TrendingUp },
      ],
    },
    {
      title: 'INDUSTRIAL OPERATIONS',
      items: [
        { id: 'MFG_SITES_TWIN' as NavViewId, label: 'Global Manufacturing Sites', icon: Factory },
        { id: 'MFG_PRODUCTION_LINES' as NavViewId, label: 'Production Lines & Assets', icon: Workflow },
        { id: 'MFG_BATCH_TRACEABILITY' as NavViewId, label: 'Batch Traceability & Disruption', icon: GitBranch, badge: delayedBatchesCount > 0 ? `${delayedBatchesCount} HOLD` : undefined, badgeColor: 'bg-amber-500/20 text-amber-300' },
      ],
    },
    {
      title: 'SUPPLY NETWORK',
      items: [
        { id: 'SUPPLY_NETWORK_GRAPH' as NavViewId, label: 'Supply Network Graph', icon: GitBranch },
        { id: 'SUPPLY_SCENARIOS_LAB' as NavViewId, label: 'Scenario Laboratory', icon: ShieldAlert },
      ],
    },
    {
      title: 'SCIENCE & DATA',
      items: [
        { id: 'SCIENCE_KNOWLEDGE_GRAPH' as NavViewId, label: 'Research Knowledge Graph', icon: Database },
        { id: 'SCIENCE_AI_REGISTRY' as NavViewId, label: 'AI & Analytics Registry', icon: BrainCircuit },
      ],
    },
    {
      title: 'CORPORATE FUNCTIONS',
      items: [
        { id: 'CORP_SUSTAINABILITY' as NavViewId, label: 'Sustainability Operations', icon: Leaf },
        { id: 'CORP_FINANCE' as NavViewId, label: 'Finance & CapEx Pipeline', icon: DollarSign },
        { id: 'CORP_GOVERNANCE' as NavViewId, label: 'System Governance & Health', icon: Sliders },
      ],
    },
  ];

  return (
    <aside className="w-64 bg-[#182030] text-slate-300 border-r border-slate-800 flex flex-col shrink-0 select-none overflow-y-auto">
      <div className="p-3 border-b border-slate-800 bg-[#121826]/60 flex items-center justify-between">
        <span className="text-[10px] font-mono tracking-widest text-slate-400 uppercase font-semibold">NAVIGATION MATRIX</span>
        <span className="text-[10px] font-mono text-emerald-400">8 MODULES</span>
      </div>

      <div className="p-2 space-y-4 text-xs font-sans">
        {sections.map((section, idx) => (
          <div key={idx} className="space-y-1">
            <div className="px-2 py-1 text-[10px] font-mono font-bold tracking-wider text-slate-400 uppercase flex items-center justify-between">
              <span>{section.title}</span>
            </div>
            <div className="space-y-0.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = activeView === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => onSelectView(item.id)}
                    className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded transition-all text-left ${
                      isActive
                        ? 'bg-slate-800 text-white font-medium border-l-2 border-emerald-500 shadow-sm'
                        : 'text-slate-300 hover:bg-slate-800/50 hover:text-white'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <Icon className={`w-3.5 h-3.5 shrink-0 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                      <span className="truncate text-[12px]">{item.label}</span>
                    </div>
                    {item.badge !== undefined && item.badge !== 0 && (
                      <span className={`px-1.5 py-0.2 rounded text-[10px] font-mono font-bold ${item.badgeColor || 'bg-slate-700 text-slate-200'}`}>
                        {item.badge}
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Footer System Status Widget */}
      <div className="mt-auto p-3 border-t border-slate-800 bg-[#121826]/90 font-mono text-[11px] text-slate-400 space-y-1.5">
        <div className="flex items-center justify-between">
          <span className="text-[10px] text-slate-400">QMS EVENTS:</span>
          <span className="text-amber-400 font-bold">{openQualityEventsCount} OPEN</span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-[10px] text-slate-400">RISK EXPOSURE:</span>
          <span className="text-rose-400 font-bold">€4.2M</span>
        </div>
        <div className="pt-1 text-[10px] text-slate-400 border-t border-slate-800/60 flex items-center gap-1">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
          <span>SCADA PLC SYNCED</span>
        </div>
      </div>
    </aside>
  );
};
