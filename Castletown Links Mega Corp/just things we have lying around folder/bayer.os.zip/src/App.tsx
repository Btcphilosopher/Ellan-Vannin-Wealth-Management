import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Navigation, NavViewId } from './components/Navigation';
import { AuditLogDrawer } from './components/AuditLogDrawer';
import { OperationalReportModal } from './components/OperationalReportModal';
import { SimulateDelayModal } from './components/SimulateDelayModal';

// Modules
import { GroupOverview } from './modules/GlobalControl/GroupOverview';
import { EnterpriseMap } from './modules/GlobalControl/EnterpriseMap';
import { EnterpriseRisk } from './modules/GlobalControl/EnterpriseRisk';
import { PharmaWorkspace } from './modules/Pharmaceuticals/PharmaWorkspace';
import { CropScienceWorkspace } from './modules/CropScience/CropScienceWorkspace';
import { ConsumerHealthWorkspace } from './modules/ConsumerHealth/ConsumerHealthWorkspace';
import { ManufacturingDigitalTwin } from './modules/IndustrialOperations/ManufacturingDigitalTwin';
import { SupplyNetworkGraph } from './modules/SupplyNetwork/SupplyNetworkGraph';
import { QualityManagementSystem } from './modules/QualityCompliance/QualityManagementSystem';
import { ScienceAndAnalyticsWorkspace } from './modules/ScienceData/ScienceAndAnalyticsWorkspace';
import { CorporateFunctionsWorkspace } from './modules/CorporateFunctions/CorporateFunctionsWorkspace';

import { syntheticDb } from './data/syntheticDatabase';
import { 
  DivisionId, 
  OperationalRegime, 
  UserRole, 
  Site, 
  ProductionLine, 
  Batch, 
  RiskEvent, 
  QualityEvent, 
  AuditEvent, 
  OperationalReport 
} from './types';

export function App() {
  // Navigation & View State
  const [activeView, setActiveView] = useState<NavViewId>('GROUP_OVERVIEW');
  const [selectedDivision, setSelectedDivision] = useState<DivisionId>('GROUP');
  const [regime, setRegime] = useState<OperationalRegime>('NORMAL');
  const [role, setRole] = useState<UserRole>('GROUP_EXECUTIVE');

  // Modals & Drawers
  const [isAuditDrawerOpen, setIsAuditDrawerOpen] = useState<boolean>(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);
  const [isDelayModalOpen, setIsDelayModalOpen] = useState<boolean>(false);

  // Selected Entities
  const [selectedSiteId, setSelectedSiteId] = useState<string>('SITE-LEV-01');

  // Application Data State
  const [overviewMetrics, setOverviewMetrics] = useState<any>(syntheticDb.getGroupOverviewMetrics());
  const [sites, setSites] = useState<Site[]>(syntheticDb.getSites());
  const [productionLines, setProductionLines] = useState<ProductionLine[]>(syntheticDb.getProductionLines());
  const [batches, setBatches] = useState<Batch[]>(syntheticDb.getBatches());
  const [riskEvents, setRiskEvents] = useState<RiskEvent[]>(syntheticDb.getRiskEvents());
  const [qualityEvents, setQualityEvents] = useState<QualityEvent[]>(syntheticDb.getQualityEvents());
  const [auditEvents, setAuditEvents] = useState<AuditEvent[]>(syntheticDb.getAuditLog());
  const [operationalReport, setOperationalReport] = useState<OperationalReport | null>(null);

  // Refresh State from Engine
  const refreshState = () => {
    setOverviewMetrics(syntheticDb.getGroupOverviewMetrics());
    setSites(syntheticDb.getSites());
    setProductionLines(syntheticDb.getProductionLines());
    setBatches(syntheticDb.getBatches());
    setRiskEvents(syntheticDb.getRiskEvents());
    setQualityEvents(syntheticDb.getQualityEvents());
    setAuditEvents(syntheticDb.getAuditLog());
    setRegime(syntheticDb.getRegime());
  };

  useEffect(() => {
    refreshState();
  }, []);

  // Handlers
  const handleRegimeChange = (newRegime: OperationalRegime) => {
    syntheticDb.setOperationalRegime(newRegime, role);
    refreshState();
  };

  const handleRoleChange = (newRole: UserRole) => {
    setRole(newRole);
    syntheticDb.setActiveRole(newRole);
  };

  const handleDivisionChange = (div: DivisionId) => {
    setSelectedDivision(div);
    if (div === 'GROUP') setActiveView('GROUP_OVERVIEW');
    else if (div === 'PHARMA') setActiveView('PHARMA_RESEARCH');
    else if (div === 'CROP_SCIENCE') setActiveView('CROP_PORTFOLIO');
    else if (div === 'CONSUMER_HEALTH') setActiveView('CONSUMER_PORTFOLIO');
  };

  const handleOpenSiteTwin = (siteId: string) => {
    setSelectedSiteId(siteId);
    setActiveView('MFG_SITES_TWIN');
  };

  const handleExecuteDelaySimulation = async (batchId: string, delayDays: number, reason: string) => {
    const res = syntheticDb.simulateProductionDelay(batchId, delayDays, reason, role);
    refreshState();
    return res;
  };

  const handleTriageQualityEvent = async (
    eventId: string,
    status: QualityEvent['status'],
    rootCause: string,
    owner: string
  ) => {
    const res = syntheticDb.triageQualityEvent(eventId, status, rootCause, owner, role);
    refreshState();
    return res;
  };

  const handleAssignRiskOwner = async (riskId: string, owner: string, mitigationPlan: string) => {
    const res = syntheticDb.assignRiskOwner(riskId, owner, mitigationPlan, role);
    refreshState();
    return res;
  };

  const handleOpenReportModal = () => {
    const report = syntheticDb.generateOperationalReport();
    setOperationalReport(report);
    setIsReportModalOpen(true);
  };

  // Delayed batches count for nav badge
  const delayedBatchesCount = batches.filter((b) => b.status === 'DELAYED' || b.status === 'QUALITY_HOLD').length;
  const openRisksCount = riskEvents.filter((r) => r.status === 'ACTIVE_MONITORING' || r.status === 'MITIGATION_IN_PROGRESS').length;
  const openQualityEventsCount = qualityEvents.filter((q) => q.status !== 'CLOSED').length;

  return (
    <div className="min-h-screen bg-[#0B132B] text-slate-100 flex flex-col font-sans antialiased selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Persistent Enterprise Header */}
      <Header
        selectedDivision={selectedDivision}
        onSelectDivision={handleDivisionChange}
        regime={regime}
        onChangeRegime={handleRegimeChange}
        role={role}
        onChangeRole={handleRoleChange}
        auditCount={auditEvents.length}
        onOpenAuditLog={() => setIsAuditDrawerOpen(true)}
        onOpenReportModal={handleOpenReportModal}
        onTriggerDelayModal={() => setIsDelayModalOpen(true)}
      />

      {/* Main Container Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Persistent Navigation Matrix */}
        <Navigation
          activeView={activeView}
          onSelectView={setActiveView}
          openRisksCount={openRisksCount}
          openQualityEventsCount={openQualityEventsCount}
          delayedBatchesCount={delayedBatchesCount}
        />

        {/* Dynamic View Workspace Content */}
        <main className="flex-1 overflow-y-auto bg-[#0d1733] min-w-0">
          {activeView === 'GROUP_OVERVIEW' && (
            <GroupOverview
              overviewData={overviewMetrics}
              sites={sites}
              batches={batches}
              onSelectSite={handleOpenSiteTwin}
              onSelectDivision={handleDivisionChange}
              onTriggerSimulateDelay={() => setIsDelayModalOpen(true)}
            />
          )}

          {activeView === 'ENTERPRISE_MAP' && (
            <EnterpriseMap
              sites={sites}
              onSelectSite={handleOpenSiteTwin}
            />
          )}

          {activeView === 'ENTERPRISE_RISK' && (
            <EnterpriseRisk
              riskEvents={riskEvents}
              onAssignRiskOwner={handleAssignRiskOwner}
            />
          )}

          {(activeView === 'PHARMA_RESEARCH' || activeView === 'PHARMA_CLINICAL' || activeView === 'PHARMA_REGULATORY') && (
            <PharmaWorkspace
              researchProgrammes={syntheticDb.getResearchProgrammes()}
              clinicalStudies={syntheticDb.getClinicalStudies()}
              regulatorySubmissions={syntheticDb.getRegulatorySubmissions()}
            />
          )}

          {(activeView === 'CROP_PORTFOLIO' || activeView === 'CROP_FIELD_TRIALS' || activeView === 'CROP_DIGITAL_TWIN') && (
            <CropScienceWorkspace
              cropTrials={syntheticDb.getCropTrials()}
            />
          )}

          {(activeView === 'CONSUMER_PORTFOLIO' || activeView === 'CONSUMER_DEMAND') && (
            <ConsumerHealthWorkspace
              products={syntheticDb.getConsumerHealthProducts()}
            />
          )}

          {(activeView === 'MFG_SITES_TWIN' || activeView === 'MFG_PRODUCTION_LINES' || activeView === 'MFG_BATCH_TRACEABILITY') && (
            <ManufacturingDigitalTwin
              sites={sites}
              productionLines={productionLines}
              batches={batches}
              selectedSiteId={selectedSiteId}
              onSelectSite={setSelectedSiteId}
              onTriggerSimulateDelay={() => setIsDelayModalOpen(true)}
            />
          )}

          {(activeView === 'SUPPLY_NETWORK_GRAPH' || activeView === 'SUPPLY_SCENARIOS_LAB') && (
            <SupplyNetworkGraph
              supplyNodes={syntheticDb.getSupplyNodes()}
              supplyRoutes={syntheticDb.getSupplyRoutes()}
              supplyScenarios={syntheticDb.getSupplyScenarios()}
            />
          )}

          {(activeView === 'SCIENCE_KNOWLEDGE_GRAPH' || activeView === 'SCIENCE_AI_REGISTRY') && (
            <ScienceAndAnalyticsWorkspace
              datasets={syntheticDb.getScientificDatasets()}
              aiModels={syntheticDb.getAIModels()}
            />
          )}

          {(activeView === 'CORP_SUSTAINABILITY' || activeView === 'CORP_FINANCE' || activeView === 'CORP_GOVERNANCE') && (
            <CorporateFunctionsWorkspace
              sustainabilityMetrics={syntheticDb.getSustainabilityMetrics()}
              financePlans={syntheticDb.getFinancePlans()}
            />
          )}
        </main>
      </div>

      {/* Drawers & Modals */}
      <AuditLogDrawer
        isOpen={isAuditDrawerOpen}
        onClose={() => setIsAuditDrawerOpen(false)}
        auditEvents={auditEvents}
      />

      <OperationalReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        report={operationalReport}
      />

      <SimulateDelayModal
        isOpen={isDelayModalOpen}
        onClose={() => setIsDelayModalOpen(false)}
        batches={batches}
        onExecuteSimulation={handleExecuteDelaySimulation}
      />
    </div>
  );
}

export default App;
