/**
 * BAYER.OS Domain Types
 * Supermodernist Enterprise Operating System Type Definitions
 */

export type DivisionId = 'PHARMA' | 'CROP_SCIENCE' | 'CONSUMER_HEALTH' | 'GROUP';

export type UserRole = 
  | 'GROUP_EXECUTIVE' 
  | 'DIVISION_DIRECTOR' 
  | 'SITE_MANAGER' 
  | 'RESEARCH_LEAD' 
  | 'MANUFACTURING_MANAGER' 
  | 'QUALITY_MANAGER' 
  | 'REGULATORY_SPECIALIST' 
  | 'SUPPLY_CHAIN_ANALYST' 
  | 'FINANCE_ANALYST' 
  | 'SUSTAINABILITY_ANALYST' 
  | 'SYSTEM_ADMIN' 
  | 'AUDITOR';

export type OperationalRegime = 
  | 'NORMAL' 
  | 'HIGH_DEMAND' 
  | 'MANUFACTURING_DISRUPTION' 
  | 'SUPPLY_SHORTAGE' 
  | 'REGULATORY_DELAY' 
  | 'SEVERE_WEATHER' 
  | 'QUALITY_INVESTIGATION' 
  | 'RESEARCH_ACCELERATION';

export interface Site {
  id: string;
  name: string;
  code: string;
  city: string;
  country: string;
  region: string;
  coordinates: [number, number]; // [lat, lng]
  division: DivisionId;
  type: 'MANUFACTURING' | 'RESEARCH_LAB' | 'DISTRIBUTION_CENTER' | 'AGRONOMIC_STATION' | 'REGIONAL_HQ';
  status: 'OPTIMAL' | 'DEGRADED' | 'DISRUPTED' | 'MAINTENANCE';
  activeLinesCount: number;
  activeBatchesCount: number;
  workforceCount: number;
  energyConsumptionKWh: number;
  waterUsageM3: number;
  carbonEmissionsMT: number;
  capabilities: string[];
  openQualityIncidents: number;
  riskScore: number; // 0 - 100
  lastAuditDate: string;
}

export interface ProductionLine {
  id: string;
  siteId: string;
  name: string;
  lineCode: string;
  category: string;
  status: 'RUNNING' | 'PAUSED' | 'MAINTENANCE' | 'DELAYED_DISRUPTED' | 'CLEANING';
  currentBatchId?: string;
  throughputUnitsPerHour: number;
  efficiencyOEE: number; // e.g. 88.5%
  queueLengthBatches: number;
  plannedDowntimeHours: number;
  activePowerKW: number;
  stages: ProductionStage[];
  assets: Asset[];
}

export interface ProductionStage {
  stageNumber: number;
  name: string; // e.g. "Raw Intake & Dosing", "Reaction / Synthesis", "Sterile Filtration", "Formulation", "Blister Filling", "Quality QA Release", "Packaging"
  status: 'COMPLETED' | 'IN_PROGRESS' | 'PENDING' | 'HOLD' | 'CRITICAL_DELAY';
  durationMinutes: number;
  temperatureCelsius?: number;
  pressureBar?: number;
  phLevel?: number;
}

export interface Asset {
  id: string;
  siteId: string;
  lineId: string;
  name: string;
  assetCode: string;
  manufacturer: string;
  assetType: string; // e.g., Bioreactor, Lyophilizer, High-Speed Encapsulator, HPLC Analyzer
  state: 'OPERATIONAL' | 'WARNING' | 'CRITICAL' | 'STANDBY';
  healthScore: number; // 0 - 100
  vibrationMmS: number;
  operatingTempC: number;
  lastInspectionDate: string;
  nextScheduledMaintenance: string;
  failureRiskProbability: number; // 0 - 1
  openWorkOrdersCount: number;
}

export interface MaterialInput {
  materialId: string;
  code: string;
  name: string;
  supplierName: string;
  supplierId: string;
  lotNumber: string;
  quantityUsedKg: number;
  qualityCertificateVerified: boolean;
  status: 'VERIFIED' | 'PENDING_TEST' | 'HOLD';
  originCountry: string;
}

export interface QualityCheckpoint {
  checkpointId: string;
  name: string;
  stageName: string;
  parameter: string; // e.g., "Assay Purity (>99.2%)", "Endotoxin Level (<0.25 EU/mL)", "Dissolution Rate (>85% at 15min)", "Moisture Content (<1.5%)"
  measuredValue: string;
  specification: string;
  status: 'PASS' | 'FAIL' | 'IN_REVIEW' | 'FLAGGED';
  testedBy: string;
  timestamp: string;
}

export interface Batch {
  id: string;
  batchNumber: string;
  productName: string;
  productId: string;
  division: DivisionId;
  siteId: string;
  siteName: string;
  productionLineId: string;
  status: 'SCHEDULED' | 'PROCESSING' | 'QUALITY_HOLD' | 'DELAYED' | 'RELEASED' | 'QUARANTINED';
  plannedStartDate: string;
  actualStartDate: string;
  estimatedCompletionDate: string;
  quantityUnits: number;
  unitMeasurement: string;
  progressPercent: number;
  materialInputs: MaterialInput[];
  qualityCheckpoints: QualityCheckpoint[];
  deviationsCount: number;
  delayReason?: string;
  disruptionImpactDays?: number;
  affectedDestinationMarkets?: string[];
  traceabilityHash: string;
}

export interface SupplyNode {
  id: string;
  name: string;
  type: 'SUPPLIER' | 'MANUFACTURING_SITE' | 'WAREHOUSE' | 'DISTRIBUTION_HUB' | 'MARKET_NODE';
  location: string;
  lat: number;
  lng: number;
  inventoryLevelPct: number;
  status: 'HEALTHY' | 'WARNING' | 'CRITICAL_SHORTAGE' | 'DISRUPTED';
  leadTimeDays: number;
  singleSourceDependency: boolean;
}

export interface SupplyRoute {
  id: string;
  fromNodeId: string;
  toNodeId: string;
  materialOrProduct: string;
  transportMode: 'AIR_FREIGHT' | 'OCEAN_CONTAINER' | 'COLD_CHAIN_TRUCK' | 'RAIL';
  transitDays: number;
  status: 'ON_SCHEDULE' | 'DELAYED' | 'REROUTED' | 'BLOCKED';
  temperatureRangeMinC: number;
  temperatureRangeMaxC: number;
  currentTempC: number;
}

export interface SupplyScenario {
  id: string;
  scenarioType: 'SUPPLIER_SHUTDOWN' | 'PORT_CLOSURE' | 'COLD_CHAIN_EXCURSION' | 'RAW_MATERIAL_SHORTAGE' | 'DEMAND_SURGE';
  title: string;
  affectedLocation: string;
  estimatedDelayDays: number;
  financialImpactEUR: number;
  mitigationStrategy: string;
  affectedProducts: string[];
  riskSeverity: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
}

export interface PharmaResearchProgramme {
  id: string;
  code: string;
  name: string;
  therapeuticArea: 'CARDIOLOGY' | 'ONCOLOGY' | 'OPHTHALMOLOGY' | 'WOMENS_HEALTH' | 'HEMATOLOGY' | 'RADIOLOGY' | 'CELL_GENE_THERAPY';
  hypothesis: string;
  objective: string;
  phase: 'DISCOVERY' | 'PRECLINICAL' | 'PHASE_I' | 'PHASE_II' | 'PHASE_III' | 'SUBMISSION' | 'APPROVED';
  leadInvestigator: string;
  researchSite: string;
  targetMilestoneDate: string;
  probabilityOfSuccessPct: number; // e.g. 64%
  budgetAllocationEUR: number;
  riskClassification: 'LOW' | 'MEDIUM' | 'HIGH';
  dataQualityStatus: 'VERIFIED_AUDITED' | 'REQUIRES_VALIDATION' | 'EXPERIMENTAL';
}

export interface ClinicalStudy {
  id: string;
  protocolNumber: string;
  title: string;
  indication: string;
  phase: 'PHASE_I' | 'PHASE_II' | 'PHASE_III' | 'POST_MARKET';
  geographicRegions: string[];
  activeStudySitesCount: number;
  recruitmentTarget: number;
  recruitmentCurrent: number;
  protocolVersion: string;
  dataQualityScore: number; // 0-100
  operationalRisk: 'STABLE' | 'BEHIND_SCHEDULE' | 'REGULATORY_QUERY';
}

export interface RegulatorySubmission {
  id: string;
  submissionCode: string;
  productName: string;
  authority: 'EMA' | 'FDA' | 'PMDA' | 'NMPA' | 'BFARM';
  countryRegion: string;
  submissionType: 'NDA' | 'MAA' | 'VARIATION' | 'SUPPLEMENT' | 'RENEWAL';
  targetDate: string;
  approvalStatus: 'PREPARATION' | 'UNDER_REVIEW' | 'INFORMATION_REQUEST' | 'APPROVED' | 'REJECTED';
  dossierCompletenessPct: number;
  auditTrailReference: string;
}

export interface CropTrial {
  id: string;
  trialCode: string;
  locationName: string;
  country: string;
  cropType: 'CORN_MAIZE' | 'SOYBEAN' | 'WHEAT' | 'COTTON' | 'CANOLA' | 'VEGETABLES';
  varietyOrTrait: string;
  soilType: string;
  plantingDate: string;
  harvestDate: string;
  yieldBuPerAcreActual: number;
  yieldBuPerAcreBenchmark: number;
  pestPressureIndex: 'LOW' | 'MODERATE' | 'HIGH' | 'SEVERE';
  soilMoisturePct: number;
  weatherConditionSummary: string;
  dataProvenance: string;
}

export interface ConsumerHealthProduct {
  id: string;
  sku: string;
  brandName: string;
  category: 'ANALGESICS' | 'DERMATOLOGY' | 'DIGESTIVE_HEALTH' | 'NUTRITIONALS' | 'ALLERGY';
  primaryActiveIngredient: string;
  marketAvailabilityCountries: number;
  manufacturingSite: string;
  monthlyDemandUnits: number;
  inventoryCoverageDays: number;
  packagingVariants: string[];
  qualityHoldStatus: 'CLEAR' | 'UNDER_INVESTIGATION' | 'RESTRICTED';
  lifecycleStage: 'GROWTH' | 'MATURE' | 'REFORMULATION' | 'PHASE_OUT';
}

export interface QualityEvent {
  id: string;
  eventNumber: string;
  title: string;
  severity: 'MINOR' | 'MAJOR' | 'CRITICAL';
  originSite: string;
  division: DivisionId;
  relatedBatchId?: string;
  relatedProductId?: string;
  assignedOwner: string;
  creationDate: string;
  dueDate: string;
  status: 'OPENED' | 'TRIAGE' | 'INVESTIGATION' | 'ACTION_PLAN' | 'REVIEW' | 'CLOSED';
  rootCauseAnalysis: string;
  correctiveActions: string[];
  auditHistory: string[];
}

export interface RiskEvent {
  id: string;
  riskCode: string;
  title: string;
  category: 'SUPPLY_DISRUPTION' | 'QUALITY_DEVIATION' | 'REGULATORY_DELAY' | 'EHS_SAFETY' | 'CYBERSECURITY' | 'GEOPOLITICAL';
  probability: 'LOW' | 'MEDIUM' | 'HIGH';
  impact: 'MINOR' | 'MODERATE' | 'SEVERE' | 'CATASTROPHIC';
  exposureEUR: number;
  assignedOwner: string;
  status: 'ACTIVE_MONITORING' | 'MITIGATION_IN_PROGRESS' | 'RESOLVED';
  mitigationPlan: string;
  createdTimestamp: string;
  associatedBatchOrSite?: string;
}

export interface ScientificDataset {
  id: string;
  datasetCode: string;
  title: string;
  domain: 'GENOMICS' | 'HIGH_THROUGHPUT_SCREENING' | 'PROTEIN_CRYSTALLOGRAPHY' | 'AGRONOMIC_FIELD_GENOMICS' | 'CLINICAL_BIOMARKERS';
  recordsCount: number;
  dataQualityFlags: string[];
  lastUpdated: string;
  leadScientist: string;
  provenanceSource: string;
  linkedEntities: string[];
}

export interface AIModelRecord {
  id: string;
  modelCode: string;
  name: string;
  domain: 'PREDICTIVE_MAINTENANCE' | 'DEMAND_FORECASTING' | 'CROP_YIELD_OPTIMIZATION' | 'SUPPLY_DISRUPTION_RISK' | 'QUALITY_EVENT_TRIAGE';
  modelVersion: string;
  accuracyMetric: string; // e.g. "94.2% ROC-AUC"
  driftIndicator: 'HEALTHY' | 'STABLE' | 'DRIFT_DETECTED';
  deploymentStatus: 'PRODUCTION' | 'STAGING' | 'RE_TRAINING';
  modelOwner: string;
  explainabilitySummary: string;
  syntheticDataLabel: string;
}

export interface SustainabilityMetric {
  siteId: string;
  siteName: string;
  division: DivisionId;
  energyTotalKWh: number;
  renewableEnergySharePct: number;
  waterConsumptionM3: number;
  wasteRecycledPct: number;
  carbonScope1And2MT: number;
  carbonScope3MT: number;
  targetCompliance: 'ON_TRACK' | 'AT_RISK' | 'NEEDS_ACTION';
}

export interface FinancialPlan {
  division: DivisionId;
  divisionName: string;
  budgetEUR: number;
  actualSpentEUR: number;
  forecastEUR: number;
  variancePercent: number;
  researchExpenditureEUR: number;
  capexPipelineEUR: number;
  mfgCostPerUnitEUR: number;
}

export interface AuditEvent {
  id: string;
  timestamp: string;
  action: string;
  actor: string;
  role: UserRole;
  entityType: string;
  entityId: string;
  details: string;
  previousState?: string;
  newState?: string;
  traceabilityHash: string;
}

export interface OperationalReport {
  generatedAt: string;
  reportTitle: string;
  regime: OperationalRegime;
  summary: {
    totalOperatingSites: number;
    activeManufacturingFacilities: number;
    activeBatchesCount: number;
    batchesOnQualityHold: number;
    disruptedBatchesCount: number;
    openCriticalRisks: number;
    overallOEEPercent: number;
    supplyChainResilienceScore: number;
  };
  keyEvents: string[];
  activeDisruptions: {
    siteName: string;
    lineName: string;
    batchNumber: string;
    delayDays: number;
    reason: string;
    assignedOwner: string;
  }[];
  auditTrailHash: string;
}
