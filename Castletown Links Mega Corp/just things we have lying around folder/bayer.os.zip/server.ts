import express, { Request, Response } from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { syntheticDb } from './src/data/syntheticDatabase.js';

const PORT = 3000;

function formatApiResponse(data: any, extraMeta: Record<string, any> = {}) {
  return {
    meta: {
      timestamp: new Date().toISOString(),
      sourceClassification: 'SYNTHETIC_DEMONSTRATION_DATA',
      syntheticDataFlag: true,
      schemaVersion: 'v1.0',
      disclaimer: 'BAYER.OS IS A CONCEPTUAL DEMONSTRATION PLATFORM. ALL DATA IS FICTIONAL AND SYNTHETIC.',
      ...extraMeta,
    },
    data,
  };
}

async function startServer() {
  const app = express();
  app.use(express.json());

  // --- API ROUTES FIRST ---

  // Health & Governance
  app.get('/api/v1/health', (req: Request, res: Response) => {
    res.json(formatApiResponse({
      status: 'HEALTHY',
      version: 'BAYER.OS v2.4.0-Enterprise',
      database: 'SYNTHETIC_IN_MEMORY_DETERMINISTIC_ENGINE',
      uptimeSeconds: process.uptime(),
      regime: syntheticDb.getRegime(),
      activeRole: syntheticDb.getActiveRole(),
    }));
  });

  // Global Group Overview
  app.get('/api/v1/group/overview', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getGroupOverviewMetrics()));
  });

  // Divisions & Organisations
  app.get('/api/v1/organisations', (req: Request, res: Response) => {
    res.json(formatApiResponse({
      groupName: 'BAYER Group (Conceptual Enterprise)',
      divisions: [
        { id: 'PHARMA', name: 'Pharmaceuticals Division', hq: 'Berlin / Wuppertal', focus: 'Cardiology, Oncology, Ophthalmology, Cell & Gene Therapy' },
        { id: 'CROP_SCIENCE', name: 'Crop Science Division', hq: 'Monheim am Rhein / St. Louis', focus: 'Seeds, Traits, Biologicals, Crop Protection, Digital Agriculture' },
        { id: 'CONSUMER_HEALTH', name: 'Consumer Health Division', hq: 'Basel / Pittsburgh', focus: 'Dermatology, Analgesics, Allergy, Digestive Health, Nutritionals' },
      ],
      sitesCount: syntheticDb.getSites().length,
    }));
  });

  app.get('/api/v1/divisions', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getFinancePlans()));
  });

  // Sites
  app.get('/api/v1/sites', (req: Request, res: Response) => {
    const { division } = req.query;
    let sites = syntheticDb.getSites();
    if (division && typeof division === 'string') {
      sites = sites.filter((s) => s.division === division.toUpperCase());
    }
    res.json(formatApiResponse(sites));
  });

  app.get('/api/v1/sites/:id', (req: Request, res: Response) => {
    const site = syntheticDb.getSites().find((s) => s.id === req.params.id);
    if (!site) {
      res.status(404).json(formatApiResponse({ error: 'Site not found' }));
      return;
    }
    const lines = syntheticDb.getProductionLines().filter((l) => l.siteId === site.id);
    const batches = syntheticDb.getBatches().filter((b) => b.siteId === site.id);
    const qualityEvents = syntheticDb.getQualityEvents().filter((q) => q.originSite === site.name);

    res.json(formatApiResponse({
      site,
      productionLines: lines,
      activeBatches: batches,
      qualityEvents,
    }));
  });

  // Manufacturing Lines & Batches
  app.get('/api/v1/manufacturing/lines', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getProductionLines()));
  });

  app.get('/api/v1/manufacturing/batches', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getBatches()));
  });

  app.get('/api/v1/manufacturing/batches/:id', (req: Request, res: Response) => {
    const batch = syntheticDb.getBatches().find((b) => b.id === req.params.id);
    if (!batch) {
      res.status(404).json(formatApiResponse({ error: 'Batch not found' }));
      return;
    }
    res.json(formatApiResponse(batch));
  });

  // Simulate Production Delay (Vertical Slice Core Action)
  app.post('/api/v1/manufacturing/simulate-delay', (req: Request, res: Response) => {
    const { batchId, delayDays, reason, actor } = req.body;
    if (!batchId || !delayDays || !reason) {
      res.status(400).json(formatApiResponse({ error: 'Missing batchId, delayDays, or reason' }));
      return;
    }

    try {
      const result = syntheticDb.simulateProductionDelay(
        batchId,
        Number(delayDays),
        String(reason),
        actor ? String(actor) : 'SITE_MANAGER_LEV'
      );
      res.json(formatApiResponse(result));
    } catch (err: any) {
      res.status(500).json(formatApiResponse({ error: err.message }));
    }
  });

  // Pharmaceuticals
  app.get('/api/v1/research/programmes', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getResearchProgrammes()));
  });

  app.get('/api/v1/clinical/programmes', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getClinicalStudies()));
  });

  app.get('/api/v1/regulatory/submissions', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getRegulatorySubmissions()));
  });

  // Crop Science
  app.get('/api/v1/crop-science/trials', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getCropTrials()));
  });

  // Consumer Health
  app.get('/api/v1/consumer-health/products', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getConsumerHealthProducts()));
  });

  // Supply Chain Network & Scenarios
  app.get('/api/v1/supply-chain/network', (req: Request, res: Response) => {
    res.json(formatApiResponse({
      nodes: syntheticDb.getSupplyNodes(),
      routes: syntheticDb.getSupplyRoutes(),
    }));
  });

  app.get('/api/v1/supply-chain/scenarios', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getSupplyScenarios()));
  });

  // Quality Events & Triage
  app.get('/api/v1/quality/events', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getQualityEvents()));
  });

  app.post('/api/v1/quality/events/:id/triage', (req: Request, res: Response) => {
    const { id } = req.params;
    const { status, rootCause, owner, actor } = req.body;
    try {
      const updated = syntheticDb.triageQualityEvent(id, status, rootCause, owner, actor);
      res.json(formatApiResponse(updated));
    } catch (err: any) {
      res.status(400).json(formatApiResponse({ error: err.message }));
    }
  });

  // Science & Data
  app.get('/api/v1/scientific/datasets', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getScientificDatasets()));
  });

  // AI & Analytics
  app.get('/api/v1/analytics/models', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getAIModels()));
  });

  // Sustainability & Resource Mgmt
  app.get('/api/v1/sustainability/observations', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getSustainabilityMetrics()));
  });

  // Finance & Planning
  app.get('/api/v1/finance/plans', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getFinancePlans()));
  });

  // Risk Management
  app.get('/api/v1/risk/events', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getRiskEvents()));
  });

  app.post('/api/v1/risk/events/:id/assign', (req: Request, res: Response) => {
    const { id } = req.params;
    const { owner, mitigationPlan, actor } = req.body;
    try {
      const updated = syntheticDb.assignRiskOwner(id, owner, mitigationPlan, actor);
      res.json(formatApiResponse(updated));
    } catch (err: any) {
      res.status(400).json(formatApiResponse({ error: err.message }));
    }
  });

  // Audit Events
  app.get('/api/v1/audit/events', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.getAuditLog()));
  });

  // Reports
  app.get('/api/v1/reports/operational-summary', (req: Request, res: Response) => {
    res.json(formatApiResponse(syntheticDb.generateOperationalReport()));
  });

  app.post('/api/v1/governance/regime', (req: Request, res: Response) => {
    const { regime, actor } = req.body;
    if (!regime) {
      res.status(400).json(formatApiResponse({ error: 'Regime is required' }));
      return;
    }
    syntheticDb.setOperationalRegime(regime, actor);
    res.json(formatApiResponse({ regime: syntheticDb.getRegime(), overview: syntheticDb.getGroupOverviewMetrics() }));
  });

  // --- VITE MIDDLEWARE FOR FRONTEND SERVING ---
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BAYER.OS Enterprise Kernel server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
