'use client';

import React, { useState } from 'react';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { MessageSquare, CheckCircle2, Upload, FileText, Send, ShieldCheck, Phone, Mail, Building } from 'lucide-react';

interface ContactWorkflowProps {
  initialSubject?: string;
}

export const ContactWorkflow: React.FC<ContactWorkflowProps> = ({ initialSubject }) => {
  const { lang, t } = useTranslation();
  const [step, setStep] = useState<number>(1);

  // Form State
  const [inquiryType, setInquiryType] = useState<string>('Engineering & FEED');
  const [sector, setSector] = useState<string>('Chemicals & Petrochemicals');
  const [fullName, setFullName] = useState<string>('');
  const [company, setCompany] = useState<string>('');
  const [email, setEmail] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [message, setMessage] = useState<string>(initialSubject ? `Regarding: ${initialSubject}` : '');
  const [consentDataPrivacy, setConsentDataPrivacy] = useState<boolean>(false);
  const [ticketId, setTicketId] = useState<string>('');
  const [errorMessage, setErrorMessage] = useState<string>('');

  const inquiryTypes = [
    'Engineering & FEED',
    'Plant Construction & Skids',
    'Turnaround & Stillstand',
    'Maintenance & BMC',
    'Digital OT/IT & Cybersecurity',
    'Decarbonization & Hydrogen',
  ];

  const sectors = [
    'Chemicals & Petrochemicals',
    'Pharma & Biopharma',
    'Energy & Utilities',
    'Industrial Manufacturing',
    'Oil & Gas',
  ];

  const handleNextStep1 = (e: React.FormEvent) => {
    e.preventDefault();
    setStep(2);
  };

  const handleNextStep2 = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName || !email || !message) {
      setErrorMessage('Please fill in all required fields.');
      return;
    }
    setErrorMessage('');
    setStep(3);
  };

  const handleSubmitFinal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!consentDataPrivacy) {
      setErrorMessage('Please accept the data privacy terms.');
      return;
    }
    setErrorMessage('');

    // Generate synthetic ticket ID
    const generated = `BILF-INQ-${Math.floor(100000 + Math.random() * 900000)}`;
    setTicketId(generated);
    setStep(4);
  };

  return (
    <section id="contact" className="py-20 bg-[#121518] text-white border-b border-[#2A3038] font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3">
          <span className="text-xs font-mono text-[#F97316] uppercase tracking-widest font-semibold block">
            {"// DISCUSS YOUR INDUSTRIAL CHALLENGE"}
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase tracking-tight font-sans">
            {t.contact.title}
          </h2>
          <p className="text-neutral-300 text-base font-sans">
            {t.contact.subtitle}
          </p>
        </div>

        {/* Multi-Step Form Container */}
        <div className="bg-[#1A1E23] border border-[#2A3038] p-6 sm:p-10 shadow-2xl space-y-8">
          {/* Stepper Progress Bar */}
          <div className="grid grid-cols-4 gap-2 text-xs font-mono border-b border-white/10 pb-4">
            <div className={`p-2 border-b-2 text-center ${step >= 1 ? 'border-[#F97316] text-[#F97316] font-bold' : 'border-white/10 text-neutral-500'}`}>
              01. CATEGORY
            </div>
            <div className={`p-2 border-b-2 text-center ${step >= 2 ? 'border-[#F97316] text-[#F97316] font-bold' : 'border-white/10 text-neutral-500'}`}>
              02. DETAILS
            </div>
            <div className={`p-2 border-b-2 text-center ${step >= 3 ? 'border-[#F97316] text-[#F97316] font-bold' : 'border-white/10 text-neutral-500'}`}>
              03. CONSENT
            </div>
            <div className={`p-2 border-b-2 text-center ${step >= 4 ? 'border-[#F97316] text-[#F97316] font-bold' : 'border-white/10 text-neutral-500'}`}>
              04. CONFIRMATION
            </div>
          </div>

          {errorMessage && (
            <div className="p-3 bg-red-950/80 border border-red-500 text-red-200 text-xs font-mono">
              ⚠️ {errorMessage}
            </div>
          )}

          {/* STEP 1: Inquiry Type & Sector Selection */}
          {step === 1 && (
            <form onSubmit={handleNextStep1} className="space-y-6">
              <div className="space-y-3">
                <label className="text-xs font-mono text-neutral-300 uppercase block">1. Select Service Category *</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {inquiryTypes.map((type) => (
                    <button
                      type="button"
                      key={type}
                      onClick={() => setInquiryType(type)}
                      className={`p-3 text-left font-mono text-xs border transition-colors ${
                        inquiryType === type
                          ? 'bg-[#F97316] text-white border-[#F97316] font-bold'
                          : 'bg-[#121518] text-neutral-300 border-white/10 hover:border-white/30'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <label className="text-xs font-mono text-neutral-300 uppercase block">2. Select Industry Sector *</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                  {sectors.map((sec) => (
                    <button
                      type="button"
                      key={sec}
                      onClick={() => setSector(sec)}
                      className={`p-3 text-left font-mono text-xs border transition-colors ${
                        sector === sec
                          ? 'bg-[#F97316] text-white border-[#F97316] font-bold'
                          : 'bg-[#121518] text-neutral-300 border-white/10 hover:border-white/30'
                      }`}
                    >
                      {sec}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex justify-end pt-4">
                <button
                  type="submit"
                  className="px-8 py-3 bg-[#F97316] hover:bg-[#EA580C] text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  Proceed to Contact Details →
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: Contact Details & Message */}
          {step === 2 && (
            <form onSubmit={handleNextStep2} className="space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                <div>
                  <label className="text-neutral-300 block mb-1">Full Name *</label>
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Dr. Hans Weber"
                    className="w-full bg-[#121518] text-white p-3 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
                  />
                </div>

                <div>
                  <label className="text-neutral-300 block mb-1">Company / Organization *</label>
                  <input
                    type="text"
                    required
                    value={company}
                    onChange={(e) => setCompany(e.target.value)}
                    placeholder="BASF SE / EVONIK / BAYER"
                    className="w-full bg-[#121518] text-white p-3 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
                  />
                </div>

                <div>
                  <label className="text-neutral-300 block mb-1">Business Email *</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="h.weber@company.de"
                    className="w-full bg-[#121518] text-white p-3 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
                  />
                </div>

                <div>
                  <label className="text-neutral-300 block mb-1">Phone Number</label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+49 69 1234567"
                    className="w-full bg-[#121518] text-white p-3 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
                  />
                </div>
              </div>

              <div className="space-y-1 text-xs font-mono">
                <label className="text-neutral-300 block mb-1">Project Scope & Challenge Description *</label>
                <textarea
                  required
                  rows={4}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Outline facility capacity, timeframe, regulatory constraints, or desired engineering outcomes..."
                  className="w-full bg-[#121518] text-white p-3 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316] font-sans text-sm"
                />
              </div>

              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="px-6 py-3 bg-white/5 hover:bg-white/10 text-neutral-300 font-mono text-xs uppercase"
                >
                  ← Back
                </button>
                <button
                  type="submit"
                  className="px-8 py-3 bg-[#F97316] hover:bg-[#EA580C] text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors"
                >
                  Review & Attachments →
                </button>
              </div>
            </form>
          )}

          {/* STEP 3: File Upload & Legal Consent */}
          {step === 3 && (
            <form onSubmit={handleSubmitFinal} className="space-y-6">
              <div className="bg-[#121518] p-6 border border-white/10 space-y-4">
                <h4 className="text-xs font-mono text-[#F97316] uppercase font-bold">{"// INQUIRY SUMMARY REVIEW"}</h4>
                <div className="grid grid-cols-2 gap-2 text-xs font-mono text-neutral-300">
                  <div><span className="text-neutral-500">CATEGORY:</span> {inquiryType}</div>
                  <div><span className="text-neutral-500">SECTOR:</span> {sector}</div>
                  <div><span className="text-neutral-500">NAME:</span> {fullName}</div>
                  <div><span className="text-neutral-500">COMPANY:</span> {company}</div>
                  <div><span className="text-neutral-500">EMAIL:</span> {email}</div>
                  <div><span className="text-neutral-500">PHONE:</span> {phone || 'N/A'}</div>
                </div>
              </div>

              {/* Synthetic File Attachment */}
              <div className="space-y-2 text-xs font-mono">
                <label className="text-neutral-300 block">Attach Technical Specs / Tender Specs (Optional)</label>
                <div className="flex items-center space-x-3 bg-[#121518] p-4 border border-white/10 text-neutral-400">
                  <Upload className="w-5 h-5 text-[#F97316]" />
                  <input type="file" className="text-xs text-neutral-400" />
                </div>
              </div>

              {/* Data Privacy Checkbox */}
              <div className="p-4 bg-[#121518] border border-white/10 space-y-3">
                <label className="flex items-start space-x-3 cursor-pointer text-xs font-sans text-neutral-300">
                  <input
                    type="checkbox"
                    checked={consentDataPrivacy}
                    onChange={(e) => setConsentDataPrivacy(e.target.checked)}
                    className="mt-1 accent-[#F97316]"
                  />
                  <span>
                    I agree to the processing of my contact information by Bilfinger Industrial in accordance with European GDPR compliance guidelines for the sole purpose of responding to this engineering inquiry.
                  </span>
                </label>
              </div>

              <div className="flex justify-between pt-4">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="px-6 py-3 bg-white/5 hover:bg-white/10 text-neutral-300 font-mono text-xs uppercase"
                >
                  ← Edit Details
                </button>
                <button
                  type="submit"
                  className="px-8 py-3 bg-[#F97316] hover:bg-[#EA580C] text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors flex items-center space-x-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Transmit Inquiry Package</span>
                </button>
              </div>
            </form>
          )}

          {/* STEP 4: Confirmation Card */}
          {step === 4 && (
            <div className="p-8 bg-[#121518] border border-[#F97316] text-center space-y-6">
              <div className="w-16 h-16 bg-[#F97316]/10 border border-[#F97316] text-[#F97316] rounded-full flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-8 h-8" />
              </div>

              <div className="space-y-2">
                <span className="text-xs font-mono text-[#F97316] uppercase font-bold">{"// INQUIRY REGISTERED"}</span>
                <h3 className="text-2xl font-extrabold uppercase text-white font-sans">
                  TRANSMISSION SUCCESSFUL
                </h3>
                <div className="text-sm font-mono text-neutral-300 pt-1">
                  SYNTHETIC TICKET REFERENCE: <span className="text-[#F97316] font-bold">{ticketId}</span>
                </div>
              </div>

              <p className="text-xs text-neutral-300 leading-relaxed font-sans max-w-xl mx-auto">
                Thank you, <span className="text-white font-bold">{fullName}</span> ({company}). Your inquiry regarding <span className="text-[#F97316] font-bold">{inquiryType}</span> has been logged. In a production deployment, our Mannheim engineering hub would dispatch a technical specialist within 24 business hours.
              </p>

              <button
                onClick={() => setStep(1)}
                className="px-6 py-3 bg-[#F97316] text-white font-mono text-xs font-bold uppercase tracking-wider"
              >
                Submit Additional Inquiry
              </button>
            </div>
          )}
        </div>
      </div>
    </section>
  );
};
