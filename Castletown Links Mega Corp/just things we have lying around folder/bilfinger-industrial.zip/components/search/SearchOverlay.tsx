'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { getFullSearchIndex, SearchResultItem } from '@/lib/data/searchIndex';
import { Search, X, ArrowRight, History, FileText, Factory, Briefcase, MapPin, Compass, Layers } from 'lucide-react';

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectResult: (url: string) => void;
}

export const SearchOverlay: React.FC<SearchOverlayProps> = ({ isOpen, onClose, onSelectResult }) => {
  const { lang, t } = useTranslation();
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('bilfinger_recent_searches');
      if (saved) {
        try {
          return JSON.parse(saved);
        } catch (e) {
          // ignore
        }
      }
    }
    return [];
  });
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => inputRef.current?.focus(), 100);
      return () => clearTimeout(timer);
    }
  }, [isOpen]);

  // Keyboard escape listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
        else {
          // Open search triggered
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const allItems = getFullSearchIndex();

  const filteredItems = allItems.filter((item) => {
    const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
    if (!matchesCategory) return false;

    if (!query.trim()) return true;

    const q = query.toLowerCase();
    const titleMatch = item.title[lang].toLowerCase().includes(q);
    const snippetMatch = item.snippet[lang].toLowerCase().includes(q);
    const keywordMatch = item.keywords.some((kw) => kw.includes(q));

    return titleMatch || snippetMatch || keywordMatch;
  });

  const handleResultClick = (url: string, titleText: string) => {
    // Save to recent searches
    const updated = [titleText, ...recentSearches.filter((s) => s !== titleText)].slice(0, 5);
    setRecentSearches(updated);
    localStorage.setItem('bilfinger_recent_searches', JSON.stringify(updated));

    onSelectResult(url);
    onClose();
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Service':
        return Compass;
      case 'Industry':
        return Factory;
      case 'Project':
        return Layers;
      case 'Career':
        return Briefcase;
      case 'Location':
        return MapPin;
      default:
        return FileText;
    }
  };

  const categories = ['All', 'Service', 'Industry', 'Project', 'Career', 'Location', 'Glossary'];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-start justify-center pt-16 px-4 sm:px-6"
      role="dialog"
      aria-modal="true"
      aria-label="Search Bilfinger Industrial"
    >
      <div className="bg-[#1A1E23] border border-[#2A3038] w-full max-w-3xl rounded-none shadow-2xl overflow-hidden font-sans relative flex flex-col max-h-[82vh]">
        {/* Header Search Input */}
        <div className="p-4 border-b border-white/10 flex items-center space-x-3 bg-[#121518]">
          <Search className="w-5 h-5 text-[#F97316] shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={t.search.placeholder}
            className="w-full bg-transparent text-white text-base font-sans placeholder-neutral-500 focus:outline-none"
          />
          {query && (
            <button onClick={() => setQuery('')} className="p-1 text-neutral-400 hover:text-white">
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={onClose}
            className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white text-xs font-mono rounded border border-white/10"
          >
            ESC
          </button>
        </div>

        {/* Category Chips */}
        <div className="p-3 bg-[#121518]/60 border-b border-white/5 flex items-center space-x-2 overflow-x-auto text-xs font-mono">
          <span className="text-neutral-500 uppercase mr-1">{t.search.categories}:</span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded transition-colors whitespace-nowrap ${
                selectedCategory === cat ? 'bg-[#F97316] text-white font-bold' : 'bg-white/5 text-neutral-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Results Area */}
        <div className="overflow-y-auto p-4 space-y-3 flex-1">
          {recentSearches.length > 0 && !query && (
            <div className="mb-4 pb-3 border-b border-white/5">
              <div className="text-xs font-mono text-neutral-500 uppercase tracking-wider mb-2 flex items-center">
                <History className="w-3.5 h-3.5 mr-1 text-[#F97316]" /> {t.search.recentSearches}
              </div>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((term, i) => (
                  <button
                    key={i}
                    onClick={() => setQuery(term)}
                    className="px-2.5 py-1 bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-mono rounded border border-white/10"
                  >
                    {term}
                  </button>
                ))}
              </div>
            </div>
          )}

          {filteredItems.length === 0 ? (
            <div className="py-12 text-center text-neutral-400 font-mono text-sm">
              <Search className="w-8 h-8 mx-auto text-neutral-600 mb-2 stroke-[1.5]" />
              <p>{t.search.noResults}</p>
              <p className="text-xs text-neutral-500 mt-1">Try searching for &quot;Instandhaltung&quot;, &quot;Hydrogen&quot;, or &quot;Pharma&quot;</p>
            </div>
          ) : (
            filteredItems.map((item) => {
              const IconComp = getCategoryIcon(item.category);
              return (
                <div
                  key={item.id}
                  onClick={() => handleResultClick(item.url, item.title[lang])}
                  className="p-3.5 bg-[#121518] hover:bg-[#22272E] border border-white/5 hover:border-[#F97316]/50 cursor-pointer transition-all group rounded-none flex items-start justify-between"
                >
                  <div className="space-y-1">
                    <div className="flex items-center space-x-2">
                      <span className="px-1.5 py-0.5 bg-[#F97316]/10 text-[#F97316] font-mono text-[10px] uppercase font-bold tracking-wider rounded border border-[#F97316]/20 flex items-center">
                        <IconComp className="w-3 h-3 mr-1" />
                        {item.category}
                      </span>
                      <h4 className="text-sm font-semibold text-white group-hover:text-[#F97316] transition-colors font-sans">
                        {item.title[lang]}
                      </h4>
                    </div>
                    <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed pl-1">
                      {item.snippet[lang]}
                    </p>
                  </div>
                  <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-[#F97316] transition-colors mt-1 shrink-0 ml-3" />
                </div>
              );
            })
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-[#121518] border-t border-white/10 text-[11px] font-mono text-neutral-500 flex justify-between items-center">
          <span>BILFINGER INDUSTRIAL LOCAL SEARCH INDEX</span>
          <span>PRESS ESC TO CLOSE</span>
        </div>
      </div>
    </div>
  );
};
