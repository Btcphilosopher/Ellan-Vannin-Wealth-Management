'use client';

import React, { useState } from 'react';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { servicesData, ServiceItem } from '@/lib/data/servicesData';
import { ChevronDown, ChevronUp, ArrowUpRight, Search, CheckCircle, Compass, Layers, Factory, Wrench, Settings, Cpu, Grid, Shield, Activity, TrendingUp, Clock, Server, Zap, Sliders } from 'lucide-react';

interface ServiceExplorerProps {
  onSelectService?: (serviceId: string) => void;
  onOpenProject?: (projectTitle: string) => void;
}

export const ServiceExplorer: React.FC<ServiceExplorerProps> = ({ onSelectService, onOpenProject }) => {
  const { lang, t } = useTranslation();
  const [expandedId, setExpandedId] = useState<string | null>('consulting-engineering');
  const [filterQuery, setFilterQuery] = useState('');

  const toggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? null : id);
  };

  const filteredServices = servicesData.filter((service) => {
    if (!filterQuery.trim()) return true;
    const q = filterQuery.toLowerCase();
    return (
      service.name[lang].toLowerCase().includes(q) ||
      service.shortDesc[lang].toLowerCase().includes(q) ||
      service.number.includes(q) ||
      service.relatedIndustries.some((ind) => ind.toLowerCase().includes(q))
    );
  });

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Compass':
        return Compass;
      case 'Layers':
        return Layers;
      case 'Factory':
        return Factory;
      case 'Wrench':
        return Wrench;
      case 'Settings':
        return Settings;
      case 'Cpu':
        return Cpu;
      case 'Grid':
        return Grid;
      case 'Shield':
        return Shield;
      case 'Activity':
        return Activity;
      case 'TrendingUp':
        return TrendingUp;
      case 'Clock':
        return Clock;
      case 'Server':
        return Server;
      case 'Zap':
        return Zap;
      default:
        return Sliders;
    }
  };

  return (
    <section id="services" className="py-20 bg-[#121518] text-white border-b border-[#2A3038] font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12 pb-6 border-b border-white/10 gap-6">
          <div className="space-y-3 max-w-2xl">
            <span className="text-xs font-mono text-[#F97316] uppercase tracking-widest font-semibold block">
              {"// COMPLETE SERVICE PORTFOLIO [14 DOMAINS]"}
            </span>
            <h2 className="text-3xl sm:text-5xl font-extrabold uppercase tracking-tight font-sans">
              {t.services.title}
            </h2>
            <p className="text-neutral-400 text-base font-sans">
              {t.services.subtitle}
            </p>
          </div>

          {/* Search/Filter Bar */}
          <div className="w-full md:w-80">
            <div className="relative">
              <Search className="w-4 h-4 text-[#F97316] absolute left-3 top-3" />
              <input
                type="text"
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder={t.services.searchPlaceholder}
                className="w-full bg-[#1A1E23] text-white text-xs font-mono pl-9 pr-4 py-2.5 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316] placeholder-neutral-500"
              />
            </div>
          </div>
        </div>

        {/* 14 Services Rows */}
        <div className="space-y-2">
          {filteredServices.map((service) => {
            const isExpanded = expandedId === service.id;
            const IconComponent = getIcon(service.iconName);

            return (
              <div
                key={service.id}
                className={`border transition-all ${
                  isExpanded
                    ? 'bg-[#1A1E23] border-[#F97316]'
                    : 'bg-[#121518] border-white/10 hover:border-white/30 hover:bg-[#1A1E23]/50'
                }`}
              >
                {/* Main Typographic Row */}
                <button
                  onClick={() => toggleExpand(service.id)}
                  className="w-full px-6 py-5 flex items-center justify-between text-left focus:outline-none group"
                >
                  <div className="flex items-center space-x-6 sm:space-x-8">
                    <span className="font-mono text-lg sm:text-xl font-bold text-[#F97316] w-8">
                      {service.number}
                    </span>
                    <div className="flex items-center space-x-4">
                      <div className="p-2 bg-white/5 border border-white/10 text-neutral-300 group-hover:text-white hidden sm:block">
                        <IconComponent className="w-5 h-5 text-[#F97316]" />
                      </div>
                      <h3 className="text-lg sm:text-2xl font-bold uppercase tracking-wider text-white font-sans group-hover:text-[#F97316] transition-colors">
                        {service.name[lang]}
                      </h3>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4">
                    <span className="hidden lg:inline-block text-xs text-neutral-400 font-sans max-w-xs truncate">
                      {service.shortDesc[lang]}
                    </span>
                    <div className="p-1.5 bg-white/5 rounded border border-white/10 text-neutral-400 group-hover:text-white">
                      {isExpanded ? <ChevronUp className="w-5 h-5 text-[#F97316]" /> : <ChevronDown className="w-5 h-5" />}
                    </div>
                  </div>
                </button>

                {/* Expanded Details Card */}
                {isExpanded && (
                  <div className="px-6 pb-8 pt-2 border-t border-white/10 space-y-6 bg-[#121518]/90">
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                      {/* Left 2 Cols: Scope & Key Deliverables */}
                      <div className="lg:col-span-2 space-y-6">
                        <p className="text-neutral-200 text-sm sm:text-base leading-relaxed font-sans">
                          {service.fullScope[lang]}
                        </p>

                        <div className="space-y-3">
                          <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
                            {"// CORE DELIVERABLES & SCOPE OF WORK"}
                          </h4>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-neutral-300 font-sans">
                            {service.keyDeliverables[lang].map((item, idx) => (
                              <div key={idx} className="flex items-start space-x-2 bg-white/5 p-2.5 border border-white/5">
                                <CheckCircle className="w-4 h-4 text-[#F97316] shrink-0 mt-0.5" />
                                <span>{item}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        {/* Technical Spec note */}
                        <div className="bg-[#1A1E23] p-3 border-l-2 border-[#F97316] text-xs font-mono text-neutral-400">
                          <span className="text-white font-bold block mb-1">TECHNICAL STANDARDS:</span>
                          {service.technicalSpecs[lang]}
                        </div>
                      </div>

                      {/* Right Col: Industries & Case Study link */}
                      <div className="bg-[#1A1E23] p-6 border border-white/10 space-y-4">
                        <div className="space-y-2">
                          <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
                            {"// RELATED INDUSTRIES"}
                          </h4>
                          <div className="flex flex-wrap gap-1.5">
                            {service.relatedIndustries.map((ind, idx) => (
                              <span
                                key={idx}
                                className="px-2 py-1 bg-white/5 text-neutral-300 text-xs font-mono rounded border border-white/10"
                              >
                                {ind}
                              </span>
                            ))}
                          </div>
                        </div>

                        <div className="pt-4 border-t border-white/10 space-y-2">
                          <span className="text-[11px] font-mono text-neutral-500 uppercase block">
                            DEMONSTRATION CASE STUDY
                          </span>
                          <button
                            onClick={() => onOpenProject && onOpenProject(service.syntheticProjectRef)}
                            className="text-xs font-mono text-[#F97316] hover:text-white flex items-center space-x-1 group text-left font-bold"
                          >
                            <span>{service.syntheticProjectRef}</span>
                            <ArrowUpRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
