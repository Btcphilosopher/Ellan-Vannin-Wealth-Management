'use client';

import React, { useState } from 'react';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { careersData, JobPosting } from '@/lib/data/careersData';
import { Briefcase, MapPin, Search, Filter, ArrowRight, X, CheckCircle, Upload, Send } from 'lucide-react';

export const CareersSection: React.FC = () => {
  const { lang, t } = useTranslation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState('All');
  const [selectedDept, setSelectedDept] = useState('All');
  const [activeJob, setActiveJob] = useState<JobPosting | null>(null);

  // Application form state
  const [applicantName, setApplicantName] = useState('');
  const [applicantEmail, setApplicantEmail] = useState('');
  const [fileName, setFileName] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const countries = ['All', 'Germany', 'Netherlands', 'Austria', 'Switzerland'];
  const departments = ['All', 'Consulting & Engineering', 'Turnarounds & Plant Construction', 'Digital Industrial Solutions', 'Prefabrication & Installation'];

  const filteredJobs = careersData.filter((job) => {
    if (selectedCountry !== 'All' && job.country !== selectedCountry) return false;
    if (selectedDept !== 'All' && job.department.en !== selectedDept) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = job.title[lang].toLowerCase().includes(q);
      const matchLoc = job.location.toLowerCase().includes(q);
      return matchTitle || matchLoc;
    }
    return true;
  });

  const handleApplySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (applicantName && applicantEmail) {
      setIsSubmitted(true);
    }
  };

  return (
    <section id="careers" className="py-20 bg-[#121518] text-white border-b border-[#2A3038] font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3">
          <span className="text-xs font-mono text-[#F97316] uppercase tracking-widest font-semibold block">
            {"// JOIN OUR EUROPEAN SPECIALIST NETWORK"}
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase tracking-tight font-sans">
            {t.careers.title}
          </h2>
          <p className="text-neutral-300 text-base font-sans">
            {t.careers.subtitle}
          </p>
        </div>

        {/* Filter Controls */}
        <div className="bg-[#1A1E23] p-6 border border-white/10 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs font-mono">
            <div>
              <label className="text-neutral-400 mb-1 block">Search Job Title</label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter engineering positions..."
                  className="w-full bg-[#121518] text-white text-xs pl-8 pr-3 py-2 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
                />
              </div>
            </div>

            <div>
              <label className="text-neutral-400 mb-1 block">Country / Hub</label>
              <select
                value={selectedCountry}
                onChange={(e) => setSelectedCountry(e.target.value)}
                className="w-full bg-[#121518] text-white text-xs px-3 py-2 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
              >
                {countries.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-neutral-400 mb-1 block">Department</label>
              <select
                value={selectedDept}
                onChange={(e) => setSelectedDept(e.target.value)}
                className="w-full bg-[#121518] text-white text-xs px-3 py-2 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
              >
                {departments.map((d) => (
                  <option key={d} value={d}>{d}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Job Listings List */}
        <div className="space-y-3">
          {filteredJobs.map((job) => (
            <div
              key={job.id}
              onClick={() => {
                setActiveJob(job);
                setIsSubmitted(false);
              }}
              className="p-6 bg-[#1A1E23] hover:bg-[#22272E] border border-white/10 hover:border-[#F97316] cursor-pointer transition-all flex flex-col md:flex-row md:items-center justify-between gap-4 group"
            >
              <div className="space-y-2">
                <div className="flex items-center space-x-3 text-xs font-mono">
                  <span className="px-2 py-0.5 bg-[#F97316]/10 text-[#F97316] font-bold border border-[#F97316]/30 uppercase">
                    {job.department[lang]}
                  </span>
                  <span className="text-neutral-400 flex items-center">
                    <MapPin className="w-3 h-3 text-[#F97316] mr-1" />
                    {job.location} ({job.country})
                  </span>
                  <span className="text-neutral-500">• {job.workModel}</span>
                </div>

                <h3 className="text-xl font-bold uppercase tracking-wider text-white font-sans group-hover:text-[#F97316] transition-colors">
                  {job.title[lang]}
                </h3>

                <p className="text-xs text-neutral-300 leading-relaxed max-w-3xl font-sans">
                  {job.description[lang]}
                </p>
              </div>

              <div className="flex items-center space-x-3 self-end md:self-auto shrink-0">
                <button className="px-4 py-2 bg-white/5 group-hover:bg-[#F97316] text-white font-mono text-xs font-bold uppercase rounded border border-white/10 group-hover:border-[#F97316] transition-all flex items-center space-x-1">
                  <span>{t.careers.applyNow}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Job Details & Demo Application Modal */}
        {activeJob && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
            <div className="bg-[#1A1E23] border border-[#2A3038] w-full max-w-3xl max-h-[90vh] overflow-y-auto shadow-2xl relative font-sans text-white p-6 sm:p-10 space-y-6">
              <button
                onClick={() => setActiveJob(null)}
                className="absolute top-6 right-6 p-2 bg-white/5 hover:bg-[#F97316] text-white border border-white/10"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="space-y-2 border-b border-white/10 pb-4 pr-10">
                <span className="text-xs font-mono text-[#F97316] font-bold uppercase">
                  {activeJob.department[lang]} — {activeJob.location}
                </span>
                <h2 className="text-2xl font-extrabold uppercase tracking-wider text-white font-sans">
                  {activeJob.title[lang]}
                </h2>
                <div className="text-xs font-mono text-neutral-400">
                  WORK MODEL: {activeJob.workModel} | EXPERIENCE: {activeJob.experienceLevel[lang]}
                </div>
              </div>

              {isSubmitted ? (
                <div className="p-8 bg-[#121518] border border-[#F97316] text-center space-y-4">
                  <CheckCircle className="w-12 h-12 text-[#F97316] mx-auto" />
                  <h3 className="text-xl font-bold uppercase text-white font-sans">APPLICATION TRANSMITTED</h3>
                  <p className="text-xs text-neutral-300 font-sans max-w-md mx-auto">
                    Thank you, <span className="text-white font-bold">{applicantName}</span>. Your application for <span className="text-[#F97316] font-bold">{activeJob.title[lang]}</span> has been registered in the synthetic demonstration portal.
                  </p>
                  <button
                    onClick={() => setActiveJob(null)}
                    className="px-6 py-2.5 bg-[#F97316] text-white font-mono text-xs font-bold uppercase"
                  >
                    Return to Positions
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Scope & Responsibilities */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316] font-bold">
                      {"// RESPONSIBILITIES:"}
                    </h4>
                    <ul className="space-y-1.5 text-xs text-neutral-300 font-sans">
                      {activeJob.responsibilities[lang].map((resp, idx) => (
                        <li key={idx} className="flex items-start space-x-2">
                          <span className="text-[#F97316] font-mono">•</span>
                          <span>{resp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Qualifications */}
                  <div className="space-y-3">
                    <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316] font-bold">
                      {"// QUALIFICATIONS:"}
                    </h4>
                    <ul className="space-y-1.5 text-xs text-neutral-300 font-sans">
                      {activeJob.qualifications[lang].map((qual, idx) => (
                        <li key={idx} className="flex items-start space-x-2">
                          <CheckCircle className="w-3.5 h-3.5 text-[#F97316] shrink-0 mt-0.5" />
                          <span>{qual}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Application Form */}
                  <form onSubmit={handleApplySubmit} className="pt-4 border-t border-white/10 space-y-4 bg-[#121518] p-6 border border-white/10">
                    <h4 className="text-xs font-mono uppercase tracking-widest text-white font-bold flex items-center">
                      <Send className="w-3.5 h-3.5 text-[#F97316] mr-1.5" /> SUBMIT DEMO APPLICATION
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
                      <div>
                        <label className="text-neutral-400 block mb-1">Full Name *</label>
                        <input
                          type="text"
                          required
                          value={applicantName}
                          onChange={(e) => setApplicantName(e.target.value)}
                          placeholder="Ing. Max Mustermann"
                          className="w-full bg-[#1A1E23] text-white p-2.5 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
                        />
                      </div>

                      <div>
                        <label className="text-neutral-400 block mb-1">Email Address *</label>
                        <input
                          type="email"
                          required
                          value={applicantEmail}
                          onChange={(e) => setApplicantEmail(e.target.value)}
                          placeholder="m.mustermann@engineering.de"
                          className="w-full bg-[#1A1E23] text-white p-2.5 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
                        />
                      </div>
                    </div>

                    <div className="space-y-1 text-xs font-mono">
                      <label className="text-neutral-400 block">CV / Resume Upload (PDF)</label>
                      <div className="flex items-center space-x-3 bg-[#1A1E23] p-3 border border-white/10 text-neutral-400">
                        <Upload className="w-4 h-4 text-[#F97316]" />
                        <input
                          type="file"
                          accept=".pdf,.doc,.docx"
                          onChange={(e) => setFileName(e.target.files?.[0]?.name || '')}
                          className="text-xs text-neutral-400"
                        />
                      </div>
                      {fileName && <span className="text-[11px] text-[#F97316]">Selected: {fileName}</span>}
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 bg-[#F97316] hover:bg-[#EA580C] text-white font-mono text-xs font-bold uppercase tracking-wider transition-colors"
                    >
                      Transmit Application Package
                    </button>
                  </form>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
