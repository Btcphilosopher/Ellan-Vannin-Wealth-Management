'use client';

import React, { useState } from 'react';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { calculateFacilityScenario, FacilityScenarioState } from '@/lib/data/sustainabilityData';
import { Sliders, Leaf, Zap, Clock, ShieldCheck, RefreshCw, BarChart2, Info } from 'lucide-react';

export const SustainabilityScenarioTool: React.FC = () => {
  const { lang, t } = useTranslation();

  const [scenarioState, setScenarioState] = useState<FacilityScenarioState>({
    energyEfficiency: 80,
    heatRecovery: 45,
    maintenanceMode: 'predictive',
    electrificationLevel: 60,
    productionLoad: 100,
    operatingHours: 8000,
  });

  const outputs = calculateFacilityScenario(scenarioState);

  const resetToBaseline = () => {
    setScenarioState({
      energyEfficiency: 60,
      heatRecovery: 10,
      maintenanceMode: 'reactive',
      electrificationLevel: 10,
      productionLoad: 100,
      operatingHours: 8760,
    });
  };

  return (
    <section id="sustainability" className="py-20 bg-[#121518] text-white border-b border-[#2A3038] font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3">
          <span className="text-xs font-mono text-[#F97316] uppercase tracking-widest font-semibold block">
            {"// SUSTAINABLE PLANT ENGINEERING"}
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase tracking-tight font-sans">
            {lang === 'de' ? 'Industrielle Performance nachhaltiger gestalten.' : 'Making industrial performance more sustainable.'}
          </h2>
          <p className="text-neutral-300 text-base font-sans">
            {t.sustainability.subtitle}
          </p>
        </div>

        {/* Interactive Scenario Tool Layout */}
        <div className="bg-[#1A1E23] border border-[#2A3038] p-6 lg:p-10 space-y-8 shadow-2xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/10 pb-4 gap-4">
            <div>
              <h3 className="text-xl font-extrabold uppercase tracking-wider text-white font-sans flex items-center">
                <Sliders className="w-5 h-5 text-[#F97316] mr-2" />
                {t.sustainability.simulatorTitle}
              </h3>
              <p className="text-xs text-neutral-400 font-sans mt-1">
                {t.sustainability.simulatorDesc}
              </p>
            </div>

            <button
              onClick={resetToBaseline}
              className="px-3 py-1.5 bg-white/5 hover:bg-white/10 text-neutral-300 text-xs font-mono rounded border border-white/10 flex items-center space-x-1.5 self-start sm:self-auto"
            >
              <RefreshCw className="w-3.5 h-3.5 text-[#F97316]" />
              <span>Reset to Legacy Baseline</span>
            </button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Left 7 Cols: Sliders & Controls */}
            <div className="lg:col-span-7 space-y-6">
              <div className="text-xs font-mono text-[#F97316] font-bold uppercase tracking-widest">
                {"// ADJUST SYNTHETIC FACILITY PARAMETERS"}
              </div>

              {/* Slider 1: Energy Efficiency */}
              <div className="space-y-2 bg-[#121518] p-4 border border-white/10">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-neutral-300 uppercase">{t.sustainability.energyEfficiency}</span>
                  <span className="text-[#F97316] font-bold">{scenarioState.energyEfficiency}%</span>
                </div>
                <input
                  type="range"
                  min={50}
                  max={100}
                  value={scenarioState.energyEfficiency}
                  onChange={(e) => setScenarioState({ ...scenarioState, energyEfficiency: Number(e.target.value) })}
                  className="w-full accent-[#F97316] cursor-pointer"
                />
              </div>

              {/* Slider 2: Heat Recovery */}
              <div className="space-y-2 bg-[#121518] p-4 border border-white/10">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-neutral-300 uppercase">{t.sustainability.heatRecovery}</span>
                  <span className="text-[#F97316] font-bold">{scenarioState.heatRecovery}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={scenarioState.heatRecovery}
                  onChange={(e) => setScenarioState({ ...scenarioState, heatRecovery: Number(e.target.value) })}
                  className="w-full accent-[#F97316] cursor-pointer"
                />
              </div>

              {/* Slider 3: Maintenance Strategy Mode */}
              <div className="space-y-2 bg-[#121518] p-4 border border-white/10">
                <div className="text-xs font-mono text-neutral-300 uppercase mb-2">
                  {t.sustainability.maintenanceStrategy}
                </div>
                <div className="grid grid-cols-3 gap-2 text-xs font-mono">
                  {(['reactive', 'scheduled', 'predictive'] as const).map((mode) => (
                    <button
                      key={mode}
                      onClick={() => setScenarioState({ ...scenarioState, maintenanceMode: mode })}
                      className={`p-2 rounded border transition-colors capitalize ${
                        scenarioState.maintenanceMode === mode
                          ? 'bg-[#F97316] text-white border-[#F97316] font-bold'
                          : 'bg-white/5 text-neutral-400 border-white/10 hover:text-white'
                      }`}
                    >
                      {mode === 'predictive' ? 'Predictive (BMC)' : mode}
                    </button>
                  ))}
                </div>
              </div>

              {/* Slider 4: Electrification Level */}
              <div className="space-y-2 bg-[#121518] p-4 border border-white/10">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-neutral-300 uppercase">{t.sustainability.electrificationLevel}</span>
                  <span className="text-[#F97316] font-bold">{scenarioState.electrificationLevel}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={100}
                  value={scenarioState.electrificationLevel}
                  onChange={(e) => setScenarioState({ ...scenarioState, electrificationLevel: Number(e.target.value) })}
                  className="w-full accent-[#F97316] cursor-pointer"
                />
              </div>

              {/* Slider 5: Production Load */}
              <div className="space-y-2 bg-[#121518] p-4 border border-white/10">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-neutral-300 uppercase">{t.sustainability.productionLoad}</span>
                  <span className="text-[#F97316] font-bold">{scenarioState.productionLoad}%</span>
                </div>
                <input
                  type="range"
                  min={50}
                  max={120}
                  value={scenarioState.productionLoad}
                  onChange={(e) => setScenarioState({ ...scenarioState, productionLoad: Number(e.target.value) })}
                  className="w-full accent-[#F97316] cursor-pointer"
                />
              </div>
            </div>

            {/* Right 5 Cols: Live Calculated Outputs */}
            <div className="lg:col-span-5 bg-[#121518] p-6 border border-white/10 space-y-6 flex flex-col justify-between">
              <div className="space-y-6">
                <div className="flex items-center space-x-2 text-xs font-mono text-[#F97316] font-bold uppercase tracking-widest border-b border-white/10 pb-3">
                  <BarChart2 className="w-4 h-4" />
                  <span>MODELED DEMONSTRATION OUTPUTS</span>
                </div>

                {/* Gauge 1: Energy Use */}
                <div className="space-y-1">
                  <span className="text-xs font-mono text-neutral-400 uppercase block">{t.sustainability.outputs.energyUse}</span>
                  <div className="flex items-baseline space-x-3">
                    <span className="text-3xl font-extrabold text-white font-mono">{outputs.energyUseIndex}</span>
                    <span className="text-xs font-mono text-neutral-500">(Baseline = 100)</span>
                  </div>
                  <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                    <div className="h-full bg-[#F97316]" style={{ width: `${Math.min(100, outputs.energyUseIndex)}%` }} />
                  </div>
                </div>

                {/* Gauge 2: CO2 Emissions */}
                <div className="space-y-1">
                  <span className="text-xs font-mono text-neutral-400 uppercase block">{t.sustainability.outputs.co2Emissions}</span>
                  <div className="flex items-baseline space-x-3">
                    <span className="text-3xl font-extrabold text-[#F97316] font-mono">{outputs.co2EmissionsTonnes.toLocaleString()}</span>
                    <span className="text-xs font-mono text-neutral-500">t CO₂ / yr</span>
                  </div>
                </div>

                {/* Gauge 3: Unplanned Downtime */}
                <div className="space-y-1">
                  <span className="text-xs font-mono text-neutral-400 uppercase block">{t.sustainability.outputs.downtime}</span>
                  <div className="flex items-baseline space-x-3">
                    <span className="text-3xl font-extrabold text-white font-mono">{outputs.unplannedDowntimeHours}</span>
                    <span className="text-xs font-mono text-neutral-500">Hours / yr</span>
                  </div>
                </div>

                {/* Gauge 4: OPEX Index */}
                <div className="space-y-1">
                  <span className="text-xs font-mono text-neutral-400 uppercase block">{t.sustainability.outputs.opexIndex}</span>
                  <div className="flex items-baseline space-x-3">
                    <span className="text-3xl font-extrabold text-white font-mono">{outputs.opexIndex}</span>
                    <span className="text-xs font-mono text-neutral-500">Index Factor</span>
                  </div>
                </div>
              </div>

              {/* Disclaimer */}
              <div className="p-3 bg-[#1A1E23] border border-white/10 text-[11px] font-mono text-neutral-400 space-y-1">
                <div className="flex items-center text-[#F97316] font-bold">
                  <Info className="w-3.5 h-3.5 mr-1" />
                  <span>SIMULATED MODEL NOTICE</span>
                </div>
                <p>{t.sustainability.syntheticDisclaimer}</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
