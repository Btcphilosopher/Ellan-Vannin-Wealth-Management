'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { companyTimeline, leadershipTeam, globalLocations, LocationHub } from '@/lib/data/companyData';
import { Building2, Globe, ShieldCheck, Award, MapPin, Users, History, CheckCircle } from 'lucide-react';

export const AboutSection: React.FC = () => {
  const { lang, t } = useTranslation();
  const [selectedHub, setSelectedHub] = useState<LocationHub>(globalLocations[0]);

  return (
    <section id="about" className="py-20 bg-[#121518] text-white border-b border-[#2A3038] font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-16">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3">
          <span className="text-xs font-mono text-[#F97316] uppercase tracking-widest font-semibold block">
            {"// INDUSTRIAL HERITAGE & GLOBAL REACH"}
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase tracking-tight font-sans">
            {t.about.title}
          </h2>
          <p className="text-neutral-300 text-base font-sans">
            {t.about.subtitle}
          </p>
        </div>

        {/* Narrative & History Timeline */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left Narrative */}
          <div className="lg:col-span-5 space-y-6">
            <h3 className="text-2xl font-extrabold uppercase tracking-wider text-white font-sans">
              140+ YEARS OF INDUSTRIAL ENGINEERING EXCELLENCE
            </h3>
            <p className="text-neutral-300 text-sm leading-relaxed font-sans">
              Bilfinger Industrial delivers comprehensive lifecycle solutions for process plants across Europe and global markets. From initial FEED feasibility studies and high-purity prefabrication to critical turnaround execution and digital OT/IT asset performance management, we bridge engineering precision with daily operational reliability.
            </p>

            <div className="p-4 bg-[#1A1E23] border-l-2 border-[#F97316] space-y-2 text-xs font-mono">
              <span className="text-[#F97316] font-bold block">{"// COMPLIANCE & HSEQ INTEGRITY"}</span>
              <p className="text-neutral-300">
                Operating strictly in accordance with ISO 9001, ISO 14001, ISO 45001, SCCP, and cGMP pharmaceutical regulations.
              </p>
            </div>
          </div>

          {/* Right Interactive History Timeline */}
          <div className="lg:col-span-7 bg-[#1A1E23] p-6 lg:p-8 border border-white/10 space-y-6">
            <div className="flex items-center space-x-2 text-xs font-mono text-[#F97316] font-bold uppercase tracking-widest border-b border-white/10 pb-3">
              <History className="w-4 h-4" />
              <span>EVOLUTION OF EUROPEAN PROCESS ENGINEERING</span>
            </div>

            <div className="space-y-6">
              {companyTimeline.map((item, idx) => (
                <div key={idx} className="flex items-start space-x-4 group">
                  <span className="px-2.5 py-1 bg-[#F97316] text-white font-mono text-xs font-bold rounded shrink-0">
                    {item.year}
                  </span>
                  <div className="space-y-1">
                    <h4 className="text-sm font-bold text-white group-hover:text-[#F97316] transition-colors font-sans">
                      {item.title[lang]}
                    </h4>
                    <p className="text-xs text-neutral-400 leading-relaxed font-sans">
                      {item.description[lang]}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Global Locations Map & Inspector */}
        <div className="space-y-6 pt-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/10 pb-4 gap-2">
            <div>
              <span className="text-xs font-mono text-[#F97316] font-bold uppercase tracking-widest">
                {"// INTERNATIONAL HUB NETWORK"}
              </span>
              <h3 className="text-2xl font-extrabold uppercase tracking-wider text-white font-sans">
                {t.about.hubsTitle}
              </h3>
            </div>
            <span className="text-xs font-mono text-neutral-400">30,000+ SPECIALISTS ACROSS 6 MAIN HUBS</span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Hub Buttons List */}
            <div className="lg:col-span-5 space-y-2">
              {globalLocations.map((loc) => {
                const isSelected = selectedHub.id === loc.id;
                return (
                  <button
                    key={loc.id}
                    onClick={() => setSelectedHub(loc)}
                    className={`w-full p-4 text-left transition-all border flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#1A1E23] border-[#F97316] text-white shadow-lg'
                        : 'bg-[#121518] border-white/10 hover:border-white/20 text-neutral-400 hover:text-neutral-200'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <MapPin className={`w-4 h-4 ${isSelected ? 'text-[#F97316]' : 'text-neutral-500'}`} />
                      <div>
                        <span className="text-sm font-bold uppercase font-sans block">{loc.city}</span>
                        <span className="text-xs font-mono text-neutral-400">{loc.country}</span>
                      </div>
                    </div>
                    <span className="text-xs font-mono text-[#F97316] font-bold">{loc.headcount}</span>
                  </button>
                );
              })}
            </div>

            {/* Selected Hub Inspector Card */}
            <div id="locations" className="lg:col-span-7 bg-[#1A1E23] p-8 border border-[#2A3038] space-y-6 shadow-2xl">
              <div className="flex items-center justify-between border-b border-white/10 pb-4">
                <div>
                  <span className="text-xs font-mono text-[#F97316] uppercase font-bold">{selectedHub.country}</span>
                  <h4 className="text-2xl font-extrabold text-white uppercase font-sans">{selectedHub.city} Hub</h4>
                </div>
                <span className="px-3 py-1 bg-[#F97316]/10 text-[#F97316] text-xs font-mono border border-[#F97316]/30 uppercase font-bold">
                  {selectedHub.headcount}
                </span>
              </div>

              <div className="space-y-2 text-xs font-mono text-neutral-300">
                <p className="text-white font-semibold">{selectedHub.hubType[lang]}</p>
                <p className="text-neutral-400">{selectedHub.address}</p>
              </div>

              <div className="space-y-3 pt-2">
                <h5 className="text-xs font-mono uppercase tracking-widest text-[#F97316]">{"// CORE SPECIALIZATIONS:"}</h5>
                <div className="grid grid-cols-2 gap-2 text-xs text-neutral-200 font-sans">
                  {selectedHub.specializations.map((spec, i) => (
                    <div key={i} className="flex items-center space-x-2 bg-[#121518] p-2.5 border border-white/5">
                      <CheckCircle className="w-3.5 h-3.5 text-[#F97316] shrink-0" />
                      <span>{spec}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Leadership Executive Board */}
        <div className="space-y-6 pt-6">
          <div className="border-b border-white/10 pb-4">
            <span className="text-xs font-mono text-[#F97316] font-bold uppercase tracking-widest">
              {"// EXECUTIVE GOVERNANCE"}
            </span>
            <h3 className="text-2xl font-extrabold uppercase tracking-wider text-white font-sans">
              {t.about.leadershipTitle}
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {leadershipTeam.map((leader, idx) => (
              <div key={idx} className="bg-[#1A1E23] border border-white/10 overflow-hidden group">
                <div className="h-64 bg-[#121518] overflow-hidden relative">
                  <Image
                    src={leader.imageUrl}
                    alt={leader.name}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500 opacity-80"
                    referrerPolicy="no-referrer"
                    unoptimized
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1A1E23] via-transparent to-transparent" />
                </div>
                <div className="p-6 space-y-2">
                  <h4 className="text-lg font-extrabold text-white uppercase font-sans">{leader.name}</h4>
                  <p className="text-xs font-mono text-[#F97316] font-bold uppercase">{leader.role[lang]}</p>
                  <p className="text-xs text-neutral-300 leading-relaxed font-sans pt-2">{leader.bio[lang]}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
