'use client';

import React, { useState } from 'react';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { industriesData, IndustryItem } from '@/lib/data/industriesData';
import { Factory, ShieldAlert, Zap, ArrowRight, X, MessageSquare, CheckCircle } from 'lucide-react';

interface IndustrySelectorProps {
  onDiscussChallenge: () => void;
}

export const IndustrySelector: React.FC<IndustrySelectorProps> = ({ onDiscussChallenge }) => {
  const { lang, t } = useTranslation();
  const [selectedIndustry, setSelectedIndustry] = useState<IndustryItem | null>(industriesData[0]);

  return (
    <section id="industries" className="py-20 bg-[#121518] text-white border-b border-[#2A3038] font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3 mb-12">
          <span className="text-xs font-mono text-[#F97316] uppercase tracking-widest font-semibold block">
            {"// SECTOR-SPECIFIC PROCESS ENGINEERING"}
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase tracking-tight font-sans">
            {t.industries.title}
          </h2>
          <p className="text-neutral-400 text-base font-sans">
            {t.industries.subtitle}
          </p>
        </div>

        {/* 6 Industry Selector Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {industriesData.map((ind) => {
            const isSelected = selectedIndustry?.id === ind.id;
            return (
              <button
                key={ind.id}
                onClick={() => setSelectedIndustry(ind)}
                className={`p-6 text-left transition-all border relative group flex flex-col justify-between ${
                  isSelected
                    ? 'bg-[#1A1E23] border-[#F97316] shadow-2xl'
                    : 'bg-[#121518] border-white/10 hover:border-white/30 hover:bg-[#1A1E23]/60'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-mono text-[#F97316] font-bold">SECTOR // {ind.id.toUpperCase()}</span>
                    <span className="p-1 bg-white/5 rounded border border-white/10 text-neutral-400 group-hover:text-white">
                      <Factory className="w-4 h-4" />
                    </span>
                  </div>

                  <h3 className="text-xl font-extrabold uppercase tracking-wider text-white mb-2 font-sans group-hover:text-[#F97316] transition-colors">
                    {ind.name[lang]}
                  </h3>

                  <p className="text-xs text-neutral-400 leading-relaxed font-sans line-clamp-3">
                    {ind.tagline[lang]}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-xs font-mono">
                  <span className={isSelected ? 'text-[#F97316] font-bold' : 'text-neutral-500'}>
                    {isSelected ? 'VIEWING SPECIFICATIONS' : 'EXAMINE SECTOR'}
                  </span>
                  <ArrowRight className={`w-4 h-4 ${isSelected ? 'text-[#F97316]' : 'text-neutral-600'}`} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Detailed Active Industry Inspector View */}
        {selectedIndustry && (
          <div className="bg-[#1A1E23] border border-[#2A3038] p-8 lg:p-12 relative overflow-hidden shadow-2xl space-y-8">
            <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/10 pb-6 gap-4">
              <div>
                <span className="text-xs font-mono text-[#F97316] font-bold uppercase tracking-widest">
                  SELECTED SECTOR SPECIFICATIONS
                </span>
                <h3 className="text-2xl sm:text-4xl font-extrabold text-white uppercase tracking-wider font-sans">
                  {selectedIndustry.name[lang]}
                </h3>
              </div>

              <div className="flex items-center space-x-3">
                <span className="px-3 py-1 bg-[#F97316]/10 text-[#F97316] font-mono text-xs font-bold uppercase rounded border border-[#F97316]/30">
                  PROCESS ENGINEERING COVERAGE
                </span>
              </div>
            </div>

            <p className="text-neutral-200 text-base leading-relaxed max-w-4xl font-sans">
              {selectedIndustry.intro[lang]}
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 pt-2">
              {/* Box 1: Sector Challenges */}
              <div className="bg-[#121518] p-6 border border-white/10 space-y-4">
                <div className="flex items-center space-x-2 text-[#F97316] text-xs font-mono font-bold uppercase tracking-wider">
                  <ShieldAlert className="w-4 h-4" />
                  <span>{t.industries.challenges}</span>
                </div>
                <ul className="space-y-2 text-xs text-neutral-300">
                  {selectedIndustry.challenges[lang].map((c, i) => (
                    <li key={i} className="flex items-start space-x-2">
                      <span className="text-[#F97316] font-mono font-bold">•</span>
                      <span>{c}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Box 2: Core Capabilities */}
              <div className="bg-[#121518] p-6 border border-white/10 space-y-4">
                <div className="flex items-center space-x-2 text-white text-xs font-mono font-bold uppercase tracking-wider">
                  <Zap className="w-4 h-4 text-[#F97316]" />
                  <span>{t.industries.capabilities}</span>
                </div>
                <ul className="space-y-2 text-xs text-neutral-300">
                  {selectedIndustry.capabilities[lang].map((cap, i) => (
                    <li key={i} className="flex items-start space-x-2">
                      <CheckCircle className="w-3.5 h-3.5 text-[#F97316] shrink-0 mt-0.5" />
                      <span>{cap}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Box 3: Synthetic Project Concept */}
              <div className="bg-[#121518] p-6 border border-white/10 space-y-4">
                <div className="flex items-center justify-between">
                  <span className="px-2 py-0.5 bg-[#F97316]/10 text-[#F97316] text-[10px] font-mono font-bold border border-[#F97316]/30 uppercase">
                    {t.industries.syntheticBadge}
                  </span>
                </div>
                {selectedIndustry.syntheticProjects.map((p, idx) => (
                  <div key={idx} className="space-y-2">
                    <h4 className="text-sm font-bold text-white font-sans">{p.title[lang]}</h4>
                    <p className="text-xs text-neutral-400 leading-relaxed font-sans">{p.description[lang]}</p>
                  </div>
                ))}

                <div className="pt-4 border-t border-white/10 flex justify-between items-center text-xs font-mono text-neutral-400">
                  <span>SUSTAINABILITY SCOPE:</span>
                  <span className="text-white font-bold">Scope-1 Abatement</span>
                </div>
              </div>
            </div>

            {/* Bottom Contact CTA inside Industry Inspector */}
            <div className="pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs font-mono text-neutral-400">
                NEED A CUSTOM SECTOR ASSESSMENT OR FEASIBILITY STUDY?
              </div>
              <button
                onClick={onDiscussChallenge}
                className="px-6 py-3 bg-[#F97316] hover:bg-[#EA580C] text-white font-bold text-xs uppercase tracking-wider font-sans transition-all flex items-center space-x-2"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Discuss {selectedIndustry.name[lang]} Challenge</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
