'use client';

import React, { useState } from 'react';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { Zap, ShieldCheck, Leaf, ArrowRight, Activity, BarChart2, CheckCircle2 } from 'lucide-react';

export const IndustrialPerformanceSection: React.FC = () => {
  const { lang, t } = useTranslation();
  const [activeTab, setActiveTab] = useState<'efficiency' | 'reliability' | 'sustainability'>('efficiency');

  const themeData = {
    efficiency: {
      title: t.performance.efficiencyTitle,
      subtitle: {
        en: 'Maximizing thermodynamic yields and lowering energy consumption per unit of chemical throughput.',
        de: 'Thermodynamische Erträge maximieren und Energieverbrauch pro Stoffmengeneinheit senken.',
      },
      desc: t.performance.efficiencyDesc,
      highlights: {
        en: [
          'Pinch-analysis heat network optimization cutting steam fuel demand by up to 30%',
          'Advanced multivariable process control (APC) stabilizing distillation column operations',
          'Mechanical vapor recompression (MVR) converting waste energy into productive process steam',
        ],
        de: [
          'Pinch-Analyse Wärmeintegration reduziert Dampfbedarf um bis to 30%',
          'Modellprädiktive Prozessregelung (APC) zur Stabilisierung von Destillationskolonnen',
          'Brüdenverdichtung (MVR) verwandelt Abwärme in nutzbaren Prozessdampf',
        ],
      },
      metric: 'up to -28%',
      metricLabel: { en: 'Thermal Energy Use Index', de: 'Thermischer Energieverbrauchsindex' },
      icon: Zap,
    },
    reliability: {
      title: t.performance.reliabilityTitle,
      subtitle: {
        en: 'Predictive engineering, turnaround excellence, and zero-unplanned-downtime asset protection.',
        de: 'Vorausschauendes Engineering, Stillstandsexzellenz und Instandhaltung ohne ungeplante Ausfälle.',
      },
      desc: t.performance.reliabilityDesc,
      highlights: {
        en: [
          'Bilfinger Maintenance Concept (BMC) standardized across 1,800 machinery assets',
          'Wireless IIoT tri-axial vibration sensors monitoring critical rotating pumps and compressors',
          'Turnaround Excellence Model (TAR-EM) delivering compressed critical-path shutdown execution',
        ],
        de: [
          'Bilfinger Maintenance Concept (BMC) standardisiert für über 1.800 Anlagenteile',
          'Drahtlose IIoT-Schwingungssensoren überwachen rotierende Pumpen und Verdichter',
          'Turnaround Excellence Modell (TAR-EM) für minimierte Stillstandszeiten am kritischen Pfad',
        ],
      },
      metric: '+13.6%',
      metricLabel: { en: 'Overall Equipment Effectiveness (OEE)', de: 'Gesamtanlageneffizienz (OEE)' },
      icon: ShieldCheck,
    },
    sustainability: {
      title: t.performance.sustainabilityTitle,
      subtitle: {
        en: 'Decarbonization roadmaps, industrial electrification, heat recovery, and green hydrogen builds.',
        de: 'Dekarbonisierungs-Roadmaps, industrielle Elektrifizierung, Abwärmenutzung und Wasserstoffanlagen.',
      },
      desc: t.performance.sustainabilityDesc,
      highlights: {
        en: [
          'Turnkey balance-of-plant engineering for 50MW+ PEM hydrogen electrolyzer installations',
          'Industrial high-temperature heat pumps displacing fossil steam generation in municipal grids',
          'Corrosion-under-insulation (CUI) aerogel cladding preventing insulation heat decay',
        ],
        de: [
          'Schlüsselfertiger Anlagenbau für 50MW+ PEM-Wasserstoff-Elektrolyseanlagen',
          'Industrielle Hochtemperatur-Wärmepumpen ersetzen fossile Dampferzeugung',
          'CUI-Isolierschutz mit Aerogel verhindert thermische Ausstrahlungsverluste',
        ],
      },
      metric: '-84,000 t',
      metricLabel: { en: 'Annual CO2 Abatement per Facility', de: 'Jährlich vermiedene CO2-Emissionen' },
      icon: Leaf,
    },
  };

  const currentTheme = themeData[activeTab];
  const IconComponent = currentTheme.icon;

  return (
    <section className="py-20 bg-[#121518] text-white border-b border-[#2A3038] relative overflow-hidden font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Editorial Statement */}
        <div className="text-center max-w-4xl mx-auto space-y-4 mb-16">
          <span className="text-xs font-mono text-[#F97316] uppercase tracking-widest block font-semibold">
            {"// INDUSTRIAL PERFORMANCE FOCUS"}
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight uppercase font-sans text-white">
            {t.performance.statement}
          </h2>
          <p className="text-xl sm:text-2xl text-neutral-300 font-medium font-sans">
            {t.performance.substatement}
          </p>
        </div>

        {/* 3 Measurable Theme Selector Tabs */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {(['efficiency', 'reliability', 'sustainability'] as const).map((key) => {
            const item = themeData[key];
            const isActive = activeTab === key;
            const ItemIcon = item.icon;
            return (
              <button
                key={key}
                onClick={() => setActiveTab(key)}
                className={`p-6 text-left transition-all border rounded-none flex flex-col justify-between ${
                  isActive
                    ? 'bg-[#1A1E23] border-[#F97316] shadow-xl text-white'
                    : 'bg-[#121518] border-white/10 hover:border-white/20 text-neutral-400 hover:text-neutral-200'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <ItemIcon className={`w-6 h-6 ${isActive ? 'text-[#F97316]' : 'text-neutral-500'}`} />
                    <span className="font-mono text-xs text-neutral-500">0{key === 'efficiency' ? 1 : key === 'reliability' ? 2 : 3}</span>
                  </div>
                  <h3 className="text-lg font-bold uppercase tracking-wider mb-2 font-sans">{item.title}</h3>
                  <p className="text-xs leading-relaxed line-clamp-2 font-sans">{item.subtitle[lang]}</p>
                </div>

                <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-xs font-mono">
                  <span className={isActive ? 'text-[#F97316] font-bold' : 'text-neutral-500'}>
                    {isActive ? 'ACTIVE PANEL' : 'EXPLORE METRICS'}
                  </span>
                  <ArrowRight className={`w-4 h-4 ${isActive ? 'text-[#F97316]' : 'text-neutral-600'}`} />
                </div>
              </button>
            );
          })}
        </div>

        {/* Interactive Content Panel Expansion */}
        <div className="bg-[#1A1E23] border border-[#2A3038] p-8 lg:p-12 relative overflow-hidden shadow-2xl">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 items-center">
            <div className="lg:col-span-2 space-y-6">
              <div className="flex items-center space-x-3">
                <div className="p-3 bg-[#F97316]/10 border border-[#F97316]/30 text-[#F97316]">
                  <IconComponent className="w-8 h-8" />
                </div>
                <div>
                  <div className="text-xs font-mono text-[#F97316] uppercase tracking-widest">MEASURABLE THEME — 01</div>
                  <h3 className="text-2xl font-bold uppercase tracking-wider text-white font-sans">
                    {currentTheme.title}
                  </h3>
                </div>
              </div>

              <p className="text-neutral-300 text-base leading-relaxed font-sans">
                {currentTheme.desc}
              </p>

              <div className="space-y-3 pt-2">
                <h4 className="text-xs font-mono uppercase tracking-wider text-neutral-400">{"// TECHNICAL IMPLEMENTATION HIGHLIGHTS:"}</h4>
                <ul className="space-y-2">
                  {currentTheme.highlights[lang].map((hl, idx) => (
                    <li key={idx} className="flex items-start space-x-3 text-sm text-neutral-200 font-sans">
                      <CheckCircle2 className="w-4 h-4 text-[#F97316] shrink-0 mt-0.5" />
                      <span>{hl}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* KPI Highlight Box */}
            <div className="bg-[#121518] p-8 border border-white/10 text-center space-y-3">
              <span className="text-xs font-mono text-neutral-500 uppercase tracking-widest block">DEMONSTRATION BENCHMARK</span>
              <div className="text-4xl lg:text-5xl font-extrabold text-[#F97316] font-mono tracking-tight">
                {currentTheme.metric}
              </div>
              <div className="text-xs font-mono text-neutral-300 uppercase tracking-wider">
                {currentTheme.metricLabel[lang]}
              </div>
              <p className="text-[11px] font-mono text-neutral-500 pt-3 border-t border-white/10">
                Verified across synthetic process facility audits and customer benchmark models.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
