'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { projectsData, ProjectItem } from '@/lib/data/projectsData';
import { Filter, Search, X, Calendar, MapPin, CheckCircle2, ArrowRight, Layers, Sliders, Image as ImageIcon } from 'lucide-react';

export const ProjectExplorer: React.FC = () => {
  const { lang, t } = useTranslation();
  const [selectedIndustry, setSelectedIndustry] = useState<string>('All');
  const [selectedService, setSelectedService] = useState<string>('All');
  const [selectedRegion, setSelectedRegion] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeProjectModal, setActiveProjectModal] = useState<ProjectItem | null>(null);

  const industriesList = ['All', 'Energy', 'Pharma & Biopharma', 'Chemicals & Petrochemicals', 'Industrial Manufacturing', 'Oil & Gas', 'Utilities'];
  const servicesList = ['All', 'Energy Transition', 'Prefabrication & Installation', 'Process Optimisation', 'Maintenance', 'Plant Construction'];
  const regionsList = ['All', 'Central Europe', 'Western Europe', 'North Sea'];

  const filteredProjects = projectsData.filter((project) => {
    if (selectedIndustry !== 'All' && project.industry !== selectedIndustry) return false;
    if (selectedService !== 'All' && project.service !== selectedService) return false;
    if (selectedRegion !== 'All' && project.region !== selectedRegion) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const matchTitle = project.title[lang].toLowerCase().includes(q);
      const matchSummary = project.summary[lang].toLowerCase().includes(q);
      const matchLoc = project.location.toLowerCase().includes(q);
      return matchTitle || matchSummary || matchLoc;
    }
    return true;
  });

  return (
    <section id="projects" className="py-20 bg-[#121518] text-white border-b border-[#2A3038] font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Title */}
        <div className="max-w-3xl space-y-3 mb-10">
          <span className="text-xs font-mono text-[#F97316] uppercase tracking-widest font-semibold block">
            {"// DEMONSTRATION ENGINEERING PORTFOLIO"}
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase tracking-tight font-sans">
            {t.projects.title}
          </h2>
          <p className="text-neutral-400 text-base font-sans">
            {t.projects.subtitle}
          </p>
        </div>

        {/* Filter Bar Controls */}
        <div className="bg-[#1A1E23] p-4 sm:p-6 border border-white/10 mb-10 space-y-4">
          <div className="flex items-center space-x-2 text-xs font-mono text-[#F97316] font-bold uppercase tracking-widest border-b border-white/5 pb-3">
            <Filter className="w-4 h-4" />
            <span>PORTFOLIO FILTERS & MATRIX QUERY</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-xs font-mono">
            {/* Search Input */}
            <div>
              <label className="text-neutral-400 mb-1 block">Search Query</label>
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Filter by keyword..."
                  className="w-full bg-[#121518] text-white text-xs pl-8 pr-3 py-2 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
                />
              </div>
            </div>

            {/* Filter Industry */}
            <div>
              <label className="text-neutral-400 mb-1 block">Industry Sector</label>
              <select
                value={selectedIndustry}
                onChange={(e) => setSelectedIndustry(e.target.value)}
                className="w-full bg-[#121518] text-white text-xs px-3 py-2 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
              >
                {industriesList.map((ind) => (
                  <option key={ind} value={ind}>
                    {ind === 'All' ? t.projects.allIndustries : ind}
                  </option>
                ))}
              </select>
            </div>

            {/* Filter Service */}
            <div>
              <label className="text-neutral-400 mb-1 block">Engineering Service</label>
              <select
                value={selectedService}
                onChange={(e) => setSelectedService(e.target.value)}
                className="w-full bg-[#121518] text-white text-xs px-3 py-2 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
              >
                {servicesList.map((srv) => (
                  <option key={srv} value={srv}>
                    {srv === 'All' ? t.projects.allServices : srv}
                  </option>
                ))}
              </select>
            </div>

            {/* Filter Region */}
            <div>
              <label className="text-neutral-400 mb-1 block">Geographic Region</label>
              <select
                value={selectedRegion}
                onChange={(e) => setSelectedRegion(e.target.value)}
                className="w-full bg-[#121518] text-white text-xs px-3 py-2 border border-white/10 rounded-none focus:outline-none focus:border-[#F97316]"
              >
                {regionsList.map((reg) => (
                  <option key={reg} value={reg}>
                    {reg === 'All' ? t.projects.allRegions : reg}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Projects Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((project) => (
            <div
              key={project.id}
              onClick={() => setActiveProjectModal(project)}
              className="bg-[#1A1E23] border border-white/10 hover:border-[#F97316] transition-all cursor-pointer group flex flex-col justify-between overflow-hidden shadow-lg"
            >
              <div>
                {/* Image header with overlay badge */}
                <div className="relative h-48 overflow-hidden bg-[#121518]">
                  <Image
                    src={project.imageUrl}
                    alt={project.title[lang]}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500 opacity-80"
                    referrerPolicy="no-referrer"
                    unoptimized
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#1A1E23] via-transparent to-transparent" />

                  <div className="absolute top-3 left-3">
                    <span className="px-2 py-1 bg-[#F97316] text-white text-[10px] font-mono font-bold uppercase tracking-wider">
                      {project.number}
                    </span>
                  </div>

                  <div className="absolute top-3 right-3">
                    <span className="px-2 py-1 bg-black/70 backdrop-blur-md text-[#F97316] text-[10px] font-mono font-bold border border-[#F97316]/30 uppercase">
                      {t.projects.syntheticBadge}
                    </span>
                  </div>
                </div>

                <div className="p-6 space-y-4">
                  <div className="flex items-center space-x-2 text-xs font-mono text-neutral-400">
                    <MapPin className="w-3.5 h-3.5 text-[#F97316]" />
                    <span>{project.location}</span>
                  </div>

                  <h3 className="text-xl font-extrabold uppercase tracking-wider text-white font-sans group-hover:text-[#F97316] transition-colors">
                    {project.title[lang]}
                  </h3>

                  <p className="text-xs text-neutral-300 leading-relaxed line-clamp-3 font-sans">
                    {project.summary[lang]}
                  </p>

                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {project.disciplines.slice(0, 3).map((disc, i) => (
                      <span key={i} className="px-2 py-0.5 bg-white/5 text-neutral-400 text-[10px] font-mono border border-white/10">
                        {disc}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0 border-t border-white/5 mt-4">
                <div className="flex items-center justify-between text-xs font-mono pt-4 text-neutral-400">
                  <span className="text-[#F97316] font-bold">{project.status[lang]}</span>
                  <div className="flex items-center space-x-1 group-hover:text-white transition-colors">
                    <span>EXAMINE SPECS</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform text-[#F97316]" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Project Detail Modal */}
        {activeProjectModal && (
          <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
            <div className="bg-[#1A1E23] border border-[#2A3038] w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-2xl relative font-sans text-white p-6 sm:p-10 space-y-8">
              {/* Modal Close Button */}
              <button
                onClick={() => setActiveProjectModal(null)}
                className="absolute top-6 right-6 p-2 bg-white/5 hover:bg-[#F97316] text-white transition-colors border border-white/10"
                aria-label="Close project modal"
              >
                <X className="w-5 h-5" />
              </button>

              {/* Modal Header */}
              <div className="space-y-3 border-b border-white/10 pb-6 pr-12">
                <div className="flex items-center space-x-3 text-xs font-mono text-[#F97316]">
                  <span className="font-bold uppercase tracking-widest">{activeProjectModal.industry} — {activeProjectModal.service}</span>
                  <span className="text-neutral-600">|</span>
                  <span className="text-neutral-400">{activeProjectModal.location}</span>
                </div>

                <h2 className="text-2xl sm:text-4xl font-extrabold uppercase tracking-wider font-sans">
                  {activeProjectModal.title[lang]}
                </h2>

                <div className="inline-block px-3 py-1 bg-[#F97316]/10 text-[#F97316] text-xs font-mono font-bold border border-[#F97316]/30 uppercase">
                  {t.projects.syntheticBadge}
                </div>
              </div>

              {/* Challenge / Solution / Outcome Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="bg-[#121518] p-5 border border-white/10 space-y-2">
                  <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316] font-bold">
                    {"// 01. "} {t.projects.challenge}
                  </h4>
                  <p className="text-xs text-neutral-300 leading-relaxed font-sans">
                    {activeProjectModal.challenge[lang]}
                  </p>
                </div>

                <div className="bg-[#121518] p-5 border border-white/10 space-y-2">
                  <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316] font-bold">
                    {"// 02. "} {t.projects.solution}
                  </h4>
                  <p className="text-xs text-neutral-300 leading-relaxed font-sans">
                    {activeProjectModal.solution[lang]}
                  </p>
                </div>

                <div className="bg-[#121518] p-5 border border-white/10 space-y-2">
                  <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316] font-bold">
                    {"// 03. "} {t.projects.outcome}
                  </h4>
                  <p className="text-xs text-neutral-300 leading-relaxed font-sans">
                    {activeProjectModal.outcome[lang]}
                  </p>
                </div>
              </div>

              {/* Metrics Row */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 bg-[#121518] p-6 border border-white/10 font-mono text-center">
                {activeProjectModal.metrics.map((m, i) => (
                  <div key={i}>
                    <span className="text-2xl sm:text-3xl font-extrabold text-[#F97316] block">{m.value}</span>
                    <span className="text-[11px] text-neutral-400 uppercase tracking-wider">{m.label[lang]}</span>
                  </div>
                ))}
              </div>

              {/* Timeline Section */}
              <div className="space-y-4">
                <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316] font-bold">
                  {"// PROJECT EXECUTION TIMELINE & MILESTONES"}
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {activeProjectModal.timeline.map((step, idx) => (
                    <div key={idx} className="bg-[#121518] p-4 border-l-2 border-[#F97316] space-y-1">
                      <span className="text-xs font-mono text-[#F97316] font-bold">{step.date}</span>
                      <h5 className="text-xs font-bold text-white font-sans">{step.title[lang]}</h5>
                      <p className="text-[11px] text-neutral-400 font-sans">{step.desc[lang]}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Technical Systems & Disciplines */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                <div>
                  <h4 className="text-xs font-mono uppercase tracking-widest text-neutral-400 mb-2">{"// TECHNICAL SYSTEMS INSTALLED:"}</h4>
                  <div className="flex flex-wrap gap-1.5">
                    {activeProjectModal.technicalSystems.map((sys, idx) => (
                      <span key={idx} className="px-2.5 py-1 bg-white/5 text-neutral-300 text-xs font-mono border border-white/10">
                        {sys}
                      </span>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-xs font-mono uppercase tracking-widest text-neutral-400 mb-2">{"// ENGINEERING DISCIPLINES INVOLVED:"}</h4>
                  <div className="flex flex-wrap gap-1.5">
                    {activeProjectModal.disciplines.map((disc, idx) => (
                      <span key={idx} className="px-2.5 py-1 bg-[#F97316]/10 text-[#F97316] text-xs font-mono border border-[#F97316]/30">
                        {disc}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Image Gallery */}
              <div className="space-y-3 pt-4 border-t border-white/10">
                <h4 className="text-xs font-mono uppercase tracking-widest text-neutral-400 flex items-center">
                  <ImageIcon className="w-4 h-4 mr-1.5 text-[#F97316]" /> {"// SYNTHETIC PROJECT VISUAL GALLERY"}
                </h4>
                <div className="grid grid-cols-3 gap-4">
                  {activeProjectModal.galleryUrls.map((url, i) => (
                    <div key={i} className="h-32 bg-[#121518] overflow-hidden border border-white/10 relative">
                      <Image
                        src={url}
                        alt={`Gallery ${i}`}
                        fill
                        className="object-cover hover:scale-105 transition-transform"
                        referrerPolicy="no-referrer"
                        unoptimized
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};
