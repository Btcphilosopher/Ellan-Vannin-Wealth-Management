'use client';

import React from 'react';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { ArrowRight, MessageSquare, Shield, Activity, Compass, Cpu } from 'lucide-react';

interface HeroSectionProps {
  onExploreServices: () => void;
  onDiscussChallenge: () => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({ onExploreServices, onDiscussChallenge }) => {
  const { lang, t } = useTranslation();

  return (
    <section className="relative min-h-[90vh] lg:min-h-screen flex items-center pt-24 pb-16 bg-[#121518] overflow-hidden border-b border-[#2A3038]">
      {/* Background Image Overlay with Industrial Visual */}
      <div className="absolute inset-0 z-0">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-30 transform scale-105 animate-pulse transition-all duration-[10000ms]"
          style={{
            backgroundImage: `url('https://picsum.photos/seed/industrial-refinery-hero/1920/1080')`,
          }}
        />
        {/* Dark Vignette Gradients */}
        <div className="absolute inset-0 bg-gradient-to-r from-[#121518] via-[#121518]/90 to-[#121518]/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#121518] via-transparent to-[#121518]/80" />
      </div>

      {/* Fine Technical Grid & Crosshairs */}
      <div className="absolute inset-0 bg-grid-pattern opacity-15 pointer-events-none z-0" />

      {/* Animated Measurement Line Overlays */}
      <div className="absolute top-1/4 right-12 lg:right-24 hidden lg:flex flex-col space-y-8 z-10 font-mono text-[11px] text-neutral-400 border-l border-[#F97316]/30 pl-4 py-6">
        <div className="flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-[#F97316] animate-ping" />
          <span className="text-[#F97316] font-bold">LIVE TELEMETRY [NODE_HQ]</span>
        </div>
        <div>
          <span className="text-neutral-500 block">FLOW RATE (STEAM):</span>
          <span className="text-white font-bold">142.8 t/h @ 120 Bar</span>
        </div>
        <div>
          <span className="text-neutral-500 block">THERMAL YIELD:</span>
          <span className="text-white font-bold">94.6% OPTIMAL</span>
        </div>
        <div>
          <span className="text-neutral-500 block">TURBINE VIBRATION:</span>
          <span className="text-white font-bold">0.82 mm/s [ISO PASS]</span>
        </div>
        <div className="pt-2 border-t border-white/10 text-[10px] text-neutral-500">
          GRID_LAT: 49.4875° N <br />
          GRID_LON: 8.4660° E
        </div>
      </div>

      {/* Content Container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="max-w-3xl space-y-8">
          {/* Restrained Technical Label */}
          <div className="inline-flex items-center space-x-3 px-3 py-1.5 bg-[#1A1E23]/90 border border-white/15 text-xs font-mono text-neutral-300 backdrop-blur-md">
            <span className="w-2 h-2 bg-[#F97316]" />
            <span className="font-bold tracking-widest text-[#F97316]">{t.hero.label}</span>
            <span className="text-neutral-600">|</span>
            <span className="text-neutral-400 font-mono text-[11px]">{t.hero.statusLabel}</span>
          </div>

          {/* Main Title */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-white tracking-tight leading-[1.05] uppercase font-sans">
            {t.hero.title}
          </h1>

          {/* Subtitle & Body */}
          <div className="space-y-4 border-l-2 border-[#F97316] pl-6 py-1">
            <p className="text-xl sm:text-2xl font-medium text-neutral-200 leading-snug font-sans">
              {t.hero.subtitle}
            </p>
            <p className="text-base sm:text-lg text-neutral-400 leading-relaxed max-w-2xl font-sans">
              {t.hero.body}
            </p>
          </div>

          {/* CTA Buttons */}
          <div className="pt-4 flex flex-col sm:flex-row items-stretch sm:items-center gap-4">
            <button
              onClick={onExploreServices}
              className="px-8 py-4 bg-[#F97316] hover:bg-[#EA580C] text-white font-bold text-sm uppercase tracking-wider font-sans transition-all flex items-center justify-center space-x-3 shadow-xl group border border-[#F97316]"
            >
              <span>{t.hero.primaryCta}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={onDiscussChallenge}
              className="px-8 py-4 bg-[#1A1E23] hover:bg-[#22272E] text-white font-bold text-sm uppercase tracking-wider font-sans border border-white/20 transition-all flex items-center justify-center space-x-3 group"
            >
              <MessageSquare className="w-4 h-4 text-[#F97316] group-hover:scale-110 transition-transform" />
              <span>{t.hero.secondaryCta}</span>
            </button>
          </div>

          {/* Key Metric Highlights Banner */}
          <div className="pt-10 grid grid-cols-2 sm:grid-cols-4 gap-4 border-t border-white/10 text-xs font-mono">
            <div>
              <span className="text-[#F97316] font-bold block text-lg font-sans">30,000+</span>
              <span className="text-neutral-400 uppercase">Process Specialists</span>
            </div>
            <div>
              <span className="text-white font-bold block text-lg font-sans">14 DOMAINS</span>
              <span className="text-neutral-400 uppercase">Lifecycle Services</span>
            </div>
            <div>
              <span className="text-white font-bold block text-lg font-sans">0.22 LTI</span>
              <span className="text-neutral-400 uppercase">Class Safety Index</span>
            </div>
            <div>
              <span className="text-white font-bold block text-lg font-sans">100% DE / EN</span>
              <span className="text-neutral-400 uppercase">Bilingual Delivery</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
