'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { Search, Globe, Menu, X, ChevronRight, Shield, MapPin, Building, FileText, Lock } from 'lucide-react';

interface SiteHeaderProps {
  onOpenSearch: () => void;
  activeSection?: string;
  setActiveSection?: (section: string) => void;
}

export const SiteHeader: React.FC<SiteHeaderProps> = ({ onOpenSearch, activeSection, setActiveSection }) => {
  const { lang, setLang, t } = useTranslation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavClick = (sectionId: string) => {
    if (setActiveSection) {
      setActiveSection(sectionId);
    }
    setMobileMenuOpen(false);
    // Smooth scroll if element exists on page
    const elem = document.getElementById(sectionId);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const navItems = [
    { id: 'home', label: t.nav.home },
    { id: 'services', label: t.nav.services },
    { id: 'industries', label: t.nav.industries },
    { id: 'projects', label: t.nav.projects },
    { id: 'digital', label: t.nav.digital },
    { id: 'sustainability', label: t.nav.sustainability },
    { id: 'about', label: t.nav.about },
    { id: 'careers', label: t.nav.careers },
    { id: 'contact', label: t.nav.contact },
  ];

  const utilityItems = [
    { id: 'locations', label: t.nav.locations, icon: MapPin },
    { id: 'news', label: t.nav.news, icon: FileText },
    { id: 'investors', label: t.nav.investors, icon: Building },
    { id: 'supplier-portal', label: t.nav.supplierPortal, icon: Shield },
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-all duration-300 border-b ${
        scrolled
          ? 'bg-[#121518]/95 backdrop-blur-md border-[#2A3038] py-2.5 shadow-2xl'
          : 'bg-[#121518]/80 backdrop-blur-sm border-white/10 py-4'
      }`}
    >
      {/* Utility Top Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between text-xs text-neutral-400 pb-2 border-b border-white/5 mb-3 hidden md:flex">
          <div className="flex items-center space-x-6 font-mono tracking-wider">
            <span className="flex items-center text-[#F97316]">
              <span className="w-1.5 h-1.5 rounded-full bg-[#F97316] animate-pulse mr-2"></span>
              BILFINGER INDUSTRIAL PLATFORM
            </span>
            <span className="text-neutral-500">|</span>
            <span className="text-neutral-300">SYS_OPERATIONAL</span>
            <span className="text-neutral-500">|</span>
            <span className="text-neutral-400">HQ MANNHEIM [DE]</span>
          </div>

          <div className="flex items-center space-x-6">
            {utilityItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className="hover:text-white transition-colors flex items-center space-x-1.5 text-neutral-400"
              >
                <item.icon className="w-3.5 h-3.5 text-[#F97316]" />
                <span>{item.label}</span>
              </button>
            ))}

            {/* Language Toggle */}
            <div className="flex items-center space-x-1 pl-4 border-l border-white/10">
              <Globe className="w-3.5 h-3.5 text-neutral-400 mr-1" />
              <button
                onClick={() => setLang('en')}
                className={`px-1.5 py-0.5 font-mono text-xs font-semibold rounded transition-colors ${
                  lang === 'en' ? 'bg-[#F97316] text-white' : 'text-neutral-400 hover:text-white'
                }`}
                aria-label="Switch to English"
              >
                EN
              </button>
              <span className="text-neutral-600">/</span>
              <button
                onClick={() => setLang('de')}
                className={`px-1.5 py-0.5 font-mono text-xs font-semibold rounded transition-colors ${
                  lang === 'de' ? 'bg-[#F97316] text-white' : 'text-neutral-400 hover:text-white'
                }`}
                aria-label="Auf Deutsch wechseln"
              >
                DE
              </button>
            </div>
          </div>
        </div>

        {/* Main Navigation Row */}
        <div className="flex items-center justify-between">
          {/* Logo / Branding */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center space-x-3 text-left group focus:outline-none"
          >
            <div className="w-9 h-9 bg-[#F97316] flex items-center justify-center font-mono font-extrabold text-white text-lg tracking-tighter shadow-lg group-hover:bg-[#EA580C] transition-colors border border-white/20">
              BI
            </div>
            <div>
              <div className="font-extrabold tracking-wider text-lg text-white font-sans flex items-center">
                Bilfinger <span className="text-[#F97316] font-mono ml-1 font-normal text-xs uppercase tracking-widest px-1.5 py-0.5 bg-white/5 border border-white/10 rounded-sm">INDUSTRIAL</span>
              </div>
              <div className="text-[10px] font-mono text-neutral-400 uppercase tracking-widest hidden sm:block">
                European Process Engineering & Services
              </div>
            </div>
          </button>

          {/* Desktop Primary Nav Links */}
          <nav className="hidden lg:flex items-center space-x-1 xl:space-x-2" aria-label="Primary Navigation">
            {navItems.map((item) => {
              const isActive = activeSection === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className={`px-3 py-1.5 text-xs font-semibold uppercase tracking-wider font-sans transition-all relative ${
                    isActive
                      ? 'text-white font-bold bg-white/5 border-b-2 border-[#F97316]'
                      : 'text-neutral-300 hover:text-white hover:bg-white/5'
                  }`}
                >
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Search Trigger & Mobile Menu Button */}
          <div className="flex items-center space-x-3">
            <button
              onClick={onOpenSearch}
              className="flex items-center space-x-2 bg-[#1A1E23] hover:bg-[#22272E] text-neutral-300 hover:text-white px-3 py-2 border border-white/10 text-xs font-mono transition-all rounded-sm focus:outline-none focus:border-[#F97316]"
              aria-label="Open Search"
            >
              <Search className="w-4 h-4 text-[#F97316]" />
              <span className="hidden sm:inline">{t.nav.search}</span>
              <kbd className="hidden md:inline-block px-1.5 py-0.5 text-[10px] bg-black/40 text-neutral-400 rounded border border-white/10 ml-2 font-mono">
                ⌘K
              </kbd>
            </button>

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="lg:hidden p-2 text-neutral-300 hover:text-white bg-[#1A1E23] border border-white/10 rounded-sm focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6 text-[#F97316]" /> : <Menu className="w-6 h-6 text-white" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Full Screen Navigation Panel */}
      {mobileMenuOpen && (
        <div className="lg:hidden fixed inset-0 top-[65px] bg-[#121518] z-50 overflow-y-auto border-t border-white/10 px-6 py-8 flex flex-col justify-between">
          <div className="space-y-6">
            <div className="flex justify-between items-center pb-4 border-b border-white/10">
              <span className="text-xs font-mono text-[#F97316] tracking-widest uppercase">
                {"// MOBILE NAVIGATION MATRIX"}
              </span>
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => setLang('en')}
                  className={`px-2 py-1 font-mono text-xs rounded ${
                    lang === 'en' ? 'bg-[#F97316] text-white' : 'bg-white/5 text-neutral-400'
                  }`}
                >
                  EN
                </button>
                <button
                  onClick={() => setLang('de')}
                  className={`px-2 py-1 font-mono text-xs rounded ${
                    lang === 'de' ? 'bg-[#F97316] text-white' : 'bg-white/5 text-neutral-400'
                  }`}
                >
                  DE
                </button>
              </div>
            </div>

            <nav className="flex flex-col space-y-2">
              {navItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => handleNavClick(item.id)}
                  className="flex items-center justify-between p-3 text-base font-semibold text-neutral-200 hover:text-white hover:bg-white/5 border-b border-white/5 transition-colors text-left font-sans"
                >
                  <span>{item.label}</span>
                  <ChevronRight className="w-4 h-4 text-[#F97316]" />
                </button>
              ))}
            </nav>

            <div className="pt-4 border-t border-white/10 space-y-3">
              <div className="text-xs font-mono text-neutral-400 uppercase tracking-wider mb-2">
                Utility Services & Portals
              </div>
              <div className="grid grid-cols-2 gap-2">
                {utilityItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className="p-2.5 bg-[#1A1E23] border border-white/10 rounded text-xs text-neutral-300 hover:text-white flex items-center space-x-2 text-left"
                  >
                    <item.icon className="w-4 h-4 text-[#F97316]" />
                    <span>{item.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-white/10 text-xs font-mono text-neutral-500 space-y-2">
            <p>BILFINGER INDUSTRIAL ENGINEERING PLATFORM</p>
            <p className="text-[#F97316]">SYSTEM_VER: 2026.3.18-RELEASE</p>
          </div>
        </div>
      )}
    </header>
  );
};
