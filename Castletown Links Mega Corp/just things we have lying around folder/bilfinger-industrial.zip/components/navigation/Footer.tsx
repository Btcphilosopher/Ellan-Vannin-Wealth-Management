'use client';

import React from 'react';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { ShieldCheck, MapPin, Globe, Phone, Mail, Award, ArrowUp, ExternalLink } from 'lucide-react';

interface FooterProps {
  onNavigateSection: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigateSection }) => {
  const { lang, setLang, t } = useTranslation();

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0B0D0E] border-t border-[#2A3038] text-neutral-400 pt-16 pb-12 font-sans relative overflow-hidden">
      {/* Background Technical Grid */}
      <div className="absolute inset-0 bg-grid-pattern opacity-10 pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 pb-12 border-b border-white/10">
          {/* Col 1: Brand & Identity */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-[#F97316] flex items-center justify-center font-mono font-extrabold text-white text-xl">
                BI
              </div>
              <div>
                <div className="font-extrabold tracking-wider text-xl text-white">
                  Bilfinger <span className="text-[#F97316] font-mono font-normal text-xs uppercase tracking-widest px-1.5 py-0.5 bg-white/5 border border-white/10 rounded-sm">INDUSTRIAL</span>
                </div>
                <div className="text-xs font-mono text-neutral-400 uppercase tracking-widest">
                  European Process Engineering & Industrial Services
                </div>
              </div>
            </div>

            <p className="text-sm text-neutral-400 leading-relaxed max-w-md pt-2">
              {t.hero.subtitle} We combine advanced process engineering with operational excellence, digital OT/IT integration, and turnaround expertise across high-consequence industries.
            </p>

            <div className="flex items-center space-x-4 pt-2 text-xs font-mono text-neutral-300">
              <span className="flex items-center text-[#F97316]">
                <ShieldCheck className="w-4 h-4 mr-1.5" />
                ISO 9001 / ISO 45001 / SCCP CERTIFIED
              </span>
            </div>
          </div>

          {/* Col 2: Primary Services */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316] font-semibold">
              {"// SERVICES & CAPABILITIES"}
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => onNavigateSection('services')} className="hover:text-white transition-colors text-left">
                  Consulting & Engineering
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateSection('services')} className="hover:text-white transition-colors text-left">
                  Plant Construction & Skids
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateSection('services')} className="hover:text-white transition-colors text-left">
                  Prefabrication & Orbital Welding
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateSection('services')} className="hover:text-white transition-colors text-left">
                  Mechanical & Rotating Services
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateSection('services')} className="hover:text-white transition-colors text-left">
                  Electrical & Automation (ATEX)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateSection('services')} className="hover:text-white transition-colors text-left">
                  Turnarounds (TAR-EM)
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Sectors & Digital */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316] font-semibold">
              {"// SECTORS & SOLUTIONS"}
            </h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button onClick={() => onNavigateSection('industries')} className="hover:text-white transition-colors text-left">
                  Chemicals & Petrochemicals
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateSection('industries')} className="hover:text-white transition-colors text-left">
                  Pharma & Biopharma (cGMP)
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateSection('industries')} className="hover:text-white transition-colors text-left">
                  Energy & Hydrogen Networks
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateSection('digital')} className="hover:text-white transition-colors text-left">
                  Digital Industrial OT/IT
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateSection('sustainability')} className="hover:text-white transition-colors text-left">
                  Decarbonization & Heat Integration
                </button>
              </li>
              <li>
                <button onClick={() => onNavigateSection('careers')} className="hover:text-white transition-colors text-left">
                  Careers & Apprenticeships
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Locations & Language */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316] font-semibold">
              {"// GLOBAL HUBS & CONTACT"}
            </h4>
            <div className="text-xs space-y-2 text-neutral-400 font-mono">
              <p className="text-white font-semibold">Global HQ Mannheim [DE]</p>
              <p>Oskar-Meixner-Straße 1</p>
              <p>68163 Mannheim, Germany</p>
              <p className="flex items-center text-neutral-300 pt-1">
                <Phone className="w-3.5 h-3.5 text-[#F97316] mr-2" /> +49 621 6570-0
              </p>
              <p className="flex items-center text-neutral-300">
                <Mail className="w-3.5 h-3.5 text-[#F97316] mr-2" /> info@bilfinger-industrial.de
              </p>
            </div>

            <div className="pt-4 border-t border-white/5">
              <div className="text-xs font-mono text-neutral-400 mb-2">LANGUAGE PREFERENCE</div>
              <div className="inline-flex rounded border border-white/10 bg-[#1A1E23] p-1">
                <button
                  onClick={() => setLang('en')}
                  className={`px-3 py-1 font-mono text-xs rounded transition-colors ${
                    lang === 'en' ? 'bg-[#F97316] text-white font-bold' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  English
                </button>
                <button
                  onClick={() => setLang('de')}
                  className={`px-3 py-1 font-mono text-xs rounded transition-colors ${
                    lang === 'de' ? 'bg-[#F97316] text-white font-bold' : 'text-neutral-400 hover:text-white'
                  }`}
                >
                  Deutsch
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Legal Disclaimer & Compliance */}
        <div className="pt-8 pb-4 text-xs font-mono text-neutral-400 leading-relaxed border-b border-white/5 space-y-3">
          <p className="bg-white/5 p-3 rounded border border-white/10 text-neutral-300">
            <span className="text-[#F97316] font-bold uppercase mr-2">{"// LEGAL NOTICE & DISCLAIMER:"}</span>
            {t.footer.disclaimer} All synthetic case studies, process schematics, and demonstration data featured on this platform are for analytical illustration.
          </p>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-xs text-neutral-400 font-mono gap-4">
          <div>{t.footer.copyright}</div>

          <div className="flex items-center space-x-6">
            <button onClick={() => onNavigateSection('about')} className="hover:text-white transition-colors">
              {t.footer.imprint}
            </button>
            <button onClick={() => onNavigateSection('about')} className="hover:text-white transition-colors">
              {t.footer.privacy}
            </button>
            <button onClick={() => onNavigateSection('about')} className="hover:text-white transition-colors">
              {t.footer.security}
            </button>
            <button
              onClick={scrollToTop}
              className="p-2 bg-[#1A1E23] hover:bg-[#F97316] text-white rounded border border-white/10 transition-colors flex items-center space-x-1"
              aria-label="Scroll back to top"
            >
              <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
