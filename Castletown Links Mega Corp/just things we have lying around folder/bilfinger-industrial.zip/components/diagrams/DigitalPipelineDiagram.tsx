'use client';

import React, { useState } from 'react';
import { useTranslation } from '@/lib/i18n/LanguageContext';
import { digitalPipelineNodes, DigitalPipelineNode } from '@/lib/data/digitalData';
import { Factory, Radio, Database, Cpu, Lightbulb, GitMerge, CheckCircle, TrendingUp, ArrowRight, ShieldCheck, Server, Lock } from 'lucide-react';

export const DigitalPipelineDiagram: React.FC = () => {
  const { lang, t } = useTranslation();
  const [selectedNode, setSelectedNode] = useState<DigitalPipelineNode>(digitalPipelineNodes[0]);

  const getNodeIcon = (iconName: string) => {
    switch (iconName) {
      case 'Factory':
        return Factory;
      case 'Radio':
        return Radio;
      case 'Database':
        return Database;
      case 'Cpu':
        return Cpu;
      case 'Lightbulb':
        return Lightbulb;
      case 'GitMerge':
        return GitMerge;
      case 'CheckCircle':
        return CheckCircle;
      default:
        return TrendingUp;
    }
  };

  return (
    <section id="digital" className="py-20 bg-[#121518] text-white border-b border-[#2A3038] font-sans">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-12">
        {/* Section Header */}
        <div className="max-w-3xl space-y-3">
          <span className="text-xs font-mono text-[#F97316] uppercase tracking-widest font-semibold block">
            {"// OPERATIONAL OT/IT INTEGRATION"}
          </span>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase tracking-tight font-sans">
            {t.digital.title}
          </h2>
          <p className="text-neutral-300 text-base font-sans">
            {t.digital.subtitle}
          </p>
          <p className="text-xs font-mono text-[#F97316] pt-1 border-l-2 border-[#F97316] pl-3">
            {t.digital.tagline}
          </p>
        </div>

        {/* Pipeline Diagram Node Stepper */}
        <div className="bg-[#1A1E23] p-6 lg:p-8 border border-white/10 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/10 pb-4 gap-2">
            <div>
              <h3 className="text-lg font-bold uppercase tracking-wider text-white font-sans">
                {t.digital.diagramTitle}
              </h3>
              <p className="text-xs font-mono text-neutral-400">
                {t.digital.diagramSubtitle}
              </p>
            </div>
            <div className="flex items-center space-x-2 text-xs font-mono text-[#F97316]">
              <Lock className="w-3.5 h-3.5" />
              <span>IEC 62443 CYBERSECURITY ENCRYPTED</span>
            </div>
          </div>

          {/* Interactive Stepper Nodes Row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 relative">
            {digitalPipelineNodes.map((node, index) => {
              const isSelected = selectedNode.id === node.id;
              const NodeIcon = getNodeIcon(node.iconName);

              return (
                <button
                  key={node.id}
                  onClick={() => setSelectedNode(node)}
                  className={`p-3 text-left transition-all border flex flex-col justify-between group relative ${
                    isSelected
                      ? 'bg-[#F97316] text-white border-[#F97316] shadow-xl'
                      : 'bg-[#121518] text-neutral-300 border-white/10 hover:border-white/30 hover:bg-[#1A1E23]'
                  }`}
                  aria-label={`Select node ${node.stepNumber}: ${node.name[lang]}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className={`font-mono text-[10px] font-bold ${isSelected ? 'text-white' : 'text-[#F97316]'}`}>
                      {node.stepNumber}
                    </span>
                    <NodeIcon className="w-4 h-4" />
                  </div>

                  <div className="font-extrabold text-xs uppercase tracking-wider font-sans leading-tight">
                    {node.name[lang]}
                  </div>

                  {index < digitalPipelineNodes.length - 1 && (
                    <div className="hidden lg:block absolute -right-2 top-1/2 -translate-y-1/2 z-10 text-neutral-600">
                      →
                    </div>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Node Explanatory Panel */}
        <div className="bg-[#1A1E23] border border-[#2A3038] p-8 lg:p-10 space-y-8 shadow-2xl relative">
          <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-white/10 pb-6 gap-4">
            <div className="flex items-center space-x-4">
              <div className="p-3 bg-[#F97316] text-white">
                {React.createElement(getNodeIcon(selectedNode.iconName), { className: 'w-6 h-6' })}
              </div>
              <div>
                <span className="text-xs font-mono text-[#F97316] uppercase tracking-widest font-bold">
                  PIPELINE NODE — {selectedNode.stepNumber}
                </span>
                <h3 className="text-2xl sm:text-3xl font-extrabold uppercase tracking-wider text-white font-sans">
                  {selectedNode.name[lang]}
                </h3>
              </div>
            </div>

            <div className="flex items-center space-x-2 text-xs font-mono text-neutral-400 bg-[#121518] px-3 py-2 border border-white/10">
              <Server className="w-4 h-4 text-[#F97316]" />
              <span>COMMUNICATION LATENCY: &lt; 15ms</span>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Scope & Description */}
            <div className="lg:col-span-2 space-y-6">
              <p className="text-neutral-200 text-base leading-relaxed font-sans">
                {selectedNode.shortDesc[lang]}
              </p>

              <div className="space-y-3">
                <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316]">
                  {"// TECHNICAL ARCHITECTURE SPECIFICATION"}
                </h4>
                <p className="text-xs text-neutral-300 leading-relaxed font-mono bg-[#121518] p-4 border border-white/10">
                  {selectedNode.technicalSpecs[lang]}
                </p>
              </div>

              {/* Data Protocols Chips */}
              <div className="space-y-2">
                <h4 className="text-xs font-mono uppercase tracking-widest text-neutral-400">
                  {"// SUPPORTED INDUSTRIAL PROTOCOLS & STANDARDS:"}
                </h4>
                <div className="flex flex-wrap gap-2">
                  {selectedNode.dataProtocols.map((proto, i) => (
                    <span key={i} className="px-3 py-1 bg-white/5 text-neutral-200 text-xs font-mono border border-white/10">
                      {proto}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Sample Metrics Telemetry Box */}
            <div className="bg-[#121518] p-6 border border-white/10 space-y-4">
              <h4 className="text-xs font-mono uppercase tracking-widest text-[#F97316] font-bold">
                {"// REAL-TIME TELEMETRY BENCHMARKS"}
              </h4>
              <div className="space-y-4 font-mono">
                {selectedNode.sampleMetrics.map((sm, i) => (
                  <div key={i} className="p-3 bg-[#1A1E23] border border-white/5">
                    <span className="text-xs text-neutral-400 uppercase block mb-1">{sm.label[lang]}</span>
                    <span className="text-xl font-bold text-white">{sm.value}</span>
                  </div>
                ))}
              </div>

              <div className="pt-4 border-t border-white/10 text-[11px] font-mono text-neutral-500">
                Connected to Bilfinger Industrial Edge OT Data Engine.
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
