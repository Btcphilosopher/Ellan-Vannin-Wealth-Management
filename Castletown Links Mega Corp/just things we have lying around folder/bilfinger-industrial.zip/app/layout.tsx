import type { Metadata } from 'next';
import './globals.css';
import { LanguageProvider } from '@/lib/i18n/LanguageContext';

export const metadata: Metadata = {
  title: 'Bilfinger INDUSTRIAL — European Process Engineering & Industrial Services',
  description: 'Official bilingual web platform for Bilfinger INDUSTRIAL. Providing engineering, plant construction, prefabrication, maintenance, digital OT/IT solutions, turnarounds, and decarbonization.',
  openGraph: {
    title: 'Bilfinger INDUSTRIAL — European Process Engineering & Industrial Services',
    description: 'Official bilingual web platform for Bilfinger INDUSTRIAL. Providing engineering, plant construction, prefabrication, maintenance, digital OT/IT solutions, turnarounds, and decarbonization.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Bilfinger INDUSTRIAL — European Process Engineering & Industrial Services',
    description: 'Official bilingual web platform for Bilfinger INDUSTRIAL.',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <body suppressHydrationWarning className="bg-[#121518] text-white antialiased font-sans selection:bg-[#F97316] selection:text-white">
        <LanguageProvider>
          {children}
        </LanguageProvider>
      </body>
    </html>
  );
}

