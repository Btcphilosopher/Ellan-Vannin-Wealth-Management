'use client';

import React, { useState } from 'react';
import { SiteHeader } from '@/components/navigation/SiteHeader';
import { HeroSection } from '@/components/hero/HeroSection';
import { IndustrialPerformanceSection } from '@/components/sections/IndustrialPerformanceSection';
import { ServiceExplorer } from '@/components/sections/ServiceExplorer';
import { IndustrySelector } from '@/components/sections/IndustrySelector';
import { ProjectExplorer } from '@/components/sections/ProjectExplorer';
import { DigitalPipelineDiagram } from '@/components/diagrams/DigitalPipelineDiagram';
import { SustainabilityScenarioTool } from '@/components/sections/SustainabilityScenarioTool';
import { AboutSection } from '@/components/sections/AboutSection';
import { CareersSection } from '@/components/sections/CareersSection';
import { ContactWorkflow } from '@/components/forms/ContactWorkflow';
import { Footer } from '@/components/navigation/Footer';
import { SearchOverlay } from '@/components/search/SearchOverlay';

export default function HomePage() {
  const [searchOpen, setSearchOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [contactSubject, setContactSubject] = useState<string>('');

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const elem = document.getElementById(sectionId);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleDiscussChallenge = (subject?: string) => {
    if (subject) {
      setContactSubject(subject);
    }
    scrollToSection('contact');
  };

  const handleSelectSearchResult = (url: string) => {
    // Check if url contains a hash or query section
    if (url.includes('?id=')) {
      const parts = url.split('?id=');
      const sectionPath = parts[0].replace('/', '');
      if (sectionPath) {
        scrollToSection(sectionPath);
      }
    } else {
      const sectionPath = url.replace('/', '');
      if (sectionPath) {
        scrollToSection(sectionPath);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#121518] text-white font-sans selection:bg-[#F97316] selection:text-white flex flex-col justify-between relative">
      {/* Site Header */}
      <SiteHeader
        onOpenSearch={() => setSearchOpen(true)}
        activeSection={activeSection}
        setActiveSection={setActiveSection}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Section 0: Hero Section */}
        <div id="home">
          <HeroSection
            onExploreServices={() => scrollToSection('services')}
            onDiscussChallenge={() => handleDiscussChallenge('General Industrial Feasibility Study')}
          />
        </div>

        {/* Section 1: Industrial Performance Overview (Section A) */}
        <IndustrialPerformanceSection />

        {/* Section 2: Complete 14 Service Categories (Section B) */}
        <ServiceExplorer
          onSelectService={(id) => scrollToSection('services')}
          onOpenProject={(projectTitle) => scrollToSection('projects')}
        />

        {/* Section 3: 6 Industry Sectors (Section C) */}
        <IndustrySelector
          onDiscussChallenge={() => handleDiscussChallenge('Sector Specific Optimization')}
        />

        {/* Section 4: Interactive Project Explorer (Section 6) */}
        <ProjectExplorer />

        {/* Section 5: Digital Industrial Solutions & OT/IT Diagram (Section 7) */}
        <DigitalPipelineDiagram />

        {/* Section 6: Sustainability & Facility Simulator (Section 8) */}
        <SustainabilityScenarioTool />

        {/* Section 7: About, History, Leadership, Locations (Section 9) */}
        <AboutSection />

        {/* Section 8: Careers & Demo Application (Section 10) */}
        <CareersSection />

        {/* Section 9: Multi-Step Contact Workflow (Section 11) */}
        <ContactWorkflow initialSubject={contactSubject} />
      </main>

      {/* Footer */}
      <Footer onNavigateSection={scrollToSection} />

      {/* Search Overlay Command Palette Modal */}
      <SearchOverlay
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        onSelectResult={handleSelectSearchResult}
      />
    </div>
  );
}
