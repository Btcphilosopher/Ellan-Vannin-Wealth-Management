import { servicesData } from './servicesData';
import { industriesData } from './industriesData';
import { projectsData } from './projectsData';
import { careersData } from './careersData';
import { globalLocations } from './companyData';

export interface SearchResultItem {
  id: string;
  category: 'Service' | 'Industry' | 'Project' | 'Career' | 'Location' | 'Glossary';
  title: { en: string; de: string };
  snippet: { en: string; de: string };
  url: string;
  keywords: string[];
}

export const glossaryItems: SearchResultItem[] = [
  {
    id: 'glossary-feed',
    category: 'Glossary',
    title: { en: 'Front-End Engineering Design (FEED)', de: 'Front-End Engineering Design (FEED)' },
    snippet: { en: 'Basic engineering conducted after conceptual feasibility to define technical scope, preliminary P&ID, and capex estimates.', de: 'Grundlegendes Engineering nach der Machbarkeit zur Festlegung von Scope, R&I-Fließschemata und Capex-Schätzungen.' },
    url: '/services?id=consulting-engineering',
    keywords: ['feed', 'engineering', 'capex', 'p&id', 'design', 'machbarkeit'],
  },
  {
    id: 'glossary-bmc',
    category: 'Glossary',
    title: { en: 'Bilfinger Maintenance Concept (BMC)', de: 'Bilfinger Maintenance Concept (BMC)' },
    snippet: { en: 'Standardized comprehensive maintenance framework combining risk-based inspection, CMMS digital work orders, and reliability engineering.', de: 'Standardisiertes Instandhaltungskonzept zur risikobasierten Inspektion und OEE-Steigerung.' },
    url: '/services?id=maintenance',
    keywords: ['bmc', 'maintenance', 'instandhaltung', 'oee', 'cmms', 'sap pm'],
  },
  {
    id: 'glossary-atex',
    category: 'Glossary',
    title: { en: 'ATEX Explosion Protection', de: 'ATEX Explosionsschutz' },
    snippet: { en: 'European Union directive governing equipment and protective systems intended for use in potentially explosive atmospheres.', de: 'EU-Richtlinie für Geräte und Schutzsysteme in explosionsgefährdeten Bereichen.' },
    url: '/services?id=electrical-automation',
    keywords: ['atex', 'explosion', 'explosionsschutz', 'zone 0', 'zone 1', 'hazardous'],
  },
  {
    id: 'glossary-wfi',
    category: 'Glossary',
    title: { en: 'Water-for-Injection (WFI)', de: 'Wasser für Injektionszwecke (WFI)' },
    snippet: { en: 'Ultra-pure water meeting strict cGMP conductivity, TOC, and bio-burden limits for biopharmaceutical manufacturing.', de: 'Ultra-reines Wasser nach cGMP-Standards für die pharmazeutische Produktion.' },
    url: '/services?id=prefabrication-installation',
    keywords: ['wfi', 'cgmp', 'pharma', 'cleanroom', 'reinraum', 'orbital welding'],
  },
];

export function getFullSearchIndex(): SearchResultItem[] {
  const results: SearchResultItem[] = [];

  // 1. Services
  servicesData.forEach((s) => {
    results.push({
      id: `service-${s.id}`,
      category: 'Service',
      title: s.name,
      snippet: s.shortDesc,
      url: `/services?id=${s.id}`,
      keywords: [s.number, ...s.name.en.toLowerCase().split(' '), ...s.name.de.toLowerCase().split(' '), ...s.relatedIndustries.map((i) => i.toLowerCase())],
    });
  });

  // 2. Industries
  industriesData.forEach((ind) => {
    results.push({
      id: `industry-${ind.id}`,
      category: 'Industry',
      title: ind.name,
      snippet: ind.tagline,
      url: `/industries?id=${ind.id}`,
      keywords: [...ind.name.en.toLowerCase().split(' '), ...ind.name.de.toLowerCase().split(' ')],
    });
  });

  // 3. Projects
  projectsData.forEach((p) => {
    results.push({
      id: `project-${p.id}`,
      category: 'Project',
      title: p.title,
      snippet: p.summary,
      url: `/projects?id=${p.id}`,
      keywords: [p.number, p.industry.toLowerCase(), p.service.toLowerCase(), ...p.disciplines.map((d) => d.toLowerCase())],
    });
  });

  // 4. Careers
  careersData.forEach((c) => {
    results.push({
      id: `career-${c.id}`,
      category: 'Career',
      title: c.title,
      snippet: c.description,
      url: `/careers?id=${c.id}`,
      keywords: [c.country.toLowerCase(), c.location.toLowerCase(), c.department.en.toLowerCase()],
    });
  });

  // 5. Locations
  globalLocations.forEach((loc) => {
    results.push({
      id: `location-${loc.id}`,
      category: 'Location',
      title: { en: `${loc.city} Hub (${loc.country})`, de: `${loc.city} Standort (${loc.country})` },
      snippet: loc.hubType,
      url: `/locations?id=${loc.id}`,
      keywords: [loc.city.toLowerCase(), loc.country.toLowerCase(), ...loc.specializations.map((sp) => sp.toLowerCase())],
    });
  });

  // 6. Glossary
  results.push(...glossaryItems);

  return results;
}
