export interface JobPosting {
  id: string;
  title: { en: string; de: string };
  department: { en: string; de: string };
  country: string;
  location: string;
  workModel: 'On-site' | 'Hybrid' | 'Fly-in Fly-out';
  experienceLevel: { en: string; de: string };
  description: { en: string; de: string };
  responsibilities: { en: string[]; de: string[] };
  qualifications: { en: string[]; de: string[] };
  postedDate: string;
}

export const careersData: JobPosting[] = [
  {
    id: 'lead-process-engineer-h2',
    title: {
      en: 'Senior Lead Process Engineer — Hydrogen & Clean Fuels',
      de: 'Senior Lead Prozessingenieur — Wasserstoff & Grüne Kraftstoffe',
    },
    department: { en: 'Consulting & Engineering', de: 'Consulting & Engineering' },
    country: 'Germany',
    location: 'Frankfurt / Mannheim Hub',
    workModel: 'Hybrid',
    experienceLevel: { en: 'Senior (7+ Years)', de: 'Senior (7+ Jahre)' },
    description: {
      en: 'Lead front-end engineering design (FEED) for industrial scale hydrogen electrolyzer balance of plant and ammonia cracking facilities across Western Europe.',
      de: 'Leitung des Front-End Engineering Designs (FEED) für industrielle Wasserstoff-Elektrolyseanlagen und Ammoniak-Crack-Anlagen in Westeuropa.',
    },
    responsibilities: {
      en: [
        'Perform process thermodynamic simulations using ASPEN Plus and HYSYS',
        'Lead HAZOP and SIL classification workshops with client safety leads',
        'Review PFDs, P&IDs, equipment datasheets, and piping material specs',
        'Mentor junior process engineers and coordinate multidisciplinary engineering packages',
      ],
      de: [
        'Thermodynamische Prozesssimulationen mit ASPEN Plus und HYSYS durchführen',
        'Leitung von HAZOP- und SIL-Klassifizierungsworkshops mit Sicherheitsexperten',
        'Prüfung von R&I-Fließschemata, Apparatedatenblättern und Rohrleistungsspezifikationen',
        'Mentoring von Nachwuchsingenieuren und Koordination interdisziplinärer Pakete',
      ],
    },
    qualifications: {
      en: [
        'M.Sc. in Chemical Engineering, Process Technology, or Thermal Power Engineering',
        '5+ years experience in gas processing, refining, or hydrogen production systems',
        'Fluent in German and English (C1 level requirement)',
      ],
      de: [
        'Master / Dipl.-Ing. Chemieingenieurwesen, Verfahrenstechnik oder Energietechnik',
        '5+ Jahre Erfahrung in Gasaufbereitung, Raffinerietechnik oder H2-Erzeugung',
        'Verhandlungssichere Deutsch- und Englischkenntnisse (C1 Niveau)',
      ],
    },
    postedDate: '2026-03-12',
  },
  {
    id: 'turnaround-construction-manager',
    title: {
      en: 'Turnaround Construction Manager — Petrochemicals',
      de: 'Bauleiter Turnaround & Stillstandsmanagement — Petrochemie',
    },
    department: { en: 'Turnarounds & Plant Construction', de: 'Anlagenstillstände & Anlagenbau' },
    country: 'Netherlands',
    location: 'Rotterdam Mainport',
    workModel: 'On-site',
    experienceLevel: { en: 'Executive / Lead (10+ Years)', de: 'Führungskraft (10+ Jahre)' },
    description: {
      en: 'Direct field execution of major cracker and chemical refinery turnarounds, overseeing up to 800 craft specialists and multi-discipline subcontractors.',
      de: 'Operative Gesamtleitung von Großstillständen in Raffinerien und Chemieparks mit Führungsverantwortung für bis zu 800 Fachkräfte und Nachunternehmer.',
    },
    responsibilities: {
      en: [
        'Manage critical-path turnaround daily execution using Primavera P6 and RFID site control',
        'Enforce zero-incident HSEQ protocols across all mechanical, piping, and scaffolding scopes',
        'Control daily burn rates, scope changes, and field progress sign-offs',
      ],
      de: [
        'Steuerung der Kritischen-Pfad-Stillstandsabwicklung mit Primavera P6 und RFID-Systemen',
        'Durchsetzung höchster HSEQ-Protokolle über alle Mechanik-, Rohr- und Gerüstgewerke',
        'Kostenkontrolle, Nachtragsmanagement und tägliche Baufortschrittsfreigaben',
      ],
    },
    qualifications: {
      en: [
        'Degree in Mechanical Engineering or extensive master craft certified site leadership experience',
        'Proven track record delivering major European refinery turnarounds on schedule',
        'SCCP / VCA Executive Safety Certification',
      ],
      de: [
        'Ingenieurstudium Maschinenbau oder Meister/Techniker mit langjähriger Baustellenerfahrung',
        'Nachweisbare Erfolge bei der termingerechten Abwicklung europäischer Großstillstände',
        'SCCP / VCA Führungs-Sicherheitszertifizierung',
      ],
    },
    postedDate: '2026-03-15',
  },
  {
    id: 'ot-cybersecurity-automation-specialist',
    title: {
      en: 'OT/IT Cybersecurity & Automation Specialist',
      de: 'Spezialist OT/IT-Cybersicherheit & Automatisierung',
    },
    department: { en: 'Digital Industrial Solutions', de: 'Digitale Industrielösungen' },
    country: 'Austria',
    location: 'Vienna / Linz Hub',
    workModel: 'Hybrid',
    experienceLevel: { en: 'Mid-Senior (4+ Years)', de: 'Erfahren (4+ Jahre)' },
    description: {
      en: 'Design and deploy IEC 62443 certified OT network architectures, edge telemetry gateways, and DCS firewall isolation for biopharma and chemical facilities.',
      de: 'Konzeption und Implementierung IEC 62443 zertifizierter OT-Netzwerkarchitekturen, Edge-Gateways und PLS-Firewalls für Biopharma und Chemie.',
    },
    responsibilities: {
      en: [
        'Audit industrial control systems (DCS/PLC) for security vulnerabilities and IEC 62443 compliance',
        'Deploy OPC UA security profiles and encrypted MQTT edge transmission pipelines',
        'Conduct threat response drills and patch management for mission-critical plant networks',
      ],
      de: [
        'Auditing industrieller Steuerungs- & Leitsysteme auf IEC 62443 Konformität',
        'Rollout von OPC UA Sicherheits-Profilen und verschlüsselten MQTT-Pipelines',
        'Durchführung von Cyber-Threat-Response Übungen und Patch-Management in Leitsystemen',
      ],
    },
    qualifications: {
      en: [
        'B.Sc. in Automation Engineering, Electrical Engineering, or Cybersecurity',
        'Experience with Siemens PCS7, ABB 800xA, or Emerson DeltaV architectures',
        'GICSP or IEC 62443 Cybersecurity Specialist Certification',
      ],
      de: [
        'Bachelor / Master Automatisierungstechnik, Elektrotechnik oder IT-Sicherheit',
        'Erfahrung mit Siemens PCS7, ABB 800xA oder Emerson DeltaV Systemen',
        'GICSP oder IEC 62443 Cybersicherheits-Zertifizierung',
      ],
    },
    postedDate: '2026-03-18',
  },
  {
    id: 'piping-orbital-welding-inspector',
    title: {
      en: 'High-Purity Piping & Orbital Welding Inspector',
      de: 'Inspektor Hochreine Rohrleitungssysteme & Orbitalschweißen',
    },
    department: { en: 'Prefabrication & Installation', de: 'Vorfertigung & Installation' },
    country: 'Switzerland',
    location: 'Basel / Zurich',
    workModel: 'On-site',
    experienceLevel: { en: 'Mid-Level (3+ Years)', de: 'Mittleres Niveau (3+ Jahre)' },
    description: {
      en: 'Inspect and certify high-purity stainless steel piping loops (WFI / Clean Steam) for biopharmaceutical cleanroom construction.',
      de: 'Prüfung und Zertifizierung hochreiner Edelstahl-Rohrleitungen (WFI / Reindampf) für den biopharmazeutischen Reinraumbau.',
    },
    responsibilities: {
      en: [
        'Perform video-borescope internal weld inspections and surface roughness Ra checks',
        'Verify welding logs, argon backing gas purity, and material certificates (EN 10204 3.1)',
        'Compile cGMP turnover packages (DQ/IQ/OQ) for regulatory submission',
      ],
      de: [
        'Durchführung von Endoskopie-Schweißnahtprüfungen und Rauheitsmessungen (Ra)',
        'Überprüfung von Schweißprotokollen, Formiergasreinheit und Werkstoffzeugnissen (3.1)',
        'Erstellung von cGMP-Übergabedokumentationen (DQ/IQ/OQ)',
      ],
    },
    qualifications: {
      en: [
        'Certified International Welding Inspector (IWI) or VT Level 2 Certification',
        'Minimum 3 years experience in pharmaceutical clean utility installation',
        'German & English working proficiency',
      ],
      de: [
        'Zertifizierter Internationaler Schweißfachmann / Schweißinspektor oder VT2',
        'Mindestens 3 Jahre Erfahrung im pharmagerechten Rohrleitungsbau',
        'Gute Deutsch- und Englischkenntnisse',
      ],
    },
    postedDate: '2026-03-19',
  },
];
