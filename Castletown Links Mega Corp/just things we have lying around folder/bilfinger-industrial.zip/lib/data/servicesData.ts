export interface ServiceItem {
  id: string;
  number: string;
  name: { en: string; de: string };
  shortDesc: { en: string; de: string };
  fullScope: { en: string; de: string };
  keyDeliverables: { en: string[]; de: string[] };
  relatedIndustries: string[];
  syntheticProjectRef: string;
  iconName: string;
  technicalSpecs: { en: string; de: string };
}

export const servicesData: ServiceItem[] = [
  {
    id: 'consulting-engineering',
    number: '01',
    name: {
      en: 'Consulting & Engineering',
      de: 'Consulting & Engineering',
    },
    shortDesc: {
      en: 'Feasibility studies, front-end engineering design (FEED), process simulation, and safety concepts for chemical and energy installations.',
      de: 'Machbarkeitsstudien, Front-End Engineering Design (FEED), Prozesssimulation und Sicherheitskonzepte für Chemie- und Energieanlagen.',
    },
    fullScope: {
      en: 'Our multidisciplinary engineering teams deliver early-stage conceptual studies, 3D laser scan modeling, hydraulic process optimization, and HAZOP safety compliance to de-risk capital investment and optimize lifecycle capex.',
      de: 'Unsere multidisziplinären Ingenieurteams liefern bereits in der Frühphase Konzeptstudien, 3D-Laserscan-Modellierungen, hydraulische Prozessoptimierungen und HAZOP-Sicherheitsanalysen zur Risikominimierung.',
    },
    keyDeliverables: {
      en: ['Process Flow Diagrams (PFD) & P&IDs', 'Basic & Detail Engineering Packages', 'HAZOP & SIL Functional Safety Audits', 'Capex & Opex Lifecycle Estimations'],
      de: ['Verfahrensfließbilder (PFD) & R&I-Fließschemata', 'Basic- & Detail-Engineering-Pakete', 'HAZOP & SIL Funktionaler Sicherheitssicherungs-Audit', 'Capex & Opex Lebenszyklus-Kostenberechnungen'],
    },
    relatedIndustries: ['Chemicals & Petrochemicals', 'Pharma & Biopharma', 'Energy', 'Oil & Gas'],
    syntheticProjectRef: 'Project 01 — Hydrogen Integration Facility',
    iconName: 'Compass',
    technicalSpecs: {
      en: 'ASME B31.3 / EN 13480 compliant CAD modeling; ASPEN Plus thermodynamics software.',
      de: 'ASME B31.3 / EN 13480 konformes CAD-Modellieren; ASPEN Plus Thermodynamik-Software.',
    },
  },
  {
    id: 'project-management',
    number: '02',
    name: {
      en: 'Project Management',
      de: 'Projektmanagement',
    },
    shortDesc: {
      en: 'EPCM execution, procurement management, field construction oversight, and commissioning control.',
      de: 'EPCM-Abwicklung, Beschaffungsmanagement, Bauüberwachung und Inbetriebnahme-Steuerung.',
    },
    fullScope: {
      en: 'Structured program management ensuring schedule adherence, stringent HSEQ compliance, risk mitigation, and seamless handovers for mega-industrial brownfield and greenfield builds.',
      de: 'Strukturiertes Programm-Management zur Sicherstellung von Termintreue, strenger HSEQ-Einhaltung und nahtlosen Übergaben bei Großprojekten.',
    },
    keyDeliverables: {
      en: ['EPCM Prime Contracting', 'Stage-Gate Governance & Earned Value Management', 'Vendor & Subcontractor Procurement', 'Commissioning & Ramp-up Qualification'],
      de: ['EPCM-Generalunternehmerschaft', 'Stage-Gate Governance & Earned Value Management', 'Lieferanten- & Nachunternehmerbeschaffung', 'Inbetriebnahme & Qualifizierung'],
    },
    relatedIndustries: ['Energy', 'Chemicals & Petrochemicals', 'Utilities', 'Industrial Manufacturing'],
    syntheticProjectRef: 'Project 02 — Pharmaceutical Utility Expansion',
    iconName: 'Layers',
    technicalSpecs: {
      en: 'Primavera P6 & SAP S/4HANA integrated milestone tracking with real-time field reporting.',
      de: 'Primavera P6 & SAP S/4HANA integriertes Meilenstein-Tracking mit Echtzeit-Feldberichten.',
    },
  },
  {
    id: 'plant-construction',
    number: '03',
    name: {
      en: 'Plant Construction',
      de: 'Anlagenbau',
    },
    shortDesc: {
      en: 'Erection of heavy process equipment, pressure vessels, modular skid construction, and structural steelwork.',
      de: 'Errichtung von schwerem Prozessapparaterecht, Druckbehältern, modularem Skid-Bau und Stahlbau.',
    },
    fullScope: {
      en: 'Turnkey erection of high-pressure process units, columns, reactors, and high-purity utility systems using precision heavy-rigging and advanced welding technology.',
      de: 'Schlüsselfertige Montage von Hochdruckprozessanlagen, Kolonnen, Reaktoren und hochreinen Versorgungssystemen mit Präzisions-Schwerlastlogistik.',
    },
    keyDeliverables: {
      en: ['Heavy Lift Crane Logistics', 'Modular Skid Fabrication & Onsite Placement', 'High-Pressure Vessel Assembly', 'Structural Steel Framing & Foundations'],
      de: ['Schwerlast-Kranlogistik', 'Modulare Skid-Fertigung & Vor-Ort-Platzierung', 'Hochdruckbehälter-Montage', 'Stahltragwerksbau & Fundamentierung'],
    },
    relatedIndustries: ['Chemicals & Petrochemicals', 'Oil & Gas', 'Energy'],
    syntheticProjectRef: 'Project 03 — Chemical Plant Efficiency Programme',
    iconName: 'Factory',
    technicalSpecs: {
      en: 'EN 1090 structural steel execution class EXC4; EN ISO 3834-2 welding quality management.',
      de: 'EN 1090 Stahltragwerke Ausführungsklasse EXC4; EN ISO 3834-2 Schweißqualitätsmanagement.',
    },
  },
  {
    id: 'prefabrication-installation',
    number: '04',
    name: {
      en: 'Prefabrication & Installation',
      de: 'Vorfertigung & Installation',
    },
    shortDesc: {
      en: 'Offsite high-accuracy piping spool fabrication, automated orbital welding, and rapid site installation.',
      de: 'Offsite Präzisions-Rohrleitungsvorfertigung, automatisiertes Orbitalschweißen und zügige Baustellenmontage.',
    },
    fullScope: {
      en: 'State-of-the-art workshop prefabrication of alloy, stainless steel, and carbon steel pipe spools minimizing site congestion, reducing hot-work hazards, and accelerating plant tie-in schedules.',
      de: 'Hochmoderne Werkstattvorfertigung von Legierungs-, Edelstahl- und C-Stahl-Rohrspool-Systemen zur Reduzierung von Baustellenrisiken und Beschleunigung von Einbinde-Terminen.',
    },
    keyDeliverables: {
      en: ['Orbital TIG & SAW Welding Spools', 'Non-Destructive Testing (NDT / Radiography)', 'Pickling & Passivation Cleanliness Control', 'Tight Tolerance Spool Site Erection'],
      de: ['Orbital-WIG- & UP-Schweißspools', 'Zerstörungsfreie Werkstoffprüfung (ZfP / Radiographie)', 'Beizen & Passivieren', 'Toleranzgenaue Baustellenmontage'],
    },
    relatedIndustries: ['Pharma & Biopharma', 'Chemicals & Petrochemicals', 'Energy'],
    syntheticProjectRef: 'Project 01 — Hydrogen Integration Facility',
    iconName: 'Wrench',
    technicalSpecs: {
      en: 'ISO 5817 Level B weld quality; ASME IX certified welding procedure specifications.',
      de: 'ISO 5817 Bewertungsgruppe B Schweißnahtqualität; ASME IX zertifizierte Schweißverfahren.',
    },
  },
  {
    id: 'mechanical-services',
    number: '05',
    name: {
      en: 'Mechanical Services',
      de: 'Mechanische Dienstleistungen',
    },
    shortDesc: {
      en: 'Overhaul of turbomachinery, pumps, compressors, valves, heat exchangers, and rotating equipment.',
      de: 'Überholung von Turbomaschinen, Pumpen, Verdichtern, Armaturen, Wärmetauschern und rotierenden Anlagenteilen.',
    },
    fullScope: {
      en: 'Comprehensive mechanical maintenance, laser alignment, dynamic balancing, dynamic sealing retrofits, and valve certification for continuous-process facilities.',
      de: 'Umfassende mechanische Instandhaltung, Laser-Ausrichtung, dynamisches Auswuchten, Dichtungs-Retrofits und Armaturen-Zertifizierung.',
    },
    keyDeliverables: {
      en: ['Compressor & Turbine Rotor Overhauls', 'Laser Shaft Alignment & Vibration Analysis', 'Valve Hydro-testing & Safety Valve Calibration', 'Heat Exchanger Retubing & Hydro-cleaning'],
      de: ['Kompressor- & Turbinenläufer-Überholungen', 'Laser-Wellenausrichtung & Schwingungsanalyse', 'Sicherheitsventil-Kalibrierung & Hydrotest', 'Wärmetauscher-Neubewicklung'],
    },
    relatedIndustries: ['Oil & Gas', 'Chemicals & Petrochemicals', 'Utilities', 'Industrial Manufacturing'],
    syntheticProjectRef: 'Project 04 — Industrial Maintenance Transformation',
    iconName: 'Settings',
    technicalSpecs: {
      en: 'API 610 centrifugal pump compliance; ISO 10816 vibration severity standards.',
      de: 'API 610 Zentrifugalpumpen-Standard; ISO 10816 Schwingungsbewertungsnormen.',
    },
  },
  {
    id: 'electrical-automation',
    number: '06',
    name: {
      en: 'Electrical & Automation',
      de: 'Elektrotechnik & Automatisierung',
    },
    shortDesc: {
      en: 'Instrumentation, DCS/PLC programming, SCADA architecture, low/medium voltage distribution, and ATEX explosion protection.',
      de: 'MSR-Technik, PLS/SPS-Programmierung, SCADA-Architektur, Mittelspannungsschaltanlagen und ATEX-Explosionsschutz.',
    },
    fullScope: {
      en: 'Integrated electrical power engineering, safety instrumented system (SIS) implementation, field bus wiring, and smart sensor integration for autonomous industrial control.',
      de: 'Integrierte Elektrotechnik, sicherheitsgerichtete Steuerungen (SIS), Feldbus-Verdrahtung und smarte Sensortintegration für autonome Anlagensteuerung.',
    },
    keyDeliverables: {
      en: ['DCS / PLC Logic Architecture (Siemens / ABB / Emerson)', 'ATEX / IECEx Hazardous Area Certification', 'Low & Medium Voltage Switchgear Engineering', 'Smart Field Instrumentation Calibration'],
      de: ['PLS / SPS-Logikarchitektur (Siemens / ABB / Emerson)', 'ATEX / IECEx Explosionsschutz-Zertifizierung', 'Niederspannungs- & Mittelspannungsschaltanlagen', 'Kalibrierung intelligenter Feldmesstechnik'],
    },
    relatedIndustries: ['Energy', 'Pharma & Biopharma', 'Chemicals & Petrochemicals', 'Utilities'],
    syntheticProjectRef: 'Project 02 — Pharmaceutical Utility Expansion',
    iconName: 'Cpu',
    technicalSpecs: {
      en: 'IEC 61508 / IEC 61511 Functional Safety SIL-3 compliance; IEC 61850 substation automation.',
      de: 'IEC 61508 / IEC 61511 Funktionaler Sicherheit SIL-3 Standard; IEC 61850 Schaltanlagenautomatisierung.',
    },
  },
  {
    id: 'access-solutions',
    number: '07',
    name: {
      en: 'Access Solutions',
      de: 'Zugangslösungen',
    },
    shortDesc: {
      en: 'Engineered industrial scaffolding, rope access techniques, mobile platforms, and safety enclosures.',
      de: 'Ingenieurmäßiger Gerüstbau, Seilzugangstechnik, mobile Arbeitsbühnen und Schutzeinhausungen.',
    },
    fullScope: {
      en: 'Rapid-erection modular system scaffolding and certified industrial rope access teams delivering safe work platforms inside complex boiler interiors, columns, and high-elevation structures during turnarounds.',
      de: 'Schnellmontage-Systemgerüste und zertifizierte Höhenarbeitsteams für sichere Arbeitsplattformen in komplexen Kesselinnenräumen und hohen Kolonnen.',
    },
    keyDeliverables: {
      en: ['3D Scaffolding Load-Calculation Modeling', 'Heavy-Duty Cantilever & Suspended Platforms', 'IRATA Certified Rope Access Services', 'Weatherproof Environmental Protection Shells'],
      de: ['3D-Gerüstbau-Statikberechnung', 'Schwerlast-Kragerüste & Hängegerüste', 'IRATA zertifizierte Seilzugangstechnik', 'Wetterfeste Schutzeinhausungen'],
    },
    relatedIndustries: ['Chemicals & Petrochemicals', 'Oil & Gas', 'Energy', 'Industrial Manufacturing'],
    syntheticProjectRef: 'Project 04 — Industrial Maintenance Transformation',
    iconName: 'Grid',
    technicalSpecs: {
      en: 'EN 12810 / EN 12811 system scaffolding standards; DIN 4420 compliance.',
      de: 'EN 12810 / EN 12811 Systemgerüstbau-Normen; DIN 4420 Einhaltung.',
    },
  },
  {
    id: 'insulation',
    number: '08',
    name: {
      en: 'Insulation',
      de: 'Isoliertechnik',
    },
    shortDesc: {
      en: 'Thermal, cryogenic, and acoustic insulation solutions to reduce heat loss, prevent CUI, and lower plant emissions.',
      de: 'Wärme-, Kälte- und Schallschutzisolierungen zur Minimierung von Wärmeverlusten, CUI-Vermeidung und Emissionsminderung.',
    },
    fullScope: {
      en: 'High-performance insulation cladding, aerogel systems, and corrosion-under-insulation (CUI) prevention treatments for high-temperature steam networks and liquefied gas vessels.',
      de: 'Hochleistungs-Isolierverkleidungen, Aerogel-Systeme und Korrosionsschutz unter Isolierung (CUI) für Hochtemperatur-Dampfnetze und Flüssiggasbehälter.',
    },
    keyDeliverables: {
      en: ['High-Temperature Thermal Barrier Cladding', 'Cryogenic LNG Pipe Insulation (Aerogel / PIR)', 'Corrosion Under Insulation (CUI) Audits & Coatings', 'Acoustic Enclosures for Turbines & Blowers'],
      de: ['Hochtemperatur-Thermoschutzverkleidungen', 'Kryogene LNG-Isolierung (Aerogel / PIR)', 'CUI-Korrosionsaudits & Schutzbeschichtungen', 'Schallschutzkapseln für Turbinen'],
    },
    relatedIndustries: ['Energy', 'Chemicals & Petrochemicals', 'Oil & Gas', 'Pharma & Biopharma'],
    syntheticProjectRef: 'Project 03 — Chemical Plant Efficiency Programme',
    iconName: 'Shield',
    technicalSpecs: {
      en: 'AGI Q 05 / VDI 2055 thermal calculation methodology; CUI risk matrix standards.',
      de: 'AGI Q 05 / VDI 2055 Wärmeberechnungsmethodik; CUI-Risikomatrix-Normen.',
    },
  },
  {
    id: 'maintenance',
    number: '09',
    name: {
      en: 'Maintenance',
      de: 'Instandhaltung',
    },
    shortDesc: {
      en: 'Routine, preventive, and contract maintenance services ensuring total facility uptime and asset integrity.',
      de: 'Laufende, präventive und vertragliche Instandhaltung für maximale Anlagenverfügbarkeit und Substanzerhaltung.',
    },
    fullScope: {
      en: 'Integrated maintenance partnerships (BMC / Bilfinger Maintenance Concept) utilizing computerized maintenance management systems (CMMS), mobile work orders, and resident maintenance crews.',
      de: 'Integrierte Instandhaltungspartnerschaften (BMC) mit computergestützten CMMS-Systemen, mobilen Aufträgen und festen Vor-Ort-Teams.',
    },
    keyDeliverables: {
      en: ['Comprehensive Resident Crew Maintenance', 'Preventive Maintenance Execution & CMMS Logging', 'Condition Monitoring & Thermography Audits', 'Spare Parts Logistics & Inventory Optimization'],
      de: ['Umfassende Partner-Instandhaltung mit Vor-Ort-Crew', 'Präventive Wartung & CMMS-Protokollierung', 'Schwingungs- & Thermographie-Audits', 'Ersatzteillogistik & Lageroptimierung'],
    },
    relatedIndustries: ['Industrial Manufacturing', 'Chemicals & Petrochemicals', 'Utilities', 'Energy'],
    syntheticProjectRef: 'Project 04 — Industrial Maintenance Transformation',
    iconName: 'Activity',
    technicalSpecs: {
      en: 'DIN EN 13306 maintenance terminology standard; Reliability-Centered Maintenance (RCM) methodology.',
      de: 'DIN EN 13306 Instandhaltungsnorm; Reliability-Centered Maintenance (RCM) Methodik.',
    },
  },
  {
    id: 'asset-performance',
    number: '10',
    name: {
      en: 'Asset Performance',
      de: 'Anlagenperformance',
    },
    shortDesc: {
      en: 'Data-driven reliability engineering, lifecycle cost optimization, and overall equipment effectiveness (OEE) enhancement.',
      de: 'Datengetriebenes Reliability Engineering, Lebenszykluskosten-Optimierung und Steigerung der Gesamtanlageneffizienz (OEE).',
    },
    fullScope: {
      en: 'Systematic analysis of asset health, root-cause failure analysis (RCFA), bottleneck elimination, and performance benchmarking to maximize asset profitability and availability.',
      de: 'Systematische Analyse des Anlagenzustands, Ursachenanalysen (RCFA), Engpassbeseitigung und Benchmarking zur Maximierung der Anlagenrendite.',
    },
    keyDeliverables: {
      en: ['OEE Bottleneck Identification & Analytics', 'Root Cause Failure Analysis (RCFA)', 'Asset Lifecycle Cost (LCC) Modeling', 'Risk-Based Inspection (RBI) Program Development'],
      de: ['OEE-Engpassidentifikation & Analytik', 'Ursachenanalyse von Anlagenausfällen (RCFA)', 'Asset Lifecycle Cost (LCC) Modellierung', 'Risikobasierte Inspektion (RBI) Programmentwicklung'],
    },
    relatedIndustries: ['Chemicals & Petrochemicals', 'Pharma & Biopharma', 'Energy', 'Industrial Manufacturing'],
    syntheticProjectRef: 'Project 03 — Chemical Plant Efficiency Programme',
    iconName: 'TrendingUp',
    technicalSpecs: {
      en: 'ISO 55000 Asset Management Standard compliance; API 580 / API 581 RBI principles.',
      de: 'ISO 55000 Asset Management Standard; API 580 / API 581 RBI Prinzipien.',
    },
  },
  {
    id: 'turnarounds',
    number: '11',
    name: {
      en: 'Turnarounds',
      de: 'Anlagenstillstände & Turnarounds',
    },
    shortDesc: {
      en: 'Turnkey planning, execution, and safety management for major plant turnarounds and shutdowns.',
      de: 'Schlüsselfertige Planung, Abwicklung und Sicherheitssteuerung für komplexe Anlagenstillstände und Großrevisionen.',
    },
    fullScope: {
      en: 'Flawless turnaround execution using proprietary scope control, pre-turnaround 3D simulation, multi-discipline labor coordination, and compressed critical-path schedules.',
      de: 'Einwandfreie Stillstandsabwicklung durch präzises Scope Management, 3D-Simulationen vor Stillstand, multidisziplinäre Koordination und minimierte Kritische-Pfad-Zeiten.',
    },
    keyDeliverables: {
      en: ['Turnaround Scope Challenge & Optimization', 'Critical-Path Daily Milestone Tracking', 'Integrated Multi-Discipline Site Execution', 'Zero-Incident Safety & Quality Compliance'],
      de: ['Stillstands-Scope-Prüfung & Optimierung', 'Tägliches Kritischer-Pfad-Meilensteintracking', 'Integrierte multidisziplinäre Baustellenabwicklung', 'Null-Unfall-Sicherheits- & Qualitätsmanagement'],
    },
    relatedIndustries: ['Chemicals & Petrochemicals', 'Oil & Gas', 'Energy'],
    syntheticProjectRef: 'Project 04 — Industrial Maintenance Transformation',
    iconName: 'Clock',
    technicalSpecs: {
      en: 'Turnaround Excellence Model (TAR-EM); Real-time RFID site access & tool tracking.',
      de: 'Turnaround Excellence Modell (TAR-EM); Echtzeit RFID Zugangskontrolle & Werkzeugtracking.',
    },
  },
  {
    id: 'digital-industrial-solutions',
    number: '12',
    name: {
      en: 'Digital Industrial Solutions',
      de: 'Digitale Industrielösungen',
    },
    shortDesc: {
      en: 'Industrial IoT edge telemetry, digital twins, OT/IT cyber-security, and predictive analytics platforms.',
      de: 'Industrielle IoT-Edge-Telemetrie, Digitale Zwillinge, OT/IT-Cybersicherheit und Predictive Analytics Plattformen.',
    },
    fullScope: {
      en: 'End-to-end industrial digitalization architecture connecting sensor instrumentation to cloud analytics, enabling real-time anomaly detection and autonomous process guidance.',
      de: 'Ganzheitliche Digitalisierungsarchitektur von Feldsensoren bis Cloud-Analytik für Anomalieerkennung in Echtzeit und autonome Prozessführung.',
    },
    keyDeliverables: {
      en: ['Industrial Data Lake & Edge Gateways', 'Physics-Based Digital Twin Simulations', 'IEC 62443 OT Cybersecurity Hardening', 'Predictive Maintenance Anomaly Algorithms'],
      de: ['Industrial Data Lake & Edge Gateways', 'Physikbasierte Digitale-Zwillings-Simulationen', 'IEC 62443 OT Cybersicherheits-Härtung', 'Anomalie-Algorithmen für Predictive Maintenance'],
    },
    relatedIndustries: ['Energy', 'Chemicals & Petrochemicals', 'Pharma & Biopharma', 'Utilities'],
    syntheticProjectRef: 'Project 01 — Hydrogen Integration Facility',
    iconName: 'Server',
    technicalSpecs: {
      en: 'OPC UA unified architecture; MQTT-SN edge protocols; IEC 62443 cybersecurity standard.',
      de: 'OPC UA Architektur; MQTT-SN Edge-Protokolle; IEC 62443 Cybersicherheitsstandard.',
    },
  },
  {
    id: 'energy-transition',
    number: '13',
    name: {
      en: 'Energy Transition',
      de: 'Energiewende',
    },
    shortDesc: {
      en: 'Green hydrogen electrolyzer plants, carbon capture & storage (CCS), battery storage, and industrial electrification.',
      de: 'Grüne Wasserstoff-Elektrolyseanlagen, CO₂-Abscheidung und -Speicherung (CCS), Batteriespeicher und industrielle Elektrifizierung.',
    },
    fullScope: {
      en: 'Engineering and building the infrastructure required for industrial decarbonization, hydrogen transport networks, waste-to-energy conversion, and carbon removal technologies.',
      de: 'Engineering und Errichtung von Infrastrukturen für die industrielle Dekarbonisierung, Wasserstoff-Transportnetze und CO₂-Abscheidungsanlagen.',
    },
    keyDeliverables: {
      en: ['Electrolyzer Plant Balance of Plant (BoP)', 'CO₂ Capture & Compression Compression Units', 'High-Capacity Thermal Energy Storage Systems', 'Industrial Power-to-X Infrastructure'],
      de: ['Elektrolyse-Anlagen Balance of Plant (BoP)', 'CO₂-Abscheidungs- & Kompressionsanlagen', 'Hochkapazitive thermische Energiespeicher', 'Industrielle Power-to-X Infrastruktur'],
    },
    relatedIndustries: ['Energy', 'Utilities', 'Chemicals & Petrochemicals', 'Industrial Manufacturing'],
    syntheticProjectRef: 'Project 01 — Hydrogen Integration Facility',
    iconName: 'Zap',
    technicalSpecs: {
      en: 'Direct high-pressure H2 compression up to 500 bar; Amine-based CCS solvent thermodynamics.',
      de: 'Direkte Hochdruck-H2-Kompression bis 500 bar; Aminbasierte CO2-Abscheidungs-Thermodynamik.',
    },
  },
  {
    id: 'process-optimisation',
    number: '14',
    name: {
      en: 'Process Optimisation',
      de: 'Prozessoptimierung',
    },
    shortDesc: {
      en: 'Advanced process control (APC), pinch technology heat integration, and yield maximization studies.',
      de: 'Advanced Process Control (APC), Pinch-Technologie für Abwärmenutzung und Ertragsoptimierung.',
    },
    fullScope: {
      en: 'Scientific optimization of plant chemical kinetics, mass flow balance, steam consumption, and solvent recycling to maximize operational yield while reducing environmental footprints.',
      de: 'Wissenschaftliche Optimierung chemischer Kinetik, Massenstrombilanzen und Dampfverbrauch zur Maximierung von Erträgen bei minimierter Umweltbelastung.',
    },
    keyDeliverables: {
      en: ['Pinch Analysis Heat Integration Studies', 'Advanced Multivariable Process Control (APC)', 'Debottlenecking & Column Hydraulics Overhaul', 'Emissions Abatement & VOC Recovery Units'],
      de: ['Pinch-Analyse zur Abwärmeintegration', 'Advanced Multivariable Process Control (APC)', 'Engpassbeseitigung & Kolonnenhydraulik-Optimierung', 'VOC-Rückgewinnungs- & Abgassysteme'],
    },
    relatedIndustries: ['Chemicals & Petrochemicals', 'Pharma & Biopharma', 'Energy'],
    syntheticProjectRef: 'Project 03 — Chemical Plant Efficiency Programme',
    iconName: 'Sliders',
    technicalSpecs: {
      en: 'Thermodynamic Pinch Technology analysis; Model Predictive Control (MPC) algorithms.',
      de: 'Thermodynamische Pinch-Technologie; Modellprädiktive Reglungs-Algorithmen (MPC).',
    },
  },
];
