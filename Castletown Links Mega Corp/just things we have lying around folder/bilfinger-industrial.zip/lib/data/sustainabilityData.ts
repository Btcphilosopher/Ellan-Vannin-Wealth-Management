export interface FacilityScenarioState {
  energyEfficiency: number; // 50 to 100%
  heatRecovery: number; // 0 to 100%
  maintenanceMode: 'reactive' | 'scheduled' | 'predictive';
  electrificationLevel: number; // 0 to 100%
  productionLoad: number; // 50 to 120%
  operatingHours: number; // 4000 to 8760 hrs
}

export interface FacilityScenarioOutput {
  energyUseIndex: number; // Baseline ~ 100
  co2EmissionsTonnes: number; // e.g. 15,000 to 80,000 t/yr
  unplannedDowntimeHours: number; // e.g. 12 to 320 hrs/yr
  opexIndex: number; // Baseline ~ 100
}

export function calculateFacilityScenario(state: FacilityScenarioState): FacilityScenarioOutput {
  const baseHours = state.operatingHours / 8760;
  const loadFactor = state.productionLoad / 100;

  // Base energy index depends on production load and operating hours
  let rawEnergy = 100 * loadFactor * baseHours;
  // Efficiency cuts energy use
  const efficiencyDiscount = (state.energyEfficiency - 50) * 0.4; // up to 20% savings
  // Heat recovery cuts fuel consumption
  const heatRecoveryDiscount = (state.heatRecovery / 100) * 22; // up to 22% savings

  const energyUseIndex = Math.max(35, Math.round(rawEnergy * (1 - (efficiencyDiscount + heatRecoveryDiscount) / 100)));

  // CO2 Emissions (tonnes / yr) - electrification dramatically cuts direct thermal emissions
  const thermalCo2Baseline = 65000 * loadFactor * baseHours;
  const electrificationFactor = 1 - (state.electrificationLevel / 100) * 0.78; // up to 78% lower direct emissions
  const heatRecoveryCo2Factor = 1 - (state.heatRecovery / 100) * 0.18;

  const co2EmissionsTonnes = Math.round(thermalCo2Baseline * electrificationFactor * heatRecoveryCo2Factor * (state.energyEfficiency / 100));

  // Downtime Hours / yr based on maintenance mode & load
  let maintenanceDowntimeMultiplier = 1.0;
  if (state.maintenanceMode === 'reactive') maintenanceDowntimeMultiplier = 2.4;
  if (state.maintenanceMode === 'scheduled') maintenanceDowntimeMultiplier = 1.0;
  if (state.maintenanceMode === 'predictive') maintenanceDowntimeMultiplier = 0.22;

  const baseDowntime = 140 * baseHours * (loadFactor > 1 ? 1.3 : 1.0);
  const unplannedDowntimeHours = Math.round(baseDowntime * maintenanceDowntimeMultiplier);

  // OPEX Index
  let opexBase = (energyUseIndex * 0.5) + (co2EmissionsTonnes / 650) + (unplannedDowntimeHours * 0.25);
  if (state.maintenanceMode === 'predictive') opexBase *= 0.88; // preventive savings offset software cost

  const opexIndex = Math.round(Math.max(40, opexBase));

  return {
    energyUseIndex,
    co2EmissionsTonnes,
    unplannedDowntimeHours,
    opexIndex,
  };
}
