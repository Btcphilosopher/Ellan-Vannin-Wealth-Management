export interface ProjectMilestone {
  date: string;
  title: { en: string; de: string };
  desc: { en: string; de: string };
}

export interface ProjectItem {
  id: string;
  number: string;
  title: { en: string; de: string };
  summary: { en: string; de: string };
  industry: string;
  service: string;
  region: string;
  location: string;
  status: { en: string; de: string };
  challenge: { en: string; de: string };
  solution: { en: string; de: string };
  outcome: { en: string; de: string };
  disciplines: string[];
  technicalSystems: string[];
  metrics: { label: { en: string; de: string }; value: string }[];
  timeline: ProjectMilestone[];
  imageUrl: string;
  galleryUrls: string[];
}

export const projectsData: ProjectItem[] = [
  {
    id: 'hydrogen-integration-facility',
    number: '01',
    title: {
      en: 'Hydrogen Integration Facility',
      de: 'Wasserstoff-Integrationsanlage',
    },
    summary: {
      en: 'Integrating a new hydrogen system into an existing industrial energy network.',
      de: 'Integration eines neuen Wasserstoffsystems in ein bestehendes industrielles Energienetz.',
    },
    industry: 'Energy',
    service: 'Energy Transition',
    region: 'Central Europe',
    location: 'Leuna Chemical Park, Germany',
    status: {
      en: 'Completed & Operational',
      de: 'Erfolgreich Abgeschlossen & In Betrieb',
    },
    challenge: {
      en: 'Connecting a 50MW PEM green hydrogen electrolyzer unit into an active chemical park pipeline network with strict 99.999% gas purity standards, zero-leak embrittlement safeguards, and continuous 24/7 process synchronization without interrupting surrounding chemical production.',
      de: 'Anbindung eines 50MW PEM-Elektrolyseurs an ein bestehendes Chemiepark-Rohrnetz unter Einhaltung von 99,999% Gasreinheit, Versprödungsschutz und unterbrechungsfreiem 24/7-Betrieb der benachbarten Chemieanlagen.',
    },
    solution: {
      en: 'Delivered turnkey EPCM front-end design, prefabrication of high-pressure stainless steel spools (316L/Hastelloy C-276), automated ATEX flame detection, direct buffer gas compression up to 350 bar, and SIL-3 safety instrumented system logic.',
      de: 'Schlüsselfertiges EPCM Front-End-Design, Vorfertigung von Edelstahl-Hochdruckspools (316L/Hastelloy C-276), automatisierte ATEX-Flammenüberwachung, Puffergaskompression bis 350 bar und SIL-3 Sicherheitssteuerung.',
    },
    outcome: {
      en: 'Displaced 42,000 tonnes of fossil H2 annually, achieved 100% schedule compliance during tie-in shutdown window, and established a scalable blueprint for regional industrial hydrogen clusters.',
      de: 'Jährliche Einsparung von 42.000 Tonnen fossilem Wasserstoff, 100% Termintreue beim Einbindestillstand und Schaffung einer skalierbaren Referenz für Wasserstoff-Cluster.',
    },
    disciplines: ['Process Engineering', 'Piping & Fabrication', 'Instrumentation & Controls', 'ATEX Safety Compliance'],
    technicalSystems: ['PEM Electrolyzer Balance of Plant', 'Multi-Stage Diaphragm Compressor', 'PSA Hydrogen Purification Unit', 'IEC 61511 SIL-3 Safety Matrix'],
    metrics: [
      { label: { en: 'Annual CO2 Abated', de: 'Jährlich vermiedenes CO2' }, value: '84,000 t' },
      { label: { en: 'Piping Purity Standard', de: 'Rohrleitungs-Reinheitsklasse' }, value: 'ISO 8573-1' },
      { label: { en: 'Tie-in Downtime', de: 'Einbinde-Stillstandszeit' }, value: '72 Hours' },
      { label: { en: 'Peak Operating Pressure', de: 'Maximaler Betriebsdruck' }, value: '350 Bar' },
    ],
    timeline: [
      { date: 'Q1 2024', title: { en: 'FEED & HAZOP Safety Approval', de: 'FEED & HAZOP Sicherheitsfreigabe' }, desc: { en: '3D Laser scanning and safety hazard analysis completed.', de: '3D-Laserscanning und HAZOP-Gefahrenanalyse abgeschlossen.' } },
      { date: 'Q3 2024', title: { en: 'Offsite Spool Prefabrication', de: 'Offsite Rohrleitungsvorfertigung' }, desc: { en: '1,400 orbital welded spools tested with 100% radiography.', de: '1.400 orbitalgeschweißte Spools zu 100% röntgengeprüft.' } },
      { date: 'Q1 2025', title: { en: 'Onsite Erection & Commissioning', de: 'Montage vor Ort & Inbetriebnahme' }, desc: { en: 'Skid placement, pressure testing, and grid tie-in executed.', de: 'Skid-Setzung, Druckprüfung und Netzeinbindung durchgeführt.' } },
    ],
    imageUrl: 'https://picsum.photos/seed/hydrogen-facility/1200/800',
    galleryUrls: [
      'https://picsum.photos/seed/hydrogen-1/800/600',
      'https://picsum.photos/seed/hydrogen-2/800/600',
      'https://picsum.photos/seed/hydrogen-3/800/600',
    ],
  },
  {
    id: 'pharma-utility-expansion',
    number: '02',
    title: {
      en: 'Pharmaceutical Utility Expansion',
      de: 'Erweiterung der Medienversorgung Pharma',
    },
    summary: {
      en: 'Expanding media supply and ultra-clean utilities for a state-of-the-art biopharmaceutical facility.',
      de: 'Erweiterung der Medienversorgung für eine hochmoderne biopharmazeutische Produktionsanlage.',
    },
    industry: 'Pharma & Biopharma',
    service: 'Prefabrication & Installation',
    region: 'Western Europe',
    location: 'Basel Biotech Hub, Switzerland',
    status: {
      en: 'Commissioned & Validated',
      de: 'In Betrieb & Vollständig Validiert',
    },
    challenge: {
      en: 'Constructing and validating a 3,500-meter Water-for-Injection (WFI) loop and clean steam distribution network in an active ISO Class 7 cleanroom environment without disturbing ongoing mammalian cell culture batches.',
      de: 'Bau und Validierung eines 3.500m WFI-Kreislaufs und Reindampfnetzes in einem aktiven ISO 7 Reinraum ohne Beeinträchtigung laufender Zellkultur-Chargen.',
    },
    solution: {
      en: 'Implemented modular offsite cleanroom prefabrication, closed orbital TIG welding with internal argon purge, continuous surface roughness verification (Ra < 0.38 µm), and automated CIP/SIP thermal validation routines.',
      de: 'Modulare Offsite-Reinraumvorfertigung, geschlossenes Orbital-WIG-Schweißen mit Argon-Schutzgas, kontinuierliche Rauheitsprüfung (Ra < 0,38 µm) und automatisierte CIP/SIP Validierung.',
    },
    outcome: {
      en: 'Achieved 100% pass rate on FDA cGMP sanitization audits, zero bio-film formation across 12 months of continuous monitoring, and enabled 40% increased bioreactor production capacity.',
      de: '100% Bestehensquote bei FDA cGMP Audits, null Biofilmbildung in 12 Monaten Überwachung und 40% Kapazitätserweiterung der Bioreaktoren.',
    },
    disciplines: ['Clean Utilities', 'Orbital Welding', 'cGMP Qualification', 'Instrumentation'],
    technicalSystems: ['WFI Storage & Distribution Loop', 'Clean Steam Generator Unit', 'CIP/SIP Skid Assembly', 'Siemens PCS7 Batch Controller'],
    metrics: [
      { label: { en: 'Surface Finish Ra', de: 'Oberflächengüte Ra' }, value: '< 0.38 µm' },
      { label: { en: 'Validation Protocol Pass Rate', de: 'Validierungs-Erfolgsquote' }, value: '100%' },
      { label: { en: 'WFI Recirculation Temp', de: 'WFI Zirkulationstemperatur' }, value: '85°C Hot Loop' },
      { label: { en: 'Construction Cleanliness Class', de: 'Bausauberkeitsklasse' }, value: 'ISO Class 5/7' },
    ],
    timeline: [
      { date: 'Q2 2024', title: { en: 'Design Qualification (DQ)', de: 'Design-Qualifizierung (DQ)' }, desc: { en: 'Validation master plan & 3D BIM coordination approved.', de: 'Validierungsmasterplan und 3D-BIM-Koordination freigegeben.' } },
      { date: 'Q4 2024', title: { en: 'Modular Skid Offsite Prefab', de: 'Offsite-Skid-Vorfertigung' }, desc: { en: 'Skids built in class 10,000 clean workshop.', de: 'Skid-Bau in Klasse 10.000 Sauberwerkstatt.' } },
      { date: 'Q2 2025', title: { en: 'IQ/OQ/PQ Performance Run', de: 'IQ/OQ/PQ Leistungslauf' }, desc: { en: 'Thermal profiling and TOC water quality verified.', de: 'Thermoprofilierung und TOC-Wasserqualität nachgewiesen.' } },
    ],
    imageUrl: 'https://picsum.photos/seed/pharma-facility/1200/800',
    galleryUrls: [
      'https://picsum.photos/seed/pharma-1/800/600',
      'https://picsum.photos/seed/pharma-2/800/600',
      'https://picsum.photos/seed/pharma-3/800/600',
    ],
  },
  {
    id: 'chemical-plant-efficiency',
    number: '03',
    title: {
      en: 'Chemical Plant Efficiency Programme',
      de: 'Effizienzprogramm Chemische Anlage',
    },
    summary: {
      en: 'Comprehensive energy efficiency and heat integration transformation for a specialty chemical plant.',
      de: 'Programm zur Steigerung der Energieeffizienz einer chemischen Produktionsanlage.',
    },
    industry: 'Chemicals & Petrochemicals',
    service: 'Process Optimisation',
    region: 'Western Europe',
    location: 'Rotterdam Mainport, Netherlands',
    status: {
      en: 'Operational & Optimizing',
      de: 'In Betrieb & Fortlaufend Optimiert',
    },
    challenge: {
      en: 'High natural gas exposure across four distillation columns and a thermal oxidizer unit facing rising carbon tax levies, severe thermal energy losses, and bottlenecked cooling water capacity during summer peak ambient conditions.',
      de: 'Hoher Erdgasverbrauch an vier Destillationskolonnen und einer thermischen Nachverbrennung bei steigenden CO2-Kosten und thermischen Engpässen im Sommerbetrieb.',
    },
    solution: {
      en: 'Executed thermodynamic Pinch Analysis heat network synthesis, installed high-efficiency plate heat exchangers, added mechanical vapor recompression (MVR) units, and deployed Advanced Process Control (APC) model prdictive loops.',
      de: 'Durchführung einer thermodynamischen Pinch-Analyse, Installation von Hocheffizienz-Plattenwärmetauschern, Brüdenverdichtern (MVR) und modellprädiktiver Prozessregelung (APC).',
    },
    outcome: {
      en: 'Reduced site natural gas consumption by 28.4%, lowered annual operating expenses by €4.1M, and cut Scope-1 thermal carbon intensity by 34,000 tonnes CO2e per year.',
      de: 'Reduzierung des Erdgasverbrauchs um 28,4%, Senkung der jährlichen OPEX um 4,1 Mio. € und Verringerung der CO2-Intensität um 34.000 t/Jahr.',
    },
    disciplines: ['Thermodynamic Engineering', 'Advanced Process Control', 'Mechanical Equipment Retrofit', 'Insulation Technology'],
    technicalSystems: ['Mechanical Vapor Recompression (MVR)', 'Pinch-Integrated Heat Exchanger Network', 'MPC Column Controller', 'High-Efficiency Aerogel Insulation'],
    metrics: [
      { label: { en: 'Natural Gas Savings', de: 'Erdgas-Einsparung' }, value: '28.4%' },
      { label: { en: 'Annual OPEX Reduction', de: 'Jährliche OPEX-Senkung' }, value: '€4.1M' },
      { label: { en: 'Payback Period', de: 'Amortisationszeit' }, value: '2.3 Years' },
      { label: { en: 'CO2 Abatement', de: 'CO2-Reduktion' }, value: '34,000 t/yr' },
    ],
    timeline: [
      { date: 'Q1 2024', title: { en: 'Thermodynamic Pinch Audit', de: 'Thermodynamisches Pinch-Audit' }, desc: { en: 'Site-wide energy balance & waste heat mapping completed.', de: 'Standortweite Energiebilanzierung und Abwärmemapping.' } },
      { date: 'Q3 2024', title: { en: 'MVR Unit Installation', de: 'Installation der Brüdenverdichter' }, desc: { en: 'Mechanical vapor compressor skids tied into columns.', de: 'Brüdenverdichter-Skids an Destillationskolonnen angebunden.' } },
      { date: 'Q1 2025', title: { en: 'APC Model Tuning & Handover', de: 'APC-Modellabstimmung & Übergabe' }, desc: { en: 'Closed-loop optimization verified during summer peak.', de: 'Closed-loop Optimierung im Sommerpeak verifiziert.' } },
    ],
    imageUrl: 'https://picsum.photos/seed/chemical-efficiency/1200/800',
    galleryUrls: [
      'https://picsum.photos/seed/chemical-1/800/600',
      'https://picsum.photos/seed/chemical-2/800/600',
      'https://picsum.photos/seed/chemical-3/800/600',
    ],
  },
  {
    id: 'industrial-maintenance-transformation',
    number: '04',
    title: {
      en: 'Industrial Maintenance Transformation',
      de: 'Instandhaltungstransformation',
    },
    summary: {
      en: 'Predictive maintenance digitalization and turnaround execution for higher availability and predictability.',
      de: 'Transformation der Instandhaltung für höhere Anlagenverfügbarkeit und bessere Planbarkeit.',
    },
    industry: 'Industrial Manufacturing',
    service: 'Maintenance',
    region: 'Central Europe',
    location: 'Linz Industrial Hub, Austria',
    status: {
      en: 'Active Multi-Year Partnership',
      de: 'Aktive Mehrjährige Partnerschaft',
    },
    challenge: {
      en: 'High reactive maintenance ratio (62%), frequent unplanned equipment stoppages across a heavy continuous steel rolling mill, fragmented legacy work-order logs, and retiring specialist workforce knowledge loss.',
      de: 'Hoher reaktiver Instandhaltungsanteil (62%), ungeplante Maschinenausfälle an einem Warmwalzwerk und drohender Wissensverlust durch Generationenwechsel.',
    },
    solution: {
      en: 'Deployed Bilfinger Maintenance Concept (BMC), installed wireless IIoT vibration & thermography sensors on 420 critical rotating assets, integrated mobile tablet work orders connected to SAP PM, and established resident technical maintenance squads.',
      de: 'Einführung des Bilfinger Maintenance Concepts (BMC), Installation kabelloser IIoT-Schwingungssensoren an 420 Anlagen, mobile SAP-PM Tablet-Instandhaltung und feste Vor-Ort-Teams.',
    },
    outcome: {
      en: 'Increased Overall Equipment Effectiveness (OEE) from 71.2% to 84.8%, slashed unplanned downtime by 54%, and achieved 820+ consecutive days with Zero Lost Time Injuries (LTI).',
      de: 'Steigerung der Gesamtanlageneffizienz (OEE) von 71,2% auf 84,8%, Senkung ungeplanter Ausfälle um 54% und über 820 Tage ohne Arbeitsunfall mit Ausfallzeit.',
    },
    disciplines: ['Reliability Engineering', 'IIoT Condition Monitoring', 'Turnaround Excellence', 'HSEQ Management'],
    technicalSystems: ['SAP S/4HANA PM Integration', 'IIoT Wireless Vibration Mesh Network', 'Ultrasound & Oil Analysis Diagnostics', 'Bilfinger BMC Governance Suite'],
    metrics: [
      { label: { en: 'OEE Improvement', de: 'OEE-Steigerung' }, value: '71.2% → 84.8%' },
      { label: { en: 'Unplanned Downtime Drop', de: 'Ungeplanter Ausfallrückgang' }, value: '-54%' },
      { label: { en: 'Sensors Monitored', de: 'Überwachte Sensoren' }, value: '420 Assets' },
      { label: { en: 'Safety Standard', de: 'Sicherheitsstandard' }, value: '0 LTI (820+ Days)' },
    ],
    timeline: [
      { date: 'Q1 2024', title: { en: 'BMC Readiness & Asset Criticality Audit', de: 'BMC Audit & Asset-Kritikalität' }, desc: { en: 'Classified 1,800 machinery assets into risk tiers.', de: '1.800 Anlagenteile in Risikoklassen klassifiziert.' } },
      { date: 'Q3 2024', title: { en: 'IIoT Sensor Network Deployment', de: 'IIoT-Sensornetz-Rollout' }, desc: { en: 'Wireless telemetry installed on high-impact drive trains.', de: 'Drahtlose Telemetrie an Hauptantrieben montiert.' } },
      { date: 'Q1 2025', title: { en: 'Full Predictive Mode Operational', de: 'Vollständiger Prädiktiv-Betrieb' }, desc: { en: 'Predictive algorithms preventing 14 major failure events.', de: 'Prädiktive Algorithmen verhinderten 14 Großstörungen.' } },
    ],
    imageUrl: 'https://picsum.photos/seed/maintenance-transform/1200/800',
    galleryUrls: [
      'https://picsum.photos/seed/maint-1/800/600',
      'https://picsum.photos/seed/maint-2/800/600',
      'https://picsum.photos/seed/maint-3/800/600',
    ],
  },
  {
    id: 'offshore-electrification-skid',
    number: '05',
    title: {
      en: 'Offshore Electrification Skid',
      de: 'Offshore-Elektrifizierungs-Skid',
    },
    summary: {
      en: 'Modular high-voltage substation skid for offshore platform decarbonization.',
      de: 'Modulare Hochspannungs-Transformator-Skidanlage zur Offshore-Dekarbonisierung.',
    },
    industry: 'Oil & Gas',
    service: 'Plant Construction',
    region: 'North Sea',
    location: 'North Sea Energy Hub, Norway',
    status: {
      en: 'Installed & Grid-Connected',
      de: 'Installiert & Am Netz',
    },
    challenge: {
      en: 'Replacing gas turbine offshore power generation with shore-supplied renewable electricity under severe space, weight (max 480 tonnes skid), and extreme North Sea maritime weather constraints.',
      de: 'Ersatz fossiler Gasturbinen-Stromerzeugung durch Festland-Ökostrom unter extremen Platz-, Gewichts- (max. 480t Skid) und Nordsee-Wetterbedingungen.',
    },
    solution: {
      en: 'Designed and preassembled a compact, heavy-duty offshore transformer skid package featuring SF6-free switchgear, stainless steel blast-rated enclosures, and remote digital monitoring.',
      de: 'Planung und Vorfertigung eines kompakten Schwerlast-Offshore-Transformatorskids mit SF6-freier Schaltanlage, druckfesten Edelstahlgehäusen und Fernüberwachung.',
    },
    outcome: {
      en: 'Eliminated 110,000 tonnes of offshore gas turbine CO2 emissions per year and increased power supply reliability to 99.98%.',
      de: 'Vermeidung von 110.000 Tonnen CO2 pro Jahr aus Offshore-Gasturbinen und Steigerung der Stromzuverlässigkeit auf 99,98%.',
    },
    disciplines: ['Offshore Structural Engineering', 'High-Voltage Electrical', 'Heavy Lift Logistics', 'Subsea Cable Tie-In'],
    technicalSystems: ['132kV Offshore Substation Skid', 'SF6-Free Clean Air GIS Switchgear', 'Offshore Blast-Proof Control Enclosure', 'Subsea Fiber-Optic Telemetry Link'],
    metrics: [
      { label: { en: 'Annual CO2 Abated', de: 'Jährlich vermiedenes CO2' }, value: '110,000 t' },
      { label: { en: 'Skid Module Weight', de: 'Skid-Modulgewicht' }, value: '465 Tonnes' },
      { label: { en: 'Supply Voltage', de: 'Versorgungsspannung' }, value: '132 kV AC' },
      { label: { en: 'Availability Rate', de: 'Verfügbarkeitsrate' }, value: '99.98%' },
    ],
    timeline: [
      { date: 'Q1 2024', title: { en: 'Structural Engineering & HAZID', de: 'Strukturplanung & HAZID' }, desc: { en: 'Weight management & blast load simulation.', de: 'Gewichtsmanagement und Explosionslast-Simulation.' } },
      { date: 'Q4 2024', title: { en: 'Yard Modular Prefabrication', de: 'Werft-Modulvorfertigung' }, desc: { en: 'Assembly & heavy lift testing at coastal yard.', de: 'Montage und Schwerlasttest in Küstenwerft.' } },
      { date: 'Q2 2025', title: { en: 'Offshore Heavy Lift Installation', de: 'Offshore Schwerlastinstallation' }, desc: { en: 'Lifting and cable tie-in during weather window.', de: 'Einhub und Kabelanbindung im Wetterfenster.' } },
    ],
    imageUrl: 'https://picsum.photos/seed/offshore-plant/1200/800',
    galleryUrls: [
      'https://picsum.photos/seed/offshore-1/800/600',
      'https://picsum.photos/seed/offshore-2/800/600',
      'https://picsum.photos/seed/offshore-3/800/600',
    ],
  },
  {
    id: 'district-heating-decarbonization',
    number: '06',
    title: {
      en: 'District Heating Heat Pump Integration',
      de: 'Fernwärme-Großwärmepumpen-Integration',
    },
    summary: {
      en: 'Large-scale river heat pump integration into a municipal district heating grid.',
      de: 'Einbindung einer Großwärmepumpe mit Flusswärmenutzung in ein städtisches Fernwärmenetz.',
    },
    industry: 'Utilities',
    service: 'Energy Transition',
    region: 'Central Europe',
    location: 'Mannheim Neckar Hub, Germany',
    status: {
      en: 'Operational Demonstration',
      de: 'In Betrieb als Demonstrationsanlage',
    },
    challenge: {
      en: 'Replacing coal-fired district heating generation with a 20MW river-water thermal heat pump, requiring complex river intake filtration, environmental water discharge compliance, and 120°C output steam temperatures.',
      de: 'Ersatz kohlegefeuerter Fernwärme durch eine 20MW Flusswasser-Großwärmepumpe mit komplexer Flusswasser-Filtration und 120°C Vorlauftemperatur.',
    },
    solution: {
      en: 'Engineered a multi-stage ammonia-based heat pump system, insulated underground pre-insulated piping loops, and automated load-balancing SCADA dispatching.',
      de: 'Engineering einer mehrstufigen Ammoniak-Großwärmepumpe, verlegte vorisolierte Fernwärmerohre und automatisierte SCADA-Lastverteilung.',
    },
    outcome: {
      en: 'Supplies carbon-neutral district heating to over 30,000 residential and commercial buildings, achieving a seasonal performance factor (COP) of 3.4.',
      de: 'Versorgung von über 30.000 Haushalten mit klimaneutraler Fernwärme bei einer Jahresarbeitszahl (COP) von 3,4.',
    },
    disciplines: ['Thermal Process Engineering', 'District Piping', 'Refrigeration & Ammonia Safety', 'SCADA Dispatch'],
    technicalSystems: ['20MW High-Temp Ammonia Heat Pump', 'River Intake Traveling Screens', 'Pre-Insulated Direct Burial Steel Pipes', 'IEC 60870 Grid Dispatch Controller'],
    metrics: [
      { label: { en: 'Thermal Output', de: 'Thermische Leistung' }, value: '20 MWth' },
      { label: { en: 'Coefficient of Performance (COP)', de: 'Jahresarbeitszahl (COP)' }, value: '3.4' },
      { label: { en: 'Flow Temperature', de: 'Vorlauftemperatur' }, value: '120°C' },
      { label: { en: 'Homes Supplied', de: 'Versorgte Haushalte' }, value: '30,000+' },
    ],
    timeline: [
      { date: 'Q2 2024', title: { en: 'Hydraulic Grid Simulation', de: 'Hydraulische Netzsimulation' }, desc: { en: 'Flow dynamics and river temperature impact study.', de: 'Strömungsdynamik und Temperaturstudie am Fluss.' } },
      { date: 'Q4 2024', title: { en: 'Heat Pump Skid Assembly', de: 'Wärmepumpen-Skidmontage' }, desc: { en: 'Ammonia refrigeration compressor installation.', de: 'Installation der Ammoniak-Kältekompressoren.' } },
      { date: 'Q2 2025', title: { en: 'Grid Injection & Heat Supply', de: 'Netzeinspeisung & Wärmeversorgung' }, desc: { en: 'First thermal energy dispatched to city loop.', de: 'Erste Wärmeeinspeisung in das Stadtnetz.' } },
    ],
    imageUrl: 'https://picsum.photos/seed/heatpump-plant/1200/800',
    galleryUrls: [
      'https://picsum.photos/seed/heatpump-1/800/600',
      'https://picsum.photos/seed/heatpump-2/800/600',
      'https://picsum.photos/seed/heatpump-3/800/600',
    ],
  },
];
