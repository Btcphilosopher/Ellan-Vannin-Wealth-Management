export interface IndustryItem {
  id: string;
  name: { en: string; de: string };
  tagline: { en: string; de: string };
  intro: { en: string; de: string };
  challenges: { en: string[]; de: string[] };
  capabilities: { en: string[]; de: string[] };
  syntheticProjects: { title: { en: string; de: string }; description: { en: string; de: string } }[];
  sustainabilityAspects: { en: string[]; de: string[] };
  relatedServices: string[];
  imageUrl: string;
}

export const industriesData: IndustryItem[] = [
  {
    id: 'energy',
    name: {
      en: 'ENERGY',
      de: 'ENERGIE',
    },
    tagline: {
      en: 'Powering the global energy transformation with resilient infrastructure.',
      de: 'Resiliente Infrastruktur für die weltweite Energiewende.',
    },
    intro: {
      en: 'From conventional thermal power plants and combined heat and power (CHP) installations to hydrogen networks, biomass conversion, and grid-scale energy storage, we engineer high-reliability infrastructure.',
      de: 'Von konventionellen thermischen Kraftwerken und Kraft-Wärme-Kopplungsanlagen bis zu Wasserstoffnetzen, Biomasseumwandlung und Energiespeichern entwickeln wir hochzuverlässige Infrastrukturen.',
    },
    challenges: {
      en: ['Grid flexibility & intermittent load integration', 'Rapid decarbonization & coal-to-gas-to-hydrogen switching', 'Thermal plant life-extension & strict emissions limits', 'High-temperature steam loop corrosion & fatigue'],
      de: ['Netzflexibilität & Einbindung schwankender Einspeisungen', 'Zügige Dekarbonisierung & Fuel-Switching zu H2', 'Lebensdauerverlängerung thermischer Kraftwerke', 'Hochtemperatur-Dampfleitungskorrosion & Materialermüdung'],
    },
    capabilities: {
      en: ['High-Pressure Boiler & Turbine Overhauls', 'Hydrogen Fuel Blending & Burner Conversion', 'Flue Gas Desulfurization (FGD) & DeNOx Retrofits', 'Thermal Energy Storage Integration'],
      de: ['Kessel- & Turbinenrevisionen im Hochdruckbereich', 'Wasserstoff-Beimischung & Brennerumrüstung', 'Rauchgasentschwefelung & DeNOx-Nachrüstungen', 'Integration thermischer Energiespeicher'],
    },
    syntheticProjects: [
      {
        title: {
          en: 'Project 01 — Hydrogen Integration Facility',
          de: 'Projekt 01 — Wasserstoff-Integrationsanlage',
        },
        description: {
          en: 'Integrating a 50MW green hydrogen electrolyzer into a regional industrial energy grid.',
          de: 'Einbindung eines 50MW Grünwasserstoff-Elektrolyseurs in ein regionales Industrie-Energienetz.',
        },
      },
    ],
    sustainabilityAspects: {
      en: ['Direct Scope-1 emissions reduction via fuel switching', 'Combined heat and power (CHP) thermal efficiency >88%', 'Carbon capture ready engineering architecture'],
      de: ['Direkte Scope-1 Emissionsminderung durch Fuel-Switching', 'Kraft-Wärme-Kopplung Effizienz >88%', 'Carbon-Capture-Ready Ingenieurarchitektur'],
    },
    relatedServices: ['Energy Transition', 'Plant Construction', 'Electrical & Automation', 'Turnarounds'],
    imageUrl: 'https://picsum.photos/seed/energy-plant/1200/800',
  },
  {
    id: 'chemicals-petrochemicals',
    name: {
      en: 'CHEMICALS & PETROCHEMICALS',
      de: 'CHEMIE & PETROCHEMIE',
    },
    tagline: {
      en: 'Optimizing throughput, safety, and energy intensity in complex process plants.',
      de: 'Durchsatz, Sicherheit und Energieeffizienz in komplexen Prozessanlagen optimieren.',
    },
    intro: {
      en: 'Chemical production demands uncompromising process safety, flawless turnarounds, and precise thermodynamics. We serve continuous crackers, polymer lines, basic chemicals, and specialty synthesis plants.',
      de: 'Die chemische Produktion erfordert kompromisslose Prozesssicherheit, präzise Turnarounds und optimale Thermodynamik bei Steamcrackern, Polymeren und Spezialchemie.',
    },
    challenges: {
      en: ['Extreme process temperatures & toxic media containment', 'Volatile organic compound (VOC) leak detection & repair', 'Turnaround downtime cost (~€1M/day in lost production)', 'Transitioning crackers to electric heating and bio-feedstocks'],
      de: ['Extreme Prozess-Temperaturen & Einschluss toxischer Medien', 'VOC-Leckageerkennung & Reparatur', 'Hohe Ausfallkosten bei Stillständen', 'Umstellung von Crackern auf elektrische Beheizung'],
    },
    capabilities: {
      en: ['ATEX Hazardous Area Electrical Installation', 'Corrosion Resistant Piping (Inconel / Hastelloy)', 'Advanced Process Control & Pinch Optimization', 'Turnkey Turnaround Execution (TAR-EM)'],
      de: ['ATEX-Explosionsschutz Elektroinstallation', 'Korrosionsbeständiger Rohrleitungsbau (Inconel / Hastelloy)', 'Advanced Process Control & Pinch-Optimierung', 'Schlüsselfertige Stillstandsabwicklung (TAR-EM)'],
    },
    syntheticProjects: [
      {
        title: {
          en: 'Project 03 — Chemical Plant Efficiency Programme',
          de: 'Projekt 03 — Effizienzprogramm Chemische Anlage',
        },
        description: {
          en: 'Comprehensive heat integration and waste steam recovery across an ethylene derivative complex.',
          de: 'Umfassende Wärmeintegration und Abdamprückgewinnung in einem Äthylenderivate-Komplex.',
        },
      },
    ],
    sustainabilityAspects: {
      en: ['Pinch-analysis steam closed-loop recovery', 'VOC emissions abatement via catalytic ox-units', 'Circular solvent recycling integration'],
      de: ['Dampfrückgewinnung im geschlossenen Kreislauf durch Pinch-Analyse', 'VOC-Minderung über katalytische Anlagen', 'Integration zirkulärer Lösungsmittel-Recycling-Netze'],
    },
    relatedServices: ['Consulting & Engineering', 'Maintenance', 'Asset Performance', 'Process Optimisation'],
    imageUrl: 'https://picsum.photos/seed/chemical-facility/1200/800',
  },
  {
    id: 'pharma-biopharma',
    name: {
      en: 'PHARMA & BIOPHARMA',
      de: 'PHARMA & BIOPHARMA',
    },
    tagline: {
      en: 'Cleanroom precision, cGMP compliance, and high-purity fluid systems.',
      de: 'Reinraum-Präzision, cGMP-Compliance und hochreine Medienversorgungen.',
    },
    intro: {
      en: 'For pharmaceutical ingredient manufacturing, bioreactor skids, and fill-finish lines, we deliver fully validated mechanical, electrical, and piping engineering adhering strictly to cGMP and FDA guidelines.',
      de: 'Für die Wirkstoffherstellung, Bioreaktor-Skids und Abfüllanlagen liefern wir vollständig validierte Mechanik-, Elektro- und Rohrleitungssysteme nach cGMP- und FDA-Standards.',
    },
    challenges: {
      en: ['Strict FDA / EMA validation & qualification requirements', 'Zero-contamination high-purity media transport (WFI / Pure Steam)', 'Accelerated time-to-market for bio-therapeutic facilities', 'Cleanroom HVAC pressure differential & particulate control'],
      de: ['Strenge FDA / EMA Validierungs- & Qualifizierungsauflagen', 'Kontaminationsfreier Transport hochreiner Medien (WFI / Reindampf)', 'Beschleunigte Time-to-Market für Biotherapeutika-Anlagen', 'Reinraum-RLT Druckdifferenz- & Partikelkontrolle'],
    },
    capabilities: {
      en: ['Orbital Welded High-Purity Stainless Piping (316L Ra < 0.38µm)', 'Clean Utilities (Water-for-Injection, CIP/SIP Systems)', 'cGMP Qualification (DQ, IQ, OQ, PQ Documentation)', 'Automated Batch Control Architecture (ISA-88)'],
      de: ['Orbitalgeschweißte Reinststoff-Rohrleitungen (316L Ra < 0,38µm)', 'Clean Utilities (WFI, CIP/SIP-Systeme)', 'cGMP-Qualifizierung (DQ, IQ, OQ, PQ-Dokumentation)', 'Automatisierte Batch-Steuerung (ISA-88)'],
    },
    syntheticProjects: [
      {
        title: {
          en: 'Project 02 — Pharmaceutical Utility Expansion',
          de: 'Projekt 02 — Erweiterung Medienversorgung Biopharma',
        },
        description: {
          en: 'Design and orbital installation of a WFI loop and clean steam system for monoclonal antibody production.',
          de: 'Planung und Orbital-Installation eines WFI-Kreislaufs und Reindampfsystems für die Antikörper-Herstellung.',
        },
      },
    ],
    sustainabilityAspects: {
      en: ['Energy-efficient CIP water recovery loops', 'Low-power cleanroom HVAC recirculation units', 'Single-use bio-container integration minimizing chemical wash'],
      de: ['Energieeffiziente CIP-Wasser-Rückgewinnung', 'Energiesparende Reinraum-Umluftsysteme', 'Single-Use-Einbindung zur Minimierung chemischer Spülungen'],
    },
    relatedServices: ['Prefabrication & Installation', 'Electrical & Automation', 'Project Management', 'Consulting & Engineering'],
    imageUrl: 'https://picsum.photos/seed/pharma-cleanroom/1200/800',
  },
  {
    id: 'oil-gas',
    name: {
      en: 'OIL & GAS',
      de: 'ÖL & GAS',
    },
    tagline: {
      en: 'Uncompromising asset integrity and safety across upstream, midstream, and refining assets.',
      de: 'Kompromisslose Anlagenintegrität und Sicherheit in Upstream, Midstream und Raffinerien.',
    },
    intro: {
      en: 'We maintain and modernize refineries, gas processing terminals, offshore platforms, and pipeline compressor stations, focusing on safety, corrosion control, and fugitive emissions abatement.',
      de: 'Wir instandhalten und modernisieren Raffinerien, Gas-Terminals, Offshore-Plattformen und Verdichterstationen mit Fokus auf Arbeitssicherheit, Korrosionsschutz und Methan-Emissionsminderung.',
    },
    challenges: {
      en: ['Harsh corrosive environments & severe wear', 'Fugitive methane emission tracking & LDAR programs', 'Complex brownfield tie-ins under continuous operation', 'Transitioning refining capacity to bio-refining & SAF (Sustainable Aviation Fuel)'],
      de: ['Aggressive Korrosionsumgebungen & hoher Verschleiß', 'Methan-Leckage-Erfassung & LDAR-Programme', 'Komplexe Einbindungen bei laufendem Betrieb', 'Raffinerie-Umrüstung auf Bio-Kraftstoffe & SAF'],
    },
    capabilities: {
      en: ['Refinery Turnaround Management (Catalyst changeout, column packing)', 'Subsea & Offshore Structural Inspection & Repair', 'High-Pressure Gas Compressor Overhauls', 'CUI Defense Cladding & Passive Fire Protection'],
      de: ['Raffinerie-Stillstandsmanagement (Katalysatorwechsel, Kolonneneinbauten)', 'Offshore-Strukturinspektion & Reparatur', 'Hochdruck-Gasverdichterrevisionen', 'CUI-Schutzverkleidungen & Passiver Brandschutz'],
    },
    syntheticProjects: [
      {
        title: {
          en: 'Project 04 — Industrial Maintenance Transformation',
          de: 'Projekt 04 — Instandhaltungstransformation',
        },
        description: {
          en: 'Predictive condition monitoring and turnaround optimization across a major coastal refinery hub.',
          de: 'Vorausschauende Zustandsüberwachung und Stillstandsoptimierung für einen Küstenraffinerie-Standard.',
        },
      },
    ],
    sustainabilityAspects: {
      en: ['Fugitive methane LDAR reduction >95%', 'Flare gas recovery unit (FGRU) installation', 'SAF hydrotreatment conversion engineering'],
      de: ['Methan-Leckagereduzierung >95%', 'Fackelgas-Rückgewinnungsanlagen (FGRU)', 'Ingenieurtechnische Umstellung auf SAF-Herstellung'],
    },
    relatedServices: ['Mechanical Services', 'Insulation', 'Turnarounds', 'Asset Performance'],
    imageUrl: 'https://picsum.photos/seed/oil-refinery/1200/800',
  },
  {
    id: 'industrial-manufacturing',
    name: {
      en: 'INDUSTRIAL MANUFACTURING',
      de: 'INDUSTRIELLE FERTIGUNG',
    },
    tagline: {
      en: 'Driving productivity, automation, and asset longevity in heavy manufacturing.',
      de: 'Produktivität, Automatisierung und Langlebigkeit in der Schwerfertigung steigern.',
    },
    intro: {
      en: 'From steel mills and automotive assembly plants to paper mills and precision machinery manufacturing, we deliver total productive maintenance, mechanical automation, and energy-saving retrofits.',
      de: 'Von Stahlwerken und Automobilwerken bis zu Papierfabriken und Präzisionsmaschinenbau liefern wir Instandhaltung, Automatisierung und Energiespar-Nachrüstungen.',
    },
    challenges: {
      en: ['High mechanical stress, vibration, and thermal shock', 'Unplanned machine downtime halting continuous assembly lines', 'Legacy equipment integration with modern Industry 4.0 IoT', 'High energy costs in furnace and heat treatment processes'],
      de: ['Hohe mechanische Belastung, Schwingung und Thermoschock', 'Ungeplante Maschinenausfälle auf Fertigungsstraßen', 'Anbindung von Altanlagen an Industrie 4.0 IoT', 'Hohe Energiekosten bei Öfen und Wärmebehandlungen'],
    },
    capabilities: {
      en: ['Total Productive Maintenance (TPM) Contracts', 'Robotic Assembly & Conveyor Line Automation', 'Furnace Heat Recovery & Electrical Induction Conversion', 'Precision Machine Tool Laser Calibration'],
      de: ['Total Productive Maintenance (TPM) Verträge', 'Roboter- & Fördertechnik-Automatisierung', 'Ofen-Abwärmenutzung & Umstellung auf Induktion', 'Laser-Kalibrierung von Werkzeugmaschinen'],
    },
    syntheticProjects: [
      {
        title: {
          en: 'Project 03 — Chemical Plant Efficiency Programme',
          de: 'Projekt 03 — Effizienzprogramm Chemische Anlage',
        },
        description: {
          en: 'Automated energy management and waste heat capture across heavy machinery manufacturing lines.',
          de: 'Automatisiertes Energiemanagement und Abwärmenutzung in der Schwermaschinenfertigung.',
        },
      },
    ],
    sustainabilityAspects: {
      en: ['Variable speed drive (VSD) retrofits lowering motor power by 30%', 'Waste heat recovery for ambient building heating', 'Extended equipment lifecycle through precision maintenance'],
      de: ['Frequenzumrichter-Nachrüstung senkt Motorstrom um 30%', 'Abwärmenutzung für Hallenbeheizung', 'Verlängerte Anlagenlebensdauer durch Präzisionswartung'],
    },
    relatedServices: ['Maintenance', 'Electrical & Automation', 'Access Solutions', 'Process Optimisation'],
    imageUrl: 'https://picsum.photos/seed/manufacturing-plant/1200/800',
  },
  {
    id: 'utilities',
    name: {
      en: 'UTILITIES',
      de: 'VERSORGUNGSWIRTSCHAFT',
    },
    tagline: {
      en: 'Safeguarding municipal and industrial water, district heating, and grid networks.',
      de: 'Sicherung kommunaler und industrieller Wasser-, Fernwärme- und Stromnetze.',
    },
    intro: {
      en: 'We engineer, build, and maintain drinking water purification plants, industrial wastewater treatment facilities, high-efficiency district heating networks, and electrical distribution substations.',
      de: 'Wir planen, bauen und warten Trinkwasseraufbereitungen, industrielle Abwasserreinigungen, Fernwärmenetze und Umspannwerke.',
    },
    challenges: {
      en: ['Aging municipal piping and underground distribution grids', 'Strict environmental effluent quality standards', 'Resilience against extreme weather events and cybersecurity threats', 'Transitioning district heating to geothermal & large heat pumps'],
      de: ['Veraltete städtische Rohrnetze und Versorgungsstrukturen', 'Strenge Umweltauflagen für Abwassereinleitung', 'Resilienz gegen Wetterextreme und Cyberangriffe', 'Fernwärmeumstellung auf Geothermie & Großwärmepumpen'],
    },
    capabilities: {
      en: ['Water Treatment Reverse Osmosis & Ultrafiltration Engineering', 'High-Pressure District Heating Pipe Network Construction', 'Substation Automation & SCADA Telemetry Systems', 'Emergency Outage Repair & 24/7 Grid Field Response'],
      de: ['Wasseraufbereitung Umkehrosmose & Ultrafiltration', 'Hochdruck-Fernwärmerohrleitungsbau', 'Umspannwerk-Automatisierung & SCADA-Telemetrie', 'Havariedienst & 24/7 Netzentstörung'],
    },
    syntheticProjects: [
      {
        title: {
          en: 'Project 02 — Pharmaceutical Utility Expansion',
          de: 'Projekt 02 — Erweiterung Medienversorgung Biopharma',
        },
        description: {
          en: 'District utility steam grid modernization and condensate return optimization.',
          de: 'Ferndampfnetz-Modernisierung und Kondensatrückführung-Optimierung.',
        },
      },
    ],
    sustainabilityAspects: {
      en: ['Closed-loop water recycling reducing freshwater withdrawal by 65%', 'District heat pump integration reducing fossil fuel reliance', 'Smart grid leak detection minimizing network water loss'],
      de: ['Wasserrecycling reduziert Frischwasserbedarf um 65%', 'Großwärmepumpen-Integration reduziert fossile Brennstoffe', 'Smarte Netzüberwachung zur Vermeidung von Rohrnetzverlusten'],
    },
    relatedServices: ['Plant Construction', 'Consulting & Engineering', 'Digital Industrial Solutions', 'Insulation'],
    imageUrl: 'https://picsum.photos/seed/water-utility/1200/800',
  },
];
