export interface DigitalPipelineNode {
  id: string;
  stepNumber: string;
  name: { en: string; de: string };
  shortDesc: { en: string; de: string };
  technicalSpecs: { en: string; de: string };
  dataProtocols: string[];
  sampleMetrics: { label: { en: string; de: string }; value: string }[];
  iconName: string;
}

export const digitalPipelineNodes: DigitalPipelineNode[] = [
  {
    id: 'asset',
    stepNumber: '01',
    name: { en: 'ASSET', de: 'ANLAGE' },
    shortDesc: {
      en: 'Physical industrial plant equipment — boilers, reactors, turbines, pumps, heat exchangers, and piping loops.',
      de: 'Physische Industrieanlage — Kessel, Reaktoren, Turbinen, Pumpen, Wärmetauscher und Rohrleitungssysteme.',
    },
    technicalSpecs: {
      en: 'Primary operational equipment generating mechanical vibration, thermal flux, pressure gradients, and mass flow.',
      de: 'Primäre Betriebsanlagen, die Schwingungen, Wärmeströme, Druckgradienten und Massenströme erzeugen.',
    },
    dataProtocols: ['Physical Equipment', 'Mechanical Wear Points', 'Acoustic Signatures'],
    sampleMetrics: [
      { label: { en: 'Operating Hours', de: 'Betriebsstunden' }, value: '8,760 hrs/yr' },
      { label: { en: 'Asset Value Class', de: 'Anlagenwertklasse' }, value: 'Tier-1 Critical' },
    ],
    iconName: 'Factory',
  },
  {
    id: 'sensor',
    stepNumber: '02',
    name: { en: 'SENSOR', de: 'SENSOR' },
    shortDesc: {
      en: 'Industrial instrumentation — tri-axial accelerometers, RTD temperature probes, ultrasonic flowmeters, and acoustic emissions.',
      de: 'Industrielle Messtechnik — Triaxial-Beschleunigungssensoren, Pt100-Temperaturfühler, Ultraschall-Durchflussmesser.',
    },
    technicalSpecs: {
      en: 'ATEX Zone 0/1 certified WirelessHART and IO-Link edge sensors sampling at up to 20kHz for high-fidelity vibration spectra.',
      de: 'ATEX Zone 0/1 zertifizierte WirelessHART & IO-Link Sensoren mit Abtastraten bis 20kHz für präzise Schwingungsspektren.',
    },
    dataProtocols: ['WirelessHART', 'IO-Link', '4-20mA HART', 'Modbus RTU'],
    sampleMetrics: [
      { label: { en: 'Sampling Frequency', de: 'Abtastfrequenz' }, value: '20,000 Hz' },
      { label: { en: 'Battery Field Life', de: 'Sensor-Akkulaufzeit' }, value: '5+ Years' },
    ],
    iconName: 'Radio',
  },
  {
    id: 'data',
    stepNumber: '03',
    name: { en: 'DATA', de: 'DATEN' },
    shortDesc: {
      en: 'OT/IT edge gateways aggregating raw telemetry, filtering noise, and transmitting via secure industrial protocols.',
      de: 'OT/IT Edge-Gateways aggregieren Telemetriedaten, filtern Rauschen und übermitteln über sichere Industrieprotokolle.',
    },
    technicalSpecs: {
      en: 'Edge compute devices converting field bus signals to OPC UA / MQTT-SN with IEC 62443-4-2 hardware encryption.',
      de: 'Edge-Geräte zur Konvertierung von Feldbussignalen in OPC UA / MQTT-SN mit IEC 62443-4-2 Verschlüsselung.',
    },
    dataProtocols: ['OPC UA', 'MQTT-SN', 'PROFINET', 'EtherNet/IP'],
    sampleMetrics: [
      { label: { en: 'Data Throughput', de: 'Datendurchsatz' }, value: '1.2 GB/day' },
      { label: { en: 'Gateway Latency', de: 'Gateway-Latenz' }, value: '< 15 ms' },
    ],
    iconName: 'Database',
  },
  {
    id: 'analysis',
    stepNumber: '04',
    name: { en: 'ANALYSIS', de: 'ANALYSE' },
    shortDesc: {
      en: 'Physics-informed neural networks and fast Fourier transform (FFT) spectral analytics detecting early micro-faults.',
      de: 'Physikbasierte KI-Modelle und FFT-Spektralanalysen zur Früherkennung mikroskopischer Materialfehler.',
    },
    technicalSpecs: {
      en: 'Deterministic physics models merged with empirical machine learning to detect bearing spalling, impeller cavitation, and thermal degradation.',
      de: 'Deterministische Physikmodelle kombiniert mit Machine Learning zur Erkennung von Lagerschäden und Kavitation.',
    },
    dataProtocols: ['FFT Spectral Analysis', 'Physics Digital Twin', 'Anomaly Classifiers'],
    sampleMetrics: [
      { label: { en: 'Model Accuracy', de: 'Modellgenauigkeit' }, value: '99.4%' },
      { label: { en: 'False Positive Rate', de: 'Falschpositiv-Quote' }, value: '< 0.1%' },
    ],
    iconName: 'Cpu',
  },
  {
    id: 'insight',
    stepNumber: '05',
    name: { en: 'INSIGHT', de: 'ERKENNTNIS' },
    shortDesc: {
      en: 'Contextual operational intelligence — pinpointing Remaining Useful Life (RUL) and failure probability timelines.',
      de: 'Kontextualisierte operative Erkenntnisse — Bestimmung der Restnutzungsdauer (RUL) und Ausfallwahrscheinlichkeiten.',
    },
    technicalSpecs: {
      en: 'Automated root cause identification calculating specific component fatigue degradation and time-to-failure windows.',
      de: 'Automatisierte Ursachenerkennung zur Berechnung konkreter Bauteilermüdungen und Zeitfenstern bis zum Ausfall.',
    },
    dataProtocols: ['RUL Analytics', 'Root Cause Classifiers', 'Thermal Fatigue Index'],
    sampleMetrics: [
      { label: { en: 'Failure Horizon Notice', de: 'Vorwarnzeit Ausfall' }, value: '21 Days' },
      { label: { en: 'Confidence Score', de: 'Konfidenzwert' }, value: '96.8%' },
    ],
    iconName: 'Lightbulb',
  },
  {
    id: 'decision',
    stepNumber: '06',
    name: { en: 'DECISION', de: 'ENTSCHEIDUNG' },
    shortDesc: {
      en: 'Risk-weighted decision matrix balancing maintenance cost, production schedule disruption, and spare part lead time.',
      de: 'Risikogewichtete Matrix zur Abwägung von Reparaturkosten, Produktionsplänen und Ersatzteil-Lieferzeiten.',
    },
    technicalSpecs: {
      en: 'Integration with SAP PM / Maximo generating automated work-order proposals with recommended maintenance windows.',
      de: 'Integration in SAP PM / Maximo zur automatischen Erstellung von Arbeitsaufträgen mit empfohlenen Wartungsfenstern.',
    },
    dataProtocols: ['SAP PM API', 'CMMS Dispatcher', 'OPEX Risk Calculator'],
    sampleMetrics: [
      { label: { en: 'Decision Lead Time', de: 'Entscheidungs-Vorlauf' }, value: '4 Hours' },
      { label: { en: 'Spare Part Reserved', de: 'Ersatzteil reserviert' }, value: 'Automated' },
    ],
    iconName: 'GitMerge',
  },
  {
    id: 'action',
    stepNumber: '07',
    name: { en: 'ACTION', de: 'MASSNAHME' },
    shortDesc: {
      en: 'Field technician deployment with AR tablet guidance, precise torque specs, and digital work clearance approvals.',
      de: 'Einsatz von Servicetechnikern mit AR-Tablets, präzisen Drehmomentangaben und digitalen Freigaben.',
    },
    technicalSpecs: {
      en: 'Guided step-by-step mobile intervention with AR spatial overlay, safety permit-to-work verification, and digital torque wrench logging.',
      de: 'Schritt-für-Schritt geführter Einsatz mit AR-Visualisierung, Erlaubnisscheinprüfung und digitaler Drehmomentdokumentation.',
    },
    dataProtocols: ['AR Mobile Guide', 'Permit to Work (PTW)', 'Digital Torque Logger'],
    sampleMetrics: [
      { label: { en: 'Mean Time to Repair (MTTR)', de: 'Mittlere Reparaturdauer' }, value: '-38%' },
      { label: { en: 'First-Time Fix Rate', de: 'Erstbehebungsquote' }, value: '98.2%' },
    ],
    iconName: 'CheckCircle',
  },
  {
    id: 'improved-performance',
    stepNumber: '08',
    name: { en: 'IMPROVED PERFORMANCE', de: 'BESSERE PERFORMANCE' },
    shortDesc: {
      en: 'Measurable progress — zero unplanned outages, extended asset lifespan, and lower carbon footprint.',
      de: 'Messbarer Fortschritt — null ungeplante Ausfälle, verlängerte Lebensdauer und reduzierte CO2-Emissionen.',
    },
    technicalSpecs: {
      en: 'Continuous OEE feedback loop closing the OT/IT cycle to continuously refine baseline algorithms.',
      de: 'Kontinuierliche OEE-Rückkopplung zur fortlaufenden Kalibrierung der Algorithmen.',
    },
    dataProtocols: ['OEE Analytics', 'Lifecycle Asset Return', 'Carbon Baseline Feed'],
    sampleMetrics: [
      { label: { en: 'Overall OEE Gain', de: 'Gesamte OEE-Steigerung' }, value: '+13.6%' },
      { label: { en: 'Avoided Failure Loss', de: 'Vermiedener Ausfallschaden' }, value: '€850,000' },
    ],
    iconName: 'TrendingUp',
  },
];
