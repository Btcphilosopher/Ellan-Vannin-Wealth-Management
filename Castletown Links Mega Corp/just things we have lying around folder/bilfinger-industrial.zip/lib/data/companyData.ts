export interface CompanyTimelineEvent {
  year: string;
  title: { en: string; de: string };
  description: { en: string; de: string };
}

export interface LeadershipMember {
  name: string;
  role: { en: string; de: string };
  bio: { en: string; de: string };
  imageUrl: string;
}

export interface LocationHub {
  id: string;
  city: string;
  country: string;
  address: string;
  coordinates: [number, number];
  hubType: { en: string; de: string };
  headcount: string;
  specializations: string[];
}

export const companyTimeline: CompanyTimelineEvent[] = [
  {
    year: '1880',
    title: { en: 'Foundation of European Engineering Legacy', de: 'Gründung europäischer Ingenieurstradition' },
    description: { en: 'Pioneering heavy civil and industrial construction in Germany, laying the foundation for modern process plant engineering.', de: 'Pionierarbeit im Industrie- und Bauwesen in Deutschland als Grundstein für modernes Prozess-Engineering.' },
  },
  {
    year: '1960',
    title: { en: 'Expansion into Chemical & Energy Maintenance', de: 'Expansion in Chemie- & Energieinstandhaltung' },
    description: { en: 'Establishing specialized maintenance partnerships across Rhine-Neckar chemical complexes and thermal power stations.', de: 'Etablierung spezialisierter Instandhaltungspartnerschaften in Chemieparks und Kraftwerken im Rhein-Neckar-Raum.' },
  },
  {
    year: '2000',
    title: { en: 'Standardization of the Bilfinger Maintenance Concept (BMC)', de: 'Standardisierung des Bilfinger Maintenance Concepts (BMC)' },
    description: { en: 'Codifying risk-based asset maintenance standards to deliver verifiable OEE improvements across European process industries.', de: 'Standardisierung risikobasierter Instandhaltung zur messbaren Steigerung der Gesamtanlageneffizienz in Europa.' },
  },
  {
    year: '2020',
    title: { en: 'Launch of Digital OT/IT & Decarbonization Division', de: 'Sparte Digitale OT/IT & Dekarbonisierung' },
    description: { en: 'Integrating IIoT edge sensors, physics digital twins, green hydrogen, and carbon capture engineering into core plant services.', de: 'Integration von IIoT, Digitalen Zwillingen, Wasserstoff- & Carbon-Capture-Technologien in das Leistungsportfolio.' },
  },
  {
    year: '2026',
    title: { en: 'Next-Generation Industrial Performance Leader', de: 'Führend bei zukunftsfähiger Industrial Performance' },
    description: { en: 'Over 30,000 engineering specialists driving efficiency, safety, and energy transition for global process industries.', de: 'Über 30.000 Fachkräfte gestalten Effizienz, Sicherheit und Energiewende für die weltweite Prozessindustrie.' },
  },
];

export const leadershipTeam: LeadershipMember[] = [
  {
    name: 'Dr. Thomas Lindemann',
    role: { en: 'Chief Executive Officer', de: 'Vorsitzender des Vorstands (CEO)' },
    bio: { en: 'Over 25 years of leadership in international process engineering, EPC contracting, and industrial digital transformation.', de: 'Über 25 Jahre Führungserfahrung im internationalen Prozess-Engineering, EPCM-Anlagenbau und der digitalen Transformation.' },
    imageUrl: 'https://picsum.photos/seed/leader-1/400/500',
  },
  {
    name: 'Dr. Karen Vaneck',
    role: { en: 'Chief Operating Officer — Process Services', de: 'Vorstand Operatives Geschäft (COO)' },
    bio: { en: 'Former Vice President of Global Refinery Maintenance with deep expertise in turnaround execution and HSEQ safety culture.', de: 'Ehemalige Vizepräsidentin für globale Raffinerie-Instandhaltung mit Expertise in Stillstandsmanagement und HSEQ-Kultur.' },
    imageUrl: 'https://picsum.photos/seed/leader-2/400/500',
  },
  {
    name: 'Markus von Berg',
    role: { en: 'Chief Technology Officer — Digital & Energy Transition', de: 'Vorstand Technologie & Digitalisierung (CTO)' },
    bio: { en: 'Pioneer in OT cybersecurity, IIoT edge architectures, and green hydrogen balance-of-plant design.', de: 'Pionier für OT-Cybersicherheit, IIoT-Edge-Architekturen und Wasserstoff-Anlagenbau.' },
    imageUrl: 'https://picsum.photos/seed/leader-3/400/500',
  },
];

export const globalLocations: LocationHub[] = [
  {
    id: 'mannheim-hq',
    city: 'Mannheim',
    country: 'Germany',
    address: 'Oskar-Meixner-Straße 1, 68163 Mannheim',
    coordinates: [49.4875, 8.4660],
    hubType: { en: 'Global Headquarters & Engineering Hub', de: 'Konzernzentrale & Haupt-Engineering-Center' },
    headcount: '4,200 Specialists',
    specializations: ['Process Design', 'Plant Construction', 'BMC Maintenance', 'H2 Engineering'],
  },
  {
    id: 'frankfurt-tech',
    city: 'Frankfurt / Höchst',
    country: 'Germany',
    address: 'Industriepark Höchst, Geb. K801, 65926 Frankfurt',
    coordinates: [50.1109, 8.6821],
    hubType: { en: 'Chemicals & Pharma Innovation Center', de: 'Technologiezentrum Chemie & Pharma' },
    headcount: '2,800 Specialists',
    specializations: ['cGMP Clean Utilities', 'Pinch Analysis', 'Advanced Process Control'],
  },
  {
    id: 'rotterdam-port',
    city: 'Rotterdam',
    country: 'Netherlands',
    address: 'Havennummer 3210, Botlekweg, 3197 KA Botlek',
    coordinates: [51.9244, 4.4777],
    hubType: { en: 'Turnaround Excellence Center', de: 'Kompetenzzentrum Stillstandsmanagement' },
    headcount: '3,100 Specialists',
    specializations: ['Turnarounds (TAR-EM)', 'Refinery Maintenance', 'Offshore Skids'],
  },
  {
    id: 'vienna-hub',
    city: 'Vienna',
    country: 'Austria',
    address: 'Simmeringer Hauptstraße 24, 1110 Wien',
    coordinates: [48.2082, 16.3738],
    hubType: { en: 'Central & Eastern Europe Engineering Hub', de: 'Engineering Hub Mittel- & Osteuropa' },
    headcount: '1,900 Specialists',
    specializations: ['Substation Automation', 'District Energy', 'Electrical & Instrumentation'],
  },
  {
    id: 'london-uk',
    city: 'London / Aberdeen',
    country: 'United Kingdom',
    address: '100 Bishopsgate, London EC2N 4AG',
    coordinates: [51.5074, -0.1278],
    hubType: { en: 'North Sea Energy & Decarbonization Hub', de: 'Zentrum Energiewende & Nordsee Offshore' },
    headcount: '2,400 Specialists',
    specializations: ['Offshore Electrification', 'Carbon Capture (CCS)', 'Rope Access'],
  },
  {
    id: 'houston-us',
    city: 'Houston',
    country: 'United States',
    address: '1200 Smith St, Houston, TX 77002',
    coordinates: [29.7604, -95.3698],
    hubType: { en: 'Americas Operations Headquarters', de: 'Zentrale Nordamerika' },
    headcount: '3,800 Specialists',
    specializations: ['Gulf Coast Refining', 'LNG Infrastructure', 'Heavy Rigging'],
  },
];
