export type Language = 'en' | 'de';

export interface Translations {
  nav: {
    home: string;
    services: string;
    industries: string;
    solutions: string;
    projects: string;
    digital: string;
    sustainability: string;
    about: string;
    careers: string;
    contact: string;
    locations: string;
    news: string;
    investors: string;
    supplierPortal: string;
    search: string;
  };
  hero: {
    label: string;
    title: string;
    subtitle: string;
    body: string;
    primaryCta: string;
    secondaryCta: string;
    statusLabel: string;
    coordinateLabel: string;
  };
  performance: {
    statement: string;
    substatement: string;
    efficiencyTitle: string;
    efficiencyDesc: string;
    reliabilityTitle: string;
    reliabilityDesc: string;
    sustainabilityTitle: string;
    sustainabilityDesc: string;
  };
  services: {
    title: string;
    subtitle: string;
    explorerTitle: string;
    searchPlaceholder: string;
    viewDetails: string;
    relatedIndustries: string;
    caseStudyTag: string;
  };
  industries: {
    title: string;
    subtitle: string;
    challenges: string;
    capabilities: string;
    syntheticBadge: string;
  };
  projects: {
    title: string;
    subtitle: string;
    allIndustries: string;
    allServices: string;
    allRegions: string;
    syntheticBadge: string;
    challenge: string;
    solution: string;
    outcome: string;
    timeline: string;
    disciplines: string;
  };
  digital: {
    title: string;
    subtitle: string;
    tagline: string;
    diagramTitle: string;
    diagramSubtitle: string;
    nodeDetailsTitle: string;
  };
  sustainability: {
    title: string;
    subtitle: string;
    simulatorTitle: string;
    simulatorDesc: string;
    syntheticDisclaimer: string;
    energyEfficiency: string;
    heatRecovery: string;
    maintenanceStrategy: string;
    electrificationLevel: string;
    productionLoad: string;
    operatingHours: string;
    outputs: {
      energyUse: string;
      co2Emissions: string;
      downtime: string;
      opexIndex: string;
    };
  };
  about: {
    title: string;
    subtitle: string;
    whoWeAre: string;
    approach: string;
    history: string;
    leadership: string;
    locations: string;
    hubsTitle: string;
    leadershipTitle: string;
  };
  careers: {
    title: string;
    subtitle: string;
    searchJobs: string;
    allCountries: string;
    allDisciplines: string;
    applyNow: string;
  };
  contact: {
    title: string;
    subtitle: string;
    categoryLabel: string;
    nameLabel: string;
    emailLabel: string;
    companyLabel: string;
    messageLabel: string;
    fileUploadLabel: string;
    consentText: string;
    submitButton: string;
    successTitle: string;
    successBody: string;
    mockDisclaimer: string;
  };
  search: {
    placeholder: string;
    noResults: string;
    categories: string;
    recentSearches: string;
  };
  footer: {
    disclaimer: string;
    copyright: string;
    privacy: string;
    imprint: string;
    security: string;
  };
}

export const dictionary: Record<Language, Translations> = {
  en: {
    nav: {
      home: 'Home',
      services: 'Services',
      industries: 'Industries',
      solutions: 'Solutions',
      projects: 'Projects',
      digital: 'Digital',
      sustainability: 'Sustainability',
      about: 'About',
      careers: 'Careers',
      contact: 'Contact',
      locations: 'Locations',
      news: 'News',
      investors: 'Investors',
      supplierPortal: 'Supplier Portal',
      search: 'Search',
    },
    hero: {
      label: 'INDUSTRIAL PERFORMANCE / 01',
      title: 'ENGINEERING WHAT MATTERS',
      subtitle: 'Efficiency, reliability and sustainability for the industries that keep the world moving.',
      body: 'From engineering and installation to maintenance and asset performance, we turn industrial complexity into measurable progress.',
      primaryCta: 'Explore our services',
      secondaryCta: 'Discuss your challenge',
      statusLabel: 'SYSTEM_STATUS: OPERATIONAL 100%',
      coordinateLabel: 'GRID_LOC: 49.4875° N, 8.4660° E [MANNHEIM HQ HUB]',
    },
    performance: {
      statement: 'Your performance is the point.',
      substatement: 'Our expertise is how we get there.',
      efficiencyTitle: 'EFFICIENCY',
      efficiencyDesc: 'Optimizing throughput, thermodynamic yields, and energy consumption across entire process plants.',
      reliabilityTitle: 'RELIABILITY',
      reliabilityDesc: 'Predictive engineering, turnaround excellence, and zero-unplanned-downtime maintenance programs.',
      sustainabilityTitle: 'SUSTAINABILITY',
      sustainabilityDesc: 'Decarbonization roadmaps, industrial electrification, heat integration, and hydrogen facility builds.',
    },
    services: {
      title: 'INDUSTRIAL SERVICES',
      subtitle: 'End-to-end engineering and lifecycle asset management for process industries.',
      explorerTitle: 'Service Explorer',
      searchPlaceholder: 'Filter services by domain or keyword...',
      viewDetails: 'Examine Technical Scope',
      relatedIndustries: 'Core Industries Served',
      caseStudyTag: 'Demonstration Project',
    },
    industries: {
      title: 'INDUSTRIES WE SERVE',
      subtitle: 'Tailored process engineering solutions for high-consequence industrial sectors.',
      challenges: 'Sector Challenges',
      capabilities: 'Core Technical Capabilities',
      syntheticBadge: 'SYNTHETIC PROJECT CONCEPT',
    },
    projects: {
      title: 'PROJECT PORTFOLIO',
      subtitle: 'Demonstrating engineering precision across complex plant lifecycles.',
      allIndustries: 'All Industries',
      allServices: 'All Services',
      allRegions: 'All Regions',
      syntheticBadge: 'SYNTHETIC PROJECT CONCEPT',
      challenge: 'Challenge & Context',
      solution: 'Engineering Solution',
      outcome: 'Measurable Outcome',
      timeline: 'Execution Timeline',
      disciplines: 'Engineering Disciplines',
    },
    digital: {
      title: 'DIGITAL INDUSTRIAL SOLUTIONS',
      subtitle: 'Practical OT/IT engineering — converting plant telemetry into operational action.',
      tagline: 'No vague AI hype. Real sensor-to-cloud infrastructure and predictive asset performance.',
      diagramTitle: 'Operational Data Pipeline Architecture',
      diagramSubtitle: 'Click any node to inspect sensor inputs, processing layers, and decision controls.',
      nodeDetailsTitle: 'Technical Specification & Implementation',
    },
    sustainability: {
      title: 'SUSTAINABLE PLANT ENGINEERING',
      subtitle: 'Making industrial performance cleaner, electrified, and resource-efficient.',
      simulatorTitle: 'Synthetic Facility Scenario Model',
      simulatorDesc: 'Simulate the impact of energy recovery, maintenance optimization, and electrification on operational metrics.',
      syntheticDisclaimer: 'NOTE: All calculations represent a simulated demonstration facility model for analytical illustration.',
      energyEfficiency: 'Energy Efficiency Level',
      heatRecovery: 'Waste Heat Integration',
      maintenanceStrategy: 'Maintenance Strategy Mode',
      electrificationLevel: 'Process Electrification Share',
      productionLoad: 'Facility Operating Capacity',
      operatingHours: 'Annual Operating Hours',
      outputs: {
        energyUse: 'Simulated Energy Consumption Index',
        co2Emissions: 'Estimated Annual CO₂ Emissions',
        downtime: 'Estimated Unplanned Downtime',
        opexIndex: 'Relative Operating Cost Index (OPEX)',
      },
    },
    about: {
      title: 'ABOUT BILFINGER INDUSTRIAL',
      subtitle: 'Decades of process engineering heritage, delivered with modern digital precision.',
      whoWeAre: 'Who We Are',
      approach: 'Our Operational Approach',
      history: 'Engineering Heritage',
      leadership: 'Executive Leadership',
      locations: 'Global Footprint & Hubs',
      hubsTitle: 'Global Engineering & Operational Network',
      leadershipTitle: 'Executive Leadership & Governance',
    },
    careers: {
      title: 'CAREERS AT BILFINGER INDUSTRIAL',
      subtitle: 'Build the industries of tomorrow alongside world-class process engineers and asset specialists.',
      searchJobs: 'Search Open Engineering & Field Roles',
      allCountries: 'All Countries',
      allDisciplines: 'All Disciplines',
      applyNow: 'Submit Application (Demo)',
    },
    contact: {
      title: 'DISCUSS YOUR INDUSTRIAL CHALLENGE',
      subtitle: 'Connect directly with our engineering teams for project inquiries, maintenance audits, or digital transformation.',
      categoryLabel: 'Inquiry Category',
      nameLabel: 'Full Name / Title',
      emailLabel: 'Business Email Address',
      companyLabel: 'Company / Facility Name',
      messageLabel: 'Project Scope or Technical Requirement',
      fileUploadLabel: 'Attach Technical Specs / P&ID (Max 10MB)',
      consentText: 'I agree to the processing of technical inquiry data in according with industrial privacy standards.',
      submitButton: 'Transmit Inquiry',
      successTitle: 'Inquiry Transmitted Successfully',
      successBody: 'Your inquiry reference #IND-2026-8941 has been logged in our mock local database.',
      mockDisclaimer: 'DEMONSTRATION SYSTEM: Form data is handled locally and not sent to external servers.',
    },
    search: {
      placeholder: 'Search services, industries, synthetic projects, terms...',
      noResults: 'No matching technical documentation found.',
      categories: 'Categories',
      recentSearches: 'Recent Searches',
    },
    footer: {
      disclaimer: 'Bilfinger INDUSTRIAL is an independent demonstration web platform inspired by European industrial engineering standards. This site is not affiliated with, sponsored by, or endorsed by Bilfinger SE.',
      copyright: '© 2026 Bilfinger INDUSTRIAL. All synthetic concepts & original materials reserved.',
      privacy: 'Data Privacy Policy',
      imprint: 'Imprint / Legal Notice',
      security: 'Industrial HSEQ Standards',
    },
  },
  de: {
    nav: {
      home: 'Startseite',
      services: 'Leistungen',
      industries: 'Branchen',
      solutions: 'Lösungen',
      projects: 'Projekte',
      digital: 'Digital',
      sustainability: 'Nachhaltigkeit',
      about: 'Über uns',
      careers: 'Karriere',
      contact: 'Kontakt',
      locations: 'Standorte',
      news: 'Aktuelles',
      investors: 'Investoren',
      supplierPortal: 'Lieferantenportal',
      search: 'Suche',
    },
    hero: {
      label: 'INDUSTRIELLE PERFORMANCE / 01',
      title: 'WAS ZÄHLT, INGENIEURTECHNISCH UMSETZEN',
      subtitle: 'Effizienz, Zuverlässigkeit und Nachhaltigkeit für die Industrien, die unsere Welt bewegen.',
      body: 'Von Engineering und Installation bis zu Instandhaltung und Anlagenperformance machen wir industrielle Komplexität messbar besser.',
      primaryCta: 'Unsere Leistungen entdecken',
      secondaryCta: 'Herausforderung besprechen',
      statusLabel: 'SYSTEM_STATUS: BETRIEBSBEREIT 100%',
      coordinateLabel: 'GRID_LOC: 49.4875° N, 8.4660° E [MANNHEIM ZENTRALE HUB]',
    },
    performance: {
      statement: 'Ihre Performance steht im Mittelpunkt.',
      substatement: 'Unsere Expertise bringt Sie dorthin.',
      efficiencyTitle: 'EFFIZIENZ',
      efficiencyDesc: 'Optimierung von Durchsatz, thermodynamischen Erträgen und Energieverbrauch in gesamten Prozessanlagen.',
      reliabilityTitle: 'ZUVERLÄSSIGKEIT',
      reliabilityDesc: 'Vorausschauendes Engineering, Exzellenz bei Anlagenstillständen und Instandhaltungskonzepte für maximale Anlagenverfügbarkeit.',
      sustainabilityTitle: 'NACHHALTIGKEIT',
      sustainabilityDesc: 'Dekarbonisierungs-Roadmaps, industrielle Elektrifizierung, Abwärmenutzung und Bau von Wasserstoffanlagen.',
    },
    services: {
      title: 'INDUSTRIELLE DIENSTLEISTUNGEN',
      subtitle: 'Ganzheitliches Engineering und Asset-Lifecycle-Management für die Prozessindustrie.',
      explorerTitle: 'Leistungs-Explorer',
      searchPlaceholder: 'Leistungen nach Domain oder Stichwort filtern...',
      viewDetails: 'Technische Details anzeigen',
      relatedIndustries: 'Kernbranchen',
      caseStudyTag: 'Demonstrationsprojekt',
    },
    industries: {
      title: 'UNSERE BRANCHEN',
      subtitle: 'Maßgeschneiderte Prozess-Engineering-Lösungen für anspruchsvolle Industriezweige.',
      challenges: 'Branchenspezifische Herausforderungen',
      capabilities: 'Technische Kernkompetenzen',
      syntheticBadge: 'FIKTIVES PROJEKTKONZEPT',
    },
    projects: {
      title: 'PROJEKTPORTFOLIO',
      subtitle: 'Präzisionstechnik in komplexen Anlagenlebenszyklen anschaulich belegt.',
      allIndustries: 'Alle Branchen',
      allServices: 'Alle Leistungen',
      allRegions: 'Alle Regionen',
      syntheticBadge: 'FIKTIVES PROJEKTKONZEPT',
      challenge: 'Herausforderung & Kontext',
      solution: 'Ingenieurtechnische Lösung',
      outcome: 'Messbares Ergebnis',
      timeline: 'Ausführungs-Zeitplan',
      disciplines: 'Ingenieurdisziplinen',
    },
    digital: {
      title: 'DIGITALE INDUSTRIELÖSUNGEN',
      subtitle: 'Praktische OT/IT-Ingenieurtechnik — Telemetriedaten in operative Maßnahmen übersetzen.',
      tagline: 'Kein vager AI-Hype. Echte Sensor-to-Cloud Infrastruktur und vorausschauende Anlagenperformance.',
      diagramTitle: 'Architektur der operativen Datenpipeline',
      diagramSubtitle: 'Klicken Sie auf einen Knoten, um Sensoreingaben, Verarbeitungs-Layers und Entscheidungslogik einzusehen.',
      nodeDetailsTitle: 'Technische Spezifikation & Implementierung',
    },
    sustainability: {
      title: 'NACHHALTIGER ANLAGENBAU',
      subtitle: 'Industrielle Performance nachhaltiger, elektrifizierter und ressourcenschonender gestalten.',
      simulatorTitle: 'Fiktives Anlagen-Szenariomodell',
      simulatorDesc: 'Simulieren Sie den Einfluss von Abwärmenutzung, Instandhaltungsstrategien und Elektrifizierung auf betriebliche Kennzahlen.',
      syntheticDisclaimer: 'HINWEIS: Alle Berechnungen stellen ein modelliertes Demonstrationsmodell zur analytischen Veranschaulichung dar.',
      energyEfficiency: 'Energieeffizienz-Grad',
      heatRecovery: 'Abwärmeintegration',
      maintenanceStrategy: 'Instandhaltungsstrategie',
      electrificationLevel: 'Elektrifizierungsanteil',
      productionLoad: 'Anlagenauslastung',
      operatingHours: 'Jährliche Betriebsstunden',
      outputs: {
        energyUse: 'Simulierter Energieverbrauchsindex',
        co2Emissions: 'Geschätzte jährliche CO₂-Emissionen',
        downtime: 'Geschätzte ungeplante Ausfallzeit',
        opexIndex: 'Relativer Betriebskostenindex (OPEX)',
      },
    },
    about: {
      title: 'ÜBER BILFINGER INDUSTRIAL',
      subtitle: 'Jahrzehntelange Erfahrung im Prozess-Engineering, kombiniert mit moderner digitaler Präzision.',
      whoWeAre: 'Wer wir sind',
      approach: 'Unser operativer Ansatz',
      history: 'Ingenieurhistorie',
      leadership: 'Unternehmensführung',
      locations: 'Globale Präsenz & Standorte',
      hubsTitle: 'Globales Engineering- & Operationsnetzwerk',
      leadershipTitle: 'Unternehmensführung & Governance',
    },
    careers: {
      title: 'KARRIERE BEI BILFINGER INDUSTRIAL',
      subtitle: 'Gestalten Sie die Industrien von morgen gemeinsam mit erstklassigen Prozessingenieuren und Anlagenspezialisten.',
      searchJobs: 'Ingenieur- & Feldpositionen suchen',
      allCountries: 'Alle Länder',
      allDisciplines: 'Alle Disziplinen',
      applyNow: 'Bewerbung einreichen (Demo)',
    },
    contact: {
      title: 'HERAUSFORDERUNG BESPRECHEN',
      subtitle: 'Treten Sie direkt mit unseren Ingenieurteams in Kontakt für Projektanfragen, Instandhaltungsaudits oder digitale Lösungen.',
      categoryLabel: 'Anfragekategorie',
      nameLabel: 'Vollständiger Name / Titel',
      emailLabel: 'Geschäftliche E-Mail-Adresse',
      companyLabel: 'Unternehmen / Anlagenstandort',
      messageLabel: 'Projektspezifikation oder technische Anforderungen',
      fileUploadLabel: 'Technische Dokumente / P&ID anhängen (Max 10MB)',
      consentText: 'Ich stimme der Verarbeitung meiner Anfragedaten gemäß den industriellen Datenschutzstandards zu.',
      submitButton: 'Anfrage übermitteln',
      successTitle: 'Anfrage erfolgreich übermittelt',
      successBody: 'Ihre Anfragenummer #IND-2026-8941 wurde in unserer lokalen Datenbank protokolliert.',
      mockDisclaimer: 'DEMONSTRATIONS-SYSTEM: Formulardaten werden lokal verarbeitet und nicht an externe Server übertragen.',
    },
    search: {
      placeholder: 'Leistungen, Branchen, fiktive Projekte, Begriffe suchen...',
      noResults: 'Keine passenden technischen Dokumente gefunden.',
      categories: 'Kategorien',
      recentSearches: 'Kürzliche Suchanfragen',
    },
    footer: {
      disclaimer: 'Bilfinger INDUSTRIAL ist eine unabhängige Demonstrationsplattform auf Basis europäischer Industrie-Engineering-Standards. Diese Website steht in keiner geschäftlichen Verbindung zu oder Unterstützung durch die Bilfinger SE.',
      copyright: '© 2026 Bilfinger INDUSTRIAL. Alle fiktiven Konzepte & Materialien vorbehalten.',
      privacy: 'Datenschutzrichtlinie',
      imprint: 'Impressum / Rechtliche Hinweise',
      security: 'Industrielle HSEQ-Standards',
    },
  },
};
