'use client';

import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language, dictionary, Translations } from './translations';

interface LanguageContextType {
  lang: Language;
  setLang: (lang: Language) => void;
  t: Translations;
  getRoute: (enPath: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const routeMap: Record<string, { en: string; de: string }> = {
  '/': { en: '/', de: '/' },
  '/services': { en: '/services', de: '/leistungen' },
  '/industries': { en: '/industries', de: '/branchen' },
  '/solutions': { en: '/solutions', de: '/loesungen' },
  '/projects': { en: '/projects', de: '/projekte' },
  '/digital': { en: '/digital', de: '/digital' },
  '/sustainability': { en: '/sustainability', de: '/nachhaltigkeit' },
  '/about': { en: '/about', de: '/ueber-uns' },
  '/careers': { en: '/careers', de: '/karriere' },
  '/contact': { en: '/contact', de: '/kontakt' },
  '/locations': { en: '/locations', de: '/standorte' },
  '/news': { en: '/news', de: '/aktuelles' },
  '/investors': { en: '/investors', de: '/investoren' },
  '/supplier-portal': { en: '/supplier-portal', de: '/lieferantenportal' },
};

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [lang, setLangState] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      const urlLang = params.get('lang');
      if (urlLang === 'de' || urlLang === 'en') {
        return urlLang;
      }
      const saved = localStorage.getItem('bilfinger_lang');
      if (saved === 'de' || saved === 'en') {
        return saved;
      }
    }
    return 'en';
  });

  const setLang = (newLang: Language) => {
    setLangState(newLang);
    if (typeof window !== 'undefined') {
      localStorage.setItem('bilfinger_lang', newLang);
      const url = new URL(window.location.href);
      url.searchParams.set('lang', newLang);
      window.history.replaceState({}, '', url.toString());
    }
  };

  const getRoute = (basePath: string) => {
    const entry = routeMap[basePath];
    if (!entry) return `${basePath}?lang=${lang}`;
    const mappedPath = lang === 'de' ? entry.de : entry.en;
    return `${mappedPath}?lang=${lang}`;
  };

  return (
    <LanguageContext.Provider value={{ lang, setLang, t: dictionary[lang], getRoute }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useTranslation = (): LanguageContextType => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useTranslation must be used within a LanguageProvider');
  }
  return context;
};
