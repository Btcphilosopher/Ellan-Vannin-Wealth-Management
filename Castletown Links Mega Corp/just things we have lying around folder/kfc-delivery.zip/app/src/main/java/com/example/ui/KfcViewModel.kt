package com.example.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.KfcRepository
import com.example.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

enum class AppScreen {
    SPLASH,
    HOME,
    LOCATION_INPUT,
    RESTAURANT_SELECTOR,
    MENU,
    PRODUCT_DETAIL,
    BUCKET_BUILDER,
    OFFERS,
    BASKET,
    CHECKOUT,
    CONFIRMATION,
    TRACKING,
    ACCOUNT,
    KITCHEN_DASHBOARD,
    ASSISTANT
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val isUser: Boolean,
    val text: String,
    val suggestedItem: CartItem? = null
)

class KfcViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = KfcRepository(application)

    // Expose static domain data directly to prevent repository leaks in the Composable UI
    val restaurants = repository.getRestaurants()
    val extraOptions = repository.extraOptions
    val products = repository.products

    // Screen navigation backstack
    private val backStack = mutableListOf<AppScreen>()
    var currentScreen by mutableStateOf(AppScreen.SPLASH)
        private set

    // App configurations / selections
    var isDeliveryMode by mutableStateOf(true)
    var postcodeQuery by mutableStateOf("")
    var selectedRestaurant by mutableStateOf<Restaurant?>(null)
    var searchQuery by mutableStateOf("")
    
    // Promo/Pricing Engine State
    var promoCodeText by mutableStateOf("")
    var activePromoCode by mutableStateOf("")
    var promoDiscountPence by mutableStateOf(0)
    var promoError by mutableStateOf<String?>(null)

    // Customizer state (for current product details screen)
    var activeCustomizerProduct by mutableStateOf<Product?>(null)
    var customizerChickenType by mutableStateOf(ChickenType.ORIGINAL)
    var customizerMealSize by mutableStateOf(MealSize.SOLO)
    val customizerSelectedExtras = mutableStateOf<List<ExtraOption>>(emptyList())
    var customizerSelectedDrink by mutableStateOf("Pepsi Max")
    var customizerSelectedSide by mutableStateOf("Fries")

    // Bucket Builder state (Visual builder state)
    var bucketBuilderPieces by mutableStateOf(8)
    var bucketBuilderWings by mutableStateOf(4)
    var bucketBuilderFillets by mutableStateOf(4)
    var bucketBuilderSidesCount by mutableStateOf(4)
    var bucketBuilderDrinksCount by mutableStateOf(4)
    var bucketBuilderSelectedSide by mutableStateOf("Fries")
    var bucketBuilderSelectedDrink by mutableStateOf("Pepsi Max")

    // Assistant state
    var assistantInput by mutableStateOf("")
    private val _assistantChatHistory = MutableStateFlow<List<ChatMessage>>(emptyList())
    val assistantChatHistory = _assistantChatHistory.asStateFlow()

    // Demo Mode default user profile
    var customerName by mutableStateOf("Demo Customer")
    var customerPhone by mutableStateOf("07123456789")
    var customerEmail by mutableStateOf("demo.colonel@kfc.co.uk")
    var deliveryAddress by mutableStateOf("10 Downing Street, Westminster")
    var deliveryInstructions by mutableStateOf("Leave with security at front desk, thank you.")

    // Last completed order ID for tracking
    var activeTrackingOrderId by mutableStateOf<String?>(null)

    // Reactive streams from database
    val cartItems = repository.cartItems.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val allOrders = repository.allOrders.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val favorites = repository.favorites.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    init {
        // Initialize with default demo location and restaurant
        postcodeQuery = "SW1A 1AA"
        selectedRestaurant = restaurants.first() // KFC London Central
        
        // Add welcome message to AI assistant
        _assistantChatHistory.value = listOf(
            ChatMessage(
                isUser = false,
                text = "Well hello there! I'm the Colonel's digital order assistant. Tell me what you're craving! Need enough chicken for four hungry people? Want something quick and spicy? Just say the word!"
            )
        )
    }

    // Navigation Methods
    fun navigateTo(screen: AppScreen) {
        if (currentScreen != screen) {
            backStack.add(currentScreen)
            currentScreen = screen
        }
    }

    fun navigateBack() {
        if (backStack.isNotEmpty()) {
            currentScreen = backStack.removeAt(backStack.size - 1)
        } else {
            // Default fallback
            currentScreen = AppScreen.HOME
        }
    }

    fun startDemoMode() {
        postcodeQuery = "SW1A 1AA"
        selectedRestaurant = restaurants.first { it.id == "rest_demo" }
        isDeliveryMode = true
    }

    // Cart operations
    fun addToCart(item: CartItem) {
        viewModelScope.launch {
            repository.addToCart(item)
        }
    }

    fun removeFromCart(id: String) {
        viewModelScope.launch {
            repository.removeFromCart(id)
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCart()
        }
    }

    fun toggleFavorite(productId: String) {
        viewModelScope.launch {
            repository.toggleFavorite(productId)
        }
    }

    // Customizer actions
    fun openProductCustomizer(product: Product) {
        activeCustomizerProduct = product
        customizerChickenType = if (product.spicyLevel > 0) ChickenType.ZINGER else ChickenType.ORIGINAL
        customizerMealSize = MealSize.SOLO
        customizerSelectedExtras.value = emptyList()
        customizerSelectedDrink = "Pepsi Max"
        customizerSelectedSide = "Fries"
        navigateTo(AppScreen.PRODUCT_DETAIL)
    }

    fun toggleCustomizerExtra(extra: ExtraOption) {
        val current = customizerSelectedExtras.value.toMutableList()
        if (current.any { it.id == extra.id }) {
            current.removeAll { it.id == extra.id }
        } else {
            current.add(extra)
        }
        customizerSelectedExtras.value = current
    }

    fun addCustomizedItemToCart() {
        val product = activeCustomizerProduct ?: return
        val item = CartItem(
            id = UUID.randomUUID().toString(),
            product = product,
            quantity = 1,
            chickenType = customizerChickenType,
            selectedMealSize = customizerMealSize,
            selectedExtras = customizerSelectedExtras.value,
            selectedDrink = customizerSelectedDrink,
            selectedSide = customizerSelectedSide
        )
        addToCart(item)
        navigateTo(AppScreen.MENU)
    }

    // Bucket Builder Actions
    fun updateBucketBuilderPieces(delta: Int) {
        bucketBuilderPieces = (bucketBuilderPieces + delta).coerceIn(4, 20)
    }

    fun updateBucketBuilderWings(delta: Int) {
        bucketBuilderWings = (bucketBuilderWings + delta).coerceIn(0, 12)
    }

    fun updateBucketBuilderFillets(delta: Int) {
        bucketBuilderFillets = (bucketBuilderFillets + delta).coerceIn(0, 12)
    }

    fun updateBucketBuilderSides(delta: Int) {
        bucketBuilderSidesCount = (bucketBuilderSidesCount + delta).coerceIn(1, 8)
    }

    fun updateBucketBuilderDrinks(delta: Int) {
        bucketBuilderDrinksCount = (bucketBuilderDrinksCount + delta).coerceIn(1, 8)
    }

    fun getBucketBuilderPricePence(): Int {
        val basePrice = 1499
        val chickenCost = (bucketBuilderPieces * 150) + (bucketBuilderWings * 60) + (bucketBuilderFillets * 100)
        val sidesCost = bucketBuilderSidesCount * 120
        val drinksCost = bucketBuilderDrinksCount * 100
        return basePrice + chickenCost + sidesCost + drinksCost
    }

    fun addCustomBucketToBasket() {
        val price = getBucketBuilderPricePence()
        val customBucketProduct = Product(
            id = "custom_bucket_${UUID.randomUUID()}",
            name = "Your Custom Bucket ($bucketBuilderPieces Pcs)",
            description = "$bucketBuilderPieces chicken pieces, $bucketBuilderWings hot wings, $bucketBuilderFillets mini fillets, $bucketBuilderSidesCount x $bucketBuilderSelectedSide, $bucketBuilderDrinksCount x $bucketBuilderSelectedDrink.",
            basePricePence = price,
            category = MenuCategory.BUCKETS,
            calories = 1200 + (bucketBuilderPieces * 180) + (bucketBuilderWings * 90) + (bucketBuilderFillets * 110)
        )
        val item = CartItem(
            id = UUID.randomUUID().toString(),
            product = customBucketProduct,
            quantity = 1,
            selectedMealSize = MealSize.SOLO,
            selectedDrink = bucketBuilderSelectedDrink,
            selectedSide = bucketBuilderSelectedSide
        )
        addToCart(item)
        navigateTo(AppScreen.MENU)
    }

    // Offers & Deals Direct Addition
    fun addOfferToBasket(title: String, description: String, pricePence: Int) {
        val offerProduct = Product(
            id = "offer_${UUID.randomUUID()}",
            name = title,
            description = description,
            basePricePence = pricePence,
            category = MenuCategory.BUCKETS,
            calories = 1450
        )
        val item = CartItem(
            id = UUID.randomUUID().toString(),
            product = offerProduct,
            quantity = 1
        )
        addToCart(item)
        navigateTo(AppScreen.MENU)
    }

    // Pricing calculations
    fun getSubtotalPence(): Int {
        return cartItems.value.sumOf { it.totalPricePence }
    }

    fun getDeliveryFeePence(): Int {
        return if (isDeliveryMode) {
            selectedRestaurant?.deliveryFeePence ?: 199
        } else {
            0
        }
    }

    fun getTotalPence(): Int {
        val subtotal = getSubtotalPence()
        val delivery = getDeliveryFeePence()
        return (subtotal + delivery - promoDiscountPence).coerceAtLeast(0)
    }

    fun applyPromoCode() {
        val code = promoCodeText.trim().uppercase()
        if (code.isEmpty()) {
            promoError = "Please enter a code"
            return
        }
        val subtotal = getSubtotalPence()
        val discount = repository.calculateDiscount(code, subtotal)
        if (discount > 0) {
            activePromoCode = code
            promoDiscountPence = discount
            promoError = null
        } else {
            promoError = "Invalid promo code. Try 'COLONEL5' or 'CRISPY20'"
            promoDiscountPence = 0
            activePromoCode = ""
        }
    }

    fun removePromoCode() {
        activePromoCode = ""
        promoDiscountPence = 0
        promoCodeText = ""
        promoError = null
    }

    // Place and simulate order
    fun checkoutAndPay() {
        val rest = selectedRestaurant ?: return
        val currentCart = cartItems.value
        if (currentCart.isEmpty()) return

        val orderId = "KFC-${(10000..99999).random()}"
        val serializedItems = repository.serializeCartItemsList(currentCart)
        
        val newOrder = Order(
            id = orderId,
            restaurantId = rest.id,
            restaurantName = rest.name,
            customerName = customerName,
            customerPhone = customerPhone,
            customerEmail = customerEmail,
            postcode = postcodeQuery,
            address = if (isDeliveryMode) deliveryAddress else "Collection from ${rest.name}",
            deliveryInstructions = if (isDeliveryMode) deliveryInstructions else "Will collect in person.",
            itemsJson = serializedItems,
            subtotalPence = getSubtotalPence(),
            deliveryFeePence = getDeliveryFeePence(),
            discountPence = promoDiscountPence,
            totalPence = getTotalPence(),
            state = OrderState.CONFIRMED,
            timestamp = System.currentTimeMillis(),
            courierName = listOf("Alex", "Sarah", "Michael", "Emily").random(),
            courierVehicle = listOf("E-Bike", "Scooter", "Electric Car").random(),
            routeProgress = 0.0f
        )

        viewModelScope.launch {
            repository.placeOrder(newOrder)
            activeTrackingOrderId = orderId
            removePromoCode()
            navigateTo(AppScreen.CONFIRMATION)
        }
    }

    fun deserializeOrderItems(itemsJson: String): List<CartItem> {
        return repository.deserializeCartItemsList(itemsJson)
    }

    // Manual operation control (for restaurant manager board)
    fun advanceOrderStateManually(orderId: String) {
        viewModelScope.launch {
            val orders = repository.allOrders.first()
            val order = orders.find { it.id == orderId } ?: return@launch
            val nextState = when (order.state) {
                OrderState.CONFIRMED -> OrderState.ACCEPTED
                OrderState.ACCEPTED -> OrderState.PREPARING
                OrderState.PREPARING -> OrderState.READY
                OrderState.READY -> OrderState.COLLECTED
                OrderState.COLLECTED -> OrderState.DELIVERING
                OrderState.DELIVERING -> OrderState.DELIVERED
                else -> order.state
            }
            repository.updateOrderState(orderId, nextState, if (nextState == OrderState.DELIVERING) 0.5f else 0.0f)
        }
    }

    fun cancelOrderManually(orderId: String) {
        viewModelScope.launch {
            repository.updateOrderState(orderId, OrderState.CANCELLED)
        }
    }

    // AI Order Assistant interactive dialog
    fun sendAssistantMessage() {
        val query = assistantInput.trim()
        if (query.isEmpty()) return

        // Append user query
        val userMsg = ChatMessage(isUser = true, text = query)
        _assistantChatHistory.value = _assistantChatHistory.value + userMsg
        assistantInput = ""

        viewModelScope.launch {
            delay(1000L) // natural delay for conversational feel
            val responseText: String
            var suggestion: CartItem? = null

            val lower = query.lowercase()
            when {
                lower.contains("four") || lower.contains("4 people") || lower.contains("crew") || lower.contains("family") -> {
                    val p = products.first { it.id == "b1" } // Family Bucket
                    responseText = "Ah, feeding the whole flock! I highly recommend our classic **Family Bucket**. It comes packed with 10 pieces of Original Recipe chicken, 4 fries, 2 sides, and a big bottle of Pepsi Max. It's plenty, mild, and absolute perfection for 4 people!"
                    suggestion = CartItem(
                        id = UUID.randomUUID().toString(),
                        product = p,
                        quantity = 1,
                        selectedDrink = "Pepsi Max",
                        selectedSide = "Fries"
                    )
                }
                lower.contains("spicy") || lower.contains("zinger") || lower.contains("fiery") -> {
                    val p = products.first { it.id == "bu2" } // Zinger Tower Burger
                    responseText = "Want to turn up the heat? My personal favorite is the **Zinger® Tower Burger Meal**! Spicy chicken breast fillet, crispy hash brown, cheese, salsa, and fiery mayo. Tap below to add this hot number directly!"
                    suggestion = CartItem(
                        id = UUID.randomUUID().toString(),
                        product = p,
                        quantity = 1,
                        selectedMealSize = MealSize.REGULAR,
                        selectedDrink = "Pepsi Max",
                        selectedSide = "Fries"
                    )
                }
                lower.contains("veggie") || lower.contains("vegetarian") || lower.contains("no meat") -> {
                    val p = products.first { it.id == "s1" } // Regular fries
                    responseText = "Keeping it fresh and green? While our signature chicken is our pride, our **Signature skin-on potato Fries**, BBQ Baked Beans, and Creamy Coleslaw are completely vegetarian! I suggest a couple of Large Fries to get you started!"
                    suggestion = CartItem(
                        id = UUID.randomUUID().toString(),
                        product = p,
                        quantity = 2
                    )
                }
                lower.contains("deal") || lower.contains("offer") || lower.contains("cheap") || lower.contains("discount") -> {
                    responseText = "Love a bargain, do we? Our **LUNCH BOX DEAL** is absolute gold! Get a Fillet Burger + Regular Fries + Soft Drink for only **£8.99**! You can view all our premium offers on our 'Offers' screen!"
                    val p = products.first { it.id == "bu3" } // Fillet Burger
                    suggestion = CartItem(
                        id = UUID.randomUUID().toString(),
                        product = p.copy(name = "Lunch Box Deal", basePricePence = 899, description = "Fillet Burger, Regular Fries, Pepsi Max"),
                        quantity = 1
                    )
                }
                lower.contains("wings") || lower.contains("wing") -> {
                    val p = products.first { it.id == "c2" } // 6 Hot wings
                    responseText = "Crispy, crunchy, fiery little devils! Our **6 Hot Wings** are exactly what you need. They are coated in a spicy crunch coating that will blow your socks off."
                    suggestion = CartItem(
                        id = UUID.randomUUID().toString(),
                        product = p,
                        quantity = 1
                    )
                }
                else -> {
                    responseText = "I hear you! If you want a classic recommendation, try our legendary **Fillet Burger Meal** - simple, crispy original recipe chicken with creamy pepper mayo. Or let me know if you want to feed a group or craving something spicy!"
                    val p = products.find { it.id == "bu3" } ?: products.first()
                    suggestion = CartItem(
                        id = UUID.randomUUID().toString(),
                        product = p,
                        quantity = 1,
                        selectedMealSize = MealSize.REGULAR
                    )
                }
            }

            _assistantChatHistory.value = _assistantChatHistory.value + ChatMessage(
                isUser = false,
                text = responseText,
                suggestedItem = suggestion
            )
        }
    }

    // Global filtering based on search query
    fun getFilteredProducts(): List<Product> {
        val q = searchQuery.trim().lowercase()
        if (q.isEmpty()) return products
        return products.filter {
            it.name.lowercase().contains(q) ||
            it.description.lowercase().contains(q) ||
            it.category.name.lowercase().contains(q) ||
            it.allergens.lowercase().contains(q)
        }
    }

    // Mock data structures for analytics (Restrained, realistic, highly accurate dashboard stats)
    fun getAnalyticsStats(): Map<String, String> {
        val totalRevenuePence = allOrders.value.filter { it.state == OrderState.DELIVERED }.sumOf { it.totalPence }
        val deliveredCount = allOrders.value.count { it.state == OrderState.DELIVERED }
        val avgBasket = if (deliveredCount > 0) totalRevenuePence / deliveredCount else 0
        return mapOf(
            "active_orders" to allOrders.value.count { it.state.isActive }.toString(),
            "completed_orders" to deliveredCount.toString(),
            "total_revenue" to "£${String.format("%.2f", totalRevenuePence / 100.0)}",
            "avg_basket" to "£${String.format("%.2f", avgBasket / 100.0)}",
            "prep_time" to "4.2 min",
            "delivery_time" to "22.5 min",
            "rating" to "4.8 ★"
        )
    }
}
