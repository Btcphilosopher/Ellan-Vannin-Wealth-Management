package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = KfcRed,
    onPrimary = KfcWhite,
    primaryContainer = KfcRedDark,
    onPrimaryContainer = KfcWhite,
    secondary = KfcGold,
    onSecondary = KfcBlack,
    background = KfcBlack,
    onBackground = KfcCream,
    surface = KfcCharcoal,
    onSurface = KfcWhite,
    surfaceVariant = KfcCharcoal,
    onSurfaceVariant = KfcCream,
    error = KfcRed,
    onError = KfcWhite
)

private val LightColorScheme = lightColorScheme(
    primary = KfcRed,
    onPrimary = KfcWhite,
    primaryContainer = KfcCream,
    onPrimaryContainer = KfcRedDark,
    secondary = KfcBlack,
    onSecondary = KfcWhite,
    background = KfcCream,
    onBackground = KfcBlack,
    surface = KfcWhite,
    onSurface = KfcBlack,
    surfaceVariant = KfcLightGrey,
    onSurfaceVariant = KfcCharcoal,
    error = KfcRed,
    onError = KfcWhite
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
