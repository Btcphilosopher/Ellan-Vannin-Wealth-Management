package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun KfcMainApp(viewModel: KfcViewModel) {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Crossfade(targetState = viewModel.currentScreen, label = "ScreenTransition") { screen ->
                when (screen) {
                    AppScreen.SPLASH -> SplashScreen(viewModel)
                    AppScreen.HOME -> HomeScreen(viewModel)
                    AppScreen.LOCATION_INPUT -> LocationInputScreen(viewModel)
                    AppScreen.RESTAURANT_SELECTOR -> RestaurantSelectorScreen(viewModel)
                    AppScreen.MENU -> MenuScreen(viewModel)
                    AppScreen.PRODUCT_DETAIL -> ProductDetailScreen(viewModel)
                    AppScreen.BUCKET_BUILDER -> BucketBuilderScreen(viewModel)
                    AppScreen.OFFERS -> OffersScreen(viewModel)
                    AppScreen.BASKET -> BasketScreen(viewModel)
                    AppScreen.CHECKOUT -> CheckoutScreen(viewModel)
                    AppScreen.CONFIRMATION -> OrderConfirmationScreen(viewModel)
                    AppScreen.TRACKING -> OrderTrackingScreen(viewModel)
                    AppScreen.ACCOUNT -> AccountScreen(viewModel)
                    AppScreen.KITCHEN_DASHBOARD -> KitchenDashboardScreen(viewModel)
                    AppScreen.ASSISTANT -> AssistantChatScreen(viewModel)
                }
            }

            // Floating Operations & Assistant shortcuts on suitable screens
            if (viewModel.currentScreen != AppScreen.SPLASH && 
                viewModel.currentScreen != AppScreen.CONFIRMATION && 
                viewModel.currentScreen != AppScreen.TRACKING
            ) {
                FloatingActionStrip(viewModel)
            }
        }
    }
}

// Global Floating Helpers
@Composable
fun BoxScope.FloatingActionStrip(viewModel: KfcViewModel) {
    Column(
        modifier = Modifier
            .align(Alignment.BottomEnd)
            .padding(end = 16.dp, bottom = 84.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Assistant Quick Button
        FloatingActionButton(
            onClick = { viewModel.navigateTo(AppScreen.ASSISTANT) },
            containerColor = KfcRed,
            contentColor = KfcWhite,
            shape = CircleShape,
            modifier = Modifier.testTag("assistant_fab").size(56.dp)
        ) {
            Icon(Icons.Filled.SupportAgent, contentDescription = "Colonel AI Assistant")
        }

        // Kitchen Dashboard Quick Button (Simulator)
        FloatingActionButton(
            onClick = { viewModel.navigateTo(AppScreen.KITCHEN_DASHBOARD) },
            containerColor = KfcBlack,
            contentColor = KfcWhite,
            shape = CircleShape,
            modifier = Modifier.testTag("kitchen_dashboard_fab").size(56.dp)
        ) {
            Icon(Icons.Filled.Storefront, contentDescription = "KFC Kitchen Ops")
        }
    }
}

// 1. SPLASH SCREEN
@Composable
fun SplashScreen(viewModel: KfcViewModel) {
    LaunchedEffect(Unit) {
        delay(2500)
        viewModel.navigateTo(AppScreen.HOME)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(KfcRed),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // KFC Stripes background effect
            Row(
                modifier = Modifier.height(180.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                repeat(3) {
                    Box(
                        modifier = Modifier
                            .width(28.dp)
                            .fillMaxHeight()
                            .background(KfcWhite)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "KFC",
                color = KfcWhite,
                fontSize = 56.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 2.sp
            )
            
            Text(
                text = "DELIVERY",
                color = KfcWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 4.sp
            )

            Spacer(modifier = Modifier.height(32.dp))

            CircularProgressIndicator(
                color = KfcWhite,
                strokeWidth = 3.dp,
                modifier = Modifier.size(24.dp)
            )
        }
    }
}

// 2. HOME SCREEN
@Composable
fun HomeScreen(viewModel: KfcViewModel) {
    val context = LocalContext.current

    Scaffold(
        bottomBar = { KfcBottomNavigation(viewModel, AppScreen.HOME) }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            // Hero section with dynamic visual cues
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp)
                        .background(KfcBlack)
                ) {
                    // Try to load generated hero photo, otherwise fallback gracefully
                    val resourceId = context.resources.getIdentifier("img_hero_banner", "drawable", context.packageName)
                    if (resourceId != 0) {
                        Image(
                            painter = painterResource(id = resourceId),
                            contentDescription = "Signature Bucket Hero",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        // High fidelity gradient canvas if image missing
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.verticalGradient(
                                        colors = listOf(KfcRedDark, KfcBlack)
                                    )
                                )
                        )
                    }

                    // Hot Overlay shadow for typography readability
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                                )
                            )
                    )

                    // Hero Text
                    Column(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .background(KfcRed, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "EST. 1952",
                                color = KfcWhite,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "FINGER LICKIN'\nGOOD",
                            color = KfcWhite,
                            fontSize = 32.sp,
                            fontWeight = FontWeight.Black,
                            lineHeight = 36.sp
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Hot chicken. Cold drinks. Straight to your door.",
                            color = KfcCream,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // CTAs
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = { viewModel.navigateTo(AppScreen.LOCATION_INPUT) },
                        colors = ButtonDefaults.buttonColors(containerColor = KfcRed),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("order_now_button"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "ORDER DELIVERY NOW",
                            color = KfcWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { 
                                viewModel.isDeliveryMode = false
                                viewModel.navigateTo(AppScreen.LOCATION_INPUT) 
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = KfcBlack),
                            border = BorderStroke(2.dp, KfcBlack),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Filled.DirectionsRun, contentDescription = null, tint = KfcBlack)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("COLLECTION", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Button(
                            onClick = { viewModel.navigateTo(AppScreen.BUCKET_BUILDER) },
                            colors = ButtonDefaults.buttonColors(containerColor = KfcGold),
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Filled.ShoppingBag, contentDescription = null, tint = KfcBlack)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("BUILD BUCKET", color = KfcBlack, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            // What are you craving?
            item {
                Text(
                    text = "WHAT ARE YOU CRAVING?",
                    color = KfcBlack,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )

                LazyRow(
                    contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(MenuCategory.values()) { cat ->
                        Card(
                            onClick = {
                                viewModel.navigateTo(AppScreen.MENU)
                            },
                            colors = CardDefaults.cardColors(containerColor = KfcWhite),
                            border = BorderStroke(1.dp, KfcLightGrey),
                            modifier = Modifier
                                .width(110.dp)
                                .height(100.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Center
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .background(KfcRed.copy(alpha = 0.1f), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    val icon = when (cat) {
                                        MenuCategory.BUCKETS -> Icons.Filled.ShoppingBasket
                                        MenuCategory.CHICKEN -> Icons.Filled.TakeoutDining
                                        MenuCategory.BURGERS -> Icons.Filled.LunchDining
                                        MenuCategory.WRAPS -> Icons.Filled.WrapText
                                        MenuCategory.SIDES -> Icons.Filled.RestaurantMenu
                                        MenuCategory.DRINKS -> Icons.Filled.LocalDrink
                                        MenuCategory.DESSERTS -> Icons.Filled.Icecream
                                    }
                                    Icon(icon, contentDescription = cat.name, tint = KfcRed)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = cat.name,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Black,
                                    color = KfcBlack,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                    }
                }
            }

            // Offers Banner Section
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "HOT DEALS & OFFERS",
                        color = KfcBlack,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black
                    )
                    TextButton(onClick = { viewModel.navigateTo(AppScreen.OFFERS) }) {
                        Text("View All", color = KfcRed, fontWeight = FontWeight.Bold)
                    }
                }
            }

            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    OfferTile(
                        title = "FAMILY NIGHT COOP",
                        desc = "Our legendary 10-Piece Bargain Bucket + 4 Fries + 2 Gravies for only £29.99!",
                        price = "£29.99",
                        badge = "BESTSELLER",
                        onClick = {
                            viewModel.addOfferToBasket("Family Night Coop Deal", "10-Piece Bucket + 4 Fries + 2 Gravies", 2999)
                        }
                    )
                    OfferTile(
                        title = "LUNCH BOX FEAST",
                        desc = "Classic Fillet Burger + regular fries + drink for £8.99. The ultimate lunch break.",
                        price = "£8.99",
                        badge = "LUNCH SPECIAL",
                        onClick = {
                            viewModel.addOfferToBasket("Lunch Box Feast Deal", "Fillet Burger + regular fries + drink", 899)
                        }
                    )
                }
            }
        }
    }
}

// 3. LOCATION INPUT SCREEN
@Composable
fun LocationInputScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateBack() }

    Scaffold(
        topBar = {
            KfcHeader(
                title = "KFC DELIVERY",
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(innerPadding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Top
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "WHERE SHOULD WE DELIVER?",
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                color = KfcBlack,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Enter your UK postcode to find your nearest open restaurant",
                fontSize = 14.sp,
                color = KfcCharcoal,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Postcode textfield
            OutlinedTextField(
                value = viewModel.postcodeQuery,
                onValueChange = { viewModel.postcodeQuery = it.uppercase() },
                label = { Text("Enter Postcode (e.g. SW1A 1AA)") },
                placeholder = { Text("SW1A 1AA") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("postcode_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = KfcRed,
                    focusedLabelColor = KfcRed,
                    cursorColor = KfcRed
                ),
                shape = RoundedCornerShape(8.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Service Toggles
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(90.dp)
                        .clickable { viewModel.isDeliveryMode = true },
                    border = BorderStroke(
                        width = if (viewModel.isDeliveryMode) 3.dp else 1.dp,
                        color = if (viewModel.isDeliveryMode) KfcRed else KfcLightGrey
                    ),
                    colors = CardDefaults.cardColors(containerColor = KfcWhite)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Filled.ElectricBike,
                            contentDescription = null,
                            tint = if (viewModel.isDeliveryMode) KfcRed else KfcCharcoal
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "DELIVERY",
                            fontWeight = FontWeight.Bold,
                            color = if (viewModel.isDeliveryMode) KfcRed else KfcBlack,
                            fontSize = 12.sp
                        )
                    }
                }

                Card(
                    modifier = Modifier
                        .weight(1f)
                        .height(90.dp)
                        .clickable { viewModel.isDeliveryMode = false },
                    border = BorderStroke(
                        width = if (!viewModel.isDeliveryMode) 3.dp else 1.dp,
                        color = if (!viewModel.isDeliveryMode) KfcRed else KfcLightGrey
                    ),
                    colors = CardDefaults.cardColors(containerColor = KfcWhite)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Filled.DirectionsRun,
                            contentDescription = null,
                            tint = if (!viewModel.isDeliveryMode) KfcRed else KfcCharcoal
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "COLLECTION",
                            fontWeight = FontWeight.Bold,
                            color = if (!viewModel.isDeliveryMode) KfcRed else KfcBlack,
                            fontSize = 12.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = {
                    if (viewModel.postcodeQuery.trim().isNotEmpty()) {
                        viewModel.navigateTo(AppScreen.RESTAURANT_SELECTOR)
                    }
                },
                enabled = viewModel.postcodeQuery.trim().isNotEmpty(),
                colors = ButtonDefaults.buttonColors(
                    containerColor = KfcRed,
                    disabledContainerColor = KfcGrey
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("find_restaurants_button"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("FIND NEAREST KFC", fontWeight = FontWeight.Black, fontSize = 16.sp)
            }
        }
    }
}

// 4. RESTAURANT SELECTOR SCREEN
@Composable
fun RestaurantSelectorScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateBack() }

    Scaffold(
        topBar = {
            KfcHeader(
                title = "SELECT RESTAURANT",
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(innerPadding)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(KfcBlack)
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.LocationOn, contentDescription = null, tint = KfcRed)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Results near '${viewModel.postcodeQuery}'",
                        color = KfcWhite,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }
            }

            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Show standard list
                items(viewModel.restaurants.take(10)) { rest ->
                    RestaurantCard(
                        restaurant = rest,
                        isDelivery = viewModel.isDeliveryMode,
                        onSelect = {
                            viewModel.selectedRestaurant = rest
                            viewModel.navigateTo(AppScreen.MENU)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun RestaurantCard(
    restaurant: Restaurant,
    isDelivery: Boolean,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() },
        border = BorderStroke(1.dp, KfcLightGrey),
        colors = CardDefaults.cardColors(containerColor = KfcWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = restaurant.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = KfcBlack
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = restaurant.address,
                        fontSize = 12.sp,
                        color = KfcGrey
                    )
                }
                Box(
                    modifier = Modifier
                        .background(KfcGold, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "${restaurant.rating} ★",
                        color = KfcBlack,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = KfcLightGrey)
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        if (isDelivery) Icons.Filled.ElectricBike else Icons.Filled.DirectionsRun,
                        contentDescription = null,
                        tint = KfcRed,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isDelivery) {
                            "${restaurant.deliveryMinStart}-${restaurant.deliveryMinEnd} min"
                        } else {
                            "${restaurant.collectionMinStart}-${restaurant.collectionMinEnd} min"
                        },
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = KfcBlack
                    )
                }

                Text(
                    text = if (isDelivery) "Delivery: £${String.format("%.2f", restaurant.deliveryFeePence / 100.0)}" else "Collection: FREE",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = KfcRed
                )

                Text(
                    text = "${restaurant.distanceMiles} miles",
                    fontSize = 11.sp,
                    color = KfcGrey
                )
            }
        }
    }
}

// 5. MENU SCREEN
@Composable
fun MenuScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateTo(AppScreen.HOME) }
    var selectedCat by remember { mutableStateOf(MenuCategory.BUCKETS) }

    Scaffold(
        topBar = {
            KfcHeader(
                title = viewModel.selectedRestaurant?.name ?: "KFC MENU",
                onBackClick = { viewModel.navigateTo(AppScreen.HOME) }
            )
        },
        bottomBar = { KfcBottomNavigation(viewModel, AppScreen.MENU) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            // Search Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(KfcWhite)
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                OutlinedTextField(
                    value = viewModel.searchQuery,
                    onValueChange = { viewModel.searchQuery = it },
                    placeholder = { Text("Search menu (e.g. zinger, wings)") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = KfcGrey) },
                    trailingIcon = {
                        if (viewModel.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.searchQuery = "" }) {
                                Icon(Icons.Default.Close, contentDescription = null, tint = KfcGrey)
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("menu_search_input"),
                    shape = RoundedCornerShape(24.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = KfcRed,
                        cursorColor = KfcRed
                    )
                )
            }

            // Category Navigation Row (Sticky tab equivalent)
            if (viewModel.searchQuery.isEmpty()) {
                LazyRow(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(KfcWhite)
                        .padding(bottom = 8.dp),
                    contentPadding = PaddingValues(horizontal = 16.dp)
                ) {
                    items(MenuCategory.values()) { cat ->
                        val isSelected = cat == selectedCat
                        Column(
                            modifier = Modifier
                                .clickable { selectedCat = cat }
                                .padding(end = 16.dp, bottom = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = cat.name,
                                fontWeight = FontWeight.Black,
                                fontSize = 14.sp,
                                color = if (isSelected) KfcRed else KfcCharcoal,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                            Box(
                                modifier = Modifier
                                    .height(3.dp)
                                    .width(40.dp)
                                    .background(if (isSelected) KfcRed else Color.Transparent)
                            )
                        }
                    }
                }
            }

            // Products list
            val filteredProducts = viewModel.getFilteredProducts().filter {
                viewModel.searchQuery.isNotEmpty() || it.category == selectedCat
            }

            if (filteredProducts.isEmpty()) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(Icons.Outlined.NoFood, contentDescription = null, modifier = Modifier.size(64.dp), tint = KfcGrey)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("No chicken found! Try searching something else.", color = KfcGrey, fontWeight = FontWeight.Bold)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(filteredProducts) { product ->
                        val favs by viewModel.favorites.collectAsStateWithLifecycle()
                        val isFav = favs.any { it.id == product.id }
                        
                        FoodCard(
                            product = product,
                            isFavorite = isFav,
                            onFavoriteClick = { viewModel.toggleFavorite(product.id) },
                            onSelect = { viewModel.openProductCustomizer(product) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FoodCard(
    product: Product,
    isFavorite: Boolean,
    onFavoriteClick: () -> Unit,
    onSelect: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() },
        colors = CardDefaults.cardColors(containerColor = KfcWhite),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, KfcLightGrey),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Food Card Left - Details
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(end = 12.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (product.spicyLevel > 0) {
                        Box(
                            modifier = Modifier
                                .background(KfcRed, RoundedCornerShape(2.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                "SPICY ${"🔥".repeat(product.spicyLevel)}",
                                color = KfcWhite,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    if (product.isVegetarian) {
                        Box(
                            modifier = Modifier
                                .background(KfcGreen, RoundedCornerShape(2.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                "VEGGIE 🌿",
                                color = KfcWhite,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                    }

                    Text(
                        text = "${product.calories} kcal",
                        fontSize = 10.sp,
                        color = KfcGrey,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = product.name,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    color = KfcBlack,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = product.description,
                    fontSize = 12.sp,
                    color = KfcCharcoal,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "£${String.format("%.2f", product.basePricePence / 100.0)}",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    color = KfcRed
                )
            }

            // Food Card Right - Styling composition/photo simulation placeholder
            Box(
                modifier = Modifier
                    .size(90.dp)
                    .background(KfcCream, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Highly aesthetic stylized canvas food asset drawing
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    val vector = when (product.category) {
                        MenuCategory.BUCKETS -> Icons.Filled.ShoppingBag
                        MenuCategory.CHICKEN -> Icons.Filled.TakeoutDining
                        MenuCategory.BURGERS -> Icons.Filled.LunchDining
                        MenuCategory.WRAPS -> Icons.Filled.WrapText
                        MenuCategory.SIDES -> Icons.Filled.RestaurantMenu
                        MenuCategory.DRINKS -> Icons.Filled.LocalDrink
                        MenuCategory.DESSERTS -> Icons.Filled.Icecream
                    }
                    Icon(
                        vector,
                        contentDescription = null,
                        tint = KfcRed,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "KFC FRESH",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Black,
                        color = KfcRed,
                        letterSpacing = 1.sp
                    )
                }

                // Heart favorite action
                IconButton(
                    onClick = { onFavoriteClick() },
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .size(32.dp)
                ) {
                    Icon(
                        if (isFavorite) Icons.Filled.Favorite else Icons.Outlined.FavoriteBorder,
                        contentDescription = "Favorite",
                        tint = KfcRed,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Add indicator inside image
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .background(KfcRed, RoundedCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
                        .clickable { onSelect() }
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        "+ ADD",
                        color = KfcWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

// 6. PRODUCT DETAIL CUSTOMIZATION SCREEN
@Composable
fun ProductDetailScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateBack() }
    val product = viewModel.activeCustomizerProduct ?: return

    val extrasCount = viewModel.customizerSelectedExtras.value.size
    var tempPricePence by remember(
        viewModel.customizerChickenType,
        viewModel.customizerMealSize,
        extrasCount
    ) {
        var base = product.basePricePence
        base += when (viewModel.customizerMealSize) {
            MealSize.SOLO -> 0
            MealSize.REGULAR -> 200
            MealSize.LARGE -> 270
        }
        base += viewModel.customizerSelectedExtras.value.sumOf { it.pricePence }
        mutableStateOf(base)
    }

    Scaffold(
        topBar = {
            KfcHeader(
                title = product.name,
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Hero Image Banner placeholder
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(KfcRedDark, KfcBlack)
                                ),
                                RoundedCornerShape(8.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Filled.TakeoutDining, contentDescription = null, tint = KfcWhite, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "CRISPY & FRESH INGREDIENTS",
                                color = KfcWhite,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }

                // Title & Description
                item {
                    Column {
                        Text(
                            text = product.name,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            color = KfcBlack
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = product.description,
                            fontSize = 14.sp,
                            color = KfcCharcoal,
                            lineHeight = 18.sp
                        )
                    }
                }

                // Allergen warning panel
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = KfcWhite),
                        border = BorderStroke(1.dp, KfcRed.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.Info, contentDescription = "Allergens", tint = KfcRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text("ALLERGENS & NUTRITION", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = KfcRed)
                                Text(
                                    "Contains: ${product.allergens}. Generated synthetic data.",
                                    fontSize = 11.sp,
                                    color = KfcCharcoal
                                )
                            }
                        }
                    }
                }

                // 1. Choose Chicken style (only if not side/drink/dessert)
                if (product.category == MenuCategory.BURGERS || product.category == MenuCategory.WRAPS || product.category == MenuCategory.CHICKEN) {
                    item {
                        Column {
                            Text("CHOOSE CHICKEN FLAVOUR", fontWeight = FontWeight.Black, fontSize = 16.sp, color = KfcBlack)
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            ChickenType.values().forEach { type ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.customizerChickenType = type }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = viewModel.customizerChickenType == type,
                                        onClick = { viewModel.customizerChickenType = type },
                                        colors = RadioButtonDefaults.colors(selectedColor = KfcRed)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = when (type) {
                                            ChickenType.ORIGINAL -> "Original Recipe (Secret 11 Herbs & Spices)"
                                            ChickenType.ZINGER -> "Zinger Spicy Crunchy"
                                            ChickenType.EXTRA_SPICY -> "Supercharged Fiery Glazed"
                                        },
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = KfcBlack
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. Select Portion Meal upgrade
                if (product.category == MenuCategory.BURGERS || product.category == MenuCategory.WRAPS) {
                    item {
                        Column {
                            Text("MAKE IT A MEAL?", fontWeight = FontWeight.Black, fontSize = 16.sp, color = KfcBlack)
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            MealSize.values().forEach { size ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.customizerMealSize = size }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = viewModel.customizerMealSize == size,
                                        onClick = { viewModel.customizerMealSize = size },
                                        colors = RadioButtonDefaults.colors(selectedColor = KfcRed)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = when (size) {
                                            MealSize.SOLO -> "Burger Only (Base price)"
                                            MealSize.REGULAR -> "Add Regular Fries & Drink (+£2.00)"
                                            MealSize.LARGE -> "Add Large Fries & Drink (+£2.70)"
                                        },
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = KfcBlack
                                    )
                                }
                            }
                        }
                    }
                }

                // Extras addition multiselect
                item {
                    Column {
                        Text("ADD EXTRA TOPPINGS", fontWeight = FontWeight.Black, fontSize = 16.sp, color = KfcBlack)
                        Spacer(modifier = Modifier.height(8.dp))
                        
                        viewModel.extraOptions.forEach { extra ->
                            val isSelected = viewModel.customizerSelectedExtras.value.any { it.id == extra.id }
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.toggleCustomizerExtra(extra) }
                                    .padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isSelected,
                                    onCheckedChange = { viewModel.toggleCustomizerExtra(extra) },
                                    colors = CheckboxDefaults.colors(checkedColor = KfcRed)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "${extra.name} (+£${String.format("%.2f", extra.pricePence / 100.0)})",
                                    fontSize = 14.sp,
                                    color = KfcBlack,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                // 3. Choose Drinks/Sides if meal is upgraded
                if (viewModel.customizerMealSize != MealSize.SOLO) {
                    item {
                        Column {
                            Text("SELECT MEAL DRINK", fontWeight = FontWeight.Black, fontSize = 16.sp, color = KfcBlack)
                            Spacer(modifier = Modifier.height(8.dp))
                            listOf("Pepsi Max", "Pepsi Cola", "7UP Free", "Tango Orange", "Spring Water").forEach { drink ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.customizerSelectedDrink = drink }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = viewModel.customizerSelectedDrink == drink,
                                        onClick = { viewModel.customizerSelectedDrink = drink },
                                        colors = RadioButtonDefaults.colors(selectedColor = KfcRed)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(drink, fontSize = 14.sp, color = KfcBlack)
                                }
                            }
                        }
                    }

                    item {
                        Column {
                            Text("SELECT MEAL SIDE", fontWeight = FontWeight.Black, fontSize = 16.sp, color = KfcBlack)
                            Spacer(modifier = Modifier.height(8.dp))
                            listOf("Fries", "BBQ Beans", "Gravy", "Coleslaw", "Corn Cob").forEach { side ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable { viewModel.customizerSelectedSide = side }
                                        .padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = viewModel.customizerSelectedSide == side,
                                        onClick = { viewModel.customizerSelectedSide = side },
                                        colors = RadioButtonDefaults.colors(selectedColor = KfcRed)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(side, fontSize = 14.sp, color = KfcBlack)
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Add to Basket Bar
            Surface(
                color = KfcWhite,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("TOTAL CUSTOM PRICE", fontSize = 11.sp, color = KfcGrey, fontWeight = FontWeight.Bold)
                        Text(
                            "£${String.format("%.2f", tempPricePence / 100.0)}",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = KfcRed
                        )
                    }

                    Button(
                        onClick = { viewModel.addCustomizedItemToCart() },
                        colors = ButtonDefaults.buttonColors(containerColor = KfcRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(50.dp)
                            .testTag("add_to_basket_custom_button")
                    ) {
                        Text(
                            "ADD TO BASKET",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = KfcWhite
                        )
                    }
                }
            }
        }
    }
}

// 7. BUCKET BUILDER SCREEN
@Composable
fun BucketBuilderScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateBack() }

    Scaffold(
        topBar = {
            KfcHeader(
                title = "BUILD YOUR BUCKET",
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(innerPadding)
        ) {
            // Visual Bucket preview drawing (Real-time updates)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(KfcBlack)
                    .padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                // Red stripes background canvas with bucket counting text
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .width(120.dp)
                            .height(110.dp)
                            .background(
                                Brush.verticalGradient(
                                    colors = listOf(KfcRed, KfcRedDark)
                                ),
                                RoundedCornerShape(bottomStart = 24.dp, bottomEnd = 24.dp)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        // Stripes on bucket
                        Row(
                            modifier = Modifier.fillMaxWidth().fillMaxHeight().padding(horizontal = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            repeat(3) {
                                Box(modifier = Modifier.width(12.dp).fillMaxHeight().background(KfcWhite))
                            }
                        }
                        
                        Text(
                            text = "${viewModel.bucketBuilderPieces + viewModel.bucketBuilderWings + viewModel.bucketBuilderFillets}\nPCS",
                            color = KfcBlack,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center,
                            modifier = Modifier
                                .background(KfcWhite, CircleShape)
                                .size(64.dp)
                                .wrapContentHeight()
                        )
                    }
                    
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "YOUR BUCKET BUILDER",
                        color = KfcGold,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Controls
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Text(
                        "CHOOSE YOUR FEAST MIX",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = KfcBlack
                    )
                }

                item {
                    BucketCounterRow(
                        title = "Original Recipe Pieces",
                        desc = "Legendary bone-in chicken",
                        count = viewModel.bucketBuilderPieces,
                        onMinus = { viewModel.updateBucketBuilderPieces(-2) },
                        onPlus = { viewModel.updateBucketBuilderPieces(2) }
                    )
                }

                item {
                    BucketCounterRow(
                        title = "Hot Wings",
                        desc = "Crispy, fiery crunch wings",
                        count = viewModel.bucketBuilderWings,
                        onMinus = { viewModel.updateBucketBuilderWings(-2) },
                        onPlus = { viewModel.updateBucketBuilderWings(2) }
                    )
                }

                item {
                    BucketCounterRow(
                        title = "Mini Fillets",
                        desc = "100% white breast meat strips",
                        count = viewModel.bucketBuilderFillets,
                        onMinus = { viewModel.updateBucketBuilderFillets(-2) },
                        onPlus = { viewModel.updateBucketBuilderFillets(2) }
                    )
                }

                item {
                    BucketCounterRow(
                        title = "Sides Included",
                        desc = "Signature skin-on sides",
                        count = viewModel.bucketBuilderSidesCount,
                        onMinus = { viewModel.updateBucketBuilderSides(-1) },
                        onPlus = { viewModel.updateBucketBuilderSides(1) }
                    )
                }

                item {
                    BucketCounterRow(
                        title = "Soft Drinks Included",
                        desc = "Crisp, cold cans",
                        count = viewModel.bucketBuilderDrinksCount,
                        onMinus = { viewModel.updateBucketBuilderDrinks(-1) },
                        onPlus = { viewModel.updateBucketBuilderDrinks(1) }
                    )
                }
            }

            // Bottom Add to Basket Bar
            Surface(
                color = KfcWhite,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("ESTIMATED TOTAL", fontSize = 11.sp, color = KfcGrey, fontWeight = FontWeight.Bold)
                        Text(
                            "£${String.format("%.2f", viewModel.getBucketBuilderPricePence() / 100.0)}",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            color = KfcRed
                        )
                    }

                    Button(
                        onClick = { viewModel.addCustomBucketToBasket() },
                        colors = ButtonDefaults.buttonColors(containerColor = KfcRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .height(50.dp)
                            .testTag("add_custom_bucket_button")
                    ) {
                        Text(
                            "ADD BUCKET TO BASKET",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            color = KfcWhite
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BucketCounterRow(
    title: String,
    desc: String,
    count: Int,
    onMinus: () -> Unit,
    onPlus: () -> Unit
) {
    Card(
        border = BorderStroke(1.dp, KfcLightGrey),
        colors = CardDefaults.cardColors(containerColor = KfcWhite)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1.5f)) {
                Text(title, fontWeight = FontWeight.Black, fontSize = 16.sp, color = KfcBlack)
                Text(desc, color = KfcGrey, fontSize = 11.sp)
            }

            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.End
            ) {
                OutlinedIconButton(
                    onClick = onMinus,
                    border = BorderStroke(1.dp, KfcRed),
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Filled.Remove, contentDescription = null, tint = KfcRed)
                }

                Text(
                    text = "$count",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = KfcBlack,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )

                OutlinedIconButton(
                    onClick = onPlus,
                    border = BorderStroke(1.dp, KfcRed),
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Filled.Add, contentDescription = null, tint = KfcRed)
                }
            }
        }
    }
}

// 8. OFFERS SCREEN
@Composable
fun OffersScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateTo(AppScreen.HOME) }

    Scaffold(
        topBar = {
            KfcHeader(
                title = "EXCLUSIVE OFFERS",
                onBackClick = { viewModel.navigateTo(AppScreen.HOME) }
            )
        },
        bottomBar = { KfcBottomNavigation(viewModel, AppScreen.OFFERS) }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(bottom = innerPadding.calculateBottomPadding())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    "HOT COOP DEALS",
                    color = KfcRed,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            }

            item {
                OfferTile(
                    title = "FAMILY NIGHT COOP",
                    desc = "Our legendary 10-Piece Bargain Bucket + 4 Fries + 2 Gravies for only £29.99!",
                    price = "£29.99",
                    badge = "BESTSELLER",
                    onClick = {
                        viewModel.addOfferToBasket("Family Night Coop Deal", "10-Piece Bucket + 4 Fries + 2 Gravies", 2999)
                    }
                )
            }

            item {
                OfferTile(
                    title = "LUNCH BOX FEAST",
                    desc = "Classic Fillet Burger + regular fries + drink for £8.99. The ultimate lunch break.",
                    price = "£8.99",
                    badge = "LUNCH SPECIAL",
                    onClick = {
                        viewModel.addOfferToBasket("Lunch Box Feast Deal", "Fillet Burger + regular fries + drink", 899)
                    }
                )
            }

            item {
                OfferTile(
                    title = "FEED THE CREW BUCKET",
                    desc = "14 pieces of Original Recipe Chicken, 6 regular fries, and 2 Pepsi Max large bottles.",
                    price = "£34.99",
                    badge = "BIG SHARER",
                    onClick = {
                        viewModel.addOfferToBasket("Feed The Crew Deal", "14-Piece Bucket + 6 Fries + 2 Pepsi bottles", 3499)
                    }
                )
            }
        }
    }
}

@Composable
fun OfferTile(
    title: String,
    desc: String,
    price: String,
    badge: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = KfcBlack),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(2.dp, KfcRed)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .background(KfcRed, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = badge,
                        color = KfcWhite,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Black
                    )
                }

                Text(
                    text = price,
                    color = KfcGold,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = title,
                color = KfcWhite,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = desc,
                color = KfcCream,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onClick,
                colors = ButtonDefaults.buttonColors(containerColor = KfcRed),
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    "GET THIS DEAL",
                    color = KfcWhite,
                    fontWeight = FontWeight.Black,
                    fontSize = 12.sp
                )
            }
        }
    }
}

// 9. BASKET SCREEN
@Composable
fun BasketScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateTo(AppScreen.MENU) }
    val items by viewModel.cartItems.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            KfcHeader(
                title = "YOUR BASKET",
                onBackClick = { viewModel.navigateTo(AppScreen.MENU) }
            )
        },
        bottomBar = { KfcBottomNavigation(viewModel, AppScreen.BASKET) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            if (items.isEmpty()) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Outlined.ShoppingBag,
                        contentDescription = null,
                        modifier = Modifier.size(72.dp),
                        tint = KfcGrey
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        "Your basket is empty!",
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        color = KfcBlack
                    )
                    Text("Add some hot & crispy chicken to get started.", color = KfcGrey, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = { viewModel.navigateTo(AppScreen.MENU) },
                        colors = ButtonDefaults.buttonColors(containerColor = KfcRed),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("BROWSE MENU", color = KfcWhite, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Text(
                            text = "REVIEW YOUR ORDER",
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            color = KfcBlack
                        )
                    }

                    items(items) { item ->
                        BasketItemRow(
                            item = item,
                            onRemove = { viewModel.removeFromCart(item.id) }
                        )
                    }

                    // Promo Code block
                    item {
                        PromoCodeBlock(viewModel)
                    }

                    // Pricing breakdown list
                    item {
                        PricingBreakdownCard(viewModel)
                    }
                }

                // Proceed checkout button
                Surface(
                    color = KfcWhite,
                    shadowElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Button(
                            onClick = { viewModel.navigateTo(AppScreen.CHECKOUT) },
                            colors = ButtonDefaults.buttonColors(containerColor = KfcRed),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(54.dp)
                                .testTag("checkout_button")
                        ) {
                            Text(
                                "PROCEED TO CHECKOUT",
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp,
                                color = KfcWhite
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BasketItemRow(
    item: CartItem,
    onRemove: () -> Unit
) {
    Card(
        border = BorderStroke(1.dp, KfcLightGrey),
        colors = CardDefaults.cardColors(containerColor = KfcWhite)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "${item.quantity}x ${item.product.name}",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = KfcBlack
                )
                
                // Show customizers
                val customSpecs = mutableListOf<String>()
                if (item.chickenType != ChickenType.ORIGINAL) {
                    customSpecs.add(item.chickenType.name)
                }
                if (item.selectedMealSize != MealSize.SOLO) {
                    customSpecs.add("${item.selectedMealSize.name} Meal")
                    customSpecs.add(item.selectedDrink)
                    customSpecs.add(item.selectedSide)
                }
                item.selectedExtras.forEach { ex ->
                    customSpecs.add("+${ex.name}")
                }
                
                if (customSpecs.isNotEmpty()) {
                    Text(
                        text = customSpecs.joinToString(", "),
                        fontSize = 11.sp,
                        color = KfcGrey
                    )
                }
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "£${String.format("%.2f", item.totalPricePence / 100.0)}",
                    fontWeight = FontWeight.Black,
                    fontSize = 16.sp,
                    color = KfcRed
                )
                
                IconButton(onClick = onRemove, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = KfcGrey, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun PromoCodeBlock(viewModel: KfcViewModel) {
    Card(
        border = BorderStroke(1.dp, KfcLightGrey),
        colors = CardDefaults.cardColors(containerColor = KfcWhite)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("PROMOTION CODE", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = KfcBlack)
            Spacer(modifier = Modifier.height(8.dp))
            
            if (viewModel.activePromoCode.isNotEmpty()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .background(KfcGold, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            "ACTIVE: ${viewModel.activePromoCode}",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            color = KfcBlack
                        )
                    }
                    TextButton(onClick = { viewModel.removePromoCode() }) {
                        Text("REMOVE", color = KfcRed, fontWeight = FontWeight.Bold)
                    }
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = viewModel.promoCodeText,
                        onValueChange = { viewModel.promoCodeText = it },
                        placeholder = { Text("Enter code (e.g. CRISPY20)") },
                        singleLine = true,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("promo_input"),
                        shape = RoundedCornerShape(4.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = KfcRed)
                    )

                    Button(
                        onClick = { viewModel.applyPromoCode() },
                        colors = ButtonDefaults.buttonColors(containerColor = KfcBlack),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.height(48.dp)
                    ) {
                        Text("APPLY")
                    }
                }
                
                viewModel.promoError?.let { err ->
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(err, color = KfcRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun PricingBreakdownCard(viewModel: KfcViewModel) {
    Card(
        border = BorderStroke(1.dp, KfcLightGrey),
        colors = CardDefaults.cardColors(containerColor = KfcWhite)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Subtotal", color = KfcCharcoal)
                Text("£${String.format("%.2f", viewModel.getSubtotalPence() / 100.0)}", color = KfcBlack)
            }
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Delivery Fee", color = KfcCharcoal)
                Text("£${String.format("%.2f", viewModel.getDeliveryFeePence() / 100.0)}", color = KfcBlack)
            }
            if (viewModel.promoDiscountPence > 0) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Promo Discount", color = KfcGreen)
                    Text("-£${String.format("%.2f", viewModel.promoDiscountPence / 100.0)}", color = KfcGreen, fontWeight = FontWeight.Bold)
                }
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            Divider(color = KfcLightGrey)
            Spacer(modifier = Modifier.height(4.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Total to Pay", fontWeight = FontWeight.Black, fontSize = 18.sp, color = KfcBlack)
                Text(
                    "£${String.format("%.2f", viewModel.getTotalPence() / 100.0)}",
                    fontWeight = FontWeight.Black,
                    fontSize = 18.sp,
                    color = KfcRed
                )
            }
        }
    }
}

// 10. CHECKOUT SCREEN
@Composable
fun CheckoutScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateBack() }

    Scaffold(
        topBar = {
            KfcHeader(
                title = "SECURE CHECKOUT",
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(innerPadding)
        ) {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Customer details
                item {
                    Text("YOUR DETAILS", fontWeight = FontWeight.Black, fontSize = 16.sp, color = KfcBlack)
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = KfcWhite), border = BorderStroke(1.dp, KfcLightGrey)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(
                                value = viewModel.customerName,
                                onValueChange = { viewModel.customerName = it },
                                label = { Text("Full Name") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = viewModel.customerPhone,
                                onValueChange = { viewModel.customerPhone = it },
                                label = { Text("Mobile Phone") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                // Delivery address (only if delivery mode)
                if (viewModel.isDeliveryMode) {
                    item {
                        Text("DELIVERY ADDRESS", fontWeight = FontWeight.Black, fontSize = 16.sp, color = KfcBlack)
                        Spacer(modifier = Modifier.height(8.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = KfcWhite), border = BorderStroke(1.dp, KfcLightGrey)) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                OutlinedTextField(
                                    value = viewModel.deliveryAddress,
                                    onValueChange = { viewModel.deliveryAddress = it },
                                    label = { Text("Street Address") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = viewModel.deliveryInstructions,
                                    onValueChange = { viewModel.deliveryInstructions = it },
                                    label = { Text("Driver Instructions (Optional)") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }

                // Payment Methods
                item {
                    Text("PAYMENT METHOD", fontWeight = FontWeight.Black, fontSize = 16.sp, color = KfcBlack)
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(colors = CardDefaults.cardColors(containerColor = KfcWhite), border = BorderStroke(1.dp, KfcLightGrey)) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Simulated Visa / Mastercard", "Apple Pay (Simulated)", "Google Pay (Simulated)", "PayPal (Simulated)").forEachIndexed { idx, option ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = idx == 0,
                                        onClick = { },
                                        colors = RadioButtonDefaults.colors(selectedColor = KfcRed)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(option, fontSize = 14.sp, color = KfcBlack, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Secure Pay Button Bar
            Surface(
                color = KfcWhite,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Button(
                        onClick = { viewModel.checkoutAndPay() },
                        colors = ButtonDefaults.buttonColors(containerColor = KfcRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .testTag("pay_button")
                    ) {
                        Text(
                            "PAY £${String.format("%.2f", viewModel.getTotalPence() / 100.0)} SECURELY",
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp,
                            color = KfcWhite
                        )
                    }
                }
            }
        }
    }
}

// 11. ORDER CONFIRMATION SCREEN
@Composable
fun OrderConfirmationScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateTo(AppScreen.HOME) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(KfcRed),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Animated celebratory chicken bucket shape drawing
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .background(KfcWhite, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Filled.Check,
                    contentDescription = null,
                    tint = KfcRed,
                    modifier = Modifier.size(56.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "ORDER CONFIRMED!",
                color = KfcWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Order #${viewModel.activeTrackingOrderId ?: "KFC-48291"}",
                color = KfcGold,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Prepare yourself! The kitchen is already hand-breading your hot chicken. Estimated delivery arrival in:",
                color = KfcCream,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                lineHeight = 20.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "15-25 MINUTES",
                color = KfcWhite,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(48.dp))

            Button(
                onClick = { viewModel.navigateTo(AppScreen.TRACKING) },
                colors = ButtonDefaults.buttonColors(containerColor = KfcBlack),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("track_order_button"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text(
                    "TRACK MY ORDER",
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    color = KfcWhite
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = { viewModel.navigateTo(AppScreen.HOME) },
                colors = ButtonDefaults.outlinedButtonColors(contentColor = KfcWhite),
                border = BorderStroke(2.dp, KfcWhite),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("BACK TO HOME", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }
    }
}

// 12. LIVE ORDER TRACKING SCREEN
@Composable
fun OrderTrackingScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateTo(AppScreen.HOME) }
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()
    val trackingId = viewModel.activeTrackingOrderId
    val activeOrder = orders.find { it.id == trackingId } ?: orders.firstOrNull()

    Scaffold(
        topBar = {
            KfcHeader(
                title = "LIVE ORDER TRACKING",
                onBackClick = { viewModel.navigateTo(AppScreen.HOME) }
            )
        }
    ) { innerPadding ->
        if (activeOrder == null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(KfcCream)
                    .padding(innerPadding),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("No active orders being tracked currently", color = KfcGrey)
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(KfcCream)
                    .padding(innerPadding)
            ) {
                // Tracking Status Top Panel
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(KfcBlack)
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                "ESTIMATED ARRIVAL",
                                color = KfcGrey,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "15-22 Minutes",
                                color = KfcWhite,
                                fontSize = 24.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                        
                        Box(
                            modifier = Modifier
                                .background(KfcRed, RoundedCornerShape(4.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                activeOrder.state.label.uppercase(),
                                color = KfcWhite,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black
                            )
                        }
                    }
                }

                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Timeline Progression
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = KfcWhite)) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("DELIVERY STAGE PROGRESSION", fontWeight = FontWeight.Black, fontSize = 14.sp)
                                
                                val stages = listOf(
                                    OrderState.CONFIRMED to "Order Received",
                                    OrderState.ACCEPTED to "Kitchen Preparing",
                                    OrderState.PREPARING to "Chicken Cooking",
                                    OrderState.READY to "Order Packed",
                                    OrderState.COLLECTED to "Driver Collected",
                                    OrderState.DELIVERING to "On the Way",
                                    OrderState.DELIVERED to "Arrived!"
                                )

                                stages.forEach { (st, lbl) ->
                                    val isPastOrCurrent = activeOrder.state.ordinal >= st.ordinal
                                    val isCurrent = activeOrder.state == st
                                    
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(24.dp)
                                                .background(
                                                    if (isCurrent) KfcRed else if (isPastOrCurrent) KfcBlack else KfcLightGrey,
                                                    CircleShape
                                                ),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            if (isPastOrCurrent && !isCurrent) {
                                                Icon(Icons.Filled.Check, null, tint = KfcWhite, modifier = Modifier.size(12.dp))
                                            } else if (isCurrent) {
                                                Box(modifier = Modifier.size(8.dp).background(KfcWhite, CircleShape))
                                            }
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Text(
                                            text = lbl,
                                            fontWeight = if (isCurrent) FontWeight.Black else FontWeight.Bold,
                                            color = if (isCurrent) KfcRed else if (isPastOrCurrent) KfcBlack else KfcGrey,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Simulated Courier Information Card
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = KfcWhite)) {
                            Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(48.dp)
                                        .background(KfcRed, CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Filled.Person, contentDescription = null, tint = KfcWhite)
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(activeOrder.courierName, fontWeight = FontWeight.Black, fontSize = 16.sp)
                                    Text("KFC Delivery Specialist • ${activeOrder.courierVehicle}", color = KfcGrey, fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Simulated Route Map Graphic drawing
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(KfcLightGrey, RoundedCornerShape(8.dp))
                                .border(1.dp, KfcRed.copy(alpha = 0.2f), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            // Schematic London street lines representation
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                drawLine(color = Color.LightGray, start = androidx.compose.ui.geometry.Offset(0f, 100f), end = androidx.compose.ui.geometry.Offset(size.width, 100f), strokeWidth = 8f)
                                drawLine(color = Color.LightGray, start = androidx.compose.ui.geometry.Offset(200f, 0f), end = androidx.compose.ui.geometry.Offset(200f, size.height), strokeWidth = 8f)
                                drawLine(color = Color.LightGray, start = androidx.compose.ui.geometry.Offset(0f, 300f), end = androidx.compose.ui.geometry.Offset(size.width, 200f), strokeWidth = 6f)
                            }
                            
                            // Restaurant source dot, Courier moving dot, House target dot
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 24.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Filled.Store, contentDescription = null, tint = KfcBlack)
                                    Text("KFC Kitchen", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }

                                // Moving Courier
                                val offsetAmount = (activeOrder.routeProgress * 100).toInt().dp
                                Box(
                                    modifier = Modifier
                                        .offset(x = offsetAmount)
                                        .background(KfcRed, CircleShape)
                                        .padding(8.dp)
                                ) {
                                    Icon(Icons.Filled.ElectricBike, contentDescription = null, tint = KfcWhite, modifier = Modifier.size(16.dp))
                                }

                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(Icons.Filled.Home, contentDescription = null, tint = KfcBlack)
                                    Text("Your Door", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 13. ACCOUNT SCREEN
@Composable
fun AccountScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateTo(AppScreen.HOME) }
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            KfcHeader(
                title = "MY KFC PROFILE",
                onBackClick = { viewModel.navigateTo(AppScreen.HOME) }
            )
        },
        bottomBar = { KfcBottomNavigation(viewModel, AppScreen.ACCOUNT) }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(bottom = innerPadding.calculateBottomPadding())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    "WELCOME, COLONEL!",
                    color = KfcBlack,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black
                )
                Text("UK Delivery Account Demo", color = KfcGrey, fontSize = 12.sp)
            }

            // Loyalty tier indicator card
            item {
                Card(colors = CardDefaults.cardColors(containerColor = KfcBlack)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("COLONEL LOYALTY CLUB", color = KfcGold, fontWeight = FontWeight.Black, fontSize = 14.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("You're currently in the Golden Drumstick Tier!", color = KfcWhite, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(12.dp))
                        LinearProgressIndicator(progress = 0.75f, color = KfcGold, trackColor = KfcGrey, modifier = Modifier.fillMaxWidth())
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("300 points to next free 6-piece Hot Wings bucket!", color = KfcGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Past Orders List
            item {
                Text("YOUR PAST ORDERS", fontWeight = FontWeight.Black, fontSize = 16.sp, color = KfcBlack)
            }

            if (orders.isEmpty()) {
                item {
                    Text("No past orders logged yet. Place an order to see it here!", color = KfcGrey, fontSize = 13.sp)
                }
            } else {
                items(orders) { order ->
                    Card(
                        border = BorderStroke(1.dp, KfcLightGrey),
                        colors = CardDefaults.cardColors(containerColor = KfcWhite)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Order #${order.id}", fontWeight = FontWeight.Black, fontSize = 14.sp)
                                Box(
                                    modifier = Modifier
                                        .background(if (order.state == OrderState.DELIVERED) KfcGreen else KfcRed, RoundedCornerShape(2.dp))
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(order.state.label, color = KfcWhite, fontSize = 8.sp, fontWeight = FontWeight.Black)
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Total Paid: £${String.format("%.2f", order.totalPence / 100.0)}", color = KfcCharcoal, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = {
                                        viewModel.activeTrackingOrderId = order.id
                                        viewModel.navigateTo(AppScreen.TRACKING)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = KfcBlack),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.weight(1f).height(36.dp)
                                ) {
                                    Text("TRACK STATS", fontSize = 11.sp)
                                }

                                Button(
                                    onClick = {
                                        // Simple Re-order simulation: deserialise items and push to cart
                                        viewModel.clearCart()
                                        viewModel.deserializeOrderItems(order.itemsJson).forEach { item ->
                                            viewModel.addToCart(item)
                                        }
                                        viewModel.navigateTo(AppScreen.BASKET)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = KfcRed),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.weight(1f).height(36.dp)
                                ) {
                                    Text("REORDER NOW", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 14. OPERATIONS / KITCHEN DISP LAY DASHBOARD
@Composable
fun KitchenDashboardScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateBack() }
    val orders by viewModel.allOrders.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            KfcHeader(
                title = "KFC OPERATIONS MANAGER",
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(innerPadding)
        ) {
            // Analytics Mini panel
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(KfcBlack)
                    .padding(16.dp)
            ) {
                val stats = viewModel.getAnalyticsStats()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    stats.forEach { (key, valStr) ->
                        if (key == "total_revenue" || key == "avg_basket" || key == "completed_orders") {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(key.replace("_", " ").uppercase(), color = KfcGrey, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                Text(valStr, color = KfcGold, fontSize = 16.sp, fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            }

            // Columns NEW, PREPARING, READY (interactive Operations Simulator)
            val activeOrders = orders.filter { it.state.isActive }
            
            if (activeOrders.isEmpty()) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth(),
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("No active kitchen tasks currently. Place an order first!", color = KfcGrey, fontWeight = FontWeight.Bold)
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    items(activeOrders) { ord ->
                        Card(
                            border = BorderStroke(2.dp, KfcRed),
                            colors = CardDefaults.cardColors(containerColor = KfcWhite)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text("ORDER #${ord.id}", fontWeight = FontWeight.Black, fontSize = 16.sp, color = KfcRed)
                                        Text("Customer: ${ord.customerName} • ${ord.postcode}", color = KfcCharcoal, fontSize = 12.sp)
                                    }

                                    Box(
                                        modifier = Modifier
                                            .background(KfcBlack, RoundedCornerShape(4.dp))
                                            .padding(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text(
                                            ord.state.label.uppercase(),
                                            color = KfcWhite,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Black
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))
                                Divider(color = KfcLightGrey)
                                Spacer(modifier = Modifier.height(12.dp))

                                // Advance Actions
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { viewModel.cancelOrderManually(ord.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = KfcLightGrey, contentColor = KfcBlack),
                                        modifier = Modifier.weight(1f).height(42.dp),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text("CANCEL", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }

                                    Button(
                                        onClick = { viewModel.advanceOrderStateManually(ord.id) },
                                        colors = ButtonDefaults.buttonColors(containerColor = KfcRed),
                                        modifier = Modifier.weight(1.5f).height(42.dp),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        val cta = when (ord.state) {
                                            OrderState.CONFIRMED -> "ACCEPT ORDER"
                                            OrderState.ACCEPTED -> "START COOKING"
                                            OrderState.PREPARING -> "PACK FOOD"
                                            OrderState.READY -> "DISPATCH DRIVER"
                                            OrderState.COLLECTED -> "SIMULATE TRAVEL"
                                            OrderState.DELIVERING -> "ARRIVED AT DOOR"
                                            else -> "COMPLETE"
                                        }
                                        Text(cta, fontWeight = FontWeight.Black, fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// 15. ASSISTANT CHAT SCREEN
@Composable
fun AssistantChatScreen(viewModel: KfcViewModel) {
    BackHandler { viewModel.navigateBack() }
    val history by viewModel.assistantChatHistory.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            KfcHeader(
                title = "KFC ORDER ASSISTANT",
                onBackClick = { viewModel.navigateBack() }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(KfcCream)
                .padding(innerPadding)
        ) {
            // Chat Logs list
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(top = 16.dp, bottom = 16.dp)
            ) {
                items(history) { chat ->
                    ChatBubble(chat, onAddSuggestion = { item ->
                        viewModel.addToCart(item)
                        viewModel.navigateTo(AppScreen.BASKET)
                    })
                }
            }

            // Input strip
            Surface(
                color = KfcWhite,
                shadowElevation = 8.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = viewModel.assistantInput,
                        onValueChange = { viewModel.assistantInput = it },
                        placeholder = { Text("Ask Colonel (e.g. spicy feast for four)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("assistant_text_input"),
                        shape = RoundedCornerShape(24.dp),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = KfcRed),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = { viewModel.sendAssistantMessage() },
                        enabled = viewModel.assistantInput.trim().isNotEmpty(),
                        modifier = Modifier
                            .background(KfcRed, CircleShape)
                            .size(44.dp)
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = KfcWhite)
                    }
                }
            }
        }
    }
}

@Composable
fun ChatBubble(
    chat: ChatMessage,
    onAddSuggestion: (CartItem) -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (chat.isUser) Alignment.End else Alignment.Start
    ) {
        Box(
            modifier = Modifier
                .background(
                    color = if (chat.isUser) KfcBlack else KfcWhite,
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (chat.isUser) 16.dp else 4.dp,
                        bottomEnd = if (chat.isUser) 4.dp else 16.dp
                    )
                )
                .border(
                    width = if (chat.isUser) 0.dp else 1.dp,
                    color = KfcLightGrey,
                    shape = RoundedCornerShape(
                        topStart = 16.dp,
                        topEnd = 16.dp,
                        bottomStart = if (chat.isUser) 16.dp else 4.dp,
                        bottomEnd = if (chat.isUser) 4.dp else 16.dp
                    )
                )
                .padding(14.dp)
                .widthIn(max = 280.dp)
        ) {
            Column {
                Text(
                    text = chat.text,
                    color = if (chat.isUser) KfcWhite else KfcBlack,
                    fontSize = 14.sp,
                    lineHeight = 18.sp
                )
                
                chat.suggestedItem?.let { suggestion ->
                    Spacer(modifier = Modifier.height(12.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = KfcCream),
                        border = BorderStroke(1.dp, KfcRed.copy(alpha = 0.3f))
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(suggestion.product.name, fontWeight = FontWeight.Black, fontSize = 12.sp, color = KfcRed)
                            Text(suggestion.product.description, fontSize = 10.sp, color = KfcCharcoal, maxLines = 2)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("£${String.format("%.2f", suggestion.singleItemPricePence / 100.0)}", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Button(
                                    onClick = { onAddSuggestion(suggestion) },
                                    colors = ButtonDefaults.buttonColors(containerColor = KfcRed),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text("ADD TO CART", fontSize = 9.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// REUSABLE TOP BAR COMPOSABLE
@Composable
fun KfcHeader(
    title: String,
    onBackClick: (() -> Unit)? = null
) {
    Surface(
        color = KfcRed,
        shadowElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBackClick != null) {
                IconButton(onClick = onBackClick, modifier = Modifier.size(44.dp)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = KfcWhite)
                }
                Spacer(modifier = Modifier.width(6.dp))
            } else {
                Spacer(modifier = Modifier.width(16.dp))
            }

            Text(
                text = title.uppercase(),
                color = KfcWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

// CUSTOM BOTTOM NAVIGATION COMPOSABLE
@Composable
fun KfcBottomNavigation(viewModel: KfcViewModel, activeScreen: AppScreen) {
    val cart by viewModel.cartItems.collectAsStateWithLifecycle()
    val totalInCart = cart.sumOf { it.quantity }
    
    NavigationBar(
        containerColor = KfcWhite,
        contentColor = KfcCharcoal,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = activeScreen == AppScreen.HOME,
            onClick = { viewModel.navigateTo(AppScreen.HOME) },
            icon = { Icon(Icons.Filled.Home, contentDescription = null) },
            label = { Text("Home", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = KfcRed, selectedTextColor = KfcRed, indicatorColor = KfcCream)
        )

        NavigationBarItem(
            selected = activeScreen == AppScreen.MENU,
            onClick = { viewModel.navigateTo(AppScreen.MENU) },
            icon = { Icon(Icons.Filled.RestaurantMenu, contentDescription = null) },
            label = { Text("Menu", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = KfcRed, selectedTextColor = KfcRed, indicatorColor = KfcCream)
        )

        NavigationBarItem(
            selected = activeScreen == AppScreen.BASKET,
            onClick = { viewModel.navigateTo(AppScreen.BASKET) },
            icon = {
                BadgedBox(
                    badge = {
                        if (totalInCart > 0) {
                            Badge(containerColor = KfcRed, contentColor = KfcWhite) {
                                Text("$totalInCart", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                ) {
                    Icon(Icons.Filled.ShoppingBag, contentDescription = null)
                }
            },
            label = { Text("Basket", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = KfcRed, selectedTextColor = KfcRed, indicatorColor = KfcCream)
        )

        NavigationBarItem(
            selected = activeScreen == AppScreen.ACCOUNT,
            onClick = { viewModel.navigateTo(AppScreen.ACCOUNT) },
            icon = { Icon(Icons.Filled.Person, contentDescription = null) },
            label = { Text("Account", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
            colors = NavigationBarItemDefaults.colors(selectedIconColor = KfcRed, selectedTextColor = KfcRed, indicatorColor = KfcCream)
        )
    }
}
