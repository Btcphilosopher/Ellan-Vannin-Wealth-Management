package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// KFC Bold Brand Colors
val KfcRed = Color(0xFFC41230)       // Signature KFC Red
val KfcRedDark = Color(0xFF9E0B22)   // Deep KFC Red
val KfcCream = Color(0xFFFBF6F0)     // Warm Cream
val KfcCharcoal = Color(0xFF1E1E1E)  // Dark Charcoal
val KfcGrey = Color(0xFF757575)      // Classic Grey
val KfcLightGrey = Color(0xFFF5F5F5) // Off-white/Light grey
val KfcBlack = Color(0xFF000000)     // Pure Black
val KfcWhite = Color(0xFFFFFFFF)     // Pure White
val KfcGold = Color(0xFFFFC72C)      // Crispy Gold Accent
val KfcGreen = Color(0xFF2E7D32)     // Fresh Green (Allergens/Dietary check)
