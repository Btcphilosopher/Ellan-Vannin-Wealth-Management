package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.KfcMainApp
import com.example.ui.KfcViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    private val viewModel: KfcViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Mandatory modern Edge-to-Edge display
        enableEdgeToEdge()
        
        setContent {
            MyApplicationTheme {
                KfcMainApp(viewModel = viewModel)
            }
        }
    }
}
