package com.example.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "cart_items")
data class DbCartItem(
    @PrimaryKey val id: String,
    val productId: String,
    val productName: String,
    val productDescription: String,
    val productBasePricePence: Int,
    val productCategory: String,
    val quantity: Int,
    val chickenType: String,
    val selectedMealSize: String,
    val selectedExtrasJson: String, // Comma separated list of extras
    val selectedDrink: String,
    val selectedSide: String
)

@Entity(tableName = "orders")
data class DbOrder(
    @PrimaryKey val id: String,
    val restaurantId: String,
    val restaurantName: String,
    val customerName: String,
    val customerPhone: String,
    val customerEmail: String,
    val postcode: String,
    val address: String,
    val deliveryInstructions: String,
    val itemsJson: String, // serialized cart items
    val subtotalPence: Int,
    val deliveryFeePence: Int,
    val discountPence: Int,
    val totalPence: Int,
    val state: String, // mapped from OrderState
    val timestamp: Long,
    val courierName: String,
    val courierVehicle: String,
    val routeProgress: Float,
    val elapsedSecondsInState: Int = 0
)

@Entity(tableName = "favorites")
data class DbFavorite(
    @PrimaryKey val productId: String
)

@Dao
interface KfcDao {
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<DbCartItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCartItem(item: DbCartItem)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItem(id: String)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()

    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getAllOrders(): Flow<List<DbOrder>>

    @Query("SELECT * FROM orders WHERE id = :id")
    fun getOrderById(id: String): Flow<DbOrder?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: DbOrder)

    @Query("SELECT * FROM favorites")
    fun getFavorites(): Flow<List<DbFavorite>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(favorite: DbFavorite)

    @Query("DELETE FROM favorites WHERE productId = :productId")
    suspend fun deleteFavorite(productId: String)
}

@Database(entities = [DbCartItem::class, DbOrder::class, DbFavorite::class], version = 1, exportSchema = false)
abstract class KfcDatabase : RoomDatabase() {
    abstract fun kfcDao(): KfcDao

    companion object {
        @Volatile
        private var INSTANCE: KfcDatabase? = null

        fun getDatabase(context: Context): KfcDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    KfcDatabase::class.java,
                    "kfc_delivery_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
