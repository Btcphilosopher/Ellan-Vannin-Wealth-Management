package com.example.data

import android.content.Context
import com.example.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class KfcRepository(private val context: Context) {
    private val kfcDao = KfcDatabase.getDatabase(context).kfcDao()
    private val scope = CoroutineScope(Dispatchers.Default)

    // Core static products list (Fully detailed, authentic KFC products)
    val products = listOf(
        // BUCKETS
        Product(
            id = "b1",
            name = "Family Bucket",
            description = "10 pieces of Original Recipe chicken, 4 regular fries, 2 large sides and a large bottle of Pepsi Max.",
            basePricePence = 2999,
            category = MenuCategory.BUCKETS,
            spicyLevel = 0,
            calories = 3450,
            allergens = "Gluten, Milk, Eggs, Celery",
            ingredients = "Fresh UK chicken pieces hand-breaded in our Secret 11 Herbs & Spices, crispy potato fries, choice of baked beans/coleslaw/gravy, Pepsi Max."
        ),
        Product(
            id = "b2",
            name = "Bargain Bucket",
            description = "10 pieces of Original Recipe chicken and 4 regular fries. Simple and finger lickin' good.",
            basePricePence = 2299,
            category = MenuCategory.BUCKETS,
            spicyLevel = 0,
            calories = 2900,
            allergens = "Gluten, Celery",
            ingredients = "Fresh UK chicken pieces hand-breaded in our Secret 11 Herbs & Spices, crispy potato fries."
        ),
        Product(
            id = "b3",
            name = "Boneless Bucket",
            description = "10 Mini Fillets, Popcorn Chicken, 4 regular fries, 4 dip pots and a large bottle of Pepsi Max.",
            basePricePence = 2899,
            category = MenuCategory.BUCKETS,
            spicyLevel = 0,
            calories = 3100,
            allergens = "Gluten, Milk, Eggs",
            ingredients = "Mini fillets, popcorn chicken bites, crispy fries, choice of original/BBQ/sweet chili dipping sauces, Pepsi Max."
        ),
        Product(
            id = "b4",
            name = "Wicked Variety Bucket",
            description = "6 pieces of Original Recipe chicken, 6 Hot Wings, 6 Mini Fillets, 4 regular fries and a large bottle of Pepsi Max.",
            basePricePence = 3299,
            category = MenuCategory.BUCKETS,
            spicyLevel = 1,
            calories = 3600,
            allergens = "Gluten, Milk, Eggs, Celery, Mustard",
            ingredients = "Original recipe chicken pieces, spicy hot wings, crispy mini fillets, fries, large Pepsi Max bottle."
        ),

        // CHICKEN
        Product(
            id = "c1",
            name = "Original Recipe Chicken (2pc)",
            description = "2 pieces of our legendary golden-brown Original Recipe chicken, hand-breaded in the Colonel's 11 secret herbs and spices.",
            basePricePence = 449,
            category = MenuCategory.CHICKEN,
            spicyLevel = 0,
            calories = 490,
            allergens = "Gluten, Celery",
            ingredients = "Fresh chicken portions (drumstick/thigh/breast), double-breaded in flour seasoned with the classic secret 11 herbs and spices, pressure fried."
        ),
        Product(
            id = "c2",
            name = "Hot Wings (6pc)",
            description = "6 hot, fiery wings coated in a crispy, crunchy spicy coating.",
            basePricePence = 499,
            category = MenuCategory.CHICKEN,
            spicyLevel = 2,
            calories = 540,
            allergens = "Gluten, Mustard",
            ingredients = "Spicy marinated chicken wings, coated in a super crunchy fiery batter, fried to crispy golden perfection."
        ),
        Product(
            id = "c3",
            name = "Hot Wings (10pc)",
            description = "10 hot, fiery wings coated in a crispy, crunchy spicy coating. Perfect for sharing.",
            basePricePence = 799,
            category = MenuCategory.CHICKEN,
            spicyLevel = 2,
            calories = 900,
            allergens = "Gluten, Mustard",
            ingredients = "Fiery marinated chicken wings, coated in deep crispy crunchy batter, pressure cooked."
        ),
        Product(
            id = "c4",
            name = "Mini Fillets (4pc)",
            description = "4 premium 100% chicken breast fillets, tender and original-flavored.",
            basePricePence = 449,
            category = MenuCategory.CHICKEN,
            spicyLevel = 0,
            calories = 380,
            allergens = "Gluten, Celery",
            ingredients = "Tender 100% chicken breast strips, breaded in the classic secret 11 herbs and spices."
        ),

        // BURGERS
        Product(
            id = "bu1",
            name = "Zinger® Burger",
            description = "A fiery, crispy chicken breast fillet with fresh crunchy lettuce and hot pepper mayonnaise in a toasted sesame seed bun.",
            basePricePence = 749,
            category = MenuCategory.BURGERS,
            spicyLevel = 1,
            calories = 510,
            allergens = "Gluten, Eggs, Mustard, Sesame",
            ingredients = "Crispy spicy chicken breast fillet, toasted sesame bun, fresh lettuce, spicy pepper mayo."
        ),
        Product(
            id = "bu2",
            name = "Zinger® Tower Burger",
            description = "Fiery crispy chicken fillet, a golden crispy hash brown, a slice of cheese, tangy tomato salsa and fiery mayo.",
            basePricePence = 899,
            category = MenuCategory.BURGERS,
            spicyLevel = 2,
            calories = 720,
            allergens = "Gluten, Milk, Eggs, Mustard, Sesame",
            ingredients = "Fiery chicken breast fillet, crispy potato hash brown, processed cheddar slice, salsa, spicy pepper mayo, toasted bun."
        ),
        Product(
            id = "bu3",
            name = "Fillet Burger",
            description = "Original recipe chicken breast fillet, crunchy fresh lettuce and creamy pepper mayonnaise in a toasted bun.",
            basePricePence = 699,
            category = MenuCategory.BURGERS,
            spicyLevel = 0,
            calories = 460,
            allergens = "Gluten, Eggs, Sesame",
            ingredients = "Original recipe chicken breast fillet, toasted sesame bun, crisp iceberg lettuce, smooth pepper mayo."
        ),
        Product(
            id = "bu4",
            name = "Double Zinger® Burger",
            description = "Two fiery crispy chicken fillets, double cheese, crunchy lettuce and spicy pepper mayo in a toasted bun.",
            basePricePence = 999,
            category = MenuCategory.BURGERS,
            spicyLevel = 2,
            calories = 880,
            allergens = "Gluten, Milk, Eggs, Mustard, Sesame",
            ingredients = "Double spicy chicken fillets, two cheddar cheese slices, crisp lettuce, hot pepper mayo, toasted bun."
        ),

        // WRAPS
        Product(
            id = "w1",
            name = "Original Twister®",
            description = "An original recipe fillet with pickled pepper mayonnaise, fresh lettuce and diced tomatoes, wrapped in a soft toasted tortilla.",
            basePricePence = 649,
            category = MenuCategory.WRAPS,
            spicyLevel = 0,
            calories = 440,
            allergens = "Gluten, Eggs, Celery",
            ingredients = "Original recipe fillet strip, soft wheat flour tortilla, fresh tomatoes, lettuce, creamy pepper mayo."
        ),
        Product(
            id = "w2",
            name = "Zinger® Twister®",
            description = "A fiery spicy chicken fillet, fresh lettuce, pickled onions, tomatoes and spicy sweet-chili sauce, toasted in a warm wrap.",
            basePricePence = 699,
            category = MenuCategory.WRAPS,
            spicyLevel = 1,
            calories = 460,
            allergens = "Gluten, Eggs, Mustard",
            ingredients = "Crispy spicy breast strip, wheat flour wrap, sliced tomatoes, pickled onions, fresh lettuce, sweet chili sauce."
        ),

        // SIDES
        Product(
            id = "s1",
            name = "Signature Fries (Regular)",
            description = "Crispy, golden potato skin-on fries, lightly sprinkled with our signature seasoning.",
            basePricePence = 249,
            category = MenuCategory.SIDES,
            spicyLevel = 0,
            calories = 280,
            allergens = "None",
            ingredients = "Thick skin-on UK potatoes, fried in vegetable oil, signature savory fry seasoning."
        ),
        Product(
            id = "s2",
            name = "Signature Fries (Large)",
            description = "Large portion of our crispy, golden potato skin-on fries with signature seasoning.",
            basePricePence = 299,
            category = MenuCategory.SIDES,
            spicyLevel = 0,
            calories = 410,
            allergens = "None",
            ingredients = "Thick skin-on UK potatoes, fried in vegetable oil, fry seasoning."
        ),
        Product(
            id = "s3",
            name = "BBQ Baked Beans",
            description = "Warm baked beans cooked in a sweet, rich, smoky BBQ sauce.",
            basePricePence = 199,
            category = MenuCategory.SIDES,
            spicyLevel = 0,
            calories = 110,
            allergens = "None",
            ingredients = "Navy beans, sweet tomato sauce, smoky hickory BBQ essence."
        ),
        Product(
            id = "s4",
            name = "Signature Gravy (Regular)",
            description = "Our legendary hot, savory, pepper-infused chicken gravy. Perfect for dipping.",
            basePricePence = 199,
            category = MenuCategory.SIDES,
            spicyLevel = 0,
            calories = 80,
            allergens = "Gluten, Celery",
            ingredients = "Hot pepper-infused savory chicken stock, thickened with wheat starch, secret spices."
        ),
        Product(
            id = "s5",
            name = "Creamy Coleslaw",
            description = "Freshly shredded cabbage, carrots, and onions folded into a smooth, thick sweet cream dressing.",
            basePricePence = 199,
            category = MenuCategory.SIDES,
            spicyLevel = 0,
            calories = 140,
            allergens = "Eggs, Mustard",
            ingredients = "Shredded green cabbage, carrots, onions, mayonnaise dressing, sugar, spirit vinegar."
        ),

        // DRINKS
        Product(
            id = "d1",
            name = "Pepsi Max® (Regular)",
            description = "Cold, refreshing maximum-taste sugar-free cola.",
            basePricePence = 199,
            category = MenuCategory.DRINKS,
            spicyLevel = 0,
            calories = 2,
            allergens = "None",
            ingredients = "Carbonated water, caramel color, sweeteners (aspartame, acesulfame K), caffeine, natural flavorings."
        ),
        Product(
            id = "d2",
            name = "Pepsi® (Regular)",
            description = "The classic, bold, crisp sugar-sweetened cola beverage.",
            basePricePence = 219,
            category = MenuCategory.DRINKS,
            spicyLevel = 0,
            calories = 150,
            allergens = "None",
            ingredients = "Carbonated water, sugar, caramel color, phosphoric acid, caffeine, natural flavorings."
        ),
        Product(
            id = "d3",
            name = "7UP® Free",
            description = "Crisp, clean lemon and lime sugar-free fizzy drink.",
            basePricePence = 199,
            category = MenuCategory.DRINKS,
            spicyLevel = 0,
            calories = 1,
            allergens = "None",
            ingredients = "Carbonated water, acids (citric acid, malic acid), natural lemon and lime flavorings, acidity regulator."
        ),
        Product(
            id = "d4",
            name = "Tango® Orange",
            description = "Burst of orange flavor, bubbly and sweet.",
            basePricePence = 199,
            category = MenuCategory.DRINKS,
            spicyLevel = 0,
            calories = 19,
            allergens = "None",
            ingredients = "Carbonated water, orange fruit from concentrate, citric acid, natural orange flavorings."
        ),

        // DESSERTS
        Product(
            id = "de1",
            name = "Choc Chip Cookie",
            description = "Freshly baked, chewy golden cookie loaded with dark chocolate chips.",
            basePricePence = 199,
            category = MenuCategory.DESSERTS,
            spicyLevel = 0,
            calories = 240,
            allergens = "Gluten, Milk, Eggs, Soy",
            ingredients = "Wheat flour, brown sugar, butter, dark chocolate chips (cocoa mass, sugar), whole egg powder."
        ),
        Product(
            id = "de2",
            name = "Strawberry Sundae",
            description = "Creamy vanilla dairy ice cream topped with a thick, sweet strawberry fruit glaze.",
            basePricePence = 299,
            category = MenuCategory.DESSERTS,
            spicyLevel = 0,
            calories = 190,
            allergens = "Milk",
            ingredients = "Reconstituted skimmed milk, sugar, cream, real strawberry puree glaze, pectin."
        )
    )

    // Extras customizer options
    val extraOptions = listOf(
        ExtraOption("ex_cheese", "Extra Monterey Jack Cheese", 80),
        ExtraOption("ex_chicken", "Extra Original Recipe Chicken Fillet", 250),
        ExtraOption("ex_bacon", "Smoked Maple Bacon", 120),
        ExtraOption("ex_sauce", "Supercharged Hot Sauce", 30),
        ExtraOption("ex_hashbrown", "Crispy Potato Hash Brown", 100)
    )

    // Pre-generate 100 synthetic UK Restaurants
    private val allRestaurants: List<Restaurant> by lazy {
        val list = mutableListOf<Restaurant>()
        
        // Pin the nearest primary ones
        list.add(
            Restaurant(
                id = "rest_demo",
                name = "KFC London Central — Synthetic Demo",
                address = "126 Charing Cross Rd, London",
                postcode = "WC2H 0JR",
                distanceMiles = 0.5,
                deliveryMinStart = 15,
                deliveryMinEnd = 25,
                collectionMinStart = 5,
                collectionMinEnd = 10,
                deliveryFeePence = 99,
                rating = 4.9
            )
        )
        list.add(
            Restaurant(
                id = "rest_victoria",
                name = "KFC Victoria Station",
                address = "Unit 12, Victoria Station Concourse, London",
                postcode = "SW1V 1JT",
                distanceMiles = 1.2,
                deliveryMinStart = 25,
                deliveryMinEnd = 35,
                collectionMinStart = 10,
                collectionMinEnd = 15,
                deliveryFeePence = 199,
                rating = 4.7
            )
        )
        list.add(
            Restaurant(
                id = "rest_camden",
                name = "KFC Camden High Street",
                address = "142 Camden High St, London",
                postcode = "NW1 0NE",
                distanceMiles = 2.1,
                deliveryMinStart = 30,
                deliveryMinEnd = 40,
                collectionMinStart = 12,
                collectionMinEnd = 18,
                deliveryFeePence = 249,
                rating = 4.5
            )
        )

        // Let's generate another 97 locations dynamically so we have exactly 100 restaurants!
        val cities = listOf("London", "Manchester", "Birmingham", "Edinburgh", "Leeds", "Glasgow", "Bristol", "Liverpool", "Cardiff", "Belfast")
        val streets = listOf("High Street", "Station Road", "Broadway", "Queens Road", "Church Street", "Market Place", "London Road", "Victoria Street", "Park Lane")
        
        for (i in 4..100) {
            val city = cities[i % cities.size]
            val street = streets[(i * 3) % streets.size]
            val dist = 2.5 + (i * 0.14) % 15.0
            val startMin = 20 + (i * 3) % 25
            val endMin = startMin + 10 + (i % 5)
            val fee = 149 + (i * 10) % 250
            val rat = 3.8 + (i * 31 % 13) * 0.1
            
            val cleanRating = String.format("%.1f", rat.coerceAtMost(5.0)).toDouble()
            val cleanDist = String.format("%.1f", dist).toDouble()

            list.add(
                Restaurant(
                    id = "rest_$i",
                    name = "KFC $city $street",
                    address = "${i * 12} $street, $city",
                    postcode = "${city.substring(0,2).uppercase()}${i % 9} ${i % 3}${('A' + (i % 26))}${('A' + ((i + 3) % 26))}",
                    distanceMiles = cleanDist,
                    deliveryMinStart = startMin,
                    deliveryMinEnd = endMin,
                    collectionMinStart = startMin / 2,
                    collectionMinEnd = (startMin / 2) + 5,
                    deliveryFeePence = fee,
                    rating = cleanRating
                )
            )
        }
        list
    }

    fun getRestaurants(): List<Restaurant> = allRestaurants

    // DB Operations mapped from/to entities
    val cartItems: Flow<List<CartItem>> = kfcDao.getCartItems().map { list ->
        list.map { dbItem ->
            val p = products.find { it.id == dbItem.productId } ?: Product(
                dbItem.productId, dbItem.productName, dbItem.productDescription,
                dbItem.productBasePricePence, MenuCategory.valueOf(dbItem.productCategory)
            )
            CartItem(
                id = dbItem.id,
                product = p,
                quantity = dbItem.quantity,
                chickenType = ChickenType.valueOf(dbItem.chickenType),
                selectedMealSize = MealSize.valueOf(dbItem.selectedMealSize),
                selectedExtras = parseExtrasJson(dbItem.selectedExtrasJson),
                selectedDrink = dbItem.selectedDrink,
                selectedSide = dbItem.selectedSide
            )
        }
    }

    val allOrders: Flow<List<Order>> = kfcDao.getAllOrders().map { list ->
        list.map { db ->
            Order(
                id = db.id,
                restaurantId = db.restaurantId,
                restaurantName = db.restaurantName,
                customerName = db.customerName,
                customerPhone = db.customerPhone,
                customerEmail = db.customerEmail,
                postcode = db.postcode,
                address = db.address,
                deliveryInstructions = db.deliveryInstructions,
                itemsJson = db.itemsJson,
                subtotalPence = db.subtotalPence,
                deliveryFeePence = db.deliveryFeePence,
                discountPence = db.discountPence,
                totalPence = db.totalPence,
                state = OrderState.valueOf(db.state),
                timestamp = db.timestamp,
                courierName = db.courierName,
                courierVehicle = db.courierVehicle,
                routeProgress = db.routeProgress,
                elapsedSecondsInState = db.elapsedSecondsInState
            )
        }
    }

    val favorites: Flow<List<Product>> = kfcDao.getFavorites().map { list ->
        list.mapNotNull { fav -> products.find { it.id == fav.productId } }
    }

    suspend fun addToCart(item: CartItem) {
        val dbItem = DbCartItem(
            id = item.id,
            productId = item.product.id,
            productName = item.product.name,
            productDescription = item.product.description,
            productBasePricePence = item.product.basePricePence,
            productCategory = item.product.category.name,
            quantity = item.quantity,
            chickenType = item.chickenType.name,
            selectedMealSize = item.selectedMealSize.name,
            selectedExtrasJson = serializeExtrasList(item.selectedExtras),
            selectedDrink = item.selectedDrink,
            selectedSide = item.selectedSide
        )
        kfcDao.insertCartItem(dbItem)
    }

    suspend fun removeFromCart(id: String) {
        kfcDao.deleteCartItem(id)
    }

    suspend fun clearCart() {
        kfcDao.clearCart()
    }

    suspend fun toggleFavorite(productId: String) {
        val currentFavs = kfcDao.getFavorites().first()
        val exists = currentFavs.any { it.productId == productId }
        if (exists) {
            kfcDao.deleteFavorite(productId)
        } else {
            kfcDao.insertFavorite(DbFavorite(productId))
        }
    }

    suspend fun placeOrder(order: Order) {
        val db = DbOrder(
            id = order.id,
            restaurantId = order.restaurantId,
            restaurantName = order.restaurantName,
            customerName = order.customerName,
            customerPhone = order.customerPhone,
            customerEmail = order.customerEmail,
            postcode = order.postcode,
            address = order.address,
            deliveryInstructions = order.deliveryInstructions,
            itemsJson = order.itemsJson,
            subtotalPence = order.subtotalPence,
            deliveryFeePence = order.deliveryFeePence,
            discountPence = order.discountPence,
            totalPence = order.totalPence,
            state = order.state.name,
            timestamp = order.timestamp,
            courierName = order.courierName,
            courierVehicle = order.courierVehicle,
            routeProgress = order.routeProgress,
            elapsedSecondsInState = order.elapsedSecondsInState
        )
        kfcDao.insertOrder(db)
        clearCart()

        // Start background order state machine progression simulator
        simulateOrderProgression(order.id)
    }

    suspend fun updateOrderState(orderId: String, newState: OrderState, progress: Float = 0f) {
        val currentDb = kfcDao.getAllOrders().first().find { it.id == orderId } ?: return
        val updated = currentDb.copy(
            state = newState.name,
            routeProgress = progress,
            elapsedSecondsInState = 0
        )
        kfcDao.insertOrder(updated)
    }

    // Interactive order state machine simulation
    private fun simulateOrderProgression(orderId: String) {
        scope.launch {
            // State sequence: CONFIRMED -> ACCEPTED -> PREPARING -> READY -> COLLECTED -> DELIVERING -> DELIVERED
            val stages = listOf(
                OrderState.CONFIRMED to 5000L,
                OrderState.ACCEPTED to 6000L,
                OrderState.PREPARING to 10000L,
                OrderState.READY to 6000L,
                OrderState.COLLECTED to 5000L,
                OrderState.DELIVERING to 20000L, // Will increment delivery progress in steps
                OrderState.DELIVERED to 0L
            )

            for ((state, durationMs) in stages) {
                // Read current DB and check if cancelled
                val current = kfcDao.getAllOrders().first().find { it.id == orderId } ?: break
                if (current.state == OrderState.CANCELLED.name) break

                if (state == OrderState.DELIVERING) {
                    // Update state to DELIVERING
                    updateOrderState(orderId, OrderState.DELIVERING, 0.0f)
                    
                    // Animate travel progress over 20 seconds
                    val steps = 10
                    for (step in 1..steps) {
                        delay(2000L)
                        val cancelCheck = kfcDao.getAllOrders().first().find { it.id == orderId }
                        if (cancelCheck == null || cancelCheck.state == OrderState.CANCELLED.name) break
                        
                        val progress = step.toFloat() / steps.toFloat()
                        val dbToUpdate = cancelCheck.copy(
                            routeProgress = progress,
                            elapsedSecondsInState = step * 2
                        )
                        kfcDao.insertOrder(dbToUpdate)
                    }
                } else {
                    updateOrderState(orderId, state, 0.0f)
                    if (durationMs > 0) {
                        // Sleep in chunks to allow elapsedSeconds update
                        val loops = (durationMs / 1000).toInt()
                        for (l in 1..loops) {
                            delay(1000L)
                            val innerCheck = kfcDao.getAllOrders().first().find { it.id == orderId } ?: break
                            if (innerCheck.state == OrderState.CANCELLED.name) break
                            val updatedWithElapsed = innerCheck.copy(elapsedSecondsInState = l)
                            kfcDao.insertOrder(updatedWithElapsed)
                        }
                    }
                }
            }
        }
    }

    // Manual customizer serialisation helpers
    private fun serializeExtrasList(list: List<ExtraOption>): String {
        return list.joinToString(",") { "${it.id}:${it.name}:${it.pricePence}" }
    }

    private fun parseExtrasJson(str: String): List<ExtraOption> {
        if (str.isEmpty()) return emptyList()
        return str.split(",").mapNotNull { part ->
            val sub = part.split(":")
            if (sub.size >= 3) {
                ExtraOption(sub[0], sub[1], sub[2].toIntOrNull() ?: 0)
            } else null
        }
    }

    // Pricing engine promotion code checker
    fun calculateDiscount(promoCode: String, subtotalPence: Int): Int {
        return when (promoCode.uppercase().trim()) {
            "COLONEL5" -> 500 // £5 off
            "CRISPY20" -> (subtotalPence * 0.2).toInt() // 20% off
            "FREEFEAST" -> (subtotalPence * 0.15).toInt() // 15% off
            else -> 0
        }
    }

    // Order items string helper (JSON)
    fun serializeCartItemsList(items: List<CartItem>): String {
        val array = JSONArray()
        for (item in items) {
            val obj = JSONObject()
            obj.put("id", item.id)
            obj.put("productId", item.product.id)
            obj.put("productName", item.product.name)
            obj.put("productCategory", item.product.category.name)
            obj.put("productPricePence", item.product.basePricePence)
            obj.put("quantity", item.quantity)
            obj.put("chickenType", item.chickenType.name)
            obj.put("selectedMealSize", item.selectedMealSize.name)
            obj.put("selectedDrink", item.selectedDrink)
            obj.put("selectedSide", item.selectedSide)
            
            val extrasArr = JSONArray()
            item.selectedExtras.forEach { ex ->
                val exObj = JSONObject()
                exObj.put("id", ex.id)
                exObj.put("name", ex.name)
                exObj.put("pricePence", ex.pricePence)
                extrasArr.put(exObj)
            }
            obj.put("extras", extrasArr)
            obj.put("totalPricePence", item.totalPricePence)
            array.put(obj)
        }
        return array.toString()
    }

    fun deserializeCartItemsList(jsonStr: String): List<CartItem> {
        val result = mutableListOf<CartItem>()
        try {
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                val pid = obj.getString("productId")
                val prod = products.find { it.id == pid } ?: Product(
                    id = pid,
                    name = obj.getString("productName"),
                    description = "",
                    basePricePence = obj.getInt("productPricePence"),
                    category = MenuCategory.valueOf(obj.getString("productCategory"))
                )

                val extrasList = mutableListOf<ExtraOption>()
                val extrasArr = obj.getJSONArray("extras")
                for (j in 0 until extrasArr.length()) {
                    val exObj = extrasArr.getJSONObject(j)
                    extrasList.add(
                        ExtraOption(
                            exObj.getString("id"),
                            exObj.getString("name"),
                            exObj.getInt("pricePence")
                        )
                    )
                }

                result.add(
                    CartItem(
                        id = obj.getString("id"),
                        product = prod,
                        quantity = obj.getInt("quantity"),
                        chickenType = ChickenType.valueOf(obj.getString("chickenType")),
                        selectedMealSize = MealSize.valueOf(obj.getString("selectedMealSize")),
                        selectedExtras = extrasList,
                        selectedDrink = obj.getString("selectedDrink"),
                        selectedSide = obj.getString("selectedSide")
                    )
                )
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return result
    }
}
