package com.example.model

import java.io.Serializable

enum class MenuCategory {
    BUCKETS,
    CHICKEN,
    BURGERS,
    WRAPS,
    SIDES,
    DRINKS,
    DESSERTS
}

data class Product(
    val id: String,
    val name: String,
    val description: String,
    val basePricePence: Int,
    val category: MenuCategory,
    val spicyLevel: Int = 0, // 0 = mild, 1 = spicy, 2 = very spicy
    val calories: Int = 450,
    val allergens: String = "Gluten, Milk, Eggs",
    val ingredients: String = "Original Recipe Chicken breast, toasted sesame bun, fresh lettuce, pepper mayonnaise.",
    val isVegetarian: Boolean = false
) : Serializable

data class ExtraOption(
    val id: String,
    val name: String,
    val pricePence: Int
) : Serializable

enum class MealSize {
    SOLO,
    REGULAR,
    LARGE
}

enum class ChickenType {
    ORIGINAL,
    ZINGER,
    EXTRA_SPICY
}

data class CartItem(
    val id: String, // unique cart item instance ID
    val product: Product,
    val quantity: Int,
    val chickenType: ChickenType = ChickenType.ORIGINAL,
    val selectedMealSize: MealSize = MealSize.SOLO,
    val selectedExtras: List<ExtraOption> = emptyList(),
    val selectedDrink: String = "Pepsi Max",
    val selectedSide: String = "Fries"
) : Serializable {
    val singleItemPricePence: Int
        get() {
            var total = product.basePricePence
            
            // Meal size upgrade
            total += when (selectedMealSize) {
                MealSize.SOLO -> 0
                MealSize.REGULAR -> 200 // +£2.00
                MealSize.LARGE -> 270   // +£2.70
            }
            
            // Customization extras
            total += selectedExtras.sumOf { it.pricePence }
            return total
        }

    val totalPricePence: Int
        get() = singleItemPricePence * quantity
}

data class Restaurant(
    val id: String,
    val name: String,
    val address: String,
    val postcode: String,
    val distanceMiles: Double,
    val deliveryMinStart: Int,
    val deliveryMinEnd: Int,
    val collectionMinStart: Int,
    val collectionMinEnd: Int,
    val deliveryFeePence: Int,
    val rating: Double
) : Serializable

enum class OrderState {
    CART,
    CHECKOUT,
    PAYMENT_PENDING,
    CONFIRMED,
    ACCEPTED,
    PREPARING,
    READY,
    COLLECTED,
    DELIVERING,
    DELIVERED,
    CANCELLED,
    REFUNDED,
    FAILED;

    val isActive: Boolean
        get() = this in listOf(CONFIRMED, ACCEPTED, PREPARING, READY, COLLECTED, DELIVERING)

    val label: String
        get() = when (this) {
            CART -> "Cart"
            CHECKOUT -> "Checkout"
            PAYMENT_PENDING -> "Payment Pending"
            CONFIRMED -> "Order Received"
            ACCEPTED -> "Kitchen Preparing"
            PREPARING -> "Chicken Cooking"
            READY -> "Order Packed"
            COLLECTED -> "Driver Collected"
            DELIVERING -> "On the Way"
            DELIVERED -> "Delivered"
            CANCELLED -> "Cancelled"
            REFUNDED -> "Refunded"
            FAILED -> "Failed"
        }
}

data class Order(
    val id: String, // e.g. KFC-48291
    val restaurantId: String,
    val restaurantName: String,
    val customerName: String,
    val customerPhone: String,
    val customerEmail: String,
    val postcode: String,
    val address: String,
    val deliveryInstructions: String,
    val itemsJson: String, // Serialized list of items
    val subtotalPence: Int,
    val deliveryFeePence: Int,
    val discountPence: Int,
    val totalPence: Int,
    val state: OrderState,
    val timestamp: Long,
    val courierName: String,
    val courierVehicle: String,
    val routeProgress: Float, // 0.0f to 1.0f
    val elapsedSecondsInState: Int = 0
) : Serializable
