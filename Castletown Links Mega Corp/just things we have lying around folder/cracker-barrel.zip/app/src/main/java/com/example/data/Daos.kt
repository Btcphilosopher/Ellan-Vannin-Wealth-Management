package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RestaurantDao {
    @Query("SELECT * FROM restaurants ORDER BY id ASC")
    fun getAll(): Flow<List<RestaurantEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(restaurants: List<RestaurantEntity>)

    @Update
    suspend fun update(restaurant: RestaurantEntity)

    @Query("SELECT * FROM restaurants WHERE id = :id")
    suspend fun getById(id: Int): RestaurantEntity?
}

@Dao
interface MenuItemDao {
    @Query("SELECT * FROM menu_items ORDER BY category, id ASC")
    fun getAll(): Flow<List<MenuItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(items: List<MenuItemEntity>)

    @Update
    suspend fun update(item: MenuItemEntity)

    @Query("SELECT * FROM menu_items WHERE id = :id")
    suspend fun getById(id: Int): MenuItemEntity?
}

@Dao
interface CartDao {
    @Query("SELECT * FROM cart_items")
    fun getAll(): Flow<List<CartItemEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: CartItemEntity)

    @Update
    suspend fun update(item: CartItemEntity)

    @Delete
    suspend fun delete(item: CartItemEntity)

    @Query("DELETE FROM cart_items")
    suspend fun clear()
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY dateCreated DESC")
    fun getAll(): Flow<List<OrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(order: OrderEntity): Long

    @Update
    suspend fun update(order: OrderEntity)

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun getById(id: Int): OrderEntity?
}

@Dao
interface WaitlistDao {
    @Query("SELECT * FROM waitlist_entries ORDER BY dateCreated ASC")
    fun getAll(): Flow<List<WaitlistEntryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(entry: WaitlistEntryEntity)

    @Update
    suspend fun update(entry: WaitlistEntryEntity)

    @Query("DELETE FROM waitlist_entries WHERE id = :id")
    suspend fun deleteById(id: Int)
}

@Dao
interface RetailProductDao {
    @Query("SELECT * FROM retail_products ORDER BY category, id ASC")
    fun getAll(): Flow<List<RetailProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(products: List<RetailProductEntity>)

    @Update
    suspend fun update(product: RetailProductEntity)

    @Query("SELECT * FROM retail_products WHERE id = :id")
    suspend fun getById(id: Int): RetailProductEntity?
}

@Dao
interface PegDao {
    @Query("SELECT * FROM peg_transactions ORDER BY dateCreated DESC")
    fun getAll(): Flow<List<PegTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: PegTransactionEntity)
}

@Dao
interface CateringDao {
    @Query("SELECT * FROM catering_orders ORDER BY dateCreated DESC")
    fun getAll(): Flow<List<CateringOrderEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(order: CateringOrderEntity)

    @Update
    suspend fun update(order: CateringOrderEntity)
}

@Dao
interface TableSessionDao {
    @Query("SELECT * FROM table_sessions ORDER BY id ASC")
    fun getAll(): Flow<List<TableSessionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(session: TableSessionEntity)

    @Update
    suspend fun update(session: TableSessionEntity)

    @Query("SELECT * FROM table_sessions WHERE id = :id")
    suspend fun getById(id: Int): TableSessionEntity?
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM menu_updates_audit ORDER BY timestamp DESC")
    fun getAll(): Flow<List<MenuUpdateAuditEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(audit: MenuUpdateAuditEntity)
}
