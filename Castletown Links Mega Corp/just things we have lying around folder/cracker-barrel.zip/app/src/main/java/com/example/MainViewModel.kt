package com.example

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: CrackerBarrelRepository

    init {
        val database = AppDatabase.getDatabase(application)
        repository = CrackerBarrelRepository(database)
        viewModelScope.launch(Dispatchers.IO) {
            repository.seedDatabaseIfEmpty()
        }
    }

    // Role switcher state
    private val _isHQView = MutableStateFlow(false)
    val isHQView: StateFlow<Boolean> = _isHQView.asStateFlow()

    // Customer App navigation: "HOME", "ORDER", "REWARDS", "STORES", "ACCOUNT"
    private val _customerTab = MutableStateFlow("HOME")
    val customerTab: StateFlow<String> = _customerTab.asStateFlow()

    // HQ App navigation: "DASHBOARD", "OPERATIONS", "MENU_MGMT", "RETAIL_HQ", "REWARDS_HQ"
    private val _hqTab = MutableStateFlow("DASHBOARD")
    val hqTab: StateFlow<String> = _hqTab.asStateFlow()

    // Simulation/Demo state: "NORMAL_DAY", "BREAKFAST_RUSH", "LUNCH_RUSH", "CURBSIDE_SURGE", "CATERING_DAY"
    private val _simulationMode = MutableStateFlow("NORMAL_DAY")
    val simulationMode: StateFlow<String> = _simulationMode.asStateFlow()

    // Live Flow data from DB
    val restaurants: StateFlow<List<RestaurantEntity>> = repository.allRestaurants
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val menuItems: StateFlow<List<MenuItemEntity>> = repository.allMenuItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartItems: StateFlow<List<CartItemEntity>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val waitlist: StateFlow<List<WaitlistEntryEntity>> = repository.allWaitlist
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val retailProducts: StateFlow<List<RetailProductEntity>> = repository.allRetailProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val pegLedger: StateFlow<List<PegTransactionEntity>> = repository.pegTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cateringOrders: StateFlow<List<CateringOrderEntity>> = repository.allCateringOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tableSessions: StateFlow<List<TableSessionEntity>> = repository.allTableSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val auditTrail: StateFlow<List<MenuUpdateAuditEntity>> = repository.auditTrail
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Customer selections
    private val _selectedStoreId = MutableStateFlow(184) // Default to Nashville Store
    val selectedStoreId: StateFlow<Int> = _selectedStoreId.asStateFlow()

    // Retrieve selected store helper
    val selectedStore: StateFlow<RestaurantEntity?> = combine(restaurants, selectedStoreId) { list, id ->
        list.find { it.id == id }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Current logged-in user details ("Sarah")
    val userName = "Sarah"
    val userEmail = "sarah.taylor@roadtrips.com"

    // Computed peg score
    val totalPegs: StateFlow<Int> = pegLedger.map { ledger ->
        ledger.sumOf { it.amount }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 127)

    // Waitlist tracking for Sarah
    private val _activeWaitlistEntry = MutableStateFlow<WaitlistEntryEntity?>(null)
    val activeWaitlistEntry: StateFlow<WaitlistEntryEntity?> = _activeWaitlistEntry.asStateFlow()

    // Pay & Go states
    private val _activeTableSession = MutableStateFlow<TableSessionEntity?>(null)
    val activeTableSession: StateFlow<TableSessionEntity?> = _activeTableSession.asStateFlow()
    
    private val _payAndGoSuccessMessage = MutableStateFlow<String?>(null)
    val payAndGoSuccessMessage: StateFlow<String?> = _payAndGoSuccessMessage.asStateFlow()

    // Ordering Flow states
    private val _orderType = MutableStateFlow("Pickup") // Dine-In, Pickup, Curbside, Delivery
    val orderType: StateFlow<String> = _orderType.asStateFlow()

    private val _orderSpaceNumber = MutableStateFlow("") // e.g. Space 4
    val orderSpaceNumber: StateFlow<String> = _orderSpaceNumber.asStateFlow()

    private val _activeOrder = MutableStateFlow<OrderEntity?>(null)
    val activeOrder: StateFlow<OrderEntity?> = _activeOrder.asStateFlow()

    private val _selectedCateringSize = MutableStateFlow(20)
    val selectedCateringSize: StateFlow<Int> = _selectedCateringSize.asStateFlow()

    private val _cateringSuccessMessage = MutableStateFlow<String?>(null)
    val cateringSuccessMessage: StateFlow<String?> = _cateringSuccessMessage.asStateFlow()

    // Methods
    fun setHQView(enabled: Boolean) {
        _isHQView.value = enabled
    }

    fun setCustomerTab(tab: String) {
        _customerTab.value = tab
    }

    fun setHQTab(tab: String) {
        _hqTab.value = tab
    }

    fun setStoreId(id: Int) {
        _selectedStoreId.value = id
    }

    fun setOrderType(type: String) {
        _orderType.value = type
    }

    fun setSpaceNumber(space: String) {
        _orderSpaceNumber.value = space
    }

    fun setCateringSize(size: Int) {
        _selectedCateringSize.value = size
    }

    // Cart actions
    fun addToCart(itemId: Int, isRetailItem: Boolean, name: String, category: String, price: Double, quantity: Int, modifiers: String = "") {
        viewModelScope.launch(Dispatchers.IO) {
            val existing = repository.cartItems.first().find { it.itemId == itemId && it.isRetailItem == isRetailItem }
            if (existing != null) {
                repository.cartDao.update(existing.copy(quantity = existing.quantity + quantity))
            } else {
                repository.cartDao.insert(
                    CartItemEntity(
                        itemId = itemId,
                        isRetailItem = isRetailItem,
                        name = name,
                        category = category,
                        price = price,
                        quantity = quantity,
                        modifiers = modifiers
                    )
                )
            }
        }
    }

    fun updateCartQuantity(cartItem: CartItemEntity, delta: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val nextQuantity = cartItem.quantity + delta
            if (nextQuantity <= 0) {
                repository.cartDao.delete(cartItem)
            } else {
                repository.cartDao.update(cartItem.copy(quantity = nextQuantity))
            }
        }
    }

    fun clearCart() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.cartDao.clear()
        }
    }

    // Waitlist actions
    fun joinWaitlist(storeId: Int, guestName: String, partySize: Int, phoneNumber: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val store = repository.allRestaurants.first().find { it.id == storeId } ?: return@launch
            val newPosition = repository.allWaitlist.first().filter { it.storeId == storeId }.size + 1
            val entry = WaitlistEntryEntity(
                storeId = storeId,
                storeName = store.name,
                partySize = partySize,
                guestName = guestName,
                phoneNumber = phoneNumber,
                status = "WAITING",
                position = newPosition,
                estimatedWaitMinutes = store.currentWaitMinutes,
                dateCreated = System.currentTimeMillis()
            )
            repository.waitlistDao.insert(entry)
            
            // Increment wait time on store
            repository.restaurantDao.update(store.copy(currentWaitMinutes = store.currentWaitMinutes + 4, status = "WAITLIST"))
            
            // Keep a local copy for Sarah to track
            if (guestName == userName) {
                // Find and save the entry
                val updatedWaitlist = repository.allWaitlist.first()
                _activeWaitlistEntry.value = entry
            }
        }
    }

    fun leaveWaitlist() {
        val entry = _activeWaitlistEntry.value
        if (entry != null) {
            viewModelScope.launch(Dispatchers.IO) {
                repository.waitlistDao.deleteById(entry.id)
                // Decrease store wait time slightly
                repository.allRestaurants.first().find { it.id == entry.storeId }?.let { store ->
                    repository.restaurantDao.update(store.copy(currentWaitMinutes = (store.currentWaitMinutes - 4).coerceAtLeast(0)))
                }
                _activeWaitlistEntry.value = null
            }
        }
    }

    // Pay & Go scanning and payment
    fun scanTableCheck(tableId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val session = repository.tableSessionDao.getById(tableId)
            _activeTableSession.value = session
            _payAndGoSuccessMessage.value = null
        }
    }

    fun payTableCheck(tipAmount: Double) {
        val session = _activeTableSession.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val updated = session.copy(status = "PAID", tipAmount = tipAmount)
            repository.tableSessionDao.update(updated)
            _activeTableSession.value = updated

            // Calculate total and add Pegs (+1 Peg per dollar spent, rounded)
            val subtotal = session.checkAmount + session.taxAmount + tipAmount
            val pegsEarned = subtotal.roundToInt()
            
            repository.pegDao.insert(
                PegTransactionEntity(
                    amount = pegsEarned,
                    description = "Pay & Go - ${session.storeName} (Table ${session.id})",
                    dateCreated = System.currentTimeMillis()
                )
            )

            _payAndGoSuccessMessage.value = "PAID SUCCESSFULLY! Earned +$pegsEarned Pegs. Enjoy your day!"
        }
    }

    fun clearPayAndGo() {
        _activeTableSession.value = null
        _payAndGoSuccessMessage.value = null
    }

    // Checkout / Place Order Flow
    fun checkoutOrder(tipAmount: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            val cartList = repository.cartItems.first()
            if (cartList.isEmpty()) return@launch

            val storeId = _selectedStoreId.value
            val store = repository.allRestaurants.first().find { it.id == storeId } ?: return@launch
            
            val subtotal = cartList.sumOf { it.price * it.quantity }
            val tax = subtotal * 0.0825
            val total = subtotal + tax + tipAmount
            
            val summary = cartList.joinToString(", ") { "${it.quantity}x ${it.name}" }
            
            val newOrder = OrderEntity(
                storeId = storeId,
                storeName = store.name,
                orderType = _orderType.value,
                status = "ORDER_PLACED",
                subtotal = subtotal,
                tax = tax,
                tip = tipAmount,
                total = total,
                spaceNumber = if (_orderType.value == "Curbside") _orderSpaceNumber.value.ifBlank { "Space 4" } else null,
                dateCreated = System.currentTimeMillis(),
                itemsText = summary
            )
            
            val orderId = repository.orderDao.insert(newOrder)
            val insertedOrder = repository.orderDao.getById(orderId.toInt())
            
            // Clear shopping cart
            repository.cartDao.clear()
            
            // Save as active customer order for status tracking
            _activeOrder.value = insertedOrder

            // Add peg rewards
            val pegsEarned = total.roundToInt()
            repository.pegDao.insert(
                PegTransactionEntity(
                    amount = pegsEarned,
                    description = "${_orderType.value} Order - ${store.name}",
                    dateCreated = System.currentTimeMillis()
                )
            )
        }
    }

    fun clearActiveOrder() {
        _activeOrder.value = null
        _orderSpaceNumber.value = ""
    }

    fun markCustomerArrived() {
        val order = _activeOrder.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val updated = order.copy(status = "CUSTOMER_ARRIVED")
            repository.orderDao.update(updated)
            _activeOrder.value = updated
        }
    }

    // Catering Ordering
    fun placeCateringOrder(guestCount: Int, date: String, time: String, type: String, itemsSummary: String, total: Double) {
        viewModelScope.launch(Dispatchers.IO) {
            val storeId = _selectedStoreId.value
            val store = repository.allRestaurants.first().find { it.id == storeId } ?: return@launch

            val order = CateringOrderEntity(
                storeId = storeId,
                storeName = store.name,
                guestCount = guestCount,
                dateScheduled = date,
                timeScheduled = time,
                fulfillmentType = type,
                itemsText = itemsSummary,
                total = total,
                status = "SCHEDULED",
                dateCreated = System.currentTimeMillis()
            )
            repository.cateringDao.insert(order)
            _cateringSuccessMessage.value = "CATERING ORDER SCHEDULED! $guestCount guests for $date at $time."
        }
    }

    fun clearCateringSuccess() {
        _cateringSuccessMessage.value = null
    }

    // HQ Actions: Progress Order Status
    fun updateOrderStatus(orderId: Int, newStatus: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val order = repository.orderDao.getById(orderId) ?: return@launch
            val updated = order.copy(status = newStatus)
            repository.orderDao.update(updated)
            
            // Sync current active order if it is the same one
            if (_activeOrder.value?.id == orderId) {
                _activeOrder.value = updated
            }
        }
    }

    // HQ Actions: Progress Catering Status
    fun updateCateringStatus(orderId: Int, newStatus: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val allCatering = repository.allCateringOrders.first()
            val order = allCatering.find { it.id == orderId } ?: return@launch
            repository.cateringDao.update(order.copy(status = newStatus))
        }
    }

    // HQ Actions: Table Management (Waitlist Control)
    fun seatWaitlistGuest(entryId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            val list = repository.allWaitlist.first()
            val entry = list.find { it.id == entryId } ?: return@launch
            repository.waitlistDao.deleteById(entryId)
            
            // If it is Sarah, update her active waitlist state
            if (_activeWaitlistEntry.value?.id == entryId) {
                _activeWaitlistEntry.value = entry.copy(status = "SEATED")
            }

            // Create a table session for seated guest
            val newSession = TableSessionEntity(
                id = (10..40).random(),
                storeId = entry.storeId,
                storeName = entry.storeName,
                checkAmount = 24.50 + (0..15).random() * 1.5,
                taxAmount = 2.49,
                status = "ORDERING",
                customerName = entry.guestName
            )
            repository.tableSessionDao.insert(newSession)
        }
    }

    fun removeWaitlistGuest(entryId: Int) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.waitlistDao.deleteById(entryId)
            if (_activeWaitlistEntry.value?.id == entryId) {
                _activeWaitlistEntry.value = null
            }
        }
    }

    fun updateTableStatus(tableId: Int, nextStatus: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val session = repository.tableSessionDao.getById(tableId) ?: return@launch
            repository.tableSessionDao.update(session.copy(status = nextStatus))
        }
    }

    // HQ Actions: Menu Management with Audit Logging
    fun editMenuItemPrice(itemId: Int, newPrice: Double, changedBy: String, reason: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val item = repository.menuItemDao.getById(itemId) ?: return@launch
            val oldPrice = item.price
            repository.menuItemDao.update(item.copy(price = newPrice))
            
            // Log audit
            repository.auditDao.insert(
                MenuUpdateAuditEntity(
                    itemName = item.name,
                    changeDetails = "Price changed \$${String.format("%.2f", oldPrice)} -> \$${String.format("%.2f", newPrice)}",
                    changedBy = changedBy,
                    timestamp = System.currentTimeMillis(),
                    reason = reason
                )
            )
        }
    }

    // HQ Actions: Stock transfer between stores
    fun transferRetailStock(productId: Int, amount: Int, description: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val product = repository.retailProductDao.getById(productId) ?: return@launch
            val newStock = (product.stockLevel + amount).coerceAtLeast(0)
            repository.retailProductDao.update(product.copy(stockLevel = newStock))
        }
    }

    // Rewards HQ: Grant or Deduct Pegs directly
    fun hqAdjustPegs(guestName: String, amount: Int, reason: String) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.pegDao.insert(
                PegTransactionEntity(
                    amount = amount,
                    description = "HQ Admin ($reason) for $guestName",
                    dateCreated = System.currentTimeMillis()
                )
            )
        }
    }

    // Dynamic Simulation Switch engine
    fun applySimulationMode(mode: String) {
        _simulationMode.value = mode
        viewModelScope.launch(Dispatchers.IO) {
            val storeList = repository.allRestaurants.first()
            val nashville = storeList.find { it.id == 184 } ?: return@launch
            val franklin = storeList.find { it.id == 221 } ?: return@launch
            
            when (mode) {
                "NORMAL_DAY" -> {
                    repository.restaurantDao.update(nashville.copy(status = "BUSY", currentWaitMinutes = 18))
                    repository.restaurantDao.update(franklin.copy(status = "WAITLIST", currentWaitMinutes = 12))
                }
                "BREAKFAST_RUSH" -> {
                    // Set extremely high wait times and Busy/Waitlist states
                    repository.restaurantDao.update(nashville.copy(status = "WAITLIST", currentWaitMinutes = 45))
                    repository.restaurantDao.update(franklin.copy(status = "BUSY", currentWaitMinutes = 35))
                    
                    // Trigger dynamic new waitlist guest
                    repository.waitlistDao.insert(
                        WaitlistEntryEntity(
                            storeId = 184,
                            storeName = "Nashville Store",
                            partySize = 5,
                            guestName = "Simulated Family ${ (10..99).random() }",
                            phoneNumber = "(615) 555-8821",
                            status = "WAITING",
                            position = 8,
                            estimatedWaitMinutes = 45,
                            dateCreated = System.currentTimeMillis()
                        )
                    )
                }
                "LUNCH_RUSH" -> {
                    repository.restaurantDao.update(nashville.copy(status = "BUSY", currentWaitMinutes = 30))
                    repository.restaurantDao.update(franklin.copy(status = "WAITLIST", currentWaitMinutes = 25))
                    
                    // Insert a simulated active order
                    val simulatedOrder = OrderEntity(
                        storeId = 184,
                        storeName = "Nashville Store",
                        orderType = "Pickup",
                        status = "PREPARING",
                        subtotal = 27.98,
                        tax = 2.31,
                        tip = 3.00,
                        total = 33.29,
                        spaceNumber = null,
                        dateCreated = System.currentTimeMillis(),
                        itemsText = "2x Chicken n' Dumplins, 1x Fresh Sweet Tea"
                    )
                    repository.orderDao.insert(simulatedOrder)
                }
                "CURBSIDE_SURGE" -> {
                    repository.restaurantDao.update(nashville.copy(status = "BUSY", currentWaitMinutes = 15))
                    
                    // Insert multiple active curbside orders to showcase curbside operations
                    val curbside1 = OrderEntity(
                        storeId = 184,
                        storeName = "Nashville Store",
                        orderType = "Curbside",
                        status = "READY",
                        subtotal = 21.48,
                        tax = 1.77,
                        tip = 2.00,
                        total = 25.25,
                        spaceNumber = "Space 2",
                        dateCreated = System.currentTimeMillis() - 15 * 60 * 1000,
                        itemsText = "1x Homestyle Meatloaf, 1x Lil' Pancakes"
                    )
                    val curbside2 = OrderEntity(
                        storeId = 184,
                        storeName = "Nashville Store",
                        orderType = "Curbside",
                        status = "CUSTOMER_ARRIVED",
                        subtotal = 15.49,
                        tax = 1.28,
                        tip = 2.00,
                        total = 18.77,
                        spaceNumber = "Space 4",
                        dateCreated = System.currentTimeMillis() - 25 * 60 * 1000,
                        itemsText = "1x Country Boy Breakfast"
                    )
                    repository.orderDao.insert(curbside1)
                    repository.orderDao.insert(curbside2)
                }
                "CATERING_DAY" -> {
                    // Seed some live catering orders
                    val cateringSim = CateringOrderEntity(
                        storeId = 184,
                        storeName = "Nashville Store",
                        guestCount = 40,
                        dateScheduled = "2026-09-25",
                        timeScheduled = "11:30 AM",
                        fulfillmentType = "DELIVERY",
                        itemsText = "Catering Homestyle Chicken Platter, Sweet Tea Gallons, Cornbread Tray",
                        total = 345.50,
                        status = "PREPARING",
                        dateCreated = System.currentTimeMillis()
                    )
                    repository.cateringDao.insert(cateringSim)
                }
            }
        }
    }
}
