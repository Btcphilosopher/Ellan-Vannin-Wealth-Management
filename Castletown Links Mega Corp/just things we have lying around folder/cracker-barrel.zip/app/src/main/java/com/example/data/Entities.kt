package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "restaurants")
data class RestaurantEntity(
    @PrimaryKey val id: Int,
    val name: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val status: String, // "OPEN", "CLOSED", "BUSY", "WAITLIST", "TEMPORARILY_UNAVAILABLE"
    val currentWaitMinutes: Int,
    val seatingCapacity: Int,
    val curbsideSpaceCount: Int,
    val hasCatering: Boolean,
    val hasGiftCards: Boolean,
    val hours: String,
    val holidayHours: String,
    val description: String,
    val isRetailStore: Boolean = true
)

@Entity(tableName = "menu_items")
data class MenuItemEntity(
    @PrimaryKey val id: Int,
    val category: String, // "BREAKFAST", "LUNCH", "DINNER", "BEVERAGES", "DESSERTS", "FAMILY_MEALS", "KIDS", "SEASONAL"
    val name: String,
    val description: String,
    val price: Double,
    val calories: Int,
    val allergens: String, // Comma separated, e.g., "Wheat, Milk, Eggs"
    val dietaryTags: String, // Comma separated, e.g., "Homestyle, Guest Favorite"
    val isAvailable: Boolean = true
)

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val itemId: Int, // Can be menuItemId or retailProductId
    val isRetailItem: Boolean,
    val name: String,
    val category: String,
    val price: Double,
    val quantity: Int,
    val modifiers: String // Comma-separated or selected options
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val storeId: Int,
    val storeName: String,
    val orderType: String, // "Dine-In", "Pickup", "Curbside", "Delivery"
    val status: String, // "CART", "ORDER_PLACED", "PREPARING", "READY", "CUSTOMER_ARRIVED", "HANDED_OFF", "COMPLETED", "CANCELLED"
    val subtotal: Double,
    val tax: Double,
    val tip: Double,
    val total: Double,
    val spaceNumber: String?, // For Curbside (e.g., "Space 4")
    val dateCreated: Long,
    val itemsText: String // Summary representation (e.g., "2x Chicken n' Dumplins, 1x Biscuits")
)

@Entity(tableName = "waitlist_entries")
data class WaitlistEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val storeId: Int,
    val storeName: String,
    val partySize: Int,
    val guestName: String,
    val phoneNumber: String,
    val status: String, // "WAITING", "TABLE_READY", "SEATED", "CANCELLED"
    val position: Int,
    val estimatedWaitMinutes: Int,
    val dateCreated: Long
)

@Entity(tableName = "retail_products")
data class RetailProductEntity(
    @PrimaryKey val id: Int,
    val category: String, // "HOME", "FOOD", "CANDY", "GIFTS", "DECOR", "SEASONAL", "CLOTHING", "COLLECTIBLES"
    val name: String,
    val price: Double,
    val description: String,
    val isAvailableOnline: Boolean,
    val isAvailableInStore: Boolean,
    val stockLevel: Int,
    val imageResName: String = ""
)

@Entity(tableName = "peg_transactions")
data class PegTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val amount: Int, // e.g. +42, -150
    val description: String, // e.g., "Restaurant purchase - Nashville #184", "Redeemed: Free Entrée"
    val dateCreated: Long
)

@Entity(tableName = "catering_orders")
data class CateringOrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val storeId: Int,
    val storeName: String,
    val guestCount: Int,
    val dateScheduled: String, // e.g., "2026-09-28"
    val timeScheduled: String, // e.g., "12:30 PM"
    val fulfillmentType: String, // "DELIVERY" or "PICKUP"
    val itemsText: String,
    val total: Double,
    val status: String, // "SCHEDULED", "PREPARING", "READY", "COLLECTED"
    val dateCreated: Long
)

@Entity(tableName = "table_sessions")
data class TableSessionEntity(
    @PrimaryKey val id: Int, // Table number (e.g. 24)
    val storeId: Int,
    val storeName: String,
    val checkAmount: Double,
    val taxAmount: Double,
    val tipAmount: Double = 0.0,
    val status: String, // "SEATED", "ORDERING", "DINING", "CHECK_REQUESTED", "PAID", "CLEANING"
    val customerName: String? = null
)

@Entity(tableName = "menu_updates_audit")
data class MenuUpdateAuditEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val itemName: String,
    val changeDetails: String, // e.g., "Price changed $14.99 -> $15.49"
    val changedBy: String, // "MERCHANDISING_ADMIN"
    val timestamp: Long,
    val reason: String // "MENU_UPDATE"
)
