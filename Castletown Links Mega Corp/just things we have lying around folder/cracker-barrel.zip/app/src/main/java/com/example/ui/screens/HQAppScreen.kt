package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainViewModel
import com.example.data.*
import com.example.ui.components.*
import com.example.ui.theme.BarrelBrown
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.HeritageRed
import com.example.ui.theme.GoldenHoney
import com.example.ui.theme.CreamPaper
import com.example.ui.theme.WarmCream
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontStyle
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HQAppScreen(viewModel: MainViewModel) {
    val hqTab by viewModel.hqTab.collectAsState()
    val simulationMode by viewModel.simulationMode.collectAsState()

    Scaffold(
        topBar = {
            Column {
                HQHeader()
                SimulationController(
                    currentMode = simulationMode,
                    onModeChange = { viewModel.applySimulationMode(it) }
                )
            }
        },
        bottomBar = {
            HQBottomBar(
                currentTab = hqTab,
                onTabSelected = { viewModel.setHQTab(it) }
            )
        },
        containerColor = Color(0xFF1F2421) // High density dark background for HQ
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = hqTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "hq_tab_anim"
            ) { targetTab ->
                when (targetTab) {
                    "DASHBOARD" -> HQDashboardScreen(viewModel)
                    "OPERATIONS" -> HQOperationsScreen(viewModel)
                    "MENU_MGMT" -> HQMenuManagementScreen(viewModel)
                    "RETAIL_HQ" -> HQRetailScreen(viewModel)
                    "REWARDS_HQ" -> HQRewardsScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun HQHeader() {
    Surface(
        color = Color(0xFF111412),
        contentColor = Color.White,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "CRACKER BARREL HQ",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    letterSpacing = 1.5.sp,
                    color = Color(0xFF90A4AE)
                )
            )
            Text(
                text = "SYSTEM ROLE: ENTERPRISE OPERATIONS OPERATOR",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.SemiBold,
                    color = ForestGreen,
                    letterSpacing = 1.sp
                )
            )
        }
    }
}

@Composable
fun HQBottomBar(currentTab: String, onTabSelected: (String) -> Unit) {
    NavigationBar(
        containerColor = Color(0xFF111412),
        contentColor = Color.White,
        modifier = Modifier.testTag("hq_bottom_nav")
    ) {
        val tabs = listOf(
            Triple("DASHBOARD", Icons.Default.Dashboard, "Dashboard"),
            Triple("OPERATIONS", Icons.Default.ToggleOn, "Live Ops"),
            Triple("MENU_MGMT", Icons.Default.BorderColor, "Menu Admin"),
            Triple("RETAIL_HQ", Icons.Default.Warehouse, "Retail"),
            Triple("REWARDS_HQ", Icons.Default.SupervisorAccount, "Rewards HQ")
        )

        tabs.forEach { (tabId, icon, label) ->
            val isSelected = currentTab == tabId
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tabId) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) ForestGreen else Color.White.copy(alpha = 0.5f)
                    )
                },
                label = {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) ForestGreen else Color.White.copy(alpha = 0.7f)
                        )
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = Color.White.copy(alpha = 0.05f)
                ),
                modifier = Modifier.testTag("hq_tab_item_$tabId")
            )
        }
    }
}

// ---------------- HQ DASHBOARD ----------------
@Composable
fun HQDashboardScreen(viewModel: MainViewModel) {
    val liveRestaurants by viewModel.restaurants.collectAsState()
    val liveOrders by viewModel.orders.collectAsState()
    val liveWaitlist by viewModel.waitlist.collectAsState()
    val liveCatering by viewModel.cateringOrders.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "NETWORK OPERATIONS DASHBOARD",
                style = MaterialTheme.typography.headlineLarge,
                color = Color.White
            )
            Text(
                text = "Real-time state summary across all 1,742 franchise locations.",
                style = MaterialTheme.typography.bodySmall,
                color = Color.LightGray
            )
            DottedDivider(color = Color.White.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 8.dp))
        }

        // Network Figures Card Grid
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HQMetricCard(
                        title = "FRANCHISE NETWORK",
                        value = "${liveRestaurants.size}/1,742",
                        subtitle = "Active Online Stores",
                        icon = Icons.Default.Storefront,
                        color = Color(0xFF64B5F6),
                        modifier = Modifier.weight(1f)
                    )
                    HQMetricCard(
                        title = "WAITLIST QUEUE",
                        value = "${liveWaitlist.size}",
                        subtitle = "Active Guest Parties",
                        icon = Icons.Default.People,
                        color = GoldenHoney,
                        modifier = Modifier.weight(1f)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    HQMetricCard(
                        title = "TOTAL LIVE ORDERS",
                        value = "${liveOrders.size}",
                        subtitle = "To-Go & Curbside Placed",
                        icon = Icons.Default.RestaurantMenu,
                        color = ForestGreen,
                        modifier = Modifier.weight(1f)
                    )
                    HQMetricCard(
                        title = "CATERING CONTRACTS",
                        value = "${liveCatering.size}",
                        subtitle = "Scheduled Platters",
                        icon = Icons.Default.SoupKitchen,
                        color = Color(0xFFE57373),
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Live Load metrics
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF263238)),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, Color(0xFF37474F))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("REGIONAL KITCHEN LOAD METRICS", style = MaterialTheme.typography.labelSmall, color = Color.LightGray, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    KitchenLoadBar("Breakfast Station", 0.75f, "BUSY")
                    Spacer(modifier = Modifier.height(10.dp))
                    KitchenLoadBar("Lunch/Dinner Platter Line", 0.45f, "STABLE")
                    Spacer(modifier = Modifier.height(10.dp))
                    KitchenLoadBar("Catering Bulk Production", 0.30f, "OPTIMAL")
                }
            }
        }

        // Live Incident Desk / System status log
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF263238)),
                shape = RoundedCornerShape(4.dp),
                border = BorderStroke(1.dp, Color(0xFF37474F))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .background(ForestGreen, RoundedCornerShape(4.dp))
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("SYSTEM HEURISTIC INTEGRITY", style = MaterialTheme.typography.labelSmall, color = Color.LightGray, fontWeight = FontWeight.Bold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "All API nodes running. WebSocket server active. Payment provider sandbox fully operational. Live database queries resolving <5ms.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.LightGray
                    )
                }
            }
        }
    }
}

@Composable
fun HQMetricCard(title: String, value: String, subtitle: String, icon: ImageVector, color: Color, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF263238)),
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, Color(0xFF37474F)),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, style = MaterialTheme.typography.labelSmall, color = Color.LightGray, fontSize = 9.sp)
                Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(16.dp))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = value, style = MaterialTheme.typography.headlineLarge, color = color, fontWeight = FontWeight.Bold)
            Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = Color.LightGray.copy(alpha = 0.7f), fontSize = 10.sp)
        }
    }
}

@Composable
fun KitchenLoadBar(label: String, progress: Float, status: String) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(text = label, style = MaterialTheme.typography.bodySmall, color = Color.White)
            Text(text = "$status (${(progress * 100).toInt()}%)", style = MaterialTheme.typography.bodySmall, color = if (progress > 0.7f) HeritageRed else ForestGreen, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        LinearProgressIndicator(
            progress = progress,
            color = if (progress > 0.7f) HeritageRed else ForestGreen,
            trackColor = Color.Gray.copy(alpha = 0.2f),
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp))
        )
    }
}

// ---------------- HQ OPERATIONS (LIVE QUEUES & TABLES) ----------------
@Composable
fun HQOperationsScreen(viewModel: MainViewModel) {
    val storeList by viewModel.restaurants.collectAsState()
    val selectedId by viewModel.selectedStoreId.collectAsState()
    val liveOrders by viewModel.orders.collectAsState()
    val liveWaitlist by viewModel.waitlist.collectAsState()
    val liveTables by viewModel.tableSessions.collectAsState()

    var activeSubTab by remember { mutableStateOf("LIVE_ORDERS") } // LIVE_ORDERS, WAITLIST, TABLES

    val activeStore = storeList.find { it.id == selectedId }
    val filteredOrders = liveOrders.filter { it.storeId == selectedId }
    val filteredWaitlist = liveWaitlist.filter { it.storeId == selectedId }
    val filteredTables = liveTables.filter { it.storeId == selectedId }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "STORE OPERATIONS HUB", style = MaterialTheme.typography.headlineMedium, color = Color.White)
                    Text(text = "Live Console: ${activeStore?.name ?: "Loading..."} (#$selectedId)", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                }
                
                // Location Selector Quick Menu
                Box(modifier = Modifier.background(Color(0xFF263238), RoundedCornerShape(4.dp)).padding(horizontal = 8.dp, vertical = 4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "STORE #$selectedId", color = Color.White, style = MaterialTheme.typography.labelSmall)
                        IconButton(
                            onClick = {
                                val nextId = if (selectedId == 184) 221 else 184
                                viewModel.setStoreId(nextId)
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(Icons.Default.SwapHoriz, contentDescription = "Switch", tint = Color.White)
                        }
                    }
                }
            }
            DottedDivider(color = Color.White.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 4.dp))
        }

        // Sub tab navigation: Live Orders, Waitlist, Table State Map
        item {
            Row(modifier = Modifier.fillMaxWidth().background(Color(0xFF111412), RoundedCornerShape(4.dp))) {
                val subTabs = listOf(
                    "LIVE_ORDERS" to "Live Orders (${filteredOrders.size})",
                    "WAITLIST" to "Waitlist Queue (${filteredWaitlist.size})",
                    "TABLES" to "Dining Tables (${filteredTables.size})"
                )
                
                subTabs.forEach { (tabCode, label) ->
                    val isSel = activeSubTab == tabCode
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isSel) ForestGreen else Color.Transparent)
                            .clickable { activeSubTab = tabCode }
                            .padding(vertical = 10.dp)
                            .testTag("ops_tab_$tabCode"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.White,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        // RENDER ACTIVE SUBTAB
        when (activeSubTab) {
            "LIVE_ORDERS" -> {
                if (filteredOrders.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text("No live restaurant orders placed in this store.", color = Color.LightGray, textAlign = TextAlign.Center)
                        }
                    }
                }
                
                items(filteredOrders) { order ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF263238)),
                        border = BorderStroke(1.dp, Color(0xFF37474F)),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.testTag("hq_order_card_${order.id}")
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = "Order #${order.id + 10480}", style = MaterialTheme.typography.titleMedium, color = Color.White)
                                    Text(text = "Fulfillment: ${order.orderType} ${if (order.spaceNumber != null) "- ${order.spaceNumber}" else ""}", style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
                                }
                                Box(
                                    modifier = Modifier
                                        .background(
                                            color = when (order.status) {
                                                "ORDER_PLACED" -> Color.Blue.copy(alpha = 0.2f)
                                                "PREPARING" -> GoldenHoney.copy(alpha = 0.2f)
                                                "READY" -> ForestGreen.copy(alpha = 0.2f)
                                                "CUSTOMER_ARRIVED" -> HeritageRed.copy(alpha = 0.2f)
                                                "COMPLETED" -> Color.Gray.copy(alpha = 0.2f)
                                                else -> Color.DarkGray
                                            },
                                            shape = RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text(
                                        text = order.status.replace("_", " "),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = when (order.status) {
                                            "ORDER_PLACED" -> Color(0xFF64B5F6)
                                            "PREPARING" -> GoldenHoney
                                            "READY" -> ForestGreen
                                            "CUSTOMER_ARRIVED" -> Color(0xFFEF9A9A)
                                            else -> Color.White
                                        }
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(text = "Items: ${order.itemsText}", style = MaterialTheme.typography.bodyMedium, color = Color.LightGray)
                            Text(text = "Subtotal: \$${String.format("%.2f", order.subtotal)} | Total: \$${String.format("%.2f", order.total)}", style = MaterialTheme.typography.labelSmall, color = ForestGreen)
                            
                            // Status update controller actions for staff
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                when (order.status) {
                                    "ORDER_PLACED" -> {
                                        Button(
                                            onClick = { viewModel.updateOrderStatus(order.id, "PREPARING") },
                                            colors = ButtonDefaults.buttonColors(containerColor = GoldenHoney),
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.weight(1f).testTag("hq_prep_btn_${order.id}")
                                        ) {
                                            Text("START PREPARING", style = MaterialTheme.typography.labelSmall, color = Color.Black)
                                        }
                                    }
                                    "PREPARING" -> {
                                        Button(
                                            onClick = { viewModel.updateOrderStatus(order.id, "READY") },
                                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.weight(1f).testTag("hq_ready_btn_${order.id}")
                                        ) {
                                            Text("MARK READY", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                    "READY" -> {
                                        Button(
                                            onClick = { viewModel.updateOrderStatus(order.id, "COMPLETED") },
                                            colors = ButtonDefaults.buttonColors(containerColor = Color.Gray),
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("COMPLETE HANDOFF", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                    "CUSTOMER_ARRIVED" -> {
                                        Button(
                                            onClick = { viewModel.updateOrderStatus(order.id, "COMPLETED") },
                                            colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.weight(1f).testTag("hq_deliver_btn_${order.id}")
                                        ) {
                                            Text("RUN OUT & DELIVERED", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                    "COMPLETED" -> {
                                        OutlinedButton(
                                            onClick = { viewModel.updateOrderStatus(order.id, "ORDER_PLACED") },
                                            border = BorderStroke(1.dp, Color.White),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                            shape = RoundedCornerShape(2.dp),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Text("RESET ORDER STATUS", style = MaterialTheme.typography.labelSmall)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "WAITLIST" -> {
                if (filteredWaitlist.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text("No guests waiting on the waitlist.", color = Color.LightGray)
                        }
                    }
                }
                
                items(filteredWaitlist) { entry ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF263238)),
                        border = BorderStroke(1.dp, Color(0xFF37474F)),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = entry.guestName, style = MaterialTheme.typography.titleMedium, color = Color.White)
                                Text(text = "Party Size: ${entry.partySize} guests | Phone: ${entry.phoneNumber}", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                                Text(text = "Position: #${entry.position} | Est Wait: ${entry.estimatedWaitMinutes} min", style = MaterialTheme.typography.labelSmall, color = GoldenHoney)
                            }
                            
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Button(
                                    onClick = { viewModel.seatWaitlistGuest(entry.id) },
                                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                    shape = RoundedCornerShape(2.dp),
                                    modifier = Modifier.testTag("hq_seat_btn_${entry.id}")
                                ) {
                                    Text("SEAT GUEST", style = MaterialTheme.typography.labelSmall)
                                }
                                IconButton(onClick = { viewModel.removeWaitlistGuest(entry.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Remove", tint = HeritageRed)
                                }
                            }
                        }
                    }
                }
            }

            "TABLES" -> {
                item {
                    Text(text = "TABLE STATUS MONITOR", style = MaterialTheme.typography.labelMedium, color = Color.LightGray)
                }
                
                items(filteredTables) { session ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF263238)),
                        border = BorderStroke(1.dp, Color(0xFF37474F)),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "Table #${session.id}", style = MaterialTheme.typography.titleMedium, color = Color.White)
                                Text(text = "Guest: ${session.customerName ?: "Walk-in"}", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                                Text(text = "Bill Check: \$${String.format("%.2f", session.checkAmount)}", style = MaterialTheme.typography.labelSmall, color = ForestGreen)
                            }
                            
                            // Table status badge cyclic dropdown simulated
                            Box(
                                modifier = Modifier
                                    .clickable {
                                        val next = when (session.status) {
                                            "ORDERING" -> "DINING"
                                            "DINING" -> "CHECK_REQUESTED"
                                            "CHECK_REQUESTED" -> "PAID"
                                            "PAID" -> "CLEANING"
                                            else -> "ORDERING"
                                        }
                                        viewModel.updateTableStatus(session.id, next)
                                    }
                                    .background(
                                        color = when (session.status) {
                                            "ORDERING" -> Color(0xFF64B5F6).copy(alpha = 0.2f)
                                            "DINING" -> GoldenHoney.copy(alpha = 0.2f)
                                            "CHECK_REQUESTED" -> Color(0xFFFFB74D).copy(alpha = 0.2f)
                                            "PAID" -> ForestGreen.copy(alpha = 0.2f)
                                            else -> Color.Gray.copy(alpha = 0.2f)
                                        },
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = session.status,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = when (session.status) {
                                        "ORDERING" -> Color(0xFF64B5F6)
                                        "DINING" -> GoldenHoney
                                        "CHECK_REQUESTED" -> Color(0xFFFFB74D)
                                        "PAID" -> ForestGreen
                                        else -> Color.White
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- HQ MENU MANAGEMENT & AUDIT TRAIL ----------------
@Composable
fun HQMenuManagementScreen(viewModel: MainViewModel) {
    val menuItemsList by viewModel.menuItems.collectAsState()
    val auditTrailLogs by viewModel.auditTrail.collectAsState()

    var selectedItemToEdit by remember { mutableStateOf<MenuItemEntity?>(null) }
    var priceInput by remember { mutableStateOf("") }
    var reasonInput by remember { mutableStateOf("MENU_UPDATE") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(text = "MENU PRICE CONTROL & AUDITING", style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Text(text = "Corporate merchandising adjustment. Every change logged on secure audit ledger.", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
            DottedDivider(color = Color.White.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 4.dp))
        }

        item {
            Text(text = "ACTIVE MENU ITEMS", style = MaterialTheme.typography.labelMedium, color = Color.LightGray)
        }

        items(menuItemsList) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF263238)),
                border = BorderStroke(1.dp, Color(0xFF37474F)),
                shape = RoundedCornerShape(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = item.name, style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Text(text = "Category: ${item.category} | ${item.calories} Cal", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                        Text(text = "Price: \$${String.format("%.2f", item.price)}", style = MaterialTheme.typography.labelLarge, color = GoldenHoney)
                    }
                    Button(
                        onClick = {
                            selectedItemToEdit = item
                            priceInput = String.format("%.2f", item.price)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.testTag("hq_edit_price_${item.id}")
                    ) {
                        Text("EDIT PRICE", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        item {
            DottedDivider(color = Color.White.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 8.dp))
            Text(text = "PRICE LEDGER SECURE AUDITING", style = MaterialTheme.typography.labelMedium, color = Color.LightGray)
        }

        if (auditTrailLogs.isEmpty()) {
            item {
                Text("No merchandising edits recorded. Auditing node clean.", color = Color.Gray, fontStyle = FontStyle.Italic)
            }
        } else {
            items(auditTrailLogs) { log ->
                val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
                val formattedDate = sdf.format(Date(log.timestamp))
                
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B221E)),
                    border = BorderStroke(0.5.dp, ForestGreen.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(text = "ITEM: ${log.itemName}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = GoldenHoney))
                        Text(text = "CHANGE: ${log.changeDetails}", style = MaterialTheme.typography.bodyMedium, color = Color.White)
                        Row(modifier = Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "By: ${log.changedBy}", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                            Text(text = "Reason: ${log.reason}", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                        }
                        Text(text = formattedDate, style = MaterialTheme.typography.bodySmall, color = Color.Gray, fontSize = 9.sp)
                    }
                }
            }
        }
    }

    // Edit price dialog
    if (selectedItemToEdit != null) {
        val item = selectedItemToEdit!!
        AlertDialog(
            onDismissRequest = { selectedItemToEdit = null },
            title = { Text("ADJUST PRICE - ${item.name}", fontFamily = FontFamily.Serif, color = BarrelBrown) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Original Price: \$${String.format("%.2f", item.price)}", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = priceInput,
                        onValueChange = { priceInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        label = { Text("New Price") },
                        modifier = Modifier.testTag("hq_price_input")
                    )
                    OutlinedTextField(
                        value = reasonInput,
                        onValueChange = { reasonInput = it },
                        label = { Text("Auditable Reason") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val nextPrice = priceInput.toDoubleOrNull()
                        if (nextPrice != null) {
                            viewModel.editMenuItemPrice(item.id, nextPrice, "MERCHANDISING_ADMIN", reasonInput)
                        }
                        selectedItemToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.testTag("hq_price_submit")
                ) {
                    Text("COMMIT PRICE CHANGE")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedItemToEdit = null }) {
                    Text("CANCEL", color = BarrelBrown)
                }
            },
            containerColor = CreamPaper
        )
    }
}

// ---------------- HQ RETAIL / INVENTORY CONTROL ----------------
@Composable
fun HQRetailScreen(viewModel: MainViewModel) {
    val productsList by viewModel.retailProducts.collectAsState()
    var selectedProductToRestock by remember { mutableStateOf<RetailProductEntity?>(null) }
    var restockAmountInput by remember { mutableStateOf("50") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(text = "OLD COUNTRY STORE WAREHOUSE INVENTORY", style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Text(text = "Stock transfers between centralized fulfillment distribution hubs and offline retail store sections.", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
            DottedDivider(color = Color.White.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 4.dp))
        }

        items(productsList) { product ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF263238)),
                border = BorderStroke(1.dp, Color(0xFF37474F)),
                shape = RoundedCornerShape(4.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = product.name, style = MaterialTheme.typography.titleMedium, color = Color.White)
                        Text(text = "Category: ${product.category}", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                        Text(text = "Current Stock Level: ${product.stockLevel}", style = MaterialTheme.typography.labelLarge, color = if (product.stockLevel < 20) HeritageRed else ForestGreen)
                    }
                    Button(
                        onClick = {
                            selectedProductToRestock = product
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        shape = RoundedCornerShape(2.dp),
                        modifier = Modifier.testTag("hq_restock_btn_${product.id}")
                    ) {
                        Text("TRANSFER STOCK", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
    }

    // Restock dialog
    if (selectedProductToRestock != null) {
        val product = selectedProductToRestock!!
        AlertDialog(
            onDismissRequest = { selectedProductToRestock = null },
            title = { Text("STOCK ALLOCATION TRANSFER", fontFamily = FontFamily.Serif, color = BarrelBrown) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Product: ${product.name}", style = MaterialTheme.typography.bodyLarge)
                    Text("Current stock: ${product.stockLevel}", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(
                        value = restockAmountInput,
                        onValueChange = { restockAmountInput = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        label = { Text("Transfer Quantity (add/subtract)") },
                        modifier = Modifier.testTag("restock_amount_field")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = restockAmountInput.toIntOrNull()
                        if (amount != null) {
                            viewModel.transferRetailStock(product.id, amount, "HQ restock transfer")
                        }
                        selectedProductToRestock = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.testTag("restock_submit_btn")
                ) {
                    Text("EXECUTE STOCK TRANSFER")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedProductToRestock = null }) {
                    Text("CANCEL", color = BarrelBrown)
                }
            },
            containerColor = CreamPaper
        )
    }
}

// ---------------- HQ REWARDS & CUSTOMER DATA MONITOR ----------------
@Composable
fun HQRewardsScreen(viewModel: MainViewModel) {
    val totalPegs by viewModel.totalPegs.collectAsState()
    val ledgerLogs by viewModel.pegLedger.collectAsState()

    var showAdjustPegsDialog by remember { mutableStateOf(false) }
    var adjustAmount by remember { mutableStateOf("50") }
    var adjustReason by remember { mutableStateOf("Corporate Surprise & Birthday Bonus") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(text = "REWARDS & MEMBER AUDITING CONSOLE", style = MaterialTheme.typography.headlineLarge, color = Color.White)
            Text(text = "Customer security, risk evaluation, and loyalty peg modifications. Authenticated audits enforced.", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
            DottedDivider(color = Color.White.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 4.dp))
        }

        // Selected Customer Profile Inspector
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF263238)),
                border = BorderStroke(1.dp, Color(0xFF37474F)),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("CUSTOMER IDENTITY PROFILE", style = MaterialTheme.typography.labelSmall, color = Color.LightGray, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Name: ${viewModel.userName}", style = MaterialTheme.typography.titleMedium, color = Color.White)
                    Text(text = "Email: ${viewModel.userEmail}", style = MaterialTheme.typography.bodyMedium, color = Color.LightGray)
                    Text(text = "Account Standing: ACTIVE | NO RISK DETECTED", style = MaterialTheme.typography.bodySmall, color = ForestGreen, fontWeight = FontWeight.Bold)
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Total Peg Balance", style = MaterialTheme.typography.labelSmall, color = Color.LightGray)
                            Text(text = "$totalPegs Pegs", style = MaterialTheme.typography.titleMedium, color = GoldenHoney, fontWeight = FontWeight.Bold)
                        }
                        
                        Button(
                            onClick = { showAdjustPegsDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier.testTag("hq_adjust_pegs_btn")
                        ) {
                            Text("MANUALLY ADJUST PEGS", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        item {
            Text(text = "CUSTOMER REWARDS LOGS & RISK JOURNAL", style = MaterialTheme.typography.labelMedium, color = Color.LightGray)
        }

        items(ledgerLogs) { tx ->
            val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
            val formattedDate = sdf.format(Date(tx.dateCreated))
            
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1B221E)),
                border = BorderStroke(0.5.dp, Color.White.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(2.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = tx.description, style = MaterialTheme.typography.bodyMedium, color = Color.White)
                        Text(text = formattedDate, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                    }
                    Text(
                        text = if (tx.amount >= 0) "+${tx.amount}" else "${tx.amount}",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (tx.amount >= 0) ForestGreen else HeritageRed,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    // Adjust pegs dialog
    if (showAdjustPegsDialog) {
        AlertDialog(
            onDismissRequest = { showAdjustPegsDialog = false },
            title = { Text("AUDITED ACCOUNT PEG ADJUSTMENT", fontFamily = FontFamily.Serif, color = BarrelBrown) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("User: ${viewModel.userName}", style = MaterialTheme.typography.bodyLarge)
                    OutlinedTextField(
                        value = adjustAmount,
                        onValueChange = { adjustAmount = it },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        label = { Text("Peg Modification (add/subtract)") },
                        modifier = Modifier.testTag("pegs_amount_field")
                    )
                    OutlinedTextField(
                        value = adjustReason,
                        onValueChange = { adjustReason = it },
                        label = { Text("Auditable Adjustment Reason") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amount = adjustAmount.toIntOrNull()
                        if (amount != null) {
                            viewModel.hqAdjustPegs(viewModel.userName, amount, adjustReason)
                        }
                        showAdjustPegsDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.testTag("pegs_submit_btn")
                ) {
                    Text("LOG LEDGER ENTRY")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAdjustPegsDialog = false }) {
                    Text("CANCEL", color = BarrelBrown)
                }
            },
            containerColor = CreamPaper
        )
    }
}
