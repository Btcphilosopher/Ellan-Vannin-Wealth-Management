package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.MainViewModel
import com.example.data.*
import com.example.ui.components.*
import com.example.ui.theme.BarrelBrown
import com.example.ui.theme.GoldenHoney
import com.example.ui.theme.HeritageRed
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.WarmCream
import com.example.ui.theme.CreamPaper
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun CustomerAppScreen(viewModel: MainViewModel) {
    val currentTab by viewModel.customerTab.collectAsState()
    val activeWaitlist by viewModel.activeWaitlistEntry.collectAsState()
    val activeOrder by viewModel.activeOrder.collectAsState()
    val tableSession by viewModel.activeTableSession.collectAsState()
    val simulationMode by viewModel.simulationMode.collectAsState()

    Scaffold(
        topBar = {
            Column {
                CustomerTopHeader()
                SimulationController(
                    currentMode = simulationMode,
                    onModeChange = { viewModel.applySimulationMode(it) }
                )
            }
        },
        bottomBar = {
            CustomerBottomBar(
                currentTab = currentTab,
                onTabSelected = { viewModel.setCustomerTab(it) }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn() togetherWith fadeOut()
                },
                label = "customer_tab_anim"
            ) { targetTab ->
                when (targetTab) {
                    "HOME" -> CustomerHomeScreen(viewModel)
                    "ORDER" -> CustomerOrderScreen(viewModel)
                    "REWARDS" -> CustomerRewardsScreen(viewModel)
                    "STORES" -> CustomerStoresScreen(viewModel)
                    "ACCOUNT" -> CustomerAccountScreen(viewModel)
                }
            }
        }
    }
}

@Composable
fun CustomerTopHeader() {
    Surface(
        color = BarrelBrown,
        contentColor = Color.White,
        modifier = Modifier.fillMaxWidth(),
        shadowElevation = 4.dp
    ) {
        Column(
            modifier = Modifier
                .padding(horizontal = 16.dp, vertical = 12.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "CRACKER BARREL",
                style = MaterialTheme.typography.displayMedium.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    letterSpacing = 1.sp,
                    color = GoldenHoney
                ),
                textAlign = TextAlign.Center
            )
            Text(
                text = "OLD COUNTRY STORE",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = FontFamily.Serif,
                    fontStyle = FontStyle.Italic,
                    letterSpacing = 2.sp,
                    color = Color.White.copy(alpha = 0.8f)
                ),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun CustomerBottomBar(currentTab: String, onTabSelected: (String) -> Unit) {
    NavigationBar(
        containerColor = BarrelBrown,
        contentColor = Color.White,
        modifier = Modifier.testTag("customer_bottom_nav")
    ) {
        val tabs = listOf(
            Triple("HOME", Icons.Default.Home, "Home"),
            Triple("ORDER", Icons.Default.RestaurantMenu, "Order"),
            Triple("REWARDS", Icons.Default.Star, "Rewards"),
            Triple("STORES", Icons.Default.Storefront, "Stores"),
            Triple("ACCOUNT", Icons.Default.Person, "Account")
        )

        tabs.forEach { (tabId, icon, label) ->
            val isSelected = currentTab == tabId
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tabId) },
                icon = {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = if (isSelected) GoldenHoney else Color.White.copy(alpha = 0.6f)
                    )
                },
                label = {
                    Text(
                        text = label,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) GoldenHoney else Color.White.copy(alpha = 0.8f)
                        )
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = Color.White.copy(alpha = 0.15f)
                ),
                modifier = Modifier.testTag("nav_tab_$tabId")
            )
        }
    }
}

// ---------------- HOME SCREEN ----------------
@Composable
fun CustomerHomeScreen(viewModel: MainViewModel) {
    val selectedStore by viewModel.selectedStore.collectAsState()
    val totalPegs by viewModel.totalPegs.collectAsState()
    val activeWaitlist by viewModel.activeWaitlistEntry.collectAsState()
    val activeOrder by viewModel.activeOrder.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcoming Greeting banner
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Good Morning, Sarah",
                    style = MaterialTheme.typography.displayMedium,
                    color = BarrelBrown
                )
                Text(
                    text = "Welcome to the digital front porch. Put your feet up and stay a while.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        fontStyle = FontStyle.Italic,
                        color = BarrelBrown.copy(alpha = 0.7f)
                    ),
                    modifier = Modifier.padding(top = 2.dp)
                )
                DottedDivider(modifier = Modifier.padding(vertical = 12.dp))
            }
        }

        // Active Order or Active Waitlist banner alert if present
        if (activeOrder != null) {
            item {
                ActiveOrderTrackerCard(activeOrder!!, onClear = { viewModel.clearActiveOrder() }, onArrive = { viewModel.markCustomerArrived() })
            }
        }

        if (activeWaitlist != null) {
            item {
                ActiveWaitlistHomeCard(activeWaitlist!!, onCancel = { viewModel.leaveWaitlist() })
            }
        }

        // Selected Local Restaurant Card
        item {
            selectedStore?.let { store ->
                TraditionalPaperCard(modifier = Modifier.testTag("local_store_card")) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, contentDescription = "Location", tint = HeritageRed, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Your Local Cracker Barrel",
                                    style = MaterialTheme.typography.labelMedium.copy(color = ForestGreen, fontWeight = FontWeight.Bold)
                                )
                                Text(text = store.name, style = MaterialTheme.typography.titleLarge, color = BarrelBrown)
                            }
                        }
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "Current Dining Wait",
                                    style = MaterialTheme.typography.bodySmall.copy(color = BarrelBrown.copy(alpha = 0.6f))
                                )
                                Text(
                                    text = if (store.currentWaitMinutes == 0) "No Wait!" else "${store.currentWaitMinutes} mins",
                                    style = MaterialTheme.typography.headlineMedium,
                                    color = if (store.currentWaitMinutes > 20) HeritageRed else ForestGreen,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        viewModel.setCustomerTab("STORES")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.testTag("home_waitlist_btn")
                                ) {
                                    Text("JOIN WAITLIST", style = MaterialTheme.typography.labelSmall)
                                }
                                
                                Button(
                                    onClick = {
                                        viewModel.setCustomerTab("ORDER")
                                        viewModel.setOrderType("Pickup")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = BarrelBrown),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.testTag("home_order_btn")
                                ) {
                                    Text("ORDER TO-GO", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Favorites Row
        item {
            Column {
                Text(
                    text = "YOUR FAVORITES",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = BarrelBrown.copy(alpha = 0.8f),
                        letterSpacing = 1.sp
                    )
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    val favorites = listOf(
                        Pair("Country Boy Breakfast", "$15.49"),
                        Pair("Chicken n' Dumplins", "$13.99"),
                        Pair("Biscuits & Gravy", "$5.99")
                    )
                    items(favorites) { (name, price) ->
                        Card(
                            modifier = Modifier
                                .width(150.dp)
                                .clickable {
                                    viewModel.setCustomerTab("ORDER")
                                },
                            colors = CardDefaults.cardColors(containerColor = CreamPaper),
                            border = BorderStroke(1.dp, BarrelBrown.copy(alpha = 0.15f)),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(80.dp)
                                        .background(GoldenHoney.copy(alpha = 0.2f), RoundedCornerShape(2.dp)),
                                    contentAlignment = Alignment.Center
                               ) {
                                    Icon(Icons.Default.Restaurant, contentDescription = "Food", tint = BarrelBrown, modifier = Modifier.size(28.dp))
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = name,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = BarrelBrown),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(text = price, style = MaterialTheme.typography.labelSmall.copy(color = ForestGreen))
                            }
                        }
                    }
                }
            }
        }

        // Peg Reward status card
        item {
            TraditionalPaperCard {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "CRACKER BARREL REWARDS",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = ForestGreen, letterSpacing = 1.sp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(text = "$totalPegs", style = MaterialTheme.typography.displayLarge.copy(color = GoldenHoney))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(text = "PEGS", style = MaterialTheme.typography.labelLarge.copy(color = BarrelBrown), modifier = Modifier.padding(bottom = 6.dp))
                        }
                        Text(text = "Next reward: Any Homestyle Entrée", style = MaterialTheme.typography.bodySmall.copy(color = BarrelBrown.copy(alpha = 0.6f)))
                    }
                    Button(
                        onClick = { viewModel.setCustomerTab("REWARDS") },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("VIEW REWARDS", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // Old Country Store Card
        item {
            TraditionalPaperCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .background(Color(0xFFEFEBE9)),
                        contentAlignment = Alignment.Center
                    ) {
                        // Illustrated Banner Representation
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.LocalMall, contentDescription = "Store", tint = BarrelBrown, modifier = Modifier.size(42.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "THE OLD COUNTRY STORE",
                                style = MaterialTheme.typography.headlineLarge,
                                color = BarrelBrown
                            )
                            Text(
                                text = "Handmade Rockers, Nostalgic Candies, Cast Iron & Gifts",
                                style = MaterialTheme.typography.labelSmall.copy(color = BarrelBrown.copy(alpha = 0.7f))
                            )
                        }
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Explore Our Autumn Catalog", style = MaterialTheme.typography.titleLarge, color = BarrelBrown)
                            Text(text = "Bring the roadside warm feeling home with you.", style = MaterialTheme.typography.bodySmall.copy(color = BarrelBrown.copy(alpha = 0.6f)))
                        }
                        Button(
                            onClick = {
                                viewModel.setCustomerTab("ORDER")
                                // Automatically choose the store selection later
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BarrelBrown),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("SHOP PRODUCTS", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActiveWaitlistHomeCard(entry: WaitlistEntryEntity, onCancel: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
        border = BorderStroke(1.5.dp, GoldenHoney),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.HourglassEmpty, contentDescription = "Waitlist", tint = GoldenHoney, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "YOU'RE ON THE WAITLIST!", style = MaterialTheme.typography.titleLarge.copy(color = BarrelBrown))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "Store: ${entry.storeName}", style = MaterialTheme.typography.bodyMedium.copy(color = BarrelBrown, fontWeight = FontWeight.Bold))
            Row(modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Column {
                    Text(text = "Position", style = MaterialTheme.typography.labelMedium.copy(color = BarrelBrown.copy(alpha = 0.6f)))
                    Text(text = "#${entry.position}", style = MaterialTheme.typography.headlineLarge, color = BarrelBrown)
                }
                Column {
                    Text(text = "Est. Wait", style = MaterialTheme.typography.labelMedium.copy(color = BarrelBrown.copy(alpha = 0.6f)))
                    Text(text = "${entry.estimatedWaitMinutes} min", style = MaterialTheme.typography.headlineLarge, color = BarrelBrown)
                }
                Column {
                    Text(text = "Party Size", style = MaterialTheme.typography.labelMedium.copy(color = BarrelBrown.copy(alpha = 0.6f)))
                    Text(text = "${entry.partySize} guests", style = MaterialTheme.typography.headlineLarge, color = BarrelBrown)
                }
            }
            
            Text(
                text = "We'll notify you here and send a text when your table is ready. Check in with the host upon arrival.",
                style = MaterialTheme.typography.bodySmall.copy(color = BarrelBrown.copy(alpha = 0.7f)),
                modifier = Modifier.padding(vertical = 4.dp)
            )
            
            OutlinedButton(
                onClick = onCancel,
                border = BorderStroke(1.dp, HeritageRed),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = HeritageRed),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().testTag("home_cancel_waitlist_btn")
            ) {
                Text("CANCEL WAITLIST REGISTRATION", style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
fun ActiveOrderTrackerCard(order: OrderEntity, onClear: () -> Unit, onArrive: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
        border = BorderStroke(1.5.dp, ForestGreen),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.CheckCircle, contentDescription = "Active order", tint = ForestGreen, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(text = "ACTIVE ORDER IN PROGRESS", style = MaterialTheme.typography.titleLarge.copy(color = BarrelBrown))
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "Status: ${order.status.replace("_", " ")}", style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold, color = ForestGreen))
            Text(text = "Fulfillment: ${order.orderType}", style = MaterialTheme.typography.bodyMedium.copy(color = BarrelBrown))
            Text(text = "Items: ${order.itemsText}", style = MaterialTheme.typography.bodyMedium.copy(color = BarrelBrown.copy(alpha = 0.7f)))
            
            Spacer(modifier = Modifier.height(8.dp))
            
            // Progress Bar timeline representation
            val progressVal = when (order.status) {
                "ORDER_PLACED" -> 0.25f
                "PREPARING" -> 0.5f
                "READY" -> 0.75f
                "CUSTOMER_ARRIVED" -> 0.9f
                "COMPLETED" -> 1.0f
                else -> 0.1f
            }
            
            Column(modifier = Modifier.fillMaxWidth()) {
                LinearProgressIndicator(
                    progress = progressVal,
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = ForestGreen,
                    trackColor = ForestGreen.copy(alpha = 0.2f)
                )
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("Placed", style = MaterialTheme.typography.labelMedium, fontSize = 9.sp, color = if (progressVal >= 0.25f) ForestGreen else Color.Gray)
                    Text("Preparing", style = MaterialTheme.typography.labelMedium, fontSize = 9.sp, color = if (progressVal >= 0.5f) ForestGreen else Color.Gray)
                    Text("Ready", style = MaterialTheme.typography.labelMedium, fontSize = 9.sp, color = if (progressVal >= 0.75f) ForestGreen else Color.Gray)
                    Text("Complete", style = MaterialTheme.typography.labelMedium, fontSize = 9.sp, color = if (progressVal >= 1.0f) ForestGreen else Color.Gray)
                }
            }

            // Curbside "I'm Here!" logic
            if (order.orderType == "Curbside" && order.status == "READY") {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onArrive,
                    colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth().testTag("curbside_im_here_btn")
                ) {
                    Text("I'M HERE (PARKED IN SPACE 4)", style = MaterialTheme.typography.labelSmall)
                }
            } else if (order.status == "CUSTOMER_ARRIVED") {
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(GoldenHoney.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Text(
                        text = "Runner is delivering your meal out to Space 4. Please sit back and enjoy!",
                        style = MaterialTheme.typography.bodySmall,
                        color = BarrelBrown,
                        textAlign = TextAlign.Center
                    )
                }
            } else if (order.status == "COMPLETED" || order.status == "HANDED_OFF") {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onClear,
                    colors = ButtonDefaults.buttonColors(containerColor = BarrelBrown),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth().testTag("clear_order_tracker_btn")
                ) {
                    Text("DISMISS TRACKER & ENJOY MEAL", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

// ---------------- ORDER SCREEN ----------------
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CustomerOrderScreen(viewModel: MainViewModel) {
    val items by viewModel.menuItems.collectAsState()
    val retailList by viewModel.retailProducts.collectAsState()
    val cartList by viewModel.cartItems.collectAsState()
    val orderType by viewModel.orderType.collectAsState()
    val spaceNumber by viewModel.orderSpaceNumber.collectAsState()
    val selectedStore by viewModel.selectedStore.collectAsState()

    var activeSubCategory by remember { mutableStateOf("BREAKFAST") }
    var shopType by remember { mutableStateOf("RESTAURANT") } // "RESTAURANT" or "RETAIL"
    var showCartDialog by remember { mutableStateOf(false) }
    var showCheckoutScreen by remember { mutableStateOf(false) }

    // Item detail dialog state
    var selectedItemForDetail by remember { mutableStateOf<MenuItemEntity?>(null) }
    var selectedRetailForDetail by remember { mutableStateOf<RetailProductEntity?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Selector: Restaurant Menu vs Country Store Retail
        Row(modifier = Modifier.fillMaxWidth()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(if (shopType == "RESTAURANT") WarmCream else BarrelBrown.copy(alpha = 0.1f))
                    .border(
                        BorderStroke(
                            1.dp,
                            if (shopType == "RESTAURANT") BarrelBrown else Color.Transparent
                        )
                    )
                    .clickable { shopType = "RESTAURANT" }
                    .padding(vertical = 12.dp)
                    .testTag("shop_restaurant_tab"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "RESTAURANT MENU",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (shopType == "RESTAURANT") BarrelBrown else BarrelBrown.copy(alpha = 0.6f)
                    )
                )
            }
            Box(
                modifier = Modifier
                    .weight(1f)
                    .background(if (shopType == "RETAIL") WarmCream else BarrelBrown.copy(alpha = 0.1f))
                    .border(
                        BorderStroke(
                            1.dp,
                            if (shopType == "RETAIL") BarrelBrown else Color.Transparent
                        )
                    )
                    .clickable { shopType = "RETAIL" }
                    .padding(vertical = 12.dp)
                    .testTag("shop_retail_tab"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "COUNTRY STORE RETAIL",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = if (shopType == "RETAIL") BarrelBrown else BarrelBrown.copy(alpha = 0.6f)
                    )
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CreamPaper)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "Store: ${selectedStore?.name ?: "Loading..."}",
                    style = MaterialTheme.typography.labelSmall,
                    color = BarrelBrown
                )
                Text(
                    text = "Fulfillment: $orderType",
                    style = MaterialTheme.typography.labelSmall,
                    color = ForestGreen,
                    fontWeight = FontWeight.Bold
                )
            }

            // Quick checkout button if cart is not empty
            val cartCount = cartList.sumOf { it.quantity }
            Badge(
                containerColor = HeritageRed,
                contentColor = Color.White,
                modifier = Modifier
                    .clickable { showCartDialog = true }
                    .testTag("cart_badge_btn")
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = "Cart", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(text = "$cartCount items", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // Subcategory filters list
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFFEFEBE9))
                .padding(vertical = 6.dp),
            contentPadding = PaddingValues(horizontal = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            if (shopType == "RESTAURANT") {
                val categories = listOf("BREAKFAST", "LUNCH", "DINNER", "BEVERAGES", "DESSERTS", "KIDS", "SEASONAL")
                items(categories) { cat ->
                    val isSel = activeSubCategory == cat
                    Surface(
                        modifier = Modifier
                            .clickable { activeSubCategory = cat }
                            .testTag("menu_filter_$cat"),
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSel) BarrelBrown else Color.White,
                        border = BorderStroke(1.dp, BarrelBrown.copy(alpha = 0.2f))
                    ) {
                        Text(
                            text = cat,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSel) Color.White else BarrelBrown,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            } else {
                val retailCategories = listOf("HOME", "DECOR", "CANDY", "FOOD", "SEASONAL", "GIFTS")
                items(retailCategories) { cat ->
                    val isSel = activeSubCategory == cat
                    Surface(
                        modifier = Modifier
                            .clickable { activeSubCategory = cat }
                            .testTag("retail_filter_$cat"),
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSel) ForestGreen else Color.White,
                        border = BorderStroke(1.dp, ForestGreen.copy(alpha = 0.2f))
                    ) {
                        Text(
                            text = cat,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSel) Color.White else ForestGreen,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Items Grid/List
        if (shopType == "RESTAURANT") {
            val filteredMenu = items.filter { it.category == activeSubCategory }
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (filteredMenu.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text("No items available in this category.", color = Color.Gray, textAlign = TextAlign.Center)
                        }
                    }
                }
                items(filteredMenu) { item ->
                    TraditionalPaperCard {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedItemForDetail = item }
                                .padding(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = item.name, style = MaterialTheme.typography.titleMedium, color = BarrelBrown)
                                Text(text = "${item.calories} Cal", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                Text(
                                    text = item.description,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = BarrelBrown.copy(alpha = 0.7f),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(text = "\$${String.format("%.2f", item.price)}", style = MaterialTheme.typography.labelLarge.copy(color = ForestGreen))
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            // Vector box indicating item
                            Box(
                                modifier = Modifier
                                    .size(70.dp)
                                    .background(GoldenHoney.copy(alpha = 0.15f), RoundedCornerShape(4.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Restaurant, contentDescription = "Item Photo", tint = BarrelBrown, modifier = Modifier.size(32.dp))
                            }
                        }
                    }
                }
            }
        } else {
            val filteredRetail = retailList.filter { it.category == activeSubCategory }
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .weight(1f)
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (filteredRetail.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                            Text("No retail items available in this category.", color = Color.Gray, textAlign = TextAlign.Center)
                        }
                    }
                }
                items(filteredRetail) { product ->
                    TraditionalPaperCard {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedRetailForDetail = product }
                                .padding(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = product.name, style = MaterialTheme.typography.titleMedium, color = BarrelBrown)
                                Text(text = product.description, style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp), color = BarrelBrown.copy(alpha = 0.7f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = "\$${String.format("%.2f", product.price)}", style = MaterialTheme.typography.labelLarge.copy(color = ForestGreen))
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = "In stock: ${product.stockLevel}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (product.stockLevel < 20) HeritageRed else ForestGreen
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .size(70.dp)
                                    .background(ForestGreen.copy(alpha = 0.15f), RoundedCornerShape(4.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.LocalMall, contentDescription = "Item Photo", tint = ForestGreen, modifier = Modifier.size(32.dp))
                            }
                        }
                    }
                }
            }
        }
    }

    // Food Item Detail Modal dialog
    if (selectedItemForDetail != null) {
        val item = selectedItemForDetail!!
        AlertDialog(
            onDismissRequest = { selectedItemForDetail = null },
            title = { Text(item.name, fontFamily = FontFamily.Serif, color = BarrelBrown) },
            text = {
                Column {
                    Text("${item.calories} Calories | Allergens: ${item.allergens.ifBlank { "None" }}", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(item.description, style = MaterialTheme.typography.bodyMedium, color = BarrelBrown)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Dietary Tags: ${item.dietaryTags}", style = MaterialTheme.typography.labelSmall.copy(color = ForestGreen))
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addToCart(item.id, false, item.name, item.category, item.price, 1)
                        selectedItemForDetail = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.testTag("add_food_confirm_btn")
                ) {
                    Text("ADD TO BAG - \$${String.format("%.2f", item.price)}")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedItemForDetail = null }) {
                    Text("CANCEL", color = BarrelBrown)
                }
            },
            containerColor = CreamPaper
        )
    }

    // Retail Item Detail Modal dialog
    if (selectedRetailForDetail != null) {
        val product = selectedRetailForDetail!!
        AlertDialog(
            onDismissRequest = { selectedRetailForDetail = null },
            title = { Text(product.name, fontFamily = FontFamily.Serif, color = BarrelBrown) },
            text = {
                Column {
                    Text("Category: ${product.category}", style = MaterialTheme.typography.labelSmall.copy(color = ForestGreen))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(product.description, style = MaterialTheme.typography.bodyMedium, color = BarrelBrown)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Available Online: ${if (product.isAvailableOnline) "Yes" else "No"}", style = MaterialTheme.typography.bodySmall)
                    Text("Available In-Store: ${if (product.isAvailableInStore) "Yes" else "No"}", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addToCart(product.id, true, product.name, product.category, product.price, 1)
                        selectedRetailForDetail = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.testTag("add_retail_confirm_btn")
                ) {
                    Text("ADD TO BAG - \$${String.format("%.2f", product.price)}")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedRetailForDetail = null }) {
                    Text("CANCEL", color = BarrelBrown)
                }
            },
            containerColor = CreamPaper
        )
    }

    // Cart Dialog / Modal
    if (showCartDialog) {
        val subtotal = cartList.sumOf { it.price * it.quantity }
        AlertDialog(
            onDismissRequest = { showCartDialog = false },
            title = { Text("YOUR CUSTOMER BAG", fontFamily = FontFamily.Serif, color = BarrelBrown, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth()) {
                    if (cartList.isEmpty()) {
                        Text("Your bag is currently empty. Visit our restaurant menu or country store to grab some homestyle goods!", color = Color.Gray)
                    } else {
                        LazyColumn(
                            modifier = Modifier.height(260.dp).fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(cartList) { cartItem ->
                                Row(
                                    modifier = Modifier.fillMaxWidth().background(WarmCream.copy(alpha = 0.5f)).padding(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = cartItem.name, style = MaterialTheme.typography.labelMedium, color = BarrelBrown)
                                        Text(text = "\$${String.format("%.2f", cartItem.price)}", style = MaterialTheme.typography.labelSmall.copy(color = ForestGreen))
                                    }
                                    
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        IconButton(onClick = { viewModel.updateCartQuantity(cartItem, -1) }) {
                                            Icon(Icons.Default.Remove, contentDescription = "Less", tint = HeritageRed)
                                        }
                                        Text(text = "${cartItem.quantity}", style = MaterialTheme.typography.labelLarge)
                                        IconButton(onClick = { viewModel.updateCartQuantity(cartItem, 1) }) {
                                            Icon(Icons.Default.Add, contentDescription = "More", tint = ForestGreen)
                                        }
                                    }
                                }
                            }
                        }
                        
                        DottedDivider(modifier = Modifier.padding(vertical = 8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Estimated Subtotal", style = MaterialTheme.typography.titleMedium)
                            Text("\$${String.format("%.2f", subtotal)}", style = MaterialTheme.typography.titleMedium, color = ForestGreen)
                        }
                    }
                }
            },
            confirmButton = {
                if (cartList.isNotEmpty()) {
                    Button(
                        onClick = {
                            showCartDialog = false
                            showCheckoutScreen = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.testTag("checkout_order_btn")
                    ) {
                        Text("PROCEED TO CHECKOUT")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showCartDialog = false }) {
                    Text("KEEP BROWSING", color = BarrelBrown)
                }
            },
            containerColor = CreamPaper
        )
    }

    // Checkout Details dialog
    if (showCheckoutScreen) {
        val subtotal = cartList.sumOf { it.price * it.quantity }
        val tax = subtotal * 0.0825
        var tipSelected by remember { mutableStateOf(3.00) }
        var spaceNoInput by remember { mutableStateOf(spaceNumber) }
        val total = subtotal + tax + tipSelected

        AlertDialog(
            onDismissRequest = { showCheckoutScreen = false },
            title = { Text("CONFIRM ORDER", fontFamily = FontFamily.Serif, color = BarrelBrown, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("Fulfillment Method:", style = MaterialTheme.typography.labelLarge, color = BarrelBrown)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        val types = listOf("Dine-In", "Pickup", "Curbside", "Delivery")
                        types.forEach { type ->
                            val isSel = orderType == type
                            Surface(
                                modifier = Modifier
                                    .clickable { viewModel.setOrderType(type) }
                                    .weight(1f),
                                color = if (isSel) BarrelBrown else Color.White,
                                border = BorderStroke(1.dp, BarrelBrown.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = type,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSel) Color.White else BarrelBrown,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }

                    if (orderType == "Curbside") {
                        Text("Curbside Parking Space:", style = MaterialTheme.typography.labelLarge, color = BarrelBrown)
                        OutlinedTextField(
                            value = spaceNoInput,
                            onValueChange = {
                                spaceNoInput = it
                                viewModel.setSpaceNumber(it)
                            },
                            placeholder = { Text("e.g. Space 4") },
                            modifier = Modifier.fillMaxWidth().testTag("curbside_space_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = BarrelBrown,
                                cursorColor = BarrelBrown
                            )
                        )
                    }

                    Text("Add a Warm Tip for Store Staff:", style = MaterialTheme.typography.labelLarge, color = BarrelBrown)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        val tips = listOf(1.50, 3.00, 5.00)
                        tips.forEach { t ->
                            val isSel = tipSelected == t
                            Surface(
                                modifier = Modifier
                                    .clickable { tipSelected = t }
                                    .weight(1f),
                                color = if (isSel) ForestGreen else Color.White,
                                border = BorderStroke(1.dp, ForestGreen.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "\$${String.format("%.2f", t)}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSel) Color.White else ForestGreen,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }

                    DottedDivider(modifier = Modifier.padding(vertical = 4.dp))
                    
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Subtotal:", style = MaterialTheme.typography.bodyMedium)
                        Text("\$${String.format("%.2f", subtotal)}", style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Tax (8.25%):", style = MaterialTheme.typography.bodyMedium)
                        Text("\$${String.format("%.2f", tax)}", style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Tip Added:", style = MaterialTheme.typography.bodyMedium)
                        Text("\$${String.format("%.2f", tipSelected)}", style = MaterialTheme.typography.bodyMedium)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Total Due:", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = BarrelBrown)
                        Text("\$${String.format("%.2f", total)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = ForestGreen)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.checkoutOrder(tipSelected)
                        showCheckoutScreen = false
                        viewModel.setCustomerTab("HOME") // Send to home tab to watch status progress!
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.testTag("pay_order_submit_btn")
                ) {
                    Text("AUTHORIZE & SUBMIT ORDER")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCheckoutScreen = false }) {
                    Text("CANCEL", color = BarrelBrown)
                }
            },
            containerColor = CreamPaper
        )
    }
}

// ---------------- REWARDS SCREEN ----------------
@Composable
fun CustomerRewardsScreen(viewModel: MainViewModel) {
    val totalPegs by viewModel.totalPegs.collectAsState()
    val ledger by viewModel.pegLedger.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "CRACKER BARREL REWARDS",
                    style = MaterialTheme.typography.displayMedium,
                    color = BarrelBrown,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "The more you dine and shop, the more Pegs you earn. Redeem them for real food and general store goodies!",
                    style = MaterialTheme.typography.bodySmall.copy(color = BarrelBrown.copy(alpha = 0.6f)),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 4.dp)
                )
                DottedDivider(modifier = Modifier.padding(vertical = 12.dp))
            }
        }

        // Animated Peg status board
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CreamPaper),
                border = BorderStroke(1.5.dp, BarrelBrown),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(text = "YOUR ACTIVE BALANCE", style = MaterialTheme.typography.labelSmall.copy(color = ForestGreen, fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(text = "$totalPegs", style = MaterialTheme.typography.displayLarge.copy(fontSize = 52.sp, color = GoldenHoney))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(text = "Pegs Available", style = MaterialTheme.typography.titleMedium, color = BarrelBrown, modifier = Modifier.padding(bottom = 8.dp))
                    }
                    
                    Spacer(modifier = Modifier.height(10.dp))
                    // Circular Gauge
                    Box(contentAlignment = Alignment.Center, modifier = Modifier.size(100.dp)) {
                        CircularProgressIndicator(
                            progress = (totalPegs % 200) / 200f,
                            color = ForestGreen,
                            strokeWidth = 8.dp,
                            modifier = Modifier.fillMaxSize()
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(text = "${200 - (totalPegs % 200)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = ForestGreen)
                            Text(text = "pegs left", style = MaterialTheme.typography.labelSmall, fontSize = 8.sp, color = Color.Gray)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Sarah, you are 57 Pegs away from your next Free Homestyle Dessert threshold (200 Pegs)!",
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Center,
                        color = BarrelBrown.copy(alpha = 0.7f)
                    )
                }
            }
        }

        // Virtual Peg game illustration!
        item {
            PegGameIllustration(interactive = true)
        }

        // Reward Thresholds section
        item {
            Column {
                Text(
                    text = "REWARDS CATALOG",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = BarrelBrown.copy(alpha = 0.8f))
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                val thresholds = listOf(
                    Triple("Free Drink or Side", "75 Pegs", Icons.Default.Coffee),
                    Triple("Free Shareable / Appetizer", "150 Pegs", Icons.Default.BakeryDining),
                    Triple("Free Homestyle Entrée", "225 Pegs", Icons.Default.DinnerDining),
                    Triple("15% Retail Country Store Discount", "250 Pegs", Icons.Default.LocalOffer)
                )

                thresholds.forEach { (reward, cost, icon) ->
                    val progress = totalPegs.toFloat() / cost.replace(" Pegs", "").toFloat()
                    val isLocked = progress < 1f
                    
                    TraditionalPaperCard(modifier = Modifier.padding(vertical = 4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(icon, contentDescription = "Reward Icon", tint = if (isLocked) Color.Gray else ForestGreen, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(text = reward, style = MaterialTheme.typography.titleMedium, color = if (isLocked) Color.Gray else BarrelBrown)
                                Text(text = "Cost: $cost", style = MaterialTheme.typography.bodySmall.copy(color = if (isLocked) Color.Gray else ForestGreen))
                            }
                            if (isLocked) {
                                Box(
                                    modifier = Modifier
                                        .background(Color.LightGray.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                        .padding(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("LOCKED", style = MaterialTheme.typography.labelSmall, color = Color.Gray, fontSize = 9.sp)
                                }
                            } else {
                                Button(
                                    onClick = {
                                        viewModel.hqAdjustPegs("Sarah", -cost.replace(" Pegs", "").toInt(), "Redeemed $reward")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                                    shape = RoundedCornerShape(4.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                ) {
                                    Text("REDEEM", style = MaterialTheme.typography.labelSmall, fontSize = 9.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Ledger History ledger log
        item {
            Column {
                Text(
                    text = "TRANSACTION LEDGER & AUDIT HISTORY",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = BarrelBrown.copy(alpha = 0.8f))
                )
                Spacer(modifier = Modifier.height(8.dp))
                
                if (ledger.isEmpty()) {
                    Text("No reward transactions logged.", color = Color.Gray, fontStyle = FontStyle.Italic)
                } else {
                    ledger.forEach { tx ->
                        val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
                        val formattedDate = sdf.format(Date(tx.dateCreated))
                        
                        TraditionalPaperCard(modifier = Modifier.padding(vertical = 3.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(text = tx.description, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = BarrelBrown))
                                    Text(text = formattedDate, style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                                }
                                Text(
                                    text = if (tx.amount >= 0) "+${tx.amount}" else "${tx.amount}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = if (tx.amount >= 0) ForestGreen else HeritageRed,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ---------------- STORES / LOCATION SCREEN ----------------
@Composable
fun CustomerStoresScreen(viewModel: MainViewModel) {
    val stores by viewModel.restaurants.collectAsState()
    val selectedId by viewModel.selectedStoreId.collectAsState()
    val activeWaitlist by viewModel.activeWaitlistEntry.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var partySize by remember { mutableStateOf(4) }
    var guestPhone by remember { mutableStateOf("(615) 555-0199") }
    var showJoinWaitlistSheet by remember { mutableStateOf(false) }

    val filteredStores = stores.filter {
        it.name.contains(searchQuery, ignoreCase = true) || it.address.contains(searchQuery, ignoreCase = true)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "RESTAURANT DISCOVERY",
                    style = MaterialTheme.typography.displayMedium,
                    color = BarrelBrown
                )
                Text(
                    text = "Find nearest roadside Cracker Barrel store, view current wait times, and register on the waitlist.",
                    style = MaterialTheme.typography.bodySmall.copy(color = BarrelBrown.copy(alpha = 0.6f)),
                    modifier = Modifier.padding(top = 2.dp)
                )
                DottedDivider(modifier = Modifier.padding(vertical = 12.dp))
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search city, state or address...") },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", tint = BarrelBrown) },
                modifier = Modifier.fillMaxWidth().testTag("store_search_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = BarrelBrown,
                    cursorColor = BarrelBrown
                )
            )
        }

        // Illustrated Tennessee Paper Roadmap Card!
        item {
            IllustratedRoadMap(
                stores = filteredStores,
                selectedStoreId = selectedId,
                onStoreSelected = { viewModel.setStoreId(it) }
            )
        }

        // Store List details
        item {
            Text(
                text = "NEAREST LOCATIONS",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = BarrelBrown.copy(alpha = 0.8f))
            )
        }

        items(filteredStores) { store ->
            val isSelected = store.id == selectedId
            TraditionalPaperCard(
                borderColor = if (isSelected) BarrelBrown else BarrelBrown.copy(alpha = 0.15f),
                modifier = Modifier.testTag("store_card_${store.id}")
            ) {
                Column(
                    modifier = Modifier
                        .clickable { viewModel.setStoreId(store.id) }
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = store.name, style = MaterialTheme.typography.titleLarge, color = BarrelBrown)
                            Text(text = store.address, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                        
                        // Status badge
                        Box(
                            modifier = Modifier
                                .background(
                                    color = when (store.status) {
                                        "OPEN" -> ForestGreen.copy(alpha = 0.15f)
                                        "CLOSED" -> Color.Red.copy(alpha = 0.15f)
                                        "BUSY", "WAITLIST" -> GoldenHoney.copy(alpha = 0.15f)
                                        else -> Color.Gray.copy(alpha = 0.15f)
                                    },
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = store.status,
                                style = MaterialTheme.typography.labelSmall,
                                color = when (store.status) {
                                    "OPEN" -> ForestGreen
                                    "CLOSED" -> Color.Red
                                    "BUSY", "WAITLIST" -> BarrelBrown
                                    else -> Color.DarkGray
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(text = store.description, style = MaterialTheme.typography.bodyMedium.copy(fontSize = 12.sp), color = BarrelBrown.copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Hours: ${store.hours}", style = MaterialTheme.typography.labelMedium)
                            Text(text = "Current Wait: ${store.currentWaitMinutes} mins", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = if (store.currentWaitMinutes > 20) HeritageRed else ForestGreen))
                        }

                        if (store.status != "CLOSED") {
                            Button(
                                onClick = {
                                    viewModel.setStoreId(store.id)
                                    showJoinWaitlistSheet = true
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                                shape = RoundedCornerShape(4.dp),
                                enabled = activeWaitlist == null
                            ) {
                                Text("JOIN WAITLIST", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }
    }

    // Join Waitlist Sheet / Modal Dialogue
    if (showJoinWaitlistSheet) {
        val store = stores.find { it.id == selectedId }
        AlertDialog(
            onDismissRequest = { showJoinWaitlistSheet = false },
            title = { Text("JOIN THE WAITLIST", fontFamily = FontFamily.Serif, color = BarrelBrown, fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Store: ${store?.name}", style = MaterialTheme.typography.labelLarge)
                    Text("Current Est. Wait: ${store?.currentWaitMinutes} mins", style = MaterialTheme.typography.bodyMedium.copy(color = ForestGreen))
                    
                    Text("Party Size:", style = MaterialTheme.typography.labelMedium)
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        (1..6).forEach { size ->
                            val isSel = partySize == size
                            Surface(
                                modifier = Modifier
                                    .clickable { partySize = size }
                                    .weight(1f),
                                color = if (isSel) BarrelBrown else Color.White,
                                border = BorderStroke(1.dp, BarrelBrown.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "$size",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSel) Color.White else BarrelBrown,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Text("Guest Contact Number:", style = MaterialTheme.typography.labelMedium)
                    OutlinedTextField(
                        value = guestPhone,
                        onValueChange = { guestPhone = it },
                        modifier = Modifier.fillMaxWidth().testTag("waitlist_phone_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BarrelBrown,
                            cursorColor = BarrelBrown
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.joinWaitlist(selectedId, viewModel.userName, partySize, guestPhone)
                        showJoinWaitlistSheet = false
                        viewModel.setCustomerTab("HOME") // Send home to view interactive state card
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.testTag("waitlist_submit_btn")
                ) {
                    Text("JOIN WAITLIST")
                }
            },
            dismissButton = {
                TextButton(onClick = { showJoinWaitlistSheet = false }) {
                    Text("CANCEL", color = BarrelBrown)
                }
            },
            containerColor = CreamPaper
        )
    }
}

// ---------------- ACCOUNT & CATERING SCREEN ----------------
@Composable
fun CustomerAccountScreen(viewModel: MainViewModel) {
    val ordersHistory by viewModel.orders.collectAsState()
    val cateringHistory by viewModel.cateringOrders.collectAsState()
    val totalPegs by viewModel.totalPegs.collectAsState()
    val cateringMsg by viewModel.cateringSuccessMessage.collectAsState()

    var showCateringPlanner by remember { mutableStateOf(false) }
    var guestCount by remember { mutableStateOf(40) }
    var cateringDate by remember { mutableStateOf("2026-09-28") }
    var cateringTime by remember { mutableStateOf("12:00 PM") }
    var cateringType by remember { mutableStateOf("PICKUP") } // PICKUP or DELIVERY

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                // Profile Avatar Box
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .background(GoldenHoney.copy(alpha = 0.2f), CircleShape)
                        .border(2.dp, BarrelBrown, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Person, contentDescription = "Sarah", tint = BarrelBrown, modifier = Modifier.size(42.dp))
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "Sarah Taylor", style = MaterialTheme.typography.displayMedium, color = BarrelBrown)
                Text(text = viewModel.userEmail, style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                
                Row(
                    modifier = Modifier.padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .background(ForestGreen, RoundedCornerShape(20.dp))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text("MEMBER SINCE 2024", style = MaterialTheme.typography.labelSmall, color = Color.White)
                    }
                    Box(
                        modifier = Modifier
                            .background(GoldenHoney, RoundedCornerShape(20.dp))
                            .padding(horizontal = 12.dp, vertical = 4.dp)
                    ) {
                        Text("$totalPegs PEGS ACTIVE", style = MaterialTheme.typography.labelSmall, color = BarrelBrown)
                    }
                }
                DottedDivider(modifier = Modifier.padding(vertical = 12.dp))
            }
        }

        // Pay & Go Simulator Helper Quick Scan Table 24 Button!
        item {
            TraditionalPaperCard(borderColor = ForestGreen) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "PAY & GO — TABLE QR CODE SIMULATION",
                        style = MaterialTheme.typography.labelMedium.copy(color = ForestGreen, fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Scan Table 24 check at your table inside Nashville store to test instant payments and Peg rewards updates.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Button(
                        onClick = {
                            viewModel.scanTableCheck(24)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ForestGreen),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().testTag("pay_and_go_scan_simulate")
                    ) {
                        Text("SIMULATE SCANNING QR CODE (TABLE 24)", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        // Active QR session billing box if scanned
        viewModel.activeTableSession.value?.let { session ->
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = CreamPaper),
                    border = BorderStroke(1.5.dp, BarrelBrown),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().testTag("table_session_bill_card")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.QrCode, contentDescription = "QR Code", tint = BarrelBrown, modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "TABLE ${session.id} BILL CHECK", style = MaterialTheme.typography.titleLarge)
                        }
                        Text(text = "Store: ${session.storeName}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Text(text = "Status: ${session.status}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = ForestGreen))
                        
                        DottedDivider(modifier = Modifier.padding(vertical = 8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Food Subtotal:")
                            Text("\$${String.format("%.2f", session.checkAmount)}")
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Tax:")
                            Text("\$${String.format("%.2f", session.taxAmount)}")
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Simulated Tip (15%):")
                            Text("\$4.20")
                        }
                        val finalBillTotal = session.checkAmount + session.taxAmount + 4.20
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Bill:", fontWeight = FontWeight.Bold)
                            Text("\$${String.format("%.2f", finalBillTotal)}", fontWeight = FontWeight.Bold, color = ForestGreen)
                        }
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        if (session.status != "PAID") {
                            Button(
                                onClick = {
                                    viewModel.payTableCheck(4.20)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.fillMaxWidth().testTag("table_pay_now_btn")
                            ) {
                                Text("PAY NOW WITH GOOGLE PAY")
                            }
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(ForestGreen, RoundedCornerShape(4.dp))
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "PAID! check cleared. Ledger Updated. +$28 Pegs added!",
                                    color = Color.White,
                                    style = MaterialTheme.typography.bodySmall,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = { viewModel.clearPayAndGo() },
                                border = BorderStroke(1.dp, BarrelBrown),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = BarrelBrown),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("DISMISS", style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }
        }

        // Catering Management Panel
        item {
            TraditionalPaperCard(borderColor = BarrelBrown) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.SoupKitchen, contentDescription = "Catering", tint = BarrelBrown, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(text = "CATERING FOR LARGE GROUPS", style = MaterialTheme.typography.titleLarge, color = BarrelBrown)
                    }
                    Text(
                        text = "Order legendary homestyle platters, beverages by the gallon, and desserts for gatherings of 10 to 100+ guests.",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.Gray,
                        modifier = Modifier.padding(vertical = 4.dp)
                    )
                    Button(
                        onClick = { showCateringPlanner = true },
                        colors = ButtonDefaults.buttonColors(containerColor = BarrelBrown),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth().testTag("catering_planner_open")
                    ) {
                        Text("SCHEDULE NEW CATERING", style = MaterialTheme.typography.labelSmall)
                    }
                    
                    if (cateringMsg != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 8.dp)
                                .background(ForestGreen.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                .padding(8.dp)
                        ) {
                            Text(text = cateringMsg!!, style = MaterialTheme.typography.bodySmall, color = ForestGreen, textAlign = TextAlign.Center)
                        }
                    }
                }
            }
        }

        // Cronological order history
        item {
            Text(
                text = "ORDER HISTORY & RECEIPTS",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = BarrelBrown.copy(alpha = 0.8f))
            )
        }

        items(ordersHistory) { order ->
            val sdf = SimpleDateFormat("MMM dd, yyyy - hh:mm a", Locale.getDefault())
            val formattedDate = sdf.format(Date(order.dateCreated))
            TraditionalPaperCard(modifier = Modifier.testTag("past_order_${order.id}")) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "${order.orderType} Order - ${order.storeName}", style = MaterialTheme.typography.titleMedium, color = BarrelBrown)
                            Text(text = formattedDate, style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                        }
                        Box(
                            modifier = Modifier
                                .background(
                                    color = if (order.status == "COMPLETED" || order.status == "HANDED_OFF") ForestGreen.copy(alpha = 0.15f) else Color.Red.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(4.dp)
                                )
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = order.status, style = MaterialTheme.typography.labelSmall, color = if (order.status == "COMPLETED" || order.status == "HANDED_OFF") ForestGreen else Color.Red)
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "Items purchased: ${order.itemsText}", style = MaterialTheme.typography.bodyMedium, color = BarrelBrown.copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = "Total Paid: \$${String.format("%.2f", order.total)}", style = MaterialTheme.typography.labelLarge.copy(color = ForestGreen))
                }
            }
        }

        // Cronological catering history
        if (cateringHistory.isNotEmpty()) {
            item {
                Text(
                    text = "SCHEDULED CATERING CONTRACTS",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = BarrelBrown.copy(alpha = 0.8f))
                )
            }
            items(cateringHistory) { order ->
                TraditionalPaperCard {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "CATERING FOR ${order.guestCount} GUESTS", style = MaterialTheme.typography.titleMedium, color = BarrelBrown)
                            Box(
                                modifier = Modifier
                                    .background(ForestGreen.copy(alpha = 0.15f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(text = order.status, style = MaterialTheme.typography.labelSmall, color = ForestGreen)
                            }
                        }
                        Text(text = "Delivery Date: ${order.dateScheduled} | Time: ${order.timeScheduled}", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        Text(text = "Menu: ${order.itemsText}", style = MaterialTheme.typography.bodyMedium, color = BarrelBrown.copy(alpha = 0.7f))
                        Text(text = "Estimated Subtotal: \$${String.format("%.2f", order.total)}", style = MaterialTheme.typography.labelLarge, color = ForestGreen)
                    }
                }
            }
        }
    }

    // Catering Planner Dialog
    if (showCateringPlanner) {
        AlertDialog(
            onDismissRequest = { showCateringPlanner = false },
            title = { Text("SCHEDULE CATERING", fontFamily = FontFamily.Serif, color = BarrelBrown, fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("How many guests?", style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                        val sizes = listOf(20, 40, 80, 100)
                        sizes.forEach { size ->
                            val isSel = guestCount == size
                            Surface(
                                modifier = Modifier
                                    .clickable { guestCount = size }
                                    .weight(1f),
                                color = if (isSel) BarrelBrown else Color.White,
                                border = BorderStroke(1.dp, BarrelBrown.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "$size",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSel) Color.White else BarrelBrown,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Text("Fulfillment Type:", style = MaterialTheme.typography.labelMedium)
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        listOf("PICKUP", "DELIVERY").forEach { type ->
                            val isSel = cateringType == type
                            Surface(
                                modifier = Modifier
                                    .clickable { cateringType = type }
                                    .weight(1f),
                                color = if (isSel) ForestGreen else Color.White,
                                border = BorderStroke(1.dp, ForestGreen.copy(alpha = 0.2f)),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = type,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (isSel) Color.White else ForestGreen,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 8.dp)
                                )
                            }
                        }
                    }

                    Text("Catering Menu Package Selected:", style = MaterialTheme.typography.labelMedium)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(WarmCream.copy(alpha = 0.5f))
                            .border(1.dp, BarrelBrown.copy(alpha = 0.2f))
                            .padding(8.dp)
                    ) {
                        Column {
                            Text("Homestyle Chicken Platter Pack", style = MaterialTheme.typography.labelMedium, color = BarrelBrown)
                            Text("Includes 40 large bone-in fried chicken pieces, double sides of hashbrown casserole and green beans, sweet tea gallons, and fresh-baked buttermilk biscuits.", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
                        }
                    }

                    val basePrice = guestCount * 9.50
                    Text("Calculated Contract Total: \$${String.format("%.2f", basePrice)}", style = MaterialTheme.typography.labelLarge, color = ForestGreen, fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.placeCateringOrder(
                            guestCount = guestCount,
                            date = cateringDate,
                            time = cateringTime,
                            type = cateringType,
                            itemsSummary = "Fried Chicken Feast Pack, Grits, Buttermilk Biscuits, Sweet Tea",
                            total = guestCount * 9.50
                        )
                        showCateringPlanner = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = HeritageRed),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.testTag("submit_catering_btn")
                ) {
                    Text("AUTHORIZE & SCHEDULE")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCateringPlanner = false }) {
                    Text("CANCEL", color = BarrelBrown)
                }
            },
            containerColor = CreamPaper
        )
    }
}
