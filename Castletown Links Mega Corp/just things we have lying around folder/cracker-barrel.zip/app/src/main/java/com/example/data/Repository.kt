package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.firstOrNull

class CrackerBarrelRepository(private val db: AppDatabase) {

    // DAOs
    val restaurantDao = db.restaurantDao()
    val menuItemDao = db.menuItemDao()
    val cartDao = db.cartDao()
    val orderDao = db.orderDao()
    val waitlistDao = db.waitlistDao()
    val retailProductDao = db.retailProductDao()
    val pegDao = db.pegDao()
    val cateringDao = db.cateringDao()
    val tableSessionDao = db.tableSessionDao()
    val auditDao = db.auditDao()

    // Flows
    val allRestaurants: Flow<List<RestaurantEntity>> = restaurantDao.getAll()
    val allMenuItems: Flow<List<MenuItemEntity>> = menuItemDao.getAll()
    val cartItems: Flow<List<CartItemEntity>> = cartDao.getAll()
    val allOrders: Flow<List<OrderEntity>> = orderDao.getAll()
    val allWaitlist: Flow<List<WaitlistEntryEntity>> = waitlistDao.getAll()
    val allRetailProducts: Flow<List<RetailProductEntity>> = retailProductDao.getAll()
    val pegTransactions: Flow<List<PegTransactionEntity>> = pegDao.getAll()
    val allCateringOrders: Flow<List<CateringOrderEntity>> = cateringDao.getAll()
    val allTableSessions: Flow<List<TableSessionEntity>> = tableSessionDao.getAll()
    val auditTrail: Flow<List<MenuUpdateAuditEntity>> = auditDao.getAll()

    // Seeding Method
    suspend fun seedDatabaseIfEmpty() {
        val existing = restaurantDao.getAll().first()
        if (existing.isNotEmpty()) return // Already seeded!

        // 1. Seed Restaurants
        val initialRestaurants = listOf(
            RestaurantEntity(
                id = 184,
                name = "Nashville Store",
                address = "2406 Music Valley Dr, Nashville, TN 37214",
                latitude = 36.2168,
                longitude = -86.6923,
                status = "BUSY",
                currentWaitMinutes = 18,
                seatingCapacity = 140,
                curbsideSpaceCount = 6,
                hasCatering = true,
                hasGiftCards = true,
                hours = "6:00 AM - 10:00 PM",
                holidayHours = "Thanksgiving: 6:00 AM - 9:00 PM",
                description = "Nestled right near the Grand Ole Opry, featuring a vibrant front porch and deep country store selections."
            ),
            RestaurantEntity(
                id = 221,
                name = "Franklin Store",
                address = "1104 Murfreesboro Rd, Franklin, TN 37064",
                latitude = 35.9150,
                longitude = -86.8480,
                status = "WAITLIST",
                currentWaitMinutes = 12,
                seatingCapacity = 120,
                curbsideSpaceCount = 4,
                hasCatering = true,
                hasGiftCards = true,
                hours = "6:00 AM - 10:00 PM",
                holidayHours = "Christmas Eve: Closed at 2:00 PM",
                description = "Our charming historic Franklin location, beloved by locals and travelers alike."
            ),
            RestaurantEntity(
                id = 102,
                name = "Knoxville West",
                address = "208 Market Place Blvd, Knoxville, TN 37922",
                latitude = 35.9224,
                longitude = -84.1481,
                status = "OPEN",
                currentWaitMinutes = 0,
                seatingCapacity = 135,
                curbsideSpaceCount = 5,
                hasCatering = true,
                hasGiftCards = true,
                hours = "7:00 AM - 9:00 PM",
                holidayHours = "Normal Hours",
                description = "Conveniently located off I-40, perfect for family road trip pitstops."
            ),
            RestaurantEntity(
                id = 95,
                name = "Chattanooga Lookout",
                address = "2010 Hamilton Place Blvd, Chattanooga, TN 37421",
                latitude = 35.0347,
                longitude = -85.1632,
                status = "OPEN",
                currentWaitMinutes = 5,
                seatingCapacity = 110,
                curbsideSpaceCount = 4,
                hasCatering = true,
                hasGiftCards = true,
                hours = "6:00 AM - 10:00 PM",
                holidayHours = "Normal Hours",
                description = "Overlooking scenic views, offering homestyle fuel before exploring the mountains."
            ),
            RestaurantEntity(
                id = 76,
                name = "Memphis East",
                address = "6025 Stage Rd, Bartlett, TN 38134",
                latitude = 35.2189,
                longitude = -89.8130,
                status = "CLOSED",
                currentWaitMinutes = 0,
                seatingCapacity = 150,
                curbsideSpaceCount = 6,
                hasCatering = true,
                hasGiftCards = true,
                hours = "6:00 AM - 10:00 PM",
                holidayHours = "Christmas Day: Closed",
                description = "A warm, family-centered hub in eastern Shelby County with signature fireplace dining."
            )
        )
        restaurantDao.insertAll(initialRestaurants)

        // 2. Seed Menu Items
        val menuItems = listOf(
            MenuItemEntity(
                id = 1,
                category = "BREAKFAST",
                name = "Country Boy Breakfast",
                description = "Three eggs, fried apples, hashbrown casserole, grits, choice of meat (steak, country ham, or pork chops), plus warm biscuits and gravy.",
                price = 15.49,
                calories = 1150,
                allergens = "Wheat, Milk, Eggs, Soy",
                dietaryTags = "Guest Favorite, Heavy"
            ),
            MenuItemEntity(
                id = 2,
                category = "BREAKFAST",
                name = "Momma's Pancake Breakfast",
                description = "Three buttermilk pancakes served with 100% Pure Natural Syrup, two fresh eggs, and your choice of thick-sliced bacon or smoked sausage.",
                price = 11.99,
                calories = 890,
                allergens = "Wheat, Milk, Eggs",
                dietaryTags = "Homestyle, Sweet"
            ),
            MenuItemEntity(
                id = 3,
                category = "BREAKFAST",
                name = "Biscuits & Gravy",
                description = "Three hand-rolled buttermilk biscuits smothered in our warm homestyle sawmill gravy.",
                price = 5.99,
                calories = 620,
                allergens = "Wheat, Milk",
                dietaryTags = "Traditional, Vegetarian"
            ),
            MenuItemEntity(
                id = 4,
                category = "LUNCH",
                name = "Chicken n' Dumplins",
                description = "Slow-simmered chicken and hand-rolled dumplins cooked to a tender, golden-rich perfection, served with two country sides.",
                price = 13.99,
                calories = 720,
                allergens = "Wheat, Milk",
                dietaryTags = "Signature, Popular"
            ),
            MenuItemEntity(
                id = 5,
                category = "DINNER",
                name = "Southern Fried Chicken",
                description = "Four large bone-in pieces of crispy, double-breaded chicken spiced with our special blend, served with three country sides.",
                price = 16.99,
                calories = 1240,
                allergens = "Wheat, Milk",
                dietaryTags = "Crispy, Classic"
            ),
            MenuItemEntity(
                id = 6,
                category = "DINNER",
                name = "Homestyle Meatloaf",
                description = "A sweet, savory slice of meatloaf baked with onions, green peppers, and topped with a sweet tomato glaze, plus two country sides.",
                price = 14.49,
                calories = 810,
                allergens = "Wheat, Eggs, Soy",
                dietaryTags = "Comfort Food"
            ),
            MenuItemEntity(
                id = 7,
                category = "BEVERAGES",
                name = "Freshly Brewed Sweet Tea",
                description = "The classic Southern signature sweet tea, freshly brewed throughout the day and served cold over ice.",
                price = 3.29,
                calories = 140,
                allergens = "None",
                dietaryTags = "Gluten-Free, Southern Traditional"
            ),
            MenuItemEntity(
                id = 8,
                category = "DESSERTS",
                name = "Double Chocolate Fudge Coca-Cola Cake",
                description = "Traditional rich chocolate fudge cake made with real Coca-Cola, served warm with a scoop of premium vanilla bean ice cream.",
                price = 7.49,
                calories = 790,
                allergens = "Wheat, Milk, Eggs, Soy",
                dietaryTags = "Legendary Sweet"
            ),
            MenuItemEntity(
                id = 9,
                category = "SEASONAL",
                name = "Southern Pecan Peach Cobbler",
                description = "Warm spiced peaches under a golden buttery crumb crust studded with toasted Southern pecans, finished with whipped cream.",
                price = 8.29,
                calories = 650,
                allergens = "Wheat, Milk, Pecans",
                dietaryTags = "Seasonal Favorite"
            ),
            MenuItemEntity(
                id = 10,
                category = "KIDS",
                name = "Lil' Buttermilk Pancakes",
                description = "Three mini buttermilk pancakes served with natural syrup and one slice of bacon.",
                price = 5.49,
                calories = 380,
                allergens = "Wheat, Milk, Eggs",
                dietaryTags = "Kid Friendly"
            )
        )
        menuItemDao.insertAll(menuItems)

        // 3. Seed Old Country Store Products
        val retailProducts = listOf(
            RetailProductEntity(
                id = 1001,
                category = "HOME",
                name = "Traditional Wood Peg Game",
                price = 4.99,
                description = "The classic wooden triangle puzzle found on every Cracker Barrel table. Try to leave only one peg to be a 'genius'!",
                isAvailableOnline = true,
                isAvailableInStore = true,
                stockLevel = 420
            ),
            RetailProductEntity(
                id = 1002,
                category = "HOME",
                name = "Lodge Cast Iron 10.25\" Skillet",
                price = 24.99,
                description = "Pre-seasoned 10.25-inch cast iron skillet. Made in the USA, providing excellent heat retention and even cooking.",
                isAvailableOnline = true,
                isAvailableInStore = true,
                stockLevel = 85
            ),
            RetailProductEntity(
                id = 1003,
                category = "DECOR",
                name = "Porch Rocking Chair",
                price = 199.99,
                description = "Crafted of solid, sturdy hardwood with an posture-supporting high back and smooth rocker runners, just like on our front porches.",
                isAvailableOnline = true,
                isAvailableInStore = true,
                stockLevel = 14
            ),
            RetailProductEntity(
                id = 1004,
                category = "FOOD",
                name = "100% Pure Natural Maple Syrup",
                price = 12.99,
                description = "One pint of the real deal: pure, rich, grade-A amber maple syrup imported directly from northern sugar maples.",
                isAvailableOnline = true,
                isAvailableInStore = true,
                stockLevel = 150
            ),
            RetailProductEntity(
                id = 1005,
                category = "CANDY",
                name = "Old-Fashioned Candy Sticks",
                price = 1.99,
                description = "Traditional 5-inch peppermint and butterscotch stick candy wrapped in old-school clear cellophane. 10 per pack.",
                isAvailableOnline = true,
                isAvailableInStore = true,
                stockLevel = 1200
            ),
            RetailProductEntity(
                id = 1006,
                category = "SEASONAL",
                name = "Harvest Apple Spice Candle",
                price = 14.99,
                description = "A warm, highly scented hand-poured jar candle radiating spiced McIntosh apple, crushed cinnamon, and ground clove.",
                isAvailableOnline = true,
                isAvailableInStore = true,
                stockLevel = 60
            ),
            RetailProductEntity(
                id = 1007,
                category = "GIFTS",
                name = "Country Waffle Kitchen Towels",
                price = 9.99,
                description = "A set of two durable waffle-weave cotton kitchen towels in vintage barn red and cream plaid.",
                isAvailableOnline = true,
                isAvailableInStore = true,
                stockLevel = 220
            )
        )
        retailProductDao.insertAll(retailProducts)

        // 4. Seed Sarah's Rewards (Peg transactions)
        // Starting with 127 Pegs
        val pegTransactionsList = listOf(
            PegTransactionEntity(
                amount = 42,
                description = "Restaurant purchase - Nashville Store #184",
                dateCreated = System.currentTimeMillis() - 6 * 24 * 60 * 60 * 1000 // 6 days ago
            ),
            PegTransactionEntity(
                amount = 15,
                description = "Bonus Event: Fall Road-Trip Check-In",
                dateCreated = System.currentTimeMillis() - 12 * 24 * 60 * 60 * 1000 // 12 days ago
            ),
            PegTransactionEntity(
                amount = -150,
                description = "Redeemed: Free Entrée (Chicken n' Dumplins)",
                dateCreated = System.currentTimeMillis() - 14 * 24 * 60 * 60 * 1000 // 14 days ago
            ),
            PegTransactionEntity(
                amount = 220,
                description = "Account Activation & Welcome Bonus",
                dateCreated = System.currentTimeMillis() - 30 * 24 * 60 * 60 * 1000 // 30 days ago
            )
        )
        for (tx in pegTransactionsList) {
            pegDao.insert(tx)
        }

        // 5. Seed Past Orders in history
        val pastOrders = listOf(
            OrderEntity(
                storeId = 184,
                storeName = "Nashville Store",
                orderType = "Pickup",
                status = "COMPLETED",
                subtotal = 15.49,
                tax = 1.35,
                tip = 1.00,
                total = 17.84,
                spaceNumber = null,
                dateCreated = System.currentTimeMillis() - 6 * 24 * 60 * 60 * 1000,
                itemsText = "1x Country Boy Breakfast"
            ),
            OrderEntity(
                storeId = 184,
                storeName = "Nashville Store",
                orderType = "Curbside",
                status = "COMPLETED",
                subtotal = 31.97,
                tax = 2.78,
                tip = 3.00,
                total = 37.75,
                spaceNumber = "Space 4",
                dateCreated = System.currentTimeMillis() - 20 * 24 * 60 * 60 * 1000,
                itemsText = "1x Chicken n' Dumplins, 1x Southern Fried Chicken"
            )
        )
        for (order in pastOrders) {
            orderDao.insert(order)
        }

        // 6. Seed Waitlist entries (live management for HQ view)
        val waitlistEntries = listOf(
            WaitlistEntryEntity(
                storeId = 184,
                storeName = "Nashville Store",
                partySize = 4,
                guestName = "Robert Taylor",
                phoneNumber = "(615) 555-0142",
                status = "WAITING",
                position = 3,
                estimatedWaitMinutes = 8,
                dateCreated = System.currentTimeMillis() - 10 * 60 * 1000
            ),
            WaitlistEntryEntity(
                storeId = 184,
                storeName = "Nashville Store",
                partySize = 2,
                guestName = "Evelyn Carter",
                phoneNumber = "(615) 555-0987",
                status = "WAITING",
                position = 5,
                estimatedWaitMinutes = 14,
                dateCreated = System.currentTimeMillis() - 5 * 60 * 1000
            ),
            WaitlistEntryEntity(
                storeId = 221,
                storeName = "Franklin Store",
                partySize = 6,
                guestName = "Michael Brown",
                phoneNumber = "(615) 555-2319",
                status = "WAITING",
                position = 2,
                estimatedWaitMinutes = 6,
                dateCreated = System.currentTimeMillis() - 15 * 60 * 1000
            )
        )
        for (entry in waitlistEntries) {
            waitlistDao.insert(entry)
        }

        // 7. Seed Active Table QR checks for Pay & Go
        val tableSessions = listOf(
            TableSessionEntity(
                id = 24,
                storeId = 184,
                storeName = "Nashville Store",
                checkAmount = 28.50,
                taxAmount = 2.49,
                status = "DINING",
                customerName = "Sarah"
            ),
            TableSessionEntity(
                id = 12,
                storeId = 184,
                storeName = "Nashville Store",
                checkAmount = 42.15,
                taxAmount = 3.68,
                status = "CHECK_REQUESTED",
                customerName = "John Doe"
            ),
            TableSessionEntity(
                id = 8,
                storeId = 221,
                storeName = "Franklin Store",
                checkAmount = 18.20,
                taxAmount = 1.59,
                status = "DINING",
                customerName = "Evelyn Carter"
            )
        )
        for (session in tableSessions) {
            tableSessionDao.insert(session)
        }
    }
}
