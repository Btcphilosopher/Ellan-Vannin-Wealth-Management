package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.BarrelBrown
import com.example.ui.theme.GoldenHoney
import com.example.ui.theme.HeritageRed
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.WarmCream
import com.example.ui.theme.CreamPaper
import androidx.compose.foundation.BorderStroke

@Composable
fun DottedDivider(
    modifier: Modifier = Modifier,
    color: Color = BarrelBrown.copy(alpha = 0.3f),
    thickness: Float = 4f
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(2.dp)
    ) {
        val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
        drawLine(
            color = color,
            start = Offset(0f, size.height / 2),
            end = Offset(size.width, size.height / 2),
            strokeWidth = thickness,
            pathEffect = pathEffect
        )
    }
}

@Composable
fun TraditionalPaperCard(
    modifier: Modifier = Modifier,
    borderColor: Color = BarrelBrown.copy(alpha = 0.15f),
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .border(1.dp, borderColor, RoundedCornerShape(4.dp)),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        shape = RoundedCornerShape(4.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        content = content
    )
}

@Composable
fun PegGameIllustration(
    modifier: Modifier = Modifier,
    interactive: Boolean = false
) {
    var selectedPeg by remember { mutableStateOf(-1) }
    
    // Draw the classic triangle peg game
    Box(
        modifier = modifier
            .background(Color(0xFFEFEBE9), RoundedCornerShape(8.dp))
            .border(2.dp, BarrelBrown, RoundedCornerShape(8.dp))
            .padding(12.dp)
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "CRACKER BARREL PEG GAME",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = BarrelBrown,
                    letterSpacing = 1.sp
                )
            )
            Spacer(modifier = Modifier.height(8.dp))
            
            // Triangle layout
            val rows = 5
            var pegCounter = 0
            for (r in 0 until rows) {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 3.dp)
                ) {
                    for (c in 0..r) {
                        val currentPegId = pegCounter++
                        // The top-most peg is empty to start the classic game
                        val isEmpty = currentPegId == 0
                        val pinColor = if (isEmpty) {
                            Color.LightGray
                        } else if (currentPegId == selectedPeg) {
                            HeritageRed
                        } else {
                            GoldenHoney
                        }
                        
                        Box(
                            modifier = Modifier
                                .padding(horizontal = 6.dp)
                                .size(24.dp)
                                .background(pinColor, RoundedCornerShape(12.dp))
                                .border(1.5.dp, BarrelBrown, RoundedCornerShape(12.dp))
                                .clickable(enabled = interactive) {
                                    if (!isEmpty) {
                                        selectedPeg = if (selectedPeg == currentPegId) -1 else currentPegId
                                    }
                                }
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (selectedPeg >= 0) "Peg $selectedPeg selected! Jump to play." else "Leave only one peg to be a GENIUS!",
                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Serif, color = BarrelBrown),
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
fun IllustratedRoadMap(
    modifier: Modifier = Modifier,
    stores: List<com.example.data.RestaurantEntity>,
    selectedStoreId: Int,
    onStoreSelected: (Int) -> Unit
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(240.dp)
            .background(Color(0xFFF3EAD3), RoundedCornerShape(4.dp)) // Old parchment paper map background
            .border(2.dp, BarrelBrown.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
    ) {
        // Draw decorative geographic/road lines in background
        Canvas(modifier = Modifier.fillMaxSize()) {
            // Main "Interstate Highway 40" reference
            val dashEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
            drawLine(
                color = Color(0xFF795548).copy(alpha = 0.3f),
                start = Offset(0f, size.height * 0.3f),
                end = Offset(size.width, size.height * 0.7f),
                strokeWidth = 6f
            )
            // Route 66 reference
            drawLine(
                color = Color(0xFF795548).copy(alpha = 0.2f),
                start = Offset(size.width * 0.4f, 0f),
                end = Offset(size.width * 0.6f, size.height),
                strokeWidth = 4f,
                pathEffect = dashEffect
            )
            
            // Draw some stylized landscape circles (mountains/valleys)
            drawCircle(
                color = Color(0xFFE0D4B3),
                radius = 120f,
                center = Offset(size.width * 0.15f, size.height * 0.2f)
            )
            drawCircle(
                color = Color(0xFFE0D4B3),
                radius = 90f,
                center = Offset(size.width * 0.85f, size.height * 0.8f)
            )
        }
        
        // Dynamic map pins for each store
        stores.forEach { store ->
            // Map lat/long into relative coordinates on the card
            // Lat ranges roughly from 35.0 (Chattanooga) to 36.3 (Nashville)
            // Long ranges roughly from -89.8 (Memphis) to -84.1 (Knoxville)
            val relX = when (store.id) {
                184 -> 0.5f  // Nashville (center)
                221 -> 0.42f // Franklin (slightly West/South of Nashville)
                102 -> 0.85f // Knoxville (East)
                95 -> 0.75f  // Chattanooga (South-East)
                76 -> 0.15f  // Memphis (West)
                else -> 0.5f
            }
            val relY = when (store.id) {
                184 -> 0.35f
                221 -> 0.55f
                102 -> 0.25f
                95 -> 0.75f
                76 -> 0.6f
                else -> 0.5f
            }
            
            val isSelected = store.id == selectedStoreId
            val pinSize by animateFloatAsState(
                targetValue = if (isSelected) 36f else 24f,
                animationSpec = spring(dampingRatio = 0.5f)
            )
            
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .offset(
                            x = (280.dp * relX) - (pinSize.dp / 2),
                            y = (200.dp * relY) - pinSize.dp
                        )
                        .size(pinSize.dp)
                        .testTag("store_pin_${store.id}")
                        .clickable { onStoreSelected(store.id) }
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val color = if (isSelected) HeritageRed else BarrelBrown
                        // Draw pin teardrop
                        drawCircle(color = color, radius = size.width / 2.5f, center = Offset(size.width / 2, size.height / 3))
                        drawCircle(color = Color.White, radius = size.width / 8f, center = Offset(size.width / 2, size.height / 3))
                    }
                    
                    // Tiny indicator text above pin if selected
                    if (isSelected) {
                        Box(
                            modifier = Modifier
                                .offset(y = (-20).dp)
                                .background(BarrelBrown, RoundedCornerShape(4.dp))
                                .border(0.5.dp, Color.White, RoundedCornerShape(4.dp))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Store #${store.id}",
                                color = Color.White,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 8.sp,
                                maxLines = 1
                            )
                        }
                    }
                }
            }
        }
        
        // Bottom map metadata tag
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(8.dp)
                .background(BarrelBrown, RoundedCornerShape(4.dp))
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            Text(
                text = "HISTORICAL TENNESSEE HIGHWAY GUIDE",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.5.sp
            )
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SimulationController(
    currentMode: String,
    onModeChange: (String) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("simulation_panel"),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFECEFF1)
        ),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, Color(0xFFCFD8DC))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Simulation Switch",
                    tint = ForestGreen,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "REAL-TIME SIMULATION CONTROLLER (DEMO MODE)",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF37474F)
                    )
                )
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .background(ForestGreen, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "ACTIVE",
                        color = Color.White,
                        style = MaterialTheme.typography.labelSmall,
                        fontSize = 8.sp
                    )
                }
            }
            Text(
                text = "Simulate real restaurant network situations to watch both the Customer App and HQ operational systems react immediately.",
                style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF546E7A)),
                modifier = Modifier.padding(vertical = 4.dp)
            )
            
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val modes = listOf(
                    "NORMAL_DAY" to "Normal",
                    "BREAKFAST_RUSH" to "Breakfast Rush (Waitlists)",
                    "LUNCH_RUSH" to "Lunch Rush (Active Orders)",
                    "CURBSIDE_SURGE" to "Curbside Surge (Space 4)",
                    "CATERING_DAY" to "Catering Production"
                )
                
                modes.forEach { (modeCode, displayName) ->
                    val isSelected = currentMode == modeCode
                    val btnBg = if (isSelected) ForestGreen else Color.White
                    val btnTxt = if (isSelected) Color.White else Color(0xFF37474F)
                    val border = if (isSelected) BorderStroke(0.dp, Color.Transparent) else BorderStroke(1.dp, Color(0xFFB0BEC5))
                    
                    Surface(
                        modifier = Modifier
                            .clickable { onModeChange(modeCode) }
                            .testTag("sim_btn_$modeCode"),
                        shape = RoundedCornerShape(4.dp),
                        color = btnBg,
                        border = border
                    ) {
                        Text(
                            text = displayName,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            color = btnTxt
                        )
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(
                    imageVector = Icons.Default.Info,
                    contentDescription = "Tips",
                    tint = Color(0xFF78909C),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = when (currentMode) {
                        "BREAKFAST_RUSH" -> "Simulation loaded: Wait times spike up to 45 mins. Sarah can join waitlist and manager will seat her on HQ."
                        "LUNCH_RUSH" -> "Simulation loaded: Active Orders are submitted into preparing. Watch them on the HQ operations screen."
                        "CURBSIDE_SURGE" -> "Simulation loaded: Multiple vehicles arrive in Spaces 2 & 4. Customers can tap 'I'm Here' to trigger runner output."
                        "CATERING_DAY" -> "Simulation loaded: Heavy corporate catering scheduled on dashboard. HQ schedule is updated."
                        else -> "Simulation loaded: Normal daily operation. Smooth table turnover."
                    },
                    style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFF607D8B), fontSize = 10.sp)
                )
            }
        }
    }
}
