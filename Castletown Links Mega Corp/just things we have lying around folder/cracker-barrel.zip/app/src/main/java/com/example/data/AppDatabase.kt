package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        RestaurantEntity::class,
        MenuItemEntity::class,
        CartItemEntity::class,
        OrderEntity::class,
        WaitlistEntryEntity::class,
        RetailProductEntity::class,
        PegTransactionEntity::class,
        CateringOrderEntity::class,
        TableSessionEntity::class,
        MenuUpdateAuditEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {

    abstract fun restaurantDao(): RestaurantDao
    abstract fun menuItemDao(): MenuItemDao
    abstract fun cartDao(): CartDao
    abstract fun orderDao(): OrderDao
    abstract fun waitlistDao(): WaitlistDao
    abstract fun retailProductDao(): RetailProductDao
    abstract fun pegDao(): PegDao
    abstract fun cateringDao(): CateringDao
    abstract fun tableSessionDao(): TableSessionDao
    abstract fun auditDao(): AuditDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "cracker_barrel_os_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
