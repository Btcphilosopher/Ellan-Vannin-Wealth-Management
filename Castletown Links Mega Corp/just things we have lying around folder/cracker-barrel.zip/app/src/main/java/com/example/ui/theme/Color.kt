package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Modern Cracker Barrel Palette
val BarrelBrown = Color(0xFF5C3826)      // Primary: Warm rich brown
val HeritageRed = Color(0xFF9E2A2B)      // Secondary: Heritage vintage red
val GoldenHoney = Color(0xFFE09F3E)      // Tertiary: Warm country gold
val WarmCream = Color(0xFFFAF6EE)        // Background: Soft roadside warm cream
val CreamPaper = Color(0xFFFFFDF9)       // Surface: Off-white clean parchment
val ForestGreen = Color(0xFF3F5E4D)      // Accent: Porch pine green

// Dark Mode Palette
val LightBrown = Color(0xFFD7CCC8)
val FadedRed = Color(0xFFE57373)
val FadedHoney = Color(0xFFFFD54F)
val DarkCharcoal = Color(0xFF1E1E1E)
val CharcoalSurface = Color(0xFF2C2C2C)
val CharcoalOnPrimary = Color(0xFF3E2723)
