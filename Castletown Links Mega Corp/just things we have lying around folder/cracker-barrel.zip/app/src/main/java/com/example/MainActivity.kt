package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cached
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.SupervisorAccount
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.CustomerAppScreen
import com.example.ui.screens.HQAppScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.ForestGreen
import com.example.ui.theme.BarrelBrown

class MainActivity : ComponentActivity() {
    
    private val mainViewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    topBar = {
                        RoleSwitcherHeader(viewModel = mainViewModel)
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        val isHQ by mainViewModel.isHQView.collectAsState()
                        if (isHQ) {
                            HQAppScreen(viewModel = mainViewModel)
                        } else {
                            CustomerAppScreen(viewModel = mainViewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RoleSwitcherHeader(viewModel: MainViewModel) {
    val isHQ by viewModel.isHQView.collectAsState()
    
    Surface(
        color = Color(0xFF100F0D),
        contentColor = Color.White,
        modifier = Modifier.fillMaxWidth().statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp, horizontal = 12.dp)
                .testTag("role_switcher_container"),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Cached,
                    contentDescription = "Role Selector",
                    tint = Color(0xFFFFD54F),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "CB.OS REDESIGN",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFB0BEC5),
                        letterSpacing = 1.sp
                    )
                )
            }
            
            // Selector Buttons
            Row(
                modifier = Modifier
                    .background(Color(0xFF212121), RoundedCornerShape(20.dp))
                    .padding(2.dp)
            ) {
                // Customer Button
                Box(
                    modifier = Modifier
                        .background(
                            color = if (!isHQ) BarrelBrown else Color.Transparent,
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { viewModel.setHQView(false) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("switch_to_customer_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = "Customer",
                            tint = if (!isHQ) Color.White else Color.Gray,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "CUSTOMER",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = if (!isHQ) Color.White else Color.Gray
                            )
                        )
                    }
                }
                
                // HQ Button
                Box(
                    modifier = Modifier
                        .background(
                            color = if (isHQ) ForestGreen else Color.Transparent,
                            shape = RoundedCornerShape(20.dp)
                        )
                        .clickable { viewModel.setHQView(true) }
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                        .testTag("switch_to_hq_btn"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.SupervisorAccount,
                            contentDescription = "Enterprise HQ",
                            tint = if (isHQ) Color.White else Color.Gray,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "HQ CONSOLE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                fontSize = 9.sp,
                                color = if (isHQ) Color.White else Color.Gray
                            )
                        )
                    }
                }
            }
        }
    }
}
