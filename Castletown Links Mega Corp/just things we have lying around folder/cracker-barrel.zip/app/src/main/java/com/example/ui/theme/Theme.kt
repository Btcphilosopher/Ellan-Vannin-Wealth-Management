package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = LightBrown,
    secondary = FadedRed,
    tertiary = FadedHoney,
    background = DarkCharcoal,
    surface = CharcoalSurface,
    onPrimary = CharcoalOnPrimary,
    onSecondary = DarkCharcoal,
    onBackground = WarmCream,
    onSurface = WarmCream
)

private val LightColorScheme = lightColorScheme(
    primary = BarrelBrown,
    secondary = HeritageRed,
    tertiary = GoldenHoney,
    background = WarmCream,
    surface = CreamPaper,
    onPrimary = CreamPaper,
    onSecondary = CreamPaper,
    onBackground = BarrelBrown,
    onSurface = BarrelBrown
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // We enforce our highly branded, curated Cracker Barrel color scheme to avoid bland dynamic colors
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
