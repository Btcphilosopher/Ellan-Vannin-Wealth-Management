/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize server-side Gemini API client
let ai: GoogleGenAI | null = null;
try {
  const apiKey = process.env.GEMINI_API_KEY;
  if (apiKey) {
    ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
    console.log('Gemini API client initialized successfully.');
  } else {
    console.warn('GEMINI_API_KEY not found in environment variables. AI queries will fall back to local rule-based suggestions.');
  }
} catch (e) {
  console.error('Failed to initialize Gemini Client:', e);
}

// ----------------------------------------------------
// API ROUTES FIRST
// ----------------------------------------------------

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// AI Command Assistant endpoint
app.post('/api/ai', async (req, res) => {
  const { prompt, systemContext } = req.body;

  if (!prompt) {
    res.status(400).json({ error: 'Prompt is required.' });
    return;
  }

  // Provide high-fidelity rule-based responses if AI is not available
  if (!ai) {
    let fallbackText = "AI Client not fully initialized. Here is a local analysis: ";
    const queryLower = prompt.toLowerCase();
    
    if (queryLower.includes('contract') || queryLower.includes('apex')) {
      fallbackText += "The Artist holds an exclusive contract with Apex Music Group expiring 2029-08-31. It has 18% base royalty rate and 100% recoupment of advances.";
    } else if (queryLower.includes('split') || queryLower.includes('anomaly') || queryLower.includes('missing')) {
      fallbackText += "WARNING: Incomplete split sheet detected on 'Apex Rebound' (ID: comp_39, 80% total) and Over-allocated split sheet detected on 'The Last Tier' (ID: comp_40, 110% total). Action required: Sign remediated split sheet.";
    } else if (queryLower.includes('recoup') || queryLower.includes('advance')) {
      fallbackText += "Current recoupment ledger shows original advance of $500,000, and $265,000 in recoupable expenses. With $730,000 royalty credits applied, the remaining unrecouped balance is $35,000.";
    } else if (queryLower.includes('value') || queryLower.includes('valuation')) {
      fallbackText += "Catalogue is valued at $5.95M base case using DCF (8.5% discount rate) and Multiple-based methodologies (12.5x annual revenue).";
    } else {
      fallbackText += "Platform data is normal. Please verify active contracts, metadata checklist approvals for upcoming Single launches, and tour routing logistics.";
    }
    
    res.json({
      text: fallbackText,
      provenance: {
        model: 'local-fallback-engine',
        timestamp: new Date().toISOString(),
        humanApprovalRequired: false
      }
    });
    return;
  }

  try {
    const defaultSystemContext = `
You are the built-in AI Assistant of the "ARTIST OS" platform, analyzing institutional catalog data for the fictional band "THE UPPER TIER".
You are Gemini 3.8 Flash, a principal audit accountant, veteran music licensing counsel, and metadata compliance specialist.

Here is the exact state of the Artist Graph you have read access to:
- Artist Name: THE UPPER TIER (4 members: Leo Hayes 30%, Maya Vance 25%, Jude Miller 25%, Chloe Sterling 20% splits).
- Label: Apex Music Group (AMG). Distribution: Global Sonic. Publisher: Vector Publishing.
- Contracts:
  1. AMG: Base Royalty 18%. 100% Recoupment Rate. Term: 3 Firm Albums + 1 Option. Initial Advance: $500,000.
  2. Zenith Management: 15% Gross Commission. Expires Dec 31, 2026.
  3. Vector Publishing: 75/25 Co-Pub split.
- Financial Ledgers:
  - Original Advance: $500,000
  - Recoupable Costs (Recording/Marketing/Touring/Legal): $265,000
  - Total Recoupment Pool: $765,000
  - Royalty Credits Applied: $730,000
  - Remaining Unrecouped Balance: $35,000
  - cash in hand: $140,600 (S1 2026 statement pending reconciliation).
- Catalogue State: 40 compositions, 50 recordings.
  - Anomaly comp_39: Incomplete split sheet (total 80%).
  - Anomaly comp_40: Over-split sheet (total 110%).
  - Anomaly merch_004: Negative stock level (-5) for CD Digipack.
  - Anomaly rel_album_3: Monoliths in Motion is missing UPC/EAN code before DSP release.
- Valuation Base Case: $5.95M, Multiple-based: $6.0M (12.5x multiples), DCF: $5.45M.

RULES:
- Provide highly professional, serious, and precise calculations.
- NEVER invent fictitious DSP APIs or contract structures outside the dataset.
- Always include "Provenance Details" at the bottom of responses showing the model name, timestamp, and human approval notice.
- AI must NEVER silently modify financial, legal, or rights records.
`;

    const combinedInstruction = defaultSystemContext + (systemContext ? `\nAdditional Context: ${systemContext}` : '');

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        systemInstruction: combinedInstruction,
        temperature: 0.1, // low temperature for precise calculations
      }
    });

    const text = response.text || "No response received from the model.";

    res.json({
      text,
      provenance: {
        model: 'gemini-3.8-flash',
        timestamp: new Date().toISOString(),
        humanApprovalRequired: false,
        sourceHash: 'sha256-a0e28f323f'
      }
    });
  } catch (error: any) {
    console.error('Gemini generateContent error:', error);
    res.status(500).json({ error: error.message || 'Error communicating with Gemini.' });
  }
});

// ----------------------------------------------------
// VITE OR STATIC MIDDLEWARE SETUP
// ----------------------------------------------------
async function setupViteOrStatic() {
  if (process.env.NODE_ENV !== 'production') {
    console.log('Running server in development (Vite middleware mode)');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    console.log('Running server in production (Static files mode)');
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ARTIST OS Server booted successfully. Direct port ingress routed at: http://localhost:${PORT}`);
  });
}

setupViteOrStatic().catch((err) => {
  console.error('Failed to start server:', err);
});
