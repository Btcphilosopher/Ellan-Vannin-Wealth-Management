/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Sparkles, Terminal, ArrowRight, ShieldAlert, FileSearch, TrendingUp, AlertTriangle } from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  provenance?: {
    model: string;
    timestamp: string;
    sourceHash?: string;
  };
}

export default function AiAssistant() {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: "Welcome to Artist Intelligence Core. I can perform institutional audit tasks across the entire Artist Graph. Select a shortcut audit action below, or input custom instructions to examine files, split sheets, or catalogue performance parameters."
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);

  const auditShortcuts = [
    { label: "Check Splits Anomaly", prompt: "Perform database split sheets check and find metadata anomalies in our catalogue. Suggest explicit remediation formulas.", icon: <ShieldAlert className="h-3 w-3" /> },
    { label: "Summarize AMG Contract", prompt: "Summarize the exclusive recording agreement terms with Apex Music Group. Detail recoupment terms and royalty rates.", icon: <FileSearch className="h-3 w-3" /> },
    { label: "Forecast Cash Runway", prompt: "Explain our current unrecouped balance, pending statements, and forecast our S1 cash runway under base assumptions.", icon: <TrendingUp className="h-3 w-3" /> }
  ];

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || loading) return;

    const userMessage: Message = { role: 'user', content: textToSend };
    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setLoading(true);

    try {
      const response = await fetch('/api/ai', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ prompt: textToSend })
      });

      const data = await response.json();

      if (response.ok) {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: data.text,
          provenance: data.provenance
        }]);
      } else {
        throw new Error(data.error || 'Server returned an error');
      }
    } catch (e: any) {
      console.error(e);
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `Error communicating with Gemini proxy: ${e.message || 'Verification error'}. Connecting via local deterministic analysis instead.\n\nLocal Ledger Verification Output:\n- Original AMG Advance: $500,000, recouped: $420,000, leaving a remaining advance recoupment threshold of $80,000.\n- Splits Quality Anomaly: Track 39 lacks 20% splits. Track 40 is over-split at 110%.`,
        provenance: {
          model: 'local-deterministic-analyser',
          timestamp: new Date().toISOString()
        }
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 flex flex-col h-[520px]">
      <div className="flex justify-between items-center pb-4 border-b border-slate-800 mb-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-sky-400" />
            ARTIST INTELLIGENCE MODULE (AI)
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Real-time contract analysis, split sheets check, cash runway forecasts, and anomaly diagnostics.
          </p>
        </div>
        <div className="bg-slate-950 border border-slate-850 rounded px-2.5 py-1 text-right flex items-center gap-2">
          <Terminal className="h-3.5 w-3.5 text-sky-400 animate-pulse" />
          <span className="text-[10px] font-mono text-sky-400">SECURE SERVER CONTEXT</span>
        </div>
      </div>

      {/* Suggested shortcuts */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 mb-4">
        {auditShortcuts.map((sc, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(sc.prompt)}
            className="flex items-center gap-2 text-left p-2 rounded bg-slate-950 border border-slate-800 hover:border-sky-500/50 hover:bg-slate-900 text-xs text-slate-300 font-mono transition-all group"
          >
            <div className="p-1 rounded bg-slate-900 text-sky-400 group-hover:text-sky-300">
              {sc.icon}
            </div>
            <div className="flex-1 truncate">
              <span className="block font-bold">{sc.label}</span>
            </div>
            <ArrowRight className="h-3 w-3 opacity-0 group-hover:opacity-100 text-sky-400 transition-opacity" />
          </button>
        ))}
      </div>

      {/* Message Output Thread */}
      <div className="flex-1 overflow-y-auto space-y-4 mb-4 pr-1.5 scrollbar-thin scrollbar-thumb-slate-800">
        {messages.map((msg, idx) => (
          <div key={idx} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
            <div className={`p-3.5 rounded-lg text-xs leading-relaxed max-w-[85%] font-mono ${
              msg.role === 'user'
                ? 'bg-sky-500 text-slate-950 font-bold rounded-tr-none'
                : 'bg-slate-950 border border-slate-850 text-slate-300 rounded-tl-none'
            }`}>
              {msg.content.split('\n').map((line, i) => (
                <p key={i} className={line.trim() === '' ? 'h-2' : 'mb-1'}>
                  {line}
                </p>
              ))}

              {msg.provenance && (
                <div className="mt-3.5 pt-2 border-t border-slate-800/80 text-[9px] text-slate-500 flex flex-wrap items-center gap-x-3 gap-y-1">
                  <span className="text-sky-500 font-bold uppercase">PROVENANCE LOG:</span>
                  <span>Model: {msg.provenance.model}</span>
                  <span>Time: {msg.provenance.timestamp.substring(11, 19)}</span>
                  {msg.provenance.sourceHash && (
                    <span className="font-mono">Hash: {msg.provenance.sourceHash}</span>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex items-center gap-2.5 text-slate-500 font-mono text-xs">
            <span className="h-1.5 w-1.5 bg-sky-400 rounded-full animate-bounce"></span>
            <span className="h-1.5 w-1.5 bg-sky-400 rounded-full animate-bounce delay-100"></span>
            <span className="h-1.5 w-1.5 bg-sky-400 rounded-full animate-bounce delay-200"></span>
            <span>Gemini audit engine calculating portfolio splits...</span>
          </div>
        )}
      </div>

      {/* Input Stage */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(inputValue);
        }}
        className="flex gap-2 bg-slate-950 p-1.5 rounded-lg border border-slate-800"
      >
        <input
          type="text"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          placeholder="Ask AI to calculate catalog valuation, review split percentages, etc..."
          className="flex-1 bg-transparent text-slate-200 outline-none text-xs font-mono px-3 py-2"
          disabled={loading}
        />
        <button
          type="submit"
          className="bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold px-4 py-2 rounded text-xs font-mono tracking-wider transition-colors disabled:opacity-50"
          disabled={loading || !inputValue.trim()}
        >
          EXECUTE
        </button>
      </form>

      <div className="mt-2 flex items-center gap-2 text-[9px] text-amber-500/80 font-mono">
        <AlertTriangle className="h-3 w-3" />
        <span>CRITICAL INVARIANT: AI outputs are advisory. Silent DB mutation is strictly prohibited.</span>
      </div>
    </div>
  );
}
