/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { mainArtist, compositions, recordings, releases, recoupmentPools } from '../data';
import { Network, FileText, Music, PlayCircle, Award, DollarSign, ArrowRight, Layers, Eye } from 'lucide-react';

interface Node {
  id: string;
  label: string;
  type: 'artist' | 'song' | 'composition' | 'writer' | 'publisher' | 'recording' | 'release' | 'dsp' | 'royalty' | 'payment';
  details: Record<string, string | number>;
}

interface Edge {
  from: string;
  to: string;
  label?: string;
}

export default function ArtistGraph() {
  const [selectedNode, setSelectedNode] = useState<Node | null>({
    id: 'artist_tut',
    label: mainArtist.name,
    type: 'artist',
    details: {
      'Legal Entity': mainArtist.legalName,
      'Active Members': mainArtist.members?.map(m => m.name).join(', ') || '4 members',
      'Career Start': mainArtist.careerStart,
      'Active Genres': mainArtist.genres.join(', '),
      'Audience Reach': '3.2M TikTok / 2.45M Spotify'
    }
  });

  const [activePathway, setActivePathway] = useState<'creative' | 'commercial'>('creative');

  // Define our static traversable nodes
  const creativeNodes: Node[] = [
    { id: 'artist_tut', label: 'THE UPPER TIER', type: 'artist', details: { 'Legal Entity': 'The Upper Tier Music Group LLC', 'Members': 'Leo, Maya, Jude, Chloe', 'Role': 'Master Owner' } },
    { id: 'song_neon', label: 'Neon Horizon (Song)', type: 'song', details: { 'Primary Work': 'Neon Horizon', 'ISWC': 'T-100.000.000-8', 'Status': 'Fully Registered' } },
    { id: 'comp_neon', label: 'Neon Horizon Composition', type: 'composition', details: { 'ISWC': 'T-100.000.000-8', 'Split sheet': 'Signed 2019-11-10', 'Validation': '100.0% Complete' } },
    { id: 'writer_leo', label: 'Leo Hayes (Writer)', type: 'writer', details: { 'Split Percentage': '35.0%', 'IPI': 'IPI-0082711', 'Affiliation': 'PRS' } },
    { id: 'writer_maya', label: 'Maya Vance (Writer)', type: 'writer', details: { 'Split Percentage': '25.0%', 'IPI': 'IPI-0091823', 'Affiliation': 'BMI' } },
    { id: 'pub_vector', label: 'Vector Music Publishing', type: 'publisher', details: { 'Agreement Type': 'Co-Publishing', 'Commission': '25% Admin Keep', 'Accounting': 'Quarterly' } }
  ];

  const commercialNodes: Node[] = [
    { id: 'song_neon_comm', label: 'Neon Horizon (Song)', type: 'song', details: { 'ISWC': 'T-100.000.000-8', 'Catalog Status': 'Active Catalogue' } },
    { id: 'rec_neon_master', label: 'Neon Horizon (Master)', type: 'recording', details: { 'ISRC': 'GB-APX-26-09200000', 'Format': 'WAV 96k 24bit', 'Duration': '180 seconds' } },
    { id: 'rel_neon_single', label: 'Neon Horizon Single', type: 'release', details: { 'UPC': '075429100114', 'Release Date': '2019-11-10', 'State': 'CATALOGUE' } },
    { id: 'dsp_spotify', label: 'Spotify DSP', type: 'dsp', details: { 'Streams (YTD)': '42.4M', 'Standard Rate': '$0.0035 / stream', 'Availability': 'Worldwide' } },
    { id: 'roy_amg_share', label: 'Apex Royalty Rule', type: 'royalty', details: { 'Base Royalty': '18.0%', 'Recoupment Deduct': '100% of Artist Share', 'Rule ID': 'con_label_apex' } },
    { id: 'pay_stmt_reconcile', label: 'Royalty Credit ledger', type: 'payment', details: { 'Unrecouped Remaining': '$35,000', 'Original Advance': '$500,000', 'Reconciled': 'Yes' } }
  ];

  const creativeEdges: Edge[] = [
    { from: 'artist_tut', to: 'song_neon', label: 'Author' },
    { from: 'song_neon', to: 'comp_neon', label: 'Manifests' },
    { from: 'comp_neon', to: 'writer_leo', label: '35% Split' },
    { from: 'comp_neon', to: 'writer_maya', label: '25% Split' },
    { from: 'writer_leo', to: 'pub_vector', label: 'Administered by' },
    { from: 'writer_maya', to: 'pub_vector', label: 'Administered by' }
  ];

  const commercialEdges: Edge[] = [
    { from: 'song_neon_comm', to: 'rec_neon_master', label: 'Recording' },
    { from: 'rec_neon_master', to: 'rel_neon_single', label: 'Included In' },
    { from: 'rel_neon_single', to: 'dsp_spotify', label: 'Delivered to' },
    { from: 'dsp_spotify', to: 'roy_amg_share', label: 'Generates Revenue' },
    { from: 'roy_amg_share', to: 'pay_stmt_reconcile', label: 'Reduces Advance' }
  ];

  const activeNodes = activePathway === 'creative' ? creativeNodes : commercialNodes;
  const activeEdges = activePathway === 'creative' ? creativeEdges : commercialEdges;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-lg p-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h2 className="text-xl font-bold text-slate-100 flex items-center gap-2">
            <Network className="h-5 w-5 text-sky-400" />
            UNIFIED ARTIST GRAPH & RELATIONSHIP TRAVERSER
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            Traverse logical dependencies bidirectionally between creations, rights-owners, platforms, and accounting ledgers.
          </p>
        </div>

        <div className="flex bg-slate-950 p-1 rounded border border-slate-800">
          <button
            onClick={() => {
              setActivePathway('creative');
              setSelectedNode(creativeNodes[0]);
            }}
            className={`px-3 py-1.5 rounded text-xs font-mono transition-colors ${
              activePathway === 'creative'
                ? 'bg-sky-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            CREATIVE SPLITS PATH
          </button>
          <button
            onClick={() => {
              setActivePathway('commercial');
              setSelectedNode(commercialNodes[0]);
            }}
            className={`px-3 py-1.5 rounded text-xs font-mono transition-colors ${
              activePathway === 'commercial'
                ? 'bg-sky-500 text-slate-950 font-bold'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            COMMERCIAL REVENUE PATH
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Interactive Visual Graph Stage */}
        <div className="lg:col-span-2 bg-slate-950 rounded-lg border border-slate-800 p-4 h-[380px] relative overflow-hidden flex flex-col justify-between">
          <div className="absolute top-3 left-3 flex gap-2">
            <span className="text-[10px] font-mono bg-slate-900 border border-slate-800 px-2 py-0.5 rounded text-slate-400">
              Interactive Nodes: Click to Inspect
            </span>
          </div>

          {/* Graphical Pipeline representation using flow layout to avoid breaking canvas resize guidelines */}
          <div className="flex flex-col md:flex-row items-center justify-around h-full py-4 gap-4">
            {activeNodes.map((node, idx) => {
              const isSelected = selectedNode?.id === node.id;
              const nodeIcons: Record<string, React.ReactNode> = {
                artist: <Award className="h-4 w-4" />,
                song: <Music className="h-4 w-4" />,
                composition: <FileText className="h-4 w-4" />,
                writer: <Award className="h-4 w-4" />,
                publisher: <Layers className="h-4 w-4" />,
                recording: <PlayCircle className="h-4 w-4" />,
                release: <Layers className="h-4 w-4" />,
                dsp: <Network className="h-4 w-4" />,
                royalty: <DollarSign className="h-4 w-4" />,
                payment: <DollarSign className="h-4 w-4" />
              };

              return (
                <React.Fragment key={node.id}>
                  <button
                    onClick={() => setSelectedNode(node)}
                    className={`flex flex-col items-center justify-center p-3 rounded-lg border text-center transition-all w-[110px] h-[110px] relative ${
                      isSelected
                        ? 'bg-sky-950/80 border-sky-400 shadow-md shadow-sky-950 text-sky-300 transform scale-105'
                        : 'bg-slate-900 hover:bg-slate-850 border-slate-800 text-slate-300 hover:border-slate-700'
                    }`}
                  >
                    <div className={`p-2 rounded-full mb-2 ${isSelected ? 'bg-sky-500/20 text-sky-400' : 'bg-slate-950 text-slate-400'}`}>
                      {nodeIcons[node.type] || <Network className="h-4 w-4" />}
                    </div>
                    <span className="text-[10px] font-bold font-mono tracking-wider truncate w-full px-1">
                      {node.label}
                    </span>
                    <span className="text-[8px] opacity-60 uppercase font-mono mt-0.5 block">
                      {node.type}
                    </span>
                  </button>

                  {idx < activeNodes.length - 1 && (
                    <div className="hidden md:flex flex-col items-center text-slate-700 font-mono text-[9px] select-none">
                      <ArrowRight className="h-4 w-4 text-slate-600 animate-pulse" />
                      <span className="max-w-[80px] truncate block mt-1 text-slate-500">
                        {activeEdges.find(e => e.from === node.id || e.from === node.id + '_comm')?.label || 'Link'}
                      </span>
                    </div>
                  )}
                </React.Fragment>
              );
            })}
          </div>

          <div className="border-t border-slate-900 pt-2 text-[10px] text-slate-500 font-mono flex justify-between">
            <span>Graph Source: Live Database Schema</span>
            <span className="text-sky-500">Bidirectional Traversal Connected</span>
          </div>
        </div>

        {/* Node Detail Inspector Panel */}
        <div className="bg-slate-950 rounded-lg border border-slate-800 p-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 pb-3 border-b border-slate-800">
              <div className="bg-sky-500/10 text-sky-400 p-1.5 rounded">
                <Eye className="h-4 w-4" />
              </div>
              <div>
                <span className="text-[9px] font-mono uppercase text-sky-400 block tracking-widest">Selected Entity Inspector</span>
                <h3 className="text-sm font-bold text-slate-200 font-mono truncate">{selectedNode?.label}</h3>
              </div>
            </div>

            {selectedNode ? (
              <div className="mt-4 space-y-3.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500 font-mono">Entity Type</span>
                  <span className="bg-slate-900 border border-slate-800 px-2.5 py-0.5 rounded text-slate-300 font-mono text-[10px] uppercase">
                    {selectedNode.type}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-500 font-mono">Reference ID</span>
                  <span className="text-slate-400 font-mono text-[10px]">{selectedNode.id}</span>
                </div>

                <div className="border-t border-slate-900 pt-3 space-y-2.5">
                  {Object.entries(selectedNode.details).map(([key, val]) => (
                    <div key={key} className="flex flex-col">
                      <span className="text-[9px] text-slate-500 font-mono uppercase tracking-wider">{key}</span>
                      <span className="text-xs text-slate-300 font-mono mt-0.5">{val}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="py-12 text-center text-xs text-slate-600 font-mono">
                Click any node in the graph pipeline to load detail specifications.
              </div>
            )}
          </div>

          <div className="bg-slate-900 border border-slate-850 p-2.5 rounded text-[10px] text-slate-400 mt-4 font-mono leading-relaxed">
            <span className="text-sky-400 font-bold block mb-0.5">💡 Graph Traversal Tip</span>
            In {activePathway === 'creative' ? 'Creative Splits' : 'Commercial Revenue'} mode, traversing from left-to-right provides down-stream audits. Right-to-left exposes source documentation paths.
          </div>
        </div>
      </div>
    </div>
  );
}
