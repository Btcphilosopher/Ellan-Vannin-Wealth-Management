/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { initialAnomalies, mainArtist } from '../data';
import { ShieldCheck, AlertOctagon, RefreshCw, Zap, TrendingUp, Music, Sparkles, PlusCircle } from 'lucide-react';
import { AnomalyReport } from '../types';

interface QualityRemediationProps {
  onSimulate: (type: string) => void;
  anomalies: AnomalyReport[];
  onRemediate: (id: string) => void;
  simulationLog: string[];
}

export default function QualityRemediation({
  onSimulate,
  anomalies,
  onRemediate,
  simulationLog
}: QualityRemediationProps) {
  const [loadingAnomalyId, setLoadingAnomalyId] = useState<string | null>(null);

  const handleRemediateClick = (anom: AnomalyReport) => {
    setLoadingAnomalyId(anom.id);
    setTimeout(() => {
      onRemediate(anom.id);
      setLoadingAnomalyId(null);
    }, 800);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* DATA QUALITY CENTRE */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-6">
        <div className="flex justify-between items-center mb-5 pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-sm font-bold text-slate-100 uppercase font-mono tracking-wider flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              INSTITUTIONAL DATA QUALITY CENTRE
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Verify compliance of metadata, split sheets, stock levels, and contracts against label-grade standards.
            </p>
          </div>
          <span className="text-[10px] bg-slate-950 border border-slate-800 text-slate-400 font-mono px-2 py-0.5 rounded">
            {anomalies.length} Issues Open
          </span>
        </div>

        {anomalies.length > 0 ? (
          <div className="space-y-3 max-h-[380px] overflow-y-auto pr-1">
            {anomalies.map((anom) => {
              const severityStyles = {
                high: 'border-red-500/30 bg-red-950/20 text-red-400',
                medium: 'border-amber-500/30 bg-amber-950/20 text-amber-400',
                low: 'border-blue-500/30 bg-blue-950/20 text-blue-400'
              };

              return (
                <div
                  key={anom.id}
                  className={`border p-4 rounded-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4 transition-all ${
                    severityStyles[anom.severity]
                  }`}
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1.5">
                      <span className={`text-[8px] font-mono font-bold uppercase tracking-wider px-1.5 py-0.5 rounded border ${
                        anom.severity === 'high' ? 'bg-red-500/20 border-red-500/40' :
                        anom.severity === 'medium' ? 'bg-amber-500/20 border-amber-500/40' :
                        'bg-blue-500/20 border-blue-500/40'
                      }`}>
                        {anom.severity} SEVERITY
                      </span>
                      <span className="text-[9px] font-mono text-slate-500 uppercase">
                        Category: {anom.category}
                      </span>
                    </div>
                    <p className="text-xs font-mono font-bold text-slate-200">
                      {anom.description}
                    </p>
                    <p className="text-[10px] text-slate-400 font-mono mt-1 leading-relaxed">
                      <span className="text-sky-400 font-bold">Remediation:</span> {anom.remediationStep}
                    </p>
                  </div>

                  <button
                    onClick={() => handleRemediateClick(anom)}
                    disabled={loadingAnomalyId === anom.id}
                    className="w-full md:w-auto px-3.5 py-1.5 bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 text-[10px] text-slate-200 font-bold font-mono tracking-wider rounded transition-all flex items-center justify-center gap-1.5 disabled:opacity-50"
                  >
                    {loadingAnomalyId === anom.id ? (
                      <RefreshCw className="h-3 w-3 animate-spin text-sky-400" />
                    ) : (
                      <RefreshCw className="h-3 w-3 text-emerald-400" />
                    )}
                    REMEDIATE
                  </button>
                </div>
              );
            })}
          </div>
        ) : (
          <div className="py-16 text-center border border-dashed border-slate-800 rounded-lg bg-slate-950/40">
            <ShieldCheck className="h-10 w-10 text-emerald-500 mx-auto mb-3 animate-pulse" />
            <h3 className="text-xs font-bold text-slate-200 font-mono">ALL SYSTEMS EXECUTING NORMALLY</h3>
            <p className="text-[10px] text-slate-500 font-mono max-w-sm mx-auto mt-1 leading-relaxed">
              100% split validations conform, EAN/UPC barcodes are attached, and stock levels are within normal bounds.
            </p>
          </div>
        )}
      </div>

      {/* SIMULATION CONTROLS */}
      <div className="bg-slate-900 border border-slate-800 rounded-lg p-6">
        <div className="flex justify-between items-center mb-5 pb-3 border-b border-slate-800">
          <div>
            <h2 className="text-sm font-bold text-slate-100 uppercase font-mono tracking-wider flex items-center gap-2">
              <Zap className="h-4 w-4 text-sky-400" />
              SYSTEMIC SIMULATION MODE
            </h2>
            <p className="text-[11px] text-slate-400 mt-0.5">
              Simulate market shocks, releases, licensing sync placements, or catalog decays to analyze resulting cash flow shifts.
            </p>
          </div>
          <span className="text-[9px] bg-sky-500/10 border border-sky-500/20 text-sky-400 font-mono px-2 py-0.5 rounded uppercase font-bold animate-pulse">
            Sim Active
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2.5 mb-5">
          <button
            onClick={() => onSimulate('viral_spike')}
            className="p-3 bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-sky-500/40 text-left rounded transition-all group"
          >
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="h-4 w-4 text-sky-400 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold font-mono text-slate-200">Viral DSP Spike</span>
            </div>
            <p className="text-[9px] text-slate-400 font-mono leading-relaxed">
              Boost streams by +50M, generating +$175K in gross label revenue and accelerating recoupments.
            </p>
          </button>

          <button
            onClick={() => onSimulate('netflix_sync')}
            className="p-3 bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-amber-500/40 text-left rounded transition-all group"
          >
            <div className="flex items-center gap-2 mb-1">
              <Sparkles className="h-4 w-4 text-amber-400 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold font-mono text-slate-200">Netflix Sync Licensing</span>
            </div>
            <p className="text-[9px] text-slate-400 font-mono leading-relaxed">
              Lock $120K synch license for "Velocity Echo" in retro Sci-Fi series. Split 50% publishing/master.
            </p>
          </button>

          <button
            onClick={() => onSimulate('album_drop')}
            className="p-3 bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-emerald-500/40 text-left rounded transition-all group"
          >
            <div className="flex items-center gap-2 mb-1">
              <Music className="h-4 w-4 text-emerald-400 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold font-mono text-slate-200">Drop Upcoming LP</span>
            </div>
            <p className="text-[9px] text-slate-400 font-mono leading-relaxed">
              Deliver "Monoliths in Motion" to DSPs, driving $250K S1 streaming revenues and royalty commissions.
            </p>
          </button>

          <button
            onClick={() => onSimulate('tour_expense')}
            className="p-3 bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-red-500/40 text-left rounded transition-all group"
          >
            <div className="flex items-center gap-2 mb-1">
              <AlertOctagon className="h-4 w-4 text-red-400 group-hover:scale-110 transition-transform" />
              <span className="text-xs font-bold font-mono text-slate-200">Tour Cost Overruns</span>
            </div>
            <p className="text-[9px] text-slate-400 font-mono leading-relaxed">
              Simulate $40K charter travel delay & backline damage, reducing tour net cash flows immediately.
            </p>
          </button>
        </div>

        {/* SIMULATION EVENT REAL-TIME LOG */}
        <div className="bg-slate-950 border border-slate-850 rounded p-4">
          <span className="text-[9px] font-mono text-slate-500 block uppercase tracking-widest mb-2.5">
            Real-Time Simulation Event Feed
          </span>
          <div className="space-y-1.5 max-h-[140px] overflow-y-auto font-mono text-[10px] text-slate-400 pr-1">
            {simulationLog.map((log, idx) => (
              <div key={idx} className="flex items-start gap-2 border-b border-slate-900 pb-1 text-slate-300">
                <span className="text-sky-500 font-bold shrink-0">&gt;&gt;</span>
                <span className="flex-1 leading-relaxed">{log}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
