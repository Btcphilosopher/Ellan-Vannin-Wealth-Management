/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Artist,
  Person,
  Organisation,
  Composition,
  Recording,
  Release,
  Contract,
  Right,
  RoyaltyRule,
  Advance,
  RecoupmentPool,
  RoyaltyStatement,
  RoyaltyTransaction,
  Tour,
  TourDate,
  MerchandiseProduct,
  FinancialTransaction,
  CatalogueValuation,
  MarketingCampaign,
  DigitalAsset,
  PressContact,
  Workflow,
  AuditEvent,
  AnomalyReport
} from './types';

// Helper to generate unique hashes or IDs
const genId = (prefix: string, index: number) => `${prefix}_${String(index).padStart(4, '0')}`;

// --- organisations ---
export const organizations: Organisation[] = [
  { id: 'org_label', name: 'Apex Music Group (AMG)', type: 'label', contactPerson: 'Charles Sterling', email: 'c.sterling@apexmusic.com', phone: '+1-212-555-0101', territory: 'WW' },
  { id: 'org_mgmt', name: 'Zenith Artist Management', type: 'management', contactPerson: 'Richard Vance', email: 'rvance@zenithmanagement.com', phone: '+1-310-555-0202', territory: 'WW' },
  { id: 'org_pub', name: 'Vector Music Publishing', type: 'publisher', contactPerson: 'Eliza Thorne', email: 'e.thorne@vectorpub.co.uk', phone: '+44-207-555-0303', territory: 'WW' },
  { id: 'org_dist', name: 'Global Sonic Distribution', type: 'distributor', contactPerson: 'Marcus Vance', email: 'mvance@globalsonic.net', phone: '+1-415-555-0404', territory: 'WW' },
  { id: 'org_agency', name: 'United Talent Alliance (UTA)', type: 'agency', contactPerson: 'Sarah Jenkins', email: 'sjenkins@unitedtalent.com', phone: '+1-310-555-0505', territory: 'US_EU' },
  { id: 'org_law', name: 'Hampton & Partners LLP', type: 'law_firm', contactPerson: 'Alistair Hampton', email: 'ahampton@hamptonpartners.law', phone: '+1-212-555-0606', territory: 'WW' },
  { id: 'org_accounting', name: 'Sound & Ledger CPAs', type: 'accounting_firm', contactPerson: 'Nesta Miller', email: 'nmiller@soundledger.tax', phone: '+1-615-555-0707', territory: 'US' },
  { id: 'org_bank', name: 'Private Sound Bank', type: 'bank', contactPerson: 'Devon Hayes', email: 'dhayes@privatesound.com', phone: '+44-207-555-0808', territory: 'EU_US' }
];

// --- Fictional Artist: THE UPPER TIER ---
export const mainArtist: Artist = {
  id: 'artist_tut',
  name: 'THE UPPER TIER',
  legalName: 'The Upper Tier Music Group LLC',
  aliases: ['TUT', 'Upper Tier', 'The Tier'],
  genres: ['Electronic', 'Alternative', 'Indie Rock'],
  subgenres: ['Synthwave', 'Indietronica', 'Cyber-Punk'],
  territories: ['WW'],
  languages: ['English'],
  biography: 'Formed in London and currently operating out of Los Angeles, THE UPPER TIER has redefined the alternative electronic landscape with complex syncopations, deep analogue synthesis, and an immutable identity. A four-piece collective that maintains 100% control of their early master catalogue while licensing new releases under an innovative profit-split contract format.',
  careerStart: '2019',
  managementCompanyId: 'org_mgmt',
  labelId: 'org_label',
  publisherId: 'org_pub',
  distributorId: 'org_dist',
  bookingAgencyId: 'org_agency',
  lawFirmId: 'org_law',
  accountingFirmId: 'org_accounting',
  publicistId: 'person_pub',
  socials: [
    { platform: 'Spotify', url: 'https://spotify.com/artist/tut', handle: '@theuppertier', followers: 2450000 },
    { platform: 'YouTube', url: 'https://youtube.com/tut', handle: '@theuppertier', followers: 1890000 },
    { platform: 'Instagram', url: 'https://instagram.com/tut', handle: '@theuppertier', followers: 1450000 },
    { platform: 'TikTok', url: 'https://tiktok.com/@tut', handle: '@theuppertier', followers: 3200000 }
  ],
  website: 'https://theuppertier.com',
  brandIdentity: {
    logoUrl: '/assets/brand/logo_tut.png',
    primaryColor: '#0F172A', // Slate 900
    secondaryColor: '#38BDF8', // Sky 400
    brandGuidelines: 'High-contrast minimalist layouts. Primary use of neutral slate tones with sky blue interactive highlights. Custom geometric letterforms. No script fonts or decorative elements. Strictly industrial tone.'
  },
  audienceProfile: {
    demographics: [
      { ageGroup: '18-24', percentage: 42 },
      { ageGroup: '25-34', percentage: 38 },
      { ageGroup: '35-44', percentage: 15 },
      { ageGroup: '45+', percentage: 5 }
    ],
    topTerritories: [
      { country: 'United States', listenerCount: 890000 },
      { country: 'United Kingdom', listenerCount: 450000 },
      { country: 'Germany', listenerCount: 320000 },
      { country: 'Japan', listenerCount: 210000 },
      { country: 'Australia', listenerCount: 150000 }
    ]
  },
  careerGoals: [
    'Secure 100% master catalogue recoupment on Apex Contract within 18 months.',
    'Execute global arena headline tour with a carbon-neutral footprint.',
    'Incorporate interactive Web3 spatial audio rendering in upcoming live albums.',
    'Acquire additional composition shares from early collaborators to fully consolidate publisher rights.'
  ],
  members: [
    { id: 'member_leo', name: 'Leo Hayes', role: 'Lead Vocalist / Synthesizer Lead', status: 'active', ownershipPercentage: 30, votingWeight: 30, profitSharePercentage: 30, creativeAuthority: true, managementAuthority: true },
    { id: 'member_maya', name: 'Maya Vance', role: 'Bass / Modular Rig Engineer', status: 'active', ownershipPercentage: 25, votingWeight: 25, profitSharePercentage: 25, creativeAuthority: true, managementAuthority: false },
    { id: 'member_jude', name: 'Jude Miller', role: 'Drums / Trigger Pads / Percussion', status: 'active', ownershipPercentage: 25, votingWeight: 25, profitSharePercentage: 25, creativeAuthority: false, managementAuthority: false },
    { id: 'member_chloe', name: 'Chloe Sterling', role: 'Lead Guitars / Custom Midi Pedals', status: 'active', ownershipPercentage: 20, votingWeight: 20, profitSharePercentage: 20, creativeAuthority: true, managementAuthority: true }
  ]
};

// --- TEAM & PEOPLE ---
export const teamPeople: Person[] = [
  { id: 'person_mgr', name: 'Richard Vance', email: 'rvance@zenithmanagement.com', phone: '+1-310-555-0202', organisationId: 'org_mgmt', role: 'Lead Artist Manager', territory: 'WW', startDate: '2019-01-01', permissions: ['ALL'], feeType: 'commission', feeValue: 0, commissionRate: 15, notes: 'Managing the artist since discovery in East London.' },
  { id: 'person_lawyer', name: 'Alistair Hampton', email: 'ahampton@hamptonpartners.law', phone: '+1-212-555-0606', organisationId: 'org_law', role: 'General Counsel', territory: 'WW', startDate: '2019-03-12', permissions: ['contracts', 'legal'], feeType: 'retainer', feeValue: 7500, notes: 'Manages all contract negotiation and clearings.' },
  { id: 'person_acct', name: 'Nesta Miller', email: 'nmiller@soundledger.tax', phone: '+1-615-555-0707', organisationId: 'org_accounting', role: 'Business Manager / Accountant', territory: 'US_EU', startDate: '2020-01-15', permissions: ['accounting', 'royalties', 'finance'], feeType: 'commission', feeValue: 0, commissionRate: 5, notes: 'Coordinates all tax reporting and distributions.' },
  { id: 'person_agent', name: 'Sarah Jenkins', email: 'sjenkins@unitedtalent.com', phone: '+1-310-555-0505', organisationId: 'org_agency', role: 'Global Booking Agent', territory: 'WW', startDate: '2020-05-01', permissions: ['touring'], feeType: 'commission', feeValue: 0, commissionRate: 10, notes: 'Coordinates global routing, festivals, and venue bookings.' },
  { id: 'person_pub', name: 'Hannah Wright', email: 'hwright@skylinepress.com', phone: '+44-207-555-0999', organisationId: 'org_mgmt', role: 'Lead Publicist', territory: 'UK_EU', startDate: '2021-02-10', permissions: ['press'], feeType: 'flat', feeValue: 4000, notes: 'Manages press relationships and review pipelines.' },
  { id: 'person_a_r', name: 'Nigel West', email: 'nwest@apexmusic.com', phone: '+1-212-555-0101', organisationId: 'org_label', role: 'Label A&R Executive', territory: 'WW', startDate: '2021-09-01', permissions: ['catalogue'], feeType: 'flat', feeValue: 0, notes: 'Main point of contact at AMG label.' },
  { id: 'person_tm', name: 'Jackson Brody', email: 'jbrody@tourlife.com', phone: '+1-615-555-1122', organisationId: 'org_mgmt', role: 'Tour Manager', territory: 'WW', startDate: '2022-03-01', permissions: ['touring'], feeType: 'flat', feeValue: 2500, notes: 'Handles day-to-day operations and road logistics.' },
  { id: 'person_me', name: 'Seraphina Lin', email: 'slin@mixlab.io', phone: '+1-323-555-3344', organisationId: 'org_mgmt', role: 'Mix Engineer / Sound Designer', territory: 'US', startDate: '2020-08-01', permissions: ['catalogue'], feeType: 'flat', feeValue: 3500, notes: 'Lead engineer for multi-track stem deliveries.' }
];

// --- 40 COMPOSITIONS & 50 RECORDINGS ---
// Let's programmatically generate a robust catalogue of 40 compositions.
// A composition is NOT a recording. Let's create realistic titles and splits.
export const compositions: Composition[] = [];
export const recordings: Recording[] = [];

// Base track names for generating compositions
const trackBaseNames = [
  'Neon Horizon', 'Velocity Echo', 'Stellar Tide', 'Orbiting Chaos', 'Silent Resonance',
  'Monoliths in Motion', 'Vintage Gravity', 'Atmospheric Drag', 'Quartz Cascade', 'Electric Pulse',
  'Subterranean Hum', 'Lunar Phase', 'Cybernetic Dream', 'Friction Coefficients', 'Apex Rise',
  'Transient Wave', 'Binary Sunset', 'Digital Catalyst', 'Analogue Heart', 'Voltage Spike',
  'Chroma Blur', 'Infinite Drift', 'Prism Splinter', 'Echo Chamber', 'Static Cling',
  'Grid Runner', 'Solar Flare', 'Heavy Water', 'Signal Leak', 'Spectral Shift',
  'Carbon Shadow', 'Neural Net', 'Failsafe Switch', 'Overclocked Pulse', 'Dark Matter',
  'Vector Grid', 'Frequency Modulation', 'Synthesizer Sonata', 'Apex Rebound', 'The Last Tier'
];

// Writers of the band or collaborators
const bandWriters = [
  { personId: 'member_leo', name: 'Leo Hayes', ipi: 'IPI-0082711', role: 'composer-lyricist' as const },
  { personId: 'member_maya', name: 'Maya Vance', ipi: 'IPI-0091823', role: 'composer' as const },
  { personId: 'member_chloe', name: 'Chloe Sterling', ipi: 'IPI-0010293', role: 'composer' as const },
  { personId: 'external_collab', name: 'Kaelen O\'Neal', ipi: 'IPI-0044551', role: 'lyricist' as const } // External writer
];

// Construct 40 compositions
trackBaseNames.forEach((title, idx) => {
  const iswcIdx = 100000000 + idx;
  const iswc = `T-${String(iswcIdx).match(/.{1,3}/g)?.join('.')}-8`; // e.g. T-100.000.008-8

  // Normal split distribution for TUT.
  // We make one composition (e.g., track 39) have an INVALID split (exceeding 100% or incomplete) for testing and demonstration of our data quality module.
  let isSplitComplete = true;
  let writersSplits = [];

  if (idx === 38) {
    // Under-split (Incomplete split: 80% total)
    writersSplits = [
      { personId: 'member_leo', role: 'composer-lyricist' as const, splitPercentage: 40, ipi: 'IPI-0082711', publisherId: 'org_pub' },
      { personId: 'member_maya', role: 'composer' as const, splitPercentage: 40, ipi: 'IPI-0091823', publisherId: 'org_pub' }
    ];
    isSplitComplete = false;
  } else if (idx === 39) {
    // Over-split (Exceeding 100%: 110% total)
    writersSplits = [
      { personId: 'member_leo', role: 'composer-lyricist' as const, splitPercentage: 40, ipi: 'IPI-0082711', publisherId: 'org_pub' },
      { personId: 'member_maya', role: 'composer' as const, splitPercentage: 40, ipi: 'IPI-0091823', publisherId: 'org_pub' },
      { personId: 'member_chloe', role: 'composer' as const, splitPercentage: 30, ipi: 'IPI-0010293', publisherId: 'org_pub' }
    ];
    isSplitComplete = false;
  } else {
    // Normal correct splits (Summing up to 100%)
    writersSplits = [
      { personId: 'member_leo', role: 'composer-lyricist' as const, splitPercentage: 35, ipi: 'IPI-0082711', publisherId: 'org_pub' },
      { personId: 'member_maya', role: 'composer' as const, splitPercentage: 25, ipi: 'IPI-0091823', publisherId: 'org_pub' },
      { personId: 'member_chloe', role: 'composer' as const, splitPercentage: 25, ipi: 'IPI-0010293', publisherId: 'org_pub' },
      { personId: 'external_collab', role: 'lyricist' as const, splitPercentage: 15, ipi: 'IPI-0044551', publisherId: 'org_pub' }
    ];
  }

  compositions.push({
    id: `comp_${idx + 1}`,
    title,
    alternateTitles: idx % 4 === 0 ? [`${title} (Alt Mix)`, `${title} (Extended Instrumental)`] : [],
    iswc,
    workIds: [`WORK-US-TUT-${idx + 100}`],
    registrationStatus: idx === 38 || idx === 39 ? 'pending' : 'registered',
    territories: ['WW'],
    lyrics: `[Verse 1]\nSignals flashing on the grid...\n[Chorus]\nTake me over the Apex...\nWe are ${title}...`,
    writers: writersSplits,
    samples: idx === 5 ? [{ sourceWork: 'Vintage Retro Loop 1982', sharePercentage: 5, cleared: true }] : [],
    interpolations: [],
    isSplitComplete
  });
});

// Construct 50 Recordings
// For our 40 compositions, we create masters and some alternate versions (remixes, acapellas, instrumentals) to sum exactly to 50 recordings.
let recCount = 1;
compositions.forEach((comp, idx) => {
  // Create Main Studio Master
  const masterIsrcIdx = 9200000 + idx;
  const masterIsrc = `GB-APX-26-${String(masterIsrcIdx)}`;

  recordings.push({
    id: `rec_${recCount++}`,
    compositionId: comp.id,
    version: 'MASTER',
    recordingDate: idx < 15 ? '2020-04-12' : idx < 30 ? '2022-11-05' : '2026-02-18',
    studio: 'Sunset Analogue, LA',
    producerId: 'person_me',
    engineerId: 'person_me',
    isrc: masterIsrc,
    masterOwnerId: 'artist_tut', // Band owns their masters, licenses them
    labelId: 'org_label',
    format: 'WAV 96k 24bit',
    duration: 180 + (idx * 5) % 90, // Varied duration
    sampleRate: 96000,
    bitDepth: 24,
    hasStems: true,
    releaseStatus: 'released',
    stems: [
      { name: 'VOCALS', fileUrl: `/assets/masters/${comp.id}_vocals.wav`, size: '42.1 MB' },
      { name: 'SYNTHS', fileUrl: `/assets/masters/${comp.id}_synths.wav`, size: '65.2 MB' },
      { name: 'DRUMS', fileUrl: `/assets/masters/${comp.id}_drums.wav`, size: '58.4 MB' },
      { name: 'BASS', fileUrl: `/assets/masters/${comp.id}_bass.wav`, size: '49.8 MB' }
    ]
  });

  // For the first 10 compositions, we also generate secondary edits (e.g. Instrumental or Radio Edit, Remix, Acapella)
  if (idx < 10) {
    const editType = idx % 3 === 0 ? 'INSTRUMENTAL' : idx % 3 === 1 ? 'RADIO_EDIT' : 'REMIX';
    const subIsrcIdx = masterIsrcIdx + 50000;
    const subIsrc = `GB-APX-26-${String(subIsrcIdx)}`;

    recordings.push({
      id: `rec_${recCount++}`,
      compositionId: comp.id,
      version: editType,
      recordingDate: idx < 5 ? '2020-04-14' : '2023-01-10',
      studio: 'Sunset Analogue, LA',
      producerId: 'person_me',
      engineerId: 'person_me',
      isrc: subIsrc,
      masterOwnerId: 'artist_tut',
      labelId: 'org_label',
      format: 'WAV 48k 24bit',
      duration: editType === 'RADIO_EDIT' ? 175 : 180 + (idx * 5) % 90,
      sampleRate: 48000,
      bitDepth: 24,
      hasStems: false,
      releaseStatus: 'released',
      stems: []
    });
  }
});

// Ensure we have exactly 50 recordings. If not, top up.
while (recordings.length < 50) {
  const topIdx = recordings.length;
  const isrcIdx = 9500000 + topIdx;
  recordings.push({
    id: `rec_${recCount++}`,
    compositionId: `comp_${(topIdx % 40) + 1}`,
    version: 'DEMO',
    recordingDate: '2026-05-10',
    studio: 'TUT Home Lab',
    producerId: 'member_leo',
    engineerId: 'member_leo',
    isrc: `GB-APX-26-${String(isrcIdx)}`,
    masterOwnerId: 'artist_tut',
    labelId: 'org_label',
    format: 'MP3 320kbps',
    duration: 155,
    sampleRate: 44100,
    bitDepth: 16,
    hasStems: false,
    releaseStatus: 'unreleased',
    stems: []
  });
}

// --- RELEASES: 3 ALBUMS, 5 SINGLES ---
// Album 1: "Vintage Gravity"
// Album 2: "Apex of the Curve"
// Album 3: "Monoliths in Motion"
export const releases: Release[] = [
  {
    id: 'rel_album_1',
    title: 'Vintage Gravity',
    type: 'ALBUM',
    releaseDate: '2020-06-20',
    originalReleaseDate: '2020-06-20',
    upc: '075429102283',
    catalogNumber: 'APX-ALB-001',
    labelCode: 'LC-9827',
    genre: 'Electronic',
    subgenre: 'Synthwave',
    language: 'English',
    isExplicit: false,
    pLine: '℗ 2020 The Upper Tier Music Group LLC',
    cLine: '© 2020 The Upper Tier Music Group LLC / Apex Music Group',
    state: 'CATALOGUE',
    artworkUrl: 'https://images.unsplash.com/photo-1614613535308-eb5fbd3d2c17?q=80&w=400&h=400&fit=crop',
    tracks: [
      { recordingId: 'rec_1', sequenceNumber: 1 }, // Neon Horizon
      { recordingId: 'rec_3', sequenceNumber: 2 }, // Velocity Echo
      { recordingId: 'rec_5', sequenceNumber: 3 }, // Stellar Tide
      { recordingId: 'rec_7', sequenceNumber: 4 }, // Orbiting Chaos
      { recordingId: 'rec_9', sequenceNumber: 5 }, // Silent Resonance
      { recordingId: 'rec_11', sequenceNumber: 6 }, // Monoliths in Motion
      { recordingId: 'rec_13', sequenceNumber: 7 }  // Vintage Gravity
    ],
    checklist: { masterApproved: true, metadataApproved: true, artworkApproved: true, creditsApproved: true, rightsCleared: true, isrcAssigned: true, upcAssigned: true, dspConfigured: true, preSaveSet: true, marketingReady: true, physicalManufacturing: true }
  },
  {
    id: 'rel_album_2',
    title: 'Apex of the Curve',
    type: 'ALBUM',
    releaseDate: '2023-04-14',
    originalReleaseDate: '2023-04-14',
    upc: '075429103492',
    catalogNumber: 'APX-ALB-002',
    labelCode: 'LC-9827',
    genre: 'Electronic',
    subgenre: 'Cyber-Punk',
    language: 'English',
    isExplicit: true,
    pLine: '℗ 2023 The Upper Tier Music Group LLC',
    cLine: '© 2023 The Upper Tier Music Group LLC / Apex Music Group',
    state: 'CATALOGUE',
    artworkUrl: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=400&h=400&fit=crop',
    tracks: [
      { recordingId: 'rec_15', sequenceNumber: 1 }, // Quartz Cascade
      { recordingId: 'rec_16', sequenceNumber: 2 }, // Electric Pulse
      { recordingId: 'rec_17', sequenceNumber: 3 }, // Subterranean Hum
      { recordingId: 'rec_18', sequenceNumber: 4 }, // Lunar Phase
      { recordingId: 'rec_19', sequenceNumber: 5 }, // Cybernetic Dream
      { recordingId: 'rec_20', sequenceNumber: 6 }  // Friction Coefficients
    ],
    checklist: { masterApproved: true, metadataApproved: true, artworkApproved: true, creditsApproved: true, rightsCleared: true, isrcAssigned: true, upcAssigned: true, dspConfigured: true, preSaveSet: true, marketingReady: true, physicalManufacturing: true }
  },
  {
    id: 'rel_album_3',
    title: 'Monoliths in Motion',
    type: 'ALBUM',
    releaseDate: '2026-10-15', // Upcoming releases
    originalReleaseDate: '2026-10-15',
    upc: '075429108112',
    catalogNumber: 'APX-ALB-003',
    labelCode: 'LC-9827',
    genre: 'Alternative',
    subgenre: 'Indietronica',
    language: 'English',
    isExplicit: false,
    pLine: '℗ 2026 The Upper Tier Music Group LLC',
    cLine: '© 2026 The Upper Tier Music Group LLC / Apex Music Group',
    state: 'RECORDING', // Release state
    artworkUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=400&h=400&fit=crop',
    tracks: [
      { recordingId: 'rec_21', sequenceNumber: 1 }, // Apex Rise
      { recordingId: 'rec_22', sequenceNumber: 2 }, // Transient Wave
      { recordingId: 'rec_23', sequenceNumber: 3 }, // Binary Sunset
      { recordingId: 'rec_24', sequenceNumber: 4 }, // Digital Catalyst
      { recordingId: 'rec_25', sequenceNumber: 5 }  // Analogue Heart
    ],
    checklist: { masterApproved: true, metadataApproved: true, artworkApproved: true, creditsApproved: false, rightsCleared: false, isrcAssigned: true, upcAssigned: false, dspConfigured: false, preSaveSet: false, marketingReady: false, physicalManufacturing: false }
  },
  // 5 Singles
  {
    id: 'rel_single_1',
    title: 'Neon Horizon',
    type: 'SINGLE',
    releaseDate: '2019-11-10',
    upc: '075429100114',
    catalogNumber: 'APX-SGL-001',
    labelCode: 'LC-9827',
    genre: 'Electronic',
    subgenre: 'Synthwave',
    language: 'English',
    isExplicit: false,
    pLine: '℗ 2019 The Upper Tier Music Group LLC',
    cLine: '© 2019 Apex Music Group',
    state: 'CATALOGUE',
    artworkUrl: 'https://images.unsplash.com/photo-1508700115892-45ecd05ae2ad?q=80&w=400&h=400&fit=crop',
    tracks: [{ recordingId: 'rec_1', sequenceNumber: 1 }],
    checklist: { masterApproved: true, metadataApproved: true, artworkApproved: true, creditsApproved: true, rightsCleared: true, isrcAssigned: true, upcAssigned: true, dspConfigured: true, preSaveSet: true, marketingReady: true, physicalManufacturing: false }
  },
  {
    id: 'rel_single_2',
    title: 'Velocity Echo',
    type: 'SINGLE',
    releaseDate: '2020-02-05',
    upc: '075429100220',
    catalogNumber: 'APX-SGL-002',
    labelCode: 'LC-9827',
    genre: 'Electronic',
    subgenre: 'Synthwave',
    language: 'English',
    isExplicit: false,
    pLine: '℗ 2020 The Upper Tier Music Group LLC',
    cLine: '© 2020 Apex Music Group',
    state: 'CATALOGUE',
    artworkUrl: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=400&h=400&fit=crop',
    tracks: [{ recordingId: 'rec_3', sequenceNumber: 1 }, { recordingId: 'rec_4', sequenceNumber: 2 }],
    checklist: { masterApproved: true, metadataApproved: true, artworkApproved: true, creditsApproved: true, rightsCleared: true, isrcAssigned: true, upcAssigned: true, dspConfigured: true, preSaveSet: true, marketingReady: true, physicalManufacturing: false }
  },
  {
    id: 'rel_single_3',
    title: 'Stellar Tide',
    type: 'SINGLE',
    releaseDate: '2020-05-01',
    upc: '075429100336',
    catalogNumber: 'APX-SGL-003',
    labelCode: 'LC-9827',
    genre: 'Electronic',
    subgenre: 'Indietronica',
    language: 'English',
    isExplicit: false,
    pLine: '℗ 2020 The Upper Tier Music Group LLC',
    cLine: '© 2020 Apex Music Group',
    state: 'CATALOGUE',
    artworkUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?q=80&w=400&h=400&fit=crop',
    tracks: [{ recordingId: 'rec_5', sequenceNumber: 1 }],
    checklist: { masterApproved: true, metadataApproved: true, artworkApproved: true, creditsApproved: true, rightsCleared: true, isrcAssigned: true, upcAssigned: true, dspConfigured: true, preSaveSet: true, marketingReady: true, physicalManufacturing: false }
  },
  {
    id: 'rel_single_4',
    title: 'Orbiting Chaos',
    type: 'SINGLE',
    releaseDate: '2022-09-18',
    upc: '075429100442',
    catalogNumber: 'APX-SGL-004',
    labelCode: 'LC-9827',
    genre: 'Electronic',
    subgenre: 'Cyber-Punk',
    language: 'English',
    isExplicit: false,
    pLine: '℗ 2022 The Upper Tier Music Group LLC',
    cLine: '© 2022 Apex Music Group',
    state: 'CATALOGUE',
    artworkUrl: 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?q=80&w=400&h=400&fit=crop',
    tracks: [{ recordingId: 'rec_7', sequenceNumber: 1 }],
    checklist: { masterApproved: true, metadataApproved: true, artworkApproved: true, creditsApproved: true, rightsCleared: true, isrcAssigned: true, upcAssigned: true, dspConfigured: true, preSaveSet: true, marketingReady: true, physicalManufacturing: false }
  },
  {
    id: 'rel_single_5',
    title: 'Velocity Echo (Remixes)',
    type: 'REMIX',
    releaseDate: '2020-03-25',
    upc: '075429100558',
    catalogNumber: 'APX-SGL-002-RM',
    labelCode: 'LC-9827',
    genre: 'Electronic',
    subgenre: 'Synthwave',
    language: 'English',
    isExplicit: false,
    pLine: '℗ 2020 The Upper Tier Music Group LLC',
    cLine: '© 2020 Apex Music Group',
    state: 'CATALOGUE',
    artworkUrl: 'https://images.unsplash.com/photo-1506157786151-b8491531f063?q=80&w=400&h=400&fit=crop',
    tracks: [{ recordingId: 'rec_4', sequenceNumber: 1 }],
    checklist: { masterApproved: true, metadataApproved: true, artworkApproved: true, creditsApproved: true, rightsCleared: true, isrcAssigned: true, upcAssigned: true, dspConfigured: true, preSaveSet: true, marketingReady: true, physicalManufacturing: false }
  }
];

// --- CONTRACTS & RIGHTS ---
export const contracts: Contract[] = [
  {
    id: 'con_label_apex',
    contractType: 'recording',
    parties: ['The Upper Tier Music Group LLC', 'Apex Music Group (AMG)'],
    effectiveDate: '2019-09-01',
    expirationDate: '2029-08-31',
    renewalNoticeDate: '2029-02-28',
    territory: 'WW',
    term: '3 Firm Albums + 1 Option',
    advanceAmount: 500000, // $500,000 Initial Advance
    recoupmentRate: 100, // 100% of Artist Share goes to Recouped Pool until fully cleared
    royaltyRate: 18, // 18% Base artist royalty rate
    isExclusive: true,
    rightsGranted: ['Exclusive World-wide Physical exploitation', 'Exclusive Digital Audio Streaming', 'Direct Synchronisation sub-licensing'],
    rightsRetained: ['Merchandise creation direct-to-consumer', 'Sponsorship and Endorsement rights', 'Live Concert touring ownership'],
    accountingFrequency: 'semi-annually',
    deliveryRequirements: ['10-12 Studio Masters per album', '96kHz/24bit audio standard', 'Cleared stem deliverables for A&R approval'],
    approvalRights: ['Artwork approval', 'Master delivery approval', 'Co-producer selection'],
    alerts: [
      { id: 'al_con_1', type: 'expiry', date: '2029-08-31', triggered: false, description: 'Apex Recording Contract Expiry (WW)' },
      { id: 'al_con_2', type: 'option', date: '2026-10-15', triggered: false, description: 'Option Deadline for Album 3 Decision' },
      { id: 'al_con_3', type: 'delivery', date: '2026-09-30', triggered: false, description: 'Delivery Deadline for "Monoliths in Motion" Masters' }
    ]
  },
  {
    id: 'con_mgmt_zenith',
    contractType: 'management',
    parties: ['The Upper Tier Music Group LLC', 'Zenith Artist Management'],
    effectiveDate: '2019-01-01',
    expirationDate: '2026-12-31',
    renewalNoticeDate: '2026-10-01',
    territory: 'WW',
    term: '3 Years + 3 Year Renewal Option',
    advanceAmount: 0,
    recoupmentRate: 0,
    royaltyRate: 0,
    commissionRate: 15, // 15% commission on gross earnings
    isExclusive: true,
    rightsGranted: ['Non-exclusive representation of digital marketing products', 'Co-management authority representation'],
    rightsRetained: ['All copyright ownership in songwriting/compositions', 'Master sound recording licenses control'],
    accountingFrequency: 'monthly',
    deliveryRequirements: [],
    approvalRights: [],
    alerts: [
      { id: 'al_con_4', type: 'expiry', date: '2026-12-31', triggered: false, description: 'Zenith Management Contract Expiry (Alert: Expires in 111 Days)' }
    ]
  },
  {
    id: 'con_pub_vector',
    contractType: 'publishing',
    parties: ['The Upper Tier Music Group LLC', 'Vector Music Publishing'],
    effectiveDate: '2020-01-01',
    expirationDate: '2027-12-31',
    territory: 'WW',
    term: '5 Years Co-Publishing',
    advanceAmount: 150000,
    recoupmentRate: 100,
    royaltyRate: 75, // 75% Net receipts to writer, 25% kept by publisher
    isExclusive: true,
    rightsGranted: ['Exclusive World-wide administration rights', 'Mechanical collection sub-administration'],
    rightsRetained: ['50% Writer Share of Performance Royalties collected directly from PRS/BMI', 'NIL rights ownership'],
    accountingFrequency: 'quarterly',
    deliveryRequirements: ['Minimum commitment of 12 full songs written/co-written per year'],
    approvalRights: ['Sync licensing over $10,000 require artist approval'],
    alerts: [
      { id: 'al_con_5', type: 'audit', date: '2027-03-31', triggered: false, description: 'Vector Publishing Audit Window Opens' }
    ]
  }
];

// Programmatic Rights Map Generator based on Contracts
export const rights: Right[] = [];
// Generate master rights for AMG
compositions.forEach((comp) => {
  rights.push({
    id: `right_mas_${comp.id}`,
    rightType: 'master',
    ownerId: 'artist_tut',
    beneficiaryId: 'org_label', // AMG has licensed exploitation
    assetId: `rec_${comp.id.replace('comp_', '')}`,
    assetType: 'recording',
    territory: 'WW',
    startDate: '2019-09-01',
    endDate: '2029-08-31',
    percentage: 100,
    isExclusive: true,
    contractId: 'con_label_apex',
    licensingStatus: 'active',
    restrictions: ['No physical merchandising compilation release without written notice']
  });

  // Publishing Rights for Vector
  rights.push({
    id: `right_pub_${comp.id}`,
    rightType: 'publishing',
    ownerId: 'artist_tut',
    beneficiaryId: 'org_pub', // Vector manages publishing
    assetId: comp.id,
    assetType: 'composition',
    territory: 'WW',
    startDate: '2020-01-01',
    endDate: '2027-12-31',
    percentage: 50, // 50% Co-Pub split
    isExclusive: true,
    contractId: 'con_pub_vector',
    licensingStatus: 'active',
    restrictions: ['Strictly prohibited for use in oil/gas/tobacco advertisements']
  });
});

// --- ADVANCES & RECOUPMENT LEDGER ---
export const recoupmentPools: RecoupmentPool[] = [
  {
    id: 'pool_apex_primary',
    name: 'Apex Label Agreement Recoupment Ledger',
    originalAdvance: 500000,
    costs: [
      { type: 'recording', amount: 85000, description: 'Sunset Analogue Studio Hire & Tape Reels', date: '2020-02-10' },
      { type: 'marketing', amount: 120000, description: 'Vintage Gravity Promo Campaign & Physical Merchandising setup', date: '2020-05-15' },
      { type: 'touring', amount: 45000, description: 'Co-tour support advance subsidy', date: '2021-04-12' },
      { type: 'legal', amount: 15000, description: 'Contract signing fees & clearance payments', date: '2019-09-10' }
    ],
    credits: [
      { amount: 185000, source: '2021-S1 Royalty Statement Credit', date: '2021-09-30' },
      { amount: 110000, source: '2022-S1 Royalty Statement Credit', date: '2022-09-30' },
      { amount: 145000, source: '2023-S2 Royalty Statement Credit', date: '2024-03-31' },
      { amount: 125000, source: '2024-S2 Royalty Statement Credit', date: '2025-03-31' },
      { amount: 165000, source: '2025-S2 Royalty Statement Credit', date: '2026-03-31' }
    ],
    recoupmentRate: 100
  }
];

// --- ROYALTY STATEMENTS (LAST FIVE SESSIONS) ---
export const royaltyStatements: RoyaltyStatement[] = [
  { id: 'stmt_001', periodId: '2024-S1', statementDate: '2024-09-30', publisherOrLabel: 'Apex Music Group (AMG)', grossRevenue: 420000, deductions: 25000, netRevenue: 395000, calculatedRoyalty: 71100, recoupedAmount: 71100, paidAmount: 0, isReconciled: true, sourceFile: 'AMG_Tut_Royalty_2024S1.csv' },
  { id: 'stmt_002', periodId: '2024-S2', statementDate: '2025-03-31', publisherOrLabel: 'Apex Music Group (AMG)', grossRevenue: 510000, deductions: 30000, netRevenue: 480000, calculatedRoyalty: 86400, recoupedAmount: 86400, paidAmount: 0, isReconciled: true, sourceFile: 'AMG_Tut_Royalty_2024S2.csv' },
  { id: 'stmt_003', periodId: '2025-S1', statementDate: '2025-09-30', publisherOrLabel: 'Apex Music Group (AMG)', grossRevenue: 680000, deductions: 45000, netRevenue: 635000, calculatedRoyalty: 114300, recoupedAmount: 114300, paidAmount: 0, isReconciled: true, sourceFile: 'AMG_Tut_Royalty_2025S1.csv' },
  { id: 'stmt_004', periodId: '2025-S2', statementDate: '2026-03-31', publisherOrLabel: 'Apex Music Group (AMG)', grossRevenue: 850000, deductions: 55000, netRevenue: 795000, calculatedRoyalty: 143100, recoupedAmount: 143100, paidAmount: 0, isReconciled: true, sourceFile: 'AMG_Tut_Royalty_2025S2.csv' },
  { id: 'stmt_005', periodId: '2026-S1', statementDate: '2026-09-30', publisherOrLabel: 'Apex Music Group (AMG)', grossRevenue: 980000, deductions: 60000, netRevenue: 920000, calculatedRoyalty: 165600, recoupedAmount: 25000, paidAmount: 140600, isReconciled: false, sourceFile: 'AMG_Tut_Royalty_2026S1.csv' } // Current pending statement, finally starting to pay cash!
];

// Programmatic Royalty Transaction Logs
export const royaltyTransactions: RoyaltyTransaction[] = [];
// Generate a set of realistic metric reports for top hits
const dsps = ['Spotify', 'Apple Music', 'YouTube Music', 'Amazon Music', 'TikTok'];
const territories = ['US', 'GB', 'DE', 'JP', 'AU', 'FR', 'CA'];

for (let s = 1; s <= 50; s++) {
  const isMaster = s % 2 === 0;
  const dspIdx = s % dsps.length;
  const terrIdx = s % territories.length;
  const units = 150000 * (50 - s);
  const gross = units * 0.0035;
  const net = gross * 0.92;
  const allocated = net * 0.18; // 18% base royalty

  royaltyTransactions.push({
    id: `tx_${s}`,
    statementId: s <= 10 ? 'stmt_001' : s <= 20 ? 'stmt_002' : s <= 30 ? 'stmt_003' : s <= 40 ? 'stmt_004' : 'stmt_005',
    assetId: `rec_${(s % 40) + 1}`,
    assetType: 'recording',
    dsp: dsps[dspIdx],
    territory: territories[terrIdx],
    units,
    grossRevenue: gross,
    netRevenue: net,
    allocatedRoyalty: allocated,
    date: '2026-06-15'
  });
}

// --- TOURING ---
export const tours: Tour[] = [
  {
    id: 'tour_apex_2026',
    name: 'THE MONOLITH OVERDRIVE TOUR (2026)',
    year: 2026,
    legs: [
      {
        id: 'leg_us',
        name: 'North American Arena Leg',
        dates: [
          {
            id: 'td_001',
            date: '2026-10-20',
            city: 'New York',
            country: 'United States',
            venueId: 'Madison Square Garden',
            promoterId: 'Live Nation Global',
            status: 'booked',
            capacity: 18000,
            ticketsSold: 16420,
            ticketPrice: 85,
            guarantee: 350000,
            splitPercentage: 85,
            grossRevenue: 1395700,
            expenses: 420000,
            netSettlement: 829345, // calculated based on promoter variables
            merchRevenue: 112000,
            crewCount: 22,
            travelDetails: { departure: 'London Heathrow (LHR)', arrival: 'John F Kennedy (JFK)', method: 'flight', cost: 18500 },
            hotelBookings: [{ hotelName: 'Standard High Line NYC', rooms: 14, cost: 24500 }]
          },
          {
            id: 'td_002',
            date: '2026-10-23',
            city: 'Chicago',
            country: 'United States',
            venueId: 'United Center',
            promoterId: 'Live Nation Global',
            status: 'booked',
            capacity: 16500,
            ticketsSold: 14200,
            ticketPrice: 80,
            guarantee: 280000,
            splitPercentage: 85,
            grossRevenue: 1136000,
            expenses: 350000,
            netSettlement: 668100,
            merchRevenue: 91000,
            crewCount: 22,
            travelDetails: { departure: 'New York (JFK)', arrival: 'Chicago O\'Hare (ORD)', method: 'flight', cost: 6500 },
            hotelBookings: [{ hotelName: 'The Drake Chicago', rooms: 14, cost: 12000 }]
          },
          {
            id: 'td_003',
            date: '2026-10-28',
            city: 'Los Angeles',
            country: 'United States',
            venueId: 'The Forum',
            promoterId: 'Goldenvoice',
            status: 'booked',
            capacity: 17500,
            ticketsSold: 17500, // Sold out
            ticketPrice: 90,
            guarantee: 400000,
            splitPercentage: 85,
            grossRevenue: 1575000,
            expenses: 450000,
            netSettlement: 956250,
            merchRevenue: 145000,
            crewCount: 22,
            travelDetails: { departure: 'Chicago (ORD)', arrival: 'Los Angeles (LAX)', method: 'flight', cost: 8200 },
            hotelBookings: [{ hotelName: 'The Line Hotel LA', rooms: 14, cost: 18500 }]
          }
        ]
      },
      {
        id: 'leg_eu',
        name: 'European Club & Theatre Leg',
        dates: [
          {
            id: 'td_004',
            date: '2026-11-12',
            city: 'London',
            country: 'United Kingdom',
            venueId: 'Alexandra Palace',
            promoterId: 'Metropolis Music',
            status: 'booked',
            capacity: 10400,
            ticketsSold: 10400, // Sold out
            ticketPrice: 45, // GBP converted roughly
            guarantee: 120000,
            splitPercentage: 80,
            grossRevenue: 468000,
            expenses: 110000,
            netSettlement: 286400,
            merchRevenue: 64000,
            crewCount: 16,
            travelDetails: { departure: 'Los Angeles (LAX)', arrival: 'London Heathrow (LHR)', method: 'flight', cost: 24000 },
            hotelBookings: [{ hotelName: 'The Standard London', rooms: 10, cost: 15000 }]
          },
          {
            id: 'td_005',
            date: '2026-11-15',
            city: 'Berlin',
            country: 'Germany',
            venueId: 'Columbiahalle',
            promoterId: 'MCT Agentur',
            status: 'hold',
            capacity: 3500,
            ticketsSold: 2800,
            ticketPrice: 50,
            guarantee: 45000,
            splitPercentage: 80,
            grossRevenue: 140000,
            expenses: 35000,
            netSettlement: 84000,
            merchRevenue: 28000,
            crewCount: 16,
            travelDetails: { departure: 'London St Pancras', arrival: 'Berlin Hauptbahnhof', method: 'train', cost: 3500 },
            hotelBookings: [{ hotelName: 'Soho House Berlin', rooms: 10, cost: 8500 }]
          }
        ]
      }
    ]
  }
];

// --- MERCHANDISE INVENTORY ---
export const merchandiseProducts: MerchandiseProduct[] = [
  { id: 'merch_001', name: 'THE UPPER TIER - Monolith Geometric Tee', sku: 'TUT-TEE-MONO-BLK-M', category: 'Apparel', costPrice: 8.50, sellingPrice: 35.00, stockLevel: 450, reorderPoint: 100, variants: [{ sizeOrColor: 'S', stock: 120, sku: 'TUT-TEE-MONO-BLK-S' }, { sizeOrColor: 'M', stock: 150, sku: 'TUT-TEE-MONO-BLK-M' }, { sizeOrColor: 'L', stock: 180, sku: 'TUT-TEE-MONO-BLK-L' }], warehouseLocation: 'ShipBob LA Warehouse', totalSales: 1850 },
  { id: 'merch_002', name: 'THE UPPER TIER - Apex Cyber Hoodie', sku: 'TUT-HD-APEX-CHAR-M', category: 'Apparel', costPrice: 18.20, sellingPrice: 65.00, stockLevel: 24, reorderPoint: 50, variants: [{ sizeOrColor: 'S', stock: 2, sku: 'TUT-HD-APEX-CHAR-S' }, { sizeOrColor: 'M', stock: 4, sku: 'TUT-HD-APEX-CHAR-M' }, { sizeOrColor: 'L', stock: 18, sku: 'TUT-HD-APEX-CHAR-L' }], warehouseLocation: 'ShipBob LA Warehouse', totalSales: 940 }, // Under Stock Alert
  { id: 'merch_003', name: 'Vintage Gravity - 180g Sky Blue Gatefold Vinyl', sku: 'TUT-VIN-VINT-BLU-12', category: 'Vinyl', costPrice: 9.10, sellingPrice: 40.00, stockLevel: 820, reorderPoint: 200, variants: [], warehouseLocation: 'AMG Distribution Hub', totalSales: 3500 },
  { id: 'merch_004', name: 'Apex of the Curve - Limited Digipack CD', sku: 'TUT-CD-APEX-002', category: 'CD', costPrice: 3.20, sellingPrice: 18.00, stockLevel: -5, reorderPoint: 100, variants: [], warehouseLocation: 'AMG Distribution Hub', totalSales: 1240 }, // Negative stock anomaly
  { id: 'merch_005', name: 'Geometric Enamel Pin Badge Set', sku: 'TUT-PIN-GEO-SET', category: 'Accessories', costPrice: 1.80, sellingPrice: 12.00, stockLevel: 1200, reorderPoint: 200, variants: [], warehouseLocation: 'Zenith Storage Unit B', totalSales: 2200 }
];

// --- FINANCIAL TRANSACTION LEDGERS (SPLIT ENTITIES) ---
export const financialTransactions: FinancialTransaction[] = [
  // Income
  { id: 'fin_tx_1', date: '2026-08-15', type: 'income', category: 'merchandise', entityType: 'merchandise', amount: 48500, description: 'Shopify Checkout Sales - Aug 2026 Batch', reconciled: true },
  { id: 'fin_tx_2', date: '2026-09-01', type: 'income', category: 'touring', entityType: 'touring', amount: 150000, description: 'Live Nation Wire Guarantee Deposit leg-us', reconciled: true },
  { id: 'fin_tx_3', date: '2026-09-10', type: 'income', category: 'royalties', entityType: 'artist', amount: 140600, description: 'Statement settlement - S1 2026 net paid AMG', reconciled: false }, // Outstanding bank reconciliation
  // Expenses
  { id: 'fin_tx_4', date: '2026-08-10', type: 'expense', category: 'recording_costs', entityType: 'label', amount: -28500, description: 'Midi setup / Modular components rig hire', reconciled: true },
  { id: 'fin_tx_5', date: '2026-08-20', type: 'expense', category: 'marketing', entityType: 'management', amount: -12500, description: 'Prism Splinter Dolby Atmos spatial audio ad buy', reconciled: true },
  { id: 'fin_tx_6', date: '2026-09-05', type: 'expense', category: 'travel', entityType: 'touring', amount: -18500, description: 'LHR to JFK flight bookings leg-us', reconciled: true },
  { id: 'fin_tx_7', date: '2026-09-06', type: 'expense', category: 'legal_accounting', entityType: 'management', amount: -7500, description: 'Monthly General Counsel Retainer Hampton Partners', reconciled: true }
];

// --- CATALOGUE VALUATION ---
export const catalogueValuations: CatalogueValuation[] = [
  {
    id: 'val_2026_q3',
    valuationDate: '2026-09-01',
    historicalAnnualRevenue: 480000,
    multipleBasedValue: { multiple: 12.5, value: 6000000 },
    dcfValue: { discountRate: 8.5, perpetuityGrowth: 2.0, value: 5450000 },
    incomeCapitalizationValue: { capRate: 7.5, value: 6400000 },
    scenarios: {
      low: 4500000,
      base: 5950000, // Weighted blending of methodologies
      high: 7800000
    },
    assumptions: {
      streamingGrowth: 15.4,
      syncGrowth: 25.0,
      decayRate: -4.5,
      contractRemainingYears: 3
    }
  }
];

// --- MARKETING CAMPAIGNS ---
export const marketingCampaigns: MarketingCampaign[] = [
  {
    id: 'cam_mono_2026',
    name: 'Monoliths in Motion Album Rollout',
    type: 'release',
    status: 'active',
    startDate: '2026-07-01',
    endDate: '2026-11-01',
    budget: 150000,
    spend: 92450,
    channels: [
      { name: 'DSP Placement Pitching', spend: 5000, resultLabel: 'Pitch Acceptance Rate', resultValue: '85%' },
      { name: 'TikTok/Instagram Spatial Filters', spend: 25000, resultLabel: 'Filter Impressions', resultValue: '4.8M' },
      { name: 'Digital Out-of-Home (London/LA)', spend: 45000, resultLabel: 'Foot Traffic Reach', resultValue: '2.1M' },
      { name: 'YouTube Premise Video Promo', spend: 17450, resultLabel: 'Video Views Generated', resultValue: '1.2M' }
    ],
    kpis: [
      { metric: 'Album Pre-Saves', target: '50,000', actual: '41,200' },
      { metric: 'Spotify Lead Streams', target: '5.0M', actual: '4.2M' },
      { metric: 'TikTok Sound Additions', target: '100,000', actual: '112,000' }
    ],
    tasks: [
      { id: 'tk_cam_1', title: 'Deliver Dolby Atmos Mix to Distributor', assignedTo: 'Seraphina Lin', dueDate: '2026-09-15', completed: true },
      { id: 'tk_cam_2', title: 'Approve Vinyl Sleeve Test Proofs', assignedTo: 'Leo Hayes', dueDate: '2026-09-20', completed: false },
      { id: 'tk_cam_3', title: 'Schedule Pre-Save Embed Email Newsletters', assignedTo: 'Richard Vance', dueDate: '2026-10-01', completed: false }
    ]
  }
];

// --- DIGITAL ASSETS ---
export const digitalAssets: DigitalAsset[] = [
  { id: 'as_001', name: 'Monoliths in Motion Master (Atmos Mix)', category: 'Master', version: 'v2.1', hash: 'SHA256-42d4a51e6...', fileUrl: '/assets/masters/monoliths_v2.1.wav', fileSize: '185 MB', ownerId: 'artist_tut', approvalStatus: 'approved', approvedBy: 'Nigel West (AMG)', createdDate: '2026-08-10' },
  { id: 'as_002', name: 'Monolith Geometric Artwork Flat PSD', category: 'Artwork', version: 'v1.0', hash: 'SHA256-8ef3a52f2...', fileUrl: '/assets/art/monolith_final.psd', fileSize: '52 MB', ownerId: 'artist_tut', approvalStatus: 'approved', approvedBy: 'Leo Hayes', createdDate: '2026-07-15' },
  { id: 'as_003', name: 'Apex Tour Backline Blueprint PDF', category: 'PressRelease', version: 'v3.2', hash: 'SHA256-7ee3a44b9...', fileUrl: '/assets/docs/backline_v3.2.pdf', fileSize: '12 MB', ownerId: 'artist_tut', approvalStatus: 'pending', createdDate: '2026-09-02' }
];

// --- PRESS CONTACTS & PITCHES ---
export const pressContacts: PressContact[] = [
  { id: 'pr_001', name: 'Julian Mercer', publication: 'Pitchfork', role: 'Contributing Editor', email: 'j.mercer@pitchfork.com', influenceLevel: 'Tier 1', pitchHistory: [{ date: '2026-08-15', pitch: 'Exclusive advance stream of "Apex Rise" single', status: 'replied' }] },
  { id: 'pr_002', name: 'Clara Oswald', publication: 'NME', role: 'Reviews Editor', email: 'clara@nme.co.uk', influenceLevel: 'Tier 1', pitchHistory: [{ date: '2026-08-18', pitch: 'Feature interview with Leo & Chloe on Modular rigs', status: 'covered' }] },
  { id: 'pr_003', name: 'Thomas Thorne', publication: 'Resident Advisor', role: 'Staff Writer', email: 'thomas@ra.co', influenceLevel: 'Tier 2', pitchHistory: [{ date: '2026-08-22', pitch: 'Review copy of Monoliths in Motion LP', status: 'sent' }] }
];

// --- GENERIC WORKFLOWS ---
export const workflows: Workflow[] = [
  {
    id: 'wf_release_new',
    name: 'NEW SINGLE RELEASE PIPELINE',
    steps: [
      { id: 'ws_1', title: 'Song Composition Approved & Split Sheet Signed', status: 'completed', assignee: 'Alistair Hampton', completedAt: '2026-07-10' },
      { id: 'ws_2', title: 'Master approved by Band & Label', status: 'completed', assignee: 'Leo Hayes', completedAt: '2026-08-10' },
      { id: 'ws_3', title: 'High-Res Artwork signed-off and cleared', status: 'completed', assignee: 'Leo Hayes', completedAt: '2026-08-15' },
      { id: 'ws_4', title: 'Metadata, ISRC and UPC package validation', status: 'in_progress', assignee: 'Seraphina Lin' },
      { id: 'ws_5', title: 'Deliver package to Global Sonic Distribution Hub', status: 'pending', assignee: 'Richard Vance' },
      { id: 'ws_6', title: 'Pre-Save links & DSP pitching locking', status: 'pending', assignee: 'Richard Vance' }
    ]
  }
];

// --- IMMUTABLE AUDIT EVENTS ---
export const auditEvents: AuditEvent[] = [
  { id: 'aud_001', actor: 'Alistair Hampton', timestamp: '2026-07-10T14:20:00Z', entityType: 'composition', entityId: 'comp_1', action: 'SPLIT_SHEET_SIGNED', previousStateHash: 'PREV-74aef12d', newStateHash: 'HASH-8ef9300d', reason: 'Band members and external collaborator signed agreement split.' },
  { id: 'aud_002', actor: 'Nigel West (AMG)', timestamp: '2026-08-10T11:05:00Z', entityType: 'recording', entityId: 'rec_1', action: 'MASTER_APPROVED_FOR_RELEASE', previousStateHash: 'PREV-9ef82110', newStateHash: 'HASH-10af49dd', reason: 'Dolby Atmos Master checked in and fully certified by label A&R.' },
  { id: 'aud_003', actor: 'Nesta Miller', timestamp: '2026-09-01T09:12:00Z', entityType: 'royalty_rules', entityId: 'con_label_apex', action: 'ROYALTY_RECONCILIATION_RUN', previousStateHash: 'PREV-32fe8110', newStateHash: 'HASH-32fe8110', reason: 'Audit of S1 2026 statement from Apex Records. $140,600 verified net payable.' }
];

// --- ANOMALY DATABASE / DATA QUALITY CENTRE ---
export const initialAnomalies: AnomalyReport[] = [
  { id: 'anom_001', severity: 'high', category: 'splits', description: 'Composition "Apex Rebound" (ID: comp_39) split is incomplete (totaling 80%). Missing 20% owner allocation.', remediationStep: 'Prompt members to add missing writer split or adjust Leo Hayes share to 60%.', entityId: 'comp_39', entityType: 'composition' },
  { id: 'anom_002', severity: 'high', category: 'splits', description: 'Composition "The Last Tier" (ID: comp_40) split exceeds 100% (totaling 110%). Over-allocated by 10%.', remediationStep: 'Review the signed split sheet. Reduce Chloe Sterling allocation from 30% to 20% to balance exactly 100%.', entityId: 'comp_40', entityType: 'composition' },
  { id: 'anom_003', severity: 'medium', category: 'inventory', description: 'Apex of the Curve CD (SKU: TUT-CD-APEX-002) has negative stock level (-5). Indicating unfulfilled ecommerce backorders.', remediationStep: 'Verify warehouse shipment report. Reorder stock or log inventory adjustment.', entityId: 'merch_004', entityType: 'merchandise' },
  { id: 'anom_004', severity: 'low', category: 'contracts', description: 'Zenith Management Contract (ID: con_mgmt_zenith) expires in 111 days on 2026-12-31.', remediationStep: 'Draft option extension clause or commence renewal renegotiations.', entityId: 'con_mgmt_zenith', entityType: 'contract' },
  { id: 'anom_005', severity: 'medium', category: 'metadata', description: 'Release "Monoliths in Motion" (ID: rel_album_3) is missing its EAN/UPC code assignment.', remediationStep: 'Request UPC allocation from Global Sonic Distribution and insert into release metadata.', entityId: 'rel_album_3', entityType: 'release' }
];

// --- DSP Ingestion Layer Normalized Metrics ---
// Multi-dimension stream analytics curves over last 30 days
export const getIngestedStreamData = (daysCount = 30) => {
  const data = [];
  const baseValue = 185000;
  for (let i = daysCount; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];

    // Create a realistic upward trajectory with weekly weekend cycles (indices where i%7 has peaks)
    const weekendMultiplier = 1 + 0.15 * Math.sin((i / 7) * 2 * Math.PI);
    const growthTrend = 1 + (daysCount - i) * 0.005; // 0.5% daily growth
    const dailyRandom = 0.95 + Math.random() * 0.1;

    const streams = Math.round(baseValue * weekendMultiplier * growthTrend * dailyRandom);
    const listeners = Math.round(streams * 0.72);
    const saves = Math.round(streams * 0.08);

    data.push({
      date: dateStr,
      streams,
      listeners,
      saves,
      followerGrowth: 1500 + Math.round(Math.random() * 800)
    });
  }
  return data;
};
