/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// --- IDENTITY & CORE ---
export interface Artist {
  id: string;
  name: string;
  legalName: string;
  aliases: string[];
  genres: string[];
  subgenres: string[];
  territories: string[];
  languages: string[];
  biography: string;
  careerStart: string;
  managementCompanyId: string;
  labelId: string;
  publisherId: string;
  distributorId: string;
  bookingAgencyId: string;
  lawFirmId: string;
  accountingFirmId: string;
  publicistId: string;
  socials: { platform: string; url: string; handle: string; followers: number }[];
  website: string;
  brandIdentity: {
    logoUrl: string;
    primaryColor: string;
    secondaryColor: string;
    brandGuidelines: string;
  };
  audienceProfile: {
    demographics: { ageGroup: string; percentage: number }[];
    topTerritories: { country: string; listenerCount: number }[];
  };
  careerGoals: string[];
  members?: GroupMember[];
}

export interface GroupMember {
  id: string;
  name: string;
  role: string;
  status: 'active' | 'former' | 'session';
  ownershipPercentage: number;
  votingWeight: number;
  profitSharePercentage: number;
  creativeAuthority: boolean;
  managementAuthority: boolean;
}

export interface Person {
  id: string;
  name: string;
  email: string;
  phone: string;
  organisationId: string;
  role: string; // e.g., Tour Manager, Lawyer, A&R
  territory: string;
  contractId?: string;
  startDate: string;
  endDate?: string;
  permissions: string[];
  feeType: 'flat' | 'commission' | 'retainer';
  feeValue: number;
  commissionRate?: number;
  notes: string;
}

export interface Organisation {
  id: string;
  name: string;
  type: 'label' | 'management' | 'publisher' | 'distributor' | 'agency' | 'law_firm' | 'accounting_firm' | 'bank' | 'venue' | 'promoter';
  contactPerson: string;
  email: string;
  phone: string;
  territory: string;
}

// --- SONG, COMPOSITION, RECORDING & RELEASE ---
export interface Composition {
  id: string;
  title: string;
  alternateTitles: string[];
  iswc: string; // International Standard Musical Work Code
  workIds: string[];
  registrationStatus: 'pending' | 'registered' | 'disputed';
  territories: string[];
  lyrics: string;
  writers: {
    personId: string;
    role: 'composer' | 'lyricist' | 'composer-lyricist';
    splitPercentage: number;
    ipi: string;
    publisherId?: string;
  }[];
  samples: { sourceWork: string; sharePercentage: number; cleared: boolean }[];
  interpolations: { sourceWork: string; cleared: boolean }[];
  isSplitComplete: boolean;
}

export interface Recording {
  id: string;
  compositionId: string;
  version: string; // e.g., Album Version, Instrumental, Radio Edit
  recordingDate: string;
  studio: string;
  producerId: string;
  engineerId: string;
  isrc: string; // International Standard Recording Code
  masterOwnerId: string;
  labelId: string;
  format: string;
  duration: number; // in seconds
  sampleRate: number; // e.g., 96000
  bitDepth: number; // e.g., 24
  hasStems: boolean;
  releaseStatus: 'unreleased' | 'released' | 'archived';
  stems: { name: string; fileUrl: string; size: string }[];
}

export interface Release {
  id: string;
  title: string;
  type: 'SINGLE' | 'EP' | 'ALBUM' | 'DELUXE' | 'COMPILATION' | 'LIVE' | 'SOUNDTRACK' | 'REMIX' | 'BOX_SET';
  releaseDate: string;
  originalReleaseDate?: string;
  upc: string; // Universal Product Code / EAN
  catalogNumber: string;
  labelCode: string;
  genre: string;
  subgenre: string;
  language: string;
  isExplicit: boolean;
  pLine: string; // ℗ phonographic copyright
  cLine: string; // © copyright
  state: 'IDEA' | 'PLANNED' | 'A&R' | 'RECORDING' | 'MIXING' | 'MASTERING' | 'METADATA' | 'ARTWORK' | 'CLEARANCE' | 'DISTRIBUTION' | 'SCHEDULED' | 'RELEASED' | 'PROMOTING' | 'CATALOGUE' | 'ARCHIVED';
  artworkUrl: string;
  tracks: {
    recordingId: string;
    sequenceNumber: number;
  }[];
  checklist: {
    masterApproved: boolean;
    metadataApproved: boolean;
    artworkApproved: boolean;
    creditsApproved: boolean;
    rightsCleared: boolean;
    isrcAssigned: boolean;
    upcAssigned: boolean;
    dspConfigured: boolean;
    preSaveSet: boolean;
    marketingReady: boolean;
    physicalManufacturing: boolean;
  };
}

// --- RIGHTS & CONTRACTS ---
export interface Right {
  id: string;
  rightType: 'master' | 'composition' | 'publishing' | 'mechanical' | 'performance' | 'neighbouring' | 'sync' | 'digital' | 'physical' | 'territorial' | 'image_likeness' | 'merchandising';
  ownerId: string;
  beneficiaryId: string;
  assetId: string; // Can map to Recording ID or Composition ID
  assetType: 'recording' | 'composition';
  territory: string; // ISO Code or 'WW'
  startDate: string;
  endDate?: string;
  percentage: number;
  isExclusive: boolean;
  contractId: string;
  licensingStatus: 'restricted' | 'licensed' | 'disputed' | 'active';
  restrictions: string[];
}

export interface Contract {
  id: string;
  contractType: 'recording' | 'management' | 'publishing' | 'distribution' | 'sync' | 'booking' | 'merchandise' | 'employment' | 'nda';
  parties: string[]; // Party names
  effectiveDate: string;
  expirationDate: string;
  renewalNoticeDate?: string;
  territory: string;
  term: string; // e.g., "3 Options", "5 Years"
  advanceAmount: number;
  recoupmentRate: number; // e.g. 50 (means 50% of royalities go to recouping)
  royaltyRate: number; // Base rate e.g., 18 (means 18%)
  commissionRate?: number;
  rightsGranted: string[];
  rightsRetained: string[];
  isExclusive: boolean;
  accountingFrequency: 'monthly' | 'quarterly' | 'semi-annually' | 'annually';
  deliveryRequirements: string[];
  approvalRights: string[];
  alerts: {
    id: string;
    type: 'expiry' | 'option' | 'delivery' | 'audit' | 'renewal';
    date: string;
    triggered: boolean;
    description: string;
  }[];
}

// --- ROYALTIES, ADVANCES & RECOUPMENT ---
export interface RoyaltyRule {
  id: string;
  contractId: string;
  sourceType: 'streaming' | 'downloads' | 'physical' | 'sync' | 'performance' | 'merchandise' | 'neighbouring';
  territory: string;
  ratePercentage: number; // e.g., 18% of gross after deductions
  deductionsMaxPercentage: number; // e.g., 10%
  labelShare: number;
  artistShare: number;
  producerShare: number;
  writerShare: number;
  managerCommission: number;
}

export interface Advance {
  id: string;
  artistId: string;
  contractId: string;
  amount: number;
  date: string;
  status: 'paid' | 'pending';
  recoupmentPoolId: string;
}

export interface RecoupmentPool {
  id: string;
  name: string; // e.g., "Primary Album Recoupment"
  originalAdvance: number;
  costs: { type: 'recording' | 'marketing' | 'touring' | 'legal' | 'other'; amount: number; description: string; date: string }[];
  credits: { amount: number; source: string; date: string }[];
  recoupmentRate: number; // percentage of royalty income allocated to recouping
}

export interface RoyaltyStatement {
  id: string;
  periodId: string; // e.g., "2026-Q2"
  statementDate: string;
  publisherOrLabel: string;
  grossRevenue: number;
  deductions: number;
  netRevenue: number;
  calculatedRoyalty: number; // gross * split
  recoupedAmount: number;
  paidAmount: number;
  isReconciled: boolean;
  sourceFile: string;
}

export interface RoyaltyTransaction {
  id: string;
  statementId: string;
  assetId: string; // Recording or Composition ID
  assetType: 'recording' | 'composition';
  dsp: string; // e.g., Spotify, Apple Music
  territory: string;
  units: number; // e.g. streams count
  grossRevenue: number;
  netRevenue: number;
  allocatedRoyalty: number;
  date: string;
}

// --- TOURING SYSTEM ---
export interface Tour {
  id: string;
  name: string;
  year: number;
  legs: {
    id: string;
    name: string;
    dates: TourDate[];
  }[];
}

export interface TourDate {
  id: string;
  date: string;
  city: string;
  country: string;
  venueId: string;
  promoterId: string;
  status: 'hold' | 'booked' | 'settled' | 'cancelled';
  capacity: number;
  ticketsSold: number;
  ticketPrice: number;
  guarantee: number;
  splitPercentage: number; // Promoter vs Artist split e.g. 85 (means 85% to artist after expenses)
  grossRevenue: number;
  expenses: number;
  netSettlement: number;
  merchRevenue: number;
  crewCount: number;
  travelDetails: {
    departure: string;
    arrival: string;
    method: 'flight' | 'bus' | 'train' | 'car';
    cost: number;
  };
  hotelBookings: { hotelName: string; rooms: number; cost: number }[];
}

// --- MERCHANDISE ---
export interface MerchandiseProduct {
  id: string;
  name: string;
  sku: string;
  category: 'Apparel' | 'Vinyl' | 'CD' | 'Accessories' | 'Posters';
  costPrice: number;
  sellingPrice: number;
  stockLevel: number;
  reorderPoint: number;
  variants: { sizeOrColor: string; stock: number; sku: string }[];
  warehouseLocation: string;
  totalSales: number;
}

// --- FINANCE & FORECASTS ---
export interface FinancialTransaction {
  id: string;
  date: string;
  type: 'income' | 'expense';
  category: 'royalties' | 'advances' | 'merchandise' | 'touring' | 'recording_costs' | 'marketing' | 'legal_accounting' | 'insurance' | 'travel' | 'equipment' | 'tax';
  entityType: 'artist' | 'label' | 'management' | 'publishing' | 'touring' | 'merchandise';
  amount: number;
  description: string;
  reconciled: boolean;
}

export interface CatalogueValuation {
  id: string;
  valuationDate: string;
  historicalAnnualRevenue: number;
  multipleBasedValue: { multiple: number; value: number };
  dcfValue: { discountRate: number; perpetuityGrowth: number; value: number };
  incomeCapitalizationValue: { capRate: number; value: number };
  scenarios: {
    low: number;
    base: number;
    high: number;
  };
  assumptions: {
    streamingGrowth: number;
    syncGrowth: number;
    decayRate: number; // for catalog decay
    contractRemainingYears: number;
  };
}

// --- MARKETING CAMPAIGNS ---
export interface MarketingCampaign {
  id: string;
  name: string;
  type: 'release' | 'tour' | 'merchandise' | 'reissue' | 'brand_partnership';
  status: 'planned' | 'active' | 'completed' | 'paused';
  startDate: string;
  endDate: string;
  budget: number;
  spend: number;
  channels: { name: string; spend: number; resultLabel: string; resultValue: string }[];
  kpis: { metric: string; target: string; actual: string }[];
  tasks: { id: string; title: string; assignedTo: string; dueDate: string; completed: boolean }[];
}

// --- CONTENT MANAGEMENT ---
export interface DigitalAsset {
  id: string;
  name: string;
  category: 'Master' | 'Stem' | 'Artwork' | 'Logo' | 'Photograph' | 'Video' | 'PressRelease';
  version: string;
  hash: string;
  fileUrl: string;
  fileSize: string;
  ownerId: string;
  approvalStatus: 'pending' | 'approved' | 'rejected';
  approvedBy?: string;
  createdDate: string;
}

// --- PRESS & PUBLICITY ---
export interface PressContact {
  id: string;
  name: string;
  publication: string;
  role: string;
  email: string;
  influenceLevel: 'Tier 1' | 'Tier 2' | 'Tier 3';
  pitchHistory: { date: string; pitch: string; status: 'sent' | 'replied' | 'covered' | 'passed' }[];
}

// --- WORKFLOWS & LOGS ---
export interface Workflow {
  id: string;
  name: string; // e.g., "New Single Release Lifecycle"
  steps: {
    id: string;
    title: string;
    status: 'pending' | 'in_progress' | 'completed';
    assignee: string;
    completedAt?: string;
  }[];
}

export interface AuditEvent {
  id: string;
  actor: string;
  timestamp: string;
  entityType: string;
  entityId: string;
  action: string; // e.g., "MASTER_APPROVED", "CONTRACT_MODIFIED"
  previousStateHash: string;
  newStateHash: string;
  reason: string;
}

export interface AnomalyReport {
  id: string;
  severity: 'low' | 'medium' | 'high';
  category: 'metadata' | 'royalties' | 'contracts' | 'splits' | 'inventory';
  description: string;
  remediationStep: string;
  entityId: string;
  entityType: string;
}
