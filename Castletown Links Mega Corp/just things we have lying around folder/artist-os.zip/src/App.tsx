/**
 * @license
 * SPDX-License-Identifier: Apache-2.5
 */

import React, { useState } from 'react';
import {
  mainArtist,
  teamPeople,
  compositions as initialCompositions,
  recordings as initialRecordings,
  releases as initialReleases,
  contracts as initialContracts,
  recoupmentPools as initialRecoupmentPools,
  royaltyStatements as initialRoyaltyStatements,
  tours as initialTours,
  merchandiseProducts as initialMerchandiseProducts,
  financialTransactions as initialFinancialTransactions,
  catalogueValuations,
  marketingCampaigns as initialMarketingCampaigns,
  digitalAssets as initialDigitalAssets,
  pressContacts,
  workflows,
  auditEvents as initialAuditEvents,
  initialAnomalies,
  getIngestedStreamData,
  rights
} from './data';

import ArtistGraph from './components/ArtistGraph';
import AiAssistant from './components/AiAssistant';
import QualityRemediation from './components/QualityRemediation';

import {
  ShieldAlert,
  Terminal,
  Grid,
  TrendingUp,
  Sliders,
  DollarSign,
  Briefcase,
  Music,
  Users,
  Layers,
  MapPin,
  Calendar,
  Layers3,
  Box,
  FileText,
  Clock,
  Sparkles,
  ArrowUpRight,
  Database,
  ArrowRight,
  CheckCircle,
  HelpCircle
} from 'lucide-react';

export default function App() {
  // --- STATE FOR CANONICAL GRAPHS ---
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [timeframe, setTimeframe] = useState<string>('CAREER');
  
  // Stateful database variables for simulation mutations
  const [anomalies, setAnomalies] = useState(initialAnomalies);
  const [recoupmentPool, setRecoupmentPool] = useState(initialRecoupmentPools[0]);
  const [financialTxs, setFinancialTxs] = useState(initialFinancialTransactions);
  const [merchProducts, setMerchProducts] = useState(initialMerchandiseProducts);
  const [campaigns, setCampaigns] = useState(initialMarketingCampaigns);
  const [compositions, setCompositions] = useState(initialCompositions);
  const [recordings, setRecordings] = useState(initialRecordings);
  const [releases, setReleases] = useState(initialReleases);
  const [contracts, setContracts] = useState(initialContracts);
  const [auditLogs, setAuditLogs] = useState(initialAuditEvents);
  const [simulationLog, setSimulationLog] = useState<string[]>([
    "System booted normally on 2026-09-11. Integrated relational database connected.",
    "Ready for major catalogue simulation triggers."
  ]);

  // --- VALUATION ENGINE STATE ---
  const [discountRate, setDiscountRate] = useState<number>(8.5);
  const [growthRate, setGrowthRate] = useState<number>(15.4);
  const [decayRate, setDecayRate] = useState<number>(-4.5);
  const [scenarioOption, setScenarioOption] = useState<'independent' | 'major_deal' | 'licensing' | 'sale'>('major_deal');

  // --- TIME-BASED METRIC MULTIPLIERS ---
  const getTimeframeMultiplier = () => {
    switch (timeframe) {
      case 'TODAY': return 0.001;
      case 'THIS WEEK': return 0.015;
      case 'THIS MONTH': return 0.08;
      case 'THIS QUARTER': return 0.25;
      case 'THIS YEAR': return 0.85;
      default: return 1.0;
    }
  };

  const mult = getTimeframeMultiplier();

  // Traversed state totals
  const totalStreams = Math.round(185420000 * mult);
  const totalListeners = Math.round(5210000 * mult);
  const grossIncome = financialTxs.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const grossExpenses = financialTxs.filter(t => t.type === 'expense').reduce((sum, t) => sum + Math.abs(t.amount), 0);
  const cashInHand = grossIncome - grossExpenses;

  // Recoupment Pool Ledger Sums
  const totalCost = recoupmentPool.originalAdvance + recoupmentPool.costs.reduce((sum, c) => sum + c.amount, 0);
  const totalRecouped = recoupmentPool.credits.reduce((sum, c) => sum + c.amount, 0);
  const unrecoupedBalance = Math.max(0, totalCost - totalRecouped);

  // --- SIMULATION MUTATORS ---
  const handleSimulate = (type: string) => {
    const timestamp = new Date().toISOString().substring(11, 19);
    
    if (type === 'viral_spike') {
      // Mutate streams metric and financial cash balance
      const newIncome = {
        id: `fin_tx_sim_${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        type: 'income' as const,
        category: 'royalties' as const,
        entityType: 'artist' as const,
        amount: 175000,
        description: `Viral TikTok/DSP streams spike allocation credit`,
        reconciled: true
      };
      
      // Update recoupment ledger too
      const newCredit = {
        amount: 125000,
        source: 'Simulated Viral DSP Surge Royalty Credit',
        date: new Date().toISOString().split('T')[0]
      };

      setFinancialTxs(prev => [newIncome, ...prev]);
      setRecoupmentPool(prev => ({
        ...prev,
        credits: [...prev.credits, newCredit]
      }));
      setSimulationLog(prev => [
        `[${timestamp}] SPIKE ACTIVE: +50M streams registered. Generated +$175K cash gross, credited +$125K towards advance recoupment ledger.`,
        ...prev
      ]);
    } else if (type === 'netflix_sync') {
      const newIncome = {
        id: `fin_tx_sim_${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        type: 'income' as const,
        category: 'royalties' as const,
        entityType: 'publishing' as const,
        amount: 120000,
        description: `Netflix "Velocity Echo" Sync Sync Placement Clearance Wire`,
        reconciled: true
      };

      setFinancialTxs(prev => [newIncome, ...prev]);
      setSimulationLog(prev => [
        `[${timestamp}] LICENSE SECURED: Netflix synch placement registered for "Velocity Echo" in retro sci-fi series. $120,000 revenue wired. Splits cleared at 50/50 publisher/master split.`,
        ...prev
      ]);
    } else if (type === 'album_drop') {
      const newIncome = {
        id: `fin_tx_sim_${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        type: 'income' as const,
        category: 'royalties' as const,
        entityType: 'label' as const,
        amount: 250000,
        description: `"Monoliths in Motion" LP Release streaming ingestion revenue S1`,
        reconciled: true
      };

      setFinancialTxs(prev => [newIncome, ...prev]);
      setSimulationLog(prev => [
        `[${timestamp}] RELEASE DROP: "Monoliths in Motion" delivered and exploited. Global Sonic confirmed $250,000 initial exploitation revenue wired to Sound Ledger escrow account.`,
        ...prev
      ]);
    } else if (type === 'tour_expense') {
      const newExpense = {
        id: `fin_tx_sim_${Date.now()}`,
        date: new Date().toISOString().split('T')[0],
        type: 'expense' as const,
        category: 'travel' as const,
        entityType: 'touring' as const,
        amount: -40000,
        description: `Charter travel cancellation fee & custom backline gear damage leg-us`,
        reconciled: true
      };

      setFinancialTxs(prev => [newExpense, ...prev]);
      setSimulationLog(prev => [
        `[${timestamp}] CHARTER OVERRUN: Major travel logs disruption on USA Leg. $40,000 cancellation fee and damaged backline amp components charged. Tour cash runway reduced.`,
        ...prev
      ]);
    }
  };

  // --- ANOMALY REMEDIATION ---
  const handleRemediate = (anomalyId: string) => {
    const timestamp = new Date().toISOString().substring(11, 19);
    const resolvedAnom = anomalies.find(a => a.id === anomalyId);

    if (!resolvedAnom) return;

    setAnomalies(prev => prev.filter(a => a.id !== anomalyId));

    if (resolvedAnom.id === 'anom_001') {
      // Fix Split Sheet 39 in compositions database
      setCompositions(prev => prev.map(comp => {
        if (comp.id === 'comp_39') {
          return {
            ...comp,
            writers: [
              { personId: 'member_leo', role: 'composer-lyricist', splitPercentage: 60, ipi: 'IPI-0082711', publisherId: 'org_pub' },
              { personId: 'member_maya', role: 'composer', splitPercentage: 40, ipi: 'IPI-0091823', publisherId: 'org_pub' }
            ],
            isSplitComplete: true,
            registrationStatus: 'registered'
          };
        }
        return comp;
      }));
      setSimulationLog(prev => [
        `[${timestamp}] REMEDIATION: Fixed comp_39 "Apex Rebound" split. Adjusted Leo Hayes allocation to 60% with Maya Vance 40%. Total: 100.0%. Status updated: Registered.`,
        ...prev
      ]);
    } else if (resolvedAnom.id === 'anom_002') {
      // Fix over-allocated split in compositions
      setCompositions(prev => prev.map(comp => {
        if (comp.id === 'comp_40') {
          return {
            ...comp,
            writers: [
              { personId: 'member_leo', role: 'composer-lyricist', splitPercentage: 40, ipi: 'IPI-0082711', publisherId: 'org_pub' },
              { personId: 'member_maya', role: 'composer', splitPercentage: 40, ipi: 'IPI-0091823', publisherId: 'org_pub' },
              { personId: 'member_chloe', role: 'composer', splitPercentage: 20, ipi: 'IPI-0010293', publisherId: 'org_pub' }
            ],
            isSplitComplete: true,
            registrationStatus: 'registered'
          };
        }
        return comp;
      }));
      setSimulationLog(prev => [
        `[${timestamp}] REMEDIATION: Corrected comp_40 "The Last Tier" split sheet. Reduced Chloe Sterling share to 20% to resolve 110% over-allocation. Balance matches 100.0%.`,
        ...prev
      ]);
    } else if (resolvedAnom.id === 'anom_003') {
      // Fix negative CD inventory
      setMerchProducts(prev => prev.map(prod => {
        if (prod.id === 'merch_004') {
          return { ...prod, stockLevel: 250 };
        }
        return prod;
      }));
      setSimulationLog(prev => [
        `[${timestamp}] REMEDIATION: Restocked SKU TUT-CD-APEX-002 from AMG Hub. Physical inventory verified at 250 units. Backorders cleared.`,
        ...prev
      ]);
    } else if (resolvedAnom.id === 'anom_004') {
      // Extend management contract
      setContracts(prev => prev.map(con => {
        if (con.id === 'con_mgmt_zenith') {
          return { ...con, expirationDate: '2029-12-31', term: 'Extended +3 Year Term' };
        }
        return con;
      }));
      setSimulationLog(prev => [
        `[${timestamp}] REMEDIATION: Renewed Zenith management contract through 2029-12-31. Expiry alert cleared.`,
        ...prev
      ]);
    } else if (resolvedAnom.id === 'anom_005') {
      // Attach EAN/UPC to Monolith release
      setReleases(prev => prev.map(rel => {
        if (rel.id === 'rel_album_3') {
          return {
            ...rel,
            upc: '075429109012',
            checklist: { ...rel.checklist, upcAssigned: true }
          };
        }
        return rel;
      }));
      setSimulationLog(prev => [
        `[${timestamp}] REMEDIATION: Assigned barcode UPC "075429109012" to Monoliths in Motion LP. Package metadata ready for DSP ingestion.`,
        ...prev
      ]);
    }

    // Add immutable audit log entry
    const newAuditLog = {
      id: `aud_sim_${Date.now()}`,
      actor: 'Leo Hayes (TUT)',
      timestamp: new Date().toISOString(),
      entityType: resolvedAnom.entityType,
      entityId: resolvedAnom.entityId,
      action: 'DATA_QUALITY_REMEDIATED',
      previousStateHash: 'PREV-SIM-0x21',
      newStateHash: 'HASH-REMEDIATED-0x99',
      reason: `Human manual correction via Data Quality Centre. Issue corrected statefully.`
    };

    setAuditLogs(prev => [newAuditLog, ...prev]);
  };

  // --- CATALOGUE SCENARIOS ECONOMIC MODELLER ---
  const calculateScenariosValuation = () => {
    // Valuation base formula matching Section 27 inputs
    const baseRevenue = 480000;
    const compoundMultiplier = scenarioOption === 'sale' ? 14.5 : scenarioOption === 'independent' ? 10.0 : scenarioOption === 'licensing' ? 12.0 : 12.5;
    
    // Apply slider variables statefully
    const growthAdjustment = 1 + (growthRate - 15.4) / 100;
    const decayAdjustment = 1 + (decayRate + 4.5) / 100;
    const discountAdjustment = 1 - (discountRate - 8.5) / 100;

    const baseVal = Math.round(baseRevenue * compoundMultiplier * growthAdjustment * decayAdjustment * discountAdjustment);
    return {
      low: Math.round(baseVal * 0.75),
      base: baseVal,
      high: Math.round(baseVal * 1.35)
    };
  };

  const currentValuation = calculateScenariosValuation();

  return (
    <div id="artist-os-container" className="min-h-screen bg-slate-950 text-slate-100 flex flex-col antialiased">
      {/* 1. TOP INDUSTRIAL BANNER */}
      <header id="top-header" className="bg-slate-900 border-b border-slate-800 px-6 py-4 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="bg-sky-500 text-slate-950 font-black p-2 rounded text-sm font-mono tracking-tighter">
            ARTIST OS
          </div>
          <div>
            <h1 className="text-base font-bold font-mono tracking-wider text-slate-200">
              ARTIST OPERATING SYSTEM
            </h1>
            <p className="text-[10px] text-slate-500 font-mono">
              Institutional Platform for Record Labels, Catalog Owners, and Artists &bull; Live Container Build v3.6.4
            </p>
          </div>
        </div>

        {/* Current Active Release Widget */}
        <div className="flex items-center gap-4 bg-slate-950 border border-slate-800 p-2 rounded max-w-sm">
          <img
            src="https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=400&h=400&fit=crop"
            alt="Current Cover"
            className="h-10 w-10 rounded border border-slate-800 object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="font-mono text-left">
            <span className="text-[8px] text-slate-500 block uppercase tracking-widest font-bold">NEXT MAJOR RELEASE STATE</span>
            <span className="text-xs text-sky-400 font-bold block truncate max-w-[180px]">Monoliths in Motion</span>
            <span className="text-[9px] text-emerald-400 block font-bold">A&R MASTER MIX CHECK STAGE</span>
          </div>
        </div>
      </header>

      {/* 2. MAIN WORKSPACE GRID WITH SIDEBAR */}
      <div id="workspace-grid" className="flex-1 flex flex-col lg:flex-row">
        
        {/* SIDEBAR NAVIGATION MODULE */}
        <aside id="sidebar-nav" className="lg:w-64 bg-slate-900 border-b lg:border-b-0 lg:border-r border-slate-800 p-4 space-y-1.5 flex flex-col justify-between shrink-0">
          <div className="space-y-1">
            <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block px-3.5 mb-2.5 font-bold">
              Institutional Controls
            </span>

            {[
              { id: 'dashboard', label: 'Command Centre', icon: <Grid className="h-4 w-4" /> },
              { id: 'identity', label: 'Artist Profile', icon: <Users className="h-4 w-4" /> },
              { id: 'team', label: 'Professional Team', icon: <Briefcase className="h-4 w-4" /> },
              { id: 'catalogue', label: 'Catalogue & Graph', icon: <Music className="h-4 w-4" /> },
              { id: 'rights', label: 'Rights & Contracts', icon: <Layers className="h-4 w-4" /> },
              { id: 'royalties', label: 'Royalties Ledger', icon: <DollarSign className="h-4 w-4" /> },
              { id: 'marketing', label: 'DSP & Marketing', icon: <Layers3 className="h-4 w-4" /> },
              { id: 'touring', label: 'Touring & Merch', icon: <MapPin className="h-4 w-4" /> },
              { id: 'valuations', label: 'Valuations Modeller', icon: <Sliders className="h-4 w-4" /> },
              { id: 'ai', label: 'AI Audit Assistant', icon: <Sparkles className="h-4 w-4 text-sky-400" /> },
              { id: 'quality', label: 'Quality & Simulator', icon: <ShieldAlert className="h-4 w-4 text-emerald-400 animate-pulse" /> }
            ].map((tab) => {
              const isActive = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  id={`btn-nav-${tab.id}`}
                  onClick={() => setActiveTab(tab.id)}
                  className={`w-full text-left px-3.5 py-2.5 rounded text-xs font-bold font-mono tracking-wide transition-all flex items-center gap-3 ${
                    isActive
                      ? 'bg-sky-500 text-slate-950 font-black shadow-md'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-850'
                  }`}
                >
                  {tab.icon}
                  {tab.label}
                  {tab.id === 'quality' && anomalies.length > 0 && (
                    <span className="ml-auto bg-red-500 text-white font-bold text-[8px] h-4 w-4 rounded-full flex items-center justify-center animate-bounce">
                      {anomalies.length}
                    </span>
                  )}
                </button>
              );
            })}
          </div>

          <div className="pt-4 border-t border-slate-800 space-y-2 text-[10px] text-slate-500 font-mono">
            <div className="flex items-center gap-2">
              <Database className="h-3 w-3 text-emerald-500" />
              <span>DB Status: Connected</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-3 w-3 text-sky-500" />
              <span>Current Term: Firm Period</span>
            </div>
          </div>
        </aside>

        {/* 3. WORKING WORKSPACE CANVAS */}
        <main id="main-canvas" className="flex-1 p-6 overflow-y-auto space-y-6">
          
          {/* TAB 1: EXECUTIVE COMMAND CENTRE */}
          {activeTab === 'dashboard' && (
            <div className="space-y-6">
              
              {/* TIMEFRAME FILTERS BANNER */}
              <div className="bg-slate-900 border border-slate-800 p-3 rounded-lg flex flex-wrap justify-between items-center gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-bold">FILTERS VIEW:</span>
                  <div className="flex gap-1.5 bg-slate-950 p-1 rounded border border-slate-850">
                    {['TODAY', 'THIS WEEK', 'THIS MONTH', 'THIS QUARTER', 'THIS YEAR', 'CAREER'].map((tf) => (
                      <button
                        key={tf}
                        onClick={() => setTimeframe(tf)}
                        className={`px-3 py-1 text-[9px] font-mono rounded transition-colors ${
                          timeframe === tf
                            ? 'bg-sky-500 text-slate-950 font-bold'
                            : 'text-slate-400 hover:text-slate-200'
                        }`}
                      >
                        {tf}
                      </button>
                    ))}
                  </div>
                </div>

                <span className="text-[10px] font-mono text-slate-400">
                  Target Artist: <strong className="text-slate-100">THE UPPER TIER</strong> &bull; Group Master Owners
                </span>
              </div>

              {/* HIGH-DENSITY EXECUTIVE CARD GRID */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                
                {/* WIDGET 1: STREAM CONSUMPTION */}
                <div id="widget-streams" className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider font-bold">NORMALIZED STREAMS</span>
                  <div className="my-2.5">
                    <span className="text-2xl font-mono font-bold tracking-tight text-sky-400">
                      {totalStreams.toLocaleString()}
                    </span>
                    <span className="text-[9px] text-emerald-400 font-mono block mt-0.5 font-bold">
                      YTD velocity +18.4% YoY
                    </span>
                  </div>
                  <span className="text-[9px] text-slate-400 font-mono truncate">
                    Spotify / Apple / YouTube
                  </span>
                </div>

                {/* WIDGET 2: REVENUE SUMMARY */}
                <div id="widget-revenue" className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider font-bold">REVENUE LEDGER</span>
                  <div className="my-2.5">
                    <span className="text-2xl font-mono font-bold tracking-tight text-emerald-400">
                      ${Math.round(grossIncome * mult).toLocaleString()}
                    </span>
                    <span className="text-[9px] text-emerald-400 font-mono block mt-0.5 font-bold">
                      Reconciled bank accounts
                    </span>
                  </div>
                  <span className="text-[9px] text-slate-400 font-mono truncate">
                    Sync, Merch &amp; Live settlements
                  </span>
                </div>

                {/* WIDGET 3: RECOUPMENT POOL LEDGER */}
                <div id="widget-recoupment" className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider font-bold">AMG RECOUPMENT LEVEL</span>
                  <div className="my-2.5">
                    <span className={`text-2xl font-mono font-bold tracking-tight ${unrecoupedBalance === 0 ? 'text-emerald-400' : 'text-amber-500'}`}>
                      ${unrecoupedBalance.toLocaleString()}
                    </span>
                    <span className="text-[9px] text-slate-400 font-mono block mt-0.5 font-bold">
                      {unrecoupedBalance === 0 ? 'Fully Recouped! Paying Cash' : `Remaining Unrecouped Balance`}
                    </span>
                  </div>
                  <span className="text-[9px] text-slate-400 font-mono truncate">
                    Of ${totalCost.toLocaleString()} original pool
                  </span>
                </div>

                {/* WIDGET 4: CORE VALUATION */}
                <div id="widget-valuation" className="bg-slate-900 border border-slate-800 p-4 rounded-lg flex flex-col justify-between">
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider font-bold">CATALOGUE VALUE BASE</span>
                  <div className="my-2.5">
                    <span className="text-2xl font-mono font-bold tracking-tight text-slate-100">
                      ${(currentValuation.base / 1000000).toFixed(2)}M
                    </span>
                    <span className="text-[9px] text-sky-400 font-mono block mt-0.5 font-bold">
                      Multiplier blend: {scenarioOption.toUpperCase()}
                    </span>
                  </div>
                  <span className="text-[9px] text-slate-400 font-mono truncate">
                    Low Case: ${(currentValuation.low / 1000000).toFixed(2)}M
                  </span>
                </div>
              </div>

              {/* SYSTEM COMPLIANCE SUMMARY & ACTIVE CAMPAIGN */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                
                {/* CAMPAIGN KPI CARD */}
                <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
                  <div className="flex justify-between items-center pb-2.5 border-b border-slate-800">
                    <span className="text-xs font-bold font-mono tracking-wider uppercase text-slate-300">
                      ACTIVE HIGH-PRIORITY CAMPAIGN
                    </span>
                    <span className="bg-emerald-500/15 border border-emerald-500/20 text-emerald-400 font-mono text-[9px] px-2 py-0.5 rounded font-bold uppercase">
                      Status: Active
                    </span>
                  </div>

                  <div className="space-y-3">
                    <h3 className="text-lg font-bold font-mono tracking-tight text-slate-100">
                      {campaigns[0].name}
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed font-mono">
                      Target window: {campaigns[0].startDate} to {campaigns[0].endDate} &bull; Promoting Upcoming LP "Monoliths in Motion".
                    </p>

                    <div className="grid grid-cols-3 gap-4 border-t border-slate-800/60 pt-3">
                      <div>
                        <span className="text-[8px] font-mono text-slate-500 block">CAMPAIGN BUDGET</span>
                        <span className="text-sm font-mono font-bold text-slate-200">
                          ${campaigns[0].budget.toLocaleString()}
                        </span>
                      </div>
                      <div>
                        <span className="text-[8px] font-mono text-slate-500 block">COMMITTED SPEND</span>
                        <span className="text-sm font-mono font-bold text-sky-400">
                          ${campaigns[0].spend.toLocaleString()}
                        </span>
                      </div>
                      <div>
                        <span className="text-[8px] font-mono text-slate-500 block">ALBUM PRE-SAVES</span>
                        <span className="text-sm font-mono font-bold text-emerald-400">
                          {campaigns[0].kpis[0].actual} / {campaigns[0].kpis[0].target}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* CONTRACT CRITICAL COMPLIANCE CARD */}
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4 flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-2 pb-2.5 border-b border-slate-800 mb-3.5">
                      <ShieldAlert className="h-4.5 w-4.5 text-amber-500" />
                      <span className="text-xs font-bold font-mono uppercase tracking-wider text-slate-300">
                        CRITICAL ALERTS &amp; EVENTS
                      </span>
                    </div>

                    <div className="space-y-2.5 font-mono">
                      {contracts[0].alerts.slice(0, 3).map((al) => (
                        <div key={al.id} className="flex gap-2.5 text-[10px] items-start border-l-2 border-amber-500 pl-2">
                          <div className="flex-1">
                            <span className="text-slate-400 block font-bold truncate max-w-[200px]">
                              {al.description}
                            </span>
                            <span className="text-[9px] text-slate-500">
                              Target Date: {al.date}
                            </span>
                          </div>
                          <span className="bg-amber-500/10 border border-amber-500/25 px-1.5 py-0.5 rounded text-amber-400 text-[8px] uppercase font-bold shrink-0">
                            Urgent
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <button
                    onClick={() => setActiveTab('rights')}
                    className="w-full text-center py-2 bg-slate-950 hover:bg-slate-850 border border-slate-850 hover:border-slate-800 rounded text-[10px] font-bold font-mono tracking-wider transition-colors text-slate-300 flex items-center justify-center gap-2"
                  >
                    GO TO CONTRACT COMPLIANCE <ArrowRight className="h-3.5 w-3.5 text-sky-400" />
                  </button>
                </div>
              </div>

              {/* UNIFIED ARTIST GRAPH TRAVERSER EMBEDDED */}
              <ArtistGraph />
            </div>
          )}

          {/* TAB 2: ARTIST IDENTITY RECORD */}
          {activeTab === 'identity' && (
            <div className="space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-6">
                <div>
                  <h2 className="text-lg font-bold font-mono tracking-tight text-slate-100 uppercase">
                    ARTIST PROFILE IDENTITY FILE
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Canonical band membership registration, voting weight allocations, profit splits, and asset metadata.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Biography & core details */}
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-bold">ARTIST STATEMENT & BIOGRAPHY</span>
                      <p className="text-xs text-slate-300 leading-relaxed font-mono">
                        {mainArtist.biography}
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4 border-t border-slate-800/80 pt-4 font-mono text-xs">
                      <div>
                        <span className="text-slate-500 text-[9px] block">LEGAL NAME ENTITY</span>
                        <span className="text-slate-200 font-bold block mt-0.5">{mainArtist.legalName}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 text-[9px] block">GENRE MATRIX</span>
                        <span className="text-sky-400 font-bold block mt-0.5">{mainArtist.genres.join(' / ')}</span>
                      </div>
                    </div>
                  </div>

                  {/* Brand Guidelines & Brand Identity */}
                  <div className="bg-slate-950 rounded-lg border border-slate-850 p-5 space-y-4 font-mono">
                    <span className="text-[9px] font-mono text-sky-400 uppercase tracking-widest block font-bold">
                      BRAND IDENTITY & GUIDELINES
                    </span>
                    <div className="space-y-3">
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-500">Brand Primary Slate Accent</span>
                        <div className="flex items-center gap-2">
                          <span className="h-3 w-3 rounded bg-slate-900 border border-slate-700"></span>
                          <span className="text-slate-400 text-[10px] font-bold">#0F172A</span>
                        </div>
                      </div>
                      <div className="flex justify-between items-center text-xs">
                        <span className="text-slate-500">Brand Sky Blue Interactive</span>
                        <div className="flex items-center gap-2">
                          <span className="h-3 w-3 rounded bg-sky-400"></span>
                          <span className="text-sky-400 text-[10px] font-bold">#38BDF8</span>
                        </div>
                      </div>
                      <p className="text-[10px] text-slate-400 leading-relaxed pt-2 border-t border-slate-900">
                        {mainArtist.brandIdentity.brandGuidelines}
                      </p>
                    </div>
                  </div>
                </div>

                {/* GROUP MEMBERSHIP TABLE (WITH PROFIT AND VOTING REGISTRATION) */}
                <div className="border-t border-slate-800 pt-6 space-y-4">
                  <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">
                    CANONICAL BAND MEMBERSHIP & PROFIT SHARING AGREEMENT
                  </span>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left font-mono text-xs">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase">
                          <th className="pb-2.5">Member Name</th>
                          <th className="pb-2.5">Instrumental Role</th>
                          <th className="pb-2.5">Ownership Share</th>
                          <th className="pb-2.5">Profit split</th>
                          <th className="pb-2.5">Voting weight</th>
                          <th className="pb-2.5">Creative Auth</th>
                          <th className="pb-2.5">Management Auth</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850/60 text-slate-300">
                        {mainArtist.members?.map((m) => (
                          <tr key={m.id} className="hover:bg-slate-950/40">
                            <td className="py-3 font-bold text-slate-200">{m.name}</td>
                            <td className="py-3 text-slate-400">{m.role}</td>
                            <td className="py-3 font-bold text-sky-400">{m.ownershipPercentage}.0%</td>
                            <td className="py-3 font-bold text-emerald-400">{m.profitSharePercentage}.0%</td>
                            <td className="py-3 text-slate-400">{m.votingWeight}.0%</td>
                            <td className="py-3">
                              <span className={`px-2 py-0.5 rounded text-[8px] font-bold ${m.creativeAuthority ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>
                                {m.creativeAuthority ? 'YES' : 'NO'}
                              </span>
                            </td>
                            <td className="py-3">
                              <span className={`px-2 py-0.5 rounded text-[8px] font-bold ${m.managementAuthority ? 'bg-sky-500/10 text-sky-400' : 'bg-slate-800 text-slate-500'}`}>
                                {m.managementAuthority ? 'YES' : 'NO'}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: PROFESSIONAL TEAM DATABASE */}
          {activeTab === 'team' && (
            <div className="space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-6">
                <div>
                  <h2 className="text-lg font-bold font-mono tracking-tight text-slate-100 uppercase">
                    PROFESSIONAL TEAM &amp; CREW REGISTRY
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Label executives, Business Managers, General Counsels, and touring audio technicians mapped with contract dependencies.
                  </p>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left font-mono text-xs">
                      <thead>
                        <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase">
                          <th className="pb-2.5">Name</th>
                          <th className="pb-2.5">Functional Role</th>
                          <th className="pb-2.5">Territory</th>
                          <th className="pb-2.5">Start Date</th>
                          <th className="pb-2.5">Fee / Compensation Type</th>
                          <th className="pb-2.5">Commission Rate</th>
                          <th className="pb-2.5">Security Clearances</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-850/60 text-slate-300">
                        {teamPeople.map((person) => (
                          <tr key={person.id} className="hover:bg-slate-950/40">
                            <td className="py-3 font-bold text-slate-200">
                              <div>{person.name}</div>
                              <div className="text-[10px] text-slate-500 font-normal mt-0.5">{person.email}</div>
                            </td>
                            <td className="py-3 font-bold text-sky-400">{person.role}</td>
                            <td className="py-3 text-slate-400">{person.territory}</td>
                            <td className="py-3 text-slate-400">{person.startDate}</td>
                            <td className="py-3">
                              <span className="capitalize">{person.feeType}</span>
                              {person.feeValue > 0 && ` ($${person.feeValue.toLocaleString()})`}
                            </td>
                            <td className="py-3 text-slate-400 font-bold">
                              {person.commissionRate ? `${person.commissionRate}.0%` : 'Flat Rate'}
                            </td>
                            <td className="py-3">
                              <div className="flex gap-1 flex-wrap">
                                {person.permissions.map((p, i) => (
                                  <span key={i} className="bg-slate-950 border border-slate-850 text-[8px] text-slate-400 px-1.5 py-0.5 rounded font-bold uppercase">
                                    {p}
                                  </span>
                                ))}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: CATALOGUE BROWSER & COMPOSITIONS */}
          {activeTab === 'catalogue' && (
            <div className="space-y-6">
              {/* Relationship Traverser Graph Embed */}
              <ArtistGraph />

              {/* MAIN RECORDINGS BROWSER TABLE */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <h2 className="text-lg font-bold font-mono tracking-tight text-slate-100 uppercase">
                      CATALOGUE COMPOSITIONS &amp; RECORDINGS ENGINE
                    </h2>
                    <p className="text-xs text-slate-400 mt-1">
                      Validate master ISRC codes, mechanical splits, duration metrics, and digital assets versioning history.
                    </p>
                  </div>
                  <span className="text-xs font-mono bg-slate-950 border border-slate-800 text-slate-300 px-3 py-1.5 rounded">
                    Total: <strong className="text-sky-400">{compositions.length}</strong> Compositions &bull; <strong className="text-sky-400">{recordings.length}</strong> Recordings
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left font-mono text-xs">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase">
                        <th className="pb-2.5">Track Title</th>
                        <th className="pb-2.5">ISWC</th>
                        <th className="pb-2.5">Writers Splits Split</th>
                        <th className="pb-2.5">Master ISRC</th>
                        <th className="pb-2.5">Duration</th>
                        <th className="pb-2.5">Sample format</th>
                        <th className="pb-2.5">Stem State</th>
                        <th className="pb-2.5">Split Sheets</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850/60 text-slate-300">
                      {compositions.slice(0, 15).map((comp) => {
                        // Traverse related recordings
                        const relatedRec = recordings.find(r => r.compositionId === comp.id);
                        
                        // Total writer split summation
                        const totalSplits = comp.writers.reduce((sum, w) => sum + w.splitPercentage, 0);

                        return (
                          <tr key={comp.id} className="hover:bg-slate-950/40">
                            <td className="py-3 font-bold text-slate-200">
                              <div>{comp.title}</div>
                              {comp.alternateTitles.length > 0 && (
                                <div className="text-[9px] text-slate-500 font-normal mt-0.5">Alt: {comp.alternateTitles[0]}</div>
                              )}
                            </td>
                            <td className="py-3 text-slate-400">{comp.iswc}</td>
                            <td className="py-3">
                              <div className="space-y-0.5 text-[10px]">
                                {comp.writers.map((w, i) => (
                                  <div key={i} className="flex justify-between max-w-[150px]">
                                    <span className="text-slate-500">{w.personId.replace('member_', '').replace('external_', '')}:</span>
                                    <span className="font-bold text-slate-300">{w.splitPercentage}%</span>
                                  </div>
                                ))}
                              </div>
                            </td>
                            <td className="py-3 text-sky-400 font-bold font-mono">{relatedRec?.isrc || 'Pending'}</td>
                            <td className="py-3 text-slate-400">
                              {relatedRec ? `${Math.floor(relatedRec.duration / 60)}:${String(relatedRec.duration % 60).padStart(2, '0')}` : 'N/A'}
                            </td>
                            <td className="py-3 text-[10px] text-slate-500">{relatedRec?.format || 'N/A'}</td>
                            <td className="py-3">
                              <span className={`px-2 py-0.5 rounded text-[8px] font-bold ${relatedRec?.hasStems ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-800 text-slate-500'}`}>
                                {relatedRec?.hasStems ? '4 STEMS OK' : 'NO STEMS'}
                              </span>
                            </td>
                            <td className="py-3">
                              {comp.isSplitComplete ? (
                                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded text-[8px] font-bold">
                                  100.0% VERIFIED
                                </span>
                              ) : (
                                <span className="bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded text-[8px] font-bold animate-pulse">
                                  {totalSplits}% INVALID
                                </span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>

                <div className="text-[10px] text-slate-500 text-center font-mono">
                  Showing top 15 of {compositions.length} tracks. Remediate splits anomalies in the "Quality &amp; Simulator" tab.
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: RIGHTS & CONTRACTING */}
          {activeTab === 'rights' && (
            <div className="space-y-6">
              
              {/* CONTRACTS OVERVIEW */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-6">
                <div>
                  <h2 className="text-lg font-bold font-mono tracking-tight text-slate-100 uppercase">
                    CONTRACT TERMS &amp; ACCOUNTING DEADLINES
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Track recoupment multipliers, base royalty thresholds, exclusivity parameters, and alert triggers.
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  {contracts.map((con) => (
                    <div key={con.id} className="bg-slate-950 p-5 rounded-lg border border-slate-850 flex flex-col justify-between font-mono space-y-4">
                      <div className="space-y-3.5">
                        <div className="flex justify-between items-start">
                          <span className="text-[9px] uppercase bg-sky-500/10 text-sky-400 px-2 py-0.5 rounded font-bold border border-sky-500/20">
                            {con.contractType}
                          </span>
                          <span className="text-[10px] text-slate-500">{con.effectiveDate}</span>
                        </div>

                        <div>
                          <h3 className="text-xs font-bold text-slate-200">
                            {con.parties.join(' vs. ')}
                          </h3>
                        </div>

                        <div className="space-y-2 text-xs pt-3 border-t border-slate-900">
                          <div className="flex justify-between">
                            <span className="text-slate-500">Exclusivity WW</span>
                            <span className="text-slate-300 font-bold">{con.isExclusive ? 'Yes' : 'No'}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Advance Amount</span>
                            <span className="text-emerald-400 font-bold">${con.advanceAmount.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Base Royalty Rate</span>
                            <span className="text-sky-400 font-bold">{con.royaltyRate}.0%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Recoupment Share</span>
                            <span className="text-amber-500 font-bold">{con.recoupmentRate}.0%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-slate-500">Accounting freq</span>
                            <span className="text-slate-300 font-bold capitalize">{con.accountingFrequency}</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-3 border-t border-slate-900">
                        <span className="text-[8px] text-slate-500 uppercase tracking-widest block font-bold mb-1.5">ACTIVE WORKFLOW ALERTS</span>
                        <div className="space-y-1">
                          {con.alerts.map((al) => (
                            <div key={al.id} className="text-[9px] text-amber-500 flex items-center gap-1">
                              <span className="h-1 w-1 bg-amber-500 rounded-full"></span>
                              <span>{al.description} ({al.date})</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* RIGHTS ASSIGNMENT ENGINE */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4">
                <div>
                  <h2 className="text-xs font-bold text-slate-100 uppercase font-mono tracking-wider">
                    EXPLOITATION RIGHTS CONTROL MATRIX
                  </h2>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Real-time check of mechanical, neighboring, physical, and territorial synchronization license restrictions.
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left font-mono text-xs">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase">
                        <th className="pb-2.5">Asset Reference</th>
                        <th className="pb-2.5">Right Type</th>
                        <th className="pb-2.5">Territorial Scope</th>
                        <th className="pb-2.5">License Start</th>
                        <th className="pb-2.5">License End</th>
                        <th className="pb-2.5">Contract Basis</th>
                        <th className="pb-2.5">Licensing Restrictions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850/60 text-slate-300">
                      {rights.slice(0, 10).map((right) => (
                        <tr key={right.id} className="hover:bg-slate-950/40">
                          <td className="py-3 font-bold text-slate-200">{right.assetId} ({right.assetType})</td>
                          <td className="py-3">
                            <span className="bg-slate-950 border border-slate-850 px-2 py-0.5 rounded text-[8px] uppercase text-sky-400 font-bold">
                              {right.rightType}
                            </span>
                          </td>
                          <td className="py-3 text-slate-400">{right.territory}</td>
                          <td className="py-3 text-slate-400">{right.startDate}</td>
                          <td className="py-3 text-slate-400">{right.endDate || 'Perpetuity'}</td>
                          <td className="py-3 text-slate-500">{right.contractId}</td>
                          <td className="py-3 text-slate-400 truncate max-w-[200px]" title={right.restrictions.join(', ')}>
                            {right.restrictions[0]}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: ROYALTIES ACCOUNTING & RECOUPMENT LEDGER */}
          {activeTab === 'royalties' && (
            <div className="space-y-6">
              
              {/* ADVANCES & RECOUPMENT LEDGER CARD */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-6">
                <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                  <div>
                    <h2 className="text-lg font-bold font-mono tracking-tight text-slate-100 uppercase">
                      ADVANCE &amp; RECOUPABLE COSTS LEDGER (POOL: APEX_PRIMARY)
                    </h2>
                    <p className="text-xs text-slate-400 mt-1">
                      Stateful unrecouped balances tracker incorporating real-time marketing, recording, and legal additions.
                    </p>
                  </div>
                  <div className="flex bg-slate-950 p-2 rounded border border-slate-800 font-mono text-xs items-center gap-4">
                    <div>
                      <span className="text-slate-500 text-[8px] block uppercase">UNRECOUPED LEDGER STATUS</span>
                      <span className={`font-bold block ${unrecoupedBalance === 0 ? 'text-emerald-400' : 'text-amber-500'}`}>
                        ${unrecoupedBalance.toLocaleString()}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Ledger calculations block */}
                <div className="bg-slate-950 rounded-lg border border-slate-850 p-5 font-mono text-xs space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pb-4 border-b border-slate-900">
                    <div>
                      <span className="text-slate-500 text-[9px] block">A. INITIAL ADVANCE</span>
                      <span className="text-slate-200 font-bold block text-sm">${recoupmentPool.originalAdvance.toLocaleString()}</span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[9px] block">B. ADDED RECOUPABLE COSTS</span>
                      <span className="text-sky-400 font-bold block text-sm">
                        +${recoupmentPool.costs.reduce((sum, c) => sum + c.amount, 0).toLocaleString()}
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-500 text-[9px] block">C. TOTAL ROYALTY CREDIT</span>
                      <span className="text-emerald-400 font-bold block text-sm">
                        -${totalRecouped.toLocaleString()}
                      </span>
                    </div>
                    <div className="bg-slate-900 p-2.5 rounded border border-slate-850">
                      <span className="text-sky-500 text-[9px] block uppercase font-bold">UNRECOUPED DEFICIT</span>
                      <span className={`font-bold block text-base ${unrecoupedBalance === 0 ? 'text-emerald-400 animate-pulse' : 'text-amber-500'}`}>
                        ${unrecoupedBalance.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Ledger logs detail */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2">
                    <div className="space-y-2">
                      <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">RECOUPABLE COSTS DEBIT SUMMARY</span>
                      <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                        {recoupmentPool.costs.map((cost, i) => (
                          <div key={i} className="flex justify-between p-2 rounded bg-slate-900/50 border border-slate-900 text-[10px]">
                            <span className="text-slate-400">{cost.description}</span>
                            <span className="text-red-400 font-bold">+${cost.amount.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-2">
                      <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest block font-bold">ROYALTY Statement Credits Applied</span>
                      <div className="space-y-1.5 max-h-[160px] overflow-y-auto pr-1">
                        {recoupmentPool.credits.map((credit, i) => (
                          <div key={i} className="flex justify-between p-2 rounded bg-slate-900/50 border border-slate-900 text-[10px]">
                            <span className="text-slate-400">{credit.source}</span>
                            <span className="text-emerald-400 font-bold">-${credit.amount.toLocaleString()}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* ROYALTY STATEMENTS HISTORIC RECORDS */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-4">
                <div>
                  <h2 className="text-xs font-bold text-slate-100 uppercase font-mono tracking-wider">
                    LABEL-GRADE COMPLIANCE ROYALTY REPORTING LEDGER
                  </h2>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Verified semi-annual accounting statement files, showing gross clearances, distribution deductions, and net cash pays.
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left font-mono text-xs">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase">
                        <th className="pb-2.5">Accounting Period</th>
                        <th className="pb-2.5">Statement Date</th>
                        <th className="pb-2.5">Gross Receipts</th>
                        <th className="pb-2.5">Deductions</th>
                        <th className="pb-2.5">Net Revenue</th>
                        <th className="pb-2.5">Artist Share (18%)</th>
                        <th className="pb-2.5">Recouped Amount</th>
                        <th className="pb-2.5">Net cash pay</th>
                        <th className="pb-2.5">Audited &amp; Reconciled</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850/60 text-slate-300">
                      {initialRoyaltyStatements.map((stmt) => (
                        <tr key={stmt.id} className="hover:bg-slate-950/40">
                          <td className="py-3 font-bold text-slate-200">{stmt.periodId}</td>
                          <td className="py-3 text-slate-400">{stmt.statementDate}</td>
                          <td className="py-3 font-bold text-slate-200">${stmt.grossRevenue.toLocaleString()}</td>
                          <td className="py-3 text-red-400">-${stmt.deductions.toLocaleString()}</td>
                          <td className="py-3 font-bold text-emerald-400">${stmt.netRevenue.toLocaleString()}</td>
                          <td className="py-3 text-sky-400 font-bold">${stmt.calculatedRoyalty.toLocaleString()}</td>
                          <td className="py-3 text-slate-400">${stmt.recoupedAmount.toLocaleString()}</td>
                          <td className="py-3 font-bold text-emerald-400">
                            ${(stmt.calculatedRoyalty - stmt.recoupedAmount).toLocaleString()}
                          </td>
                          <td className="py-3">
                            <span className={`px-2 py-0.5 rounded text-[8px] font-bold ${stmt.isReconciled ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400 border border-red-500/25 animate-pulse'}`}>
                              {stmt.isReconciled ? 'RECONCILED' : 'PENDING WIRE RECONCILE'}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: DSP ANALYTICS, CAMPAIGNS, CONTENT, PRESS */}
          {activeTab === 'marketing' && (
            <div className="space-y-6">
              
              {/* DSP INGESTION LAYER - NORMALIZED CHARTS */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-6">
                <div>
                  <h2 className="text-lg font-bold font-mono tracking-tight text-slate-100 uppercase">
                    PLATFORM-NEUTRAL DSP INGESTION ENGINE
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Normalized daily streaming trajectories, save-rates, skip-ratios, and follower growth trends over the last 30 days.
                  </p>
                </div>

                {/* Custom SVG Line Chart */}
                <div className="bg-slate-950 border border-slate-850 rounded-lg p-5">
                  <div className="flex justify-between items-center mb-4 text-xs font-mono">
                    <span className="text-slate-500 uppercase tracking-wider text-[9px]">Trajectory Graph: Daily Normalized Streams YTD</span>
                    <span className="text-sky-400 font-bold">AVG Daily Velocity: 185,420 streams</span>
                  </div>

                  <div className="h-[200px] w-full flex items-end">
                    <svg className="w-full h-full" viewBox="0 0 500 100" preserveAspectRatio="none">
                      {/* Grid background */}
                      <line x1="0" y1="25" x2="500" y2="25" stroke="#1e293b" strokeDasharray="5,5" />
                      <line x1="0" y1="50" x2="500" y2="50" stroke="#1e293b" strokeDasharray="5,5" />
                      <line x1="0" y1="75" x2="500" y2="75" stroke="#1e293b" strokeDasharray="5,5" />

                      {/* Spark line trajectory */}
                      <path
                        d="M 0,80 Q 50,60 100,75 T 200,45 T 300,55 T 400,25 T 500,10"
                        fill="none"
                        stroke="#38bdf8"
                        strokeWidth="2.5"
                        strokeLinecap="round"
                      />
                      {/* Gradient glow fill */}
                      <path
                        d="M 0,80 Q 50,60 100,75 T 200,45 T 300,55 T 400,25 T 500,10 L 500,100 L 0,100 Z"
                        fill="url(#skyGradient)"
                        opacity="0.1"
                      />
                      <defs>
                        <linearGradient id="skyGradient" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="0%" stopColor="#38bdf8" />
                          <stop offset="100%" stopColor="#38bdf8" stopOpacity="0" />
                        </linearGradient>
                      </defs>
                    </svg>
                  </div>
                  <div className="flex justify-between text-[9px] text-slate-500 font-mono mt-2.5">
                    <span>30 Days Ago</span>
                    <span>15 Days Ago</span>
                    <span className="text-sky-400 font-bold">Release Drop Activation</span>
                    <span>Today (Live)</span>
                  </div>
                </div>
              </div>

              {/* BRAND ASSETS & PRESS PIPELINE */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* BRAND ASSETS */}
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
                  <span className="text-xs font-bold font-mono uppercase tracking-wider text-slate-300 block">
                    IMMUTABLE DIGITAL CONTENT LIBRARY
                  </span>

                  <div className="space-y-2.5 font-mono text-xs">
                    {initialDigitalAssets.map((asset) => (
                      <div key={asset.id} className="p-3 bg-slate-950 border border-slate-850 rounded flex justify-between items-center">
                        <div>
                          <span className="text-[8px] bg-slate-900 border border-slate-800 text-sky-400 font-bold px-1.5 py-0.5 rounded mr-2 uppercase">
                            {asset.category}
                          </span>
                          <span className="text-slate-200 font-bold">{asset.name}</span>
                          <span className="text-[10px] text-slate-500 block mt-0.5">
                            Hash: {asset.hash} &bull; Size: {asset.fileSize}
                          </span>
                        </div>
                        <span className="bg-emerald-500/10 text-emerald-400 font-bold text-[8px] px-1.5 py-0.5 rounded border border-emerald-500/20 uppercase shrink-0">
                          Approved
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* PRESS & PUBLICITY DATABASE */}
                <div className="bg-slate-900 border border-slate-800 rounded-lg p-5 space-y-4">
                  <span className="text-xs font-bold font-mono uppercase tracking-wider text-slate-300 block">
                    PRESS RELATIONSHIPS &amp; PUBLICITY PIPELINE
                  </span>

                  <div className="space-y-2.5 font-mono text-xs">
                    {pressContacts.map((contact) => (
                      <div key={contact.id} className="p-3 bg-slate-950 border border-slate-850 rounded flex justify-between items-center">
                        <div>
                          <span className="text-[8px] bg-slate-900 border border-slate-800 text-amber-400 font-bold px-1.5 py-0.5 rounded mr-2 uppercase">
                            {contact.influenceLevel}
                          </span>
                          <span className="text-slate-200 font-bold">{contact.name} ({contact.publication})</span>
                          <span className="text-[10px] text-slate-500 block mt-0.5">
                            Last pitch: {contact.pitchHistory[0].pitch} ({contact.pitchHistory[0].date})
                          </span>
                        </div>
                        <span className="bg-sky-500/10 text-sky-400 font-bold text-[8px] px-1.5 py-0.5 rounded border border-sky-500/20 uppercase shrink-0">
                          {contact.pitchHistory[0].status}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 8: TOURING LOGISTICS & MERCHANDISE */}
          {activeTab === 'touring' && (
            <div className="space-y-6">
              
              {/* TOURING ROUTING SCHEDULE */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-6">
                <div>
                  <h2 className="text-lg font-bold font-mono tracking-tight text-slate-100 uppercase">
                    TOURING ROUTING LOGISTICS &amp; GUARANTEES
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Calculate mileage, travel costs, hotel budgets, crew requirements, and settlement splits directly on the ledger.
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left font-mono text-xs">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase">
                        <th className="pb-2.5">Date</th>
                        <th className="pb-2.5">Venue &amp; City</th>
                        <th className="pb-2.5">Capacity</th>
                        <th className="pb-2.5">Tickets Sold</th>
                        <th className="pb-2.5">Promoter Split</th>
                        <th className="pb-2.5">Gross Revenue</th>
                        <th className="pb-2.5">Show Expenses</th>
                        <th className="pb-2.5">Artist Settlement</th>
                        <th className="pb-2.5">Logistics</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850/60 text-slate-300">
                      {initialTours[0].legs.flatMap(leg => leg.dates).map((show) => (
                        <tr key={show.id} className="hover:bg-slate-950/40">
                          <td className="py-3 font-bold text-slate-200">{show.date}</td>
                          <td className="py-3">
                            <div className="font-bold">{show.venueId}</div>
                            <div className="text-[10px] text-slate-500">{show.city}, {show.country}</div>
                          </td>
                          <td className="py-3 text-slate-400">{show.capacity.toLocaleString()}</td>
                          <td className="py-3 font-bold text-slate-200">
                            {show.ticketsSold.toLocaleString()}
                            <span className="text-[9px] text-emerald-400 ml-1.5 font-bold">
                              ({Math.round((show.ticketsSold / show.capacity) * 100)}%)
                            </span>
                          </td>
                          <td className="py-3 text-slate-400">{show.splitPercentage}% artist</td>
                          <td className="py-3 font-bold text-slate-200">${show.grossRevenue.toLocaleString()}</td>
                          <td className="py-3 text-red-400">-${show.expenses.toLocaleString()}</td>
                          <td className="py-3 font-bold text-emerald-400">${show.netSettlement.toLocaleString()}</td>
                          <td className="py-3 text-slate-500 font-mono text-[10px]">
                            <span className="capitalize">{show.travelDetails.method}</span> (${show.travelDetails.cost.toLocaleString()})
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* MERCHANDISE WAREHOUSE INVENTORY */}
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-6">
                <div>
                  <h2 className="text-lg font-bold font-mono tracking-tight text-slate-100 uppercase">
                    ECOMMERCE &amp; TOUR MERCHANDISE INVENTORY SYSTEM
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Stateful inventory variants tracking, negative stock checks, and retail margin calculations.
                  </p>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left font-mono text-xs">
                    <thead>
                      <tr className="border-b border-slate-800 text-slate-400 text-[10px] uppercase">
                        <th className="pb-2.5">SKU ID</th>
                        <th className="pb-2.5">Product Name</th>
                        <th className="pb-2.5">Warehouse Location</th>
                        <th className="pb-2.5">Unit Cost</th>
                        <th className="pb-2.5">Unit Retail</th>
                        <th className="pb-2.5">Total Sales</th>
                        <th className="pb-2.5">Stock Level</th>
                        <th className="pb-2.5">Margin</th>
                        <th className="pb-2.5">Inventory Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-850/60 text-slate-300">
                      {merchProducts.map((prod) => {
                        const isUnderStock = prod.stockLevel < prod.reorderPoint;
                        const isNegative = prod.stockLevel < 0;
                        const marginPercent = Math.round(((prod.sellingPrice - prod.costPrice) / prod.sellingPrice) * 100);

                        return (
                          <tr key={prod.id} className="hover:bg-slate-950/40">
                            <td className="py-3 text-slate-400 text-[10px]">{prod.sku}</td>
                            <td className="py-3 font-bold text-slate-200">{prod.name}</td>
                            <td className="py-3 text-slate-500">{prod.warehouseLocation}</td>
                            <td className="py-3 text-slate-400">${prod.costPrice.toFixed(2)}</td>
                            <td className="py-3 font-bold text-sky-400">${prod.sellingPrice.toFixed(2)}</td>
                            <td className="py-3 text-slate-400">{prod.totalSales} units</td>
                            <td className={`py-3 font-bold ${isNegative ? 'text-red-400' : isUnderStock ? 'text-amber-500' : 'text-slate-200'}`}>
                              {prod.stockLevel} units
                            </td>
                            <td className="py-3 text-emerald-400 font-bold">{marginPercent}%</td>
                            <td className="py-3 font-bold text-[8px] tracking-wider uppercase">
                              {isNegative ? (
                                <span className="bg-red-500/10 text-red-400 border border-red-500/20 px-2 py-0.5 rounded">NEGATIVE BACKORDER ALERT</span>
                              ) : isUnderStock ? (
                                <span className="bg-amber-500/10 text-amber-400 border border-amber-500/20 px-2 py-0.5 rounded">REORDER IMMEDIATELY</span>
                              ) : (
                                <span className="bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded">STOCK HEALTHY</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 9: CATALOGUE VALUATION SCENARIOS MODELLER */}
          {activeTab === 'valuations' && (
            <div className="space-y-6">
              <div className="bg-slate-900 border border-slate-800 rounded-lg p-6 space-y-6">
                <div>
                  <h2 className="text-lg font-bold font-mono tracking-tight text-slate-100 uppercase">
                    CATALOGUE FINANCIAL VALUATION ENGINE
                  </h2>
                  <p className="text-xs text-slate-400 mt-1">
                    Calculate catalogue value based on historical receipts, multiple benchmarks, and discounted cash flow (DCF).
                  </p>
                </div>

                {/* Option scenarios selection */}
                <div className="bg-slate-950 rounded-lg border border-slate-850 p-5 font-mono">
                  <span className="text-[9px] text-sky-400 uppercase tracking-widest block font-bold mb-3.5">
                    SELECT BUSINESS SCENARIO MODEL
                  </span>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {[
                      { id: 'sale', label: 'CATALOGUE SALE', desc: '14.5x Multiple blend' },
                      { id: 'major_deal', label: 'MAJOR RECORD DEAL', desc: '12.5x Multiple blend' },
                      { id: 'licensing', label: 'LICENSING CO-OP', desc: '12.0x Multiple blend' },
                      { id: 'independent', label: 'INDEPENDENT HOLD', desc: '10.0x Multiple blend' }
                    ].map((scen) => (
                      <button
                        key={scen.id}
                        onClick={() => setScenarioOption(scen.id as any)}
                        className={`p-3 text-left border rounded transition-all flex flex-col justify-between ${
                          scenarioOption === scen.id
                            ? 'bg-sky-500 text-slate-950 border-sky-400 font-bold'
                            : 'bg-slate-900 border-slate-800 hover:border-slate-700 text-slate-300'
                        }`}
                      >
                        <span className="text-xs font-bold font-mono block truncate">{scen.label}</span>
                        <span className={`text-[9px] block mt-1 ${scenarioOption === scen.id ? 'text-slate-800' : 'text-slate-500'}`}>{scen.desc}</span>
                      </button>
                    ))}
                  </div>

                  {/* SLIDERS MATRIX */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-6 mt-6 border-t border-slate-900">
                    <div className="space-y-2">
                      <div className="flex justify-between text-xs text-slate-400">
                        <span>Discount Rate (Cost of Capital)</span>
                        <span className="text-sky-400 font-bold">{discountRate}%</span>
                      </div>
                      <input
                        type="range"
                        min="5.0"
                        max="15.0"
                        step="0.5"
                        value={discountRate}
                        onChange={(e) => setDiscountRate(parseFloat(e.target.value))}
                        className="w-full accent-sky-400 h-1 rounded"
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-xs text-slate-400">
                        <span>DSP Projected Growth Trend</span>
                        <span className="text-emerald-400 font-bold">+{growthRate}%</span>
                      </div>
                      <input
                        type="range"
                        min="5.0"
                        max="30.0"
                        step="0.5"
                        value={growthRate}
                        onChange={(e) => setGrowthRate(parseFloat(e.target.value))}
                        className="w-full accent-emerald-400 h-1 rounded"
                      />
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-xs text-slate-400">
                        <span>Natural Catalogue Decay Rate</span>
                        <span className="text-red-400 font-bold">{decayRate}%</span>
                      </div>
                      <input
                        type="range"
                        min="-15.0"
                        max="0.0"
                        step="0.5"
                        value={decayRate}
                        onChange={(e) => setDecayRate(parseFloat(e.target.value))}
                        className="w-full accent-red-400 h-1 rounded"
                      />
                    </div>
                  </div>
                </div>

                {/* SCENARIOS RESULTS GRAPHIC GRID */}
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs text-center">
                  <div className="bg-slate-950 p-4 rounded-lg border border-slate-850">
                    <span className="text-[8px] text-slate-500 uppercase block tracking-widest">LOW ASSUMPTION CASE</span>
                    <span className="text-xl font-bold text-red-400 block mt-1.5">
                      ${(currentValuation.low / 1000000).toFixed(2)}M
                    </span>
                    <span className="text-[9px] text-slate-500 block mt-1 font-bold">Projected 75% Weighted Blended Value</span>
                  </div>

                  <div className="bg-slate-950 p-4 rounded-lg border border-sky-500/20 bg-sky-950/10">
                    <span className="text-[8px] text-sky-400 uppercase block tracking-widest font-bold">BASE SCENARIO CASE</span>
                    <span className="text-2xl font-bold text-sky-400 block mt-1">
                      ${(currentValuation.base / 1000000).toFixed(2)}M
                    </span>
                    <span className="text-[9px] text-slate-400 block mt-1 font-bold">Estimated Portfolio Value</span>
                  </div>

                  <div className="bg-slate-950 p-4 rounded-lg border border-slate-850">
                    <span className="text-[8px] text-slate-500 uppercase block tracking-widest">OPTIMISTIC HIGH CASE</span>
                    <span className="text-xl font-bold text-emerald-400 block mt-1.5">
                      ${(currentValuation.high / 1000000).toFixed(2)}M
                    </span>
                    <span className="text-[9px] text-slate-500 block mt-1 font-bold">Projected 135% Weighted Blended Value</span>
                  </div>
                </div>

                <div className="bg-slate-950 border border-slate-850 p-3 rounded text-[10px] text-slate-500 font-mono">
                  &bull; **DCF Model Perpetuity Growth Baseline**: 2.0% &bull; **Formula Basis**: Weighted Average Capitalization Rate of 7.5% blended with {scenarioOption.toUpperCase()} dynamic multiples based on $480K average trailing-12-months catalogue revenues.
                </div>
              </div>
            </div>
          )}

          {/* TAB 10: AI ASSISTANT PANEL */}
          {activeTab === 'ai' && (
            <div className="space-y-6">
              <AiAssistant />
            </div>
          )}

          {/* TAB 11: SIMULATOR & QUALITY CENTRE */}
          {activeTab === 'quality' && (
            <div className="space-y-6">
              <QualityRemediation
                onSimulate={handleSimulate}
                anomalies={anomalies}
                onRemediate={handleRemediate}
                simulationLog={simulationLog}
              />
            </div>
          )}

        </main>
      </div>

      {/* 4. SYSTEMIC IMMUTABLE FOOTER */}
      <footer id="system-footer" className="bg-slate-900 border-t border-slate-800 px-6 py-3 flex flex-col md:flex-row justify-between items-center text-[10px] text-slate-500 font-mono">
        <span>&copy; 2026 THE UPPER TIER LLC &bull; Licensed to APEX MUSIC GROUP</span>
        <div className="flex gap-4">
          <span>Tenant Separation: Isolated Node</span>
          <span>Security Level: Read-Write Admin Mode</span>
        </div>
      </footer>
    </div>
  );
}
