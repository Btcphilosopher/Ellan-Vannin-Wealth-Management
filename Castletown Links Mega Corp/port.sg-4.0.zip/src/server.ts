import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import { GoogleGenAI } from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());
const angularApp = new AngularNodeAppEngine();

// Lazy Gemini API client initializer
function getGenAIClient(): GoogleGenAI | null {
  const key = process.env['GEMINI_API_KEY'];
  if (!key) return null;
  return new GoogleGenAI({
    apiKey: key,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

/**
 * PORT.SG 4.0 Express API Endpoints
 */

// Terminal Natural Language Intelligence API
app.post('/api/port/terminal-command', async (req, res) => {
  const { command, portState } = req.body;
  if (!command) {
    return res.status(400).json({ error: 'Command string is required' });
  }

  const ai = getGenAIClient();
  if (!ai) {
    // Structured offline fallback response if API key is not present
    return res.json({
      intent: 'DIGITAL_TWIN_QUERY',
      explanation: `[OFFLINE INTELLIGENCE MODE] Analyzed query: "${command}". Database query executed against live state snapshot.`,
      causeChain: [
        'Vessel arrival offset +22 minutes due to harbor pilot scheduling slot.',
        'Quay Crane Q17 fault placed 18% additional discharge load on Q18.',
        'Yard Block T17 density reached 94.6%, triggering AGV rerouting via Intersection J12.',
      ],
      recommendation: 'Reallocate 2 AGVs from Block T05 to T17; dispatch maintenance crew to Q17.',
      confidence: 0.92,
      rawOutput: `Analyzed port telemetry for command "${command}". Found 1 critical alarm (Q17) and 1 yard bottleneck (T17).`,
    });
  }

  try {
    const prompt = `
You are the central AI Operations Architect for PORT.SG 4.0, an automated container port digital twin.
An operator has typed the following natural language command:
"${command}"

Current Live Port Summary Context:
- Active Vessels: 10 (e.g. MSC Meridian, Evergreen SG, Maersk Tuas)
- Berths: 8 (B01-B08)
- Quay Cranes: 32 (Q01-Q32, Note: Q17 in FAULT state)
- AGV Fleet: 50 Autonomous Guided Vehicles (8 fast charging)
- Yard Density: 68.4% (T17 congested at 94.6%)
- Bottleneck: Primary: Yard Block T17 (31%), Secondary: AGV Intersection J12 (18%), Tertiary: Quay Crane Q17 (11%)
- Weather: ${portState?.weather?.scenario || 'NORMAL'}, Wind ${portState?.weather?.windSpeedKnots || 12} knots

Instruction:
Respond in clear, professional industrial engineering language. Provide:
1. INTENT SUMMARY
2. CAUSE CHAIN (step-by-step root cause analysis if query is about delay or congestion)
3. OPTIMAL OPERATIONAL ACTION / PROPOSAL
4. CONFIDENCE SCORE (0.00 to 1.00)

Return JSON matching this exact structure:
{
  "intent": "SHORT_INTENT_NAME",
  "explanation": "High level summary for the operator",
  "causeChain": ["Step 1...", "Step 2...", "Step 3..."],
  "recommendation": "Concrete operational recommendation",
  "confidence": 0.95
}
`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({
      intent: parsed.intent || 'PORT_ANALYSIS',
      explanation: parsed.explanation || response.text,
      causeChain: parsed.causeChain || ['Analyzed digital twin state.'],
      recommendation: parsed.recommendation || 'Maintain current automated control boundaries.',
      confidence: parsed.confidence || 0.90,
      rawOutput: response.text,
    });
  } catch (err: unknown) {
    console.error('Gemini Terminal API error:', err);
    const msg = err instanceof Error ? err.message : 'Error processing AI command';
    return res.status(500).json({ error: msg });
  }
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
