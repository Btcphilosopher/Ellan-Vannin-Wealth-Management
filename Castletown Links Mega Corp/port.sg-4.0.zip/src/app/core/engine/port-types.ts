export type PortSimMode = 'LIVE' | 'SIMULATED' | 'REPLAY' | 'SCENARIO';
export type ClockMode = 'REAL_TIME' | 'ACCELERATED' | 'PAUSED' | 'STEP' | 'REPLAY';

export type VesselStatus =
  | 'APPROACHING'
  | 'ANCHORING'
  | 'PILOTING'
  | 'BERTHING'
  | 'WORKING'
  | 'DEPARTING'
  | 'SAILING';

export type CraneStatus =
  | 'IDLE'
  | 'POSITIONING'
  | 'LIFTING'
  | 'TRAVELLING'
  | 'LOWERING'
  | 'DISCHARGING'
  | 'LOADING'
  | 'FAULT'
  | 'MAINTENANCE';

export type AGVState =
  | 'IDLE'
  | 'EN_ROUTE_TO_PICKUP'
  | 'LOADED_TRAVEL'
  | 'UNLOADING'
  | 'EN_ROUTE_TO_CHARGER'
  | 'CHARGING'
  | 'FAULT';

export type HazardClass = 'NONE' | 'CLASS_3_FLAMMABLE' | 'CLASS_8_CORROSIVE' | 'CLASS_9_MISC';

export type WeatherScenario =
  | 'NORMAL'
  | 'HEAVY_RAIN'
  | 'HIGH_WIND'
  | 'LOW_VISIBILITY'
  | 'STORM'
  | 'EXTREME_HEAT';

export interface Position2D {
  x: number; // meters from port origin
  y: number;
}

export interface Container {
  id: string; // e.g. MSCU7283912
  isoCode: string; // e.g. 45G1
  sizeFeet: 20 | 40 | 45;
  weightTons: number;
  originPort: string;
  destPort: string;
  vesselId: string;
  hazardClass: HazardClass;
  reefer: boolean;
  reeferTempC?: number;
  customsCleared: boolean;
  priority: 'ROUTINE' | 'HIGH' | 'EXPRESS';
  locationType: 'VESSEL' | 'QUAY' | 'AGV' | 'YARD' | 'TRUCK' | 'RAIL';
  currentLocationId: string; // e.g. T18-S06-T4
  targetLocationId: string;
  nextMoveTime?: number;
}

export interface Vessel {
  id: string; // e.g. VESSEL-001
  name: string; // e.g. MSC Meridian
  imo: number;
  mmsi: number;
  lengthMeters: number;
  beamMeters: number;
  draftMeters: number;
  teuCapacity: number;
  eta: number; // epoch ms or sim timestamp
  etd: number;
  actualArrival?: number;
  actualDeparture?: number;
  status: VesselStatus;
  berthId?: string;
  totalMoves: number;
  completedMoves: number;
  fuelTons: number;
  emissionsKgCO2: number;
  pos: Position2D;
  speedKnots: number;
  headingDeg: number;
}

export interface Berth {
  id: string; // B01-B08
  name: string;
  lengthMeters: number;
  maxDraftMeters: number;
  occupiedVesselId?: string;
  assignedCraneIds: string[];
  powerAvailableMW: number;
  shorePowerConnected: boolean;
  status: 'AVAILABLE' | 'OCCUPIED' | 'MAINTENANCE' | 'RESERVED';
}

export interface QuayCrane {
  id: string; // Q01-Q32
  berthId: string;
  xPositionMeters: number; // along quay
  status: CraneStatus;
  currentContainerId?: string;
  currentTaskType?: 'DISCHARGE' | 'LOAD';
  cycleTimeSec: number;
  movesPerHour: number;
  totalMovesShift: number;
  powerKw: number;
  energyKwhPerMove: number;
  trolleyPosMeters: number; // 0 (quay) to 50 (vessel)
  hoistHeightMeters: number; // 0 to 35m
  healthScore: number; // 0 - 100%
  vibrationMmPerSec: number;
  temperatureC: number;
  nextMaintenanceHours: number;
}

export interface AGV {
  id: string; // AGV-001 to AGV-050
  name: string;
  pos: Position2D;
  headingDeg: number;
  speedMps: number;
  maxSpeedMps: number;
  batteryPct: number;
  chargingState: 'NOT_CHARGING' | 'QUEUED' | 'CHARGING';
  currentTaskId?: string;
  payloadContainerId?: string;
  state: AGVState;
  healthScore: number;
  motorTempC: number;
  totalDistanceKm: number;
  routeNodes: Position2D[];
  currentRouteIndex: number;
}

export interface YardStack {
  stackId: string; // e.g. S01
  laneId: string;
  maxTier: number;
  containers: Container[];
}

export interface YardBlock {
  id: string; // T01 - T20
  name: string;
  pos: Position2D;
  widthMeters: number;
  lengthMeters: number;
  lanesCount: number;
  stacksPerLane: number;
  maxTierHeight: number;
  assignedCraneIds: string[]; // YC-01 etc
  occupiedTeu: number;
  capacityTeu: number;
  densityPct: number;
  congestionIndex: number; // 0.0 to 1.0
  rehandleRiskScore: number;
  status: 'OPERATIONAL' | 'CONGESTED' | 'MAINTENANCE' | 'CLOSED';
}

export interface GateLane {
  id: string; // G01-G12
  name: string;
  mode: 'INBOUND' | 'OUTBOUND' | 'REVERSIBLE';
  queueLengthTrucks: number;
  ocrSuccessRatePct: number;
  avgTurnaroundMin: number;
  status: 'OPEN' | 'BUSY' | 'CLOSED';
}

export interface EnergyAsset {
  id: string;
  name: string;
  type: 'GRID' | 'SOLAR_PARK' | 'BESS_BATTERY' | 'AGV_CHARGER_HUB' | 'BUILDING_LOAD';
  capacityMw: number;
  currentPowerMw: number;
  socPct?: number; // State of charge for batteries
  efficiencyPct: number;
  status: 'ONLINE' | 'PEAK_SHAVING' | 'CHARGING' | 'OFFLINE';
}

export interface WeatherState {
  scenario: WeatherScenario;
  windSpeedKnots: number;
  windDirectionDeg: number;
  rainMmPerHour: number;
  visibilityKm: number;
  tideLevelMeters: number;
  currentKnots: number;
  temperatureC: number;
  craneSpeedLimitPct: number;
}

export interface MaintenanceAsset {
  assetId: string;
  assetName: string;
  category: 'QUAY_CRANE' | 'YARD_CRANE' | 'AGV' | 'TRANSFORMER' | 'BESS';
  healthScore: number;
  failureProbabilityPct: number;
  rulHours: number; // Remaining Useful Life
  vibrationMmSec: number;
  temperatureC: number;
  motorCurrentAmp: number;
  status: 'HEALTHY' | 'MONITORING' | 'MAINTENANCE_REQUIRED' | 'CRITICAL_ALERT';
  activeWorkOrdersCount: number;
}

export interface DigitalBunkeringTransaction {
  id: string;
  vesselId: string;
  vesselName: string;
  bunkerBargeName: string;
  fuelType: 'VLSFO' | 'MGO' | 'BIO_LNG' | 'GREEN_METHANOL';
  quantityTons: number;
  massFlowRateTonsHr: number;
  status: 'SCHEDULED' | 'PUMPING' | 'VERIFYING_MASS_FLOW' | 'COMPLETED' | 'SIGNED';
  bdnHash: string;
  co2eIntensityKgPerTon: number;
  timestamp: number;
}

export interface SingleWindowClearance {
  vesselId: string;
  vesselName: string;
  immigrationCleared: boolean;
  customsCleared: boolean;
  healthQuarantineCleared: boolean;
  maritimeSecurityCleared: boolean;
  pilotAssigned: boolean;
  tugAssigned: boolean;
  overallStatus: 'PENDING' | 'APPROVED' | 'HOLDS_EXIST';
}

export interface SimEvent {
  id: string;
  simTimeMs: number;
  realTimestampMs: number;
  eventType:
    | 'VESSEL_ARRIVED'
    | 'BERTH_ASSIGNED'
    | 'CRANE_LIFT'
    | 'AGV_DISPATCHED'
    | 'AGV_ARRIVED'
    | 'CONTAINER_STOWED'
    | 'EQUIPMENT_FAILURE'
    | 'MAINTENANCE_DISPATCHED'
    | 'CHARGING_STARTED'
    | 'WEATHER_CHANGED'
    | 'SCENARIO_INJECTED';
  entityId: string;
  description: string;
  previousState?: string;
  newState?: string;
  source: 'SIMULATOR' | 'OPTIMIZER' | 'OPERATOR' | 'TELEMETRY';
  confidenceScore: number;
}

export interface OptimisationRecommendation {
  id: string;
  type: 'STOWAGE' | 'BERTH_ALLOCATION' | 'AGV_DISPATCH' | 'CHARGING_SCHEDULE';
  targetEntityId: string;
  currentConfig: string;
  recommendedConfig: string;
  reasons: string[];
  predictedRehandleReduction: number;
  predictedTravelKmReduction: number;
  predictedEnergySavingsKwh: number;
  confidence: number;
  approvedByHuman: boolean;
}

export interface PortBottleneck {
  primaryId: string;
  primaryName: string;
  primaryContributionPct: number;
  secondaryId: string;
  secondaryName: string;
  secondaryContributionPct: number;
  tertiaryId: string;
  tertiaryName: string;
  tertiaryContributionPct: number;
  causeChain: string[];
}

export interface ScenarioRunResult {
  scenarioName: string;
  baselineThroughputTeuHr: number;
  counterfactualThroughputTeuHr: number;
  vesselDelayDeltaMin: number;
  yardCongestionDeltaPct: number;
  agvUtilisationDeltaPct: number;
  energyCostDeltaUsd: number;
  emissionsDeltaKgCO2: number;
  estimatedRecoveryTimeMin: number;
}

export interface PortStateSnapshot {
  simTimeMs: number;
  clockMode: ClockMode;
  speedFactor: number;
  weather: WeatherState;
  vessels: Vessel[];
  berths: Berth[];
  quayCranes: QuayCrane[];
  agvs: AGV[];
  yardBlocks: YardBlock[];
  gates: GateLane[];
  energyAssets: EnergyAsset[];
  maintenanceAssets: MaintenanceAsset[];
  bunkeringTransactions: DigitalBunkeringTransaction[];
  clearances: SingleWindowClearance[];
  recentEvents: SimEvent[];
  recommendations: OptimisationRecommendation[];
  bottleneck: PortBottleneck;
  
  // Aggregate Metrics
  totalTeuHandledToday: number;
  currentMovesPerHour: number;
  vesselTurnaroundAvgHours: number;
  berthOccupancyPct: number;
  yardDensityPct: number;
  totalPowerMw: number;
  co2eKgPerTeu: number;
  activeAlarmsCount: number;
}
