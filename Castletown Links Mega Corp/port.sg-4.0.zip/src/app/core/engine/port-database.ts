import {
  AGV,
  Berth,
  Container,
  DigitalBunkeringTransaction,
  EnergyAsset,
  GateLane,
  MaintenanceAsset,
  PortBottleneck,
  PortStateSnapshot,
  QuayCrane,
  SingleWindowClearance,
  Vessel,
  WeatherState,
  YardBlock,
} from './port-types';

export class PortDatabase {
  private static instance: PortDatabase;

  public simTimeMs = Date.now();
  public clockSpeed = 60; // 1 real sec = 60 sim sec
  public clockMode: PortStateSnapshot['clockMode'] = 'ACCELERATED';

  public weather: WeatherState = {
    scenario: 'NORMAL',
    windSpeedKnots: 12,
    windDirectionDeg: 140,
    rainMmPerHour: 0,
    visibilityKm: 15,
    tideLevelMeters: 2.4,
    currentKnots: 0.8,
    temperatureC: 29.5,
    craneSpeedLimitPct: 100,
  };

  public vessels: Vessel[] = [];
  public berths: Berth[] = [];
  public quayCranes: QuayCrane[] = [];
  public agvs: AGV[] = [];
  public yardBlocks: YardBlock[] = [];
  public gates: GateLane[] = [];
  public energyAssets: EnergyAsset[] = [];
  public maintenanceAssets: MaintenanceAsset[] = [];
  public bunkeringTransactions: DigitalBunkeringTransaction[] = [];
  public clearances: SingleWindowClearance[] = [];
  public containers: Container[] = [];
  public historicalSnapshots: { time: number; state: PortStateSnapshot }[] = [];

  private constructor() {
    this.seedDatabase();
  }

  public static getInstance(): PortDatabase {
    if (!PortDatabase.instance) {
      PortDatabase.instance = new PortDatabase();
    }
    return PortDatabase.instance;
  }

  public seedDatabase(): void {
    const now = Date.now();
    this.simTimeMs = now;

    // 1. Seed Berths (B01 - B08)
    const berthNames = [
      'B01 (Tuas North 1)',
      'B02 (Tuas North 2)',
      'B03 (Tuas North 3)',
      'B04 (Tuas Central 1)',
      'B05 (Tuas Central 2)',
      'B06 (Tuas South 1)',
      'B07 (Tuas South 2)',
      'B08 (Deepwater Ultra)',
    ];

    this.berths = berthNames.map((name, i) => {
      const id = `B0${i + 1}`;
      return {
        id,
        name,
        lengthMeters: 420,
        maxDraftMeters: i === 7 ? 21.5 : 18.0,
        occupiedVesselId: undefined,
        assignedCraneIds: [`Q${i * 4 + 1}`, `Q${i * 4 + 2}`, `Q${i * 4 + 3}`, `Q${i * 4 + 4}`],
        powerAvailableMW: 15,
        shorePowerConnected: true,
        status: 'AVAILABLE',
      };
    });

    // 2. Seed Vessels (10 Ultra Large & New Panamax Vessels)
    const vesselList = [
      { name: 'MSC Meridian', imo: 9839201, teu: 24116, length: 400, draft: 16.5, status: 'WORKING' as const, berthId: 'B01' },
      { name: 'Evergreen Singapore', imo: 9811002, teu: 20388, length: 400, draft: 15.8, status: 'WORKING' as const, berthId: 'B02' },
      { name: 'Maersk Tuas Lion', imo: 9784321, teu: 19241, length: 399, draft: 15.2, status: 'WORKING' as const, berthId: 'B04' },
      { name: 'CMA CGM Pasir', imo: 9890112, teu: 23000, length: 400, draft: 16.0, status: 'BERTHING' as const, berthId: 'B05' },
      { name: 'COSCO Shipping Straits', imo: 9754320, teu: 21237, length: 400, draft: 15.5, status: 'PILOTING' as const },
      { name: 'ONE Express 01', imo: 9822190, teu: 14000, length: 366, draft: 14.2, status: 'APPROACHING' as const },
      { name: 'HMM Singapore Star', imo: 9863300, teu: 23964, length: 400, draft: 16.2, status: 'ANCHORING' as const },
      { name: 'PIL Horizon', imo: 9711099, teu: 11800, length: 330, draft: 13.5, status: 'WORKING' as const, berthId: 'B07' },
      { name: 'Yang Ming Raffles', imo: 9700881, teu: 14080, length: 368, draft: 14.0, status: 'APPROACHING' as const },
      { name: 'Hapag-Lloyd Express', imo: 9844010, teu: 23600, length: 400, draft: 16.1, status: 'DEPARTING' as const, berthId: 'B03' },
    ];

    this.vessels = vesselList.map((v, i) => {
      const id = `VESSEL-${String(i + 1).padStart(3, '0')}`;
      if (v.berthId) {
        const berth = this.berths.find((b) => b.id === v.berthId);
        if (berth) {
          berth.occupiedVesselId = id;
          berth.status = 'OCCUPIED';
        }
      }
      return {
        id,
        name: v.name,
        imo: v.imo,
        mmsi: 563000000 + i * 1421,
        lengthMeters: v.length,
        beamMeters: 61.5,
        draftMeters: v.draft,
        teuCapacity: v.teu,
        eta: now - 3600000 * (i * 2 - 4),
        etd: now + 3600000 * (12 + i * 4),
        status: v.status,
        berthId: v.berthId,
        totalMoves: 2200 + i * 350,
        completedMoves: v.status === 'WORKING' ? 1420 + i * 180 : 0,
        fuelTons: 1850 - i * 90,
        emissionsKgCO2: 42000 + i * 850,
        pos: {
          x: v.berthId ? 80 + (parseInt(v.berthId.slice(1)) - 1) * 350 : 120 + i * 280,
          y: v.berthId ? 60 : 350 + i * 120,
        },
        speedKnots: v.status === 'WORKING' ? 0 : v.status === 'APPROACHING' ? 12.4 : 3.5,
        headingDeg: v.berthId ? 90 : 270,
      };
    });

    // 3. Seed Quay Cranes (32 Automated Double Trolley Cranes Q01-Q32)
    for (let i = 1; i <= 32; i++) {
      const qId = `Q${String(i).padStart(2, '0')}`;
      const berthIdx = Math.floor((i - 1) / 4);
      const berthId = `B0${berthIdx + 1}`;
      const isFault = i === 17; // Q17 fault scenario testing
      
      this.quayCranes.push({
        id: qId,
        berthId,
        xPositionMeters: (i - 1) * 85 + 40,
        status: isFault ? 'FAULT' : i % 5 === 0 ? 'IDLE' : 'LIFTING',
        currentContainerId: `MSCU${7280000 + i}`,
        currentTaskType: i % 2 === 0 ? 'DISCHARGE' : 'LOAD',
        cycleTimeSec: 68 + (i % 7) * 2,
        movesPerHour: isFault ? 0 : 38 + (i % 5),
        totalMovesShift: 310 + (i % 12) * 25,
        powerKw: isFault ? 15 : 420 + (i % 8) * 30,
        energyKwhPerMove: 4.8,
        trolleyPosMeters: 15 + (i * 7) % 30,
        hoistHeightMeters: 10 + (i * 3) % 20,
        healthScore: isFault ? 42 : 94 + (i % 6),
        vibrationMmPerSec: isFault ? 8.4 : 1.2 + (i % 3) * 0.3,
        temperatureC: isFault ? 78.5 : 42.0 + (i % 4),
        nextMaintenanceHours: isFault ? 0 : 140 + i * 15,
      });
    }

    // 4. Seed AGVs (50 Electric Autonomous Vehicles AGV-001 to AGV-050)
    for (let i = 1; i <= 50; i++) {
      const agvId = `AGV-${String(i).padStart(3, '0')}`;
      const isCharging = i > 42;
      const isFault = i === 20;

      this.agvs.push({
        id: agvId,
        name: `Automated Vehicle ${i}`,
        pos: {
          x: 100 + (i % 10) * 120,
          y: isCharging ? 480 : 150 + Math.floor(i / 10) * 60,
        },
        headingDeg: (i * 90) % 360,
        speedMps: isCharging || isFault ? 0 : 4.5 + (i % 3) * 0.5,
        maxSpeedMps: 7.0,
        batteryPct: isCharging ? 35 + (i * 12) % 60 : 65 + (i * 7) % 34,
        chargingState: isCharging ? 'CHARGING' : 'NOT_CHARGING',
        currentTaskId: isCharging ? undefined : `TASK-${88000 + i}`,
        payloadContainerId: i % 3 === 0 ? `CMAU${9000000 + i}` : undefined,
        state: isFault
          ? 'FAULT'
          : isCharging
          ? 'CHARGING'
          : i % 3 === 0
          ? 'LOADED_TRAVEL'
          : 'EN_ROUTE_TO_PICKUP',
        healthScore: isFault ? 51 : 96 + (i % 4),
        motorTempC: isFault ? 82 : 38 + (i % 6),
        totalDistanceKm: 1240 + i * 85,
        routeNodes: [
          { x: 100 + (i % 10) * 120, y: 150 },
          { x: 300, y: 220 },
          { x: 500, y: 300 },
        ],
        currentRouteIndex: 1,
      });
    }

    // 5. Seed Yard Blocks (T01 - T20)
    for (let i = 1; i <= 20; i++) {
      const blockId = `T${String(i).padStart(2, '0')}`;
      const isCongested = i === 17 || i === 18;

      this.yardBlocks.push({
        id: blockId,
        name: `Tuas Yard Block ${blockId}`,
        pos: {
          x: 120 + ((i - 1) % 5) * 260,
          y: 220 + Math.floor((i - 1) / 5) * 110,
        },
        widthMeters: 60,
        lengthMeters: 220,
        lanesCount: 6,
        stacksPerLane: 10,
        maxTierHeight: 5,
        assignedCraneIds: [`YC-${String(i * 2 - 1).padStart(2, '0')}`, `YC-${String(i * 2).padStart(2, '0')}`],
        occupiedTeu: isCongested ? 1420 : 850 + (i * 27) % 400,
        capacityTeu: 1500,
        densityPct: isCongested ? 94.6 : 62.0 + (i * 3) % 25,
        congestionIndex: isCongested ? 0.88 : 0.25 + (i % 4) * 0.1,
        rehandleRiskScore: isCongested ? 0.42 : 0.08,
        status: isCongested ? 'CONGESTED' : 'OPERATIONAL',
      });
    }

    // 6. Seed Gate Lanes (G01 - G12)
    for (let i = 1; i <= 12; i++) {
      this.gates.push({
        id: `G${String(i).padStart(2, '0')}`,
        name: `Automated Gate Lane ${i}`,
        mode: i <= 8 ? 'INBOUND' : 'OUTBOUND',
        queueLengthTrucks: 2 + (i % 5),
        ocrSuccessRatePct: 99.4 - (i % 3) * 0.2,
        avgTurnaroundMin: 4.2 + (i % 4) * 0.5,
        status: 'OPEN',
      });
    }

    // 7. Seed Energy Assets
    this.energyAssets = [
      { id: 'GRID-01', name: 'Singapore Power Grid Substation 66kV', type: 'GRID', capacityMw: 60.0, currentPowerMw: 24.5, efficiencyPct: 99.1, status: 'ONLINE' },
      { id: 'SOLAR-01', name: 'Tuas Rooftop & Floating Solar Array (25MWp)', type: 'SOLAR_PARK', capacityMw: 25.0, currentPowerMw: 18.2, efficiencyPct: 94.5, status: 'ONLINE' },
      { id: 'BESS-01', name: 'Tuas BESS Mega-Battery System (50MWh)', type: 'BESS_BATTERY', capacityMw: 20.0, currentPowerMw: -4.0, socPct: 82, efficiencyPct: 96.0, status: 'PEAK_SHAVING' },
      { id: 'CHARGER-HUB', name: 'Automated AGV Fast-Charging Hub (80 Ports)', type: 'AGV_CHARGER_HUB', capacityMw: 12.0, currentPowerMw: 6.8, efficiencyPct: 97.5, status: 'CHARGING' },
      { id: 'PORT-HQ', name: 'Control Centre & Cold Storage Load', type: 'BUILDING_LOAD', capacityMw: 8.0, currentPowerMw: 3.5, efficiencyPct: 98.0, status: 'ONLINE' },
    ];

    // 8. Seed Maintenance Assets
    this.maintenanceAssets = [
      { assetId: 'Q17', assetName: 'Quay Crane Q17', category: 'QUAY_CRANE', healthScore: 42, failureProbabilityPct: 84.5, rulHours: 12, vibrationMmSec: 8.4, temperatureC: 78.5, motorCurrentAmp: 340, status: 'CRITICAL_ALERT', activeWorkOrdersCount: 2 },
      { assetId: 'AGV-020', assetName: 'AGV Vehicle 020', category: 'AGV', healthScore: 51, failureProbabilityPct: 62.0, rulHours: 48, vibrationMmSec: 5.2, temperatureC: 82.0, motorCurrentAmp: 190, status: 'MAINTENANCE_REQUIRED', activeWorkOrdersCount: 1 },
      { assetId: 'YC-33', assetName: 'Yard Crane YC-33', category: 'YARD_CRANE', healthScore: 74, failureProbabilityPct: 22.0, rulHours: 320, vibrationMmSec: 3.1, temperatureC: 54.0, motorCurrentAmp: 210, status: 'MONITORING', activeWorkOrdersCount: 0 },
      { assetId: 'TR-04', assetName: 'Substation Transformer TR-04', category: 'TRANSFORMER', healthScore: 98, failureProbabilityPct: 1.2, rulHours: 8500, vibrationMmSec: 0.8, temperatureC: 41.0, motorCurrentAmp: 820, status: 'HEALTHY', activeWorkOrdersCount: 0 },
    ];

    // 9. Seed Digital Bunkering Transactions
    this.bunkeringTransactions = [
      { id: 'BDN-2026-901', vesselId: 'VESSEL-001', vesselName: 'MSC Meridian', bunkerBargeName: 'Equatorial Marine 08', fuelType: 'VLSFO', quantityTons: 1250, massFlowRateTonsHr: 450, status: 'PUMPING', bdnHash: '0x8f2a9c1e4d3b...', co2eIntensityKgPerTon: 3150, timestamp: now - 1800000 },
      { id: 'BDN-2026-902', vesselId: 'VESSEL-002', vesselName: 'Evergreen Singapore', bunkerBargeName: 'Sentek BioFuel 03', fuelType: 'BIO_LNG', quantityTons: 800, massFlowRateTonsHr: 320, status: 'SIGNED', bdnHash: '0x3a7e91f0c2d...', co2eIntensityKgPerTon: 1950, timestamp: now - 7200000 },
      { id: 'BDN-2026-903', vesselId: 'VESSEL-004', vesselName: 'CMA CGM Pasir', bunkerBargeName: 'Tuas Green Methanol 01', fuelType: 'GREEN_METHANOL', quantityTons: 1500, massFlowRateTonsHr: 500, status: 'VERIFYING_MASS_FLOW', bdnHash: '0x9d11e4b882a...', co2eIntensityKgPerTon: 850, timestamp: now - 900000 },
    ];

    // 10. Seed Clearances
    this.clearances = this.vessels.map((v) => ({
      vesselId: v.id,
      vesselName: v.name,
      immigrationCleared: true,
      customsCleared: true,
      healthQuarantineCleared: true,
      maritimeSecurityCleared: true,
      pilotAssigned: true,
      tugAssigned: true,
      overallStatus: 'APPROVED' as const,
    }));
  }

  public getSnapshot(): PortStateSnapshot {
    const totalMoves = this.vessels.reduce((acc, v) => acc + v.completedMoves, 0);
    const activeVessels = this.vessels.filter((v) => v.status === 'WORKING').length;

    const bottleneck: PortBottleneck = {
      primaryId: 'T17',
      primaryName: 'Yard Block T17',
      primaryContributionPct: 31,
      secondaryId: 'J12',
      secondaryName: 'AGV Intersection J12',
      secondaryContributionPct: 18,
      tertiaryId: 'Q17',
      tertiaryName: 'Quay Crane Q17 (In Fault)',
      tertiaryContributionPct: 11,
      causeChain: [
        'Yard Block T17 reached 94.6% density capacity.',
        'Quay Crane Q17 fault shifted 20% discharge load onto neighboring cranes.',
        'AGV travel time near Intersection J12 increased +11% due to detour rerouting.',
      ],
    };

    return {
      simTimeMs: this.simTimeMs,
      clockMode: this.clockMode,
      speedFactor: this.clockSpeed,
      weather: this.weather,
      vessels: [...this.vessels],
      berths: [...this.berths],
      quayCranes: [...this.quayCranes],
      agvs: [...this.agvs],
      yardBlocks: [...this.yardBlocks],
      gates: [...this.gates],
      energyAssets: [...this.energyAssets],
      maintenanceAssets: [...this.maintenanceAssets],
      bunkeringTransactions: [...this.bunkeringTransactions],
      clearances: [...this.clearances],
      recentEvents: [],
      recommendations: [
        {
          id: 'REC-101',
          type: 'STOWAGE',
          targetEntityId: 'MSCU7283912',
          currentConfig: 'Block T18 / Stack 06 / Tier 4',
          recommendedConfig: 'Block T21 / Stack 02 / Tier 2',
          reasons: [
            'Reduces predicted rehandles by 1',
            '240 m shorter AGV route',
            'Compatible with MSC Meridian loading sequence',
          ],
          predictedRehandleReduction: 1,
          predictedTravelKmReduction: 0.24,
          predictedEnergySavingsKwh: 1.8,
          confidence: 0.94,
          approvedByHuman: false,
        },
        {
          id: 'REC-102',
          type: 'BERTH_ALLOCATION',
          targetEntityId: 'VESSEL-005',
          currentConfig: 'Berth B06 (Estimated Start 16:30)',
          recommendedConfig: 'Berth B03 (Reallocated after departure of Hapag-Lloyd)',
          reasons: [
            'Avoids 45 min waiting time in anchorage',
            'Reduces crane idle time by 18%',
            'Minimizes AGV deadheading to Yard T10',
          ],
          predictedRehandleReduction: 0,
          predictedTravelKmReduction: 1.15,
          predictedEnergySavingsKwh: 8.5,
          confidence: 0.89,
          approvedByHuman: false,
        },
      ],
      bottleneck,

      totalTeuHandledToday: 14820 + totalMoves,
      currentMovesPerHour: 980,
      vesselTurnaroundAvgHours: 14.2,
      berthOccupancyPct: Math.round((activeVessels / this.berths.length) * 100),
      yardDensityPct: 68.4,
      totalPowerMw: 24.5,
      co2eKgPerTeu: 14.8,
      activeAlarmsCount: this.maintenanceAssets.filter((m) => m.status === 'CRITICAL_ALERT' || m.status === 'MAINTENANCE_REQUIRED').length,
    };
  }
}
