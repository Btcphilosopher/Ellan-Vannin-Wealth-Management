import { Injectable, signal } from '@angular/core';
import { PortDatabase } from './port-database';
import { PortStateSnapshot, SimEvent, WeatherScenario } from './port-types';

@Injectable({
  providedIn: 'root',
})
export class PortSimulatorService {
  private db = PortDatabase.getInstance();
  private timerId: ReturnType<typeof setInterval> | null = null;

  public state = signal<PortStateSnapshot>(this.db.getSnapshot());
  public events = signal<SimEvent[]>([]);

  constructor() {
    this.startSimulation();
  }

  public startSimulation(): void {
    if (this.timerId) clearInterval(this.timerId);
    this.timerId = setInterval(() => {
      this.tick();
    }, 1000); // 1 real second tick
  }

  public pauseSimulation(): void {
    this.db.clockMode = 'PAUSED';
    this.notifyState();
  }

  public resumeSimulation(): void {
    this.db.clockMode = 'ACCELERATED';
    this.notifyState();
  }

  public setSpeed(factor: number): void {
    this.db.clockSpeed = factor;
    this.notifyState();
  }

  public stepSimulation(): void {
    this.tick(true);
  }

  public setWeatherScenario(scenario: WeatherScenario): void {
    this.db.weather.scenario = scenario;
    if (scenario === 'HIGH_WIND' || scenario === 'STORM') {
      this.db.weather.windSpeedKnots = scenario === 'STORM' ? 45 : 34;
      this.db.weather.craneSpeedLimitPct = 50;
      this.addEvent({
        id: `EVT-${Date.now()}`,
        simTimeMs: this.db.simTimeMs,
        realTimestampMs: Date.now(),
        eventType: 'WEATHER_CHANGED',
        entityId: 'WEATHER',
        description: `Weather alert: ${scenario} active. Quay crane speeds throttled to 50%.`,
        source: 'SIMULATOR',
        confidenceScore: 1.0,
      });
    } else if (scenario === 'HEAVY_RAIN') {
      this.db.weather.rainMmPerHour = 45;
      this.db.weather.visibilityKm = 2.5;
    } else {
      this.db.weather.windSpeedKnots = 12;
      this.db.weather.rainMmPerHour = 0;
      this.db.weather.visibilityKm = 15;
      this.db.weather.craneSpeedLimitPct = 100;
    }
    this.notifyState();
  }

  public injectFailure(entityId: string): void {
    const qc = this.db.quayCranes.find((c) => c.id === entityId);
    if (qc) {
      qc.status = 'FAULT';
      qc.healthScore = 35;
      qc.vibrationMmPerSec = 9.2;
      qc.temperatureC = 84.0;
      this.addEvent({
        id: `EVT-${Date.now()}`,
        simTimeMs: this.db.simTimeMs,
        realTimestampMs: Date.now(),
        eventType: 'EQUIPMENT_FAILURE',
        entityId: qc.id,
        description: `CRITICAL ALARM: ${qc.id} experienced motor drive fault & elevated vibration!`,
        previousState: 'LIFTING',
        newState: 'FAULT',
        source: 'TELEMETRY',
        confidenceScore: 0.98,
      });
    }

    const agv = this.agvsList.find((a) => a.id === entityId);
    if (agv) {
      agv.state = 'FAULT';
      agv.speedMps = 0;
      agv.healthScore = 40;
      this.addEvent({
        id: `EVT-${Date.now()}`,
        simTimeMs: this.db.simTimeMs,
        realTimestampMs: Date.now(),
        eventType: 'EQUIPMENT_FAILURE',
        entityId: agv.id,
        description: `CRITICAL ALARM: ${agv.id} guidance sensor failure on fairway grid!`,
        source: 'TELEMETRY',
        confidenceScore: 0.96,
      });
    }

    this.notifyState();
  }

  private get agvsList() {
    return this.db.agvs;
  }

  private tick(forceStep = false): void {
    if (this.db.clockMode === 'PAUSED' && !forceStep) return;

    const dtSimSeconds = (1 * this.db.clockSpeed); // seconds passed in sim time
    this.db.simTimeMs += dtSimSeconds * 1000;

    // 1. Update Quay Cranes Physics
    const speedMultiplier = (this.db.weather.craneSpeedLimitPct / 100);
    for (const qc of this.db.quayCranes) {
      if (qc.status === 'FAULT' || qc.status === 'MAINTENANCE' || qc.status === 'IDLE') continue;

      // Animate trolley position
      qc.trolleyPosMeters = (qc.trolleyPosMeters + 3.5 * speedMultiplier) % 45;
      qc.hoistHeightMeters = Math.sin(qc.trolleyPosMeters * 0.1) * 15 + 15;

      // Increment completed moves occasionally
      if (Math.random() < 0.15 * speedMultiplier) {
        qc.totalMovesShift += 1;
        const vessel = this.db.vessels.find((v) => v.berthId === qc.berthId);
        if (vessel && vessel.completedMoves < vessel.totalMoves) {
          vessel.completedMoves += 1;
        }
      }
    }

    // 2. Update AGVs Movement & Battery Discharge
    for (const agv of this.db.agvs) {
      if (agv.state === 'FAULT') continue;

      if (agv.chargingState === 'CHARGING') {
        agv.batteryPct = Math.min(100, agv.batteryPct + 0.4 * (this.db.clockSpeed / 60));
        if (agv.batteryPct >= 95) {
          agv.chargingState = 'NOT_CHARGING';
          agv.state = 'IDLE';
        }
      } else {
        // Battery drain
        agv.batteryPct = Math.max(5, agv.batteryPct - 0.05 * (this.db.clockSpeed / 60));
        if (agv.batteryPct < 20 && agv.state !== 'EN_ROUTE_TO_CHARGER') {
          agv.state = 'EN_ROUTE_TO_CHARGER';
          agv.currentTaskId = 'CHARGE-ROUTINE';
        }

        // AGV motion along route
        if (agv.speedMps > 0) {
          const dx = Math.sin(agv.headingDeg * (Math.PI / 180)) * agv.speedMps * (dtSimSeconds / 60);
          const dy = Math.cos(agv.headingDeg * (Math.PI / 180)) * agv.speedMps * (dtSimSeconds / 60);
          agv.pos.x = (agv.pos.x + dx + 1200) % 1200;
          agv.pos.y = (agv.pos.y + dy + 800) % 800;

          if (Math.random() < 0.05) {
            agv.headingDeg = (agv.headingDeg + (Math.random() > 0.5 ? 90 : -90) + 360) % 360;
          }
        }
      }
    }

    // 3. Update Vessel Movements
    for (const v of this.db.vessels) {
      if (v.status === 'APPROACHING' || v.status === 'PILOTING') {
        v.pos.x = Math.max(80, v.pos.x - 2.0 * (dtSimSeconds / 60));
        if (v.pos.x <= 150 && v.status === 'APPROACHING') {
          v.status = 'BERTHING';
          v.berthId = 'B05';
          this.addEvent({
            id: `EVT-${Date.now()}`,
            simTimeMs: this.db.simTimeMs,
            realTimestampMs: Date.now(),
            eventType: 'BERTH_ASSIGNED',
            entityId: v.id,
            description: `Vessel ${v.name} safely berthed at B05. Cargo operations commencing.`,
            previousState: 'APPROACHING',
            newState: 'BERTHING',
            source: 'SIMULATOR',
            confidenceScore: 0.99,
          });
        }
      }
    }

    this.notifyState();
  }

  private addEvent(event: SimEvent): void {
    const current = this.events();
    this.events.set([event, ...current.slice(0, 49)]);
  }

  private notifyState(): void {
    const snapshot = this.db.getSnapshot();
    snapshot.recentEvents = this.events();
    this.state.set(snapshot);
  }
}
