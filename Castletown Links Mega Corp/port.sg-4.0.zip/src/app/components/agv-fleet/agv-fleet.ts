import { ChangeDetectionStrategy, Component, Input, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AGV } from '../../core/engine/port-types';
import { OptimisationEngineService } from '../../core/engine/optimisation-engine';

@Component({
  selector: 'app-agv-fleet',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 p-4 border border-slate-800 rounded-xl flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-emerald-400">directions_car</mat-icon>
            AGV FLEET COMMAND & PATH ROUTING
          </h2>
          <p class="text-xs text-slate-400">50 Electric Autonomous Vehicles multi-agent routing & fast charging schedule.</p>
        </div>

        <button
          (click)="optimizeSchedule()"
          class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-bold text-xs rounded-lg transition-all flex items-center gap-2 shadow-lg shadow-emerald-950"
        >
          <mat-icon class="!text-sm">battery_charging_full</mat-icon>
          OPTIMIZE AGV FAST-CHARGING QUEUE
        </button>
      </div>

      <!-- Charging Schedule Output Banner -->
      @if (chargingSchedule()) {
        <div class="p-4 bg-emerald-950/40 border border-emerald-800/80 rounded-xl text-xs font-mono space-y-2">
          <div class="text-emerald-300 font-bold flex items-center gap-2">
            <mat-icon class="!text-sm text-emerald-400">bolt</mat-icon>
            OPTIMIZED CHARGING QUEUE GENERATED (Peak Shaving: {{ chargingSchedule()?.peakShavingMw }} MW Saved)
          </div>
          <div class="flex flex-wrap gap-2 pt-1">
            @for (s of chargingSchedule()?.schedule; track s.agvId) {
              <span class="px-2.5 py-1 bg-slate-900 border border-emerald-800 rounded text-slate-300">
                <strong class="text-emerald-400">{{ s.agvId }}</strong> @ {{ s.slotTime }} ({{ s.chargerPort }})
              </span>
            }
          </div>
        </div>
      }

      <!-- Fleet Stats Overview -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-4 font-mono text-xs">
        <div class="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span class="text-slate-400">Active Vehicles</span>
          <div class="text-2xl font-bold text-emerald-400">{{ activeCount() }} / 50</div>
        </div>
        <div class="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span class="text-slate-400">Fast Charging</span>
          <div class="text-2xl font-bold text-cyan-400">{{ chargingCount() }}</div>
        </div>
        <div class="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span class="text-slate-400">Avg Fleet Battery</span>
          <div class="text-2xl font-bold text-white">{{ avgBattery().toFixed(1) }}%</div>
        </div>
        <div class="bg-slate-900 border border-slate-800 p-4 rounded-xl space-y-1">
          <span class="text-slate-400">Intersection Conflict Risk</span>
          <div class="text-2xl font-bold text-emerald-400">0.02 (Low)</div>
        </div>
      </div>

      <!-- AGV List Table -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
        <h3 class="font-mono font-bold text-sm text-white flex items-center gap-2">
          <mat-icon class="text-emerald-400">directions_car</mat-icon> AGV VEHICLE TELEMETRY & PAYLOAD STATE
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-left font-mono text-xs text-slate-300">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase">
              <tr>
                <th class="p-3">AGV ID</th>
                <th class="p-3">STATE</th>
                <th class="p-3">BATTERY %</th>
                <th class="p-3">SPEED</th>
                <th class="p-3">PAYLOAD CONTAINER</th>
                <th class="p-3">HEALTH</th>
                <th class="p-3">MOTOR TEMP</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (a of agvs; track a.id) {
                <tr class="hover:bg-slate-800/40 transition-colors">
                  <td class="p-3 font-bold text-white flex items-center gap-2">
                    <mat-icon class="!text-sm text-slate-400">smart_toy</mat-icon>
                    {{ a.id }}
                  </td>
                  <td class="p-3">
                    <span
                      class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-emerald-500/20]="a.state === 'LOADED_TRAVEL'"
                      [class.text-emerald-400]="a.state === 'LOADED_TRAVEL'"
                      [class.bg-cyan-500/20]="a.chargingState === 'CHARGING'"
                      [class.text-cyan-400]="a.chargingState === 'CHARGING'"
                      [class.bg-red-500/20]="a.state === 'FAULT'"
                      [class.text-red-400]="a.state === 'FAULT'"
                    >
                      {{ a.chargingState === 'CHARGING' ? 'CHARGING' : a.state }}
                    </span>
                  </td>
                  <td class="p-3 font-bold" [class.text-emerald-400]="a.batteryPct > 50" [class.text-amber-400]="a.batteryPct <= 30">
                    {{ a.batteryPct.toFixed(1) }}%
                  </td>
                  <td class="p-3 text-slate-400">{{ a.speedMps.toFixed(1) }} m/s</td>
                  <td class="p-3 text-cyan-400 font-bold">{{ a.payloadContainerId || 'NONE' }}</td>
                  <td class="p-3 text-white font-bold">{{ a.healthScore }}%</td>
                  <td class="p-3 text-slate-400">{{ a.motorTempC }}°C</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class AgvFleetComponent {
  @Input({ required: true }) agvs: AGV[] = [];

  private optimizer = inject(OptimisationEngineService);
  public chargingSchedule = signal<{ schedule: { agvId: string; slotTime: string; durationMin: number; chargerPort: string }[]; peakShavingMw: number } | null>(null);

  public activeCount(): number {
    return this.agvs.filter((a) => a.state === 'LOADED_TRAVEL' || a.state === 'EN_ROUTE_TO_PICKUP').length;
  }

  public chargingCount(): number {
    return this.agvs.filter((a) => a.chargingState === 'CHARGING').length;
  }

  public avgBattery(): number {
    if (this.agvs.length === 0) return 0;
    return this.agvs.reduce((acc, a) => acc + a.batteryPct, 0) / this.agvs.length;
  }

  public optimizeSchedule(): void {
    const res = this.optimizer.optimizeAgvCharging(this.agvs);
    this.chargingSchedule.set(res);
  }
}
