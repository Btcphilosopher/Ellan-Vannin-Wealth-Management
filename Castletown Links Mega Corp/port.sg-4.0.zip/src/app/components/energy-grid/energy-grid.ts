import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EnergyAsset } from '../../core/engine/port-types';

@Component({
  selector: 'app-energy-grid',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 p-4 border border-slate-800 rounded-xl flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-yellow-400">bolt</mat-icon>
            PORT MICROGRID & DECARBONISATION ENGINE
          </h2>
          <p class="text-xs text-slate-400">Real-time MW power curves, 25MWp Solar, 50MWh BESS & Scope 1/2 carbon intensity tracking.</p>
        </div>

        <div class="flex items-center gap-4 font-mono text-xs">
          <div class="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300">
            Total Demand: <strong class="text-yellow-400">24.5 MW</strong>
          </div>
          <div class="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300">
            Solar Generation: <strong class="text-emerald-400">18.2 MWp</strong>
          </div>
          <div class="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300">
            Carbon Intensity: <strong class="text-cyan-400">14.8 kg CO2e / TEU</strong>
          </div>
        </div>
      </div>

      <!-- Energy Asset Cards Grid -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        @for (asset of energyAssets; track asset.id) {
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
            <div class="flex items-center justify-between font-mono">
              <span class="font-bold text-sm text-white flex items-center gap-2">
                <mat-icon class="!text-sm text-yellow-400">electrical_services</mat-icon>
                {{ asset.name }}
              </span>
              <span class="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-emerald-500/20 text-emerald-400">
                {{ asset.status }}
              </span>
            </div>

            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2 text-xs font-mono">
              <div class="flex justify-between">
                <span class="text-slate-400">Capacity / Load:</span>
                <span class="text-white font-bold">{{ asset.currentPowerMw }} MW / {{ asset.capacityMw }} MW</span>
              </div>
              <div class="flex justify-between">
                <span class="text-slate-400">System Efficiency:</span>
                <span class="text-emerald-400 font-bold">{{ asset.efficiencyPct }}%</span>
              </div>
              @if (asset.socPct !== undefined) {
                <div class="flex justify-between">
                  <span class="text-slate-400">BESS State of Charge:</span>
                  <span class="text-cyan-400 font-bold">{{ asset.socPct }}%</span>
                </div>
              }
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class EnergyGridComponent {
  @Input({ required: true }) energyAssets: EnergyAsset[] = [];
}
