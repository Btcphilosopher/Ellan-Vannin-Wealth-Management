import { ChangeDetectionStrategy, Component, Input, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { HttpClient } from '@angular/common/http';
import { PortStateSnapshot } from '../../core/engine/port-types';

interface TerminalResponse {
  intent: string;
  explanation: string;
  causeChain: string[];
  recommendation: string;
  confidence: number;
}

@Component({
  selector: 'app-terminal-console',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 p-4 border border-slate-800 rounded-xl flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-cyan-400">terminal</mat-icon>
            PORT.TERM // GEMINI 3.6 AI OPERATIONS TERMINAL
          </h2>
          <p class="text-xs text-slate-400">Natural language industrial command prompt powered by Gemini 3.6 server-side reasoning.</p>
        </div>

        <div class="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-xs font-mono text-emerald-400 flex items-center gap-2">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
          <span>GEMINI 3.6 INTELLIGENCE LAYER: ONLINE</span>
        </div>
      </div>

      <!-- Quick Action Prompt Pills -->
      <div class="flex flex-wrap gap-2 text-xs font-mono">
        <span class="text-slate-400 py-1 font-bold">QUICK COMMANDS:</span>
        <button
          (click)="sendQuickPrompt('Why is MSC Meridian delayed? Explain cause chain.')"
          class="px-3 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 rounded-lg transition-all"
        >
          "Why is MSC Meridian delayed?"
        </button>
        <button
          (click)="sendQuickPrompt('Analyze primary bottleneck Yard Block T17 and propose mitigation plan.')"
          class="px-3 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 rounded-lg transition-all"
        >
          "Analyze bottleneck Yard T17"
        </button>
        <button
          (click)="sendQuickPrompt('Propose optimal re-routing plan after Quay Crane Q17 fault.')"
          class="px-3 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 rounded-lg transition-all"
        >
          "Mitigate Q17 crane fault"
        </button>
        <button
          (click)="sendQuickPrompt('Assess BESS battery peak shaving efficiency for next 4 hours.')"
          class="px-3 py-1 bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 rounded-lg transition-all"
        >
          "Assess microgrid peak shaving"
        </button>
      </div>

      <!-- Command Output Area -->
      <div class="bg-[#04070d] border border-slate-800 rounded-xl p-4 font-mono text-xs space-y-4 min-h-[340px] shadow-inner">
        @if (isProcessing()) {
          <div class="flex items-center gap-3 text-cyan-400 font-bold p-4 bg-slate-900/60 rounded-lg border border-slate-800">
            <mat-icon class="animate-spin">sync</mat-icon>
            <span>EXECUTING GEMINI 3.6 REASONING ENGINE OVER DIGITAL TWIN TELEMETRY...</span>
          </div>
        }

        @if (response()) {
          @let res = response()!;
          <div class="space-y-4 animate-fadeIn">
            <!-- Intent Header -->
            <div class="flex items-center justify-between p-3 bg-slate-900/90 rounded-lg border border-slate-800">
              <span class="text-cyan-400 font-bold flex items-center gap-2">
                <mat-icon class="!text-sm">psychology</mat-icon> INTENT: {{ res.intent }}
              </span>
              <span class="text-emerald-400 font-bold">CONFIDENCE: {{ (res.confidence * 100).toFixed(0) }}%</span>
            </div>

            <!-- Explanation -->
            <div class="p-3 bg-slate-900/60 rounded-lg border border-slate-800/80 text-slate-200">
              {{ res.explanation }}
            </div>

            <!-- Cause Chain Steps -->
            <div class="p-4 bg-slate-900/80 rounded-lg border border-slate-800 space-y-2">
              <span class="text-amber-400 font-bold uppercase block text-[11px] flex items-center gap-1.5">
                <mat-icon class="!text-sm">account_tree</mat-icon> ROOT CAUSE CHAIN ANALYSIS
              </span>
              <div class="space-y-1.5 pl-2 border-l-2 border-amber-500/50">
                @for (step of res.causeChain; track step; let idx = $index) {
                  <div class="text-slate-300">
                    <strong class="text-amber-300">[{{ idx + 1 }}]</strong> {{ step }}
                  </div>
                }
              </div>
            </div>

            <!-- Recommendation & Safety Interlock -->
            <div class="p-4 bg-emerald-950/40 border border-emerald-800/80 rounded-lg space-y-3">
              <div class="text-emerald-300 font-bold flex items-center justify-between">
                <span class="flex items-center gap-2">
                  <mat-icon class="text-emerald-400">gavel</mat-icon> PROPOSED OPERATIONAL PLAN
                </span>
                <span class="text-[10px] bg-emerald-500/20 px-2 py-0.5 rounded text-emerald-400">REQUIRES HUMAN APPROVAL</span>
              </div>
              <div class="text-white">{{ res.recommendation }}</div>

              <div class="pt-2 flex items-center gap-3">
                <button
                  (click)="approvePlan()"
                  class="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded transition-all flex items-center gap-1.5 shadow"
                >
                  <mat-icon class="!text-sm">check_circle</mat-icon> APPROVE & EXECUTE CONTROL PLAN
                </button>
                @if (planApproved()) {
                  <span class="text-emerald-400 font-bold flex items-center gap-1 animate-pulse">
                    <mat-icon class="!text-sm">verified</mat-icon> DISPATCHED TO OT CONTROL LAYER!
                  </span>
                }
              </div>
            </div>
          </div>
        } @else if (!isProcessing()) {
          <div class="text-slate-500 p-8 text-center space-y-2">
            <mat-icon class="!text-4xl text-slate-700">terminal</mat-icon>
            <div>TYPE A NATURAL LANGUAGE COMMAND ABOVE OR CLICK A QUICK PROMPT</div>
            <div class="text-[10px] text-slate-600">The Gemini API interprets port telemetry, solves cause chains, and drafts human-in-the-loop plans.</div>
          </div>
        }
      </div>

      <!-- Prompt Input Form -->
      <form [formGroup]="form" (ngSubmit)="onSubmit()" class="flex items-center gap-2">
        <input
          formControlName="command"
          type="text"
          placeholder="Type industrial command (e.g. 'Why is berth B05 queue building up?')"
          class="flex-1 bg-slate-900 border border-slate-700 focus:border-cyan-500 rounded-xl px-4 py-3 font-mono text-xs text-white placeholder-slate-500 outline-none transition-all"
        />
        <button
          type="submit"
          [disabled]="form.invalid || isProcessing()"
          class="px-6 py-3 bg-cyan-600 hover:bg-cyan-500 disabled:bg-slate-800 disabled:text-slate-600 text-white font-mono font-bold text-xs rounded-xl transition-all flex items-center gap-2 shadow-lg shadow-cyan-950"
        >
          <mat-icon class="!text-sm">send</mat-icon> EXECUTE
        </button>
      </form>
    </div>
  `,
})
export class TerminalConsoleComponent {
  @Input({ required: true }) portState!: PortStateSnapshot;

  private http = inject(HttpClient);
  private fb = inject(FormBuilder);

  public form = this.fb.group({
    command: [''],
  });

  public isProcessing = signal(false);
  public response = signal<TerminalResponse | null>(null);
  public planApproved = signal(false);

  public sendQuickPrompt(prompt: string): void {
    this.form.patchValue({ command: prompt });
    this.onSubmit();
  }

  public onSubmit(): void {
    const cmd = this.form.value.command?.trim();
    if (!cmd) return;

    this.isProcessing.set(true);
    this.planApproved.set(false);

    this.http
      .post<TerminalResponse>('/api/port/terminal-command', {
        command: cmd,
        portState: this.portState,
      })
      .subscribe({
        next: (res) => {
          this.response.set(res);
          this.isProcessing.set(false);
        },
        error: (err) => {
          console.error(err);
          this.isProcessing.set(false);
        },
      });
  }

  public approvePlan(): void {
    this.planApproved.set(true);
  }
}
