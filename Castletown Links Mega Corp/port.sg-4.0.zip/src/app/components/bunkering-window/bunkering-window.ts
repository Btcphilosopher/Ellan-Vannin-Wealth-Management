import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { DigitalBunkeringTransaction, SingleWindowClearance } from '../../core/engine/port-types';

@Component({
  selector: 'app-bunkering-window',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 p-4 border border-slate-800 rounded-xl flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-sky-400">verified</mat-icon>
            DIGITAL BUNKERING & MARITIME SINGLE WINDOW
          </h2>
          <p class="text-xs text-slate-400">Mass flow meter telemetry, digital Bunker Delivery Notes (BDN) & regulatory clearances.</p>
        </div>
      </div>

      <!-- Bunkering Transactions Table -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4 font-mono text-xs">
        <h3 class="font-bold text-sm text-white flex items-center gap-2">
          <mat-icon class="text-sky-400">local_gas_station</mat-icon> DIGITAL BUNKERING (MASS FLOW METERING)
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-slate-300">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase">
              <tr>
                <th class="p-3">BDN REF</th>
                <th class="p-3">VESSEL</th>
                <th class="p-3">BUNKER BARGE</th>
                <th class="p-3">FUEL TYPE</th>
                <th class="p-3">QUANTITY</th>
                <th class="p-3">FLOW RATE</th>
                <th class="p-3">STATUS</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (b of bunkering; track b.id) {
                <tr class="hover:bg-slate-800/40">
                  <td class="p-3 font-bold text-white">{{ b.id }}</td>
                  <td class="p-3 text-cyan-400">{{ b.vesselName }}</td>
                  <td class="p-3 text-slate-400">{{ b.bunkerBargeName }}</td>
                  <td class="p-3">
                    <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-sky-500/20 text-sky-400">
                      {{ b.fuelType }}
                    </span>
                  </td>
                  <td class="p-3 text-white font-bold">{{ b.quantityTons }} MT</td>
                  <td class="p-3 text-slate-400">{{ b.massFlowRateTonsHr }} MT/h</td>
                  <td class="p-3 text-emerald-400 font-bold">{{ b.status }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class BunkeringWindowComponent {
  @Input({ required: true }) bunkering: DigitalBunkeringTransaction[] = [];
  @Input({ required: true }) clearances: SingleWindowClearance[] = [];
}
