import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { QuayCrane } from '../../core/engine/port-types';

@Component({
  selector: 'app-crane-telemetry',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 p-4 border border-slate-800 rounded-xl flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-amber-400">precision_manufacturing</mat-icon>
            AUTOMATED QUAY CRANE TELEMETRY & TROLLEY DYNAMICS
          </h2>
          <p class="text-xs text-slate-400">32 Double-Trolley Automated Quay Cranes (Q01-Q32) real-time cycle times & hoist telemetry.</p>
        </div>

        <div class="flex items-center gap-3 font-mono text-xs">
          <div class="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300">
            Avg Cycle Time: <strong class="text-cyan-400">68.4 sec</strong>
          </div>
          <div class="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300">
            Total Shifts Moves: <strong class="text-emerald-400">11,840 TEU</strong>
          </div>
        </div>
      </div>

      <!-- Crane Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        @for (qc of quayCranes; track qc.id) {
          <div
            class="bg-slate-900 border rounded-xl p-4 space-y-3 relative overflow-hidden"
            [class.border-red-500/80]="qc.status === 'FAULT'"
            [class.border-slate-800]="qc.status !== 'FAULT'"
          >
            <!-- Top Status -->
            <div class="flex items-center justify-between font-mono">
              <span class="font-bold text-sm text-white flex items-center gap-1.5">
                <mat-icon class="!text-sm text-amber-400">build</mat-icon> {{ qc.id }}
              </span>
              <span
                class="px-2 py-0.5 rounded text-[10px] font-bold uppercase"
                [class.bg-emerald-500/20]="qc.status === 'LIFTING'"
                [class.text-emerald-400]="qc.status === 'LIFTING'"
                [class.bg-red-500/20]="qc.status === 'FAULT'"
                [class.text-red-400]="qc.status === 'FAULT'"
                [class.bg-slate-800]="qc.status === 'IDLE'"
                [class.text-slate-400]="qc.status === 'IDLE'"
              >
                {{ qc.status }}
              </span>
            </div>

            <!-- Trolley & Hoist Gauge Visualizer -->
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800/80 space-y-2">
              <div class="flex justify-between text-[10px] font-mono text-slate-400">
                <span>Trolley Reach: {{ qc.trolleyPosMeters.toFixed(1) }}m</span>
                <span>Hoist: {{ qc.hoistHeightMeters.toFixed(1) }}m</span>
              </div>
              <!-- Trolley Bar -->
              <div class="w-full bg-slate-900 h-3 rounded relative overflow-hidden border border-slate-800">
                <div
                  class="bg-amber-400 h-full transition-all duration-200"
                  [style.width.%]="(qc.trolleyPosMeters / 50) * 100"
                ></div>
              </div>
            </div>

            <!-- Crane Performance Metrics -->
            <div class="space-y-1.5 font-mono text-xs text-slate-400 border-t border-slate-800/60 pt-2">
              <div class="flex justify-between">
                <span>Throughput:</span>
                <span class="text-cyan-400 font-bold">{{ qc.movesPerHour }} moves/h</span>
              </div>
              <div class="flex justify-between">
                <span>Power Demand:</span>
                <span class="text-white">{{ qc.powerKw }} kW</span>
              </div>
              <div class="flex justify-between">
                <span>Health Index:</span>
                <span [class.text-emerald-400]="qc.healthScore > 80" [class.text-red-400]="qc.healthScore <= 50" class="font-bold">
                  {{ qc.healthScore }}%
                </span>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class CraneTelemetryComponent {
  @Input({ required: true }) quayCranes: QuayCrane[] = [];
}
