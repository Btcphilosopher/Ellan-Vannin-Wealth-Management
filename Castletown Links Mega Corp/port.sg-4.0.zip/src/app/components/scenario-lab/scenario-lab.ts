import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { OptimisationEngineService } from '../../core/engine/optimisation-engine';
import { PortSimulatorService } from '../../core/engine/port-simulator';
import { ScenarioRunResult } from '../../core/engine/port-types';

@Component({
  selector: 'app-scenario-lab',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 p-4 border border-slate-800 rounded-xl flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-purple-400">science</mat-icon>
            WHAT-IF SCENARIO LAB & COUNTERFACTUAL SIMULATOR
          </h2>
          <p class="text-xs text-slate-400">Stress test port operations against failures, storms, and volume surges with quantitative baseline comparisons.</p>
        </div>
      </div>

      <!-- Quick Failure & Storm Injection Controls -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3">
        <h3 class="font-mono font-bold text-xs text-slate-300 uppercase tracking-wider flex items-center gap-2">
          <mat-icon class="!text-sm text-red-400">warning</mat-icon> INJECT DISRUPTIVE SCENARIO INTO DIGITAL TWIN
        </h3>
        <div class="flex flex-wrap gap-3 font-mono text-xs">
          <button
            (click)="runScenario('Quay Crane Q17 Failure')"
            class="px-3 py-2 bg-red-950/60 hover:bg-red-900 border border-red-800 text-red-300 rounded-lg transition-all flex items-center gap-1.5"
          >
            <mat-icon class="!text-sm">error</mat-icon> INJECT Q17 MOTOR FAULT
          </button>
          <button
            (click)="runScenario('20 AGV Fleet Outage')"
            class="px-3 py-2 bg-amber-950/60 hover:bg-amber-900 border border-amber-800 text-amber-300 rounded-lg transition-all flex items-center gap-1.5"
          >
            <mat-icon class="!text-sm">no_crash</mat-icon> DISABLE 20 AGVs
          </button>
          <button
            (click)="runScenario('High Wind Storm (45 kts)')"
            class="px-3 py-2 bg-purple-950/60 hover:bg-purple-900 border border-purple-800 text-purple-300 rounded-lg transition-all flex items-center gap-1.5"
          >
            <mat-icon class="!text-sm">air</mat-icon> STORM / HIGH WIND (45 KTS)
          </button>
          <button
            (click)="runScenario('+20% Volume Surge')"
            class="px-3 py-2 bg-cyan-950/60 hover:bg-cyan-900 border border-cyan-800 text-cyan-300 rounded-lg transition-all flex items-center gap-1.5"
          >
            <mat-icon class="!text-sm">trending_up</mat-icon> +20% CARGO VOLUME SURGE
          </button>
        </div>
      </div>

      <!-- Quantitative KPI Delta Results -->
      @if (activeResult()) {
        @let r = activeResult()!;
        <div class="bg-slate-900 border border-purple-800/80 rounded-xl p-4 space-y-4">
          <div class="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 class="font-mono font-bold text-sm text-white flex items-center gap-2">
              <mat-icon class="text-purple-400">analytics</mat-icon> SCENARIO RESULT: {{ r.scenarioName }}
            </h3>
            <span class="text-xs font-mono text-slate-400">Estimated Recovery Time: <strong class="text-cyan-400">{{ r.estimatedRecoveryTimeMin }} min</strong></span>
          </div>

          <div class="grid grid-cols-1 md:grid-cols-3 gap-4 font-mono text-xs">
            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
              <span class="text-slate-400">Throughput Impact</span>
              <div class="flex items-baseline gap-2">
                <span class="text-slate-400 font-bold">Baseline: {{ r.baselineThroughputTeuHr }} TEU/h</span>
                <span class="text-red-400 font-bold text-lg">→ {{ r.counterfactualThroughputTeuHr }} TEU/h</span>
              </div>
            </div>

            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
              <span class="text-slate-400">Vessel Waiting Time Delta</span>
              <div class="text-lg font-bold text-amber-400">+{{ r.vesselDelayDeltaMin }} minutes / vessel</div>
            </div>

            <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-1">
              <span class="text-slate-400">Yard Congestion Delta</span>
              <div class="text-lg font-bold text-purple-400">+{{ r.yardCongestionDeltaPct }}% Density</div>
            </div>
          </div>
        </div>
      }
    </div>
  `,
})
export class ScenarioLabComponent {
  private optimizer = inject(OptimisationEngineService);
  private simulator = inject(PortSimulatorService);

  public activeResult = signal<ScenarioRunResult | null>(null);

  public runScenario(name: string): void {
    if (name.includes('Q17')) {
      this.simulator.injectFailure('Q17');
    } else if (name.includes('Storm') || name.includes('WIND')) {
      this.simulator.setWeatherScenario('STORM');
    }
    const result = this.optimizer.runScenarioComparison(name);
    this.activeResult.set(result);
  }
}
