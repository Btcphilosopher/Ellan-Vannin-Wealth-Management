import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MaintenanceAsset } from '../../core/engine/port-types';

@Component({
  selector: 'app-predictive-maint',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 p-4 border border-slate-800 rounded-xl flex items-center justify-between">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-red-400">build_circle</mat-icon>
            PREDICTIVE ASSET HEALTH & MAINTENANCE ENGINE
          </h2>
          <p class="text-xs text-slate-400">Vibration FFT analysis, motor thermography, Remaining Useful Life (RUL) & automated work orders.</p>
        </div>

        <div class="bg-slate-950 px-3 py-1.5 rounded-lg border border-slate-800 text-xs font-mono text-slate-300">
          Critical Alarms: <strong class="text-red-400">1 Active (Q17 Drive Fault)</strong>
        </div>
      </div>

      <!-- Asset Health Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
        @for (m of maintenanceAssets; track m.assetId) {
          <div
            class="bg-slate-900 border rounded-xl p-4 space-y-3"
            [class.border-red-500/80]="m.status === 'CRITICAL_ALERT'"
            [class.border-amber-500/80]="m.status === 'MAINTENANCE_REQUIRED'"
            [class.border-slate-800]="m.status === 'HEALTHY' || m.status === 'MONITORING'"
          >
            <div class="flex items-center justify-between font-mono">
              <span class="font-bold text-sm text-white flex items-center gap-2">
                <mat-icon class="!text-sm text-slate-400">construction</mat-icon> {{ m.assetName }}
              </span>
              <span
                class="px-2 py-0.5 rounded text-[10px] font-bold uppercase"
                [class.bg-red-500/20]="m.status === 'CRITICAL_ALERT'"
                [class.text-red-400]="m.status === 'CRITICAL_ALERT'"
                [class.bg-amber-500/20]="m.status === 'MAINTENANCE_REQUIRED'"
                [class.text-amber-400]="m.status === 'MAINTENANCE_REQUIRED'"
                [class.bg-emerald-500/20]="m.status === 'HEALTHY'"
                [class.text-emerald-400]="m.status === 'HEALTHY'"
              >
                {{ m.status }}
              </span>
            </div>

            <div class="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-950 p-3 rounded-lg border border-slate-800">
              <div>
                <span class="text-slate-400 block text-[10px]">HEALTH SCORE</span>
                <span class="font-bold text-base" [class.text-red-400]="m.healthScore < 50" [class.text-emerald-400]="m.healthScore >= 80">
                  {{ m.healthScore }}%
                </span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px]">FAILURE PROBABILITY</span>
                <span class="font-bold text-base text-amber-400">{{ m.failureProbabilityPct }}%</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px]">REMAINING USEFUL LIFE (RUL)</span>
                <span class="text-white font-bold">{{ m.rulHours }} Hours</span>
              </div>
              <div>
                <span class="text-slate-400 block text-[10px]">VIBRATION / TEMP</span>
                <span class="text-cyan-400 font-bold">{{ m.vibrationMmSec }} mm/s | {{ m.temperatureC }}°C</span>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class PredictiveMaintComponent {
  @Input({ required: true }) maintenanceAssets: MaintenanceAsset[] = [];
}
