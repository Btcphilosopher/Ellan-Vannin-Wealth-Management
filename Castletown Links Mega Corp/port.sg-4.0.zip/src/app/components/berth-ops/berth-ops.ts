import { ChangeDetectionStrategy, Component, Input, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { Berth, Vessel } from '../../core/engine/port-types';
import { OptimisationEngineService } from '../../core/engine/optimisation-engine';

@Component({
  selector: 'app-berth-ops',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="space-y-6">
      <!-- Header Bar -->
      <div class="flex items-center justify-between bg-slate-900 p-4 border border-slate-800 rounded-xl">
        <div>
          <h2 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-cyan-400">directions_boat</mat-icon>
            BERTH ALLOCATION & PORT CALL MANAGEMENT
          </h2>
          <p class="text-xs text-slate-400">Real-time berth assignments, depth compatibility & MILP dynamic optimization.</p>
        </div>

        <button
          (click)="runOptimizer()"
          class="px-4 py-2 bg-cyan-600 hover:bg-cyan-500 text-white font-mono font-bold text-xs rounded-lg transition-all flex items-center gap-2 shadow-lg shadow-cyan-950"
        >
          <mat-icon class="!text-sm">auto_fix_high</mat-icon>
          RUN MILP BERTH OPTIMIZER
        </button>
      </div>

      <!-- Optimization Result Banner -->
      @if (optimizerOutput()) {
        <div class="p-4 bg-cyan-950/40 border border-cyan-800/80 rounded-xl text-xs font-mono space-y-2">
          <div class="text-cyan-300 font-bold flex items-center gap-2">
            <mat-icon class="!text-sm text-cyan-400">check_circle</mat-icon>
            MILP BERTH SOLVER CONVERGED (Runtime: 142 ms)
          </div>
          <div class="text-slate-300">{{ optimizerOutput()?.summary }}</div>
        </div>
      }

      <!-- Berths Grid View -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        @for (b of berths; track b.id) {
          @let vessel = getBerthedVessel(b.occupiedVesselId);
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-3 relative overflow-hidden">
            <!-- Top Status Indicator -->
            <div class="flex items-center justify-between">
              <span class="font-mono font-bold text-sm text-cyan-400">{{ b.name }}</span>
              <span
                class="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase"
                [class.bg-emerald-500/20]="b.status === 'AVAILABLE'"
                [class.text-emerald-400]="b.status === 'AVAILABLE'"
                [class.bg-sky-500/20]="b.status === 'OCCUPIED'"
                [class.text-sky-400]="b.status === 'OCCUPIED'"
              >
                {{ b.status }}
              </span>
            </div>

            <!-- Specs -->
            <div class="text-xs space-y-1 font-mono text-slate-400 border-b border-slate-800/60 pb-3">
              <div class="flex justify-between">
                <span>Length / Max Draft:</span>
                <span class="text-white">{{ b.lengthMeters }}m / {{ b.maxDraftMeters }}m</span>
              </div>
              <div class="flex justify-between">
                <span>Shore Power:</span>
                <span class="text-emerald-400 font-bold">{{ b.powerAvailableMW }} MW Connected</span>
              </div>
              <div class="flex justify-between">
                <span>Assigned QC:</span>
                <span class="text-white">{{ b.assignedCraneIds.join(', ') }}</span>
              </div>
            </div>

            <!-- Occupied Vessel Box -->
            @if (vessel) {
              <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-xs text-white">{{ vessel.name }}</span>
                  <span class="text-[10px] font-mono text-cyan-400">{{ vessel.teuCapacity.toLocaleString() }} TEU</span>
                </div>
                <!-- Move Progress Bar -->
                <div class="space-y-1 text-[10px] font-mono">
                  <div class="flex justify-between text-slate-400">
                    <span>Container Moves:</span>
                    <span class="text-white">{{ vessel.completedMoves }} / {{ vessel.totalMoves }}</span>
                  </div>
                  <div class="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
                    <div
                      class="bg-cyan-500 h-full transition-all duration-300"
                      [style.width.%]="(vessel.completedMoves / vessel.totalMoves) * 100"
                    ></div>
                  </div>
                </div>
              </div>
            } @else {
              <div class="p-4 border border-dashed border-slate-800 rounded-lg text-center font-mono text-xs text-slate-500">
                NO VESSEL BERTHED (READY FOR CALL)
              </div>
            }
          </div>
        }
      </div>

      <!-- Vessels Queue Table -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-4">
        <h3 class="font-mono font-bold text-sm text-white flex items-center gap-2">
          <mat-icon class="text-cyan-400">list_alt</mat-icon> ACTIVE PORT CALLS & SCHEDULED ARRIVALS
        </h3>

        <div class="overflow-x-auto">
          <table class="w-full text-left font-mono text-xs text-slate-300">
            <thead class="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase">
              <tr>
                <th class="p-3">VESSEL</th>
                <th class="p-3">IMO</th>
                <th class="p-3">TEU CAPACITY</th>
                <th class="p-3">STATUS</th>
                <th class="p-3">ASSIGNED BERTH</th>
                <th class="p-3">DRAFT</th>
                <th class="p-3">ETA / ETD WINDOW</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/60">
              @for (v of vessels; track v.id) {
                <tr class="hover:bg-slate-800/40 transition-colors">
                  <td class="p-3 font-bold text-white flex items-center gap-2">
                    <mat-icon class="!text-sm text-slate-400">directions_boat</mat-icon>
                    {{ v.name }}
                  </td>
                  <td class="p-3 text-slate-400">{{ v.imo }}</td>
                  <td class="p-3 text-cyan-400 font-bold">{{ v.teuCapacity.toLocaleString() }}</td>
                  <td class="p-3">
                    <span
                      class="px-2 py-0.5 rounded text-[10px] font-bold"
                      [class.bg-emerald-500/20]="v.status === 'WORKING'"
                      [class.text-emerald-400]="v.status === 'WORKING'"
                      [class.bg-amber-500/20]="v.status === 'APPROACHING' || v.status === 'PILOTING'"
                      [class.text-amber-400]="v.status === 'APPROACHING' || v.status === 'PILOTING'"
                      [class.bg-sky-500/20]="v.status === 'BERTHING'"
                      [class.text-sky-400]="v.status === 'BERTHING'"
                    >
                      {{ v.status }}
                    </span>
                  </td>
                  <td class="p-3 text-white font-bold">{{ v.berthId || 'ANCHORAGE' }}</td>
                  <td class="p-3 text-slate-400">{{ v.draftMeters }}m</td>
                  <td class="p-3 text-slate-400">08:00 - 22:00 UTC+8</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `,
})
export class BerthOpsComponent {
  @Input({ required: true }) berths: Berth[] = [];
  @Input({ required: true }) vessels: Vessel[] = [];

  private optimizer = inject(OptimisationEngineService);
  public optimizerOutput = signal<{ plan: { vesselId: string; vesselName: string; berthId: string; startOffsetMin: number; durationHours: number; assignedCranes: number; confidence: number }[]; summary: string } | null>(null);

  public getBerthedVessel(vesselId?: string): Vessel | undefined {
    if (!vesselId) return undefined;
    return this.vessels.find((v) => v.id === vesselId);
  }

  public runOptimizer(): void {
    const res = this.optimizer.optimizeBerthAllocation(this.vessels, this.berths, []);
    this.optimizerOutput.set(res);
  }
}
