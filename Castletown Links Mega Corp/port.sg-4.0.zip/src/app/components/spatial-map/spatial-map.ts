import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  Input,
  OnDestroy,
  OnInit,
  ViewChild,
  signal,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AGV, Berth, QuayCrane, Vessel, YardBlock } from '../../core/engine/port-types';
import * as THREE from 'three';

@Component({
  selector: 'app-spatial-map',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="relative w-full h-[calc(100vh-140px)] bg-[#090d14] border border-slate-800 rounded-xl overflow-hidden flex flex-col">
      <!-- Toolbar Header -->
      <div class="h-12 px-4 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between text-xs z-10 backdrop-blur-md">
        <div class="flex items-center gap-3">
          <span class="font-mono text-cyan-400 font-bold uppercase tracking-wider flex items-center gap-1.5">
            <mat-icon class="!text-sm">radar</mat-icon> SPATIAL DIGITAL TWIN
          </span>
          <div class="h-4 w-[1px] bg-slate-700"></div>

          <!-- Mode Toggle: 2D Radar vs 3D Mesh -->
          <div class="flex bg-slate-950 p-1 rounded-lg border border-slate-800">
            <button
              (click)="viewMode.set('2D')"
              class="px-3 py-1 rounded font-medium transition-all duration-200 flex items-center gap-1"
              [class.bg-cyan-600]="viewMode() === '2D'"
              [class.text-white]="viewMode() === '2D'"
              [class.text-slate-400]="viewMode() !== '2D'"
            >
              <mat-icon class="!text-xs">map</mat-icon> 2D TACTICAL RADAR
            </button>
            <button
              (click)="viewMode.set('3D')"
              class="px-3 py-1 rounded font-medium transition-all duration-200 flex items-center gap-1"
              [class.bg-cyan-600]="viewMode() === '3D'"
              [class.text-white]="viewMode() === '3D'"
              [class.text-slate-400]="viewMode() !== '3D'"
            >
              <mat-icon class="!text-xs">view_in_ar</mat-icon> 3D INDUSTRIAL VIEW
            </button>
          </div>
        </div>

        <div class="flex items-center gap-4 font-mono text-slate-400">
          <div class="flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>TELEMETRY STREAM: <strong class="text-white">50 Hz</strong></span>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-cyan-400"></span>
            <span>AGVs ACTIVE: <strong class="text-white">{{ activeAgvCount() }}</strong></span>
          </div>
          <div class="flex items-center gap-1.5">
            <span class="w-2 h-2 rounded-full bg-amber-400"></span>
            <span>CRANES LIFTING: <strong class="text-white">{{ activeCraneCount() }}</strong></span>
          </div>
        </div>
      </div>

      <!-- Main Canvas Container -->
      <div class="relative flex-1 bg-[#06090e] overflow-hidden">
        <!-- 2D Canvas View -->
        @if (viewMode() === '2D') {
          <canvas
            #canvas2d
            (click)="handleCanvasClick($event)"
            class="w-full h-full cursor-crosshair block"
          ></canvas>
        }

        <!-- 3D View Container -->
        @if (viewMode() === '3D') {
          <div #canvas3dContainer class="w-full h-full block relative"></div>
        }

        <!-- Floating Quick Status Overlay -->
        <div class="absolute bottom-4 left-4 p-3 bg-slate-900/90 border border-slate-800 rounded-lg text-xs font-mono space-y-1.5 backdrop-blur-md pointer-events-none max-w-sm">
          <div class="text-cyan-400 font-bold flex items-center gap-1">
            <mat-icon class="!text-xs">location_on</mat-icon> MERIDIAN INTERNATIONAL TERMINAL
          </div>
          <div class="text-slate-400">Coordinates: 01°13'42"N 103°38'10"E (Tuas Basin)</div>
          <div class="text-slate-300">Quay Length: 3,400m | Berths: 8 | AGV Road Grid: 14.8 km</div>
        </div>

        <!-- Selected Entity Inspector Drawer -->
        @if (selectedEntity()) {
          <div class="absolute top-4 right-4 w-96 bg-slate-900/95 border border-slate-700 rounded-xl p-4 shadow-2xl backdrop-blur-md z-20 space-y-4 text-xs font-sans">
            <div class="flex items-center justify-between border-b border-slate-800 pb-2">
              <div class="flex items-center gap-2">
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold uppercase"
                  [class.bg-cyan-500/20]="selectedEntityType() === 'VESSEL'"
                  [class.text-cyan-400]="selectedEntityType() === 'VESSEL'"
                  [class.bg-amber-500/20]="selectedEntityType() === 'CRANE'"
                  [class.text-amber-400]="selectedEntityType() === 'CRANE'"
                  [class.bg-emerald-500/20]="selectedEntityType() === 'AGV'"
                  [class.text-emerald-400]="selectedEntityType() === 'AGV'"
                  [class.bg-purple-500/20]="selectedEntityType() === 'YARD'"
                  [class.text-purple-400]="selectedEntityType() === 'YARD'"
                >
                  {{ selectedEntityType() }}
                </span>
                <h3 class="font-mono font-bold text-sm text-white">{{ getEntityName() }}</h3>
              </div>
              <button (click)="selectedEntity.set(null)" class="text-slate-400 hover:text-white">
                <mat-icon class="!text-sm">close</mat-icon>
              </button>
            </div>

            <!-- Telemetry Details Grid -->
            <div class="space-y-3 font-mono">
              <div class="grid grid-cols-2 gap-2 bg-slate-950/70 p-2.5 rounded-lg border border-slate-800/80">
                <div>
                  <span class="text-slate-400 block text-[10px]">ID</span>
                  <span class="text-white font-bold">{{ getEntityId() }}</span>
                </div>
                <div>
                  <span class="text-slate-400 block text-[10px]">STATUS</span>
                  <span class="font-bold" [class.text-emerald-400]="getEntityStatus() === 'WORKING' || getEntityStatus() === 'LIFTING' || getEntityStatus() === 'LOADED_TRAVEL'" [class.text-red-400]="getEntityStatus() === 'FAULT'">
                    {{ getEntityStatus() }}
                  </span>
                </div>
              </div>

              <!-- Specific Specs based on type -->
              @if (selectedEntityType() === 'VESSEL') {
                @let v = asVessel();
                <div class="space-y-2">
                  <div class="flex justify-between border-b border-slate-800/50 py-1">
                    <span class="text-slate-400">IMO / MMSI:</span>
                    <span class="text-white">{{ v.imo }} / {{ v.mmsi }}</span>
                  </div>
                  <div class="flex justify-between border-b border-slate-800/50 py-1">
                    <span class="text-slate-400">Length x Draft:</span>
                    <span class="text-white">{{ v.lengthMeters }}m x {{ v.draftMeters }}m</span>
                  </div>
                  <div class="flex justify-between border-b border-slate-800/50 py-1">
                    <span class="text-slate-400">TEU Progress:</span>
                    <span class="text-cyan-400 font-bold">{{ v.completedMoves }} / {{ v.totalMoves }} TEU</span>
                  </div>
                  <div class="flex justify-between py-1">
                    <span class="text-slate-400">Assigned Berth:</span>
                    <span class="text-emerald-400 font-bold">{{ v.berthId || 'ANCHORAGE' }}</span>
                  </div>
                </div>
              }

              @if (selectedEntityType() === 'CRANE') {
                @let qc = asCrane();
                <div class="space-y-2">
                  <div class="flex justify-between border-b border-slate-800/50 py-1">
                    <span class="text-slate-400">Moves / Hour:</span>
                    <span class="text-cyan-400 font-bold">{{ qc.movesPerHour }} moves/h</span>
                  </div>
                  <div class="flex justify-between border-b border-slate-800/50 py-1">
                    <span class="text-slate-400">Cycle Time:</span>
                    <span class="text-white">{{ qc.cycleTimeSec }} sec</span>
                  </div>
                  <div class="flex justify-between border-b border-slate-800/50 py-1">
                    <span class="text-slate-400">Health Index:</span>
                    <span class="font-bold" [class.text-emerald-400]="qc.healthScore > 80" [class.text-red-400]="qc.healthScore <= 50">{{ qc.healthScore }}%</span>
                  </div>
                  <div class="flex justify-between py-1">
                    <span class="text-slate-400">Vibration / Temp:</span>
                    <span class="text-white">{{ qc.vibrationMmPerSec }} mm/s | {{ qc.temperatureC }}°C</span>
                  </div>
                </div>
              }

              @if (selectedEntityType() === 'AGV') {
                @let agv = asAGV();
                <div class="space-y-2">
                  <div class="flex justify-between border-b border-slate-800/50 py-1">
                    <span class="text-slate-400">Battery Level:</span>
                    <span class="font-bold" [class.text-emerald-400]="agv.batteryPct > 50" [class.text-amber-400]="agv.batteryPct <= 30">{{ agv.batteryPct.toFixed(1) }}%</span>
                  </div>
                  <div class="flex justify-between border-b border-slate-800/50 py-1">
                    <span class="text-slate-400">Current Speed:</span>
                    <span class="text-white">{{ agv.speedMps.toFixed(1) }} m/s ({{ (agv.speedMps * 3.6).toFixed(1) }} km/h)</span>
                  </div>
                  <div class="flex justify-between border-b border-slate-800/50 py-1">
                    <span class="text-slate-400">Payload Container:</span>
                    <span class="text-cyan-400 font-bold">{{ agv.payloadContainerId || 'NONE (EMPTY TRAVEL)' }}</span>
                  </div>
                  <div class="flex justify-between py-1">
                    <span class="text-slate-400">Odometer:</span>
                    <span class="text-white">{{ agv.totalDistanceKm.toFixed(1) }} km</span>
                  </div>
                </div>
              }

              @if (selectedEntityType() === 'YARD') {
                @let y = asYard();
                <div class="space-y-2">
                  <div class="flex justify-between border-b border-slate-800/50 py-1">
                    <span class="text-slate-400">Stack Occupancy:</span>
                    <span class="text-cyan-400 font-bold">{{ y.occupiedTeu }} / {{ y.capacityTeu }} TEU</span>
                  </div>
                  <div class="flex justify-between border-b border-slate-800/50 py-1">
                    <span class="text-slate-400">Density Pct:</span>
                    <span class="font-bold" [class.text-red-400]="y.densityPct > 85" [class.text-emerald-400]="y.densityPct <= 75">{{ y.densityPct.toFixed(1) }}%</span>
                  </div>
                  <div class="flex justify-between py-1">
                    <span class="text-slate-400">Congestion Index:</span>
                    <span class="text-amber-400 font-bold">{{ (y.congestionIndex * 100).toFixed(0) }}%</span>
                  </div>
                </div>
              }

              <!-- Telemetry Metadata Footer -->
              <div class="pt-2 border-t border-slate-800 text-[10px] text-slate-500 space-y-1">
                <div class="flex justify-between">
                  <span>Sensor Source:</span>
                  <span class="text-slate-400">5G Private Network IoT</span>
                </div>
                <div class="flex justify-between">
                  <span>State Confidence:</span>
                  <span class="text-emerald-400 font-bold">99.4% (Kalman Filtered)</span>
                </div>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `,
})
export class SpatialMapComponent implements OnInit, OnDestroy {
  @Input({ required: true }) vessels: Vessel[] = [];
  @Input({ required: true }) berths: Berth[] = [];
  @Input({ required: true }) quayCranes: QuayCrane[] = [];
  @Input({ required: true }) agvs: AGV[] = [];
  @Input({ required: true }) yardBlocks: YardBlock[] = [];

  @ViewChild('canvas2d') canvas2dRef!: ElementRef<HTMLCanvasElement>;
  @ViewChild('canvas3dContainer') canvas3dContainerRef!: ElementRef<HTMLDivElement>;

  public viewMode = signal<'2D' | '3D'>('2D');
  public selectedEntity = signal<Vessel | QuayCrane | AGV | YardBlock | null>(null);
  public selectedEntityType = signal<'VESSEL' | 'CRANE' | 'AGV' | 'YARD'>('VESSEL');

  private animationFrameId: number | null = null;
  private threeScene?: THREE.Scene;
  private threeCamera?: THREE.PerspectiveCamera;
  private threeRenderer?: THREE.WebGLRenderer;
  private threeAgvMeshes = new Map<string, THREE.Mesh>();

  ngOnInit(): void {
    this.start2DRenderLoop();
  }

  ngOnDestroy(): void {
    if (this.animationFrameId) cancelAnimationFrame(this.animationFrameId);
    if (this.threeRenderer) this.threeRenderer.dispose();
  }

  public activeAgvCount(): number {
    return this.agvs.filter((a) => a.state === 'LOADED_TRAVEL' || a.state === 'EN_ROUTE_TO_PICKUP').length;
  }

  public activeCraneCount(): number {
    return this.quayCranes.filter((c) => c.status === 'LIFTING' || c.status === 'DISCHARGING').length;
  }

  private start2DRenderLoop(): void {
    const render = () => {
      if (this.viewMode() === '2D' && this.canvas2dRef) {
        this.draw2DRadar();
      } else if (this.viewMode() === '3D' && this.canvas3dContainerRef && !this.threeRenderer) {
        this.init3DScene();
      } else if (this.viewMode() === '3D' && this.threeRenderer) {
        this.update3DScene();
      }
      this.animationFrameId = requestAnimationFrame(render);
    };
    this.animationFrameId = requestAnimationFrame(render);
  }

  private draw2DRadar(): void {
    const canvas = this.canvas2dRef.nativeElement;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = canvas.clientWidth;
    canvas.height = canvas.clientHeight;

    const w = canvas.width;
    const h = canvas.height;

    // Deep graphite background
    ctx.fillStyle = '#06090e';
    ctx.fillRect(0, 0, w, h);

    // Draw Grid Lines (Geospatial 50m grid)
    ctx.strokeStyle = '#101726';
    ctx.lineWidth = 1;
    for (let x = 0; x < w; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, h);
      ctx.stroke();
    }
    for (let y = 0; y < h; y += 40) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(w, y);
      ctx.stroke();
    }

    // 1. Draw Water Basin (Top side)
    const seaHeight = 160;
    ctx.fillStyle = '#0a1628';
    ctx.fillRect(0, 0, w, seaHeight);

    ctx.fillStyle = '#0e243a';
    ctx.font = '10px "JetBrains Mono"';
    ctx.fillText('SINGAPORE STRAITS / DEEPWATER FAIRWAY', 20, 25);

    // 2. Draw Quay Line & Berths (B01 - B08)
    ctx.fillStyle = '#1e293b';
    ctx.fillRect(0, seaHeight, w, 24);

    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 2;
    ctx.strokeRect(0, seaHeight, w, 24);

    const berthWidth = w / 8;
    for (let i = 0; i < 8; i++) {
      const bx = i * berthWidth;
      const berth = this.berths[i];

      ctx.strokeStyle = '#334155';
      ctx.beginPath();
      ctx.moveTo(bx, seaHeight);
      ctx.lineTo(bx, seaHeight + 24);
      ctx.stroke();

      ctx.fillStyle = berth?.status === 'OCCUPIED' ? '#0284c7' : '#059669';
      ctx.font = '9px "JetBrains Mono"';
      ctx.fillText(berth ? berth.id : `B0${i + 1}`, bx + 8, seaHeight + 16);
    }

    // 3. Draw Vessels in Water / Berthed
    for (const v of this.vessels) {
      const vx = (v.pos.x / 1200) * w;
      const vy = (v.pos.y / 800) * (seaHeight - 20) + 10;

      ctx.save();
      ctx.translate(vx, vy);

      // Vessel Hull Shape
      ctx.fillStyle = v.status === 'WORKING' ? '#0369a1' : v.status === 'BERTHING' ? '#d97706' : '#475569';
      ctx.beginPath();
      ctx.moveTo(0, -12);
      ctx.lineTo(60, -12);
      ctx.lineTo(75, 0);
      ctx.lineTo(60, 12);
      ctx.lineTo(0, 12);
      ctx.closePath();
      ctx.fill();

      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 1;
      ctx.stroke();

      // Vessel Name Label
      ctx.fillStyle = '#ffffff';
      ctx.font = '10px sans-serif';
      ctx.fillText(v.name, 5, 4);

      ctx.restore();
    }

    // 4. Draw Quay Cranes (Q01 - Q32)
    const craneWidth = w / 32;
    for (let i = 0; i < this.quayCranes.length; i++) {
      const qc = this.quayCranes[i];
      const qcx = i * craneWidth + 4;
      const qcy = seaHeight - 10;

      ctx.fillStyle = qc.status === 'FAULT' ? '#ef4444' : qc.status === 'LIFTING' ? '#f59e0b' : '#10b981';
      ctx.fillRect(qcx, qcy, 6, 18);

      // Trolley Boom Arm line into water
      ctx.strokeStyle = qc.status === 'FAULT' ? '#ef4444' : '#38bdf8';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(qcx + 3, qcy);
      ctx.lineTo(qcx + 3, qcy - qc.trolleyPosMeters * 0.7);
      ctx.stroke();
    }

    // 5. Draw Yard Blocks (T01 - T20)
    const yardStartY = seaHeight + 50;
    for (const yb of this.yardBlocks) {
      const ybx = (yb.pos.x / 1200) * w;
      const yby = yardStartY + (yb.pos.y / 800) * (h - yardStartY - 100);

      ctx.fillStyle = yb.status === 'CONGESTED' ? '#7f1d1d' : '#1e1b4b';
      ctx.fillRect(ybx, yby, 80, 45);

      ctx.strokeStyle = yb.status === 'CONGESTED' ? '#ef4444' : '#6366f1';
      ctx.lineWidth = 1;
      ctx.strokeRect(ybx, yby, 80, 45);

      ctx.fillStyle = '#a5b4fc';
      ctx.font = '9px "JetBrains Mono"';
      ctx.fillText(yb.id, ybx + 4, yby + 12);

      // Stack Density Bar
      ctx.fillStyle = '#312e81';
      ctx.fillRect(ybx + 4, yby + 20, 72, 6);

      ctx.fillStyle = yb.densityPct > 85 ? '#ef4444' : yb.densityPct > 70 ? '#f59e0b' : '#10b981';
      ctx.fillRect(ybx + 4, yby + 20, (72 * yb.densityPct) / 100, 6);
    }

    // 6. Draw Moving AGVs
    for (const agv of this.agvs) {
      const ax = (agv.pos.x / 1200) * w;
      const ay = yardStartY + (agv.pos.y / 800) * (h - yardStartY - 80);

      ctx.fillStyle = agv.state === 'FAULT' ? '#ef4444' : agv.state === 'CHARGING' ? '#06b6d4' : agv.payloadContainerId ? '#10b981' : '#3b82f6';
      ctx.beginPath();
      ctx.arc(ax, ay, 4.5, 0, Math.PI * 2);
      ctx.fill();

      // Heading indicator
      const hx = ax + Math.sin(agv.headingDeg * (Math.PI / 180)) * 8;
      const hy = ay - Math.cos(agv.headingDeg * (Math.PI / 180)) * 8;
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(ax, ay);
      ctx.lineTo(hx, hy);
      ctx.stroke();
    }
  }

  private init3DScene(): void {
    if (!this.canvas3dContainerRef) return;
    const container = this.canvas3dContainerRef.nativeElement;

    this.threeScene = new THREE.Scene();
    this.threeScene.background = new THREE.Color(0x06090e);

    const aspect = container.clientWidth / container.clientHeight;
    this.threeCamera = new THREE.PerspectiveCamera(45, aspect, 0.1, 2000);
    this.threeCamera.position.set(0, 300, 400);
    this.threeCamera.lookAt(0, 0, 0);

    // Lights
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    this.threeScene.add(ambientLight);

    const dirLight = new THREE.DirectionalLight(0x38bdf8, 1.2);
    dirLight.position.set(100, 200, 100);
    this.threeScene.add(dirLight);

    // Port Ground & Water
    const waterGeo = new THREE.PlaneGeometry(1200, 400);
    const waterMat = new THREE.MeshBasicMaterial({ color: 0x0a1628, side: THREE.DoubleSide });
    const waterMesh = new THREE.Mesh(waterGeo, waterMat);
    waterMesh.rotation.x = Math.PI / 2;
    waterMesh.position.set(0, 0, -200);
    this.threeScene.add(waterMesh);

    const quayGeo = new THREE.PlaneGeometry(1200, 500);
    const quayMat = new THREE.MeshBasicMaterial({ color: 0x1e293b, side: THREE.DoubleSide });
    const quayMesh = new THREE.Mesh(quayGeo, quayMat);
    quayMesh.rotation.x = Math.PI / 2;
    quayMesh.position.set(0, 0, 250);
    this.threeScene.add(quayMesh);

    // Renderer
    this.threeRenderer = new THREE.WebGLRenderer({ antialias: true });
    this.threeRenderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(this.threeRenderer.domElement);
  }

  private update3DScene(): void {
    if (!this.threeRenderer || !this.threeScene || !this.threeCamera) return;
    this.threeRenderer.render(this.threeScene, this.threeCamera);
  }

  public handleCanvasClick(event: MouseEvent): void {
    const canvas = this.canvas2dRef.nativeElement;
    const rect = canvas.getBoundingClientRect();
    const clickX = event.clientX - rect.left;
    const clickY = event.clientY - rect.top;

    // Check if clicked near an AGV
    const w = canvas.width;
    const h = canvas.height;
    const yardStartY = 160 + 50;

    for (const agv of this.agvs) {
      const ax = (agv.pos.x / 1200) * w;
      const ay = yardStartY + (agv.pos.y / 800) * (h - yardStartY - 80);
      const dist = Math.hypot(clickX - ax, clickY - ay);
      if (dist < 12) {
        this.selectedEntity.set(agv);
        this.selectedEntityType.set('AGV');
        return;
      }
    }

    // Default to first Quay Crane if clicked near quay
    if (clickY > 140 && clickY < 180) {
      const qIndex = Math.min(31, Math.floor((clickX / w) * 32));
      const qc = this.quayCranes[qIndex];
      if (qc) {
        this.selectedEntity.set(qc);
        this.selectedEntityType.set('CRANE');
        return;
      }
    }

    // Default to first vessel if clicked in water
    if (clickY < 140 && this.vessels.length > 0) {
      this.selectedEntity.set(this.vessels[0]);
      this.selectedEntityType.set('VESSEL');
    }
  }

  public getEntityName(): string {
    const e = this.selectedEntity();
    if (!e) return '';
    if ('name' in e && e.name) return e.name;
    return e.id;
  }

  public getEntityId(): string {
    const e = this.selectedEntity();
    return e?.id || '';
  }

  public getEntityStatus(): string {
    const e = this.selectedEntity();
    if (!e) return 'UNKNOWN';
    if ('status' in e) return e.status;
    if ('state' in e) return e.state;
    return 'UNKNOWN';
  }

  public asVessel(): Vessel {
    return this.selectedEntity() as Vessel;
  }

  public asCrane(): QuayCrane {
    return this.selectedEntity() as QuayCrane;
  }

  public asAGV(): AGV {
    return this.selectedEntity() as AGV;
  }

  public asYard(): YardBlock {
    return this.selectedEntity() as YardBlock;
  }
}
