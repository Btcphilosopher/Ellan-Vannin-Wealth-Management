import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PortSimulatorService } from './core/engine/port-simulator';

import { SpatialMapComponent } from './components/spatial-map/spatial-map';
import { BerthOpsComponent } from './components/berth-ops/berth-ops';
import { CraneTelemetryComponent } from './components/crane-telemetry/crane-telemetry';
import { AgvFleetComponent } from './components/agv-fleet/agv-fleet';
import { EnergyGridComponent } from './components/energy-grid/energy-grid';
import { PredictiveMaintComponent } from './components/predictive-maint/predictive-maint';
import { ScenarioLabComponent } from './components/scenario-lab/scenario-lab';
import { BunkeringWindowComponent } from './components/bunkering-window/bunkering-window';
import { TerminalConsoleComponent } from './components/terminal-console/terminal-console';

export type SubsystemTab =
  | 'SPATIAL_TWIN'
  | 'BERTH_OPS'
  | 'CRANE_TELEMETRY'
  | 'AGV_FLEET'
  | 'ENERGY_GRID'
  | 'PREDICTIVE_MAINT'
  | 'SCENARIO_LAB'
  | 'BUNKERING_WINDOW'
  | 'TERMINAL_CONSOLE';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    MatIconModule,
    SpatialMapComponent,
    BerthOpsComponent,
    CraneTelemetryComponent,
    AgvFleetComponent,
    EnergyGridComponent,
    PredictiveMaintComponent,
    ScenarioLabComponent,
    BunkeringWindowComponent,
    TerminalConsoleComponent,
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App {
  public simulator = inject(PortSimulatorService);
  public activeTab = signal<SubsystemTab>('SPATIAL_TWIN');

  public formatTime(timeMs: number): string {
    const date = new Date(timeMs);
    return date.toTimeString().split(' ')[0] + ' UTC+8';
  }

  public setTab(tab: SubsystemTab): void {
    this.activeTab.set(tab);
  }
}
