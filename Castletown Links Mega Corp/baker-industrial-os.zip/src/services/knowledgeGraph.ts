/**
 * BAKER INDUSTRIAL OS - INDUSTRIAL KNOWLEDGE GRAPH SERVICE
 * Connects physical asset entities to condition signals, failure modes, risks, work orders & financial impacts.
 */

import { KnowledgeNode, KnowledgeEdge } from '../types';

export class KnowledgeGraphService {
  public static getGraphData(): { nodes: KnowledgeNode[]; edges: KnowledgeEdge[] } {
    const nodes: KnowledgeNode[] = [
      {
        id: "c101",
        label: { en: "Booster Gas Compressor C-101", ar: "ضاغط الغاز المعزز C-101" },
        type: "ASSET",
        code: "C-101"
      },
      {
        id: "b101",
        label: { en: "Radial Bearing B-101", ar: "المحمل الشعاعي B-101" },
        type: "COMPONENT",
        code: "B-101"
      },
      {
        id: "vib101",
        label: { en: "Vibration Sensor VIB-101-X", ar: "مجس الاهتزاز VIB-101-X" },
        type: "SENSOR",
        code: "VIB-101-X"
      },
      {
        id: "fm_whirl",
        label: { en: "Sub-synchronous Oil Whirl Degradation", ar: "تدهور دوامة الزيت دون التزامنية" },
        type: "FAILURE_MODE"
      },
      {
        id: "risk_144k",
        label: { en: "Unplanned Shutdown Risk ($144,000 Expected Loss)", ar: "مخاطر التوقف غير التخطيطي (خسارة متوقعة ١٤٤٫٠٠٠$)" },
        type: "RISK"
      },
      {
        id: "wo_8842",
        label: { en: "Work Order WO-2026-8842 (Inspect Bearing & Lube)", ar: "أمر صيانة WO-2026-8842 (فحص المحمل والتشحيم)" },
        type: "WORK_ORDER",
        code: "WO-2026-8842"
      },
      {
        id: "econ_109k",
        label: { en: "Net Risk Reduction ($109,000 Value Saved)", ar: "تخفيض المخاطر الصافي (توفير بقيمة ١٠٩٫٠٠٠$)" },
        type: "ECONOMIC"
      }
    ];

    const edges: KnowledgeEdge[] = [
      { source: "c101", target: "b101", relation: { en: "houses component", ar: "يحتوي على المحمل" } },
      { source: "b101", target: "vib101", relation: { en: "monitored by tag", ar: "مراقب بواسطة المجس" } },
      { source: "vib101", target: "fm_whirl", relation: { en: "detects anomaly", ar: "يكتشف شذوذ الاهتزاز" } },
      { source: "fm_whirl", target: "risk_144k", relation: { en: "creates operational risk", ar: "ينشئ مخاطر تشغيلية" } },
      { source: "risk_144k", target: "wo_8842", relation: { en: "recommends action", ar: "يوصي بإجراء صيانة" } },
      { source: "wo_8842", target: "econ_109k", relation: { en: "delivers economic return", ar: "يحقق عائداً اقتصادياً" } }
    ];

    return { nodes, edges };
  }
}
