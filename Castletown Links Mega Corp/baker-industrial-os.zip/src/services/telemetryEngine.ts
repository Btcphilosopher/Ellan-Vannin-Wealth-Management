/**
 * BAKER INDUSTRIAL OS - REAL-TIME TELEMETRY & PHYSICS ENGINE
 * Simulates high-fidelity correlated sensor readings with OPC-UA quality flags and limit checking.
 */

import { TelemetrySignal, AlarmItem, AssetHealthDetail } from '../types';

export class TelemetryEngine {
  private static instance: TelemetryEngine;
  private currentSignals: Map<string, TelemetrySignal> = new Map();

  public static getInstance(): TelemetryEngine {
    if (!TelemetryEngine.instance) {
      TelemetryEngine.instance = new TelemetryEngine();
    }
    return TelemetryEngine.instance;
  }

  /**
   * Generates next telemetry tick with correlated physical changes.
   * e.g., if compressor load increases, vibration and temperature rise proportionally.
   */
  public generateNextTick(loadPercentage: number, currentTelemetry: TelemetrySignal[]): TelemetrySignal[] {
    const loadFactor = loadPercentage / 100.0;
    const timeNow = new Date().toISOString();

    return currentTelemetry.map(signal => {
      let baseVal = signal.value;
      const noise = (Math.random() - 0.5) * 0.1; // realistic Gaussian fluctuation

      if (signal.tag === "C101_VIB_RAD_X") {
        // Vibration increases non-linearly with load factor squared + bearing wear
        baseVal = 5.2 * Math.pow(loadFactor, 1.8) + (loadFactor > 0.85 ? 2.4 : 1.1) + noise;
      } else if (signal.tag === "C101_BEARING_TEMP_01") {
        // Bearing temp rises with load factor
        baseVal = 72.0 + (loadFactor * 25.0) + noise * 2;
      } else if (signal.tag === "C101_DISCHARGE_PRESS") {
        baseVal = 80.0 + (loadFactor * 42.0) + noise;
      } else if (signal.tag === "C101_GAS_FLOW_RATE") {
        baseVal = 165.0 * loadFactor + noise * 3;
      }

      const updatedVal = Math.max(0, Math.round(baseVal * 100) / 100);
      
      return {
        ...signal,
        timestamp: timeNow,
        value: updatedVal,
        quality: "GOOD"
      };
    });
  }

  /**
   * Evaluates alarms against limits.
   */
  public evaluateAlarms(telemetry: TelemetrySignal[]): AlarmItem[] {
    const newAlarms: AlarmItem[] = [];
    telemetry.forEach(t => {
      if (t.warning_high && t.value >= t.warning_high) {
        newAlarms.push({
          id: `alm-${t.tag}-${Date.now()}`,
          timestamp: t.timestamp,
          asset_id: t.asset_id,
          asset_code: "C-101",
          asset_name: { en: "Booster Centrifugal Gas Compressor C-101", ar: "ضاغط الغاز المعزز C-101" },
          tag: t.tag,
          severity: t.critical_high && t.value >= t.critical_high ? "CRITICAL" : "WARNING",
          title: {
            en: `High Limit Threshold Exceeded on ${t.tag} (${t.value} ${t.unit})`,
            ar: `تجاوز الحد الأعلى المقبول في ${t.tag} (${t.value} ${t.unit})`
          },
          description: {
            en: `Telemetry reading ${t.value} ${t.unit} surpassed ${t.warning_high} ${t.unit} warning limit.`,
            ar: `القيمة المقاسة ${t.value} ${t.unit} تجاوزت حد التحذير ${t.warning_high} ${t.unit}.`
          },
          value: t.value,
          threshold: t.warning_high,
          unit: t.unit,
          acknowledged: false
        });
      }
    });
    return newAlarms;
  }
}
