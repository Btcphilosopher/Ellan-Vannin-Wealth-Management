/**
 * BAKER INDUSTRIAL OS - RELIABILITY ENGINEERING ENGINE
 * Explicit mathematical formulations for MTBF, MTTR, Availability, Exponential/Weibull Distributions, FMEA.
 */

import { ReliabilityRecord } from '../types';

export class ReliabilityEngine {
  /**
   * Calculates Asset Availability: A = MTBF / (MTBF + MTTR)
   */
  public static calculateAvailability(mtbfHours: number, mttrHours: number): number {
    if (mtbfHours <= 0) return 0;
    const avail = (mtbfHours / (mtbfHours + mttrHours)) * 100;
    return Math.round(avail * 100) / 100;
  }

  /**
   * Exponential Reliability R(t) = exp(-lambda * t) where lambda = 1 / MTBF
   */
  public static calculateExponentialReliability(timeHours: number, mtbfHours: number): number {
    if (mtbfHours <= 0) return 0;
    const lambda = 1.0 / mtbfHours;
    const r = Math.exp(-lambda * timeHours);
    return Math.round(r * 10000) / 10000;
  }

  /**
   * Weibull Reliability R(t) = exp( - (t / scale_eta) ^ shape_beta )
   */
  public static calculateWeibullReliability(timeHours: number, shapeBeta: number, scaleEtaHours: number): number {
    if (scaleEtaHours <= 0) return 0;
    const exponent = Math.pow(timeHours / scaleEtaHours, shapeBeta);
    const r = Math.exp(-exponent);
    return Math.round(r * 10000) / 10000;
  }

  /**
   * Calculates FMEA Risk Priority Number (RPN) = Severity x Occurrence x Detection
   */
  public static calculateFMEARPN(severity: number, occurrence: number, detection: number): number {
    return Math.min(1000, Math.max(1, severity * occurrence * detection));
  }

  /**
   * Evaluates overall fleet availability and identifies top Bad Actors.
   */
  public static analyzeFleetReliability(records: ReliabilityRecord[]): {
    fleetAvailabilityPct: number;
    badActors: ReliabilityRecord[];
  } {
    if (records.length === 0) return { fleetAvailabilityPct: 100, badActors: [] };

    const totalAvail = records.reduce((acc, r) => acc + r.availability_pct, 0);
    const avgAvail = totalAvail / records.length;

    const sortedBadActors = [...records].sort((a, b) => b.fmea_rpn - a.fmea_rpn);

    return {
      fleetAvailabilityPct: Math.round(avgAvail * 100) / 100,
      badActors: sortedBadActors
    };
  }
}
