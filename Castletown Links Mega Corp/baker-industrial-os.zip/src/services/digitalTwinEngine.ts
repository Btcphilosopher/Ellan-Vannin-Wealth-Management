/**
 * BAKER INDUSTRIAL OS - DIGITAL TWIN ENGINE & SIMULATOR
 * Connects physical asset parameters to thermodynamic engineering models, financial risk, and emissions.
 */

import { DigitalTwinScenario } from '../types';

export class DigitalTwinEngine {
  /**
   * Simulates consequences of changing compressor load & operating conditions.
   */
  public static simulateCompressorScenario(
    loadPercentage: number,
    suctionPressBar: number,
    dischargePressBar: number,
    ambientTempC: number
  ): DigitalTwinScenario {
    const loadFactor = Math.max(0.5, Math.min(1.2, loadPercentage / 100.0));

    // Thermodynamic & mechanical model calculations
    const bearingTempC = ambientTempC + 52.0 * Math.pow(loadFactor, 1.5) + (loadFactor > 0.85 ? 8.5 : 2.0);
    const vibrationRmsMms = 4.2 * Math.pow(loadFactor, 1.8) + (loadFactor > 0.85 ? 2.4 : 1.0);

    // Efficiency penalty from vibration & off-design load
    const polytropicEff = Math.max(65.0, Math.min(88.5, 86.5 - 0.14 * Math.abs(loadPercentage - 85.0) - (vibrationRmsMms * 0.9)));

    // Power consumption (MW) = mass flow * head / efficiency
    const basePowerMW = 14.5 * loadFactor;
    const powerConsumptionMW = Math.round((basePowerMW * (88.5 / polytropicEff)) * 100) / 100;

    // Daily Emissions & Financial calculations
    const co2eEmissionsTpd = Math.round((powerConsumptionMW * 24.0 * 0.48) * 10) / 10;
    const powerCostUsd = powerConsumptionMW * 24.0 * 85.0; // $85 per MWh
    const carbonTaxUsd = co2eEmissionsTpd * 35.0; // $35 per tonne CO2e
    const dailyOperatingCostUsd = Math.round(powerCostUsd + carbonTaxUsd);

    // 30-day Failure Probability
    const failureRisk30d = Math.min(0.95, Math.max(0.05, 0.12 + Math.pow(vibrationRmsMms / 9.0, 2.5) * 0.65));

    return {
      load_percentage: loadPercentage,
      suction_pressure_bar: suctionPressBar,
      discharge_pressure_bar: dischargePressBar,
      ambient_temp_c: ambientTempC,
      bearing_temp_c: Math.round(bearingTempC * 10) / 10,
      vibration_rms_mms: Math.round(vibrationRmsMms * 100) / 100,
      polytropic_efficiency_pct: Math.round(polytropicEff * 10) / 10,
      power_consumption_mw: powerConsumptionMW,
      co2e_emissions_tpd: co2eEmissionsTpd,
      daily_operating_cost_usd: dailyOperatingCostUsd,
      failure_risk_30d: Math.round(failureRisk30d * 100) / 100
    };
  }
}
