import React, { useState } from 'react';
import { Bot, Send, ShieldCheck, FileText, Sparkles, RefreshCw, UserCheck } from 'lucide-react';
import { LocaleCode } from '../../types';
import { DICTIONARY, formatBilingualText } from '../../localization';

interface BakerCopilotProps {
  locale: LocaleCode;
  themeDark: boolean;
  onIssueWorkOrder: (assetCode: string) => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'copilot';
  text: string;
  provenance?: {
    model: string;
    confidence: number;
    data_timestamp: string;
    human_authorization_required: boolean;
    basis: string;
  };
}

export const BakerCopilot: React.FC<BakerCopilotProps> = ({ locale, themeDark, onIssueWorkOrder }) => {
  const isArabic = locale.startsWith('ar');

  const [inputQuery, setInputQuery] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg-1',
      sender: 'copilot',
      text: isArabic
        ? 'مرحباً بك في مساعد باكر الصناعي الذكي (Baker Industrial Copilot). يمكنك استفساري عن حالة الأصول مثل الضاغط C-101، أو معادلات الموثوقية FMECA، أو محاكاة التوأم الرقمي، أو طلب تحليل الأسباب الجذرية.'
        : 'Welcome to Baker Industrial Copilot. You can ask me about compressor C-101 vibration diagnostics, FMECA Weibull parameters, digital twin load optimization, or root cause failure modes.',
      provenance: {
        model: 'gemini-3.8-flash',
        confidence: 0.95,
        data_timestamp: new Date().toISOString(),
        human_authorization_required: true,
        basis: 'ISO 10816-3 Spectral FFT & Physics Twin Baseline'
      }
    }
  ]);

  const handleSend = async (queryText?: string) => {
    const textToSend = queryText || inputQuery;
    if (!textToSend.trim() || loading) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: textToSend
    };

    setMessages(prev => [...prev, userMsg]);
    if (!queryText) setInputQuery('');
    setLoading(true);

    try {
      const res = await fetch('/api/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: textToSend,
          locale,
          context: { asset: 'C-101', site: 'SA-MGS-ST04' }
        })
      });

      const data = await res.json();

      const copilotMsg: ChatMessage = {
        id: `cop-${Date.now()}`,
        sender: 'copilot',
        text: data.answer,
        provenance: data.provenance
      };

      setMessages(prev => [...prev, copilotMsg]);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const samplePrompts = isArabic ? [
    'ما هي تشخيصات الضاغط C-101 والإجراء الموصى به؟',
    'احسب الجاهزية التشغيلية للأسطول وحلل الفئات السيئة RPN',
    'محاكاة خفض حمولة الضاغط C-101 إلى ٨٠٪ وتأثير ذلك على الحرارة والانبعاثات'
  ] : [
    'What is the diagnostic status and engineering basis for Compressor C-101?',
    'Calculate fleet availability & explain the top FMEA bad actors.',
    'Simulate derating Compressor C-101 load to 80% and show impact on temperature and carbon emissions.'
  ];

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Top Banner */}
      <div className={`p-4 rounded-xl border flex justify-between items-center ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          <div className="w-10 h-10 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">{formatBilingualText(DICTIONARY.navCopilot, locale)}</h2>
            <p className="text-xs text-slate-400">{isArabic ? 'ذكاء اصطناعي هجين للموثوقية والهندسة الصناعية مع إسناد الدلائل وحظر التحكم المباشر' : 'Physics-grounded industrial Copilot with audit provenance & zero control authority.'}</p>
          </div>
        </div>
        <span className="px-3 py-1 rounded bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-mono font-bold">
          Gemini 3.8 Flash Industrial Engine
        </span>
      </div>

      {/* Suggested Prompts */}
      <div className="flex flex-wrap gap-2">
        {samplePrompts.map((prompt, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(prompt)}
            className={`px-3 py-1.5 rounded-lg border text-xs font-medium transition-all ${
              themeDark
                ? 'bg-slate-900 border-slate-800 hover:border-emerald-500 text-slate-300'
                : 'bg-white border-slate-200 hover:border-emerald-500 text-slate-700 shadow-sm'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 inline mr-1 text-emerald-400" />
            {prompt}
          </button>
        ))}
      </div>

      {/* Chat Conversation History */}
      <div className={`p-4 rounded-xl border space-y-4 min-h-[380px] max-h-[500px] overflow-y-auto ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
          >
            <div className={`max-w-2xl p-4 rounded-xl text-xs space-y-3 ${
              msg.sender === 'user'
                ? 'bg-emerald-600 text-white rounded-br-none'
                : themeDark
                  ? 'bg-slate-950 border border-slate-800 text-slate-200 rounded-bl-none'
                  : 'bg-slate-100 border border-slate-200 text-slate-900 rounded-bl-none'
            }`}>
              <p className="whitespace-pre-line leading-relaxed">{msg.text}</p>

              {/* Provenance Card for Copilot Responses */}
              {msg.provenance && (
                <div className="pt-3 border-t border-slate-800/80 text-[11px] font-mono space-y-1.5 text-slate-400">
                  <div className="flex items-center justify-between text-emerald-400 font-bold">
                    <span>Provenance: {msg.provenance.model}</span>
                    <span>Confidence: {(msg.provenance.confidence * 100).toFixed(0)}%</span>
                  </div>
                  <p>Basis: {msg.provenance.basis}</p>
                  {msg.provenance.human_authorization_required && (
                    <div className="p-2 rounded bg-amber-500/10 border border-amber-500/30 text-amber-300 flex items-center gap-1.5 mt-2 font-sans font-medium">
                      <ShieldCheck className="w-4 h-4 text-amber-400 flex-shrink-0" />
                      <span>{isArabic ? 'يتطلب تفويضاً بشرياً صريحاً قبل إجراء أي صيانة مادية.' : 'Requires explicit human authorization prior to physical work order approval.'}</span>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}

        {loading && (
          <div className="flex items-center space-x-2 text-xs font-mono text-emerald-400">
            <RefreshCw className="w-4 h-4 animate-spin" />
            <span>Analyzing Industrial Physics Knowledge Graph...</span>
          </div>
        )}
      </div>

      {/* Query Input Box */}
      <div className="flex gap-2">
        <input
          type="text"
          value={inputQuery}
          onChange={(e) => setInputQuery(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleSend()}
          placeholder={isArabic ? 'اكتب سؤالك الهندسي هنا...' : 'Ask Baker Industrial Copilot...'}
          className={`flex-1 p-3 text-xs rounded-xl border font-mono ${
            themeDark
              ? 'bg-slate-900 border-slate-800 text-slate-100 focus:border-emerald-500'
              : 'bg-white border-slate-300 text-slate-900 focus:border-emerald-600 shadow-sm'
          }`}
        />
        <button
          onClick={() => handleSend()}
          disabled={loading}
          className="px-5 py-3 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
        >
          <Send className="w-4 h-4" />
          {isArabic ? 'إرسال' : 'Send'}
        </button>
      </div>
    </div>
  );
};
