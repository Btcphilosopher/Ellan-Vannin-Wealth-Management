import React from 'react';
import { Share2, ArrowRight } from 'lucide-react';
import { KnowledgeGraphService } from '../../services/knowledgeGraph';
import { LocaleCode } from '../../types';
import { DICTIONARY, formatBilingualText } from '../../localization';

interface KnowledgeGraphViewProps {
  locale: LocaleCode;
  themeDark: boolean;
}

export const KnowledgeGraphView: React.FC<KnowledgeGraphViewProps> = ({ locale, themeDark }) => {
  const isArabic = locale.startsWith('ar');
  const graph = KnowledgeGraphService.getGraphData();

  return (
    <div className="space-y-6">
      <div className={`p-4 rounded-xl border flex justify-between items-center ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div>
          <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">{formatBilingualText(DICTIONARY.navKnowledgeGraph, locale)}</h2>
          <p className="text-xs text-slate-400">{isArabic ? 'رسم بياني موحد لربط المعدات بالحساسات، وأنماط العطل، والمخاطر المالية وأوامر الصيانة' : 'Connected Industrial Knowledge Graph mapping Asset -> Sensor -> Anomaly -> Risk -> WO -> Return.'}</p>
        </div>
        <span className="px-3 py-1 rounded bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs font-mono font-bold">
          7 Nodes / 6 Directed Edges
        </span>
      </div>

      <div className={`p-6 rounded-xl border ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-6 font-mono">
          {isArabic ? 'مسار العلاقات المباشرة المترابطة' : 'Directed Operational Graph Traversal'}
        </h3>

        <div className="space-y-4 max-w-4xl mx-auto">
          {graph.edges.map((edge, idx) => {
            const sourceNode = graph.nodes.find(n => n.id === edge.source);
            const targetNode = graph.nodes.find(n => n.id === edge.target);

            return (
              <div key={idx} className="p-4 rounded-xl border border-slate-800 bg-slate-950/60 flex flex-wrap items-center justify-between gap-4 text-xs font-mono">
                {/* Source Node */}
                <div className="p-3 rounded-lg border border-slate-700 bg-slate-900 min-w-[200px]">
                  <span className="text-[10px] text-emerald-400 font-bold block uppercase">{sourceNode?.type}</span>
                  <span className="font-bold text-slate-100 mt-1 block">{formatBilingualText(sourceNode?.label || { en: '', ar: '' }, locale)}</span>
                </div>

                {/* Edge Relation */}
                <div className="flex flex-col items-center">
                  <span className="text-[10px] text-amber-400 font-semibold mb-1">{formatBilingualText(edge.relation, locale)}</span>
                  <ArrowRight className="w-5 h-5 text-slate-500 rtl:rotate-180" />
                </div>

                {/* Target Node */}
                <div className="p-3 rounded-lg border border-slate-700 bg-slate-900 min-w-[200px]">
                  <span className="text-[10px] text-purple-400 font-bold block uppercase">{targetNode?.type}</span>
                  <span className="font-bold text-slate-100 mt-1 block">{formatBilingualText(targetNode?.label || { en: '', ar: '' }, locale)}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
