import React from 'react';
import { Leaf, ShieldCheck, AlertTriangle } from 'lucide-react';
import { EmissionRecord, LocaleCode } from '../../types';
import { DICTIONARY, formatBilingualText } from '../../localization';

interface EmissionsCentreProps {
  emissions: EmissionRecord[];
  locale: LocaleCode;
  themeDark: boolean;
}

export const EmissionsCentre: React.FC<EmissionsCentreProps> = ({ emissions, locale, themeDark }) => {
  const isArabic = locale.startsWith('ar');

  const totalCO2e = emissions.reduce((acc, e) => acc + (e.gas_type === 'CO2e' ? e.emission_rate_tpd : e.emission_rate_tpd * 28), 0);

  return (
    <div className="space-y-6">
      <div className={`p-4 rounded-xl border flex justify-between items-center ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div>
          <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">{formatBilingualText(DICTIONARY.navEmissions, locale)}</h2>
          <p className="text-xs text-slate-400">{isArabic ? 'إدارة الكربون والانبعاثات: احتراق التوربينات، الشاعل، واحتجاز الكربون CCUS' : 'GHG inventory, methane leak detection, OGMP 2.0 Level 5, & CCUS capture rates.'}</p>
        </div>
        <span className="px-3 py-1 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold">
          Total Fleet Emissions: {totalCO2e.toFixed(1)} tCO2e/day
        </span>
      </div>

      <div className="space-y-4">
        {emissions.map((e, idx) => (
          <div key={idx} className={`p-4 rounded-xl border space-y-3 ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-xs font-mono text-emerald-400 font-bold uppercase">{e.source_type} ({e.gas_type})</span>
              <span className="text-xs font-mono text-slate-400">{e.jurisdiction_standard}</span>
            </div>
            <h3 className="font-bold text-sm text-slate-100">{formatBilingualText(e.source_name, locale)}</h3>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs font-mono pt-2 border-t border-slate-800/60">
              <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Emission Rate</span>
                <span className="text-base font-bold text-emerald-400">{e.emission_rate_tpd} tpd</span>
              </div>
              <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Emission Factor</span>
                <span className="text-base font-bold text-slate-200">{e.emission_factor} {e.factor_unit}</span>
              </div>
              <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">CCUS Captured %</span>
                <span className="text-base font-bold text-sky-400">{e.ccus_captured_pct}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
