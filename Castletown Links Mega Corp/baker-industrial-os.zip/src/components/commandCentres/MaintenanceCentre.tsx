import React from 'react';
import { 
  Wrench, 
  CheckCircle2, 
  Clock, 
  UserCheck, 
  Box, 
  ShieldCheck, 
  ChevronRight,
  AlertTriangle
} from 'lucide-react';
import { WorkOrder, LocaleCode } from '../../types';
import { DICTIONARY, formatBilingualText, formatCurrencyUSD } from '../../localization';

interface MaintenanceCentreProps {
  workOrders: WorkOrder[];
  onApproveWorkOrder: (woId: string) => void;
  locale: LocaleCode;
  themeDark: boolean;
}

export const MaintenanceCentre: React.FC<MaintenanceCentreProps> = ({
  workOrders,
  onApproveWorkOrder,
  locale,
  themeDark
}) => {
  const isArabic = locale.startsWith('ar');

  const workflowSteps = [
    { key: 'DETECT', en: 'DETECT', ar: 'اكتشاف' },
    { key: 'CLASSIFY', en: 'CLASSIFY', ar: 'تصنيف' },
    { key: 'PRIORITIZE', en: 'PRIORITIZE', ar: 'أولوية' },
    { key: 'PLAN', en: 'PLAN', ar: 'تخطيط' },
    { key: 'APPROVED', en: 'APPROVED', ar: 'اعتماد' },
    { key: 'SCHEDULED', en: 'SCHEDULED', ar: 'جدولة' },
    { key: 'EXECUTING', en: 'EXECUTING', ar: 'تنفيذ' },
    { key: 'CLOSED', en: 'CLOSED', ar: 'إغلاق' }
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className={`p-4 rounded-xl border flex flex-wrap items-center justify-between gap-4 ${
        themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <div>
          <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">
            {formatBilingualText(DICTIONARY.navMaintenance, locale)}
          </h2>
          <p className="text-xs text-slate-400">
            {isArabic ? 'إدارة دورة حياة أوامر الصيانة، وتوزيع قطع الغيار وحوكمة الاعتمادات البشرية' : 'End-to-end Work Order lifecycle workflow with spares check & human approval.'}
          </p>
        </div>

        <div className="flex items-center gap-2 font-mono text-xs">
          <span className="px-3 py-1.5 rounded bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
            Work Orders Active: {workOrders.length}
          </span>
        </div>
      </div>

      {/* Industrial Workflow Pipeline Visualizer */}
      <div className={`p-4 rounded-xl border ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 font-mono">
          {isArabic ? 'مسار حوكمة وتدفق الصيانة (ISO 14224 / SAP EAM)' : 'Work Order Governance Pipeline'}
        </h3>
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 pb-1">
          {workflowSteps.map((step, idx) => (
            <React.Fragment key={step.key}>
              <div className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold flex items-center gap-1.5 ${
                step.key === 'APPROVED'
                  ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-900/40'
                  : 'bg-slate-800 text-slate-300 border border-slate-700'
              }`}>
                <span>{idx + 1}.</span>
                <span>{isArabic ? step.ar : step.en}</span>
              </div>
              {idx < workflowSteps.length - 1 && (
                <ChevronRight className="w-4 h-4 text-slate-600 hidden sm:inline-block" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>

      {/* Work Orders List */}
      <div className="space-y-4">
        {workOrders.map((wo) => {
          const isApproved = wo.wo_status === 'APPROVED' || wo.wo_status === 'EXECUTING' || wo.wo_status === 'CLOSED';

          return (
            <div
              key={wo.id}
              className={`p-5 rounded-xl border space-y-4 ${
                themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
              }`}
            >
              {/* Header */}
              <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-800 pb-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 font-mono text-xs font-bold">
                      {wo.wo_number}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-purple-500/20 text-purple-300 font-mono text-xs">
                      {wo.wo_type}
                    </span>
                    <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 font-mono text-xs font-bold">
                      {wo.priority} PRIORITY
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-slate-100 dark:text-slate-100 mt-2">
                    {formatBilingualText(wo.title, locale)}
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Target Asset: <strong className="text-slate-200 font-mono">{wo.asset_code}</strong> - {formatBilingualText(wo.asset_name, locale)}
                  </p>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right rtl:text-left font-mono">
                    <span className="text-[10px] text-slate-400 block">Est. Maintenance Cost</span>
                    <span className="text-sm font-extrabold text-slate-200">{formatCurrencyUSD(wo.estimated_cost_usd, locale)}</span>
                  </div>

                  {!isApproved ? (
                    <button
                      onClick={() => onApproveWorkOrder(wo.id)}
                      className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      {formatBilingualText(DICTIONARY.actionApprove, locale)}
                    </button>
                  ) : (
                    <span className="px-3 py-1.5 rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-mono text-xs font-bold flex items-center gap-1.5">
                      <CheckCircle2 className="w-4 h-4" />
                      Human Authorized
                    </span>
                  )}
                </div>
              </div>

              {/* Technician & Craft Details */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs font-mono">
                <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block flex items-center gap-1">
                    <UserCheck className="w-3 h-3 text-emerald-400" /> Assigned Technician
                  </span>
                  <span className="font-bold text-slate-200 mt-0.5 block">
                    {wo.assigned_technician ? formatBilingualText(wo.assigned_technician, locale) : 'Unassigned'}
                  </span>
                </div>

                <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block flex items-center gap-1">
                    <Clock className="w-3 h-3 text-sky-400" /> Estimated Duration
                  </span>
                  <span className="font-bold text-slate-200 mt-0.5 block">{wo.estimated_hours} Hours</span>
                </div>

                <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                  <span className="text-[10px] text-slate-500 block flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3 text-purple-400" /> Expected Risk Reduction
                  </span>
                  <span className="font-bold text-emerald-400 mt-0.5 block">
                    {formatCurrencyUSD(wo.risk_reduction_usd, locale)}
                  </span>
                </div>
              </div>

              {/* Required Spares Stock Validation */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 font-mono flex items-center gap-1.5">
                  <Box className="w-3.5 h-3.5 text-amber-400" />
                  {isArabic ? 'التحقق من توفر قطع الغيار المطلوبة' : 'Required Spares Stock Verification'}
                </h4>
                <div className="space-y-1.5">
                  {wo.required_spares.map((spare, idx) => (
                    <div key={idx} className="p-2 rounded bg-slate-950/30 border border-slate-800/80 flex items-center justify-between text-xs font-mono">
                      <div className="flex items-center gap-2">
                        <span className="text-slate-400 font-bold">{spare.part_number}</span>
                        <span className="text-slate-300 font-sans text-[11px]">- {formatBilingualText(spare.name, locale)}</span>
                      </div>
                      <div className="flex items-center gap-3">
                        <span>Qty: <strong>{spare.qty}</strong></span>
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                          spare.in_stock ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                        }`}>
                          {spare.in_stock ? (isArabic ? 'متوفر بالمستودع' : 'IN STOCK') : (isArabic ? 'طلب شراء مطلوب' : 'BACKORDER')}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
