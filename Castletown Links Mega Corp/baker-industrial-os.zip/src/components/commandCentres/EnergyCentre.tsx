import React from 'react';
import { Zap, DollarSign, Activity } from 'lucide-react';
import { EnergyMetric, LocaleCode } from '../../types';
import { DICTIONARY, formatBilingualText, formatCurrencyUSD } from '../../localization';

interface EnergyCentreProps {
  metrics: EnergyMetric[];
  locale: LocaleCode;
  themeDark: boolean;
}

export const EnergyCentre: React.FC<EnergyCentreProps> = ({ metrics, locale, themeDark }) => {
  const isArabic = locale.startsWith('ar');

  return (
    <div className="space-y-6">
      <div className={`p-4 rounded-xl border flex justify-between items-center ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div>
          <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">{formatBilingualText(DICTIONARY.navEnergy, locale)}</h2>
          <p className="text-xs text-slate-400">{isArabic ? 'إدارة وكثافة الطاقة: استهلاك غاز الوقود والكهرباء' : 'Fuel gas, electricity intensity, & hourly energy operational expenditure.'}</p>
        </div>
        <span className="px-3 py-1 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-mono font-bold">
          Energy Intensity: 24.5 kWh/BOE
        </span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {metrics.map((m, idx) => (
          <div key={idx} className={`p-4 rounded-xl border space-y-3 ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-xs font-mono text-amber-400 uppercase font-bold">{m.source_type}</span>
              <span className="text-xs font-mono text-slate-400">{m.energy_intensity_kwh_boe} kWh/BOE</span>
            </div>
            <h3 className="font-bold text-sm text-slate-100">{formatBilingualText(m.name, locale)}</h3>
            <div className="flex justify-between items-baseline font-mono pt-2 border-t border-slate-800/60">
              <span className="text-xl font-extrabold text-sky-400">{m.consumption_rate} {m.unit}</span>
              <span className="text-xs text-amber-400">{formatCurrencyUSD(m.cost_per_hour_usd, locale)} / hour</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
