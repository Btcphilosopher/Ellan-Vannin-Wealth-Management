import React from 'react';
import { 
  Building2, 
  MapPin, 
  TrendingUp, 
  AlertOctagon, 
  DollarSign, 
  Leaf, 
  ArrowUpRight,
  ShieldCheck
} from 'lucide-react';
import { Site, LocaleCode, UnitSystem } from '../../types';
import { DICTIONARY, formatBilingualText, formatNumber, formatCurrencyUSD } from '../../localization';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

interface ExecutiveCentreProps {
  sites: Site[];
  locale: LocaleCode;
  unitSystem: UnitSystem;
  themeDark: boolean;
  onSelectSite: (siteId: string) => void;
}

export const ExecutiveCentre: React.FC<ExecutiveCentreProps> = ({
  sites,
  locale,
  unitSystem,
  themeDark,
  onSelectSite
}) => {
  const isArabic = locale.startsWith('ar');

  const totalAssets = sites.reduce((acc, s) => acc + s.asset_count, 0);
  const totalAlarms = sites.reduce((acc, s) => acc + s.active_alarms_count, 0);
  const totalCapacity = sites.reduce((acc, s) => acc + s.production_capacity_mboed, 0);
  const totalCurrentProd = sites.reduce((acc, s) => acc + s.current_production_mboed, 0);
  const avgHealth = (sites.reduce((acc, s) => acc + s.overall_health, 0) / sites.length).toFixed(1);

  const chartData = sites.map(s => ({
    name: isArabic ? s.name.ar.split('-')[0].trim() : s.code,
    health: s.overall_health,
    capacity: s.production_capacity_mboed,
    actual: s.current_production_mboed
  }));

  return (
    <div className="space-y-6">
      {/* Top Banner Overview */}
      <div className={`p-5 rounded-xl border ${themeDark ? 'bg-slate-900/90 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-emerald-500 font-mono text-xs uppercase font-semibold">
              <Building2 className="w-4 h-4" />
              {isArabic ? 'نظام باكر المؤسسي العالمي' : 'Global Baker Enterprise Operating Model'}
            </div>
            <h2 className="text-xl font-bold mt-1 text-slate-100 dark:text-slate-100">
              {formatBilingualText(DICTIONARY.navExecutive, locale)}
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              {isArabic
                ? 'مراقبة الموثوقية الشاملة، والإنتاج، والانبعاثات والمخاطر عبر المواقع الخمسة الرئيسية'
                : 'Enterprise-level visibility across global oil & gas, LNG, compression, and petrochemical assets.'}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <span className="px-3 py-1.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-medium flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              ISO 55001 Asset Management Compliant
            </span>
          </div>
        </div>

        {/* Executive KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-6">
          <div className={`p-4 rounded-lg border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
            <span className="text-xs text-slate-400 font-medium block">{formatBilingualText(DICTIONARY.overallHealth, locale)}</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-2xl font-extrabold font-mono text-emerald-400">{avgHealth}%</span>
              <span className="text-xs text-emerald-500 flex items-center gap-0.5">
                <TrendingUp className="w-3.5 h-3.5" /> +1.2%
              </span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">Fleet Average (5 Global Sites)</p>
          </div>

          <div className={`p-4 rounded-lg border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
            <span className="text-xs text-slate-400 font-medium block">{formatBilingualText(DICTIONARY.productionRate, locale)}</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-2xl font-extrabold font-mono text-sky-400">{formatNumber(totalCurrentProd, locale, 1)}</span>
              <span className="text-xs text-slate-400 font-mono">/ {formatNumber(totalCapacity, locale, 0)} MBOED</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">95.2% Utilization Rate</p>
          </div>

          <div className={`p-4 rounded-lg border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
            <span className="text-xs text-slate-400 font-medium block">{formatBilingualText(DICTIONARY.economicRiskLoss, locale)}</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-2xl font-extrabold font-mono text-amber-400">{formatCurrencyUSD(144000, locale)}</span>
              <span className="text-xs text-amber-500 font-mono">High Risk (C-101)</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">Expected 30-Day Failure Loss</p>
          </div>

          <div className={`p-4 rounded-lg border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
            <span className="text-xs text-slate-400 font-medium block">{formatBilingualText(DICTIONARY.totalAssets, locale)}</span>
            <div className="flex items-baseline justify-between mt-2">
              <span className="text-2xl font-extrabold font-mono text-purple-400">{formatNumber(totalAssets, locale, 0)}</span>
              <span className="text-xs text-amber-400 font-mono">{totalAlarms} Alarms</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-1">100,000+ OPC-UA Sensors</p>
          </div>
        </div>
      </div>

      {/* Global Sites Grid */}
      <div>
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 font-mono">
          {isArabic ? 'المواقع الصناعية الخمسة الرئيسية' : 'Enterprise Regional Operational Sites'}
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sites.map((site) => (
            <div
              key={site.id}
              onClick={() => onSelectSite(site.id)}
              className={`p-4 rounded-xl border cursor-pointer transition-all hover:border-emerald-500/60 ${
                themeDark ? 'bg-slate-900 border-slate-800 hover:bg-slate-850' : 'bg-white border-slate-200 shadow-sm hover:shadow-md'
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-slate-400 font-mono">
                    <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                    <span>{site.code}</span>
                  </div>
                  <h4 className="font-bold text-sm text-slate-100 dark:text-slate-100 mt-1 line-clamp-1">
                    {formatBilingualText(site.name, locale)}
                  </h4>
                  <p className="text-xs text-slate-400 mt-0.5">{site.country}</p>
                </div>
                <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold ${
                  site.overall_health >= 90 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                }`}>
                  {site.overall_health}% Health
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2 mt-4 text-xs font-mono pt-3 border-t border-slate-800/60">
                <div>
                  <span className="text-[10px] text-slate-500 block">Production</span>
                  <span className="font-bold text-sky-400">{site.current_production_mboed} MBOED</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 block">Active Alarms</span>
                  <span className={`font-bold ${site.active_alarms_count > 0 ? 'text-amber-400' : 'text-slate-400'}`}>
                    {site.active_alarms_count}
                  </span>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between text-xs text-emerald-400 font-semibold">
                <span>{isArabic ? 'عرض تفاصيل الموقع' : 'Inspect Site Details'}</span>
                <ArrowUpRight className="w-4 h-4" />
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Health & Capacity Chart */}
      <div className={`p-5 rounded-xl border ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-4 font-mono">
          {isArabic ? 'صحة المواقع ومقارنة الطاقة الإنتاجية' : 'Site Asset Health vs Production Capacity'}
        </h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke={themeDark ? "#334155" : "#e2e8f0"} />
              <XAxis dataKey="name" stroke={themeDark ? "#94a3b8" : "#64748b"} />
              <YAxis yAxisId="left" stroke="#10b981" orientation="left" domain={[0, 100]} />
              <YAxis yAxisId="right" stroke="#0284c7" orientation="right" />
              <Tooltip contentStyle={{ backgroundColor: themeDark ? '#0f172a' : '#ffffff', borderColor: '#334155' }} />
              <Bar yAxisId="left" dataKey="health" fill="#10b981" name={isArabic ? 'الصحة (%)' : 'Health Score (%)'} radius={[4, 4, 0, 0]} />
              <Bar yAxisId="right" dataKey="actual" fill="#0284c7" name={isArabic ? 'الإنتاج (MBOED)' : 'Production (MBOED)'} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
