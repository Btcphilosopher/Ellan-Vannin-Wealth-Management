import React from 'react';
import { Truck, Box, AlertTriangle, ShieldCheck } from 'lucide-react';
import { SparePart, LocaleCode } from '../../types';
import { DICTIONARY, formatBilingualText, formatCurrencyUSD } from '../../localization';

interface SupplyChainCentreProps {
  spares: SparePart[];
  locale: LocaleCode;
  themeDark: boolean;
}

export const SupplyChainCentre: React.FC<SupplyChainCentreProps> = ({ spares, locale, themeDark }) => {
  const isArabic = locale.startsWith('ar');

  return (
    <div className="space-y-6">
      <div className={`p-4 rounded-xl border flex justify-between items-center ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div>
          <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">{formatBilingualText(DICTIONARY.navSupplyChain, locale)}</h2>
          <p className="text-xs text-slate-400">{isArabic ? 'إدارة قطع الغيار الحرجة والمستودعات وسلاسل الإمداد اللوجستية' : 'Critical rotating machinery spare parts inventory, reorder triggers, & lead-time management.'}</p>
        </div>
        <span className="px-3 py-1 rounded bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs font-mono font-bold">
          Dhahran & Jubail Hubs Connected
        </span>
      </div>

      <div className="space-y-4">
        {spares.map((sp) => (
          <div key={sp.id} className={`p-4 rounded-xl border space-y-3 ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-xs font-mono text-purple-400 font-bold">{sp.part_number}</span>
              <span className="text-xs font-mono text-slate-400">{sp.warehouse_location}</span>
            </div>
            <h3 className="font-bold text-sm text-slate-100">{formatBilingualText(sp.name, locale)}</h3>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono pt-2 border-t border-slate-800/60">
              <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Stock Qty</span>
                <span className="text-base font-bold text-emerald-400">{sp.stock_qty} (Reorder: {sp.reorder_point})</span>
              </div>
              <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Lead Time</span>
                <span className="text-base font-bold text-slate-200">{sp.lead_time_days} Days</span>
              </div>
              <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Unit Cost</span>
                <span className="text-base font-bold text-sky-400">{formatCurrencyUSD(sp.unit_cost_usd, locale)}</span>
              </div>
              <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Criticality</span>
                <span className="text-base font-bold text-amber-400">{sp.criticality}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
