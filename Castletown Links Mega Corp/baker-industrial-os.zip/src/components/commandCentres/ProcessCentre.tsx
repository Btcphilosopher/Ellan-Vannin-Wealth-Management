import React from 'react';
import { Sliders, Activity, ArrowRight, ShieldCheck } from 'lucide-react';
import { LocaleCode, UnitSystem } from '../../types';
import { DICTIONARY, formatBilingualText, formatEngineeringUnit } from '../../localization';

interface ProcessCentreProps {
  locale: LocaleCode;
  unitSystem: UnitSystem;
  themeDark: boolean;
}

export const ProcessCentre: React.FC<ProcessCentreProps> = ({ locale, unitSystem, themeDark }) => {
  const isArabic = locale.startsWith('ar');

  const processNodes = [
    { name: { en: "Gas Feed Wellhead", ar: "رأس بئر إمداد الغاز" }, press: "45.0 bar", temp: "38.0 °C" },
    { name: { en: "Inlet Scrubber Separator", ar: "فاصل عازل المدخل" }, press: "44.2 bar", temp: "36.5 °C" },
    { name: { en: "Booster Gas Compressor C-101", ar: "ضاغط الغاز المعزز C-101" }, press: "118.6 bar", temp: "94.2 °C", active: true },
    { name: { en: "Air Cooler Heat Exchanger", ar: "المبادل الحراري المبرد بالهواء" }, press: "117.8 bar", temp: "45.0 °C" },
    { name: { en: "Gas Trunkline Pipeline", ar: "خط أنابيب الغاز الرئيسي" }, press: "116.5 bar", temp: "42.0 °C" }
  ];

  return (
    <div className="space-y-6">
      <div className={`p-4 rounded-xl border flex justify-between items-center ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div>
          <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">{formatBilingualText(DICTIONARY.navProcess, locale)}</h2>
          <p className="text-xs text-slate-400">{isArabic ? 'تحسين العمليات والديناميكا الحرارية: مخطط التدفق P&ID وتوازن الكتلة والطاقة' : 'P&ID flow schematics, mass & energy balance solvers, & thermodynamic setpoint optimization.'}</p>
        </div>
        <span className="px-3 py-1 rounded bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-mono font-bold">
          Thermodynamic Solver: CONVERGED
        </span>
      </div>

      {/* P&ID Process Flow Schematic */}
      <div className={`p-5 rounded-xl border ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-6 font-mono">
          {isArabic ? 'مخطط تدفق العمليات الرئيسي (P&ID Process Flow)' : 'P&ID Process Flow Pipeline'}
        </h3>

        <div className="flex flex-wrap items-center justify-between gap-3 max-w-5xl mx-auto">
          {processNodes.map((node, idx) => (
            <React.Fragment key={idx}>
              <div className={`p-3.5 rounded-xl border text-xs font-mono space-y-1 text-center min-w-[150px] ${
                node.active 
                  ? 'border-emerald-500 bg-emerald-500/10 shadow-md shadow-emerald-900/30' 
                  : 'border-slate-800 bg-slate-950/60 text-slate-300'
              }`}>
                <span className="text-[10px] text-slate-400 block font-bold">Node 0{idx + 1}</span>
                <h4 className="font-bold text-slate-100 font-sans text-xs">{formatBilingualText(node.name, locale)}</h4>
                <div className="pt-2 text-[10px] text-slate-400 space-y-0.5 border-t border-slate-800/80 mt-2">
                  <div>Press: <strong className="text-sky-400">{node.press}</strong></div>
                  <div>Temp: <strong className="text-amber-400">{node.temp}</strong></div>
                </div>
              </div>
              {idx < processNodes.length - 1 && (
                <ArrowRight className="w-5 h-5 text-slate-600 hidden md:inline-block rtl:rotate-180" />
              )}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
};
