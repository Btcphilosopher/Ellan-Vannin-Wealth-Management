import React from 'react';
import { 
  BarChart3, 
  Calculator, 
  TrendingDown, 
  AlertOctagon, 
  FileSpreadsheet
} from 'lucide-react';
import { ReliabilityRecord, LocaleCode } from '../../types';
import { DICTIONARY, formatBilingualText, formatNumber } from '../../localization';
import { ReliabilityEngine } from '../../services/reliabilityEngine';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

interface ReliabilityCentreProps {
  records: ReliabilityRecord[];
  locale: LocaleCode;
  themeDark: boolean;
}

export const ReliabilityCentre: React.FC<ReliabilityCentreProps> = ({
  records,
  locale,
  themeDark
}) => {
  const isArabic = locale.startsWith('ar');

  const fleetAnalysis = ReliabilityEngine.analyzeFleetReliability(records);

  // Generate Weibull curve points for C-101
  const weibullPoints = Array.from({ length: 10 }).map((_, i) => {
    const hours = (i + 1) * 500; // 500 to 5000 hours
    const reliability = ReliabilityEngine.calculateWeibullReliability(hours, 2.15, 4800);
    return {
      hours: `${hours}h`,
      reliability: Math.round(reliability * 100)
    };
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className={`p-4 rounded-xl border flex flex-wrap items-center justify-between gap-4 ${
        themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <div>
          <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">
            {formatBilingualText(DICTIONARY.navReliability, locale)}
          </h2>
          <p className="text-xs text-slate-400">
            {isArabic ? 'تحليل الموثوقية والهندسة: معادلات الجاهزية والتوزيعات التكرارية للفشل' : 'RCM, FMECA RPN calculations, Weibull distributions, & bad actor pareto breakdown.'}
          </p>
        </div>

        <div className="flex items-center gap-3 font-mono text-xs">
          <div className="px-3 py-1.5 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400">
            Fleet Availability: <strong className="text-emerald-300 font-bold">{fleetAnalysis.fleetAvailabilityPct}%</strong>
          </div>
        </div>
      </div>

      {/* Engineering Equation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className={`p-4 rounded-xl border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
          <div className="flex items-center gap-2 text-xs font-mono text-emerald-400 font-semibold mb-1">
            <Calculator className="w-4 h-4" />
            Asset Availability Formula
          </div>
          <div className="p-2.5 rounded bg-slate-900 text-center font-mono text-slate-100 text-sm border border-slate-800 my-2">
            A = MTBF / (MTBF + MTTR)
          </div>
          <p className="text-[11px] text-slate-400">
            Compressor C-101: 4200h / (4200h + 14.5h) = <strong className="text-emerald-400">99.65%</strong>
          </p>
        </div>

        <div className={`p-4 rounded-xl border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
          <div className="flex items-center gap-2 text-xs font-mono text-sky-400 font-semibold mb-1">
            <Calculator className="w-4 h-4" />
            Exponential Reliability
          </div>
          <div className="p-2.5 rounded bg-slate-900 text-center font-mono text-slate-100 text-sm border border-slate-800 my-2">
            R(t) = exp(-λ · t)
          </div>
          <p className="text-[11px] text-slate-400">
            Constant failure rate λ = 1/MTBF assumption for random electronic components.
          </p>
        </div>

        <div className={`p-4 rounded-xl border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
          <div className="flex items-center gap-2 text-xs font-mono text-purple-400 font-semibold mb-1">
            <Calculator className="w-4 h-4" />
            Weibull Distribution
          </div>
          <div className="p-2.5 rounded bg-slate-900 text-center font-mono text-slate-100 text-sm border border-slate-800 my-2">
            R(t) = exp(-(t / η)^β)
          </div>
          <p className="text-[11px] text-slate-400">
            Shape parameter β = 2.15 (Wear-out phase), Scale parameter η = 4800h.
          </p>
        </div>
      </div>

      {/* Main Grid: Weibull Chart + Bad Actors Pareto List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weibull Reliability Survival Curve */}
        <div className={`p-4 rounded-xl border ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 font-mono">
            {isArabic ? 'منحنى بقاء الموثوقية (توزيع فايبول β=2.15)' : 'C-101 Weibull Survival Probability Curve'}
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={weibullPoints}>
                <CartesianGrid strokeDasharray="3 3" stroke={themeDark ? "#334155" : "#e2e8f0"} />
                <XAxis dataKey="hours" stroke={themeDark ? "#94a3b8" : "#64748b"} />
                <YAxis domain={[0, 100]} stroke={themeDark ? "#94a3b8" : "#64748b"} />
                <Tooltip contentStyle={{ backgroundColor: themeDark ? '#0f172a' : '#ffffff', borderColor: '#334155' }} />
                <Line type="monotone" dataKey="reliability" stroke="#a855f7" strokeWidth={2.5} dot={{ r: 4 }} name="Survival R(t) %" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bad Actors FMECA Table */}
        <div className={`p-4 rounded-xl border ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 font-mono flex items-center justify-between">
            <span>{isArabic ? 'تصنيف الفئات السيئة حسب مؤشر RPN' : 'Bad Actor Ranking (FMECA Risk Priority Number)'}</span>
            <AlertOctagon className="w-4 h-4 text-amber-400" />
          </h3>

          <div className="space-y-2">
            {records.map((rec) => (
              <div key={rec.asset_code} className="p-3 rounded border border-slate-800 bg-slate-950/40 flex items-center justify-between text-xs font-mono">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-full bg-slate-800 text-slate-300 font-bold flex items-center justify-center text-[10px]">
                      #{rec.bad_actor_rank}
                    </span>
                    <span className="font-bold text-slate-100">{rec.asset_code}</span>
                    <span className="text-slate-400 font-sans text-[11px]">- {formatBilingualText(rec.asset_name, locale)}</span>
                  </div>
                  <div className="mt-1 flex items-center gap-3 text-[10px] text-slate-400">
                    <span>MTBF: <strong>{rec.mtbf_hours}h</strong></span>
                    <span>MTTR: <strong>{rec.mttr_hours}h</strong></span>
                    <span>Availability: <strong className="text-emerald-400">{rec.availability_pct}%</strong></span>
                  </div>
                </div>

                <div className="text-right rtl:text-left">
                  <span className="text-[10px] text-slate-500 block">RPN Score</span>
                  <span className={`text-base font-extrabold ${rec.fmea_rpn >= 200 ? 'text-amber-400' : 'text-slate-300'}`}>
                    {rec.fmea_rpn}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
