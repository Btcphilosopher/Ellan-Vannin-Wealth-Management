import React, { useState } from 'react';
import { 
  ChevronRight, 
  ChevronDown, 
  Cpu, 
  AlertTriangle, 
  CheckCircle2, 
  Wrench, 
  ShieldAlert, 
  Clock,
  Layers,
  FileSpreadsheet
} from 'lucide-react';
import { FacilityNode, AssetHealthDetail, LocaleCode, UnitSystem } from '../../types';
import { DICTIONARY, formatBilingualText, formatCurrencyUSD } from '../../localization';

interface AssetCentreProps {
  hierarchy: FacilityNode;
  healthDetails: AssetHealthDetail[];
  locale: LocaleCode;
  unitSystem: UnitSystem;
  themeDark: boolean;
  onIssueWorkOrder: (assetCode: string) => void;
}

export const AssetCentre: React.FC<AssetCentreProps> = ({
  hierarchy,
  healthDetails,
  locale,
  unitSystem,
  themeDark,
  onIssueWorkOrder
}) => {
  const isArabic = locale.startsWith('ar');
  const [selectedAssetCode, setSelectedAssetCode] = useState<string>("C-101");
  const [expandedNodes, setExpandedNodes] = useState<Record<string, boolean>>({
    "ent-01": true,
    "reg-01": true,
    "cntry-sa": true,
    "site-sa-mgs": true,
    "plant-train-2": true,
  });

  const toggleExpand = (id: string) => {
    setExpandedNodes(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const selectedHealth = healthDetails.find(h => h.asset_code === selectedAssetCode) || healthDetails[0];

  const renderTreeNode = (node: FacilityNode, depth: number = 0) => {
    const isExpanded = expandedNodes[node.id];
    const hasChildren = node.children && node.children.length > 0;
    const isSelected = selectedAssetCode === node.code;

    return (
      <div key={node.id} className="text-xs font-mono">
        <div
          onClick={() => {
            if (hasChildren) toggleExpand(node.id);
            if (node.level === 'EQUIPMENT' || node.level === 'COMPONENT') {
              setSelectedAssetCode(node.code);
            }
          }}
          className={`flex items-center space-x-2 rtl:space-x-reverse py-1.5 px-2 rounded cursor-pointer transition-colors ${
            isSelected
              ? 'bg-emerald-500/20 text-emerald-400 font-bold border border-emerald-500/40'
              : themeDark
                ? 'hover:bg-slate-800 text-slate-300'
                : 'hover:bg-slate-200 text-slate-700'
          }`}
          style={{ paddingLeft: `${depth * 14 + 8}px`, paddingRight: `${depth * 14 + 8}px` }}
        >
          {hasChildren ? (
            isExpanded ? <ChevronDown className="w-3.5 h-3.5 text-slate-400" /> : <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          ) : (
            <span className="w-3.5 inline-block"></span>
          )}

          <Cpu className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />
          <span className="text-[11px] font-bold text-slate-200">{node.code}</span>
          <span className="text-slate-400 text-[11px] truncate">- {formatBilingualText(node.name, locale)}</span>

          {node.health_score !== undefined && (
            <span className={`ml-auto rtl:mr-auto text-[10px] px-1.5 py-0.2 rounded font-mono ${
              node.health_score >= 90 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
            }`}>
              {node.health_score}%
            </span>
          )}
        </div>

        {hasChildren && isExpanded && (
          <div className="space-y-0.5">
            {node.children!.map(child => renderTreeNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className={`p-4 rounded-xl border flex items-center justify-between ${
        themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <div>
          <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">
            {formatBilingualText(DICTIONARY.navAsset, locale)}
          </h2>
          <p className="text-xs text-slate-400">
            {isArabic ? 'هرمية الأصول الصناعية والتشخيص المتقدم وإدارة دورة الحياة' : 'Hierarchical asset tree, 360-degree health diagnostics, & vibration spectrum FFT.'}
          </p>
        </div>
        <span className="px-3 py-1 rounded bg-slate-800 text-slate-300 text-xs font-mono">
          ISO 14224 Equipment Taxonomy
        </span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Unlimited Depth Hierarchy Navigator */}
        <div className={`p-4 rounded-xl border ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 font-mono flex items-center justify-between">
            <span>{isArabic ? 'هيكلية الأصول المؤسسية' : 'Enterprise Asset Tree'}</span>
            <Layers className="w-3.5 h-3.5 text-slate-400" />
          </h3>
          <div className="max-h-[500px] overflow-y-auto pr-1">
            {renderTreeNode(hierarchy)}
          </div>
        </div>

        {/* Right: 360 Diagnostic Card for Selected Equipment */}
        <div className={`lg:col-span-2 p-5 rounded-xl border space-y-5 ${
          themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          {/* Header of selected asset */}
          <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-800 pb-4">
            <div>
              <span className="text-xs font-mono text-emerald-400 uppercase">360° Diagnostic Workbench</span>
              <h3 className="text-xl font-extrabold text-slate-100 font-mono mt-0.5">
                {selectedHealth.asset_code} - {formatBilingualText(selectedHealth.asset_name, locale)}
              </h3>
              <p className="text-xs text-slate-400 mt-1">Primary Failure Mode: {formatBilingualText(selectedHealth.primary_failure_mode, locale)}</p>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right rtl:text-left font-mono">
                <span className="text-[10px] text-slate-400 block">Health Index</span>
                <span className="text-2xl font-black text-amber-400">{selectedHealth.health_score}%</span>
              </div>
              <button
                onClick={() => onIssueWorkOrder(selectedHealth.asset_code)}
                className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
              >
                <Wrench className="w-4 h-4" />
                {formatBilingualText(DICTIONARY.actionCreateWorkOrder, locale)}
              </button>
            </div>
          </div>

          {/* Diagnostic Metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className={`p-3.5 rounded-lg border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
              <span className="text-xs text-slate-400 block font-medium">30-Day Failure Probability</span>
              <span className="text-xl font-extrabold text-amber-400 font-mono mt-1 block">
                {(selectedHealth.failure_probability_30d * 100).toFixed(0)}%
              </span>
              <span className="text-[10px] text-slate-500">Confidence: {(selectedHealth.confidence * 100).toFixed(0)}%</span>
            </div>

            <div className={`p-3.5 rounded-lg border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
              <span className="text-xs text-slate-400 block font-medium">Remaining Useful Life (RUL)</span>
              <span className="text-xl font-extrabold text-sky-400 font-mono mt-1 block">
                {selectedHealth.remaining_useful_life_days} Days
              </span>
              <span className="text-[10px] text-slate-500">Est. Shutdown: Oct 2026</span>
            </div>

            <div className={`p-3.5 rounded-lg border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
              <span className="text-xs text-slate-400 block font-medium">Financial Failure Risk</span>
              <span className="text-xl font-extrabold text-rose-400 font-mono mt-1 block">
                {formatCurrencyUSD(selectedHealth.risk_score_usd, locale)}
              </span>
              <span className="text-[10px] text-slate-500">Unplanned Downtime Cost</span>
            </div>
          </div>

          {/* Contributing Anomaly Factors */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 font-mono">
              {isArabic ? 'العوامل المساهمة في الانحراف' : 'Contributing Sensor Anomalies'}
            </h4>
            <div className="space-y-2">
              {selectedHealth.contributing_factors.map((factor, idx) => (
                <div key={idx} className="p-2.5 rounded border border-slate-800 bg-slate-950/40 flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                    <span className="font-semibold text-slate-200">{formatBilingualText(factor.factor, locale)}</span>
                    <span className="text-[10px] text-slate-500">({factor.sensor_tag})</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <span className="text-slate-300 font-bold">{factor.current_value}</span>
                    <span className="text-amber-400 font-bold">{factor.impact_pct > 0 ? `+${factor.impact_pct}%` : `${factor.impact_pct}%`}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Engineering Basis */}
          <div className="p-3.5 rounded-lg bg-emerald-500/10 border border-emerald-500/30 text-xs">
            <h4 className="font-bold text-emerald-400 font-mono flex items-center gap-1.5 mb-1">
              <FileSpreadsheet className="w-4 h-4" />
              {formatBilingualText(DICTIONARY.engineeringBasis, locale)}
            </h4>
            <p className="text-slate-300">{formatBilingualText(selectedHealth.engineering_basis, locale)}</p>
            <div className="mt-2 pt-2 border-t border-emerald-500/20 font-semibold text-emerald-300">
              {isArabic ? 'الإجراء الموصى به:' : 'Recommended Action:'} {formatBilingualText(selectedHealth.recommended_action, locale)}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
