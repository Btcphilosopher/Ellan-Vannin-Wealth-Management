import React, { useState } from 'react';
import { 
  Boxes, 
  Sliders, 
  Activity, 
  Zap, 
  Leaf, 
  DollarSign, 
  AlertTriangle,
  RefreshCw,
  TrendingUp,
  SlidersHorizontal
} from 'lucide-react';
import { LocaleCode, UnitSystem } from '../../types';
import { DICTIONARY, formatBilingualText, formatCurrencyUSD } from '../../localization';
import { DigitalTwinEngine } from '../../services/digitalTwinEngine';

interface DigitalTwinCentreProps {
  locale: LocaleCode;
  unitSystem: UnitSystem;
  themeDark: boolean;
}

export const DigitalTwinCentre: React.FC<DigitalTwinCentreProps> = ({
  locale,
  unitSystem,
  themeDark
}) => {
  const isArabic = locale.startsWith('ar');

  const [loadPct, setLoadPct] = useState<number>(88);
  const [suctionPress, setSuctionPress] = useState<number>(42.5);
  const [dischargePress, setDischargePress] = useState<number>(118.6);
  const [ambientTemp, setAmbientTemp] = useState<number>(42.0);

  // Run simulation engine
  const scenario = DigitalTwinEngine.simulateCompressorScenario(loadPct, suctionPress, dischargePress, ambientTemp);
  const baseline = DigitalTwinEngine.simulateCompressorScenario(88, 42.5, 118.6, 42.0);

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className={`p-4 rounded-xl border flex flex-wrap items-center justify-between gap-4 ${
        themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          <div className="w-10 h-10 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold">
            <Boxes className="w-5 h-5 animate-spin" style={{ animationDuration: '12s' }} />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">
              {formatBilingualText(DICTIONARY.navDigitalTwin, locale)}
            </h2>
            <p className="text-xs text-slate-400">
              {isArabic ? 'بيئة المحاكاة التوأمية الرقمية: الديناميكا الحرارية، استهلاك الطاقة، الانبعاثات والمخاطر' : 'Physics-grounded thermodynamic simulator for compressor load optimization.'}
            </p>
          </div>
        </div>

        <button
          onClick={() => {
            setLoadPct(88);
            setSuctionPress(42.5);
            setDischargePress(118.6);
            setAmbientTemp(42.0);
          }}
          className="px-3 py-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono flex items-center gap-1.5 transition-colors"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          Reset to Baseline
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Simulation Control Sliders */}
        <div className={`p-5 rounded-xl border space-y-6 ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono flex items-center gap-1.5">
            <SlidersHorizontal className="w-4 h-4 text-emerald-400" />
            {isArabic ? 'معايير المحاكاة والتحكم' : 'Interactive Simulation Controls'}
          </h3>

          {/* Load Slider */}
          <div>
            <div className="flex justify-between text-xs font-mono mb-2">
              <span className="text-slate-300 font-semibold">Compressor Operating Load</span>
              <span className="text-emerald-400 font-bold">{loadPct}%</span>
            </div>
            <input
              type="range"
              min="50"
              max="115"
              step="1"
              value={loadPct}
              onChange={(e) => setLoadPct(Number(e.target.value))}
              className="w-full accent-emerald-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
              <span>50% (Minimum Turndown)</span>
              <span>100% (MCR Design)</span>
              <span>115% (Overload)</span>
            </div>
          </div>

          {/* Ambient Temp Slider */}
          <div>
            <div className="flex justify-between text-xs font-mono mb-2">
              <span className="text-slate-300 font-semibold">Ambient Air Temperature</span>
              <span className="text-sky-400 font-bold">{ambientTemp} °C</span>
            </div>
            <input
              type="range"
              min="20"
              max="55"
              step="1"
              value={ambientTemp}
              onChange={(e) => setAmbientTemp(Number(e.target.value))}
              className="w-full accent-sky-500 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono mt-1">
              <span>20°C (Winter)</span>
              <span>42°C (Standard Gulf)</span>
              <span>55°C (Extreme Peak)</span>
            </div>
          </div>

          {/* Suction & Discharge Inputs */}
          <div className="grid grid-cols-2 gap-3 text-xs font-mono">
            <div>
              <label className="text-slate-400 block mb-1">Suction Press (bar)</label>
              <input
                type="number"
                value={suctionPress}
                onChange={(e) => setSuctionPress(Number(e.target.value))}
                className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-slate-100 font-bold"
              />
            </div>
            <div>
              <label className="text-slate-400 block mb-1">Discharge Press (bar)</label>
              <input
                type="number"
                value={dischargePress}
                onChange={(e) => setDischargePress(Number(e.target.value))}
                className="w-full p-2 rounded bg-slate-950 border border-slate-700 text-slate-100 font-bold"
              />
            </div>
          </div>
        </div>

        {/* Right: Simulated Physical & Economic Consequences */}
        <div className={`lg:col-span-2 p-5 rounded-xl border space-y-6 ${
          themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 font-mono">
            {isArabic ? 'النتائج الديناميكية الحرارية والاقتصادية المحاكاة' : 'Simulated Thermodynamic & Economic Consequences'}
          </h3>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className={`p-3.5 rounded-lg border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
              <span className="text-[11px] text-slate-400 block">Radial Bearing Temp</span>
              <span className={`text-xl font-extrabold font-mono mt-1 block ${scenario.bearing_temp_c >= 90 ? 'text-amber-400' : 'text-slate-100'}`}>
                {scenario.bearing_temp_c} °C
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                Δ Baseline: {(scenario.bearing_temp_c - baseline.bearing_temp_c).toFixed(1)} °C
              </span>
            </div>

            <div className={`p-3.5 rounded-lg border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
              <span className="text-[11px] text-slate-400 block">Radial Vibration RMS</span>
              <span className={`text-xl font-extrabold font-mono mt-1 block ${scenario.vibration_rms_mms >= 6.5 ? 'text-amber-400' : 'text-slate-100'}`}>
                {scenario.vibration_rms_mms} mm/s
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                Limit: 6.5 mm/s
              </span>
            </div>

            <div className={`p-3.5 rounded-lg border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
              <span className="text-[11px] text-slate-400 block">Polytropic Efficiency</span>
              <span className="text-xl font-extrabold text-emerald-400 font-mono mt-1 block">
                {scenario.polytropic_efficiency_pct}%
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                Optimum: 86.5%
              </span>
            </div>

            <div className={`p-3.5 rounded-lg border ${themeDark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'}`}>
              <span className="text-[11px] text-slate-400 block">30-Day Failure Risk</span>
              <span className={`text-xl font-extrabold font-mono mt-1 block ${scenario.failure_risk_30d >= 0.5 ? 'text-amber-400' : 'text-emerald-400'}`}>
                {(scenario.failure_risk_30d * 100).toFixed(0)}%
              </span>
              <span className="text-[10px] text-slate-500 font-mono">
                P(Failure)
              </span>
            </div>
          </div>

          {/* Environmental & Financial Comparison Table */}
          <div className="border border-slate-800 rounded-lg overflow-hidden text-xs font-mono">
            <div className="p-3 bg-slate-950 text-slate-300 font-bold border-b border-slate-800 flex justify-between">
              <span>Simulation Scenario vs Current Baseline Comparison</span>
              <span className="text-emerald-400">Live Mathematical Solver</span>
            </div>
            <div className="p-3 space-y-2 bg-slate-900/60">
              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">Power Consumption (MW)</span>
                <div className="space-x-4 rtl:space-x-reverse">
                  <span className="text-slate-400">Baseline: {baseline.power_consumption_mw} MW</span>
                  <span className="font-bold text-sky-400">Simulated: {scenario.power_consumption_mw} MW</span>
                </div>
              </div>

              <div className="flex justify-between py-1 border-b border-slate-800/60">
                <span className="text-slate-400">CO2e Carbon Emissions (tonnes/day)</span>
                <div className="space-x-4 rtl:space-x-reverse">
                  <span className="text-slate-400">Baseline: {baseline.co2e_emissions_tpd} tpd</span>
                  <span className="font-bold text-emerald-400">Simulated: {scenario.co2e_emissions_tpd} tpd</span>
                </div>
              </div>

              <div className="flex justify-between py-1">
                <span className="text-slate-400">Daily Total Operating Cost (Energy + Carbon Tax)</span>
                <div className="space-x-4 rtl:space-x-reverse">
                  <span className="text-slate-400">Baseline: {formatCurrencyUSD(baseline.daily_operating_cost_usd, locale)}</span>
                  <span className="font-bold text-amber-400">Simulated: {formatCurrencyUSD(scenario.daily_operating_cost_usd, locale)}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
