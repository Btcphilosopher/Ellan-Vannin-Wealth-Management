import React, { useState } from 'react';
import { 
  Activity, 
  AlertTriangle, 
  CheckCircle2, 
  Sliders, 
  Radio, 
  Clock, 
  Maximize2
} from 'lucide-react';
import { TelemetrySignal, AlarmItem, LocaleCode, UnitSystem } from '../../types';
import { DICTIONARY, formatBilingualText, formatEngineeringUnit } from '../../localization';
import { ResponsiveContainer, LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

interface OperationsCentreProps {
  telemetry: TelemetrySignal[];
  alarms: AlarmItem[];
  onAcknowledgeAlarm: (alarmId: string) => void;
  locale: LocaleCode;
  unitSystem: UnitSystem;
  themeDark: boolean;
}

export const OperationsCentre: React.FC<OperationsCentreProps> = ({
  telemetry,
  alarms,
  onAcknowledgeAlarm,
  locale,
  unitSystem,
  themeDark
}) => {
  const isArabic = locale.startsWith('ar');
  const [selectedTag, setSelectedTag] = useState<string>("C101_VIB_RAD_X");

  // Synthetic 10-point historical trend data for selected tag
  const historyData = Array.from({ length: 10 }).map((_, i) => {
    const time = new Date(Date.now() - (9 - i) * 60000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const signal = telemetry.find(t => t.tag === selectedTag);
    const baseVal = signal ? signal.value : 5.0;
    const noise = (Math.sin(i) * 0.4);
    return {
      time,
      value: Math.round((baseVal + noise) * 100) / 100,
      warning: signal?.warning_high || 6.5
    };
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className={`p-4 rounded-xl border flex flex-wrap items-center justify-between gap-4 ${
        themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
      }`}>
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          <div className="w-10 h-10 rounded-lg bg-sky-500/20 text-sky-400 flex items-center justify-center font-bold">
            <Radio className="w-5 h-5 animate-pulse" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">
              {formatBilingualText(DICTIONARY.navOperations, locale)}
            </h2>
            <p className="text-xs text-slate-400">
              {isArabic ? 'بث البيانات الحية وتنبيهات SCADA/DCS ومؤشرات جودة الإشارات' : 'Live OPC-UA telemetry feed, SCADA alarm console, & signal trend lines.'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono">
          <span className="px-2.5 py-1 rounded bg-emerald-500/20 text-emerald-400 font-semibold border border-emerald-500/30">
            OPC-UA: ACTIVE
          </span>
          <span className="px-2.5 py-1 rounded bg-slate-800 text-slate-300 border border-slate-700">
            Rate: 1000ms
          </span>
        </div>
      </div>

      {/* Main Grid: Telemetry Signals List + Trend Graph */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Telemetry Signals List */}
        <div className={`p-4 rounded-xl border ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
          <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-3 font-mono flex items-center justify-between">
            <span>{isArabic ? 'إشارات الاستشعار الحية (OPC-UA)' : 'Live Telemetry Signals'}</span>
            <span className="text-emerald-400 font-mono text-[10px]">100% GOOD</span>
          </h3>

          <div className="space-y-2 max-h-[420px] overflow-y-auto pr-1">
            {telemetry.map((t) => {
              const formattedUnit = formatEngineeringUnit(t.value, t.unit, unitSystem, locale);
              const isSelected = selectedTag === t.tag;
              const isWarning = t.warning_high && t.value >= t.warning_high;

              return (
                <div
                  key={t.tag}
                  onClick={() => setSelectedTag(t.tag)}
                  className={`p-3 rounded-lg border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-emerald-500 bg-emerald-500/10'
                      : themeDark
                        ? 'bg-slate-950/60 border-slate-800 hover:border-slate-700'
                        : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-mono text-slate-400 block">{t.tag}</span>
                      <h4 className="font-semibold text-xs text-slate-200 dark:text-slate-200 mt-0.5">
                        {formatBilingualText(t.name, locale)}
                      </h4>
                    </div>
                    <span className={`text-xs px-1.5 py-0.5 rounded font-mono font-bold ${
                      isWarning ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'
                    }`}>
                      {t.quality}
                    </span>
                  </div>

                  <div className="mt-2 flex items-baseline justify-between font-mono">
                    <span className={`text-base font-extrabold ${isWarning ? 'text-amber-400' : 'text-slate-100'}`}>
                      {formattedUnit.display}
                    </span>
                    <span className="text-[10px] text-slate-500">Source: {t.source}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right: Live Trend Graph */}
        <div className={`lg:col-span-2 p-4 rounded-xl border flex flex-col justify-between ${
          themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'
        }`}>
          <div>
            <div className="flex items-center justify-between mb-4">
              <div>
                <span className="text-xs font-mono text-emerald-400 uppercase">Selected Signal Trend</span>
                <h3 className="text-sm font-bold text-slate-100 font-mono">
                  {selectedTag} - {formatBilingualText(telemetry.find(t => t.tag === selectedTag)?.name || { en: '', ar: '' }, locale)}
                </h3>
              </div>
              <Maximize2 className="w-4 h-4 text-slate-400 cursor-pointer" />
            </div>

            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={historyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke={themeDark ? "#334155" : "#e2e8f0"} />
                  <XAxis dataKey="time" stroke={themeDark ? "#94a3b8" : "#64748b"} />
                  <YAxis stroke={themeDark ? "#94a3b8" : "#64748b"} />
                  <Tooltip contentStyle={{ backgroundColor: themeDark ? '#0f172a' : '#ffffff', borderColor: '#334155' }} />
                  <Line type="monotone" dataKey="value" stroke="#10b981" strokeWidth={2} dot={{ r: 3 }} name="Measured" />
                  <Line type="monotone" dataKey="warning" stroke="#f59e0b" strokeDasharray="4 4" strokeWidth={1.5} name="Warning High" />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="p-3 rounded bg-slate-950/40 border border-slate-800/60 mt-4 flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">Sampling Interval: 1000ms | Anti-aliasing Filter: Butterworth 4th order</span>
            <span className="text-emerald-400 font-semibold">IEEE 1451 Compliant</span>
          </div>
        </div>
      </div>

      {/* Active Alarms Console */}
      <div className={`p-4 rounded-xl border ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-3 font-mono flex items-center justify-between">
          <span>{isArabic ? 'وحدة إقرار تنبيهات SCADA النشطة' : 'Active SCADA/DCS Alarm Console'}</span>
          <span className="text-amber-400 font-mono text-xs">{alarms.length} Alarms Active</span>
        </h3>

        {alarms.length === 0 ? (
          <div className="p-6 text-center text-slate-400 text-xs font-mono">
            {isArabic ? 'لا توجد تنبيهات نشطة حالياً' : 'No active alarms. All process parameters within normal limits.'}
          </div>
        ) : (
          <div className="space-y-3">
            {alarms.map((alarm) => (
              <div
                key={alarm.id}
                className={`p-3.5 rounded-lg border flex flex-wrap items-center justify-between gap-3 ${
                  alarm.acknowledged
                    ? 'bg-slate-950/30 border-slate-800 text-slate-400'
                    : 'bg-amber-500/10 border-amber-500/30 text-amber-200'
                }`}
              >
                <div className="flex items-start space-x-3 rtl:space-x-reverse">
                  <AlertTriangle className={`w-5 h-5 flex-shrink-0 mt-0.5 ${alarm.acknowledged ? 'text-slate-500' : 'text-amber-400 animate-bounce'}`} />
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-xs font-bold text-amber-400">{alarm.asset_code}</span>
                      <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300">
                        {alarm.tag}
                      </span>
                    </div>
                    <h4 className="font-bold text-xs mt-1 text-slate-100">
                      {formatBilingualText(alarm.title, locale)}
                    </h4>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {formatBilingualText(alarm.description, locale)}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {alarm.acknowledged ? (
                    <span className="px-3 py-1 rounded bg-slate-800 text-slate-400 text-xs font-mono flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                      {isArabic ? 'تم الإقرار' : 'Acknowledged'}
                    </span>
                  ) : (
                    <button
                      onClick={() => onAcknowledgeAlarm(alarm.id)}
                      className="px-3 py-1.5 rounded bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs transition-colors shadow-sm"
                    >
                      {formatBilingualText(DICTIONARY.actionAcknowledge, locale)}
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
