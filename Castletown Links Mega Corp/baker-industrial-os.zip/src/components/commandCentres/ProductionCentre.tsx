import React from 'react';
import { Gauge, TrendingUp, AlertTriangle, Droplet } from 'lucide-react';
import { ProductionStream, LocaleCode } from '../../types';
import { DICTIONARY, formatBilingualText, formatNumber } from '../../localization';

interface ProductionCentreProps {
  streams: ProductionStream[];
  locale: LocaleCode;
  themeDark: boolean;
}

export const ProductionCentre: React.FC<ProductionCentreProps> = ({ streams, locale, themeDark }) => {
  const isArabic = locale.startsWith('ar');

  return (
    <div className="space-y-6">
      <div className={`p-4 rounded-xl border flex justify-between items-center ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div>
          <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">{formatBilingualText(DICTIONARY.navProduction, locale)}</h2>
          <p className="text-xs text-slate-400">{isArabic ? 'مراقبة معدلات الإنتاج ونسب الماء والغاز المحسوب' : 'Oil, Gas & Water throughput balance, Water Cut %, & Derating loss accounting.'}</p>
        </div>
        <span className="px-3 py-1 rounded bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-mono font-bold">
          428.5 MMscf/d Active
        </span>
      </div>

      <div className="space-y-4">
        {streams.map((stream) => (
          <div key={stream.id} className={`p-5 rounded-xl border space-y-4 ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex justify-between items-start border-b border-slate-800 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-100">{formatBilingualText(stream.stream_name, locale)}</h3>
                <span className="text-xs font-mono text-slate-400">Target Throughput: {stream.target_gas_mmscfd} MMscf/d</span>
              </div>
              <div className="text-right rtl:text-left font-mono">
                <span className="text-xs text-amber-400 block font-bold">Production Derating Loss</span>
                <span className="text-lg font-extrabold text-amber-400">-{stream.production_loss_mmscfd} MMscf/d</span>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-3 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Gas Flow Rate</span>
                <span className="text-base font-bold text-sky-400 mt-0.5 block">{stream.gas_rate_mmscfd} MMscf/d</span>
              </div>

              <div className="p-3 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Oil Production</span>
                <span className="text-base font-bold text-emerald-400 mt-0.5 block">{formatNumber(stream.oil_rate_bbld, locale, 0)} bbl/d</span>
              </div>

              <div className="p-3 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Water Cut %</span>
                <span className="text-base font-bold text-slate-200 mt-0.5 block">{stream.water_cut_pct}%</span>
              </div>

              <div className="p-3 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Gas-Oil Ratio (GOR)</span>
                <span className="text-base font-bold text-purple-400 mt-0.5 block">{stream.gor_scf_bbl} scf/bbl</span>
              </div>
            </div>

            {stream.loss_reason && (
              <div className="p-3 rounded bg-amber-500/10 border border-amber-500/30 text-xs font-mono text-amber-300 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 text-amber-400" />
                <span>Derating Cause: {formatBilingualText(stream.loss_reason, locale)}</span>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
