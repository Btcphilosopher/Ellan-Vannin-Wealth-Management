import React from 'react';
import { ShieldAlert, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { SafetyBarrier, LocaleCode } from '../../types';
import { DICTIONARY, formatBilingualText } from '../../localization';

interface SafetyCentreProps {
  barriers: SafetyBarrier[];
  locale: LocaleCode;
  themeDark: boolean;
}

export const SafetyCentre: React.FC<SafetyCentreProps> = ({ barriers, locale, themeDark }) => {
  const isArabic = locale.startsWith('ar');

  return (
    <div className="space-y-6">
      <div className={`p-4 rounded-xl border flex justify-between items-center ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div>
          <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">{formatBilingualText(DICTIONARY.navSafety, locale)}</h2>
          <p className="text-xs text-slate-400">{isArabic ? 'حواجز السلامة والمخاطر: مصفوفة Bowtie وإغلاق الطوارئ ESD ورخص العمل' : 'Bowtie safety barrier health, SIL rating, Permits-to-Work (PTW), & risk matrix.'}</p>
        </div>
        <span className="px-3 py-1 rounded bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-mono font-bold">
          Safety Integrity Level: SIL-3
        </span>
      </div>

      <div className="space-y-4">
        {barriers.map((b) => (
          <div key={b.id} className={`p-4 rounded-xl border space-y-3 ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200'}`}>
            <div className="flex justify-between items-center border-b border-slate-800 pb-2">
              <span className="text-xs font-mono text-purple-400 font-bold uppercase">{b.category}</span>
              <span className={`px-2 py-0.5 rounded text-xs font-mono font-bold ${
                b.status === 'HEALTHY' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
              }`}>
                {b.status}
              </span>
            </div>
            <h3 className="font-bold text-sm text-slate-100">{formatBilingualText(b.barrier_name, locale)}</h3>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono pt-2 border-t border-slate-800/60">
              <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Probability Score</span>
                <span className="text-base font-bold text-slate-200">{b.probability_score} / 5</span>
              </div>
              <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Consequence Score</span>
                <span className="text-base font-bold text-slate-200">{b.consequence_score} / 5</span>
              </div>
              <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Risk Rating</span>
                <span className="text-base font-bold text-amber-400">{b.risk_matrix_rating}</span>
              </div>
              <div className="p-2.5 rounded bg-slate-950/40 border border-slate-800">
                <span className="text-slate-500 block">Active Permits (PTW)</span>
                <span className="text-base font-bold text-sky-400">{b.active_permits_count}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
