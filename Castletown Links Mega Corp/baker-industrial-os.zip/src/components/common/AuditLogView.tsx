import React from 'react';
import { FileText, ShieldCheck, UserCheck, Clock } from 'lucide-react';
import { AuditLogEntry, LocaleCode } from '../../types';
import { DICTIONARY, formatBilingualText } from '../../localization';

interface AuditLogViewProps {
  logs: AuditLogEntry[];
  locale: LocaleCode;
  themeDark: boolean;
}

export const AuditLogView: React.FC<AuditLogViewProps> = ({ logs, locale, themeDark }) => {
  const isArabic = locale.startsWith('ar');

  return (
    <div className="space-y-6">
      <div className={`p-4 rounded-xl border flex justify-between items-center ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div>
          <h2 className="text-lg font-bold text-slate-100 dark:text-slate-100">{formatBilingualText(DICTIONARY.navAuditLog, locale)}</h2>
          <p className="text-xs text-slate-400">{isArabic ? 'سجل التدقيق الأمني والحوكمة غير القابل للتعديل' : 'Tamper-evident operational audit trail & human decision provenance.'}</p>
        </div>
        <span className="px-3 py-1 rounded bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-mono font-bold flex items-center gap-1.5">
          <ShieldCheck className="w-4 h-4" /> SHA-256 Immutable Audit Log
        </span>
      </div>

      <div className={`p-4 rounded-xl border ${themeDark ? 'bg-slate-900 border-slate-800' : 'bg-white border-slate-200 shadow-sm'}`}>
        <div className="space-y-3">
          {logs.map((log) => (
            <div key={log.id} className="p-3.5 rounded-lg border border-slate-800 bg-slate-950/40 space-y-2 text-xs font-mono">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800/60 pb-2">
                <div className="flex items-center gap-2">
                  <UserCheck className="w-4 h-4 text-emerald-400" />
                  <span className="font-bold text-slate-200">{log.user_name}</span>
                  <span className="text-[10px] text-slate-400">({log.user_role})</span>
                </div>
                <div className="flex items-center gap-2 text-slate-400 text-[10px]">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{new Date(log.timestamp).toLocaleString(locale)}</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    log.approval_status === 'HUMAN_APPROVED' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-sky-500/20 text-sky-400'
                  }`}>
                    {log.approval_status}
                  </span>
                </div>
              </div>

              <p className="text-slate-300 font-sans text-xs font-medium">{formatBilingualText(log.action, locale)}</p>

              <div className="text-[10px] text-slate-500 pt-1 flex justify-between">
                <span>Target Entity: {log.entity_type} ({log.entity_id})</span>
                <span>Provenance: {log.provenance}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
