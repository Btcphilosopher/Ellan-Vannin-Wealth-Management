import React from 'react';
import { Download, FileText, X, Printer, ShieldCheck } from 'lucide-react';
import { LocaleCode, Site, TelemetrySignal, WorkOrder } from '../../types';
import { DICTIONARY, formatBilingualText } from '../../localization';

interface BilingualReportExportProps {
  isOpen: boolean;
  onClose: () => void;
  locale: LocaleCode;
  sites: Site[];
  telemetry: TelemetrySignal[];
  workOrders: WorkOrder[];
}

export const BilingualReportExport: React.FC<BilingualReportExportProps> = ({
  isOpen,
  onClose,
  locale,
  sites,
  telemetry,
  workOrders
}) => {
  if (!isOpen) return null;

  const isArabic = locale.startsWith('ar');

  const downloadCSV = () => {
    let csvContent = "data:text/csv;charset=utf-8,";
    csvContent += "BAKER HUGHES INDUSTRIAL ENTERPRISE OS - AUDIT REPORT\n";
    csvContent += "Generated Timestamp," + new Date().toISOString() + "\n\n";

    csvContent += "SITE CODE,NAME (EN),NAME (AR),HEALTH %,PRODUCTION MBOED\n";
    sites.forEach(s => {
      csvContent += `${s.code},"${s.name.en}","${s.name.ar}",${s.overall_health},${s.current_production_mboed}\n`;
    });

    csvContent += "\nTELEMETRY TAG,NAME,VALUE,UNIT,QUALITY\n";
    telemetry.forEach(t => {
      csvContent += `${t.tag},"${t.name.en}",${t.value},${t.unit},${t.quality}\n`;
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `baker_industrial_report_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full p-6 text-slate-100 space-y-5 shadow-2xl">
        <div className="flex justify-between items-center border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs">
            <FileText className="w-4 h-4" />
            <span>{isArabic ? 'تقرير التدقيق الموحد ثنائي اللغة' : 'Bilingual Industrial Operational Audit Report'}</span>
          </div>
          <button onClick={onClose} className="p-1 rounded hover:bg-slate-800 text-slate-400">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-3 text-xs text-slate-300 font-sans leading-relaxed">
          <p>
            {isArabic
              ? 'يحتوي هذا التقرير على السجل الكامل للأصول ومؤشرات الجاهزية ومحاكاة التوأم الرقمي وسجلات التدقيق غير القابلة للتعديل المعقودة وفقاً لمعايير ISO 55001 و ISO 14224.'
              : 'This export bundle includes complete site health indices, live OPC-UA telemetry readings, work order approvals, and immutable audit logs.'}
          </p>

          <div className="p-3 rounded bg-slate-950/60 border border-slate-800 font-mono text-xs space-y-1 text-slate-400">
            <div>Global Sites: <strong className="text-slate-200">{sites.length} Active</strong></div>
            <div>Telemetry Signals: <strong className="text-emerald-400">{telemetry.length} Logged (100% Good)</strong></div>
            <div>Work Orders Backlog: <strong className="text-amber-400">{workOrders.length} Issued</strong></div>
          </div>
        </div>

        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-800">
          <button
            onClick={downloadCSV}
            className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            {isArabic ? 'تنزيل ملف CSV' : 'Export CSV Audit Bundle'}
          </button>

          <button
            onClick={handlePrint}
            className="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-all flex items-center gap-1.5"
          >
            <Printer className="w-4 h-4" />
            {isArabic ? 'طباعة التقرير' : 'Print Bilingual PDF'}
          </button>
        </div>
      </div>
    </div>
  );
};
