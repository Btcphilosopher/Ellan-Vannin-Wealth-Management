import React from 'react';
import { 
  BarChart3, 
  Activity, 
  Cpu, 
  Wrench, 
  Sliders, 
  Boxes, 
  Gauge, 
  Zap, 
  Leaf, 
  ShieldAlert, 
  Truck, 
  Bot, 
  Share2, 
  FileText,
  Building2
} from 'lucide-react';
import { LocaleCode } from '../../types';
import { DICTIONARY, formatBilingualText } from '../../localization';

export type CommandCentreId = 
  | 'executive'
  | 'operations'
  | 'asset'
  | 'reliability'
  | 'maintenance'
  | 'process'
  | 'digitalTwin'
  | 'production'
  | 'energy'
  | 'emissions'
  | 'safety'
  | 'supplyChain'
  | 'copilot'
  | 'knowledgeGraph'
  | 'auditLog';

interface SidebarProps {
  activeTab: CommandCentreId;
  setActiveTab: (tab: CommandCentreId) => void;
  locale: LocaleCode;
  themeDark: boolean;
  activeAlarmsCount: number;
  workOrdersCount: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  locale,
  themeDark,
  activeAlarmsCount,
  workOrdersCount
}) => {
  const menuItems: { id: CommandCentreId; label: keyof typeof DICTIONARY; icon: React.ReactNode; badge?: number; highlight?: boolean }[] = [
    { id: 'executive', label: 'navExecutive', icon: <Building2 className="w-4 h-4" /> },
    { id: 'operations', label: 'navOperations', icon: <Activity className="w-4 h-4" />, badge: activeAlarmsCount },
    { id: 'asset', label: 'navAsset', icon: <Cpu className="w-4 h-4" /> },
    { id: 'reliability', label: 'navReliability', icon: <BarChart3 className="w-4 h-4" /> },
    { id: 'maintenance', label: 'navMaintenance', icon: <Wrench className="w-4 h-4" />, badge: workOrdersCount },
    { id: 'process', label: 'navProcess', icon: <Sliders className="w-4 h-4" /> },
    { id: 'digitalTwin', label: 'navDigitalTwin', icon: <Boxes className="w-4 h-4" />, highlight: true },
    { id: 'production', label: 'navProduction', icon: <Gauge className="w-4 h-4" /> },
    { id: 'energy', label: 'navEnergy', icon: <Zap className="w-4 h-4" /> },
    { id: 'emissions', label: 'navEmissions', icon: <Leaf className="w-4 h-4" /> },
    { id: 'safety', label: 'navSafety', icon: <ShieldAlert className="w-4 h-4" /> },
    { id: 'supplyChain', label: 'navSupplyChain', icon: <Truck className="w-4 h-4" /> },
    { id: 'copilot', label: 'navCopilot', icon: <Bot className="w-4 h-4 text-emerald-400" />, highlight: true },
    { id: 'knowledgeGraph', label: 'navKnowledgeGraph', icon: <Share2 className="w-4 h-4" /> },
    { id: 'auditLog', label: 'navAuditLog', icon: <FileText className="w-4 h-4" /> },
  ];

  return (
    <aside className={`w-64 flex-shrink-0 border-r ${themeDark ? 'bg-slate-900 border-slate-800 text-slate-300' : 'bg-slate-50 border-slate-200 text-slate-700'} min-h-[calc(100vh-80px)] p-2 transition-colors`}>
      <div className="text-[10px] font-mono uppercase tracking-wider text-slate-400 px-3 py-2 font-semibold">
        {locale.startsWith('ar') ? 'مراكز التحكم الموحدة' : 'Unified Command Centres'}
      </div>

      <nav className="space-y-1 text-xs">
        {menuItems.map((item) => {
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-md font-medium transition-all ${
                isActive
                  ? themeDark
                    ? 'bg-emerald-600 text-white font-semibold shadow-sm'
                    : 'bg-emerald-600 text-white font-semibold shadow-sm'
                  : themeDark
                    ? 'hover:bg-slate-800 text-slate-300'
                    : 'hover:bg-slate-200 text-slate-700'
              } ${item.highlight && !isActive ? 'border border-emerald-500/30 text-emerald-400' : ''}`}
            >
              <div className="flex items-center space-x-2.5 rtl:space-x-reverse truncate">
                {item.icon}
                <span className="truncate">{formatBilingualText(DICTIONARY[item.label], locale)}</span>
              </div>
              {item.badge !== undefined && item.badge > 0 && (
                <span className={`px-1.5 py-0.5 text-[10px] font-bold rounded-full font-mono ${isActive ? 'bg-white text-emerald-800' : 'bg-amber-500 text-slate-950'}`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>
    </aside>
  );
};
