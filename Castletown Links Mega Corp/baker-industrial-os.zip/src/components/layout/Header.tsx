import React from 'react';
import { 
  Globe, 
  ShieldCheck, 
  Activity, 
  Search, 
  Moon, 
  Sun, 
  User, 
  Sliders,
  AlertTriangle
} from 'lucide-react';
import { LocaleCode, UnitSystem, UserRole, BilingualText } from '../../types';
import { DICTIONARY, formatBilingualText, getDirection } from '../../localization';

interface HeaderProps {
  locale: LocaleCode;
  setLocale: (loc: LocaleCode) => void;
  unitSystem: UnitSystem;
  setUnitSystem: (sys: UnitSystem) => void;
  persona: UserRole;
  setPersona: (p: UserRole) => void;
  themeDark: boolean;
  setThemeDark: (dark: boolean) => void;
  searchQuery: string;
  setSearchQuery: (q: string) => void;
  activeAlarmsCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  locale,
  setLocale,
  unitSystem,
  setUnitSystem,
  persona,
  setPersona,
  themeDark,
  setThemeDark,
  searchQuery,
  setSearchQuery,
  activeAlarmsCount
}) => {
  const isArabic = locale.startsWith('ar');

  return (
    <header className={`border-b ${themeDark ? 'bg-slate-900 border-slate-800 text-slate-100' : 'bg-white border-slate-200 text-slate-900'} sticky top-0 z-50 transition-colors`}>
      {/* Top Banner Status Bar */}
      <div className={`px-4 py-1 flex items-center justify-between text-xs font-mono border-b ${themeDark ? 'bg-slate-950/80 border-slate-800/80 text-slate-400' : 'bg-slate-100 border-slate-200 text-slate-600'}`}>
        <div className="flex items-center space-x-4 rtl:space-x-reverse">
          <span className="flex items-center gap-1.5 text-emerald-500 font-semibold">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            {formatBilingualText(DICTIONARY.dataQualityGood, locale)}
          </span>
          <span className="hidden md:inline-block text-slate-500">|</span>
          <span className="hidden md:flex items-center gap-1 text-sky-400">
            <ShieldCheck className="w-3.5 h-3.5" />
            OT Boundary: READ-ONLY (SIS / DCS Protected)
          </span>
        </div>
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          <span className="text-amber-400 font-medium flex items-center gap-1">
            <AlertTriangle className="w-3.5 h-3.5" />
            Active Alarms: <strong className="px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 font-bold">{activeAlarmsCount}</strong>
          </span>
          <span>•</span>
          <span>Locale: <strong className="text-slate-200">{locale}</strong> ({getDirection(locale).toUpperCase()})</span>
        </div>
      </div>

      {/* Main Header Controls */}
      <div className="px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        {/* Brand Logo & Title */}
        <div className="flex items-center space-x-3 rtl:space-x-reverse">
          <div className="w-9 h-9 rounded-lg bg-emerald-600 flex items-center justify-center text-white font-bold tracking-wider shadow-md shadow-emerald-900/30">
            BH
          </div>
          <div>
            <h1 className="text-base font-bold tracking-tight leading-none text-emerald-500">
              {formatBilingualText(DICTIONARY.appTitle, locale)}
            </h1>
            <p className="text-xs text-slate-400 mt-0.5 font-sans">
              {formatBilingualText(DICTIONARY.appSubtitle, locale)}
            </p>
          </div>
        </div>

        {/* Global Bilingual Search */}
        <div className="flex-1 max-w-xl mx-2 min-w-[260px]">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 rtl:right-3 rtl:left-auto top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={formatBilingualText(DICTIONARY.searchPlaceholder, locale)}
              className={`w-full pl-9 rtl:pr-9 rtl:pl-3 pr-3 py-1.5 text-xs rounded-md border font-mono transition-all ${
                themeDark 
                  ? 'bg-slate-950 border-slate-700 text-slate-100 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500' 
                  : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-emerald-600'
              }`}
            />
          </div>
        </div>

        {/* Controls: Locale, Units, Persona, Theme */}
        <div className="flex items-center space-x-2 rtl:space-x-reverse text-xs">
          {/* Language Selector */}
          <div className="flex items-center gap-1">
            <Globe className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={locale}
              onChange={(e) => setLocale(e.target.value as LocaleCode)}
              className={`py-1 px-2 rounded border font-mono ${themeDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300'}`}
            >
              <option value="en-US">English (en-US)</option>
              <option value="en-GB">English (en-GB)</option>
              <option value="ar-SA">العربية - السعودية (ar-SA)</option>
              <option value="ar-AE">العربية - الإمارات (ar-AE)</option>
              <option value="ar-QA">العربية - قطر (ar-QA)</option>
              <option value="ar-KW">العربية - الكويت (ar-KW)</option>
              <option value="ar-IQ">العربية - العراق (ar-IQ)</option>
              <option value="ar-OM">العربية - عُمان (ar-OM)</option>
            </select>
          </div>

          {/* Unit System */}
          <div className="flex items-center gap-1">
            <Sliders className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={unitSystem}
              onChange={(e) => setUnitSystem(e.target.value as UnitSystem)}
              className={`py-1 px-2 rounded border font-mono ${themeDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300'}`}
            >
              <option value="SI">SI (bar, °C, kg/s)</option>
              <option value="Imperial">Imperial (psi, °F)</option>
              <option value="Oilfield">Oilfield (bbl/d, MMscf/d)</option>
            </select>
          </div>

          {/* Persona Role */}
          <div className="hidden lg:flex items-center gap-1">
            <User className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={persona}
              onChange={(e) => setPersona(e.target.value as UserRole)}
              className={`py-1 px-2 rounded border font-mono ${themeDark ? 'bg-slate-800 border-slate-700 text-slate-200' : 'bg-white border-slate-300'}`}
            >
              <option value="Engineer">Engineer / مهندس</option>
              <option value="ReliabilityEngineer">Reliability / موثوقية</option>
              <option value="MaintenancePlanner">Maintenance / صيانة</option>
              <option value="Operator">Operator / مشغل</option>
              <option value="Executive">Executive / تنفيذي</option>
              <option value="HSEManager">HSE / سلامة</option>
            </select>
          </div>

          {/* Theme Toggle */}
          <button
            onClick={() => setThemeDark(!themeDark)}
            className={`p-1.5 rounded border transition-colors ${themeDark ? 'bg-slate-800 border-slate-700 text-amber-400 hover:bg-slate-700' : 'bg-slate-100 border-slate-300 text-slate-700 hover:bg-slate-200'}`}
            title={formatBilingualText(themeDark ? DICTIONARY.lightStandard : DICTIONARY.darkControlRoom, locale)}
          >
            {themeDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </header>
  );
};
