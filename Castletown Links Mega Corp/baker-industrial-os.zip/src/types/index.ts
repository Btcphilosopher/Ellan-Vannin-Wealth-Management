/**
 * BAKER INDUSTRIAL OS - CANONICAL ENTERPRISE INDUSTRIAL MODEL
 * Strongly-typed domain definitions matching industrial standards (ISO 14224, OPC-UA, ISA-95)
 */

export type LocaleCode = 
  | 'en-US' | 'en-GB' 
  | 'ar-SA' | 'ar-AE' | 'ar-QA' | 'ar-KW' | 'ar-IQ' | 'ar-OM' | 'ar-BH' | 'ar-EG';

export type TextDirection = 'ltr' | 'rtl';

export type UnitSystem = 'SI' | 'Imperial' | 'USCustomary' | 'Oilfield';

export interface BilingualText {
  en: string;
  ar: string;
}

export type AssetCategory = 
  | 'rotating' 
  | 'static' 
  | 'pipeline' 
  | 'electrical' 
  | 'instrumentation' 
  | 'well' 
  | 'power';

export type AssetType = 
  | 'compressor' | 'pump' | 'turbine' | 'motor' | 'gearbox' | 'fan' | 'blower' | 'generator'
  | 'vessel' | 'separator' | 'exchanger' | 'reactor' | 'column' | 'tank' | 'furnace'
  | 'pipeline' | 'valve' | 'pump_station' | 'compressor_station' | 'meter'
  | 'transformer' | 'switchgear' | 'breaker'
  | 'pressure_tx' | 'temp_tx' | 'flow_tx' | 'level_tx' | 'vibration_sensor'
  | 'well' | 'esp' | 'casing' | 'tubing'
  | 'hrsg' | 'boiler';

export type ConditionState = 'NORMAL' | 'WATCH' | 'DEGRADED' | 'WARNING' | 'CRITICAL' | 'FAILED';

export type TelemetryQuality = 'GOOD' | 'BAD' | 'UNCERTAIN' | 'STALE' | 'MISSING' | 'OUT_OF_RANGE' | 'MANUAL' | 'ESTIMATED';

export type UserRole = 
  | 'Operator' 
  | 'Engineer' 
  | 'ReliabilityEngineer' 
  | 'MaintenancePlanner' 
  | 'MaintenanceManager' 
  | 'ProductionEngineer' 
  | 'ProcessEngineer' 
  | 'HSEManager' 
  | 'SupplyChainManager' 
  | 'PlantManager' 
  | 'SiteManager' 
  | 'Executive' 
  | 'Administrator' 
  | 'Auditor';

export interface BaseEntity {
  id: string;
  tenant_id: string;
  created_at: string;
  updated_at: string;
  created_by: string;
  updated_by: string;
  version: number;
  status: 'ACTIVE' | 'ARCHIVED' | 'MAINTENANCE';
}

export interface Site extends BaseEntity {
  name: BilingualText;
  code: string;
  country: string;
  region: string;
  coordinates: { lat: number; lng: number };
  operating_company: BilingualText;
  asset_count: number;
  active_alarms_count: number;
  overall_health: number;
  production_capacity_mboed: number;
  current_production_mboed: number;
}

export interface Plant extends BaseEntity {
  site_id: string;
  name: BilingualText;
  code: string;
  type: string;
  health_score: number;
}

export interface FacilityNode extends BaseEntity {
  parent_id?: string;
  level: 'ENTERPRISE' | 'REGION' | 'COUNTRY' | 'SITE' | 'PLANT' | 'FACILITY' | 'AREA' | 'UNIT' | 'SYSTEM' | 'EQUIPMENT' | 'COMPONENT' | 'SENSOR';
  name: BilingualText;
  code: string; // e.g. "C-101", "P-104", "SA-EAST-MGS-ST04"
  category?: AssetCategory;
  asset_type?: AssetType;
  health_score?: number;
  condition_state?: ConditionState;
  risk_score?: number;
  children?: FacilityNode[];
}

export interface TelemetrySignal {
  timestamp: string;
  asset_id: string;
  tag: string; // e.g., "C101_VIB_RAD_01"
  name: BilingualText;
  value: number;
  unit: string;
  quality: TelemetryQuality;
  source: 'OPC-UA' | 'MQTT' | 'DCS' | 'SCADA' | 'HISTORIAN';
  min_limit?: number;
  max_limit?: number;
  warning_high?: number;
  critical_high?: number;
}

export interface AssetHealthDetail {
  asset_id: string;
  asset_code: string;
  asset_name: BilingualText;
  health_score: number; // 0 - 100
  condition_state: ConditionState;
  failure_probability_30d: number; // 0.0 - 1.0
  remaining_useful_life_days: number;
  risk_score_usd: number;
  primary_failure_mode: BilingualText;
  contributing_factors: {
    factor: BilingualText;
    impact_pct: number;
    sensor_tag: string;
    current_value: string;
  }[];
  engineering_basis: BilingualText;
  recommended_action: BilingualText;
  confidence: number;
  timestamp: string;
}

export interface AlarmItem {
  id: string;
  timestamp: string;
  asset_id: string;
  asset_code: string;
  asset_name: BilingualText;
  tag: string;
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  title: BilingualText;
  description: BilingualText;
  value: number;
  threshold: number;
  unit: string;
  acknowledged: boolean;
  acknowledged_by?: string;
  acknowledged_at?: string;
  work_order_id?: string;
}

export interface WorkOrder extends BaseEntity {
  wo_number: string; // e.g. "WO-2026-8842"
  asset_id: string;
  asset_code: string;
  asset_name: BilingualText;
  title: BilingualText;
  description: BilingualText;
  priority: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  wo_type: 'PREDICTIVE' | 'PREVENTIVE' | 'CORRECTIVE' | 'INSPECTION' | 'SHUTDOWN';
  wo_status: 'DETECTED' | 'CLASSIFIED' | 'PRIORITIZED' | 'PLANNED' | 'APPROVED' | 'SCHEDULED' | 'EXECUTING' | 'INSPECTED' | 'CLOSED';
  assigned_technician?: BilingualText;
  craft: BilingualText;
  estimated_hours: number;
  estimated_cost_usd: number;
  required_spares: {
    part_number: string;
    name: BilingualText;
    qty: number;
    in_stock: boolean;
  }[];
  scheduled_start?: string;
  risk_reduction_usd: number;
}

export interface ProcessVariable {
  tag: string;
  name: BilingualText;
  value: number;
  recommended_setpoint: number;
  unit: string;
  min_constraint: number;
  max_constraint: number;
  status: 'OPTIMAL' | 'DEGRADED' | 'VIOLATION';
}

export interface DigitalTwinScenario {
  load_percentage: number; // 50 - 110 %
  suction_pressure_bar: number;
  discharge_pressure_bar: number;
  ambient_temp_c: number;
  // Calculated outputs
  bearing_temp_c: number;
  vibration_rms_mms: number;
  polytropic_efficiency_pct: number;
  power_consumption_mw: number;
  co2e_emissions_tpd: number;
  daily_operating_cost_usd: number;
  failure_risk_30d: number;
}

export interface ReliabilityRecord {
  asset_code: string;
  asset_name: BilingualText;
  mtbf_hours: number;
  mttr_hours: number;
  availability_pct: number; // A = MTBF / (MTBF + MTTR)
  failure_distribution: 'Weibull' | 'Exponential' | 'Lognormal';
  shape_beta?: number;
  scale_eta_hours?: number;
  bad_actor_rank: number;
  fmea_rpn: number; // Risk Priority Number (Severity x Occurrence x Detection)
}

export interface ProductionStream {
  id: string;
  site_id: string;
  stream_name: BilingualText;
  oil_rate_bbld: number;
  gas_rate_mmscfd: number;
  water_rate_bbld: number;
  gor_scf_bbl: number;
  water_cut_pct: number;
  target_gas_mmscfd: number;
  production_loss_mmscfd: number;
  loss_reason: BilingualText;
}

export interface EnergyMetric {
  source_type: 'Electricity' | 'Fuel Gas' | 'Steam' | 'Compressed Air' | 'Water';
  name: BilingualText;
  consumption_rate: number;
  unit: string;
  cost_per_hour_usd: number;
  energy_intensity_kwh_boe: number;
}

export interface EmissionRecord {
  source_name: BilingualText;
  source_type: 'Combustion' | 'Flares' | 'Vents' | 'Fugitive' | 'Electricity';
  gas_type: 'CO2' | 'CH4' | 'N2O' | 'CO2e';
  emission_rate_tpd: number;
  emission_factor: number;
  factor_unit: string;
  jurisdiction_standard: string;
  ccus_captured_pct: number;
}

export interface SafetyBarrier {
  id: string;
  facility_code: string;
  barrier_name: BilingualText;
  category: 'PREVENTION' | 'MITIGATION' | 'EMERGENCY_SHUTDOWN';
  status: 'HEALTHY' | 'DEGRADED' | 'IMPAIRED';
  probability_score: number; // 1 to 5
  consequence_score: number; // 1 to 5
  risk_matrix_rating: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  active_permits_count: number;
}

export interface SparePart {
  id: string;
  part_number: string;
  name: BilingualText;
  category: string;
  stock_qty: number;
  reorder_point: number;
  lead_time_days: number;
  unit_cost_usd: number;
  criticality: 'HIGH' | 'MEDIUM' | 'LOW';
  supplier_name: string;
  warehouse_location: string;
}

export interface KnowledgeNode {
  id: string;
  label: BilingualText;
  type: 'ASSET' | 'COMPONENT' | 'SENSOR' | 'FAILURE_MODE' | 'RISK' | 'WORK_ORDER' | 'ECONOMIC';
  code?: string;
}

export interface KnowledgeEdge {
  source: string;
  target: string;
  relation: BilingualText;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  user_name: string;
  user_role: UserRole;
  action: BilingualText;
  entity_type: string;
  entity_id: string;
  provenance: string;
  approval_status: 'AUTOMATED' | 'HUMAN_APPROVED' | 'PENDING';
}
