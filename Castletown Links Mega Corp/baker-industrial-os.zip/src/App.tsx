import React, { useState, useEffect } from 'react';
import { Header } from './components/layout/Header';
import { Sidebar, CommandCentreId } from './components/layout/Sidebar';
import { ExecutiveCentre } from './components/commandCentres/ExecutiveCentre';
import { OperationsCentre } from './components/commandCentres/OperationsCentre';
import { AssetCentre } from './components/commandCentres/AssetCentre';
import { ReliabilityCentre } from './components/commandCentres/ReliabilityCentre';
import { MaintenanceCentre } from './components/commandCentres/MaintenanceCentre';
import { ProcessCentre } from './components/commandCentres/ProcessCentre';
import { DigitalTwinCentre } from './components/commandCentres/DigitalTwinCentre';
import { ProductionCentre } from './components/commandCentres/ProductionCentre';
import { EnergyCentre } from './components/commandCentres/EnergyCentre';
import { EmissionsCentre } from './components/commandCentres/EmissionsCentre';
import { SafetyCentre } from './components/commandCentres/SafetyCentre';
import { SupplyChainCentre } from './components/commandCentres/SupplyChainCentre';
import { BakerCopilot } from './components/copilot/BakerCopilot';
import { KnowledgeGraphView } from './components/graph/KnowledgeGraphView';
import { AuditLogView } from './components/common/AuditLogView';
import { BilingualReportExport } from './components/common/BilingualReportExport';

import { 
  INITIAL_SITES, 
  ROOT_ASSET_HIERARCHY, 
  INITIAL_TELEMETRY, 
  INITIAL_HEALTH_DETAILS, 
  INITIAL_ALARMS, 
  INITIAL_WORK_ORDERS, 
  INITIAL_RELIABILITY_DATA, 
  INITIAL_PRODUCTION_STREAMS, 
  INITIAL_ENERGY_METRICS, 
  INITIAL_EMISSIONS, 
  INITIAL_SAFETY_BARRIERS, 
  INITIAL_SPARES, 
  INITIAL_AUDIT_LOGS 
} from './data/demoData';

import { LocaleCode, UnitSystem, UserRole, AlarmItem, WorkOrder, AuditLogEntry, TelemetrySignal } from './types';
import { TelemetryEngine } from './services/telemetryEngine';
import { getDirection } from './localization';
import { FileText } from 'lucide-react';

export function App() {
  const [locale, setLocale] = useState<LocaleCode>('en-US');
  const [unitSystem, setUnitSystem] = useState<UnitSystem>('SI');
  const [persona, setPersona] = useState<UserRole>('Engineer');
  const [themeDark, setThemeDark] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<CommandCentreId>('executive');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [isExportOpen, setIsExportOpen] = useState<boolean>(false);

  // Core Industrial State
  const [sites, setSites] = useState(INITIAL_SITES);
  const [telemetry, setTelemetry] = useState<TelemetrySignal[]>(INITIAL_TELEMETRY);
  const [alarms, setAlarms] = useState<AlarmItem[]>(INITIAL_ALARMS);
  const [workOrders, setWorkOrders] = useState<WorkOrder[]>(INITIAL_WORK_ORDERS);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_AUDIT_LOGS);

  // Real-Time Physics Ticker
  useEffect(() => {
    const interval = setInterval(() => {
      const nextTelemetry = TelemetryEngine.getInstance().generateNextTick(88, telemetry);
      setTelemetry(nextTelemetry);
    }, 2000);
    return () => clearInterval(interval);
  }, [telemetry]);

  // Handle Alarm Acknowledge
  const handleAcknowledgeAlarm = (alarmId: string) => {
    setAlarms(prev => prev.map(a => a.id === alarmId ? { ...a, acknowledged: true } : a));

    // Append Audit Trail Record
    const newAudit: AuditLogEntry = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user_name: persona === 'Operator' ? 'Control Room Operator (Shift A)' : 'Eng. Tariq Al-Mansoor',
      user_role: persona,
      action: {
        en: `Acknowledged SCADA Alarm (${alarmId}) for C-101 Compressor`,
        ar: `إقرار تنبيه SCADA الرقم (${alarmId}) للضاغط C-101`
      },
      entity_type: 'AlarmItem',
      entity_id: alarmId,
      provenance: 'OPC-UA Real-time Alarm Engine',
      approval_status: 'HUMAN_APPROVED'
    };
    setAuditLogs(prev => [newAudit, ...prev]);
  };

  // Handle Work Order Issue
  const handleIssueWorkOrder = (assetCode: string) => {
    const newWo: WorkOrder = {
      id: `wo-${Date.now()}`,
      tenant_id: 'tenant-baker-global',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      created_by: 'baker_copilot_ai',
      updated_by: 'baker_copilot_ai',
      version: 1,
      status: 'ACTIVE',
      wo_number: `WO-2026-${Math.floor(1000 + Math.random() * 9000)}`,
      asset_id: 'asset-c101',
      asset_code: assetCode,
      asset_name: { en: `Diagnostic Maintenance for ${assetCode}`, ar: `صيانة تشخيصية للأصل ${assetCode}` },
      title: { en: `Inspect Bearing & Replace Lubricant on ${assetCode}`, ar: `فحص المحمل واستبدال زيت التشحيم للأصل ${assetCode}` },
      description: { en: 'Perform 1X/2X FFT vibration analysis, inspect lube oil sample.', ar: 'إجراء تحليل اهتزاز طيفي وفحص عينة الزيت.' },
      priority: 'HIGH',
      wo_type: 'PREDICTIVE',
      wo_status: 'APPROVED',
      assigned_technician: { en: 'Eng. Tariq Al-Mansoor', ar: 'م. طارق المنصور' },
      craft: { en: 'Vibration Specialist', ar: 'أخصائي اهتزازات' },
      estimated_hours: 4.0,
      estimated_cost_usd: 28000,
      required_spares: [
        { part_number: 'SP-B101-RAD', name: { en: 'Tilting Pad Journal Bearing Insert 120mm', ar: 'حشوة محمل شعاعي مقاس ١٢٠ مم' }, qty: 1, in_stock: true }
      ],
      risk_reduction_usd: 95000
    };

    setWorkOrders(prev => [newWo, ...prev]);
    setActiveTab('maintenance');
  };

  // Handle Work Order Approval
  const handleApproveWorkOrder = (woId: string) => {
    setWorkOrders(prev => prev.map(w => w.id === woId ? { ...w, wo_status: 'EXECUTING' } : w));

    const newAudit: AuditLogEntry = {
      id: `aud-${Date.now()}`,
      timestamp: new Date().toISOString(),
      user_name: 'Eng. Tariq Al-Mansoor',
      user_role: 'ReliabilityEngineer',
      action: {
        en: `Human Authorized & Approved Work Order ${woId} for Execution`,
        ar: `تفويض بشري واعتماد أمر الصيانة ${woId} للتنفيذ الميداني`
      },
      entity_type: 'WorkOrder',
      entity_id: woId,
      provenance: 'ISO 55001 Asset Management Governance Workflow',
      approval_status: 'HUMAN_APPROVED'
    };
    setAuditLogs(prev => [newAudit, ...prev]);
  };

  const activeAlarmsCount = alarms.filter(a => !a.acknowledged).length;
  const direction = getDirection(locale);

  return (
    <div className={`min-h-screen ${themeDark ? 'bg-slate-950 text-slate-100' : 'bg-slate-100 text-slate-900'} font-sans flex flex-col transition-colors`} dir={direction}>
      {/* Top Header */}
      <Header
        locale={locale}
        setLocale={setLocale}
        unitSystem={unitSystem}
        setUnitSystem={setUnitSystem}
        persona={persona}
        setPersona={setPersona}
        themeDark={themeDark}
        setThemeDark={setThemeDark}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        activeAlarmsCount={activeAlarmsCount}
      />

      {/* Main Workspace Layout */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar Drawer */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          locale={locale}
          themeDark={themeDark}
          activeAlarmsCount={activeAlarmsCount}
          workOrdersCount={workOrders.length}
        />

        {/* Command Centre Viewport */}
        <main className="flex-1 p-6 overflow-y-auto">
          {/* Quick Action Bar for Export */}
          <div className="flex justify-end mb-4">
            <button
              onClick={() => setIsExportOpen(true)}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-md transition-all flex items-center gap-1.5 font-mono"
            >
              <FileText className="w-4 h-4" />
              {locale.startsWith('ar') ? 'تصدير تقرير التدقيق' : 'Export Bilingual Audit Report'}
            </button>
          </div>

          {activeTab === 'executive' && (
            <ExecutiveCentre
              sites={sites}
              locale={locale}
              unitSystem={unitSystem}
              themeDark={themeDark}
              onSelectSite={() => setActiveTab('asset')}
            />
          )}

          {activeTab === 'operations' && (
            <OperationsCentre
              telemetry={telemetry}
              alarms={alarms}
              onAcknowledgeAlarm={handleAcknowledgeAlarm}
              locale={locale}
              unitSystem={unitSystem}
              themeDark={themeDark}
            />
          )}

          {activeTab === 'asset' && (
            <AssetCentre
              hierarchy={ROOT_ASSET_HIERARCHY}
              healthDetails={INITIAL_HEALTH_DETAILS}
              locale={locale}
              unitSystem={unitSystem}
              themeDark={themeDark}
              onIssueWorkOrder={handleIssueWorkOrder}
            />
          )}

          {activeTab === 'reliability' && (
            <ReliabilityCentre
              records={INITIAL_RELIABILITY_DATA}
              locale={locale}
              themeDark={themeDark}
            />
          )}

          {activeTab === 'maintenance' && (
            <MaintenanceCentre
              workOrders={workOrders}
              onApproveWorkOrder={handleApproveWorkOrder}
              locale={locale}
              themeDark={themeDark}
            />
          )}

          {activeTab === 'process' && (
            <ProcessCentre
              locale={locale}
              unitSystem={unitSystem}
              themeDark={themeDark}
            />
          )}

          {activeTab === 'digitalTwin' && (
            <DigitalTwinCentre
              locale={locale}
              unitSystem={unitSystem}
              themeDark={themeDark}
            />
          )}

          {activeTab === 'production' && (
            <ProductionCentre
              streams={INITIAL_PRODUCTION_STREAMS}
              locale={locale}
              themeDark={themeDark}
            />
          )}

          {activeTab === 'energy' && (
            <EnergyCentre
              metrics={INITIAL_ENERGY_METRICS}
              locale={locale}
              themeDark={themeDark}
            />
          )}

          {activeTab === 'emissions' && (
            <EmissionsCentre
              emissions={INITIAL_EMISSIONS}
              locale={locale}
              themeDark={themeDark}
            />
          )}

          {activeTab === 'safety' && (
            <SafetyCentre
              barriers={INITIAL_SAFETY_BARRIERS}
              locale={locale}
              themeDark={themeDark}
            />
          )}

          {activeTab === 'supplyChain' && (
            <SupplyChainCentre
              spares={INITIAL_SPARES}
              locale={locale}
              themeDark={themeDark}
            />
          )}

          {activeTab === 'copilot' && (
            <BakerCopilot
              locale={locale}
              themeDark={themeDark}
              onIssueWorkOrder={handleIssueWorkOrder}
            />
          )}

          {activeTab === 'knowledgeGraph' && (
            <KnowledgeGraphView
              locale={locale}
              themeDark={themeDark}
            />
          )}

          {activeTab === 'auditLog' && (
            <AuditLogView
              logs={auditLogs}
              locale={locale}
              themeDark={themeDark}
            />
          )}
        </main>
      </div>

      {/* Bilingual Report Export Modal */}
      <BilingualReportExport
        isOpen={isExportOpen}
        onClose={() => setIsExportOpen(false)}
        locale={locale}
        sites={sites}
        telemetry={telemetry}
        workOrders={workOrders}
      />
    </div>
  );
}

export default App;
