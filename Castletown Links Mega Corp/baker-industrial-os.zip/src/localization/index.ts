/**
 * BAKER INDUSTRIAL OS - BILINGUAL LOCALIZATION & TERMINOLOGY ENGINE
 * English + Arabic First-Class Architectural Primitive
 */

import { LocaleCode, TextDirection, UnitSystem, BilingualText } from '../types';

export interface UIStringDictionary {
  appTitle: BilingualText;
  appSubtitle: BilingualText;
  searchPlaceholder: BilingualText;
  language: BilingualText;
  unitSystem: BilingualText;
  personaRole: BilingualText;
  theme: BilingualText;
  darkControlRoom: BilingualText;
  lightStandard: BilingualText;
  
  // Command Centres
  navExecutive: BilingualText;
  navOperations: BilingualText;
  navAsset: BilingualText;
  navReliability: BilingualText;
  navMaintenance: BilingualText;
  navProcess: BilingualText;
  navDigitalTwin: BilingualText;
  navProduction: BilingualText;
  navEnergy: BilingualText;
  navEmissions: BilingualText;
  navSafety: BilingualText;
  navSupplyChain: BilingualText;
  navCopilot: BilingualText;
  navKnowledgeGraph: BilingualText;
  navAuditLog: BilingualText;

  // Key KPI & Metrics
  overallHealth: BilingualText;
  totalAssets: BilingualText;
  activeAlarms: BilingualText;
  mtbf: BilingualText;
  mttr: BilingualText;
  availability: BilingualText;
  workOrderBacklog: BilingualText;
  productionRate: BilingualText;
  energyIntensity: BilingualText;
  carbonEmissions: BilingualText;
  economicRiskLoss: BilingualText;
  riskReduction: BilingualText;

  // Statuses
  normal: BilingualText;
  watch: BilingualText;
  degraded: BilingualText;
  warning: BilingualText;
  critical: BilingualText;
  failed: BilingualText;

  // Actions
  actionApprove: BilingualText;
  actionAcknowledge: BilingualText;
  actionRunSimulation: BilingualText;
  actionExportReport: BilingualText;
  actionCreateWorkOrder: BilingualText;
  actionInspect: BilingualText;
  actionCopilotAsk: BilingualText;

  // Provenance & AI Governance
  provenanceTitle: BilingualText;
  engineeringBasis: BilingualText;
  humanAuthorizationRequired: BilingualText;
  dataQualityGood: BilingualText;
  dataQualityBad: BilingualText;
}

export const DICTIONARY: UIStringDictionary = {
  appTitle: { en: "BAKER INDUSTRIAL OS", ar: "نظام باكر الصناعي للمؤسسات" },
  appSubtitle: { en: "Enterprise Industrial Operations & Asset Intelligence", ar: "العمليات الصناعية ورؤى الأصول للمؤسسات" },
  searchPlaceholder: { en: "Search assets (e.g., C-101, vibration, ضاغط, Riyadh)...", ar: "البحث في الأصول (مثال: C-101، اهتزاز، ضاغط، الرياض)..." },
  language: { en: "Language", ar: "اللغة" },
  unitSystem: { en: "Unit System", ar: "نظام الوحدات" },
  personaRole: { en: "Workspace Persona", ar: "نموذج المستخدم" },
  theme: { en: "Theme Mode", ar: "نمط العرض" },
  darkControlRoom: { en: "Industrial Dark", ar: "غرفة التحكم الداكنة" },
  lightStandard: { en: "Enterprise Light", ar: "النمط المضيء للمؤسسات" },

  navExecutive: { en: "Executive Command", ar: "القيادة التنفيذية" },
  navOperations: { en: "Operations Centre", ar: "مركز العمليات" },
  navAsset: { en: "Asset Intelligence", ar: "ذكاء الأصول" },
  navReliability: { en: "Reliability & FMEA", ar: "الموثوقية والتحليل" },
  navMaintenance: { en: "Maintenance Management", ar: "إدارة الصيانة" },
  navProcess: { en: "Process Optimization", ar: "تحسين العمليات" },
  navDigitalTwin: { en: "Digital Twin Workbench", ar: "منصة التوأم الرقمي" },
  navProduction: { en: "Production Tracking", ar: "متابعة الإنتاج" },
  navEnergy: { en: "Energy Management", ar: "إدارة الطاقة" },
  navEmissions: { en: "Emissions & Carbon", ar: "الانبعاثات والكربون" },
  navSafety: { en: "Safety & HSE Barriers", ar: "السلامة والحواجز" },
  navSupplyChain: { en: "Supply Chain & Spares", ar: "سلسلة الإمداد وقطع الغيار" },
  navCopilot: { en: "Baker Copilot AI", ar: "مساعد باكر الذكي" },
  navKnowledgeGraph: { en: "Knowledge Graph", ar: "رسم المعرفة الصناعي" },
  navAuditLog: { en: "Governance & Audit", ar: "الحوكمة والسجلات" },

  overallHealth: { en: "Overall Health Score", ar: "مؤشر الصحة العام" },
  totalAssets: { en: "Monitored Assets", ar: "الأصول المراقبة" },
  activeAlarms: { en: "Active Alarms", ar: "التنبيهات النشطة" },
  mtbf: { en: "MTBF (Mean Time Between Failures)", ar: "متوسط الوقت بين الأعطال" },
  mttr: { en: "MTTR (Mean Time To Repair)", ar: "متوسط وقت الإصلاح" },
  availability: { en: "Asset Availability", ar: "جاهزية المعدات" },
  workOrderBacklog: { en: "Work Order Backlog", ar: "أوامر الصيانة المعلقة" },
  productionRate: { en: "Production Rate", ar: "معدل الإنتاج" },
  energyIntensity: { en: "Energy Intensity", ar: "كثافة استهلاك الطاقة" },
  carbonEmissions: { en: "CO2e Emissions Rate", ar: "معدل انبعاثات المكافئ الكربونية" },
  economicRiskLoss: { en: "Expected Economic Loss Risk", ar: "مخاطر الخسائر الاقتصادية" },
  riskReduction: { en: "Expected Risk Reduction", ar: "تخفيض المخاطر المتوقع" },

  normal: { en: "NORMAL", ar: "طبيعي" },
  watch: { en: "WATCH", ar: "مراقبة" },
  degraded: { en: "DEGRADED", ar: "متدهور" },
  warning: { en: "WARNING", ar: "تحذير" },
  critical: { en: "CRITICAL", ar: "حرج" },
  failed: { en: "FAILED", ar: "تعطل" },

  actionApprove: { en: "Authorize Action", ar: "اعتماد الإجراء" },
  actionAcknowledge: { en: "Acknowledge Alarm", ar: "إقرار التنبيه" },
  actionRunSimulation: { en: "Run Digital Twin Scenario", ar: "تشغيل محاكاة التوأم الرقمي" },
  actionExportReport: { en: "Export Bilingual Report", ar: "تصدير تقرير ثنائي اللغة" },
  actionCreateWorkOrder: { en: "Issue Work Order", ar: "إصدار أمر صيانة" },
  actionInspect: { en: "Schedule Spectrum Inspection", ar: "جدولة فحص الاهتزاز" },
  actionCopilotAsk: { en: "Ask Baker Copilot", ar: "استشارة مساعد باكر" },

  provenanceTitle: { en: "Engineering Provenance & Traceability", ar: "المصدر وإمكانية التتبع الهندسية" },
  engineeringBasis: { en: "Engineering Basis", ar: "الأساس الهندسي" },
  humanAuthorizationRequired: { en: "Human Authorization Required Prior to Execution", ar: "يتطلب تفويضاً بشرياً قبل التنفيذ" },
  dataQualityGood: { en: "OPC-UA Telemetry: GOOD (100% Quality)", ar: "قياسات OPC-UA: جيدة (جودة ١٠٠٪)" },
  dataQualityBad: { en: "OPC-UA Telemetry: UNCERTAIN", ar: "قياسات OPC-UA: غير مؤكدة" }
};

export function getDirection(locale: LocaleCode): TextDirection {
  return locale.startsWith('ar') ? 'rtl' : 'ltr';
}

export function formatBilingualText(text: BilingualText, locale: LocaleCode): string {
  const isArabic = locale.startsWith('ar');
  return isArabic ? text.ar : text.en;
}

export function formatNumber(val: number, locale: LocaleCode, decimals: number = 2): string {
  const formatted = val.toLocaleString(locale === 'ar-SA' || locale.startsWith('ar') ? 'ar-SA' : 'en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  });
  return formatted;
}

export function formatCurrencyUSD(val: number, locale: LocaleCode): string {
  const isArabic = locale.startsWith('ar');
  if (val >= 1_000_000) {
    const millions = (val / 1_000_000).toFixed(2);
    return isArabic ? `$ ${millions} مليون` : `$${millions}M`;
  }
  if (val >= 1_000) {
    const thousands = (val / 1_000).toFixed(1);
    return isArabic ? `$ ${thousands} ألف` : `$${thousands}k`;
  }
  return `$${val.toLocaleString()}`;
}

export function formatEngineeringUnit(value: number, unit: string, system: UnitSystem, locale: LocaleCode): { value: number; unit: string; display: string } {
  let convertedValue = value;
  let targetUnit = unit;

  if (system === 'Imperial' || system === 'Oilfield') {
    if (unit === 'bar') {
      convertedValue = value * 14.5038; // bar to psi
      targetUnit = 'psi';
    } else if (unit === '°C') {
      convertedValue = (value * 9/5) + 32; // C to F
      targetUnit = '°F';
    }
  } else if (system === 'SI') {
    if (unit === 'psi') {
      convertedValue = value / 14.5038;
      targetUnit = 'bar';
    } else if (unit === '°F') {
      convertedValue = (value - 32) * 5/9;
      targetUnit = '°C';
    }
  }

  const numStr = formatNumber(convertedValue, locale, 1);
  return {
    value: convertedValue,
    unit: targetUnit,
    display: `${numStr} ${targetUnit}`
  };
}

/**
 * Terminology graph mapping for universal bilingual search.
 */
export const TERMINOLOGY_GRAPH: Record<string, string[]> = {
  "compressor": ["ضاغط", "C-101", "C-204", "gas turbine", "vibration", "bearing", "compression train"],
  "ضاغط": ["compressor", "C-101", "C-204", "توربين", "اهتزاز", "محمل"],
  "vibration": ["اهتزاز", "VIB-101", "spectrum", "bearing wear", "mms"],
  "اهتزاز": ["vibration", "VIB-101", "محمل", "طيف الاهتزاز"],
  "bearing": ["محمل", "B-101", "lubrication", "temperature"],
  "محمل": ["bearing", "B-101", "تشحيم", "حرارة"],
  "temperature": ["حرارة", "درجة الحرارة", "TEMP-101", "thermal"],
  "حرارة": ["temperature", "TEMP-101", "درجة حرارة"],
  "saudi": ["السعودية", "Saudi Gas Demo", "Master Gas System", "Eastern Province"],
  "السعودية": ["saudi", "المملكة العربية السعودية", "نظام الغاز الرئيسي"],
  "esp": ["ESP-17", "مضخة كهربائية غاطسة", "artificial lift", "downhole"],
  "مضخة": ["pump", "ESP-17", "P-101", "الرفع الاصطناعي"]
};

export function matchesBilingualSearch(query: string, text: BilingualText, code: string): boolean {
  if (!query || query.trim() === '') return true;
  const q = query.toLowerCase().trim();
  const codeLower = code.toLowerCase();
  const enLower = text.en.toLowerCase();
  const arLower = text.ar.toLowerCase();

  if (codeLower.includes(q) || enLower.includes(q) || arLower.includes(q)) return true;

  // Check synonym graph
  for (const [key, synonyms] of Object.entries(TERMINOLOGY_GRAPH)) {
    if (q.includes(key.toLowerCase())) {
      for (const syn of synonyms) {
        if (codeLower.includes(syn.toLowerCase()) || enLower.includes(syn.toLowerCase()) || arLower.includes(syn.toLowerCase())) {
          return true;
        }
      }
    }
  }

  return false;
}
