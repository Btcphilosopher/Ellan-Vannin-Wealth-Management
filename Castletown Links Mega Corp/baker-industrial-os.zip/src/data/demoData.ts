/**
 * BAKER INDUSTRIAL ENTERPRISE OS - DEMO DATASET
 * Fictional industrial demonstration dataset inspired by global energy technology benchmarks.
 * Reference: Saudi Arabian Booster Gas Compression Stations & Gulf Energy Operations.
 */

import { Site, FacilityNode, TelemetrySignal, AssetHealthDetail, AlarmItem, WorkOrder, ReliabilityRecord, ProductionStream, EnergyMetric, EmissionRecord, SafetyBarrier, SparePart, AuditLogEntry } from '../types';

export const INITIAL_SITES: Site[] = [
  {
    id: "site-01",
    tenant_id: "tenant-baker-global",
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-09-12T02:00:00Z",
    created_by: "system_admin",
    updated_by: "system_admin",
    version: 1,
    status: "ACTIVE",
    code: "SA-MGS-ST04",
    name: {
      en: "Saudi Gas Demo - Booster Compression Station 04",
      ar: "عرض الغاز السعودي - محطة ضغط الغاز المعزز ٠٤"
    },
    country: "Saudi Arabia / المملكة العربية السعودية",
    region: "Eastern Province / المنطقة الشرقية",
    coordinates: { lat: 26.2856, lng: 50.1167 },
    operating_company: { en: "Saudi Aramco Master Gas System", ar: "نظام الغاز الرئيسي - أرامكو السعودية" },
    asset_count: 2450,
    active_alarms_count: 3,
    overall_health: 87.4,
    production_capacity_mboed: 450.0,
    current_production_mboed: 428.5,
  },
  {
    id: "site-02",
    tenant_id: "tenant-baker-global",
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-09-12T02:00:00Z",
    created_by: "system_admin",
    updated_by: "system_admin",
    version: 1,
    status: "ACTIVE",
    code: "UAE-LNG-T3",
    name: {
      en: "UAE LNG Complex - Das Island Train 3",
      ar: "مجمع الغاز المسال في الإمارات - قطار داس ٣"
    },
    country: "United Arab Emirates / الإمارات العربية المتحدة",
    region: "Abu Dhabi Offshore / أوفشور أبوظبي",
    coordinates: { lat: 25.1472, lng: 52.8752 },
    operating_company: { en: "ADNOC Gas LNG Operations", ar: "عمليات أدنوك للغاز المسال" },
    asset_count: 3120,
    active_alarms_count: 1,
    overall_health: 93.1,
    production_capacity_mboed: 380.0,
    current_production_mboed: 375.2,
  },
  {
    id: "site-03",
    tenant_id: "tenant-baker-global",
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-09-12T02:00:00Z",
    created_by: "system_admin",
    updated_by: "system_admin",
    version: 1,
    status: "ACTIVE",
    code: "QA-RL-NFS",
    name: {
      en: "Qatar Gas Compression - Ras Laffan Station",
      ar: "عرض ضغط الغاز القطرية - محطة رأس لفان"
    },
    country: "Qatar / دولة قطر",
    region: "Ras Laffan Industrial City / مدينة رأس لفان",
    coordinates: { lat: 25.9083, lng: 51.5475 },
    operating_company: { en: "QatarEnergy North Field West", ar: "قطر للطاقة - حقل الشمال الغربي" },
    asset_count: 1890,
    active_alarms_count: 0,
    overall_health: 96.8,
    production_capacity_mboed: 520.0,
    current_production_mboed: 518.0,
  },
  {
    id: "site-04",
    tenant_id: "tenant-baker-global",
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-09-12T02:00:00Z",
    created_by: "system_admin",
    updated_by: "system_admin",
    version: 1,
    status: "ACTIVE",
    code: "UK-NS-FORT",
    name: {
      en: "UK Offshore Energy - Forties Platform",
      ar: "عرض الطاقة البحرية البريطانية - منصة فورتيز"
    },
    country: "United Kingdom / المملكة المتحدة",
    region: "North Sea Sector 21 / بحر الشمال Sector 21",
    coordinates: { lat: 57.7500, lng: 0.9000 },
    operating_company: { en: "North Sea Operator Co.", ar: "شركة مشغل بحر الشمال" },
    asset_count: 1420,
    active_alarms_count: 2,
    overall_health: 81.2,
    production_capacity_mboed: 180.0,
    current_production_mboed: 162.0,
  },
  {
    id: "site-05",
    tenant_id: "tenant-baker-global",
    created_at: "2026-01-01T00:00:00Z",
    updated_at: "2026-09-12T02:00:00Z",
    created_by: "system_admin",
    updated_by: "system_admin",
    version: 1,
    status: "ACTIVE",
    code: "US-GC-SAB",
    name: {
      en: "US Industrial Gulf Coast - Sabine Petrochem",
      ar: "عرض البتروكيماويات الأمريكية - سابين باس"
    },
    country: "United States / الولايات المتحدة",
    region: "Texas Gulf Coast / ساحل خليج تكساس",
    coordinates: { lat: 29.7341, lng: -93.8721 },
    operating_company: { en: "Gulf Industrial Energy LLC", ar: "شركة طاقة الخليج الصناعية" },
    asset_count: 2890,
    active_alarms_count: 1,
    overall_health: 90.5,
    production_capacity_mboed: 310.0,
    current_production_mboed: 304.0,
  }
];

export const ROOT_ASSET_HIERARCHY: FacilityNode = {
  id: "ent-01",
  tenant_id: "tenant-baker-global",
  created_at: "2026-01-01T00:00:00Z",
  updated_at: "2026-09-12T02:00:00Z",
  created_by: "system_admin",
  updated_by: "system_admin",
  version: 1,
  status: "ACTIVE",
  level: "ENTERPRISE",
  name: { en: "Baker Industrial Global Enterprise", ar: "المؤسسة العالمية لمجموعة باكر الصناعية" },
  code: "BAKER-ENT-GLOBAL",
  children: [
    {
      id: "reg-01",
      tenant_id: "tenant-baker-global",
      created_at: "2026-01-01T00:00:00Z",
      updated_at: "2026-09-12T02:00:00Z",
      created_by: "system_admin",
      updated_by: "system_admin",
      version: 1,
      status: "ACTIVE",
      level: "REGION",
      name: { en: "Middle East & North Africa (MENA)", ar: "الشرق الأوسط وشمال إفريقيا" },
      code: "MENA-REG",
      children: [
        {
          id: "cntry-sa",
          tenant_id: "tenant-baker-global",
          created_at: "2026-01-01T00:00:00Z",
          updated_at: "2026-09-12T02:00:00Z",
          created_by: "system_admin",
          updated_by: "system_admin",
          version: 1,
          status: "ACTIVE",
          level: "COUNTRY",
          name: { en: "Kingdom of Saudi Arabia", ar: "المملكة العربية السعودية" },
          code: "KSA",
          children: [
            {
              id: "site-sa-mgs",
              tenant_id: "tenant-baker-global",
              created_at: "2026-01-01T00:00:00Z",
              updated_at: "2026-09-12T02:00:00Z",
              created_by: "system_admin",
              updated_by: "system_admin",
              version: 1,
              status: "ACTIVE",
              level: "SITE",
              name: { en: "Booster Compression Station 04", ar: "محطة ضغط الغاز المعزز ٠٤" },
              code: "SA-MGS-ST04",
              health_score: 87.4,
              children: [
                {
                  id: "plant-train-2",
                  tenant_id: "tenant-baker-global",
                  created_at: "2026-01-01T00:00:00Z",
                  updated_at: "2026-09-12T02:00:00Z",
                  created_by: "system_admin",
                  updated_by: "system_admin",
                  version: 1,
                  status: "ACTIVE",
                  level: "UNIT",
                  name: { en: "Compression Train 2", ar: "قطار الانضغاط رقم ٢" },
                  code: "TRAIN-02",
                  health_score: 74.2,
                  condition_state: "DEGRADED",
                  children: [
                    {
                      id: "asset-c101",
                      tenant_id: "tenant-baker-global",
                      created_at: "2026-01-01T00:00:00Z",
                      updated_at: "2026-09-12T02:00:00Z",
                      created_by: "system_admin",
                      updated_by: "system_admin",
                      version: 1,
                      status: "ACTIVE",
                      level: "EQUIPMENT",
                      name: { en: "Booster Centrifugal Gas Compressor C-101", ar: "ضاغط الغاز المعزز الطارد المركزي C-101" },
                      code: "C-101",
                      category: "rotating",
                      asset_type: "compressor",
                      health_score: 68.5,
                      condition_state: "WARNING",
                      risk_score: 144000,
                      children: [
                        {
                          id: "comp-b101",
                          tenant_id: "tenant-baker-global",
                          created_at: "2026-01-01T00:00:00Z",
                          updated_at: "2026-09-12T02:00:00Z",
                          created_by: "system_admin",
                          updated_by: "system_admin",
                          version: 1,
                          status: "ACTIVE",
                          level: "COMPONENT",
                          name: { en: "Drive End Radial Journal Bearing B-101", ar: "محمل التوجيه الشعاعي لجانب المحرك B-101" },
                          code: "B-101",
                          health_score: 61.0,
                          condition_state: "DEGRADED",
                          children: [
                            {
                              id: "sensor-vib101",
                              tenant_id: "tenant-baker-global",
                              created_at: "2026-01-01T00:00:00Z",
                              updated_at: "2026-09-12T02:00:00Z",
                              created_by: "system_admin",
                              updated_by: "system_admin",
                              version: 1,
                              status: "ACTIVE",
                              level: "SENSOR",
                              name: { en: "Radial Vibration Proximity Probe X-Axis", ar: "مجس اهتزاز التقارب الشعاعي المحور X" },
                              code: "VIB-101-X",
                              health_score: 95.0,
                              condition_state: "NORMAL"
                            }
                          ]
                        }
                      ]
                    },
                    {
                      id: "asset-gt03",
                      tenant_id: "tenant-baker-global",
                      created_at: "2026-01-01T00:00:00Z",
                      updated_at: "2026-09-12T02:00:00Z",
                      created_by: "system_admin",
                      updated_by: "system_admin",
                      version: 1,
                      status: "ACTIVE",
                      level: "EQUIPMENT",
                      name: { en: "Heavy Industrial Gas Turbine GT-03", ar: "التوربين الغازي الصناعي الثقيل GT-03" },
                      code: "GT-03",
                      category: "power",
                      asset_type: "turbine",
                      health_score: 94.0,
                      condition_state: "NORMAL",
                      risk_score: 12000
                    }
                  ]
                }
              ]
            }
          ]
        }
      ]
    }
  ]
};

export const INITIAL_TELEMETRY: TelemetrySignal[] = [
  {
    timestamp: new Date().toISOString(),
    asset_id: "asset-c101",
    tag: "C101_VIB_RAD_X",
    name: { en: "C-101 DE Radial Vibration (RMS)", ar: "اهتزاز C-101 الشعاعي RMS" },
    value: 7.84,
    unit: "mm/s",
    quality: "GOOD",
    source: "OPC-UA",
    min_limit: 0.0,
    max_limit: 12.0,
    warning_high: 6.5,
    critical_high: 9.0
  },
  {
    timestamp: new Date().toISOString(),
    asset_id: "asset-c101",
    tag: "C101_BEARING_TEMP_01",
    name: { en: "B-101 Metal Temperature", ar: "درجة حرارة معدن المحمل B-101" },
    value: 94.2,
    unit: "°C",
    quality: "GOOD",
    source: "OPC-UA",
    min_limit: 10.0,
    max_limit: 130.0,
    warning_high: 88.0,
    critical_high: 105.0
  },
  {
    timestamp: new Date().toISOString(),
    asset_id: "asset-c101",
    tag: "C101_SUCTION_PRESS",
    name: { en: "C-101 Suction Pressure", ar: "ضغط السحب للضاغط C-101" },
    value: 42.5,
    unit: "bar",
    quality: "GOOD",
    source: "DCS",
    min_limit: 20.0,
    max_limit: 60.0,
    warning_high: 52.0,
    critical_high: 56.0
  },
  {
    timestamp: new Date().toISOString(),
    asset_id: "asset-c101",
    tag: "C101_DISCHARGE_PRESS",
    name: { en: "C-101 Discharge Pressure", ar: "ضغط التفريغ للضاغط C-101" },
    value: 118.6,
    unit: "bar",
    quality: "GOOD",
    source: "DCS",
    min_limit: 80.0,
    max_limit: 140.0,
    warning_high: 130.0,
    critical_high: 135.0
  },
  {
    timestamp: new Date().toISOString(),
    asset_id: "asset-c101",
    tag: "C101_GAS_FLOW_RATE",
    name: { en: "C-101 Gas Throughput", ar: "تدفق الغاز للضاغط C-101" },
    value: 142.8,
    unit: "MMscf/d",
    quality: "GOOD",
    source: "HISTORIAN",
    min_limit: 50.0,
    max_limit: 180.0
  },
  {
    timestamp: new Date().toISOString(),
    asset_id: "asset-c101",
    tag: "C101_LUBE_OIL_PRESS",
    name: { en: "Lube Oil Header Pressure", ar: "ضغط زيت التشحييم الرئيسي" },
    value: 2.15,
    unit: "bar",
    quality: "GOOD",
    source: "SCADA",
    warning_high: 1.8,
    critical_high: 1.4
  }
];

export const INITIAL_HEALTH_DETAILS: AssetHealthDetail[] = [
  {
    asset_id: "asset-c101",
    asset_code: "C-101",
    asset_name: { en: "Booster Centrifugal Gas Compressor C-101", ar: "ضاغط الغاز المعزز C-101" },
    health_score: 68.5,
    condition_state: "WARNING",
    failure_probability_30d: 0.71,
    remaining_useful_life_days: 18,
    risk_score_usd: 144000,
    primary_failure_mode: {
      en: "Hydrodynamic Journal Bearing Degradation & Sub-synchronous Oil Whirl",
      ar: "تدهور المحمل الهيدروديناميكي ودوامة الزيت دون التزامنية"
    },
    contributing_factors: [
      {
        factor: { en: "Radial Vibration Elevation", ar: "ارتفاع الاهتزاز الشعاعي" },
        impact_pct: +18.4,
        sensor_tag: "C101_VIB_RAD_X",
        current_value: "7.84 mm/s (Warning > 6.5)"
      },
      {
        factor: { en: "Bearing Metal Thermal Drift", ar: "الانجراف الحراري لمعدن المحمل" },
        impact_pct: +7.2,
        sensor_tag: "C101_BEARING_TEMP_01",
        current_value: "94.2 °C (Warning > 88.0)"
      },
      {
        factor: { en: "Lube Oil Supply Pressure Drop", ar: "انخفاض ضغط إمداد زيت التشحيم" },
        impact_pct: -4.1,
        sensor_tag: "C101_LUBE_OIL_PRESS",
        current_value: "2.15 bar"
      }
    ],
    engineering_basis: {
      en: "ISO 10816-3 Zone C Severity combined with spectral Fast Fourier Transform peak at 0.43x RPM indicating bearing clearance enlargement.",
      ar: "حسب معيار ISO 10816-3 المنطقة C مع إشارة تحليل الطيف عند 0.43x دورة/دقيقة مما يشير إلى اتساع خلوص المحمل."
    },
    recommended_action: {
      en: "Perform 1X/2X FFT spectral analysis, inspect lube oil filtration and prepare replacement for Bearing B-101 within 24 hours.",
      ar: "إجراء تحليل طيف FFT، وفحص تصفية زيت التشحيم وإعداد بديل للمحمل B-101 خلال ٢٤ ساعة."
    },
    confidence: 0.92,
    timestamp: new Date().toISOString()
  }
];

export const INITIAL_ALARMS: AlarmItem[] = [
  {
    id: "alm-101",
    timestamp: new Date().toISOString(),
    asset_id: "asset-c101",
    asset_code: "C-101",
    asset_name: { en: "Booster Gas Compressor C-101", ar: "ضاغط الغاز المعزز C-101" },
    tag: "C101_VIB_RAD_X",
    severity: "WARNING",
    title: { en: "High Radial Vibration Alarm (7.84 mm/s)", ar: "تنبيه اهتزاز شعاعي مرتفع (٧٫٨٤ مم/ث)" },
    description: { en: "Vibration level exceeded 6.5 mm/s warning threshold on Drive End Bearing.", ar: "تجاوز مستوى الاهتزاز حد التحذير ٦٫٥ مم/ث على محمل جانب التوجيه." },
    value: 7.84,
    threshold: 6.5,
    unit: "mm/s",
    acknowledged: false
  },
  {
    id: "alm-102",
    timestamp: new Date().toISOString(),
    asset_id: "asset-c101",
    asset_code: "C-101",
    asset_name: { en: "Booster Gas Compressor C-101", ar: "ضاغط الغاز المعزز C-101" },
    tag: "C101_BEARING_TEMP_01",
    severity: "WARNING",
    title: { en: "Bearing B-101 Temperature High (94.2 °C)", ar: "ارتفاع حرارة المحمل B-101 (٩٤٫٢ م°)" },
    description: { en: "Temperature exceeded 88.0 °C warning setpoint under current 88% load.", ar: "تجاوزت الحرارة نقطة التحذير ٨٨٫٠ م° تحت حمولة ٨٨٪." },
    value: 94.2,
    threshold: 88.0,
    unit: "°C",
    acknowledged: false
  }
];

export const INITIAL_WORK_ORDERS: WorkOrder[] = [
  {
    id: "wo-8842",
    tenant_id: "tenant-baker-global",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    created_by: "reliability_system",
    updated_by: "reliability_system",
    version: 1,
    status: "ACTIVE",
    wo_number: "WO-2026-8842",
    asset_id: "asset-c101",
    asset_code: "C-101",
    asset_name: { en: "Booster Gas Compressor C-101", ar: "ضاغط الغاز المعزز C-101" },
    title: { en: "Inspect & Replace Bearing B-101 Lube Oil Pack", ar: "فحص واستبدال حزمة زيت التشحيم للمحمل B-101" },
    description: { en: "Perform spectrum analysis, inspect lube oil sample for particulate wear, check anti-whirl geometry.", ar: "إجراء تحليل طيفي، وفحص عينة الزيت لجسيمات التآكل، والتحقق من جغرافيا المحمل." },
    priority: "HIGH",
    wo_type: "PREDICTIVE",
    wo_status: "APPROVED",
    assigned_technician: { en: "Eng. Tariq Al-Mansoor", ar: "م. طارق المنصور" },
    craft: { en: "Mechanical / Vibration Specialist", ar: "أخصائي ميكانيكا واهتزاز" },
    estimated_hours: 6.0,
    estimated_cost_usd: 35000,
    required_spares: [
      {
        part_number: "SP-B101-RAD",
        name: { en: "Tilting Pad Journal Bearing Insert 120mm", ar: "حشوة محمل شعاعي مقاس ١٢٠ مم" },
        qty: 1,
        in_stock: true
      },
      {
        part_number: "OIL-SYN-ISO46",
        name: { en: "Synthetic Lube Oil ISO VG 46 (200L)", ar: "زيت تشحيم اصطناعي ISO VG 46" },
        qty: 2,
        in_stock: true
      }
    ],
    risk_reduction_usd: 109000
  }
];

export const INITIAL_RELIABILITY_DATA: ReliabilityRecord[] = [
  {
    asset_code: "C-101",
    asset_name: { en: "Booster Gas Compressor C-101", ar: "ضاغط الغاز المعزز C-101" },
    mtbf_hours: 4200,
    mttr_hours: 14.5,
    availability_pct: 99.65,
    failure_distribution: "Weibull",
    shape_beta: 2.15,
    scale_eta_hours: 4800,
    bad_actor_rank: 1,
    fmea_rpn: 252
  },
  {
    asset_code: "GT-03",
    asset_name: { en: "Heavy Gas Turbine GT-03", ar: "التوربين الغازي GT-03" },
    mtbf_hours: 8500,
    mttr_hours: 22.0,
    availability_pct: 99.74,
    failure_distribution: "Weibull",
    shape_beta: 1.4,
    scale_eta_hours: 9200,
    bad_actor_rank: 4,
    fmea_rpn: 112
  },
  {
    asset_code: "ESP-17",
    asset_name: { en: "Downhole ESP Pump Unit 17", ar: "مضخة ESP الغاطسة 17" },
    mtbf_hours: 3100,
    mttr_hours: 48.0,
    availability_pct: 98.47,
    failure_distribution: "Exponential",
    bad_actor_rank: 2,
    fmea_rpn: 210
  }
];

export const INITIAL_PRODUCTION_STREAMS: ProductionStream[] = [
  {
    id: "prod-01",
    site_id: "site-01",
    stream_name: { en: "Master Gas Station 04 Trunkline", ar: "أنبوب رئيسي محطة الغاز ٠٤" },
    oil_rate_bbld: 125000,
    gas_rate_mmscfd: 428.5,
    water_rate_bbld: 14200,
    gor_scf_bbl: 3428,
    water_cut_pct: 10.2,
    target_gas_mmscfd: 450.0,
    production_loss_mmscfd: 21.5,
    loss_reason: { en: "C-101 Derating to 85% Load for Bearing Cooling", ar: "تخفيض حمولة C-101 إلى ٨٥٪ لتبريد المحمل" }
  }
];

export const INITIAL_ENERGY_METRICS: EnergyMetric[] = [
  {
    source_type: "Fuel Gas",
    name: { en: "Gas Turbine Fuel Consumption", ar: "استهلاك وقود التوربين الغازي" },
    consumption_rate: 18.4,
    unit: "MMscf/d",
    cost_per_hour_usd: 1850,
    energy_intensity_kwh_boe: 24.5
  },
  {
    source_type: "Electricity",
    name: { en: "Auxiliary Motor Drives Power", ar: "طاقة المحركات المساعدة" },
    consumption_rate: 14.2,
    unit: "MW",
    cost_per_hour_usd: 1136,
    energy_intensity_kwh_boe: 12.1
  }
];

export const INITIAL_EMISSIONS: EmissionRecord[] = [
  {
    source_name: { en: "Gas Turbine GT-03 Exhaust Stack", ar: "عادم التوربين الغازي GT-03" },
    source_type: "Combustion",
    gas_type: "CO2e",
    emission_rate_tpd: 412.0,
    emission_factor: 56.1,
    factor_unit: "kg CO2e / GJ",
    jurisdiction_standard: "Saudi NCEC / EPA Subpart W",
    ccus_captured_pct: 35.0
  },
  {
    source_name: { en: "Station Flare System Header", ar: "شعلة المحطة الرئيسية" },
    source_type: "Flares",
    gas_type: "CH4",
    emission_rate_tpd: 4.2,
    emission_factor: 0.98,
    factor_unit: "t CH4 / MMscf",
    jurisdiction_standard: "OGMP 2.0 Level 5",
    ccus_captured_pct: 0.0
  }
];

export const INITIAL_SAFETY_BARRIERS: SafetyBarrier[] = [
  {
    id: "sb-01",
    facility_code: "SA-MGS-ST04",
    barrier_name: { en: "High Pressure Emergency Shutdown (ESD-1)", ar: "إغلاق الطوارئ للضغط العالي (ESD-1)" },
    category: "EMERGENCY_SHUTDOWN",
    status: "HEALTHY",
    probability_score: 1,
    consequence_score: 5,
    risk_matrix_rating: "MEDIUM",
    active_permits_count: 2
  },
  {
    id: "sb-02",
    facility_code: "SA-MGS-ST04",
    barrier_name: { en: "Compressor Anti-Surge Control Valve System", ar: "نظام صمام التحكم بمانع الضخ للضاغط" },
    category: "PREVENTION",
    status: "DEGRADED",
    probability_score: 3,
    consequence_score: 4,
    risk_matrix_rating: "HIGH",
    active_permits_count: 1
  }
];

export const INITIAL_SPARES: SparePart[] = [
  {
    id: "sp-01",
    part_number: "SP-B101-RAD",
    name: { en: "Tilting Pad Journal Bearing Insert 120mm", ar: "حشوة محمل شعاعي مقاس ١٢٠ مم" },
    category: "Rotating Spares",
    stock_qty: 4,
    reorder_point: 2,
    lead_time_days: 14,
    unit_cost_usd: 18500,
    criticality: "HIGH",
    supplier_name: "Baker Hughes Turbomachinery Spares",
    warehouse_location: "Dhahran Central Warehouse / ظهران"
  },
  {
    id: "sp-02",
    part_number: "OIL-SYN-ISO46",
    name: { en: "Synthetic Lube Oil ISO VG 46 (200L Drum)", ar: "برميل زيت تشحيم اصطناعي ISO VG 46" },
    category: "Consumables",
    stock_qty: 18,
    reorder_point: 10,
    lead_time_days: 3,
    unit_cost_usd: 1200,
    criticality: "MEDIUM",
    supplier_name: "Saudi Industrial Lubricants",
    warehouse_location: "Jubail Logistics Facility / الجبيل"
  }
];

export const INITIAL_AUDIT_LOGS: AuditLogEntry[] = [
  {
    id: "aud-901",
    timestamp: new Date().toISOString(),
    user_name: "Eng. Tariq Al-Mansoor",
    user_role: "ReliabilityEngineer",
    action: { en: "Approved Work Order WO-2026-8842 for C-101 Bearing Inspection", ar: "اعتماد أمر الصيانة WO-2026-8842 لفحص محمل C-101" },
    entity_type: "WorkOrder",
    entity_id: "wo-8842",
    provenance: "AI Anomaly Model v3.8 (Confidence 92%)",
    approval_status: "HUMAN_APPROVED"
  },
  {
    id: "aud-900",
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    user_name: "Baker Industrial Copilot Engine",
    user_role: "Administrator",
    action: { en: "Generated Predictive Failure Alert for Compressor C-101", ar: "إصدار تنبيه عطل متوقع للضاغط C-101" },
    entity_type: "AssetHealthDetail",
    entity_id: "asset-c101",
    provenance: "ISO 10816-3 Spectral Model",
    approval_status: "AUTOMATED"
  }
];
