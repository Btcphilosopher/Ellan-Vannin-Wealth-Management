import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Synthetic In-Memory Drex REST API Endpoints

// 1. Wallets
app.get('/api/v1/wallets', (req: Request, res: Response) => {
  res.json({
    status: 'success',
    notice: 'DADOS SIMULADOS — PILOTO DREX BCB',
    data: [
      { id: 'w-pers-01', name: 'Carteira Pessoal — Ana Silva', type: 'PERSON', totalBalanceBrl: 18450.80, status: 'ATIVA' },
      { id: 'w-pers-02', name: 'Carteira Pessoal — Carlos Eduardo', type: 'PERSON', totalBalanceBrl: 850000.00, status: 'ATIVA' },
      { id: 'w-corp-01', name: 'AgroSul Cooperativa Exportadora', type: 'BUSINESS', totalBalanceBrl: 14200000.00, status: 'ATIVA' },
      { id: 'w-corp-02', name: 'Construtora & Incorporadora Jardins', type: 'BUSINESS', totalBalanceBrl: 38500000.00, status: 'ATIVA' },
      { id: 'w-inst-bb', name: 'Tesouraria BB Digital', type: 'BANK', totalBalanceBrl: 14200000000.00, status: 'ATIVA' },
      { id: 'w-inst-paulista', name: 'Tesouraria Banco Paulista', type: 'BANK', totalBalanceBrl: 8400000000.00, status: 'ATIVA' }
    ]
  });
});

app.get('/api/v1/wallets/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  res.json({
    status: 'success',
    notice: 'DADOS SIMULADOS — AMBIENTE DE TESTE DREX',
    data: {
      id,
      name: `Carteira Sintética ${id}`,
      type: 'PERSON',
      wholesaleDrexBalance: 0,
      tokenisedDepositBalance: 18450.80,
      limits: { daily: 50000, monthly: 200000 },
      kycStatus: 'VERIFICADO_BACEN',
      privacySetting: 'ZK_ENCRYPTED_AUDITABLE'
    }
  });
});

// 2. Transactions
app.get('/api/v1/transactions', (req: Request, res: Response) => {
  res.json({
    status: 'success',
    notice: 'DADOS SIMULADOS — PILOTO DREX BCB',
    totalRecords: 8421930,
    data: [
      { txId: 'TX-DRX-000184291', amountBrl: 420000000, sender: 'Banco do Brasil Digital', receiver: 'Banco Paulista S.A.', instrument: 'WHOLESALE_DREX', status: 'LIQUIDADA' },
      { txId: 'TX-DRX-000184290', amountBrl: 184.90, sender: 'Ana Maria Silva', receiver: 'Mercado Local SP', instrument: 'TOKENISED_DEPOSIT', status: 'LIQUIDADA' },
      { txId: 'TX-DRX-000184289', amountBrl: 1000000, sender: 'Tesouro Nacional', receiver: 'Banco Paulista S.A.', instrument: 'TOKENISED_SECURITY', status: 'LIQUIDADA' }
    ]
  });
});

app.post('/api/v1/transactions', (req: Request, res: Response) => {
  const { senderWalletId, receiverWalletId, amount, purpose } = req.body;
  const newTxId = `TX-DRX-${Math.floor(100000000 + Math.random() * 900000000)}`;

  res.status(201).json({
    status: 'success',
    notice: 'DADOS SIMULADOS — LIQUIDAÇÃO PROGRAMÁVEL DREX',
    data: {
      txId: newTxId,
      senderWalletId,
      receiverWalletId,
      amountBrl: amount || 100.00,
      purpose: purpose || 'Transferência Direta DREX',
      status: 'LIQUIDADA',
      settlementTimestamp: new Date().toISOString(),
      blockNumber: 4821903,
      hash: `0x${Math.random().toString(16).substring(2, 18)}`
    }
  });
});

// 3. Assets & Tokenisation
app.get('/api/v1/assets', (req: Request, res: Response) => {
  res.json({
    status: 'success',
    notice: 'DADOS SIMULADOS — ATIVOS TOKENIZADOS DREX',
    data: [
      { code: 'LFT-2029-BR', name: 'Tesouro Selic 2029 (LFT)', category: 'TITULOS_PUBLICOS', priceBrl: 104850.20, yieldRate: '10.75%' },
      { code: 'NTNF-2031-BR', name: 'Tesouro Prefixado 2031 (NTN-F)', category: 'TITULOS_PUBLICOS', priceBrl: 982400.00, yieldRate: '11.20%' },
      { code: 'MATR-SP-98214', name: 'Apt 142 Jardins SP', category: 'IMOVEIS', priceBrl: 850000.00, yieldRate: 'N/A' },
      { code: 'CPR-SOJA-2026', name: 'CPR Soja Sorriso MT 5k Sacas', category: 'AGRONEGOCIO', priceBrl: 2400000.00, yieldRate: '9.80%' }
    ]
  });
});

// 4. Contracts
app.get('/api/v1/contracts', (req: Request, res: Response) => {
  res.json({
    status: 'success',
    data: [
      { id: 'sc-00182', title: 'Transferência Atômica de Imóvel Jardins SP', amountBrl: 850000, status: 'FUNDS_LOCKED' },
      { id: 'sc-00183', title: 'Financiamento Agrícola CPR Soja', amountBrl: 2400000, status: 'ASSET_LOCKED' }
    ]
  });
});

app.post('/api/v1/contracts/:id/execute', (req: Request, res: Response) => {
  const { id } = req.params;
  res.json({
    status: 'success',
    message: `Contrato Inteligente ${id} executado com sucesso e liquidado no ambiente Drex.`,
    executedAt: new Date().toISOString(),
    settlementStatus: 'LIQUIDADA'
  });
});

// 5. Institutions & Liquidity
app.get('/api/v1/institutions', (req: Request, res: Response) => {
  res.json({
    status: 'success',
    count: 142,
    notice: 'DADOS SIMULADOS',
    data: [
      { code: '000', name: 'Banco Central do Brasil', wholesaleBalanceBrl: 500000000000 },
      { code: '001', name: 'Banco do Brasil Digital', wholesaleBalanceBrl: 14200000000 },
      { code: '012', name: 'Banco Paulista S.A.', wholesaleBalanceBrl: 8400000000 }
    ]
  });
});

app.get('/api/v1/risk', (req: Request, res: Response) => {
  res.json({
    status: 'success',
    metrics: {
      liquidityRisk: 'BAIXO (1.2%)',
      settlementRisk: 'ZERO (Liquidação Atômica DvP)',
      counterpartyRisk: 'MINIMO',
      systemicStabilityIndex: '99.8 / 100'
    }
  });
});

// Setup Vite or static serving
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom'
    });
    app.use(vite.middlewares);

    app.use('*', async (req, res, next) => {
      if (req.originalUrl.startsWith('/api')) return next();
      try {
        const fs = await import('fs');
        let template = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(req.originalUrl, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      if (req.originalUrl.startsWith('/api')) return res.status(404).json({ error: 'Endpoint não encontrado' });
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`[DREX SYSTEM] Server running on http://localhost:${PORT}`);
  });
}

startServer();
