import React from 'react';
import {
  Coins,
  ArrowUpRight,
  ShieldCheck,
  Building2,
  Wallet,
  Zap,
  Landmark,
  Activity,
  ArrowRight,
  ArrowRightLeft,
  Sparkles,
  MapPin,
  CheckCircle2,
  Clock,
  Layers
} from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';

interface VisaoGeralProps {
  onOpenDemos: () => void;
  onNavigate: (tab: any) => void;
}

export const VisaoGeralView: React.FC<VisaoGeralProps> = ({ onOpenDemos, onNavigate }) => {
  const [metrics, setMetrics] = React.useState(drexEngine.getSystemMetrics());
  const [transactions, setTransactions] = React.useState(drexEngine.getTransactions());
  const [regionFlows, setRegionFlows] = React.useState(drexEngine.getRegionFlows());

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      setMetrics(drexEngine.getSystemMetrics());
      setTransactions(drexEngine.getTransactions());
    });
  }, []);

  const formatBrl = (val: number) => {
    if (val >= 1000000000) {
      return `R$ ${(val / 1000000000).toFixed(1).replace('.', ',')} B`;
    }
    if (val >= 1000000) {
      return `R$ ${(val / 1000000).toFixed(1).replace('.', ',')} M`;
    }
    return `R$ ${val.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`;
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner Notice */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-[#236B4B] animate-pulse" />
            <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">
              DREX — VISÃO GERAL DO SISTEMA FINANCEIRO DIGITAL
            </h1>
          </div>
          <p className="text-xs text-[#D9D8D2]/80 max-w-3xl">
            Simulação sintética em tempo real da infraestrutura de liquidação programável e ativos tokenizados do Real Digital.
            Acesso integrado para instituições financeiras autorizadas, custódia de depósitos e contratos inteligentes.
          </p>
        </div>
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={onOpenDemos}
            className="px-3 py-2 bg-[#236B4B] hover:bg-[#174D3A] text-white rounded text-xs font-semibold transition-all flex items-center gap-2 shadow"
          >
            <Sparkles className="w-4 h-4 text-[#C9A83E]" />
            EXECTUAR DEMONSTRAÇÕES
          </button>
        </div>
      </div>

      {/* Section 9 KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        
        {/* Metric 1 */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-3 space-y-1 hover:border-[#2E7775]/50 transition-colors">
          <div className="flex items-center justify-between text-[11px] text-[#D9D8D2]/60 uppercase tracking-wider font-semibold">
            <span>LIQUIDEZ DREX</span>
            <Coins className="w-3.5 h-3.5 text-[#2E7775]" />
          </div>
          <div className="font-mono-numbers text-lg font-bold text-[#F8F7F2]">
            {formatBrl(metrics.totalLiquidityBrl)}
          </div>
          <div className="text-[10px] text-[#236B4B] flex items-center gap-1 font-mono">
            <span>Disponível no BCB</span>
          </div>
          <div className="text-[9px] text-[#C9A83E] uppercase font-semibold">DADOS SIMULADOS</div>
        </div>

        {/* Metric 2 */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-3 space-y-1 hover:border-[#2E7775]/50 transition-colors">
          <div className="flex items-center justify-between text-[11px] text-[#D9D8D2]/60 uppercase tracking-wider font-semibold">
            <span>TRANSAÇÕES HOJE</span>
            <ArrowRightLeft className="w-3.5 h-3.5 text-[#2E7775]" />
          </div>
          <div className="font-mono-numbers text-lg font-bold text-[#F8F7F2]">
            {metrics.txCountToday.toLocaleString('pt-BR')}
          </div>
          <div className="text-[10px] text-[#236B4B] font-mono">
            +14.2% vs ontem
          </div>
          <div className="text-[9px] text-[#C9A83E] uppercase font-semibold">DADOS SIMULADOS</div>
        </div>

        {/* Metric 3 */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-3 space-y-1 hover:border-[#2E7775]/50 transition-colors">
          <div className="flex items-center justify-between text-[11px] text-[#D9D8D2]/60 uppercase tracking-wider font-semibold">
            <span>VALOR LIQUIDADO</span>
            <Zap className="w-3.5 h-3.5 text-[#2E7775]" />
          </div>
          <div className="font-mono-numbers text-lg font-bold text-[#F8F7F2]">
            {formatBrl(metrics.settledValueTodayBrl)}
          </div>
          <div className="text-[10px] text-[#236B4B] font-mono">
            Liquidação Atômica DvP
          </div>
          <div className="text-[9px] text-[#C9A83E] uppercase font-semibold">DADOS SIMULADOS</div>
        </div>

        {/* Metric 4 */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-3 space-y-1 hover:border-[#2E7775]/50 transition-colors">
          <div className="flex items-center justify-between text-[11px] text-[#D9D8D2]/60 uppercase tracking-wider font-semibold">
            <span>CONTRATOS ATIVOS</span>
            <Activity className="w-3.5 h-3.5 text-[#2E7775]" />
          </div>
          <div className="font-mono-numbers text-lg font-bold text-[#F8F7F2]">
            {metrics.activeContractsCount.toLocaleString('pt-BR')}
          </div>
          <div className="text-[10px] text-[#236B4B] font-mono">
            Em execução programada
          </div>
          <div className="text-[9px] text-[#C9A83E] uppercase font-semibold">DADOS SIMULADOS</div>
        </div>

        {/* Metric 5 */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-3 space-y-1 hover:border-[#2E7775]/50 transition-colors">
          <div className="flex items-center justify-between text-[11px] text-[#D9D8D2]/60 uppercase tracking-wider font-semibold">
            <span>ATIVOS TOKENIZADOS</span>
            <Building2 className="w-3.5 h-3.5 text-[#2E7775]" />
          </div>
          <div className="font-mono-numbers text-lg font-bold text-[#F8F7F2]">
            {formatBrl(metrics.tokenisedAssetsValueBrl)}
          </div>
          <div className="text-[10px] text-[#236B4B] font-mono">
            Títulos / CPR / Imóveis
          </div>
          <div className="text-[9px] text-[#C9A83E] uppercase font-semibold">DADOS SIMULADOS</div>
        </div>

        {/* Metric 6 */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-3 space-y-1 hover:border-[#2E7775]/50 transition-colors">
          <div className="flex items-center justify-between text-[11px] text-[#D9D8D2]/60 uppercase tracking-wider font-semibold">
            <span>INSTITUIÇÕES</span>
            <Landmark className="w-3.5 h-3.5 text-[#2E7775]" />
          </div>
          <div className="font-mono-numbers text-lg font-bold text-[#F8F7F2]">
            {metrics.participatingInstitutionsCount}
          </div>
          <div className="text-[10px] text-[#236B4B] font-mono">
            Intermediários Autorizados
          </div>
          <div className="text-[9px] text-[#C9A83E] uppercase font-semibold">DADOS SIMULADOS</div>
        </div>

        {/* Metric 7 */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-3 space-y-1 hover:border-[#2E7775]/50 transition-colors">
          <div className="flex items-center justify-between text-[11px] text-[#D9D8D2]/60 uppercase tracking-wider font-semibold">
            <span>CARTEIRAS ATIVAS</span>
            <Wallet className="w-3.5 h-3.5 text-[#2E7775]" />
          </div>
          <div className="font-mono-numbers text-lg font-bold text-[#F8F7F2]">
            12,8 M
          </div>
          <div className="text-[10px] text-[#236B4B] font-mono">
            Pessoas e Empresas
          </div>
          <div className="text-[9px] text-[#C9A83E] uppercase font-semibold">DADOS SIMULADOS</div>
        </div>

      </div>

      {/* Monetary Flow Architecture Diagram & Real-World Distinction */}
      <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-5 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="font-brand text-base font-bold text-[#F8F7F2] flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#2E7775]" />
            ARQUITETURA MONETÁRIA DE 2 NÍVEIS DO DREX (PILOTO BANCO CENTRAL)
          </h2>
          <span className="text-xs text-[#D9D8D2]/60">Diferenciação clara dos instrumentos financeiros</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-center text-xs">
          
          {/* Level 1: BCB Wholesale */}
          <div className="bg-[#111516] border border-[#163D56] rounded p-3 space-y-2 flex flex-col justify-between">
            <div>
              <div className="text-[10px] text-[#2E7775] font-bold uppercase tracking-wider">NÍVEL 1 — ATACADO</div>
              <div className="font-bold text-[#F8F7F2] text-sm mt-1">BANCO CENTRAL</div>
              <div className="text-[11px] text-[#D9D8D2]/70 mt-1">Drex Atacado (Wholesale CBDC)</div>
            </div>
            <div className="pt-2 border-t border-[#24292A] text-[10px] text-[#236B4B] font-mono">
              Reservas Bancárias de Liquidação
            </div>
          </div>

          <div className="hidden md:flex items-center justify-center text-[#2E7775]">
            <ArrowRight className="w-5 h-5" />
          </div>

          {/* Level 2: Intermediaries / Tokenised Deposits */}
          <div className="bg-[#111516] border border-[#163D56] rounded p-3 space-y-2 flex flex-col justify-between">
            <div>
              <div className="text-[10px] text-[#2E7775] font-bold uppercase tracking-wider">INTERMEDIÁRIOS</div>
              <div className="font-bold text-[#F8F7F2] text-sm mt-1">INSTITUIÇÕES FINANCEIRAS</div>
              <div className="text-[11px] text-[#D9D8D2]/70 mt-1">Depósitos Tokenizados (Retail Money)</div>
            </div>
            <div className="pt-2 border-t border-[#24292A] text-[10px] text-[#236B4B] font-mono">
              Lastreado 1:1 em Drex Atacado
            </div>
          </div>

          <div className="hidden md:flex items-center justify-center text-[#2E7775]">
            <ArrowRight className="w-5 h-5" />
          </div>

          {/* Level 3: Users & Smart Contracts */}
          <div className="bg-[#111516] border border-[#163D56] rounded p-3 space-y-2 flex flex-col justify-between">
            <div>
              <div className="text-[10px] text-[#2E7775] font-bold uppercase tracking-wider">NÍVEL RETAIL & CONTRATOS</div>
              <div className="font-bold text-[#F8F7F2] text-sm mt-1">CARTEIRAS & ATIVOS</div>
              <div className="text-[11px] text-[#D9D8D2]/70 mt-1">Liquidação Programável / DvP</div>
            </div>
            <div className="pt-2 border-t border-[#24292A] text-[10px] text-[#236B4B] font-mono">
              Imóveis, Títulos, Recebíveis, Agrobusiness
            </div>
          </div>

        </div>
      </div>

      {/* Economic Flow Map of Brazil & Live Ledger Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Brazil Flow Map Component */}
        <div className="lg:col-span-2 bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="font-brand text-base font-bold text-[#F8F7F2] flex items-center gap-2">
                <MapPin className="w-4 h-4 text-[#236B4B]" />
                FLUXO FINANCEIRO REGIONAL NO BRASIL
              </h2>
              <p className="text-xs text-[#D9D8D2]/60">Volumes e taxa de transação sintética por praça financeira</p>
            </div>
            <span className="text-[10px] bg-[#111516] text-[#C9A83E] px-2 py-1 rounded font-mono border border-[#C9A83E]/30 uppercase">
              MAPA ECONÔMICO — DADOS SIMULADOS
            </span>
          </div>

          {/* Visual Brazil Map / Flow Nodes Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {regionFlows.map(rf => (
              <div key={rf.region} className="bg-[#111516] border border-[#D9D8D2]/10 rounded p-3 space-y-1 hover:border-[#2E7775]/60 transition-colors">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-[#F8F7F2]">{rf.cityName}</span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#163D56] text-[#2E7775]">
                    {rf.region}
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs font-mono-numbers pt-1">
                  <span className="text-[#D9D8D2]/60 text-[11px]">Volume:</span>
                  <span className="font-semibold text-[#236B4B]">R$ {rf.volumeBrlMillions.toLocaleString('pt-BR')} M</span>
                </div>
                <div className="flex items-center justify-between text-[11px] font-mono text-[#D9D8D2]/60">
                  <span>Tx/seg:</span>
                  <span>{rf.activeTxRate} ops</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Transaction Ledger Ticker */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-5 space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="font-brand text-base font-bold text-[#F8F7F2] flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#2E7775]" />
                LEDGER EM TEMPO REAL
              </h2>
              <button
                onClick={() => onNavigate('TRANSACOES')}
                className="text-xs text-[#2E7775] hover:underline"
              >
                Ver Todas →
              </button>
            </div>

            <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
              {transactions.slice(0, 7).map(tx => (
                <div key={tx.id} className="bg-[#111516] border border-[#D9D8D2]/10 rounded p-2.5 text-xs space-y-1 hover:border-[#2E7775]/50 transition-colors">
                  <div className="flex items-center justify-between font-mono text-[11px]">
                    <span className="text-[#2E7775] font-bold">{tx.txId}</span>
                    <span className="text-[#236B4B] font-semibold">{tx.status}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-[#D9D8D2]/80 truncate max-w-[150px]">{tx.senderName}</span>
                    <ArrowRight className="w-3 h-3 text-[#D9D8D2]/40 shrink-0" />
                    <span className="text-[#D9D8D2]/80 truncate max-w-[150px]">{tx.receiverName}</span>
                  </div>
                  <div className="flex items-center justify-between font-mono-numbers text-xs pt-0.5">
                    <span className="text-[#D9D8D2]/60 text-[10px]">{tx.instrumentType}</span>
                    <span className="font-bold text-[#F8F7F2]">R$ {tx.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-2 border-t border-[#D9D8D2]/10 text-[10px] text-[#D9D8D2]/50 flex items-center justify-between font-mono">
            <span>Bloco Recente: #{metrics.lastBlockNumber}</span>
            <span>Latência Média: {metrics.averageSettlementLatencyMs}ms</span>
          </div>
        </div>

      </div>

    </div>
  );
};
