import React from 'react';
import { Terminal, Send, Play, Code2, Copy, CheckCircle2 } from 'lucide-react';

export const DesenvolvedorView: React.FC = () => {
  const [selectedEndpoint, setSelectedEndpoint] = React.useState('GET /api/v1/wallets');
  const [responseJson, setResponseJson] = React.useState<string>('Clique em "Executar Chamada API" para testar o endpoint.');
  const [isLoading, setIsLoading] = React.useState(false);
  const [activeTab, setActiveTab] = React.useState<'API' | 'R_NOTEBOOK' | 'RUST_ENGINE'>('API');

  const handleCallApi = async () => {
    setIsLoading(true);
    try {
      let path = '/api/v1/wallets';
      let method = 'GET';
      let body: any = null;

      if (selectedEndpoint === 'GET /api/v1/transactions') path = '/api/v1/transactions';
      if (selectedEndpoint === 'POST /api/v1/transactions') {
        path = '/api/v1/transactions';
        method = 'POST';
        body = JSON.stringify({
          senderWalletId: 'w-pers-01',
          receiverWalletId: 'w-corp-01',
          amount: 1250.00,
          purpose: 'Teste de Desenvolvedor via API Explorer'
        });
      }
      if (selectedEndpoint === 'GET /api/v1/assets') path = '/api/v1/assets';
      if (selectedEndpoint === 'GET /api/v1/contracts') path = '/api/v1/contracts';
      if (selectedEndpoint === 'GET /api/v1/institutions') path = '/api/v1/institutions';
      if (selectedEndpoint === 'GET /api/v1/risk') path = '/api/v1/risk';

      const res = await fetch(path, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body
      });
      const data = await res.json();
      setResponseJson(JSON.stringify(data, null, 2));
    } catch (e: any) {
      setResponseJson(JSON.stringify({ error: e.message || 'Erro ao conectar à API' }, null, 2));
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <Terminal className="w-5 h-5 text-[#2E7775]" />
          <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">DREX DEV — CONSOLE DE DESENVOLVEDOR & EXPLORADOR DE API REST</h1>
        </div>
        <p className="text-xs text-[#D9D8D2]/80 mt-1">
          Ambiente de testes para integração de sistemas bancários com os endpoints OpenAPI do Drex, execução de notebooks de pesquisa em R e simulação do motor de liquidação em Rust.
        </p>
      </div>

      {/* Tabs Selector */}
      <div className="flex items-center gap-2 border-b border-[#D9D8D2]/10 pb-2 text-xs font-mono">
        <button
          onClick={() => setActiveTab('API')}
          className={`px-3 py-1.5 rounded transition-colors ${
            activeTab === 'API' ? 'bg-[#163D56] text-[#F8F7F2] font-bold border border-[#2E7775]' : 'text-[#D9D8D2]/60 hover:text-white'
          }`}
        >
          EXPLORADOR DE API REST
        </button>
        <button
          onClick={() => setActiveTab('R_NOTEBOOK')}
          className={`px-3 py-1.5 rounded transition-colors ${
            activeTab === 'R_NOTEBOOK' ? 'bg-[#163D56] text-[#F8F7F2] font-bold border border-[#2E7775]' : 'text-[#D9D8D2]/60 hover:text-white'
          }`}
        >
          CADERNO DE PESQUISA EM R (PESQUISA MACRO)
        </button>
        <button
          onClick={() => setActiveTab('RUST_ENGINE')}
          className={`px-3 py-1.5 rounded transition-colors ${
            activeTab === 'RUST_ENGINE' ? 'bg-[#163D56] text-[#F8F7F2] font-bold border border-[#2E7775]' : 'text-[#D9D8D2]/60 hover:text-white'
          }`}
        >
          MOTOR DE LIQUIDAÇÃO EM RUST (SANDBOX)
        </button>
      </div>

      {/* Tab 1: API Explorer */}
      {activeTab === 'API' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-5 space-y-4">
            <h2 className="font-brand text-sm font-bold text-[#F8F7F2]">SELECIONAR ENDPOINT</h2>

            <div className="space-y-2 text-xs font-mono">
              {[
                'GET /api/v1/wallets',
                'GET /api/v1/transactions',
                'POST /api/v1/transactions',
                'GET /api/v1/assets',
                'GET /api/v1/contracts',
                'GET /api/v1/institutions',
                'GET /api/v1/risk'
              ].map(ep => (
                <button
                  key={ep}
                  onClick={() => setSelectedEndpoint(ep)}
                  className={`w-full text-left p-2.5 rounded border transition-colors ${
                    selectedEndpoint === ep
                      ? 'bg-[#163D56] border-[#2E7775] text-[#F8F7F2] font-bold'
                      : 'bg-[#111516] border-[#D9D8D2]/10 text-[#D9D8D2]/70 hover:border-[#2E7775]/40'
                  }`}
                >
                  {ep}
                </button>
              ))}
            </div>

            <button
              onClick={handleCallApi}
              disabled={isLoading}
              className="w-full bg-[#236B4B] hover:bg-[#174D3A] text-white py-2 rounded text-xs font-semibold transition-colors flex items-center justify-center gap-2"
            >
              <Play className="w-3.5 h-3.5 fill-white" />
              {isLoading ? 'Chamando Endpoint...' : 'Executar Chamada API'}
            </button>
          </div>

          <div className="lg:col-span-2 bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-5 space-y-3">
            <div className="flex items-center justify-between border-b border-[#D9D8D2]/10 pb-2">
              <span className="font-brand text-sm font-bold text-[#F8F7F2]">RESPOSTA HTTP (JSON)</span>
              <span className="text-[10px] font-mono text-[#236B4B]">STATUS 200 OK</span>
            </div>

            <pre className="bg-[#111516] p-4 rounded border border-[#D9D8D2]/10 font-mono text-xs text-[#2E7775] overflow-x-auto max-h-[420px]">
              {responseJson}
            </pre>
          </div>
        </div>
      )}

      {/* Tab 2: R Notebook Research */}
      {activeTab === 'R_NOTEBOOK' && (
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-6 space-y-4">
          <h2 className="font-brand text-base font-bold text-[#F8F7F2]">CADERNO DE PESQUISA MONETÁRIA DREX (SINTAXE R REPRODUTÍVEL)</h2>
          <p className="text-xs text-[#D9D8D2]/80">
            Funções de análise estatística de estabilidade e taxa de liquidação interbancária para pesquisadores do Banco Central do Brasil.
          </p>

          <pre className="bg-[#111516] p-4 rounded border border-[#2E7775]/40 font-mono text-xs text-[#C9A83E] overflow-x-auto">
{`# Drex Monetary Research Notebook (R Package)
library(drexr)
library(ggplot2)

# Carregar séries temporais sintéticas do simulador Drex
df_drex <- drex_monetary_scenario(seed = "DREX-2026-BRAZIL", horizon_days = 90)

# Calcular velocidade de circulação do Drex Atacado vs Depósitos Tokenizados
v_wholesale <- drex_velocity(df_drex, level = "wholesale")
v_retail    <- drex_velocity(df_drex, level = "tokenised_deposits")

cat("Velocidade Anualizada Drex Atacado:", v_wholesale, "\\n")
cat("Velocidade Anualizada Depósitos Tokenizados:", v_retail, "\\n")

# Teste de Estresse de Liquidez Interbancária
stress_results <- drex_stress_test(
  banks = 142, 
  liquidity_shock_percent = 0.85, 
  collateral_haircut = 0.10
)

summary(stress_results)`}
          </pre>
        </div>
      )}

      {/* Tab 3: Rust Engine */}
      {activeTab === 'RUST_ENGINE' && (
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-6 space-y-4">
          <h2 className="font-brand text-base font-bold text-[#F8F7F2]">NÚCLEO DE LIQUIDAÇÃO EM RUST (RUST LEDGER CORE)</h2>
          <p className="text-xs text-[#D9D8D2]/80">
            Protótipo em Rust para motor determinístico de alta performance com verificador de invariantes financeiros.
          </p>

          <pre className="bg-[#111516] p-4 rounded border border-[#2E7775]/40 font-mono text-xs text-[#2E7775] overflow-x-auto">
{`// Drex Atomic Settlement Engine in Rust
pub struct AtomicSwapContract {
    pub contract_id: String,
    pub asset_id: String,
    pub buyer_wallet: String,
    pub seller_wallet: String,
    pub amount_brl: u64,
}

impl AtomicSwapContract {
    pub fn execute_settlement(&self, ledger: &mut LedgerState) -> Result<SettlementProof, ExecutionError> {
        // Step 1: Verify invariant and sufficient funds
        if !ledger.has_sufficient_balance(&self.buyer_wallet, self.amount_brl) {
            return Err(ExecutionError::InsufficientBalance);
        }

        // Step 2: Atomic Swap
        ledger.transfer_drex(&self.buyer_wallet, &self.seller_wallet, self.amount_brl)?;
        ledger.transfer_asset(&self.seller_wallet, &self.buyer_wallet, &self.asset_id)?;

        Ok(SettlementProof::new(&self.contract_id))
    }
}`}
          </pre>
        </div>
      )}

    </div>
  );
};
