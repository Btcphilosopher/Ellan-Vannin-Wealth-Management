import React from 'react';
import { Wallet, Send, ArrowDownLeft, Lock, ShieldCheck, CheckCircle2, User, Building, Landmark, Scale } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';
import { Wallet as WalletType, WalletType as WalletKind } from '../../types/drex';

export const CarteirasView: React.FC = () => {
  const [wallets, setWallets] = React.useState<WalletType[]>(drexEngine.getWallets());
  const [selectedWallet, setSelectedWallet] = React.useState<WalletType>(wallets[0]);
  const [sendModalOpen, setSendModalOpen] = React.useState(false);
  
  // Send form
  const [receiverId, setReceiverId] = React.useState(wallets[1]?.id || '');
  const [amount, setAmount] = React.useState('150.00');
  const [purpose, setPurpose] = React.useState('Pagamento via Depósito Tokenizado Drex');
  const [txSuccess, setTxSuccess] = React.useState<string | null>(null);

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      const updated = drexEngine.getWallets();
      setWallets(updated);
      const cur = updated.find(w => w.id === selectedWallet.id);
      if (cur) setSelectedWallet(cur);
    });
  }, [selectedWallet.id]);

  const handleSendDrex = (e: React.FormEvent) => {
    e.preventDefault();
    const val = parseFloat(amount);
    if (!isNaN(val) && val > 0) {
      const tx = drexEngine.createTransaction(
        selectedWallet.id,
        receiverId,
        val,
        purpose,
        selectedWallet.type === 'BANK' ? 'WHOLESALE_DREX' : 'TOKENISED_DEPOSIT'
      );
      setTxSuccess(`Transação realizada com sucesso! ID: ${tx.txId}`);
      setTimeout(() => {
        setSendModalOpen(false);
        setTxSuccess(null);
      }, 2000);
    }
  };

  const getWalletBadge = (type: WalletKind) => {
    switch (type) {
      case 'PERSON':
        return { label: 'CARTEIRA PESSOAL', icon: User, color: 'text-[#2E7775] border-[#2E7775]/40 bg-[#163D56]/30' };
      case 'BUSINESS':
        return { label: 'CARTEIRA EMPRESARIAL', icon: Building, color: 'text-[#C9A83E] border-[#C9A83E]/40 bg-[#24292A]' };
      case 'BANK':
        return { label: 'CARTEIRA INSTITUCIONAL', icon: Landmark, color: 'text-[#236B4B] border-[#236B4B]/40 bg-[#174D3A]/30' };
      case 'GOVERNMENT':
        return { label: 'CARTEIRA PÚBLICA', icon: Scale, color: 'text-sky-400 border-sky-400/40 bg-sky-950/30' };
      case 'ESCROW':
        return { label: 'CARTEIRA DE GARANTIA (ESCROW)', icon: Lock, color: 'text-amber-400 border-amber-400/40 bg-amber-950/30' };
    }
  };

  const BadgeIcon = getWalletBadge(selectedWallet.type).icon;

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Wallet className="w-5 h-5 text-[#2E7775]" />
            <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">SISTEMA DE CARTEIRAS DREX</h1>
          </div>
          <p className="text-xs text-[#D9D8D2]/80 mt-1">
            Contas digitais registradas no ecossistema DREX com gestão de limites regulatórios, permissões e saldos em depósitos tokenizados ou moeda central de atacado.
          </p>
        </div>
        <button
          onClick={() => setSendModalOpen(true)}
          className="px-4 py-2 bg-[#236B4B] hover:bg-[#174D3A] text-white rounded text-xs font-semibold transition-all flex items-center gap-2 shadow shrink-0"
        >
          <Send className="w-4 h-4 text-white" />
          ENVIAR DREX
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Wallet Selector List */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-4 space-y-3">
          <h2 className="font-brand text-sm font-bold text-[#F8F7F2]">CARTEIRAS SIMULADAS</h2>
          
          <div className="space-y-2">
            {wallets.map(w => {
              const isSelected = w.id === selectedWallet.id;
              const badge = getWalletBadge(w.type);
              const Icon = badge.icon;
              return (
                <button
                  key={w.id}
                  onClick={() => setSelectedWallet(w)}
                  className={`w-full text-left p-3 rounded border transition-all space-y-1 ${
                    isSelected
                      ? 'bg-[#163D56] border-[#2E7775] text-[#F8F7F2]'
                      : 'bg-[#111516] border-[#D9D8D2]/10 text-[#D9D8D2]/80 hover:border-[#2E7775]/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs truncate max-w-[180px]">{w.name}</span>
                    <span className={`text-[9px] px-1.5 py-0.5 rounded border uppercase font-mono ${badge.color}`}>
                      {w.type}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#D9D8D2]/60 truncate">{w.institutionName}</div>
                  <div className="font-mono-numbers text-sm font-bold pt-1 text-[#F8F7F2]">
                    R$ {w.totalBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Wallet Details Card */}
        <div className="lg:col-span-2 bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-6 space-y-6">
          
          {/* Top Wallet Info */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-[#D9D8D2]/10">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className={`text-xs px-2 py-0.5 rounded border uppercase font-mono font-bold flex items-center gap-1 ${getWalletBadge(selectedWallet.type).color}`}>
                  <BadgeIcon className="w-3.5 h-3.5" />
                  {getWalletBadge(selectedWallet.type).label}
                </span>
                <span className="text-xs text-[#236B4B] font-mono">STATUS: {selectedWallet.status}</span>
              </div>
              <h2 className="font-brand text-xl font-bold text-[#F8F7F2]">{selectedWallet.name}</h2>
              <p className="text-xs text-[#D9D8D2]/70 font-mono">
                Titular: {selectedWallet.ownerName} ({selectedWallet.cpfCnpjMasked})
              </p>
            </div>

            <div className="bg-[#111516] p-3 rounded border border-[#2E7775]/30 text-right space-y-1">
              <span className="text-[10px] text-[#D9D8D2]/60 uppercase tracking-wider font-semibold">SALDO TOTAL DISPONÍVEL</span>
              <div className="font-mono-numbers text-2xl font-bold text-[#236B4B]">
                R$ {selectedWallet.totalBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
            </div>
          </div>

          {/* Balance Breakdown by Instrument */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="bg-[#111516] p-4 rounded border border-[#D9D8D2]/10 space-y-1">
              <span className="text-xs text-[#D9D8D2]/60 font-semibold">SALDO EM DEPÓSITO TOKENIZADO</span>
              <div className="font-mono-numbers text-lg font-bold text-[#F8F7F2]">
                R$ {selectedWallet.tokenisedDepositBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
              <p className="text-[10px] text-[#D9D8D2]/50">Moeda comercial de varejo custodiada em {selectedWallet.institutionName}</p>
            </div>

            <div className="bg-[#111516] p-4 rounded border border-[#D9D8D2]/10 space-y-1">
              <span className="text-xs text-[#D9D8D2]/60 font-semibold">SALDO EM DREX ATACADO (RESERVAS)</span>
              <div className="font-mono-numbers text-lg font-bold text-[#2E7775]">
                R$ {selectedWallet.wholesaleBalance.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </div>
              <p className="text-[10px] text-[#D9D8D2]/50">Passivo direto no Banco Central do Brasil</p>
            </div>
          </div>

          {/* Limits & Regulatory Controls */}
          <div className="space-y-3 pt-2">
            <h3 className="font-brand text-sm font-bold text-[#F8F7F2] flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#2E7775]" />
              LIMITES REGULATÓRIOS E OPERACIONAIS
            </h3>

            <div className="space-y-2 text-xs">
              <div>
                <div className="flex justify-between text-[#D9D8D2]/80 font-mono mb-1">
                  <span>Limite Diário de Transferência:</span>
                  <span>R$ {selectedWallet.limits.dailyUsed.toLocaleString('pt-BR')} / R$ {selectedWallet.limits.dailyLimit.toLocaleString('pt-BR')}</span>
                </div>
                <div className="w-full bg-[#111516] h-2 rounded overflow-hidden">
                  <div
                    className="bg-[#236B4B] h-full transition-all"
                    style={{ width: `${Math.min(100, (selectedWallet.limits.dailyUsed / selectedWallet.limits.dailyLimit) * 100)}%` }}
                  />
                </div>
              </div>

              <div className="flex justify-between text-[#D9D8D2]/60 font-mono pt-1">
                <span>Limite Mensal Aprovado:</span>
                <span>R$ {selectedWallet.limits.monthlyLimit.toLocaleString('pt-BR')}</span>
              </div>
            </div>
          </div>

        </div>

      </div>

      {/* Send Modal */}
      {sendModalOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#24292A] border border-[#2E7775] rounded-lg max-w-md w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#D9D8D2]/10 pb-3">
              <h3 className="font-brand text-base font-bold text-[#F8F7F2]">ENVIAR DREX / LIQUIDAÇÃO PROGRAMADA</h3>
              <button
                onClick={() => setSendModalOpen(false)}
                className="text-[#D9D8D2]/60 hover:text-white"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSendDrex} className="space-y-4 text-xs">
              <div className="space-y-1">
                <label className="text-[#D9D8D2]/70 font-semibold">Carteira Origem:</label>
                <div className="p-2 bg-[#111516] rounded font-bold text-[#F8F7F2] border border-[#D9D8D2]/10">
                  {selectedWallet.name} ({selectedWallet.institutionName})
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[#D9D8D2]/70 font-semibold">Carteira Destino:</label>
                <select
                  value={receiverId}
                  onChange={e => setReceiverId(e.target.value)}
                  className="w-full bg-[#111516] border border-[#D9D8D2]/20 rounded p-2 text-[#F8F7F2] font-mono focus:border-[#2E7775] outline-none"
                >
                  {wallets.filter(w => w.id !== selectedWallet.id).map(w => (
                    <option key={w.id} value={w.id}>
                      {w.name} ({w.institutionName})
                    </option>
                  ))}
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[#D9D8D2]/70 font-semibold">Valor da Transferência (R$):</label>
                <input
                  type="number"
                  step="0.01"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  className="w-full bg-[#111516] border border-[#D9D8D2]/20 rounded p-2 text-[#F8F7F2] font-mono focus:border-[#2E7775] outline-none"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[#D9D8D2]/70 font-semibold">Finalidade da Operação:</label>
                <input
                  type="text"
                  value={purpose}
                  onChange={e => setPurpose(e.target.value)}
                  className="w-full bg-[#111516] border border-[#D9D8D2]/20 rounded p-2 text-[#F8F7F2] focus:border-[#2E7775] outline-none"
                />
              </div>

              {txSuccess && (
                <div className="p-2 bg-[#174D3A] text-[#236B4B] border border-[#236B4B] rounded font-mono text-[11px] flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>{txSuccess}</span>
                </div>
              )}

              <div className="flex gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setSendModalOpen(false)}
                  className="flex-1 bg-[#111516] hover:bg-[#111516]/80 text-[#D9D8D2]/80 py-2 rounded font-semibold"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 bg-[#236B4B] hover:bg-[#174D3A] text-white py-2 rounded font-semibold transition-colors"
                >
                  Confirmar Transferência
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
