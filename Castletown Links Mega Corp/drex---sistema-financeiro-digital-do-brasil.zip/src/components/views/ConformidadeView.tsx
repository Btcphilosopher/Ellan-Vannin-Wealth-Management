import React from 'react';
import { Scale, AlertTriangle, CheckCircle2, ShieldAlert } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';
import { ComplianceAlert } from '../../types/drex';

export const ConformidadeView: React.FC = () => {
  const [alerts, setAlerts] = React.useState<ComplianceAlert[]>(drexEngine.getAlerts());

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      setAlerts(drexEngine.getAlerts());
    });
  }, []);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <Scale className="w-5 h-5 text-[#2E7775]" />
          <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">PAINEL DE CONFORMIDADE, MONITORAMENTO E PREVENÇÃO A LAVAGEM DE DINHEIRO (AML/PLD)</h1>
        </div>
        <p className="text-xs text-[#D9D8D2]/80 mt-1">
          Supervisão automatizada de padrões atípicos, fracionamento de operações e triagem contra listas de sanções regulatórias no ambiente Drex.
        </p>
      </div>

      {/* Alerts Table */}
      <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg overflow-hidden shadow">
        <div className="p-4 border-b border-[#D9D8D2]/10 font-brand text-sm font-bold text-[#F8F7F2] flex items-center justify-between">
          <span>ALERTAS REGULATÓRIOS EM ANÁLISE</span>
          <span className="text-xs font-mono text-[#C9A83E]">{alerts.length} Casos Suspeitos</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#111516] border-b border-[#D9D8D2]/10 text-[#D9D8D2]/60 font-mono uppercase text-[10px]">
              <tr>
                <th className="p-3">ID ALERTA</th>
                <th className="p-3">TX ID</th>
                <th className="p-3">INSTITUIÇÃO</th>
                <th className="p-3">PADRÃO ATÍPICO DETECTADO</th>
                <th className="p-3 text-right">VALOR (R$)</th>
                <th className="p-3">SCORE DE RISCO</th>
                <th className="p-3">STATUS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D9D8D2]/10">
              {alerts.map(alt => (
                <tr key={alt.id} className="hover:bg-[#163D56]/20 transition-colors">
                  <td className="p-3 font-mono font-bold text-[#2E7775]">{alt.id}</td>
                  <td className="p-3 font-mono text-[#F8F7F2]">{alt.txId}</td>
                  <td className="p-3 text-[#D9D8D2]/80 font-medium">{alt.institutionName}</td>
                  <td className="p-3 text-red-300 font-medium max-w-xs">{alt.pattern}</td>
                  <td className="p-3 text-right font-mono-numbers font-bold text-red-400">
                    R$ {alt.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="p-3 font-mono">
                    <span className="px-2 py-0.5 rounded bg-red-950/60 text-red-400 font-bold border border-red-500/30">
                      {alt.riskScore} / 100
                    </span>
                  </td>
                  <td className="p-3 font-mono text-[10px] text-[#C9A83E] font-bold">
                    {alt.status}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
