import React from 'react';
import { ArrowRightLeft, Search, Filter, ShieldCheck, ExternalLink, CheckCircle2 } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';
import { Transaction } from '../../types/drex';

export const TransacoesView: React.FC = () => {
  const [transactions, setTransactions] = React.useState<Transaction[]>(drexEngine.getTransactions());
  const [searchTerm, setSearchTerm] = React.useState('');
  const [selectedTx, setSelectedTx] = React.useState<Transaction | null>(null);

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      setTransactions(drexEngine.getTransactions());
    });
  }, []);

  const filteredTx = transactions.filter(tx => {
    const query = searchTerm.toLowerCase();
    return (
      tx.txId.toLowerCase().includes(query) ||
      tx.senderName.toLowerCase().includes(query) ||
      tx.receiverName.toLowerCase().includes(query) ||
      tx.purpose.toLowerCase().includes(query) ||
      tx.hash.toLowerCase().includes(query)
    );
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <ArrowRightLeft className="w-5 h-5 text-[#2E7775]" />
          <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">EXPLORADOR DE TRANSAÇÕES E LEDGER DREX</h1>
        </div>
        <p className="text-xs text-[#D9D8D2]/80 mt-1">
          Registro determinístico imutável de todas as transferências, liquidações atômicas e trocas de ativos no ecossistema DREX.
        </p>
      </div>

      {/* Search Bar & Filter Controls */}
      <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-4 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-96">
          <Search className="w-4 h-4 text-[#D9D8D2]/40 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="Buscar por Tx ID, Carteira, Hash ou Ativo..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full bg-[#111516] border border-[#D9D8D2]/20 rounded pl-9 pr-3 py-2 text-xs text-[#F8F7F2] focus:border-[#2E7775] outline-none"
          />
        </div>

        <div className="text-xs text-[#D9D8D2]/60 font-mono">
          Exibindo {filteredTx.length} de {transactions.length} transações recentes no bloco ativo
        </div>
      </div>

      {/* Ledger Table */}
      <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg overflow-hidden shadow">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#111516] border-b border-[#D9D8D2]/10 text-[#D9D8D2]/60 font-mono uppercase text-[10px]">
              <tr>
                <th className="p-3">ID TRANSAÇÃO</th>
                <th className="p-3">DATA / BLOCO</th>
                <th className="p-3">PAGADOR (REMETENTE)</th>
                <th className="p-3">RECEBEDOR (DESTINATÁRIO)</th>
                <th className="p-3">INSTRUMENTO</th>
                <th className="p-3 text-right">VALOR (R$)</th>
                <th className="p-3">STATUS</th>
                <th className="p-3 text-center">AÇÕES</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D9D8D2]/10">
              {filteredTx.map(tx => (
                <tr key={tx.id} className="hover:bg-[#163D56]/20 transition-colors">
                  <td className="p-3 font-mono font-bold text-[#2E7775]">
                    {tx.txId}
                  </td>
                  <td className="p-3 font-mono text-[11px] text-[#D9D8D2]/70">
                    <div>{new Date(tx.timestamp).toLocaleTimeString()}</div>
                    <div className="text-[9px] text-[#D9D8D2]/40"># {tx.blockNumber}</div>
                  </td>
                  <td className="p-3 font-medium text-[#F8F7F2]">
                    <div>{tx.senderName}</div>
                    <div className="text-[10px] text-[#D9D8D2]/50">{tx.institutionName}</div>
                  </td>
                  <td className="p-3 font-medium text-[#F8F7F2]">
                    <div>{tx.receiverName}</div>
                  </td>
                  <td className="p-3 font-mono text-[10px] text-[#C9A83E]">
                    {tx.instrumentType}
                  </td>
                  <td className="p-3 text-right font-mono-numbers font-bold text-[#236B4B]">
                    R$ {tx.amount.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </td>
                  <td className="p-3">
                    <span className="px-2 py-0.5 rounded bg-[#174D3A] text-[#236B4B] border border-[#236B4B]/40 font-mono text-[10px] font-bold">
                      {tx.status}
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <button
                      onClick={() => setSelectedTx(tx)}
                      className="px-2.5 py-1 bg-[#163D56] hover:bg-[#2E7775] text-[#F8F7F2] rounded text-[11px] font-medium transition-colors"
                    >
                      Detalhes
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Transaction Detail Modal */}
      {selectedTx && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#24292A] border border-[#2E7775] rounded-lg max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#D9D8D2]/10 pb-3">
              <div>
                <h3 className="font-brand text-base font-bold text-[#F8F7F2]">DETALHES DA TRANSAÇÃO DREX</h3>
                <span className="font-mono text-xs text-[#2E7775]">{selectedTx.txId}</span>
              </div>
              <button onClick={() => setSelectedTx(null)} className="text-[#D9D8D2]/60 hover:text-white">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs font-mono">
              <div className="bg-[#111516] p-3 rounded border border-[#D9D8D2]/10 space-y-2">
                <div className="flex justify-between">
                  <span className="text-[#D9D8D2]/60">Status de Liquidação:</span>
                  <span className="text-[#236B4B] font-bold">{selectedTx.status}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D9D8D2]/60">Modo de Liquidação:</span>
                  <span className="text-[#2E7775]">{selectedTx.settlementMode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D9D8D2]/60">Garantia de Privacidade:</span>
                  <span className="text-[#C9A83E]">{selectedTx.privacyStatus}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D9D8D2]/60">Conformidade AML:</span>
                  <span className="text-[#236B4B]">{selectedTx.complianceStatus}</span>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[#D9D8D2]/60">Hash Criptográfico do Bloco:</span>
                <div className="p-2 bg-[#111516] rounded text-[11px] text-[#2E7775] break-all border border-[#D9D8D2]/10">
                  {selectedTx.hash}
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[#D9D8D2]/60">Finalidade / Motivo:</span>
                <div className="p-2 bg-[#111516] rounded text-[#F8F7F2] border border-[#D9D8D2]/10">
                  {selectedTx.purpose}
                </div>
              </div>
            </div>

            <button
              onClick={() => setSelectedTx(null)}
              className="w-full bg-[#163D56] hover:bg-[#163D56]/80 text-[#F8F7F2] py-2 rounded text-xs font-semibold"
            >
              Fechar Detalhes
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
