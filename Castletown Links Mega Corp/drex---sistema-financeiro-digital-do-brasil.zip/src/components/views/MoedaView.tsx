import React from 'react';
import { Coins, ArrowDownUp, RefreshCw, Layers, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';

export const MoedaView: React.FC = () => {
  const [metrics, setMetrics] = React.useState(drexEngine.getSystemMetrics());
  const [issuanceAmount, setIssuanceAmount] = React.useState('500000000');
  const [issuedLog, setIssuedLog] = React.useState<string[]>([]);

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      setMetrics(drexEngine.getSystemMetrics());
    });
  }, []);

  const handleIssueWholesale = () => {
    const val = parseFloat(issuanceAmount);
    if (!isNaN(val) && val > 0) {
      setIssuedLog(prev => [
        `[${new Date().toLocaleTimeString()}] Emissão de R$ ${val.toLocaleString('pt-BR')} em Drex Atacado para Conta de Reservas BCB - Autorizada`,
        ...prev
      ]);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <Coins className="w-5 h-5 text-[#2E7775]" />
          <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">DREX MONEY ENGINE — NÚCLEO MONETÁRIO</h1>
        </div>
        <p className="text-xs text-[#D9D8D2]/80 mt-1">
          Gestão e controle dos agregados monetários do Real Digital. Modelo de emissão atacadista pelo Banco Central do Brasil e custódia de depósitos tokenizados no sistema financeiro.
        </p>
      </div>

      {/* Monetary Instruments Distinction Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Wholesale Drex */}
        <div className="bg-[#24292A] border border-[#2E7775]/50 rounded-lg p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#2E7775]">MOEDA CENTRAL DE ATACADO</span>
            <span className="text-[10px] bg-[#163D56] text-[#2E7775] px-2 py-0.5 rounded font-mono">BCB LEVEL</span>
          </div>
          <h2 className="text-sm font-bold text-[#F8F7F2]">DREX ATACADO (WHOLESALE CBDC)</h2>
          <div className="font-mono-numbers text-2xl font-bold text-[#F8F7F2]">
            R$ {(metrics.wholesaleDrexSupplyBrl / 1000000000).toFixed(1).replace('.', ',')} B
          </div>
          <p className="text-xs text-[#D9D8D2]/70">
            Passivo direto do Banco Central do Brasil. Utilizado exclusivamente por bancos e instituições financeiras autorizadas para liquidação interbancária e lastro de depósitos.
          </p>
        </div>

        {/* Tokenised Deposits */}
        <div className="bg-[#24292A] border border-[#236B4B]/50 rounded-lg p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#236B4B]">DEPÓSITOS VAREJO BANCÁRIO</span>
            <span className="text-[10px] bg-[#174D3A] text-[#236B4B] px-2 py-0.5 rounded font-mono">RETAIL LEVEL</span>
          </div>
          <h2 className="text-sm font-bold text-[#F8F7F2]">DEPÓSITOS TOKENIZADOS</h2>
          <div className="font-mono-numbers text-2xl font-bold text-[#F8F7F2]">
            R$ {(metrics.tokenisedDepositsBrl / 1000000000).toFixed(1).replace('.', ',')} B
          </div>
          <p className="text-xs text-[#D9D8D2]/70">
            Moeda bancária tokenizada emitida por instituições autorizadas. Mantém conversibilidade 1:1 e parity integral garantida pelo lastro em Drex Atacado.
          </p>
        </div>

        {/* Securities & Collateral */}
        <div className="bg-[#24292A] border border-[#C9A83E]/50 rounded-lg p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-[#C9A83E]">GARANTIAS & TÍTULOS</span>
            <span className="text-[10px] bg-[#24292A] text-[#C9A83E] px-2 py-0.5 rounded font-mono border border-[#C9A83E]/30">TESOURO / ASSETS</span>
          </div>
          <h2 className="text-sm font-bold text-[#F8F7F2]">TÍTULOS E RECEBÍVEIS TOKENIZADOS</h2>
          <div className="font-mono-numbers text-2xl font-bold text-[#F8F7F2]">
            R$ {(metrics.tokenisedAssetsValueBrl / 1000000000).toFixed(1).replace('.', ',')} B
          </div>
          <p className="text-xs text-[#D9D8D2]/70">
            Ativos financeiros (Títulos Públicos LFT/NTN-F, CPRs agrícolas, recebíveis imobiliários) registrados para liquidação atômica DvP no ambiente Drex.
          </p>
        </div>

      </div>

      {/* Issuance & Monetary Reserve Operations Simulator */}
      <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-5 space-y-4">
        <h2 className="font-brand text-base font-bold text-[#F8F7F2] flex items-center gap-2">
          <RefreshCw className="w-4 h-4 text-[#2E7775]" />
          SIMULADOR DE OPERAÇÃO MONETÁRIA DO BANCO CENTRAL
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-end">
          <div className="space-y-1">
            <label className="text-xs text-[#D9D8D2]/70">Valor da Emissão / Resgate (R$):</label>
            <input
              type="number"
              value={issuanceAmount}
              onChange={e => setIssuanceAmount(e.target.value)}
              className="w-full bg-[#111516] border border-[#D9D8D2]/20 rounded p-2 text-sm text-[#F8F7F2] font-mono focus:border-[#2E7775] outline-none"
            />
          </div>

          <div className="flex gap-2">
            <button
              onClick={handleIssueWholesale}
              className="flex-1 bg-[#236B4B] hover:bg-[#174D3A] text-white py-2 rounded text-xs font-semibold transition-colors"
            >
              Emitir Drex Atacado
            </button>
            <button
              onClick={handleIssueWholesale}
              className="flex-1 bg-[#163D56] hover:bg-[#163D56]/80 text-[#F8F7F2] py-2 rounded text-xs font-semibold transition-colors"
            >
              Converter p/ Depósito
            </button>
          </div>

          <div className="text-xs text-[#D9D8D2]/60 font-mono">
            Operações submetidas via contrato do Selic / Sistema de Liquidação
          </div>
        </div>

        {/* Operation Audit Log */}
        {issuedLog.length > 0 && (
          <div className="bg-[#111516] border border-[#2E7775]/40 rounded p-3 font-mono text-xs space-y-1 text-[#2E7775]">
            {issuedLog.map((log, idx) => (
              <div key={idx} className="flex items-center gap-2">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#236B4B] shrink-0" />
                <span>{log}</span>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
};
