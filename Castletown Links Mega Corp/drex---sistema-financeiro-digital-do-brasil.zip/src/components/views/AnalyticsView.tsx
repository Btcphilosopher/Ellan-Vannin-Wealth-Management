import React from 'react';
import { LineChart, TrendingUp, BarChart3, Activity } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';

export const AnalyticsView: React.FC = () => {
  const [metrics, setMetrics] = React.useState(drexEngine.getSystemMetrics());

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      setMetrics(drexEngine.getSystemMetrics());
    });
  }, []);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <LineChart className="w-5 h-5 text-[#2E7775]" />
          <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">ANALYTICS MONETÁRIO E ESTATÍSTICAS DO DREX</h1>
        </div>
        <p className="text-xs text-[#D9D8D2]/80 mt-1">
          Indicadores macroeconômicos em tempo real do ecossistema do Real Digital: velocidade da moeda, taxa de liquidação atômica e composição do M1 tokenizado.
        </p>
      </div>

      {/* Analytics KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono">
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-4 space-y-2">
          <span className="text-[#D9D8D2]/60">Velocidade do Drex (V):</span>
          <div className="font-mono-numbers text-2xl font-bold text-[#236B4B]">4.82x / ano</div>
          <p className="text-[#D9D8D2]/50 text-[10px]">Rotatividade da moeda em liquidações</p>
        </div>

        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-4 space-y-2">
          <span className="text-[#D9D8D2]/60">M1 Tokenizado Estimado:</span>
          <div className="font-mono-numbers text-2xl font-bold text-[#F8F7F2]">R$ 131,9 B</div>
          <p className="text-[#D9D8D2]/50 text-[10px]">Atacado + Depósitos Tokenizados</p>
        </div>

        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-4 space-y-2">
          <span className="text-[#D9D8D2]/60">Taxa Média de Falha DvP:</span>
          <div className="font-mono-numbers text-2xl font-bold text-[#2E7775]">0.001%</div>
          <p className="text-[#D9D8D2]/50 text-[10px]">Zero falhas por risco de liquidação</p>
        </div>

        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-4 space-y-2">
          <span className="text-[#D9D8D2]/60">Eficiência de Capital Interbancário:</span>
          <div className="font-mono-numbers text-2xl font-bold text-[#C9A83E]">+38.4%</div>
          <p className="text-[#D9D8D2]/50 text-[10px]">Redução de necessidade de margem de garantia</p>
        </div>
      </div>

    </div>
  );
};
