import React from 'react';
import { FileCode2, Play, CheckCircle2, ShieldCheck, ArrowRight, Lock } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';
import { SmartContract } from '../../types/drex';

export const ContratosView: React.FC = () => {
  const [contracts, setContracts] = React.useState<SmartContract[]>(drexEngine.getContracts());
  const [selectedContract, setSelectedContract] = React.useState<SmartContract>(contracts[0]);
  const [executionMessage, setExecutionMessage] = React.useState<string | null>(null);

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      const updated = drexEngine.getContracts();
      setContracts(updated);
      const cur = updated.find(c => c.id === selectedContract.id);
      if (cur) setSelectedContract(cur);
    });
  }, [selectedContract.id]);

  const handleExecuteContract = () => {
    const executed = drexEngine.executeContract(selectedContract.id);
    if (executed) {
      setExecutionMessage(`Contrato ${executed.id} executado com sucesso! Liquidação atômica processada.`);
      setTimeout(() => setExecutionMessage(null), 3000);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <FileCode2 className="w-5 h-5 text-[#2E7775]" />
          <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">MOTOR DE CONTRATOS INTELIGENTES DREX</h1>
        </div>
        <p className="text-xs text-[#D9D8D2]/80 mt-1">
          Lógica programável de liquidação financeira condicional. Permite expressar regras de negócio, bloqueios em custódia e execução automática sem intermédio manual.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Contract List */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-4 space-y-3">
          <h2 className="font-brand text-sm font-bold text-[#F8F7F2]">CONTRATOS REGISTRADOS</h2>

          <div className="space-y-2">
            {contracts.map(c => {
              const isSelected = c.id === selectedContract.id;
              return (
                <button
                  key={c.id}
                  onClick={() => setSelectedContract(c)}
                  className={`w-full text-left p-3 rounded border transition-all space-y-1 ${
                    isSelected
                      ? 'bg-[#163D56] border-[#2E7775] text-[#F8F7F2]'
                      : 'bg-[#111516] border-[#D9D8D2]/10 text-[#D9D8D2]/80 hover:border-[#2E7775]/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-xs truncate max-w-[180px]">{c.title}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#174D3A] text-[#236B4B]">
                      {c.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#D9D8D2]/60 font-mono">Tipo: {c.type}</div>
                  <div className="font-mono-numbers text-sm font-bold pt-1 text-[#F8F7F2]">
                    R$ {c.amountBrl.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Contract Visual Sandbox */}
        <div className="lg:col-span-2 bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-6 space-y-6">
          
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-[#D9D8D2]/10">
            <div>
              <span className="text-xs text-[#2E7775] font-mono font-bold">ID: {selectedContract.id}</span>
              <h2 className="font-brand text-lg font-bold text-[#F8F7F2]">{selectedContract.title}</h2>
              <p className="text-xs text-[#D9D8D2]/70 font-mono">
                Valor do Contrato: R$ {selectedContract.amountBrl.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
              </p>
            </div>

            <button
              onClick={handleExecuteContract}
              disabled={selectedContract.status === 'LIQUIDADA'}
              className="px-4 py-2 bg-[#236B4B] hover:bg-[#174D3A] text-white rounded text-xs font-semibold transition-all flex items-center gap-2 shadow disabled:opacity-50 shrink-0"
            >
              <Play className="w-4 h-4 text-white fill-white" />
              {selectedContract.status === 'LIQUIDADA' ? 'CONTRATO LIQUIDADO' : 'EXECUTAR CONTRATO (SIMULAÇÃO)'}
            </button>
          </div>

          {/* Partes do Contrato */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
            <div className="bg-[#111516] p-3 rounded border border-[#D9D8D2]/10 space-y-1">
              <span className="text-[#D9D8D2]/60">Comprador / Devedor:</span>
              <div className="font-bold text-[#F8F7F2]">{selectedContract.buyerName}</div>
            </div>
            <div className="bg-[#111516] p-3 rounded border border-[#D9D8D2]/10 space-y-1">
              <span className="text-[#D9D8D2]/60">Vendedor / Credor:</span>
              <div className="font-bold text-[#F8F7F2]">{selectedContract.sellerName}</div>
            </div>
          </div>

          {/* Conditions Checkbox List */}
          <div className="space-y-3">
            <h3 className="font-brand text-sm font-bold text-[#F8F7F2]">CONDIÇÕES DO CONTRATO</h3>

            <div className="space-y-2">
              {selectedContract.conditions.map((cond, idx) => (
                <div key={cond.id} className="bg-[#111516] p-3 rounded border border-[#D9D8D2]/10 flex items-center justify-between text-xs font-mono">
                  <div className="flex items-center gap-3">
                    <span className="w-5 h-5 rounded-full bg-[#163D56] text-[#2E7775] flex items-center justify-center font-bold text-[11px]">
                      {idx + 1}
                    </span>
                    <span className="text-[#F8F7F2]">{cond.label}</span>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    cond.status === 'VALIDADA' ? 'bg-[#174D3A] text-[#236B4B]' : 'bg-amber-950/40 text-amber-400'
                  }`}>
                    {cond.status}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {executionMessage && (
            <div className="p-3 bg-[#174D3A] text-[#236B4B] border border-[#236B4B] rounded text-xs font-mono flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 shrink-0" />
              <span>{executionMessage}</span>
            </div>
          )}

        </div>

      </div>

    </div>
  );
};
