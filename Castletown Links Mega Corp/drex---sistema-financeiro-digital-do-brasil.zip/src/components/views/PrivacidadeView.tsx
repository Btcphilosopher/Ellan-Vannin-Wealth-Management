import React from 'react';
import { EyeOff, ShieldCheck, Lock, CheckCircle2 } from 'lucide-react';

export const PrivacidadeView: React.FC = () => {
  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <EyeOff className="w-5 h-5 text-[#2E7775]" />
              <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">DREX PRIVACY LAB — MATRIZ DE PRIVACIDADE E AUDITORIA</h1>
            </div>
            <p className="text-xs text-[#D9D8D2]/80 mt-1">
              Simulação de políticas de visibilidade das transações conforme diretrizes do Banco Central do Brasil. Equilíbrio entre privacidade dos participantes, escalabilidade e conformidade legal.
            </p>
          </div>
          <span className="text-xs bg-[#111516] text-[#C9A83E] px-2 py-1 rounded font-mono border border-[#C9A83E]/30 uppercase">
            SIMULAÇÃO DE POLÍTICAS DE PRIVACIDADE
          </span>
        </div>
      </div>

      {/* Privacy Matrix Table */}
      <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg overflow-hidden shadow">
        <div className="p-4 border-b border-[#D9D8D2]/10 font-brand text-sm font-bold text-[#F8F7F2]">
          MATRIZ DE VISIBILIDADE POR AGENTE NO SISTEMA
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-[#111516] border-b border-[#D9D8D2]/10 text-[#D9D8D2]/60 uppercase text-[10px]">
              <tr>
                <th className="p-3">AGENTE / PARTICIPANTE</th>
                <th className="p-3">VALOR DA OPERAÇÃO</th>
                <th className="p-3">IDENTIDADE DO ENVIADOR</th>
                <th className="p-3">IDENTIDADE DO RECEBEDOR</th>
                <th className="p-3">ATIVO TRANSACTIONADO</th>
                <th className="p-3">TECNOLOGIA APLICADA</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D9D8D2]/10">
              <tr className="hover:bg-[#163D56]/20">
                <td className="p-3 font-bold text-[#F8F7F2]">Comprador / Vendedor</td>
                <td className="p-3 text-[#236B4B]">VISÍVEL</td>
                <td className="p-3 text-[#236B4B]">PRÓPRIA / CONTRAPARTE</td>
                <td className="p-3 text-[#236B4B]">PRÓPRIA / CONTRAPARTE</td>
                <td className="p-3 text-[#236B4B]">VISÍVEL</td>
                <td className="p-3 text-[#2E7775]">Chave Privada Assinada</td>
              </tr>
              <tr className="hover:bg-[#163D56]/20">
                <td className="p-3 font-bold text-[#F8F7F2]">Banco Intermediário</td>
                <td className="p-3 text-[#C9A83E]">OFUSCADO (ZK-PROOF)</td>
                <td className="p-3 text-[#236B4B]">OBRIGATÓRIO (KYC)</td>
                <td className="p-3 text-[#C9A83E]">ANONIMIZADO POR HASH</td>
                <td className="p-3 text-[#236B4B]">REGISTRADO VIA SMART CONTRACT</td>
                <td className="p-3 text-[#2E7775]">Zero-Knowledge Circuits (ZK-SNARKs)</td>
              </tr>
              <tr className="hover:bg-[#163D56]/20">
                <td className="p-3 font-bold text-[#F8F7F2]">Banco Central (BCB)</td>
                <td className="p-3 text-[#236B4B]">AUDITÁVEL COM CHAVE AUTORIZADA</td>
                <td className="p-3 text-[#236B4B]">IDENTIFICÁVEL VIA REGISTRO REGULATÓRIO</td>
                <td className="p-3 text-[#236B4B]">IDENTIFICÁVEL VIA REGISTRO REGULATÓRIO</td>
                <td className="p-3 text-[#236B4B]">MONITORADO EM MACRO-CONSOLIDADO</td>
                <td className="p-3 text-[#2E7775]">Decryption Key Regulatório</td>
              </tr>
              <tr className="hover:bg-[#163D56]/20">
                <td className="p-3 font-bold text-[#F8F7F2]">Público / Validadores Terceiros</td>
                <td className="p-3 text-red-400">INVISÍVEL</td>
                <td className="p-3 text-red-400">INVISÍVEL</td>
                <td className="p-3 text-red-400">INVISÍVEL</td>
                <td className="p-3 text-red-400">INVISÍVEL</td>
                <td className="p-3 text-[#2E7775]">Criptografia Assimétrica + ZK</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
