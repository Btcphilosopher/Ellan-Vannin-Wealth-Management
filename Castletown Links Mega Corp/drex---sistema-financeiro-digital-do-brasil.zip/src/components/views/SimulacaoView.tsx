import React from 'react';
import { PlaySquare, FastForward, Play, Pause, RefreshCw, History, CheckCircle2 } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';

export const SimulacaoView: React.FC = () => {
  const [simState, setSimState] = React.useState(drexEngine.getSimulationState());

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      setSimState(drexEngine.getSimulationState());
    });
  }, []);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <PlaySquare className="w-5 h-5 text-[#2E7775]" />
          <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">SIMULADOR DETERMINÍSTICO E REPLAY MONETÁRIO DREX</h1>
        </div>
        <p className="text-xs text-[#D9D8D2]/80 mt-1">
          Ambiente de simulação com gerador de semente determinística (<code className="text-[#C9A83E] font-bold">DREX-2026-BRAZIL</code>). Controle de velocidade e replay de blocos de liquidação.
        </p>
      </div>

      <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-6 space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-[#D9D8D2]/10">
          <div>
            <span className="text-xs text-[#D9D8D2]/60 font-mono">SEMENTE DO SIMULADOR</span>
            <h2 className="font-mono text-xl font-bold text-[#2E7775]">DREX-2026-BRAZIL</h2>
            <p className="text-xs text-[#D9D8D2]/70">500.000 carteiras sintéticas, 142 instituições, 100.000 ativos tokenizados e 10.000 contratos ativos</p>
          </div>

          <div className="flex items-center gap-2 bg-[#111516] p-2 rounded border border-[#D9D8D2]/10">
            <button
              onClick={() => drexEngine.toggleSimulation()}
              className={`px-3 py-1.5 rounded text-xs font-bold transition-all flex items-center gap-1.5 ${
                simState.isSimulationRunning ? 'bg-[#236B4B] text-white' : 'bg-amber-900/60 text-amber-200'
              }`}
            >
              {simState.isSimulationRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              {simState.isSimulationRunning ? 'EM EXECUÇÃO' : 'PAUSADO'}
            </button>

            <div className="flex items-center gap-1 border-l border-[#D9D8D2]/10 px-2 font-mono text-xs">
              {[1, 10, 100].map(s => (
                <button
                  key={s}
                  onClick={() => drexEngine.setSpeed(s as any)}
                  className={`px-2 py-1 rounded text-xs font-bold transition-all ${
                    simState.speed === s ? 'bg-[#2E7775] text-white' : 'text-[#D9D8D2]/60 hover:text-white'
                  }`}
                >
                  {s}x
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-[#111516] p-4 rounded border border-[#2E7775]/30 space-y-2 text-xs font-mono">
          <div className="flex justify-between">
            <span className="text-[#D9D8D2]/60">Bloco Atual em Execução:</span>
            <span className="font-bold text-[#236B4B]">#{simState.currentBlockNumber}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#D9D8D2]/60">Velocidade da Engine:</span>
            <span className="text-[#2E7775]">{simState.speed}x Velocidade Real</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#D9D8D2]/60">Estado do Ledger:</span>
            <span className="text-[#236B4B]">SINCRONIZADO E VALIDADO (100% SINTÉTICO)</span>
          </div>
        </div>

      </div>

    </div>
  );
};
