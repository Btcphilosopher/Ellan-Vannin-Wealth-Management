import React from 'react';
import { Droplets, Landmark, AlertCircle } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';

export const LiquidezView: React.FC = () => {
  const [metrics, setMetrics] = React.useState(drexEngine.getSystemMetrics());

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      setMetrics(drexEngine.getSystemMetrics());
    });
  }, []);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <Droplets className="w-5 h-5 text-[#2E7775]" />
          <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">MONITORAMENTO DE LIQUIDEZ INTERBANCÁRIA DREX</h1>
        </div>
        <p className="text-xs text-[#D9D8D2]/80 mt-1">
          Análise do mercado interbancário, janela de redesconto do Banco Central do Brasil e colateralização das posições dos participantes em tempo real.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono">
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-4 space-y-2">
          <span className="text-[#D9D8D2]/60">Nível de Reservas de Liquidez:</span>
          <div className="font-mono-numbers text-2xl font-bold text-[#236B4B]">R$ 48,7 B</div>
          <p className="text-[#D9D8D2]/50 text-[10px]">Superávit em conta de custódia BCB</p>
        </div>

        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-4 space-y-2">
          <span className="text-[#D9D8D2]/60">Taxa Selic Over Tokenizada:</span>
          <div className="font-mono-numbers text-2xl font-bold text-[#C9A83E]">10,75% a.a.</div>
          <p className="text-[#D9D8D2]/50 text-[10px]">Mercado de liquidação noturna de títulos</p>
        </div>

        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-4 space-y-2">
          <span className="text-[#D9D8D2]/60">Aproveitamento de Colateral:</span>
          <div className="font-mono-numbers text-2xl font-bold text-[#2E7775]">94.2%</div>
          <p className="text-[#D9D8D2]/50 text-[10px]">Títulos públicos vinculados a operações</p>
        </div>
      </div>

    </div>
  );
};
