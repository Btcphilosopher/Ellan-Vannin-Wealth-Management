import React from 'react';
import { Zap, ArrowRight, CheckCircle2, ShieldCheck, RefreshCw } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';

export const LiquidacaoView: React.FC = () => {
  const [step, setStep] = React.useState(0);
  const [isExecuting, setIsExecuting] = React.useState(false);

  const runAtomicDvPFlow = () => {
    setIsExecuting(true);
    setStep(1);
    setTimeout(() => setStep(2), 1000);
    setTimeout(() => setStep(3), 2000);
    setTimeout(() => setStep(4), 3000);
    setTimeout(() => {
      setIsExecuting(false);
      drexEngine.runPropertyAtomicTransferDemo();
    }, 4000);
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#2E7775]" />
            <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">MECANISMO DE LIQUIDAÇÃO ATÔMICA DvP (DELIVERY VS PAYMENT)</h1>
          </div>
          <p className="text-xs text-[#D9D8D2]/80 mt-1">
            Garantia de simultaneidade entre a transferência da propriedade do ativo tokenizado e o pagamento correspondente em moeda Drex. Elimina o risco de contraparte.
          </p>
        </div>

        <button
          onClick={runAtomicDvPFlow}
          disabled={isExecuting}
          className="px-4 py-2 bg-[#236B4B] hover:bg-[#174D3A] text-white rounded text-xs font-semibold transition-all flex items-center gap-2 shadow shrink-0 disabled:opacity-50"
        >
          <RefreshCw className={`w-4 h-4 ${isExecuting ? 'animate-spin' : ''}`} />
          EXECUTAR SIMULAÇÃO DvP
        </button>
      </div>

      {/* Visual State Transition Pipeline */}
      <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-6 space-y-6">
        <h2 className="font-brand text-sm font-bold text-[#F8F7F2]">FLUXO DE LIQUIDAÇÃO SIMULTÂNEA EM TEMPO REAL</h2>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 text-center">
          
          {/* Step 1 */}
          <div className={`p-4 rounded border transition-all ${
            step >= 1 ? 'bg-[#163D56] border-[#2E7775] text-[#F8F7F2]' : 'bg-[#111516] border-[#D9D8D2]/10 text-[#D9D8D2]/50'
          }`}>
            <div className="text-[10px] uppercase font-mono font-bold">PASSO 1</div>
            <div className="font-bold text-xs mt-1">TRAVA DO ATIVO</div>
            <p className="text-[10px] mt-1">Token imobiliário/título retido em Smart Contract</p>
          </div>

          {/* Step 2 */}
          <div className={`p-4 rounded border transition-all ${
            step >= 2 ? 'bg-[#163D56] border-[#2E7775] text-[#F8F7F2]' : 'bg-[#111516] border-[#D9D8D2]/10 text-[#D9D8D2]/50'
          }`}>
            <div className="text-[10px] uppercase font-mono font-bold">PASSO 2</div>
            <div className="font-bold text-xs mt-1">RESERVA DREX</div>
            <p className="text-[10px] mt-1">Bloqueio de depósitos tokenizados do comprador</p>
          </div>

          {/* Step 3 */}
          <div className={`p-4 rounded border transition-all ${
            step >= 3 ? 'bg-[#163D56] border-[#2E7775] text-[#F8F7F2]' : 'bg-[#111516] border-[#D9D8D2]/10 text-[#D9D8D2]/50'
          }`}>
            <div className="text-[10px] uppercase font-mono font-bold">PASSO 3</div>
            <div className="font-bold text-xs mt-1">VALIDAÇÃO LEGAL</div>
            <p className="text-[10px] mt-1">Verificação de certidões e oráculo público</p>
          </div>

          {/* Step 4 */}
          <div className={`p-4 rounded border transition-all ${
            step >= 4 ? 'bg-[#174D3A] border-[#236B4B] text-[#236B4B]' : 'bg-[#111516] border-[#D9D8D2]/10 text-[#D9D8D2]/50'
          }`}>
            <div className="text-[10px] uppercase font-mono font-bold">PASSO 4</div>
            <div className="font-bold text-xs mt-1">SWAP ATÔMICO</div>
            <p className="text-[10px] mt-1">Transferência atômica simultânea e irrevogável</p>
          </div>

          {/* Finality Status */}
          <div className={`p-4 rounded border transition-all ${
            step === 4 ? 'bg-[#236B4B] border-[#236B4B] text-white' : 'bg-[#111516] border-[#D9D8D2]/10 text-[#D9D8D2]/50'
          }`}>
            <div className="text-[10px] uppercase font-mono font-bold">FINALIDADE</div>
            <div className="font-bold text-xs mt-1">LIQUIDADO (FINAL)</div>
            <p className="text-[10px] mt-1">Bloco validado no Ledger Drex</p>
          </div>

        </div>

        {/* Guarantees Box */}
        <div className="bg-[#111516] border border-[#2E7775]/30 rounded p-4 flex items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-6 h-6 text-[#2E7775] shrink-0" />
            <div>
              <span className="font-bold text-[#F8F7F2]">Regra de Invariante Monocórdica:</span>
              <p className="text-[#D9D8D2]/70 text-[11px]">Se qualquer validação falhar, os fundos e o ativo retornam instantaneamente aos proprietários originais (Rollback/Reversão Atômica sem perdas).</p>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
