import React from 'react';
import { Building2, ShieldCheck, Lock, ExternalLink, FileText, CheckCircle2 } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';
import { Asset } from '../../types/drex';

export const AtivosView: React.FC = () => {
  const [assets, setAssets] = React.useState<Asset[]>(drexEngine.getAssets());
  const [selectedAsset, setSelectedAsset] = React.useState<Asset | null>(null);

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      setAssets(drexEngine.getAssets());
    });
  }, []);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Building2 className="w-5 h-5 text-[#2E7775]" />
              <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">REGISTRO DE ATIVOS FINANCIALS TOKENIZADOS</h1>
            </div>
            <p className="text-xs text-[#D9D8D2]/80 mt-1">
              Catálogo e custódia de Títulos Públicos Federais (Tesouro Direto), Recebíveis do Agronegócio (CPR), Ativos Imobiliários e de Crédito para negociação atômica no ecossistema DREX.
            </p>
          </div>
          <span className="text-xs bg-[#111516] text-[#C9A83E] px-2 py-1 rounded font-mono border border-[#C9A83E]/30 uppercase">
            SIMULAÇÃO DE REGISTRO DREX
          </span>
        </div>
      </div>

      {/* Asset Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {assets.map(ast => (
          <div key={ast.id} className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-5 space-y-3 hover:border-[#2E7775]/50 transition-colors flex flex-col justify-between">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-[#163D56] text-[#2E7775]">
                  {ast.category}
                </span>
                {ast.isEncumbered ? (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950/40 text-amber-400 border border-amber-400/30 flex items-center gap-1">
                    <Lock className="w-3 h-3" /> PLEDGED / GARANTIA
                  </span>
                ) : (
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#174D3A] text-[#236B4B]">
                    DISPONÍVEL
                  </span>
                )}
              </div>

              <h2 className="font-bold text-sm text-[#F8F7F2]">{ast.name}</h2>
              <div className="text-xs text-[#D9D8D2]/60 font-mono">Código: {ast.code}</div>

              <div className="bg-[#111516] p-3 rounded border border-[#D9D8D2]/10 space-y-1">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-[#D9D8D2]/60">Preço Estimado:</span>
                  <span className="font-bold text-[#236B4B]">
                    R$ {ast.currentPrice.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                {ast.yieldRatePercent && (
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-[#D9D8D2]/60">Taxa / Rendimento:</span>
                    <span className="text-[#C9A83E] font-bold">{ast.yieldRatePercent}% a.a.</span>
                  </div>
                )}
                {ast.maturityDate && (
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-[#D9D8D2]/60">Vencimento:</span>
                    <span className="text-[#D9D8D2]/80">{ast.maturityDate}</span>
                  </div>
                )}
              </div>

              <div className="text-[11px] text-[#D9D8D2]/70 font-mono">
                Proprietário: <span className="text-[#F8F7F2] font-semibold">{ast.ownerName}</span>
              </div>
            </div>

            <div className="pt-3 border-t border-[#D9D8D2]/10 flex items-center justify-between">
              <span className="text-[9px] text-[#C9A83E] font-semibold">{ast.simulatedNotice}</span>
              <button
                onClick={() => setSelectedAsset(ast)}
                className="px-3 py-1 bg-[#163D56] hover:bg-[#2E7775] text-[#F8F7F2] rounded text-xs font-medium transition-colors"
              >
                Passaporte Digital →
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Asset Passport Modal */}
      {selectedAsset && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#24292A] border border-[#2E7775] rounded-lg max-w-lg w-full p-6 space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#D9D8D2]/10 pb-3">
              <div>
                <h3 className="font-brand text-base font-bold text-[#F8F7F2]">PASSAPORTE DE ATIVO DIGITAL (DREX PASSPORT)</h3>
                <span className="font-mono text-xs text-[#2E7775]">{selectedAsset.code}</span>
              </div>
              <button onClick={() => setSelectedAsset(null)} className="text-[#D9D8D2]/60 hover:text-white">
                ✕
              </button>
            </div>

            <div className="space-y-3 text-xs font-mono">
              <div className="bg-[#111516] p-3 rounded border border-[#D9D8D2]/10 space-y-2">
                <div className="flex justify-between">
                  <span className="text-[#D9D8D2]/60">Nome do Ativo:</span>
                  <span className="text-[#F8F7F2] font-bold">{selectedAsset.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D9D8D2]/60">Categoria:</span>
                  <span className="text-[#2E7775]">{selectedAsset.category}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D9D8D2]/60">Custodiante Emissor:</span>
                  <span className="text-[#F8F7F2]">{selectedAsset.institutionName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#D9D8D2]/60">Titular Atual:</span>
                  <span className="text-[#F8F7F2]">{selectedAsset.ownerName}</span>
                </div>
              </div>

              <div className="space-y-1">
                <span className="text-[#D9D8D2]/60">Hash do Passaporte do Ativo:</span>
                <div className="p-2 bg-[#111516] rounded text-[11px] text-[#2E7775] break-all border border-[#D9D8D2]/10">
                  {selectedAsset.passportHash}
                </div>
              </div>

              {selectedAsset.isEncumbered && (
                <div className="p-3 bg-amber-950/40 border border-amber-400/40 rounded space-y-1">
                  <span className="text-amber-300 font-bold flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5" /> GRAVAME / PENHOR ATIVO:
                  </span>
                  <p className="text-amber-200 text-[11px]">{selectedAsset.encumbranceDetails}</p>
                </div>
              )}
            </div>

            <button
              onClick={() => setSelectedAsset(null)}
              className="w-full bg-[#163D56] hover:bg-[#163D56]/80 text-[#F8F7F2] py-2 rounded text-xs font-semibold"
            >
              Fechar Passaporte
            </button>
          </div>
        </div>
      )}

    </div>
  );
};
