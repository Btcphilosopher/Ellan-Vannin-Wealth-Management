import React from 'react';
import { ShieldCheck, AlertTriangle, Play, RefreshCw, CheckCircle2 } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';

export const RiscoView: React.FC = () => {
  const [activeScenario, setActiveScenario] = React.useState<string | null>(null);
  const [shockExecuted, setShockExecuted] = React.useState(false);

  const runBankShock = () => {
    setActiveScenario('CRISE_LIQUIDEZ_BANCO_PAULISTA');
    setShockExecuted(true);
    drexEngine.triggerBankLiquidityShock('inst-012');
  };

  const restoreSystem = () => {
    setActiveScenario(null);
    setShockExecuted(false);
    drexEngine.restoreBankLiquidity('inst-012');
  };

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-[#2E7775]" />
          <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">LABORATÓRIO DE ESTABILIDADE FINANCEIRA E TESTE DE ESTRESSE</h1>
        </div>
        <p className="text-xs text-[#D9D8D2]/80 mt-1">
          Simulação de cenários de estresse sistêmico, choques de liquidez interbancária e propagação de risco de crédito no ecossistema Drex.
        </p>
      </div>

      {/* Scenarios Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        
        {/* Scenario 1 */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-5 space-y-3 flex flex-col justify-between">
          <div className="space-y-2">
            <span className="text-[10px] font-mono text-red-400 font-bold bg-red-950/50 px-2 py-0.5 rounded border border-red-500/30">
              ESTRESSE DE LIQUIDEZ
            </span>
            <h2 className="font-bold text-sm text-[#F8F7F2]">Choque de Liquidez Interbancário (Banco Paulista)</h2>
            <p className="text-xs text-[#D9D8D2]/70">
              Simula uma perda abrupta de 85% das reservas em Drex Atacado de uma instituição financeira de médio porte. Avalia resiliência e contágio.
            </p>
          </div>

          <button
            onClick={shockExecuted ? restoreSystem : runBankShock}
            className={`w-full py-2 rounded text-xs font-semibold transition-colors flex items-center justify-center gap-2 ${
              shockExecuted
                ? 'bg-[#163D56] text-[#F8F7F2] hover:bg-[#2E7775]'
                : 'bg-red-900/60 text-red-200 hover:bg-red-800'
            }`}
          >
            {shockExecuted ? <RefreshCw className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            {shockExecuted ? 'Restaurar Sistema' : 'Disparar Choque de Liquidez'}
          </button>
        </div>

        {/* Scenario 2 */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-5 space-y-3 opacity-80">
          <div className="space-y-2">
            <span className="text-[10px] font-mono text-[#C9A83E] font-bold bg-amber-950/50 px-2 py-0.5 rounded border border-amber-500/30">
              PICO DE PAGAMENTOS
            </span>
            <h2 className="font-bold text-sm text-[#F8F7F2]">Surge de Transações Varejo (Black Friday / Pix+Drex)</h2>
            <p className="text-xs text-[#D9D8D2]/70">
              Aumento de 500% na carga de transações por segundo. Teste de latência do Ledger e capacidade dos validadores ZK-Proof.
            </p>
          </div>
          <button disabled className="w-full bg-[#111516] text-[#D9D8D2]/40 py-2 rounded text-xs font-semibold">
            Cenário em Espera
          </button>
        </div>

        {/* Scenario 3 */}
        <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg p-5 space-y-3 opacity-80">
          <div className="space-y-2">
            <span className="text-[10px] font-mono text-sky-400 font-bold bg-sky-950/50 px-2 py-0.5 rounded border border-sky-500/30">
              QUEDA DE COLATERAL
            </span>
            <h2 className="font-bold text-sm text-[#F8F7F2]">Volatilidade de Preço de Títulos Públicos</h2>
            <p className="text-xs text-[#D9D8D2]/70">
              Desvalorização de 15% nos ativos pledged. Disparo automático de chamadas de margem e rebalanceamento de garantias.
            </p>
          </div>
          <button disabled className="w-full bg-[#111516] text-[#D9D8D2]/40 py-2 rounded text-xs font-semibold">
            Cenário em Espera
          </button>
        </div>

      </div>

      {/* Active Shock Feedback */}
      {shockExecuted && (
        <div className="p-4 bg-red-950/40 border border-red-500/40 rounded-lg text-xs font-mono space-y-2 text-red-200">
          <div className="flex items-center gap-2 font-bold text-red-400 text-sm">
            <AlertTriangle className="w-5 h-5 shrink-0" />
            <span>ALERTA DE ESTRESSE SISTÊMICO ATIVADO — DADOS SIMULADOS</span>
          </div>
          <p>
            O Banco Paulista S.A. teve suas reservas reduzidas para R$ 1,26 B. A janela de redesconto do Banco Central do Brasil foi solicitada e aprovada automaticamente via colateralização de títulos NTN-F 2031. Sem risco de inadimplência sistêmica.
          </p>
        </div>
      )}

    </div>
  );
};
