import React from 'react';
import { Landmark, ShieldCheck, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { drexEngine } from '../../services/drexEngine';
import { Institution } from '../../types/drex';

export const InstituicoesView: React.FC = () => {
  const [institutions, setInstitutions] = React.useState<Institution[]>(drexEngine.getInstitutions());

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      setInstitutions(drexEngine.getInstitutions());
    });
  }, []);

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-[#163D56]/40 border border-[#2E7775]/40 rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2">
              <Landmark className="w-5 h-5 text-[#2E7775]" />
              <h1 className="font-brand text-lg font-bold text-[#F8F7F2]">REDE DE INSTITUIÇÕES FINANCEIRAS INTERMEDIÁRIAS (142 PARTICIPANTES)</h1>
            </div>
            <p className="text-xs text-[#D9D8D2]/80 mt-1">
              Bancos comerciais, cooperativas e fintechs autorizadas pelo Banco Central do Brasil para prestação de serviços de custódia e intermediação do Drex.
            </p>
          </div>
          <span className="text-xs bg-[#111516] text-[#C9A83E] px-2 py-1 rounded font-mono border border-[#C9A83E]/30 uppercase">
            SISTEMA INTERBANCÁRIO SINTÉTICO
          </span>
        </div>
      </div>

      {/* Institutions Table */}
      <div className="bg-[#24292A] border border-[#D9D8D2]/10 rounded-lg overflow-hidden shadow">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#111516] border-b border-[#D9D8D2]/10 text-[#D9D8D2]/60 font-mono uppercase text-[10px]">
              <tr>
                <th className="p-3">CÓDIGO</th>
                <th className="p-3">INSTITUIÇÃO</th>
                <th className="p-3">TIPO</th>
                <th className="p-3">PRAÇA / REGIÃO</th>
                <th className="p-3 text-right">RESERVAS DREX ATACADO (R$)</th>
                <th className="p-3 text-right">DEPÓSITOS TOKENIZADOS (R$)</th>
                <th className="p-3">RISCO</th>
                <th className="p-3">LIQUIDEZ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D9D8D2]/10">
              {institutions.map(inst => (
                <tr key={inst.id} className="hover:bg-[#163D56]/20 transition-colors">
                  <td className="p-3 font-mono font-bold text-[#2E7775]">
                    {inst.code}
                  </td>
                  <td className="p-3 font-medium text-[#F8F7F2]">
                    <div>{inst.name}</div>
                    <div className="text-[10px] text-[#D9D8D2]/50">{inst.customersCount.toLocaleString('pt-BR')} clientes</div>
                  </td>
                  <td className="p-3 font-mono text-[10px] text-[#C9A83E]">
                    {inst.type}
                  </td>
                  <td className="p-3 font-mono text-[11px] text-[#D9D8D2]/80">
                    {inst.locationRegion}
                  </td>
                  <td className="p-3 text-right font-mono-numbers font-bold text-[#2E7775]">
                    R$ {(inst.wholesaleBalance / 1000000).toLocaleString('pt-BR')} M
                  </td>
                  <td className="p-3 text-right font-mono-numbers font-bold text-[#236B4B]">
                    R$ {(inst.totalTokenisedDeposits / 1000000).toLocaleString('pt-BR')} M
                  </td>
                  <td className="p-3 font-mono text-[11px] text-[#C9A83E] font-bold">
                    {inst.riskRating}
                  </td>
                  <td className="p-3 font-mono">
                    {inst.liquidityStatus === 'ESTRESSE' ? (
                      <span className="px-2 py-0.5 rounded bg-red-950/60 text-red-400 border border-red-500/40 text-[10px] font-bold flex items-center gap-1 w-fit">
                        <AlertTriangle className="w-3 h-3" /> ESTRESSE
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded bg-[#174D3A] text-[#236B4B] text-[10px] font-bold">
                        NORMAL
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
