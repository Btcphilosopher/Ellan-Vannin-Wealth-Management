import React from 'react';
import {
  LayoutDashboard,
  Coins,
  Wallet,
  ArrowRightLeft,
  Zap,
  Building2,
  Landmark,
  Droplets,
  ShieldCheck,
  EyeOff,
  Scale,
  LineChart,
  PlaySquare,
  Terminal,
  FileCode2
} from 'lucide-react';

export type NavTab =
  | 'VISAO_GERAL'
  | 'MOEDA'
  | 'CARTEIRAS'
  | 'TRANSACOES'
  | 'LIQUIDACAO'
  | 'ATIVOS'
  | 'CONTRATOS'
  | 'INSTITUICOES'
  | 'LIQUIDEZ'
  | 'RISCO'
  | 'PRIVACIDADE'
  | 'CONFORMIDADE'
  | 'ANALYTICS'
  | 'SIMULACAO'
  | 'DESENVOLVEDOR';

interface NavbarProps {
  activeTab: NavTab;
  setActiveTab: (tab: NavTab) => void;
}

const NAV_ITEMS: { id: NavTab; label: string; icon: React.FC<{ className?: string }> }[] = [
  { id: 'VISAO_GERAL', label: 'VISÃO GERAL', icon: LayoutDashboard },
  { id: 'MOEDA', label: 'MOEDA', icon: Coins },
  { id: 'CARTEIRAS', label: 'CARTEIRAS', icon: Wallet },
  { id: 'TRANSACOES', label: 'TRANSAÇÕES', icon: ArrowRightLeft },
  { id: 'LIQUIDACAO', label: 'LIQUIDAÇÃO', icon: Zap },
  { id: 'ATIVOS', label: 'ATIVOS', icon: Building2 },
  { id: 'CONTRATOS', label: 'CONTRATOS', icon: FileCode2 },
  { id: 'INSTITUICOES', label: 'INSTITUIÇÕES', icon: Landmark },
  { id: 'LIQUIDEZ', label: 'LIQUIDEZ', icon: Droplets },
  { id: 'RISCO', label: 'RISCO', icon: ShieldCheck },
  { id: 'PRIVACIDADE', label: 'PRIVACIDADE', icon: EyeOff },
  { id: 'CONFORMIDADE', label: 'CONFORMIDADE', icon: Scale },
  { id: 'ANALYTICS', label: 'ANALYTICS', icon: LineChart },
  { id: 'SIMULACAO', label: 'SIMULAÇÃO', icon: PlaySquare },
  { id: 'DESENVOLVEDOR', label: 'DESENVOLVEDOR', icon: Terminal },
];

export const Navbar: React.FC<NavbarProps> = ({ activeTab, setActiveTab }) => {
  return (
    <nav className="bg-[#111516] border-b border-[#24292A] px-4 overflow-x-auto scrollbar-none shrink-0 sticky top-[61px] z-30">
      <div className="max-w-[1600px] mx-auto flex items-center gap-1 py-1.5 min-w-max">
        {NAV_ITEMS.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs font-medium tracking-wide transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-[#163D56] text-[#F8F7F2] font-semibold border border-[#2E7775]/60 shadow-inner'
                  : 'text-[#D9D8D2]/70 hover:text-[#F8F7F2] hover:bg-[#24292A]/60'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#2E7775]' : 'text-[#D9D8D2]/40'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
