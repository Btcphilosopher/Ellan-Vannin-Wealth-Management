import React from 'react';
import { Sparkles, Building, Landmark, Sprout, AlertTriangle, ArrowRightLeft, CheckCircle2, Play, RefreshCw } from 'lucide-react';
import { drexEngine } from '../services/drexEngine';

interface SignatureDemosModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateToView: (view: string) => void;
}

export const SignatureDemosModal: React.FC<SignatureDemosModalProps> = ({ isOpen, onClose, onNavigateToView }) => {
  const [runningDemo, setRunningDemo] = React.useState<string | null>(null);
  const [demoLog, setDemoLog] = React.useState<string[]>([]);

  if (!isOpen) return null;

  const runDemo1Property = () => {
    setRunningDemo('PROPERTY');
    setDemoLog(['[0.0s] Iniciando Contrato de Transferência Atômica de Imóvel (MATR-SP-98214)...']);
    setTimeout(() => setDemoLog(prev => [...prev, '[1.0s] Validação de Trava de Depósito Tokenizado DREX pelo Comprador (Carlos Eduardo)... OK']), 1000);
    setTimeout(() => setDemoLog(prev => [...prev, '[2.0s] Verificação de Certidões Negativas no Oráculo do Registro de Imóveis SP... OK']), 2000);
    setTimeout(() => setDemoLog(prev => [...prev, '[3.0s] Liquidação Atômica DvP: Transferência simultânea de R$ 850.000,00 e do Token Imobiliário!']), 3000);
    setTimeout(() => {
      drexEngine.runPropertyAtomicTransferDemo();
      setDemoLog(prev => [...prev, '[3.5s] CONTRATO LIQUIDADO COM SUCESSO NO LEDGER DREX.']);
    }, 3500);
  };

  const runDemo2Tesouro = () => {
    setRunningDemo('TESOURO');
    setDemoLog(['[0.0s] Início de Emissão e Distribuição do Título Tesouro Prefixado 2031 (NTN-F)...']);
    setTimeout(() => setDemoLog(prev => [...prev, '[1.0s] Banco Paulista solicita compra de R$ 1.000.000,00 em títulos para tesouraria...']), 1000);
    setTimeout(() => setDemoLog(prev => [...prev, '[2.0s] Transferência Atômica DvP realizada via Drex Atacado na Conta de Reservas BCB... OK']), 2000);
    setTimeout(() => setDemoLog(prev => [...prev, '[3.0s] Pagamento de Cupom Semestral e Custódia do Título Confirmada no Tesouro Direto.']), 3000);
  };

  const runDemo3Agro = () => {
    setRunningDemo('AGRO');
    setDemoLog(['[0.0s] Tokenização de Cédula de Produto Rural (CPR Soja Sorriso/MT)...']);
    setTimeout(() => setDemoLog(prev => [...prev, '[1.0s] AgroSul deposita CPR tokenizada (R$ 2.400.000) em custódia Drex...']), 1000);
    setTimeout(() => setDemoLog(prev => [...prev, '[2.0s] Cooperativa Central libera linha de crédito garantida pela CPR... OK']), 2000);
    setTimeout(() => setDemoLog(prev => [...prev, '[3.0s] Liquidação atômica de financiamento agrícola concluída!']), 3000);
  };

  const runDemo4Shock = () => {
    setRunningDemo('SHOCK');
    setDemoLog(['[0.0s] Simulação de estresse de liquidez interbancária no Banco Paulista...']);
    setTimeout(() => {
      drexEngine.triggerBankLiquidityShock('inst-012');
      setDemoLog(prev => [...prev, '[1.0s] Redução de 85% nas reservas atacadistas ativada! Status: ESTRESSE DETECTADO.']);
    }, 1000);
    setTimeout(() => setDemoLog(prev => [...prev, '[2.5s] Janela de Redesconto BCB acionada via colateralização atômica de Títulos NTN-F... OK']), 2500);
    setTimeout(() => setDemoLog(prev => [...prev, '[3.5s] Estabilidade financeira preservada sem contágio sistêmico.']), 3500);
  };

  const runDemo5PixBridge = () => {
    setRunningDemo('PIX_BRIDGE');
    setDemoLog(['[0.0s] Solicitação de Pagamento iniciada via Chave Pix em e-commerce...']);
    setTimeout(() => setDemoLog(prev => [...prev, '[1.0s] Roteamento pelo PSP para o ambiente de liquidação DREX...']), 1000);
    setTimeout(() => setDemoLog(prev => [...prev, '[2.0s] Conversão automática de Depósito Tokenizado em Drex Atacado... OK']), 2000);
    setTimeout(() => setDemoLog(prev => [...prev, '[3.0s] Liquidação final simultânea em tempo real concluída!']), 3000);
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#24292A] border border-[#2E7775] rounded-xl max-w-2xl w-full p-6 space-y-6 shadow-2xl my-8">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#D9D8D2]/10 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded bg-[#163D56] text-[#2E7775] flex items-center justify-center border border-[#2E7775]/40">
              <Sparkles className="w-4 h-4 text-[#C9A83E]" />
            </div>
            <div>
              <h2 className="font-brand text-lg font-bold text-[#F8F7F2]">DEMONSTRAÇÕES ASSINATURA DREX</h2>
              <p className="text-xs text-[#D9D8D2]/60">Casos reais de liquidação programável e ativos tokenizados no Brasil</p>
            </div>
          </div>
          <button onClick={onClose} className="text-[#D9D8D2]/60 hover:text-white text-lg">
            ✕
          </button>
        </div>

        {/* Demo Selector Buttons */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          
          {/* Demo 1 */}
          <button
            onClick={runDemo1Property}
            className="p-3 bg-[#111516] hover:bg-[#163D56]/40 border border-[#D9D8D2]/10 hover:border-[#2E7775] rounded-lg text-left transition-all space-y-1"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-[#F8F7F2] flex items-center gap-1.5">
                <Building className="w-3.5 h-3.5 text-[#2E7775]" />
                1. Transferência de Imóvel Tokenizado
              </span>
              <span className="text-[10px] font-mono text-[#236B4B]">DvP R$ 850k</span>
            </div>
            <p className="text-[11px] text-[#D9D8D2]/60">Troca simultânea de imóvel SP e depósitos Drex</p>
          </button>

          {/* Demo 2 */}
          <button
            onClick={runDemo2Tesouro}
            className="p-3 bg-[#111516] hover:bg-[#163D56]/40 border border-[#D9D8D2]/10 hover:border-[#2E7775] rounded-lg text-left transition-all space-y-1"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-[#F8F7F2] flex items-center gap-1.5">
                <Landmark className="w-3.5 h-3.5 text-[#C9A83E]" />
                2. Tesouro Direto Tokenizado
              </span>
              <span className="text-[10px] font-mono text-[#C9A83E]">NTN-F 2031</span>
            </div>
            <p className="text-[11px] text-[#D9D8D2]/60">Emissão e liquidação de Títulos Públicos Federais</p>
          </button>

          {/* Demo 3 */}
          <button
            onClick={runDemo3Agro}
            className="p-3 bg-[#111516] hover:bg-[#163D56]/40 border border-[#D9D8D2]/10 hover:border-[#2E7775] rounded-lg text-left transition-all space-y-1"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-[#F8F7F2] flex items-center gap-1.5">
                <Sprout className="w-3.5 h-3.5 text-[#236B4B]" />
                3. Recebível Agrícola (CPR Soja)
              </span>
              <span className="text-[10px] font-mono text-[#236B4B]">R$ 2.4 M</span>
            </div>
            <p className="text-[11px] text-[#D9D8D2]/60">Financiamento agrícola colateralizado em Drex</p>
          </button>

          {/* Demo 4 */}
          <button
            onClick={runDemo4Shock}
            className="p-3 bg-[#111516] hover:bg-[#163D56]/40 border border-[#D9D8D2]/10 hover:border-[#2E7775] rounded-lg text-left transition-all space-y-1"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-[#F8F7F2] flex items-center gap-1.5">
                <AlertTriangle className="w-3.5 h-3.5 text-red-400" />
                4. Choque de Liquidez Bancária
              </span>
              <span className="text-[10px] font-mono text-red-400">Estresse BCB</span>
            </div>
            <p className="text-[11px] text-[#D9D8D2]/60">Simula resiliência e redesconto emergencial</p>
          </button>

          {/* Demo 5 */}
          <button
            onClick={runDemo5PixBridge}
            className="p-3 bg-[#111516] hover:bg-[#163D56]/40 border border-[#D9D8D2]/10 hover:border-[#2E7775] rounded-lg text-left transition-all space-y-1 sm:col-span-2"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-xs text-[#F8F7F2] flex items-center gap-1.5">
                <ArrowRightLeft className="w-3.5 h-3.5 text-[#2E7775]" />
                5. Ponte de Interoperabilidade Pix ↔ Drex
              </span>
              <span className="text-[10px] font-mono text-[#2E7775]">Pagamento Varejo</span>
            </div>
            <p className="text-[11px] text-[#D9D8D2]/60">Interface de liquidação em tempo real integrada ao Pix</p>
          </button>

        </div>

        {/* Console Log Window */}
        {demoLog.length > 0 && (
          <div className="space-y-2">
            <span className="text-xs text-[#D9D8D2]/70 font-mono font-bold">LOG DE EXECUÇÃO EM TEMPO REAL:</span>
            <div className="bg-[#111516] p-4 rounded border border-[#2E7775]/40 font-mono text-xs text-[#2E7775] space-y-1 max-h-48 overflow-y-auto">
              {demoLog.map((msg, i) => (
                <div key={i} className="flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#236B4B] shrink-0" />
                  <span>{msg}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="flex justify-end pt-2 border-t border-[#D9D8D2]/10">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-[#163D56] hover:bg-[#163D56]/80 text-[#F8F7F2] rounded text-xs font-semibold"
          >
            Fechar Janela
          </button>
        </div>

      </div>
    </div>
  );
};
