import React from 'react';
import { Activity, ShieldAlert, Cpu, Sparkles, Play, Pause, FastForward } from 'lucide-react';
import { drexEngine } from '../services/drexEngine';

interface HeaderProps {
  onOpenDemos: () => void;
  devMode: boolean;
  setDevMode: (val: boolean) => void;
}

export const Header: React.FC<HeaderProps> = ({ onOpenDemos, devMode, setDevMode }) => {
  const [simState, setSimState] = React.useState(drexEngine.getSimulationState());

  React.useEffect(() => {
    return drexEngine.subscribe(() => {
      setSimState(drexEngine.getSimulationState());
    });
  }, []);

  return (
    <header className="bg-[#111516] border-b border-[#24292A] px-4 lg:px-8 py-3 shrink-0 sticky top-0 z-40 shadow-xl">
      <div className="max-w-[1600px] mx-auto flex items-center justify-between gap-4">
        
        {/* Brand Zone */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 bg-[#2E7775] text-[#F8F7F2] font-brand font-bold text-xl flex items-center justify-center rounded border border-[#236B4B]">
            D
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-brand text-xl font-bold tracking-tight text-[#F8F7F2]">DREX</span>
              <span className="text-xs px-2 py-0.5 rounded bg-[#163D56]/60 text-[#2E7775] border border-[#2E7775]/40 font-mono font-medium">
                REAL DIGITAL
              </span>
              <span className="text-[10px] text-[#C9A83E] uppercase tracking-wider font-semibold bg-[#24292A] px-1.5 py-0.5 rounded border border-[#C9A83E]/30">
                DADOS SIMULADOS
              </span>
            </div>
            <p className="text-[11px] text-[#D9D8D2]/60 hidden sm:block">
              INFRAESTRUTURA FINANCEIRA E MONETÁRIA DO BRASIL — BANCO CENTRAL DO BRASIL (SIMULAÇÃO)
            </p>
          </div>
        </div>

        {/* System Simulation Controls & Quick Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          
          {/* Simulation Ticker Controls */}
          <div className="bg-[#24292A] rounded border border-[#D9D8D2]/10 p-1 flex items-center gap-1">
            <button
              onClick={() => drexEngine.toggleSimulation()}
              className={`p-1.5 rounded text-xs font-medium transition-colors flex items-center gap-1 ${
                simState.isSimulationRunning ? 'bg-[#236B4B] text-white' : 'bg-amber-900/40 text-amber-300'
              }`}
              title={simState.isSimulationRunning ? 'Pausar Simulação' : 'Retomar Simulação'}
            >
              {simState.isSimulationRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span className="hidden md:inline font-mono text-[11px]">
                {simState.isSimulationRunning ? 'AO VIVO' : 'PAUSADO'}
              </span>
            </button>

            <div className="flex items-center px-1 gap-1 border-l border-[#D9D8D2]/10 text-xs">
              {[1, 10, 100].map(s => (
                <button
                  key={s}
                  onClick={() => drexEngine.setSpeed(s as any)}
                  className={`px-1.5 py-0.5 rounded font-mono text-[11px] transition-colors ${
                    simState.speed === s
                      ? 'bg-[#2E7775] text-white font-bold'
                      : 'text-[#D9D8D2]/60 hover:text-white'
                  }`}
                >
                  {s}x
                </button>
              ))}
            </div>
          </div>

          {/* Demos Launcher Button */}
          <button
            onClick={onOpenDemos}
            className="px-3 py-1.5 bg-[#163D56] hover:bg-[#163D56]/80 text-[#F8F7F2] rounded text-xs font-medium transition-all border border-[#2E7775]/50 flex items-center gap-1.5 shadow-sm shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#C9A83E]" />
            <span className="hidden sm:inline">DEMONSTRAÇÕES</span>
          </button>

          {/* Dev / Researcher Mode Toggle */}
          <button
            onClick={() => setDevMode(!devMode)}
            className={`px-2.5 py-1.5 rounded text-xs font-medium transition-all border flex items-center gap-1 shrink-0 ${
              devMode
                ? 'bg-[#236B4B] text-white border-[#236B4B]'
                : 'bg-[#24292A] text-[#D9D8D2]/80 border-[#D9D8D2]/10 hover:text-white'
            }`}
            title="Alternar Modo Desenvolvedor / Pesquisador"
          >
            <Cpu className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">{devMode ? 'MODO DEV' : 'VISÃO GERAL'}</span>
          </button>

        </div>
      </div>
    </header>
  );
};
