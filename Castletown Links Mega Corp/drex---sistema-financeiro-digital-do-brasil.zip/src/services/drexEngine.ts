/**
 * Drex Money Engine & Deterministic Simulator
 * Seed: DREX-2026-BRAZIL
 */

import {
  Wallet,
  Institution,
  Asset,
  SmartContract,
  Transaction,
  ComplianceAlert,
  SystemMetrics,
  EconomicRegionFlow,
  MonetaryInstrumentType
} from '../types/drex';

// Initial Mock Seed Data
export const INITIAL_INSTITUTIONS: Institution[] = [
  {
    id: 'inst-000',
    code: '000',
    name: 'Banco Central do Brasil',
    shortName: 'BCB',
    type: 'CENTRAL_BANK',
    wholesaleBalance: 500000000000,
    totalTokenisedDeposits: 0,
    reserveRatioPercent: 100,
    customersCount: 1,
    riskRating: 'AAA',
    liquidityStatus: 'NORMAL',
    locationRegion: 'BRASILIA'
  },
  {
    id: 'inst-001',
    code: '001',
    name: 'Banco do Brasil Digital',
    shortName: 'BB Digital',
    type: 'BANCO_COMERCIAL',
    wholesaleBalance: 14200000000,
    totalTokenisedDeposits: 28500000000,
    reserveRatioPercent: 100,
    customersCount: 4200000,
    riskRating: 'AAA',
    liquidityStatus: 'NORMAL',
    locationRegion: 'BRASILIA'
  },
  {
    id: 'inst-012',
    code: '012',
    name: 'Banco Paulista S.A.',
    shortName: 'Banco Paulista',
    type: 'BANCO_COMERCIAL',
    wholesaleBalance: 8400000000,
    totalTokenisedDeposits: 16200000000,
    reserveRatioPercent: 100,
    customersCount: 1850000,
    riskRating: 'AA',
    liquidityStatus: 'NORMAL',
    locationRegion: 'SAO_PAULO'
  },
  {
    id: 'inst-003',
    code: '003',
    name: 'Banco Amazônia Digital',
    shortName: 'Basa Digital',
    type: 'BANCO_COMERCIAL',
    wholesaleBalance: 4100000000,
    totalTokenisedDeposits: 9800000000,
    reserveRatioPercent: 100,
    customersCount: 920000,
    riskRating: 'AA',
    liquidityStatus: 'NORMAL',
    locationRegion: 'NORTE'
  },
  {
    id: 'inst-004',
    code: '004',
    name: 'Banco Industrial do Brasil',
    shortName: 'BIB',
    type: 'BANCO_COMERCIAL',
    wholesaleBalance: 6200000000,
    totalTokenisedDeposits: 11400000000,
    reserveRatioPercent: 100,
    customersCount: 650000,
    riskRating: 'A',
    liquidityStatus: 'NORMAL',
    locationRegion: 'RIO'
  },
  {
    id: 'inst-005',
    code: '005',
    name: 'Fintech Alpha Pagamentos',
    shortName: 'Alpha Pay',
    type: 'FINTECH',
    wholesaleBalance: 1800000000,
    totalTokenisedDeposits: 4100000000,
    reserveRatioPercent: 100,
    customersCount: 2800000,
    riskRating: 'A',
    liquidityStatus: 'NORMAL',
    locationRegion: 'SAO_PAULO'
  },
  {
    id: 'inst-006',
    code: '006',
    name: 'Cooperativa Central Cresol/Sicredi',
    shortName: 'Coop Central',
    type: 'COOPERATIVA',
    wholesaleBalance: 3200000000,
    totalTokenisedDeposits: 7500000000,
    reserveRatioPercent: 100,
    customersCount: 1400000,
    riskRating: 'AA',
    liquidityStatus: 'NORMAL',
    locationRegion: 'SUL'
  },
  {
    id: 'inst-999',
    code: '999',
    name: 'Tesouro Nacional Digital',
    shortName: 'Tesouro Direto',
    type: 'TESOURO',
    wholesaleBalance: 85000000000,
    totalTokenisedDeposits: 0,
    reserveRatioPercent: 100,
    customersCount: 1,
    riskRating: 'AAA',
    liquidityStatus: 'NORMAL',
    locationRegion: 'BRASILIA'
  }
];

export const INITIAL_WALLETS: Wallet[] = [
  {
    id: 'w-pers-01',
    name: 'Carteira Pessoal — Ana Silva',
    type: 'PERSON',
    institutionId: 'inst-001',
    institutionName: 'Banco do Brasil Digital',
    ownerName: 'Ana Maria Silva',
    cpfCnpjMasked: '***.482.910-**',
    wholesaleBalance: 0,
    tokenisedDepositBalance: 18450.80,
    totalBalance: 18450.80,
    activeContractsCount: 2,
    limits: { dailyLimit: 50000, dailyUsed: 1250, monthlyLimit: 200000 },
    status: 'ATIVA'
  },
  {
    id: 'w-pers-02',
    name: 'Carteira Pessoal — Carlos Eduardo',
    type: 'PERSON',
    institutionId: 'inst-012',
    institutionName: 'Banco Paulista S.A.',
    ownerName: 'Carlos Eduardo Santos',
    cpfCnpjMasked: '***.193.854-**',
    wholesaleBalance: 0,
    tokenisedDepositBalance: 850000.00,
    totalBalance: 850000.00,
    activeContractsCount: 1,
    limits: { dailyLimit: 1000000, dailyUsed: 0, monthlyLimit: 5000000 },
    status: 'ATIVA'
  },
  {
    id: 'w-corp-01',
    name: 'AgroSul Cooperativa Exportadora',
    type: 'BUSINESS',
    institutionId: 'inst-006',
    institutionName: 'Cooperativa Central',
    ownerName: 'AgroSul S/A',
    cpfCnpjMasked: '12.345.678/0001-**',
    wholesaleBalance: 0,
    tokenisedDepositBalance: 14200000.00,
    totalBalance: 14200000.00,
    activeContractsCount: 4,
    limits: { dailyLimit: 50000000, dailyUsed: 2400000, monthlyLimit: 200000000 },
    status: 'ATIVA'
  },
  {
    id: 'w-corp-02',
    name: 'Construtora & Incorporadora Jardins',
    type: 'BUSINESS',
    institutionId: 'inst-012',
    institutionName: 'Banco Paulista S.A.',
    ownerName: 'Jardins Empreendimentos LTDA',
    cpfCnpjMasked: '98.765.432/0001-**',
    wholesaleBalance: 0,
    tokenisedDepositBalance: 38500000.00,
    totalBalance: 38500000.00,
    activeContractsCount: 3,
    limits: { dailyLimit: 100000000, dailyUsed: 850000, monthlyLimit: 500000000 },
    status: 'ATIVA'
  },
  {
    id: 'w-inst-bb',
    name: 'Tesouraria Interbancária — BB Digital',
    type: 'BANK',
    institutionId: 'inst-001',
    institutionName: 'Banco do Brasil Digital',
    ownerName: 'Banco do Brasil Digital S/A',
    cpfCnpjMasked: '00.000.000/0001-**',
    wholesaleBalance: 14200000000,
    tokenisedDepositBalance: 0,
    totalBalance: 14200000000,
    activeContractsCount: 18,
    limits: { dailyLimit: 5000000000, dailyUsed: 420000000, monthlyLimit: 20000000000 },
    status: 'ATIVA'
  },
  {
    id: 'w-inst-paulista',
    name: 'Tesouraria Interbancária — Banco Paulista',
    type: 'BANK',
    institutionId: 'inst-012',
    institutionName: 'Banco Paulista S.A.',
    ownerName: 'Banco Paulista S.A.',
    cpfCnpjMasked: '33.000.000/0001-**',
    wholesaleBalance: 8400000000,
    tokenisedDepositBalance: 0,
    totalBalance: 8400000000,
    activeContractsCount: 12,
    limits: { dailyLimit: 3000000000, dailyUsed: 210000000, monthlyLimit: 15000000000 },
    status: 'ATIVA'
  },
  {
    id: 'w-gov-tesouro',
    name: 'Emissão Pública — Tesouro Nacional',
    type: 'GOVERNMENT',
    institutionId: 'inst-999',
    institutionName: 'Tesouro Nacional Digital',
    ownerName: 'Secretaria do Tesouro Nacional',
    cpfCnpjMasked: '00.394.460/0001-**',
    wholesaleBalance: 85000000000,
    tokenisedDepositBalance: 0,
    totalBalance: 85000000000,
    activeContractsCount: 45,
    limits: { dailyLimit: 50000000000, dailyUsed: 1200000000, monthlyLimit: 500000000000 },
    status: 'ATIVA'
  },
  {
    id: 'w-escrow-01',
    name: 'Custódia Escrow — Registro Imobiliário SP',
    type: 'ESCROW',
    institutionId: 'inst-000',
    institutionName: 'Banco Central do Brasil',
    ownerName: 'Smart Contract Escrow Service',
    cpfCnpjMasked: 'CONTRATO-SMART-ESCROW',
    wholesaleBalance: 850000,
    tokenisedDepositBalance: 0,
    totalBalance: 850000,
    activeContractsCount: 1,
    limits: { dailyLimit: 1000000000, dailyUsed: 850000, monthlyLimit: 10000000000 },
    status: 'ATIVA'
  }
];

export const INITIAL_ASSETS: Asset[] = [
  {
    id: 'ast-tit-001',
    code: 'LFT-2029-BR',
    name: 'Tesouro Selic 2029 Tokenizado (LFT)',
    category: 'TITULOS_PUBLICOS',
    faceValue: 100000,
    currentPrice: 104850.20,
    yieldRatePercent: 10.75,
    maturityDate: '2029-03-01',
    ownerWalletId: 'w-pers-02',
    ownerName: 'Carlos Eduardo Santos',
    institutionId: 'inst-999',
    institutionName: 'Tesouro Nacional Digital',
    isEncumbered: false,
    simulatedNotice: 'DADOS SIMULADOS — AMBIENTE TESTE PILOTO BCB',
    passportHash: '0x8f2a931c...7e41'
  },
  {
    id: 'ast-tit-002',
    code: 'NTNF-2031-BR',
    name: 'Tesouro Prefixado com Juros Semestrais 2031 (NTN-F)',
    category: 'TITULOS_PUBLICOS',
    faceValue: 1000000,
    currentPrice: 982400.00,
    yieldRatePercent: 11.20,
    maturityDate: '2031-01-01',
    ownerWalletId: 'w-inst-paulista',
    ownerName: 'Banco Paulista S.A.',
    institutionId: 'inst-999',
    institutionName: 'Tesouro Nacional Digital',
    isEncumbered: true,
    encumbranceDetails: 'Garantia Pledgada de Liquidez Interbancária no BCB',
    simulatedNotice: 'DADOS SIMULADOS — AMBIENTE TESTE PILOTO BCB',
    passportHash: '0x3c1b829d...1f90'
  },
  {
    id: 'ast-imo-001',
    code: 'MATR-SP-98214',
    name: 'Token Imobiliário — Apt 142, Jardins, São Paulo-SP',
    category: 'IMOVEIS',
    faceValue: 850000,
    currentPrice: 850000.00,
    ownerWalletId: 'w-corp-02',
    ownerName: 'Jardins Empreendimentos LTDA',
    institutionId: 'inst-012',
    institutionName: 'Banco Paulista S.A.',
    isEncumbered: true,
    encumbranceDetails: 'Contrato Escrow de Compra e Venda pendente liquidação',
    simulatedNotice: 'DADOS SIMULADOS — REGISTRO IMOBILIÁRIO SINTÉTICO',
    passportHash: '0x7d92e104...88a2'
  },
  {
    id: 'ast-rec-001',
    code: 'CPR-SOJA-2026',
    name: 'Cédula de Produto Rural Tokenizada — Soja Sorriso/MT (5.000 Sacas)',
    category: 'AGRONEGOCIO',
    faceValue: 2400000,
    currentPrice: 2400000.00,
    yieldRatePercent: 9.80,
    maturityDate: '2026-11-15',
    ownerWalletId: 'w-corp-01',
    ownerName: 'AgroSul Cooperativa Exportadora',
    institutionId: 'inst-006',
    institutionName: 'Cooperativa Central',
    isEncumbered: false,
    simulatedNotice: 'DADOS SIMULADOS — RECEBÍVEL AGRÍCOLA SINTÉTICO',
    passportHash: '0x1e4f509a...442b'
  },
  {
    id: 'ast-rec-002',
    code: 'REC-CARTAO-BATCH88',
    name: 'Recebíveis de Cartão de Crédito — Lote Varejo Q3',
    category: 'RECEBIVEIS',
    faceValue: 5000000,
    currentPrice: 4880000.00,
    yieldRatePercent: 12.50,
    maturityDate: '2026-10-30',
    ownerWalletId: 'w-corp-01',
    ownerName: 'AgroSul Cooperativa Exportadora',
    institutionId: 'inst-005',
    institutionName: 'Alpha Pay',
    isEncumbered: false,
    simulatedNotice: 'DADOS SIMULADOS — RECEBÍVEIS DREX',
    passportHash: '0x99a0d2ef...12c8'
  }
];

export const INITIAL_CONTRACTS: SmartContract[] = [
  {
    id: 'sc-00182',
    title: 'Transferência Atômica de Imóvel Jardins SP',
    type: 'TRANSFERENCIA_IMOVEL',
    buyerWalletId: 'w-pers-02',
    buyerName: 'Carlos Eduardo Santos',
    sellerWalletId: 'w-corp-02',
    sellerName: 'Jardins Empreendimentos LTDA',
    assetId: 'ast-imo-001',
    assetName: 'Apt 142, Jardins, SP (MATR-SP-98214)',
    amountBrl: 850000,
    conditions: [
      { id: 'c1', label: 'Reserva e Trava de Depósito Tokenizado DREX pelo Comprador', status: 'VALIDADA', validatorRole: 'COMPRADOR' },
      { id: 'c2', label: 'Bloqueio do Token Imobiliário no Contrato Escrow pelo Vendedor', status: 'VALIDADA', validatorRole: 'VENDEDOR' },
      { id: 'c3', label: 'Certidão Negativa de Débitos & Matrícula Liberada (Ofício de Imóveis)', status: 'VALIDADA', validatorRole: 'REGISTRO_IMOVEIS' },
      { id: 'c4', label: 'Validação Sinal e Liquidação Simultânea DvP (Banco Central)', status: 'PENDENTE', validatorRole: 'BANCO_CENTRAL' }
    ],
    status: 'FUNDS_LOCKED',
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString()
  },
  {
    id: 'sc-00183',
    title: 'Financiamento Agrícola com Garantia CPR Soja',
    type: 'CREDITO_AGRO',
    buyerWalletId: 'w-inst-paulista',
    buyerName: 'Banco Paulista S.A.',
    sellerWalletId: 'w-corp-01',
    sellerName: 'AgroSul Cooperativa Exportadora',
    assetId: 'ast-rec-001',
    assetName: 'CPR Soja Sorriso MT (CPR-SOJA-2026)',
    amountBrl: 2400000,
    conditions: [
      { id: 'c11', label: 'Depósito da Cédula de Produto Rural em Custódia DREX', status: 'VALIDADA', validatorRole: 'VENDEDOR' },
      { id: 'c12', label: 'Aprovação da Linha de Crédito pelo Banco Intermediário', status: 'VALIDADA', validatorRole: 'BANCO_CENTRAL' },
      { id: 'c13', label: 'Liberação Condicionada dos Fundos em Conta Tokenizada', status: 'PENDENTE', validatorRole: 'COMPRADOR' }
    ],
    status: 'ASSET_LOCKED',
    createdAt: new Date(Date.now() - 3600000 * 12).toISOString()
  }
];

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-001',
    txId: 'TX-DRX-000184291',
    timestamp: new Date(Date.now() - 120000).toISOString(),
    blockNumber: 4821901,
    senderWalletId: 'w-inst-bb',
    senderName: 'Banco do Brasil Digital',
    receiverWalletId: 'w-inst-paulista',
    receiverName: 'Banco Paulista S.A.',
    instrumentType: 'WHOLESALE_DREX',
    amount: 420000000,
    institutionId: 'inst-000',
    institutionName: 'Banco Central do Brasil',
    purpose: 'Liquidação de Mercado Interbancário / Over-Selic',
    status: 'LIQUIDADA',
    settlementMode: 'INTERBANK_RESERVE',
    hash: '0xa4f8291c98e0...771b',
    privacyStatus: 'AUDITABLE_BCB',
    complianceStatus: 'APROVADO'
  },
  {
    id: 'tx-002',
    txId: 'TX-DRX-000184290',
    timestamp: new Date(Date.now() - 240000).toISOString(),
    blockNumber: 4821900,
    senderWalletId: 'w-pers-01',
    senderName: 'Ana Maria Silva',
    receiverWalletId: 'w-corp-01',
    receiverName: 'AgroSul Cooperativa',
    instrumentType: 'TOKENISED_DEPOSIT',
    amount: 184.90,
    institutionId: 'inst-001',
    institutionName: 'Banco do Brasil Digital',
    purpose: 'Pagamento Varejo Via Contrato DREX',
    status: 'LIQUIDADA',
    settlementMode: 'RETAIL_DEPOSIT',
    hash: '0x8821bc3e7a12...990f',
    privacyStatus: 'ZK_ENCRYPTED',
    complianceStatus: 'APROVADO'
  },
  {
    id: 'tx-003',
    txId: 'TX-DRX-000184289',
    timestamp: new Date(Date.now() - 480000).toISOString(),
    blockNumber: 4821898,
    senderWalletId: 'w-gov-tesouro',
    senderName: 'Tesouro Nacional',
    receiverWalletId: 'w-inst-paulista',
    receiverName: 'Banco Paulista S.A.',
    instrumentType: 'TOKENISED_SECURITY',
    amount: 1000000,
    institutionId: 'inst-999',
    institutionName: 'Tesouro Nacional Digital',
    purpose: 'Emissão Primária de Título Público NTN-F 2031',
    status: 'LIQUIDADA',
    settlementMode: 'ATOMIC_DvP',
    hash: '0x112938475aef...481d',
    privacyStatus: 'AUDITABLE_BCB',
    complianceStatus: 'APROVADO'
  }
];

export const INITIAL_ALERTS: ComplianceAlert[] = [
  {
    id: 'alt-001',
    txId: 'TX-DRX-000184205',
    timestamp: new Date(Date.now() - 1800000).toISOString(),
    amount: 8400000.00,
    pattern: 'Transferência atípica fora do perfil do cliente / Limite excedido',
    riskScore: 88,
    status: 'PENDENTE_ANALISE',
    institutionName: 'Fintech Alpha Pagamentos',
    walletName: 'Carteira Comercial Privada Beta'
  },
  {
    id: 'alt-002',
    txId: 'TX-DRX-000184192',
    timestamp: new Date(Date.now() - 3600000).toISOString(),
    amount: 15000000.00,
    pattern: 'Fracionamento recorrente de operações abaixo do gatilho regulatório',
    riskScore: 74,
    status: 'PENDENTE_ANALISE',
    institutionName: 'Banco Industrial do Brasil',
    walletName: 'Distribuidora Global SA'
  }
];

export const INITIAL_REGION_FLOWS: EconomicRegionFlow[] = [
  { region: 'DF', cityName: 'Brasília (BCB / Tesouro)', lat: -15.7975, lng: -47.8919, activeTxRate: 1420, volumeBrlMillions: 85400 },
  { region: 'SP', cityName: 'São Paulo (B3 / Faria Lima)', lat: -23.5505, lng: -46.6333, activeTxRate: 4820, volumeBrlMillions: 112000 },
  { region: 'RJ', cityName: 'Rio de Janeiro', lat: -22.9068, lng: -43.1729, activeTxRate: 1250, volumeBrlMillions: 28400 },
  { region: 'MG', cityName: 'Belo Horizonte', lat: -19.9167, lng: -43.9345, activeTxRate: 890, volumeBrlMillions: 14200 },
  { region: 'RS', cityName: 'Porto Alegre', lat: -30.0346, lng: -51.2177, activeTxRate: 640, volumeBrlMillions: 11800 },
  { region: 'PR', cityName: 'Curitiba', lat: -25.4284, lng: -49.2733, activeTxRate: 580, volumeBrlMillions: 9600 },
  { region: 'BA', cityName: 'Salvador', lat: -12.9777, lng: -38.5016, activeTxRate: 490, volumeBrlMillions: 7200 },
  { region: 'PE', cityName: 'Recife', lat: -8.0476, lng: -34.8770, activeTxRate: 410, volumeBrlMillions: 6100 },
  { region: 'CE', cityName: 'Fortaleza', lat: -3.7172, lng: -38.5437, activeTxRate: 380, volumeBrlMillions: 5400 },
  { region: 'AM', cityName: 'Manaus (Basa Digital)', lat: -3.1190, lng: -60.0217, activeTxRate: 290, volumeBrlMillions: 4800 },
  { region: 'PA', cityName: 'Belém', lat: -1.4558, lng: -48.4902, activeTxRate: 240, volumeBrlMillions: 3900 },
  { region: 'GO', cityName: 'Goiânia (Agro Hub)', lat: -16.6869, lng: -49.2648, activeTxRate: 520, volumeBrlMillions: 12100 }
];

export class DrexSimulationEngine {
  private static instance: DrexSimulationEngine;

  private institutions: Institution[] = [...INITIAL_INSTITUTIONS];
  private wallets: Wallet[] = [...INITIAL_WALLETS];
  private assets: Asset[] = [...INITIAL_ASSETS];
  private contracts: SmartContract[] = [...INITIAL_CONTRACTS];
  private transactions: Transaction[] = [...INITIAL_TRANSACTIONS];
  private alerts: ComplianceAlert[] = [...INITIAL_ALERTS];
  private regionFlows: EconomicRegionFlow[] = [...INITIAL_REGION_FLOWS];

  private simulationSpeed: 1 | 10 | 100 = 1;
  private isSimulationRunning: boolean = true;
  private currentBlockNumber: number = 4821902;
  private listeners: Array<() => void> = [];
  private intervalId: any = null;

  private constructor() {
    this.startEngineTicks();
  }

  public static getInstance(): DrexSimulationEngine {
    if (!DrexSimulationEngine.instance) {
      DrexSimulationEngine.instance = new DrexSimulationEngine();
    }
    return DrexSimulationEngine.instance;
  }

  public subscribe(callback: () => void): () => void {
    this.listeners.push(callback);
    return () => {
      this.listeners = this.listeners.filter(l => l !== callback);
    };
  }

  private notify() {
    this.listeners.forEach(l => l());
  }

  public setSpeed(speed: 1 | 10 | 100) {
    this.simulationSpeed = speed;
    this.restartEngineTicks();
    this.notify();
  }

  public toggleSimulation() {
    this.isSimulationRunning = !this.isSimulationRunning;
    if (this.isSimulationRunning) {
      this.startEngineTicks();
    } else {
      if (this.intervalId) clearInterval(this.intervalId);
    }
    this.notify();
  }

  private startEngineTicks() {
    if (this.intervalId) clearInterval(this.intervalId);
    const ms = 3000 / this.simulationSpeed;
    this.intervalId = setInterval(() => {
      if (this.isSimulationRunning) {
        this.generateSyntheticTick();
      }
    }, ms);
  }

  private restartEngineTicks() {
    this.startEngineTicks();
  }

  private generateSyntheticTick() {
    this.currentBlockNumber++;

    // Pick random wallets and institutions for dynamic synthetic settlement
    const randomSender = this.wallets[Math.floor(Math.random() * this.wallets.length)];
    let randomReceiver = this.wallets[Math.floor(Math.random() * this.wallets.length)];
    while (randomReceiver.id === randomSender.id) {
      randomReceiver = this.wallets[Math.floor(Math.random() * this.wallets.length)];
    }

    const randomAmount = Math.floor(Math.random() * 5000) + 15.50;
    const randomTxId = `TX-DRX-${Math.floor(100000000 + Math.random() * 900000000)}`;

    const newTx: Transaction = {
      id: `tx-gen-${Date.now()}`,
      txId: randomTxId,
      timestamp: new Date().toISOString(),
      blockNumber: this.currentBlockNumber,
      senderWalletId: randomSender.id,
      senderName: randomSender.name,
      receiverWalletId: randomReceiver.id,
      receiverName: randomReceiver.name,
      instrumentType: randomSender.type === 'BANK' ? 'WHOLESALE_DREX' : 'TOKENISED_DEPOSIT',
      amount: randomAmount,
      institutionId: randomSender.institutionId,
      institutionName: randomSender.institutionName,
      purpose: 'Transferência de Liquidação Sintética em Tempo Real',
      status: 'LIQUIDADA',
      settlementMode: randomSender.type === 'BANK' ? 'INTERBANK_RESERVE' : 'RETAIL_DEPOSIT',
      hash: `0x${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`,
      privacyStatus: 'ZK_ENCRYPTED',
      complianceStatus: 'APROVADO'
    };

    // Update balances
    if (randomSender.tokenisedDepositBalance >= randomAmount) {
      randomSender.tokenisedDepositBalance -= randomAmount;
      randomReceiver.tokenisedDepositBalance += randomAmount;
    }

    this.transactions.unshift(newTx);
    if (this.transactions.length > 50) {
      this.transactions.pop();
    }

    this.notify();
  }

  // System Metrics Summary
  public getSystemMetrics(): SystemMetrics {
    const totalWholesale = this.institutions.reduce((acc, inst) => acc + inst.wholesaleBalance, 0);
    const totalDeposits = this.institutions.reduce((acc, inst) => acc + inst.totalTokenisedDeposits, 0);
    const totalAssetVal = this.assets.reduce((acc, ast) => acc + ast.currentPrice, 0);

    return {
      totalLiquidityBrl: 48700000000,
      wholesaleDrexSupplyBrl: totalWholesale,
      tokenisedDepositsBrl: totalDeposits,
      txCountToday: 8421930 + (this.currentBlockNumber - 4821902) * 14,
      settledValueTodayBrl: 214800000000 + (this.currentBlockNumber - 4821902) * 250000,
      activeContractsCount: 48219 + this.contracts.length,
      tokenisedAssetsValueBrl: 83200000000 + totalAssetVal,
      participatingInstitutionsCount: 142,
      activeWalletsCount: 12800000,
      systemHealth: 'OPTIMAL',
      averageSettlementLatencyMs: 142,
      lastBlockNumber: this.currentBlockNumber
    };
  }

  // Getters
  public getInstitutions() { return this.institutions; }
  public getWallets() { return this.wallets; }
  public getAssets() { return this.assets; }
  public getContracts() { return this.contracts; }
  public getTransactions() { return this.transactions; }
  public getAlerts() { return this.alerts; }
  public getRegionFlows() { return this.regionFlows; }
  public getSimulationState() {
    return {
      isSimulationRunning: this.isSimulationRunning,
      speed: this.simulationSpeed,
      currentBlockNumber: this.currentBlockNumber
    };
  }

  // Actions / Mutations
  public createTransaction(
    senderWalletId: string,
    receiverWalletId: string,
    amount: number,
    purpose: string,
    instrumentType: MonetaryInstrumentType = 'TOKENISED_DEPOSIT'
  ): Transaction {
    const sender = this.wallets.find(w => w.id === senderWalletId) || this.wallets[0];
    const receiver = this.wallets.find(w => w.id === receiverWalletId) || this.wallets[1];

    const txId = `TX-DRX-${Math.floor(100000000 + Math.random() * 900000000)}`;
    const tx: Transaction = {
      id: `tx-user-${Date.now()}`,
      txId,
      timestamp: new Date().toISOString(),
      blockNumber: ++this.currentBlockNumber,
      senderWalletId: sender.id,
      senderName: sender.name,
      receiverWalletId: receiver.id,
      receiverName: receiver.name,
      instrumentType,
      amount,
      institutionId: sender.institutionId,
      institutionName: sender.institutionName,
      purpose,
      status: 'LIQUIDADA',
      settlementMode: 'ATOMIC_DvP',
      hash: `0x${Math.random().toString(16).substring(2, 10)}${Math.random().toString(16).substring(2, 10)}`,
      privacyStatus: 'ZK_ENCRYPTED',
      complianceStatus: 'APROVADO'
    };

    if (instrumentType === 'WHOLESALE_DREX') {
      sender.wholesaleBalance -= amount;
      receiver.wholesaleBalance += amount;
    } else {
      sender.tokenisedDepositBalance -= amount;
      receiver.tokenisedDepositBalance += amount;
    }
    sender.totalBalance = sender.wholesaleBalance + sender.tokenisedDepositBalance;
    receiver.totalBalance = receiver.wholesaleBalance + receiver.tokenisedDepositBalance;

    this.transactions.unshift(tx);
    this.notify();
    return tx;
  }

  public executeContract(contractId: string): SmartContract | null {
    const contract = this.contracts.find(c => c.id === contractId);
    if (!contract) return null;

    // Validate all pending conditions
    contract.conditions.forEach(cond => {
      cond.status = 'VALIDADA';
    });

    contract.status = 'LIQUIDADA';
    contract.executedAt = new Date().toISOString();

    // Execute atomic asset and monetary settlement
    if (contract.assetId) {
      const asset = this.assets.find(a => a.id === contract.assetId);
      if (asset) {
        const buyerWallet = this.wallets.find(w => w.id === contract.buyerWalletId);
        if (buyerWallet) {
          asset.ownerWalletId = buyerWallet.id;
          asset.ownerName = buyerWallet.ownerName;
          asset.isEncumbered = false;
        }
      }
    }

    // Money transfer
    this.createTransaction(
      contract.buyerWalletId,
      contract.sellerWalletId,
      contract.amountBrl,
      `Liquidação Atômica do Contrato Inteligente ${contract.title}`
    );

    this.notify();
    return contract;
  }

  // Signature Demo: Property Title Transfer
  public runPropertyAtomicTransferDemo() {
    const contract = this.contracts.find(c => c.type === 'TRANSFERENCIA_IMOVEL');
    if (contract) {
      this.executeContract(contract.id);
    }
  }

  // Signature Demo: Bank Liquidity Shock
  public triggerBankLiquidityShock(institutionId: string = 'inst-012') {
    const bank = this.institutions.find(i => i.id === institutionId);
    if (bank) {
      bank.liquidityStatus = 'ESTRESSE';
      bank.wholesaleBalance = Math.floor(bank.wholesaleBalance * 0.15); // 85% drop
      this.notify();
    }
  }

  // Signature Demo: Restore Liquidity
  public restoreBankLiquidity(institutionId: string = 'inst-012') {
    const bank = this.institutions.find(i => i.id === institutionId);
    if (bank) {
      bank.liquidityStatus = 'NORMAL';
      bank.wholesaleBalance = 8400000000;
      this.notify();
    }
  }
}

export const drexEngine = DrexSimulationEngine.getInstance();
