/**
 * Drex — Real Digital
 * Brazilian Digital Currency & Financial Infrastructure System
 * Main Application Root
 */

import React from 'react';
import { Header } from './components/Header';
import { Navbar, NavTab } from './components/Navbar';
import { VisaoGeralView } from './components/views/VisaoGeralView';
import { MoedaView } from './components/views/MoedaView';
import { CarteirasView } from './components/views/CarteirasView';
import { TransacoesView } from './components/views/TransacoesView';
import { LiquidacaoView } from './components/views/LiquidacaoView';
import { AtivosView } from './components/views/AtivosView';
import { ContratosView } from './components/views/ContratosView';
import { InstituicoesView } from './components/views/InstituicoesView';
import { LiquidezView } from './components/views/LiquidezView';
import { RiscoView } from './components/views/RiscoView';
import { PrivacidadeView } from './components/views/PrivacidadeView';
import { ConformidadeView } from './components/views/ConformidadeView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { SimulacaoView } from './components/views/SimulacaoView';
import { DesenvolvedorView } from './components/views/DesenvolvedorView';
import { SignatureDemosModal } from './components/SignatureDemosModal';

export default function App() {
  const [activeTab, setActiveTab] = React.useState<NavTab>('VISAO_GERAL');
  const [devMode, setDevMode] = React.useState(false);
  const [demosModalOpen, setDemosModalOpen] = React.useState(false);

  // Switch to developer view automatically when developer toggle is engaged
  React.useEffect(() => {
    if (devMode) {
      setActiveTab('DESENVOLVEDOR');
    }
  }, [devMode]);

  const renderActiveView = () => {
    switch (activeTab) {
      case 'VISAO_GERAL':
        return <VisaoGeralView onOpenDemos={() => setDemosModalOpen(true)} onNavigate={setActiveTab} />;
      case 'MOEDA':
        return <MoedaView />;
      case 'CARTEIRAS':
        return <CarteirasView />;
      case 'TRANSACOES':
        return <TransacoesView />;
      case 'LIQUIDACAO':
        return <LiquidacaoView />;
      case 'ATIVOS':
        return <AtivosView />;
      case 'CONTRATOS':
        return <ContratosView />;
      case 'INSTITUICOES':
        return <InstituicoesView />;
      case 'LIQUIDEZ':
        return <LiquidezView />;
      case 'RISCO':
        return <RiscoView />;
      case 'PRIVACIDADE':
        return <PrivacidadeView />;
      case 'CONFORMIDADE':
        return <ConformidadeView />;
      case 'ANALYTICS':
        return <AnalyticsView />;
      case 'SIMULACAO':
        return <SimulacaoView />;
      case 'DESENVOLVEDOR':
        return <DesenvolvedorView />;
      default:
        return <VisaoGeralView onOpenDemos={() => setDemosModalOpen(true)} onNavigate={setActiveTab} />;
    }
  };

  return (
    <div className="min-h-screen bg-[#111516] text-[#F2F0E8] flex flex-col font-sans selection:bg-[#2E7775] selection:text-white">
      
      {/* Top Header */}
      <Header
        onOpenDemos={() => setDemosModalOpen(true)}
        devMode={devMode}
        setDevMode={setDevMode}
      />

      {/* Main Navigation Bar */}
      <Navbar activeTab={activeTab} setActiveTab={setActiveTab} />

      {/* Primary View Content Container */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto p-4 lg:p-8">
        {renderActiveView()}
      </main>

      {/* Brazilian Institutional Footer */}
      <footer className="bg-[#111516] border-t border-[#24292A] py-6 px-4 lg:px-8 text-xs text-[#D9D8D2]/50 shrink-0">
        <div className="max-w-[1600px] mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="space-y-1 text-center md:text-left">
            <div className="font-brand font-bold text-sm text-[#F8F7F2]">
              DREX — REAL DIGITAL — INFRAESTRUTURA FINANCEIRA DO BRASIL
            </div>
            <p>
              Ambiente de simulação e pesquisa sintética. Não associado oficialmente ao Banco Central do Brasil.
            </p>
          </div>

          <div className="flex items-center gap-4 text-[11px] font-mono text-[#D9D8D2]/60">
            <span>SEMENTE: DREX-2026-BRAZIL</span>
            <span>·</span>
            <span>BANCO CENTRAL DO BRASIL (SIMULADO)</span>
            <span>·</span>
            <span className="text-[#236B4B] font-bold">RESERVAS 100% AUDITADAS</span>
          </div>
        </div>
      </footer>

      {/* Interactive Signature Demos Modal */}
      <SignatureDemosModal
        isOpen={demosModalOpen}
        onClose={() => setDemosModalOpen(false)}
        onNavigateToView={(view: string) => setActiveTab(view as NavTab)}
      />

    </div>
  );
}
