/**
 * Drex — Real Digital
 * Brazilian Digital Currency & Financial Infrastructure System Types
 */

export type MonetaryInstrumentType =
  | 'WHOLESALE_DREX'        // Central Bank Wholesale Digital Currency (BCB Level)
  | 'TOKENISED_DEPOSIT'     // Retail Bank Tokenised Deposit (Commercial Bank Level)
  | 'DIGITAL_WALLET_BALANCE'// Consumer / Business Drex Balance
  | 'TOKENISED_SECURITY'    // Tesouro Direto / Public Securities
  | 'TOKENISED_RECEIVABLE'  // Card / Agricultural / Commercial Receivables
  | 'TOKENISED_COLLATERAL'; // Pledged Collateral Assets

export type WalletType =
  | 'PERSON'       // Carteira Pessoal
  | 'BUSINESS'     // Carteira Empresarial
  | 'BANK'         // Carteira Institucional / Bancária
  | 'GOVERNMENT'   // Carteira Pública
  | 'ESCROW';      // Carteira de Garantia / Smart Contract Escrow

export type TransactionStatus =
  | 'CRIADA'
  | 'VALIDANDO'
  | 'AUTORIZADA'
  | 'LIQUIDANDO'
  | 'LIQUIDADA'
  | 'REJEITADA'
  | 'REVERTIDA';

export type ContractStatus =
  | 'CRIADA'
  | 'FUNDS_LOCKED'
  | 'ASSET_LOCKED'
  | 'VALIDATING_CONDITIONS'
  | 'LIQUIDADA'
  | 'REJEITADA'
  | 'REVERTIDA';

export type AssetCategory =
  | 'TITULOS_PUBLICOS'
  | 'DEPOSITOS'
  | 'RECEBIVEIS'
  | 'CREDITO'
  | 'IMOVEIS'
  | 'VEICULOS'
  | 'AGRONEGOCIO'
  | 'FUNDO_INVESTIMENTO';

export interface Wallet {
  id: string;
  name: string;
  type: WalletType;
  institutionId: string;
  institutionName: string;
  ownerName: string;
  cpfCnpjMasked: string;
  wholesaleBalance: number;
  tokenisedDepositBalance: number;
  totalBalance: number;
  activeContractsCount: number;
  limits: {
    dailyLimit: number;
    dailyUsed: number;
    monthlyLimit: number;
  };
  status: 'ATIVA' | 'BLOQUEADA' | 'EM_REVISAO';
}

export interface Institution {
  id: string;
  code: string;
  name: string;
  shortName: string;
  type: 'CENTRAL_BANK' | 'BANCO_COMERCIAL' | 'FINTECH' | 'COOPERATIVA' | 'TESOURO';
  wholesaleBalance: number;
  totalTokenisedDeposits: number;
  reserveRatioPercent: number;
  customersCount: number;
  riskRating: 'AAA' | 'AA' | 'A' | 'BBB' | 'BB';
  liquidityStatus: 'NORMAL' | 'ATENCAO' | 'ESTRESSE';
  locationRegion: 'BRASILIA' | 'SAO_PAULO' | 'RIO' | 'NORDESTE' | 'SUL' | 'NORTE' | 'CENTRO_OESTE';
}

export interface Asset {
  id: string;
  code: string;
  name: string;
  category: AssetCategory;
  faceValue: number;
  currentPrice: number;
  yieldRatePercent?: number;
  maturityDate?: string;
  ownerWalletId: string;
  ownerName: string;
  institutionId: string;
  institutionName: string;
  isEncumbered: boolean; // Pledged as collateral
  encumbranceDetails?: string;
  simulatedNotice: string; // E.g., "DADOS SIMULADOS — AMBIENTE TESTE BCB"
  passportHash: string;
}

export interface ContractCondition {
  id: string;
  label: string;
  status: 'PENDENTE' | 'VALIDADA' | 'FALHOU';
  validatorRole: 'COMPRADOR' | 'VENDEDOR' | 'BANCO_CENTRAL' | 'REGISTRO_IMOVEIS' | 'RECEITA_FEDERAL' | 'ORACULO';
}

export interface SmartContract {
  id: string;
  title: string;
  type: 'ESCROW' | 'DvP' | 'TITULO_PUBLICO' | 'DESCONTO_RECEBIVEL' | 'TRANSFERENCIA_IMOVEL' | 'CREDITO_AGRO';
  buyerWalletId: string;
  buyerName: string;
  sellerWalletId: string;
  sellerName: string;
  assetId?: string;
  assetName?: string;
  amountBrl: number;
  conditions: ContractCondition[];
  status: ContractStatus;
  createdAt: string;
  executedAt?: string;
}

export interface Transaction {
  id: string;
  txId: string; // e.g. TX-DRX-000184291
  timestamp: string;
  blockNumber: number;
  senderWalletId: string;
  senderName: string;
  receiverWalletId: string;
  receiverName: string;
  instrumentType: MonetaryInstrumentType;
  amount: number;
  institutionId: string;
  institutionName: string;
  purpose: string;
  status: TransactionStatus;
  settlementMode: 'ATOMIC_DvP' | 'DIRECT_WHOLESALE' | 'RETAIL_DEPOSIT' | 'INTERBANK_RESERVE';
  hash: string;
  privacyStatus: 'ZK_ENCRYPTED' | 'AUDITABLE_BCB' | 'ANONYMISED';
  complianceStatus: 'APROVADO' | 'EM_REVISAO' | 'ALERTA_AML';
}

export interface ComplianceAlert {
  id: string;
  txId: string;
  timestamp: string;
  amount: number;
  pattern: string;
  riskScore: number; // 0 - 100
  status: 'PENDENTE_ANALISE' | 'REVISADO_APROVADO' | 'BLOQUEADO';
  institutionName: string;
  walletName: string;
}

export interface SystemMetrics {
  totalLiquidityBrl: number;
  wholesaleDrexSupplyBrl: number;
  tokenisedDepositsBrl: number;
  txCountToday: number;
  settledValueTodayBrl: number;
  activeContractsCount: number;
  tokenisedAssetsValueBrl: number;
  participatingInstitutionsCount: number;
  activeWalletsCount: number;
  systemHealth: 'OPTIMAL' | 'DEGRADED' | 'HIGH_LOAD';
  averageSettlementLatencyMs: number;
  lastBlockNumber: number;
}

export interface EconomicRegionFlow {
  region: string;
  cityName: string;
  lat: number;
  lng: number;
  activeTxRate: number;
  volumeBrlMillions: number;
}
