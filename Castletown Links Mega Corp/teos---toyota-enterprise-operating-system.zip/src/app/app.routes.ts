import {Routes} from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'executive',
    pathMatch: 'full'
  },
  {
    path: 'executive',
    loadComponent: () => import('./features/executive/executive').then(m => m.ExecutiveCommand),
    title: 'TEOS · Executive Command Centre'
  },
  {
    path: 'plant',
    loadComponent: () => import('./features/plant/plant').then(m => m.PlantCommand),
    title: 'TEOS · Plant Shop Floor Digital Twin'
  },
  {
    path: 'jit',
    loadComponent: () => import('./features/jit/jit').then(m => m.JitStudio),
    title: 'TEOS · JIT Engine & Heijunka Studio'
  },
  {
    path: 'andon',
    loadComponent: () => import('./features/andon/andon').then(m => m.AndonCentre),
    title: 'TEOS · Jidoka & Andon Command'
  },
  {
    path: 'kaizen',
    loadComponent: () => import('./features/kaizen/kaizen').then(m => m.KaizenWorkspace),
    title: 'TEOS · Continuous Improvement & 5-Whys'
  },
  {
    path: 'msp',
    loadComponent: () => import('./features/msp/msp').then(m => m.MspStudio),
    title: 'TEOS · Mobility Software Platform'
  },
  {
    path: 'twin',
    loadComponent: () => import('./features/twin/twin').then(m => m.VehicleTwin),
    title: 'TEOS · Vehicle & BMS Digital Twin'
  },
  {
    path: 'supply-chain',
    loadComponent: () => import('./features/supply-chain/supply-chain').then(m => m.SupplyChainTower),
    title: 'TEOS · Supply Chain Control Tower'
  },
  {
    path: 'quality',
    loadComponent: () => import('./features/quality/quality').then(m => m.QualitySafety),
    title: 'TEOS · Statistical Quality & ASIL-D'
  },
  {
    path: 'finance',
    loadComponent: () => import('./features/finance/finance').then(m => m.FinanceLedger),
    title: 'TEOS · Financial Ledger & Unit Economics'
  },
  {
    path: 'ringi',
    loadComponent: () => import('./features/ringi/ringi').then(m => m.RingiWorkflow),
    title: 'TEOS · Ringi Electronic Approvals'
  },
  {
    path: 'audit',
    loadComponent: () => import('./features/audit/audit').then(m => m.AuditViewer),
    title: 'TEOS · Immutable Audit Event Bus'
  },
  {
    path: 'blueprint',
    loadComponent: () => import('./features/blueprint/blueprint').then(m => m.SystemBlueprint),
    title: 'TEOS · System Blueprint & Test Suite'
  },
  {
    path: '**',
    redirectTo: 'executive'
  }
];

