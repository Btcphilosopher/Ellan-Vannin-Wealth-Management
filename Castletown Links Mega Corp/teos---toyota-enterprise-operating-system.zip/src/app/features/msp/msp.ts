import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { VehicleMspService } from '../../core/services/vehicle-msp.service';
import { I18nService } from '../../core/services/i18n.service';
import { MspSoftwarePackage, VehicleModel } from '../../core/models/enterprise.model';

@Component({
  selector: 'app-msp-studio',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-3">
            <mat-icon class="text-indigo-400">directions_car</mat-icon>
            <div>
              <h2 class="text-xl font-bold text-white tracking-tight">
                {{ i18n.isJapanese() ? 'モビリティ・ソフトウェア・プラットフォーム (MSP) 管制スタジオ' : 'Mobility Software Platform (MSP-OS) Studio' }}
              </h2>
              <p class="text-xs text-slate-400 font-mono">
                SOFTWARE-DEFINED VEHICLE (SDV) ARCHITECTURE · ASIL-D ISO 26262 SAFETY GATES · CANARY OTA PIPELINE
              </p>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <span class="px-3 py-1 rounded text-xs font-mono bg-indigo-950/80 border border-indigo-800 text-indigo-300">
            ARENE REFERENCE RUNTIME · 4.82M FLEET CONNECTED
          </span>
        </div>
      </div>

      <!-- Vehicle Model Graph & ECU Registry -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Vehicle Models (4 cols) -->
        <div class="lg:col-span-4 space-y-4">
          <h3 class="text-sm font-bold text-white flex items-center gap-2">
            <mat-icon class="text-indigo-400 text-sm">hub</mat-icon>
            {{ i18n.isJapanese() ? 'SDV ビークルモデル・グラフ' : 'SDV Vehicle Model Graph' }}
          </h3>

          @for (vm of mspService.vehicleModels(); track vm.vin) {
            <div 
              (click)="selectedModel.set(vm)"
              class="p-4 rounded-xl border transition-all cursor-pointer bg-slate-900/90"
              [class.border-indigo-500]="selectedModel()?.vin === vm.vin"
              [class.border-slate-800]="selectedModel()?.vin !== vm.vin">
              
              <div class="flex items-start justify-between">
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700">
                  {{ vm.assemblyPlant }}
                </span>
                <span class="text-xs font-mono text-cyan-400">{{ vm.powertrainType }}</span>
              </div>

              <h4 class="text-base font-bold text-white mt-2">{{ vm.modelName }}</h4>
              <p class="text-xs text-slate-400">{{ vm.japaneseName }}</p>

              <div class="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
                <span>Release: <strong class="text-indigo-300">{{ vm.currentSoftwareRelease }}</strong></span>
                <span>ECUs: {{ vm.ecuList.length }}</span>
              </div>
            </div>
          }
        </div>

        <!-- ECU Domain Controller Topology (8 cols) -->
        <div class="lg:col-span-8 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
          @if (selectedModel(); as m) {
            <div>
              <div class="flex items-start justify-between pb-4 border-b border-slate-800">
                <div>
                  <h3 class="text-base font-bold text-white">{{ m.modelName }} ({{ m.japaneseName }})</h3>
                  <p class="text-xs text-slate-400 font-mono">VIN: {{ m.vin }} · Plant: {{ m.assemblyPlant }} · Variant: {{ m.variant }}</p>
                </div>
                <div class="text-right">
                  <span class="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-emerald-950 border border-emerald-800 text-emerald-300">
                    CANARY OTA READY
                  </span>
                </div>
              </div>

              <!-- ECU Nodes Grid -->
              <div class="mt-4">
                <h4 class="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">
                  Domain Controllers & High-Compute Zonal ECUs
                </h4>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                  @for (ecu of m.ecuList; track ecu.ecuId) {
                    <div class="p-3.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-col justify-between">
                      <div>
                        <div class="flex items-center justify-between">
                          <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-950 text-indigo-300 border border-indigo-800">
                            {{ ecu.architectureDomain }}
                          </span>
                          <span class="text-[10px] font-mono text-slate-400">{{ ecu.hardwarePartNumber }}</span>
                        </div>

                        <h5 class="text-sm font-bold text-white mt-1.5">{{ ecu.name }}</h5>
                        <p class="text-xs text-slate-400 font-mono text-[11px] mt-0.5">Status: {{ ecu.status }} · ID: {{ ecu.ecuId }}</p>
                      </div>

                      <div class="mt-3 pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs font-mono">
                        <span class="text-slate-400">Firmware: <strong class="text-cyan-400">{{ ecu.installedFirmware }}</strong></span>
                        <span class="text-[10px] text-emerald-400 flex items-center gap-1">
                          <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span> Target: {{ ecu.targetFirmware }}
                        </span>
                      </div>
                    </div>
                  }
                </div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Mobility Software Release Packages & Canary OTA Pipeline -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 class="text-base font-bold text-white flex items-center gap-2">
              <mat-icon class="text-cyan-400">system_update_alt</mat-icon>
              {{ i18n.isJapanese() ? 'MSP-OS ソフトウェアリリース & カナリアOTAデプロイ' : 'MSP-OS Software Packages & Canary Deployment Pipeline' }}
            </h3>
            <p class="text-xs text-slate-400">Zero-downtime dual-bank A/B partitioning with automated safety rollback on anomaly.</p>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
          @for (pkg of mspService.softwarePackages(); track pkg.packageId) {
            <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div class="flex items-start justify-between">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-base font-bold text-white font-mono">{{ pkg.version }}</span>
                    <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-950 text-rose-300 border border-rose-800">
                      {{ pkg.asilSafetyRating }}
                    </span>
                  </div>
                  <div class="text-xs text-slate-400 font-mono mt-0.5">Commit: {{ pkg.gitCommitHash }}</div>
                </div>

                <span class="px-2 py-0.5 rounded text-xs font-mono font-bold bg-indigo-950 text-indigo-300 border border-indigo-800">
                  {{ pkg.deploymentPhase }}
                </span>
              </div>

              <div class="text-xs text-slate-300 leading-relaxed">{{ pkg.releaseNotes }}</div>

              <div class="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-900 p-2.5 rounded border border-slate-800">
                <div>SIL Coverage: <strong class="text-emerald-400">{{ pkg.silTestCoveragePct }}%</strong></div>
                <div>HIL Pass Rate: <strong class="text-cyan-400">{{ pkg.hilTestPassRatePct }}%</strong></div>
                <div class="col-span-2 truncate text-slate-400 text-[10px]">SHA: {{ pkg.checksumSha256.slice(0, 24) }}...</div>
              </div>

              <div class="pt-2 flex items-center justify-end gap-2">
                <button 
                  (click)="promoteCanary(pkg.packageId)"
                  class="px-3 py-1.5 rounded bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs font-mono tracking-wider flex items-center gap-1">
                  <mat-icon class="text-sm scale-75">upload</mat-icon> PROMOTE OTA WAVE
                </button>
                <button 
                  (click)="rollback(pkg.packageId)"
                  class="px-3 py-1.5 rounded bg-rose-950 hover:bg-rose-900 border border-rose-700 text-rose-300 font-bold text-xs font-mono tracking-wider flex items-center gap-1">
                  <mat-icon class="text-sm scale-75">undo</mat-icon> ROLLBACK
                </button>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class MspStudio {
  public mspService = inject(VehicleMspService);
  public i18n = inject(I18nService);

  public selectedModel = signal<VehicleModel | null>(this.mspService.vehicleModels()[0] || null);

  public promoteCanary(pkgId: string): void {
    this.mspService.promotePackageToNextWave(pkgId);
  }

  public rollback(pkgId: string): void {
    this.mspService.rollbackPackage(pkgId, 'Field safety watchdog triggered precaution rollback.');
  }
}
