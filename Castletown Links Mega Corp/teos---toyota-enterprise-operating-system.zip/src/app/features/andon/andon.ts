import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { JidokaAndonService } from '../../core/services/jidoka-andon.service';
import { I18nService } from '../../core/services/i18n.service';
import { AndonEvent } from '../../core/models/enterprise.model';

@Component({
  selector: 'app-andon-centre',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-3">
            <mat-icon class="text-rose-500 animate-pulse">warning</mat-icon>
            <div>
              <h2 class="text-xl font-bold text-white tracking-tight">
                {{ i18n.isJapanese() ? '自働化 (Jidoka) · 行灯 (Andon) 統合管制センター' : 'Jidoka & Andon Production Interlock Centre' }}
              </h2>
              <p class="text-xs text-slate-400 font-mono">
                AUTONOMATION WITH HUMAN TOUCH · STOP AT DEFECT · 9-STAGE ESCALATION PIPELINE
              </p>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <button 
            (click)="triggerNewAbnormality()"
            class="px-4 py-2 rounded-lg bg-rose-700 hover:bg-rose-600 text-white font-bold text-xs font-mono tracking-wider flex items-center gap-2 shadow-lg shadow-rose-950 transition-all">
            <mat-icon class="text-sm">notification_important</mat-icon> SIMULATE ANDON CORD PULL
          </button>
        </div>
      </div>

      <!-- Active Andon Overview Ribbon -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div class="text-xs text-slate-400">Total Active Incidents</div>
          <div class="text-2xl font-bold text-white font-mono mt-1">
            {{ andonService.activeEvents().length }}
          </div>
          <div class="text-xs text-slate-400 mt-1 font-mono">Across 5 Global Hubs</div>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div class="text-xs text-slate-400">Total Line Downtime Incurred</div>
          <div class="text-2xl font-bold text-rose-400 font-mono mt-1">
            {{ andonService.totalDowntimeSeconds() }}s
          </div>
          <div class="text-xs text-slate-400 mt-1 font-mono">Preventing defect leakage downstream</div>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div class="text-xs text-slate-400">Jidoka Principle</div>
          <div class="text-sm font-bold text-emerald-400 mt-1">
            {{ i18n.isJapanese() ? '「不良品は後工程に絶対に流さない」' : '"Never Pass a Defect to the Next Process"' }}
          </div>
          <div class="text-xs text-slate-400 mt-1 font-mono">Autonomous interlocks prevent compounding defects</div>
        </div>
      </div>

      <!-- Main Andon Board & Detailed Investigation View -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Active Incident List (5 cols) -->
        <div class="lg:col-span-5 space-y-4">
          <h3 class="text-sm font-bold text-white flex items-center gap-2">
            <mat-icon class="text-amber-400 text-sm">dynamic_feed</mat-icon>
            {{ i18n.isJapanese() ? 'アクティブ異常インシデント一覧' : 'Active Abnormality Stream' }}
          </h3>

          @for (ev of andonService.activeEvents(); track ev.id) {
            <button 
              type="button"
              (click)="selectedEvent.set(ev)"
              class="w-full text-left p-4 rounded-xl border transition-all cursor-pointer bg-slate-900/90 block"
              [class.border-rose-600]="ev.severity === 'RED_STOP_LINE' && selectedEvent()?.id === ev.id"
              [class.border-slate-800]="selectedEvent()?.id !== ev.id"
              [class.border-amber-600]="ev.severity === 'YELLOW_WARNING' && selectedEvent()?.id === ev.id">
              
              <div class="flex items-start justify-between gap-2">
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                  [class.bg-rose-950]="ev.severity === 'RED_STOP_LINE'"
                  [class.text-rose-300]="ev.severity === 'RED_STOP_LINE'"
                  [class.bg-amber-950]="ev.severity === 'YELLOW_WARNING'"
                  [class.text-amber-300]="ev.severity === 'YELLOW_WARNING'">
                  {{ ev.severity }}
                </span>
                <span class="text-xs font-mono text-slate-400">Downtime: {{ ev.downtimeSeconds }}s</span>
              </div>

              <h4 class="text-sm font-bold text-white mt-2">{{ ev.stationName }} ({{ ev.lineName }})</h4>
              <p class="text-xs text-slate-300 mt-1">{{ ev.problemDescription }}</p>

              <div class="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
                <span>Stage {{ ev.escalationStage }}/9: {{ andonService.getStageName(ev.escalationStage).en }}</span>
                <span class="text-cyan-400">Details →</span>
              </div>
            </button>
          }
        </div>

        <!-- 9-Stage Resolution Workflow Stepper (7 cols) -->
        <div class="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl">
          @if (selectedEvent(); as activeEv) {
            <div class="space-y-6">
              <div class="flex items-start justify-between pb-4 border-b border-slate-800">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-xs font-mono text-slate-400">{{ activeEv.id }}</span>
                    <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-950 text-rose-300 border border-rose-800">
                      {{ activeEv.severity }}
                    </span>
                  </div>
                  <h3 class="text-lg font-bold text-white mt-1">{{ activeEv.stationName }}</h3>
                  <p class="text-xs text-slate-400 font-mono">{{ activeEv.lineName }} · Category: {{ activeEv.category }}</p>
                </div>

                <div class="text-right">
                  <div class="text-xs text-slate-400 font-mono">Downtime Counter</div>
                  <div class="text-xl font-bold font-mono text-rose-400">{{ activeEv.downtimeSeconds }}s</div>
                </div>
              </div>

              <!-- 9 Stages Visual Progression -->
              <div>
                <h4 class="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">
                  9-Stage Standard TPS Resolution Stepper
                </h4>
                <div class="grid grid-cols-3 sm:grid-cols-5 md:grid-cols-9 gap-1 text-center font-mono">
                  @for (s of [1,2,3,4,5,6,7,8,9]; track s) {
                    <div class="p-2 rounded border text-[10px]"
                      [class.bg-emerald-950]="activeEv.escalationStage > s"
                      [class.border-emerald-700]="activeEv.escalationStage > s"
                      [class.text-emerald-300]="activeEv.escalationStage > s"
                      [class.bg-amber-950]="activeEv.escalationStage === s"
                      [class.border-amber-500]="activeEv.escalationStage === s"
                      [class.text-amber-200]="activeEv.escalationStage === s"
                      [class.bg-slate-950]="activeEv.escalationStage < s"
                      [class.border-slate-800]="activeEv.escalationStage < s"
                      [class.text-slate-600]="activeEv.escalationStage < s">
                      <div class="font-bold">#{{ s }}</div>
                      <div class="truncate text-[9px] mt-0.5">{{ andonService.getStageName(s).ja }}</div>
                    </div>
                  }
                </div>
              </div>

              <!-- Current Stage Action & Form -->
              <div class="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-4">
                <div class="flex items-center justify-between">
                  <span class="text-xs font-bold text-white font-mono">
                    CURRENT: Stage {{ activeEv.escalationStage }} - {{ andonService.getStageName(activeEv.escalationStage).en }} ({{ andonService.getStageName(activeEv.escalationStage).ja }})
                  </span>
                  <span class="text-xs text-slate-400 font-mono">Leader: {{ activeEv.assignedLeader || 'Dispatched' }}</span>
                </div>

                <div class="space-y-2">
                  <label for="andonCountermeasure" class="block text-xs text-slate-300">Containment Action / Countermeasure Log:</label>
                  <textarea 
                    id="andonCountermeasure"
                    #countermeasureInput
                    rows="3" 
                    placeholder="Enter immediate containment action (Genchi Genbutsu observation, tool replacement, calibration verification)..."
                    class="w-full bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none"></textarea>
                </div>

                <div class="flex justify-end gap-3 pt-2">
                  <button 
                    (click)="advanceStage(activeEv.id, countermeasureInput.value)"
                    class="py-2 px-4 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white font-bold text-xs font-mono tracking-wider flex items-center gap-2 shadow-lg shadow-emerald-950">
                    <mat-icon class="text-sm">verified</mat-icon> ADVANCE STAGE & RESOLVE
                  </button>
                </div>
              </div>
            </div>
          } @else {
            <div class="p-12 text-center text-slate-500 font-mono text-xs">
              Select an active abnormality from the list to inspect and resolve.
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class AndonCentre {
  public andonService = inject(JidokaAndonService);
  public i18n = inject(I18nService);

  public selectedEvent = signal<AndonEvent | null>(this.andonService.activeEvents()[0] || null);

  public triggerNewAbnormality(): void {
    const ev = this.andonService.pullAndonCord(
      'ST-TSUT-WELD-04',
      'Underbody Robotic Spot Weld',
      'Flexible Body Welding Line',
      'PLANT-TSUTSUMI',
      'QUALITY_DEFECT',
      'RED_STOP_LINE',
      'Ultrasonic inline weld inspection detected micro-void in B-pillar high-tensile steel flange.'
    );
    this.selectedEvent.set(ev);
  }

  public advanceStage(eventId: string, notes: string): void {
    this.andonService.advanceEscalationStage(eventId, notes);
    this.selectedEvent.set(this.andonService.activeEvents().find(e => e.id === eventId) || null);
  }
}

