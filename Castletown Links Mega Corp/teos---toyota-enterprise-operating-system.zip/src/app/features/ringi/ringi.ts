import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { RingiWorkflowService } from '../../core/services/ringi-workflow.service';
import { I18nService } from '../../core/services/i18n.service';
import { RingiDocument } from '../../core/models/enterprise.model';

@Component({
  selector: 'app-ringi-workflow',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-3">
            <mat-icon class="text-rose-400">approval</mat-icon>
            <div>
              <h2 class="text-xl font-bold text-white tracking-tight">
                {{ i18n.isJapanese() ? '電子稟議 (Ringi) & 決裁ワークフロー' : 'Enterprise Ringi Electronic Approval Workflow' }}
              </h2>
              <p class="text-xs text-slate-400 font-mono">
                JAPANESE DECISION-MAKING CONSENSUS · ELECTRONIC HANKO (判子) STAMPING · SASHIMODOSHI (差戻し)
              </p>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <span class="px-3 py-1 rounded text-xs font-mono bg-rose-950/80 border border-rose-800 text-rose-300">
            CORPORATE DECISION CONSENSUS
          </span>
        </div>
      </div>

      <!-- Ringi Documents List & Hanko Approval Card -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Document List (5 cols) -->
        <div class="lg:col-span-5 space-y-4">
          <h3 class="text-sm font-bold text-white flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-sm">description</mat-icon>
            {{ i18n.isJapanese() ? '申請中・決裁済み稟議書一覧' : 'Ringi Documents' }}
          </h3>

          @for (doc of ringiService.documents(); track doc.id) {
            <div 
              (click)="selectedDoc.set(doc)"
              class="p-4 rounded-xl border transition-all cursor-pointer bg-slate-900/90"
              [class.border-rose-600]="selectedDoc()?.id === doc.id"
              [class.border-slate-800]="selectedDoc()?.id !== doc.id">
              
              <div class="flex items-start justify-between gap-2">
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700">
                  {{ doc.ringiNumber }}
                </span>
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                  [class.bg-emerald-950]="doc.status === 'FORMALLY_DECIDED_APPROVED'"
                  [class.text-emerald-300]="doc.status === 'FORMALLY_DECIDED_APPROVED'"
                  [class.bg-amber-950]="doc.status === 'UNDER_CONFIRMATION'"
                  [class.text-amber-300]="doc.status === 'UNDER_CONFIRMATION'"
                  [class.bg-blue-950]="doc.status === 'SUBMITTED_FOR_REVIEW'"
                  [class.text-blue-300]="doc.status === 'SUBMITTED_FOR_REVIEW'">
                  {{ doc.status }}
                </span>
              </div>

              <h4 class="text-sm font-bold text-white mt-2">{{ doc.title }}</h4>
              <p class="text-xs text-slate-400 font-mono mt-0.5">{{ doc.japaneseTitle }}</p>

              <div class="mt-3 pt-2 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
                <span>By: {{ doc.applicant.name }}</span>
                <span class="text-cyan-400">Inspect →</span>
              </div>
            </div>
          }
        </div>

        <!-- Selected Document Details & Hanko Seals (7 cols) -->
        <div class="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-6">
          @if (selectedDoc(); as d) {
            <div>
              <div class="flex items-start justify-between pb-4 border-b border-slate-800">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="text-xs font-mono text-slate-400">{{ d.ringiNumber }}</span>
                    <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-rose-950 text-rose-300 border border-rose-800">
                      {{ d.category }}
                    </span>
                  </div>
                  <h3 class="text-lg font-bold text-white mt-1">{{ d.title }}</h3>
                  <p class="text-xs text-slate-400">{{ d.japaneseTitle }}</p>
                </div>

                <div class="text-right">
                  <div class="text-[10px] font-mono text-slate-400">Submission Date</div>
                  <div class="text-xs font-bold text-white font-mono mt-0.5">{{ d.submissionDate | date:'short' }}</div>
                </div>
              </div>

              <!-- Applicant & Justification -->
              <div class="mt-4 space-y-3">
                <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs">
                  <span class="text-slate-400 font-mono">Applicant / Department:</span>
                  <div class="font-bold text-white mt-0.5">{{ d.applicant.name }} · {{ d.applicant.department }}</div>
                  <div class="text-slate-400 font-mono text-[11px]">{{ d.applicant.email }}</div>
                </div>

                <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs">
                  <span class="font-bold text-cyan-400 font-mono">Proposal Justification:</span>
                  <p class="text-slate-200 mt-1">{{ d.justificationText }}</p>
                </div>

                <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs">
                  <span class="font-bold text-amber-400 font-mono">Risk & Contingency Assessment:</span>
                  <p class="text-slate-200 mt-1">{{ d.riskAssessment }}</p>
                </div>
              </div>

              <!-- Hanko (判子) Electronic Seals Stepper -->
              <div class="bg-slate-950 p-4 rounded-lg border border-slate-800">
                <h4 class="text-xs font-mono text-slate-400 uppercase tracking-wider mb-4 flex items-center justify-between">
                  <span>Electronic Hanko (電子判子) Approval Chain</span>
                  <span class="text-[10px] text-emerald-400">Immutable Cryptographic Seal</span>
                </h4>

                <div class="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  @for (app of d.approvers; track app.role) {
                    <div class="p-3 rounded-lg bg-slate-900 border border-slate-800 flex flex-col items-center text-center justify-between">
                      <div class="text-[11px] font-mono text-slate-400">{{ app.role }}</div>
                      <div class="text-xs font-bold text-white mt-1">{{ app.approverName }}</div>

                      <!-- Circular Hanko Stamp Graphic -->
                      <div class="my-3 w-16 h-16 rounded-full border-2 flex flex-col items-center justify-center p-1 font-serif transition-all"
                        [class.border-rose-600]="app.decision === 'APPROVED'"
                        [class.text-rose-500]="app.decision === 'APPROVED'"
                        [class.bg-rose-950/40]="app.decision === 'APPROVED'"
                        [class.border-dashed]="app.decision === 'PENDING'"
                        [class.border-slate-700]="app.decision === 'PENDING'"
                        [class.text-slate-600]="app.decision === 'PENDING'">
                        @if (app.decision === 'APPROVED') {
                          <div class="text-[9px] font-bold border-b border-rose-600/80 w-full text-center">承認</div>
                          <div class="text-xs font-bold">{{ app.hankoStamp }}</div>
                          <div class="text-[7px] text-rose-400 font-mono">{{ app.decidedAt | date:'MM/dd' }}</div>
                        } @else {
                          <div class="text-[10px] font-mono">未決</div>
                        }
                      </div>

                      <div class="text-[10px] font-mono" [class.text-emerald-400]="app.decision === 'APPROVED'" [class.text-slate-500]="app.decision === 'PENDING'">
                        {{ app.decision }}
                      </div>
                    </div>
                  }
                </div>

                <!-- Approval Actions -->
                @if (d.status !== 'FORMALLY_DECIDED_APPROVED') {
                  <div class="mt-4 pt-4 border-t border-slate-800 flex justify-end gap-3">
                    <button 
                      (click)="returnDoc(d.id)"
                      class="px-4 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 border border-slate-700 text-slate-300 font-bold text-xs font-mono">
                      差戻し (Sashimodoshi - Return for Revision)
                    </button>
                    <button 
                      (click)="approveDoc(d.id)"
                      class="px-4 py-2 rounded-lg bg-rose-700 hover:bg-rose-600 text-white font-bold text-xs font-mono tracking-wider flex items-center gap-1.5 shadow-lg shadow-rose-950">
                      <mat-icon class="text-sm">verified</mat-icon> 押印・承認 (Affix Hanko & Approve)
                    </button>
                  </div>
                }
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class RingiWorkflow {
  public ringiService = inject(RingiWorkflowService);
  public i18n = inject(I18nService);

  public selectedDoc = signal<RingiDocument | null>(this.ringiService.documents()[0] || null);

  public approveDoc(id: string): void {
    this.ringiService.approveStep(id, 'General Manager', '豊田', 'Final executive verification complete.');
    this.selectedDoc.set(this.ringiService.documents().find(d => d.id === id) || null);
  }

  public returnDoc(id: string): void {
    this.ringiService.returnSashimodoshi(id, 'Corporate Finance GM', 'Provide additional detail on equipment depreciation schedule.');
    this.selectedDoc.set(this.ringiService.documents().find(d => d.id === id) || null);
  }
}
