import { ChangeDetectionStrategy, Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PlantDigitalTwinService } from '../../core/services/plant-digital-twin.service';
import { JidokaAndonService } from '../../core/services/jidoka-andon.service';
import { I18nService } from '../../core/services/i18n.service';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-executive-command',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule, RouterLink],
  template: `
    <div class="space-y-6">
      <!-- Top Banner Summary -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-6 shadow-xl">
        <div class="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-slate-800">
          <div>
            <div class="flex items-center gap-2">
              <span class="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></span>
              <h2 class="text-xl font-bold tracking-tight text-white">
                {{ i18n.isJapanese() ? 'グローバル役員統括オペレーション司令室' : 'Global Executive Enterprise Command Centre' }}
              </h2>
            </div>
            <p class="text-xs text-slate-400 mt-1 font-mono">
              TEOS-CLUSTER-GLOBAL · UTC+09:00 (JST) · SYNTHETIC ENTERPRISE TELEMETRY
            </p>
          </div>

          <div class="flex items-center gap-3">
            <span class="px-3 py-1 rounded-md text-xs font-mono bg-rose-950/80 border border-rose-800/80 text-rose-300">
              {{ i18n.isJapanese() ? '合成データ運用中' : 'SYNTHETIC DATA MODE' }}
            </span>
            <span class="px-3 py-1 rounded-md text-xs font-mono bg-slate-800 border border-slate-700 text-slate-300">
              5 GLOBAL HUBS ACTIVE
            </span>
          </div>
        </div>

        <!-- Global Enterprise High-Level KPIs -->
        <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-6">
          <div class="bg-slate-950/80 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400 font-medium">Daily Production Target</div>
            <div class="text-2xl font-bold text-white font-mono mt-1">5,340 <span class="text-xs text-slate-400 font-normal">/ 5,340</span></div>
            <div class="text-xs text-emerald-400 mt-1 font-mono flex items-center gap-1">
              <mat-icon class="text-sm scale-75">trending_up</mat-icon> 100.0% on pace
            </div>
          </div>

          <div class="bg-slate-950/80 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400 font-medium">Global First Pass Yield (FPY)</div>
            <div class="text-2xl font-bold text-emerald-400 font-mono mt-1">98.92%</div>
            <div class="text-xs text-slate-400 mt-1 font-mono">+0.14% vs Q2 benchmark</div>
          </div>

          <div class="bg-slate-950/80 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400 font-medium">Global OEE Index</div>
            <div class="text-2xl font-bold text-cyan-400 font-mono mt-1">93.4%</div>
            <div class="text-xs text-emerald-400 mt-1 font-mono">World-class benchmark</div>
          </div>

          <div class="bg-slate-950/80 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400 font-medium">Active Andon Events</div>
            <div class="text-2xl font-bold text-amber-400 font-mono mt-1">3 <span class="text-xs text-slate-400 font-normal">Active</span></div>
            <div class="text-xs text-rose-400 mt-1 font-mono flex items-center gap-1">
              <span class="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span> 1 Line Stop Interlock
            </div>
          </div>

          <div class="bg-slate-950/80 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400 font-medium">Carbon per Vehicle</div>
            <div class="text-2xl font-bold text-emerald-300 font-mono mt-1">0.68 <span class="text-xs text-slate-400 font-normal">tCO2e</span></div>
            <div class="text-xs text-emerald-400 mt-1 font-mono">-12.4% YoY reduction</div>
          </div>

          <div class="bg-slate-950/80 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400 font-medium">Connected SDV Fleet</div>
            <div class="text-2xl font-bold text-indigo-300 font-mono mt-1">4.82M</div>
            <div class="text-xs text-slate-400 mt-1 font-mono">MSP-OS Telemetry Active</div>
          </div>
        </div>
      </div>

      <!-- Plants Grid Status -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        @for (plant of plantService.plants(); track plant.id) {
          <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 hover:border-slate-700 transition-all flex flex-col justify-between">
            <div>
              <div class="flex items-start justify-between gap-3">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="px-2 py-0.5 rounded text-[10px] font-mono font-semibold bg-slate-800 text-slate-300 border border-slate-700">
                      {{ plant.code }}
                    </span>
                    <span class="text-xs text-slate-400">{{ plant.country }}</span>
                  </div>
                  <h3 class="text-base font-bold text-white mt-1.5">{{ plant.name }}</h3>
                  <p class="text-xs text-slate-400 font-medium">{{ plant.japaneseName }}</p>
                </div>

                @if (plant.operatingState === 'RUNNING') {
                  <span class="px-2.5 py-1 rounded-full text-xs font-mono font-medium bg-emerald-950/80 border border-emerald-800 text-emerald-300 flex items-center gap-1.5">
                    <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span> RUNNING
                  </span>
                } @else {
                  <span class="px-2.5 py-1 rounded-full text-xs font-mono font-medium bg-rose-950/80 border border-rose-800 text-rose-300 flex items-center gap-1.5">
                    <span class="w-1.5 h-1.5 rounded-full bg-rose-400 animate-pulse"></span> STOPPED
                  </span>
                }
              </div>

              <!-- Plant Stats -->
              <div class="grid grid-cols-3 gap-2 mt-4 bg-slate-950/60 p-3 rounded-lg border border-slate-800/80">
                <div>
                  <div class="text-[10px] text-slate-400">Daily Target</div>
                  <div class="text-sm font-bold text-white font-mono mt-0.5">{{ plant.dailyTargetVehicles }} veh</div>
                </div>
                <div>
                  <div class="text-[10px] text-slate-400">Takt Time</div>
                  <div class="text-sm font-bold text-cyan-400 font-mono mt-0.5">{{ plant.activeTaktSeconds }}s</div>
                </div>
                <div>
                  <div class="text-[10px] text-slate-400">OEE Score</div>
                  <div class="text-sm font-bold text-emerald-400 font-mono mt-0.5">{{ plant.oeePercentage }}%</div>
                </div>
              </div>
            </div>

            <div class="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between">
              <span class="text-xs text-slate-400 font-mono">Shift: {{ plant.currentShift }}</span>
              <a [routerLink]="['/plant']" class="text-xs text-rose-400 hover:text-rose-300 font-medium flex items-center gap-1">
                Open Plant Digital Twin <mat-icon class="text-xs scale-75">arrow_forward</mat-icon>
              </a>
            </div>
          </div>
        }
      </div>

      <!-- Critical Active Exceptions & Live Andon Feed -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <div class="flex items-center gap-2">
            <mat-icon class="text-amber-400">notifications_active</mat-icon>
            <h3 class="text-base font-bold text-white">
              {{ i18n.isJapanese() ? 'リアルタイム異常検知 & 行灯エスカレーション' : 'Real-Time Abnormality Feed & Andon Escalations' }}
            </h3>
          </div>
          <a [routerLink]="['/andon']" class="text-xs text-rose-400 hover:text-rose-300 font-medium flex items-center gap-1">
            {{ i18n.isJapanese() ? '行灯コントロールセンターを開く' : 'Go to Andon Command' }} <mat-icon class="text-xs scale-75">arrow_forward</mat-icon>
          </a>
        </div>

        <div class="divide-y divide-slate-800 mt-2">
          @for (ev of andonService.activeEvents(); track ev.id) {
            <div class="py-3 flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div class="flex items-start gap-3">
                <span class="mt-0.5 px-2 py-0.5 rounded text-xs font-mono font-bold"
                  [class.bg-rose-950]="ev.severity === 'RED_STOP_LINE'"
                  [class.border]="true"
                  [class.border-rose-800]="ev.severity === 'RED_STOP_LINE'"
                  [class.text-rose-300]="ev.severity === 'RED_STOP_LINE'"
                  [class.bg-amber-950]="ev.severity === 'YELLOW_WARNING'"
                  [class.border-amber-800]="ev.severity === 'YELLOW_WARNING'"
                  [class.text-amber-300]="ev.severity === 'YELLOW_WARNING'">
                  {{ ev.severity === 'RED_STOP_LINE' ? 'LINE STOP' : 'WARNING' }}
                </span>

                <div>
                  <div class="text-sm font-semibold text-white">{{ ev.stationName }} ({{ ev.lineName }})</div>
                  <div class="text-xs text-slate-300 mt-0.5">{{ ev.problemDescription }}</div>
                  <div class="text-[11px] text-slate-400 mt-1 font-mono">
                    Operator: {{ ev.operatorName }} · Stage {{ ev.escalationStage }}/9: {{ andonService.getStageName(ev.escalationStage).en }}
                  </div>
                </div>
              </div>

              <div class="flex items-center gap-3 self-end md:self-center">
                <span class="text-xs font-mono text-slate-400">Downtime: {{ ev.downtimeSeconds }}s</span>
                <a [routerLink]="['/andon']" class="px-3 py-1 text-xs font-semibold rounded bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700">
                  Inspect
                </a>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class ExecutiveCommand {
  public plantService = inject(PlantDigitalTwinService);
  public andonService = inject(JidokaAndonService);
  public i18n = inject(I18nService);
}
