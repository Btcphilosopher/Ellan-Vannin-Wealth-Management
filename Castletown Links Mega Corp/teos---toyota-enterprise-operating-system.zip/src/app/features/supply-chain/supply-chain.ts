import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SupplyChainService } from '../../core/services/supply-chain.service';
import { I18nService } from '../../core/services/i18n.service';

@Component({
  selector: 'app-supply-chain-tower',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-3">
            <mat-icon class="text-blue-400">local_shipping</mat-icon>
            <div>
              <h2 class="text-xl font-bold text-white tracking-tight">
                {{ i18n.isJapanese() ? 'サプライチェーン統括管制タワー & マルチモーダル物流' : 'Global Supply Chain Control Tower & Intermodal Logistics' }}
              </h2>
              <p class="text-xs text-slate-400 font-mono">
                TIER-1 TO TIER-3 SUPPLIER RISK MATRIX · MARITIME/RAIL TELEMETRY · DISRUPTION SIMULATOR
              </p>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <span class="px-3 py-1 rounded text-xs font-mono bg-blue-950/80 border border-blue-800 text-blue-300">
            GLOBAL LOGISTICS ACTIVE
          </span>
        </div>
      </div>

      <!-- Intermodal Shipments Tracker & Port Disruption Simulator -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
        <div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800">
          <div>
            <h3 class="text-base font-bold text-white flex items-center gap-2">
              <mat-icon class="text-cyan-400">directions_boat</mat-icon>
              {{ i18n.isJapanese() ? '輸送中マルチモーダル貨物 (船舶・鉄道・EVトラック)' : 'Active Intermodal Freight Shipments' }}
            </h3>
            <p class="text-xs text-slate-400">Real-time satellite GPS tracking with container temperature monitoring.</p>
          </div>

          <div class="flex items-center gap-2">
            <button 
              (click)="simulateDisruption()"
              class="px-3 py-1.5 rounded-lg bg-amber-700 hover:bg-amber-600 text-white font-bold text-xs font-mono tracking-wider flex items-center gap-1.5 shadow-lg shadow-amber-950">
              <mat-icon class="text-sm scale-75">thunderstorm</mat-icon> SIMULATE TYPHOON PORT DELAY (+12h)
            </button>
          </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (shipment of scService.activeShipments(); track shipment.id) {
            <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 flex flex-col justify-between space-y-3">
              <div>
                <div class="flex items-center justify-between">
                  <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-900 text-slate-300 border border-slate-700">
                    {{ shipment.transportMode }}
                  </span>
                  <span class="text-[10px] font-mono text-cyan-400">{{ shipment.id }}</span>
                </div>

                <h4 class="text-sm font-bold text-white mt-2">{{ shipment.carrierName }}</h4>
                <div class="text-xs text-slate-400 font-mono mt-0.5">Tracking: {{ shipment.trackingNumber }}</div>

                <div class="mt-3 space-y-1 text-xs font-mono text-slate-300">
                  <div>From: <strong class="text-white">{{ shipment.originHub }}</strong></div>
                  <div>To: <strong class="text-white">{{ shipment.destinationPlant }}</strong></div>
                  <div>Container Temp: <strong class="text-emerald-400">{{ shipment.containerTempCelsius }}°C</strong></div>
                  <div>Parts: 
                    <span class="text-slate-400 font-normal">
                      {{ shipment.partsCarried[0].partName }} ({{ shipment.partsCarried[0].quantity }} pcs)
                    </span>
                  </div>
                </div>
              </div>

              <div class="pt-3 border-t border-slate-800 text-xs font-mono space-y-1">
                <div class="flex items-center justify-between">
                  <span class="text-slate-400">Delay Status:</span>
                  <span [class.text-rose-400]="shipment.delayHours > 0" [class.text-emerald-400]="shipment.delayHours === 0" class="font-bold">
                    {{ shipment.delayHours > 0 ? '+' + shipment.delayHours + 'h delay' : 'ON SCHEDULE' }}
                  </span>
                </div>
                <div class="flex items-center justify-between text-[11px] text-slate-400">
                  <span>Calculated ETA:</span>
                  <span class="text-white">{{ shipment.realTimeCalculatedEta | date:'short' }}</span>
                </div>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Multi-Tier Supplier Scorecard & Quality Matrix -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-emerald-400">verified_user</mat-icon>
            {{ i18n.isJapanese() ? 'サプライヤー品質評価 & リスクスコアカード' : 'Multi-Tier Supplier Quality Scorecard & ESG Matrix' }}
          </h3>
          <span class="text-xs text-slate-400 font-mono">Zero Defect Defect-PPM Metric</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          @for (sup of scService.suppliers(); track sup.id) {
            <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div class="flex items-start justify-between">
                <div>
                  <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-900 text-slate-300 border border-slate-700">
                    {{ sup.tier }}
                  </span>
                  <h4 class="text-sm font-bold text-white mt-1.5">{{ sup.name }}</h4>
                  <div class="text-xs text-slate-400 font-mono">{{ sup.country }} · ID: {{ sup.id }}</div>
                </div>

                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                  [class.bg-emerald-950]="sup.riskStatus === 'LOW_RISK'"
                  [class.text-emerald-300]="sup.riskStatus === 'LOW_RISK'"
                  [class.border]="true"
                  [class.border-emerald-800]="sup.riskStatus === 'LOW_RISK'"
                  [class.bg-amber-950]="sup.riskStatus !== 'LOW_RISK'"
                  [class.text-amber-300]="sup.riskStatus !== 'LOW_RISK'"
                  [class.border-amber-800]="sup.riskStatus !== 'LOW_RISK'">
                  {{ sup.riskStatus }}
                </span>
              </div>

              <div class="grid grid-cols-2 gap-2 text-xs font-mono bg-slate-900 p-2.5 rounded border border-slate-800">
                <div>Quality: <strong class="text-emerald-400">{{ sup.qualityScorePpm }} PPM</strong></div>
                <div>On-Time: <strong class="text-cyan-400">{{ sup.onTimeDeliveryRatePct }}%</strong></div>
                <div class="col-span-2 text-slate-400 text-[11px]">ESG Rating: <strong class="text-white">{{ sup.sustainabilityRating }}</strong></div>
              </div>

              <div class="text-[11px] text-slate-400 truncate">
                Key Components: {{ sup.partsSupplied.join(', ') }}
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class SupplyChainTower {
  public scService = inject(SupplyChainService);
  public i18n = inject(I18nService);

  public simulateDisruption(): void {
    const firstShipment = this.scService.activeShipments()[0];
    if (firstShipment) {
      this.scService.simulatePortDisruption(firstShipment.id, 12);
    }
  }
}
