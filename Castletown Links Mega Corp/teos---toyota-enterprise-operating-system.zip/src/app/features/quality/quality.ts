import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { SpcQualityService } from '../../core/services/spc-quality.service';
import { I18nService } from '../../core/services/i18n.service';

@Component({
  selector: 'app-quality-safety',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-3">
            <mat-icon class="text-rose-400">verified</mat-icon>
            <div>
              <h2 class="text-xl font-bold text-white tracking-tight">
                {{ i18n.isJapanese() ? '統計的工程管理 (SPC) & ISO 26262 ASIL-D 安全保証' : 'Statistical Process Control (SPC) & ISO 26262 ASIL-D' }}
              </h2>
              <p class="text-xs text-slate-400 font-mono">
                X-BAR & R-CHARTS · CP/CPK PROCESS CAPABILITY · ASIL-D SAFETY CASES & HAZARD MITIGATION
              </p>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <span class="px-3 py-1 rounded text-xs font-mono bg-rose-950/80 border border-rose-800 text-rose-300">
            CPK = 1.94 (SIX SIGMA CAPABLE)
          </span>
        </div>
      </div>

      <!-- SPC Analysis Summary Ribbon -->
      @if (spcData(); as spc) {
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400">Process Mean (X-double-bar)</div>
            <div class="text-2xl font-bold text-white font-mono mt-1">{{ spc.processMean }} <span class="text-xs text-slate-400 font-normal">Nm</span></div>
            <div class="text-[11px] text-cyan-400 font-mono mt-1">Target: {{ spc.nominalTarget }} Nm</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400">Critical Capability (Cpk)</div>
            <div class="text-2xl font-bold text-emerald-400 font-mono mt-1">{{ spc.cpk }}</div>
            <div class="text-[11px] text-emerald-300 font-mono mt-1">> 1.67 Six Sigma Tier</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400">Potential Capability (Cp)</div>
            <div class="text-2xl font-bold text-indigo-300 font-mono mt-1">{{ spc.cp }}</div>
            <div class="text-[11px] text-slate-400 font-mono mt-1">Tolerance / (6 · σ)</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400">Upper Control Limit (UCL)</div>
            <div class="text-2xl font-bold text-amber-300 font-mono mt-1">{{ spc.uclMean }} <span class="text-xs text-slate-400 font-normal">Nm</span></div>
            <div class="text-[11px] text-slate-400 font-mono mt-1">USL: {{ spc.usl }} Nm</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400">Lower Control Limit (LCL)</div>
            <div class="text-2xl font-bold text-amber-300 font-mono mt-1">{{ spc.lclMean }} <span class="text-xs text-slate-400 font-normal">Nm</span></div>
            <div class="text-[11px] text-slate-400 font-mono mt-1">LSL: {{ spc.lsl }} Nm</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400">First Pass Yield (FPY)</div>
            <div class="text-2xl font-bold text-emerald-400 font-mono mt-1">{{ spc.firstPassYieldPct }}%</div>
            <div class="text-[11px] text-slate-400 font-mono mt-1">0 Defect Outliers</div>
          </div>
        </div>

        <!-- Interactive SPC X-Bar Chart Visualizer -->
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 class="text-base font-bold text-white flex items-center gap-2">
                <mat-icon class="text-cyan-400">show_chart</mat-icon>
                {{ spc.characteristicName }}
              </h3>
              <p class="text-xs text-slate-400">12 Continuous Subgroups (n=5 per batch) · Statistical Control Limits vs Engineering Specs</p>
            </div>
          </div>

          <!-- Discrete Subgroup Data Points -->
          <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-12 gap-2 mt-4 font-mono text-xs">
            @for (sample of spc.samples; track sample.sampleIndex) {
              <div class="p-2.5 rounded-lg bg-slate-950 border border-slate-800 flex flex-col justify-between">
                <div class="text-[10px] text-slate-400 flex justify-between">
                  <span>#{{ sample.sampleIndex }}</span>
                  <span class="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                </div>
                <div class="text-sm font-bold text-white mt-1">{{ sample.mean }} Nm</div>
                <div class="text-[10px] text-slate-400 mt-1 flex justify-between pt-1 border-t border-slate-900">
                  <span>R:</span>
                  <span class="text-cyan-400">{{ sample.range }}</span>
                </div>
              </div>
            }
          </div>
        </div>
      }

      <!-- ISO 26262 ASIL-D Functional Safety Cases Repository -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 class="text-base font-bold text-white flex items-center gap-2">
            <mat-icon class="text-rose-400">security</mat-icon>
            {{ i18n.isJapanese() ? 'ISO 26262 ASIL-D 機能安全ケース (Safety Case Repository)' : 'ISO 26262 ASIL-D Safety Case Repository' }}
          </h3>
          <span class="text-xs text-slate-400 font-mono">Formal Verification & HIL Fault Injection Evidence</span>
        </div>

        <div class="grid grid-cols-1 gap-4">
          @for (c of qualityService.safetyCases(); track c.id) {
            <div class="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-3">
              <div class="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <div class="flex items-center gap-2">
                    <span class="px-2 py-0.5 rounded text-xs font-mono font-bold"
                      [class.bg-rose-950]="c.assignedAsil === 'ASIL_D'"
                      [class.text-rose-300]="c.assignedAsil === 'ASIL_D'"
                      [class.border]="true"
                      [class.border-rose-800]="c.assignedAsil === 'ASIL_D'"
                      [class.bg-blue-950]="c.assignedAsil === 'ASIL_B'"
                      [class.text-blue-300]="c.assignedAsil === 'ASIL_B'"
                      [class.border-blue-800]="c.assignedAsil === 'ASIL_B'">
                      {{ c.assignedAsil }}
                    </span>
                    <span class="text-xs font-mono text-slate-400">{{ c.id }}</span>
                  </div>
                  <h4 class="text-sm font-bold text-white mt-1">{{ c.systemName }}</h4>
                </div>

                <span class="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                  {{ c.status }}
                </span>
              </div>

              <div class="text-xs text-slate-300">
                <strong class="text-rose-400">Hazard (HARA):</strong> {{ c.hazardDescription }}
              </div>

              <div class="text-xs text-slate-300 bg-slate-900 p-2.5 rounded border border-slate-800 space-y-1">
                <div class="text-emerald-400 font-semibold">{{ c.safetyGoal }}</div>
                <div class="text-slate-400 font-mono text-[11px]">Evidence: {{ c.verificationEvidence }}</div>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class QualitySafety {
  public qualityService = inject(SpcQualityService);
  public i18n = inject(I18nService);

  public spcData = signal(this.qualityService.getSampleData());
}
