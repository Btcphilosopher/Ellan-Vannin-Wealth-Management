import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { JitEngineService } from '../../core/services/jit-engine.service';
import { I18nService } from '../../core/services/i18n.service';
import { HeijunkaSlot, JITCalculationResult, KanbanCard } from '../../core/models/enterprise.model';

@Component({
  selector: 'app-jit-studio',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-3">
            <mat-icon class="text-cyan-400">sync_alt</mat-icon>
            <div>
              <h2 class="text-xl font-bold text-white tracking-tight">
                {{ i18n.isJapanese() ? 'ジャスト・イン・タイム (JIT) 計画 & 平準化エンジン' : 'Just-In-Time (JIT) Engine & Heijunka Leveling' }}
              </h2>
              <p class="text-xs text-slate-400 font-mono">
                DETERMINISTIC PULL PRODUCTION · KANBAN SIZING · MIXED-MODEL HEIJUNKA
              </p>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <span class="px-3 py-1 rounded text-xs font-mono bg-slate-950 border border-slate-800 text-slate-300">
            TAKT-ALIGNED PULL ARCHITECTURE
          </span>
        </div>
      </div>

      <!-- JIT Deterministic Calculator Form & Live Results -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Input Parameters Card (5 cols) -->
        <div class="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
          <h3 class="text-sm font-bold text-white mb-4 flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-sm">tune</mat-icon>
            {{ i18n.isJapanese() ? 'JIT 生産計画 パラメータ入力' : 'Deterministic JIT Planning Inputs' }}
          </h3>

          <form [formGroup]="jitForm" (ngSubmit)="calculate()" class="space-y-4">
            <div class="grid grid-cols-2 gap-3">
              <div>
                <label for="jitCustomerDemand" class="block text-[11px] font-mono text-slate-400 mb-1">Daily Demand (units)</label>
                <input id="jitCustomerDemand" formControlName="customerDailyDemand" type="number" class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none" />
              </div>
              <div>
                <label for="jitDailyOperating" class="block text-[11px] font-mono text-slate-400 mb-1">Operating Sec/Day</label>
                <input id="jitDailyOperating" formControlName="dailyOperatingSeconds" type="number" class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none" />
              </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label for="jitPlannedDowntime" class="block text-[11px] font-mono text-slate-400 mb-1">Planned Downtime (sec)</label>
                <input id="jitPlannedDowntime" formControlName="plannedDowntimeSeconds" type="number" class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none" />
              </div>
              <div>
                <label for="jitLeadTimeDays" class="block text-[11px] font-mono text-slate-400 mb-1">Supplier Lead Time (Days)</label>
                <input id="jitLeadTimeDays" formControlName="leadTimeDays" type="number" class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none" />
              </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label for="jitDemandVariance" class="block text-[11px] font-mono text-slate-400 mb-1">Demand Variance</label>
                <input id="jitDemandVariance" formControlName="demandVariance" type="number" class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none" />
              </div>
              <div>
                <label for="jitServiceLevelZ" class="block text-[11px] font-mono text-slate-400 mb-1">Service Level Z (99% = 2.33)</label>
                <input id="jitServiceLevelZ" formControlName="serviceLevelZScore" type="number" step="0.01" class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none" />
              </div>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label for="jitContainerCapacity" class="block text-[11px] font-mono text-slate-400 mb-1">Kanban Container Size</label>
                <input id="jitContainerCapacity" formControlName="containerCapacity" type="number" class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none" />
              </div>
              <div>
                <label for="jitLeadTimeVariance" class="block text-[11px] font-mono text-slate-400 mb-1">Lead Time Var (Days^2)</label>
                <input id="jitLeadTimeVariance" formControlName="leadTimeVariance" type="number" step="0.01" class="w-full bg-slate-950 border border-slate-800 rounded-lg px-3 py-1.5 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none" />
              </div>
            </div>

            <button type="submit" class="w-full py-2 px-4 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs font-mono tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-cyan-950">
              <mat-icon class="text-sm">calculate</mat-icon> RECOMPUTE JIT ENGINE
            </button>
          </form>
        </div>

        <!-- Output Metric Grid (7 cols) -->
        <div class="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <h3 class="text-sm font-bold text-white mb-4 flex items-center gap-2">
              <mat-icon class="text-emerald-400 text-sm">fact_check</mat-icon>
              {{ i18n.isJapanese() ? '計算結果 · タクトタイム & かんばん所要量' : 'Deterministic TPS Planning Outputs' }}
            </h3>

            @if (result(); as res) {
              <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
                <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
                  <div class="text-[10px] font-mono text-slate-400 uppercase">Takt Time (TT)</div>
                  <div class="text-2xl font-bold text-cyan-400 font-mono mt-1">{{ res.taktTimeSeconds }}s</div>
                  <div class="text-[10px] text-slate-400 mt-1">Operating Time / Demand</div>
                </div>

                <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
                  <div class="text-[10px] font-mono text-slate-400 uppercase">Safety Stock (SS)</div>
                  <div class="text-2xl font-bold text-emerald-400 font-mono mt-1">{{ res.safetyStockUnits }} <span class="text-xs text-slate-400">units</span></div>
                  <div class="text-[10px] text-slate-400 mt-1">Z · √(LT·VarD + D²·VarLT)</div>
                </div>

                <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
                  <div class="text-[10px] font-mono text-slate-400 uppercase">Reorder Point (ROP)</div>
                  <div class="text-2xl font-bold text-white font-mono mt-1">{{ res.reorderPointUnits }} <span class="text-xs text-slate-400">units</span></div>
                  <div class="text-[10px] text-slate-400 mt-1">LT Demand + Safety Stock</div>
                </div>

                <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
                  <div class="text-[10px] font-mono text-slate-400 uppercase">Kanban Cards Required</div>
                  <div class="text-2xl font-bold text-amber-400 font-mono mt-1">{{ res.recommendedKanbanCards }} <span class="text-xs text-slate-400">cards</span></div>
                  <div class="text-[10px] text-slate-400 mt-1">Ceil(ROP / Container Size)</div>
                </div>

                <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
                  <div class="text-[10px] font-mono text-slate-400 uppercase">Heijunka Pitch Interval</div>
                  <div class="text-2xl font-bold text-indigo-300 font-mono mt-1">{{ res.dailyHeijunkaPitchMinutes }}m</div>
                  <div class="text-[10px] text-slate-400 mt-1">Container Takt Window</div>
                </div>

                <div class="bg-slate-950 p-3.5 rounded-lg border border-slate-800">
                  <div class="text-[10px] font-mono text-slate-400 uppercase">Stockout Risk</div>
                  <div class="text-2xl font-bold text-emerald-300 font-mono mt-1">{{ res.shortageRiskPercentage }}%</div>
                  <div class="text-[10px] text-slate-400 mt-1">At 99% Target Service Level</div>
                </div>
              </div>
            }
          </div>

          <div class="mt-4 p-3 bg-slate-950/80 rounded-lg border border-slate-800 text-[11px] text-slate-400 font-mono">
            <strong>TPS Rule:</strong> "Produce only what is needed, when it is needed, and in the amount needed." No speculative inventory accumulation.
          </div>
        </div>
      </div>

      <!-- Leveled Heijunka Mixed-Model Production Sequence -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 class="text-sm font-bold text-white flex items-center gap-2">
              <mat-icon class="text-indigo-400 text-sm">view_timeline</mat-icon>
              {{ i18n.isJapanese() ? '平準化 (Heijunka) 混流生産シーケンスマトリックス' : 'Heijunka Leveled Mixed-Model Production Sequence' }}
            </h3>
            <p class="text-xs text-slate-400">Cyclic smoothing eliminates burden (Muri) and unevenness (Mura) on assembly stations.</p>
          </div>

          <div class="flex items-center gap-3 text-xs font-mono">
            <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-full bg-blue-600"></span> bZ4X (BEV)</span>
            <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-full bg-emerald-600"></span> Crown (HEV)</span>
            <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-full bg-purple-600"></span> Century (PHEV)</span>
            <span class="flex items-center gap-1"><span class="w-2.5 h-2.5 rounded-full bg-cyan-600"></span> Mirai (FCEV)</span>
          </div>
        </div>

        <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-3 mt-4">
          @for (slot of heijunkaSlots(); track slot.slotIndex) {
            <div class="p-2.5 rounded-lg border bg-slate-950 border-slate-800 text-xs font-mono">
              <div class="flex items-center justify-between text-[10px] text-slate-400">
                <span>#{{ slot.slotIndex }}</span>
                <span>{{ slot.timeWindow }}</span>
              </div>
              <div class="font-bold text-white truncate mt-1" [style.color]="slot.colorCode">{{ slot.vehicleModel }}</div>
              <div class="flex items-center justify-between mt-2 pt-1 border-t border-slate-800/80 text-[10px]">
                <span class="px-1.5 py-0.2 rounded bg-slate-900 border border-slate-700 text-slate-300">{{ slot.powertrain }}</span>
                <span [class.text-emerald-400]="slot.status === 'COMPLETED'" [class.text-amber-400]="slot.status === 'IN_PRODUCTION'" [class.text-slate-500]="slot.status === 'SCHEDULED'">
                  {{ slot.status }}
                </span>
              </div>
            </div>
          }
        </div>
      </div>

      <!-- Electronic Kanban Cards Active Pull Signals -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <h3 class="text-sm font-bold text-white flex items-center gap-2">
            <mat-icon class="text-amber-400 text-sm">qr_code_2</mat-icon>
            {{ i18n.isJapanese() ? 'アクティブ電子かんばん (e-Kanban) 引取・生産指示' : 'Active Electronic Kanban (e-Kanban) Signals' }}
          </h3>
          <span class="text-xs text-slate-400 font-mono">Automated AGV & Supermarket Pull</span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
          @for (card of kanbanCards(); track card.id) {
            <div class="p-4 rounded-lg bg-slate-950 border border-slate-800 hover:border-slate-700 transition-all flex flex-col justify-between">
              <div>
                <div class="flex items-center justify-between">
                  <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-900 text-slate-300 border border-slate-700">
                    {{ card.cardType }}
                  </span>
                  <span class="text-[10px] font-mono text-cyan-400">{{ card.id }}</span>
                </div>

                <h4 class="text-sm font-bold text-white mt-2">{{ card.partName }}</h4>
                <div class="text-xs text-slate-400 font-mono mt-0.5">Part: {{ card.partNumber }}</div>

                <div class="mt-3 space-y-1 text-xs font-mono text-slate-400">
                  <div>Supplier: <strong class="text-slate-200">{{ card.supplierName }}</strong></div>
                  <div>Dest: <strong class="text-slate-200">{{ card.destinationStation }}</strong></div>
                  <div>Qty / Bin: <strong class="text-amber-400">{{ card.quantityPerContainer }} units</strong></div>
                </div>
              </div>

              <div class="mt-4 pt-2 border-t border-slate-800 flex items-center justify-between">
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                  [class.bg-amber-950]="card.currentStatus === 'PULL_SIGNAL_EMITTED'"
                  [class.text-amber-300]="card.currentStatus === 'PULL_SIGNAL_EMITTED'"
                  [class.bg-cyan-950]="card.currentStatus === 'DISPATCHED_IN_TRANSIT'"
                  [class.text-cyan-300]="card.currentStatus === 'DISPATCHED_IN_TRANSIT'"
                  [class.bg-emerald-950]="card.currentStatus === 'DELIVERED_AT_LINE'"
                  [class.text-emerald-300]="card.currentStatus === 'DELIVERED_AT_LINE'"
                  [class.bg-rose-950]="card.currentStatus === 'STORE_EMPTY'"
                  [class.text-rose-300]="card.currentStatus === 'STORE_EMPTY'">
                  {{ card.currentStatus }}
                </span>
                <span class="text-[10px] text-slate-500 font-mono">{{ card.cycleTimeMinutes }}m cycle</span>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class JitStudio {
  private fb = inject(FormBuilder);
  public jitEngine = inject(JitEngineService);
  public i18n = inject(I18nService);

  public jitForm: FormGroup = this.fb.group({
    customerDailyDemand: [850, [Validators.required, Validators.min(1)]],
    dailyOperatingSeconds: [57600, [Validators.required, Validators.min(1)]],
    plannedDowntimeSeconds: [3600, [Validators.required, Validators.min(0)]],
    leadTimeDays: [3, [Validators.required, Validators.min(1)]],
    demandVariance: [120, [Validators.required]],
    serviceLevelZScore: [2.33, [Validators.required]],
    containerCapacity: [12, [Validators.required, Validators.min(1)]],
    leadTimeVariance: [0.2, [Validators.required]]
  });

  public result = signal<JITCalculationResult>(
    this.jitEngine.calculateJitParameters(this.jitForm.value)
  );

  public heijunkaSlots = signal<HeijunkaSlot[]>(
    this.jitEngine.generateHeijunkaSchedule(8, 10, 4, 2, 58.0)
  );

  public kanbanCards = signal<KanbanCard[]>(
    this.jitEngine.getInitialKanbanCards()
  );

  public calculate(): void {
    if (this.jitForm.valid) {
      const res = this.jitEngine.calculateJitParameters(this.jitForm.value);
      this.result.set(res);
      this.heijunkaSlots.set(
        this.jitEngine.generateHeijunkaSchedule(8, 10, 4, 2, res.taktTimeSeconds)
      );
    }
  }
}
