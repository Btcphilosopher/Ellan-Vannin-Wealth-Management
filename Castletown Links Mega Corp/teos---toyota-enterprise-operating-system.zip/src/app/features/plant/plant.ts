import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { PlantDigitalTwinService } from '../../core/services/plant-digital-twin.service';
import { JidokaAndonService } from '../../core/services/jidoka-andon.service';
import { I18nService } from '../../core/services/i18n.service';
import { PlantId, WorkStation } from '../../core/models/enterprise.model';

@Component({
  selector: 'app-plant-command',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header & Plant Selector -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-3">
            <mat-icon class="text-rose-500">precision_manufacturing</mat-icon>
            <div>
              <h2 class="text-xl font-bold text-white tracking-tight">
                {{ i18n.isJapanese() ? '工場ショップフロア・デジタルツイン' : 'Plant Shop Floor Digital Twin' }}
              </h2>
              <p class="text-xs text-slate-400 font-mono">
                REAL-TIME PLC / SCADA / SENSOR MESH TELEMETRY
              </p>
            </div>
          </div>
        </div>

        <div class="flex flex-wrap items-center gap-2">
          @for (plant of plantService.plants(); track plant.id) {
            <button
              (click)="selectPlant(plant.id)"
              [class.bg-rose-950]="selectedPlant().id === plant.id"
              [class.border-rose-700]="selectedPlant().id === plant.id"
              [class.text-rose-200]="selectedPlant().id === plant.id"
              [class.bg-slate-950]="selectedPlant().id !== plant.id"
              [class.border-slate-800]="selectedPlant().id !== plant.id"
              [class.text-slate-400]="selectedPlant().id !== plant.id"
              class="px-3 py-1.5 rounded-lg border text-xs font-mono font-medium hover:border-slate-600 transition-all flex items-center gap-1.5">
              <span class="w-1.5 h-1.5 rounded-full" [class.bg-emerald-400]="plant.operatingState === 'RUNNING'" [class.bg-rose-500]="plant.operatingState !== 'RUNNING'"></span>
              {{ plant.code }} ({{ plant.country }})
            </button>
          }
        </div>
      </div>

      <!-- Current Plant Metrics Ribbon -->
      @if (selectedPlant(); as curr) {
        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
          <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400">Current Operating State</div>
            <div class="text-lg font-bold font-mono mt-1" [class.text-emerald-400]="curr.operatingState === 'RUNNING'" [class.text-rose-400]="curr.operatingState !== 'RUNNING'">
              {{ curr.operatingState }}
            </div>
            <div class="text-[11px] text-slate-400 mt-1 font-mono">Shift: {{ curr.currentShift }}</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400">Takt Time (Actual / Target)</div>
            <div class="text-lg font-bold text-white font-mono mt-1">
              {{ curr.activeTaktSeconds }}s <span class="text-xs text-slate-400">/ {{ curr.targetTaktSeconds }}s</span>
            </div>
            <div class="text-[11px] text-emerald-400 mt-1 font-mono">Pace: 99.1%</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400">Daily Target</div>
            <div class="text-lg font-bold text-cyan-400 font-mono mt-1">{{ curr.dailyTargetVehicles }} veh</div>
            <div class="text-[11px] text-slate-400 mt-1 font-mono">Current output: 780 veh</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400">Overall Equipment Eff (OEE)</div>
            <div class="text-lg font-bold text-indigo-300 font-mono mt-1">{{ curr.oeePercentage }}%</div>
            <div class="text-[11px] text-slate-400 mt-1 font-mono">Availability: 98.4%</div>
          </div>

          <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
            <div class="text-xs text-slate-400">First Pass Yield (FPY)</div>
            <div class="text-lg font-bold text-emerald-300 font-mono mt-1">{{ curr.firstPassYieldPercentage }}%</div>
            <div class="text-[11px] text-slate-400 mt-1 font-mono">Defects: 12 PPM</div>
          </div>
        </div>

        <!-- Factory Floor Layout 2D Schematic -->
        <div class="bg-slate-900 border border-slate-800 rounded-xl p-6">
          <div class="flex items-center justify-between pb-4 border-b border-slate-800">
            <div>
              <h3 class="text-base font-bold text-white flex items-center gap-2">
                <mat-icon class="text-cyan-400">alt_route</mat-icon>
                {{ i18n.isJapanese() ? '工場ライン・ステーション構造 (2D デジタルツイン)' : 'Factory Production Lines & Workstation Mesh' }}
              </h3>
              <p class="text-xs text-slate-400 mt-0.5">Click any station to inspect machines, operators, and pull Andon cord.</p>
            </div>

            <div class="flex items-center gap-4 text-xs font-mono text-slate-400">
              <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-emerald-500"></span> Normal</div>
              <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-amber-500"></span> Warning</div>
              <div class="flex items-center gap-1.5"><span class="w-3 h-3 rounded bg-rose-600 animate-pulse"></span> Andon Stop</div>
            </div>
          </div>

          <!-- Lines & Stations Grid -->
          <div class="space-y-6 mt-6">
            @for (line of curr.lines; track line.id) {
              <div class="bg-slate-950 border border-slate-800 rounded-lg p-4">
                <div class="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-800/80">
                  <div class="flex items-center gap-3">
                    <span class="px-2 py-0.5 rounded text-xs font-mono font-bold bg-slate-800 text-slate-200 border border-slate-700">
                      {{ line.code }}
                    </span>
                    <div>
                      <h4 class="text-sm font-bold text-white">{{ line.name }}</h4>
                      <p class="text-xs text-slate-400">{{ line.japaneseName }} · Type: {{ line.type }}</p>
                    </div>
                  </div>

                  <div class="flex items-center gap-4 text-xs font-mono">
                    <span class="text-slate-400">Active Orders: <strong class="text-white">{{ line.activeOrderCount }}</strong></span>
                    <span class="text-slate-400">Pace: <strong class="text-cyan-400">{{ line.currentPaceSec }}s</strong> (Target: {{ line.targetPaceSec }}s)</span>
                    <span class="px-2.5 py-0.5 rounded-full font-bold"
                      [class.bg-emerald-950]="line.status === 'NORMAL'"
                      [class.text-emerald-300]="line.status === 'NORMAL'"
                      [class.border]="true"
                      [class.border-emerald-800]="line.status === 'NORMAL'"
                      [class.bg-rose-950]="line.status === 'STOPPED'"
                      [class.text-rose-300]="line.status === 'STOPPED'"
                      [class.border-rose-800]="line.status === 'STOPPED'">
                      {{ line.status }}
                    </span>
                  </div>
                </div>

                <!-- Conveyor Pacing & Station Nodes -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
                  @for (station of line.stations; track station.id) {
                    <div 
                      (click)="selectedStation.set(station)"
                      class="p-4 rounded-lg border transition-all cursor-pointer bg-slate-900/90"
                      [class.border-rose-600]="station.state === 'STOPPED'"
                      [class.shadow-rose-900]="station.state === 'STOPPED'"
                      [class.border-emerald-800]="station.state === 'NORMAL'"
                      [class.border-amber-600]="station.state === 'WARNING'"
                      [class.hover:border-slate-500]="true">
                      
                      <div class="flex items-start justify-between gap-2">
                        <span class="text-xs font-mono font-bold text-slate-400">ST. {{ station.sequenceNumber }}</span>
                        <span class="px-2 py-0.5 rounded text-[10px] font-mono font-semibold"
                          [class.bg-rose-950]="station.state === 'STOPPED'"
                          [class.text-rose-300]="station.state === 'STOPPED'"
                          [class.bg-emerald-950]="station.state === 'NORMAL'"
                          [class.text-emerald-300]="station.state === 'NORMAL'">
                          {{ station.state }}
                        </span>
                      </div>

                      <h5 class="text-sm font-bold text-white mt-1">{{ station.name }}</h5>
                      <p class="text-xs text-slate-400">{{ station.japaneseName }}</p>

                      <div class="mt-3 pt-2 border-t border-slate-800 grid grid-cols-2 gap-2 text-xs font-mono">
                        <div>
                          <span class="text-slate-400">Cycle Time:</span>
                          <div class="font-bold" [class.text-rose-400]="station.actualCycleSec > station.standardWorkCycleSec" [class.text-emerald-400]="station.actualCycleSec <= station.standardWorkCycleSec">
                            {{ station.actualCycleSec }}s <span class="text-slate-400 font-normal">/ {{ station.standardWorkCycleSec }}s</span>
                          </div>
                        </div>
                        <div>
                          <span class="text-slate-400">Kanban Bins:</span>
                          <div class="font-bold text-white">{{ station.kanbanBinCount }} <span class="text-slate-400 font-normal">(min {{ station.kanbanMinThreshold }})</span></div>
                        </div>
                      </div>

                      <div class="mt-2 text-[11px] text-slate-400 truncate">
                        👤 {{ station.assignedOperator.name }} ({{ station.assignedOperator.skillLevel }})
                      </div>
                    </div>
                  }
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Station Inspector Modal / Drawer -->
        @if (selectedStation(); as st) {
          <div class="bg-slate-900 border border-slate-700 rounded-xl p-6 shadow-2xl">
            <div class="flex items-center justify-between pb-4 border-b border-slate-800">
              <div class="flex items-center gap-3">
                <mat-icon class="text-cyan-400">build</mat-icon>
                <div>
                  <h3 class="text-base font-bold text-white">Workstation Diagnostic & Telemetry: {{ st.name }}</h3>
                  <p class="text-xs text-slate-400 font-mono">ID: {{ st.id }} · Japanese: {{ st.japaneseName }}</p>
                </div>
              </div>

              <button (click)="selectedStation.set(null)" class="text-slate-400 hover:text-white">
                <mat-icon>close</mat-icon>
              </button>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
              <!-- Operator Details -->
              <div class="bg-slate-950 p-4 rounded-lg border border-slate-800">
                <h4 class="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Assigned Operator</h4>
                <div class="text-sm font-bold text-white">{{ st.assignedOperator.name }} ({{ st.assignedOperator.japaneseName }})</div>
                <div class="text-xs text-cyan-400 font-mono mt-0.5">Qualification: {{ st.assignedOperator.skillLevel }}</div>
                <div class="mt-3 text-xs text-slate-400">
                  Certifications:
                  <ul class="list-disc list-inside mt-1 space-y-0.5 text-slate-300 font-mono text-[11px]">
                    @for (cert of st.assignedOperator.certifications; track cert) {
                      <li>{{ cert }}</li>
                    }
                  </ul>
                </div>
              </div>

              <!-- Machine / Tool Telemetry -->
              <div class="bg-slate-950 p-4 rounded-lg border border-slate-800">
                <h4 class="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Connected Equipment</h4>
                @for (m of st.machines; track m.id) {
                  <div class="space-y-1.5 text-xs">
                    <div class="font-bold text-white">{{ m.model }}</div>
                    <div class="text-slate-400 font-mono text-[11px]">S/N: {{ m.serialNumber }} ({{ m.manufacturer }})</div>
                    <div class="grid grid-cols-2 gap-2 pt-2 text-[11px] font-mono">
                      <div>Vibration: <strong class="text-amber-400">{{ m.vibrationMmPerSec }} mm/s</strong></div>
                      <div>Temp: <strong class="text-white">{{ m.temperatureCelsius }}°C</strong></div>
                      <div>MTBF: <strong class="text-emerald-400">{{ m.mtbfHours }}h</strong></div>
                      <div>MTTR: <strong class="text-slate-300">{{ m.mttrMinutes }}m</strong></div>
                    </div>
                  </div>
                }
              </div>

              <!-- Quick Action & Andon Pull -->
              <div class="bg-slate-950 p-4 rounded-lg border border-slate-800 flex flex-col justify-between">
                <div>
                  <h4 class="text-xs font-mono text-slate-400 uppercase tracking-wider mb-2">Poka-Yoke & Line Interlock</h4>
                  <p class="text-xs text-slate-300">Pulling the Andon cord immediately logs an auditable event and halts line movement at takt boundary.</p>
                </div>

                <div class="mt-4 flex gap-2">
                  <button 
                    (click)="pullCordForStation(st)"
                    class="w-full py-2.5 px-4 rounded-lg bg-rose-700 hover:bg-rose-600 text-white font-bold text-xs tracking-wider flex items-center justify-center gap-2 shadow-lg shadow-rose-950">
                    <mat-icon class="text-sm">alarm</mat-icon> PULL ANDON CORD
                  </button>
                </div>
              </div>
            </div>
          </div>
        }
      }
    </div>
  `
})
export class PlantCommand {
  public plantService = inject(PlantDigitalTwinService);
  public andonService = inject(JidokaAndonService);
  public i18n = inject(I18nService);

  public selectedPlant = signal(this.plantService.plants()[0]);
  public selectedStation = signal<WorkStation | null>(null);

  public selectPlant(id: PlantId): void {
    const p = this.plantService.plants().find(item => item.id === id);
    if (p) this.selectedPlant.set(p);
  }

  public pullCordForStation(station: WorkStation): void {
    this.andonService.pullAndonCord(
      station.id,
      station.name,
      'Tsutsumi Final Assembly Line',
      this.selectedPlant().id,
      'EQUIPMENT_BREAKDOWN',
      'RED_STOP_LINE',
      `Manual Andon pull at Station ${station.sequenceNumber} by operator ${station.assignedOperator.name}`
    );
  }
}
