import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { EventBusService } from '../../core/services/event-bus.service';
import { I18nService } from '../../core/services/i18n.service';
import { TeosAuditEvent } from '../../core/models/enterprise.model';

@Component({
  selector: 'app-audit-viewer',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-3">
            <mat-icon class="text-cyan-400">history_edu</mat-icon>
            <div>
              <h2 class="text-xl font-bold text-white tracking-tight">
                {{ i18n.isJapanese() ? 'イミュータブル監査ログ & イベントバス (Audit Ledger)' : 'Immutable Audit Ledger & Enterprise Event Bus' }}
              </h2>
              <p class="text-xs text-slate-400 font-mono">
                CRYPTOGRAPHIC SHA-256 EVENT STREAM · CORRELATION TRACING · TIME-TRAVEL REPLAY
              </p>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <span class="px-3 py-1 rounded text-xs font-mono bg-cyan-950/80 border border-cyan-800 text-cyan-300">
            CRYPTOGRAPHIC LEDGER ACTIVE
          </span>
        </div>
      </div>

      <!-- Event Stream & Payload Diagnostic Inspector -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Event Stream (6 cols) -->
        <div class="lg:col-span-6 space-y-4">
          <h3 class="text-sm font-bold text-white flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-sm">stream</mat-icon>
            {{ i18n.isJapanese() ? 'リアルタイム監査イベントストリーム' : 'Real-Time Event Stream' }}
          </h3>

          <div class="space-y-3">
            @for (ev of eventBus.eventStream(); track ev.eventId) {
              <button 
                type="button"
                (click)="selectedEvent.set(ev)"
                class="w-full text-left p-4 rounded-xl border transition-all cursor-pointer bg-slate-900/90 block"
                [class.border-cyan-500]="selectedEvent()?.eventId === ev.eventId"
                [class.border-slate-800]="selectedEvent()?.eventId !== ev.eventId">
                
                <div class="flex items-start justify-between">
                  <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700">
                    {{ ev.eventType }}
                  </span>
                  <span class="text-[10px] font-mono text-slate-400">{{ ev.timestampIso | date:'mediumTime' }}</span>
                </div>

                <div class="text-xs font-mono font-bold text-white mt-2">{{ ev.eventId }}</div>
                <div class="text-[11px] text-slate-300 mt-0.5">
                  Actor: {{ ev.actor.userId }} ({{ ev.actor.role }}) · {{ ev.actor.plantOrHub }}
                </div>

                <div class="mt-2 pt-2 border-t border-slate-800/80 flex items-center justify-between text-[10px] font-mono text-slate-400">
                  <span>Target: {{ ev.targetObjectType }}#{{ ev.targetObjectId }}</span>
                  <span class="text-cyan-400">Inspect Payload →</span>
                </div>
              </button>
            }
          </div>
        </div>

        <!-- Selected Event JSON Payload Inspector (6 cols) -->
        <div class="lg:col-span-6 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-4">
          @if (selectedEvent(); as e) {
            <div>
              <div class="flex items-start justify-between pb-3 border-b border-slate-800">
                <div>
                  <h3 class="text-base font-bold text-white font-mono">{{ e.eventId }}</h3>
                  <p class="text-xs text-slate-400 font-mono">Correlation ID: {{ e.correlationId }}</p>
                </div>
                <span class="px-2.5 py-1 rounded text-xs font-mono font-bold bg-slate-950 text-cyan-400 border border-slate-800">
                  {{ e.schemaVersion }}
                </span>
              </div>

              <!-- Cryptographic Hash -->
              <div class="mt-4 bg-slate-950 p-3 rounded-lg border border-slate-800 font-mono text-xs">
                <span class="text-slate-400 text-[10px] block">SHA-256 Cryptographic Checksum:</span>
                <span class="text-emerald-400 break-all text-[11px]">{{ e.cryptoChecksumSha256 }}</span>
              </div>

              <!-- Before / After State Delta -->
              <div class="mt-4 space-y-3 font-mono text-xs">
                <div>
                  <span class="text-rose-400 font-bold block mb-1">State Delta (Before):</span>
                  <pre class="bg-slate-950 p-3 rounded border border-slate-800 text-slate-300 text-[11px] overflow-x-auto">{{ e.stateDeltaBefore | json }}</pre>
                </div>

                <div>
                  <span class="text-emerald-400 font-bold block mb-1">State Delta (After):</span>
                  <pre class="bg-slate-950 p-3 rounded border border-slate-800 text-slate-300 text-[11px] overflow-x-auto">{{ e.stateDeltaAfter | json }}</pre>
                </div>
              </div>
            </div>
          } @else {
            <div class="p-12 text-center text-slate-500 font-mono text-xs">
              Select an event to view full JSON payload and cryptographic verification.
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class AuditViewer {
  public eventBus = inject(EventBusService);
  public i18n = inject(I18nService);

  public selectedEvent = signal<TeosAuditEvent | null>(this.eventBus.eventStream()[0] || null);
}
