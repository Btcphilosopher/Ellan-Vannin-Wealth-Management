import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { FinanceLedgerService } from '../../core/services/finance-ledger.service';
import { I18nService } from '../../core/services/i18n.service';

@Component({
  selector: 'app-finance-ledger',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-3">
            <mat-icon class="text-emerald-400">monetization_on</mat-icon>
            <div>
              <h2 class="text-xl font-bold text-white tracking-tight">
                {{ i18n.isJapanese() ? '財務管理 & 車両ユニット・エコノミクス (原価計算)' : 'Financial Ledger & Vehicle Unit Economics' }}
              </h2>
              <p class="text-xs text-slate-400 font-mono">
                ZERO FLOATING-POINT DRIFT · EXACT INTEGER CENTS FINANCIALS · COGS & MARGIN DECOMPOSITION
              </p>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <button 
            (click)="currencyMode.set(currencyMode() === 'USD' ? 'JPY' : 'USD')"
            class="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-700 text-xs font-mono font-bold text-white hover:border-slate-500 transition-all flex items-center gap-1.5">
            <mat-icon class="text-xs scale-75">currency_exchange</mat-icon>
            Currency: {{ currencyMode() }} (Toggle USD/JPY)
          </button>
        </div>
      </div>

      <!-- Financial Rule Banner -->
      <div class="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
        <mat-icon class="text-cyan-400">account_balance</mat-icon>
        <div class="text-xs text-slate-300">
          <strong>Enterprise Accounting Constraint:</strong> All ledger transactions and unit costs are calculated and stored in 64-bit integer cents to prevent IEEE-754 floating-point rounding inaccuracies.
        </div>
      </div>

      <!-- Vehicle Unit Economics Cards -->
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        @for (item of financeService.vehicleEconomics(); track item.vin) {
          <div class="p-6 rounded-xl bg-slate-900 border border-slate-800 space-y-4">
            <div class="flex items-start justify-between">
              <div>
                <span class="text-xs font-mono text-slate-400">VIN: {{ item.vin }}</span>
                <h3 class="text-base font-bold text-white mt-0.5">{{ item.modelName }}</h3>
              </div>

              <span class="px-3 py-1 rounded-full text-xs font-mono font-bold bg-emerald-950 text-emerald-300 border border-emerald-800">
                {{ item.grossMarginPercentage }}% Gross Margin
              </span>
            </div>

            <!-- Cost Decomposition Grid -->
            <div class="bg-slate-950 p-4 rounded-lg border border-slate-800 space-y-2.5 font-mono text-xs">
              <div class="flex justify-between text-slate-400">
                <span>MSRP / Target Retail:</span>
                <strong class="text-white">{{ formatMoney(item.msrpCents) }}</strong>
              </div>

              <div class="pt-2 border-t border-slate-800/80 space-y-1.5 text-[11px] text-slate-400">
                <div class="flex justify-between">
                  <span>- Direct Material Cost:</span>
                  <span class="text-slate-300">{{ formatMoney(item.directMaterialCostCents) }}</span>
                </div>
                <div class="flex justify-between">
                  <span>- Direct Labor Cost:</span>
                  <span class="text-slate-300">{{ formatMoney(item.directLaborCostCents) }}</span>
                </div>
                <div class="flex justify-between">
                  <span>- Manufacturing Overhead:</span>
                  <span class="text-slate-300">{{ formatMoney(item.manufacturingOverheadCents) }}</span>
                </div>
                <div class="flex justify-between">
                  <span>- Logistics & Delivery:</span>
                  <span class="text-slate-300">{{ formatMoney(item.logisticsDeliveryCostCents) }}</span>
                </div>
                <div class="flex justify-between">
                  <span>- Warranty Accrual:</span>
                  <span class="text-slate-300">{{ formatMoney(item.warrantyAccrualCents) }}</span>
                </div>
              </div>

              <div class="pt-2 border-t border-slate-800 flex justify-between text-slate-300 font-bold">
                <span>Total Cost of Goods Sold (COGS):</span>
                <span>{{ formatMoney(item.totalCostOfGoodsSoldCents) }}</span>
              </div>

              <div class="pt-2 border-t border-slate-800 flex justify-between text-emerald-400 font-bold text-sm">
                <span>Gross Margin / Unit Profit:</span>
                <span>{{ formatMoney(item.grossMarginCents) }}</span>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class FinanceLedger {
  public financeService = inject(FinanceLedgerService);
  public i18n = inject(I18nService);

  public currencyMode = signal<'USD' | 'JPY'>('USD');

  public formatMoney(cents: number): string {
    const locale = this.currencyMode() === 'JPY' ? 'ja-JP' : 'en-US';
    return this.financeService.formatCentsToCurrency(cents, locale);
  }
}
