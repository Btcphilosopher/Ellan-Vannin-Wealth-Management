import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { VehicleMspService } from '../../core/services/vehicle-msp.service';
import { I18nService } from '../../core/services/i18n.service';

@Component({
  selector: 'app-vehicle-twin',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-3">
            <mat-icon class="text-cyan-400">electric_car</mat-icon>
            <div>
              <h2 class="text-xl font-bold text-white tracking-tight">
                {{ i18n.isJapanese() ? 'ビークル & BMS バッテリーパック デジタルツイン' : 'Vehicle Dynamics & BMS Battery Pack Digital Twin' }}
              </h2>
              <p class="text-xs text-slate-400 font-mono">
                800V ARCHITECTURE · CELL VOLTAGE HARMONIZATION · REAL-TIME INVERTER TELEMETRY
              </p>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-3">
          <button 
            (click)="toggleDrivingSimulation()"
            class="px-4 py-2 rounded-lg font-bold text-xs font-mono tracking-wider flex items-center gap-2 shadow-lg transition-all"
            [class.bg-emerald-600]="isSimulating()"
            [class.hover:bg-emerald-500]="isSimulating()"
            [class.text-white]="true"
            [class.bg-slate-800]="!isSimulating()"
            [class.text-slate-300]="!isSimulating()">
            <mat-icon class="text-sm">{{ isSimulating() ? 'pause' : 'play_arrow' }}</mat-icon>
            {{ isSimulating() ? 'PAUSE TELEMETRY' : 'START SIMULATION' }}
          </button>
        </div>
      </div>

      <!-- Vehicle Dynamics Telemetry Ribbon -->
      <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div class="text-xs text-slate-400">Vehicle Speed</div>
          <div class="text-2xl font-bold text-white font-mono mt-1">
            {{ speedKmh() }} <span class="text-xs text-slate-400 font-normal">km/h</span>
          </div>
          <div class="text-[11px] text-cyan-400 font-mono mt-1">Wheel Slip: 0.1%</div>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div class="text-xs text-slate-400">Motor Torque Output</div>
          <div class="text-2xl font-bold text-cyan-400 font-mono mt-1">
            {{ motorTorqueNm() }} <span class="text-xs text-slate-400 font-normal">Nm</span>
          </div>
          <div class="text-[11px] text-slate-400 font-mono mt-1">e-Axle Dual Inverter</div>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div class="text-xs text-slate-400">Battery Pack SOC</div>
          <div class="text-2xl font-bold text-emerald-400 font-mono mt-1">
            {{ batterySoc() }}%
          </div>
          <div class="text-[11px] text-emerald-300 font-mono mt-1">State of Health: 99.2%</div>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div class="text-xs text-slate-400">HV Bus Voltage</div>
          <div class="text-2xl font-bold text-indigo-300 font-mono mt-1">
            792.4 <span class="text-xs text-slate-400 font-normal">V DC</span>
          </div>
          <div class="text-[11px] text-slate-400 font-mono mt-1">Nominal: 800V</div>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div class="text-xs text-slate-400">Max Cell Temp</div>
          <div class="text-2xl font-bold text-amber-300 font-mono mt-1">
            {{ maxCellTemp() }}°C
          </div>
          <div class="text-[11px] text-emerald-400 font-mono mt-1">Glycol Loop: 22.0°C</div>
        </div>

        <div class="bg-slate-900 border border-slate-800 rounded-lg p-4">
          <div class="text-xs text-slate-400">Regen Efficiency</div>
          <div class="text-2xl font-bold text-emerald-400 font-mono mt-1">
            89.4%
          </div>
          <div class="text-[11px] text-slate-400 font-mono mt-1">Kinetic Energy Recovery</div>
        </div>
      </div>

      <!-- Controls & Battery Cell Matrix -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Interactive Controls (5 cols) -->
        <div class="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg space-y-4">
          <h3 class="text-sm font-bold text-white flex items-center gap-2">
            <mat-icon class="text-cyan-400 text-sm">tune</mat-icon>
            {{ i18n.isJapanese() ? 'ビークル走行ダイナミクス・シミュレーター' : 'Vehicle Dynamics Live Controls' }}
          </h3>

          <div class="space-y-4 bg-slate-950 p-4 rounded-lg border border-slate-800">
            <div>
              <div class="flex justify-between text-xs font-mono text-slate-400 mb-1">
                <span>Throttle Pedal Input</span>
                <strong class="text-white">{{ throttle() }}%</strong>
              </div>
              <input 
                type="range" min="0" max="100" [value]="throttle()" 
                (input)="setThrottle($event)"
                class="w-full accent-cyan-500 cursor-pointer" />
            </div>

            <div>
              <div class="flex justify-between text-xs font-mono text-slate-400 mb-1">
                <span>Regenerative Brake Pressure</span>
                <strong class="text-white">{{ regenBrake() }}%</strong>
              </div>
              <input 
                type="range" min="0" max="100" [value]="regenBrake()" 
                (input)="setRegen($event)"
                class="w-full accent-emerald-500 cursor-pointer" />
            </div>

            <div>
              <div class="flex justify-between text-xs font-mono text-slate-400 mb-1">
                <span>Road Incline Grade</span>
                <strong class="text-white">{{ roadGrade() }}%</strong>
              </div>
              <input 
                type="range" min="-15" max="15" [value]="roadGrade()" 
                (input)="setGrade($event)"
                class="w-full accent-indigo-500 cursor-pointer" />
            </div>
          </div>

          <div class="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono text-slate-400">
            <strong>ASIL-D Interlock:</strong> Steer-by-wire and brake blending modules run on dual-lockstep cores with 20ms watchdog heartbeat.
          </div>
        </div>

        <!-- Individual 8-Cell Voltage & Thermal Matrix (7 cols) -->
        <div class="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-lg flex flex-col justify-between">
          <div>
            <div class="flex items-center justify-between pb-3 border-b border-slate-800">
              <h3 class="text-sm font-bold text-white flex items-center gap-2">
                <mat-icon class="text-emerald-400 text-sm">battery_charging_full</mat-icon>
                {{ i18n.isJapanese() ? 'セル電圧バランシング・サーマルマップ' : 'BMS Cell Balancing & Thermal Matrix' }}
              </h3>
              <span class="text-xs font-mono text-slate-400">Delta V: <strong class="text-emerald-400">0.008V (Balanced)</strong></span>
            </div>

            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
              @for (cell of cellVoltages(); track $index) {
                <div class="p-3 rounded-lg bg-slate-950 border border-slate-800 text-xs font-mono">
                  <div class="flex items-center justify-between text-[10px] text-slate-400">
                    <span>Cell #{{ $index + 1 }}</span>
                    <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
                  </div>
                  <div class="text-lg font-bold text-white mt-1">{{ cell.voltage.toFixed(3) }}V</div>
                  <div class="text-[10px] text-slate-400 mt-1 flex justify-between">
                    <span>Temp:</span>
                    <span class="text-amber-400">{{ cell.temp.toFixed(1) }}°C</span>
                  </div>
                </div>
              }
            </div>
          </div>

          <div class="mt-4 pt-3 border-t border-slate-800 flex items-center justify-between text-xs font-mono text-slate-400">
            <span>PPES Prismatic NMC High-Density Cells</span>
            <span class="text-emerald-400">Active Thermal Harmonization OK</span>
          </div>
        </div>
      </div>
    </div>
  `
})
export class VehicleTwin {
  public mspService = inject(VehicleMspService);
  public i18n = inject(I18nService);

  public isSimulating = signal(true);
  public speedKmh = signal(104.5);
  public motorTorqueNm = signal(340);
  public batterySoc = signal(78.4);
  public maxCellTemp = signal(28.6);
  public throttle = signal(45);
  public regenBrake = signal(0);
  public roadGrade = signal(2);

  public cellVoltages = signal([
    { voltage: 4.120, temp: 28.2 },
    { voltage: 4.122, temp: 28.5 },
    { voltage: 4.119, temp: 28.4 },
    { voltage: 4.124, temp: 28.6 },
    { voltage: 4.121, temp: 28.3 },
    { voltage: 4.118, temp: 28.1 },
    { voltage: 4.123, temp: 28.5 },
    { voltage: 4.120, temp: 28.2 }
  ]);

  public setThrottle(e: Event): void {
    const val = Number((e.target as HTMLInputElement).value);
    this.throttle.set(val);
    this.speedKmh.set(Number((val * 1.8).toFixed(1)));
    this.motorTorqueNm.set(Math.round(val * 7.2));
  }

  public setRegen(e: Event): void {
    const val = Number((e.target as HTMLInputElement).value);
    this.regenBrake.set(val);
  }

  public setGrade(e: Event): void {
    const val = Number((e.target as HTMLInputElement).value);
    this.roadGrade.set(val);
  }

  public toggleDrivingSimulation(): void {
    this.isSimulating.update(s => !s);
  }
}
