import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { KaizenCircleService } from '../../core/services/kaizen-circle.service';
import { I18nService } from '../../core/services/i18n.service';
import { KaizenProject, WasteCategory } from '../../core/models/enterprise.model';

@Component({
  selector: 'app-kaizen-workspace',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ReactiveFormsModule, MatIconModule],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl flex flex-wrap items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-3">
            <mat-icon class="text-emerald-400">trending_up</mat-icon>
            <div>
              <h2 class="text-xl font-bold text-white tracking-tight">
                {{ i18n.isJapanese() ? '改善 (Kaizen) ワークスペース & 5-Whys 原因分析' : 'Continuous Improvement (Kaizen) & 5-Whys Studio' }}
              </h2>
              <p class="text-xs text-slate-400 font-mono">
                8 WASTES (MUDA) ELIMINATION · KARAKURI MECHANISMS · STANDARDIZED WORK REVISION
              </p>
            </div>
          </div>
        </div>

        <div class="flex items-center gap-2">
          <span class="px-3 py-1 rounded text-xs font-mono bg-emerald-950/80 border border-emerald-800 text-emerald-300">
            TOTAL ANNUAL SAVINGS: $279,000 USD
          </span>
        </div>
      </div>

      <!-- 8 Wastes of Manufacturing (Muda) Taxonomy Grid -->
      <div class="bg-slate-900 border border-slate-800 rounded-xl p-5">
        <h3 class="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">
          The 8 Wastes of Manufacturing (ムダ - Muda Taxonomy)
        </h3>
        <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 text-center text-xs font-mono">
          <div class="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div class="font-bold text-rose-400">OVERPRODUCTION</div>
            <div class="text-[10px] text-slate-400 mt-0.5">造りすぎのムダ</div>
          </div>
          <div class="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div class="font-bold text-amber-400">WAITING</div>
            <div class="text-[10px] text-slate-400 mt-0.5">手待ちのムダ</div>
          </div>
          <div class="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div class="font-bold text-yellow-400">CONVEYANCE</div>
            <div class="text-[10px] text-slate-400 mt-0.5">運搬のムダ</div>
          </div>
          <div class="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div class="font-bold text-cyan-400">OVERPROCESSING</div>
            <div class="text-[10px] text-slate-400 mt-0.5">加工そのもののムダ</div>
          </div>
          <div class="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div class="font-bold text-blue-400">INVENTORY</div>
            <div class="text-[10px] text-slate-400 mt-0.5">在庫のムダ</div>
          </div>
          <div class="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div class="font-bold text-indigo-400">MOTION</div>
            <div class="text-[10px] text-slate-400 mt-0.5">動作のムダ</div>
          </div>
          <div class="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div class="font-bold text-rose-500">DEFECTS</div>
            <div class="text-[10px] text-slate-400 mt-0.5">不良を作るムダ</div>
          </div>
          <div class="p-2.5 rounded bg-slate-950 border border-slate-800">
            <div class="font-bold text-emerald-400">UNUSED TALENT</div>
            <div class="text-[10px] text-slate-400 mt-0.5">人材能力の未活用</div>
          </div>
        </div>
      </div>

      <!-- Kaizen Projects & 5-Whys Assistant -->
      <div class="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <!-- Project List (5 cols) -->
        <div class="lg:col-span-5 space-y-4">
          <h3 class="text-sm font-bold text-white flex items-center gap-2">
            <mat-icon class="text-emerald-400 text-sm">assignment</mat-icon>
            {{ i18n.isJapanese() ? '登録済み改善プロジェクト' : 'Active & Completed Kaizen Projects' }}
          </h3>

          @for (proj of kaizenService.projects(); track proj.id) {
            <div 
              (click)="selectedProject.set(proj)"
              class="p-4 rounded-xl border transition-all cursor-pointer bg-slate-900/90"
              [class.border-emerald-600]="selectedProject()?.id === proj.id"
              [class.border-slate-800]="selectedProject()?.id !== proj.id">
              
              <div class="flex items-start justify-between gap-2">
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-800 text-slate-300 border border-slate-700">
                  {{ proj.wasteTarget }}
                </span>
                <span class="px-2 py-0.5 rounded text-[10px] font-mono font-bold"
                  [class.bg-emerald-950]="proj.status === 'STANDARDIZED' || proj.status === 'DEPLOYED_GLOBAL'"
                  [class.text-emerald-300]="proj.status === 'STANDARDIZED' || proj.status === 'DEPLOYED_GLOBAL'"
                  [class.bg-cyan-950]="proj.status === 'EXPERIMENTATION'"
                  [class.text-cyan-300]="proj.status === 'EXPERIMENTATION'">
                  {{ proj.status }}
                </span>
              </div>

              <h4 class="text-sm font-bold text-white mt-2">{{ proj.title }}</h4>
              <p class="text-xs text-slate-400 font-mono mt-0.5">{{ proj.japaneseTitle }}</p>

              <div class="mt-3 pt-2 border-t border-slate-800 grid grid-cols-2 gap-2 text-xs font-mono">
                <div>
                  <span class="text-slate-400">Cycle Time:</span>
                  <div class="font-bold text-emerald-400">
                    {{ proj.beforeMetrics.cycleTimeSec }}s → {{ proj.afterMetrics.cycleTimeSec }}s ({{ (proj.beforeMetrics.cycleTimeSec - proj.afterMetrics.cycleTimeSec).toFixed(1) }}s saved)
                  </div>
                </div>
                <div>
                  <span class="text-slate-400">Annual Savings:</span>
                  <div class="font-bold text-white">\${{ (proj.validatedAnnualSavingsCents / 100000).toFixed(0) }}k USD</div>
                </div>
              </div>
            </div>
          }
        </div>

        <!-- 5-Whys Diagnostic Studio & AI Assistant (7 cols) -->
        <div class="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-xl p-6 shadow-xl space-y-6">
          @if (selectedProject(); as p) {
            <div>
              <div class="flex items-start justify-between pb-3 border-b border-slate-800">
                <div>
                  <span class="text-xs font-mono text-slate-400">{{ p.id }} · {{ p.code }}</span>
                  <h3 class="text-lg font-bold text-white mt-1">{{ p.title }}</h3>
                  <p class="text-xs text-slate-400 font-mono">{{ p.japaneseTitle }} · Plant: {{ p.plantId }}</p>
                </div>
                <div class="text-right">
                  <div class="text-[10px] font-mono text-slate-400 uppercase">Author / Circle</div>
                  <div class="text-xs font-bold text-white font-mono mt-0.5">{{ p.author }}</div>
                </div>
              </div>

              <!-- Problem & Countermeasure -->
              <div class="mt-4 space-y-3">
                <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs">
                  <span class="font-bold text-rose-400 font-mono">Problem Statement:</span>
                  <p class="text-slate-200 mt-1">{{ p.problemStatement }}</p>
                </div>

                <!-- 5-Whys Cascade -->
                <div class="bg-slate-950 p-4 rounded-lg border border-slate-800">
                  <h4 class="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3">
                    5-Whys (なぜなぜ分析) Root Cause Chain
                  </h4>
                  <div class="space-y-2 font-mono text-xs">
                    @for (w of p.whys; track $index) {
                      <div class="flex items-start gap-2 p-2 rounded bg-slate-900 border border-slate-800">
                        <span class="px-1.5 py-0.5 rounded text-[10px] font-bold bg-cyan-950 text-cyan-300 border border-cyan-800 shrink-0">
                          Why #{{ $index + 1 }}
                        </span>
                        <div class="text-slate-200 text-[11px] leading-relaxed">{{ w }}</div>
                      </div>
                    }
                  </div>
                </div>

                <div class="bg-slate-950 p-3 rounded-lg border border-slate-800 text-xs">
                  <span class="font-bold text-emerald-400 font-mono">Implemented Countermeasure (Poka-Yoke / Karakuri):</span>
                  <p class="text-slate-200 mt-1">{{ p.countermeasure }}</p>
                  <p class="text-slate-400 text-[11px] mt-1 font-mono">Approval: {{ p.ringiApprovedBy || 'Pending' }}</p>
                </div>
              </div>
            </div>
          }

          <!-- Interactive AI Kaizen 5-Whys Assistant -->
          <div class="pt-4 border-t border-slate-800">
            <h4 class="text-xs font-mono text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <mat-icon class="text-cyan-400 text-sm">auto_awesome</mat-icon>
              Interactive AI Kaizen Generator
            </h4>

            <div class="space-y-3 bg-slate-950 p-4 rounded-lg border border-slate-800">
              <div>
                <label class="block text-xs text-slate-300 mb-1">Observed Manufacturing Abnormality / Waste:</label>
                <input 
                  #abnormalityInput
                  type="text" 
                  value="High voltage harness routing connector locking tab flexes during insertion, causing intermittent continuity error."
                  class="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white font-mono focus:border-cyan-500 focus:outline-none" />
              </div>

              <div class="flex justify-end">
                <button 
                  (click)="generateAiKaizen(abnormalityInput.value)"
                  class="py-2 px-4 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs font-mono tracking-wider flex items-center gap-2 shadow-lg shadow-indigo-950">
                  <mat-icon class="text-sm">auto_awesome</mat-icon> GENERATE 5-WHYS & KARAKURI PROPOSAL
                </button>
              </div>

              @if (aiGeneratedResult(); as ai) {
                <div class="mt-4 p-3 rounded bg-slate-900 border border-slate-800 space-y-2 text-xs font-mono">
                  <div class="text-emerald-400 font-bold">Recommended Countermeasure:</div>
                  <div class="text-slate-200">{{ ai.suggestedCountermeasure }}</div>
                  <div class="text-slate-400 text-[11px]">Expected Cycle Time Savings: {{ ai.expectedCycleTimeReductionSec }}s · Annual Impact: \${{ ai.expectedAnnualSavingsUsd }} USD</div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class KaizenWorkspace {
  public kaizenService = inject(KaizenCircleService);
  public i18n = inject(I18nService);

  public selectedProject = signal<KaizenProject | null>(this.kaizenService.projects()[0] || null);
  public aiGeneratedResult = signal<{ suggestedCountermeasure: string; expectedCycleTimeReductionSec: number; expectedAnnualSavingsUsd: number } | null>(null);

  public generateAiKaizen(problem: string): void {
    this.aiGeneratedResult.set({
      suggestedCountermeasure: 'Fabricate gravity-fed karakuri guide jig with physical keyway to guarantee zero-angle deflection during harness terminal mating.',
      expectedCycleTimeReductionSec: 2.8,
      expectedAnnualSavingsUsd: 42000
    });
  }
}
