import { ChangeDetectionStrategy, Component, inject, signal, OnInit, OnDestroy } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { I18nService } from './core/services/i18n.service';
import { JidokaAndonService } from './core/services/jidoka-andon.service';
import { SupportedLocale } from './core/i18n/teos-i18n';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive, MatIconModule],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit, OnDestroy {
  public i18n = inject(I18nService);
  public andonService = inject(JidokaAndonService);

  public sidebarCollapsed = signal(false);
  public currentTimeJst = signal<string>('');
  private timer: ReturnType<typeof setInterval> | null = null;

  public navItems = [
    { path: '/executive', icon: 'dashboard', labelEn: 'Executive Command', labelJp: '役員統括司令室', subEn: 'Global Ops' },
    { path: '/plant', icon: 'precision_manufacturing', labelEn: 'Plant Digital Twin', labelJp: '工場ツイン', subEn: '2D Shop Floor' },
    { path: '/jit', icon: 'sync_alt', labelEn: 'JIT & Heijunka', labelJp: 'JIT計画・平準化', subEn: 'Pull Production' },
    { path: '/andon', icon: 'warning', labelEn: 'Jidoka & Andon', labelJp: '自働化・行灯', subEn: 'Interlock 9-Stage' },
    { path: '/kaizen', icon: 'trending_up', labelEn: 'Kaizen 5-Whys', labelJp: '改善・なぜなぜ分析', subEn: '8 Wastes Muda' },
    { path: '/msp', icon: 'directions_car', labelEn: 'MSP-OS Studio', labelJp: 'MSP基盤・Arene', subEn: 'SDV Architecture' },
    { path: '/twin', icon: 'electric_car', labelEn: 'Vehicle & BMS Twin', labelJp: '車両・電池ツイン', subEn: '800V & Thermal' },
    { path: '/supply-chain', icon: 'local_shipping', labelEn: 'Supply Chain Tower', labelJp: '物流統括管制', subEn: 'Intermodal Logistics' },
    { path: '/quality', icon: 'verified', labelEn: 'Quality & ASIL-D', labelJp: '品質SPC・ASIL-D', subEn: 'ISO 26262' },
    { path: '/finance', icon: 'monetization_on', labelEn: 'Financial Ledger', labelJp: '財務・原価計算', subEn: 'Exact Cents' },
    { path: '/ringi', icon: 'approval', labelEn: 'Ringi Workflow', labelJp: '電子稟議・決裁', subEn: 'Hanko Seals' },
    { path: '/audit', icon: 'history_edu', labelEn: 'Audit Ledger', labelJp: '監査イベントバス', subEn: 'SHA-256 Ledger' },
    { path: '/blueprint', icon: 'architecture', labelEn: 'Architecture & Tests', labelJp: '仕様書・テスト', subEn: 'OpenAPI & Rust' },
  ];

  ngOnInit(): void {
    this.updateClock();
    if (typeof window !== 'undefined') {
      this.timer = setInterval(() => this.updateClock(), 1000);
    }
  }

  ngOnDestroy(): void {
    if (this.timer) clearInterval(this.timer);
  }

  public updateClock(): void {
    const now = new Date();
    this.currentTimeJst.set(
      now.toLocaleTimeString('en-US', { timeZone: 'Asia/Tokyo', hour12: false }) + ' JST'
    );
  }

  public setLocale(locale: SupportedLocale): void {
    this.i18n.setLocale(locale);
  }

  public toggleSidebar(): void {
    this.sidebarCollapsed.update(v => !v);
  }
}

