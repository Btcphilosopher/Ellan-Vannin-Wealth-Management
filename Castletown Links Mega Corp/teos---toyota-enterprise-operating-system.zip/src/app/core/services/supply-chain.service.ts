import { Injectable, signal } from '@angular/core';
import { IntermodalShipment, SupplierProfile } from '../models/enterprise.model';

@Injectable({
  providedIn: 'root'
})
export class SupplyChainService {
  public suppliers = signal<SupplierProfile[]>([
    {
      id: 'SUP-DENSO-01',
      name: 'Denso Corporation (Anjo & Daian Plants)',
      country: 'Japan',
      tier: 'TIER_1_SYSTEM',
      partsSupplied: ['e-Axle Inverters', 'Radar Sensors', 'Air Conditioning Compressors', 'Fuel Injection Systems'],
      qualityScorePpm: 2.1,
      onTimeDeliveryRatePct: 99.8,
      sustainabilityRating: 'A_CARBON_NEUTRAL',
      riskStatus: 'LOW_RISK'
    },
    {
      id: 'SUP-PPES-02',
      name: 'Prime Planet Energy & Solutions (Himeji)',
      country: 'Japan',
      tier: 'TIER_1_SYSTEM',
      partsSupplied: ['Prismatic NMC High-Density Cells', 'Solid-State Battery Test Modules'],
      qualityScorePpm: 4.8,
      onTimeDeliveryRatePct: 99.4,
      sustainabilityRating: 'A_CARBON_NEUTRAL',
      riskStatus: 'LOW_RISK'
    },
    {
      id: 'SUP-AISIN-03',
      name: 'Aisin Corporation (Kariya & Anjo)',
      country: 'Japan',
      tier: 'TIER_1_SYSTEM',
      partsSupplied: ['Multi-Mode Transaxles', 'Brake Systems', 'Door Lock Actuators'],
      qualityScorePpm: 5.5,
      onTimeDeliveryRatePct: 99.1,
      sustainabilityRating: 'B_TRANSITIONING',
      riskStatus: 'LOW_RISK'
    },
    {
      id: 'SUP-TOYODA-GOSEI-04',
      name: 'Toyoda Gosei Co., Ltd. (Kiyosu)',
      country: 'Japan',
      tier: 'TIER_2_COMPONENT',
      partsSupplied: ['Hydrogen High-Pressure Tanks (70MPa)', 'LED Radiator Emblems', 'Airbag Modules'],
      qualityScorePpm: 6.2,
      onTimeDeliveryRatePct: 98.7,
      sustainabilityRating: 'B_TRANSITIONING',
      riskStatus: 'LOW_RISK'
    },
    {
      id: 'SUP-TSMC-05',
      name: 'TSMC / JASM (Kumamoto Fab 1)',
      country: 'Japan / Taiwan',
      tier: 'TIER_3_RAW_MATERIAL',
      partsSupplied: ['16nm & 28nm Automotive Microcontrollers', 'MSP High-Compute SoC Wafers'],
      qualityScorePpm: 0.8,
      onTimeDeliveryRatePct: 99.9,
      sustainabilityRating: 'A_CARBON_NEUTRAL',
      riskStatus: 'LOW_RISK'
    },
    {
      id: 'SUP-PACIFIC-TRANS-06',
      name: 'Pacific Intermodal Freight Lines',
      country: 'Global Logistics',
      tier: 'TIER_1_SYSTEM',
      partsSupplied: ['International Maritime RoRo & Containerized Intermodal Transit'],
      qualityScorePpm: 12.0,
      onTimeDeliveryRatePct: 94.2,
      sustainabilityRating: 'B_TRANSITIONING',
      riskStatus: 'MODERATE_WEATHER'
    }
  ]);

  public activeShipments = signal<IntermodalShipment[]>([
    {
      id: 'SHIP-MAR-2026-881',
      trackingNumber: 'NYK-RORO-TOYOTA-PACIFIC-09',
      originHub: 'Nagoya Port (Port of Nagoya, Aichi)',
      destinationPlant: 'PLANT-GEORGETOWN',
      transportMode: 'MARITIME_VESSEL',
      carrierName: 'Ocean Network Express (ONE) Maritime Carrier',
      partsCarried: [
        { partNumber: '74120-TY-902', partName: 'e-Axle 150kW Front Inverter', quantity: 2400 },
        { partNumber: '89661-TY-GW02', partName: 'Central Gateway ECU modules', quantity: 4800 }
      ],
      departureTime: new Date(Date.now() - 6 * 86400000).toISOString(),
      plannedEta: new Date(Date.now() + 4 * 86400000).toISOString(),
      realTimeCalculatedEta: new Date(Date.now() + 4.5 * 86400000).toISOString(),
      delayHours: 12.0,
      latitude: 33.42,
      longitude: -142.15,
      containerTempCelsius: 19.5,
      status: 'IN_TRANSIT'
    },
    {
      id: 'SHIP-RAIL-2026-442',
      trackingNumber: 'JR-FREIGHT-CONTAINER-119',
      originHub: 'Himeji Battery Megafactory (PPES)',
      destinationPlant: 'PLANT-TSUTSUMI',
      transportMode: 'FREIGHT_RAIL',
      carrierName: 'Japan Freight Railway Company (JR貨物)',
      partsCarried: [
        { partNumber: '58200-TY-310', partName: 'Prismatic NMC Battery Module', quantity: 960 }
      ],
      departureTime: new Date(Date.now() - 8 * 3600000).toISOString(),
      plannedEta: new Date(Date.now() + 3 * 3600000).toISOString(),
      realTimeCalculatedEta: new Date(Date.now() + 3 * 3600000).toISOString(),
      delayHours: 0.0,
      latitude: 34.82,
      longitude: 136.22,
      containerTempCelsius: 21.0,
      status: 'IN_TRANSIT'
    },
    {
      id: 'SHIP-TRK-2026-904',
      trackingNumber: 'TOYOTA-TSUSHO-LOG-78',
      originHub: 'Kariya Logistics Distribution Hub',
      destinationPlant: 'PLANT-MOTOMACHI',
      transportMode: 'HEAVY_TRUCK',
      carrierName: 'Toyota Tsusho Logistics Fleet (Mirai FCEV Heavy Truck)',
      partsCarried: [
        { partNumber: '43512-TY-108', partName: 'High-Carbon Ventilated Brake Rotor', quantity: 480 }
      ],
      departureTime: new Date(Date.now() - 45 * 60000).toISOString(),
      plannedEta: new Date(Date.now() + 15 * 60000).toISOString(),
      realTimeCalculatedEta: new Date(Date.now() + 15 * 60000).toISOString(),
      delayHours: 0.0,
      latitude: 35.03,
      longitude: 137.08,
      containerTempCelsius: 22.1,
      status: 'IN_TRANSIT'
    }
  ]);

  public simulatePortDisruption(shipmentId: string, addedHours: number): void {
    this.activeShipments.update(shipments =>
      shipments.map(s => {
        if (s.id === shipmentId) {
          const newDelay = s.delayHours + addedHours;
          const newEta = new Date(new Date(s.plannedEta).getTime() + newDelay * 3600000).toISOString();
          return {
            ...s,
            delayHours: newDelay,
            realTimeCalculatedEta: newEta,
            status: 'CUSTOMS_CLEARANCE'
          };
        }
        return s;
      })
    );
  }
}
