import { Injectable, signal, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { KaizenProject, WasteCategory } from '../models/enterprise.model';

@Injectable({
  providedIn: 'root'
})
export class KaizenService {
  private http = inject(HttpClient);

  public projects = signal<KaizenProject[]>([
    {
      id: 'KZ-2026-081',
      code: 'KAIZEN-TSUT-081',
      title: 'Robotic Weld Gun Cable Dress Optimization to Prevent Torsional Fatigue',
      japaneseTitle: 'ロボット溶接ガンのケーブル配線最適化による捻り疲労低減',
      plantId: 'PLANT-TSUTSUMI',
      lineId: 'LINE-TSUT-BODY-01',
      wasteTarget: 'WAITING',
      author: 'Mamoru Endo (遠藤 守) - Plant Maintenance Eng',
      status: 'STANDARDIZED',
      problemStatement: 'Robotic welding cell R-04 experienced recurring intermittent umbilical harness breaks, causing 42 min line downtime per month.',
      whys: [
        'Why did line stop? -> Robot R-04 weld gun signal cable broke during cycle.',
        'Why did cable break? -> Excessive torsional strain occurred at J6 wrist articulation axis.',
        'Why was strain excessive? -> Guide clamp bracket was mounted in rigid orientation.',
        'Why was bracket rigid? -> Standard supplier mounting fixture lacked swivel articulation.',
        'Why lacked swivel articulation? -> Initial robot installation did not specify dynamic 3D articulation dress pack.'
      ],
      countermeasure: 'Designed custom lightweight swivel articulated harness bracket with Teflon sleeve. Installed across all 18 body welding robots.',
      beforeMetrics: {
        cycleTimeSec: 54.2,
        defectPpm: 120,
        downtimeMinutesMonthly: 42,
        kwhPerVehicle: 14.8,
        inventoryHoldingCents: 45000000
      },
      afterMetrics: {
        cycleTimeSec: 51.0,
        defectPpm: 25,
        downtimeMinutesMonthly: 0,
        kwhPerVehicle: 13.9,
        inventoryHoldingCents: 45000000
      },
      validatedAnnualSavingsCents: 18400000, // $184,000 / ¥27.6M
      createdAt: '2026-06-15T09:00:00Z',
      ringiApprovedBy: 'Sato General Manager (佐保 部長)'
    },
    {
      id: 'KZ-2026-092',
      code: 'KAIZEN-MOTO-092',
      title: 'Gravity Feed Roller Chute for Battery Module Cell Placement',
      japaneseTitle: '重力式シュートによる電池モジュール供給のからくり改善 (Karakuri)',
      plantId: 'PLANT-MOTOMACHI',
      lineId: 'LINE-MOTO-BAT-01',
      wasteTarget: 'MOTION',
      author: 'Kenta Nishimura (西村 健太) - Cell Team Leader',
      status: 'DEPLOYED_GLOBAL',
      problemStatement: 'Operators had to bend and rotate 180 degrees 340 times per shift to lift 4.2kg battery cell packs from lower pallet.',
      whys: [
        'Why excessive operator fatigue? -> Operator bent torso >45 degrees repeatedly.',
        'Why bending? -> Cell storage rack shelf was positioned 40cm below waist height.',
        'Why below waist height? -> Pallet unloader placed bulk crates directly on ground.',
        'Why on ground? -> No mechanical staging lifter or unpowered feeder existed.',
        'Why no unpowered feeder? -> Process initially assumed motorized lifter was needed and cost-prohibitive.'
      ],
      countermeasure: 'Built Karakuri mechanical counterweight slope chute utilizing weight of incoming empty tray to raise next full tray to waist level without electricity.',
      beforeMetrics: {
        cycleTimeSec: 38.5,
        defectPpm: 80,
        downtimeMinutesMonthly: 15,
        kwhPerVehicle: 8.4,
        inventoryHoldingCents: 22000000
      },
      afterMetrics: {
        cycleTimeSec: 29.2,
        defectPpm: 8,
        downtimeMinutesMonthly: 2,
        kwhPerVehicle: 7.9,
        inventoryHoldingCents: 18000000
      },
      validatedAnnualSavingsCents: 32500000,
      createdAt: '2026-07-20T11:30:00Z',
      ringiApprovedBy: 'Yamada VP Manufacturing'
    },
    {
      id: 'KZ-2026-104',
      code: 'KAIZEN-GEO-104',
      title: 'Digital Poka-Yoke Optical Sensor for EV High Voltage Interlock Connectors',
      japaneseTitle: 'EV高電圧コネクタ嵌合確認ポカヨケ光電センサ導入',
      plantId: 'PLANT-GEORGETOWN',
      lineId: 'LINE-GEO-ASM-02',
      wasteTarget: 'DEFECTS',
      author: 'David Miller - Quality Specialist',
      status: 'EXPERIMENTATION',
      problemStatement: 'Potential risk of terminal secondary lock not fully clicked, detectable only at end-of-line electrical verification.',
      whys: [
        'Why risk of incomplete lock? -> Locking click tactile feedback can be muffled in noisy shop floor.',
        'Why reliance on tactile? -> Operator inspects visually with flashlight.',
        'Why visual with flashlight? -> Connector housing recessed inside firewall tunnel.',
        'Why recessed? -> Packaging constraint in cabin HVAC bulkhead.',
        'Why no automated interlock? -> Line workstation lacked inline vision verification sensor.'
      ],
      countermeasure: 'Integrated micro-laser triangulation sensor on torque gun that confirms secondary locking tab engagement before pneumatic release.',
      beforeMetrics: {
        cycleTimeSec: 44.0,
        defectPpm: 450,
        downtimeMinutesMonthly: 30,
        kwhPerVehicle: 11.2,
        inventoryHoldingCents: 15000000
      },
      afterMetrics: {
        cycleTimeSec: 41.5,
        defectPpm: 0,
        downtimeMinutesMonthly: 0,
        kwhPerVehicle: 11.2,
        inventoryHoldingCents: 15000000
      },
      validatedAnnualSavingsCents: 24000000,
      createdAt: '2026-08-10T14:15:00Z'
    }
  ]);

  public addKaizenProject(project: KaizenProject): void {
    this.projects.update(list => [project, ...list]);
  }

  /**
   * AI-powered Kaizen analysis engine.
   * Calls server-side Gemini API route `/api/ai/kaizen-analyze` with fallback.
   */
  public async analyzeProblemWithAi(problemDescription: string, wasteType: WasteCategory): Promise<{
    rootCauses5Whys: string[];
    suggestedCountermeasure: string;
    expectedCycleTimeReductionSec: number;
    expectedAnnualSavingsUsd: number;
    confidenceScore: number;
  }> {
    try {
      const response = await fetch('/api/ai/kaizen-analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ problemDescription, wasteType })
      });
      if (response.ok) {
        const data = await response.json();
        return data;
      }
    } catch {
      // Fallback heuristics if offline
    }

    return {
      rootCauses5Whys: [
        `1. Why did the issue occur? -> Operational bottleneck in the ${wasteType.toLowerCase()} process.`,
        `2. Why was there a bottleneck? -> Inconsistent part staging or cycle variation at the station.`,
        `3. Why inconsistent? -> Standard work combination chart lacked micro-motion standardization.`,
        `4. Why lacked standardization? -> Tooling orientation required operator repositioning.`,
        `5. Why orientation required repositioning? -> Fixture was not engineered with Poka-Yoke (mistake-proofing) alignment.`
      ],
      suggestedCountermeasure: `Implement mechanical Poka-Yoke gravity guide and revise Standard Work Combination Sheet to eliminate ${wasteType.toLowerCase()} motion.`,
      expectedCycleTimeReductionSec: 4.8,
      expectedAnnualSavingsUsd: 48000,
      confidenceScore: 0.92
    };
  }
}
