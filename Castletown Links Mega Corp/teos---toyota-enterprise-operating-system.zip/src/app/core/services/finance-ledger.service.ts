import { Injectable, signal } from '@angular/core';
import { VehicleUnitEconomics } from '../models/enterprise.model';

@Injectable({
  providedIn: 'root'
})
export class FinanceLedgerService {
  /**
   * Enterprise Unit Economics stored in exact integer cents to eliminate floating-point rounding errors.
   * $1.00 = 100 cents.
   */
  public vehicleEconomics = signal<VehicleUnitEconomics[]>([
    {
      vin: 'JTDKN36U0R2098411',
      modelName: 'bZ4X SDV Prime Limited (BEV)',
      msrpCents: 4850000, // $48,500.00
      directMaterialCostCents: 2680000, // $26,800.00 (Includes 90kWh Battery Pack $9,200)
      directLaborCostCents: 340000, // $3,400.00
      manufacturingOverheadCents: 410000, // $4,100.00 (Energy, tooling depreciation)
      logisticsDeliveryCostCents: 125000, // $1,250.00
      warrantyAccrualCents: 85000, // $850.00
      totalCostOfGoodsSoldCents: 3640000, // $36,400.00
      grossMarginCents: 1210000, // $12,100.00
      grossMarginPercentage: 24.95
    },
    {
      vin: 'JTEBU49J6R1054920',
      modelName: 'Crown Crossover RS Advanced (HEV)',
      msrpCents: 5200000, // $52,000.00
      directMaterialCostCents: 2540000, // $25,400.00
      directLaborCostCents: 380000, // $3,800.00
      manufacturingOverheadCents: 420000, // $4,200.00
      logisticsDeliveryCostCents: 110000, // $1,100.00
      warrantyAccrualCents: 70000, // $700.00
      totalCostOfGoodsSoldCents: 3520000, // $35,200.00
      grossMarginCents: 1680000, // $16,800.00
      grossMarginPercentage: 32.31
    },
    {
      vin: 'JTMAB33V2R9012488',
      modelName: 'Century SUV GR Edition (PHEV)',
      msrpCents: 17000000, // $170,000.00
      directMaterialCostCents: 6200000, // $62,000.00 (Handcrafted craftsmanship, carbon trim)
      directLaborCostCents: 1850000, // $18,500.00 (Takumi master craftsmen assembly)
      manufacturingOverheadCents: 1200000, // $12,000.00
      logisticsDeliveryCostCents: 280000, // $2,800.00
      warrantyAccrualCents: 250000, // $2,500.00
      totalCostOfGoodsSoldCents: 9780000, // $97,800.00
      grossMarginCents: 7220000, // $72,200.00
      grossMarginPercentage: 42.47
    },
    {
      vin: 'JTDKB20U5R7033912',
      modelName: 'Mirai Hydrogen FCEV Premium',
      msrpCents: 6700000, // $67,000.00
      directMaterialCostCents: 4200000, // $42,000.00 (70MPa Type-IV carbon tanks & platinum catalyst stack)
      directLaborCostCents: 520000, // $5,200.00
      manufacturingOverheadCents: 680000, // $6,800.00
      logisticsDeliveryCostCents: 140000, // $1,400.00
      warrantyAccrualCents: 180000, // $1,800.00
      totalCostOfGoodsSoldCents: 5720000, // $57,200.00
      grossMarginCents: 980000, // $9,800.00
      grossMarginPercentage: 14.63
    }
  ]);

  public formatCentsToCurrency(cents: number, locale = 'en-US'): string {
    const dollars = cents / 100;
    if (locale === 'ja-JP') {
      // 1 USD approx 150 JPY for display
      const yen = Math.round(dollars * 150);
      return new Intl.NumberFormat('ja-JP', { style: 'currency', currency: 'JPY', maximumFractionDigits: 0 }).format(yen);
    }
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', minimumFractionDigits: 2 }).format(dollars);
  }
}
