import { Injectable } from '@angular/core';
import { HeijunkaSlot, JITCalculationInput, JITCalculationResult, KanbanCard } from '../models/enterprise.model';

@Injectable({
  providedIn: 'root'
})
export class JitEngineService {
  /**
   * Deterministic TPS / JIT calculation algorithm based on standard manufacturing equations.
   * No approximations or random placeholders.
   */
  public calculateJitParameters(input: JITCalculationInput): JITCalculationResult {
    const netOperatingSeconds = Math.max(1, input.dailyOperatingSeconds - input.plannedDowntimeSeconds);
    const demand = Math.max(1, input.customerDailyDemand);

    // 1. Takt Time = Net Available Time / Customer Demand
    const taktTimeSeconds = Number((netOperatingSeconds / demand).toFixed(2));

    // 2. Lead Time Demand (DLT) = Daily Demand * Lead Time in Days
    const leadTimeDemand = Math.round(demand * input.leadTimeDays);

    // 3. Safety Stock = Z * sqrt( (LT * Var(Demand)) + (Demand^2 * Var(LT)) )
    const varianceTerm = (input.leadTimeDays * input.demandVariance) + 
                         (Math.pow(demand, 2) * input.leadTimeVariance);
    const safetyStockUnits = Math.ceil(input.serviceLevelZScore * Math.sqrt(Math.max(0, varianceTerm)));

    // 4. Reorder Point (ROP) = Lead Time Demand + Safety Stock
    const reorderPointUnits = leadTimeDemand + safetyStockUnits;

    // 5. Kanban Card Quantity = ceil( (Lead Time Demand + Safety Stock) / Container Capacity )
    const containerCap = Math.max(1, input.containerCapacity);
    const recommendedKanbanCards = Math.ceil((leadTimeDemand + safetyStockUnits) / containerCap);

    // 6. Daily Heijunka Pitch (in minutes) = (Takt Time in Seconds * Container Size) / 60
    const dailyHeijunkaPitchMinutes = Number(((taktTimeSeconds * containerCap) / 60).toFixed(2));

    // 7. Shortage & Excess Risk percentage heuristics
    const bufferRatio = safetyStockUnits / Math.max(1, leadTimeDemand);
    const shortageRiskPercentage = Number(Math.max(1, Math.min(99, (1 - Math.min(1, bufferRatio)) * 100 * (1 / input.serviceLevelZScore))).toFixed(1));
    const excessInventoryRiskPercentage = Number(Math.max(1, Math.min(99, (bufferRatio > 0.4 ? (bufferRatio - 0.4) * 120 : 5))).toFixed(1));

    return {
      taktTimeSeconds,
      leadTimeDemand,
      safetyStockUnits,
      reorderPointUnits,
      recommendedKanbanCards,
      dailyHeijunkaPitchMinutes,
      shortageRiskPercentage,
      excessInventoryRiskPercentage
    };
  }

  /**
   * Generates a leveled Heijunka production sequence pattern for a mixed-model assembly line.
   * Follows Toyota's mixed-model smoothing principle (e.g. BEV, HEV, PHEV, FCEV).
   */
  public generateHeijunkaSchedule(
    bevCount: number,
    hevCount: number,
    phevCount: number,
    fcevCount: number,
    taktSeconds: number
  ): HeijunkaSlot[] {
    const total = bevCount + hevCount + phevCount + fcevCount;
    if (total === 0) return [];

    const models: { type: 'BEV' | 'HEV' | 'PHEV' | 'FCEV'; count: number; name: string; color: string }[] = [
      { type: 'BEV', count: bevCount, name: 'bZ4X SDV Prime', color: '#2563eb' },
      { type: 'HEV', count: hevCount, name: 'Crown Crossover HEV', color: '#10b981' },
      { type: 'PHEV', count: phevCount, name: 'Century SUV PHEV', color: '#8b5cf6' },
      { type: 'FCEV', count: fcevCount, name: 'Mirai Hydrogen FCEV', color: '#06b6d4' }
    ];

    const slots: HeijunkaSlot[] = [];
    const counts = { BEV: bevCount, HEV: hevCount, PHEV: phevCount, FCEV: fcevCount };
    
    // Distribute via smooth cyclic modulo pacing
    let startMinute = 8 * 60; // 08:00 AM

    for (let i = 0; i < Math.min(24, total); i++) {
      // Pick available model with highest remaining proportion
      let chosenType: 'BEV' | 'HEV' | 'PHEV' | 'FCEV' = 'HEV';
      let maxRatio = -1;

      for (const m of models) {
        const ratio = counts[m.type] / Math.max(1, total);
        if (counts[m.type] > 0 && ratio > maxRatio) {
          maxRatio = ratio;
          chosenType = m.type;
        }
      }

      counts[chosenType]--;
      const modelMeta = models.find(m => m.type === chosenType)!;
      
      const hours = Math.floor(startMinute / 60).toString().padStart(2, '0');
      const mins = (startMinute % 60).toString().padStart(2, '0');
      const timeWindow = `${hours}:${mins}`;
      startMinute += Math.round(taktSeconds / 60);

      slots.push({
        slotIndex: i + 1,
        timeWindow,
        vehicleModel: modelMeta.name,
        powertrain: chosenType,
        colorCode: modelMeta.color,
        targetSequence: `SEQ-${(i + 1).toString().padStart(4, '0')}`,
        lineTaktTargetSec: taktSeconds,
        status: i < 3 ? 'COMPLETED' : i === 3 ? 'IN_PRODUCTION' : 'SCHEDULED'
      });
    }

    return slots;
  }

  /**
   * Generates active electronic Kanban signals for line stations.
   */
  public getInitialKanbanCards(): KanbanCard[] {
    return [
      {
        id: 'KB-88210-A',
        cardType: 'PRODUCTION_KANBAN',
        partNumber: '74120-TY-902',
        partName: 'e-Axle 150kW Front Drive Inverter',
        supplierName: 'Denso Corp (Anjo Plant)',
        sourceLocation: 'Supermarket A-04',
        destinationStation: 'Tsutsumi Final Line 1, St. 14',
        quantityPerContainer: 8,
        cycleTimeMinutes: 28,
        currentStatus: 'PULL_SIGNAL_EMITTED',
        timestampGenerated: new Date(Date.now() - 12 * 60000).toISOString(),
        qrPayload: 'TEOS:KB:74120-TY-902:8:ST14:DENSO'
      },
      {
        id: 'KB-88211-B',
        cardType: 'WITHDRAWAL_KANBAN',
        partNumber: '58200-TY-310',
        partName: 'Prismatic NMC Battery Module Gen-4',
        supplierName: 'Prime Planet Energy & Solutions',
        sourceLocation: 'Battery Cell Supermarket B-02',
        destinationStation: 'Motomachi Battery Pack Line, St. 06',
        quantityPerContainer: 12,
        cycleTimeMinutes: 45,
        currentStatus: 'DISPATCHED_IN_TRANSIT',
        timestampGenerated: new Date(Date.now() - 24 * 60000).toISOString(),
        qrPayload: 'TEOS:KB:58200-TY-310:12:ST06:PPES'
      },
      {
        id: 'KB-88212-C',
        cardType: 'SUPPLIER_CALLOFF_KANBAN',
        partNumber: '43512-TY-108',
        partName: 'High-Carbon Ventilated Brake Rotor',
        supplierName: 'Advics Co., Ltd.',
        sourceLocation: 'Kariya Logistics Centre',
        destinationStation: 'Tahara Chassis Line, St. 22',
        quantityPerContainer: 24,
        cycleTimeMinutes: 60,
        currentStatus: 'DELIVERED_AT_LINE',
        timestampGenerated: new Date(Date.now() - 50 * 60000).toISOString(),
        qrPayload: 'TEOS:KB:43512-TY-108:24:ST22:ADVICS'
      },
      {
        id: 'KB-88213-D',
        cardType: 'PRODUCTION_KANBAN',
        partNumber: '89661-TY-SDV',
        partName: 'Central Gateway ECU (MSP Gen-2)',
        supplierName: 'Toyota Tsusho Electronics',
        sourceLocation: 'Electronics Clean Store C-01',
        destinationStation: 'Georgetown Assembly Line 2, St. 31',
        quantityPerContainer: 16,
        cycleTimeMinutes: 30,
        currentStatus: 'STORE_EMPTY',
        timestampGenerated: new Date(Date.now() - 3 * 60000).toISOString(),
        qrPayload: 'TEOS:KB:89661-TY-SDV:16:ST31:TTEC'
      }
    ];
  }
}
