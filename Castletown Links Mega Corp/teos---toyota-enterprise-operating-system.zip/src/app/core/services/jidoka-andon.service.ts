import { Injectable, signal, computed } from '@angular/core';
import { AndonCategory, AndonEvent, AndonSeverity, PlantId } from '../models/enterprise.model';

@Injectable({
  providedIn: 'root'
})
export class JidokaAndonService {
  public activeEvents = signal<AndonEvent[]>([
    {
      id: 'ANDON-2026-0912-01',
      stationId: 'ST-TSUT-ASM-14',
      stationName: 'Station 14: e-Axle Sub-assembly & Torque Fix',
      lineName: 'Tsutsumi Final Assembly Line #1',
      plantId: 'PLANT-TSUTSUMI',
      operatorName: 'Kenji Sato (佐藤 健二) - Lead Tech',
      severity: 'RED_STOP_LINE',
      category: 'EQUIPMENT_BREAKDOWN',
      problemDescription: 'Automated Nutrunner Tool #3 torque sensor calibration drift (+4.8 Nm above specification threshold). Line interlock engaged.',
      raisedAt: new Date(Date.now() - 8 * 60000).toISOString(),
      escalationStage: 6, // INVESTIGATE
      assignedLeader: 'Takeshi Yamada (山田 武) - Team Leader',
      investigationNote: 'Laser sensor confirms transducer impedance variance. Replacement tool module dispatched from toolroom.',
      downtimeSeconds: 480
    },
    {
      id: 'ANDON-2026-0912-02',
      stationId: 'ST-MOTO-BAT-06',
      stationName: 'Station 06: High Voltage Busbar Laser Weld',
      lineName: 'Motomachi Battery Pack Line #2',
      plantId: 'PLANT-MOTOMACHI',
      operatorName: 'Yuki Tanaka (田中 由紀) - Senior Specialist',
      severity: 'YELLOW_WARNING',
      category: 'QUALITY_DEFECT',
      problemDescription: 'Vision inspection camera flagged micro-porosity at cell #18 tab weld. Pre-stop yellow alert.',
      raisedAt: new Date(Date.now() - 15 * 60000).toISOString(),
      escalationStage: 4, // STOP/CONTINUE decision
      assignedLeader: 'Hiroshi Kato (加藤 博) - Quality Eng',
      investigationNote: 'Manual microscopic re-inspection in progress. No line stop required if within tolerance.',
      downtimeSeconds: 0
    },
    {
      id: 'ANDON-2026-0912-03',
      stationId: 'ST-GEO-CHAS-22',
      stationName: 'Station 22: Rear Multi-Link Subframe Decking',
      lineName: 'Georgetown Line 2 Assembly',
      plantId: 'PLANT-GEORGETOWN',
      operatorName: 'Marcus Vance - Assembly Tech',
      severity: 'YELLOW_WARNING',
      category: 'CYCLE_OVERRUN',
      problemDescription: 'Wiring harness clip routing exceeded cycle takt time by 12 seconds on 3 consecutive cycles.',
      raisedAt: new Date(Date.now() - 32 * 60000).toISOString(),
      escalationStage: 7, // CORRECT
      assignedLeader: 'Sarah Jenkins - Group Leader',
      investigationNote: 'Clip tray repositioned 15cm closer to operator reach zone. Standard work chart updated.',
      countermeasureTaken: 'Standard work sheet revision #4 applied.',
      downtimeSeconds: 36
    }
  ]);

  public activeStopCount = computed(() => 
    this.activeEvents().filter(e => e.severity === 'RED_STOP_LINE' && e.escalationStage < 9).length
  );

  public totalDowntimeSeconds = computed(() =>
    this.activeEvents().reduce((acc, curr) => acc + (curr.downtimeSeconds || 0), 0)
  );

  public getStageName(stage: number): { en: string; ja: string } {
    switch (stage) {
      case 1: return { en: '1. SIGNAL (Signal Triggered)', ja: '1. 信号発報' };
      case 2: return { en: '2. DETECT (Abnormality Detected)', ja: '2. 異常検知' };
      case 3: return { en: '3. CLASSIFY (Category Classified)', ja: '3. 要因分類' };
      case 4: return { en: '4. STOP/CONTINUE (Line Interlock)', ja: '4. 停止判定' };
      case 5: return { en: '5. ESCALATE (Leader Dispatched)', ja: '5. 監督者呼出' };
      case 6: return { en: '6. INVESTIGATE (Genchi Genbutsu)', ja: '6. 現地現物調査' };
      case 7: return { en: '7. CORRECT (Countermeasure Applied)', ja: '7. 処置実行' };
      case 8: return { en: '8. VERIFY (Quality Assurance)', ja: '8. 品質確認' };
      case 9: return { en: '9. RELEASE (Line Resumed)', ja: '9. 運転再開' };
      default: return { en: 'Unknown Stage', ja: '未定義' };
    }
  }

  public pullAndonCord(
    stationId: string,
    stationName: string,
    lineName: string,
    plantId: PlantId,
    category: AndonCategory,
    severity: AndonSeverity,
    problemDescription: string,
    operatorName = 'Assembly Technician'
  ): AndonEvent {
    const newEvent: AndonEvent = {
      id: `ANDON-${new Date().getFullYear()}-${Date.now().toString().slice(-6)}`,
      stationId,
      stationName,
      lineName,
      plantId,
      operatorName,
      severity,
      category,
      problemDescription,
      raisedAt: new Date().toISOString(),
      escalationStage: severity === 'RED_STOP_LINE' ? 4 : 2,
      assignedLeader: 'Line Leader on Duty',
      downtimeSeconds: 0
    };

    this.activeEvents.update(events => [newEvent, ...events]);
    return newEvent;
  }

  public advanceEscalationStage(eventId: string, note?: string): void {
    this.advanceWorkflow(eventId, note);
  }

  public advanceWorkflow(eventId: string, note?: string): void {
    this.activeEvents.update(events =>
      events.map(ev => {
        if (ev.id === eventId) {
          const nextStage = Math.min(9, ev.escalationStage + 1) as AndonEvent['escalationStage'];
          return {
            ...ev,
            escalationStage: nextStage,
            investigationNote: note ? note : ev.investigationNote,
            resolvedAt: nextStage === 9 ? new Date().toISOString() : undefined
          };
        }
        return ev;
      })
    );
  }

  public resolveAndon(eventId: string, countermeasure: string): void {
    this.activeEvents.update(events =>
      events.map(ev => {
        if (ev.id === eventId) {
          return {
            ...ev,
            escalationStage: 9,
            countermeasureTaken: countermeasure,
            resolvedAt: new Date().toISOString()
          };
        }
        return ev;
      })
    );
  }
}

