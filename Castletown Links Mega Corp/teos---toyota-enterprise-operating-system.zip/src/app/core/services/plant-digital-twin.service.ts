import { Injectable, signal } from '@angular/core';
import { PlantId, ProductionPlant } from '../models/enterprise.model';

@Injectable({
  providedIn: 'root'
})
export class PlantDigitalTwinService {
  public selectedPlantId = signal<PlantId>('PLANT-TSUTSUMI');

  public plants = signal<ProductionPlant[]>([
    {
      id: 'PLANT-TSUTSUMI',
      code: 'TY-JPN-TSU',
      name: 'Tsutsumi Assembly Plant (Toyota City, Aichi)',
      japaneseName: '堤工場（愛知県豊田市）',
      region: 'REGION-JP',
      country: 'Japan',
      locationCoordinates: [35.051, 137.135],
      dailyTargetVehicles: 1250,
      currentShift: 'SHIFT-1-DAY',
      operatingState: 'RUNNING',
      activeTaktSeconds: 58.5,
      targetTaktSeconds: 58.0,
      oeePercentage: 92.4,
      firstPassYieldPercentage: 98.8,
      lines: [
        {
          id: 'LINE-TSU-STAMP-01',
          plantId: 'PLANT-TSUTSUMI',
          code: 'STAMP-L1',
          name: 'High-Speed Servo Stamping Line #1',
          japaneseName: '高速サーボプレス第1ライン',
          type: 'STAMPING',
          status: 'NORMAL',
          activeOrderCount: 420,
          currentPaceSec: 4.2,
          targetPaceSec: 4.0,
          pitchMarkIndex: 12,
          andonActive: false,
          stations: [
            {
              id: 'ST-TSU-STAMP-01',
              lineId: 'LINE-TSU-STAMP-01',
              sequenceNumber: 1,
              name: 'Coil Blanking & Auto-Destacker',
              japaneseName: 'コイルブランキング・自動デスタッカー',
              standardWorkCycleSec: 4.0,
              actualCycleSec: 4.1,
              assignedOperator: { employeeId: 'EMP-STAMP-01', name: 'Kazuo Mori', japaneseName: '森 一夫', skillLevel: 'LEVEL_4_TRAINER', certifications: ['ISO-9001-STAMP', 'DIE-MAINT-G1'], shiftAssigned: 'SHIFT-1' },
              machines: [
                { id: 'M-PRESS-3500T', serialNumber: 'KOMATSU-H2-3500T-08', manufacturer: 'Komatsu Press Machinery', model: 'Servo Press H2-3500T', category: 'PRESS_MACHINE', status: 'OPTIMAL', operatingHours: 14200, mtbfHours: 720, mttrMinutes: 18, lastServiceDate: '2026-08-20', vibrationMmPerSec: 1.2, temperatureCelsius: 42.0, firmwareVersion: 'v8.4.1' }
              ],
              state: 'NORMAL',
              kanbanBinCount: 14,
              kanbanMinThreshold: 4
            }
          ]
        },
        {
          id: 'LINE-TSU-WELD-01',
          plantId: 'PLANT-TSUTSUMI',
          code: 'BODY-L1',
          name: 'Flexible Body Welding & Framing Line (TNGA-K)',
          japaneseName: 'ボディ溶接・総組第1ライン',
          type: 'BODY_WELDING',
          status: 'NORMAL',
          activeOrderCount: 280,
          currentPaceSec: 57.8,
          targetPaceSec: 58.0,
          pitchMarkIndex: 8,
          andonActive: false,
          stations: [
            {
              id: 'ST-TSU-WELD-04',
              lineId: 'LINE-TSU-WELD-01',
              sequenceNumber: 4,
              name: 'Underbody Main Subframe Robotic Spot Weld',
              japaneseName: 'アンダーボディ主骨格スポット溶接',
              standardWorkCycleSec: 58.0,
              actualCycleSec: 57.5,
              assignedOperator: { employeeId: 'EMP-WELD-09', name: 'Shinji Ota', japaneseName: '太田 慎司', skillLevel: 'LEVEL_3_ADVANCED', certifications: ['JIS-WELD-SPECIAL', 'ROBOTICS-TEACHING'], shiftAssigned: 'SHIFT-1' },
              machines: [
                { id: 'ROBOT-FANUC-R04', serialNumber: 'FANUC-M900IB-700-112', manufacturer: 'FANUC Corporation', model: 'M-900iB/700 Fast-Servo', category: 'WELDING_ROBOT', status: 'OPTIMAL', operatingHours: 8900, mtbfHours: 940, mttrMinutes: 12, lastServiceDate: '2026-09-01', vibrationMmPerSec: 0.8, temperatureCelsius: 38.4, firmwareVersion: 'v12.2.0' }
              ],
              state: 'NORMAL',
              kanbanBinCount: 8,
              kanbanMinThreshold: 2
            }
          ]
        },
        {
          id: 'LINE-TSU-ASM-01',
          plantId: 'PLANT-TSUTSUMI',
          code: 'ASM-L1',
          name: 'Crown / Prius Final Assembly Trim & Chassis Line',
          japaneseName: 'クラウン・プリウス最終組立ライン',
          type: 'FINAL_ASSEMBLY',
          status: 'STOPPED',
          activeOrderCount: 310,
          currentPaceSec: 62.4,
          targetPaceSec: 58.0,
          pitchMarkIndex: 14,
          andonActive: true,
          activeAndonReason: 'Station 14: Nutrunner torque sensor drift (+4.8 Nm). Line interlock engaged.',
          stations: [
            {
              id: 'ST-TSUT-ASM-14',
              lineId: 'LINE-TSU-ASM-01',
              sequenceNumber: 14,
              name: 'e-Axle Sub-assembly & High-Voltage Bolting',
              japaneseName: 'e-Axle締結・高電圧配線結合',
              standardWorkCycleSec: 58.0,
              actualCycleSec: 64.8,
              assignedOperator: { employeeId: 'EMP-SATO-881', name: 'Kenji Sato', japaneseName: '佐藤 健二', skillLevel: 'LEVEL_4_TRAINER', certifications: ['TOYOTA-TAKUMI-GRADE1', 'HV-SAFETY-CERT'], shiftAssigned: 'SHIFT-1' },
              machines: [
                { id: 'TOOL-NUTRUNNER-03', serialNumber: 'ATLAS-COPCO-PF6000-881', manufacturer: 'Atlas Copco / Yokota', model: 'Power Focus 6000 Multi-Torque', category: 'TORQUE_TOOL', status: 'ALARM', operatingHours: 4200, mtbfHours: 480, mttrMinutes: 25, lastServiceDate: '2026-08-15', vibrationMmPerSec: 2.8, temperatureCelsius: 51.2, firmwareVersion: 'v4.1.9' }
              ],
              currentVehicleVin: 'JTEBU49J6R1054920',
              state: 'STOPPED',
              kanbanBinCount: 2,
              kanbanMinThreshold: 3
            },
            {
              id: 'ST-TSUT-ASM-15',
              lineId: 'LINE-TSU-ASM-01',
              sequenceNumber: 15,
              name: 'Cockpit Module & HUD Dashboard Insertion',
              japaneseName: 'インストルメントパネル・HUD搭載',
              standardWorkCycleSec: 58.0,
              actualCycleSec: 56.2,
              assignedOperator: { employeeId: 'EMP-TAK-402', name: 'Naoki Takahashi', japaneseName: '高橋 直樹', skillLevel: 'LEVEL_2_CERTIFIED', certifications: ['TRIM-INTERIOR-G2'], shiftAssigned: 'SHIFT-1' },
              machines: [
                { id: 'TOOL-ASSIST-ARM-09', serialNumber: 'TOYOTA-KARAKURI-ARM-09', manufacturer: 'Toyota Custom Automation', model: 'Pneumatic Zero-G Assist Arm', category: 'TORQUE_TOOL', status: 'OPTIMAL', operatingHours: 6100, mtbfHours: 1200, mttrMinutes: 8, lastServiceDate: '2026-09-02', vibrationMmPerSec: 0.4, temperatureCelsius: 29.0, firmwareVersion: 'v1.0' }
              ],
              state: 'NORMAL',
              kanbanBinCount: 6,
              kanbanMinThreshold: 2
            }
          ]
        }
      ]
    },
    {
      id: 'PLANT-MOTOMACHI',
      code: 'TY-JPN-MOTO',
      name: 'Motomachi Plant & High-Tech SDV Craft Line',
      japaneseName: '元町工場（GRファクトリー・bZ4X・センチュリー）',
      region: 'REGION-JP',
      country: 'Japan',
      locationCoordinates: [35.068, 137.142],
      dailyTargetVehicles: 480,
      currentShift: 'SHIFT-1-DAY',
      operatingState: 'RUNNING',
      activeTaktSeconds: 140.0,
      targetTaktSeconds: 140.0,
      oeePercentage: 95.8,
      firstPassYieldPercentage: 99.4,
      lines: [
        {
          id: 'LINE-MOTO-BAT-01',
          plantId: 'PLANT-MOTOMACHI',
          code: 'BAT-L2',
          name: 'Advanced Prismatic & Solid-State Battery Assembly Line',
          japaneseName: '次世代角型・全固体電池パック組立ライン',
          type: 'BATTERY_PACK',
          status: 'NORMAL',
          activeOrderCount: 160,
          currentPaceSec: 138.2,
          targetPaceSec: 140.0,
          pitchMarkIndex: 6,
          andonActive: false,
          stations: [
            {
              id: 'ST-MOTO-BAT-06',
              lineId: 'LINE-MOTO-BAT-01',
              sequenceNumber: 6,
              name: 'Laser Tab Welding & Inline Helium Leak Detection',
              japaneseName: 'レーザータブ溶接・ヘリウム気密検査',
              standardWorkCycleSec: 140.0,
              actualCycleSec: 139.0,
              assignedOperator: { employeeId: 'EMP-TANAKA-02', name: 'Yuki Tanaka', japaneseName: '田中 由紀', skillLevel: 'LEVEL_4_TRAINER', certifications: ['LASER-OPTICS-SPEC', 'BATTERY-PACK-MASTER'], shiftAssigned: 'SHIFT-1' },
              machines: [
                { id: 'M-LASER-TRUMPF-01', serialNumber: 'TRUMPF-TRUDISK-6001-JP', manufacturer: 'Trumpf Laser Systems', model: 'TruDisk 6001 Green Wavelength', category: 'WELDING_ROBOT', status: 'OPTIMAL', operatingHours: 3200, mtbfHours: 850, mttrMinutes: 14, lastServiceDate: '2026-08-30', vibrationMmPerSec: 0.5, temperatureCelsius: 24.2, firmwareVersion: 'v6.3.0' }
              ],
              state: 'NORMAL',
              kanbanBinCount: 10,
              kanbanMinThreshold: 3
            }
          ]
        }
      ]
    },
    {
      id: 'PLANT-GEORGETOWN',
      code: 'TY-USA-TMMK',
      name: 'Toyota Motor Manufacturing Kentucky (Georgetown)',
      japaneseName: 'TMMK ケンタッキー工場（米国ジョージタウン）',
      region: 'REGION-NA',
      country: 'United States',
      locationCoordinates: [38.209, -84.558],
      dailyTargetVehicles: 2100,
      currentShift: 'SHIFT-1-DAY',
      operatingState: 'RUNNING',
      activeTaktSeconds: 49.2,
      targetTaktSeconds: 48.0,
      oeePercentage: 91.2,
      firstPassYieldPercentage: 98.2,
      lines: []
    },
    {
      id: 'PLANT-TAHARA',
      code: 'TY-JPN-TAH',
      name: 'Tahara Flagship Craft & Powertrain Plant',
      japaneseName: '田原工場（最高峰フラッグシップ・エンジン製造）',
      region: 'REGION-JP',
      country: 'Japan',
      locationCoordinates: [34.664, 137.284],
      dailyTargetVehicles: 890,
      currentShift: 'SHIFT-1-DAY',
      operatingState: 'RUNNING',
      activeTaktSeconds: 78.0,
      targetTaktSeconds: 78.0,
      oeePercentage: 94.6,
      firstPassYieldPercentage: 99.2,
      lines: []
    },
    {
      id: 'PLANT-BURNASTON',
      code: 'TY-GBR-TMUK',
      name: 'Toyota Motor Manufacturing UK (Burnaston, Derby)',
      japaneseName: 'TMUK バーナストン工場（英国ダービーシャー）',
      region: 'REGION-EU',
      country: 'United Kingdom',
      locationCoordinates: [52.868, -1.564],
      dailyTargetVehicles: 620,
      currentShift: 'SHIFT-1-DAY',
      operatingState: 'RUNNING',
      activeTaktSeconds: 88.0,
      targetTaktSeconds: 88.0,
      oeePercentage: 93.1,
      firstPassYieldPercentage: 98.9,
      lines: []
    }
  ]);
}
