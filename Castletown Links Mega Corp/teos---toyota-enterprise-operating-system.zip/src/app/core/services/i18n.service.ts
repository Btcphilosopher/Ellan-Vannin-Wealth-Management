import { Injectable, signal, computed } from '@angular/core';
import { I18N_DICTIONARY, SupportedLocale } from '../i18n/teos-i18n';

@Injectable({
  providedIn: 'root'
})
export class I18nService {
  public currentLocale = signal<SupportedLocale>('en-US');

  public isJapanese = computed(() => this.currentLocale() === 'ja-JP');

  public setLocale(locale: SupportedLocale): void {
    this.currentLocale.set(locale);
  }

  public t(key: string): string {
    const entry = I18N_DICTIONARY[key];
    if (!entry) return key;
    return entry[this.currentLocale()] || entry['en-US'] || key;
  }
}
