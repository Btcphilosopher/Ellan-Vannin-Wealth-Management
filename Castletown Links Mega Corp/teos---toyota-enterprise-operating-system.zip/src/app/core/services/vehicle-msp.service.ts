import { Injectable, signal, computed } from '@angular/core';
import { MspSoftwarePackage, VehicleModel, VehicleProgram } from '../models/enterprise.model';

@Injectable({
  providedIn: 'root'
})
export class VehicleMspService {
  public vehiclePrograms = signal<VehicleProgram[]>([
    {
      programId: 'PROG-SDV-2026',
      codeName: 'Global Software Defined Architecture - Generation 2',
      platform: 'ARENE-SDV-GEN2',
      modelYear: 2026,
      models: [
        {
          vin: 'JTDKN36U0R2098411',
          modelName: 'bZ4X SDV Prime Limited',
          japaneseName: 'bZ4X ソフトウェア定義型 EV',
          variant: 'Dual Motor AWD High Performance',
          powertrainType: 'BEV',
          assemblyPlant: 'PLANT-MOTOMACHI',
          batteryPackSerial: 'BAT-PPES-90KWH-098411',
          currentSoftwareRelease: 'MSP-OS-v4.2.1-RELEASE',
          ecuList: [
            { ecuId: 'ECU-GW-01', name: 'Central High-Compute Gateway', architectureDomain: 'GATEWAY_CONNECTIVITY', hardwarePartNumber: '89661-TY-GW02', installedFirmware: 'v4.2.1', targetFirmware: 'v4.2.1', status: 'NOMINAL' },
            { ecuId: 'ECU-ADAS-01', name: 'Teammate ADAS Perception & Planning', architectureDomain: 'ADAS_AUTONOMOUS', hardwarePartNumber: '86100-TY-AD03', installedFirmware: 'v4.2.1', targetFirmware: 'v4.2.2-CANARY', status: 'CANARY_VALIDATING' },
            { ecuId: 'ECU-BMS-01', name: 'Master Battery Management Controller', architectureDomain: 'POWERTRAIN', hardwarePartNumber: '89870-TY-BM04', installedFirmware: 'v4.2.1', targetFirmware: 'v4.2.1', status: 'NOMINAL' },
            { ecuId: 'ECU-VSC-01', name: 'Chassis Dynamic Stability & Steer-by-Wire', architectureDomain: 'CHASSIS_SAFETY', hardwarePartNumber: '89540-TY-SBW01', installedFirmware: 'v4.2.1', targetFirmware: 'v4.2.1', status: 'NOMINAL' }
          ],
          telemetry: {
            speedKmh: 84.5,
            odometerKm: 14220,
            motorTorqueNm: 245.0,
            batterySocPct: 78.4,
            batterySohPct: 98.6,
            batteryVoltageV: 398.2,
            batteryCurrentA: -32.4, // Charging during regenerative braking
            batteryTempC: 28.5,
            inverterTempC: 46.2,
            brakePressureBar: 18.0,
            steeringAngleDeg: -2.4,
            activeFaultCodes: [],
            gpsCoordinates: [35.083, 137.156] // Toyota City, Aichi
          }
        },
        {
          vin: 'JTEBU49J6R1054920',
          modelName: 'Crown Crossover RS Advanced',
          japaneseName: 'クラウン クロスオーバー HEV',
          variant: '2.4L Dual Boost Hybrid MAX AWD',
          powertrainType: 'HEV',
          assemblyPlant: 'PLANT-TSUTSUMI',
          batteryPackSerial: 'BAT-BIPOLAR-NI-MH-054920',
          currentSoftwareRelease: 'MSP-OS-v4.1.8-RELEASE',
          ecuList: [
            { ecuId: 'ECU-GW-02', name: 'Central Gateway ECU', architectureDomain: 'GATEWAY_CONNECTIVITY', hardwarePartNumber: '89661-TY-GW01', installedFirmware: 'v4.1.8', targetFirmware: 'v4.2.1', status: 'UPDATE_PENDING' },
            { ecuId: 'ECU-ENG-01', name: 'Direct-Injection Turbo Hybrid ECU', architectureDomain: 'POWERTRAIN', hardwarePartNumber: '89666-TY-T24', installedFirmware: 'v4.1.8', targetFirmware: 'v4.1.8', status: 'NOMINAL' },
            { ecuId: 'ECU-CHAS-01', name: 'Dynamic Rear Steering (DRS) ECU', architectureDomain: 'CHASSIS_SAFETY', hardwarePartNumber: '89183-TY-DRS', installedFirmware: 'v4.1.8', targetFirmware: 'v4.1.8', status: 'NOMINAL' }
          ],
          telemetry: {
            speedKmh: 102.0,
            odometerKm: 28900,
            motorTorqueNm: 180.0,
            batterySocPct: 62.0,
            batterySohPct: 99.1,
            batteryVoltageV: 244.0,
            batteryCurrentA: 45.0,
            batteryTempC: 31.0,
            inverterTempC: 52.0,
            brakePressureBar: 0.0,
            steeringAngleDeg: 0.5,
            activeFaultCodes: [],
            gpsCoordinates: [35.689, 139.692] // Tokyo Bay Shuto Expressway
          }
        },
        {
          vin: 'JTMAB33V2R9012488',
          modelName: 'Century SUV GR Edition',
          japaneseName: 'センチュリー SUV PHEV',
          variant: '3.5L V6 Plug-in Hybrid E-Four',
          powertrainType: 'PHEV',
          assemblyPlant: 'PLANT-TAHARA',
          batteryPackSerial: 'BAT-LITH-PHEV-9012488',
          currentSoftwareRelease: 'MSP-OS-v4.2.0-RELEASE',
          ecuList: [
            { ecuId: 'ECU-GW-03', name: 'Central Gateway & Chauffeur Domain', architectureDomain: 'GATEWAY_CONNECTIVITY', hardwarePartNumber: '89661-TY-CEN', installedFirmware: 'v4.2.0', targetFirmware: 'v4.2.0', status: 'NOMINAL' },
            { ecuId: 'ECU-SUS-01', name: 'Active Electromagnetic Roll Control', architectureDomain: 'CHASSIS_SAFETY', hardwarePartNumber: '89220-TY-ARC', installedFirmware: 'v4.2.0', targetFirmware: 'v4.2.0', status: 'NOMINAL' }
          ],
          telemetry: {
            speedKmh: 65.0,
            odometerKm: 6400,
            motorTorqueNm: 310.0,
            batterySocPct: 88.0,
            batterySohPct: 99.8,
            batteryVoltageV: 355.0,
            batteryCurrentA: 55.0,
            batteryTempC: 25.0,
            inverterTempC: 38.0,
            brakePressureBar: 5.0,
            steeringAngleDeg: 1.2,
            activeFaultCodes: [],
            gpsCoordinates: [34.685, 135.804] // Nagoya-Kansai Corridor
          }
        },
        {
          vin: 'JTDKB20U5R7033912',
          modelName: 'Mirai Hydrogen FCEV Premium',
          japaneseName: 'ミライ 燃料電池車 FCEV',
          variant: 'High-Pressure 70MPa Hydrogen Stack',
          powertrainType: 'FCEV',
          assemblyPlant: 'PLANT-MOTOMACHI',
          batteryPackSerial: 'BAT-FCEV-BUFFER-7033912',
          currentSoftwareRelease: 'MSP-OS-v4.1.5-RELEASE',
          ecuList: [
            { ecuId: 'ECU-FC-01', name: 'Fuel Cell Stack & Hydrogen Regulator', architectureDomain: 'POWERTRAIN', hardwarePartNumber: '89670-TY-FC70', installedFirmware: 'v4.1.5', targetFirmware: 'v4.1.5', status: 'NOMINAL' }
          ],
          telemetry: {
            speedKmh: 90.0,
            odometerKm: 33400,
            motorTorqueNm: 220.0,
            batterySocPct: 82.0,
            batterySohPct: 97.4,
            batteryVoltageV: 310.0,
            batteryCurrentA: 40.0,
            batteryTempC: 27.0,
            inverterTempC: 44.0,
            brakePressureBar: 0.0,
            steeringAngleDeg: 0.0,
            fuelCellPressureMpa: 68.4,
            activeFaultCodes: [],
            gpsCoordinates: [38.268, 140.869] // Sendai Tohoku Expressway
          }
        }
      ]
    }
  ]);

  public vehicleModels = computed<VehicleModel[]>(() => {
    const progs = this.vehiclePrograms();
    return progs.flatMap(p => p.models);
  });

  public softwarePackages = signal<MspSoftwarePackage[]>([
    {
      packageId: 'MSP-PKG-2026-09-OTA',
      version: 'MSP-OS-v4.2.2-CANARY',
      gitCommitHash: 'git:a87f2e14bc89',
      targetEcuDomain: 'ADAS_AUTONOMOUS & CHASSIS_SAFETY',
      asilSafetyRating: 'ASIL_D',
      silTestCoveragePct: 99.4,
      hilTestPassRatePct: 100.0,
      ringiDecisionId: 'RINGI-2026-0881-APPR',
      deploymentPhase: 'CANARY_FLEET_5PCT',
      checksumSha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      releaseNotes: 'Enhancement to lane-tracing assist lateral jitter filter on wet road conditions; regenerative brake transition smoothing.'
    },
    {
      packageId: 'MSP-PKG-2026-08-PROD',
      version: 'MSP-OS-v4.2.1-RELEASE',
      gitCommitHash: 'git:7b3c8991a02f',
      targetEcuDomain: 'GATEWAY_CONNECTIVITY',
      asilSafetyRating: 'ASIL_B',
      silTestCoveragePct: 98.7,
      hilTestPassRatePct: 99.9,
      ringiDecisionId: 'RINGI-2026-0744-APPR',
      deploymentPhase: 'DEPLOYED',
      checksumSha256: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
      releaseNotes: 'OTA bandwidth compression update, MQTT v5 protocol support with mutual TLS 1.3 encryption.'
    },
    {
      packageId: 'MSP-PKG-2026-10-ALPHA',
      version: 'MSP-OS-v4.3.0-RC1',
      gitCommitHash: 'git:fe558a3d119c',
      targetEcuDomain: 'POWERTRAIN (BMS Firmware)',
      asilSafetyRating: 'ASIL_D',
      silTestCoveragePct: 96.2,
      hilTestPassRatePct: 97.5,
      ringiDecisionId: 'RINGI-PENDING',
      deploymentPhase: 'HIL_LAB_PASS',
      checksumSha256: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
      releaseNotes: 'Cold-weather ultra-fast charging pre-conditioning thermal model refinement.'
    }
  ]);

  public selectedVin = signal<string>('JTDKN36U0R2098411');

  public updateVehicleTelemetry(vin: string, speedDelta: number, throttleDelta: number): void {
    this.vehiclePrograms.update(programs =>
      programs.map(prog => ({
        ...prog,
        models: prog.models.map(model => {
          if (model.vin !== vin) return model;
          const currentSpeed = Math.max(0, Math.min(180, model.telemetry.speedKmh + speedDelta));
          const currentTorque = Math.max(0, Math.min(500, model.telemetry.motorTorqueNm + throttleDelta * 10));
          const currentSoc = Math.max(10, Math.min(100, model.telemetry.batterySocPct - (currentTorque > 200 ? 0.05 : -0.02)));
          const currentCurrent = currentTorque > 0 ? (currentTorque * 0.4) : -25;
          const currentTemp = Number((28.5 + (currentSpeed / 180) * 8.0).toFixed(1));

          return {
            ...model,
            telemetry: {
              ...model.telemetry,
              speedKmh: Number(currentSpeed.toFixed(1)),
              motorTorqueNm: Number(currentTorque.toFixed(1)),
              batterySocPct: Number(currentSoc.toFixed(2)),
              batteryCurrentA: Number(currentCurrent.toFixed(1)),
              batteryTempC: currentTemp
            }
          };
        })
      }))
    );
  }

  public promotePackageToNextWave(packageId: string): void {
    this.promoteCanaryRelease(packageId);
  }

  public rollbackPackage(packageId: string, _reason?: string): void {
    this.rollbackRelease(packageId);
  }

  public promoteCanaryRelease(packageId: string): void {
    this.softwarePackages.update(packages =>
      packages.map(pkg => {
        if (pkg.packageId === packageId) {
          return {
            ...pkg,
            deploymentPhase: 'GLOBAL_DEPLOYING'
          };
        }
        return pkg;
      })
    );
  }

  public rollbackRelease(packageId: string): void {
    this.softwarePackages.update(packages =>
      packages.map(pkg => {
        if (pkg.packageId === packageId) {
          return {
            ...pkg,
            deploymentPhase: 'ROLLED_BACK'
          };
        }
        return pkg;
      })
    );
  }
}

