import { Injectable, signal } from '@angular/core';
import { TeosAuditEvent, TeosEventType } from '../models/enterprise.model';

@Injectable({
  providedIn: 'root'
})
export class EventBusService {
  public eventStream = signal<TeosAuditEvent[]>([
    {
      eventId: 'EVT-2026-0912-00981',
      eventType: 'ANDON_RAISED',
      timestampIso: new Date(Date.now() - 8 * 60000).toISOString(),
      actor: { userId: 'EMP-SATO-881', role: 'Lead Assembly Technician', plantOrHub: 'PLANT-TSUTSUMI' },
      targetObjectId: 'ST-TSUT-ASM-14',
      targetObjectType: 'WorkStation',
      correlationId: 'CORR-TSUT-20260912-01',
      stateDeltaBefore: { stationState: 'NORMAL', torqueValueNm: 45.1 },
      stateDeltaAfter: { stationState: 'STOPPED', torqueValueNm: 49.8, interlock: true },
      cryptoChecksumSha256: '9f86d081884c7d659a2feaa0c55ad015a3bf4f1b2b0b822cd15d6c15b0f00a08',
      schemaVersion: 'teos.events.tps.v2'
    },
    {
      eventId: 'EVT-2026-0912-00980',
      eventType: 'MSP_CANARY_PROMOTED',
      timestampIso: new Date(Date.now() - 35 * 60000).toISOString(),
      actor: { userId: 'EMP-MURATA-904', role: 'Principal Software Architect', plantOrHub: 'TOYOTA_WOVEN_HQ' },
      targetObjectId: 'MSP-PKG-2026-09-OTA',
      targetObjectType: 'MspSoftwarePackage',
      correlationId: 'CORR-OTA-RELEASE-422',
      stateDeltaBefore: { deploymentPhase: 'HIL_LAB_PASS', canaryFleetVehicles: 0 },
      stateDeltaAfter: { deploymentPhase: 'CANARY_FLEET_5PCT', canaryFleetVehicles: 450 },
      cryptoChecksumSha256: 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
      schemaVersion: 'teos.events.msp.v1'
    },
    {
      eventId: 'EVT-2026-0912-00979',
      eventType: 'KANBAN_CONSUMED',
      timestampIso: new Date(Date.now() - 52 * 60000).toISOString(),
      actor: { userId: 'AGV-DISPATCH-09', role: 'Autonomous Tugger Fleet', plantOrHub: 'PLANT-MOTOMACHI' },
      targetObjectId: 'KB-88210-A',
      targetObjectType: 'KanbanCard',
      correlationId: 'CORR-JIT-MOTO-33',
      stateDeltaBefore: { containerStatus: 'DELIVERED_AT_LINE', partsRemaining: 8 },
      stateDeltaAfter: { containerStatus: 'STORE_EMPTY', pullSignalEmitted: true },
      cryptoChecksumSha256: '4b227777d4dd1fc61c6f884f48641d02b4d121d3fd328cb08b5531fcacdabf8a',
      schemaVersion: 'teos.events.jit.v1'
    },
    {
      eventId: 'EVT-2026-0912-00978',
      eventType: 'RINGI_DECIDED',
      timestampIso: new Date(Date.now() - 110 * 60000).toISOString(),
      actor: { userId: 'EXEC-TOYODA-01', role: 'Managing Officer / VP', plantOrHub: 'NAGOYA_HEADQUARTERS' },
      targetObjectId: 'RINGI-2026-0881',
      targetObjectType: 'RingiDocument',
      correlationId: 'CORR-DECISION-881',
      stateDeltaBefore: { status: 'UNDER_CONFIRMATION' },
      stateDeltaAfter: { status: 'FORMALLY_DECIDED_APPROVED', hanko: '豊田' },
      cryptoChecksumSha256: '7b3c8991a02f3312d8a0c8b981298411b934ca495991b7852b855661298a0c8b',
      schemaVersion: 'teos.events.workflow.v1'
    },
    {
      eventId: 'EVT-2026-0912-00977',
      eventType: 'VEHICLE_PRODUCED',
      timestampIso: new Date(Date.now() - 145 * 60000).toISOString(),
      actor: { userId: 'EOL-TESTER-LINE1', role: 'End-of-Line Quality Gate', plantOrHub: 'PLANT-TSUTSUMI' },
      targetObjectId: 'JTEBU49J6R1054920',
      targetObjectType: 'VehicleModel',
      correlationId: 'CORR-PROD-CROWN-5492',
      stateDeltaBefore: { status: 'FINAL_INSPECTION' },
      stateDeltaAfter: { status: 'FINISHED_GOODS_STOCK', fpyPass: true },
      cryptoChecksumSha256: '1a2b3c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b',
      schemaVersion: 'teos.events.manufacturing.v1'
    }
  ]);

  public emitEvent(
    eventType: TeosEventType,
    actor: { userId: string; role: string; plantOrHub: string },
    targetObjectId: string,
    targetObjectType: string,
    correlationId: string,
    stateDeltaBefore?: Record<string, unknown>,
    stateDeltaAfter?: Record<string, unknown>
  ): TeosAuditEvent {
    const rawData = `${eventType}:${targetObjectId}:${Date.now()}:${actor.userId}`;
    let hash = 0;
    for (let i = 0; i < rawData.length; i++) {
      hash = (hash << 5) - hash + rawData.charCodeAt(i);
      hash |= 0;
    }
    const checksum = Math.abs(hash).toString(16).padStart(64, '0');

    const event: TeosAuditEvent = {
      eventId: `EVT-${new Date().getFullYear()}-${Date.now().toString().slice(-5)}`,
      eventType,
      timestampIso: new Date().toISOString(),
      actor,
      targetObjectId,
      targetObjectType,
      correlationId,
      stateDeltaBefore,
      stateDeltaAfter,
      cryptoChecksumSha256: checksum,
      schemaVersion: 'teos.events.core.v2'
    };

    this.eventStream.update(stream => [event, ...stream]);
    return event;
  }
}
