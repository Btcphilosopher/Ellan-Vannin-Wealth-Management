import { Injectable, signal } from '@angular/core';
import { RingiDocument, RingiStatus } from '../models/enterprise.model';

@Injectable({
  providedIn: 'root'
})
export class RingiWorkflowService {
  public documents = signal<RingiDocument[]>([
    {
      id: 'RINGI-2026-0881',
      ringiNumber: '決裁-第2026-0881号',
      title: 'Global Rollout Authorization for MSP-OS v4.2.2 Canary Fleet Update',
      japaneseTitle: 'MSP-OS v4.2.2 カナリアフリートOTA配信及びグローバル展開の件',
      category: 'MSP_SOFTWARE_GLOBAL_RELEASE',
      applicant: {
        name: 'Dr. Kenichi Murata (村田 健一)',
        department: 'Mobility Software Platform / Arene Engineering Div.',
        email: 'k.murata@teos-mobility.internal'
      },
      submissionDate: '2026-09-08T09:30:00Z',
      amountCents: 0,
      justificationText: 'ASIL-D lane tracking and regenerative braking transition patch has cleared 10,000 continuous HIL lab test cycles with 100% pass rate. Canary 5% deployment in Kanto test region showed zero safety regressions.',
      riskAssessment: 'Autonomous safety interlocks guarantee fail-operational transition to mechanical steering backup in event of unexpected ECU checksum mismatch.',
      status: 'FORMALLY_DECIDED_APPROVED',
      approvers: [
        { role: 'Section Manager (課長)', approverName: 'H. Tanaka (田中)', hankoStamp: '田中', decision: 'APPROVED', decidedAt: '2026-09-08T11:00:00Z', comment: 'Technical test verification complete.' },
        { role: 'General Manager (部長)', approverName: 'M. Sato (佐藤)', hankoStamp: '佐藤', decision: 'APPROVED', decidedAt: '2026-09-08T14:20:00Z', comment: 'Safety review board sign-off verified.' },
        { role: 'Managing Officer / VP (役員決裁)', approverName: 'K. Toyoda (豊田)', hankoStamp: '豊田', decision: 'APPROVED', decidedAt: '2026-09-09T08:45:00Z', comment: 'Approved for global scheduled rollout.' }
      ]
    },
    {
      id: 'RINGI-2026-0904',
      ringiNumber: '決裁-第2026-0904号',
      title: 'CapEx Investment: High-Speed Battery Tab Laser Welding Cell for Motomachi Plant #2',
      japaneseTitle: '元町工場第2電池ライン向け高速タブレーザー溶接セル設備投資の件',
      category: 'CAPEX_INVESTMENT',
      applicant: {
        name: 'Shigeru Kobayashi (小林 茂)',
        department: 'Production Engineering / Battery Manufacturing Div.',
        email: 's.kobayashi@teos-manufacturing.internal'
      },
      submissionDate: '2026-09-10T13:00:00Z',
      amountCents: 1450000000, // $14.5M (¥2.17B)
      justificationText: 'Next-generation solid-state and high-density prismatic NMC pack demand requires reducing busbar weld cycle time from 54s to 32s while improving micro-porosity defect rates below 1 PPM.',
      riskAssessment: 'Equipment lead time 14 weeks. Interim buffer stock planned to prevent takt interruption during changeover window.',
      status: 'UNDER_CONFIRMATION',
      approvers: [
        { role: 'Plant Engineering GM (工場技術部長)', approverName: 'T. Suzuki (鈴木)', hankoStamp: '鈴木', decision: 'APPROVED', decidedAt: '2026-09-11T09:15:00Z', comment: 'Engineering drawings and cycle simulation approved.' },
        { role: 'Corporate Finance GM (経理部長)', approverName: 'Y. Watanabe (渡辺)', hankoStamp: 'PENDING', decision: 'PENDING', comment: 'ROI and NPV calculation validation in progress.' },
        { role: 'Chief Production Officer (生産本部長)', approverName: 'A. Takahashi (高橋)', hankoStamp: 'PENDING', decision: 'PENDING' }
      ]
    },
    {
      id: 'RINGI-2026-0915',
      ringiNumber: '決裁-第2026-0915号',
      title: 'Emergency Line Interlock Override & Tool Calibration Procedure Revision',
      japaneseTitle: '第1組立ライン締付工具キャリブレーション規程改定及びライン停止処置の件',
      category: 'PRODUCTION_LINE_STOP',
      applicant: {
        name: 'Takeshi Yamada (山田 武)',
        department: 'Tsutsumi Assembly Division / Team Leader',
        email: 't.yamada@teos-tsutsumi.internal'
      },
      submissionDate: '2026-09-12T02:15:00Z',
      amountCents: 120000,
      justificationText: 'Station 14 nutrunner transducer experienced torque drift. Recommending tool replacement and temporary offline secondary quality gate until shift change.',
      riskAssessment: '100% manual angle-torque verification will be performed on all 42 vehicles produced during the transition.',
      status: 'SUBMITTED_FOR_REVIEW',
      approvers: [
        { role: 'Line Leader (工長)', approverName: 'K. Kato (加藤)', hankoStamp: '加藤', decision: 'APPROVED', decidedAt: '2026-09-12T02:30:00Z', comment: 'Immediate containment verified.' },
        { role: 'Quality Assurance GM (品質管理部長)', approverName: 'S. Ito (伊藤)', hankoStamp: 'PENDING', decision: 'PENDING' }
      ]
    }
  ]);

  public approveStep(ringiId: string, approverName: string, hanko: string, comment: string): void {
    this.documents.update(docs =>
      docs.map(doc => {
        if (doc.id !== ringiId) return doc;
        const updatedApprovers = doc.approvers.map(app => {
          if (app.approverName.includes(approverName) || app.decision === 'PENDING') {
            return {
              ...app,
              decision: 'APPROVED' as const,
              hankoStamp: hanko || app.hankoStamp,
              decidedAt: new Date().toISOString(),
              comment
            };
          }
          return app;
        });

        const allApproved = updatedApprovers.every(a => a.decision === 'APPROVED');
        return {
          ...doc,
          approvers: updatedApprovers,
          status: (allApproved ? 'FORMALLY_DECIDED_APPROVED' : 'UNDER_CONFIRMATION') as RingiStatus
        };
      })
    );
  }

  public returnSashimodoshi(ringiId: string, approverName: string, reason: string): void {
    this.documents.update(docs =>
      docs.map(doc => {
        if (doc.id !== ringiId) return doc;
        return {
          ...doc,
          status: 'RETURNED_SASHIMODOSHI' as RingiStatus,
          riskAssessment: `${doc.riskAssessment} [RETURNED FOR CORRECTION by ${approverName}: ${reason}]`
        };
      })
    );
  }
}
