/**
 * TEOS (Toyota Enterprise Operating System) Canonical Domain Models
 * Strict type safety, immutable structures, and enterprise domain schemas.
 */

export type PlantId = 'PLANT-TSUTSUMI' | 'PLANT-MOTOMACHI' | 'PLANT-GEORGETOWN' | 'PLANT-TAHARA' | 'PLANT-BURNASTON';
export type RegionId = 'REGION-JP' | 'REGION-NA' | 'REGION-EU' | 'REGION-ASIA';

export interface EnterpriseHierarchy {
  groupId: string;
  groupName: string;
  regions: EnterpriseRegion[];
}

export interface EnterpriseRegion {
  id: RegionId;
  name: string;
  headquarters: string;
  plants: ProductionPlant[];
}

export interface ProductionPlant {
  id: PlantId;
  code: string;
  name: string;
  japaneseName: string;
  region: RegionId;
  country: string;
  locationCoordinates: [number, number]; // [lat, lng]
  dailyTargetVehicles: number;
  currentShift: 'SHIFT-1-DAY' | 'SHIFT-2-EVENING' | 'SHIFT-3-NIGHT';
  operatingState: 'RUNNING' | 'DEGRADED' | 'ANDON_STOP' | 'MAINTENANCE';
  activeTaktSeconds: number;
  targetTaktSeconds: number;
  oeePercentage: number; // Overall Equipment Effectiveness
  firstPassYieldPercentage: number;
  lines: ProductionLine[];
}

export type LineType = 'STAMPING' | 'BODY_WELDING' | 'PAINT' | 'BATTERY_PACK' | 'FINAL_ASSEMBLY';

export interface ProductionLine {
  id: string;
  plantId: PlantId;
  code: string;
  name: string;
  japaneseName: string;
  type: LineType;
  status: 'NORMAL' | 'WARNING' | 'STOPPED' | 'CHANGEOVER';
  activeOrderCount: number;
  currentPaceSec: number;
  targetPaceSec: number;
  pitchMarkIndex: number;
  stations: WorkStation[];
  andonActive: boolean;
  activeAndonReason?: string;
}

export interface WorkStation {
  id: string;
  lineId: string;
  sequenceNumber: number;
  name: string;
  japaneseName: string;
  standardWorkCycleSec: number;
  actualCycleSec: number;
  assignedOperator: OperatorAssignment;
  machines: IndustrialMachine[];
  currentVehicleVin?: string;
  state: 'NORMAL' | 'WARNING' | 'DEGRADED' | 'STOPPED' | 'QUALITY_HOLD' | 'SAFETY_HOLD';
  kanbanBinCount: number;
  kanbanMinThreshold: number;
}

export interface OperatorAssignment {
  employeeId: string;
  name: string;
  japaneseName: string;
  skillLevel: 'LEVEL_1_TRAINEE' | 'LEVEL_2_CERTIFIED' | 'LEVEL_3_ADVANCED' | 'LEVEL_4_TRAINER';
  certifications: string[];
  shiftAssigned: string;
}

export interface IndustrialMachine {
  id: string;
  serialNumber: string;
  manufacturer: string;
  model: string;
  category: 'PRESS_MACHINE' | 'WELDING_ROBOT' | 'PAINT_ATOMIZER' | 'TORQUE_TOOL' | 'VISION_INSPECTOR' | 'BMS_TESTER';
  status: 'OPTIMAL' | 'WARNING' | 'ALARM' | 'OFFLINE';
  operatingHours: number;
  mtbfHours: number; // Mean Time Between Failures
  mttrMinutes: number; // Mean Time To Repair
  lastServiceDate: string;
  vibrationMmPerSec: number;
  temperatureCelsius: number;
  firmwareVersion: string;
}

// ==========================================
// 2. TPS / JIT & HEIJUNKA MODELS
// ==========================================

export interface JITCalculationInput {
  customerDailyDemand: number;
  dailyOperatingSeconds: number; // e.g. 2 shifts * 8h * 3600s = 57600s - breaks
  plannedDowntimeSeconds: number;
  leadTimeDays: number;
  leadTimeVariance: number;
  demandVariance: number;
  serviceLevelZScore: number; // e.g., 1.96 for 95%, 2.33 for 99%
  containerCapacity: number; // units per standard Kanban box
  supplierMinimumBatch: number;
  transitTimeHours: number;
}

export interface JITCalculationResult {
  taktTimeSeconds: number; // (OperatingSeconds - Downtime) / Demand
  leadTimeDemand: number; // Demand * LeadTime
  safetyStockUnits: number; // Z * sqrt(LT * DemandVar + Demand^2 * LTVar)
  reorderPointUnits: number; // LeadTimeDemand + SafetyStock
  recommendedKanbanCards: number; // Ceil((LeadTimeDemand + SafetyStock) / ContainerCapacity)
  dailyHeijunkaPitchMinutes: number;
  shortageRiskPercentage: number;
  excessInventoryRiskPercentage: number;
}

export interface KanbanCard {
  id: string;
  cardType: 'PRODUCTION_KANBAN' | 'WITHDRAWAL_KANBAN' | 'SUPPLIER_CALLOFF_KANBAN';
  partNumber: string;
  partName: string;
  supplierName: string;
  sourceLocation: string;
  destinationStation: string;
  quantityPerContainer: number;
  cycleTimeMinutes: number;
  currentStatus: 'STORE_EMPTY' | 'PULL_SIGNAL_EMITTED' | 'DISPATCHED_IN_TRANSIT' | 'DELIVERED_AT_LINE' | 'CONSUMED';
  timestampGenerated: string;
  qrPayload: string;
}

export interface HeijunkaSlot {
  slotIndex: number;
  timeWindow: string;
  vehicleModel: string;
  powertrain: 'BEV' | 'HEV' | 'FCEV' | 'PHEV';
  colorCode: string;
  targetSequence: string;
  lineTaktTargetSec: number;
  status: 'SCHEDULED' | 'IN_PRODUCTION' | 'COMPLETED' | 'DELAYED';
}

// ==========================================
// 3. JIDOKA / ANDON MODELS
// ==========================================

export type AndonSeverity = 'YELLOW_WARNING' | 'RED_STOP_LINE' | 'CRITICAL_SAFETY_HOLD';
export type AndonCategory = 'QUALITY_DEFECT' | 'EQUIPMENT_BREAKDOWN' | 'MATERIAL_SHORTAGE' | 'CYCLE_OVERRUN' | 'SAFETY_TRIP';

export interface AndonEvent {
  id: string;
  stationId: string;
  stationName: string;
  lineName: string;
  plantId: PlantId;
  operatorName: string;
  severity: AndonSeverity;
  category: AndonCategory;
  problemDescription: string;
  raisedAt: string;
  escalationStage: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9;
  // 9-Stage Workflow: 1:SIGNAL -> 2:DETECT -> 3:CLASSIFY -> 4:STOP -> 5:ESCALATE -> 6:INVESTIGATE -> 7:CORRECT -> 8:VERIFY -> 9:RELEASE
  assignedLeader?: string;
  investigationNote?: string;
  countermeasureTaken?: string;
  resolvedAt?: string;
  downtimeSeconds: number;
}

// ==========================================
// 4. KAIZEN & 5-WHYS MODELS
// ==========================================

export type WasteCategory = 'OVERPRODUCTION' | 'INVENTORY' | 'MOTION' | 'DEFECTS' | 'OVERPROCESSING' | 'WAITING' | 'TRANSPORTATION' | 'UNUSED_TALENT';

export interface KaizenProject {
  id: string;
  code: string;
  title: string;
  japaneseTitle: string;
  plantId: PlantId;
  lineId: string;
  wasteTarget: WasteCategory;
  author: string;
  status: 'PROPOSED' | 'ANALYSIS_5WHYS' | 'EXPERIMENTATION' | 'STANDARDIZED' | 'DEPLOYED_GLOBAL';
  problemStatement: string;
  whys: [string, string, string, string, string]; // 5 Whys
  countermeasure: string;
  beforeMetrics: {
    cycleTimeSec: number;
    defectPpm: number;
    downtimeMinutesMonthly: number;
    kwhPerVehicle: number;
    inventoryHoldingCents: number;
  };
  afterMetrics: {
    cycleTimeSec: number;
    defectPpm: number;
    downtimeMinutesMonthly: number;
    kwhPerVehicle: number;
    inventoryHoldingCents: number;
  };
  validatedAnnualSavingsCents: number;
  createdAt: string;
  ringiApprovedBy?: string;
}

// ==========================================
// 5. VEHICLE PRODUCT & MSP SOFTWARE LIFECYCLE
// ==========================================

export interface VehicleProgram {
  programId: string;
  codeName: string;
  platform: 'TNGA-K' | 'TNGA-F' | 'e-TNGA' | 'ARENE-SDV-GEN2';
  modelYear: number;
  models: VehicleModel[];
}

export interface VehicleModel {
  vin: string;
  modelName: string;
  japaneseName: string;
  variant: string;
  powertrainType: 'BEV' | 'HEV' | 'FCEV' | 'PHEV';
  assemblyPlant: PlantId;
  batteryPackSerial?: string;
  ecuList: VehicleEcu[];
  currentSoftwareRelease: string;
  telemetry: VehicleLiveTelemetry;
}

export interface VehicleEcu {
  ecuId: string;
  name: string;
  architectureDomain: 'POWERTRAIN' | 'CHASSIS_SAFETY' | 'BODY_CABIN' | 'ADAS_AUTONOMOUS' | 'GATEWAY_CONNECTIVITY';
  hardwarePartNumber: string;
  installedFirmware: string;
  targetFirmware: string;
  status: 'NOMINAL' | 'UPDATE_PENDING' | 'CANARY_VALIDATING' | 'FAULT_ISOLATED';
}

export interface MspSoftwarePackage {
  packageId: string;
  version: string;
  gitCommitHash: string;
  targetEcuDomain: string;
  asilSafetyRating: 'ASIL_QM' | 'ASIL_B' | 'ASIL_C' | 'ASIL_D';
  silTestCoveragePct: number;
  hilTestPassRatePct: number;
  ringiDecisionId: string;
  deploymentPhase: 'BUILD_VERIFIED' | 'SIL_SIMULATION' | 'HIL_LAB_PASS' | 'RINGI_APPROVED' | 'CANARY_FLEET_5PCT' | 'GLOBAL_DEPLOYING' | 'DEPLOYED' | 'ROLLED_BACK';
  checksumSha256: string;
  releaseNotes: string;
}

export interface VehicleLiveTelemetry {
  speedKmh: number;
  odometerKm: number;
  motorTorqueNm: number;
  batterySocPct: number;
  batterySohPct: number;
  batteryVoltageV: number;
  batteryCurrentA: number;
  batteryTempC: number;
  inverterTempC: number;
  brakePressureBar: number;
  steeringAngleDeg: number;
  fuelCellPressureMpa?: number;
  activeFaultCodes: string[];
  gpsCoordinates: [number, number];
}

// ==========================================
// 6. SUPPLY CHAIN & LOGISTICS CONTROL TOWER
// ==========================================

export interface SupplierProfile {
  id: string;
  name: string;
  country: string;
  tier: 'TIER_1_SYSTEM' | 'TIER_2_COMPONENT' | 'TIER_3_RAW_MATERIAL';
  partsSupplied: string[];
  qualityScorePpm: number;
  onTimeDeliveryRatePct: number;
  sustainabilityRating: 'A_CARBON_NEUTRAL' | 'B_TRANSITIONING' | 'C_BASELINE';
  riskStatus: 'LOW_RISK' | 'MODERATE_WEATHER' | 'HIGH_PORT_CONGESTION';
}

export interface IntermodalShipment {
  id: string;
  trackingNumber: string;
  originHub: string;
  destinationPlant: PlantId;
  transportMode: 'MARITIME_VESSEL' | 'FREIGHT_RAIL' | 'HEAVY_TRUCK' | 'AIR_CARGO';
  carrierName: string;
  partsCarried: { partNumber: string; partName: string; quantity: number }[];
  departureTime: string;
  plannedEta: string;
  realTimeCalculatedEta: string;
  delayHours: number;
  latitude: number;
  longitude: number;
  containerTempCelsius: number;
  status: 'IN_TRANSIT' | 'CUSTOMS_CLEARANCE' | 'PORT_DISPATCH' | 'ARRIVED_PLANT_UNLOADING';
}

// ==========================================
// 7. QUALITY (SPC) & SAFETY (ASIL-D)
// ==========================================

export interface SpcMeasurementPoint {
  sampleIndex: number;
  timestamp: string;
  subgroupValues: number[]; // e.g. 5 measurement readings per sample batch
  mean: number;
  range: number;
  withinLimits: boolean;
}

export interface SpcAnalysisResult {
  characteristicName: string;
  nominalTarget: number;
  usl: number; // Upper Spec Limit
  lsl: number; // Lower Spec Limit
  uclMean: number; // Upper Control Limit for X-bar
  lclMean: number; // Lower Control Limit for X-bar
  processMean: number;
  processStdDev: number;
  cp: number; // Process Capability
  cpk: number; // Minimum of (USL - Mean)/(3*sigma) or (Mean - LSL)/(3*sigma)
  firstPassYieldPct: number;
  samples: SpcMeasurementPoint[];
}

export interface SafetyCase {
  id: string;
  systemName: string;
  hazardDescription: string;
  severityLevel: 'S0_NO_INJURIES' | 'S1_LIGHT' | 'S2_SEVERE' | 'S3_LIFE_THREATENING';
  exposureLevel: 'E1_VERY_LOW' | 'E2_LOW' | 'E3_MEDIUM' | 'E4_HIGH';
  controllabilityLevel: 'C1_SIMPLY_CONTROLLABLE' | 'C2_NORMAL' | 'C3_DIFFICULT';
  assignedAsil: 'QM' | 'ASIL_A' | 'ASIL_B' | 'ASIL_C' | 'ASIL_D';
  safetyGoal: string;
  verificationEvidence: string;
  status: 'VALIDATED_CERTIFIED' | 'UNDER_ANALYSIS' | 'TEST_IN_PROGRESS';
}

// ==========================================
// 8. ENTERPRISE FINANCE (EXACT CENTS)
// ==========================================

export interface VehicleUnitEconomics {
  vin: string;
  modelName: string;
  msrpCents: number; // Stored in exact integer cents ($42,500.00 = 4250000)
  directMaterialCostCents: number;
  directLaborCostCents: number;
  manufacturingOverheadCents: number;
  logisticsDeliveryCostCents: number;
  warrantyAccrualCents: number;
  totalCostOfGoodsSoldCents: number;
  grossMarginCents: number;
  grossMarginPercentage: number;
}

// ==========================================
// 9. RINGI (電子稟議) ENTERPRISE WORKFLOW
// ==========================================

export type RingiCategory = 'CAPEX_INVESTMENT' | 'PRODUCTION_LINE_STOP' | 'MSP_SOFTWARE_GLOBAL_RELEASE' | 'SUPPLIER_CONTRACT_QUALIFICATION' | 'KAIZEN_STANDARDIZATION';
export type RingiStatus = 'DRAFT' | 'SUBMITTED_FOR_REVIEW' | 'UNDER_CONFIRMATION' | 'FORMALLY_DECIDED_APPROVED' | 'RETURNED_SASHIMODOSHI' | 'REJECTED';

export interface RingiDocument {
  id: string;
  ringiNumber: string;
  title: string;
  japaneseTitle: string;
  category: RingiCategory;
  applicant: { name: string; department: string; email: string };
  submissionDate: string;
  amountCents?: number;
  justificationText: string;
  riskAssessment: string;
  status: RingiStatus;
  approvers: {
    role: string;
    approverName: string;
    hankoStamp: string; // Traditional seal name e.g. "佐藤", "Tanaka", "Yamada"
    decision: 'PENDING' | 'APPROVED' | 'RETURNED' | 'REJECTED';
    decidedAt?: string;
    comment?: string;
  }[];
}

// ==========================================
// 10. AUDIT EVENT BUS & IMMUTABLE STREAM
// ==========================================

export type TeosEventType = 
  | 'VEHICLE_PRODUCED' 
  | 'ANDON_RAISED' 
  | 'ANDON_RESOLVED' 
  | 'KANBAN_CONSUMED' 
  | 'MSP_RELEASE_STAGED' 
  | 'MSP_CANARY_PROMOTED' 
  | 'SPC_OUT_OF_CONTROL_DETECTED' 
  | 'RINGI_DECIDED' 
  | 'SUPPLIER_SHIPMENT_DELAYED';

export interface TeosAuditEvent {
  eventId: string;
  eventType: TeosEventType;
  timestampIso: string;
  actor: { userId: string; role: string; plantOrHub: string };
  targetObjectId: string;
  targetObjectType: string;
  correlationId: string;
  stateDeltaBefore?: Record<string, unknown>;
  stateDeltaAfter?: Record<string, unknown>;
  cryptoChecksumSha256: string;
  schemaVersion: string;
}
