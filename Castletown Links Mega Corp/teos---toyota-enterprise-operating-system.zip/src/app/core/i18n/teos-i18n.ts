export type SupportedLocale = 'en-US' | 'en-GB' | 'ja-JP';

export type TranslationDictionary = Record<string, {
  'en-US': string;
  'en-GB': string;
  'ja-JP': string;
}>;

export const I18N_DICTIONARY: TranslationDictionary = {
  // Brand & Header
  appTitle: {
    'en-US': 'TEOS - Toyota Enterprise Operating System',
    'en-GB': 'TEOS - Toyota Enterprise Operating System',
    'ja-JP': 'TEOS - トヨタ・エンタープライズ・オペレーティング・システム'
  },
  syntheticDataNotice: {
    'en-US': 'SYNTHETIC REFERENCE DATA ONLY — NOT OFFICIAL TOYOTA MOTOR CORP DATA',
    'en-GB': 'SYNTHETIC REFERENCE DATA ONLY — NOT OFFICIAL TOYOTA MOTOR CORP DATA',
    'ja-JP': '合成参照データのみ — トヨタ自動車株式会社の公式データではありません'
  },
  oneEnterprisePhilosophy: {
    'en-US': 'One Enterprise · One Vehicle Graph · One Factory Graph · One Supply Chain · One Audit Trail',
    'en-GB': 'One Enterprise · One Vehicle Graph · One Factory Graph · One Supply Chain · One Audit Trail',
    'ja-JP': '統合企業 · 車両グラフ統一 · 工場グラフ統一 · サプライチェーン統一 · 監査証跡統合'
  },

  // Navigation
  navExecutive: { 'en-US': 'Executive Command', 'en-GB': 'Executive Command', 'ja-JP': '役員統括指令所' },
  navPlant: { 'en-US': 'Plant Digital Twin', 'en-GB': 'Plant Digital Twin', 'ja-JP': '工場デジタルツイン' },
  navJit: { 'en-US': 'TPS / JIT Engine', 'en-GB': 'TPS / JIT Engine', 'ja-JP': 'TPS / JIT 生産計画' },
  navAndon: { 'en-US': 'Jidoka / Andon', 'en-GB': 'Jidoka / Andon', 'ja-JP': '自働化 / 行灯システム' },
  navKaizen: { 'en-US': 'Kaizen & 5-Whys', 'en-GB': 'Kaizen & 5-Whys', 'ja-JP': '改善 / なぜなぜ分析' },
  navVehicleMsp: { 'en-US': 'Vehicle & MSP Platform', 'en-GB': 'Vehicle & MSP Platform', 'ja-JP': '車両グラフ & MSP基盤' },
  navVehicleTwin: { 'en-US': 'Vehicle & BMS Twin', 'en-GB': 'Vehicle & BMS Twin', 'ja-JP': '車両 & 電池ツイン' },
  navSupplyChain: { 'en-US': 'Supply Chain Tower', 'en-GB': 'Supply Chain Tower', 'ja-JP': 'サプライチェーン管制' },
  navQualitySafety: { 'en-US': 'Quality & Safety (SPC)', 'en-GB': 'Quality & Safety (SPC)', 'ja-JP': '品質管理 & 安全性 (SPC)' },
  navFinance: { 'en-US': 'Enterprise Finance', 'en-GB': 'Enterprise Finance', 'ja-JP': '企業財務 · 原価計算' },
  navRingi: { 'en-US': 'Ringi Workflow (稟議)', 'en-GB': 'Ringi Workflow (稟議)', 'ja-JP': '電子稟議・意思決定' },
  navAudit: { 'en-US': 'Audit & Event Bus', 'en-GB': 'Audit & Event Bus', 'ja-JP': '監査証跡 & イベント配信' },
  navBlueprint: { 'en-US': 'Architecture & Specs', 'en-GB': 'Architecture & Specs', 'ja-JP': 'アーキテクチャ & 設計仕様' },

  // Workflow Terms (Ringi)
  workflowApplication: { 'en-US': 'Application (Shinsei)', 'en-GB': 'Application (Shinsei)', 'ja-JP': '申請 (Shinsei)' },
  workflowApproval: { 'en-US': 'Approval (Shonin)', 'en-GB': 'Approval (Shonin)', 'ja-JP': '承認 (Shonin)' },
  workflowRejection: { 'en-US': 'Rejection (Kyakka)', 'en-GB': 'Rejection (Kyakka)', 'ja-JP': '却下 (Kyakka)' },
  workflowReturn: { 'en-US': 'Return for Correction (Sashimodoshi)', 'en-GB': 'Return for Correction (Sashimodoshi)', 'ja-JP': '差戻し (Sashimodoshi)' },
  workflowResubmission: { 'en-US': 'Resubmission (Saishinsei)', 'en-GB': 'Resubmission (Saishinsei)', 'ja-JP': '再申請 (Saishinsei)' },
  workflowConfirmation: { 'en-US': 'Confirmation (Kakunin)', 'en-GB': 'Confirmation (Kakunin)', 'ja-JP': '確認 (Kakunin)' },
  workflowReference: { 'en-US': 'Reference (Sansho)', 'en-GB': 'Reference (Sansho)', 'ja-JP': '参照 (Sansho)' },
  workflowFormalDecision: { 'en-US': 'Formal Decision (Kessai)', 'en-GB': 'Formal Decision (Kessai)', 'ja-JP': '決裁 (Kessai)' },

  // TPS Concepts
  justInTime: { 'en-US': 'Just-in-Time (JIT)', 'en-GB': 'Just-in-Time (JIT)', 'ja-JP': 'ジャスト・イン・タイム (JIT)' },
  jidoka: { 'en-US': 'Jidoka (Autonomation with Human Touch)', 'en-GB': 'Jidoka (Autonomation with Human Touch)', 'ja-JP': '自働化 (人の知恵のついた自動化)' },
  heijunka: { 'en-US': 'Heijunka (Production Leveling)', 'en-GB': 'Heijunka (Production Leveling)', 'ja-JP': '平準化 (生産の平準化)' },
  taktTime: { 'en-US': 'Takt Time', 'en-GB': 'Takt Time', 'ja-JP': 'タクトタイム' },
  kanban: { 'en-US': 'Kanban (Pull Signal)', 'en-GB': 'Kanban (Pull Signal)', 'ja-JP': 'かんばん (引取・生産指示)' },
  andon: { 'en-US': 'Andon (Visual Control Board)', 'en-GB': 'Andon (Visual Control Board)', 'ja-JP': '行灯 (あんどん)' },
  standardWork: { 'en-US': 'Standard Work', 'en-GB': 'Standard Work', 'ja-JP': '標準作業' },
  genchiGenbutsu: { 'en-US': 'Genchi Genbutsu (Go and See)', 'en-GB': 'Genchi Genbutsu (Go and See)', 'ja-JP': '現地現物 (現場観察)' },
  kaizen: { 'en-US': 'Kaizen (Continuous Improvement)', 'en-GB': 'Kaizen (Continuous Improvement)', 'ja-JP': '改善 (継続的改善)' },

  // Statuses & Actions
  statusNormal: { 'en-US': 'Normal', 'en-GB': 'Normal', 'ja-JP': '正常' },
  statusWarning: { 'en-US': 'Warning', 'en-GB': 'Warning', 'ja-JP': '警告' },
  statusDegraded: { 'en-US': 'Degraded', 'en-GB': 'Degraded', 'ja-JP': '能力低下' },
  statusStopped: { 'en-US': 'Stopped', 'en-GB': 'Stopped', 'ja-JP': '停止中' },
  statusQualityHold: { 'en-US': 'Quality Hold', 'en-GB': 'Quality Hold', 'ja-JP': '品質保留' },
  statusSafetyHold: { 'en-US': 'Safety Hold', 'en-GB': 'Safety Hold', 'ja-JP': '安全停止' },
  execute: { 'en-US': 'Execute', 'en-GB': 'Execute', 'ja-JP': '実行' },
  calculate: { 'en-US': 'Calculate', 'en-GB': 'Calculate', 'ja-JP': '計算実行' },
  pullAndonCord: { 'en-US': 'PULL ANDON CORD', 'en-GB': 'PULL ANDON CORD', 'ja-JP': '行灯コードを引く' },
  clearAndon: { 'en-US': 'Resolve & Reset Line', 'en-GB': 'Resolve & Reset Line', 'ja-JP': '処置完了・ライン復帰' },
  runSimulation: { 'en-US': 'Run Dynamic Simulation', 'en-GB': 'Run Dynamic Simulation', 'ja-JP': '動的シミュレーション開始' }
};
