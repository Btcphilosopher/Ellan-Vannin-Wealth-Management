import {
  AngularNodeAppEngine,
  createNodeRequestHandler,
  isMainModule,
  writeResponseToNodeResponse,
} from '@angular/ssr/node';
import express from 'express';
import {join} from 'node:path';
import {GoogleGenAI} from '@google/genai';

const browserDistFolder = join(import.meta.dirname, '../browser');

const app = express();
app.use(express.json());

const angularApp = new AngularNodeAppEngine();

// ==========================================
// REST API ENDPOINTS FOR TEOS PLATFORM
// ==========================================

app.get('/api/health', (req, res) => {
  res.json({
    status: 'OPTIMAL',
    system: 'TEOS - Toyota Enterprise Operating System',
    timestamp: new Date().toISOString(),
    nodes: {
      tsutsumiEdge: 'ONLINE',
      motomachiEdge: 'ONLINE',
      georgetownEdge: 'ONLINE',
      taharaEdge: 'ONLINE',
      burnastonEdge: 'ONLINE'
    },
    version: '2026.9.12-enterprise'
  });
});

app.post('/api/tps/jit/calculate', (req, res) => {
  const { customerDailyDemand, dailyOperatingSeconds, plannedDowntimeSeconds, leadTimeDays, leadTimeVariance, demandVariance, serviceLevelZScore, containerCapacity } = req.body;
  
  const netOperatingSeconds = Math.max(1, (dailyOperatingSeconds || 57600) - (plannedDowntimeSeconds || 3600));
  const demand = Math.max(1, customerDailyDemand || 850);
  const taktTimeSeconds = Number((netOperatingSeconds / demand).toFixed(2));
  const leadTimeDemand = Math.round(demand * (leadTimeDays || 3));
  const varianceTerm = ((leadTimeDays || 3) * (demandVariance || 120)) + (Math.pow(demand, 2) * (leadTimeVariance || 0.2));
  const safetyStockUnits = Math.ceil((serviceLevelZScore || 2.33) * Math.sqrt(Math.max(0, varianceTerm)));
  const reorderPointUnits = leadTimeDemand + safetyStockUnits;
  const containerCap = Math.max(1, containerCapacity || 12);
  const recommendedKanbanCards = Math.ceil((leadTimeDemand + safetyStockUnits) / containerCap);

  res.json({
    taktTimeSeconds,
    leadTimeDemand,
    safetyStockUnits,
    reorderPointUnits,
    recommendedKanbanCards,
    dailyHeijunkaPitchMinutes: Number(((taktTimeSeconds * containerCap) / 60).toFixed(2))
  });
});

app.post('/api/ai/kaizen-analyze', async (req, res): Promise<void> => {
  const { problemDescription, wasteType } = req.body;
  const apiKey = process.env['GEMINI_API_KEY'];

  if (apiKey) {
    try {
      const ai = new GoogleGenAI({ apiKey });
      const prompt = `You are a Principal Toyota Production System (TPS) / Kaizen Master Engineer.
Analyze this manufacturing abnormality and provide a disciplined 5-Whys root cause analysis, an engineered Poka-Yoke / Karakuri countermeasure, and realistic quantitative impacts.

Problem Description: "${problemDescription || 'Intermittent torque sensor calibration drift causing line stops.'}"
Target Waste Category (Muda): "${wasteType || 'DEFECTS'}"

Respond strictly in valid JSON format with this exact schema:
{
  "rootCauses5Whys": [
    "1. Why did ...",
    "2. Why ...",
    "3. Why ...",
    "4. Why ...",
    "5. Why ..."
  ],
  "suggestedCountermeasure": "string",
  "expectedCycleTimeReductionSec": number,
  "expectedAnnualSavingsUsd": number,
  "confidenceScore": number
}`;

      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
        config: {
          responseMimeType: 'application/json'
        }
      });

      if (response.text) {
        const parsed = JSON.parse(response.text);
        res.json(parsed);
        return;
      }
    } catch (err) {
      console.warn('Gemini API call encountered error, using deterministic TPS heuristic fallback:', err);
    }
  }

  // Deterministic Fallback if API key not configured or call fails
  res.json({
    rootCauses5Whys: [
      `1. Why did the line stop? -> Station torque tool registered out-of-spec deviation on ${wasteType || 'DEFECTS'} cycle.`,
      `2. Why was there a deviation? -> Dynamic vibration at the articulated robotic end-effector shifted transducer zero point.`,
      `3. Why did vibration shift zero point? -> Standard mounting bracket lacked anti-harmonic dampening pads.`,
      `4. Why lacked dampening? -> Initial line commissioning used standard rigid steel adapter.`,
      `5. Why standard rigid adapter? -> Standard Work Sheet did not prescribe dynamic dampening spec for high-torque fastening.`
    ],
    suggestedCountermeasure: 'Install composite vibration isolation collar and update Standard Work Combination Sheet with daily calibration verification.',
    expectedCycleTimeReductionSec: 3.5,
    expectedAnnualSavingsUsd: 54000,
    confidenceScore: 0.94
  });
});

/**
 * Serve static files from /browser
 */
app.use(
  express.static(browserDistFolder, {
    maxAge: '1y',
    index: false,
    redirect: false,
  }),
);

/**
 * Handle all other requests by rendering the Angular application.
 */
app.use((req, res, next) => {
  angularApp
    .handle(req)
    .then((response) =>
      response ? writeResponseToNodeResponse(response, res) : next(),
    )
    .catch(next);
});

/**
 * Start the server if this module is the main entry point, or it is ran via PM2.
 * The server listens on the port defined by the `PORT` environment variable, or defaults to 4000.
 */
if (isMainModule(import.meta.url) || process.env['pm_id']) {
  const port = process.env['PORT'] || 4000;
  app.listen(port, (error) => {
    if (error) {
      throw error;
    }

    console.log(`Node Express server listening on http://localhost:${port}`);
  });
}

/**
 * Request handler used by the Angular CLI (for dev-server and during build) or Firebase Cloud Functions.
 */
export const reqHandler = createNodeRequestHandler(app);
