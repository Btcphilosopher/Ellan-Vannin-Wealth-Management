package com.example.core.ai

import com.example.core.database.CachedProduct
import com.example.core.database.CachedSupplier
import com.example.core.database.DbPriceTier
import com.example.core.database.DbCustomisationOption
import com.example.core.localization.Language
import com.example.core.localization.LocalizationManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.Calendar

data class AssistantReply(
    val messageEn: String,
    val messageZh: String,
    val suggestedRFQ: DraftRFQ? = null,
    val matchedProductIds: List<String> = emptyList(),
    val sourceOfTruth: String = "SYNTHETIC MARKETPLACE INDEX",
    val confidence: Int = 95
)

data class DraftRFQ(
    val productTitle: String,
    val quantity: Int,
    val targetPrice: Double?,
    val destination: String,
    val deliveryDate: String,
    val specifications: String,
    val notes: String?
)

object SourcingAssistantService {

    suspend fun processQuery(
        query: String,
        availableProducts: List<CachedProduct>,
        availableSuppliers: List<CachedSupplier>
    ): AssistantReply = withContext(Dispatchers.Default) {
        val qLower = query.lowercase(Locale.US).trim()
        
        // Let's implement robust NLP heuristics to parse query intent
        // Check if user is trying to "post RFQ" or "draft RFQ" or says words like "need", "purchase", "order", "buy", "rfq"
        val isRFQIntent = qLower.contains("need") || qLower.contains("buy") || 
                          qLower.contains("purchase") || qLower.contains("rfq") || 
                          qLower.contains("询价") || qLower.contains("采购") || 
                          qLower.contains("需要") || qLower.contains("想要")

        if (isRFQIntent) {
            // NLP Entity Extraction
            // Parse Quantity (look for numbers)
            val qtyRegex = "([0-9,]+)\\s*(pcs|units|pieces|件|套|个|tonnes|tons|kg)?".toRegex()
            val matchResult = qtyRegex.find(qLower)
            val parsedQty = matchResult?.groupValues?.get(1)?.replace(",", "")?.toIntOrNull() ?: 5000
            
            // Parse Product Name
            var parsedProductEn = "Custom B2B Product"
            var parsedProductZh = "自定义工业产品"
            
            val matchesWaterBottle = qLower.contains("bottle") || qLower.contains("water") || qLower.contains("瓶") || qLower.contains("水瓶") || qLower.contains("不锈钢")
            val matchesSolar = qLower.contains("solar") || qLower.contains("panel") || qLower.contains("太阳能") || qLower.contains("光伏") || qLower.contains("光伏板")
            val matchesPump = qLower.contains("pump") || qLower.contains("pumps") || qLower.contains("泵") || qLower.contains("水泵")
            val matchesFabric = qLower.contains("fabric") || qLower.contains("textile") || qLower.contains("cotton") || qLower.contains("面料") || qLower.contains("织物") || qLower.contains("棉")

            var matchedProd: CachedProduct? = null
            when {
                matchesWaterBottle -> {
                    parsedProductEn = "Stainless Steel Water Bottles"
                    parsedProductZh = "不锈钢保温水瓶"
                    matchedProd = availableProducts.find { it.id == "prod_01" }
                }
                matchesSolar -> {
                    parsedProductEn = "Monocrystalline Solar Panels"
                    parsedProductZh = "单晶硅太阳能光伏板"
                    matchedProd = availableProducts.find { it.id == "prod_02" }
                }
                matchesPump -> {
                    parsedProductEn = "Centrifugal Industrial Water Pumps"
                    parsedProductZh = "重型工业级离心水泵"
                    matchedProd = availableProducts.find { it.id == "prod_03" }
                }
                matchesFabric -> {
                    parsedProductEn = "Organic Cotton Combed Fabric"
                    parsedProductZh = "有机棉针织精梳面料"
                    matchedProd = availableProducts.find { it.id == "prod_04" }
                }
            }

            // Parse destination (look for locations)
            var parsedDestination = "Los Angeles, CA"
            if (qLower.contains("london") || qLower.contains("uk") || qLower.contains("英国") || qLower.contains("伦敦")) {
                parsedDestination = "London Port, UK"
            } else if (qLower.contains("germany") || qLower.contains("hamburg") || qLower.contains("德国") || qLower.contains("汉堡")) {
                parsedDestination = "Hamburg Port, DE"
            } else if (qLower.contains("shanghai") || qLower.contains("上海")) {
                parsedDestination = "Shanghai Port, CN"
            }

            // Target price calculation based on catalog if matched
            val targetPrice = matchedProd?.priceTiers?.firstOrNull()?.unitPrice ?: 2.50

            // Delivery date calculation (e.g. 45 days from now)
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, 45)
            val deadlineDateStr = "%d-%02d-%02d".format(
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH) + 1,
                cal.get(Calendar.DAY_OF_MONTH)
            )

            val draft = DraftRFQ(
                productTitle = if (LocalizationManager.currentLanguage.value == Language.ZH_CN) parsedProductZh else parsedProductEn,
                quantity = parsedQty,
                targetPrice = targetPrice,
                destination = parsedDestination,
                deliveryDate = deadlineDateStr,
                specifications = "Parsed from search requirement. Needs custom logo and export standard shipping wooden boxes.",
                notes = "Trade protection active. High volume inquiry."
            )

            return@withContext AssistantReply(
                messageEn = "I've processed your sourcing request and drafted a high-density RFQ for %s (Qty: %d). This is optimized based on audited factories capable of custom laser logo branding.".format(parsedProductEn, parsedQty),
                messageZh = "我已经分析了您的采购需求，并为您草拟了一份针对【%s】的询价单（采购数量：%d 件）。此采购方案已根据支持定制Logo的认证工厂进行了最优化配置。".format(parsedProductZh, parsedQty),
                suggestedRFQ = draft,
                matchedProductIds = matchedProd?.let { listOf(it.id) } ?: emptyList(),
                sourceOfTruth = "AI TRADE MATCH ENGINE",
                confidence = 98
            )
        }

        // Search comparison intent
        val isCompareIntent = qLower.contains("compare") || qLower.contains("vs") || 
                              qLower.contains("对比") || qLower.contains("比较") || 
                              qLower.contains("哪个好")

        if (isCompareIntent) {
            val replyEn = "I have compared the available catalog quotes for you:\n" +
                    "- Zhejiang Industrial (Stainless Bottle): $2.31 unit price, MOQ 1000, 12-day lead time.\n" +
                    "- Texas Valve & Pump (Centrifugal Pump): $720.00 unit price, MOQ 5, 30-day lead time.\n" +
                    "Zhejiang Industrial provides the fastest turnaround, while Texas Valve holds structural ASME certification."
            val replyZh = "我已经为您对比了相关的工厂报价方案：\n" +
                    "- 浙江工业采购（不锈钢水瓶）：单价 2.31 美元，起订量 1000 件，交期 12 天，支持贸易保障。\n" +
                    "- 德州阀门泵业（离心工业泵）：单价 720.00 美元，起订量 5 台，交期 30 天，支持 ASME 国际质检标准。\n" +
                    "浙江工业拥有最快发货优势，而德克萨斯工厂提供更坚固的高硬度不锈钢叶轮升级。"
            return@withContext AssistantReply(
                messageEn = replyEn,
                messageZh = replyZh,
                sourceOfTruth = "B2B QUOTE COMPARISON INDEX",
                confidence = 94
            )
        }

        // Default query: product or general recommendations
        val searchResults = com.example.core.search.SearchEngine.searchAndRank(query, availableProducts)
        if (searchResults.isNotEmpty()) {
            val best = searchResults.first()
            val prod = best.product
            
            val replyEn = "Based on your interest in '%s', I highly recommend **%s** from **%s**.\n" +
                    "Why? %s\n" +
                    "It has an MOQ of %d, with price breaks down to %s per piece for bulk volume."
                    .format(query, prod.nameEn, prod.nameEn, best.matchReasonsEn.joinToString(" "), prod.moq, LocalizationManager.formatCurrency(prod.priceTiers.last().unitPrice))

            val replyZh = "根据您对“%s”的兴趣，我强烈推荐您查看来自 **%s** 的 **%s**。\n" +
                    "推荐原由：%s\n" +
                    "该产品起订量为 %d，大批量订购单价可低至每件 %s 美元。"
                    .format(query, prod.nameZh, prod.nameZh, best.matchReasonsZh.joinToString(" "), prod.moq, LocalizationManager.formatCurrency(prod.priceTiers.last().unitPrice))

            return@withContext AssistantReply(
                messageEn = replyEn,
                messageZh = replyZh,
                matchedProductIds = searchResults.map { it.product.id },
                sourceOfTruth = "SEARCH ENGINE MATCH SERVICE",
                confidence = best.score.coerceIn(50, 99)
            )
        }

        // Generic friendly reply
        return@withContext AssistantReply(
            messageEn = "I'm searching the Global B2B Catalog for '%s'. Please try queries like 'stainless bottle', 'solar panel 550W', or 'industrial water pump' to view full sample RFQ, Quote Negotiation, Production Inspection, Escrow Pay, and Maritime Tracking flows!".format(query),
            messageZh = "我正在为您检索关于“%s”的全球商品库。您可以输入例如“不锈钢水瓶”、“太阳能板”、“工业水泵”等关键词，体验完整的询价(RFQ)、价格谈判、出厂质检、受代管保护的安全支付以及航运物流实时追踪流程！".format(query),
            sourceOfTruth = "GLOBAL DIRECTORY INDEX",
            confidence = 80
        )
    }

    fun translateMessage(text: String, targetLanguage: Language): String {
        val dict = mapOf(
            "Hello, we are interested in purchasing 5,000 units. Please provide details on packaging customisation and sample cost." to 
                "您好，我们对采购5,000件产品感兴趣。请提供有关定制包装以及样品费用的详细信息。",
            "We can provide customised packaging for 5,000 units." to 
                "我们可以提供5000件的定制包装。",
            "We need an estimate for 10 units of the centrifugal water pump delivered to Los Angeles." to 
                "我们需要一份运往洛杉矶的10台离心水泵的估价。",
            "Please confirm the required voltage configuration for the motor." to 
                "请确认电机所需的电压配置。",
            "We plan to purchase 5,000 750ml stainless steel water bottles. Please provide a quotation including custom logo, packaging and shipping to Los Angeles." to
                "我们计划采购5,000件750ml不锈钢水瓶，请提供定制Logo、包装和运往洛杉矶的报价。"
        )

        // Reverse map for Chinese -> English
        val reverseDict = dict.entries.associateBy({ it.value }) { it.key }

        return if (targetLanguage == Language.ZH_CN) {
            dict[text] ?: reverseDict[text] ?: "[Automatic Translation En -> Zh]: $text"
        } else {
            reverseDict[text] ?: dict[text] ?: "[Automatic Translation Zh -> En]: $text"
        }
    }
}
