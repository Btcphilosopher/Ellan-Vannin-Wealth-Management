package com.example.core.search

import com.example.core.database.CachedProduct
import java.util.Locale

enum class DetectedLanguage {
    EN, ZH, MIXED
}

data class RankedResult(
    val product: CachedProduct,
    val score: Int,
    val matchReasonsEn: List<String>,
    val matchReasonsZh: List<String>
)

object SearchEngine {

    fun detectLanguage(query: String): DetectedLanguage {
        var hasChinese = false
        var hasEnglish = false
        for (char in query) {
            if (char.code in 0x4E00..0x9FFF) {
                hasChinese = true
            } else if (char.isLetter()) {
                hasEnglish = true
            }
        }
        return when {
            hasChinese && hasEnglish -> DetectedLanguage.MIXED
            hasChinese -> DetectedLanguage.ZH
            else -> DetectedLanguage.EN
        }
    }

    fun expandQuery(query: String): List<String> {
        val normalized = query.lowercase(Locale.US).trim()
        val expansions = mutableListOf(normalized)

        // Bi-directional expansion mapping dictionary
        val dictionary = mapOf(
            "water bottle" to listOf("水瓶", "不锈钢水瓶", "bottle"),
            "stainless steel" to listOf("不锈钢", "不锈钢水瓶", "stainless"),
            "bottle" to listOf("水瓶", "瓶子", "杯子"),
            "solar panel" to listOf("太阳能", "光伏板", "太阳能板", "solar"),
            "solar" to listOf("太阳能", "光伏"),
            "battery" to listOf("电池", "锂电池", "蓄电池"),
            "pump" to listOf("水泵", "泵", "离心泵"),
            "water pump" to listOf("水泵", "泵", "工业泵"),
            "centrifugal pump" to listOf("离心泵", "水泵"),
            "fabric" to listOf("面料", "针织", "有机棉", "织物"),
            "cotton" to listOf("棉", "有机棉", "棉花"),
            "apparel" to listOf("服装", "成衣", "纺织"),
            
            // Chinese keys
            "不锈钢" to listOf("stainless steel", "stainless"),
            "水瓶" to listOf("water bottle", "bottle"),
            "太阳能" to listOf("solar panel", "solar"),
            "光伏板" to listOf("solar panel", "photovoltaic"),
            "太阳能板" to listOf("solar panel", "solar"),
            "电池" to listOf("battery", "lithium battery"),
            "水泵" to listOf("water pump", "industrial pump", "pump"),
            "泵" to listOf("pump", "water pump"),
            "离心泵" to listOf("centrifugal pump", "pump"),
            "面料" to listOf("fabric", "cotton fabric"),
            "棉" to listOf("cotton", "organic cotton"),
            "有机棉" to listOf("organic cotton", "cotton"),
            "服装" to listOf("apparel", "textile")
        )

        for ((keyword, synonyms) in dictionary) {
            if (normalized.contains(keyword) || keyword.contains(normalized)) {
                expansions.addAll(synonyms)
            }
        }
        return expansions.distinct()
    }

    fun searchAndRank(query: String, products: List<CachedProduct>): List<RankedResult> {
        if (query.isBlank()) {
            return products.map {
                RankedResult(
                    product = it,
                    score = 100,
                    matchReasonsEn = listOf("Recommended because of high supplier rating and lead time."),
                    matchReasonsZh = listOf("因商家高评分及稳定发货时效而推荐。")
                )
            }
        }

        val expandedTerms = expandQuery(query)
        val rankedList = mutableListOf<RankedResult>()

        for (product in products) {
            var score = 0
            val reasonsEn = mutableListOf<String>()
            val reasonsZh = mutableListOf<String>()

            val pNameEn = product.nameEn.lowercase(Locale.US)
            val pNameZh = product.nameZh.lowercase(Locale.CHINESE)
            val pDescEn = product.descriptionEn.lowercase(Locale.US)
            val pDescZh = product.descriptionZh.lowercase(Locale.CHINESE)
            val pCategoryEn = product.categoryEn.lowercase(Locale.US)
            val pCategoryZh = product.categoryZh.lowercase(Locale.CHINESE)

            var matchedTermCount = 0
            for (term in expandedTerms) {
                val tLower = term.lowercase(Locale.US)
                val isEnMatch = pNameEn.contains(tLower) || pDescEn.contains(tLower) || pCategoryEn.contains(tLower)
                val isZhMatch = pNameZh.contains(tLower) || pDescZh.contains(tLower) || pCategoryZh.contains(tLower)

                if (isEnMatch || isZhMatch) {
                    matchedTermCount++
                    score += 50
                    if (pNameEn.contains(tLower) || pNameZh.contains(tLower)) {
                        score += 30 // Extra weight for title match
                    }
                }
            }

            if (score > 0) {
                // Add factor scoring
                if (product.isVerifiedSupplier) {
                    score += 20
                    reasonsEn.add("Verified Supplier status")
                    reasonsZh.add("金牌验厂商家认证")
                }
                if (product.isTradeProtection) {
                    score += 15
                    reasonsEn.add("Trade Protection available")
                    reasonsZh.add("支持官方贸易代管保障")
                }
                if (product.rating >= 4.7) {
                    score += 10
                    reasonsEn.add("Excellent supplier rating (%.1f/5)".format(product.rating))
                    reasonsZh.add("供应商高评分 (%.1f级)".format(product.rating))
                }

                // Compile Explainable Rank Description
                val detected = detectLanguage(query)
                val searchLanguageTextEn = if (detected == DetectedLanguage.ZH) "Chinese query terms" else "English query terms"
                val searchLanguageTextZh = if (detected == DetectedLanguage.ZH) "中文关键词" else "英文关键词"

                val finalReasonsEn = mutableListOf(
                    "Matches %d terms of your query (%s).".format(matchedTermCount, searchLanguageTextEn)
                )
                finalReasonsEn.addAll(reasonsEn)

                val finalReasonsZh = mutableListOf(
                    "与您的检索条件（%s）匹配了 %d 个匹配项。".format(searchLanguageTextZh, matchedTermCount)
                )
                finalReasonsZh.addAll(reasonsZh)

                rankedList.add(
                    RankedResult(
                        product = product,
                        score = score,
                        matchReasonsEn = finalReasonsEn,
                        matchReasonsZh = finalReasonsZh
                    )
                )
            }
        }

        // Sort by score descending
        return rankedList.sortedByDescending { it.score }
    }
}
