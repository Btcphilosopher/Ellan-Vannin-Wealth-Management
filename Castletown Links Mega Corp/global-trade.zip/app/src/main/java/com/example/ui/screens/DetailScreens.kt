@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.ui.screens

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.core.database.*
import com.example.core.localization.Language
import com.example.core.localization.LocalizationManager
import com.example.ui.theme.*
import kotlinx.coroutines.launch

@Composable
fun ProductDetailScreen(
    productId: String,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onNavigateToSupplier: (String) -> Unit,
    onOpenChat: (String) -> Unit
) {
    val currentLang by viewModel.currentLanguage.collectAsState()
    val productsList by viewModel.products.collectAsState()
    val suppliersList by viewModel.suppliers.collectAsState()

    val product = productsList.find { it.id == productId } ?: return
    val supplier = suppliersList.find { it.id == product.supplierId }

    val scrollState = rememberScrollState()
    val coroutineScope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (currentLang == Language.ZH_CN) "商品详情" else "Product Details", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("product_detail_back")) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            Surface(
                color = Color.White,
                tonalElevation = 8.dp,
                modifier = Modifier.navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Contact Supplier Chat Action (min 48.dp)
                    OutlinedButton(
                        onClick = {
                            val convId = "conv_${product.supplierId}"
                            viewModel.selectConversation(convId)
                            // Pre-inject a system inquiry message context
                            viewModel.sendMessage(
                                text = if (currentLang == Language.ZH_CN) "您好，我想了解更多关于该产品的定制选项和MOQ价格。" else "Hello, I want to learn more about the customization options and bulk price of this item.",
                                productRefId = product.id
                            )
                            onOpenChat(convId)
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("chat_supplier_button"),
                        border = BorderStroke(1.dp, PrimaryOrange),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = PrimaryOrange)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (currentLang == Language.ZH_CN) "联系商家" else "Chat Now", color = PrimaryOrange, fontWeight = FontWeight.Bold)
                    }

                    // Direct sample Purchase order contract (min 48.dp)
                    Button(
                        onClick = {
                            val orderId = "GT-${(10000..99999).random()}"
                            val sampleOrder = CachedOrder(
                                id = orderId,
                                productId = product.id,
                                productNameEn = "SAMPLE: " + product.nameEn,
                                productNameZh = "测试样品: " + product.nameZh,
                                productImageUrl = product.imageUrl,
                                supplierId = product.supplierId,
                                supplierNameEn = supplier?.displayNameEn ?: "Global Factory",
                                supplierNameZh = supplier?.displayNameZh ?: "全球金牌工厂",
                                quantity = 1,
                                unit = "piece",
                                unitPrice = product.samplePrice,
                                currency = "USD",
                                totalPrice = product.samplePrice + product.sampleShippingCost,
                                status = "PAYMENT_PENDING",
                                productionStatus = "NOT_STARTED",
                                isTradeProtected = true,
                                dateCreated = System.currentTimeMillis()
                            )
                            viewModel.createOrder(sampleOrder)
                            viewModel.selectOrder(orderId)
                            onOpenChat(orderId) // navigate to payment workflow
                        },
                        modifier = Modifier
                            .weight(1.2f)
                            .height(48.dp)
                            .testTag("order_sample_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.LocalShipping, contentDescription = null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (currentLang == Language.ZH_CN) "快捷拿样" else "Request Sample", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(scrollState)
                .background(BackgroundWarmWhite)
                .padding(16.dp)
        ) {
            // Main Image
            AsyncImage(
                model = product.imageUrl,
                contentDescription = "Main product image",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(LightGrey),
                contentScale = ContentScale.Crop
            )
            Spacer(modifier = Modifier.height(16.dp))

            // Brand Rating Tag row
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Star, contentDescription = "Rating", tint = GoldAmber, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "${product.rating}", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.width(12.dp))
                if (product.isVerifiedSupplier) {
                    Surface(shape = RoundedCornerShape(2.dp), color = OrangeSoft) {
                        Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = PrimaryOrange, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(if (currentLang == Language.ZH_CN) "金牌验厂商家" else "Verified Factory", fontSize = 9.sp, color = PrimaryOrange, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))

            // Title
            Text(
                text = if (currentLang == Language.ZH_CN) product.nameZh else product.nameEn,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = DeepCharcoal
            )
            Spacer(modifier = Modifier.height(12.dp))

            // Pricing Tiers (Side-by-Side Table)
            Text(
                text = if (currentLang == Language.ZH_CN) "起订量及阶梯批发价" else "Wholesale Pricing Tiers",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = DeepCharcoal,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                border = BorderStroke(1.dp, BorderGrey),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(if (currentLang == Language.ZH_CN) "采购范围" else "Volume Range", fontSize = 11.sp, color = SteelGrey, fontWeight = FontWeight.Bold)
                        Text(if (currentLang == Language.ZH_CN) "离岸单价 (FOB)" else "FOB Unit Price", fontSize = 11.sp, color = SteelGrey, fontWeight = FontWeight.Bold)
                    }
                    Divider(color = BorderGrey, modifier = Modifier.padding(vertical = 6.dp))

                    for (tier in product.priceTiers) {
                        val rangeLabel = if (tier.maxQty == 99999) "${tier.minQty}+ pcs" else "${tier.minQty} - ${tier.maxQty} pcs"
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(rangeLabel, fontSize = 13.sp, color = DeepCharcoal, fontWeight = FontWeight.Medium)
                            Text(LocalizationManager.formatCurrency(tier.unitPrice), fontSize = 14.sp, color = PrimaryOrange, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Specs
            Text(
                text = if (currentLang == Language.ZH_CN) "商品技术指标规格" else "Technical Specifications",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = DeepCharcoal,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                border = BorderStroke(1.dp, BorderGrey),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    val specMap = if (currentLang == Language.ZH_CN) product.specZh else product.specEn
                    for ((key, value) in specMap) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(key, fontSize = 12.sp, color = SteelGrey)
                            Text(value, fontSize = 12.sp, color = DeepCharcoal, fontWeight = FontWeight.SemiBold)
                        }
                        Divider(color = LightGrey)
                    }
                }
            }

            // Customization rules
            Text(
                text = if (currentLang == Language.ZH_CN) "可定制包装与Logo方案" else "Bespoke Customisation Rules",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = DeepCharcoal,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            for (opt in product.customisationOptions) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderGrey)
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = if (currentLang == Language.ZH_CN) opt.nameZh else opt.nameEn,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = DarkNavy
                        )
                        Text(
                            text = if (currentLang == Language.ZH_CN) opt.descriptionZh else opt.descriptionEn,
                            fontSize = 11.sp,
                            color = SteelGrey
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = if (currentLang == Language.ZH_CN) "最低定制数: ${opt.minQty} 件" else "Min Custom Qty: ${opt.minQty} pcs",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "+${LocalizationManager.formatCurrency(opt.additionalCost)} / pc",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryOrange
                            )
                        }
                    }
                }
            }

            // AI Recommendations explainer
            Spacer(modifier = Modifier.height(10.dp))
            Surface(
                color = NavySoft,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Psychology, contentDescription = null, tint = DarkNavy, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (currentLang == Language.ZH_CN) "为什么向您推荐这款产品?" else "Why Sourcing AI recommends this?",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = DarkNavy
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (currentLang == Language.ZH_CN) product.whyRecommendedZh else product.whyRecommendedEn,
                        fontSize = 11.sp,
                        color = DeepCharcoal
                    )
                }
            }
        }
    }
}

@Composable
fun SupplierDetailScreen(
    supplierId: String,
    viewModel: MainViewModel,
    onBack: () -> Unit,
    onNavigateToProduct: (String) -> Unit
) {
    val currentLang by viewModel.currentLanguage.collectAsState()
    val suppliersList by viewModel.suppliers.collectAsState()
    val productsList by viewModel.products.collectAsState()

    val supplier = suppliersList.find { it.id == supplierId } ?: return
    val associatedProducts = productsList.filter { it.supplierId == supplierId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (currentLang == Language.ZH_CN) "工厂实力主页" else "Supplier Verification", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.followSupplier(supplier.id, !supplier.isFollowed) }) {
                        Icon(
                            imageVector = if (supplier.isFollowed) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Follow",
                            tint = if (supplier.isFollowed) RestrainedRed else SteelGrey
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .background(BackgroundWarmWhite)
                .padding(16.dp)
        ) {
            // Header Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkNavy),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (currentLang == Language.ZH_CN) supplier.countryZh else supplier.countryEn,
                            color = PrimaryOrange,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(shape = RoundedCornerShape(2.dp), color = EscrowGreen) {
                            Text(
                                text = supplier.verificationStatus,
                                fontSize = 8.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = if (currentLang == Language.ZH_CN) supplier.legalNameZh else supplier.legalNameEn,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (currentLang == Language.ZH_CN) supplier.factoryTypeZh else supplier.factoryTypeEn,
                        color = SteelGrey,
                        fontSize = 12.sp
                    )
                }
            }

            // Stats matrix
            Text(
                text = if (currentLang == Language.ZH_CN) "商务合作及服务时效指标" else "B2B Performance Metrics",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = DeepCharcoal,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                border = BorderStroke(1.dp, BorderGrey),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (currentLang == Language.ZH_CN) "回复时效" else "Response", fontSize = 10.sp, color = SteelGrey)
                        Text(if (currentLang == Language.ZH_CN) supplier.responseTimeZh else supplier.responseTimeEn, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (currentLang == Language.ZH_CN) "信息反馈率" else "Response Rate", fontSize = 10.sp, color = SteelGrey)
                        Text("${supplier.responseRate}%", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = EscrowGreen)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (currentLang == Language.ZH_CN) "累计交单数" else "Orders Done", fontSize = 10.sp, color = SteelGrey)
                        Text("${supplier.ordersCompleted}+", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Certifications
            Text(
                text = if (currentLang == Language.ZH_CN) "工厂合规认证体系 (ISO/CE)" else "Compliance Certifications (SGS Verified)",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = DeepCharcoal,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 16.dp)
            ) {
                for (cert in supplier.certifications) {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = GreenSoft,
                        border = BorderStroke(1.dp, EscrowGreen.copy(alpha = 0.5f))
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = EscrowGreen, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(cert, fontSize = 12.sp, color = EscrowGreen, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            // Products list
            Text(
                text = if (currentLang == Language.ZH_CN) "该工厂生产的系列商品" else "Products Manufactured",
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = DeepCharcoal,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            for (p in associatedProducts) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp)
                        .clickable { onNavigateToProduct(p.id) },
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderGrey)
                ) {
                    Row(modifier = Modifier.padding(10.dp)) {
                        AsyncImage(
                            model = p.imageUrl,
                            contentDescription = null,
                            modifier = Modifier
                                .size(70.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(LightGrey),
                            contentScale = ContentScale.Crop
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = if (currentLang == Language.ZH_CN) p.nameZh else p.nameEn,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "MOQ: ${p.moq} pcs",
                                fontSize = 11.sp,
                                color = SteelGrey
                            )
                            Text(
                                text = LocalizationManager.formatCurrency(p.priceTiers.last().unitPrice),
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = PrimaryOrange
                            )
                        }
                    }
                }
            }
        }
    }
}
