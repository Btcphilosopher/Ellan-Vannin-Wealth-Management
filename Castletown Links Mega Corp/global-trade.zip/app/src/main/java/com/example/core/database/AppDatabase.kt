package com.example.core.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [
        CachedSupplier::class,
        CachedProduct::class,
        CachedConversation::class,
        CachedMessage::class,
        CachedRFQ::class,
        CachedQuote::class,
        CachedOrder::class,
        CachedShipment::class,
        CachedInspection::class,
        CachedDispute::class,
        UserPreferencesEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(AppTypeConverters::class)
abstract class AppDatabase : RoomDatabase() {

    abstract fun supplierDao(): SupplierDao
    abstract fun productDao(): ProductDao
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun rfqDao(): RFQDao
    abstract fun quoteDao(): QuoteDao
    abstract fun orderDao(): OrderDao
    abstract fun shipmentDao(): ShipmentDao
    abstract fun inspectionDao(): InspectionDao
    abstract fun disputeDao(): DisputeDao
    abstract fun userPreferencesDao(): UserPreferencesDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "global_trade_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
