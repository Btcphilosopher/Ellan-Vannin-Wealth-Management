package com.example.core.database

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class TradeRepository(private val context: Context) {
    private val database = AppDatabase.getDatabase(context)
    
    private val supplierDao = database.supplierDao()
    private val productDao = database.productDao()
    private val conversationDao = database.conversationDao()
    private val messageDao = database.messageDao()
    private val rfqDao = database.rfqDao()
    private val quoteDao = database.quoteDao()
    private val orderDao = database.orderDao()
    private val shipmentDao = database.shipmentDao()
    private val inspectionDao = database.inspectionDao()
    private val disputeDao = database.disputeDao()
    private val userPreferencesDao = database.userPreferencesDao()

    init {
        // We will seed the database in a coroutine block if needed.
        // Usually, the caller or a startup event triggers this, 
        // but we can also safely check it asynchronously.
    }

    suspend fun seedDatabaseIfNeeded() {
        SyntheticDataSeeder.seedIfNeeded(context, database)
    }

    // --- Supplier API ---
    fun getSuppliers(): Flow<List<CachedSupplier>> = supplierDao.getAllSuppliers()
    fun getSupplierById(id: String): Flow<CachedSupplier?> = supplierDao.getSupplierById(id)
    suspend fun getSupplierByIdOneShot(id: String): CachedSupplier? = supplierDao.getSupplierByIdOneShot(id)
    suspend fun updateSupplierFollowStatus(id: String, followed: Boolean) {
        supplierDao.updateFollowStatus(id, followed)
    }

    // --- Product API ---
    fun getProducts(): Flow<List<CachedProduct>> = productDao.getAllProducts()
    fun getProductById(id: String): Flow<CachedProduct?> = productDao.getProductById(id)
    suspend fun getProductByIdOneShot(id: String): CachedProduct? = productDao.getProductByIdOneShot(id)
    fun getProductsBySupplier(supplierId: String): Flow<List<CachedProduct>> = productDao.getProductsBySupplier(supplierId)

    // --- Conversation & Messages API ---
    fun getConversations(): Flow<List<CachedConversation>> = conversationDao.getAllConversations()
    fun getMessages(conversationId: String): Flow<List<CachedMessage>> = messageDao.getMessagesForConversation(conversationId)
    
    suspend fun insertMessage(message: CachedMessage) {
        messageDao.insertMessage(message)
        // Check if conversation exists
        val existingConv = conversationDao.getConversationById(message.conversationId)
        if (existingConv == null) {
            // Find supplier info to build conversation info
            val supplier = supplierDao.getSupplierByIdOneShot(message.conversationId.replace("conv_", ""))
            if (supplier != null) {
                conversationDao.insertConversation(
                    CachedConversation(
                        id = message.conversationId,
                        supplierId = supplier.id,
                        supplierNameEn = supplier.displayNameEn,
                        supplierNameZh = supplier.displayNameZh,
                        lastMessageText = message.originalText,
                        lastMessageTime = message.timestamp,
                        unreadCount = 0
                    )
                )
            }
        } else {
            // Update last message in existing conversation
            conversationDao.updateLastMessage(
                id = message.conversationId,
                text = message.originalText,
                time = message.timestamp,
                unreadAdd = if (message.senderType == "SUPPLIER") 1 else 0
            )
        }
    }

    suspend fun markConversationAsRead(conversationId: String) {
        conversationDao.markAsRead(conversationId)
    }

    // --- RFQ API ---
    fun getRFQs(): Flow<List<CachedRFQ>> = rfqDao.getAllRFQs()
    fun getRFQById(id: String): Flow<CachedRFQ?> = rfqDao.getRFQById(id)
    
    suspend fun postRFQ(rfq: CachedRFQ) {
        rfqDao.insertRFQ(rfq)
        
        // Auto-generate realistic quotes matching this RFQ from matching suppliers after a brief delay
        // We simulate a responsive B2B platform!
        autoGenerateQuotesForRFQ(rfq)
    }

    private suspend fun autoGenerateQuotesForRFQ(rfq: CachedRFQ) {
        // Query suppliers
        val suppliers = getSuppliers().firstOrNull() ?: emptyList()
        val quotesToInsert = mutableListOf<CachedQuote>()
        
        // Determine product specific factors to adjust price quote slightly
        val multiplier = if (rfq.quantity >= 10000) 0.85 else if (rfq.quantity >= 5000) 0.90 else 1.0
        val baseUnitPrice = rfq.targetPrice ?: 2.50
        
        // Fictional response from 2 suppliers
        val matchedSuppliers = suppliers.take(3)
        var index = 1
        for (sup in matchedSuppliers) {
            val quotedPrice = (baseUnitPrice * multiplier * (0.95 + (index * 0.05)))
            val days = 10 + (index * 3)
            
            quotesToInsert.add(
                CachedQuote(
                    id = "q_auto_${rfq.id}_$index",
                    rfqId = rfq.id,
                    supplierId = sup.id,
                    supplierNameEn = sup.displayNameEn,
                    supplierNameZh = sup.displayNameZh,
                    unitPrice = quotedPrice,
                    moq = if (rfq.quantity > 1000) 1000 else rfq.quantity,
                    leadTimeDays = days,
                    sampleCost = 15.0 * index,
                    shippingCost = 100.0 * index,
                    toolingCost = 0.0,
                    validityPeriod = "30 Days",
                    paymentTermsEn = "30% Advance, 70% Balance in Secure Trade Protection Escrow",
                    paymentTermsZh = "30% 预付，70% 尾款代管资金保障",
                    incoterm = "FOB",
                    customisationEn = "Logo engraving & bulk packaging fully supported.",
                    customisationZh = "完全支持定制品牌雕刻及纸盒装箱。",
                    certificationsEn = sup.certifications.joinToString(", "),
                    certificationsZh = sup.certifications.joinToString(", "),
                    status = "SUBMITTED"
                )
            )
            index++
        }
        quoteDao.insertQuotes(quotesToInsert)
    }

    // --- Quotes API ---
    fun getQuotesForRFQ(rfqId: String): Flow<List<CachedQuote>> = quoteDao.getQuotesForRFQ(rfqId)
    fun getQuoteById(id: String): Flow<CachedQuote?> = quoteDao.getQuoteById(id)
    suspend fun updateQuote(quote: CachedQuote) {
        quoteDao.updateQuote(quote)
    }

    // --- Order API ---
    fun getOrders(): Flow<List<CachedOrder>> = orderDao.getAllOrders()
    fun getOrderById(id: String): Flow<CachedOrder?> = orderDao.getOrderById(id)
    suspend fun getOrderByIdOneShot(id: String): CachedOrder? = orderDao.getOrderByIdOneShot(id)
    
    suspend fun createOrder(order: CachedOrder) {
        orderDao.insertOrder(order)
    }

    suspend fun updateOrder(order: CachedOrder) {
        orderDao.updateOrder(order)
    }

    // --- Shipment API ---
    fun getShipmentForOrder(orderId: String): Flow<CachedShipment?> = shipmentDao.getShipmentForOrder(orderId)
    suspend fun getShipmentForOrderOneShot(orderId: String): CachedShipment? = shipmentDao.getShipmentForOrderOneShot(orderId)
    
    suspend fun createShipment(shipment: CachedShipment) {
        shipmentDao.insertShipment(shipment)
    }

    suspend fun updateShipment(shipment: CachedShipment) {
        shipmentDao.updateShipment(shipment)
    }

    // --- Inspection API ---
    fun getInspectionsForOrder(orderId: String): Flow<List<CachedInspection>> = inspectionDao.getInspectionsForOrder(orderId)

    // --- Dispute API ---
    fun getDisputeForOrder(orderId: String): Flow<CachedDispute?> = disputeDao.getDisputeForOrder(orderId)
    suspend fun createDispute(dispute: CachedDispute) {
        disputeDao.insertDispute(dispute)
    }
    suspend fun updateDispute(dispute: CachedDispute) {
        disputeDao.updateDispute(dispute)
    }

    // --- User Preferences API ---
    fun getUserPreferences(): Flow<UserPreferencesEntity?> = userPreferencesDao.getUserPreferences()
    suspend fun getUserPreferencesOneShot(): UserPreferencesEntity? = userPreferencesDao.getUserPreferencesOneShot()
    suspend fun updateUserPreferences(prefs: UserPreferencesEntity) {
        userPreferencesDao.insertUserPreferences(prefs)
    }
}
