package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.screens.*
import com.example.ui.theme.MyApplicationTheme

sealed class Screen {
    object Main : Screen()
    data class ProductDetail(val productId: String) : Screen()
    data class SupplierDetail(val supplierId: String) : Screen()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: MainViewModel = viewModel()
                
                // Light-weight, type-safe navigation backstack list
                val navigationStack = remember { mutableStateListOf<Screen>(Screen.Main) }
                val currentScreen = navigationStack.last()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    // Root screen router
                    when (currentScreen) {
                        is Screen.Main -> {
                            MainLayout(
                                viewModel = viewModel,
                                onNavigateToProduct = { pid ->
                                    navigationStack.add(Screen.ProductDetail(pid))
                                },
                                onNavigateToSupplier = { sid ->
                                    navigationStack.add(Screen.SupplierDetail(sid))
                                }
                            )
                        }
                        is Screen.ProductDetail -> {
                            ProductDetailScreen(
                                productId = currentScreen.productId,
                                viewModel = viewModel,
                                onBack = {
                                    if (navigationStack.size > 1) {
                                        navigationStack.removeAt(navigationStack.size - 1)
                                    }
                                },
                                onNavigateToSupplier = { sid ->
                                    navigationStack.add(Screen.SupplierDetail(sid))
                                },
                                onOpenChat = { targetId ->
                                    // Navigate back to main workspace context
                                    navigationStack.clear()
                                    navigationStack.add(Screen.Main)
                                }
                            )
                        }
                        is Screen.SupplierDetail -> {
                            SupplierDetailScreen(
                                supplierId = currentScreen.supplierId,
                                viewModel = viewModel,
                                onBack = {
                                    if (navigationStack.size > 1) {
                                        navigationStack.removeAt(navigationStack.size - 1)
                                    }
                                },
                                onNavigateToProduct = { pid ->
                                    navigationStack.add(Screen.ProductDetail(pid))
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
