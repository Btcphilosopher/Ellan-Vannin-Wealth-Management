package com.example.core.database

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers")
    fun getAllSuppliers(): Flow<List<CachedSupplier>>

    @Query("SELECT * FROM suppliers WHERE id = :id")
    fun getSupplierById(id: String): Flow<CachedSupplier?>

    @Query("SELECT * FROM suppliers WHERE id = :id")
    suspend fun getSupplierByIdOneShot(id: String): CachedSupplier?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSuppliers(suppliers: List<CachedSupplier>)

    @Update
    suspend fun updateSupplier(supplier: CachedSupplier)

    @Query("UPDATE suppliers SET isFollowed = :followed WHERE id = :id")
    suspend fun updateFollowStatus(id: String, followed: Boolean)
}

@Dao
interface ProductDao {
    @Query("SELECT * FROM products")
    fun getAllProducts(): Flow<List<CachedProduct>>

    @Query("SELECT * FROM products WHERE id = :id")
    fun getProductById(id: String): Flow<CachedProduct?>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getProductByIdOneShot(id: String): CachedProduct?

    @Query("SELECT * FROM products WHERE supplierId = :supplierId")
    fun getProductsBySupplier(supplierId: String): Flow<List<CachedProduct>>

    @Query("SELECT * FROM products WHERE categoryEn = :category OR categoryZh = :category")
    fun getProductsByCategory(category: String): Flow<List<CachedProduct>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<CachedProduct>)
}

@Dao
interface ConversationDao {
    @Query("SELECT * FROM conversations ORDER BY lastMessageTime DESC")
    fun getAllConversations(): Flow<List<CachedConversation>>

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun getConversationById(id: String): CachedConversation?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertConversation(conversation: CachedConversation)

    @Query("UPDATE conversations SET lastMessageText = :text, lastMessageTime = :time, unreadCount = unreadCount + :unreadAdd WHERE id = :id")
    suspend fun updateLastMessage(id: String, text: String, time: Long, unreadAdd: Int)

    @Query("UPDATE conversations SET unreadCount = 0 WHERE id = :id")
    suspend fun markAsRead(id: String)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun getMessagesForConversation(conversationId: String): Flow<List<CachedMessage>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: CachedMessage)
}

@Dao
interface RFQDao {
    @Query("SELECT * FROM rfqs ORDER BY dateCreated DESC")
    fun getAllRFQs(): Flow<List<CachedRFQ>>

    @Query("SELECT * FROM rfqs WHERE id = :id")
    fun getRFQById(id: String): Flow<CachedRFQ?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRFQ(rfq: CachedRFQ)

    @Update
    suspend fun updateRFQ(rfq: CachedRFQ)
}

@Dao
interface QuoteDao {
    @Query("SELECT * FROM quotes WHERE rfqId = :rfqId")
    fun getQuotesForRFQ(rfqId: String): Flow<List<CachedQuote>>

    @Query("SELECT * FROM quotes WHERE id = :id")
    fun getQuoteById(id: String): Flow<CachedQuote?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuotes(quotes: List<CachedQuote>)

    @Update
    suspend fun updateQuote(quote: CachedQuote)
}

@Dao
interface OrderDao {
    @Query("SELECT * FROM orders ORDER BY dateCreated DESC")
    fun getAllOrders(): Flow<List<CachedOrder>>

    @Query("SELECT * FROM orders WHERE id = :id")
    fun getOrderById(id: String): Flow<CachedOrder?>

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun getOrderByIdOneShot(id: String): CachedOrder?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: CachedOrder)

    @Update
    suspend fun updateOrder(order: CachedOrder)
}

@Dao
interface ShipmentDao {
    @Query("SELECT * FROM shipments WHERE orderId = :orderId")
    fun getShipmentForOrder(orderId: String): Flow<CachedShipment?>

    @Query("SELECT * FROM shipments WHERE orderId = :orderId")
    suspend fun getShipmentForOrderOneShot(orderId: String): CachedShipment?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShipment(shipment: CachedShipment)

    @Update
    suspend fun updateShipment(shipment: CachedShipment)
}

@Dao
interface InspectionDao {
    @Query("SELECT * FROM inspections WHERE orderId = :orderId")
    fun getInspectionsForOrder(orderId: String): Flow<List<CachedInspection>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInspections(inspections: List<CachedInspection>)
}

@Dao
interface DisputeDao {
    @Query("SELECT * FROM disputes WHERE orderId = :orderId")
    fun getDisputeForOrder(orderId: String): Flow<CachedDispute?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDispute(dispute: CachedDispute)

    @Update
    suspend fun updateDispute(dispute: CachedDispute)
}

@Dao
interface UserPreferencesDao {
    @Query("SELECT * FROM user_preferences WHERE id = 0")
    fun getUserPreferences(): Flow<UserPreferencesEntity?>

    @Query("SELECT * FROM user_preferences WHERE id = 0")
    suspend fun getUserPreferencesOneShot(): UserPreferencesEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUserPreferences(prefs: UserPreferencesEntity)
}
