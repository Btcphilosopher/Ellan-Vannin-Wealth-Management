@file:OptIn(ExperimentalMaterial3Api::class)

package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.core.database.*
import com.example.core.localization.Language
import com.example.core.localization.LocalizationManager
import com.example.ui.theme.*

// Root Layout state container
enum class ActiveTab {
    HOME, PRODUCTS, RFQ, CHAT, ASSISTANT, ORDERS
}

// Global Nav helper
@Composable
fun MainLayout(
    viewModel: MainViewModel,
    onNavigateToProduct: (String) -> Unit,
    onNavigateToSupplier: (String) -> Unit
) {
    var activeTab by remember { mutableStateOf(ActiveTab.HOME) }
    val currentLang by viewModel.currentLanguage.collectAsState()
    val rfqList by viewModel.rfqs.collectAsState()
    val orderList by viewModel.orders.collectAsState()
    val convsList by viewModel.conversations.collectAsState()
    
    // Unread count
    val unreadCount = convsList.sumOf { it.unreadCount }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = if (currentLang == Language.ZH_CN) "全球贸易" else "GLOBAL TRADE",
                            fontFamily = MaterialTheme.typography.titleLarge.fontFamily,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(top = 2.0.dp)
                        ) {
                            Text(
                                text = "B2B",
                                fontSize = 10.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }
                },
                actions = {
                    // Quick language toggle
                    Button(
                        onClick = { viewModel.toggleLanguage() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("lang_toggle_button")
                    ) {
                        Text(
                            text = if (currentLang == Language.ZH_CN) "English" else "中文",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.background,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = activeTab == ActiveTab.HOME,
                    onClick = { activeTab = ActiveTab.HOME },
                    icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                    label = { Text(if (currentLang == Language.ZH_CN) "工作台" else "Console") },
                    modifier = Modifier.testTag("nav_home")
                )
                NavigationBarItem(
                    selected = activeTab == ActiveTab.PRODUCTS,
                    onClick = { activeTab = ActiveTab.PRODUCTS },
                    icon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    label = { Text(if (currentLang == Language.ZH_CN) "搜商品" else "Sourcing") },
                    modifier = Modifier.testTag("nav_search")
                )
                NavigationBarItem(
                    selected = activeTab == ActiveTab.RFQ,
                    onClick = { activeTab = ActiveTab.RFQ },
                    icon = { Icon(Icons.Default.PostAdd, contentDescription = "RFQ") },
                    label = { Text(if (currentLang == Language.ZH_CN) "发布询价" else "RFQ") },
                    modifier = Modifier.testTag("nav_rfq")
                )
                NavigationBarItem(
                    selected = activeTab == ActiveTab.CHAT,
                    onClick = { activeTab = ActiveTab.CHAT },
                    icon = { 
                        BadgedBox(badge = {
                            if (unreadCount > 0) {
                                Badge(containerColor = RestrainedRed) { Text("$unreadCount") }
                            }
                        }) {
                            Icon(Icons.Default.ChatBubble, contentDescription = "Chat")
                        }
                    },
                    label = { Text(if (currentLang == Language.ZH_CN) "聊天" else "Messages") },
                    modifier = Modifier.testTag("nav_messages")
                )
                NavigationBarItem(
                    selected = activeTab == ActiveTab.ASSISTANT,
                    onClick = { activeTab = ActiveTab.ASSISTANT },
                    icon = { Icon(Icons.Default.Psychology, contentDescription = "AI") },
                    label = { Text(if (currentLang == Language.ZH_CN) "AI采购" else "AI Sourcing") },
                    modifier = Modifier.testTag("nav_ai")
                )
                NavigationBarItem(
                    selected = activeTab == ActiveTab.ORDERS,
                    onClick = { activeTab = ActiveTab.ORDERS },
                    icon = { Icon(Icons.Default.ReceiptLong, contentDescription = "Orders") },
                    label = { Text(if (currentLang == Language.ZH_CN) "订单" else "Orders") },
                    modifier = Modifier.testTag("nav_orders")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(BackgroundWarmWhite)
        ) {
            when (activeTab) {
                ActiveTab.HOME -> HomeConsoleScreen(
                    viewModel = viewModel,
                    onNavigateToProduct = onNavigateToProduct,
                    onQuickRFQ = { activeTab = ActiveTab.RFQ },
                    onNavigateToSupplier = onNavigateToSupplier
                )
                ActiveTab.PRODUCTS -> ProductSearchScreen(
                    viewModel = viewModel,
                    onNavigateToProduct = onNavigateToProduct
                )
                ActiveTab.RFQ -> RFQWorkspaceScreen(
                    viewModel = viewModel,
                    onSwitchToChat = { activeTab = ActiveTab.CHAT }
                )
                ActiveTab.CHAT -> ChatThreadsScreen(
                    viewModel = viewModel
                )
                ActiveTab.ASSISTANT -> AISourcingScreen(
                    viewModel = viewModel,
                    onNavigateToRFQ = { activeTab = ActiveTab.RFQ }
                )
                ActiveTab.ORDERS -> OrdersConsoleScreen(
                    viewModel = viewModel
                )
            }
        }
    }
}

// --- TAB 1: HOME CONSOLE ---
@Composable
fun HomeConsoleScreen(
    viewModel: MainViewModel,
    onNavigateToProduct: (String) -> Unit,
    onQuickRFQ: () -> Unit,
    onNavigateToSupplier: (String) -> Unit
) {
    val currentLang by viewModel.currentLanguage.collectAsState()
    val suppliersList by viewModel.suppliers.collectAsState()
    val productsList by viewModel.products.collectAsState()
    val ordersList by viewModel.orders.collectAsState()
    val rfqList by viewModel.rfqs.collectAsState()

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Business Hub Card
        Card(
            colors = CardDefaults.cardColors(containerColor = DarkNavy),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(
                    text = if (currentLang == Language.ZH_CN) "跨国采购工作台" else "GLOBAL SOURCING CONSOLE",
                    color = PrimaryOrange,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (currentLang == Language.ZH_CN) "Apex 采购有限公司" else "Apex Sourcing Ltd.",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(16.dp))

                // Stats row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    HomeStatItem(
                        value = "${ordersList.count { it.status == "PRODUCTION" }}",
                        label = if (currentLang == Language.ZH_CN) "生产中" else "In Production"
                    )
                    HomeStatItem(
                        value = "${rfqList.size}",
                        label = if (currentLang == Language.ZH_CN) "询价单" else "RFQ Posted"
                    )
                    HomeStatItem(
                        value = "${ordersList.count { it.status == "SHIPPED" || it.status == "IN_TRANSIT" }}",
                        label = if (currentLang == Language.ZH_CN) "在途海运" else "In Transit"
                    )
                    HomeStatItem(
                        value = LocalizationManager.formatCurrency(ordersList.sumOf { it.totalPrice }),
                        label = if (currentLang == Language.ZH_CN) "代管资金" else "Escrow Active"
                    )
                }
            }
        }

        // Quick Sourcing Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = onQuickRFQ,
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("quick_rfq_button")
            ) {
                Icon(Icons.Default.AddBusiness, contentDescription = "Add")
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (currentLang == Language.ZH_CN) "发布快速询价" else "Publish Fast RFQ",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
            }
        }

        // Top Suppliers Section
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = if (currentLang == Language.ZH_CN) "金牌验厂商家 (SGS认证)" else "Verified Top Suppliers (SGS)",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                color = DeepCharcoal
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp)
        ) {
            items(suppliersList) { supplier ->
                Card(
                    modifier = Modifier
                        .width(220.dp)
                        .clickable { onNavigateToSupplier(supplier.id) }
                        .testTag("supplier_card_${supplier.id}"),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderGrey)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (currentLang == Language.ZH_CN) supplier.countryZh else supplier.countryEn,
                                fontSize = 11.sp,
                                color = SteelGrey,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Surface(
                                shape = RoundedCornerShape(2.dp),
                                color = GreenSoft,
                                modifier = Modifier.padding(bottom = 1.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Icon(Icons.Default.Verified, contentDescription = "Verified", tint = EscrowGreen, modifier = Modifier.size(10.dp))
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = if (currentLang == Language.ZH_CN) "已验厂" else "Audited",
                                        fontSize = 8.sp,
                                        color = EscrowGreen,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (currentLang == Language.ZH_CN) supplier.displayNameZh else supplier.displayNameEn,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = DeepCharcoal
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (currentLang == Language.ZH_CN) supplier.factoryTypeZh else supplier.factoryTypeEn,
                            fontSize = 11.sp,
                            color = SteelGrey,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Divider(color = BorderGrey)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(if (currentLang == Language.ZH_CN) "响应率" else "Response", fontSize = 9.sp, color = SteelGrey)
                                Text("${supplier.responseRate}%", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = EscrowGreen)
                            }
                            Column {
                                Text(if (currentLang == Language.ZH_CN) "操作年限" else "Years", fontSize = 9.sp, color = SteelGrey)
                                Text("${supplier.yearsOperating} Yrs", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = DeepCharcoal)
                            }
                            Column {
                                Text(if (currentLang == Language.ZH_CN) "交易量" else "Orders", fontSize = 9.sp, color = SteelGrey)
                                Text("${supplier.ordersCompleted}+", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = PrimaryOrange)
                            }
                        }
                    }
                }
            }
        }

        // Recommended Products
        Text(
            text = if (currentLang == Language.ZH_CN) "推荐采购商品" else "Recommended Products",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = DeepCharcoal,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Simple Vertical Grid inside Scrollable using manual Column grouping
        val chunked = productsList.chunked(2)
        for (row in chunked) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                for (product in row) {
                    Box(modifier = Modifier.weight(1f)) {
                        ProductGridItem(
                            product = product,
                            currentLang = currentLang,
                            onClick = { onNavigateToProduct(product.id) }
                        )
                    }
                }
                if (row.size < 2) {
                    Spacer(modifier = Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
fun HomeStatItem(value: String, label: String) {
    Column {
        Text(text = value, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(text = label, fontSize = 10.sp, color = SteelGrey)
    }
}

// --- TAB 2: PRODUCT SEARCH & SOURCING ---
@Composable
fun ProductSearchScreen(
    viewModel: MainViewModel,
    onNavigateToProduct: (String) -> Unit
) {
    val currentLang by viewModel.currentLanguage.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResultsList by viewModel.searchResults.collectAsState()
    val selectedFilters by viewModel.selectedFilters.collectAsState()

    var showFilters by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search Header
        Surface(
            color = Color.White,
            tonalElevation = 2.dp,
            border = BorderStroke(1.dp, BorderGrey)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { viewModel.updateSearchQuery(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("product_search_input"),
                    placeholder = {
                        Text(
                            text = if (currentLang == Language.ZH_CN) "搜索不锈钢水瓶, 太阳能板, 水泵, 有机棉" else "Search bottle, solar, pump, cotton",
                            fontSize = 14.sp
                        )
                    },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    shape = RoundedCornerShape(8.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = PrimaryOrange,
                        unfocusedBorderColor = BorderGrey
                    ),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(10.dp))

                // Filters row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = selectedFilters.isVerified,
                            onClick = {
                                viewModel.updateFilters(
                                    isVerified = !selectedFilters.isVerified,
                                    isTradeProtection = selectedFilters.isTradeProtection,
                                    maxMoq = selectedFilters.maxMoq,
                                    category = selectedFilters.category
                                )
                            },
                            label = { Text(if (currentLang == Language.ZH_CN) "金牌商家" else "Verified Supplier") },
                            leadingIcon = if (selectedFilters.isVerified) {
                                { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                            } else null
                        )
                        FilterChip(
                            selected = selectedFilters.isTradeProtection,
                            onClick = {
                                viewModel.updateFilters(
                                    isVerified = selectedFilters.isVerified,
                                    isTradeProtection = !selectedFilters.isTradeProtection,
                                    maxMoq = selectedFilters.maxMoq,
                                    category = selectedFilters.category
                                )
                            },
                            label = { Text(if (currentLang == Language.ZH_CN) "贸易保障" else "Trade Assurance") }
                        )
                    }

                    // Reset button
                    if (selectedFilters.isVerified || selectedFilters.isTradeProtection) {
                        TextButton(
                            onClick = { viewModel.updateFilters(false, false, null, null) },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(if (currentLang == Language.ZH_CN) "重置" else "Reset", color = RestrainedRed, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Search Results List
        if (searchResultsList.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        Icons.Default.SearchOff,
                        contentDescription = "No results",
                        modifier = Modifier.size(64.dp),
                        tint = SteelGrey
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (currentLang == Language.ZH_CN) "未检索到匹配的商品报价" else "No matching products found",
                        fontWeight = FontWeight.Bold,
                        color = DeepCharcoal
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (currentLang == Language.ZH_CN) "尝试检索 '不锈钢水瓶' 或 '太阳能板'" else "Try searching 'water bottle' or 'solar panel'",
                        fontSize = 12.sp,
                        color = SteelGrey
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(searchResultsList) { rankedResult ->
                    val product = rankedResult.product
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateToProduct(product.id) }
                            .testTag("search_result_item_${product.id}"),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = BorderStroke(1.dp, BorderGrey)
                    ) {
                        Row(modifier = Modifier.padding(12.dp)) {
                            // Product Image
                            AsyncImage(
                                model = product.imageUrl,
                                contentDescription = "Product image",
                                modifier = Modifier
                                    .size(100.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(LightGrey),
                                contentScale = ContentScale.Crop
                            )
                            Spacer(modifier = Modifier.width(12.dp))

                            // Details
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (product.isVerifiedSupplier) {
                                        Surface(
                                            shape = RoundedCornerShape(2.dp),
                                            color = OrangeSoft,
                                            modifier = Modifier.padding(end = 4.dp)
                                        ) {
                                            Text(
                                                text = if (currentLang == Language.ZH_CN) "金牌验厂" else "Verified",
                                                fontSize = 9.sp,
                                                color = PrimaryOrange,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                    if (product.isTradeProtection) {
                                        Surface(
                                            shape = RoundedCornerShape(2.dp),
                                            color = GreenSoft
                                        ) {
                                            Text(
                                                text = if (currentLang == Language.ZH_CN) "保障代管" else "Escrow Secured",
                                                fontSize = 9.sp,
                                                color = EscrowGreen,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (currentLang == Language.ZH_CN) product.nameZh else product.nameEn,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = DeepCharcoal,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                // Pricing
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        text = LocalizationManager.formatCurrency(product.priceTiers.last().unitPrice),
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryOrange
                                    )
                                    Text(
                                        text = " - " + LocalizationManager.formatCurrency(product.priceTiers.first().unitPrice),
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = SteelGrey
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (currentLang == Language.ZH_CN) "/ 件" else "/ pc",
                                        fontSize = 11.sp,
                                        color = SteelGrey
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (currentLang == Language.ZH_CN) "起订量: ${product.moq} 件" else "MOQ: ${product.moq} pcs",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = DeepCharcoal
                                    )
                                    Text(
                                        text = if (currentLang == Language.ZH_CN) "交期: ${product.leadTimeDays}天" else "Lead: ${product.leadTimeDays}d",
                                        fontSize = 12.sp,
                                        color = SteelGrey
                                    )
                                }

                                // Search Rank Explainer bubble
                                if (searchQuery.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Surface(
                                        color = NavySoft,
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(6.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(Icons.Default.Info, contentDescription = null, tint = DarkNavy, modifier = Modifier.size(12.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = if (currentLang == Language.ZH_CN) rankedResult.matchReasonsZh.first() else rankedResult.matchReasonsEn.first(),
                                                fontSize = 10.sp,
                                                color = DarkNavy,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis,
                                                fontWeight = FontWeight.Medium
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ProductGridItem(product: CachedProduct, currentLang: Language, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("recommended_product_${product.id}"),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = BorderStroke(1.dp, BorderGrey)
    ) {
        Column {
            AsyncImage(
                model = product.imageUrl,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .background(LightGrey),
                contentScale = ContentScale.Crop
            )
            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = if (currentLang == Language.ZH_CN) product.nameZh else product.nameEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    color = DeepCharcoal,
                    modifier = Modifier.height(38.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = LocalizationManager.formatCurrency(product.priceTiers.last().unitPrice),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryOrange
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = if (currentLang == Language.ZH_CN) "起" else "up",
                        fontSize = 10.sp,
                        color = SteelGrey
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = if (currentLang == Language.ZH_CN) "起订量: ${product.moq}" else "MOQ: ${product.moq}",
                    fontSize = 11.sp,
                    color = SteelGrey
                )
            }
        }
    }
}

// --- TAB 3: RFQ WORKSPACE & SIDE-BY-SIDE COMPARE ---
@Composable
fun RFQWorkspaceScreen(
    viewModel: MainViewModel,
    onSwitchToChat: () -> Unit
) {
    val currentLang by viewModel.currentLanguage.collectAsState()
    val rfqList by viewModel.rfqs.collectAsState()
    val activeRFQId by viewModel.activeRFQId.collectAsState()
    val quotesList by viewModel.activeQuotes.collectAsState()

    var showPostForm by remember { mutableStateOf(false) }

    // RFQ Posting Form inputs
    var inputTitle by remember { mutableStateOf("") }
    var inputQty by remember { mutableStateOf("") }
    var inputUnit by remember { mutableStateOf("pieces") }
    var inputPrice by remember { mutableStateOf("") }
    var inputDest by remember { mutableStateOf("Los Angeles, CA") }
    var inputDelivery by remember { mutableStateOf("2026-11-15") }
    var inputSpecs by remember { mutableStateOf("") }
    var inputNotes by remember { mutableStateOf("") }

    if (activeRFQId != null) {
        // Detailed Quote Comparison Dashboard
        val activeRfq = rfqList.find { it.id == activeRFQId }
        if (activeRfq != null) {
            QuoteComparisonPanel(
                rfq = activeRfq,
                quotes = quotesList,
                currentLang = currentLang,
                onBack = { viewModel.selectRFQ(null) },
                onAcceptQuote = { quote ->
                    viewModel.acceptQuoteAndCreatePO(quote, activeRfq)
                    onSwitchToChat() // navigate to chat/order workspace
                }
            )
        }
    } else if (showPostForm) {
        // RFQ submission form
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { showPostForm = false }) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (currentLang == Language.ZH_CN) "新建全球采购询价单" else "Post Sourcing RFQ",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = DeepCharcoal
                )
            }
            Spacer(modifier = Modifier.height(16.dp))

            OutlinedTextField(
                value = inputTitle,
                onValueChange = { inputTitle = it },
                label = { Text(if (currentLang == Language.ZH_CN) "采购商品名称 (例如: 不锈钢水瓶)" else "Product Name (e.g. Stainless bottle)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp)
                    .testTag("rfq_form_title"),
                singleLine = true
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = inputQty,
                    onValueChange = { inputQty = it },
                    label = { Text(if (currentLang == Language.ZH_CN) "采购数量" else "Quantity") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier
                        .weight(1f)
                        .padding(bottom = 12.dp)
                        .testTag("rfq_form_qty"),
                    singleLine = true
                )
                OutlinedTextField(
                    value = inputUnit,
                    onValueChange = { inputUnit = it },
                    label = { Text(if (currentLang == Language.ZH_CN) "单位" else "Unit") },
                    modifier = Modifier
                        .weight(1f)
                        .padding(bottom = 12.dp),
                    singleLine = true
                )
            }

            OutlinedTextField(
                value = inputPrice,
                onValueChange = { inputPrice = it },
                label = { Text(if (currentLang == Language.ZH_CN) "目标单价 (USD)" else "Target Price (USD, Optional)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                singleLine = true
            )

            OutlinedTextField(
                value = inputDest,
                onValueChange = { inputDest = it },
                label = { Text(if (currentLang == Language.ZH_CN) "目的港口/地 (例如: 洛杉矶)" else "Destination Port (e.g. Los Angeles)") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                singleLine = true
            )

            OutlinedTextField(
                value = inputDelivery,
                onValueChange = { inputDelivery = it },
                label = { Text(if (currentLang == Language.ZH_CN) "要求交货截止日期 (YYYY-MM-DD)" else "Required Delivery Date") },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 12.dp),
                singleLine = true
            )

            OutlinedTextField(
                value = inputSpecs,
                onValueChange = { inputSpecs = it },
                label = { Text(if (currentLang == Language.ZH_CN) "详细定制规格及技术要求" else "Detailed Technical Specs & Customisation") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .padding(bottom = 12.dp)
                    .testTag("rfq_form_specs")
            )

            OutlinedTextField(
                value = inputNotes,
                onValueChange = { inputNotes = it },
                label = { Text(if (currentLang == Language.ZH_CN) "补充说明" else "Additional Notes") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(80.dp)
                    .padding(bottom = 16.dp)
            )

            Button(
                onClick = {
                    if (inputTitle.isNotBlank() && inputQty.isNotBlank()) {
                        viewModel.postRFQ(
                            productTitle = inputTitle,
                            quantity = inputQty.toIntOrNull() ?: 1000,
                            unit = inputUnit,
                            targetPrice = inputPrice.toDoubleOrNull(),
                            destination = inputDest,
                            deliveryDate = inputDelivery,
                            specifications = inputSpecs,
                            notes = inputNotes.ifBlank { null }
                        )
                        // Reset
                        inputTitle = ""
                        inputQty = ""
                        inputSpecs = ""
                        showPostForm = false
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("rfq_submit_button"),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange)
            ) {
                Text(
                    text = if (currentLang == Language.ZH_CN) "向全球工厂发布询价" else "Publish RFQ to Global Factories",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    } else {
        // RFQ Console Workspace List
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (currentLang == Language.ZH_CN) "采购商询价单控制台" else "RFQ Control Panel",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = DeepCharcoal
                )
                Button(
                    onClick = { showPostForm = true },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.height(36.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (currentLang == Language.ZH_CN) "新建询价" else "New RFQ", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
            Spacer(modifier = Modifier.height(16.dp))

            if (rfqList.isEmpty()) {
                Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                    Text(
                        text = if (currentLang == Language.ZH_CN) "尚无已发布的询价单" else "No RFQs published yet.",
                        color = SteelGrey
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(rfqList) { rfq ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectRFQ(rfq.id) }
                                .testTag("rfq_item_card_${rfq.id}"),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, BorderGrey)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = rfq.id.uppercase(),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SteelGrey
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = OrangeSoft
                                    ) {
                                        Text(
                                            text = rfq.status,
                                            fontSize = 10.sp,
                                            color = PrimaryOrange,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = rfq.productTitle,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    color = DeepCharcoal
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(if (currentLang == Language.ZH_CN) "数量" else "Quantity", fontSize = 10.sp, color = SteelGrey)
                                        Text("${rfq.quantity} ${rfq.unit}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DeepCharcoal)
                                    }
                                    Column {
                                        Text(if (currentLang == Language.ZH_CN) "目标价" else "Target Price", fontSize = 10.sp, color = SteelGrey)
                                        Text(rfq.targetPrice?.let { LocalizationManager.formatCurrency(it) } ?: "--", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DeepCharcoal)
                                    }
                                    Column {
                                        Text(if (currentLang == Language.ZH_CN) "交期" else "Delivery Date", fontSize = 10.sp, color = SteelGrey)
                                        Text(rfq.deliveryDate, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = DeepCharcoal)
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Divider(color = BorderGrey)
                                Spacer(modifier = Modifier.height(12.dp))
                                
                                // Real-time feedback simulation
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Factory, contentDescription = null, tint = EscrowGreen, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (currentLang == Language.ZH_CN) "已收到海外工厂报价方案!" else "Received factory quotes!",
                                            fontSize = 11.sp,
                                            color = EscrowGreen,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                    Text(
                                        text = if (currentLang == Language.ZH_CN) "对比方案 >" else "Compare >",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = PrimaryOrange
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// Side-by-Side Quote Comparison View
@Composable
fun QuoteComparisonPanel(
    rfq: CachedRFQ,
    quotes: List<CachedQuote>,
    currentLang: Language,
    onBack: () -> Unit,
    onAcceptQuote: (CachedQuote) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (currentLang == Language.ZH_CN) "比价单决策面板 (Side-by-Side)" else "Decision Panel: Side-by-Side Quotes",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = DeepCharcoal
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

        // RFQ info box
        Card(
            colors = CardDefaults.cardColors(containerColor = LightGrey),
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = if (currentLang == Language.ZH_CN) "当前采购标的: ${rfq.productTitle}" else "Sourcing Target: ${rfq.productTitle}",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )
                Text(
                    text = if (currentLang == Language.ZH_CN) "需求总量: ${rfq.quantity} ${rfq.unit}" else "Volume: ${rfq.quantity} ${rfq.unit}",
                    fontSize = 12.sp,
                    color = SteelGrey
                )
            }
        }

        // Side-by-Side comparative grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            for (quote in quotes) {
                Card(
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quote_compare_card_${quote.id}"),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderGrey)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = if (currentLang == Language.ZH_CN) quote.supplierNameZh else quote.supplierNameEn,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            color = DarkNavy
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        CompareMetricItem(
                            label = if (currentLang == Language.ZH_CN) "工厂单价" else "Unit Price",
                            value = LocalizationManager.formatCurrency(quote.unitPrice),
                            highlight = true
                        )
                        CompareMetricItem(
                            label = if (currentLang == Language.ZH_CN) "工厂交期" else "Lead Time",
                            value = "${quote.leadTimeDays} " + (if (currentLang == Language.ZH_CN) "天" else "days")
                        )
                        CompareMetricItem(
                            label = if (currentLang == Language.ZH_CN) "样品费用" else "Sample cost",
                            value = LocalizationManager.formatCurrency(quote.sampleCost)
                        )
                        CompareMetricItem(
                            label = if (currentLang == Language.ZH_CN) "拼箱海运费" else "Shipping cost",
                            value = LocalizationManager.formatCurrency(quote.shippingCost)
                        )
                        CompareMetricItem(
                            label = if (currentLang == Language.ZH_CN) "起订量(MOQ)" else "MOQ Limit",
                            value = "${quote.moq} pcs"
                        )
                        CompareMetricItem(
                            label = if (currentLang == Language.ZH_CN) "国际认证" else "Certs",
                            value = quote.certificationsEn,
                            smallText = true
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { onAcceptQuote(quote) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(38.dp)
                                .testTag("accept_quote_btn_${quote.id}"),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                text = if (currentLang == Language.ZH_CN) "采纳并生成合同" else "Accept & Create PO",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CompareMetricItem(label: String, value: String, highlight: Boolean = false, smallText: Boolean = false) {
    Column(modifier = Modifier.padding(vertical = 4.dp)) {
        Text(text = label, fontSize = 9.sp, color = SteelGrey)
        Text(
            text = value,
            fontSize = if (smallText) 10.sp else if (highlight) 15.sp else 12.sp,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.SemiBold,
            color = if (highlight) PrimaryOrange else DeepCharcoal,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

// --- TAB 4: CHAT THREADS & LIVE TRANSLATION ---
@Composable
fun ChatThreadsScreen(
    viewModel: MainViewModel
) {
    val currentLang by viewModel.currentLanguage.collectAsState()
    val conversationsList by viewModel.conversations.collectAsState()
    val activeConversationId by viewModel.activeConversationId.collectAsState()
    val messagesList by viewModel.activeMessages.collectAsState()

    if (activeConversationId != null) {
        val activeConv = conversationsList.find { it.id == activeConversationId }
        ChatDetailWorkspace(
            conversation = activeConv,
            messages = messagesList,
            currentLang = currentLang,
            onBack = { viewModel.selectConversation(null) },
            onSendMessage = { text -> viewModel.sendMessage(text) }
        )
    } else {
        // Threads List
        Column(modifier = Modifier.fillMaxSize()) {
            Surface(
                color = Color.White,
                border = BorderStroke(1.dp, BorderGrey)
            ) {
                Text(
                    text = if (currentLang == Language.ZH_CN) "买家国际沟通会话" else "Supplier Communications Thread",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = DeepCharcoal,
                    modifier = Modifier.padding(16.dp)
                )
            }

            if (conversationsList.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (currentLang == Language.ZH_CN) "暂无沟通消息会话" else "No active chats.", color = SteelGrey)
                }
            } else {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(conversationsList) { conv ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectConversation(conv.id) }
                                .padding(16.dp)
                                .testTag("chat_thread_${conv.id}"),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Supplier initial avatar
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(DarkNavy),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = (if (currentLang == Language.ZH_CN) conv.supplierNameZh else conv.supplierNameEn).take(1),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = if (currentLang == Language.ZH_CN) conv.supplierNameZh else conv.supplierNameEn,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp,
                                        color = DeepCharcoal
                                    )
                                    Text(
                                        text = "1 hour ago", // Simulated time label
                                        fontSize = 11.sp,
                                        color = SteelGrey
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = conv.lastMessageText,
                                    fontSize = 12.sp,
                                    color = SteelGrey,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Divider(color = BorderGrey, modifier = Modifier.padding(horizontal = 16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun ChatDetailWorkspace(
    conversation: CachedConversation?,
    messages: List<CachedMessage>,
    currentLang: Language,
    onBack: () -> Unit,
    onSendMessage: (String) -> Unit
) {
    var textInput by remember { mutableStateOf("") }
    
    // Auto translation toggle map
    val translationToggles = remember { mutableStateMapOf<String, Boolean>() }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = conversation?.let { if (currentLang == Language.ZH_CN) it.supplierNameZh else it.supplierNameEn } ?: "Chat",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (currentLang == Language.ZH_CN) "在线（金牌实力制造厂）" else "Online (Audited Factory)",
                            fontSize = 11.sp,
                            color = EscrowGreen,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            Surface(
                color = Color.White,
                tonalElevation = 4.dp,
                modifier = Modifier.navigationBarsPadding()
            ) {
                Column {
                    // Sourcing Chat quick prompts helper bar
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState())
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ChatPromptTag(
                            label = if (currentLang == Language.ZH_CN) "请求样品" else "Request sample",
                            onClick = { onSendMessage(if (currentLang == Language.ZH_CN) "您好，我们对这款产品很感兴趣。我们想申请拿样检测，请提供样品价格和国际快递费用。" else "Hello, we are interested in this product. We would like to request a sample. Please provide the sample cost and shipping details.") }
                        )
                        ChatPromptTag(
                            label = if (currentLang == Language.ZH_CN) "咨询起订量" else "Ask MOQ",
                            onClick = { onSendMessage(if (currentLang == Language.ZH_CN) "请问最低起订量(MOQ)能调整吗？我们首次采购，想先小规模试单。" else "Could we adjust the MOQ? As our first procurement, we would like a smaller trial order.") }
                        )
                        ChatPromptTag(
                            label = if (currentLang == Language.ZH_CN) "询FOB条款" else "Inquire FOB Terms",
                            onClick = { onSendMessage(if (currentLang == Language.ZH_CN) "该商品的出厂价(FOB Shanghai)报价是多少？" else "What is the FOB Shanghai quotation for this item?") }
                        )
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = textInput,
                            onValueChange = { textInput = it },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("chat_input_field"),
                            placeholder = { Text(if (currentLang == Language.ZH_CN) "输入消息（支持实时互译）..." else "Type message (real-time translated)...") },
                            maxLines = 3,
                            shape = RoundedCornerShape(20.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PrimaryOrange,
                                unfocusedBorderColor = BorderGrey
                            )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        IconButton(
                            onClick = {
                                if (textInput.isNotBlank()) {
                                    onSendMessage(textInput)
                                    textInput = ""
                                }
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .background(PrimaryOrange, CircleShape)
                                .testTag("chat_send_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(messages) { msg ->
                val isBuyer = msg.senderType == "BUYER"
                val textToDisplay: String
                val targetLangLabel: String

                // Setup translation logic toggle
                val isTranslated = translationToggles[msg.id] ?: true
                
                if (isTranslated) {
                    textToDisplay = if (currentLang == Language.ZH_CN) msg.textZh else msg.textEn
                    targetLangLabel = if (currentLang == Language.ZH_CN) "显示原文" else "Show Original"
                } else {
                    textToDisplay = msg.originalText
                    targetLangLabel = if (currentLang == Language.ZH_CN) "显示译文" else "Show Translation"
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isBuyer) Arrangement.End else Arrangement.Start
                ) {
                    Column(
                        horizontalAlignment = if (isBuyer) Alignment.End else Alignment.Start,
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        // Translation banner tag
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isBuyer) "Apex Global" else (conversation?.let { if (currentLang == Language.ZH_CN) it.supplierNameZh else it.supplierNameEn } ?: "Supplier"),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = SteelGrey
                            )
                            if (msg.originalLang != currentLang.name) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Auto-Translated",
                                    fontSize = 8.sp,
                                    color = PrimaryOrange,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))

                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (isBuyer) PrimaryOrange else LightGrey,
                            modifier = Modifier.testTag("chat_msg_bubble")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = textToDisplay,
                                    fontSize = 14.sp,
                                    color = if (isBuyer) Color.White else DeepCharcoal
                                )

                                // Clickable Translation toggle button
                                if (msg.originalLang != currentLang.name) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = targetLangLabel,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isBuyer) Color.White.copy(alpha = 0.85f) else PrimaryOrange,
                                        modifier = Modifier
                                            .clickable {
                                                translationToggles[msg.id] = !isTranslated
                                            }
                                            .padding(vertical = 2.dp)
                                            .testTag("toggle_translate_btn")
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ChatPromptTag(label: String, onClick: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, BorderGrey),
        color = Color.White,
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            color = DeepCharcoal,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

// --- TAB 5: AI SOURCING ASSISTANT WORKSPACE ---
@Composable
fun AISourcingScreen(
    viewModel: MainViewModel,
    onNavigateToRFQ: () -> Unit
) {
    val currentLang by viewModel.currentLanguage.collectAsState()
    val aiMessages by viewModel.aiChatMessages.collectAsState()
    val isLoading by viewModel.aiSourcingLoading.collectAsState()

    var queryInput by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Psychology, contentDescription = null, tint = PrimaryOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (currentLang == Language.ZH_CN) "Sourcing AI 采购决策引擎" else "Sourcing AI Copilot",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.clearAIChat() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Clear")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.White)
            )
        },
        bottomBar = {
            Surface(
                color = Color.White,
                tonalElevation = 4.dp,
                modifier = Modifier.navigationBarsPadding()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = queryInput,
                        onValueChange = { queryInput = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("ai_assistant_input"),
                        placeholder = { 
                            Text(
                                text = if (currentLang == Language.ZH_CN) "例如：我需要5000个不锈钢保温杯..." else "e.g. I need 5000 stainless bottles...",
                                fontSize = 13.sp
                            ) 
                        },
                        maxLines = 2,
                        shape = RoundedCornerShape(20.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryOrange,
                            unfocusedBorderColor = BorderGrey
                        )
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (queryInput.isNotBlank()) {
                                viewModel.sendAIAssistantMessage(queryInput)
                                queryInput = ""
                            }
                        },
                        modifier = Modifier
                            .size(40.dp)
                            .background(PrimaryOrange, CircleShape)
                            .testTag("ai_assistant_send")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                    }
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(aiMessages) { msg ->
                val textToDisplay = if (currentLang == Language.ZH_CN) msg.textZh else msg.textEn
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (msg.isUser) Arrangement.End else Arrangement.Start
                ) {
                    Column(
                        modifier = Modifier.widthIn(max = 300.dp),
                        horizontalAlignment = if (msg.isUser) Alignment.End else Alignment.Start
                    ) {
                        Text(
                            text = if (msg.isUser) "Apex Procurement" else "Sourcing AI Engine",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = SteelGrey
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (msg.isUser) PrimaryOrange else NavySoft,
                            modifier = Modifier.testTag("ai_msg_bubble")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = textToDisplay,
                                    fontSize = 14.sp,
                                    color = if (msg.isUser) Color.White else DeepCharcoal
                                )

                                // Render suggested RFQ auto injector card
                                msg.suggestedRFQ?.let { draft ->
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = Color.White),
                                        border = BorderStroke(1.dp, BorderGrey)
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp)) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.Assignment, contentDescription = null, tint = PrimaryOrange, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = if (currentLang == Language.ZH_CN) "AI 草拟的询价单(RFQ)" else "AI Drafted RFQ",
                                                    fontWeight = FontWeight.Bold,
                                                    fontSize = 12.sp,
                                                    color = DeepCharcoal
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = draft.productTitle,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.SemiBold
                                            )
                                            Text(
                                                text = if (currentLang == Language.ZH_CN) "拟采数量: ${draft.quantity} 件" else "Volume: ${draft.quantity} pcs",
                                                fontSize = 11.sp,
                                                color = SteelGrey
                                            )
                                            Text(
                                                text = if (currentLang == Language.ZH_CN) "目的港: ${draft.destination}" else "Port: ${draft.destination}",
                                                fontSize = 11.sp,
                                                color = SteelGrey
                                            )
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Button(
                                                onClick = {
                                                    // Trigger direct RFQ posting workflow with pre-filled inputs
                                                    viewModel.postRFQ(
                                                        productTitle = draft.productTitle,
                                                        quantity = draft.quantity,
                                                        unit = "pieces",
                                                        targetPrice = draft.targetPrice,
                                                        destination = draft.destination,
                                                        deliveryDate = draft.deliveryDate,
                                                        specifications = draft.specifications,
                                                        notes = draft.notes
                                                    )
                                                    onNavigateToRFQ() // navigates to Console list
                                                },
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(34.dp)
                                                    .testTag("apply_draft_rfq_btn"),
                                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange),
                                                contentPadding = PaddingValues(0.dp)
                                            ) {
                                                Text(
                                                    text = if (currentLang == Language.ZH_CN) "直接发布此询价" else "Publish this RFQ Now",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Loading indicator
            if (isLoading) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = PrimaryOrange)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (currentLang == Language.ZH_CN) "AI 正在规划方案并对比工厂库..." else "AI is scanning audited supplier index...",
                            fontSize = 12.sp,
                            color = SteelGrey
                        )
                    }
                }
            }
        }
    }
}

// --- TAB 6: ORDERS CONSOLE & ESCROW PAYMENTS ---
@Composable
fun OrdersConsoleScreen(
    viewModel: MainViewModel
) {
    val currentLang by viewModel.currentLanguage.collectAsState()
    val ordersList by viewModel.orders.collectAsState()
    val activeOrderId by viewModel.activeOrderId.collectAsState()
    
    val activeOrderDetails by viewModel.activeOrder.collectAsState()
    val activeShipmentDetails by viewModel.activeShipment.collectAsState()
    val activeInspectionsList by viewModel.activeInspections.collectAsState()
    val activeDisputeDetails by viewModel.activeDispute.collectAsState()

    if (activeOrderId != null) {
        OrderDetailWorkspace(
            order = activeOrderDetails,
            shipment = activeShipmentDetails,
            inspections = activeInspectionsList,
            dispute = activeDisputeDetails,
            currentLang = currentLang,
            onBack = { viewModel.selectOrder(null) },
            onAuthorizePayment = { viewModel.authorizePayment(activeOrderId!!, "Secure Wire Transfer") },
            onShip = { viewModel.shipOrder(activeOrderId!!) },
            onConfirmDelivery = { viewModel.confirmDelivery(activeOrderId!!) },
            onLodgeDispute = { reason, statement, amount ->
                viewModel.openDispute(activeOrderId!!, reason, statement, amount)
            },
            onSubmitCounterOffer = { price, qty, message ->
                viewModel.submitCounterOffer(activeOrderId!!, price, qty, message)
            }
        )
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Surface(
                color = Color.White,
                border = BorderStroke(1.dp, BorderGrey)
            ) {
                Text(
                    text = if (currentLang == Language.ZH_CN) "B2B 采购合同与代管控制台" else "PO Contract & Escrow Center",
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp,
                    color = DeepCharcoal,
                    modifier = Modifier.padding(16.dp)
                )
            }
            Spacer(modifier = Modifier.height(16.dp))

            if (ordersList.isEmpty()) {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(if (currentLang == Language.ZH_CN) "尚无签署的采购合同" else "No contracts found.", color = SteelGrey)
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(ordersList) { order ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectOrder(order.id) }
                                .testTag("order_item_card_${order.id}"),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, BorderGrey)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "CONTRACT ID: ${order.id}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SteelGrey
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = if (order.status == "COMPLETED") GreenSoft else OrangeSoft
                                    ) {
                                        Text(
                                            text = order.status,
                                            fontSize = 10.sp,
                                            color = if (order.status == "COMPLETED") EscrowGreen else PrimaryOrange,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (currentLang == Language.ZH_CN) order.productNameZh else order.productNameEn,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = DeepCharcoal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = if (currentLang == Language.ZH_CN) "供应商: ${order.supplierNameZh}" else "Supplier: ${order.supplierNameEn}",
                                    fontSize = 12.sp,
                                    color = SteelGrey
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Divider(color = BorderGrey)
                                Spacer(modifier = Modifier.height(12.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(if (currentLang == Language.ZH_CN) "合同总额" else "Total Contract Price", fontSize = 9.sp, color = SteelGrey)
                                        Text(
                                            text = LocalizationManager.formatCurrency(order.totalPrice),
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PrimaryOrange
                                        )
                                    }
                                    Text(
                                        text = if (currentLang == Language.ZH_CN) "管理控制台 >" else "Manage Escrow >",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = DarkNavy
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- ORDER ESCROW MANAGEMENT WORKSPACE ---
@Composable
fun OrderDetailWorkspace(
    order: CachedOrder?,
    shipment: CachedShipment?,
    inspections: List<CachedInspection>,
    dispute: CachedDispute?,
    currentLang: Language,
    onBack: () -> Unit,
    onAuthorizePayment: () -> Unit,
    onShip: () -> Unit,
    onConfirmDelivery: () -> Unit,
    onLodgeDispute: (String, String, Double) -> Unit,
    onSubmitCounterOffer: (Double, Int, String) -> Unit
) {
    if (order == null) return

    val scrollState = rememberScrollState()

    var showNegotiateDialog by remember { mutableStateOf(false) }
    var showDisputeDialog by remember { mutableStateOf(false) }

    // Dialog inputs
    var counterPrice by remember { mutableStateOf("${order.unitPrice}") }
    var counterQty by remember { mutableStateOf("${order.quantity}") }
    var counterMessage by remember { mutableStateOf("") }

    var disputeReason by remember { mutableStateOf("") }
    var disputeStatement by remember { mutableStateOf("") }
    var disputeRefundAmount by remember { mutableStateOf("${order.totalPrice}") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = if (currentLang == Language.ZH_CN) "B2B 安全合同及代管中心" else "Contract & Escrow Hub",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = DeepCharcoal
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

        // Contract summary Card
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, BorderGrey),
            modifier = Modifier.padding(bottom = 16.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "CONTRACT NO: ${order.id}",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SteelGrey
                    )
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = GreenSoft
                    ) {
                        Row(modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = EscrowGreen, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (currentLang == Language.ZH_CN) "贸易保障" else "Trade Protected",
                                fontSize = 9.sp,
                                color = EscrowGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = if (currentLang == Language.ZH_CN) order.productNameZh else order.productNameEn,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(if (currentLang == Language.ZH_CN) "单价" else "Unit Price", fontSize = 10.sp, color = SteelGrey)
                        Text(LocalizationManager.formatCurrency(order.unitPrice), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text(if (currentLang == Language.ZH_CN) "采购数量" else "Quantity", fontSize = 10.sp, color = SteelGrey)
                        Text("${order.quantity} ${order.unit}", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text(if (currentLang == Language.ZH_CN) "合同总价" else "Total Price", fontSize = 10.sp, color = SteelGrey)
                        Text(LocalizationManager.formatCurrency(order.totalPrice), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = PrimaryOrange)
                    }
                }
            }
        }

        // Real-time Escrow progress tracker bar (Visual M3)
        Text(
            text = if (currentLang == Language.ZH_CN) "代管资金及流程节点追踪" else "Escrow Flow Tracker",
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp,
            color = DeepCharcoal,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        EscrowProgressBar(order = order, currentLang = currentLang)
        Spacer(modifier = Modifier.height(20.dp))

        // Actions console based on active status
        when (order.status) {
            "CONFIRMED" -> {
                // Negotiation counter offer list
                Text(
                    text = if (currentLang == Language.ZH_CN) "商务谈判价格变动历史" else "B2B Bargaining / Counter-Offers",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = DeepCharcoal,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                
                Card(
                    border = BorderStroke(1.dp, BorderGrey),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        for (round in order.negotiationHistory) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = "Round ${round.roundNum}: " + (if (round.proposedBy == "BUYER") "Buyer Counter" else "Supplier Quote"),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (round.proposedBy == "BUYER") PrimaryOrange else DarkNavy
                                    )
                                    Text(
                                        text = if (currentLang == Language.ZH_CN) round.messageZh else round.messageEn,
                                        fontSize = 12.sp,
                                        color = SteelGrey
                                    )
                                }
                                Text(
                                    text = LocalizationManager.formatCurrency(round.price),
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Divider(color = BorderGrey)
                        }
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { showNegotiateDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("counter_offer_button")
                            ) {
                                Text(if (currentLang == Language.ZH_CN) "商务还盘 (Counter)" else "Counter-Offer")
                            }
                            Button(
                                onClick = onAuthorizePayment,
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("accept_po_button")
                            ) {
                                Text(if (currentLang == Language.ZH_CN) "同意价格并付款" else "Sign PO & Pay")
                            }
                        }
                    }
                }
            }

            "PAYMENT_PENDING" -> {
                // Payment panel
                Card(
                    colors = CardDefaults.cardColors(containerColor = OrangeSoft),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = if (currentLang == Language.ZH_CN) "签署合同成功，等待买家进行代管付款" else "PO Signed. Secure Escrow payment required.",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = PrimaryOrange
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (currentLang == Language.ZH_CN) "您的资金将暂时锁定在官方指定的第三方代管账户中，直至货物顺利运抵洛杉矶并由您确认通过。" else "Your funds will remain securely locked in official Escrow. Money is only released after you confirm satisfying delivery.",
                            fontSize = 12.sp,
                            color = DeepCharcoal
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = onAuthorizePayment,
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp)
                                .testTag("authorize_escrow_pay")
                        ) {
                            Text(if (currentLang == Language.ZH_CN) "安全付款 (代管保障)" else "Secure Payment via Escrow")
                        }
                    }
                }
            }

            "PRODUCTION", "QUALITY_CHECK", "READY_TO_SHIP" -> {
                // Active Production & QC Inspection Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderGrey),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = PrimaryOrange)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (currentLang == Language.ZH_CN) "海外工厂生产与质检实况" else "Live Production & QC Monitoring",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(if (currentLang == Language.ZH_CN) "生产节点状态:" else "Manufacturing stage:", fontSize = 12.sp, color = SteelGrey)
                            Text(order.productionStatus, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = PrimaryOrange)
                        }
                        
                        // Render SGS inspections
                        for (insp in inspections) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Divider(color = BorderGrey)
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = EscrowGreen, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (currentLang == Language.ZH_CN) insp.inspectionTypeZh else insp.inspectionTypeEn,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = EscrowGreen
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Surface(shape = RoundedCornerShape(2.dp), color = GreenSoft) {
                                    Text(
                                        text = insp.result,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = EscrowGreen,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (currentLang == Language.ZH_CN) insp.findingsZh else insp.findingsEn,
                                fontSize = 11.sp,
                                color = SteelGrey
                            )
                        }

                        // Ship order simulator button
                        if (order.productionStatus == "READY_TO_SHIP") {
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = onShip,
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryOrange),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(if (currentLang == Language.ZH_CN) "通知并触发海运订舱" else "Authorize Booking & Shipment")
                            }
                        }
                    }
                }
            }

            "SHIPPED", "IN_TRANSIT" -> {
                // Tracking and confirmation
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, BorderGrey),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.DirectionsBoat, contentDescription = null, tint = DarkNavy)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (currentLang == Language.ZH_CN) "海上物流实时轨迹追踪" else "Maritime Tracking & Milestones",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        shipment?.let { ship ->
                            Text(
                                text = if (currentLang == Language.ZH_CN) "集装箱航运公司: ${ship.carrier}" else "Carrier: ${ship.carrier}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = if (currentLang == Language.ZH_CN) "柜号: ${ship.containerNum}" else "Container: ${ship.containerNum}",
                                fontSize = 11.sp,
                                color = SteelGrey
                            )
                            Text(
                                text = if (currentLang == Language.ZH_CN) "提单追踪号: ${ship.trackingNum}" else "Tracking: ${ship.trackingNum}",
                                fontSize = 11.sp,
                                color = SteelGrey
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(shape = RoundedCornerShape(4.dp), color = NavySoft) {
                                Row(modifier = Modifier.padding(6.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = DarkNavy, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = if (currentLang == Language.ZH_CN) ship.currentLocationZh else ship.currentLocationEn,
                                        fontSize = 11.sp,
                                        color = DarkNavy,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            // Dynamic shipping map
                            Spacer(modifier = Modifier.height(16.dp))
                            MaritimeRouteMap(shipment = ship)
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = { showDisputeDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = RestrainedRed),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("lodge_dispute_button")
                            ) {
                                Text(if (currentLang == Language.ZH_CN) "发起资金维权争议" else "Lodge Dispute")
                            }
                            Button(
                                onClick = onConfirmDelivery,
                                colors = ButtonDefaults.buttonColors(containerColor = EscrowGreen),
                                modifier = Modifier
                                    .weight(1.5f)
                                    .testTag("confirm_delivery_button")
                            ) {
                                Text(if (currentLang == Language.ZH_CN) "确认货物并释放资金" else "Confirm & Release Funds")
                            }
                        }
                    }
                }
            }

            "COMPLETED" -> {
                Card(
                    colors = CardDefaults.cardColors(containerColor = GreenSoft),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EscrowGreen)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (currentLang == Language.ZH_CN) "此跨国采购会话已完结" else "Transaction Sourcing Completed",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = EscrowGreen
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (currentLang == Language.ZH_CN) "代管账户持有的采购资金已被成功释放给工厂。感谢您使用我们的全球保障通道进行交易！" else "Escrow funds have been successfully released to the verified supplier. Thank you for securing your sourcing with Trade Protection!",
                            fontSize = 12.sp,
                            color = DeepCharcoal
                        )
                    }
                }
            }

            "DISPUTED" -> {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = BorderStroke(1.dp, RestrainedRed),
                    modifier = Modifier.padding(bottom = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Warning, contentDescription = null, tint = RestrainedRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (currentLang == Language.ZH_CN) "代管资金仲裁维权已开启" else "Escrow Trade Dispute Lodged",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = RestrainedRed
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        dispute?.let { disp ->
                            Text(
                                text = if (currentLang == Language.ZH_CN) "维权原因: ${disp.reasonZh}" else "Dispute Reason: ${disp.reasonEn}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (currentLang == Language.ZH_CN) "仲裁调解状态: ${disp.resolutionZh}" else "Official Status: ${disp.resolutionEn}",
                                fontSize = 11.sp,
                                color = SteelGrey
                            )
                            Text(
                                text = if (currentLang == Language.ZH_CN) "退款金额: $${disp.refundAmount}" else "Refund requested: $${disp.refundAmount}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = RestrainedRed
                            )
                        }
                    }
                }
            }
        }
    }

    // --- DIALOGS ---

    // Negotiation Counter Dialog
    if (showNegotiateDialog) {
        AlertDialog(
            onDismissRequest = { showNegotiateDialog = false },
            title = { Text(if (currentLang == Language.ZH_CN) "发起还盘" else "Submit B2B Counter-Offer") },
            text = {
                Column {
                    OutlinedTextField(
                        value = counterPrice,
                        onValueChange = { counterPrice = it },
                        label = { Text(if (currentLang == Language.ZH_CN) "目标还盘单价 (USD)" else "Target price (USD)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth().testTag("counter_price_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = counterQty,
                        onValueChange = { counterQty = it },
                        label = { Text(if (currentLang == Language.ZH_CN) "拟增购数量" else "Quantity") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = counterMessage,
                        onValueChange = { counterMessage = it },
                        label = { Text(if (currentLang == Language.ZH_CN) "谈判附言 (说明理由)" else "Justification message") },
                        modifier = Modifier.fillMaxWidth().testTag("counter_msg_input")
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val p = counterPrice.toDoubleOrNull()
                        val q = counterQty.toIntOrNull()
                        if (p != null && q != null) {
                            onSubmitCounterOffer(p, q, counterMessage)
                            showNegotiateDialog = false
                        }
                    },
                    modifier = Modifier.testTag("counter_dialog_submit")
                ) {
                    Text(if (currentLang == Language.ZH_CN) "提交" else "Submit")
                }
            },
            dismissButton = {
                TextButton(onClick = { showNegotiateDialog = false }) {
                    Text(if (currentLang == Language.ZH_CN) "取消" else "Cancel")
                }
            }
        )
    }

    // Dispute Lodging Dialog
    if (showDisputeDialog) {
        AlertDialog(
            onDismissRequest = { showDisputeDialog = false },
            title = { Text(if (currentLang == Language.ZH_CN) "申请代管账户仲裁维权" else "Apply for Escrow Mediation") },
            text = {
                Column {
                    OutlinedTextField(
                        value = disputeReason,
                        onValueChange = { disputeReason = it },
                        label = { Text(if (currentLang == Language.ZH_CN) "维权原因 (例: 物流延迟)" else "Dispute reason (e.g. shipping delay)") },
                        modifier = Modifier.fillMaxWidth().testTag("dispute_reason_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = disputeStatement,
                        onValueChange = { disputeStatement = it },
                        label = { Text(if (currentLang == Language.ZH_CN) "详细诉求陈述与上传证明" else "Full detailed statement & proof") },
                        modifier = Modifier.fillMaxWidth().testTag("dispute_statement_input")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = disputeRefundAmount,
                        onValueChange = { disputeRefundAmount = it },
                        label = { Text(if (currentLang == Language.ZH_CN) "退款索赔金额 (USD)" else "Requested Refund Amount") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val amt = disputeRefundAmount.toDoubleOrNull() ?: order.totalPrice
                        if (disputeReason.isNotBlank() && disputeStatement.isNotBlank()) {
                            onLodgeDispute(disputeReason, disputeStatement, amt)
                            showDisputeDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RestrainedRed),
                    modifier = Modifier.testTag("dispute_dialog_submit")
                ) {
                    Text(if (currentLang == Language.ZH_CN) "正式立案申请" else "File Case Now")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDisputeDialog = false }) {
                    Text(if (currentLang == Language.ZH_CN) "取消" else "Cancel")
                }
            }
        )
    }
}

// B2B Visual Escrow Step Tracker Component
@Composable
fun EscrowProgressBar(order: CachedOrder, currentLang: Language) {
    val steps = listOf(
        Triple("CONFIRMED", if (currentLang == Language.ZH_CN) "签约" else "PO", "GT-01"),
        Triple("PRODUCTION", if (currentLang == Language.ZH_CN) "付托" else "Escrow Pay", "GT-02"),
        Triple("SHIPPED", if (currentLang == Language.ZH_CN) "发运" else "Shipped", "GT-03"),
        Triple("COMPLETED", if (currentLang == Language.ZH_CN) "放款" else "Released", "GT-04")
    )

    val activeIndex = when (order.status) {
        "DRAFT", "CONFIRMED" -> 0
        "PAYMENT_PENDING" -> 0
        "PRODUCTION", "QUALITY_CHECK", "READY_TO_SHIP" -> 1
        "SHIPPED", "IN_TRANSIT", "CUSTOMS" -> 2
        "DELIVERED", "COMPLETED", "DISPUTED" -> 3
        else -> 0
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { idx, step ->
            val isActive = idx <= activeIndex
            val color = if (isActive) EscrowGreen else SteelGrey
            val fontWeight = if (idx == activeIndex) FontWeight.Bold else FontWeight.Medium

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .clip(CircleShape)
                        .background(if (isActive) EscrowGreen else LightGrey),
                    contentAlignment = Alignment.Center
                ) {
                    if (idx < activeIndex) {
                        Icon(Icons.Default.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                    } else {
                        Text(text = "${idx + 1}", color = if (isActive) Color.White else SteelGrey, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = step.second, fontSize = 10.sp, color = color, fontWeight = fontWeight, textAlign = TextAlign.Center)
            }
            if (idx < steps.size - 1) {
                Divider(
                    color = if (idx < activeIndex) EscrowGreen else BorderGrey,
                    modifier = Modifier
                        .weight(0.5f)
                        .padding(bottom = 12.dp),
                    thickness = 2.dp
                )
            }
        }
    }
}

// Canvas-drawn ocean shipping lane indicator
@Composable
fun MaritimeRouteMap(shipment: CachedShipment) {
    val progress = shipment.currentProgress

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(150.dp)
            .background(NavySoft, RoundedCornerShape(8.dp))
            .border(1.dp, BorderGrey)
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height

            val startPoint = Offset(width * 0.15f, height * 0.65f) // Shanghai Port (origin)
            val endPoint = Offset(width * 0.85f, height * 0.35f)   // LA Port (destination)

            // Draw shipping route curve path
            val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
            drawLine(
                color = SteelGrey,
                start = startPoint,
                end = endPoint,
                strokeWidth = 3f,
                pathEffect = pathEffect
            )

            // Draw Ports
            drawCircle(color = DarkNavy, radius = 8f, center = startPoint)
            drawCircle(color = PrimaryOrange, radius = 8f, center = endPoint)

            // Draw Active ship container coordinates on the curve
            val currentX = startPoint.x + (endPoint.x - startPoint.x) * progress.toFloat()
            val currentY = startPoint.y + (endPoint.y - startPoint.y) * progress.toFloat()
            val shipPos = Offset(currentX, currentY)

            drawCircle(color = EscrowGreen, radius = 10f, center = shipPos)
            drawCircle(color = Color.White, radius = 4f, center = shipPos)
        }

        // Port labels text
        Text(
            text = "Shanghai",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = DarkNavy,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 12.dp, bottom = 12.dp)
        )

        Text(
            text = "Los Angeles",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = PrimaryOrange,
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(end = 12.dp, top = 12.dp)
        )

        // Progress percentage tag
        Surface(
            color = EscrowGreen,
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier
                .align(Alignment.Center)
                .padding(bottom = 40.dp)
        ) {
            Text(
                text = "${(progress * 100).toInt()}% Transited",
                color = Color.White,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
        }
    }
}
