package com.example.core.database

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object SyntheticDataSeeder {

    suspend fun seedIfNeeded(context: Context, database: AppDatabase) = withContext(Dispatchers.IO) {
        val userPreferencesDao = database.userPreferencesDao()
        val supplierDao = database.supplierDao()
        val productDao = database.productDao()
        val conversationDao = database.conversationDao()
        val messageDao = database.messageDao()
        val rfqDao = database.rfqDao()
        val quoteDao = database.quoteDao()
        val orderDao = database.orderDao()
        val shipmentDao = database.shipmentDao()
        val inspectionDao = database.inspectionDao()

        // Check if seeded
        val existingPrefs = userPreferencesDao.getUserPreferencesOneShot()
        if (existingPrefs != null) {
            // Already seeded
            return@withContext
        }

        // Seed default User Preferences
        userPreferencesDao.insertUserPreferences(
            UserPreferencesEntity(
                id = 0,
                language = "EN",
                companyName = "Apex Global Procurement Ltd.",
                contactName = "Sarah Jenkins",
                country = "United States",
                role = "BUYER",
                taxId = "US-9876543-A",
                addressCountry = "United States",
                addressProvince = "California",
                addressCity = "Los Angeles",
                addressStreet = "750 Commerce Blvd Suite 100",
                addressPhone = "+1 213 555 0199"
            )
        )

        // Seed Suppliers
        val suppliers = listOf(
            CachedSupplier(
                id = "sup_01",
                legalNameEn = "Zhejiang industrial Sourcing Co., Ltd.",
                legalNameZh = "浙江工业采购有限公司",
                displayNameEn = "Zhejiang Industrial Sourcing",
                displayNameZh = "浙江工业采购",
                countryEn = "China",
                countryZh = "中国",
                provinceEn = "Zhejiang",
                provinceZh = "浙江",
                cityEn = "Hangzhou",
                cityZh = "杭州",
                yearsOperating = 12,
                verificationStatus = "FACTORY_VERIFIED",
                responseRate = 98,
                responseTimeEn = "4 hrs",
                responseTimeZh = "4 小时",
                ordersCompleted = 1240,
                productCount = 230,
                factoryTypeEn = "OEM / ODM Manufacturer",
                factoryTypeZh = "OEM/ODM实力工厂",
                certifications = listOf("ISO9001", "CE", "RoHS", "SGS"),
                tradeProtectionAvailable = true,
                primaryMarketsEn = listOf("North America", "Western Europe", "Southeast Asia"),
                primaryMarketsZh = listOf("北美", "西欧", "东南亚"),
                languages = listOf("English", "Chinese")
            ),
            CachedSupplier(
                id = "sup_02",
                legalNameEn = "Rheinland Precision Machinery GmbH",
                legalNameZh = "莱茵兰精密机械有限公司",
                displayNameEn = "Rheinland Precision",
                displayNameZh = "莱茵兰精密机械",
                countryEn = "Germany",
                countryZh = "德国",
                provinceEn = "Bavaria",
                provinceZh = "巴伐利亚",
                cityEn = "Munich",
                cityZh = "慕尼黑",
                yearsOperating = 15,
                verificationStatus = "AUDITED",
                responseRate = 95,
                responseTimeEn = "8 hrs",
                responseTimeZh = "8 小时",
                ordersCompleted = 850,
                productCount = 45,
                factoryTypeEn = "Precision Engineering",
                factoryTypeZh = "精密工程工厂",
                certifications = listOf("ISO14001", "TUV", "CE"),
                tradeProtectionAvailable = true,
                primaryMarketsEn = listOf("Western Europe", "North America", "East Asia"),
                primaryMarketsZh = listOf("西欧", "北美", "东亚"),
                languages = listOf("English", "German")
            ),
            CachedSupplier(
                id = "sup_03",
                legalNameEn = "Indus Solar & Battery Systems Ltd.",
                legalNameZh = "印度太阳能与电池系统系统有限公司",
                displayNameEn = "Indus Solar Systems",
                displayNameZh = "印度索拉太阳能",
                countryEn = "India",
                countryZh = "印度",
                provinceEn = "Gujarat",
                provinceZh = "古吉拉特邦",
                cityEn = "Ahmedabad",
                cityZh = "艾哈迈达巴德",
                yearsOperating = 8,
                verificationStatus = "BUSINESS_VERIFIED",
                responseRate = 92,
                responseTimeEn = "6 hrs",
                responseTimeZh = "6 小时",
                ordersCompleted = 420,
                productCount = 88,
                factoryTypeEn = "New Energy Plant",
                factoryTypeZh = "新能源制造基地",
                certifications = listOf("ISO9001", "UL", "IEC"),
                tradeProtectionAvailable = true,
                primaryMarketsEn = listOf("South Asia", "Middle East", "Africa", "North America"),
                primaryMarketsZh = listOf("南亚", "中东", "非洲", "北美"),
                languages = listOf("English", "Hindi")
            ),
            CachedSupplier(
                id = "sup_04",
                legalNameEn = "VinaText Apparels JSC",
                legalNameZh = "越南纺织服装股份公司",
                displayNameEn = "VinaText Apparels",
                displayNameZh = "越南 VinaText 服装",
                countryEn = "Vietnam",
                countryZh = "越南",
                provinceEn = "Dong Nai",
                provinceZh = "同奈省",
                cityEn = "Bien Hoa",
                cityZh = "边和市",
                yearsOperating = 6,
                verificationStatus = "PRODUCT_VERIFIED",
                responseRate = 96,
                responseTimeEn = "2 hrs",
                responseTimeZh = "2 小时",
                ordersCompleted = 1950,
                productCount = 350,
                factoryTypeEn = "High-Volume Garment Factory",
                factoryTypeZh = "大型成衣制造工厂",
                certifications = listOf("WRAP", "OEKO-TEX", "ISO9001"),
                tradeProtectionAvailable = true,
                primaryMarketsEn = listOf("North America", "Western Europe", "Australia"),
                primaryMarketsZh = listOf("北美", "西欧", "澳大利亚"),
                languages = listOf("English", "Vietnamese", "Chinese")
            ),
            CachedSupplier(
                id = "sup_05",
                legalNameEn = "Texas Industrial Valve & Pump Corp.",
                legalNameZh = "德克萨斯工业阀门与泵业公司",
                displayNameEn = "Texas Valve & Pump",
                displayNameZh = "德州阀门泵业",
                countryEn = "United States",
                countryZh = "美国",
                provinceEn = "Texas",
                provinceZh = "德克萨斯",
                cityEn = "Houston",
                cityZh = "休斯敦",
                yearsOperating = 20,
                verificationStatus = "AUDITED",
                responseRate = 99,
                responseTimeEn = "1 hr",
                responseTimeZh = "1 小时",
                ordersCompleted = 3100,
                productCount = 120,
                factoryTypeEn = "Heavy Duty Mechanical Plant",
                factoryTypeZh = "重型机械制造厂",
                certifications = listOf("ASME", "API", "ISO9001"),
                tradeProtectionAvailable = true,
                primaryMarketsEn = listOf("North America", "South America", "Middle East"),
                primaryMarketsZh = listOf("北美", "南美", "中东"),
                languages = listOf("English", "Spanish")
            )
        )
        supplierDao.insertSuppliers(suppliers)

        // Seed Products
        val products = listOf(
            CachedProduct(
                id = "prod_01",
                nameEn = "Industrial Stainless Steel Water Bottle 750ml",
                nameZh = "750ml 不锈钢工业水瓶",
                originalLang = "EN",
                categoryEn = "Home & Garden",
                categoryZh = "生活百货",
                imageUrl = "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&q=80&w=400",
                supplierId = "sup_01",
                moq = 500,
                priceTiers = listOf(
                    DbPriceTier(1, 499, 3.20, "USD"),
                    DbPriceTier(500, 999, 2.80, "USD"),
                    DbPriceTier(1000, 4999, 2.35, "USD"),
                    DbPriceTier(5000, 99999, 1.95, "USD")
                ),
                isReadyToShip = true,
                isVerifiedSupplier = true,
                isTradeProtection = true,
                responseRate = 98,
                leadTimeDays = 15,
                rating = 4.8,
                descriptionEn = "Double-walled vacuum insulated professional grade 304 stainless steel bottle. Leak-proof custom heavy-duty seal cap, available with custom logo engraving and bespoke cardboard packaging options.",
                descriptionZh = "双层真空保温专业级304不锈钢水瓶。防漏定制重型密封盖，支持激光雕刻定制Logo及专属纸盒包装方案。",
                specEn = mapOf(
                    "Material" to "304 Stainless Steel",
                    "Capacity" to "750 ml",
                    "Weight" to "320 g",
                    "Dimensions" to "75 × 260 mm",
                    "Thermal Insulation" to "12 Hours Hot / 24 Hours Cold"
                ),
                specZh = mapOf(
                    "材质" to "304不锈钢",
                    "容量" to "750 毫升",
                    "重量" to "320 克",
                    "尺寸" to "75 × 260 毫米",
                    "保温性能" to "12小时保温 / 24小时保冷"
                ),
                customisationOptions = listOf(
                    DbCustomisationOption("Custom Logo Engraving", "定制激光Logo", "Laser engraving on the metal surface", "金属表面激光激光刻字", 500, 0.15, 2),
                    DbCustomisationOption("Custom Packaging", "定制包装外盒", "Branded box packaging design", "定制品牌外包装纸盒", 1000, 0.30, 4),
                    DbCustomisationOption("Bespoke Color Paint", "特定喷漆颜色", "Custom powder coating paint", "定制粉末喷涂涂层", 2000, 0.25, 5)
                ),
                samplePrice = 10.0,
                sampleShippingCost = 15.0,
                whyRecommendedEn = "Recommended because you frequently search for double-wall drinkware and this supplier has verified 15-day on-time dispatch.",
                whyRecommendedZh = "推荐理由：检测到您频繁搜索双层饮水容器，且该金牌供应商支持15天保障准时发货。"
            ),
            CachedProduct(
                id = "prod_02",
                nameEn = "High-Efficiency Monocrystalline Solar Panel 550W",
                nameZh = "550W 高效单晶太阳能光伏板",
                originalLang = "EN",
                categoryEn = "Solar",
                categoryZh = "新能源",
                imageUrl = "https://images.unsplash.com/photo-1509391366360-2e959784a276?auto=format&fit=crop&q=80&w=400",
                supplierId = "sup_03",
                moq = 100,
                priceTiers = listOf(
                    DbPriceTier(1, 99, 120.00, "USD"),
                    DbPriceTier(100, 499, 98.00, "USD"),
                    DbPriceTier(500, 1999, 85.00, "USD"),
                    DbPriceTier(2000, 99999, 72.00, "USD")
                ),
                isReadyToShip = false,
                isVerifiedSupplier = true,
                isTradeProtection = true,
                responseRate = 92,
                leadTimeDays = 25,
                rating = 4.9,
                descriptionEn = "Grade A Monocrystalline Solar Cells with 21.3% conversion efficiency. High transparency tempered glass with anti-reflective coating. Sturdy anodized aluminum alloy frame.",
                descriptionZh = "A级单晶太阳能电池片，转换效率达21.3%。高透光率减反射涂层钢化玻璃。坚固的阳极氧化铝合金边框。",
                specEn = mapOf(
                    "Power Output" to "550 Watts",
                    "Cell Type" to "Monocrystalline",
                    "Efficiency" to "21.3%",
                    "Dimensions" to "2279 × 1134 × 35 mm",
                    "Weight" to "28.6 kg"
                ),
                specZh = mapOf(
                    "输出功率" to "550 瓦特",
                    "电池片类别" to "单晶硅",
                    "转换效率" to "21.3%",
                    "尺寸" to "2279 × 1134 × 35 毫米",
                    "重量" to "28.6 公斤"
                ),
                customisationOptions = listOf(
                    DbCustomisationOption("Custom Cable Length", "定制接线盒线缆长度", "Bespoke MC4 cable length integration", "定制MC4接头线缆长度", 100, 1.50, 2),
                    DbCustomisationOption("Private Label Printing", "定制背面丝印标签", "Logo printing on backsheet", "背面防水标签丝印定制", 500, 0.50, 3)
                ),
                samplePrice = 150.0,
                sampleShippingCost = 90.0,
                whyRecommendedEn = "Recommended because this product meets key regulatory standards (UL, CE) and matches your energy sector preferences.",
                whyRecommendedZh = "推荐理由：此产品符合主要新能源监管标准（UL，CE），极度契合您的能源类目采购意向。"
            ),
            CachedProduct(
                id = "prod_03",
                nameEn = "Heavy Duty Centrifugal Industrial Water Pump",
                nameZh = "重型离心工业水泵",
                originalLang = "EN",
                categoryEn = "Industrial Equipment",
                categoryZh = "工业设备",
                imageUrl = "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=400",
                supplierId = "sup_05",
                moq = 5,
                priceTiers = listOf(
                    DbPriceTier(1, 4, 850.00, "USD"),
                    DbPriceTier(5, 19, 720.00, "USD"),
                    DbPriceTier(20, 99, 650.00, "USD"),
                    DbPriceTier(100, 99999, 580.00, "USD")
                ),
                isReadyToShip = false,
                isVerifiedSupplier = true,
                isTradeProtection = true,
                responseRate = 99,
                leadTimeDays = 30,
                rating = 4.7,
                descriptionEn = "Heavy-duty cast iron centrifugal water pump for high flow rate industrial application. Equipped with premium Siemens motor and anti-corrosive impeller options.",
                descriptionZh = "重型铸铁离心式水泵，专为高流量工业供水及循环设计。搭载优质西门子电机，提供耐腐蚀叶轮定制选型。",
                specEn = mapOf(
                    "Flow Rate" to "120 m³/h",
                    "Motor Power" to "15 kW (20 HP)",
                    "Inlet / Outlet" to "80 mm / 65 mm",
                    "Max Head" to "45 meters",
                    "Impeller Material" to "Bronze / Stainless Steel"
                ),
                specZh = mapOf(
                    "最大流量" to "120 立方米/小时",
                    "电机功率" to "15 千瓦 (20 马力)",
                    "进出口径" to "80 毫米 / 65 毫米",
                    "最大扬程" to "45 米",
                    "叶轮材质" to "青铜 / 不锈钢"
                ),
                customisationOptions = listOf(
                    DbCustomisationOption("Stainless Impeller Upgrade", "升级不锈钢叶轮", "Upgrade impeller material to SS316", "将叶轮升级为SS316不锈钢材质", 5, 120.00, 4),
                    DbCustomisationOption("Custom Voltage Integration", "特定电压定制", "Configure motor for specific industrial grids", "配置满足特定国家工业电网电压（如380V/415V）", 10, 50.00, 5)
                ),
                samplePrice = 950.0,
                sampleShippingCost = 250.0,
                whyRecommendedEn = "Recommended because this industrial pump fits your target price limit and ships directly from Texas Audited mechanical plant.",
                whyRecommendedZh = "推荐理由：此工业重型水泵符合您的采购价格区间，且由美国德克萨斯州已验厂的实力实体工厂直供。"
            ),
            CachedProduct(
                id = "prod_04",
                nameEn = "Premium Organic Cotton Yarn Garment Fabric",
                nameZh = "优质有机棉精梳纱成衣面料",
                originalLang = "ZH_CN",
                categoryEn = "Textiles & Apparel",
                categoryZh = "纺织服装",
                imageUrl = "https://images.unsplash.com/photo-1544816155-12df9643f363?auto=format&fit=crop&q=80&w=400",
                supplierId = "sup_04",
                moq = 1000,
                priceTiers = listOf(
                    DbPriceTier(1, 999, 4.50, "USD"),
                    DbPriceTier(1000, 4999, 3.80, "USD"),
                    DbPriceTier(5000, 19999, 3.20, "USD"),
                    DbPriceTier(20000, 99999, 2.90, "USD")
                ),
                isReadyToShip = true,
                isVerifiedSupplier = true,
                isTradeProtection = true,
                responseRate = 96,
                leadTimeDays = 12,
                rating = 4.6,
                descriptionEn = "100% GOTS certified premium organic combed cotton. Breathable, hypoallergenic fabric roll ideal for infant apparel, casual wear, and luxury textiles.",
                descriptionZh = "100% GOTS认证的优质有机精梳棉。透气环保、防过敏面料，适用于婴儿服饰、高档便服及家纺面料。",
                specEn = mapOf(
                    "Composition" to "100% Organic Cotton",
                    "Weight" to "180 gsm (Grams per Square Meter)",
                    "Width" to "160 cm",
                    "Weave Style" to "Single Jersey Knit",
                    "Colorfastness" to "Grade 4"
                ),
                specZh = mapOf(
                    "面料成分" to "100% 有机棉",
                    "克重" to "180 gsm (克/平方米)",
                    "门幅宽度" to "160 厘米",
                    "织法工艺" to "单面针织汗布",
                    "色牢度" to "4级以上"
                ),
                customisationOptions = listOf(
                    DbCustomisationOption("Custom Dye Match", "潘通色定制染色", "Pantone color dye matching service", "定制潘通(Pantone)色卡染色服务", 1000, 0.15, 3),
                    DbCustomisationOption("Roll Length Adjustment", "特定卷卷长度", "Bespoke rolling packaging dimensions", "按米数或公斤定制单卷包装长度", 2000, 0.05, 1)
                ),
                samplePrice = 15.0,
                sampleShippingCost = 35.0,
                whyRecommendedEn = "Recommended because this factory is Certified WRAP and OEKO-TEX, matching sustainable apparel procurement guidelines.",
                whyRecommendedZh = "推荐理由：该成衣面料工厂具备 WRAP 和 OEKO-TEX 可持续认证，符合绿色采购规范。"
            )
        )
        productDao.insertProducts(products)

        // Seed initial Conversations
        val initialConversations = listOf(
            CachedConversation(
                id = "conv_sup_01",
                supplierId = "sup_01",
                supplierNameEn = "Zhejiang Industrial Sourcing",
                supplierNameZh = "浙江工业采购",
                lastMessageText = "We can provide customised packaging for 5,000 units.",
                lastMessageTime = System.currentTimeMillis() - 3600000,
                unreadCount = 1
            ),
            CachedConversation(
                id = "conv_sup_05",
                supplierId = "sup_05",
                supplierNameEn = "Texas Valve & Pump",
                supplierNameZh = "德州阀门泵业",
                lastMessageText = "Please confirm the required voltage configuration for the motor.",
                lastMessageTime = System.currentTimeMillis() - 86400000,
                unreadCount = 0
            )
        )
        for (conv in initialConversations) {
            conversationDao.insertConversation(conv)
        }

        // Seed initial Messages
        val messages = listOf(
            CachedMessage(
                id = "msg_01",
                conversationId = "conv_sup_01",
                senderType = "BUYER",
                textEn = "Hello, we are interested in purchasing 5,000 units. Please provide details on packaging customisation and sample cost.",
                textZh = "您好，我们对采购5,000件产品感兴趣。请提供有关定制包装以及样品费用的详细信息。",
                originalText = "Hello, we are interested in purchasing 5,000 units. Please provide details on packaging customisation and sample cost.",
                originalLang = "EN",
                timestamp = System.currentTimeMillis() - 7200000,
                productRefId = "prod_01"
            ),
            CachedMessage(
                id = "msg_02",
                conversationId = "conv_sup_01",
                senderType = "SUPPLIER",
                textEn = "We can provide customised packaging for 5,000 units.",
                textZh = "我们可以提供5000件的定制包装。",
                originalText = "我们可以提供5000件的定制包装。",
                originalLang = "ZH_CN",
                timestamp = System.currentTimeMillis() - 3600000,
                productRefId = "prod_01"
            ),
            CachedMessage(
                id = "msg_03",
                conversationId = "conv_sup_05",
                senderType = "BUYER",
                textEn = "We need an estimate for 10 units of the centrifugal water pump delivered to Los Angeles.",
                textZh = "我们需要一份运往洛杉矶的10台离心水泵的估价。",
                originalText = "We need an estimate for 10 units of the centrifugal water pump delivered to Los Angeles.",
                originalLang = "EN",
                timestamp = System.currentTimeMillis() - 90000000,
                productRefId = "prod_03"
            ),
            CachedMessage(
                id = "msg_04",
                conversationId = "conv_sup_05",
                senderType = "SUPPLIER",
                textEn = "Please confirm the required voltage configuration for the motor.",
                textZh = "请确认电机所需的电压配置。",
                originalText = "请确认电机所需的电压配置。",
                originalLang = "ZH_CN",
                timestamp = System.currentTimeMillis() - 86400000,
                productRefId = "prod_03"
            )
        )
        for (msg in messages) {
            messageDao.insertMessage(msg)
        }

        // Seed an RFQ
        val initialRFQ = CachedRFQ(
            id = "rfq_01",
            productTitle = "Stainless Steel Water Bottles",
            quantity = 5000,
            unit = "pieces",
            targetPrice = 2.10,
            currency = "USD",
            destination = "Los Angeles, CA",
            deliveryDate = "2026-11-01",
            specificationsEn = "Capacity: 750ml, Food-Grade 304 Stainless Steel, Double-wall vacuum insulated, Custom laser engraved logo on the front side.",
            specificationsZh = "容量: 750ml, 食品级304不锈钢, 双层真空绝热, 前侧定制激光雕刻商标。",
            notes = "Require fast shipping and Trade Protection. Please submit samples as well.",
            status = "QUOTING",
            dateCreated = System.currentTimeMillis() - 172800000 // 2 days ago
        )
        rfqDao.insertRFQ(initialRFQ)

        // Seed Quotes for RFQ
        val initialQuotes = listOf(
            CachedQuote(
                id = "q_01",
                rfqId = "rfq_01",
                supplierId = "sup_01",
                supplierNameEn = "Zhejiang Industrial Sourcing",
                supplierNameZh = "浙江工业采购",
                unitPrice = 2.31,
                moq = 1000,
                leadTimeDays = 12,
                sampleCost = 10.0,
                shippingCost = 120.0,
                toolingCost = 0.0,
                validityPeriod = "30 Days",
                paymentTermsEn = "30% Deposit, 70% Balance before shipment via Trade Protection Escrow",
                paymentTermsZh = "30% 订金，70% 尾款出货前付清，支持贸易保障第三方代管",
                incoterm = "FOB",
                customisationEn = "Full laser engraving and color paint support included.",
                customisationZh = "包含全激光雕刻定制和喷漆颜色定制支持。",
                certificationsEn = "ISO9001, CE, RoHS, FDA food-grade certification",
                certificationsZh = "ISO9001, CE, RoHS, FDA食品级检测",
                status = "SUBMITTED"
            ),
            CachedQuote(
                id = "q_02",
                rfqId = "rfq_01",
                supplierId = "sup_04",
                supplierNameEn = "VinaText Apparels",
                supplierNameZh = "越南 VinaText 服装",
                unitPrice = 2.18,
                moq = 5000,
                leadTimeDays = 18,
                sampleCost = 25.0,
                shippingCost = 180.0,
                toolingCost = 0.0,
                validityPeriod = "15 Days",
                paymentTermsEn = "100% Paid in Secure Escrow",
                paymentTermsZh = "100% 托管保障付款",
                incoterm = "EXW",
                customisationEn = "Logo printing available (minimum 5,000 units)",
                customisationZh = "支持商标印刷（最低起订量 5,000 件）",
                certificationsEn = "ISO9001, BSCI",
                certificationsZh = "ISO9001 质量认证, BSCI 社会责任认证",
                status = "SUBMITTED"
            )
        )
        quoteDao.insertQuotes(initialQuotes)

        // Seed an Active Order
        val activeOrder = CachedOrder(
            id = "GT-20483",
            productId = "prod_03",
            productNameEn = "Heavy Duty Centrifugal Industrial Water Pump",
            productNameZh = "重型离心工业水泵",
            productImageUrl = "https://images.unsplash.com/photo-1581092160607-ee22621dd758?auto=format&fit=crop&q=80&w=400",
            supplierId = "sup_05",
            supplierNameEn = "Texas Valve & Pump",
            supplierNameZh = "德州阀门泵业",
            quantity = 5,
            unit = "pieces",
            unitPrice = 720.00,
            currency = "USD",
            totalPrice = 3600.00,
            status = "PRODUCTION",
            productionStatus = "PRODUCTION",
            isTradeProtected = true,
            dateCreated = System.currentTimeMillis() - 864000000, // 10 days ago
            negotiationHistory = listOf(
                DbNegotiationRound(1, 850.00, 5, "SUPPLIER", "Initial supplier catalog quotation.", "初始目录商品报价。", System.currentTimeMillis() - 1000000000),
                DbNegotiationRound(2, 680.00, 5, "BUYER", "Requesting a budget-friendly bulk target price.", "由于预算有限，请求批量目标优惠价。", System.currentTimeMillis() - 950000000),
                DbNegotiationRound(3, 720.00, 5, "SUPPLIER", "Best factory-direct offer with customized voltage support.", "包含定制电压及合格整机检验的德州出厂最优惠报价。", System.currentTimeMillis() - 900000000),
                DbNegotiationRound(4, 720.00, 5, "BUYER", "Accepted the counter-offer, creating purchase order.", "同意还盘条件，已签章确认采购合同并付款。", System.currentTimeMillis() - 864000000)
            ),
            paymentStatus = "HELD",
            activeEscrowState = "HELD"
        )
        orderDao.insertOrder(activeOrder)

        // Seed Shipment for this Order
        val activeShipment = CachedShipment(
            id = "ship_01",
            orderId = "GT-20483",
            carrier = "Maersk Global Shipping",
            origin = "Port of Shanghai, China",
            destination = "Port of Los Angeles, USA",
            containerNum = "MSKU-483920-1",
            trackingNum = "MSK9876543210",
            transportMode = "SEA",
            etd = "2026-09-10",
            eta = "2026-10-18",
            currentLocationEn = "In Transit - Crossing North Pacific Ocean",
            currentLocationZh = "海运航行中 - 正在横渡北太平洋",
            status = "IN_TRANSIT",
            lastUpdated = System.currentTimeMillis(),
            originLat = 31.2304,
            originLng = 121.4737, // Shanghai
            destLat = 33.7431,
            destLng = -118.2673, // LA Port
            currentProgress = 0.35 // 35% in transit
        )
        shipmentDao.insertShipment(activeShipment)

        // Seed Pre-Shipment Inspection Report
        val inspection = CachedInspection(
            id = "insp_01",
            orderId = "GT-20483",
            inspectionTypeEn = "Pre-Shipment Factory Inspection",
            inspectionTypeZh = "装运前出厂质量检测",
            result = "PASS",
            findingsEn = "Motor leakage test PASSED. Impeller rotational balance alignment verified within +/- 0.1g. Electrical insulation tested up to 1000V DC. Packaging wooden crate secured properly.",
            findingsZh = "电机密封阻水性测试合格。不锈钢叶轮动平衡校验误差小于 +/- 0.1g。电气绝缘耐压达到1000V DC标准。出运木箱已完成加固与防潮封装。",
            inspectorEn = "SGS Global Mechanical Team",
            inspectorZh = "SGS 通标全球机械检测组",
            date = "2026-09-08",
            photoUrls = listOf()
        )
        inspectionDao.insertInspections(listOf(inspection))
    }
}
