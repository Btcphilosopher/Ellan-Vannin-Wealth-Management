package com.example.core.localization

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class Language {
    EN, ZH_CN
}

object LocalizationManager {
    private val _currentLanguage = MutableStateFlow(Language.EN)
    val currentLanguage: StateFlow<Language> = _currentLanguage.asStateFlow()

    fun setLanguage(language: Language) {
        _currentLanguage.value = language
    }

    private val translations = mapOf(
        Language.EN to mapOf(
            "app.name" to "GLOBAL TRADE",
            "nav.home" to "Home",
            "nav.discover" to "Discover",
            "nav.messages" to "Messages",
            "nav.orders" to "Orders",
            "nav.account" to "Account",
            
            "home.search_placeholder" to "Search products, suppliers or keywords",
            "home.recommended" to "Recommended Products",
            "home.popular" to "Popular Sourcing",
            "home.new_products" to "New Products",
            "home.ready_to_ship" to "Ready to Ship",
            "home.top_suppliers" to "Top Suppliers",
            "home.factory_direct" to "Factory Direct",
            "home.deals" to "Deals",
            "home.sourcing_assistant" to "Sourcing Assistant",
            "home.active_negotiations" to "Active Negotiations",
            "home.orders_in_production" to "Orders in Production",
            "home.shipments_in_transit" to "Shipments in Transit",
            "home.pending_payments" to "Pending Payments",
            "home.unread_messages" to "Unread Messages",
            "home.favourite_suppliers" to "Favourite Suppliers",
            "home.recent_products" to "Recent Products",
            
            "product.request_quote" to "Request a Quote",
            "product.contact_supplier" to "Contact Supplier",
            "product.trade_protection" to "Trade Protection",
            "product.ships_in_15" to "Ships in 15 days",
            "product.moq" to "Minimum Order Quantity",
            "product.moq_pcs" to "MOQ %d pcs",
            "product.moq_units" to "MOQ %d %s",
            "product.customization" to "Customisation",
            "product.lead_time" to "Lead Time",
            "product.certifications" to "Certifications",
            "product.rating" to "Rating",
            "product.response_rate" to "Response Rate",
            "product.response_time" to "Response Time",
            "product.shipping_options" to "Shipping Options",
            "product.specifications" to "Product Specification",
            "product.packaging" to "Packaging",
            "product.samples" to "Samples",
            "product.request_sample" to "Request Sample",
            "product.price_breaks" to "Quantity Pricing",
            "product.verified" to "Verified Supplier",
            "product.why_recommended" to "Why this product?",
            
            "supplier.profile" to "Supplier Profile",
            "supplier.verified" to "Verified",
            "supplier.factory" to "Factory Direct",
            "supplier.years" to "%d years",
            "supplier.response_rate" to "%d%% response",
            "supplier.response_time" to "≤ %s",
            "supplier.main_markets" to "Main Markets",
            "supplier.orders_completed" to "Orders Completed",
            "supplier.product_count" to "Total Products",
            "supplier.factory_type" to "Factory Type",
            "supplier.languages" to "Languages Spoken",
            "supplier.follow" to "Follow Supplier",
            "supplier.followed" to "Following",
            
            "message.center" to "Message Centre",
            "message.show_original" to "Show Original",
            "message.show_translated" to "Show Translated",
            "message.chat_placeholder" to "Type a message...",
            "message.translate_fail" to "[Translation Failed]",
            "message.draft_prompt" to "Draft B2B Inquiry",
            "message.ai_draft_helper" to "Generate B2B Sourcing Draft",
            "message.quote_ref" to "Quote Reference",
            "message.order_ref" to "Order Reference",
            "message.rfq_ref" to "RFQ Reference",
            
            "rfq.title" to "Request For Quotation (RFQ)",
            "rfq.my_rfqs" to "My RFQs",
            "rfq.create_rfq" to "Post RFQ",
            "rfq.product_name" to "Product Name / Category",
            "rfq.qty" to "Quantity Needed",
            "rfq.unit" to "Unit (e.g. pieces, sets)",
            "rfq.specifications" to "Product Specifications",
            "rfq.material" to "Material Requirements",
            "rfq.dimensions" to "Dimensions",
            "rfq.target_price" to "Target Price (USD/unit)",
            "rfq.destination" to "Destination Port / City",
            "rfq.delivery_date" to "Required Delivery Date",
            "rfq.customization" to "Customisation Requirements",
            "rfq.notes" to "Additional Notes",
            "rfq.submit" to "Send RFQ",
            "rfq.quotes_received" to "%d Quotes Received",
            "rfq.compare_quotes" to "Compare Quotes",
            "rfq.no_rfqs" to "No RFQs posted yet. Submit your sourcing requirement to get quotes!",
            
            "quote.details" to "Quote Details",
            "quote.compare" to "Quote Comparison",
            "quote.unit_price" to "Unit Price",
            "quote.moq" to "MOQ",
            "quote.lead_time" to "Lead Time",
            "quote.sample_cost" to "Sample Cost",
            "quote.shipping" to "Shipping Cost",
            "quote.tooling" to "Tooling Cost",
            "quote.validity" to "Validity Period",
            "quote.negotiate" to "Negotiate",
            "quote.accept" to "Accept Quote",
            "quote.status" to "Quote Status",
            "quote.best_price" to "Best Price",
            "quote.fastest" to "Fastest",
            "quote.best_supplier" to "Top Supplier",
            
            "neg.negotiation" to "Price Negotiation",
            "neg.history" to "Negotiation History",
            "neg.propose" to "Propose Counter-Offer",
            "neg.target_price" to "My Proposed Price",
            "neg.qty" to "Order Quantity",
            "neg.notes" to "Message to Supplier",
            "neg.submit_offer" to "Submit Counter-Offer",
            "neg.supplier_offer" to "Supplier's Offer",
            "neg.buyer_offer" to "Buyer's Offer",
            "neg.accepted" to "Offer Accepted",
            "neg.rejected" to "Offer Rejected",
            "neg.pending" to "Pending Response",
            "neg.accept_current" to "Accept Offer & Create PO",
            
            "order.tracking" to "Order Tracking",
            "order.list" to "My Orders",
            "order.details" to "Order Details",
            "order.summary" to "Order Summary",
            "order.po_number" to "PO Number",
            "order.total" to "Total Amount",
            "order.status" to "Order Status",
            "order.production_status" to "Production Status",
            "order.confirm_delivery" to "Confirm Delivery",
            "order.pay_now" to "Pay Now",
            "order.trade_protection_active" to "Protected by Trade Protection",
            "order.payment_escrow" to "Protected Escrow Payment",
            "order.eta" to "Estimated Arrival",
            "order.quality_control" to "Quality Inspection",
            "order.dispute" to "Open Dispute",
            
            "payment.secure" to "Secure Payment",
            "payment.select_method" to "Select Payment Method",
            "payment.credit_card" to "Credit / Debit Card",
            "payment.bank_transfer" to "Wire Transfer / TT",
            "payment.digital_wallet" to "Digital Wallet",
            "payment.success" to "Payment Authorized Successfully",
            "payment.failed" to "Payment Declined / Timeout",
            "payment.protection_title" to "B2B Trade Protection System",
            "payment.escrow_held" to "Funds Held in Secure Escrow",
            "payment.escrow_released" to "Funds Released to Supplier",
            "payment.refunded" to "Refund Processed",
            
            "logistics.tracking" to "Logistics Tracking",
            "logistics.carrier" to "Carrier",
            "logistics.container" to "Container Number",
            "logistics.tracking_no" to "Tracking Number",
            "logistics.mode" to "Transport Mode",
            "logistics.etd" to "ETD (Departure)",
            "logistics.eta" to "ETA (Arrival)",
            "logistics.route_map" to "Trade Route Tracker",
            "logistics.mode.air" to "Air Freight",
            "logistics.mode.sea" to "Ocean Freight",
            "logistics.mode.rail" to "Rail Freight",
            "logistics.mode.road" to "Road Freight",
            
            "qc.inspection_report" to "Inspection Report",
            "qc.inspector" to "Inspector",
            "qc.findings" to "Findings / Corrective Actions",
            "qc.status" to "Inspection Status",
            "qc.type" to "Inspection Type",
            "qc.date" to "Inspection Date",
            "qc.pass" to "PASS",
            "qc.fail" to "FAIL",
            
            "dispute.title" to "Dispute Center",
            "dispute.reason" to "Reason for Dispute",
            "dispute.statement" to "Buyer Statement",
            "dispute.status" to "Dispute Status",
            "dispute.resolution" to "Mediation / Resolution",
            "dispute.submit" to "File Dispute",
            "dispute.amount" to "Requested Refund Amount",
            
            "ai.assistant" to "AI Sourcing Assistant",
            "ai.welcome" to "Hello, I am your Global Trade Sourcing Assistant. How can I help you source, compare, negotiate or draft RFQs today?",
            "ai.find_prompt" to "Find stainless steel water bottles",
            "ai.compare_prompt" to "Compare solar panel quotes",
            "ai.rfq_prompt" to "Draft RFQ for 10,000 pumps",
            "ai.input_placeholder" to "Ask Sourcing Assistant...",
            "ai.draft_rfq_ready" to "RFQ Sourcing Plan Drafted! Review below to Post.",
            "ai.data_used" to "Source Data: Synthetic Global Index",
            "ai.confidence" to "Confidence: %d%%",
            "ai.why_explanation" to "Recommended because this supplier matches your location and MOQ requirements.",
            
            "account.title" to "My Business Account",
            "account.company" to "Company Name",
            "account.contact" to "Contact Person",
            "account.country" to "Country / Region",
            "account.role" to "Procurement Role",
            "account.tax_id" to "Tax ID / EIN",
            "account.switch_lang" to "Language / 语言",
            "account.role.owner" to "Company Owner",
            "account.role.buyer" to "Sourcing Buyer",
            "account.role.finance" to "Finance Manager",
            "account.role.logistics" to "Logistics Specialist",
            "account.verified_buyer" to "Verified Business Buyer",
            "account.development_mode" to "SYNTHETIC DEVELOPMENT DATA ACTIVE",
            
            "common.units.pcs" to "pieces",
            "common.units.sets" to "sets",
            "common.units.cartons" to "cartons",
            "common.units.kg" to "kg",
            "common.units.tonnes" to "tonnes",
            "common.save" to "Save",
            "common.cancel" to "Cancel",
            "common.close" to "Close",
            "common.back" to "Back",
            "common.confirm" to "Confirm",
            "common.status" to "Status",
            "common.actions" to "Actions"
        ),
        Language.ZH_CN to mapOf(
            "app.name" to "全球贸易",
            "nav.home" to "首页",
            "nav.discover" to "发现",
            "nav.messages" to "消息",
            "nav.orders" to "订单",
            "nav.account" to "我的",
            
            "home.search_placeholder" to "搜索产品、供应商或关键词",
            "home.recommended" to "推荐产品",
            "home.popular" to "热门采购",
            "home.new_products" to "新品推荐",
            "home.ready_to_ship" to "现货产品",
            "home.top_suppliers" to "优质供应商",
            "home.factory_direct" to "工厂直供",
            "home.deals" to "优惠活动",
            "home.sourcing_assistant" to "采购助手",
            "home.active_negotiations" to "洽谈中的订单",
            "home.orders_in_production" to "生产中的订单",
            "home.shipments_in_transit" to "在途物流",
            "home.pending_payments" to "待付款订单",
            "home.unread_messages" to "未读消息",
            "home.favourite_suppliers" to "关注的供应商",
            "home.recent_products" to "最近浏览",
            
            "product.request_quote" to "立即询价",
            "product.contact_supplier" to "联系供应商",
            "product.trade_protection" to "贸易保障",
            "product.ships_in_15" to "15天内发货",
            "product.moq" to "最小起订量",
            "product.moq_pcs" to "起订量 %d 件",
            "product.moq_units" to "起订量 %d %s",
            "product.customization" to "定制服务",
            "product.lead_time" to "交期",
            "product.certifications" to "企业认证",
            "product.rating" to "评分",
            "product.response_rate" to "回复率",
            "product.response_time" to "响应时间",
            "product.shipping_options" to "物流方案",
            "product.specifications" to "产品规格",
            "product.packaging" to "包装规格",
            "product.samples" to "拿样支持",
            "product.request_sample" to "索取样品",
            "product.price_breaks" to "阶梯价格",
            "product.verified" to "金牌供应商",
            "product.why_recommended" to "推荐理由",
            
            "supplier.profile" to "供应商详情",
            "supplier.verified" to "金牌供应商",
            "supplier.factory" to "实力工厂",
            "supplier.years" to "入驻 %d 年",
            "supplier.response_rate" to "%d%% 及时回复",
            "supplier.response_time" to "≤ %s 小时",
            "supplier.main_markets" to "主营市场",
            "supplier.orders_completed" to "累计成交订单",
            "supplier.product_count" to "商品数量",
            "supplier.factory_type" to "工厂类型",
            "supplier.languages" to "支持语言",
            "supplier.follow" to "关注供应商",
            "supplier.followed" to "已关注",
            
            "message.center" to "消息中心",
            "message.show_original" to "显示原文",
            "message.show_translated" to "显示译文",
            "message.chat_placeholder" to "输入新消息...",
            "message.translate_fail" to "[翻译失败]",
            "message.draft_prompt" to "生成询价草稿",
            "message.ai_draft_helper" to "AI 自动生成询价意向",
            "message.quote_ref" to "关联报价单",
            "message.order_ref" to "关联订单",
            "message.rfq_ref" to "关联询价单",
            
            "rfq.title" to "采购意向/询价单 (RFQ)",
            "rfq.my_rfqs" to "我的询价",
            "rfq.create_rfq" to "发布询价",
            "rfq.product_name" to "产品名称/类目",
            "rfq.qty" to "采购数量",
            "rfq.unit" to "单位 (如：件，套)",
            "rfq.specifications" to "规格要求",
            "rfq.material" to "材质要求",
            "rfq.dimensions" to "尺寸规格",
            "rfq.target_price" to "期望单价 (USD/单位)",
            "rfq.destination" to "目的地国家/城市",
            "rfq.delivery_date" to "期望交货期",
            "rfq.customization" to "定制要求",
            "rfq.notes" to "补充备注",
            "rfq.submit" to "发布询价",
            "rfq.quotes_received" to "已收到 %d 份报价",
            "rfq.compare_quotes" to "对比报价单",
            "rfq.no_rfqs" to "暂无发布的询价。发布采购意向后，金牌供应商将主动为您报价！",
            
            "quote.details" to "报价单详情",
            "quote.compare" to "报价对比",
            "quote.unit_price" to "报价单价",
            "quote.moq" to "起订量要求",
            "quote.lead_time" to "交期期限",
            "quote.sample_cost" to "样品费用",
            "quote.shipping" to "物流运费",
            "quote.tooling" to "模具费用",
            "quote.validity" to "报价有效期",
            "quote.negotiate" to "进一步谈判",
            "quote.accept" to "采纳报价",
            "quote.status" to "报价状态",
            "quote.best_price" to "价格最优",
            "quote.fastest" to "交期最快",
            "quote.best_supplier" to "优质商家",
            
            "neg.negotiation" to "订单价格谈判",
            "neg.history" to "谈判协商历史",
            "neg.propose" to "提出新还盘",
            "neg.target_price" to "我的期望还盘单价",
            "neg.qty" to "订购数量",
            "neg.notes" to "给供应商留言",
            "neg.submit_offer" to "提交还盘",
            "neg.supplier_offer" to "供应商报价",
            "neg.buyer_offer" to "买家还盘",
            "neg.accepted" to "还盘已达成",
            "neg.rejected" to "还盘被拒绝",
            "neg.pending" to "等待对方回复",
            "neg.accept_current" to "采纳当前条件并创建采购合同 (PO)",
            
            "order.tracking" to "订单追踪",
            "order.list" to "我的订单",
            "order.details" to "订单详情",
            "order.summary" to "合同概要",
            "order.po_number" to "采购单号",
            "order.total" to "合同总额",
            "order.status" to "订单状态",
            "order.production_status" to "工厂生产进度",
            "order.confirm_delivery" to "确认收货",
            "order.pay_now" to "立即付款",
            "order.trade_protection_active" to "已开启贸易保障",
            "order.payment_escrow" to "受保障的第三方代管支付",
            "order.eta" to "预计送达时间",
            "order.quality_control" to "质量检测结果",
            "order.dispute" to "申请纠纷维权",
            
            "payment.secure" to "安全交易付款",
            "payment.select_method" to "选择支付方式",
            "payment.credit_card" to "信用卡/借记卡",
            "payment.bank_transfer" to "国际电汇 / T/T",
            "payment.digital_wallet" to "电子钱包",
            "payment.success" to "付款授权成功",
            "payment.failed" to "付款被拒或交易超时",
            "payment.protection_title" to "全球贸易保障体系",
            "payment.escrow_held" to "资金已安全代管 (Escrow)",
            "payment.escrow_released" to "资金已解冻给供应商",
            "payment.refunded" to "退款已原路退回",
            
            "logistics.tracking" to "国际物流追踪",
            "logistics.carrier" to "承运商",
            "logistics.container" to "集装箱号",
            "logistics.tracking_no" to "货运单号",
            "logistics.mode" to "运输模式",
            "logistics.etd" to "ETD (预计发船日)",
            "logistics.eta" to "ETA (预计到港日)",
            "logistics.route_map" to "航运线路跟踪",
            "logistics.mode.air" to "空运服务",
            "logistics.mode.sea" to "海运联运",
            "logistics.mode.rail" to "铁路货运",
            "logistics.mode.road" to "公路运输",
            
            "qc.inspection_report" to "质检报告",
            "qc.inspector" to "质检员",
            "qc.findings" to "检测结果及整改说明",
            "qc.status" to "质检状态",
            "qc.type" to "质检类别",
            "qc.date" to "质检日期",
            "qc.pass" to "合格 (PASS)",
            "qc.fail" to "不合格 (FAIL)",
            
            "dispute.title" to "纠纷维权中心",
            "dispute.reason" to "维权原因",
            "dispute.statement" to "买家申诉说明",
            "dispute.status" to "纠纷状态",
            "dispute.resolution" to "官方仲裁/解决进展",
            "dispute.submit" to "提交纠纷申请",
            "dispute.amount" to "申请退款金额",
            
            "ai.assistant" to "智能采购助手",
            "ai.welcome" to "您好！我是您的全球贸易采购助手。我可以帮您寻找产品、对比报价、草拟询价单(RFQ)或跟进采购订单。今天有什么可以帮您？",
            "ai.find_prompt" to "寻找不锈钢工业水瓶",
            "ai.compare_prompt" to "对比太阳能板报价",
            "ai.rfq_prompt" to "草拟1万件水泵的询价单",
            "ai.input_placeholder" to "输入采购问题...",
            "ai.draft_rfq_ready" to "询价单方案已生成！请在下方核对，一键发布。",
            "ai.data_used" to "数据来源：全球贸易商索引库",
            "ai.confidence" to "匹配度: %d%%",
            "ai.why_explanation" to "推荐理由：该商家匹配您的地理位置并支持您的最小起订量。",
            
            "account.title" to "企业采购账号",
            "account.company" to "企业名称",
            "account.contact" to "联系人",
            "account.country" to "国家/地区",
            "account.role" to "采购职位",
            "account.tax_id" to "企业税号/注册号",
            "account.switch_lang" to "Language / 语言",
            "account.role.owner" to "企业所有者",
            "account.role.buyer" to "专业采购员",
            "account.role.finance" to "财务主管",
            "account.role.logistics" to "物流经理",
            "account.verified_buyer" to "已认证采购商企业",
            "account.development_mode" to "系统处于开发环境 (模拟全球贸易库)",
            
            "common.units.pcs" to "件",
            "common.units.sets" to "套",
            "common.units.cartons" to "箱",
            "common.units.kg" to "公斤",
            "common.units.tonnes" to "吨",
            "common.save" to "保存",
            "common.cancel" to "取消",
            "common.close" to "关闭",
            "common.back" to "返回",
            "common.confirm" to "确认",
            "common.status" to "状态",
            "common.actions" to "操作"
        )
    )

    fun tr(key: String): String {
        val lang = _currentLanguage.value
        return translations[lang]?.get(key) ?: translations[Language.EN]?.get(key) ?: key
    }

    fun tr(key: String, vararg args: Any): String {
        val raw = tr(key)
        return try {
            String.format(raw, *args)
        } catch (e: Exception) {
            raw
        }
    }

    @Composable
    fun label(key: String): String {
        val lang = currentLanguage.collectAsState().value
        return translations[lang]?.get(key) ?: translations[Language.EN]?.get(key) ?: key
    }

    @Composable
    fun label(key: String, vararg args: Any): String {
        val raw = label(key)
        return try {
            String.format(raw, *args)
        } catch (e: Exception) {
            raw
        }
    }

    fun formatCurrency(amount: Double, currency: String = "USD"): String {
        val symbol = when (currency) {
            "CNY" -> "¥"
            "EUR" -> "€"
            "GBP" -> "£"
            "JPY", "KRW" -> "¥"
            else -> "$"
        }
        return "$symbol${String.format(Locale.US, "%,.2f", amount)}"
    }

    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}
