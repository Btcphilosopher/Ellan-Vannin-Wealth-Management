package com.example.core.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory

// --- Data Classes used in Entities ---

data class DbPriceTier(
    val minQty: Int,
    val maxQty: Int,
    val unitPrice: Double,
    val currency: String
)

data class DbCustomisationOption(
    val nameEn: String,
    val nameZh: String,
    val descriptionEn: String,
    val descriptionZh: String,
    val minQty: Int,
    val additionalCost: Double,
    val leadTimeImpact: Int
)

data class DbNegotiationRound(
    val roundNum: Int,
    val price: Double,
    val qty: Int,
    val proposedBy: String, // "BUYER" or "SUPPLIER"
    val messageEn: String,
    val messageZh: String,
    val timestamp: Long
)

// --- Room Entities ---

@Entity(tableName = "suppliers")
data class CachedSupplier(
    @PrimaryKey val id: String,
    val legalNameEn: String,
    val legalNameZh: String,
    val displayNameEn: String,
    val displayNameZh: String,
    val countryEn: String,
    val countryZh: String,
    val provinceEn: String,
    val provinceZh: String,
    val cityEn: String,
    val cityZh: String,
    val yearsOperating: Int,
    val verificationStatus: String, // "UNVERIFIED", "REGISTERED", "BUSINESS_VERIFIED", "FACTORY_VERIFIED", "PRODUCT_VERIFIED", "AUDITED"
    val responseRate: Int,
    val responseTimeEn: String,
    val responseTimeZh: String,
    val ordersCompleted: Int,
    val productCount: Int,
    val factoryTypeEn: String,
    val factoryTypeZh: String,
    val certifications: List<String>,
    val tradeProtectionAvailable: Boolean,
    val primaryMarketsEn: List<String>,
    val primaryMarketsZh: List<String>,
    val languages: List<String>,
    val isFollowed: Boolean = false
)

@Entity(tableName = "products")
data class CachedProduct(
    @PrimaryKey val id: String,
    val nameEn: String,
    val nameZh: String,
    val originalLang: String, // "EN" or "ZH_CN"
    val categoryEn: String,
    val categoryZh: String,
    val imageUrl: String,
    val supplierId: String,
    val moq: Int,
    val priceTiers: List<DbPriceTier>,
    val isReadyToShip: Boolean,
    val isVerifiedSupplier: Boolean,
    val isTradeProtection: Boolean,
    val responseRate: Int,
    val leadTimeDays: Int,
    val rating: Double,
    val descriptionEn: String,
    val descriptionZh: String,
    val specEn: Map<String, String>,
    val specZh: Map<String, String>,
    val customisationOptions: List<DbCustomisationOption>,
    val samplePrice: Double,
    val sampleShippingCost: Double,
    val whyRecommendedEn: String,
    val whyRecommendedZh: String
)

@Entity(tableName = "conversations")
data class CachedConversation(
    @PrimaryKey val id: String,
    val supplierId: String,
    val supplierNameEn: String,
    val supplierNameZh: String,
    val lastMessageText: String,
    val lastMessageTime: Long,
    val unreadCount: Int
)

@Entity(tableName = "messages")
data class CachedMessage(
    @PrimaryKey val id: String,
    val conversationId: String,
    val senderType: String, // "BUYER" or "SUPPLIER"
    val textEn: String,
    val textZh: String,
    val originalText: String,
    val originalLang: String, // "EN", "ZH_CN"
    val timestamp: Long,
    val productRefId: String? = null,
    val rfqRefId: String? = null,
    val orderRefId: String? = null
)

@Entity(tableName = "rfqs")
data class CachedRFQ(
    @PrimaryKey val id: String,
    val productTitle: String,
    val quantity: Int,
    val unit: String,
    val targetPrice: Double?,
    val currency: String = "USD",
    val destination: String,
    val deliveryDate: String,
    val specificationsEn: String,
    val specificationsZh: String,
    val notes: String?,
    val status: String, // "DRAFT", "SUBMITTED", "OPEN", "QUOTING", "SHORTLISTED", "NEGOTIATING", "ACCEPTED", "REJECTED", "EXPIRED", "CANCELLED"
    val dateCreated: Long
)

@Entity(tableName = "quotes")
data class CachedQuote(
    @PrimaryKey val id: String,
    val rfqId: String,
    val supplierId: String,
    val supplierNameEn: String,
    val supplierNameZh: String,
    val unitPrice: Double,
    val moq: Int,
    val leadTimeDays: Int,
    val sampleCost: Double,
    val shippingCost: Double,
    val toolingCost: Double,
    val validityPeriod: String,
    val paymentTermsEn: String,
    val paymentTermsZh: String,
    val incoterm: String, // "FOB", "EXW", "CIF"
    val customisationEn: String,
    val customisationZh: String,
    val certificationsEn: String,
    val certificationsZh: String,
    val status: String // "SUBMITTED", "SHORTLISTED", "ACCEPTED", "REJECTED"
)

@Entity(tableName = "orders")
data class CachedOrder(
    @PrimaryKey val id: String, // e.g. "GT-20483"
    val productId: String,
    val productNameEn: String,
    val productNameZh: String,
    val productImageUrl: String,
    val supplierId: String,
    val supplierNameEn: String,
    val supplierNameZh: String,
    val quantity: Int,
    val unit: String,
    val unitPrice: Double,
    val currency: String = "USD",
    val totalPrice: Double,
    val status: String, // "DRAFT", "CONFIRMED", "PAYMENT_PENDING", "PAID", "PRODUCTION", "QUALITY_CHECK", "READY_TO_SHIP", "SHIPPED", "IN_TRANSIT", "CUSTOMS", "DELIVERED", "COMPLETED", "DISPUTED", "CANCELLED"
    val productionStatus: String, // "NOT_STARTED", "MATERIAL_PREPARATION", "PRODUCTION", "ASSEMBLY", "QUALITY_CONTROL", "PACKING", "READY_TO_SHIP"
    val isTradeProtected: Boolean,
    val dateCreated: Long,
    val negotiationHistory: List<DbNegotiationRound> = emptyList(),
    val paymentStatus: String = "INITIATED", // "INITIATED", "AUTHORISED", "HELD", "RELEASED", "REFUNDED", "DISPUTED"
    val activeEscrowState: String = "HELD" // "HELD", "RELEASED", "REFUNDED"
)

@Entity(tableName = "shipments")
data class CachedShipment(
    @PrimaryKey val id: String,
    val orderId: String,
    val carrier: String,
    val origin: String,
    val destination: String,
    val containerNum: String,
    val trackingNum: String,
    val transportMode: String, // "AIR", "SEA", "RAIL", "ROAD", "MULTIMODAL"
    val etd: String,
    val eta: String,
    val currentLocationEn: String,
    val currentLocationZh: String,
    val status: String, // "BOOKED", "PICKED_UP", "ORIGIN_WAREHOUSE", "PORT_OF_ORIGIN", "LOADED", "IN_TRANSIT", "TRANSSHIPMENT", "PORT_OF_DESTINATION", "CUSTOMS", "LAST_MILE", "OUT_FOR_DELIVERY", "DELIVERED", "DELAYED"
    val lastUpdated: Long,
    // coordinates for map simulation route
    val originLat: Double,
    val originLng: Double,
    val destLat: Double,
    val destLng: Double,
    val currentProgress: Double // 0.0 to 1.0
)

@Entity(tableName = "inspections")
data class CachedInspection(
    @PrimaryKey val id: String,
    val orderId: String,
    val inspectionTypeEn: String,
    val inspectionTypeZh: String,
    val result: String, // "PASS", "FAIL", "CONDITIONAL", "PENDING"
    val findingsEn: String,
    val findingsZh: String,
    val inspectorEn: String,
    val inspectorZh: String,
    val date: String,
    val photoUrls: List<String> = emptyList()
)

@Entity(tableName = "disputes")
data class CachedDispute(
    @PrimaryKey val id: String,
    val orderId: String,
    val reasonEn: String,
    val reasonZh: String,
    val buyerStatementEn: String,
    val buyerStatementZh: String,
    val supplierStatementEn: String?,
    val supplierStatementZh: String?,
    val status: String, // "OPEN", "UNDER_REVIEW", "SUPPLIER_RESPONSE", "BUYER_RESPONSE", "MEDIATION", "RESOLVED", "CLOSED"
    val resolutionEn: String?,
    val resolutionZh: String?,
    val refundAmount: Double
)

@Entity(tableName = "user_preferences")
data class UserPreferencesEntity(
    @PrimaryKey val id: Int = 0,
    val language: String, // "EN", "ZH_CN"
    val companyName: String = "Global Sourcing Ltd.",
    val contactName: String = "Sarah Jenkins",
    val country: String = "United States",
    val role: String = "BUYER", // "OWNER", "BUYER", "FINANCE", "LOGISTICS"
    val taxId: String = "US-9876543-A",
    val addressCountry: String = "United States",
    val addressProvince: String = "California",
    val addressCity: String = "Los Angeles",
    val addressStreet: String = "750 Commerce Blvd Suite 100",
    val addressPhone: String = "+1 213 555 0199"
)

// --- Room Type Converters ---

class AppTypeConverters {
    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    @TypeConverter
    fun fromStringList(value: List<String>?): String? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        val adapter = moshi.adapter<List<String>>(type)
        return adapter.toJson(value)
    }

    @TypeConverter
    fun toStringList(value: String?): List<String>? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        val adapter = moshi.adapter<List<String>>(type)
        return adapter.fromJson(value)
    }

    @TypeConverter
    fun fromPriceTierList(value: List<DbPriceTier>?): String? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, DbPriceTier::class.java)
        val adapter = moshi.adapter<List<DbPriceTier>>(type)
        return adapter.toJson(value)
    }

    @TypeConverter
    fun toPriceTierList(value: String?): List<DbPriceTier>? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, DbPriceTier::class.java)
        val adapter = moshi.adapter<List<DbPriceTier>>(type)
        return adapter.fromJson(value)
    }

    @TypeConverter
    fun fromCustomisationOptionList(value: List<DbCustomisationOption>?): String? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, DbCustomisationOption::class.java)
        val adapter = moshi.adapter<List<DbCustomisationOption>>(type)
        return adapter.toJson(value)
    }

    @TypeConverter
    fun toCustomisationOptionList(value: String?): List<DbCustomisationOption>? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, DbCustomisationOption::class.java)
        val adapter = moshi.adapter<List<DbCustomisationOption>>(type)
        return adapter.fromJson(value)
    }

    @TypeConverter
    fun fromNegotiationRoundList(value: List<DbNegotiationRound>?): String? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, DbNegotiationRound::class.java)
        val adapter = moshi.adapter<List<DbNegotiationRound>>(type)
        return adapter.toJson(value)
    }

    @TypeConverter
    fun toNegotiationRoundList(value: String?): List<DbNegotiationRound>? {
        if (value == null) return null
        val type = Types.newParameterizedType(List::class.java, DbNegotiationRound::class.java)
        val adapter = moshi.adapter<List<DbNegotiationRound>>(type)
        return adapter.fromJson(value)
    }

    @TypeConverter
    fun fromStringMap(value: Map<String, String>?): String? {
        if (value == null) return null
        val type = Types.newParameterizedType(Map::class.java, String::class.java, String::class.java)
        val adapter = moshi.adapter<Map<String, String>>(type)
        return adapter.toJson(value)
    }

    @TypeConverter
    fun toStringMap(value: String?): Map<String, String>? {
        if (value == null) return null
        val type = Types.newParameterizedType(Map::class.java, String::class.java, String::class.java)
        val adapter = moshi.adapter<Map<String, String>>(type)
        return adapter.fromJson(value)
    }
}
