package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// GLOBAL TRADE Industrial Brand Palette
val PrimaryOrange = Color(0xFFFF6A00) // Strong B2B Orange
val DarkNavy = Color(0xFF0F1E36)      // Professional Trust Navy
val RestrainedRed = Color(0xFFD62222)  // Secure alerts/warnings
val DeepCharcoal = Color(0xFF1E2022)   // Main dense typography
val SteelGrey = Color(0xFF7E848C)      // Sub-labels and lines
val BorderGrey = Color(0xFFE2E5E9)     // Grid lines
val LightGrey = Color(0xFFF3F4F6)      // Card surface fill
val BackgroundWarmWhite = Color(0xFFFDFDFD) // Soft body canvas
val EscrowGreen = Color(0xFF1B8D4A)    // Completed / released payment
val OrangeSoft = Color(0xFFFFF3EB)     // Badge backgrounds
val NavySoft = Color(0xFFEFF3F8)       // Tag backgrounds
val GreenSoft = Color(0xFFEEF9F1)      // Secure badge backgrounds
val GoldAmber = Color(0xFFFFB300)      // Ratings / star ratings
