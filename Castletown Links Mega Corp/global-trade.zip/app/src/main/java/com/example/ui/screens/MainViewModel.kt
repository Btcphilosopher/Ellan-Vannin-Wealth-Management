package com.example.ui.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.ai.SourcingAssistantService
import com.example.core.database.*
import com.example.core.localization.Language
import com.example.core.localization.LocalizationManager
import com.example.core.search.RankedResult
import com.example.core.search.SearchEngine
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

data class AIChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val textEn: String,
    val textZh: String,
    val isUser: Boolean,
    val suggestedRFQ: com.example.core.ai.DraftRFQ? = null,
    val sourceOfTruth: String = "SYNTHETIC MARKETPLACE INDEX"
)

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = TradeRepository(application)

    // Language configuration
    val currentLanguage = LocalizationManager.currentLanguage

    // UI Reactive State Flows
    val suppliers = repository.getSuppliers().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val products = repository.getProducts().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val conversations = repository.getConversations().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val rfqs = repository.getRFQs().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val orders = repository.getOrders().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())
    val userPrefs = repository.getUserPreferences().stateIn(viewModelScope, SharingStarted.Eagerly, null)

    // Search query-specific flows
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedFilters = MutableStateFlow(SetFilters())
    val selectedFilters = _selectedFilters.asStateFlow()

    data class SetFilters(
        val isVerified: Boolean = false,
        val isTradeProtection: Boolean = false,
        val maxMoq: Int? = null,
        val category: String? = null
    )

    // Filtered search results
    val searchResults: StateFlow<List<RankedResult>> = combine(
        _searchQuery,
        products,
        _selectedFilters
    ) { query, prods, filters ->
        val results = SearchEngine.searchAndRank(query, prods)
        
        results.filter { ranked ->
            val p = ranked.product
            val matchesVerified = !filters.isVerified || p.isVerifiedSupplier
            val matchesProtection = !filters.isTradeProtection || p.isTradeProtection
            val matchesMoq = filters.maxMoq == null || p.moq <= filters.maxMoq
            val matchesCat = filters.category == null || 
                             p.categoryEn.equals(filters.category, true) || 
                             p.categoryZh.equals(filters.category, true)

            matchesVerified && matchesProtection && matchesMoq && matchesCat
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Messaging Flow
    private val _activeConversationId = MutableStateFlow<String?>(null)
    val activeConversationId = _activeConversationId.asStateFlow()

    val activeMessages: StateFlow<List<CachedMessage>> = _activeConversationId.flatMapLatest { convId ->
        if (convId == null) flowOf(emptyList())
        else repository.getMessages(convId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Quotes for active RFQ detail
    private val _activeRFQId = MutableStateFlow<String?>(null)
    val activeRFQId = _activeRFQId.asStateFlow()

    val activeQuotes: StateFlow<List<CachedQuote>> = _activeRFQId.flatMapLatest { rfqId ->
        if (rfqId == null) flowOf(emptyList())
        else repository.getQuotesForRFQ(rfqId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active Order Details
    private val _activeOrderId = MutableStateFlow<String?>(null)
    val activeOrderId = _activeOrderId.asStateFlow()

    val activeOrder: StateFlow<CachedOrder?> = _activeOrderId.flatMapLatest { orderId ->
        if (orderId == null) flowOf(null)
        else repository.getOrderById(orderId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeShipment: StateFlow<CachedShipment?> = _activeOrderId.flatMapLatest { orderId ->
        if (orderId == null) flowOf(null)
        else repository.getShipmentForOrder(orderId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeInspections: StateFlow<List<CachedInspection>> = _activeOrderId.flatMapLatest { orderId ->
        if (orderId == null) flowOf(emptyList())
        else repository.getInspectionsForOrder(orderId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val activeDispute: StateFlow<CachedDispute?> = _activeOrderId.flatMapLatest { orderId ->
        if (orderId == null) flowOf(null)
        else repository.getDisputeForOrder(orderId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // AI Sourcing Chat State
    private val _aiChatMessages = MutableStateFlow<List<AIChatMessage>>(emptyList())
    val aiChatMessages = _aiChatMessages.asStateFlow()

    private val _aiSourcingLoading = MutableStateFlow(false)
    val aiSourcingLoading = _aiSourcingLoading.asStateFlow()

    init {
        viewModelScope.launch {
            // Seeding B2B demo database
            repository.seedDatabaseIfNeeded()
            
            // Initial AI greeting
            _aiChatMessages.value = listOf(
                AIChatMessage(
                    textEn = LocalizationManager.tr("ai.welcome"),
                    textZh = LocalizationManager.tr("ai.welcome"),
                    isUser = false
                )
            )
        }
    }

    // Language setting
    fun toggleLanguage() {
        val next = if (currentLanguage.value == Language.EN) Language.ZH_CN else Language.EN
        LocalizationManager.setLanguage(next)
        viewModelScope.launch {
            userPrefs.value?.let {
                repository.updateUserPreferences(it.copy(language = next.name))
            }
        }
    }

    // Set search parameters
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun updateFilters(isVerified: Boolean, isTradeProtection: Boolean, maxMoq: Int?, category: String?) {
        _selectedFilters.value = SetFilters(isVerified, isTradeProtection, maxMoq, category)
    }

    // Select Active Navigation Views
    fun selectConversation(convId: String?) {
        _activeConversationId.value = convId
        viewModelScope.launch {
            if (convId != null) {
                repository.markConversationAsRead(convId)
            }
        }
    }

    fun selectRFQ(rfqId: String?) {
        _activeRFQId.value = rfqId
    }

    fun selectOrder(orderId: String?) {
        _activeOrderId.value = orderId
    }

    // Message sending with simulated real-time translation
    fun sendMessage(text: String, productRefId: String? = null, rfqRefId: String? = null, orderRefId: String? = null) {
        val convId = _activeConversationId.value ?: return
        val currentLang = currentLanguage.value
        
        viewModelScope.launch {
            val isEn = SearchEngine.detectLanguage(text) == com.example.core.search.DetectedLanguage.EN
            val translatedText = SourcingAssistantService.translateMessage(
                text = text, 
                targetLanguage = if (currentLang == Language.EN) Language.ZH_CN else Language.EN
            )

            val textEn = if (currentLang == Language.EN) text else translatedText
            val textZh = if (currentLang == Language.ZH_CN) text else translatedText

            val newMsg = CachedMessage(
                id = UUID.randomUUID().toString(),
                conversationId = convId,
                senderType = "BUYER",
                textEn = textEn,
                textZh = textZh,
                originalText = text,
                originalLang = if (isEn) "EN" else "ZH_CN",
                timestamp = System.currentTimeMillis(),
                productRefId = productRefId,
                rfqRefId = rfqRefId,
                orderRefId = orderRefId
            )
            repository.insertMessage(newMsg)

            // Simulate Supplier auto-response with business-standard delays!
            simulateSupplierResponse(convId, text)
        }
    }

    private suspend fun simulateSupplierResponse(convId: String, buyerText: String) {
        val bLower = buyerText.lowercase(Locale.US)
        val responseEn: String
        val responseZh: String

        when {
            bLower.contains("fob") || bLower.contains("price") || bLower.contains("报价") || bLower.contains("价格") -> {
                responseEn = "Thank you for the inquiry. For 5,000 units, we can quote $2.31/pc FOB Shanghai. This includes custom laser logo engraving."
                responseZh = "感谢您的询价。对于 5,000 件的订单，我们可以报 2.31 美元/件的 FOB 上海价。该价格已包含定制激光Logo。"
            }
            bLower.contains("sample") || bLower.contains("样品") || bLower.contains("样") -> {
                responseEn = "Samples are available at $10.00 each plus express shipping. We can dispatch within 3 business days."
                responseZh = "样品单价为 10.00 美元，另加快递运费。我们可以在 3 个工作日内寄出。"
            }
            bLower.contains("lead") || bLower.contains("delivery") || bLower.contains("交期") || bLower.contains("时间") -> {
                responseEn = "Our production lead time is approximately 12 to 15 days after deposit confirmation and custom logo approval."
                responseZh = "我们的生产周期在订金到账且定制 Logo 方案确认后，大约需要 12 到 15 天。"
            }
            else -> {
                responseEn = "Hello, your sourcing manager is on it. We are verifying the specifications and logistics options to Los Angeles right now."
                responseZh = "您好，我们正在为您核对定制技术规格以及运往洛杉矶的物流报价，请稍候。"
            }
        }

        // Delay 1.5 seconds for realistic feedback
        kotlinx.coroutines.delay(1500)

        val newMsg = CachedMessage(
            id = UUID.randomUUID().toString(),
            conversationId = convId,
            senderType = "SUPPLIER",
            textEn = responseEn,
            textZh = responseZh,
            originalText = responseZh, // original mock language
            originalLang = "ZH_CN",
            timestamp = System.currentTimeMillis()
        )
        repository.insertMessage(newMsg)
    }

    // Post custom RFQ
    fun postRFQ(
        productTitle: String,
        quantity: Int,
        unit: String,
        targetPrice: Double?,
        destination: String,
        deliveryDate: String,
        specifications: String,
        notes: String?
    ) {
        viewModelScope.launch {
            val newRFQ = CachedRFQ(
                id = "rfq_${UUID.randomUUID().toString().take(6)}",
                productTitle = productTitle,
                quantity = quantity,
                unit = unit,
                targetPrice = targetPrice,
                destination = destination,
                deliveryDate = deliveryDate,
                specificationsEn = specifications,
                specificationsZh = specifications,
                notes = notes,
                status = "QUOTING",
                dateCreated = System.currentTimeMillis()
            )
            repository.postRFQ(newRFQ)
        }
    }

    // Submit B2B Negotiation offer
    fun submitCounterOffer(orderId: String, price: Double, qty: Int, message: String) {
        viewModelScope.launch {
            val order = repository.getOrderByIdOneShot(orderId) ?: return@launch
            val list = order.negotiationHistory.toMutableList()
            val nextRound = list.size + 1
            
            val round = DbNegotiationRound(
                roundNum = nextRound,
                price = price,
                qty = qty,
                proposedBy = "BUYER",
                messageEn = message,
                messageZh = message,
                timestamp = System.currentTimeMillis()
            )
            list.add(round)

            val updatedOrder = order.copy(
                unitPrice = price,
                quantity = qty,
                totalPrice = price * qty,
                negotiationHistory = list,
                status = "CONFIRMED" // Moves status to confirmed
            )
            repository.updateOrder(updatedOrder)
            
            // Simulate Supplier accepted/counter response
            kotlinx.coroutines.delay(1500)
            supplierAutoNegotiate(updatedOrder, price, qty)
        }
    }

    private suspend fun supplierAutoNegotiate(order: CachedOrder, buyerPrice: Double, buyerQty: Int) {
        val list = order.negotiationHistory.toMutableList()
        val nextRound = list.size + 1
        
        // Simple mock negotiation engine logic
        val finalPrice: Double
        val proposedBy: String
        val msgEn: String
        val msgZh: String
        val nextStatus: String

        if (buyerPrice >= 2.15) {
            // Price is acceptable!
            finalPrice = buyerPrice
            proposedBy = "SUPPLIER"
            msgEn = "We accept your proposed price of $%.2f for %d units. Generating formal Purchase Order (PO).".format(buyerPrice, buyerQty)
            msgZh = "我们接受您提议的单价 %.2f 美元（起订数量 %d 件）。正式采购合同已生成。".format(buyerPrice, buyerQty)
            nextStatus = "PAYMENT_PENDING"
        } else {
            // Propose slightly higher compromise
            finalPrice = 2.18
            proposedBy = "SUPPLIER"
            msgEn = "The raw material costs prevent us from going below $2.18/unit. We can accept this if we finalize the order today."
            msgZh = "因原材料成本上升，我们的最低底价为 2.18 美元。如果您今天能确认订单，我们以此价格达成协议。"
            nextStatus = "CONFIRMED"
        }

        val round = DbNegotiationRound(
            roundNum = nextRound,
            price = finalPrice,
            qty = buyerQty,
            proposedBy = proposedBy,
            messageEn = msgEn,
            messageZh = msgZh,
            timestamp = System.currentTimeMillis()
        )
        list.add(round)

        val updated = order.copy(
            unitPrice = finalPrice,
            totalPrice = finalPrice * buyerQty,
            negotiationHistory = list,
            status = nextStatus
        )
        repository.updateOrder(updated)
    }

    // Accept a Quote and generate Purchase Order
    fun acceptQuoteAndCreatePO(quote: CachedQuote, rfq: CachedRFQ) {
        viewModelScope.launch {
            val orderId = "GT-${(10000..99999).random()}"
            val newOrder = CachedOrder(
                id = orderId,
                productId = "prod_01", // Default matching product id
                productNameEn = rfq.productTitle,
                productNameZh = rfq.productTitle,
                productImageUrl = "https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&q=80&w=400",
                supplierId = quote.supplierId,
                supplierNameEn = quote.supplierNameEn,
                supplierNameZh = quote.supplierNameZh,
                quantity = rfq.quantity,
                unit = rfq.unit,
                unitPrice = quote.unitPrice,
                currency = rfq.currency,
                totalPrice = quote.unitPrice * rfq.quantity,
                status = "PAYMENT_PENDING",
                productionStatus = "NOT_STARTED",
                isTradeProtected = true,
                dateCreated = System.currentTimeMillis()
            )
            repository.createOrder(newOrder)
            _activeOrderId.value = orderId
        }
    }

    fun createOrder(order: CachedOrder) {
        viewModelScope.launch {
            repository.createOrder(order)
        }
    }

    // Complete Escrow Payments
    fun authorizePayment(orderId: String, method: String) {
        viewModelScope.launch {
            val order = repository.getOrderByIdOneShot(orderId) ?: return@launch
            val updated = order.copy(
                status = "PRODUCTION",
                productionStatus = "MATERIAL_PREPARATION",
                paymentStatus = "HELD", // Funds held in secure escrow
                activeEscrowState = "HELD"
            )
            repository.updateOrder(updated)
            
            // Seed a realistic shipment tracking log automatically
            repository.createShipment(
                CachedShipment(
                    id = "ship_${orderId}",
                    orderId = orderId,
                    carrier = "DHL Global B2B Freight",
                    origin = "Shenzhen Port, China",
                    destination = "Port of Los Angeles, USA",
                    containerNum = "DHLU-209843-0",
                    trackingNum = "DHL827492819",
                    transportMode = "SEA",
                    etd = "2026-09-18",
                    eta = "2026-10-25",
                    currentLocationEn = "Port of Shenzhen - Cleared Export Customs",
                    currentLocationZh = "深圳蛇口港 - 已完成出口通关",
                    status = "BOOKED",
                    lastUpdated = System.currentTimeMillis(),
                    originLat = 22.5431,
                    originLng = 114.0579,
                    destLat = 33.7431,
                    destLng = -118.2673,
                    currentProgress = 0.0
                )
            )

            // Auto-advance production progress in background via simulated WorkManager
            advanceProductionProgress(orderId)
        }
    }

    private suspend fun advanceProductionProgress(orderId: String) {
        // Step-by-step production progression
        val steps = listOf(
            "PRODUCTION" to "MATERIAL_PREPARATION",
            "PRODUCTION" to "PRODUCTION",
            "QUALITY_CHECK" to "QUALITY_CONTROL",
            "READY_TO_SHIP" to "READY_TO_SHIP"
        )

        for ((oStatus, pStatus) in steps) {
            kotlinx.coroutines.delay(4000) // Delay for simulation speed
            val order = repository.getOrderByIdOneShot(orderId) ?: break
            val updated = order.copy(status = oStatus, productionStatus = pStatus)
            repository.updateOrder(updated)
        }
    }

    // Dispatcher to trigger physical shipping
    fun shipOrder(orderId: String) {
        viewModelScope.launch {
            val order = repository.getOrderByIdOneShot(orderId) ?: return@launch
            val updatedOrder = order.copy(
                status = "SHIPPED",
                productionStatus = "READY_TO_SHIP"
            )
            repository.updateOrder(updatedOrder)

            val shipment = repository.getShipmentForOrderOneShot(orderId)
            if (shipment != null) {
                repository.updateShipment(
                    shipment.copy(
                        status = "IN_TRANSIT",
                        currentProgress = 0.40,
                        currentLocationEn = "In Transit - Crossing Pacific Ocean",
                        currentLocationZh = "海运航行中 - 横渡太平洋"
                    )
                )
            }
        }
    }

    // Confirm order delivery
    fun confirmDelivery(orderId: String) {
        viewModelScope.launch {
            val order = repository.getOrderByIdOneShot(orderId) ?: return@launch
            val updated = order.copy(
                status = "COMPLETED",
                paymentStatus = "RELEASED", // Funds released to supplier
                activeEscrowState = "RELEASED"
            )
            repository.updateOrder(updated)

            val shipment = repository.getShipmentForOrderOneShot(orderId)
            if (shipment != null) {
                repository.updateShipment(
                    shipment.copy(
                        status = "DELIVERED",
                        currentProgress = 1.0,
                        currentLocationEn = "Delivered - Buyer Confirmed",
                        currentLocationZh = "已妥投 - 买家确认收货"
                    )
                )
            }
        }
    }

    // Open dispute
    fun openDispute(orderId: String, reason: String, statement: String, refundAmount: Double) {
        viewModelScope.launch {
            val order = repository.getOrderByIdOneShot(orderId) ?: return@launch
            val updatedOrder = order.copy(
                status = "DISPUTED",
                paymentStatus = "DISPUTED"
            )
            repository.updateOrder(updatedOrder)

            val newDispute = CachedDispute(
                id = "disp_${UUID.randomUUID().toString().take(6)}",
                orderId = orderId,
                reasonEn = reason,
                reasonZh = reason,
                buyerStatementEn = statement,
                buyerStatementZh = statement,
                supplierStatementEn = "We request physical inspections of the batch. SGS certified report shows PASS.",
                supplierStatementZh = "我们请求对该批次实物进行复检，出厂质检(SGS)报告显示检测合格。",
                status = "OPEN",
                resolutionEn = "Mediation in progress. Trade Protection specialists are reviewing the inspection reports.",
                resolutionZh = "仲裁协调中。贸易保障专员正在审核买家上传证明及出厂检测报告。",
                refundAmount = refundAmount
            )
            repository.createDispute(newDispute)
        }
    }

    // AI Sourcing Assistant Interaction
    fun sendAIAssistantMessage(text: String) {
        if (text.isBlank()) return
        
        viewModelScope.launch {
            val userMsg = AIChatMessage(
                textEn = text,
                textZh = text,
                isUser = true
            )
            _aiChatMessages.value = _aiChatMessages.value + userMsg
            _aiSourcingLoading.value = true

            val prods = products.value
            val sups = suppliers.value

            val response = SourcingAssistantService.processQuery(text, prods, sups)
            
            // Add a little delay for humanized conversational timing
            kotlinx.coroutines.delay(1000)

            val botMsg = AIChatMessage(
                textEn = response.messageEn,
                textZh = response.messageZh,
                isUser = false,
                suggestedRFQ = response.suggestedRFQ,
                sourceOfTruth = response.sourceOfTruth
            )
            _aiChatMessages.value = _aiChatMessages.value + botMsg
            _aiSourcingLoading.value = false
        }
    }

    fun clearAIChat() {
        _aiChatMessages.value = listOf(
            AIChatMessage(
                textEn = LocalizationManager.tr("ai.welcome"),
                textZh = LocalizationManager.tr("ai.welcome"),
                isUser = false
            )
        )
    }

    fun followSupplier(supplierId: String, followed: Boolean) {
        viewModelScope.launch {
            repository.updateSupplierFollowStatus(supplierId, followed)
        }
    }
}
