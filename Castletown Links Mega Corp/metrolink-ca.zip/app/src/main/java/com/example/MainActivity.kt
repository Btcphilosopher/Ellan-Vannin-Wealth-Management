package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.data.db.AppDatabase
import com.example.data.repository.MetrolinkRepository
import com.example.ui.MetrolinkApp
import com.example.ui.MetrolinkViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Setup simple constructor-based dependency injection
        val database = AppDatabase.getDatabase(applicationContext)
        val repository = MetrolinkRepository(database)
        val viewModel = MetrolinkViewModel(repository)
        
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MetrolinkApp(viewModel = viewModel)
            }
        }
    }
}
