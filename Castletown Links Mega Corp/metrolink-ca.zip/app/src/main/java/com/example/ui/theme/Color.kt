package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Metrolink Precision - Palette
val MetrolinkBlue = Color(0xFF005577)
val MetrolinkBlueDark = Color(0xFF003850)
val SunlitOrange = Color(0xFFF58220)
val ValleyGreen = Color(0xFF00A75C)

val SandNeutral = Color(0xFFF7F6F2)
val SoftGrey = Color(0xFFECEBE6)
val CharcoalSteel = Color(0xFF1D262B)
val SlateGrey = Color(0xFF62727C)

val LightAccentBlue = Color(0xFFE8F4F8)
val LightAccentOrange = Color(0xFFFFF2E6)
val LightAccentGreen = Color(0xFFE6F7ED)

val AlertRed = Color(0xFFD32F2F)
val AlertRedLight = Color(0xFFFFEBEE)
val AlertGold = Color(0xFFFFA000)
val AlertGoldLight = Color(0xFFFFF8E1)
val WhiteSurface = Color(0xFFFFFFFF)
val OffWhiteBg = Color(0xFFFAFAF9)

