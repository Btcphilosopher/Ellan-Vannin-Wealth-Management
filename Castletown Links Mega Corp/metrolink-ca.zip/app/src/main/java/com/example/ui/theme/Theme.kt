package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = MetrolinkBlue,
    secondary = SunlitOrange,
    tertiary = ValleyGreen,
    background = CharcoalSteel,
    surface = CharcoalSteel,
    onPrimary = WhiteSurface,
    onSecondary = WhiteSurface,
    onTertiary = WhiteSurface,
    onBackground = SandNeutral,
    onSurface = SandNeutral
  )

private val LightColorScheme =
  lightColorScheme(
    primary = MetrolinkBlue,
    secondary = SunlitOrange,
    tertiary = ValleyGreen,
    background = OffWhiteBg,
    surface = WhiteSurface,
    onPrimary = WhiteSurface,
    onSecondary = WhiteSurface,
    onTertiary = WhiteSurface,
    onBackground = CharcoalSteel,
    onSurface = CharcoalSteel,
    primaryContainer = LightAccentBlue,
    secondaryContainer = LightAccentOrange,
    tertiaryContainer = LightAccentGreen,
    error = AlertRed,
    onError = WhiteSurface
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // Custom brand look by default
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
