package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "stations")
data class Station(
    @PrimaryKey val id: String,
    val name: String,
    val lines: String, // Comma-separated list of lines: "Antelope Valley Line, San Bernardino Line", etc.
    val latitude: Double,
    val longitude: Double,
    val parking: Boolean = true,
    val ticketMachines: Boolean = true,
    val restrooms: Boolean = true,
    val ramps: Boolean = true,
    val elevators: Boolean = true,
    val nearbyConnections: String = "" // "Metro Rail, OCTA Bus", etc.
)

@Entity(tableName = "tickets")
data class Ticket(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originId: String,
    val originName: String,
    val destinationId: String,
    val destinationName: String,
    val ticketType: String, // e.g. "One-Way Ticket", "Round-Trip Ticket", "SoCal Day Pass"
    val passengerType: String, // e.g. "Adult", "Senior", "Student/Youth", "Disabled", "Veteran"
    val price: Double,
    val purchaseTimestamp: Long,
    val activationTimestamp: Long? = null,
    val expiryTimestamp: Long? = null,
    val status: String, // "READY_TO_ACTIVATE", "ACTIVE", "EXPIRED", "REFUNDED", "USED"
    val barcodePayload: String, // Demo payload
    val idempotencyKey: String,
    val environment: String = "DEMO_SANDBOX" // "DEMO_SANDBOX" or "PRODUCTION_INTEGRATION"
)

@Entity(tableName = "ticket_events")
data class TicketEvent(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val ticketId: Int,
    val eventType: String, // "FareQuoteCreated", "TicketOrderCreated", "PaymentStarted", "PaymentAuthorised", "TicketIssued", "TicketActivated", "TicketInspected", "RefundRequested"
    val timestamp: Long,
    val description: String
)

@Entity(tableName = "saved_journeys")
data class SavedJourney(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val originId: String,
    val originName: String,
    val destinationId: String,
    val destinationName: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "service_alerts")
data class ServiceAlert(
    @PrimaryKey val id: String,
    val lineName: String, // e.g. "San Bernardino Line", "All Lines"
    val severity: String, // "CRITICAL", "WARNING", "INFO"
    val message: String,
    val active: Boolean = true,
    val timestamp: Long = System.currentTimeMillis()
)
