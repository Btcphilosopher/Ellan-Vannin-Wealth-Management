package com.example.data.repository

import com.example.data.db.AppDatabase
import com.example.data.model.SavedJourney
import com.example.data.model.ServiceAlert
import com.example.data.model.Station
import com.example.data.model.Ticket
import com.example.data.model.TicketEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.UUID

sealed class PaymentResult {
    object Success : PaymentResult()
    data class Declined(val reason: String) : PaymentResult()
    object Timeout : PaymentResult()
}

data class SimulatedTrain(
    val id: String,
    val lineName: String,
    val direction: String, // "Northbound", "Southbound", "Eastbound", "Westbound"
    val previousStation: String,
    val currentStation: String,
    val nextStation: String,
    val scheduledArrival: String,
    val estimatedArrival: String,
    val delayMinutes: Int,
    val confidence: Double,
    val latitude: Double,
    val longitude: Double,
    val progressPercent: Float // 0.0 to 100.0
)

class MetrolinkRepository(private val db: AppDatabase) {

    private val scope = CoroutineScope(Dispatchers.IO)

    val allStations: Flow<List<Station>> = db.stationDao().getAllStations()
    val allTickets: Flow<List<Ticket>> = db.ticketDao().getAllTickets()
    val activeAlerts: Flow<List<ServiceAlert>> = db.serviceAlertDao().getActiveAlerts()
    val savedJourneys: Flow<List<SavedJourney>> = db.savedJourneyDao().getSavedJourneys()

    // Real-time train simulation
    private val _simulatedTrains = MutableStateFlow<List<SimulatedTrain>>(emptyList())
    val simulatedTrains: StateFlow<List<SimulatedTrain>> = _simulatedTrains

    init {
        scope.launch {
            seedInitialDataIfNeeded()
            startTrainSimulation()
        }
    }

    private suspend fun seedInitialDataIfNeeded() {
        val existing = allStations.first()
        if (existing.isEmpty()) {
            val stations = listOf(
                Station("LAUS", "LA Union Station", "Antelope Valley, Ventura County, San Bernardino, Orange County, Riverside, 91/Perris Valley", 34.0562, -118.2365, nearbyConnections = "Metro Rail (B, D, A lines), Amtrak"),
                Station("BURB", "Burbank Downtown", "Antelope Valley, Ventura County", 34.1804, -118.3081, nearbyConnections = "Metro Bus"),
                Station("GLEN", "Glendale", "Antelope Valley, Ventura County", 34.1273, -118.2562, nearbyConnections = "Glendale Beeline"),
                Station("STCL", "Santa Clarita", "Antelope Valley", 34.4239, -118.5413),
                Station("PALM", "Palmdale", "Antelope Valley", 34.5908, -118.1432, restrooms = false),
                Station("LANC", "Lancaster", "Antelope Valley", 34.6982, -118.1368),
                Station("COVI", "Covina", "San Bernardino", 34.0906, -117.8924),
                Station("CLAR", "Claremont", "San Bernardino", 34.0943, -117.7166, nearbyConnections = "Foothill Transit"),
                Station("RANC", "Rancho Cucamonga", "San Bernardino", 34.1025, -117.5516, nearbyConnections = "Omnitrans SBX"),
                Station("FONT", "Fontana", "San Bernardino", 34.0988, -117.4332),
                Station("SBDW", "San Bernardino Downtown", "San Bernardino, Inland Empire-Orange County", 34.1039, -117.3117, nearbyConnections = "Omnitrans, Arrow"),
                Station("NSFS", "Norwalk/Santa Fe Springs", "Orange County, 91/Perris Valley", 33.9168, -118.0694),
                Station("FULL", "Fullerton", "Orange County, 91/Perris Valley", 33.8690, -117.9221, nearbyConnections = "OCTA Bus, Amtrak"),
                Station("ANAH", "Anaheim", "Orange County", 33.8033, -117.8767, nearbyConnections = "ARTIC connections"),
                Station("ORAN", "Orange", "Orange County, Inland Empire-Orange County", 33.7878, -117.8643),
                Station("STAA", "Santa Ana", "Orange County, Inland Empire-Orange County", 33.7516, -117.8546),
                Station("IRVI", "Irvine", "Orange County, Inland Empire-Orange County", 33.6621, -117.7314, nearbyConnections = "iShuttle"),
                Station("SJCA", "San Juan Capistrano", "Orange County, Inland Empire-Orange County", 33.5015, -117.6627),
                Station("OCEN", "Oceanside", "Orange County, Inland Empire-Orange County", 33.1936, -117.3789, nearbyConnections = "NCTD Coaster, Sprinter"),
                Station("RIVD", "Riverside Downtown", "Riverside, Inland Empire-Orange County, 91/Perris Valley", 33.9749, -117.3697, nearbyConnections = "RTA Bus")
            )
            db.stationDao().insertStations(stations)

            val alerts = listOf(
                ServiceAlert("A1", "San Bernardino Line", "WARNING", "Minor delays of 5-10 minutes near Claremont due to signal maintenance.", true),
                ServiceAlert("A2", "Ventura County Line", "INFO", "Special weekend schedules in effect for upcoming SoCal Autumn events.", true),
                ServiceAlert("A3", "Orange County Line", "CRITICAL", "Bus bridge active between Irvine and San Juan Capistrano due to track repairs.", true)
            )
            db.serviceAlertDao().insertAlerts(alerts)
        }
    }

    private fun startTrainSimulation() {
        scope.launch {
            while (true) {
                // Generate simulated train movements along our stations
                val time = System.currentTimeMillis()
                val trains = listOf(
                    SimulatedTrain(
                        id = "SB-302",
                        lineName = "San Bernardino Line",
                        direction = "Eastbound",
                        previousStation = "Covina",
                        currentStation = "Claremont",
                        nextStation = "Rancho Cucamonga",
                        scheduledArrival = "10:45 AM",
                        estimatedArrival = "10:48 AM",
                        delayMinutes = 3,
                        confidence = 0.95,
                        latitude = 34.095 + (0.005 * kotlin.math.sin(time / 5000.0)),
                        longitude = -117.70 + (0.01 * kotlin.math.cos(time / 5000.0)),
                        progressPercent = ((time / 200) % 100).toFloat()
                    ),
                    SimulatedTrain(
                        id = "OC-601",
                        lineName = "Orange County Line",
                        direction = "Southbound",
                        previousStation = "Fullerton",
                        currentStation = "Anaheim",
                        nextStation = "Orange",
                        scheduledArrival = "11:12 AM",
                        estimatedArrival = "11:12 AM",
                        delayMinutes = 0,
                        confidence = 0.99,
                        latitude = 33.80 + (0.004 * kotlin.math.cos(time / 4000.0)),
                        longitude = -117.87 + (0.006 * kotlin.math.sin(time / 4000.0)),
                        progressPercent = ((time / 150) % 100).toFloat()
                    ),
                    SimulatedTrain(
                        id = "AV-205",
                        lineName = "Antelope Valley Line",
                        direction = "Northbound",
                        previousStation = "Glendale",
                        currentStation = "Burbank Downtown",
                        nextStation = "Santa Clarita",
                        scheduledArrival = "11:30 AM",
                        estimatedArrival = "11:45 AM",
                        delayMinutes = 15,
                        confidence = 0.88,
                        latitude = 34.25 + (0.01 * kotlin.math.sin(time / 6000.0)),
                        longitude = -118.40 + (0.01 * kotlin.math.cos(time / 6000.0)),
                        progressPercent = ((time / 300) % 100).toFloat()
                    )
                )
                _simulatedTrains.value = trains
                delay(2000) // update positions every 2 seconds
            }
        }
    }

    suspend fun getStation(id: String): Station? {
        return db.stationDao().getStationById(id)
    }

    // Saved Journeys
    suspend fun saveJourney(originId: String, originName: String, destinationId: String, destinationName: String) {
        db.savedJourneyDao().insertSavedJourney(
            SavedJourney(
                originId = originId,
                originName = originName,
                destinationId = destinationId,
                destinationName = destinationName
            )
        )
    }

    suspend fun removeSavedJourney(originId: String, destinationId: String) {
        db.savedJourneyDao().deleteSavedJourney(originId, destinationId)
    }

    // State machine events logging
    suspend fun logTicketEvent(ticketId: Int, type: String, description: String) {
        db.ticketEventDao().insertEvent(
            TicketEvent(
                ticketId = ticketId,
                eventType = type,
                timestamp = System.currentTimeMillis(),
                description = description
            )
        )
    }

    fun getTicketEvents(ticketId: Int): Flow<List<TicketEvent>> {
        return db.ticketEventDao().getEventsForTicket(ticketId)
    }

    // Checkout & Purchase (State Machine Lifecycle)
    suspend fun executePaymentAndIssueTicket(
        origin: Station,
        destination: Station,
        ticketType: String,
        passengerCategory: String,
        price: Double,
        paymentOption: String, // "SUCCESS", "DECLINE", "TIMEOUT"
        useFutureFare: Boolean = false
    ): PaymentResult {
        val idempotencyKey = UUID.randomUUID().toString()
        
        // Phase 1: RESERVED
        val tempTicket = Ticket(
            originId = origin.id,
            originName = origin.name,
            destinationId = destination.id,
            destinationName = destination.name,
            ticketType = ticketType,
            passengerType = passengerCategory,
            price = price,
            purchaseTimestamp = System.currentTimeMillis(),
            status = "RESERVED",
            barcodePayload = "",
            idempotencyKey = idempotencyKey,
            environment = "DEMO_SANDBOX"
        )
        val ticketId = db.ticketDao().insertTicket(tempTicket).toInt()
        logTicketEvent(ticketId, "FareQuoteCreated", "Fare quote calculated under tariff ${if(useFutureFare) "v2.0_future" else "v1.0"} ($$price)")
        logTicketEvent(ticketId, "TicketOrderCreated", "Ticket order reserved locally. Idempotency Key: $idempotencyKey")
        logTicketEvent(ticketId, "PaymentStarted", "Initiating payment authorization via payment method token *Ref_PM_4829*")

        // Simulate Gateway
        delay(1000)

        when (paymentOption) {
            "SUCCESS" -> {
                logTicketEvent(ticketId, "PaymentAuthorised", "Payment successfully authorized and captured. Transaction ID: TXN-${UUID.randomUUID().toString().take(8).uppercase()}")
                
                // Transition to ISSUED / READY_TO_ACTIVATE
                val finalTicket = tempTicket.copy(
                    id = ticketId,
                    status = "READY_TO_ACTIVATE",
                    barcodePayload = "DEMO_NOT_VALID_FOR_TRAVEL|ID:$ticketId|TYPE:$ticketType|PASS:$passengerCategory|FROM:${origin.id}|TO:${destination.id}|SEC:${UUID.randomUUID()}"
                )
                db.ticketDao().updateTicket(finalTicket)
                logTicketEvent(ticketId, "TicketIssued", "Ticket security token created. Ready for activation. Not valid for travel until active.")
                return PaymentResult.Success
            }
            "DECLINE" -> {
                val finalTicket = tempTicket.copy(
                    id = ticketId,
                    status = "PAYMENT_FAILED"
                )
                db.ticketDao().updateTicket(finalTicket)
                logTicketEvent(ticketId, "PaymentFailed", "Gateway declined transaction. Reason: Insufficient sandbox credits.")
                return PaymentResult.Declined("Insufficient sandbox credits. Gateway code: 402")
            }
            "TIMEOUT" -> {
                val finalTicket = tempTicket.copy(
                    id = ticketId,
                    status = "PAYMENT_PENDING"
                )
                db.ticketDao().updateTicket(finalTicket)
                logTicketEvent(ticketId, "PaymentFailed", "Gateway transaction timeout. Request set to pending.")
                return PaymentResult.Timeout
            }
            else -> {
                return PaymentResult.Declined("Unknown option")
            }
        }
    }

    // Activate Ticket
    suspend fun activateTicket(ticketId: Int) {
        val ticket = db.ticketDao().getTicketById(ticketId) ?: return
        if (ticket.status == "READY_TO_ACTIVATE") {
            val now = System.currentTimeMillis()
            // validity duration: 3 hours for one-way/round-trip, 24 hours for day passes, 30 days for Monthly Pass
            val validityDuration = when {
                ticket.ticketType.contains("Day Pass", ignoreCase = true) -> 24 * 60 * 60 * 1000L
                ticket.ticketType.contains("Monthly Pass", ignoreCase = true) -> 30 * 24 * 60 * 60 * 1000L
                ticket.ticketType.contains("Flex Pass", ignoreCase = true) -> 5 * 24 * 60 * 60 * 1000L
                else -> 3 * 60 * 60 * 1000L // 3 hours base
            }
            val activeTicket = ticket.copy(
                status = "ACTIVE",
                activationTimestamp = now,
                expiryTimestamp = now + validityDuration
            )
            db.ticketDao().updateTicket(activeTicket)
            logTicketEvent(ticketId, "TicketActivated", "Ticket activated by customer on device. Expires at ${FareEngine.formatTimestamp(now + validityDuration)}")
        }
    }

    // Refund Ticket
    suspend fun refundTicket(ticketId: Int) {
        val ticket = db.ticketDao().getTicketById(ticketId) ?: return
        if (ticket.status == "READY_TO_ACTIVATE" || ticket.status == "ACTIVE") {
            val refundedTicket = ticket.copy(
                status = "REFUNDED"
            )
            db.ticketDao().updateTicket(refundedTicket)
            logTicketEvent(ticketId, "RefundRequested", "Demo refund requested. Simulated refund of $${ticket.price} successfully settled.")
        }
    }

    // Clear tickets for debug/reset
    suspend fun resetTickets() {
        db.ticketDao().clearAllTickets()
    }
}
