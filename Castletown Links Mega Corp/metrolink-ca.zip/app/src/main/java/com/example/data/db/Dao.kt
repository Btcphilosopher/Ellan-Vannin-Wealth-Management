package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.SavedJourney
import com.example.data.model.ServiceAlert
import com.example.data.model.Station
import com.example.data.model.Ticket
import com.example.data.model.TicketEvent
import kotlinx.coroutines.flow.Flow

@Dao
interface StationDao {
    @Query("SELECT * FROM stations ORDER BY name ASC")
    fun getAllStations(): Flow<List<Station>>

    @Query("SELECT * FROM stations WHERE id = :id")
    suspend fun getStationById(id: String): Station?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStations(stations: List<Station>)
}

@Dao
interface TicketDao {
    @Query("SELECT * FROM tickets ORDER BY purchaseTimestamp DESC")
    fun getAllTickets(): Flow<List<Ticket>>

    @Query("SELECT * FROM tickets WHERE id = :id")
    suspend fun getTicketById(id: Int): Ticket?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTicket(ticket: Ticket): Long

    @Update
    suspend fun updateTicket(ticket: Ticket)

    @Query("DELETE FROM tickets")
    suspend fun clearAllTickets()
}

@Dao
interface TicketEventDao {
    @Query("SELECT * FROM ticket_events WHERE ticketId = :ticketId ORDER BY timestamp ASC")
    fun getEventsForTicket(ticketId: Int): Flow<List<TicketEvent>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertEvent(event: TicketEvent)
}

@Dao
interface SavedJourneyDao {
    @Query("SELECT * FROM saved_journeys ORDER BY timestamp DESC")
    fun getSavedJourneys(): Flow<List<SavedJourney>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedJourney(journey: SavedJourney)

    @Query("DELETE FROM saved_journeys WHERE originId = :originId AND destinationId = :destinationId")
    suspend fun deleteSavedJourney(originId: String, destinationId: String)
}

@Dao
interface ServiceAlertDao {
    @Query("SELECT * FROM service_alerts WHERE active = 1 ORDER BY timestamp DESC")
    fun getActiveAlerts(): Flow<List<ServiceAlert>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAlerts(alerts: List<ServiceAlert>)
}
