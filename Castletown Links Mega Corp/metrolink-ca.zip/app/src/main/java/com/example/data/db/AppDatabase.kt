package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.SavedJourney
import com.example.data.model.ServiceAlert
import com.example.data.model.Station
import com.example.data.model.Ticket
import com.example.data.model.TicketEvent

@Database(
    entities = [
        Station::class,
        Ticket::class,
        TicketEvent::class,
        SavedJourney::class,
        ServiceAlert::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun stationDao(): StationDao
    abstract fun ticketDao(): TicketDao
    abstract fun ticketEventDao(): TicketEventDao
    abstract fun savedJourneyDao(): SavedJourneyDao
    abstract fun serviceAlertDao(): ServiceAlertDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "metrolink_california_db"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
