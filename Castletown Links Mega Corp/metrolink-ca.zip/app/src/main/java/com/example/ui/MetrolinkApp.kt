package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServiceAlert
import com.example.data.model.Station
import com.example.data.model.Ticket
import com.example.data.model.SavedJourney
import com.example.data.model.TicketEvent
import com.example.data.repository.FareEngine
import com.example.ui.theme.*
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MetrolinkApp(viewModel: MetrolinkViewModel) {
    val currentTab by viewModel.currentScreen.collectAsState()
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val stations by viewModel.stations.collectAsState()

    // Listen for UI event toasts
    LaunchedEffect(Unit) {
        viewModel.uiEvents.collectLatest { msg ->
            snackbarHostState.showSnackbar(
                message = msg,
                duration = SnackbarDuration.Short
            )
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            MetrolinkTopBar()
        },
        bottomBar = {
            MetrolinkBottomNav(
                currentTab = currentTab,
                onTabSelected = { viewModel.currentScreen.value = it }
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                is AppScreen.Home -> HomeScreen(viewModel)
                is AppScreen.Plan -> PlanScreen(viewModel)
                is AppScreen.Tickets -> TicketsScreen(viewModel)
                is AppScreen.Trips -> TripsScreen(viewModel)
                is AppScreen.More -> MoreScreen(viewModel)
            }

            // Global Checkout Overlay Bottom Sheet/Modal dialog
            val showCheckout by viewModel.checkoutInProgress.collectAsState()
            if (showCheckout) {
                CheckoutDialog(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun MetrolinkTopBar() {
    Surface(
        color = MetrolinkBlue,
        tonalElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "METROLINK",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 2.sp
                    )
                    Text(
                        text = "CALIFORNIA",
                        color = SunlitOrange,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        letterSpacing = 1.sp
                    )
                }

                Surface(
                    color = Color.White.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(ValleyGreen)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "DEMO_SANDBOX",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun MetrolinkBottomNav(
    currentTab: AppScreen,
    onTabSelected: (AppScreen) -> Unit
) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        NavigationBarItem(
            selected = currentTab is AppScreen.Home,
            onClick = { onTabSelected(AppScreen.Home) },
            icon = {
                Icon(
                    imageVector = if (currentTab is AppScreen.Home) Icons.Filled.Home else Icons.Outlined.Home,
                    contentDescription = "Home"
                )
            },
            label = { Text("Home") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MetrolinkBlue,
                selectedTextColor = MetrolinkBlue,
                indicatorColor = LightAccentBlue
            ),
            modifier = Modifier.testTag("nav_home")
        )

        NavigationBarItem(
            selected = currentTab is AppScreen.Plan,
            onClick = { onTabSelected(AppScreen.Plan) },
            icon = {
                Icon(
                    imageVector = if (currentTab is AppScreen.Plan) Icons.Filled.Search else Icons.Outlined.Search,
                    contentDescription = "Plan"
                )
            },
            label = { Text("Plan") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MetrolinkBlue,
                selectedTextColor = MetrolinkBlue,
                indicatorColor = LightAccentBlue
            ),
            modifier = Modifier.testTag("nav_plan")
        )

        NavigationBarItem(
            selected = currentTab is AppScreen.Tickets,
            onClick = { onTabSelected(AppScreen.Tickets) },
            icon = {
                Icon(
                    imageVector = if (currentTab is AppScreen.Tickets) Icons.Filled.ConfirmationNumber else Icons.Outlined.ConfirmationNumber,
                    contentDescription = "Tickets"
                )
            },
            label = { Text("Tickets") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MetrolinkBlue,
                selectedTextColor = MetrolinkBlue,
                indicatorColor = LightAccentBlue
            ),
            modifier = Modifier.testTag("nav_tickets")
        )

        NavigationBarItem(
            selected = currentTab is AppScreen.Trips,
            onClick = { onTabSelected(AppScreen.Trips) },
            icon = {
                Icon(
                    imageVector = if (currentTab is AppScreen.Trips) Icons.Filled.Train else Icons.Outlined.Train,
                    contentDescription = "Trips"
                )
            },
            label = { Text("Trips") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MetrolinkBlue,
                selectedTextColor = MetrolinkBlue,
                indicatorColor = LightAccentBlue
            ),
            modifier = Modifier.testTag("nav_trips")
        )

        NavigationBarItem(
            selected = currentTab is AppScreen.More,
            onClick = { onTabSelected(AppScreen.More) },
            icon = {
                Icon(
                    imageVector = if (currentTab is AppScreen.More) Icons.Filled.MoreHoriz else Icons.Outlined.MoreHoriz,
                    contentDescription = "More"
                )
            },
            label = { Text("More") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MetrolinkBlue,
                selectedTextColor = MetrolinkBlue,
                indicatorColor = LightAccentBlue
            ),
            modifier = Modifier.testTag("nav_more")
        )
    }
}

// -------------------------------------------------------------
// HOME SCREEN
// -------------------------------------------------------------
@Composable
fun HomeScreen(viewModel: MetrolinkViewModel) {
    val savedList by viewModel.savedJourneys.collectAsState()
    val activeAlerts by viewModel.alerts.collectAsState()
    val stations by viewModel.stations.collectAsState()
    val tickets by viewModel.tickets.collectAsState()

    val activeTicketCount = tickets.count { it.status == "ACTIVE" }
    val unusedTicketCount = tickets.count { it.status == "READY_TO_ACTIVATE" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome and Account Summary Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MetrolinkBlue),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Good Morning, Tom!",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Account: tom@ahyx.org • Adult Profile",
                        color = SandNeutral,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            color = Color.White.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Active Passes: $activeTicketCount",
                                color = Color.White,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Surface(
                            color = Color.White.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "Unused Tickets: $unusedTicketCount",
                                color = Color.White,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Live Station / Nearest Station Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth(),
                border = BorderStroke(1.dp, SoftGrey)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocationOn,
                                contentDescription = "Location Pin",
                                tint = MetrolinkBlue,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Nearest Station",
                                    color = SlateGrey,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Burbank Downtown",
                                    color = CharcoalSteel,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        TextButton(onClick = {
                            viewModel.originStationId.value = "BURB"
                            viewModel.currentScreen.value = AppScreen.Plan
                        }) {
                            Text("Departures", color = MetrolinkBlue)
                        }
                    }
                }
            }
        }

        // Quick Action Grid
        item {
            Column {
                Text(
                    text = "Quick Actions",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SlateGrey,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    QuickActionCard(
                        title = "Buy Ticket",
                        icon = Icons.Default.ConfirmationNumber,
                        color = LightAccentBlue,
                        tint = MetrolinkBlue,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            viewModel.selectedTicketType.value = "One-Way Ticket"
                            viewModel.currentScreen.value = AppScreen.Plan
                        }
                    )
                    QuickActionCard(
                        title = "Plan Journey",
                        icon = Icons.Default.Map,
                        color = LightAccentOrange,
                        tint = SunlitOrange,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.currentScreen.value = AppScreen.Plan }
                    )
                    QuickActionCard(
                        title = "Ticket Wallet",
                        icon = Icons.Default.Wallet,
                        color = LightAccentGreen,
                        tint = ValleyGreen,
                        modifier = Modifier.weight(1f),
                        onClick = { viewModel.currentScreen.value = AppScreen.Tickets }
                    )
                }
            }
        }

        // Service Alerts Section
        if (activeAlerts.isNotEmpty()) {
            item {
                Column {
                    Text(
                        text = "System Alerts",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = SlateGrey,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        activeAlerts.forEach { alert ->
                            ServiceAlertCard(alert = alert)
                        }
                    }
                }
            }
        }

        // Saved Journeys list
        item {
            Column {
                Text(
                    text = "Saved Journeys",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = SlateGrey,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                if (savedList.isEmpty()) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth(),
                        border = BorderStroke(1.dp, SoftGrey)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = Icons.Default.BookmarkBorder,
                                contentDescription = "No Saved Journeys",
                                tint = SlateGrey,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "No saved journeys yet.",
                                color = CharcoalSteel,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Plan a trip and tap the bookmark icon to save it here.",
                                color = SlateGrey,
                                fontSize = 12.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        savedList.forEach { journey ->
                            SavedJourneyCard(journey = journey, onClick = {
                                viewModel.originStationId.value = journey.originId
                                viewModel.destinationStationId.value = journey.destinationId
                                viewModel.planJourney()
                                viewModel.currentScreen.value = AppScreen.Plan
                            })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .height(90.dp)
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = color),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = tint,
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = CharcoalSteel
            )
        }
    }
}

@Composable
fun ServiceAlertCard(alert: ServiceAlert) {
    val bgColor = if (alert.severity == "CRITICAL") AlertRedLight else AlertGoldLight
    val borderColor = if (alert.severity == "CRITICAL") AlertRed else AlertGold
    val icon = if (alert.severity == "CRITICAL") Icons.Default.Error else Icons.Default.Warning

    Card(
        colors = CardDefaults.cardColors(containerColor = bgColor),
        border = BorderStroke(1.dp, borderColor),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Icon(
                imageVector = icon,
                contentDescription = alert.severity,
                tint = borderColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = "${alert.lineName} Alert",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    color = CharcoalSteel
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = alert.message,
                    fontSize = 12.sp,
                    color = CharcoalSteel
                )
            }
        }
    }
}

@Composable
fun SavedJourneyCard(journey: SavedJourney, onClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, SoftGrey),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(
                    imageVector = Icons.Default.DirectionsRailway,
                    contentDescription = "Railway Icon",
                    tint = MetrolinkBlue
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = journey.originName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = CharcoalSteel
                        )
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "to",
                            tint = SlateGrey,
                            modifier = Modifier
                                .size(14.dp)
                                .padding(horizontal = 2.dp)
                        )
                        Text(
                            text = journey.destinationName,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = CharcoalSteel
                        )
                    }
                    Text(
                        text = "Quick tap to re-plan",
                        fontSize = 11.sp,
                        color = SlateGrey
                    )
                }
            }
            Icon(
                imageVector = Icons.Default.ChevronRight,
                contentDescription = "Action arrow",
                tint = SlateGrey
            )
        }
    }
}


// -------------------------------------------------------------
// PLAN SCREEN (Journey Planning + Quotes)
// -------------------------------------------------------------
@Composable
fun PlanScreen(viewModel: MetrolinkViewModel) {
    val stations by viewModel.stations.collectAsState()
    val plannedResults by viewModel.plannedResults.collectAsState()
    val savedJourneys by viewModel.savedJourneys.collectAsState()

    val originId by viewModel.originStationId.collectAsState()
    val destinationId by viewModel.destinationStationId.collectAsState()
    val passengerCat by viewModel.selectedPassengerCategory.collectAsState()
    val ticketType by viewModel.selectedTicketType.collectAsState()
    val useFutureFare by viewModel.useFutureFarePreview.collectAsState()

    val currentOrigin = stations.find { it.id == originId }
    val currentDestination = stations.find { it.id == destinationId }

    var originExpanded by remember { mutableStateOf(false) }
    var destinationExpanded by remember { mutableStateOf(false) }
    var passengerExpanded by remember { mutableStateOf(false) }
    var ticketExpanded by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Search & Preferences Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, SoftGrey),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Build Journey Profile",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = CharcoalSteel,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Origin Station dropdown selection
                    Box {
                        OutlinedTextField(
                            value = currentOrigin?.name ?: "Select Origin Station",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Origin Station") },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, "Open") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { originExpanded = true },
                            enabled = false, // click handled by Box
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = CharcoalSteel,
                                disabledBorderColor = SlateGrey,
                                disabledLabelColor = SlateGrey,
                                disabledTrailingIconColor = MetrolinkBlue
                            )
                        )
                        // Absolute click area
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .clickable { originExpanded = true }
                        )
                        DropdownMenu(
                            expanded = originExpanded,
                            onDismissRequest = { originExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            stations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(station.name) },
                                    onClick = {
                                        viewModel.originStationId.value = station.id
                                        originExpanded = false
                                        viewModel.planJourney()
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Destination Station dropdown selection
                    Box {
                        OutlinedTextField(
                            value = currentDestination?.name ?: "Select Destination Station",
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("Destination Station") },
                            trailingIcon = { Icon(Icons.Default.ArrowDropDown, "Open") },
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { destinationExpanded = true },
                            enabled = false,
                            colors = OutlinedTextFieldDefaults.colors(
                                disabledTextColor = CharcoalSteel,
                                disabledBorderColor = SlateGrey,
                                disabledLabelColor = SlateGrey,
                                disabledTrailingIconColor = MetrolinkBlue
                            )
                        )
                        Box(
                            modifier = Modifier
                                .matchParentSize()
                                .clickable { destinationExpanded = true }
                        )
                        DropdownMenu(
                            expanded = destinationExpanded,
                            onDismissRequest = { destinationExpanded = false },
                            modifier = Modifier.fillMaxWidth(0.9f)
                        ) {
                            stations.forEach { station ->
                                DropdownMenuItem(
                                    text = { Text(station.name) },
                                    onClick = {
                                        viewModel.destinationStationId.value = station.id
                                        destinationExpanded = false
                                        viewModel.planJourney()
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Passenger Profile
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedTextField(
                                value = passengerCat,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Passenger") },
                                trailingIcon = { Icon(Icons.Default.ArrowDropDown, "Open") },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = false,
                                colors = OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = CharcoalSteel,
                                    disabledBorderColor = SoftGrey
                                )
                            )
                            Box(
                                modifier = Modifier
                                    .matchParentSize()
                                    .clickable { passengerExpanded = true }
                            )
                            DropdownMenu(
                                expanded = passengerExpanded,
                                onDismissRequest = { passengerExpanded = false }
                            ) {
                                listOf("Adult", "Student/Youth", "Senior", "Disabled/Medicare", "Veteran/Military").forEach { category ->
                                    DropdownMenuItem(
                                        text = { Text(category) },
                                        onClick = {
                                            viewModel.selectedPassengerCategory.value = category
                                            passengerExpanded = false
                                            viewModel.planJourney()
                                        }
                                    )
                                }
                            }
                        }

                        // Ticket Product Category Selection
                        Box(modifier = Modifier.weight(1.2f)) {
                            OutlinedTextField(
                                value = ticketType,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("Ticket Type") },
                                trailingIcon = { Icon(Icons.Default.ArrowDropDown, "Open") },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = false,
                                colors = OutlinedTextFieldDefaults.colors(
                                    disabledTextColor = CharcoalSteel,
                                    disabledBorderColor = SoftGrey
                                )
                            )
                            Box(
                                modifier = Modifier
                                    .matchParentSize()
                                    .clickable { ticketExpanded = true }
                            )
                            DropdownMenu(
                                expanded = ticketExpanded,
                                onDismissRequest = { ticketExpanded = false }
                            ) {
                                listOf("One-Way Ticket", "Round-Trip Ticket", "SoCal Day Pass", "LA Zone Day Pass", "5-Day Flex Pass", "Monthly Pass").forEach { t ->
                                    DropdownMenuItem(
                                        text = { Text(t) },
                                        onClick = {
                                            viewModel.selectedTicketType.value = t
                                            ticketExpanded = false
                                            viewModel.planJourney()
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Dynamic Switch for Upcoming Scheduled Fare Changes
                    Surface(
                        color = LightAccentBlue,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp)
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Scheduled Fare Change Preview",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    color = MetrolinkBlue
                                )
                                Text(
                                    text = "Inspect tariff v2.0 (Effective Jan 1, 2027)",
                                    fontSize = 11.sp,
                                    color = SlateGrey
                                )
                            }
                            Switch(
                                checked = useFutureFare,
                                onCheckedChange = {
                                    viewModel.useFutureFarePreview.value = it
                                    viewModel.planJourney()
                                },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = MetrolinkBlue
                                )
                            )
                        }
                    }
                }
            }
        }

        // Bookmark saved journey button
        if (currentOrigin != null && currentDestination != null && currentOrigin.id != currentDestination.id) {
            item {
                val isSaved = savedJourneys.any { it.originId == currentOrigin.id && it.destinationId == currentDestination.id }
                Button(
                    onClick = { viewModel.toggleSavedJourney(currentOrigin, currentDestination) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSaved) SoftGrey else LightAccentBlue,
                        contentColor = MetrolinkBlue
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isSaved) Icons.Filled.Bookmark else Icons.Outlined.BookmarkBorder,
                            contentDescription = "Save Journey"
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSaved) "Journey Saved to Dashboard" else "Save Journey Profile",
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Planned Results Title
        item {
            Text(
                text = "Available Mobility Connections",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = SlateGrey,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        // Show Results
        if (plannedResults.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth(),
                    border = BorderStroke(1.dp, SoftGrey)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Search, "Search", tint = SlateGrey, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Invalid Selection",
                            fontWeight = FontWeight.Bold,
                            color = CharcoalSteel
                        )
                        Text(
                            text = "Ensure origin and destination stations differ.",
                            color = SlateGrey,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(plannedResults) { journey ->
                JourneyOptionCard(
                    journey = journey,
                    useFutureFare = useFutureFare,
                    onBuyClicked = {
                        viewModel.startCheckout()
                    }
                )
            }
        }
    }
}

@Composable
fun JourneyOptionCard(
    journey: PlannedJourney,
    useFutureFare: Boolean,
    onBuyClicked: () -> Unit
) {
    val activePrice = if (useFutureFare) journey.fareFuture else journey.fareCurrent
    val otherPrice = if (useFutureFare) journey.fareCurrent else journey.fareFuture

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, SoftGrey),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Line Badge & Identifier
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Surface(
                    color = MetrolinkBlue,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = journey.lineName,
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }

                Text(
                    text = "Train: ${journey.trainIdentifier}",
                    color = SlateGrey,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Time & Distance Line Segment
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(journey.departureTime, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(journey.origin.id, fontSize = 11.sp, color = SlateGrey)
                }

                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 12.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Divider(color = SoftGrey, thickness = 2.dp)
                    Surface(
                        color = LightAccentBlue,
                        shape = CircleShape,
                        border = BorderStroke(1.dp, MetrolinkBlue),
                        modifier = Modifier.size(24.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.DirectionsTransit,
                                contentDescription = "train icon",
                                tint = MetrolinkBlue,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(journey.arrivalTime, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(journey.destination.id, fontSize = 11.sp, color = SlateGrey)
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Details and stats
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Duration: ${journey.durationMinutes} mins • Direct",
                        fontSize = 12.sp,
                        color = CharcoalSteel
                    )
                    Text(
                        text = journey.connectingTransit,
                        fontSize = 11.sp,
                        color = SlateGrey
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "$$activePrice",
                        color = MetrolinkBlue,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp
                    )
                    Text(
                        text = if (useFutureFare) "V2.0 Scheduled Fare" else "Current Tariff (V1.0)",
                        fontSize = 10.sp,
                        color = if (useFutureFare) SunlitOrange else ValleyGreen,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Reason Selected text block
            Surface(
                color = OffWhiteBg,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                border = BorderStroke(1.dp, SoftGrey)
            ) {
                Text(
                    text = journey.reasonSelected,
                    fontSize = 11.sp,
                    color = CharcoalSteel,
                    modifier = Modifier.padding(8.dp)
                )
            }

            // Fare rules check alert and purchase triggers
            Text(
                text = "✓ Transfer rights: Valid on connecting LA Metro buses & trains within 2 hours of departure.",
                fontSize = 10.sp,
                color = SlateGrey,
                modifier = Modifier.padding(bottom = 12.dp)
            )

            Button(
                onClick = onBuyClicked,
                colors = ButtonDefaults.buttonColors(containerColor = SunlitOrange),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("buy_ticket_button")
            ) {
                Text("Select Ticket & Checkout • $$activePrice", fontWeight = FontWeight.Bold, color = Color.White)
            }
        }
    }
}

// -------------------------------------------------------------
// CHECKOUT BOTTOM SHEET DIALOG (PAYMENT GATEWAY ENGINE)
// -------------------------------------------------------------
@Composable
fun CheckoutDialog(viewModel: MetrolinkViewModel) {
    val results by viewModel.plannedResults.collectAsState()
    val useFutureFare by viewModel.useFutureFarePreview.collectAsState()
    val ticketType by viewModel.selectedTicketType.collectAsState()
    val passengerCat by viewModel.selectedPassengerCategory.collectAsState()
    val simulatorOption by viewModel.paymentSimulatorOption.collectAsState()
    val checkoutErrorMessage by viewModel.paymentResultMessage.collectAsState()

    val journey = results.firstOrNull() ?: return
    val activePrice = if (useFutureFare) journey.fareFuture else journey.fareCurrent

    Surface(
        color = Color.Black.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxSize()
    ) {
        Box(
            contentAlignment = Alignment.BottomCenter,
            modifier = Modifier.fillMaxSize()
        ) {
            // Absolute overlay close trigger
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .clickable { viewModel.cancelCheckout() }
            )

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = false, onClick = {}) // stop click propagation
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .navigationBarsPadding()
                ) {
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Checkout Order Summary",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = CharcoalSteel
                        )
                        IconButton(onClick = { viewModel.cancelCheckout() }) {
                            Icon(Icons.Default.Close, "Close")
                        }
                    }

                    Divider(color = SoftGrey, modifier = Modifier.padding(vertical = 12.dp))

                    // Line segments info
                    Row(
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column {
                            Text("Product Choice", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(ticketType, color = MetrolinkBlue, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Profile: $passengerCat", fontSize = 12.sp, color = SlateGrey)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("Total", color = SlateGrey, fontSize = 12.sp)
                            Text("$$activePrice", fontWeight = FontWeight.Black, fontSize = 18.sp, color = CharcoalSteel)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Route: ${journey.origin.name} ➔ ${journey.destination.name}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = SlateGrey
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Sandbox Payment Simulator control panel
                    Text(
                        text = "Demo Gateway Simulator Controls",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = SunlitOrange
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        SimulatorSelectorButton(
                            label = "Decline",
                            selected = simulatorOption == "DECLINE",
                            color = AlertRed,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.paymentSimulatorOption.value = "DECLINE" }
                        )
                        SimulatorSelectorButton(
                            label = "Timeout",
                            selected = simulatorOption == "TIMEOUT",
                            color = AlertGold,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.paymentSimulatorOption.value = "TIMEOUT" }
                        )
                        SimulatorSelectorButton(
                            label = "Authorize",
                            selected = simulatorOption == "SUCCESS",
                            color = ValleyGreen,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.paymentSimulatorOption.value = "SUCCESS" }
                        )
                    }

                    if (checkoutErrorMessage != null) {
                        Surface(
                            color = AlertRedLight,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, AlertRed),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 12.dp)
                        ) {
                            Text(
                                text = "Gateway Refusal: $checkoutErrorMessage",
                                color = AlertRed,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // PCI compliant message
                    Text(
                        text = "🔐 Security Shield: We use tokenized payment descriptors. No raw card numbers are ever stored in local SQLite or transmitted.",
                        fontSize = 10.sp,
                        color = SlateGrey,
                        modifier = Modifier.padding(bottom = 16.dp)
                    )

                    Button(
                        onClick = { viewModel.completeCheckout(journey) },
                        colors = ButtonDefaults.buttonColors(containerColor = MetrolinkBlue),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_payment_button")
                    ) {
                        Text(
                            text = "Authorize Sandbox Payment • $$activePrice",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SimulatorSelectorButton(
    label: String,
    selected: Boolean,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.5.dp, if (selected) color else SoftGrey),
        color = if (selected) color.copy(alpha = 0.15f) else Color.Transparent,
        modifier = modifier
            .height(40.dp)
            .clickable(onClick = onClick)
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                text = label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (selected) color else SlateGrey
            )
        }
    }
}

// -------------------------------------------------------------
// TICKET WALLET SCREEN
// -------------------------------------------------------------
@Composable
fun TicketsScreen(viewModel: MetrolinkViewModel) {
    val tickets by viewModel.tickets.collectAsState()
    val selectedTicketId by viewModel.selectedTicketIdForDetails.collectAsState()

    val readyTickets = tickets.filter { it.status == "READY_TO_ACTIVATE" }
    val activeTickets = tickets.filter { it.status == "ACTIVE" }
    val archivedTickets = tickets.filter { it.status in listOf("EXPIRED", "REFUNDED", "USED") }

    var selectedSectionTab by remember { mutableStateOf(0) } // 0 = Active, 1 = Ready, 2 = History

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Warning Banner
        Surface(
            color = AlertGoldLight,
            shape = RoundedCornerShape(8.dp),
            border = BorderStroke(1.dp, AlertGold),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
        ) {
            Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Warning, "Demo Only", tint = AlertGold)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "DEMONSTRATION PLATFORM — NOT VALID FOR TRAVEL",
                    color = CharcoalSteel,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }

        // Section tab row selectors
        TabRow(
            selectedTabIndex = selectedSectionTab,
            containerColor = Color.Transparent,
            contentColor = MetrolinkBlue,
            divider = { Divider(color = SoftGrey) }
        ) {
            Tab(
                selected = selectedSectionTab == 0,
                onClick = { selectedSectionTab = 0 },
                text = { Text("Active (${activeTickets.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
            Tab(
                selected = selectedSectionTab == 1,
                onClick = { selectedSectionTab = 1 },
                text = { Text("Ready (${readyTickets.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
            Tab(
                selected = selectedSectionTab == 2,
                onClick = { selectedSectionTab = 2 },
                text = { Text("History (${archivedTickets.size})", fontWeight = FontWeight.Bold, fontSize = 13.sp) }
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Display lists based on tabs
        val visibleTickets = when (selectedSectionTab) {
            0 -> activeTickets
            1 -> readyTickets
            else -> archivedTickets
        }

        if (visibleTickets.isEmpty()) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Inbox,
                        contentDescription = "Empty",
                        tint = SlateGrey,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No tickets in this section.",
                        color = CharcoalSteel,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Purchase a ticket through the Plan tab.",
                        color = SlateGrey,
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(visibleTickets) { ticket ->
                    TicketRowCard(
                        ticket = ticket,
                        onClick = { viewModel.selectedTicketIdForDetails.value = ticket.id }
                    )
                }
            }
        }
    }

    // Modal details presentation for the selected ticket
    if (selectedTicketId != null) {
        val selectedTicket = tickets.find { it.id == selectedTicketId }
        if (selectedTicket != null) {
            TicketDetailsDialog(
                ticket = selectedTicket,
                onDismiss = { viewModel.selectedTicketIdForDetails.value = null },
                onActivate = { viewModel.activateTicket(selectedTicket.id) },
                onRefund = { viewModel.refundTicket(selectedTicket.id) },
                viewModel = viewModel
            )
        }
    }
}

@Composable
fun TicketRowCard(ticket: Ticket, onClick: () -> Unit) {
    val indicatorColor = when (ticket.status) {
        "ACTIVE" -> ValleyGreen
        "READY_TO_ACTIVATE" -> SunlitOrange
        "REFUNDED" -> SlateGrey
        else -> CharcoalSteel
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, SoftGrey),
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    // Left brand indicator bar
                    drawRect(
                        color = indicatorColor,
                        topLeft = Offset(0f, 0f),
                        size = androidx.compose.ui.geometry.Size(6.dp.toPx(), size.height)
                    )
                }
                .padding(16.dp)
                .padding(start = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = ticket.ticketType,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = CharcoalSteel
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "${ticket.originName} ➔ ${ticket.destinationName}",
                    fontSize = 12.sp,
                    color = SlateGrey,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Profile: ${ticket.passengerType}",
                    fontSize = 11.sp,
                    color = SlateGrey
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = ticket.status.replace("_", " "),
                    color = indicatorColor,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = "Cost: $${ticket.price}",
                    color = CharcoalSteel,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

// -------------------------------------------------------------
// TICKET DETAILS DIALOG WITH THE ENHANCED HIGH-CONTRAST QR CODE
// -------------------------------------------------------------
@Composable
fun TicketDetailsDialog(
    ticket: Ticket,
    onDismiss: () -> Unit,
    onActivate: () -> Unit,
    onRefund: () -> Unit,
    viewModel: MetrolinkViewModel
) {
    val scope = rememberCoroutineScope()
    val eventLog by viewModel.getTicketEventsFlow(ticket.id).collectAsState(emptyList())

    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Done", color = MetrolinkBlue, fontWeight = FontWeight.Bold) }
        },
        title = {
            Text(
                text = ticket.ticketType,
                fontWeight = FontWeight.Black,
                color = MetrolinkBlue
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Warning Banner
                Surface(
                    color = AlertRedLight,
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, AlertRed),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "DEMONSTRATION ONLY — NOT VALID FOR TRAVEL",
                        color = AlertRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // High Contrast Visual QR Box representation
                Surface(
                    border = BorderStroke(4.dp, CharcoalSteel),
                    shape = RoundedCornerShape(12.dp),
                    color = Color.White,
                    modifier = Modifier
                        .size(240.dp)
                        .padding(8.dp)
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.fillMaxSize()
                    ) {
                        if (ticket.status == "ACTIVE") {
                            // Animated Flashing Security Line representation to prevent static screenshot fraud
                            val infiniteTransition = rememberInfiniteTransition(label = "Security flash")
                            val flashAlpha by infiniteTransition.animateFloat(
                                initialValue = 0.2f,
                                targetValue = 0.8f,
                                animationSpec = infiniteRepeatable(
                                    animation = tween(1000, easing = LinearEasing),
                                    repeatMode = RepeatMode.Reverse
                                ),
                                label = "flash"
                            )

                            Canvas(modifier = Modifier.fillMaxSize()) {
                                // Draw a stylized mock QR pixel matrix
                                val cols = 15
                                val rows = 15
                                val cellW = size.width / cols
                                val cellH = size.height / rows

                                // Seed based matrix
                                for (i in 0 until cols) {
                                    for (j in 0 until rows) {
                                        // Random math to create unique visual look per ticket ID
                                        if (((i * 7 + j * 13 + ticket.id) % 3 == 0) ||
                                            (i < 4 && j < 4) || (i > 10 && j < 4) || (i < 4 && j > 10)
                                        ) {
                                            drawRect(
                                                color = CharcoalSteel,
                                                topLeft = Offset(i * cellW, j * cellH),
                                                size = androidx.compose.ui.geometry.Size(cellW - 1.dp.toPx(), cellH - 1.dp.toPx())
                                            )
                                        }
                                    }
                                }

                                // Overlay active flash line
                                drawLine(
                                    color = SunlitOrange.copy(alpha = flashAlpha),
                                    start = Offset(0f, size.height * flashAlpha),
                                    end = Offset(size.width, size.height * flashAlpha),
                                    strokeWidth = 6.dp.toPx()
                                )
                            }
                        } else {
                            // Non-active display placeholder
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                                Icon(Icons.Default.Lock, "Locked", tint = SlateGrey, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "Barcode Locked",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = CharcoalSteel
                                )
                                Text(
                                    text = "Activate ticket to generate travel credential.",
                                    fontSize = 11.sp,
                                    color = SlateGrey,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }

                if (ticket.status == "ACTIVE") {
                    Text(
                        text = "🔒 TICKET ACTIVATED & ENCRYPTED",
                        color = ValleyGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Detail fields
                InfoRow(label = "From", value = ticket.originName)
                InfoRow(label = "To", value = ticket.destinationName)
                InfoRow(label = "Passenger", value = ticket.passengerType)
                InfoRow(label = "Fare", value = "$${ticket.price}")
                InfoRow(label = "State Status", value = ticket.status.replace("_", " "))

                if (ticket.activationTimestamp != null) {
                    InfoRow(label = "Activated", value = FareEngine.formatTimestamp(ticket.activationTimestamp))
                }
                if (ticket.expiryTimestamp != null) {
                    InfoRow(label = "Expires", value = FareEngine.formatTimestamp(ticket.expiryTimestamp))
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Action buttons based on state
                if (ticket.status == "READY_TO_ACTIVATE") {
                    Button(
                        onClick = {
                            onActivate()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ValleyGreen),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("activate_ticket_action_button")
                    ) {
                        Text("ACTIVATE NOW • START JOURNEY", color = Color.White, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = {
                            onRefund()
                            onDismiss()
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRed),
                        border = BorderStroke(1.dp, AlertRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Simulate Refund/Cancellation")
                    }
                }

                if (ticket.status == "ACTIVE") {
                    OutlinedButton(
                        onClick = {
                            onRefund()
                            onDismiss()
                        },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = AlertRed),
                        border = BorderStroke(1.dp, AlertRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Simulate Refund (Active Pass)")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // STATE TRANSITION EVENT LEDGER (Immutable audit log)
                Text(
                    text = "Immutable Verification Ledger",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    color = SlateGrey,
                    modifier = Modifier.align(Alignment.Start)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhiteBg)
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    for (ev in eventLog) {
                        Column {
                            Row(
                                horizontalArrangement = Arrangement.SpaceBetween,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = ev.eventType,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp,
                                    color = MetrolinkBlue
                                )
                                Text(
                                    text = FareEngine.formatTimestamp(ev.timestamp),
                                    fontSize = 10.sp,
                                    color = SlateGrey
                                )
                            }
                            Text(
                                text = ev.description,
                                fontSize = 10.sp,
                                color = CharcoalSteel
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }
            }
        }
    )
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        horizontalArrangement = Arrangement.SpaceBetween,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
    ) {
        Text(label, color = SlateGrey, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(value, color = CharcoalSteel, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}


// -------------------------------------------------------------
// TRIPS / LIVE SIMULATOR MAP SCREEN
// -------------------------------------------------------------
@Composable
fun TripsScreen(viewModel: MetrolinkViewModel) {
    val trains by viewModel.simulatedTrains.collectAsState()
    val stations by viewModel.stations.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MetrolinkBlueDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Metrolink Fleet Tracker",
                        color = Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Simulated real-time positioning on Southern California segments",
                        color = SandNeutral,
                        fontSize = 12.sp
                    )
                }
            }
        }

        // Beautiful Interactive Canvas-drawn transit line segment map
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SandNeutral),
                border = BorderStroke(1.dp, SoftGrey),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        // Drawing connecting lines between simulated stations
                        val lineY = size.height / 2
                        val lineStart = 40.dp.toPx()
                        val lineEnd = size.width - 40.dp.toPx()

                        // Base track line
                        drawLine(
                            color = SlateGrey,
                            start = Offset(lineStart, lineY),
                            end = Offset(lineEnd, lineY),
                            strokeWidth = 4.dp.toPx()
                        )

                        // Burbank Station (Left)
                        drawCircle(
                            color = MetrolinkBlue,
                            center = Offset(lineStart, lineY),
                            radius = 10.dp.toPx()
                        )

                        // LA Union Station (Right)
                        drawCircle(
                            color = MetrolinkBlue,
                            center = Offset(lineEnd, lineY),
                            radius = 10.dp.toPx()
                        )

                        // Draw intermediate crossings
                        drawCircle(
                            color = SoftGrey,
                            center = Offset(size.width / 2, lineY),
                            radius = 8.dp.toPx()
                        )
                    }

                    // Floating station texts
                    Text(
                        text = "Burbank (BURB)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalSteel,
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(start = 20.dp, top = 60.dp)
                    )

                    Text(
                        text = "LA Union (LAUS)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = CharcoalSteel,
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 20.dp, top = 60.dp)
                    )

                    // Draw moving trains based on state progress
                    trains.forEach { train ->
                        val alignVal = when (train.id) {
                            "SB-302" -> 0.3f
                            "OC-601" -> 0.7f
                            else -> 0.5f
                        }
                        Box(
                            modifier = Modifier
                                .align(Alignment.Center)
                                .offset(x = if (train.id == "SB-302") (-60).dp else if (train.id == "OC-601") 60.dp else 0.dp, y = (-20).dp)
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Surface(
                                    color = SunlitOrange,
                                    shape = RoundedCornerShape(4.dp),
                                    border = BorderStroke(1.dp, Color.White)
                                ) {
                                    Text(
                                        text = train.id,
                                        color = Color.White,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(SunlitOrange)
                                )
                            }
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Live Dispatch Monitor",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = SlateGrey
            )
        }

        // Active train status cards list
        if (trains.isEmpty()) {
            item {
                Text("Initializing simulators...", color = SlateGrey)
            }
        } else {
            items(trains) { train ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, SoftGrey),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text(
                                    text = train.lineName,
                                    fontWeight = FontWeight.Bold,
                                    color = MetrolinkBlue,
                                    fontSize = 15.sp
                                )
                                Text(
                                    text = "Id: ${train.id} • ${train.direction}",
                                    fontSize = 12.sp,
                                    color = SlateGrey
                                )
                            }

                            Surface(
                                color = if (train.delayMinutes == 0) LightAccentGreen else AlertRedLight,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (train.delayMinutes == 0) "ON TIME" else "${train.delayMinutes}M DELAY",
                                    color = if (train.delayMinutes == 0) ValleyGreen else AlertRed,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Divider(color = SoftGrey, modifier = Modifier.padding(vertical = 12.dp))

                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("Previous Station", fontSize = 11.sp, color = SlateGrey)
                                Text(train.previousStation, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("Current", fontSize = 11.sp, color = SlateGrey)
                                Text(train.currentStation, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = SunlitOrange)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Next Station", fontSize = 11.sp, color = SlateGrey)
                                Text(train.nextStation, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}


// -------------------------------------------------------------
// MORE / SETTINGS / ACCOUNT SCREEN
// -------------------------------------------------------------
@Composable
fun MoreScreen(viewModel: MetrolinkViewModel) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, SoftGrey),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Customer Profile",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = CharcoalSteel
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Email: tom@ahyx.org", fontSize = 14.sp)
                    Text("Tariff Category: Adult Profile (Standard Rates)", fontSize = 12.sp, color = SlateGrey)
                    Text("Device ID Linked: SD-REG-98A4", fontSize = 11.sp, color = SlateGrey)
                }
            }
        }

        // Diagnostics & Simulator parameters
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, SoftGrey),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Sandbox Operations Panel",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = SunlitOrange,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )

                    // Clear database/tickets
                    Button(
                        onClick = { viewModel.resetDemoEnvironment() },
                        colors = ButtonDefaults.buttonColors(containerColor = AlertRed),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Reset Sandbox Tickets & Data", color = Color.White)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Simulated Sandbox parameters can be reset dynamically at any time to clear testing flows.",
                        fontSize = 11.sp,
                        color = SlateGrey
                    )
                }
            }
        }

        // About the applet
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SandNeutral),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Southern California Passenger Mobility",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        color = CharcoalSteel
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Developed as a functional demonstration for regional transit networks. This product contains offline simulation for ticketing, GPS route models, and secure JWT-like barcode indicators.",
                        fontSize = 12.sp,
                        color = SlateGrey
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Version: 3.6 Enterprise Slice (Kotlin/Compose)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = SlateGrey
                    )
                }
            }
        }
    }
}
