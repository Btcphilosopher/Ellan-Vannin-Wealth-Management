package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.SavedJourney
import com.example.data.model.ServiceAlert
import com.example.data.model.Station
import com.example.data.model.Ticket
import com.example.data.model.TicketEvent
import com.example.data.repository.FareEngine
import com.example.data.repository.MetrolinkRepository
import com.example.data.repository.PaymentResult
import com.example.data.repository.SimulatedTrain
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

data class PlannedJourney(
    val id: String,
    val origin: Station,
    val destination: Station,
    val lineName: String,
    val departureTime: String,
    val arrivalTime: String,
    val durationMinutes: Int,
    val transfers: Int,
    val trainIdentifier: String,
    val stopsList: List<String>,
    val fareCurrent: Double,
    val fareFuture: Double,
    val walkingTimeMinutes: Int,
    val connectingTransit: String,
    val reasonSelected: String
)

sealed class AppScreen {
    object Home : AppScreen()
    object Plan : AppScreen()
    object Tickets : AppScreen()
    object Trips : AppScreen()
    object More : AppScreen()
}

class MetrolinkViewModel(private val repository: MetrolinkRepository) : ViewModel() {

    // Bottom Navigation state
    val currentScreen = MutableStateFlow<AppScreen>(AppScreen.Home)

    // Form inputs for Journey Planning
    val originStationId = MutableStateFlow("BURB") // Burbank Downtown
    val destinationStationId = MutableStateFlow("LAUS") // LA Union Station
    val selectedPassengerCategory = MutableStateFlow("Adult")
    val selectedTicketType = MutableStateFlow("One-Way Ticket")
    val useFutureFarePreview = MutableStateFlow(false)
    
    // Preferences
    val prefAccessibilityRequired = MutableStateFlow(false)
    val prefBicycleRequired = MutableStateFlow(false)
    val prefWalkingPreference = MutableStateFlow("Moderate") // "Minimal", "Moderate", "High"

    // Search query states
    val originSearchQuery = MutableStateFlow("")
    val destinationSearchQuery = MutableStateFlow("")

    // Active Checkout info
    val checkoutInProgress = MutableStateFlow(false)
    val paymentSimulatorOption = MutableStateFlow("SUCCESS") // "SUCCESS", "DECLINE", "TIMEOUT"
    val paymentResultMessage = MutableStateFlow<String?>(null)

    // Active Ticket Details selector
    val selectedTicketIdForDetails = MutableStateFlow<Int?>(null)

    // Flows from database
    val stations: StateFlow<List<Station>> = repository.allStations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tickets: StateFlow<List<Ticket>> = repository.allTickets
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val alerts: StateFlow<List<ServiceAlert>> = repository.activeAlerts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val savedJourneys: StateFlow<List<SavedJourney>> = repository.savedJourneys
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val simulatedTrains: StateFlow<List<SimulatedTrain>> = repository.simulatedTrains

    // Search results
    val originStationOptions: StateFlow<List<Station>> = combine(stations, originSearchQuery) { stationList, query ->
        if (query.isBlank()) stationList else {
            stationList.filter { it.name.contains(query, ignoreCase = true) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val destinationStationOptions: StateFlow<List<Station>> = combine(stations, destinationSearchQuery) { stationList, query ->
        if (query.isBlank()) stationList else {
            stationList.filter { it.name.contains(query, ignoreCase = true) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Planned Journey result calculation
    private val _plannedResults = MutableStateFlow<List<PlannedJourney>>(emptyList())
    val plannedResults: StateFlow<List<PlannedJourney>> = _plannedResults

    // UI Toast Notification Event channel
    private val _uiEvents = MutableSharedFlow<String>()
    val uiEvents: SharedFlow<String> = _uiEvents.asSharedFlow()

    // Mock profiles information
    val accountEmail = MutableStateFlow("tom@ahyx.org")
    val discountVerified = MutableStateFlow(true) // sandbox verification toggle

    init {
        // Run an initial planning so something is visible by default
        viewModelScope.launch {
            stations.collect { list ->
                if (list.isNotEmpty()) {
                    planJourney()
                }
            }
        }
    }

    fun planJourney() {
        viewModelScope.launch {
            val stationList = stations.value
            val origin = stationList.find { it.id == originStationId.value } ?: return@launch
            val dest = stationList.find { it.id == destinationStationId.value } ?: return@launch

            if (origin.id == dest.id) {
                _plannedResults.value = emptyList()
                _uiEvents.emit("Origin and Destination stations cannot be the same.")
                return@launch
            }

            // Generate two options: Recommended and Alternative
            val distance = FareEngine.calculateDistanceMiles(origin.latitude, origin.longitude, dest.latitude, dest.longitude)
            val baseFareCurr = FareEngine.calculateFinalFare(origin, dest, selectedTicketType.value, selectedPassengerCategory.value, false)
            val baseFareFut = FareEngine.calculateFinalFare(origin, dest, selectedTicketType.value, selectedPassengerCategory.value, true)

            val recommended = PlannedJourney(
                id = "PJ-REC",
                origin = origin,
                destination = dest,
                lineName = detectLineName(origin, dest),
                departureTime = "11:05 AM",
                arrivalTime = calculateArrivalTime("11:05 AM", distance),
                durationMinutes = (distance * 1.5 + 5).toInt(),
                transfers = 0,
                trainIdentifier = "ML-305",
                stopsList = generateStopsList(origin, dest),
                fareCurrent = baseFareCurr,
                fareFuture = baseFareFut,
                walkingTimeMinutes = if (prefAccessibilityRequired.value) 2 else 6,
                connectingTransit = "Bus links available at destination",
                reasonSelected = "Fastest direct connection. Rated 99% reliable."
            )

            val alternative = PlannedJourney(
                id = "PJ-ALT",
                origin = origin,
                destination = dest,
                lineName = detectLineName(origin, dest),
                departureTime = "11:45 AM",
                arrivalTime = calculateArrivalTime("11:45 AM", distance + 2.0),
                durationMinutes = (distance * 1.5 + 15).toInt(),
                transfers = 1,
                trainIdentifier = "ML-311",
                stopsList = generateStopsList(origin, dest).take(2) + "Transfer Stop" + generateStopsList(origin, dest).takeLast(1),
                fareCurrent = (baseFareCurr * 0.9).roundToTwoDecimals(), // slightly cheaper alternative
                fareFuture = (baseFareFut * 0.9).roundToTwoDecimals(),
                walkingTimeMinutes = 12,
                connectingTransit = "Connecting Metro Rail at Downtown hub",
                reasonSelected = "Cheapest fare option. Note: includes 1 transfer."
            )

            _plannedResults.value = if (prefAccessibilityRequired.value) {
                // If accessibility is required, filter out routes with high walking or ensure they are fully accessible
                listOf(recommended.copy(reasonSelected = "Accessible Route. Elevators confirmed working at both stations."))
            } else {
                listOf(recommended, alternative)
            }
        }
    }

    private fun detectLineName(o: Station, d: Station): String {
        // Simple logic to find overlapping lines
        val oLines = o.lines.split(",").map { it.trim() }
        val dLines = d.lines.split(",").map { it.trim() }
        val common = oLines.intersect(dLines.toSet())
        return if (common.isNotEmpty()) common.first() else "Regional Interline"
    }

    private fun calculateArrivalTime(deptTime: String, distance: Double): String {
        val minToAdd = (distance * 1.5 + 5).toInt()
        val parts = deptTime.split(" ")
        val timeParts = parts[0].split(":")
        var hour = timeParts[0].toInt()
        var min = timeParts[1].toInt() + minToAdd
        while (min >= 60) {
            min -= 60
            hour += 1
            if (hour > 12) hour -= 12
        }
        val paddedMin = min.toString().padStart(2, '0')
        return "$hour:$paddedMin ${parts[1]}"
    }

    private fun generateStopsList(o: Station, d: Station): List<String> {
        return listOf(o.name, "Intermediate Crossing", d.name)
    }

    // Saved Journeys Actions
    fun toggleSavedJourney(origin: Station, dest: Station) {
        viewModelScope.launch {
            val isSaved = savedJourneys.value.any { it.originId == origin.id && it.destinationId == dest.id }
            if (isSaved) {
                repository.removeSavedJourney(origin.id, dest.id)
                _uiEvents.emit("Removed journey from saved list.")
            } else {
                repository.saveJourney(origin.id, origin.name, dest.id, dest.name)
                _uiEvents.emit("Journey saved to dashboard.")
            }
        }
    }

    // Checkout Lifecycle
    fun startCheckout() {
        checkoutInProgress.value = true
        paymentResultMessage.value = null
    }

    fun completeCheckout(journey: PlannedJourney) {
        viewModelScope.launch {
            val price = if (useFutureFarePreview.value) journey.fareFuture else journey.fareCurrent
            val result = repository.executePaymentAndIssueTicket(
                origin = journey.origin,
                destination = journey.destination,
                ticketType = selectedTicketType.value,
                passengerCategory = selectedPassengerCategory.value,
                price = price,
                paymentOption = paymentSimulatorOption.value,
                useFutureFare = useFutureFarePreview.value
            )

            when (result) {
                is PaymentResult.Success -> {
                    checkoutInProgress.value = false
                    currentScreen.value = AppScreen.Tickets
                    _uiEvents.emit("Payment Successful! Demonstration Ticket Issued.")
                }
                is PaymentResult.Declined -> {
                    paymentResultMessage.value = result.reason
                }
                is PaymentResult.Timeout -> {
                    paymentResultMessage.value = "Gateway Connection Timeout. Please check simulator settings."
                }
            }
        }
    }

    fun cancelCheckout() {
        checkoutInProgress.value = false
        paymentResultMessage.value = null
    }

    // Ticket State Machine Triggers
    fun activateTicket(ticketId: Int) {
        viewModelScope.launch {
            repository.activateTicket(ticketId)
            _uiEvents.emit("DEMO Ticket Activated. Valid for travel (SIMULATED).")
        }
    }

    fun refundTicket(ticketId: Int) {
        viewModelScope.launch {
            repository.refundTicket(ticketId)
            _uiEvents.emit("Ticket Refund Completed. Demo credits updated.")
        }
    }

    fun resetDemoEnvironment() {
        viewModelScope.launch {
            repository.resetTickets()
            _uiEvents.emit("Demo Sandbox Cleared. All tickets purged.")
        }
    }

    fun getTicketEventsFlow(ticketId: Int): Flow<List<TicketEvent>> {
        return repository.getTicketEvents(ticketId)
    }

    private fun Double.roundToTwoDecimals(): Double {
        return (this * 100.0).roundToInt() / 100.0
    }
}
