package com.example.data.repository

import com.example.data.model.Station
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.*

data class FareVersion(
    val versionId: String,
    val name: String,
    val effectiveTimestamp: Long,
    val baseFare: Double,
    val perMileRate: Double,
    val socalDayPassFlat: Double,
    val laZoneDayPassFlat: Double,
    val monthlyPassFlat: Double
)

object FareEngine {
    // Current date is Sep 18, 2026
    val FARE_VERSIONS = listOf(
        FareVersion(
            versionId = "v1.0",
            name = "2024 regional tariff",
            effectiveTimestamp = 1704067200000L, // Jan 1, 2024
            baseFare = 5.00,
            perMileRate = 0.15,
            socalDayPassFlat = 15.00,
            laZoneDayPassFlat = 12.00,
            monthlyPassFlat = 180.00
        ),
        FareVersion(
            versionId = "v2.0_future",
            name = "2027 scheduled adjustment",
            effectiveTimestamp = 1798761600000L, // Jan 1, 2027 (Future from Sep 2026)
            baseFare = 5.50,
            perMileRate = 0.18,
            socalDayPassFlat = 16.50,
            laZoneDayPassFlat = 13.50,
            monthlyPassFlat = 195.00
        )
    )

    fun getActiveVersion(targetTime: Long = System.currentTimeMillis()): FareVersion {
        // Find the newest version that is effective before or at the target time
        return FARE_VERSIONS.filter { it.effectiveTimestamp <= targetTime }
            .maxByOrNull { it.effectiveTimestamp }
            ?: FARE_VERSIONS.first()
    }

    fun getFutureVersion(): FareVersion {
        return FARE_VERSIONS.first { it.versionId == "v2.0_future" }
    }

    // Haversine distance formula to compute distance between stations
    fun calculateDistanceMiles(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 3958.8 // Earth radius in miles
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2).pow(2.0) +
                cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2).pow(2.0)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    fun calculateBasePrice(
        origin: Station,
        destination: Station,
        ticketType: String,
        version: FareVersion
    ): Double {
        val distance = calculateDistanceMiles(origin.latitude, origin.longitude, destination.latitude, destination.longitude)
        
        return when (ticketType) {
            "SoCal Day Pass" -> version.socalDayPassFlat
            "LA Zone Day Pass" -> version.laZoneDayPassFlat
            "Monthly Pass" -> version.monthlyPassFlat
            "5-Day Flex Pass" -> {
                // 5 days for the price of 4 One-Ways
                val singleTrip = version.baseFare + (distance * version.perMileRate)
                (singleTrip * 2 * 4) * 0.9 // Round trip x 4 with extra discount
            }
            "Round-Trip Ticket" -> {
                val singleTrip = version.baseFare + (distance * version.perMileRate)
                (singleTrip * 2) * 0.95 // 5% discount on round-trip
            }
            "One-Way Ticket" -> {
                version.baseFare + (distance * version.perMileRate)
            }
            else -> {
                version.baseFare + (distance * version.perMileRate)
            }
        }
    }

    fun getPassengerDiscountMultiplier(category: String): Double {
        return when (category) {
            "Adult" -> 1.0
            "Student/Youth" -> 0.75 // 25% discount
            "Senior" -> 0.50 // 50% discount
            "Disabled/Medicare" -> 0.50 // 50% discount
            "Veteran/Military" -> 0.75 // 25% discount
            else -> 1.0
        }
    }

    fun calculateFinalFare(
        origin: Station,
        destination: Station,
        ticketType: String,
        passengerCategory: String,
        useFutureFare: Boolean = false,
        customTime: Long = System.currentTimeMillis()
    ): Double {
        val version = if (useFutureFare) getFutureVersion() else getActiveVersion(customTime)
        val basePrice = calculateBasePrice(origin, destination, ticketType, version)
        val multiplier = getPassengerDiscountMultiplier(passengerCategory)
        return (basePrice * multiplier).roundToTwoDecimals()
    }

    private fun Double.roundToTwoDecimals(): Double {
        return (this * 100.0).roundToInt() / 100.0
    }

    fun formatTimestamp(timestamp: Long): String {
        val sdf = SimpleDateFormat("MMM dd, yyyy", Locale.US)
        return sdf.format(Date(timestamp))
    }
}
