# UNILEVER — Retail & Distribution Hub

Independent enterprise retail operations concept application using synthetic UK & Ireland business data.

## Quick Start

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Automated Validation Suite

```bash
npm test
```

Runs domain integrity tests covering:
- Unit / case / pallet packaging conversion versioning
- Atomic concurrent stock reservation locking
- Expired & quarantined batch exclusion during FEFO allocation
- Partial delivery POD & delivered-quantity invoicing
- Promotion precedence rules
- Idempotent EDI message processing
- Balanced double-entry subledger verification
- Role-based access control (RBAC) enforcement
- Leak-free walk-forward forecast backtesting
- Dashboard KPI reconciliation
- AI Operations Copilot human-approval gating
