import type { Request, Response, NextFunction } from 'express';
import type { Permission, RoleDefinition, RoleId } from './types.ts';

export const ROLES: Record<RoleId, RoleDefinition> = {
  commercial_director: {
    id: 'commercial_director',
    name: 'Commercial Director',
    userDisplayName: 'Claire Bennett',
    userInitials: 'CB',
    marketScope: ['UK & Ireland', 'Great Britain', 'Ireland'],
    description: 'Full commercial oversight across pricing, promo approvals, exception allocation, and P&L.',
    permissions: [
      'orders:create',
      'orders:allocate',
      'orders:approve_exception',
      'promotions:manage',
      'promotions:approve',
      'forecasts:override',
      'products:edit',
      'accounts:edit',
      'ai:propose',
      'ai:approve',
      'reports:export',
    ],
  },
  account_manager: {
    id: 'account_manager',
    name: 'Account Manager',
    userDisplayName: 'Oliver Grant',
    userInitials: 'OG',
    marketScope: ['UK & Ireland', 'Great Britain'],
    description: 'Manages retail accounts, commercial agreements, order entry, and promo proposals.',
    permissions: [
      'orders:create',
      'promotions:manage',
      'accounts:edit',
      'ai:propose',
      'reports:export',
    ],
  },
  demand_planner: {
    id: 'demand_planner',
    name: 'Demand Planner',
    userDisplayName: 'Priya Sharma',
    userInitials: 'PS',
    marketScope: ['UK & Ireland', 'Great Britain', 'Ireland'],
    description: 'Owns baseline forecasts, manual overrides, replenishment plans, and allocation approvals.',
    permissions: [
      'orders:allocate',
      'orders:approve_exception',
      'forecasts:override',
      'inventory:adjust',
      'ai:propose',
      'ai:approve',
      'reports:export',
    ],
  },
  warehouse_operator: {
    id: 'warehouse_operator',
    name: 'Warehouse Operator',
    userDisplayName: 'Liam Gallagher',
    userInitials: 'LG',
    marketScope: ['UK & Ireland', 'Great Britain'],
    description: 'Executes goods receipts, put-away, FEFO batch picking, stock counts, and transfers.',
    permissions: [
      'inventory:adjust',
      'inventory:pick',
      'inventory:recall',
      'ai:propose',
    ],
  },
  distribution_coordinator: {
    id: 'distribution_coordinator',
    name: 'Distribution Coordinator',
    userDisplayName: 'Hannah Reid',
    userInitials: 'HR',
    marketScope: ['UK & Ireland', 'Great Britain', 'Ireland'],
    description: 'Plans carrier loads, confirms dispatches, and records proof-of-delivery & shortages.',
    permissions: [
      'distribution:dispatch',
      'distribution:pod',
      'ai:propose',
      'reports:export',
    ],
  },
  finance_analyst: {
    id: 'finance_analyst',
    name: 'Finance Analyst',
    userDisplayName: 'Marcus Vance',
    userInitials: 'MV',
    marketScope: ['UK & Ireland', 'Great Britain', 'Ireland'],
    description: 'Issues invoices & credit notes, allocates cash receipts, manages accruals and subledger.',
    permissions: [
      'finance:invoice',
      'finance:payment',
      'finance:ledger',
      'ai:propose',
      'ai:approve',
      'reports:export',
    ],
  },
  administrator: {
    id: 'administrator',
    name: 'Administrator',
    userDisplayName: 'Tom Hayes (UL)',
    userInitials: 'UL',
    marketScope: ['UK & Ireland', 'Great Britain', 'Ireland'],
    description: 'Full operational & administrative permissions across all UK & Ireland modules and audit controls.',
    permissions: [
      'orders:create',
      'orders:allocate',
      'orders:approve_exception',
      'inventory:adjust',
      'inventory:pick',
      'inventory:recall',
      'distribution:dispatch',
      'distribution:pod',
      'promotions:manage',
      'promotions:approve',
      'forecasts:override',
      'finance:invoice',
      'finance:payment',
      'finance:ledger',
      'products:edit',
      'accounts:edit',
      'ai:propose',
      'ai:approve',
      'admin:manage',
      'reports:export',
    ],
  },
  read_only_reviewer: {
    id: 'read_only_reviewer',
    name: 'Read-only Reviewer',
    userDisplayName: 'Audit Guest',
    userInitials: 'RO',
    marketScope: ['UK & Ireland'],
    description: 'Inspection-only access across dashboards, traceability, subledger, and audit trails.',
    permissions: [],
  },
};

export function getRoleFromRequest(req: Request): RoleDefinition {
  const headerRole = (req.header('x-user-role') || 'administrator').toLowerCase() as RoleId;
  return ROLES[headerRole] || ROLES.administrator;
}

export function hasPermission(role: RoleDefinition, perm: Permission): boolean {
  return role.permissions.includes(perm);
}

export function requirePermission(perm: Permission) {
  return (req: Request, res: Response, next: NextFunction) => {
    const role = getRoleFromRequest(req);
    if (!hasPermission(role, perm)) {
      return res.status(403).json({
        error: 'Permission denied',
        code: 'FORBIDDEN',
        requiredPermission: perm,
        activeRole: role.name,
        message: `Role "${role.name}" does not hold "${perm}" permission. Switch to an authorised role in the user menu to perform this action.`,
      });
    }
    return next();
  };
}
