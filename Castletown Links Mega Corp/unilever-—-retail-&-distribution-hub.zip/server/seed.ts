import type { DatabaseSync } from 'node:sqlite';
import { withTransaction } from './db.ts';

export function seedDatabase(db: DatabaseSync, forceReset = false) {
  const existing = db.prepare('SELECT COUNT(*) as cnt FROM brands').get() as { cnt: number };
  if (existing.cnt > 0 && !forceReset) return;

  withTransaction(db, () => {
    if (forceReset) {
      const tables = [
        'edi_inbox',
        'notifications',
        'audit_logs',
        'ai_proposals',
        'channel_period_summaries',
        'ledger_entries',
        'payments',
        'invoices',
        'supply_exceptions',
        'forecasts',
        'promotions',
        'shipments',
        'inventory_movements',
        'stock_reservations',
        'order_lines',
        'orders',
        'inventory_batches',
        'account_price_lists',
        'delivery_locations',
        'retail_accounts',
        'locations',
        'packaging_conversions',
        'products',
        'brands',
      ];
      for (const t of tables) {
        db.exec(`DELETE FROM ${t};`);
      }
    }

    const now = '2026-11-13T08:00:00Z';

    // 1. Brands
    const insertBrand = db.prepare(`
      INSERT INTO brands (id, name, category, logo_url, accent_color, plan_target_pence, availability_pct, active)
      VALUES (?, ?, ?, ?, ?, ?, ?, 1)
    `);
    insertBrand.run('brd-dove', 'Dove', 'Personal Care', '/assets/brands/dove.svg', '#0B2E6B', 1189800000, 98.7);
    insertBrand.run('brd-persil', 'Persil', 'Home Care', '/assets/brands/persil.svg', '#D51317', 1061450000, 97.2);
    insertBrand.run('brd-hellmanns', "Hellmann's", 'Food & Nutrition', '/assets/brands/hellmanns.svg', '#0A2B66', 735150000, 98.1);
    insertBrand.run('brd-comfort', 'Comfort', 'Home Care', '/assets/brands/comfort.svg', '#5B3A99', 583330000, 96.9);
    insertBrand.run('brd-simple', 'Simple', 'Personal Care', '/assets/brands/simple.svg', '#2E7D32', 448470000, 97.5);

    // 2. Products & Versioned Packaging Conversions
    const insertProduct = db.prepare(`
      INSERT INTO products (
        id, sku, gtin, brand_id, name, variant, pack_size, category, markets_json, image_url,
        dimensions_cm, weight_kg, batch_tracked, shelf_life_days, allergens_json,
        storage_requirements, handling_notes, unit_cost_pence, list_price_case_pence, tax_code, status, version, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, 'Active', 1, ?)
    `);

    const insertConv = db.prepare(`
      INSERT INTO packaging_conversions (
        id, product_id, version_num, units_per_case, cases_per_pallet, effective_from, effective_to, is_current
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const products = [
      {
        id: 'prd-persil-24w',
        sku: 'UL-PER-24W',
        gtin: '5000101420118',
        brandId: 'brd-persil',
        name: 'Persil Non Bio Liquid 24-Wash',
        variant: 'Non Bio Concentrated',
        packSize: '840ml bottle',
        category: 'Home Care',
        markets: ['UK & Ireland', 'Great Britain', 'Ireland'],
        image: '/assets/images/product_persil_detergent_1794570847843.jpg',
        dim: '28 x 19 x 24',
        weight: 5.4,
        shelf: 730,
        allergens: [],
        storage: 'Ambient dry warehouse (5°C–28°C), keep upright',
        handling: 'Max stack height 4 pallets; UN non-hazardous surfactant',
        cost: 980,
        price: 1650,
        tax: 'VAT_UK_STD_20',
        convs: [
          { id: 'cnv-per24-v1', ver: 1, units: 8, casesPerPallet: 56, from: '2025-01-01', to: '2026-06-30', curr: 0 },
          { id: 'cnv-per24-v2', ver: 2, units: 6, casesPerPallet: 64, from: '2026-07-01', to: null, curr: 1 },
        ],
      },
      {
        id: 'prd-persil-pods',
        sku: 'UL-PER-POD38',
        gtin: '5000101420989',
        brandId: 'brd-persil',
        name: 'Persil 3-in-1 Bio Capsules',
        variant: 'Bio 38-Wash Tub',
        packSize: '38 capsules',
        category: 'Home Care',
        markets: ['UK & Ireland', 'Great Britain'],
        image: '/assets/images/product_persil_detergent_1794570847843.jpg',
        dim: '34 x 24 x 18',
        weight: 6.1,
        shelf: 540,
        allergens: [],
        storage: 'Humidity-controlled ambient (<60% RH) to protect PVA film',
        handling: 'Child-lock lid verification required at QC',
        cost: 1240,
        price: 2100,
        tax: 'VAT_UK_STD_20',
        convs: [{ id: 'cnv-perpod-v1', ver: 1, units: 6, casesPerPallet: 60, from: '2026-01-01', to: null, curr: 1 }],
      },
      {
        id: 'prd-dove-bw',
        sku: 'UL-DOV-BW400',
        gtin: '5000118204114',
        brandId: 'brd-dove',
        name: 'Dove Deeply Nourishing Body Wash',
        variant: 'Deeply Nourishing',
        packSize: '400ml bottle',
        category: 'Personal Care',
        markets: ['UK & Ireland', 'Great Britain', 'Ireland'],
        image: '/assets/images/product_dove_bodywash_1794570847011.jpg',
        dim: '30 x 22 x 21',
        weight: 5.2,
        shelf: 900,
        allergens: [],
        storage: 'Ambient (5°C–25°C), avoid direct sunlight',
        handling: 'Pump-lock collar check on export/transit pallets',
        cost: 1120,
        price: 2280,
        tax: 'VAT_UK_STD_20',
        convs: [{ id: 'cnv-dovbw-v1', ver: 1, units: 12, casesPerPallet: 80, from: '2026-01-01', to: null, curr: 1 }],
      },
      {
        id: 'prd-dove-deo',
        sku: 'UL-DOV-DEO200',
        gtin: '5000118204886',
        brandId: 'brd-dove',
        name: 'Dove Original Antiperspirant Aerosol',
        variant: 'Original Clean',
        packSize: '200ml can',
        category: 'Personal Care',
        markets: ['UK & Ireland', 'Great Britain', 'Ireland'],
        image: '/assets/images/product_dove_bodywash_1794570847011.jpg',
        dim: '27 x 21 x 22',
        weight: 3.1,
        shelf: 1095,
        allergens: [],
        storage: 'Aerosol caged storage bay (UN1950 Class 2.1, <30°C)',
        handling: 'ADR Limited Quantity placard required on carrier manifest',
        cost: 1310,
        price: 2520,
        tax: 'VAT_UK_STD_20',
        convs: [{ id: 'cnv-dovdeo-v1', ver: 1, units: 12, casesPerPallet: 96, from: '2026-01-01', to: null, curr: 1 }],
      },
      {
        id: 'prd-hell-400',
        sku: 'UL-HEL-MAYO400',
        gtin: '5000184120042',
        brandId: 'brd-hellmanns',
        name: "Hellmann's Real Mayonnaise Glass Jar",
        variant: 'Real Classic',
        packSize: '400g jar',
        category: 'Food & Nutrition',
        markets: ['UK & Ireland', 'Great Britain', 'Ireland'],
        image: '/assets/images/product_hellmanns_mayo_1794570848895.jpg',
        dim: '32 x 24 x 16',
        weight: 7.4,
        shelf: 270,
        allergens: ['Egg', 'Mustard'],
        storage: 'Cool ambient food-grade bay (8°C–20°C), strict FEFO',
        handling: 'Fragile glass divider trays; BRCGS food-safety segregated bay',
        cost: 1050,
        price: 1980,
        tax: 'VAT_UK_ZERO_0',
        convs: [{ id: 'cnv-hel400-v1', ver: 1, units: 12, casesPerPallet: 72, from: '2026-01-01', to: null, curr: 1 }],
      },
      {
        id: 'prd-hell-sqz',
        sku: 'UL-HEL-SQZ430',
        gtin: '5000184120554',
        brandId: 'brd-hellmanns',
        name: "Hellmann's Squeezy Light Mayonnaise",
        variant: 'Light 430ml',
        packSize: '430ml squeezy',
        category: 'Food & Nutrition',
        markets: ['UK & Ireland', 'Great Britain'],
        image: '/assets/images/product_hellmanns_mayo_1794570848895.jpg',
        dim: '29 x 20 x 20',
        weight: 4.9,
        shelf: 240,
        allergens: ['Egg', 'Mustard'],
        storage: 'Cool ambient food-grade bay (8°C–20°C)',
        handling: 'Strict 90-day minimum shelf-life on retail delivery (MLOR)',
        cost: 920,
        price: 1740,
        tax: 'VAT_UK_ZERO_0',
        convs: [{ id: 'cnv-helsqz-v1', ver: 1, units: 8, casesPerPallet: 84, from: '2026-01-01', to: null, curr: 1 }],
      },
      {
        id: 'prd-comf-lav',
        sku: 'UL-COM-LAV15',
        gtin: '5000101881018',
        brandId: 'brd-comfort',
        name: 'Comfort Pure & Lavender Fabric Conditioner',
        variant: 'Lavender Bloom 48-Wash',
        packSize: '1.44L bottle',
        category: 'Home Care',
        markets: ['UK & Ireland', 'Great Britain', 'Ireland'],
        image: '/assets/images/product_comfort_simple_1794570848984.jpg',
        dim: '36 x 24 x 28',
        weight: 9.2,
        shelf: 730,
        allergens: [],
        storage: 'Frost-protected warehouse (>4°C to prevent viscosity gelation)',
        handling: 'Heavy liquid case — pallet corner boards mandatory',
        cost: 890,
        price: 1680,
        tax: 'VAT_UK_STD_20',
        convs: [{ id: 'cnv-comlav-v1', ver: 1, units: 6, casesPerPallet: 48, from: '2026-01-01', to: null, curr: 1 }],
      },
      {
        id: 'prd-simp-fw',
        sku: 'UL-SIM-FW150',
        gtin: '5011417552100',
        brandId: 'brd-simple',
        name: 'Simple Kind to Skin Refreshing Facial Wash',
        variant: 'Kind to Skin 150ml',
        packSize: '150ml tube',
        category: 'Personal Care',
        markets: ['UK & Ireland', 'Great Britain', 'Ireland'],
        image: '/assets/images/product_comfort_simple_1794570848984.jpg',
        dim: '24 x 18 x 16',
        weight: 2.3,
        shelf: 900,
        allergens: [],
        storage: 'Ambient clean cosmetic zone (10°C–25°C)',
        handling: 'Shelf-ready retail display outer (SRP)',
        cost: 960,
        price: 1920,
        tax: 'VAT_UK_STD_20',
        convs: [{ id: 'cnv-simpfw-v1', ver: 1, units: 12, casesPerPallet: 110, from: '2026-01-01', to: null, curr: 1 }],
      },
    ];

    for (const p of products) {
      insertProduct.run(
        p.id,
        p.sku,
        p.gtin,
        p.brandId,
        p.name,
        p.variant,
        p.packSize,
        p.category,
        JSON.stringify(p.markets),
        p.image,
        p.dim,
        p.weight,
        p.shelf,
        JSON.stringify(p.allergens),
        p.storage,
        p.handling,
        p.cost,
        p.price,
        p.tax,
        now
      );
      for (const c of p.convs) {
        insertConv.run(c.id, p.id, c.ver, c.units, c.casesPerPallet, c.from, c.to, c.curr);
      }
    }

    // 3. Locations (DCs)
    const insertLoc = db.prepare(`
      INSERT INTO locations (id, code, name, type, market, city, capacity_pallets)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    insertLoc.run('loc-leeds', 'DC-LDS', 'Leeds DC', 'DC', 'Great Britain', 'Leeds', 18500);
    insertLoc.run('loc-mk', 'DC-MK', 'Milton Keynes NDC', 'NDC', 'Great Britain', 'Milton Keynes', 32000);
    insertLoc.run('loc-war', 'DC-WAR', 'Warrington DC', 'DC', 'Great Britain', 'Warrington', 14200);
    insertLoc.run('loc-dub', 'DC-DUB', 'Dublin Hub', 'Hub', 'Ireland', 'Dublin', 9600);

    // 4. Retail Accounts & Delivery Locations & Agreed Price Lists
    const insertAcc = db.prepare(`
      INSERT INTO retail_accounts (
        id, name, legal_entity, channel, market, logo_url, account_manager,
        commercial_contact, contact_email, ordering_entity, invoice_recipient,
        payment_terms_days, rebate_rate_pct, otif_target_pct, fill_target_pct, credit_limit_pence
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertAcc.run(
      'acc-tesco',
      'Tesco',
      'Tesco Stores Ltd (UK Retail)',
      'Grocery',
      'UK & Ireland',
      '/assets/retailers/tesco.svg',
      'Oliver Grant',
      'Eleanor Vance (Senior Buying Mgr)',
      'edi.buying@tesco-demo.example',
      'Tesco Central Replenishment (GLN 5010001000012)',
      'Tesco AP Shared Services, Welwyn Garden City',
      45,
      3.5,
      98.0,
      98.5,
      950000000
    );
    insertAcc.run(
      'acc-sainsburys',
      "Sainsbury's",
      "Sainsbury's Supermarkets Ltd",
      'Grocery',
      'Great Britain',
      '/assets/retailers/sainsburys.svg',
      'Oliver Grant',
      'David Thorne (Category Supply Lead)',
      'supply@sainsburys-demo.example',
      "Sainsbury's Holborn Buying Desk",
      "Sainsbury's Accounts Payable, Manchester",
      45,
      3.2,
      97.5,
      98.0,
      780000000
    );
    insertAcc.run(
      'acc-asda',
      'ASDA',
      'Asda Stores Ltd',
      'Grocery',
      'Great Britain',
      '/assets/retailers/asda.svg',
      'Claire Bennett',
      'Sophie Miller (Home & Personal Care)',
      'replenishment@asda-demo.example',
      'ASDA House Purchasing (Leeds)',
      'ASDA Finance Operations, Leeds',
      30,
      2.8,
      97.0,
      97.5,
      690000000
    );
    insertAcc.run(
      'acc-morrisons',
      'Morrisons',
      'Wm Morrison Supermarkets Ltd',
      'Grocery',
      'Great Britain',
      '/assets/retailers/morrisons.svg',
      'Oliver Grant',
      'Callum Briggs (Laundry & Household)',
      'orders@morrisons-demo.example',
      'Morrisons Hilmore House Buying',
      'Morrisons Commercial AP, Bradford',
      30,
      3.0,
      96.5,
      97.0,
      540000000
    );
    insertAcc.run(
      'acc-coop',
      'Co-op Convenience',
      'Co-operative Group Food Ltd',
      'Convenience',
      'UK & Ireland',
      '/assets/retailers/coop.svg',
      'Claire Bennett',
      'Niamh Doyle (Convenience Supply)',
      'orders@coop-demo.example',
      'Co-op Angel Square Replenishment',
      'Co-op Group AP, Manchester',
      30,
      2.4,
      96.0,
      97.0,
      320000000
    );
    insertAcc.run(
      'acc-booker',
      'Booker Wholesale',
      'Booker Group Wholesale Ltd',
      'Wholesale',
      'UK & Ireland',
      '/assets/retailers/booker.svg',
      'Marcus Vance',
      'Rajesh Patel (National Cash & Carry)',
      'wholesale@booker-demo.example',
      'Booker Wellingborough Central Hub',
      'Booker Wholesale AP, Wellingborough',
      60,
      4.1,
      96.5,
      96.8,
      480000000
    );

    const insertDelivLoc = db.prepare(`
      INSERT INTO delivery_locations (id, account_id, code, name, address, postcode, booking_window)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    insertDelivLoc.run('dloc-tesco-don', 'acc-tesco', 'TES-DON', 'Tesco Doncaster RDC', 'Middle Bank, Doncaster', 'DN4 5JJ', '06:00 - 10:00');
    insertDelivLoc.run('dloc-sains-hay', 'acc-sainsburys', 'SAI-HAY', "Sainsbury's Haydock RDC", 'Penny Lane, Haydock', 'WA11 0QZ', '07:00 - 11:00');
    insertDelivLoc.run('dloc-asda-wak', 'acc-asda', 'ASD-WAK', 'ASDA Wakefield ADC', 'Tuscany Park, Wakefield', 'WF6 2UA', '05:30 - 09:30');
    insertDelivLoc.run('dloc-morr-wak', 'acc-morrisons', 'MOR-WAK', 'Morrisons Wakefield RDC', '41 Kenmore Road, Wakefield', 'WF2 0XF', '08:00 - 12:00');
    insertDelivLoc.run('dloc-coop-bir', 'acc-coop', 'COO-BIR', 'Co-op Birtley NDC', 'Durham Road, Birtley', 'DH3 2QU', '06:00 - 14:00');
    insertDelivLoc.run('dloc-book-hat', 'acc-booker', 'BKR-HAT', 'Booker Hatfield NDC', 'Travellers Lane, Hatfield', 'AL10 8HY', '08:00 - 16:00');

    const insertPriceList = db.prepare(`
      INSERT INTO account_price_lists (id, account_id, product_id, agreed_case_price_pence, off_invoice_discount_pct, currency, effective_from, effective_to, is_listed)
      VALUES (?, ?, ?, ?, ?, 'GBP', '2026-01-01', '2027-12-31', 1)
    `);
    const accIds = ['acc-tesco', 'acc-sainsburys', 'acc-asda', 'acc-morrisons', 'acc-coop', 'acc-booker'];
    for (const accId of accIds) {
      for (const p of products) {
        const discount = accId === 'acc-tesco' ? 4.0 : accId === 'acc-booker' ? 5.0 : accId === 'acc-morrisons' ? 2.5 : 3.0;
        const agreedPrice = Math.round(p.price * (1 - discount / 100));
        insertPriceList.run(`pl-${accId}-${p.id}`, accId, p.id, agreedPrice, discount);
      }
    }

    // 5. Inventory Batches (including active FEFO, quarantined, expired, in-transit!)
    const insertBatch = db.prepare(`
      INSERT INTO inventory_batches (
        id, product_id, location_id, batch_number, manufactured_at, expiry_date, status,
        on_hand_cases, reserved_cases, quarantined_cases, damaged_cases, expired_cases, in_transit_cases, version
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    `);

    // Persil 24-wash at Leeds DC:
    // Available total at Leeds DC = 1,420 cases (Batch 1: 920 avail + Batch 2: 500 avail), PLUS 480 already reserved for Tesco/ASDA,
    // PLUS 220 quarantined (QA hold), PLUS 90 expired (must NEVER allocate!).
    // So when Morrisons requests 2,880 cases from Leeds DC, there is an explicit shortage of 1,460 cases!
    // Meanwhile Milton Keynes NDC has 3,400 available cases of Persil 24-wash ready for cross-DC transfer or split allocation!
    insertBatch.run('bat-per24-lds-1', 'prd-persil-24w', 'loc-leeds', 'BAT-PER-2610A', '2026-09-10', '2028-09-10', 'AVAILABLE', 1400, 480, 0, 0, 0, 0);
    insertBatch.run('bat-per24-lds-2', 'prd-persil-24w', 'loc-leeds', 'BAT-PER-2611B', '2026-10-18', '2028-10-18', 'AVAILABLE', 500, 0, 0, 0, 0, 0);
    insertBatch.run('bat-per24-lds-q', 'prd-persil-24w', 'loc-leeds', 'BAT-PER-2609Q', '2026-08-20', '2028-08-20', 'QUARANTINED', 0, 0, 220, 0, 0, 0);
    insertBatch.run('bat-per24-lds-e', 'prd-persil-24w', 'loc-leeds', 'BAT-PER-2510E', '2024-10-01', '2026-10-15', 'EXPIRED', 0, 0, 0, 0, 90, 0);
    insertBatch.run('bat-per24-mk-1', 'prd-persil-24w', 'loc-mk', 'BAT-PER-2610M', '2026-10-02', '2028-10-02', 'AVAILABLE', 3400, 0, 0, 0, 0, 0);
    insertBatch.run('bat-per24-mk-t', 'prd-persil-24w', 'loc-mk', 'BAT-PER-2611T', '2026-11-05', '2028-11-05', 'IN_TRANSIT', 0, 0, 0, 0, 0, 640);

    // Other SKUs batches
    insertBatch.run('bat-perpod-lds-1', 'prd-persil-pods', 'loc-leeds', 'BAT-POD-2610A', '2026-10-01', '2028-03-30', 'AVAILABLE', 4100, 960, 0, 0, 0, 0);
    insertBatch.run('bat-dovbw-mk-1', 'prd-dove-bw', 'loc-mk', 'BAT-DOV-2610A', '2026-10-05', '2029-04-05', 'AVAILABLE', 6800, 1200, 0, 0, 0, 0);
    insertBatch.run('bat-dovbw-lds-1', 'prd-dove-bw', 'loc-leeds', 'BAT-DOV-2610B', '2026-10-12', '2029-04-12', 'AVAILABLE', 2100, 400, 0, 35, 0, 0);
    insertBatch.run('bat-dovdeo-war-1', 'prd-dove-deo', 'loc-war', 'BAT-DEO-2609A', '2026-09-14', '2029-09-14', 'AVAILABLE', 5200, 800, 0, 0, 0, 0);
    insertBatch.run('bat-hel400-mk-1', 'prd-hell-400', 'loc-mk', 'BAT-HEL-2610A', '2026-10-15', '2027-07-12', 'AVAILABLE', 1950, 720, 0, 0, 0, 0);
    insertBatch.run('bat-hel400-lds-1', 'prd-hell-400', 'loc-leeds', 'BAT-HEL-2608A', '2026-08-10', '2027-05-07', 'AVAILABLE', 840, 240, 80, 0, 0, 0);
    insertBatch.run('bat-helsqz-war-1', 'prd-hell-sqz', 'loc-war', 'BAT-HSQ-2610A', '2026-10-20', '2027-06-18', 'AVAILABLE', 3100, 420, 0, 0, 0, 0);
    insertBatch.run('bat-comlav-mk-1', 'prd-comf-lav', 'loc-mk', 'BAT-COM-2610A', '2026-10-08', '2028-10-08', 'AVAILABLE', 5800, 1100, 0, 0, 0, 0);
    insertBatch.run('bat-simpfw-dub-1', 'prd-simp-fw', 'loc-dub', 'BAT-SIM-2610A', '2026-10-11', '2029-03-28', 'AVAILABLE', 4600, 540, 0, 0, 0, 0);
    insertBatch.run('bat-simpfw-mk-1', 'prd-simp-fw', 'loc-mk', 'BAT-SIM-2610B', '2026-10-15', '2029-04-02', 'AVAILABLE', 3900, 320, 0, 0, 0, 0);

    // 6. Featured & Supporting Orders
    const insertOrder = db.prepare(`
      INSERT INTO orders (
        id, order_ref, account_id, delivery_location_id, source_location_id, market, channel,
        reporting_period, order_date, requested_delivery_date, status, operational_flag,
        shipment_state, invoice_state, payment_state, currency, total_cases, allocated_cases,
        delivered_cases, net_amount_pence, edi_message_id, is_featured_overview, notes, version, created_at, updated_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, '2026-11', ?, ?, ?, ?, ?, ?, ?, 'GBP', ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
    `);

    const insertOrderLine = db.prepare(`
      INSERT INTO order_lines (
        id, order_id, product_id, conversion_id, units_per_case_snapshot, cases_per_pallet_snapshot,
        ordered_cases, allocated_cases, picked_cases, dispatched_cases, delivered_cases,
        agreed_case_price_pence, discount_pct, promo_id, line_net_pence
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const insertRes = db.prepare(`
      INSERT INTO stock_reservations (id, order_id, order_line_id, batch_id, cases_reserved, status, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    // Order 1: Tesco UL-24081 (5,280 cases, Confirmed)
    insertOrder.run(
      'ord-24081', 'UL-24081', 'acc-tesco', 'dloc-tesco-don', 'loc-mk', 'Great Britain', 'Grocery',
      '2026-11-11', 'Fri 13 Nov 2026', 'Allocated', 'Confirmed', 'Loading', 'Not Invoiced', 'Unpaid',
      5280, 5280, 0, 10845600, 'EDI-TES-20261111-881', 1,
      'Confirmed national promotional drop for Dove & Comfort.', now, now
    );
    insertOrderLine.run('ol-24081-1', 'ord-24081', 'prd-dove-bw', 'cnv-dovbw-v1', 12, 80, 3200, 3200, 3200, 0, 0, 2189, 4.0, 'prm-tesco-dove', 7004800);
    insertOrderLine.run('ol-24081-2', 'ord-24081', 'prd-comf-lav', 'cnv-comlav-v1', 6, 48, 2080, 2080, 1100, 0, 0, 1613, 4.0, null, 3840800);
    insertRes.run('res-24081-1', 'ord-24081', 'ol-24081-1', 'bat-dovbw-mk-1', 1200, 'ACTIVE', now);
    insertRes.run('res-24081-2', 'ord-24081', 'ol-24081-2', 'bat-comlav-mk-1', 1100, 'ACTIVE', now);

    // Order 2: Sainsbury's UL-24082 (3,960 cases, In transit)
    insertOrder.run(
      'ord-24082', 'UL-24082', 'acc-sainsburys', 'dloc-sains-hay', 'loc-leeds', 'Great Britain', 'Grocery',
      '2026-11-12', 'Mon 16 Nov 2026', 'Dispatched', 'In transit', 'In Transit', 'Not Invoiced', 'Unpaid',
      3960, 3960, 0, 7642800, 'EDI-SAI-20261112-409', 1,
      'Dispatched via Stobart Refrigerated & Ambient Fleet.', now, now
    );
    insertOrderLine.run('ol-24082-1', 'ord-24082', 'prd-persil-pods', 'cnv-perpod-v1', 6, 60, 2400, 2400, 2400, 2400, 0, 2037, 3.0, null, 4888800);
    insertOrderLine.run('ol-24082-2', 'ord-24082', 'prd-hell-400', 'cnv-hel400-v1', 12, 72, 1560, 1560, 1560, 1560, 0, 1921, 3.0, null, 2754000);
    insertRes.run('res-24082-1', 'ord-24082', 'ol-24082-1', 'bat-perpod-lds-1', 960, 'PICKED', now);

    // Order 3: ASDA UL-24083 (4,320 cases, Confirmed)
    insertOrder.run(
      'ord-24083', 'UL-24083', 'acc-asda', 'dloc-asda-wak', 'loc-war', 'Great Britain', 'Grocery',
      '2026-11-12', 'Mon 16 Nov 2026', 'Allocated', 'Confirmed', 'Planned', 'Not Invoiced', 'Unpaid',
      4320, 4320, 0, 8640000, 'EDI-ASD-20261112-712', 1,
      'Confirmed allocation from Warrington & Leeds hubs.', now, now
    );
    insertOrderLine.run('ol-24083-1', 'ord-24083', 'prd-dove-deo', 'cnv-dovdeo-v1', 12, 96, 2200, 2200, 0, 0, 0, 2444, 3.0, null, 5376800);
    insertOrderLine.run('ol-24083-2', 'ord-24083', 'prd-hell-sqz', 'cnv-helsqz-v1', 8, 84, 2120, 2120, 0, 0, 0, 1688, 3.0, 'prm-asda-hell', 3263200);
    insertRes.run('res-24083-1', 'ord-24083', 'ol-24083-1', 'bat-dovdeo-war-1', 800, 'ACTIVE', now);
    insertRes.run('res-24083-2', 'ord-24083', 'ol-24083-2', 'bat-helsqz-war-1', 420, 'ACTIVE', now);

    // Order 4: Morrisons UL-24084 (2,880 cases, Action needed - Persil 24-wash shortage at Leeds DC!)
    insertOrder.run(
      'ord-24084', 'UL-24084', 'acc-morrisons', 'dloc-morr-wak', 'loc-leeds', 'Great Britain', 'Grocery',
      '2026-11-13', 'Tue 17 Nov 2026', 'Submitted', 'Action needed', 'Pending', 'Not Invoiced', 'Unpaid',
      2880, 0, 0, 4633920, 'EDI-MOR-20261113-104', 1,
      'Shortage alert at Leeds DC: 2,880 cases Persil 24-wash requested vs 1,420 cases ATP. Active Morrisons Big Wash promo uplift (+34%).',
      now, now
    );
    insertOrderLine.run(
      'ol-24084-1', 'ord-24084', 'prd-persil-24w', 'cnv-per24-v2', 6, 64,
      2880, 0, 0, 0, 0, 1609, 2.5, 'prm-morr-persil', 4633920
    );

    // Order 5: Co-op Convenience (already delivered & invoiced in period, supporting traceability)
    insertOrder.run(
      'ord-24079', 'UL-24079', 'acc-coop', 'dloc-coop-bir', 'loc-leeds', 'UK & Ireland', 'Convenience',
      '2026-11-08', 'Wed 11 Nov 2026', 'Delivered', 'Confirmed', 'Delivered', 'Issued', 'Paid',
      1800, 1800, 1800, 3240000, 'EDI-COO-20261108-221', 0,
      'Delivered on time and paid in full.', now, now
    );
    insertOrderLine.run('ol-24079-1', 'ord-24079', 'prd-simp-fw', 'cnv-simpfw-v1', 12, 110, 1800, 1800, 1800, 1800, 1800, 1800, 2.4, null, 3240000);

    // 7. Shipments
    const insertShip = db.prepare(`
      INSERT INTO shipments (
        id, shipment_ref, order_id, origin_location_id, destination_id, carrier_name, vehicle_reg,
        vehicle_capacity_pallets, loaded_pallets, delivery_window, status, tracking_feed_status,
        estimated_arrival, confirmed_delivery_at, dispatched_cases, delivered_cases,
        shortage_cases, damaged_cases, rejected_cases, on_time, pod_notes, version
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)
    `);
    insertShip.run(
      'shp-901', 'SHP-UK-901', 'ord-24081', 'loc-mk', 'dloc-tesco-don',
      'DHL Supply Chain UK', 'UK74 DHG', 44, 42, '06:00 - 10:00',
      'Loading', 'Simulated', '2026-11-13T09:15:00Z', null, 0, 0, 0, 0, 0, null,
      'Bay 14 loading in progress at Milton Keynes NDC.'
    );
    insertShip.run(
      'shp-902', 'SHP-UK-902', 'ord-24082', 'loc-leeds', 'dloc-sains-hay',
      'Eddie Stobart Logistics', 'ST26 EDB', 44, 38, '07:00 - 11:00',
      'In Transit', 'Simulated', '2026-11-16T08:40:00Z', null, 3960, 0, 0, 0, 0, null,
      'Departed Leeds DC via M62 Westbound.'
    );
    insertShip.run(
      'shp-903', 'SHP-UK-903', 'ord-24083', 'loc-war', 'dloc-asda-wak',
      'Wincanton Fleet', 'WN73 KLP', 44, 40, '05:30 - 09:30',
      'Planned', 'Stale', '2026-11-16T07:30:00Z', null, 0, 0, 0, 0, 0, null,
      'Carrier slot assigned; awaiting pick release.'
    );
    insertShip.run(
      'shp-899', 'SHP-UK-899', 'ord-24079', 'loc-leeds', 'dloc-coop-bir',
      'GXO Logistics UK', 'GX75 MNO', 26, 17, '06:00 - 14:00',
      'Delivered', 'Simulated', '2026-11-11T10:15:00Z', '2026-11-11T10:08:00Z', 1800, 1800, 0, 0, 0, 1,
      'Clean POD signed by Gatehouse Supervisor D. Bell.'
    );

    // 8. Inventory Movements (Traceability ledger)
    const insertMov = db.prepare(`
      INSERT INTO inventory_movements (
        id, product_id, batch_id, location_id, movement_type, cases_delta,
        reference_type, reference_id, actor_role, notes, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertMov.run('mov-1', 'prd-persil-24w', 'bat-per24-lds-1', 'loc-leeds', 'GOODS_RECEIPT', 1400, 'PO', 'PO-88412', 'warehouse_operator', 'Port Sunlight plant inbound receipt', '2026-10-12T07:30:00Z');
    insertMov.run('mov-2', 'prd-persil-24w', 'bat-per24-lds-1', 'loc-leeds', 'RESERVE', -480, 'ORDER', 'UL-24075', 'demand_planner', 'FEFO allocation reserved', '2026-11-10T11:20:00Z');
    insertMov.run('mov-3', 'prd-persil-24w', 'bat-per24-lds-q', 'loc-leeds', 'QUARANTINE_HOLD', 220, 'QA', 'QA-LDS-19', 'warehouse_operator', 'Seal integrity check hold pending lab clearance', '2026-11-11T14:00:00Z');
    insertMov.run('mov-4', 'prd-persil-24w', 'bat-per24-mk-1', 'loc-mk', 'GOODS_RECEIPT', 3400, 'PO', 'PO-88501', 'warehouse_operator', 'Milton Keynes NDC replenishment', '2026-11-04T09:15:00Z');
    insertMov.run('mov-5', 'prd-simp-fw', 'bat-simpfw-mk-1', 'loc-mk', 'DISPATCH', -1800, 'SHIPMENT', 'SHP-UK-899', 'distribution_coordinator', 'Delivered to Co-op Birtley NDC', '2026-11-11T06:00:00Z');

    // 9. Promotions
    const insertPromo = db.prepare(`
      INSERT INTO promotions (
        id, code, title, account_id, brand_id, product_id, start_date, end_date, mechanic,
        discount_pct, precedence_rank, baseline_weekly_cases, expected_uplift_pct, measured_uplift_pct,
        funding_budget_pence, actual_cost_pence, proposed_volume_cases, actual_volume_cases,
        approval_state, baseline_method, ai_generated
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertPromo.run(
      'prm-morr-persil', 'PRM-MOR-PER11', 'Morrisons Big Wash November Event', 'acc-morrisons', 'brd-persil', 'prd-persil-24w',
      '2026-11-10', '2026-11-24', 'Temporary Price Reduction (TPR) + Gondola End', 18.0, 1,
      1950, 34.0, null, 1850000, 620000, 2610, 890, 'Active',
      'Trailing 8-week non-promotional mean EPOS + order adjusted baseline', 0
    );
    insertPromo.run(
      'prm-tesco-dove', 'PRM-TES-DOV11', 'Tesco Dove Winter Hydration Clubcard', 'acc-tesco', 'brd-dove', 'prd-dove-bw',
      '2026-11-09', '2026-11-23', 'Clubcard Price (£2.50 vs £3.80 RRP)', 22.0, 1,
      2500, 28.0, 26.4, 3400000, 2100000, 3200, 2410, 'Active',
      'Trailing 8-week non-promotional EPOS baseline deseasonalized', 0
    );
    insertPromo.run(
      'prm-asda-hell', 'PRM-ASD-HEL11', "ASDA Hellmann's Festive Table Rollback", 'acc-asda', 'brd-hellmanns', 'prd-hell-sqz',
      '2026-11-16', '2026-12-07', 'Multi-buy 2 for £4.00', 15.0, 2,
      1650, 24.0, null, 1450000, 0, 2046, 0, 'Approved',
      'Prior-year festive baseline + 6-week moving average', 0
    );
    insertPromo.run(
      'prm-coop-comf', 'PRM-COO-COM11', 'Co-op Comfort Lavender Freshness Drive', 'acc-coop', 'brd-comfort', 'prd-comf-lav',
      '2026-11-18', '2026-12-02', 'Off-Invoice 12% + POS Display', 12.0, 2,
      820, 16.5, null, 680000, 0, 955, 0, 'Pending Approval',
      'Trailing 8-week non-promo convenience average', 1
    );

    // 10. Forecasts (Strictly separated datasets + backtest metrics + insufficient data example)
    const insertForecast = db.prepare(`
      INSERT INTO forecasts (
        id, product_id, location_id, period_week, version_label,
        invoiced_sales_cases, customer_orders_cases, consumer_epos_cases,
        baseline_cases, promo_uplift_cases, manual_override_cases, override_reason,
        p10_cases, p50_cases, p90_cases, backtest_wape, backtest_bias, data_sufficiency,
        safety_stock_days, lead_time_days
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertForecast.run('fc-per24-lds-w46', 'prd-persil-24w', 'loc-leeds', '2026-W46', 'v2026.11-Live', 1780, 2880, 1940, 1950, 663, null, null, 2240, 2613, 3050, 8.4, -2.1, 'Sufficient', 7, 4);
    insertForecast.run('fc-per24-lds-w47', 'prd-persil-24w', 'loc-leeds', '2026-W47', 'v2026.11-Live', 0, 1850, 0, 1980, 690, null, null, 2290, 2670, 3120, 8.4, -2.1, 'Sufficient', 7, 4);
    insertForecast.run('fc-dovbw-mk-w46', 'prd-dove-bw', 'loc-mk', '2026-W46', 'v2026.11-Live', 2890, 3200, 3110, 2500, 700, 3200, 'Tesco Clubcard display uplift aligned', 2850, 3200, 3620, 6.2, 1.4, 'Sufficient', 6, 3);
    insertForecast.run('fc-hel400-lds-w46', 'prd-hell-400', 'loc-leeds', '2026-W46', 'v2026.11-Live', 1420, 1560, 1485, 1380, 180, null, null, 1340, 1560, 1810, 7.9, 0.8, 'Sufficient', 8, 5);
    insertForecast.run('fc-simpfw-dub-w46', 'prd-simp-fw', 'loc-dub', '2026-W46', 'v2026.11-Live', 310, 420, 0, 350, 0, null, null, 210, 350, 520, null, null, 'Insufficient (<12 wks EPOS)', 10, 5);

    // 11. Supply Exceptions (18 Open items so Stock Alerts KPI = 18!)
    const insertExc = db.prepare(`
      INSERT INTO supply_exceptions (
        id, product_id, location_id, exception_type, severity, title, subtitle,
        days_cover, demand_basis, recommended_action, related_order_id, status, is_featured, created_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'OPEN', ?, ?)
    `);
    insertExc.run(
      'exc-1', 'prd-persil-24w', 'loc-leeds', 'LOW_STOCK_COVER', 'High',
      'Persil 24-wash • Leeds DC', 'Stock below threshold (2.1 days cover)',
      2.1, 'Trailing 28-day shipments + active promo W46 run rate (675 cases/day)',
      'Approve 1,460-case transfer from Milton Keynes NDC or split-fulfil Morrisons UL-24084',
      'ord-24084', 1, now
    );
    insertExc.run(
      'exc-2', 'prd-dove-bw', 'loc-mk', 'PROMO_UPLIFT', 'Medium',
      'Dove body wash • Promotion uplift', 'Demand +28% vs forecast (promo week)',
      4.4, 'Tesco Clubcard POS telemetry + W46 promotional forecast (725 cases/day)',
      'Increase Milton Keynes safety buffer by 650 cases for W47',
      'ord-24081', 1, now
    );
    insertExc.run(
      'exc-3', 'prd-hell-400', 'loc-leeds', 'REPLENISHMENT_DUE', 'High',
      "Hellmann's 400g • Replenishment due", 'Reorder within 24 hours (1.8 days cover)',
      1.8, 'W46 baseline demand (330 cases/day) vs 600 available cases at Leeds DC',
      'Issue expedited replenishment PO to Burton factory (+1,800 cases)',
      null, 1, now
    );
    // 15 additional realistic alerts so total open alerts = 18 (100% live DB count!)
    const extraExceptions = [
      ['exc-4', 'prd-persil-24w', 'loc-leeds', 'QA_QUARANTINE', 'High', 'Persil 24-wash • Batch QA Hold', '220 cases quarantined on BAT-PER-2609Q', 2.1, 'QA inspection hold', 'Complete lab viscosity check & release or scrap'],
      ['exc-5', 'prd-persil-24w', 'loc-leeds', 'EXPIRED_STOCK', 'Medium', 'Persil 24-wash • Expired Lot Isolation', '90 expired cases pending write-off (BAT-PER-2510E)', 0.0, 'Expiry date 2026-10-15 passed', 'Execute disposal journal & physical removal'],
      ['exc-6', 'prd-hell-400', 'loc-mk', 'MLOR_RISK', 'Medium', "Hellmann's 400g • MLOR Shelf-Life", 'Batch BAT-HEL-2608A approaching retail MLOR threshold', 5.1, 'Food 90-day MLOR rule', 'Prioritize FEFO dispatch to regional Grocery accounts'],
      ['exc-7', 'prd-dove-deo', 'loc-war', 'HAZMAT_CAP', 'Low', 'Dove Aerosol • Caged Bay Cap', 'Aerosol bay utilization at 89% in Warrington DC', 8.2, 'UN1950 capacity limit', 'Redirect next factory inbound to Milton Keynes'],
      ['exc-8', 'prd-comf-lav', 'loc-mk', 'FROST_ALERT', 'Low', 'Comfort Lavender • Cold Snap Protocol', 'Overnight dock temp warning <5°C forecast', 7.6, 'Met Office Midlands alert', 'Enable thermal dock curtains for morning loads'],
      ['exc-9', 'prd-persil-pods', 'loc-leeds', 'PROMO_UPLIFT', 'Medium', 'Persil Capsules • Regional Spike', 'Northern Grocery orders +18% WoW', 4.1, 'Trailing 14-day orders', 'Review W47 Leeds allocation'],
      ['exc-10', 'prd-hell-sqz', 'loc-war', 'PROMO_UPLIFT', 'Medium', "Hellmann's Light • ASDA Rollback Prep", 'Pre-build required ahead of 16 Nov start', 5.8, 'ASDA Rollback forecast', 'Stage 1,200 cases at Warrington Dock B'],
      ['exc-11', 'prd-simp-fw', 'loc-dub', 'DATA_GAP', 'Low', 'Simple Facial Wash • Dublin History Gap', 'Insufficient EPOS history (<12 wks) for Dublin Hub', 13.1, 'Order-only run rate', 'Use GB proxy seasonality until W50'],
      ['exc-12', 'prd-dove-bw', 'loc-leeds', 'DAMAGED_STOCK', 'Low', 'Dove Body Wash • Transit Damage', '35 damaged cases awaiting write-off approval', 5.0, 'Warehouse inspection', 'Finance analyst write-off sign-off'],
      ['exc-13', 'prd-persil-24w', 'loc-mk', 'INBOUND_DELAY', 'Medium', 'Persil 24-wash • Port Sunlight Inbound', '640 in-transit cases delayed 6h on M6', 5.0, 'Carrier telemetry', 'Monitor arrival at MK NDC Gate 3'],
      ['exc-14', 'prd-comf-lav', 'loc-mk', 'SAFETY_BREACH', 'Medium', 'Comfort Lavender • Co-op Promo Buffer', 'Available cover below 7-day target if Co-op promo approved', 5.2, 'Promo scenario demand', 'Hold approval pending MK inbound'],
      ['exc-15', 'prd-hell-400', 'loc-leeds', 'QA_QUARANTINE', 'Medium', "Hellmann's 400g • Glass Tray Hold", '80 cases held for outer carton crush inspection', 1.8, 'Goods-in QC', 'Repack into SRP trays'],
      ['exc-16', 'prd-dove-deo', 'loc-war', 'LEAD_TIME_DRIFT', 'Low', 'Dove Aerosol • Supplier Lead Time', 'Canister vendor lead time shifted 4d -> 6d', 8.2, 'PO delivery history', 'Update safety stock parameter'],
      ['exc-17', 'prd-persil-pods', 'loc-leeds', 'PACK_CONVERSION', 'Low', 'Persil Capsules • Pallet Config Check', 'Verify 60 cases/pallet layer pattern for Sainsbury', 4.1, 'EDI ASN validation', 'Confirm ti-hi profile in WMS'],
      ['exc-18', 'prd-simp-fw', 'loc-mk', 'SAFETY_BREACH', 'Low', 'Simple Facial Wash • Online Channel Surge', 'Online fulfillment demand +14% WoW', 6.4, 'Direct-to-retail e-comm orders', 'Rebalance 300 cases from Dublin buffer'],
    ];
    for (const e of extraExceptions) {
      insertExc.run(e[0], e[1], e[2], e[3], e[4], e[5], e[6], e[7], e[8], e[9], null, 0, now);
    }

    // 12. Reconciled Channel & Brand Period Summaries (Nov 2026, Oct 2026, Q4 2026)
    // Total Nov 2026 (UK & Ireland) = £42.8m (4,280,000,000 pence)
    // Order Fill Rate Nov 2026 = 194,800 / 200,000 = 97.4%
    // On-Time Delivery Nov 2026 = 151 / 156 = 96.79% (~96.8%)
    const insertSummary = db.prepare(`
      INSERT INTO channel_period_summaries (
        id, reporting_period, market, channel, brand_id, net_sales_pence,
        cogs_pence, freight_pence, promo_accrual_pence, ordered_cases, filled_cases,
        total_deliveries, on_time_deliveries
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const novMix: Array<[string, string, string, number, number, number, number, number]> = [
      // [brandId, channel, market, netSales£m*100M, orderedCases, filledCases, totalDeliv, onTimeDeliv]
      ['brd-dove', 'Grocery', 'Great Britain', 510000000, 24000, 23520, 20, 20],
      ['brd-dove', 'Convenience', 'Great Britain', 270000000, 12000, 11880, 10, 10],
      ['brd-dove', 'Online', 'UK & Ireland', 260000000, 11500, 11385, 8, 8],
      ['brd-dove', 'Wholesale', 'Ireland', 220000000, 10000, 9870, 6, 6],

      ['brd-persil', 'Grocery', 'Great Britain', 520000000, 29000, 27165, 22, 21],
      ['brd-persil', 'Convenience', 'Great Britain', 210000000, 11000, 10780, 8, 8],
      ['brd-persil', 'Online', 'UK & Ireland', 150000000, 8000, 7840, 6, 6],
      ['brd-persil', 'Wholesale', 'Great Britain', 260000000, 14000, 13720, 8, 7],

      ['brd-hellmanns', 'Grocery', 'Great Britain', 340000000, 17000, 16660, 14, 14],
      ['brd-hellmanns', 'Convenience', 'Great Britain', 160000000, 8000, 7840, 6, 6],
      ['brd-hellmanns', 'Online', 'UK & Ireland', 100000000, 5000, 4900, 4, 4],
      ['brd-hellmanns', 'Wholesale', 'Great Britain', 180000000, 9000, 8820, 6, 5],

      ['brd-comfort', 'Grocery', 'Great Britain', 250000000, 14000, 13580, 12, 11],
      ['brd-comfort', 'Convenience', 'Great Britain', 120000000, 6500, 6305, 5, 5],
      ['brd-comfort', 'Online', 'UK & Ireland', 110000000, 6000, 5820, 4, 4],
      ['brd-comfort', 'Wholesale', 'Ireland', 150000000, 8000, 7760, 5, 5],

      ['brd-simple', 'Grocery', 'Great Britain', 170000000, 9000, 8820, 6, 6],
      ['brd-simple', 'Convenience', 'Great Britain', 100000000, 5000, 4900, 4, 4],
      ['brd-simple', 'Online', 'Ireland', 90000000, 4500, 4410, 4, 4],
      ['brd-simple', 'Wholesale', 'Great Britain', 110000000, 5500, 5390, 4, 4],
    ];
    // Verify sum of orderedCases: 57500+62000+39000+34500+24000 = 217,000? Let's scale filledCases precisely so sum(filled)/sum(ordered) = 97.4%!
    // Let's check:
    // Ordered sum = 24+12+11.5+10 + 29+11+8+14 + 17+8+5+9 + 14+6.5+6+8 + 9+5+4.5+5.5 = 217,000
    // Filled sum = 23520+11880+11385+9870 + 27665+10780+7840+13720 + 16660+7840+4900+8820 + 13580+6305+5820+7760 + 8820+4900+4410+5390 = 211,365 -> 211365 / 217000 = 0.97403 -> 97.4%!
    // Total deliveries = 44 + 44 + 30 + 26 + 18 = 162; on_time = 44 + 42 + 29 + 25 + 18 = 158 -> 158/162 = 97.5%... Let's adjust to 151/156 = 96.79% (96.8%)!
    // Let's tweak 6 rows so totalDeliveries = 156, onTime = 151:
    for (let i = 0; i < novMix.length; i++) {
      const [brandId, channel, market, net, ord, fil, deliv, ontime] = novMix[i];
      const adjDeliv = i === 0 ? 18 : i === 4 ? 19 : i === 8 ? 13 : deliv;
      const adjOntime = i === 0 ? 17 : i === 4 ? 17 : i === 8 ? 12 : ontime;
      // Wait: diff deliv = -2 -3 -1 = -6 -> 162 - 6 = 156!
      // diff ontime = -3 -4 -2 = -9? Let's compute exact: original ontime = 158, if we reduce by 7 => 151: -3 (i=0: 20->17), -4 (i=4: 21->17), -0 (i=8: 14->12 is -2, total -9 => 149). So let's keep i=8 ontime=13 (-1) and i=0 ontime=18 (-2) and i=4 ontime=17 (-4): -2-4-1 = -7 => 158-7 = 151! 151/156 = 96.7948% -> 96.8%!
      const finalDeliv = i === 0 ? 18 : i === 4 ? 19 : i === 8 ? 13 : deliv;
      const finalOntime = i === 0 ? 18 : i === 4 ? 17 : i === 8 ? 13 : ontime;
      const cogs = Math.round(net * 0.56);
      const freight = Math.round(net * 0.052);
      const accrual = Math.round(net * 0.085);
      insertSummary.run(
        `sum-nov-${i}`, '2026-11', market, channel, brandId, net,
        cogs, freight, accrual, ord, fil, finalDeliv, finalOntime
      );

      // Prior month (Oct 2026): £40.3m total (scaled by 40.3/42.8)
      const octNet = Math.round(net * (4030 / 4280));
      insertSummary.run(
        `sum-oct-${i}`, '2026-10', market, channel, brandId, octNet,
        Math.round(octNet * 0.565), Math.round(octNet * 0.053), Math.round(octNet * 0.078),
        Math.round(ord * 0.94), Math.round(fil * 0.93), finalDeliv, Math.max(1, finalOntime - (i % 3 === 0 ? 1 : 0))
      );
    }

    // 13. Invoices, Payments & Balanced Double-Entry Subledger
    const insertInv = db.prepare(`
      INSERT INTO invoices (
        id, invoice_number, order_id, account_id, reporting_period, currency, tax_code, tax_rate_pct,
        gross_pence, discount_pence, net_pence, tax_pence, total_pence, paid_pence, status, issued_at, due_date
      ) VALUES (?, ?, ?, ?, '2026-11', 'GBP', 'VAT_UK_STD_20', 20.0, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    insertInv.run('inv-24079', 'INV-2026-8841', 'ord-24079', 'acc-coop', 3319672, 79672, 3240000, 648000, 3888000, 3888000, 'Paid', '2026-11-11T11:00:00Z', '2026-12-11');

    const insertPay = db.prepare(`
      INSERT INTO payments (id, payment_ref, invoice_id, account_id, amount_pence, currency, method, received_at, reconciliation_state)
      VALUES (?, ?, ?, ?, ?, 'GBP', ?, ?, 'Reconciled')
    `);
    insertPay.run('pay-24079', 'BACS-COO-99102', 'inv-24079', 'acc-coop', 3888000, 'UK BACS Faster Payment', '2026-11-12T14:30:00Z');

    const insertLedger = db.prepare(`
      INSERT INTO ledger_entries (
        id, journal_ref, entry_date, account_code, account_name, debit_pence, credit_pence,
        currency, reference_type, reference_id, description
      ) VALUES (?, ?, ?, ?, ?, ?, ?, 'GBP', ?, ?, ?)
    `);
    // Journal 1: Invoice INV-2026-8841 (Debits = 3,888,000; Credits = 3,240,000 + 648,000 = 3,888,000)
    insertLedger.run('ldg-1', 'JRN-8841', '2026-11-11', '1100', 'Trade Accounts Receivable', 3888000, 0, 'INVOICE', 'inv-24079', 'Co-op Convenience invoice INV-2026-8841');
    insertLedger.run('ldg-2', 'JRN-8841', '2026-11-11', '4000', 'Recognised Net Sales Revenue', 0, 3240000, 'INVOICE', 'inv-24079', 'Recognised revenue on delivered cases');
    insertLedger.run('ldg-3', 'JRN-8841', '2026-11-11', '2200', 'Output VAT Control (20%)', 0, 648000, 'INVOICE', 'inv-24079', 'UK Standard VAT output liability');
    // Journal 2: Cash Receipt BACS-COO-99102 (Debits = 3,888,000; Credits = 3,888,000)
    insertLedger.run('ldg-4', 'JRN-8842', '2026-11-12', '1010', 'HSBC UK Clearing Cash', 3888000, 0, 'PAYMENT', 'pay-24079', 'Cash receipt BACS-COO-99102');
    insertLedger.run('ldg-5', 'JRN-8842', '2026-11-12', '1100', 'Trade Accounts Receivable', 0, 3888000, 'PAYMENT', 'pay-24079', 'AR settlement for INV-2026-8841');
    // Journal 3: Trade Promotion Accrual (Debits = 1,850,000; Credits = 1,850,000)
    insertLedger.run('ldg-6', 'JRN-8843', '2026-11-10', '4200', 'Trade Promotion Spend (Gross-to-Net)', 1850000, 0, 'PROMO', 'prm-morr-persil', 'Morrisons Big Wash November promo accrual');
    insertLedger.run('ldg-7', 'JRN-8843', '2026-11-10', '2150', 'Accrued Customer Rebates & Promo Liability', 0, 1850000, 'PROMO', 'prm-morr-persil', 'Accrued promo liability for Morrisons');

    // 14. Notifications & Initial Audit Log
    const insertNotif = db.prepare(`
      INSERT INTO notifications (id, title, message, severity, target_section, target_id, is_read, created_at)
      VALUES (?, ?, ?, ?, ?, ?, 0, ?)
    `);
    insertNotif.run('not-1', 'Persil 24-wash Shortage • UL-24084', 'Morrisons order UL-24084 (2,880 cases) exceeds Leeds DC ATP (1,420 cases). Review allocation or MK transfer.', 'High', 'orders', 'ord-24084', now);
    insertNotif.run('not-2', 'Dove Body Wash Promo Uplift +28%', 'Tesco Clubcard week tracking +28% above baseline forecast.', 'Medium', 'promotions', 'prm-tesco-dove', now);
    insertNotif.run('not-3', "Hellmann's 400g Reorder Window", 'Leeds DC cover down to 1.8 days; replenishment PO recommended within 24h.', 'High', 'inventory', 'prd-hell-400', now);

    db.prepare(`
      INSERT INTO audit_logs (id, actor_role, actor_name, action, entity_type, entity_id, details_json, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run('aud-seed-1', 'administrator', 'System Bootstrap', 'SEED_SYNTHETIC_DATASET', 'SYSTEM', 'hub-uk-ireland', JSON.stringify({ period: '2026-11', netSalesGbp: 42800000 }), now);
  });
}
