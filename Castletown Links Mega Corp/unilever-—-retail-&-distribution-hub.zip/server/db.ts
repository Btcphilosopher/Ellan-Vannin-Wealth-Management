import { DatabaseSync } from 'node:sqlite';
import fs from 'node:fs';
import path from 'node:path';

let dbInstance: DatabaseSync | null = null;

export function getDb(customPath?: string): DatabaseSync {
  if (dbInstance && !customPath) return dbInstance;
  const dbPath = customPath || process.env.DATABASE_PATH || path.resolve(process.cwd(), 'data/hub.db');
  if (dbPath !== ':memory:') {
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  }
  const db = new DatabaseSync(dbPath);
  db.exec('PRAGMA foreign_keys = ON;');
  db.exec('PRAGMA journal_mode = WAL;');
  db.exec('PRAGMA busy_timeout = 5000;');
  runMigrations(db);
  if (!customPath) dbInstance = db;
  return db;
}

export function resetDbInstance() {
  if (dbInstance) {
    try {
      dbInstance.close();
    } catch {
      // ignore
    }
    dbInstance = null;
  }
}

export function withTransaction<T>(db: DatabaseSync, fn: () => T): T {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (err) {
    try {
      db.exec('ROLLBACK');
    } catch {
      // ignore rollback failure
    }
    throw err;
  }
}

export function runMigrations(db: DatabaseSync) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS migrations (
      id TEXT PRIMARY KEY,
      applied_at TEXT NOT NULL
    );
  `);

  const applied = new Set(
    (db.prepare('SELECT id FROM migrations').all() as Array<{ id: string }>).map((r) => r.id)
  );

  const migrations: Array<{ id: string; sql: string }> = [
    {
      id: '001_initial_core_schema',
      sql: `
        CREATE TABLE IF NOT EXISTS brands (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL UNIQUE,
          category TEXT NOT NULL,
          logo_url TEXT NOT NULL,
          accent_color TEXT NOT NULL,
          plan_target_pence INTEGER NOT NULL,
          availability_pct REAL NOT NULL,
          active INTEGER NOT NULL DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS products (
          id TEXT PRIMARY KEY,
          sku TEXT NOT NULL UNIQUE,
          gtin TEXT NOT NULL,
          brand_id TEXT NOT NULL REFERENCES brands(id),
          name TEXT NOT NULL,
          variant TEXT NOT NULL,
          pack_size TEXT NOT NULL,
          category TEXT NOT NULL CHECK (category IN ('Home Care', 'Personal Care', 'Food & Nutrition')),
          markets_json TEXT NOT NULL,
          image_url TEXT NOT NULL,
          dimensions_cm TEXT NOT NULL,
          weight_kg REAL NOT NULL,
          batch_tracked INTEGER NOT NULL DEFAULT 1,
          shelf_life_days INTEGER NOT NULL,
          allergens_json TEXT NOT NULL DEFAULT '[]',
          storage_requirements TEXT NOT NULL,
          handling_notes TEXT NOT NULL,
          unit_cost_pence INTEGER NOT NULL,
          list_price_case_pence INTEGER NOT NULL,
          tax_code TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active', 'Discontinued', 'Draft')),
          version INTEGER NOT NULL DEFAULT 1,
          updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS packaging_conversions (
          id TEXT PRIMARY KEY,
          product_id TEXT NOT NULL REFERENCES products(id),
          version_num INTEGER NOT NULL,
          units_per_case INTEGER NOT NULL CHECK (units_per_case > 0),
          cases_per_pallet INTEGER NOT NULL CHECK (cases_per_pallet > 0),
          effective_from TEXT NOT NULL,
          effective_to TEXT,
          is_current INTEGER NOT NULL DEFAULT 1,
          UNIQUE(product_id, version_num)
        );

        CREATE TABLE IF NOT EXISTS locations (
          id TEXT PRIMARY KEY,
          code TEXT NOT NULL UNIQUE,
          name TEXT NOT NULL,
          type TEXT NOT NULL CHECK (type IN ('DC', 'NDC', 'Hub')),
          market TEXT NOT NULL,
          city TEXT NOT NULL,
          capacity_pallets INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS retail_accounts (
          id TEXT PRIMARY KEY,
          name TEXT NOT NULL UNIQUE,
          legal_entity TEXT NOT NULL,
          channel TEXT NOT NULL CHECK (channel IN ('Grocery', 'Convenience', 'Online', 'Wholesale')),
          market TEXT NOT NULL,
          logo_url TEXT NOT NULL,
          account_manager TEXT NOT NULL,
          commercial_contact TEXT NOT NULL,
          contact_email TEXT NOT NULL,
          ordering_entity TEXT NOT NULL,
          invoice_recipient TEXT NOT NULL,
          payment_terms_days INTEGER NOT NULL,
          rebate_rate_pct REAL NOT NULL,
          otif_target_pct REAL NOT NULL,
          fill_target_pct REAL NOT NULL,
          credit_limit_pence INTEGER NOT NULL,
          version INTEGER NOT NULL DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS delivery_locations (
          id TEXT PRIMARY KEY,
          account_id TEXT NOT NULL REFERENCES retail_accounts(id),
          code TEXT NOT NULL,
          name TEXT NOT NULL,
          address TEXT NOT NULL,
          postcode TEXT NOT NULL,
          booking_window TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS account_price_lists (
          id TEXT PRIMARY KEY,
          account_id TEXT NOT NULL REFERENCES retail_accounts(id),
          product_id TEXT NOT NULL REFERENCES products(id),
          agreed_case_price_pence INTEGER NOT NULL,
          off_invoice_discount_pct REAL NOT NULL DEFAULT 0,
          currency TEXT NOT NULL DEFAULT 'GBP',
          effective_from TEXT NOT NULL,
          effective_to TEXT NOT NULL,
          is_listed INTEGER NOT NULL DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS inventory_batches (
          id TEXT PRIMARY KEY,
          product_id TEXT NOT NULL REFERENCES products(id),
          location_id TEXT NOT NULL REFERENCES locations(id),
          batch_number TEXT NOT NULL,
          manufactured_at TEXT NOT NULL,
          expiry_date TEXT NOT NULL,
          status TEXT NOT NULL CHECK (status IN ('AVAILABLE', 'QUARANTINED', 'DAMAGED', 'EXPIRED', 'IN_TRANSIT')),
          on_hand_cases INTEGER NOT NULL DEFAULT 0 CHECK (on_hand_cases >= 0),
          reserved_cases INTEGER NOT NULL DEFAULT 0 CHECK (reserved_cases >= 0),
          quarantined_cases INTEGER NOT NULL DEFAULT 0 CHECK (quarantined_cases >= 0),
          damaged_cases INTEGER NOT NULL DEFAULT 0 CHECK (damaged_cases >= 0),
          expired_cases INTEGER NOT NULL DEFAULT 0 CHECK (expired_cases >= 0),
          in_transit_cases INTEGER NOT NULL DEFAULT 0 CHECK (in_transit_cases >= 0),
          version INTEGER NOT NULL DEFAULT 1,
          UNIQUE(product_id, location_id, batch_number)
        );

        CREATE TABLE IF NOT EXISTS orders (
          id TEXT PRIMARY KEY,
          order_ref TEXT NOT NULL UNIQUE,
          account_id TEXT NOT NULL REFERENCES retail_accounts(id),
          delivery_location_id TEXT NOT NULL REFERENCES delivery_locations(id),
          source_location_id TEXT NOT NULL REFERENCES locations(id),
          market TEXT NOT NULL,
          channel TEXT NOT NULL,
          reporting_period TEXT NOT NULL,
          order_date TEXT NOT NULL,
          requested_delivery_date TEXT NOT NULL,
          status TEXT NOT NULL,
          operational_flag TEXT NOT NULL DEFAULT 'Normal',
          shipment_state TEXT NOT NULL DEFAULT 'Pending',
          invoice_state TEXT NOT NULL DEFAULT 'Not Invoiced',
          payment_state TEXT NOT NULL DEFAULT 'Unpaid',
          currency TEXT NOT NULL DEFAULT 'GBP',
          total_cases INTEGER NOT NULL DEFAULT 0,
          allocated_cases INTEGER NOT NULL DEFAULT 0,
          delivered_cases INTEGER NOT NULL DEFAULT 0,
          net_amount_pence INTEGER NOT NULL DEFAULT 0,
          edi_message_id TEXT UNIQUE,
          is_featured_overview INTEGER NOT NULL DEFAULT 0,
          notes TEXT,
          version INTEGER NOT NULL DEFAULT 1,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS order_lines (
          id TEXT PRIMARY KEY,
          order_id TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
          product_id TEXT NOT NULL REFERENCES products(id),
          conversion_id TEXT NOT NULL REFERENCES packaging_conversions(id),
          units_per_case_snapshot INTEGER NOT NULL,
          cases_per_pallet_snapshot INTEGER NOT NULL,
          ordered_cases INTEGER NOT NULL CHECK (ordered_cases > 0),
          allocated_cases INTEGER NOT NULL DEFAULT 0,
          picked_cases INTEGER NOT NULL DEFAULT 0,
          dispatched_cases INTEGER NOT NULL DEFAULT 0,
          delivered_cases INTEGER NOT NULL DEFAULT 0,
          agreed_case_price_pence INTEGER NOT NULL,
          discount_pct REAL NOT NULL DEFAULT 0,
          promo_id TEXT,
          line_net_pence INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS stock_reservations (
          id TEXT PRIMARY KEY,
          order_id TEXT NOT NULL REFERENCES orders(id),
          order_line_id TEXT NOT NULL REFERENCES order_lines(id),
          batch_id TEXT NOT NULL REFERENCES inventory_batches(id),
          cases_reserved INTEGER NOT NULL CHECK (cases_reserved > 0),
          status TEXT NOT NULL CHECK (status IN ('ACTIVE', 'PICKED', 'RELEASED', 'CANCELLED')),
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS inventory_movements (
          id TEXT PRIMARY KEY,
          product_id TEXT NOT NULL REFERENCES products(id),
          batch_id TEXT REFERENCES inventory_batches(id),
          location_id TEXT NOT NULL REFERENCES locations(id),
          movement_type TEXT NOT NULL,
          cases_delta INTEGER NOT NULL,
          reference_type TEXT NOT NULL,
          reference_id TEXT NOT NULL,
          actor_role TEXT NOT NULL,
          notes TEXT,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS shipments (
          id TEXT PRIMARY KEY,
          shipment_ref TEXT NOT NULL UNIQUE,
          order_id TEXT NOT NULL REFERENCES orders(id),
          origin_location_id TEXT NOT NULL REFERENCES locations(id),
          destination_id TEXT NOT NULL REFERENCES delivery_locations(id),
          carrier_name TEXT NOT NULL,
          vehicle_reg TEXT NOT NULL,
          vehicle_capacity_pallets INTEGER NOT NULL,
          loaded_pallets INTEGER NOT NULL,
          delivery_window TEXT NOT NULL,
          status TEXT NOT NULL CHECK (status IN ('Planned', 'Loading', 'Dispatched', 'In Transit', 'Partial POD', 'Delivered', 'Rejected')),
          tracking_feed_status TEXT NOT NULL DEFAULT 'Simulated',
          estimated_arrival TEXT NOT NULL,
          confirmed_delivery_at TEXT,
          dispatched_cases INTEGER NOT NULL DEFAULT 0,
          delivered_cases INTEGER NOT NULL DEFAULT 0,
          shortage_cases INTEGER NOT NULL DEFAULT 0,
          damaged_cases INTEGER NOT NULL DEFAULT 0,
          rejected_cases INTEGER NOT NULL DEFAULT 0,
          on_time INTEGER,
          pod_notes TEXT,
          version INTEGER NOT NULL DEFAULT 1
        );

        CREATE TABLE IF NOT EXISTS promotions (
          id TEXT PRIMARY KEY,
          code TEXT NOT NULL UNIQUE,
          title TEXT NOT NULL,
          account_id TEXT NOT NULL REFERENCES retail_accounts(id),
          brand_id TEXT NOT NULL REFERENCES brands(id),
          product_id TEXT NOT NULL REFERENCES products(id),
          start_date TEXT NOT NULL,
          end_date TEXT NOT NULL,
          mechanic TEXT NOT NULL,
          discount_pct REAL NOT NULL,
          precedence_rank INTEGER NOT NULL,
          baseline_weekly_cases INTEGER NOT NULL,
          expected_uplift_pct REAL NOT NULL,
          measured_uplift_pct REAL,
          funding_budget_pence INTEGER NOT NULL,
          actual_cost_pence INTEGER NOT NULL DEFAULT 0,
          proposed_volume_cases INTEGER NOT NULL,
          actual_volume_cases INTEGER NOT NULL DEFAULT 0,
          approval_state TEXT NOT NULL CHECK (approval_state IN ('Draft', 'Pending Approval', 'Approved', 'Active', 'Completed')),
          baseline_method TEXT NOT NULL,
          ai_generated INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS forecasts (
          id TEXT PRIMARY KEY,
          product_id TEXT NOT NULL REFERENCES products(id),
          location_id TEXT NOT NULL REFERENCES locations(id),
          period_week TEXT NOT NULL,
          version_label TEXT NOT NULL,
          invoiced_sales_cases INTEGER NOT NULL,
          customer_orders_cases INTEGER NOT NULL,
          consumer_epos_cases INTEGER NOT NULL,
          baseline_cases INTEGER NOT NULL,
          promo_uplift_cases INTEGER NOT NULL,
          manual_override_cases INTEGER,
          override_reason TEXT,
          p10_cases INTEGER NOT NULL,
          p50_cases INTEGER NOT NULL,
          p90_cases INTEGER NOT NULL,
          backtest_wape REAL,
          backtest_bias REAL,
          data_sufficiency TEXT NOT NULL DEFAULT 'Sufficient',
          safety_stock_days INTEGER NOT NULL DEFAULT 7,
          lead_time_days INTEGER NOT NULL DEFAULT 4
        );

        CREATE TABLE IF NOT EXISTS supply_exceptions (
          id TEXT PRIMARY KEY,
          product_id TEXT NOT NULL REFERENCES products(id),
          location_id TEXT NOT NULL REFERENCES locations(id),
          exception_type TEXT NOT NULL,
          severity TEXT NOT NULL CHECK (severity IN ('High', 'Medium', 'Low')),
          title TEXT NOT NULL,
          subtitle TEXT NOT NULL,
          days_cover REAL,
          demand_basis TEXT NOT NULL,
          recommended_action TEXT NOT NULL,
          related_order_id TEXT REFERENCES orders(id),
          status TEXT NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN', 'IN_REVIEW', 'RESOLVED')),
          is_featured INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS invoices (
          id TEXT PRIMARY KEY,
          invoice_number TEXT NOT NULL UNIQUE,
          order_id TEXT NOT NULL REFERENCES orders(id),
          account_id TEXT NOT NULL REFERENCES retail_accounts(id),
          reporting_period TEXT NOT NULL,
          currency TEXT NOT NULL DEFAULT 'GBP',
          tax_code TEXT NOT NULL DEFAULT 'VAT_UK_STD_20',
          tax_rate_pct REAL NOT NULL DEFAULT 20.0,
          gross_pence INTEGER NOT NULL,
          discount_pence INTEGER NOT NULL,
          net_pence INTEGER NOT NULL,
          tax_pence INTEGER NOT NULL,
          total_pence INTEGER NOT NULL,
          paid_pence INTEGER NOT NULL DEFAULT 0,
          status TEXT NOT NULL CHECK (status IN ('Draft', 'Issued', 'Partially Paid', 'Paid', 'Credited')),
          issued_at TEXT NOT NULL,
          due_date TEXT NOT NULL,
          erp_sync_status TEXT NOT NULL DEFAULT 'Simulated Synced'
        );

        CREATE TABLE IF NOT EXISTS payments (
          id TEXT PRIMARY KEY,
          payment_ref TEXT NOT NULL UNIQUE,
          invoice_id TEXT NOT NULL REFERENCES invoices(id),
          account_id TEXT NOT NULL REFERENCES retail_accounts(id),
          amount_pence INTEGER NOT NULL CHECK (amount_pence > 0),
          currency TEXT NOT NULL DEFAULT 'GBP',
          method TEXT NOT NULL,
          received_at TEXT NOT NULL,
          reconciliation_state TEXT NOT NULL DEFAULT 'Reconciled'
        );

        CREATE TABLE IF NOT EXISTS ledger_entries (
          id TEXT PRIMARY KEY,
          journal_ref TEXT NOT NULL,
          entry_date TEXT NOT NULL,
          account_code TEXT NOT NULL,
          account_name TEXT NOT NULL,
          debit_pence INTEGER NOT NULL DEFAULT 0,
          credit_pence INTEGER NOT NULL DEFAULT 0,
          currency TEXT NOT NULL DEFAULT 'GBP',
          reference_type TEXT NOT NULL,
          reference_id TEXT NOT NULL,
          description TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS channel_period_summaries (
          id TEXT PRIMARY KEY,
          reporting_period TEXT NOT NULL,
          market TEXT NOT NULL,
          channel TEXT NOT NULL,
          brand_id TEXT NOT NULL REFERENCES brands(id),
          net_sales_pence INTEGER NOT NULL,
          cogs_pence INTEGER NOT NULL,
          freight_pence INTEGER NOT NULL,
          promo_accrual_pence INTEGER NOT NULL,
          ordered_cases INTEGER NOT NULL,
          filled_cases INTEGER NOT NULL,
          total_deliveries INTEGER NOT NULL,
          on_time_deliveries INTEGER NOT NULL
        );

        CREATE TABLE IF NOT EXISTS ai_proposals (
          id TEXT PRIMARY KEY,
          prompt TEXT NOT NULL,
          model_version TEXT NOT NULL,
          mode TEXT NOT NULL,
          requested_by_role TEXT NOT NULL,
          summary TEXT NOT NULL,
          source_refs_json TEXT NOT NULL,
          proposed_action_type TEXT,
          proposed_payload_json TEXT,
          status TEXT NOT NULL CHECK (status IN ('READ_ONLY', 'PENDING_APPROVAL', 'APPROVED', 'REJECTED', 'EXECUTED')),
          reviewed_by TEXT,
          execution_outcome TEXT,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS audit_logs (
          id TEXT PRIMARY KEY,
          actor_role TEXT NOT NULL,
          actor_name TEXT NOT NULL,
          action TEXT NOT NULL,
          entity_type TEXT NOT NULL,
          entity_id TEXT NOT NULL,
          details_json TEXT NOT NULL,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS notifications (
          id TEXT PRIMARY KEY,
          title TEXT NOT NULL,
          message TEXT NOT NULL,
          severity TEXT NOT NULL,
          target_section TEXT NOT NULL,
          target_id TEXT,
          is_read INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS edi_inbox (
          message_id TEXT PRIMARY KEY,
          sender_gln TEXT NOT NULL,
          message_type TEXT NOT NULL,
          payload_json TEXT NOT NULL,
          order_id TEXT,
          status TEXT NOT NULL,
          received_at TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_orders_period_market ON orders(reporting_period, market);
        CREATE INDEX IF NOT EXISTS idx_batches_sku_loc ON inventory_batches(product_id, location_id, expiry_date);
        CREATE INDEX IF NOT EXISTS idx_movements_product ON inventory_movements(product_id, created_at);
        CREATE INDEX IF NOT EXISTS idx_ledger_journal ON ledger_entries(journal_ref);
        CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);
      `,
    },
  ];

  for (const m of migrations) {
    if (!applied.has(m.id)) {
      withTransaction(db, () => {
        db.exec(m.sql);
        db.prepare('INSERT INTO migrations (id, applied_at) VALUES (?, ?)').run(m.id, new Date().toISOString());
      });
    }
  }
}
