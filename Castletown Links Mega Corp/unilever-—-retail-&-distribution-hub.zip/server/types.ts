export type RoleId =
  | 'commercial_director'
  | 'account_manager'
  | 'demand_planner'
  | 'warehouse_operator'
  | 'distribution_coordinator'
  | 'finance_analyst'
  | 'administrator'
  | 'read_only_reviewer';

export type Permission =
  | 'orders:create'
  | 'orders:allocate'
  | 'orders:approve_exception'
  | 'inventory:adjust'
  | 'inventory:pick'
  | 'inventory:recall'
  | 'distribution:dispatch'
  | 'distribution:pod'
  | 'promotions:manage'
  | 'promotions:approve'
  | 'forecasts:override'
  | 'finance:invoice'
  | 'finance:payment'
  | 'finance:ledger'
  | 'products:edit'
  | 'accounts:edit'
  | 'ai:propose'
  | 'ai:approve'
  | 'admin:manage'
  | 'reports:export';

export interface RoleDefinition {
  id: RoleId;
  name: string;
  userDisplayName: string;
  userInitials: string;
  marketScope: string[];
  description: string;
  permissions: Permission[];
}

export type OrderStatus =
  | 'Draft'
  | 'Submitted'
  | 'Validated'
  | 'Allocated'
  | 'Picking'
  | 'Dispatched'
  | 'Delivered'
  | 'Closed'
  | 'Cancelled';

export type ChannelType = 'Grocery' | 'Convenience' | 'Online' | 'Wholesale';
export type MarketScope = 'UK & Ireland' | 'Great Britain' | 'Ireland';
export type ReportingPeriod = '2026-11' | '2026-10' | '2026-Q4';
