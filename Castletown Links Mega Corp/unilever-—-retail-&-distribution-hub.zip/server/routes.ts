import { Router } from 'express';
import crypto from 'node:crypto';
import type { DatabaseSync } from 'node:sqlite';
import { getRoleFromRequest, requirePermission, ROLES } from './rbac.ts';
import { seedDatabase } from './seed.ts';
import {
  allocateOrder,
  allocatePaymentToInvoice,
  convertQuantity,
  dispatchOrderShipment,
  evaluatePromotionPrecedence,
  getBatchAtp,
  getOverviewData,
  issueInvoiceForOrder,
  logAudit,
  pickOrder,
  processEdiOrderMessage,
  recordShipmentPod,
  runWalkForwardBacktest,
  traceBatchWithdrawal,
  transferStock,
} from './services/domainService.ts';
import { approveAndExecuteProposal, runCopilotQuery } from './services/copilotService.ts';
import type { MarketScope, ReportingPeriod } from './types.ts';

function uid(prefix: string): string {
  return `${prefix}-${crypto.randomBytes(4).toString('hex')}`;
}

export function createApiRouter(db: DatabaseSync): Router {
  const router = Router();

  // Health & Roles
  router.get('/health', (_req, res) => {
    res.json({ status: 'ok', database: 'sqlite-wal', timestamp: new Date().toISOString() });
  });

  router.get('/roles', (req, res) => {
    const active = getRoleFromRequest(req);
    res.json({ activeRole: active, roles: Object.values(ROLES) });
  });

  // Global Search across products, accounts, orders, shipments
  router.get('/search', (req, res) => {
    const q = String(req.query.q || '').trim().toLowerCase();
    if (!q) return res.json({ products: [], accounts: [], orders: [], shipments: [] });
    const like = `%${q}%`;
    const products = db
      .prepare(`SELECT id, sku, name, category, brand_id as brandId FROM products WHERE LOWER(name) LIKE ? OR LOWER(sku) LIKE ? OR LOWER(gtin) LIKE ? LIMIT 5`)
      .all(like, like, like);
    const accounts = db
      .prepare(`SELECT id, name, channel, market FROM retail_accounts WHERE LOWER(name) LIKE ? OR LOWER(legal_entity) LIKE ? LIMIT 5`)
      .all(like, like);
    const orders = db
      .prepare(`SELECT o.id, o.order_ref as orderRef, o.status, o.operational_flag as operationalFlag, a.name as accountName FROM orders o JOIN retail_accounts a ON a.id = o.account_id WHERE LOWER(o.order_ref) LIKE ? OR LOWER(a.name) LIKE ? LIMIT 5`)
      .all(like, like);
    const shipments = db
      .prepare(`SELECT id, shipment_ref as shipmentRef, carrier_name as carrierName, status FROM shipments WHERE LOWER(shipment_ref) LIKE ? OR LOWER(carrier_name) LIKE ? LIMIT 5`)
      .all(like, like);
    res.json({ products, accounts, orders, shipments });
  });

  // Notifications
  router.get('/notifications', (_req, res) => {
    const rows = db.prepare('SELECT * FROM notifications ORDER BY created_at DESC LIMIT 20').all();
    res.json({ notifications: rows });
  });
  router.post('/notifications/:id/read', (req, res) => {
    db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ?').run(req.params.id);
    res.json({ ok: true });
  });

  // Overview Dashboard (Reconciled)
  router.get('/overview', (req, res) => {
    const market = (req.query.market as MarketScope) || 'UK & Ireland';
    const period = (req.query.period as ReportingPeriod) || '2026-11';
    const data = getOverviewData(db, market, period);
    res.json(data);
  });

  // Channel drill-down transactions
  router.get('/channels/:channel/transactions', (req, res) => {
    const channel = req.params.channel;
    const period = (req.query.period as string) || '2026-11';
    const summaries = db
      .prepare(
        `SELECT s.*, b.name as brand_name FROM channel_period_summaries s JOIN brands b ON b.id = s.brand_id WHERE s.channel = ? AND s.reporting_period = ?`
      )
      .all(channel, period === '2026-Q4' ? '2026-11' : period);
    const orders = db
      .prepare(
        `SELECT o.id, o.order_ref, o.total_cases, o.net_amount_pence, o.status, o.operational_flag, o.order_date, a.name as account_name
         FROM orders o JOIN retail_accounts a ON a.id = o.account_id WHERE o.channel = ? ORDER BY o.order_date DESC`
      )
      .all(channel);
    res.json({ channel, period, summaries, orders });
  });

  // Brands & Products Master Data
  router.get('/brands', (_req, res) => {
    const brands = db.prepare('SELECT * FROM brands ORDER BY plan_target_pence DESC').all();
    const products = db
      .prepare(
        `SELECT p.*, b.name as brand_name,
          (SELECT SUM(ib.on_hand_cases - ib.reserved_cases) FROM inventory_batches ib WHERE ib.product_id = p.id AND ib.status = 'AVAILABLE' AND ib.expiry_date > '2026-11-13') as total_atp_cases
         FROM products p JOIN brands b ON b.id = p.brand_id ORDER BY p.sku ASC`
      )
      .all();
    const conversions = db.prepare('SELECT * FROM packaging_conversions ORDER BY product_id, version_num DESC').all();
    res.json({ brands, products, conversions });
  });

  router.get('/products/:id', (req, res) => {
    const product = db
      .prepare('SELECT p.*, b.name as brand_name FROM products p JOIN brands b ON b.id = p.brand_id WHERE p.id = ?')
      .get(req.params.id);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    const conversions = db.prepare('SELECT * FROM packaging_conversions WHERE product_id = ? ORDER BY version_num DESC').all(req.params.id);
    const batches = db
      .prepare('SELECT ib.*, l.name as location_name, l.code as location_code FROM inventory_batches ib JOIN locations l ON l.id = ib.location_id WHERE ib.product_id = ? ORDER BY ib.expiry_date ASC')
      .all(req.params.id);
    const orders = db
      .prepare('SELECT o.id, o.order_ref, o.status, o.operational_flag, o.requested_delivery_date, ol.ordered_cases, ol.allocated_cases, ol.delivered_cases, ol.units_per_case_snapshot, a.name as account_name FROM order_lines ol JOIN orders o ON o.id = ol.order_id JOIN retail_accounts a ON a.id = o.account_id WHERE ol.product_id = ?')
      .all(req.params.id);
    const promotions = db.prepare('SELECT p.*, a.name as account_name FROM promotions p JOIN retail_accounts a ON a.id = p.account_id WHERE p.product_id = ?').all(req.params.id);
    const forecasts = db.prepare('SELECT f.*, l.name as location_name FROM forecasts f JOIN locations l ON l.id = f.location_id WHERE f.product_id = ?').all(req.params.id);
    res.json({ product, conversions, batches, orders, promotions, forecasts });
  });

  router.post('/products/:id/convert', (req, res) => {
    try {
      const { qty, fromUnit, toUnit, conversionId } = req.body;
      const result = convertQuantity(db, req.params.id, Number(qty), fromUnit, toUnit, conversionId);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  router.post('/products/:id/status', requirePermission('products:edit'), (req, res) => {
    const role = getRoleFromRequest(req);
    const { status, expectedVersion } = req.body;
    const upd = db
      .prepare(`UPDATE products SET status = ?, version = version + 1, updated_at = ? WHERE id = ? AND version = ?`)
      .run(status, new Date().toISOString(), req.params.id, expectedVersion ?? 1);
    if (upd.changes !== 1) return res.status(409).json({ error: 'Optimistic concurrency conflict — refresh product record' });
    logAudit(db, role.id, role.userDisplayName, 'UPDATE_PRODUCT_STATUS', 'PRODUCT', req.params.id, { status });
    res.json({ ok: true, status });
  });

  router.post('/products/:id/conversions', requirePermission('products:edit'), (req, res) => {
    const role = getRoleFromRequest(req);
    const { unitsPerCase, casesPerPallet } = req.body;
    const current = db
      .prepare('SELECT MAX(version_num) as maxVer FROM packaging_conversions WHERE product_id = ?')
      .get(req.params.id) as { maxVer: number | null };
    const nextVer = (current?.maxVer ?? 0) + 1;
    const today = new Date().toISOString().slice(0, 10);
    db.prepare('UPDATE packaging_conversions SET is_current = 0, effective_to = ? WHERE product_id = ? AND is_current = 1').run(today, req.params.id);
    const id = uid('cnv');
    db.prepare(
      'INSERT INTO packaging_conversions (id, product_id, version_num, units_per_case, cases_per_pallet, effective_from, effective_to, is_current) VALUES (?, ?, ?, ?, ?, ?, NULL, 1)'
    ).run(id, req.params.id, nextVer, Number(unitsPerCase), Number(casesPerPallet), today);
    logAudit(db, role.id, role.userDisplayName, 'NEW_PACKAGING_CONVERSION', 'PRODUCT', req.params.id, { version: nextVer, unitsPerCase, casesPerPallet });
    res.json({ id, versionNum: nextVer });
  });

  // Retail Accounts & Commercial Agreements
  router.get('/accounts', (_req, res) => {
    const accounts = db.prepare('SELECT * FROM retail_accounts ORDER BY name ASC').all();
    const deliveryLocations = db.prepare('SELECT * FROM delivery_locations').all();
    const priceLists = db
      .prepare('SELECT pl.*, p.sku, p.name as product_name, p.list_price_case_pence FROM account_price_lists pl JOIN products p ON p.id = pl.product_id')
      .all();
    const recentOrders = db
      .prepare('SELECT id, order_ref, account_id, total_cases, net_amount_pence, status, operational_flag, order_date FROM orders ORDER BY order_date DESC')
      .all();
    res.json({ accounts, deliveryLocations, priceLists, recentOrders });
  });

  // Orders Workbench + EDI + Lifecycle Actions
  router.get('/orders', (req, res) => {
    const statusFilter = req.query.status ? String(req.query.status) : '';
    const page = Math.max(1, Number(req.query.page || 1));
    const pageSize = Math.min(50, Math.max(5, Number(req.query.pageSize || 20)));
    const offset = (page - 1) * pageSize;

    const where = statusFilter ? 'WHERE o.status = ?' : '';
    const params = statusFilter ? [statusFilter] : [];

    const orders = db
      .prepare(
        `SELECT o.*, a.name as account_name, a.logo_url as account_logo_url, a.ordering_entity, a.invoice_recipient,
          dl.name as delivery_location_name, dl.postcode, l.name as source_location_name
         FROM orders o
         JOIN retail_accounts a ON a.id = o.account_id
         JOIN delivery_locations dl ON dl.id = o.delivery_location_id
         JOIN locations l ON l.id = o.source_location_id
         ${where}
         ORDER BY o.is_featured_overview DESC, o.order_ref DESC
         LIMIT ? OFFSET ?`
      )
      .all(...params, pageSize, offset);

    const lines = db
      .prepare(
        `SELECT ol.*, p.sku, p.name as product_name, p.image_url, pc.version_num as conversion_version
         FROM order_lines ol
         JOIN products p ON p.id = ol.product_id
         JOIN packaging_conversions pc ON pc.id = ol.conversion_id`
      )
      .all();

    const ediInbox = db.prepare('SELECT * FROM edi_inbox ORDER BY received_at DESC LIMIT 15').all();
    const locations = db.prepare('SELECT * FROM locations').all();
    res.json({ orders, lines, ediInbox, locations, page, pageSize });
  });

  router.post('/orders', requirePermission('orders:create'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const { accountId, deliveryLocationId, sourceLocationId, productId, orderedCases, requestedDeliveryDate } = req.body;
      const result = processEdiOrderMessage(
        db,
        {
          messageId: `MANUAL-${Date.now()}`,
          senderGln: 'INTERNAL-PORTAL',
          accountId,
          deliveryLocationId,
          sourceLocationId,
          productId,
          orderedCases: Number(orderedCases),
          requestedDeliveryDate: requestedDeliveryDate || 'Thu 19 Nov 2026',
        },
        role.id,
        role.userDisplayName
      );
      res.status(201).json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  router.post('/orders/:id/allocate', requirePermission('orders:allocate'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const allowPartial = Boolean(req.body?.allowPartial);
      const result = allocateOrder(db, req.params.id, { allowPartial, actorRole: role.id, actorName: role.userDisplayName });
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  router.post('/orders/:id/pick', requirePermission('inventory:pick'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const result = pickOrder(db, req.params.id, role.id, role.userDisplayName);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  router.post('/orders/:id/dispatch', requirePermission('distribution:dispatch'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const { carrierName, vehicleReg } = req.body || {};
      const result = dispatchOrderShipment(db, {
        orderId: req.params.id,
        carrierName: carrierName || 'DHL Supply Chain UK',
        vehicleReg: vehicleReg || 'UK26 ULV',
        actorRole: role.id,
        actorName: role.userDisplayName,
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  router.post('/orders/:id/cancel', requirePermission('orders:approve_exception'), (req, res) => {
    const role = getRoleFromRequest(req);
    const order = db.prepare('SELECT id, order_ref, status FROM orders WHERE id = ?').get(req.params.id) as
      | { id: string; order_ref: string; status: string }
      | undefined;
    if (!order) return res.status(404).json({ error: 'Order not found' });
    if (['Dispatched', 'Delivered', 'Closed'].includes(order.status)) {
      return res.status(400).json({ error: 'Cannot cancel dispatched/delivered order' });
    }
    const resRows = db.prepare(`SELECT * FROM stock_reservations WHERE order_id = ? AND status = 'ACTIVE'`).all(order.id) as Array<{
      id: string;
      batch_id: string;
      cases_reserved: number;
    }>;
    for (const r of resRows) {
      db.prepare('UPDATE inventory_batches SET reserved_cases = MAX(0, reserved_cases - ?) WHERE id = ?').run(r.cases_reserved, r.batch_id);
      db.prepare(`UPDATE stock_reservations SET status = 'CANCELLED' WHERE id = ?`).run(r.id);
    }
    db.prepare(`UPDATE orders SET status = 'Cancelled', operational_flag = 'Cancelled', updated_at = ? WHERE id = ?`).run(
      new Date().toISOString(),
      order.id
    );
    logAudit(db, role.id, role.userDisplayName, 'CANCEL_ORDER', 'ORDER', order.order_ref, {});
    res.json({ ok: true, status: 'Cancelled' });
  });

  router.post('/edi/inbound', requirePermission('orders:create'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const result = processEdiOrderMessage(db, req.body, role.id, role.userDisplayName);
      res.status(result.duplicate ? 200 : 201).json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Inventory, Batches, Transfers, Adjustments, Traceability & Recall
  router.get('/inventory', (_req, res) => {
    const batches = db
      .prepare(
        `SELECT ib.*,
          (CASE WHEN ib.status = 'AVAILABLE' AND ib.expiry_date > '2026-11-13' THEN MAX(0, ib.on_hand_cases - ib.reserved_cases) ELSE 0 END) as available_cases,
          p.sku, p.name as product_name, p.brand_id, b.name as brand_name, l.name as location_name, l.code as location_code
         FROM inventory_batches ib
         JOIN products p ON p.id = ib.product_id
         JOIN brands b ON b.id = p.brand_id
         JOIN locations l ON l.id = ib.location_id
         ORDER BY ib.expiry_date ASC`
      )
      .all();
    const movements = db
      .prepare(
        `SELECT m.*, p.sku, p.name as product_name, l.name as location_name
         FROM inventory_movements m
         JOIN products p ON p.id = m.product_id
         JOIN locations l ON l.id = m.location_id
         ORDER BY m.created_at DESC LIMIT 40`
      )
      .all();
    const exceptions = db
      .prepare(
        `SELECT e.*, p.sku, p.name as product_name, l.name as location_name
         FROM supply_exceptions e
         JOIN products p ON p.id = e.product_id
         JOIN locations l ON l.id = e.location_id
         ORDER BY e.is_featured DESC, CASE e.severity WHEN 'High' THEN 0 WHEN 'Medium' THEN 1 ELSE 2 END`
      )
      .all();
    const locations = db.prepare('SELECT * FROM locations').all();
    const products = db.prepare('SELECT id, sku, name FROM products').all();
    res.json({ batches, movements, exceptions, locations, products });
  });

  router.post('/inventory/transfer', requirePermission('inventory:adjust'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const { productId, fromLocationId, toLocationId, cases, resolveExceptionId } = req.body;
      const result = transferStock(db, {
        productId,
        fromLocationId,
        toLocationId,
        cases: Number(cases),
        actorRole: role.id,
        actorName: role.userDisplayName,
      });
      if (resolveExceptionId) {
        db.prepare(`UPDATE supply_exceptions SET status = 'RESOLVED' WHERE id = ?`).run(resolveExceptionId);
      }
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  router.post('/inventory/adjust', requirePermission('inventory:adjust'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const { batchId, adjustmentType, cases, reason } = req.body;
      const batch = db.prepare('SELECT * FROM inventory_batches WHERE id = ?').get(batchId) as
        | { id: string; product_id: string; location_id: string; batch_number: string; on_hand_cases: number; reserved_cases: number; version: number }
        | undefined;
      if (!batch) return res.status(404).json({ error: 'Batch not found' });
      const qty = Number(cases);
      if (!Number.isFinite(qty) || qty <= 0) return res.status(400).json({ error: 'Quantity must be positive' });

      if (adjustmentType === 'GOODS_RECEIPT') {
        db.prepare(`UPDATE inventory_batches SET on_hand_cases = on_hand_cases + ?, version = version + 1 WHERE id = ?`).run(qty, batch.id);
      } else if (adjustmentType === 'QUARANTINE') {
        if (batch.on_hand_cases - batch.reserved_cases < qty) {
          return res.status(400).json({ error: 'Cannot quarantine reserved or unavailable stock' });
        }
        db.prepare(
          `UPDATE inventory_batches SET on_hand_cases = on_hand_cases - ?, quarantined_cases = quarantined_cases + ?, version = version + 1 WHERE id = ?`
        ).run(qty, qty, batch.id);
      } else if (adjustmentType === 'RELEASE_QUARANTINE') {
        db.prepare(
          `UPDATE inventory_batches SET quarantined_cases = MAX(0, quarantined_cases - ?), on_hand_cases = on_hand_cases + ?, status = 'AVAILABLE', version = version + 1 WHERE id = ?`
        ).run(qty, qty, batch.id);
      }

      db.prepare(
        `INSERT INTO inventory_movements (id, product_id, batch_id, location_id, movement_type, cases_delta, reference_type, reference_id, actor_role, notes, created_at)
         VALUES (?, ?, ?, ?, ?, ?, 'ADJUSTMENT', ?, ?, ?, ?)`
      ).run(uid('mov'), batch.product_id, batch.id, batch.location_id, adjustmentType, adjustmentType === 'QUARANTINE' ? -qty : qty, batch.batch_number, role.id, reason || adjustmentType, new Date().toISOString());

      logAudit(db, role.id, role.userDisplayName, 'INVENTORY_ADJUSTMENT', 'BATCH', batch.batch_number, { adjustmentType, qty, reason });
      res.json({ ok: true });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  router.get('/inventory/batches/:id/trace', (req, res) => {
    try {
      res.json(traceBatchWithdrawal(db, req.params.id));
    } catch (err) {
      res.status(404).json({ error: (err as Error).message });
    }
  });

  router.post('/inventory/batches/:id/recall', requirePermission('inventory:recall'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const trace = traceBatchWithdrawal(db, req.params.id);
      db.prepare(`UPDATE inventory_batches SET status = 'QUARANTINED', quarantined_cases = quarantined_cases + on_hand_cases, on_hand_cases = 0 WHERE id = ?`).run(req.params.id);
      logAudit(db, role.id, role.userDisplayName, 'SIMULATED_PRODUCT_WITHDRAWAL', 'BATCH', req.params.id, {
        affectedOrders: (trace.affectedReservations as Array<unknown>).length,
      });
      res.json({ ...trace, withdrawalStatus: 'SIMULATED_HOLD_EXECUTED' });
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Distribution & Shipments
  router.get('/distribution', (_req, res) => {
    const shipments = db
      .prepare(
        `SELECT s.*, o.order_ref, o.total_cases as ordered_cases, a.name as account_name, a.logo_url as account_logo_url,
          orig.name as origin_name, dest.name as destination_name, dest.postcode
         FROM shipments s
         JOIN orders o ON o.id = s.order_id
         JOIN retail_accounts a ON a.id = o.account_id
         JOIN locations orig ON orig.id = s.origin_location_id
         JOIN delivery_locations dest ON dest.id = s.destination_id
         ORDER BY CASE s.status WHEN 'In Transit' THEN 0 WHEN 'Loading' THEN 1 WHEN 'Planned' THEN 2 ELSE 3 END, s.shipment_ref DESC`
      )
      .all();
    const overview = getOverviewData(db, 'UK & Ireland', '2026-11');
    res.json({
      shipments,
      serviceMetrics: {
        orderFillRatePct: overview.kpis.orderFillRatePct,
        fillNumerator: overview.kpis.fillRateNumeratorCases,
        fillDenominator: overview.kpis.fillRateDenominatorCases,
        onTimeDeliveryPct: overview.kpis.onTimeDeliveryPct,
        otdNumerator: overview.kpis.otdNumeratorDeliveries,
        otdDenominator: overview.kpis.otdDenominatorDeliveries,
        period: 'Nov 2026 (2026-11)',
      },
    });
  });

  router.post('/shipments/:id/pod', requirePermission('distribution:pod'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const { deliveredCases, damagedCases, rejectedCases, onTime, podNotes } = req.body;
      const result = recordShipmentPod(db, {
        shipmentId: req.params.id,
        deliveredCases: Number(deliveredCases),
        damagedCases: Number(damagedCases || 0),
        rejectedCases: Number(rejectedCases || 0),
        onTime: onTime !== false,
        podNotes,
        actorRole: role.id,
        actorName: role.userDisplayName,
      });
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Pricing & Promotions
  router.get('/promotions', (_req, res) => {
    const promotions = db
      .prepare(
        `SELECT pr.*, a.name as account_name, b.name as brand_name, p.sku, p.name as product_name, p.unit_cost_pence, p.list_price_case_pence
         FROM promotions pr
         JOIN retail_accounts a ON a.id = pr.account_id
         JOIN brands b ON b.id = pr.brand_id
         JOIN products p ON p.id = pr.product_id
         ORDER BY pr.precedence_rank ASC, pr.start_date ASC`
      )
      .all();
    res.json({ promotions });
  });

  router.post('/promotions/:id/approve', requirePermission('promotions:approve'), (req, res) => {
    const role = getRoleFromRequest(req);
    const { decision } = req.body;
    const newState = decision === 'REJECT' ? 'Draft' : 'Approved';
    db.prepare('UPDATE promotions SET approval_state = ? WHERE id = ?').run(newState, req.params.id);
    logAudit(db, role.id, role.userDisplayName, 'PROMOTION_APPROVAL', 'PROMOTION', req.params.id, { newState });
    res.json({ ok: true, approvalState: newState });
  });

  router.post('/promotions/precedence', (req, res) => {
    const { accountId, productId } = req.body;
    res.json(evaluatePromotionPrecedence(db, accountId, productId));
  });

  // Demand Planning & Forecasts
  router.get('/forecasts', (_req, res) => {
    const forecasts = db
      .prepare(
        `SELECT f.*, p.sku, p.name as product_name, l.name as location_name, l.code as location_code
         FROM forecasts f
         JOIN products p ON p.id = f.product_id
         JOIN locations l ON l.id = f.location_id
         ORDER BY f.period_week ASC, p.sku ASC`
      )
      .all();
    // Leak-free walk-forward backtest on synthetic 10-week Persil history
    const persilBacktest = runWalkForwardBacktest([1790, 1840, 1910, 1880, 1950, 2020, 1980, 2110, 2490, 2613], 3);
    res.json({ forecasts, backtestSample: persilBacktest });
  });

  router.post('/forecasts/:id/override', requirePermission('forecasts:override'), (req, res) => {
    const role = getRoleFromRequest(req);
    const { overrideCases, reason } = req.body;
    if (!reason || String(reason).trim().length < 5) {
      return res.status(400).json({ error: 'Manual forecast override requires an explicit business reason (min 5 chars).' });
    }
    const qty = Number(overrideCases);
    if (!Number.isFinite(qty) || qty < 0) return res.status(400).json({ error: 'Invalid override quantity' });
    db.prepare('UPDATE forecasts SET manual_override_cases = ?, override_reason = ?, p50_cases = ? WHERE id = ?').run(
      qty,
      String(reason).trim(),
      qty,
      req.params.id
    );
    logAudit(db, role.id, role.userDisplayName, 'FORECAST_OVERRIDE', 'FORECAST', req.params.id, { overrideCases: qty, reason });
    res.json({ ok: true, overrideCases: qty });
  });

  // Finance, Invoices, Payments & Balanced Subledger
  router.get('/finance', (_req, res) => {
    const invoices = db
      .prepare(
        `SELECT i.*, o.order_ref, o.delivered_cases, o.total_cases, a.name as account_name
         FROM invoices i
         JOIN orders o ON o.id = i.order_id
         JOIN retail_accounts a ON a.id = i.account_id
         ORDER BY i.issued_at DESC`
      )
      .all();
    const payments = db
      .prepare(
        `SELECT p.*, i.invoice_number, a.name as account_name
         FROM payments p
         JOIN invoices i ON i.id = p.invoice_id
         JOIN retail_accounts a ON a.id = p.account_id
         ORDER BY p.received_at DESC`
      )
      .all();
    const ledger = db.prepare('SELECT * FROM ledger_entries ORDER BY entry_date DESC, journal_ref DESC').all() as Array<{
      debit_pence: number;
      credit_pence: number;
    }>;
    const totalDebitsPence = ledger.reduce((s, l) => s + l.debit_pence, 0);
    const totalCreditsPence = ledger.reduce((s, l) => s + l.credit_pence, 0);
    const channelEconomics = db
      .prepare(
        `SELECT channel, SUM(net_sales_pence) as net_sales_pence, SUM(cogs_pence) as cogs_pence,
          SUM(freight_pence) as freight_pence, SUM(promo_accrual_pence) as promo_accrual_pence
         FROM channel_period_summaries WHERE reporting_period = '2026-11' GROUP BY channel`
      )
      .all();
    res.json({
      invoices,
      payments,
      ledger,
      ledgerBalanced: totalDebitsPence === totalCreditsPence,
      totalDebitsPence,
      totalCreditsPence,
      channelEconomics,
    });
  });

  router.post('/orders/:id/invoice', requirePermission('finance:invoice'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const invoice = issueInvoiceForOrder(db, { orderId: req.params.id, actorRole: role.id, actorName: role.userDisplayName });
      res.status(201).json(invoice);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  router.post('/invoices/:id/payments', requirePermission('finance:payment'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const { amountPence, method } = req.body;
      const payment = allocatePaymentToInvoice(db, {
        invoiceId: req.params.id,
        amountPence: Number(amountPence),
        method,
        actorRole: role.id,
        actorName: role.userDisplayName,
      });
      res.status(201).json(payment);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Operations Copilot (Gemini 4 Hydrogen + Mock Fallback + Human Approval)
  router.get('/copilot/proposals', (_req, res) => {
    const proposals = db.prepare('SELECT * FROM ai_proposals ORDER BY created_at DESC LIMIT 20').all();
    res.json({ proposals });
  });

  router.post('/copilot/query', requirePermission('ai:propose'), async (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const { prompt, untrustedAttachmentText, period } = req.body;
      if (!prompt || String(prompt).trim().length < 3) {
        return res.status(400).json({ error: 'Prompt is required' });
      }
      const result = await runCopilotQuery(db, {
        prompt: String(prompt),
        untrustedAttachmentText,
        role,
        period,
      });
      res.json(result);
    } catch (err) {
      res.status(500).json({ error: (err as Error).message });
    }
  });

  router.post('/copilot/proposals/:id/review', requirePermission('ai:approve'), (req, res) => {
    try {
      const role = getRoleFromRequest(req);
      const { decision } = req.body;
      const result = approveAndExecuteProposal(db, req.params.id, decision === 'REJECT' ? 'REJECT' : 'APPROVE', role);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: (err as Error).message });
    }
  });

  // Reports, Audit Logs, Reset & API Docs
  router.get('/audit-logs', (_req, res) => {
    const logs = db.prepare('SELECT * FROM audit_logs ORDER BY created_at DESC LIMIT 100').all();
    res.json({ logs });
  });

  router.post('/admin/reset-demo', requirePermission('admin:manage'), (req, res) => {
    const role = getRoleFromRequest(req);
    seedDatabase(db, true);
    logAudit(db, role.id, role.userDisplayName, 'RESET_DEMO_DATASET', 'SYSTEM', 'hub-uk-ireland', {});
    res.json({ ok: true, message: 'Synthetic UK & Ireland dataset reset to baseline state.' });
  });

  router.get('/docs', (_req, res) => {
    res.json({
      openapi: '3.1.0',
      info: { title: 'UNILEVER Retail & Distribution Hub API', version: '1.0.0' },
      endpoints: [
        { method: 'GET', path: '/api/overview', desc: 'Reconciled KPIs, Brand performance, Channel mix, Orders, Exceptions & Planning summary' },
        { method: 'GET', path: '/api/brands', desc: 'Brand & SKU master catalog with versioned packaging conversions' },
        { method: 'POST', path: '/api/products/:id/convert', desc: 'Unit <-> Case <-> Pallet packaging conversion calculator' },
        { method: 'GET', path: '/api/accounts', desc: 'Retail accounts, delivery locations, agreed price lists & rebates' },
        { method: 'POST', path: '/api/orders/:id/allocate', desc: 'Atomic FEFO batch reservation excluding expired/quarantined lots' },
        { method: 'POST', path: '/api/edi/inbound', desc: 'Idempotent simulated EDI ORDERS ingestion' },
        { method: 'POST', path: '/api/inventory/transfer', desc: 'Inter-DC stock transfer & exception resolution' },
        { method: 'POST', path: '/api/inventory/batches/:id/recall', desc: 'Batch traceability & simulated product withdrawal' },
        { method: 'POST', path: '/api/shipments/:id/pod', desc: 'Proof of Delivery with shortages, damage & OTD evaluation' },
        { method: 'POST', path: '/api/orders/:id/invoice', desc: 'Delivered-quantity invoicing & balanced double-entry subledger posting' },
        { method: 'POST', path: '/api/invoices/:id/payments', desc: 'Simulated BACS payment allocation & AR clearing' },
        { method: 'POST', path: '/api/copilot/query', desc: 'Operations Copilot (Gemini 4 Hydrogen / Mock fallback) with approval workflow' },
      ],
    });
  });

  return router;
}
