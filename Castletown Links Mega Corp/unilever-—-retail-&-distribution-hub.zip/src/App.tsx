import { useCallback, useEffect, useState } from 'react';
import { AlertCircle, CheckCircle2, Info, X } from 'lucide-react';
import { apiFetch, setApiRole } from './api';
import { AccountsPage } from './components/AccountsPage';
import { AdminPage } from './components/AdminPage';
import { BrandsPage } from './components/BrandsPage';
import { CopilotDrawer } from './components/CopilotDrawer';
import { DistributionPage } from './components/DistributionPage';
import { FinancePage } from './components/FinancePage';
import { ForecastsPage } from './components/ForecastsPage';
import { InventoryPage } from './components/InventoryPage';
import { Layout } from './components/Layout';
import { OrdersPage } from './components/OrdersPage';
import { OverviewPage } from './components/OverviewPage';
import { PromotionsPage } from './components/PromotionsPage';
import { ReportsPage } from './components/ReportsPage';
import type { MarketScope, OverviewResponse, ReportingPeriod, RoleDefinition, RoleId, SectionId, ToastMessage } from './types';

export default function App() {
  const [activeSection, setActiveSection] = useState<SectionId>('overview');
  const [focusId, setFocusId] = useState<string | undefined>(undefined);
  const [market, setMarket] = useState<MarketScope>('UK & Ireland');
  const [period, setPeriod] = useState<ReportingPeriod>('2026-11');
  const [roles, setRoles] = useState<RoleDefinition[]>([]);
  const [activeRole, setActiveRole] = useState<RoleDefinition>({
    id: 'administrator',
    name: 'Administrator',
    userDisplayName: 'Tom Hayes (UL)',
    userInitials: 'UL',
    marketScope: ['UK & Ireland', 'Great Britain', 'Ireland'],
    description: 'Full operational & administrative permissions.',
    permissions: [],
  });
  const [overviewData, setOverviewData] = useState<OverviewResponse | null>(null);
  const [loadingOverview, setLoadingOverview] = useState(true);
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [refreshTick, setRefreshTick] = useState(0);

  const notify = useCallback((type: ToastMessage['type'], title: string, detail?: string) => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, type, title, detail }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 5200);
  }, []);

  const loadOverview = useCallback(async () => {
    setLoadingOverview(true);
    try {
      const res = await apiFetch<OverviewResponse>(
        `/api/overview?market=${encodeURIComponent(market)}&period=${encodeURIComponent(period)}`
      );
      setOverviewData(res);
    } catch (err) {
      notify('error', 'Failed to refresh overview data', (err as Error).message);
    } finally {
      setLoadingOverview(false);
    }
  }, [market, period, notify]);

  useEffect(() => {
    apiFetch<{ activeRole: RoleDefinition; roles: RoleDefinition[] }>('/api/roles')
      .then((res) => {
        setRoles(res.roles);
        setActiveRole(res.activeRole);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    loadOverview();
  }, [loadOverview, refreshTick]);

  const handleNavigate = (section: SectionId, targetFocusId?: string) => {
    setActiveSection(section);
    setFocusId(targetFocusId);
  };

  const handleRoleChange = (roleId: RoleId) => {
    setApiRole(roleId);
    const found = roles.find((r) => r.id === roleId);
    if (found) {
      setActiveRole(found);
      notify('info', `Switched Role: ${found.name}`, `${found.userDisplayName} • ${found.permissions.length} permissions active`);
    }
  };

  const refreshAll = () => {
    setRefreshTick((t) => t + 1);
  };

  return (
    <>
      <Layout
        activeSection={activeSection}
        onNavigate={handleNavigate}
        market={market}
        onMarketChange={setMarket}
        period={period}
        onPeriodChange={setPeriod}
        roles={roles}
        activeRole={activeRole}
        onRoleChange={handleRoleChange}
        onRefresh={refreshAll}
        lastRefreshedAt={overviewData?.lastRefreshedAt || new Date().toISOString()}
        onOpenCopilot={() => setCopilotOpen(true)}
      >
        {activeSection === 'overview' && (
          <OverviewPage data={overviewData} loading={loadingOverview} onNavigate={handleNavigate} />
        )}
        {activeSection === 'brands' && (
          <BrandsPage focusId={focusId} onNotify={notify} onRefreshAll={refreshAll} />
        )}
        {activeSection === 'accounts' && <AccountsPage focusId={focusId} />}
        {activeSection === 'orders' && (
          <OrdersPage focusId={focusId} onNotify={notify} onRefreshAll={refreshAll} onNavigate={handleNavigate} />
        )}
        {activeSection === 'inventory' && (
          <InventoryPage focusId={focusId} onNotify={notify} onRefreshAll={refreshAll} />
        )}
        {activeSection === 'distribution' && (
          <DistributionPage focusId={focusId} onNotify={notify} onRefreshAll={refreshAll} />
        )}
        {activeSection === 'promotions' && (
          <PromotionsPage onNotify={notify} onRefreshAll={refreshAll} />
        )}
        {activeSection === 'forecasts' && (
          <ForecastsPage onNotify={notify} onRefreshAll={refreshAll} />
        )}
        {activeSection === 'finance' && (
          <FinancePage focusId={focusId} onNotify={notify} onRefreshAll={refreshAll} />
        )}
        {activeSection === 'reports' && <ReportsPage overview={overviewData} onNotify={notify} />}
        {activeSection === 'admin' && (
          <AdminPage roles={roles} activeRole={activeRole} onNotify={notify} onRefreshAll={refreshAll} />
        )}
      </Layout>

      <CopilotDrawer
        open={copilotOpen}
        onClose={() => setCopilotOpen(false)}
        period={period}
        activeRole={activeRole}
        onNavigate={handleNavigate}
        onNotify={notify}
        onRefreshAll={refreshAll}
      />

      {/* Toast Stack */}
      <div className="fixed bottom-4 right-4 z-[60] space-y-2 max-w-sm w-full pointer-events-none">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`pointer-events-auto rounded-xl border p-3.5 shadow-lg bg-white flex items-start gap-2.5 text-[13px] ${
              t.type === 'error'
                ? 'border-red-200'
                : t.type === 'success'
                  ? 'border-emerald-200'
                  : 'border-[#C6DCFA]'
            }`}
          >
            {t.type === 'error' ? (
              <AlertCircle className="w-4.5 h-4.5 text-[#DC2626] shrink-0 mt-0.5" />
            ) : t.type === 'success' ? (
              <CheckCircle2 className="w-4.5 h-4.5 text-[#16A34A] shrink-0 mt-0.5" />
            ) : (
              <Info className="w-4.5 h-4.5 text-[#0066FF] shrink-0 mt-0.5" />
            )}
            <div className="flex-1 min-w-0">
              <div className="font-bold text-[#0F2147]">{t.title}</div>
              {t.detail && <div className="text-[12px] text-[#5A759E] mt-0.5">{t.detail}</div>}
            </div>
            <button
              type="button"
              onClick={() => setToasts((prev) => prev.filter((x) => x.id !== t.id))}
              className="text-[#5A759E] hover:text-[#0F2147] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ))}
      </div>
    </>
  );
}
