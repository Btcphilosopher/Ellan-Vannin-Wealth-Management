export type SectionId =
  | 'overview'
  | 'brands'
  | 'accounts'
  | 'orders'
  | 'inventory'
  | 'distribution'
  | 'promotions'
  | 'forecasts'
  | 'finance'
  | 'reports'
  | 'admin';

export type MarketScope = 'UK & Ireland' | 'Great Britain' | 'Ireland';
export type ReportingPeriod = '2026-11' | '2026-10' | '2026-Q4';

export type RoleId =
  | 'commercial_director'
  | 'account_manager'
  | 'demand_planner'
  | 'warehouse_operator'
  | 'distribution_coordinator'
  | 'finance_analyst'
  | 'administrator'
  | 'read_only_reviewer';

export interface RoleDefinition {
  id: RoleId;
  name: string;
  userDisplayName: string;
  userInitials: string;
  marketScope: string[];
  description: string;
  permissions: string[];
}

export interface OverviewResponse {
  market: MarketScope;
  period: ReportingPeriod;
  lastRefreshedAt: string;
  kpis: {
    netSalesPence: number;
    vsPriorMonthPct: number;
    orderFillRatePct: number;
    fillRateNumeratorCases: number;
    fillRateDenominatorCases: number;
    onTimeDeliveryPct: number;
    otdNumeratorDeliveries: number;
    otdDenominatorDeliveries: number;
    stockAlertsCount: number;
  };
  brandPerformance: Array<{
    brandId: string;
    brandName: string;
    logoUrl: string;
    netSalesPence: number;
    vsPlanPct: number;
    availabilityPct: number;
  }>;
  salesByChannel: Array<{
    channel: string;
    netSalesPence: number;
    cogsPence: number;
    freightPence: number;
    promoAccrualPence: number;
  }>;
  featuredOrders: Array<{
    id: string;
    orderRef: string;
    totalCases: number;
    allocatedCases: number;
    deliveredCases: number;
    deliveryDate: string;
    status: string;
    operationalFlag: string;
    shipmentState: string;
    invoiceState: string;
    paymentState: string;
    netAmountPence: number;
    accountId: string;
    accountName: string;
    accountLogoUrl: string;
    channel: string;
  }>;
  featuredExceptions: Array<{
    id: string;
    productId: string;
    locationId: string;
    exceptionType: string;
    severity: string;
    title: string;
    subtitle: string;
    daysCover: number;
    demandBasis: string;
    recommendedAction: string;
    relatedOrderId: string | null;
    status: string;
  }>;
  planningSummary: {
    demandPlanningPct: number;
    promotionalUpliftPct: number;
    warehouseAvailabilityPct: number;
    warehouseDeltaPp: number;
  };
}

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info';
  title: string;
  detail?: string;
}
