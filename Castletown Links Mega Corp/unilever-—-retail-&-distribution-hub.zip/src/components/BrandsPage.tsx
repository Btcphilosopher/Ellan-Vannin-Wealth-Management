import React, { useEffect, useState } from 'react';
import { ArrowRightLeft, Box, CheckCircle2, Info, Package, ShieldAlert, X } from 'lucide-react';
import { apiFetch, formatGbp } from '../api';

interface BrandsPageProps {
  focusId?: string;
  onNotify: (type: 'success' | 'error' | 'info', title: string, detail?: string) => void;
  onRefreshAll: () => void;
}

export const BrandsPage: React.FC<BrandsPageProps> = ({ focusId, onNotify, onRefreshAll }) => {
  const [brands, setBrands] = useState<Array<{ id: string; name: string; category: string; logo_url: string; availability_pct: number; plan_target_pence: number }>>([]);
  const [products, setProducts] = useState<
    Array<{
      id: string;
      sku: string;
      gtin: string;
      brand_id: string;
      brand_name: string;
      name: string;
      variant: string;
      pack_size: string;
      category: string;
      markets_json: string;
      image_url: string;
      dimensions_cm: string;
      weight_kg: number;
      shelf_life_days: number;
      allergens_json: string;
      storage_requirements: string;
      handling_notes: string;
      unit_cost_pence: number;
      list_price_case_pence: number;
      tax_code: string;
      status: string;
      version: number;
      total_atp_cases: number;
    }>
  >([]);
  const [conversions, setConversions] = useState<
    Array<{ id: string; product_id: string; version_num: number; units_per_case: number; cases_per_pallet: number; effective_from: string; effective_to: string | null; is_current: number }>
  >([]);
  const [selectedBrand, setSelectedBrand] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [detailData, setDetailData] = useState<{
    product: (typeof products)[0];
    conversions: typeof conversions;
    batches: Array<{ id: string; batch_number: string; location_name: string; expiry_date: string; status: string; on_hand_cases: number; reserved_cases: number }>;
    orders: Array<{ order_ref: string; account_name: string; ordered_cases: number; delivered_cases: number; units_per_case_snapshot: number; status: string }>;
    promotions: Array<{ code: string; title: string; account_name: string; expected_uplift_pct: number; approval_state: string }>;
  } | null>(null);
  const [convQty, setConvQty] = useState('10');
  const [convFrom, setConvFrom] = useState<'unit' | 'case' | 'pallet'>('pallet');
  const [convTo, setConvTo] = useState<'unit' | 'case' | 'pallet'>('unit');
  const [convResult, setConvResult] = useState<{ convertedQty: number; versionNum: number; unitsPerCase: number; casesPerPallet: number } | null>(null);
  const [newUnitsPerCase, setNewUnitsPerCase] = useState('10');
  const [newCasesPerPallet, setNewCasesPerPallet] = useState('72');

  const loadData = async () => {
    const res = await apiFetch<{ brands: typeof brands; products: typeof products; conversions: typeof conversions }>('/api/brands');
    setBrands(res.brands);
    setProducts(res.products);
    setConversions(res.conversions);
  };

  useEffect(() => {
    loadData().catch(() => {});
  }, []);

  useEffect(() => {
    if (!focusId || products.length === 0) return;
    if (focusId.startsWith('brd-')) {
      setSelectedBrand(focusId);
    } else if (focusId.startsWith('prd-')) {
      openDetail(focusId);
    }
  }, [focusId, products.length]);

  const openDetail = async (productId: string) => {
    try {
      const res = await apiFetch<NonNullable<typeof detailData>>(`/api/products/${productId}`);
      setDetailData(res);
      setConvResult(null);
    } catch (err) {
      onNotify('error', 'Unable to load product details', (err as Error).message);
    }
  };

  const runConvert = async (productId: string) => {
    try {
      const res = await apiFetch<NonNullable<typeof convResult>>(`/api/products/${productId}/convert`, {
        method: 'POST',
        body: JSON.stringify({ qty: Number(convQty), fromUnit: convFrom, toUnit: convTo }),
      });
      setConvResult(res);
    } catch (err) {
      onNotify('error', 'Conversion error', (err as Error).message);
    }
  };

  const toggleProductStatus = async (p: (typeof products)[0]) => {
    const nextStatus = p.status === 'Active' ? 'Discontinued' : 'Active';
    try {
      await apiFetch(`/api/products/${p.id}/status`, {
        method: 'POST',
        body: JSON.stringify({ status: nextStatus, expectedVersion: p.version }),
      });
      onNotify('success', `Product ${p.sku} set to ${nextStatus}`);
      await loadData();
      if (detailData?.product.id === p.id) await openDetail(p.id);
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'Cannot change product status', (err as Error).message);
    }
  };

  const createConversionVersion = async (productId: string) => {
    try {
      await apiFetch(`/api/products/${productId}/conversions`, {
        method: 'POST',
        body: JSON.stringify({ unitsPerCase: Number(newUnitsPerCase), casesPerPallet: Number(newCasesPerPallet) }),
      });
      onNotify('success', 'New packaging conversion version created', 'Historical orders preserve their original conversion snapshot.');
      await loadData();
      await openDetail(productId);
    } catch (err) {
      onNotify('error', 'Cannot create conversion version', (err as Error).message);
    }
  };

  const filtered = products.filter(
    (p) => (selectedBrand === 'all' || p.brand_id === selectedBrand) && (categoryFilter === 'all' || p.category === categoryFilter)
  );

  return (
    <div className="space-y-4">
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-[20px] font-bold text-[#0F2147]">Brands &amp; Product Master Data</h2>
          <p className="text-[13px] text-[#5A759E]">
            GTINs, category attributes (Food allergens vs Home/Personal Care handling), and versioned packaging conversions.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={selectedBrand}
            onChange={(e) => setSelectedBrand(e.target.value)}
            className="h-9 px-3 text-[13px] font-medium bg-[#F4F8FD] border border-[#DCE8F7] rounded-xl"
          >
            <option value="all">All Brands</option>
            {brands.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
          <select
            value={categoryFilter}
            onChange={(e) => setCategoryFilter(e.target.value)}
            className="h-9 px-3 text-[13px] font-medium bg-[#F4F8FD] border border-[#DCE8F7] rounded-xl"
          >
            <option value="all">All Categories</option>
            <option value="Home Care">Home Care</option>
            <option value="Personal Care">Personal Care</option>
            <option value="Food & Nutrition">Food &amp; Nutrition</option>
          </select>
        </div>
      </div>

      {/* Product Grid */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-[13px] border-collapse min-w-[900px]">
            <thead>
              <tr className="bg-[#EEF4FC] text-[#475D82] text-[12px] font-semibold">
                <th className="text-left py-2.5 px-4">Product / SKU / GTIN</th>
                <th className="text-left py-2.5 px-3">Category</th>
                <th className="text-left py-2.5 px-3">Packaging (Current)</th>
                <th className="text-left py-2.5 px-3">Shelf Life &amp; Handling</th>
                <th className="text-right py-2.5 px-3">List Price / Case</th>
                <th className="text-right py-2.5 px-3">UK&amp;I ATP</th>
                <th className="text-left py-2.5 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EEF3FA]">
              {filtered.map((p) => {
                const currConv = conversions.find((c) => c.product_id === p.id && c.is_current === 1);
                const allergens: string[] = JSON.parse(p.allergens_json || '[]');
                return (
                  <tr
                    key={p.id}
                    onClick={() => openDetail(p.id)}
                    className="hover:bg-[#F6FAFF] transition-colors cursor-pointer"
                  >
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-3">
                        <img src={p.image_url} alt={p.name} className="w-11 h-11 object-contain rounded-lg border border-[#E6EFFA] bg-white p-0.5" />
                        <div>
                          <div className="font-bold text-[#0F2147]">{p.name}</div>
                          <div className="text-[12px] text-[#5A759E] font-mono tabular-nums">
                            {p.sku} • GTIN {p.gtin}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-medium text-[#0F2147]">{p.category}</div>
                      <div className="text-[11.5px] text-[#5A759E]">{p.brand_name}</div>
                    </td>
                    <td className="py-3 px-3 tabular-nums">
                      {currConv ? (
                        <div>
                          <span className="font-semibold text-[#0F2147]">{currConv.units_per_case} units/case</span>
                          <div className="text-[11.5px] text-[#5A759E]">
                            {currConv.cases_per_pallet} cases/pallet (v{currConv.version_num})
                          </div>
                        </div>
                      ) : (
                        '—'
                      )}
                    </td>
                    <td className="py-3 px-3">
                      <div className="text-[#0F2147] tabular-nums">{p.shelf_life_days} days shelf life</div>
                      {allergens.length > 0 ? (
                        <div className="text-[11.5px] font-semibold text-amber-800 flex items-center gap-1">
                          <ShieldAlert className="w-3.5 h-3.5" />
                          Allergens: {allergens.join(', ')}
                        </div>
                      ) : (
                        <div className="text-[11.5px] text-[#5A759E] truncate max-w-[230px]">{p.storage_requirements}</div>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right font-semibold tabular-nums">{formatGbp(p.list_price_case_pence)}</td>
                    <td className="py-3 px-3 text-right font-bold tabular-nums text-[#0055D4]">
                      {(p.total_atp_cases ?? 0).toLocaleString()} cs
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-flex items-center gap-1 text-[12px] font-semibold ${
                          p.status === 'Active' ? 'text-[#15803D]' : 'text-[#DC2626]'
                        }`}
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {p.status}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Product Detail Drawer/Modal */}
      {detailData && (
        <div className="fixed inset-0 z-50 bg-[#00174A]/45 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#DCE8F7] rounded-2xl shadow-2xl max-w-4xl w-full p-6 max-h-[90vh] overflow-y-auto space-y-5">
            <div className="flex items-start justify-between gap-4 pb-3 border-b border-[#EAF1FA]">
              <div className="flex items-center gap-4">
                <img src={detailData.product.image_url} alt={detailData.product.name} className="w-16 h-16 object-contain rounded-xl border border-[#DCE8F7] p-1" />
                <div>
                  <div className="text-[12px] font-mono text-[#5A759E]">
                    {detailData.product.sku} • GTIN {detailData.product.gtin} • {detailData.product.category}
                  </div>
                  <h3 className="text-[19px] font-bold text-[#0F2147]">{detailData.product.name}</h3>
                  <div className="text-[12.5px] text-[#5A759E]">
                    Dimensions: {detailData.product.dimensions_cm} cm • Weight: {detailData.product.weight_kg} kg/case • Tax: {detailData.product.tax_code}
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => toggleProductStatus(detailData.product)}
                  className="px-3 py-1.5 rounded-lg border border-[#DCE8F7] text-[12.5px] font-semibold hover:bg-[#F4F8FD] cursor-pointer"
                >
                  {detailData.product.status === 'Active' ? 'Discontinue SKU' : 'Reactivate SKU'}
                </button>
                <button
                  type="button"
                  onClick={() => setDetailData(null)}
                  className="p-1.5 rounded-lg hover:bg-[#EEF5FF] text-[#475D82] cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Handling & Allergens */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[13px]">
              <div className="bg-[#F8FBFF] border border-[#DCE8F7] rounded-xl p-3.5">
                <div className="font-bold text-[#0F2147] flex items-center gap-1.5 mb-1">
                  <Box className="w-4 h-4 text-[#0066FF]" />
                  Storage &amp; Handling Requirements
                </div>
                <p className="text-[#334A70]">{detailData.product.storage_requirements}</p>
                <p className="text-[#5A759E] mt-1">{detailData.product.handling_notes}</p>
              </div>

              {/* Packaging Conversion Calculator */}
              <div className="bg-[#F8FBFF] border border-[#DCE8F7] rounded-xl p-3.5">
                <div className="font-bold text-[#0F2147] flex items-center gap-1.5 mb-2">
                  <ArrowRightLeft className="w-4 h-4 text-[#0066FF]" />
                  Packaging Conversion Calculator (Active Version)
                </div>
                <div className="flex flex-wrap items-center gap-2">
                  <input
                    type="number"
                    value={convQty}
                    onChange={(e) => setConvQty(e.target.value)}
                    className="w-20 h-8 px-2 bg-white border border-[#DCE8F7] rounded-lg text-[13px] tabular-nums"
                  />
                  <select value={convFrom} onChange={(e) => setConvFrom(e.target.value as typeof convFrom)} className="h-8 px-2 bg-white border border-[#DCE8F7] rounded-lg">
                    <option value="unit">Units</option>
                    <option value="case">Cases</option>
                    <option value="pallet">Pallets</option>
                  </select>
                  <span className="text-[#5A759E]">to</span>
                  <select value={convTo} onChange={(e) => setConvTo(e.target.value as typeof convTo)} className="h-8 px-2 bg-white border border-[#DCE8F7] rounded-lg">
                    <option value="unit">Units</option>
                    <option value="case">Cases</option>
                    <option value="pallet">Pallets</option>
                  </select>
                  <button
                    type="button"
                    onClick={() => runConvert(detailData.product.id)}
                    className="h-8 px-3 bg-[#0055D4] text-white rounded-lg font-semibold text-[12px] hover:bg-[#003D99] cursor-pointer"
                  >
                    Convert
                  </button>
                </div>
                {convResult && (
                  <div className="mt-2 text-[12.5px] font-semibold text-[#15803D] tabular-nums">
                    = {convResult.convertedQty.toLocaleString()} {convTo}s (v{convResult.versionNum}: {convResult.unitsPerCase} units/case, {convResult.casesPerPallet} cases/pallet)
                  </div>
                )}
              </div>
            </div>

            {/* Versioned Packaging Conversions Table + New Version */}
            <div>
              <div className="flex flex-wrap items-center justify-between gap-2 mb-2">
                <h4 className="text-[14px] font-bold text-[#0F2147] flex items-center gap-1.5">
                  <Package className="w-4 h-4 text-[#0066FF]" />
                  Versioned Packaging Conversions (Historical Order Snapshot Integrity)
                </h4>
                <div className="flex items-center gap-2 text-[12px]">
                  <input
                    type="number"
                    value={newUnitsPerCase}
                    onChange={(e) => setNewUnitsPerCase(e.target.value)}
                    className="w-16 h-7 px-2 border border-[#DCE8F7] rounded-md tabular-nums"
                    title="Units per case"
                  />
                  <span>u/cs</span>
                  <input
                    type="number"
                    value={newCasesPerPallet}
                    onChange={(e) => setNewCasesPerPallet(e.target.value)}
                    className="w-16 h-7 px-2 border border-[#DCE8F7] rounded-md tabular-nums"
                    title="Cases per pallet"
                  />
                  <span>cs/plt</span>
                  <button
                    type="button"
                    onClick={() => createConversionVersion(detailData.product.id)}
                    className="h-7 px-2.5 bg-[#EAF2FF] text-[#003594] font-semibold rounded-md hover:bg-[#DCEBFF] cursor-pointer"
                  >
                    + New Version
                  </button>
                </div>
              </div>
              <table className="w-full text-[12.5px] border border-[#DCE8F7] rounded-xl overflow-hidden">
                <thead className="bg-[#EEF4FC] text-[#475D82]">
                  <tr>
                    <th className="text-left py-1.5 px-3">Version</th>
                    <th className="text-right py-1.5 px-3">Units / Case</th>
                    <th className="text-right py-1.5 px-3">Cases / Pallet</th>
                    <th className="text-left py-1.5 px-3">Effective Window</th>
                    <th className="text-left py-1.5 px-3">State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EEF3FA]">
                  {detailData.conversions.map((c) => (
                    <tr key={c.id}>
                      <td className="py-1.5 px-3 font-mono font-semibold">v{c.version_num}</td>
                      <td className="py-1.5 px-3 text-right tabular-nums">{c.units_per_case}</td>
                      <td className="py-1.5 px-3 text-right tabular-nums">{c.cases_per_pallet}</td>
                      <td className="py-1.5 px-3 tabular-nums">
                        {c.effective_from} → {c.effective_to || 'Current'}
                      </td>
                      <td className="py-1.5 px-3 font-semibold text-[#0055D4]">{c.is_current ? 'Active' : 'Historical'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Linked Inventory, Orders & Promotions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-[12.5px]">
              <div>
                <h4 className="font-bold text-[#0F2147] mb-1.5">Connected DC Batches</h4>
                <div className="border border-[#DCE8F7] rounded-xl divide-y divide-[#EEF3FA]">
                  {detailData.batches.map((b) => (
                    <div key={b.id} className="px-3 py-2 flex items-center justify-between">
                      <div>
                        <span className="font-mono font-semibold">{b.batch_number}</span>
                        <span className="text-[#5A759E]"> • {b.location_name}</span>
                      </div>
                      <span className="tabular-nums font-semibold">
                        {b.on_hand_cases - b.reserved_cases} avail / {b.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-bold text-[#0F2147] mb-1.5">Connected Orders &amp; Promotions</h4>
                <div className="border border-[#DCE8F7] rounded-xl divide-y divide-[#EEF3FA]">
                  {detailData.orders.map((o, idx) => (
                    <div key={idx} className="px-3 py-2 flex items-center justify-between">
                      <span className="font-semibold">
                        {o.order_ref} • {o.account_name}
                      </span>
                      <span className="tabular-nums text-[#5A759E]">
                        {o.ordered_cases.toLocaleString()} cs ({o.units_per_case_snapshot} u/cs snap)
                      </span>
                    </div>
                  ))}
                  {detailData.promotions.map((pr, idx) => (
                    <div key={`p-${idx}`} className="px-3 py-2 flex items-center justify-between bg-[#F8FBFF]">
                      <span className="font-semibold text-[#003594]">{pr.title}</span>
                      <span className="tabular-nums text-[#15803D] font-semibold">+{pr.expected_uplift_pct}% uplift</span>
                    </div>
                  ))}
                  {detailData.orders.length === 0 && detailData.promotions.length === 0 && (
                    <div className="px-3 py-3 text-[#5A759E] flex items-center gap-1.5">
                      <Info className="w-4 h-4" />
                      No active orders linked in current period.
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
