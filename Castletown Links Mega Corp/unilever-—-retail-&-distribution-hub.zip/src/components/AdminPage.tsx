import React, { useEffect, useState } from 'react';
import { RefreshCw, Shield, ShieldCheck } from 'lucide-react';
import { apiFetch } from '../api';
import type { RoleDefinition } from '../types';

interface AdminPageProps {
  roles: RoleDefinition[];
  activeRole: RoleDefinition;
  onNotify: (type: 'success' | 'error' | 'info', title: string, detail?: string) => void;
  onRefreshAll: () => void;
}

export const AdminPage: React.FC<AdminPageProps> = ({ roles, activeRole, onNotify, onRefreshAll }) => {
  const [logs, setLogs] = useState<
    Array<{ id: string; actor_role: string; actor_name: string; action: string; entity_type: string; entity_id: string; details_json: string; created_at: string }>
  >([]);

  const loadLogs = async () => {
    const res = await apiFetch<{ logs: typeof logs }>('/api/audit-logs');
    setLogs(res.logs);
  };

  useEffect(() => {
    loadLogs().catch(() => {});
  }, [activeRole.id]);

  const resetDemo = async () => {
    try {
      await apiFetch('/api/admin/reset-demo', { method: 'POST' });
      onNotify('success', 'Demo Dataset Reset', 'All UK & Ireland orders, batches, invoices, and alerts restored to initial baseline.');
      await loadLogs();
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'Reset denied', (err as Error).message);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-[20px] font-bold text-[#0F2147]">Administration, RBAC &amp; Audit Trail</h2>
          <p className="text-[13px] text-[#5A759E]">
            Active session role: <strong className="text-[#0055D4]">{activeRole.name}</strong> ({activeRole.userDisplayName}). Switch roles in the top-right avatar menu to test permission enforcement.
          </p>
        </div>
        <button
          type="button"
          onClick={resetDemo}
          className="h-9 px-3.5 rounded-xl border border-[#DCE8F7] bg-[#F8FBFF] hover:bg-[#EEF5FF] text-[#0F2147] text-[13px] font-semibold flex items-center gap-1.5 cursor-pointer"
        >
          <RefreshCw className="w-4 h-4 text-[#0066FF]" />
          <span>Reset Synthetic Demo Dataset</span>
        </button>
      </div>

      {/* RBAC Matrix */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
        <h3 className="text-[16px] font-bold text-[#0F2147] flex items-center gap-2 mb-3">
          <ShieldCheck className="w-4.5 h-4.5 text-[#0066FF]" />
          Role Permissions &amp; Market Scope Matrix (8 Roles)
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[12.5px]">
          {roles.map((r) => (
            <div
              key={r.id}
              className={`p-3.5 rounded-xl border ${
                r.id === activeRole.id ? 'bg-[#EEF5FF] border-[#0066FF]/50' : 'bg-[#FAFBFD] border-[#DCE8F7]'
              }`}
            >
              <div className="flex items-center justify-between">
                <span className="font-bold text-[#0F2147]">{r.name}</span>
                <span className="text-[11px] font-mono text-[#0055D4]">{r.marketScope.join(', ')}</span>
              </div>
              <p className="text-[#5A759E] mt-0.5">{r.description}</p>
              <div className="mt-2 text-[11px] font-mono text-[#475D82]">
                {r.permissions.length > 0 ? r.permissions.join(' · ') : 'Read-only inspection (0 write permissions)'}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Audit Log */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
        <h3 className="text-[16px] font-bold text-[#0F2147] flex items-center gap-2 mb-3">
          <Shield className="w-4.5 h-4.5 text-[#0066FF]" />
          Immutable Operational &amp; AI Audit Log
        </h3>
        <div className="overflow-x-auto max-h-96 overflow-y-auto">
          <table className="w-full text-[12px] border-collapse">
            <thead>
              <tr className="bg-[#EEF4FC] text-[#475D82] font-semibold">
                <th className="text-left py-2 px-3">Timestamp</th>
                <th className="text-left py-2 px-3">Actor / Role</th>
                <th className="text-left py-2 px-3">Action</th>
                <th className="text-left py-2 px-3">Target</th>
                <th className="text-left py-2 px-3">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EEF3FA]">
              {logs.map((l) => (
                <tr key={l.id}>
                  <td className="py-2 px-3 font-mono text-[#5A759E] whitespace-nowrap">{l.created_at.slice(0, 19).replace('T', ' ')}</td>
                  <td className="py-2 px-3 font-medium">
                    {l.actor_name} <span className="text-[#5A759E]">({l.actor_role})</span>
                  </td>
                  <td className="py-2 px-3 font-mono font-semibold text-[#0055D4]">{l.action}</td>
                  <td className="py-2 px-3 font-mono">
                    {l.entity_type}:{l.entity_id}
                  </td>
                  <td className="py-2 px-3 font-mono text-[11px] text-[#5A759E] max-w-xs truncate">{l.details_json}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
