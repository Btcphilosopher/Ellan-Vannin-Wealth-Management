import React, { useEffect, useState } from 'react';
import { CheckCircle2, CreditCard, FileText, Landmark } from 'lucide-react';
import { apiFetch, formatGbp } from '../api';

interface FinancePageProps {
  focusId?: string;
  onNotify: (type: 'success' | 'error' | 'info', title: string, detail?: string) => void;
  onRefreshAll: () => void;
}

export const FinancePage: React.FC<FinancePageProps> = ({ focusId, onNotify, onRefreshAll }) => {
  const [data, setData] = useState<{
    invoices: Array<{
      id: string;
      invoice_number: string;
      order_id: string;
      order_ref: string;
      account_name: string;
      delivered_cases: number;
      total_cases: number;
      tax_code: string;
      net_pence: number;
      tax_pence: number;
      total_pence: number;
      paid_pence: number;
      status: string;
      erp_sync_status: string;
    }>;
    payments: Array<{ id: string; payment_ref: string; invoice_number: string; account_name: string; amount_pence: number; method: string; received_at: string; reconciliation_state: string }>;
    ledger: Array<{ id: string; journal_ref: string; entry_date: string; account_code: string; account_name: string; debit_pence: number; credit_pence: number; description: string }>;
    ledgerBalanced: boolean;
    totalDebitsPence: number;
    totalCreditsPence: number;
    channelEconomics: Array<{ channel: string; net_sales_pence: number; cogs_pence: number; freight_pence: number; promo_accrual_pence: number }>;
  } | null>(null);

  const [deliverableOrders, setDeliverableOrders] = useState<
    Array<{ id: string; order_ref: string; account_name: string; delivered_cases: number; total_cases: number; invoice_state: string }>
  >([]);

  const loadFinance = async () => {
    const [fin, ords] = await Promise.all([
      apiFetch<NonNullable<typeof data>>('/api/finance'),
      apiFetch<{ orders: typeof deliverableOrders }>('/api/orders'),
    ]);
    setData(fin);
    setDeliverableOrders(ords.orders.filter((o) => o.delivered_cases > 0 && o.invoice_state !== 'Issued'));
  };

  useEffect(() => {
    loadFinance().catch(() => {});
  }, [focusId]);

  const issueInvoice = async (orderId: string) => {
    try {
      const res = await apiFetch<{ invoiceNumber: string; deliveredCases: number; totalPence: number }>(`/api/orders/${orderId}/invoice`, {
        method: 'POST',
      });
      onNotify(
        'success',
        `Issued ${res.invoiceNumber}`,
        `Billed strictly on ${res.deliveredCases.toLocaleString()} delivered cases (${formatGbp(res.totalPence)} incl. VAT) and posted balanced subledger journal.`
      );
      await loadFinance();
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'Invoicing failed', (err as Error).message);
    }
  };

  const recordPayment = async (invoiceId: string, outstandingPence: number) => {
    try {
      const res = await apiFetch<{ paymentRef: string; invoiceStatus: string }>(`/api/invoices/${invoiceId}/payments`, {
        method: 'POST',
        body: JSON.stringify({ amountPence: outstandingPence, method: 'UK BACS Faster Payment' }),
      });
      onNotify('success', `Allocated Payment ${res.paymentRef}`, `Invoice status updated to ${res.invoiceStatus} and AR cleared.`);
      await loadFinance();
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'Payment allocation failed', (err as Error).message);
    }
  };

  if (!data) return <div className="p-8 bg-white border border-[#DCE8F7] rounded-2xl text-[#5A759E]">Loading operational subledger...</div>;

  return (
    <div className="space-y-4">
      {/* Subledger Balance Status Banner */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-[20px] font-bold text-[#0F2147]">Operational Finance &amp; Balanced Subledger</h2>
          <p className="text-[13px] text-[#5A759E]">
            Fixed-pence integer arithmetic, versioned UK VAT rules, delivered-quantity invoicing, and balanced double-entry journals.
          </p>
        </div>
        <div
          className={`px-4 py-2 rounded-xl border text-[13px] font-semibold flex items-center gap-2 tabular-nums ${
            data.ledgerBalanced ? 'bg-[#E8F7EE] border-[#BCE5C9] text-[#157A36]' : 'bg-red-50 border-red-200 text-red-700'
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>
            Subledger Balanced: Debits {formatGbp(data.totalDebitsPence)} = Credits {formatGbp(data.totalCreditsPence)}
          </span>
        </div>
      </div>

      {/* Delivered Orders Awaiting Invoicing */}
      {deliverableOrders.length > 0 && (
        <div className="bg-[#EEF5FF] border border-[#B8D2F2] rounded-2xl p-4 flex flex-wrap items-center justify-between gap-3">
          <div className="text-[13px]">
            <strong className="text-[#0F2147]">Ready for Delivered-Quantity Invoicing:</strong>{' '}
            {deliverableOrders.map((o) => `${o.order_ref} (${o.account_name}: ${o.delivered_cases.toLocaleString()} delivered / ${o.total_cases.toLocaleString()} ordered)`).join(', ')}
          </div>
          <div className="flex gap-2">
            {deliverableOrders.map((o) => (
              <button
                key={o.id}
                type="button"
                onClick={() => issueInvoice(o.id)}
                className="px-3.5 py-2 rounded-xl bg-[#0055D4] text-white text-[12.5px] font-semibold hover:bg-[#003D99] cursor-pointer"
              >
                Issue Invoice for {o.order_ref} ({o.delivered_cases.toLocaleString()} cs)
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Invoices & Payments */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-7 bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
          <h3 className="text-[16px] font-bold text-[#0F2147] flex items-center gap-2 mb-3">
            <FileText className="w-4.5 h-4.5 text-[#0066FF]" />
            Customer Invoices (Invoiced vs Paid)
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-[12.5px] border-collapse">
              <thead>
                <tr className="bg-[#EEF4FC] text-[#475D82] text-[11.5px] font-semibold">
                  <th className="text-left py-2 px-3">Invoice / Order</th>
                  <th className="text-right py-2 px-2">Billed Qty</th>
                  <th className="text-right py-2 px-2">Net + VAT</th>
                  <th className="text-right py-2 px-2">Outstanding</th>
                  <th className="text-left py-2 px-2">Status</th>
                  <th className="text-right py-2 px-3">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EEF3FA]">
                {data.invoices.map((inv) => {
                  const outstanding = inv.total_pence - inv.paid_pence;
                  return (
                    <tr key={inv.id}>
                      <td className="py-2.5 px-3">
                        <div className="font-mono font-bold text-[#0F2147]">{inv.invoice_number}</div>
                        <div className="text-[11.5px] text-[#5A759E]">
                          {inv.order_ref} • {inv.account_name}
                        </div>
                      </td>
                      <td className="py-2.5 px-2 text-right tabular-nums">
                        {inv.delivered_cases.toLocaleString()} / {inv.total_cases.toLocaleString()} cs
                      </td>
                      <td className="py-2.5 px-2 text-right tabular-nums font-semibold">
                        {formatGbp(inv.total_pence)}
                        <div className="text-[11px] text-[#5A759E] font-normal">Net {formatGbp(inv.net_pence)}</div>
                      </td>
                      <td className="py-2.5 px-2 text-right tabular-nums font-bold text-[#0F2147]">{formatGbp(outstanding)}</td>
                      <td className="py-2.5 px-2 font-semibold text-[#15803D]">{inv.status}</td>
                      <td className="py-2.5 px-3 text-right">
                        {outstanding > 0 ? (
                          <button
                            type="button"
                            onClick={() => recordPayment(inv.id, outstanding)}
                            className="px-2.5 py-1 rounded-lg bg-[#15803D] text-white text-[11.5px] font-semibold hover:bg-[#166534] inline-flex items-center gap-1 cursor-pointer"
                          >
                            <CreditCard className="w-3.5 h-3.5" />
                            <span>Allocate BACS</span>
                          </button>
                        ) : (
                          <span className="text-[11.5px] text-[#5A759E]">{inv.erp_sync_status}</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Channel Contribution Analysis (Explicit Cost Assumptions) */}
        <div className="lg:col-span-5 bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
          <h3 className="text-[16px] font-bold text-[#0F2147] mb-1">Estimated Channel Contribution (Pre-Overhead)</h3>
          <p className="text-[12px] text-[#5A759E] mb-3">
            Separate from statutory accounting profit. Assumptions: 56% COGS, 5.2% Freight, 8.5% Trade Promo Accrual.
          </p>
          <div className="space-y-2.5 text-[12.5px]">
            {data.channelEconomics.map((c) => {
              const contrib = c.net_sales_pence - c.cogs_pence - c.freight_pence - c.promo_accrual_pence;
              const marginPct = ((contrib / Math.max(1, c.net_sales_pence)) * 100).toFixed(1);
              return (
                <div key={c.channel} className="p-3 rounded-xl bg-[#F8FBFF] border border-[#DCE8F7] flex items-center justify-between tabular-nums">
                  <div>
                    <div className="font-bold text-[#0F2147]">{c.channel}</div>
                    <div className="text-[11.5px] text-[#5A759E]">
                      Net {formatGbp(c.net_sales_pence)} • COGS {formatGbp(c.cogs_pence)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-[#15803D]">{formatGbp(contrib)}</div>
                    <div className="text-[11.5px] text-[#5A759E]">{marginPct}% est. margin</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Balanced Double-Entry Subledger */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
        <h3 className="text-[16px] font-bold text-[#0F2147] flex items-center gap-2 mb-3">
          <Landmark className="w-4.5 h-4.5 text-[#0066FF]" />
          Double-Entry Subledger Journal Lines
        </h3>
        <div className="overflow-x-auto">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr className="bg-[#EEF4FC] text-[#475D82] text-[11.5px] font-semibold">
                <th className="text-left py-2 px-3">Journal</th>
                <th className="text-left py-2 px-3">Date</th>
                <th className="text-left py-2 px-3">GL Account</th>
                <th className="text-left py-2 px-3">Description</th>
                <th className="text-right py-2 px-3">Debit</th>
                <th className="text-right py-2 px-3">Credit</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EEF3FA]">
              {data.ledger.map((l) => (
                <tr key={l.id}>
                  <td className="py-2 px-3 font-mono font-semibold text-[#0F2147]">{l.journal_ref}</td>
                  <td className="py-2 px-3 tabular-nums text-[#5A759E]">{l.entry_date}</td>
                  <td className="py-2 px-3 font-medium">
                    <span className="font-mono text-[#0055D4] mr-1.5">{l.account_code}</span>
                    {l.account_name}
                  </td>
                  <td className="py-2 px-3 text-[#475D82]">{l.description}</td>
                  <td className="py-2 px-3 text-right tabular-nums font-semibold">
                    {l.debit_pence > 0 ? formatGbp(l.debit_pence) : '—'}
                  </td>
                  <td className="py-2 px-3 text-right tabular-nums font-semibold">
                    {l.credit_pence > 0 ? formatGbp(l.credit_pence) : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
