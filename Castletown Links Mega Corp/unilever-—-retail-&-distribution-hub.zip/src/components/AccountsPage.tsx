import React, { useEffect, useState } from 'react';
import { Building2, CheckCircle2, FileText, MapPin, UserCheck } from 'lucide-react';
import { apiFetch, formatGbp } from '../api';

interface AccountsPageProps {
  focusId?: string;
}

export const AccountsPage: React.FC<AccountsPageProps> = ({ focusId }) => {
  const [data, setData] = useState<{
    accounts: Array<{
      id: string;
      name: string;
      legal_entity: string;
      channel: string;
      market: string;
      logo_url: string;
      account_manager: string;
      commercial_contact: string;
      contact_email: string;
      ordering_entity: string;
      invoice_recipient: string;
      payment_terms_days: number;
      rebate_rate_pct: number;
      otif_target_pct: number;
      fill_target_pct: number;
      credit_limit_pence: number;
    }>;
    deliveryLocations: Array<{ id: string; account_id: string; code: string; name: string; address: string; postcode: string; booking_window: string }>;
    priceLists: Array<{ id: string; account_id: string; sku: string; product_name: string; list_price_case_pence: number; agreed_case_price_pence: number; off_invoice_discount_pct: number; effective_from: string; effective_to: string }>;
    recentOrders: Array<{ id: string; order_ref: string; account_id: string; total_cases: number; net_amount_pence: number; operational_flag: string; order_date: string }>;
  } | null>(null);
  const [selectedId, setSelectedId] = useState<string>('acc-morrisons');

  useEffect(() => {
    apiFetch<NonNullable<typeof data>>('/api/accounts')
      .then((res) => {
        setData(res);
        if (focusId && res.accounts.some((a) => a.id === focusId)) {
          setSelectedId(focusId);
        }
      })
      .catch(() => {});
  }, [focusId]);

  if (!data) return <div className="p-8 bg-white border border-[#DCE8F7] rounded-2xl text-[#5A759E]">Loading commercial accounts...</div>;

  const selected = data.accounts.find((a) => a.id === selectedId) || data.accounts[0];
  const dlocs = data.deliveryLocations.filter((d) => d.account_id === selected.id);
  const prices = data.priceLists.filter((p) => p.account_id === selected.id);
  const orders = data.recentOrders.filter((o) => o.account_id === selected.id);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
      {/* Left Account Selector List */}
      <div className="lg:col-span-4 bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs space-y-2">
        <h2 className="text-[17px] font-bold text-[#0F2147] px-1">Retail Accounts (Synthetic)</h2>
        <p className="text-[12px] text-[#5A759E] px-1 pb-2">Commercial agreements, entity splits &amp; agreed price lists</p>
        <div className="space-y-1.5">
          {data.accounts.map((acc) => (
            <button
              key={acc.id}
              type="button"
              onClick={() => setSelectedId(acc.id)}
              className={`w-full text-left p-3 rounded-xl border transition-colors cursor-pointer flex items-center justify-between gap-3 ${
                acc.id === selected.id
                  ? 'bg-[#EEF5FF] border-[#0066FF]/40'
                  : 'bg-white border-[#E8F0FA] hover:bg-[#F7FAFF]'
              }`}
            >
              <div className="flex items-center gap-3 min-w-0">
                <img src={acc.logo_url} alt={acc.name} className="w-16 h-6 object-contain shrink-0" />
                <div className="min-w-0">
                  <div className="font-bold text-[13.5px] text-[#0F2147] truncate">{acc.name}</div>
                  <div className="text-[11.5px] text-[#5A759E]">{acc.channel} • {acc.market}</div>
                </div>
              </div>
              <span className="text-[11.5px] font-semibold text-[#0055D4] tabular-nums shrink-0">Net {acc.payment_terms_days}d</span>
            </button>
          ))}
        </div>
      </div>

      {/* Right Account Record Detail */}
      <div className="lg:col-span-8 space-y-4">
        <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-[#EAF1FA]">
            <div className="flex items-center gap-3.5">
              <img src={selected.logo_url} alt={selected.name} className="h-8 object-contain" />
              <div>
                <h3 className="text-[19px] font-bold text-[#0F2147]">{selected.legal_entity}</h3>
                <div className="text-[12.5px] text-[#5A759E]">
                  Account Manager: <strong className="text-[#0F2147]">{selected.account_manager}</strong> • Buyer: {selected.commercial_contact}
                </div>
              </div>
            </div>
            <div className="text-right tabular-nums">
              <div className="text-[12px] text-[#5A759E]">Credit Limit</div>
              <div className="text-[16px] font-bold text-[#0F2147]">{formatGbp(selected.credit_limit_pence)}</div>
            </div>
          </div>

          {/* Entity Separation: Ordering vs Delivery vs Invoice Recipient */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mt-4 text-[12.5px]">
            <div className="bg-[#F8FBFF] border border-[#DCE8F7] rounded-xl p-3">
              <div className="font-semibold text-[#0055D4] flex items-center gap-1.5 mb-1">
                <UserCheck className="w-4 h-4" />
                Ordering Entity
              </div>
              <div className="font-medium text-[#0F2147]">{selected.ordering_entity}</div>
              <div className="text-[#5A759E] mt-0.5">{selected.contact_email}</div>
            </div>
            <div className="bg-[#F8FBFF] border border-[#DCE8F7] rounded-xl p-3">
              <div className="font-semibold text-[#0055D4] flex items-center gap-1.5 mb-1">
                <MapPin className="w-4 h-4" />
                Delivery Destination(s)
              </div>
              {dlocs.map((d) => (
                <div key={d.id}>
                  <div className="font-medium text-[#0F2147]">{d.name}</div>
                  <div className="text-[#5A759E]">
                    {d.postcode} • Window {d.booking_window}
                  </div>
                </div>
              ))}
            </div>
            <div className="bg-[#F8FBFF] border border-[#DCE8F7] rounded-xl p-3">
              <div className="font-semibold text-[#0055D4] flex items-center gap-1.5 mb-1">
                <FileText className="w-4 h-4" />
                Invoice Recipient &amp; Terms
              </div>
              <div className="font-medium text-[#0F2147]">{selected.invoice_recipient}</div>
              <div className="text-[#5A759E] mt-0.5 tabular-nums">
                Net {selected.payment_terms_days} days • {selected.rebate_rate_pct}% annual rebate
              </div>
            </div>
          </div>

          {/* Service Targets */}
          <div className="flex flex-wrap items-center gap-6 mt-4 pt-3 border-t border-[#EEF3FA] text-[13px] tabular-nums">
            <span className="flex items-center gap-1.5 font-semibold text-[#15803D]">
              <CheckCircle2 className="w-4 h-4" />
              OTIF SLA Target: {selected.otif_target_pct}%
            </span>
            <span className="flex items-center gap-1.5 font-semibold text-[#0055D4]">
              <Building2 className="w-4 h-4" />
              Case Fill Target: {selected.fill_target_pct}%
            </span>
          </div>
        </div>

        {/* Agreed Price List & Product Listings */}
        <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
          <h4 className="text-[15px] font-bold text-[#0F2147] mb-3">Agreed Product Listings &amp; Contract Price List</h4>
          <div className="overflow-x-auto">
            <table className="w-full text-[13px] border-collapse">
              <thead>
                <tr className="bg-[#EEF4FC] text-[#475D82] text-[12px] font-semibold">
                  <th className="text-left py-2 px-3 rounded-l-lg">SKU</th>
                  <th className="text-left py-2 px-3">Product</th>
                  <th className="text-right py-2 px-3">List Price</th>
                  <th className="text-right py-2 px-3">Contract Off-Inv %</th>
                  <th className="text-right py-2 px-3 rounded-r-lg">Agreed Case Price</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EEF3FA]">
                {prices.map((p) => (
                  <tr key={p.id}>
                    <td className="py-2 px-3 font-mono font-medium">{p.sku}</td>
                    <td className="py-2 px-3 font-semibold text-[#0F2147]">{p.product_name}</td>
                    <td className="py-2 px-3 text-right tabular-nums text-[#5A759E]">{formatGbp(p.list_price_case_pence)}</td>
                    <td className="py-2 px-3 text-right tabular-nums text-[#15803D] font-semibold">-{p.off_invoice_discount_pct}%</td>
                    <td className="py-2 px-3 text-right tabular-nums font-bold text-[#0F2147]">{formatGbp(p.agreed_case_price_pence)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Account Activity History */}
        <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
          <h4 className="text-[15px] font-bold text-[#0F2147] mb-3">Account Order Activity</h4>
          {orders.length === 0 ? (
            <p className="text-[13px] text-[#5A759E]">No open orders in the current snapshot.</p>
          ) : (
            <div className="divide-y divide-[#EEF3FA] text-[13px]">
              {orders.map((o) => (
                <div key={o.id} className="py-2.5 flex items-center justify-between">
                  <div>
                    <span className="font-mono font-bold text-[#0F2147]">{o.order_ref}</span>
                    <span className="text-[#5A759E] ml-2">Ordered {o.order_date}</span>
                  </div>
                  <div className="flex items-center gap-4 tabular-nums">
                    <span>{o.total_cases.toLocaleString()} cases</span>
                    <span className="font-bold">{formatGbp(o.net_amount_pence)}</span>
                    <span className="text-[12px] font-semibold text-[#0055D4]">{o.operational_flag}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
