import React, { useEffect, useState } from 'react';
import { AlertTriangle, CheckCircle2, Edit3, TrendingUp } from 'lucide-react';
import { apiFetch } from '../api';

interface ForecastsPageProps {
  onNotify: (type: 'success' | 'error' | 'info', title: string, detail?: string) => void;
  onRefreshAll: () => void;
}

export const ForecastsPage: React.FC<ForecastsPageProps> = ({ onNotify, onRefreshAll }) => {
  const [forecasts, setForecasts] = useState<
    Array<{
      id: string;
      sku: string;
      product_name: string;
      location_name: string;
      period_week: string;
      version_label: string;
      invoiced_sales_cases: number;
      customer_orders_cases: number;
      consumer_epos_cases: number;
      baseline_cases: number;
      promo_uplift_cases: number;
      manual_override_cases: number | null;
      override_reason: string | null;
      p10_cases: number;
      p50_cases: number;
      p90_cases: number;
      backtest_wape: number | null;
      backtest_bias: number | null;
      data_sufficiency: string;
      safety_stock_days: number;
      lead_time_days: number;
    }>
  >([]);
  const [backtest, setBacktest] = useState<{
    leakFreeVerified: boolean;
    wapePct: number;
    biasPct: number;
    evaluatedWeeks: number;
    predictions: Array<{ weekIndex: number; actual: number; forecast: number; absError: number }>;
  } | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [overrideVal, setOverrideVal] = useState('');
  const [overrideReason, setOverrideReason] = useState('');

  const loadData = async () => {
    const res = await apiFetch<{ forecasts: typeof forecasts; backtestSample: typeof backtest }>('/api/forecasts');
    setForecasts(res.forecasts);
    setBacktest(res.backtestSample);
  };

  useEffect(() => {
    loadData().catch(() => {});
  }, []);

  const submitOverride = async (id: string) => {
    try {
      await apiFetch(`/api/forecasts/${id}/override`, {
        method: 'POST',
        body: JSON.stringify({ overrideCases: Number(overrideVal), reason: overrideReason }),
      });
      onNotify('success', 'Forecast Override Saved', 'Audit trail updated with planner justification.');
      setEditingId(null);
      await loadData();
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'Override rejected', (err as Error).message);
    }
  };

  return (
    <div className="space-y-4">
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-[20px] font-bold text-[#0F2147]">Demand Planning &amp; Leak-Free Backtesting</h2>
          <p className="text-[13px] text-[#5A759E]">
            Invoiced Shipments, Customer Orders, and Consumer EPOS Sell-Through are stored separately. Prediction intervals show P10–P90 uncertainty.
          </p>
        </div>
        {backtest && (
          <div className="flex items-center gap-3 text-[12.5px] bg-[#EEF5FF] border border-[#C6DCFA] rounded-xl px-3.5 py-2 tabular-nums">
            <CheckCircle2 className="w-4 h-4 text-[#16A34A]" />
            <span>
              Walk-Forward Backtest (Leak-Free): <strong>WAPE {backtest.wapePct}%</strong> • Bias {backtest.biasPct}% ({backtest.evaluatedWeeks} wks)
            </span>
          </div>
        )}
      </div>

      {/* Forecasts Table */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-[12.5px] border-collapse min-w-[1020px]">
            <thead>
              <tr className="bg-[#EEF4FC] text-[#475D82] text-[11.5px] font-semibold">
                <th className="text-left py-2.5 px-4">SKU &amp; Location</th>
                <th className="text-left py-2.5 px-2">Week / Ver</th>
                <th className="text-right py-2.5 px-2">Invoiced</th>
                <th className="text-right py-2.5 px-2">Orders</th>
                <th className="text-right py-2.5 px-2">EPOS Sell-Thru</th>
                <th className="text-right py-2.5 px-2">Base + Promo</th>
                <th className="text-right py-2.5 px-2">P10 / P50 / P90</th>
                <th className="text-left py-2.5 px-3">Safety / Data Quality</th>
                <th className="text-right py-2.5 px-4">Override</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EEF3FA]">
              {forecasts.map((f) => (
                <tr key={f.id} className="hover:bg-[#F7FAFF]">
                  <td className="py-3 px-4">
                    <div className="font-bold text-[#0F2147]">{f.product_name}</div>
                    <div className="text-[11.5px] text-[#5A759E] font-mono">
                      {f.sku} • {f.location_name}
                    </div>
                  </td>
                  <td className="py-3 px-2 tabular-nums">
                    <div className="font-semibold">{f.period_week}</div>
                    <div className="text-[11px] text-[#5A759E]">{f.version_label}</div>
                  </td>
                  <td className="py-3 px-2 text-right tabular-nums">{f.invoiced_sales_cases.toLocaleString()}</td>
                  <td className="py-3 px-2 text-right tabular-nums font-semibold text-[#0055D4]">{f.customer_orders_cases.toLocaleString()}</td>
                  <td className="py-3 px-2 text-right tabular-nums">{f.consumer_epos_cases > 0 ? f.consumer_epos_cases.toLocaleString() : '—'}</td>
                  <td className="py-3 px-2 text-right tabular-nums">
                    {f.baseline_cases.toLocaleString()} + <span className="text-[#15803D] font-semibold">{f.promo_uplift_cases}</span>
                  </td>
                  <td className="py-3 px-2 text-right tabular-nums">
                    <span className="text-[#5A759E]">{f.p10_cases}</span> / <strong className="text-[#0F2147]">{f.p50_cases}</strong> /{' '}
                    <span className="text-[#5A759E]">{f.p90_cases}</span>
                  </td>
                  <td className="py-3 px-3">
                    <div className="text-[11.5px] tabular-nums">
                      SS {f.safety_stock_days}d • LT {f.lead_time_days}d
                    </div>
                    {f.data_sufficiency !== 'Sufficient' ? (
                      <div className="text-[11.5px] font-semibold text-[#D97706] flex items-center gap-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        {f.data_sufficiency}
                      </div>
                    ) : (
                      <div className="text-[11.5px] text-[#15803D] font-medium">WAPE {f.backtest_wape}%</div>
                    )}
                  </td>
                  <td className="py-3 px-4 text-right">
                    {editingId === f.id ? (
                      <div className="flex items-center justify-end gap-1.5">
                        <input
                          type="number"
                          value={overrideVal}
                          onChange={(e) => setOverrideVal(e.target.value)}
                          placeholder="Cases"
                          className="w-20 h-7 px-2 border border-[#DCE8F7] rounded-md text-[12px] tabular-nums"
                        />
                        <input
                          type="text"
                          value={overrideReason}
                          onChange={(e) => setOverrideReason(e.target.value)}
                          placeholder="Reason..."
                          className="w-32 h-7 px-2 border border-[#DCE8F7] rounded-md text-[12px]"
                        />
                        <button
                          type="button"
                          onClick={() => submitOverride(f.id)}
                          className="h-7 px-2 bg-[#0055D4] text-white rounded-md text-[11.5px] font-semibold cursor-pointer"
                        >
                          Save
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setEditingId(f.id);
                          setOverrideVal(String(f.p50_cases));
                          setOverrideReason(f.override_reason || '');
                        }}
                        className="px-2.5 py-1 rounded-lg border border-[#C6DCFA] text-[#0055D4] text-[11.5px] font-semibold hover:bg-[#EEF5FF] inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Edit3 className="w-3 h-3" />
                        <span>{f.manual_override_cases ? `Override (${f.manual_override_cases})` : 'Override'}</span>
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Walk-Forward Backtest Detail */}
      {backtest && (
        <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4.5 h-4.5 text-[#0066FF]" />
            <h3 className="text-[15px] font-bold text-[#0F2147]">Walk-Forward Historical Backtest (Persil 24-Wash • Strict t &lt; Target Window)</h3>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-7 gap-2.5 text-[12px] tabular-nums">
            {backtest.predictions.map((p) => (
              <div key={p.weekIndex} className="bg-[#F8FBFF] border border-[#DCE8F7] rounded-xl p-2.5">
                <div className="font-semibold text-[#5A759E]">Week {p.weekIndex}</div>
                <div className="mt-1">
                  Actual: <strong className="text-[#0F2147]">{p.actual}</strong>
                </div>
                <div>
                  Fcst: <strong className="text-[#0055D4]">{p.forecast}</strong>
                </div>
                <div className="text-[11px] text-[#5A759E]">Err: {p.absError} cs</div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
