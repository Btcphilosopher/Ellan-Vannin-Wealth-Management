import React, { useState } from 'react';
import {
  AlertTriangle,
  ArrowUp,
  BarChart2,
  Calendar,
  CheckCircle2,
  ChevronRight,
  Info,
  Megaphone,
  Package,
  Truck,
  X,
} from 'lucide-react';
import { apiFetch, formatGbp, formatGbpMillions } from '../api';
import type { OverviewResponse, SectionId } from '../types';

interface OverviewPageProps {
  data: OverviewResponse | null;
  loading: boolean;
  onNavigate: (section: SectionId, focusId?: string) => void;
}

export const OverviewPage: React.FC<OverviewPageProps> = ({ data, loading, onNavigate }) => {
  const [channelModal, setChannelModal] = useState<{
    channel: string;
    period: string;
    summaries: Array<{ brand_name: string; market: string; net_sales_pence: number; ordered_cases: number; filled_cases: number }>;
    orders: Array<{ id: string; order_ref: string; account_name: string; total_cases: number; net_amount_pence: number; operational_flag: string }>;
  } | null>(null);
  const [metricInfo, setMetricInfo] = useState<string | null>(null);

  if (loading && !data) {
    return (
      <div className="space-y-4 animate-pulse">
        <div className="h-16 bg-white border border-[#DCE8F7] rounded-2xl" />
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <div key={i} className="h-28 bg-white border border-[#DCE8F7] rounded-2xl" />
          ))}
        </div>
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          <div className="lg:col-span-7 h-72 bg-white border border-[#DCE8F7] rounded-2xl" />
          <div className="lg:col-span-5 h-72 bg-white border border-[#DCE8F7] rounded-2xl" />
        </div>
      </div>
    );
  }

  if (!data) return null;

  const openChannelDrilldown = async (channel: string) => {
    try {
      const res = await apiFetch<NonNullable<typeof channelModal>>(
        `/api/channels/${encodeURIComponent(channel)}/transactions?period=${data.period}`
      );
      setChannelModal(res);
    } catch {
      // handled silently
    }
  };

  const maxChannelPence = Math.max(2_000_000_000, ...data.salesByChannel.map((c) => c.netSalesPence));

  return (
    <div className="space-y-4">
      {/* Brand Portfolio Ribbon */}
      <section
        aria-label="Demonstration brand portfolio"
        className="bg-white border border-[#DCE8F7] rounded-2xl px-4 py-2.5 shadow-2xs flex items-center justify-between gap-4 overflow-x-auto relative"
      >
        {/* Left Cyan Flourish */}
        <svg viewBox="0 0 48 40" className="w-10 h-8 shrink-0 hidden sm:block" fill="none">
          <path d="M8 32c5-12 16-20 22-14 5 5-4 15-16 17-4 1-7-1-6-3z" fill="#A5DCFF" />
          <ellipse cx="32" cy="12" rx="3.5" ry="7" transform="rotate(28 32 12)" fill="#CBEAFF" />
          <circle cx="40" cy="27" r="4" fill="#CBEAFF" />
        </svg>

        <div className="flex-1 grid grid-cols-5 min-w-[540px] divide-x divide-[#E8F0FA] items-center">
          {data.brandPerformance.map((brand) => (
            <button
              key={brand.brandId}
              type="button"
              onClick={() => onNavigate('brands', brand.brandId)}
              className="flex items-center justify-center px-3 py-1 hover:bg-[#F5F9FF] rounded-xl transition-colors cursor-pointer"
              title={`Inspect ${brand.brandName} SKUs & performance`}
            >
              <img
                src={brand.logoUrl}
                alt={brand.brandName}
                className="h-8 object-contain"
              />
            </button>
          ))}
        </div>

        {/* Right Cyan Flourish */}
        <svg viewBox="0 0 48 40" className="w-10 h-8 shrink-0 hidden sm:block scale-x-[-1]" fill="none">
          <path d="M8 32c5-12 16-20 22-14 5 5-4 15-16 17-4 1-7-1-6-3z" fill="#A5DCFF" />
          <ellipse cx="32" cy="12" rx="3.5" ry="7" transform="rotate(28 32 12)" fill="#CBEAFF" />
          <circle cx="40" cy="27" r="4" fill="#CBEAFF" />
        </svg>
      </section>

      {/* Row 1: 4 Primary KPI Cards */}
      <section aria-label="Key performance indicators" className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        {/* Net Sales */}
        <div
          onClick={() => onNavigate('finance')}
          className="bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs hover:border-[#B8D2F2] transition-colors cursor-pointer flex items-center gap-3.5"
        >
          <div className="w-12 h-12 rounded-xl bg-[#EEF5FF] text-[#0055D4] flex items-center justify-center shrink-0">
            <BarChart2 className="w-6 h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[13.5px] font-medium text-[#475D82]">Net sales</div>
            <div className="text-[28px] font-bold tracking-tight text-[#0F2147] leading-tight tabular-nums">
              {formatGbpMillions(data.kpis.netSalesPence)}
            </div>
            <div className="flex items-center gap-1 text-[12.5px] font-semibold text-[#15803D] mt-0.5 tabular-nums">
              <ArrowUp className="w-3.5 h-3.5" />
              <span>+{data.kpis.vsPriorMonthPct}% vs prior month</span>
            </div>
          </div>
        </div>

        {/* Order Fill Rate */}
        <div
          onClick={() => setMetricInfo(metricInfo === 'fill' ? null : 'fill')}
          className="bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs hover:border-[#B8D2F2] transition-colors cursor-pointer flex items-center gap-3.5 relative"
        >
          <div className="w-12 h-12 rounded-xl bg-[#EEF5FF] text-[#0055D4] flex items-center justify-center shrink-0">
            <Package className="w-6 h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-[13.5px] font-medium text-[#475D82]">
              <span>Order fill rate</span>
              <Info className="w-3.5 h-3.5 text-[#8CA3C7]" />
            </div>
            <div className="text-[28px] font-bold tracking-tight text-[#0F2147] leading-tight tabular-nums mt-0.5">
              {data.kpis.orderFillRatePct.toFixed(1)}%
            </div>
          </div>
          <CheckCircle2 className="w-6 h-6 text-[#2E9E44] shrink-0" />
          {metricInfo === 'fill' && (
            <div className="absolute left-3 right-3 top-full mt-1.5 bg-white border border-[#DCE8F7] rounded-xl shadow-lg p-2.5 text-[12px] z-20">
              <div className="font-semibold text-[#0F2147]">Case-Level Fill Rate Formula</div>
              <div className="text-[#5A759E] mt-0.5 tabular-nums">
                {data.kpis.fillRateNumeratorCases.toLocaleString()} filled cases ÷ {data.kpis.fillRateDenominatorCases.toLocaleString()} ordered cases ({data.period})
              </div>
            </div>
          )}
        </div>

        {/* On-time Delivery */}
        <div
          onClick={() => setMetricInfo(metricInfo === 'otd' ? null : 'otd')}
          className="bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs hover:border-[#B8D2F2] transition-colors cursor-pointer flex items-center gap-3.5 relative"
        >
          <div className="w-12 h-12 rounded-xl bg-[#EEF5FF] text-[#0055D4] flex items-center justify-center shrink-0">
            <Truck className="w-6 h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 text-[13.5px] font-medium text-[#475D82]">
              <span>On-time delivery</span>
              <Info className="w-3.5 h-3.5 text-[#8CA3C7]" />
            </div>
            <div className="text-[28px] font-bold tracking-tight text-[#0F2147] leading-tight tabular-nums mt-0.5">
              {data.kpis.onTimeDeliveryPct.toFixed(1)}%
            </div>
          </div>
          <CheckCircle2 className="w-6 h-6 text-[#2E9E44] shrink-0" />
          {metricInfo === 'otd' && (
            <div className="absolute left-3 right-3 top-full mt-1.5 bg-white border border-[#DCE8F7] rounded-xl shadow-lg p-2.5 text-[12px] z-20">
              <div className="font-semibold text-[#0F2147]">Shipment Booking-Window OTD</div>
              <div className="text-[#5A759E] mt-0.5 tabular-nums">
                {data.kpis.otdNumeratorDeliveries} on-time PODs ÷ {data.kpis.otdDenominatorDeliveries} confirmed deliveries ({data.period})
              </div>
            </div>
          )}
        </div>

        {/* Stock Alerts */}
        <button
          type="button"
          onClick={() => onNavigate('inventory', 'exceptions')}
          className="bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs hover:border-[#F59E0B]/60 transition-colors cursor-pointer flex items-center gap-3.5 text-left"
        >
          <div className="w-12 h-12 rounded-xl bg-[#FFF6E5] text-[#D97706] flex items-center justify-center shrink-0 border border-[#FDE6B8]">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="text-[13.5px] font-medium text-[#475D82]">Stock alerts</div>
            <div className="text-[28px] font-bold tracking-tight text-[#0F2147] leading-tight tabular-nums">
              {data.kpis.stockAlertsCount}
            </div>
            <div className="text-[12.5px] text-[#5A759E]">Review required</div>
          </div>
          <ChevronRight className="w-5 h-5 text-[#5A759E] shrink-0" />
        </button>
      </section>

      {/* Row 2: Brand Performance + Sales by Channel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Brand Performance Card */}
        <section className="lg:col-span-7 bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs flex flex-col">
          <div className="flex items-center justify-between gap-2 mb-3">
            <h2 className="text-[17px] font-bold text-[#0F2147]">Brand performance</h2>
            <button
              type="button"
              onClick={() => onNavigate('brands')}
              className="text-[13px] font-semibold text-[#0055D4] hover:text-[#003594] flex items-center gap-0.5 cursor-pointer whitespace-nowrap"
            >
              <span>View brand details</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center flex-1">
            {/* Packshot Lineup */}
            <div className="md:col-span-5 flex items-center justify-center bg-[#FAFBFD] rounded-xl p-2 border border-[#EEF3FA]">
              <img
                src="/assets/images/brand_lineup_packshot_1794570847577.jpg"
                alt="Dove, Persil, Hellmann's, Comfort and Simple product lineup"
                className="w-full max-h-52 object-contain rounded-lg"
              />
            </div>

            {/* Brand Table */}
            <div className="md:col-span-7 overflow-x-auto">
              <table className="w-full text-[13.5px] border-collapse">
                <thead>
                  <tr className="bg-[#EEF4FC] text-[#475D82] text-[12px] font-semibold">
                    <th className="text-left py-2 px-3 rounded-l-lg">Brand</th>
                    <th className="text-right py-2 px-2">Net sales</th>
                    <th className="text-right py-2 px-2">vs plan</th>
                    <th className="text-right py-2 px-3 rounded-r-lg">Availability</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EEF3FA]">
                  {data.brandPerformance.map((b) => (
                    <tr
                      key={b.brandId}
                      onClick={() => onNavigate('brands', b.brandId)}
                      className="hover:bg-[#F6FAFF] transition-colors cursor-pointer"
                    >
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-2.5">
                          <img src={b.logoUrl} alt="" className="w-12 h-5 object-contain shrink-0" />
                          <span className="font-semibold text-[#0F2147]">{b.brandName}</span>
                        </div>
                      </td>
                      <td className="py-2.5 px-2 text-right font-bold text-[#0F2147] tabular-nums">
                        {formatGbpMillions(b.netSalesPence)}
                      </td>
                      <td className="py-2.5 px-2 text-right font-semibold text-[#15803D] tabular-nums">
                        +{b.vsPlanPct.toFixed(1)}%
                      </td>
                      <td className="py-2.5 px-3 text-right tabular-nums">
                        <span className="inline-flex items-center gap-1.5 font-semibold text-[#0F2147]">
                          <span className="w-2 h-2 rounded-full bg-[#16A34A]" />
                          {b.availabilityPct.toFixed(1)}%
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* Sales by Channel Card */}
        <section className="lg:col-span-5 bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs flex flex-col">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h2 className="text-[17px] font-bold text-[#0F2147]">Sales by channel</h2>
              <p className="text-[12.5px] text-[#5A759E]">Illustrative sales mix • Click bar to drill down</p>
            </div>
            <button
              type="button"
              onClick={() => onNavigate('finance')}
              className="text-[13px] font-semibold text-[#0055D4] hover:text-[#003594] flex items-center gap-0.5 cursor-pointer whitespace-nowrap"
            >
              <span>View channel analysis</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex-1 flex items-end gap-3 pt-6 pb-1 min-h-[210px]">
            {/* Y-Axis labels */}
            <div className="flex flex-col justify-between h-44 text-[11.5px] text-[#5A759E] tabular-nums pr-1 pb-5">
              <span>£20m</span>
              <span>£15m</span>
              <span>£10m</span>
              <span>£5m</span>
              <span>£0m</span>
            </div>

            {/* Bars */}
            <div className="flex-1 relative h-44 flex items-end justify-around gap-3 border-b border-[#DCE8F7] pb-0">
              {/* Horizontal Gridlines */}
              <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
                {[0, 1, 2, 3, 4].map((line) => (
                  <div key={line} className="w-full border-t border-dashed border-[#E6EFFA]" />
                ))}
              </div>

              {data.salesByChannel.map((ch) => {
                const pct = Math.max(8, Math.min(96, (ch.netSalesPence / maxChannelPence) * 100));
                return (
                  <button
                    key={ch.channel}
                    type="button"
                    onClick={() => openChannelDrilldown(ch.channel)}
                    className="relative z-10 flex-1 max-w-[78px] h-full flex flex-col items-center justify-end group cursor-pointer"
                    title={`Drill down into ${ch.channel} transactions`}
                  >
                    <span className="text-[12.5px] font-bold text-[#0F2147] mb-1 tabular-nums">
                      {formatGbpMillions(ch.netSalesPence)}
                    </span>
                    <div
                      style={{ height: `${pct}%` }}
                      className="w-full rounded-t-md bg-gradient-to-t from-[#005CE6] to-[#0077FF] group-hover:from-[#0047B3] group-hover:to-[#0066FF] transition-all shadow-xs"
                    />
                  </button>
                );
              })}
            </div>
          </div>
          <div className="pl-9 grid grid-cols-4 gap-3 text-center text-[12.5px] font-medium text-[#334A70] pt-2">
            {data.salesByChannel.map((ch) => (
              <span key={ch.channel}>{ch.channel}</span>
            ))}
          </div>
        </section>
      </div>

      {/* Row 3: Retail Account Orders + Supply Exceptions */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Retail Account Orders */}
        <section className="lg:col-span-7 bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
          <div className="flex items-center justify-between gap-2 mb-3">
            <h2 className="text-[17px] font-bold text-[#0F2147]">Retail account orders</h2>
            <button
              type="button"
              onClick={() => onNavigate('orders')}
              className="text-[13px] font-semibold text-[#0055D4] hover:text-[#003594] flex items-center gap-0.5 cursor-pointer whitespace-nowrap"
            >
              <span>View all orders</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-[13.5px] border-collapse min-w-[540px]">
              <thead>
                <tr className="bg-[#EEF4FC] text-[#475D82] text-[12px] font-semibold">
                  <th className="text-left py-2 px-3 rounded-l-lg">Account</th>
                  <th className="text-left py-2 px-2">Order</th>
                  <th className="text-right py-2 px-2">Cases</th>
                  <th className="text-left py-2 px-3">Delivery</th>
                  <th className="text-left py-2 px-3 rounded-r-lg">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EEF3FA]">
                {data.featuredOrders.map((ord) => {
                  const flag = ord.operationalFlag;
                  return (
                    <tr
                      key={ord.id}
                      onClick={() => onNavigate('orders', ord.id)}
                      className="hover:bg-[#F6FAFF] transition-colors cursor-pointer"
                    >
                      <td className="py-2.5 px-3">
                        <div className="flex items-center gap-2.5">
                          <img src={ord.accountLogoUrl} alt="" className="w-16 h-5 object-contain shrink-0" />
                          <span className="font-semibold text-[#0F2147]">{ord.accountName}</span>
                        </div>
                      </td>
                      <td className="py-2.5 px-2 font-mono text-[13px] font-medium text-[#0F2147] tabular-nums">
                        {ord.orderRef}
                      </td>
                      <td className="py-2.5 px-2 text-right font-semibold text-[#0F2147] tabular-nums">
                        {ord.totalCases.toLocaleString()}
                      </td>
                      <td className="py-2.5 px-3 text-[#334A70] whitespace-nowrap">{ord.deliveryDate}</td>
                      <td className="py-2.5 px-3">
                        {flag === 'Confirmed' && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[12px] font-semibold bg-[#E8F7EE] text-[#157A36] border border-[#BCE5C9] whitespace-nowrap">
                            <CheckCircle2 className="w-3.5 h-3.5 text-[#16A34A]" />
                            Confirmed
                          </span>
                        )}
                        {flag === 'In transit' && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[12px] font-semibold bg-[#E8F2FF] text-[#0055D4] border border-[#C2DAFA] whitespace-nowrap">
                            <Truck className="w-3.5 h-3.5 text-[#0066FF]" />
                            In transit
                          </span>
                        )}
                        {flag === 'Action needed' && (
                          <span className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[12px] font-semibold bg-[#FEF3DC] text-[#9A5B04] border border-[#F7D794] whitespace-nowrap">
                            <AlertTriangle className="w-3.5 h-3.5 text-[#D97706]" />
                            Action needed
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* Supply Exceptions */}
        <section className="lg:col-span-5 bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs flex flex-col">
          <div className="flex items-center justify-between gap-2 mb-3">
            <h2 className="text-[17px] font-bold text-[#0F2147]">Supply exceptions</h2>
            <button
              type="button"
              onClick={() => onNavigate('inventory', 'exceptions')}
              className="text-[13px] font-semibold text-[#0055D4] hover:text-[#003594] flex items-center gap-0.5 cursor-pointer whitespace-nowrap"
            >
              <span>View all exceptions</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <div className="divide-y divide-[#EEF3FA] flex-1">
            {data.featuredExceptions.map((exc) => (
              <div key={exc.id} className="py-3 first:pt-1 last:pb-1 flex items-center justify-between gap-3">
                <div className="flex items-start gap-2.5 min-w-0">
                  <AlertTriangle
                    className={`w-4.5 h-4.5 shrink-0 mt-0.5 ${
                      exc.severity === 'High' ? 'text-[#DC2626]' : 'text-[#D97706]'
                    }`}
                  />
                  <div className="min-w-0">
                    <div className="text-[13.5px] font-bold text-[#0F2147] truncate">{exc.title}</div>
                    <div className="text-[12px] text-[#5A759E] truncate">
                      {exc.status === 'RESOLVED' ? 'Resolved • Replenishment executed' : exc.subtitle}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    type="button"
                    onClick={() =>
                      onNavigate(exc.relatedOrderId ? 'orders' : 'forecasts', exc.relatedOrderId || exc.productId)
                    }
                    className="px-2.5 py-1.5 rounded-lg bg-[#0052CC] hover:bg-[#003D99] text-white text-[12px] font-semibold transition-colors cursor-pointer whitespace-nowrap"
                  >
                    Review plan
                  </button>
                  <button
                    type="button"
                    onClick={() => onNavigate('inventory', exc.productId)}
                    className="px-2.5 py-1.5 rounded-lg bg-white hover:bg-[#F4F8FD] text-[#0055D4] border border-[#C6DCFA] text-[12px] font-semibold transition-colors cursor-pointer whitespace-nowrap"
                  >
                    View stock
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      {/* Row 4: Planning Summary Strip */}
      <section
        aria-label="Planning summary"
        className="bg-white border border-[#DCE8F7] rounded-2xl px-5 py-4 shadow-2xs grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-[#E6EFFA] gap-4 md:gap-0"
      >
        {/* Demand planning */}
        <div
          onClick={() => onNavigate('forecasts')}
          className="flex items-center justify-between gap-3 md:pr-5 cursor-pointer hover:opacity-90"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-[#EEF5FF] text-[#0055D4] flex items-center justify-center shrink-0">
              <Calendar className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[13.5px] font-semibold text-[#0F2147]">Demand planning</div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-[22px] font-bold text-[#15803D] tabular-nums">
                  +{data.planningSummary.demandPlanningPct.toFixed(1)}%
                </span>
                <span className="text-[12.5px] text-[#5A759E]">vs plan</span>
              </div>
            </div>
          </div>
          <svg viewBox="0 0 110 38" className="w-28 h-10 shrink-0" fill="none">
            <defs>
              <linearGradient id="sparkGreen1" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#16A34A" stopOpacity="0.24" />
                <stop offset="100%" stopColor="#16A34A" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d="M2 33L18 26L34 27L52 20L70 21L88 12L104 7V36H2Z" fill="url(#sparkGreen1)" />
            <path d="M2 33L18 26L34 27L52 20L70 21L88 12L104 7" stroke="#16A34A" strokeWidth="2" strokeLinecap="round" />
            <circle cx="104" cy="7" r="3" fill="#16A34A" />
          </svg>
        </div>

        {/* Promotional uplift */}
        <div
          onClick={() => onNavigate('promotions')}
          className="flex items-center justify-between gap-3 pt-3 md:pt-0 md:px-5 cursor-pointer hover:opacity-90"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-[#EEF5FF] text-[#0055D4] flex items-center justify-center shrink-0">
              <Megaphone className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[13.5px] font-semibold text-[#0F2147]">Promotional uplift</div>
              <div className="flex items-baseline gap-1.5">
                <span className="text-[22px] font-bold text-[#15803D] tabular-nums">
                  +{data.planningSummary.promotionalUpliftPct.toFixed(1)}%
                </span>
                <span className="text-[12.5px] text-[#5A759E]">vs baseline</span>
              </div>
            </div>
          </div>
          <svg viewBox="0 0 110 38" className="w-28 h-10 shrink-0" fill="none">
            <defs>
              <linearGradient id="sparkBlue" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#0066FF" stopOpacity="0.22" />
                <stop offset="100%" stopColor="#0066FF" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d="M2 33L18 25L35 28L52 19L70 22L88 14L104 7V36H2Z" fill="url(#sparkBlue)" />
            <path d="M2 33L18 25L35 28L52 19L70 22L88 14L104 7" stroke="#0066FF" strokeWidth="2" strokeLinecap="round" />
            <circle cx="104" cy="7" r="3" fill="#0066FF" />
          </svg>
        </div>

        {/* Warehouse availability */}
        <div
          onClick={() => onNavigate('inventory')}
          className="flex items-center justify-between gap-3 pt-3 md:pt-0 md:pl-5 cursor-pointer hover:opacity-90"
        >
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-[#EEF5FF] text-[#0055D4] flex items-center justify-center shrink-0">
              <Package className="w-5 h-5" />
            </div>
            <div>
              <div className="text-[13.5px] font-semibold text-[#0F2147]">Warehouse availability</div>
              <div className="flex items-baseline gap-1.5 flex-wrap">
                <span className="text-[22px] font-bold text-[#15803D] tabular-nums">
                  {data.planningSummary.warehouseAvailabilityPct.toFixed(1)}%
                </span>
                <span className="text-[12px] text-[#5A759E]">(+{data.planningSummary.warehouseDeltaPp}pp vs prior month)</span>
              </div>
            </div>
          </div>
          <svg viewBox="0 0 110 38" className="w-28 h-10 shrink-0" fill="none">
            <defs>
              <linearGradient id="sparkGreen2" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#16A34A" stopOpacity="0.24" />
                <stop offset="100%" stopColor="#16A34A" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d="M2 33L18 27L35 28L52 20L70 22L88 14L104 7V36H2Z" fill="url(#sparkGreen2)" />
            <path d="M2 33L18 27L35 28L52 20L70 22L88 14L104 7" stroke="#16A34A" strokeWidth="2" strokeLinecap="round" />
            <circle cx="104" cy="7" r="3" fill="#16A34A" />
          </svg>
        </div>
      </section>

      {/* Channel Drill-down Modal */}
      {channelModal && (
        <div className="fixed inset-0 z-50 bg-[#00174A]/45 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#DCE8F7] rounded-2xl shadow-2xl max-w-2xl w-full p-5 max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-[#EAF1FA]">
              <div>
                <h3 className="text-[17px] font-bold text-[#0F2147]">{channelModal.channel} Channel Breakdown</h3>
                <p className="text-[12.5px] text-[#5A759E]">Supporting brand mix &amp; customer order records ({channelModal.period})</p>
              </div>
              <button
                type="button"
                onClick={() => setChannelModal(null)}
                className="p-1.5 rounded-lg hover:bg-[#EEF5FF] text-[#475D82] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="mt-4 space-y-4">
              <div>
                <h4 className="text-[13px] font-semibold text-[#475D82] mb-2">Brand Mix Reconciliation</h4>
                <table className="w-full text-[13px] border border-[#DCE8F7] rounded-xl overflow-hidden">
                  <thead className="bg-[#EEF4FC] text-[#475D82]">
                    <tr>
                      <th className="text-left py-2 px-3">Brand</th>
                      <th className="text-left py-2 px-3">Market</th>
                      <th className="text-right py-2 px-3">Filled / Ordered</th>
                      <th className="text-right py-2 px-3">Net Sales</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EEF3FA]">
                    {channelModal.summaries.map((s, idx) => (
                      <tr key={idx}>
                        <td className="py-2 px-3 font-semibold">{s.brand_name}</td>
                        <td className="py-2 px-3 text-[#5A759E]">{s.market}</td>
                        <td className="py-2 px-3 text-right tabular-nums">
                          {s.filled_cases.toLocaleString()} / {s.ordered_cases.toLocaleString()} cs
                        </td>
                        <td className="py-2 px-3 text-right font-bold tabular-nums">{formatGbp(s.net_sales_pence)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {channelModal.orders.length > 0 && (
                <div>
                  <h4 className="text-[13px] font-semibold text-[#475D82] mb-2">Active Channel Orders</h4>
                  <div className="space-y-1.5">
                    {channelModal.orders.map((o) => (
                      <button
                        key={o.id}
                        type="button"
                        onClick={() => {
                          setChannelModal(null);
                          onNavigate('orders', o.id);
                        }}
                        className="w-full flex items-center justify-between px-3 py-2 rounded-xl border border-[#DCE8F7] hover:bg-[#F5F9FF] text-[13px] cursor-pointer"
                      >
                        <span className="font-semibold text-[#0F2147]">
                          {o.order_ref} • {o.account_name}
                        </span>
                        <span className="tabular-nums text-[#475D82]">
                          {o.total_cases.toLocaleString()} cases • {formatGbp(o.net_amount_pence)}
                        </span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
