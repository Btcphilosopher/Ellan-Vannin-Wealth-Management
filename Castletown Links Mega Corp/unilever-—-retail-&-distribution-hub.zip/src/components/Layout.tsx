import React, { useEffect, useRef, useState } from 'react';
import {
  BarChart3,
  Bell,
  Boxes,
  Building2,
  Calendar,
  ChevronDown,
  FileSpreadsheet,
  Home,
  Layers,
  Megaphone,
  Menu,
  RefreshCw,
  Search,
  Settings,
  ShieldCheck,
  ShoppingCart,
  Sparkles,
  Tag,
  TrendingUp,
  Truck,
  X,
} from 'lucide-react';
import { apiFetch } from '../api';
import type { MarketScope, ReportingPeriod, RoleDefinition, RoleId, SectionId } from '../types';

interface LayoutProps {
  activeSection: SectionId;
  onNavigate: (section: SectionId, focusId?: string) => void;
  market: MarketScope;
  onMarketChange: (m: MarketScope) => void;
  period: ReportingPeriod;
  onPeriodChange: (p: ReportingPeriod) => void;
  roles: RoleDefinition[];
  activeRole: RoleDefinition;
  onRoleChange: (roleId: RoleId) => void;
  onRefresh: () => void;
  lastRefreshedAt: string;
  onOpenCopilot: () => void;
  children: React.ReactNode;
}

const NAV_ITEMS: Array<{ id: SectionId; label: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'overview', label: 'Overview', icon: Home },
  { id: 'brands', label: 'Brands', icon: Tag },
  { id: 'accounts', label: 'Retail accounts', icon: Building2 },
  { id: 'orders', label: 'Orders', icon: ShoppingCart },
  { id: 'inventory', label: 'Inventory', icon: Boxes },
  { id: 'distribution', label: 'Distribution', icon: Truck },
  { id: 'promotions', label: 'Promotions', icon: Megaphone },
  { id: 'forecasts', label: 'Forecasts', icon: TrendingUp },
  { id: 'finance', label: 'Finance', icon: Layers },
  { id: 'reports', label: 'Reports', icon: FileSpreadsheet },
];

export const Layout: React.FC<LayoutProps> = ({
  activeSection,
  onNavigate,
  market,
  onMarketChange,
  period,
  onPeriodChange,
  roles,
  activeRole,
  onRoleChange,
  onRefresh,
  lastRefreshedAt,
  onOpenCopilot,
  children,
}) => {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<{
    products: Array<{ id: string; sku: string; name: string }>;
    accounts: Array<{ id: string; name: string; channel: string }>;
    orders: Array<{ id: string; orderRef: string; accountName: string; operationalFlag: string }>;
    shipments: Array<{ id: string; shipmentRef: string; carrierName: string; status: string }>;
  } | null>(null);
  const [showNotif, setShowNotif] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showDateInfo, setShowDateInfo] = useState(false);
  const [notifications, setNotifications] = useState<
    Array<{ id: string; title: string; message: string; severity: string; target_section: SectionId; target_id: string; is_read: number }>
  >([]);

  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    apiFetch<{ notifications: typeof notifications }>('/api/notifications')
      .then((d) => setNotifications(d.notifications))
      .catch(() => {});
  }, [activeSection, lastRefreshedAt]);

  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults(null);
      return;
    }
    const timer = setTimeout(() => {
      apiFetch<NonNullable<typeof searchResults>>(`/api/search?q=${encodeURIComponent(searchQuery)}`)
        .then(setSearchResults)
        .catch(() => setSearchResults(null));
    }, 180);
    return () => clearTimeout(timer);
  }, [searchQuery]);

  useEffect(() => {
    const handleOutside = (e: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) {
        setSearchResults(null);
      }
    };
    document.addEventListener('mousedown', handleOutside);
    return () => document.removeEventListener('mousedown', handleOutside);
  }, []);

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  const markRead = async (id: string, targetSection: SectionId, targetId?: string) => {
    await apiFetch(`/api/notifications/${id}/read`, { method: 'POST' }).catch(() => {});
    setNotifications((prev) => prev.map((n) => (n.id === id ? { ...n, is_read: 1 } : n)));
    setShowNotif(false);
    onNavigate(targetSection, targetId);
  };

  const sidebarContent = (
    <div className="flex flex-col h-full bg-gradient-to-b from-[#00389E] via-[#002D86] to-[#001C60] text-white relative overflow-hidden select-none">
      {/* Unilever Brand Lockup (Replaceable SVGs) */}
      <div className="px-6 pt-5 pb-4 flex flex-col items-center border-b border-white/10">
        <img
          src="/assets/brands/unilever-emblem.svg"
          alt="Unilever emblem"
          className="w-16 h-16 object-contain drop-shadow-sm"
        />
        <img
          src="/assets/brands/unilever-wordmark.svg"
          alt="Unilever"
          className="h-7 mt-1 object-contain"
        />
      </div>

      {/* Primary Navigation */}
      <nav aria-label="Primary navigation" className="flex-1 px-3 py-4 space-y-1 overflow-y-auto relative z-10">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              type="button"
              onClick={() => {
                onNavigate(item.id);
                setMobileNavOpen(false);
              }}
              className={`w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-[14px] font-medium transition-all duration-150 whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-white text-[#002D86] font-semibold shadow-md shadow-[#001242]/25'
                  : 'text-white/90 hover:bg-white/12 hover:text-white'
              }`}
            >
              <Icon className={`w-[18px] h-[18px] shrink-0 ${isActive ? 'text-[#0066FF]' : 'text-white/85'}`} />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Bottom Cyan Water-Splash Decorative Flourish (matches reference) */}
      <div className="pointer-events-none relative h-28 shrink-0">
        <svg viewBox="0 0 220 120" className="absolute bottom-0 left-0 w-full h-full" fill="none">
          <path d="M18 112c10-28 32-44 52-36 14 5 12 28-6 36H18z" fill="#00A9E0" opacity="0.45" />
          <path d="M56 105c18-32 48-56 64-44 12 10-4 34-26 44H56z" fill="#29B6F6" opacity="0.6" />
          <path d="M36 64c4-18 19-30 28-23 7 6-3 22-16 26-7 2-13 1-12-3z" fill="#00B8F4" opacity="0.72" />
          <ellipse cx="96" cy="52" rx="7" ry="13" transform="rotate(24 96 52)" fill="#29B6F6" opacity="0.65" />
          <ellipse cx="142" cy="84" rx="9" ry="16" transform="rotate(38 142 84)" fill="#00A9E0" opacity="0.55" />
          <circle cx="122" cy="104" r="7" fill="#38BDF8" opacity="0.55" />
        </svg>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen flex bg-[#F4F8FD] text-[#0F2147]">
      {/* Desktop Fixed Sidebar */}
      <aside className="hidden lg:block w-[224px] shrink-0 sticky top-0 h-screen shadow-lg shadow-[#002266]/10 z-30">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer Sidebar */}
      {mobileNavOpen && (
        <div className="fixed inset-0 z-50 lg:hidden flex">
          <div className="fixed inset-0 bg-[#00174A]/50 backdrop-blur-xs" onClick={() => setMobileNavOpen(false)} />
          <aside className="relative w-64 max-w-[80vw] h-full z-10 shadow-2xl">
            <button
              type="button"
              onClick={() => setMobileNavOpen(false)}
              className="absolute top-3 right-3 p-1.5 rounded-lg bg-white/15 text-white hover:bg-white/25 z-20"
              aria-label="Close navigation"
            >
              <X className="w-5 h-5" />
            </button>
            {sidebarContent}
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 min-w-0 flex flex-col">
        {/* Top Curved Header + Persistent Toolbar */}
        <header className="sticky top-0 z-20 bg-[#F4F8FD]/95 backdrop-blur-sm border-b border-[#DCE8F7]">
          <div className="flex flex-wrap xl:flex-nowrap items-center justify-between gap-3 pr-4 sm:pr-6">
            {/* Curved Unilever Blue Header Banner */}
            <div className="relative flex items-center gap-3 bg-gradient-to-r from-[#003594] via-[#0044B4] to-[#0058D6] text-white pl-4 sm:pl-6 pr-10 py-3.5 rounded-br-[42px] shadow-md shadow-[#003594]/15 shrink-0">
              <button
                type="button"
                onClick={() => setMobileNavOpen(true)}
                className="lg:hidden p-1.5 rounded-lg bg-white/15 hover:bg-white/25 text-white"
                aria-label="Open navigation menu"
              >
                <Menu className="w-5 h-5" />
              </button>
              <div>
                <h1 className="text-[19px] sm:text-[22px] font-bold tracking-tight leading-tight">
                  Retail &amp; Distribution Hub
                </h1>
                <p className="text-[12.5px] text-blue-100/95 font-medium mt-0.5">
                  {market === 'Ireland' ? 'Ireland' : market === 'Great Britain' ? 'Great Britain' : 'United Kingdom'} • Commercial operations
                </p>
              </div>
              {/* Subtle Cyan Splash Accent in Curved Corner */}
              <svg viewBox="0 0 60 50" className="hidden sm:block w-11 h-9 ml-2 opacity-80 shrink-0" fill="none">
                <path d="M10 38c6-14 16-24 22-18 5 5-4 18-16 21-4 1-7 0-6-3z" fill="#00A9E0" />
                <ellipse cx="42" cy="18" rx="4" ry="8" transform="rotate(28 42 18)" fill="#38BDF8" />
                <circle cx="48" cy="36" r="4.5" fill="#00B8F4" />
              </svg>
            </div>

            {/* Right-Hand Operational Toolbar */}
            <div className="flex flex-wrap items-center gap-2 py-2.5 pl-4 xl:pl-0 flex-1 justify-end">
              {/* Global Search */}
              <div ref={searchRef} className="relative w-full sm:w-64 xl:w-72">
                <Search className="w-4 h-4 text-[#5A759E] absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
                <input
                  type="search"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search accounts, orders, products..."
                  aria-label="Global search across accounts, orders, products and shipments"
                  className="w-full h-9 pl-9 pr-3 text-[13px] bg-white border border-[#DCE8F7] rounded-xl text-[#0F2147] placeholder-[#7B92B2] focus:outline-none focus:ring-2 focus:ring-[#0066FF]/30 focus:border-[#0066FF] shadow-2xs"
                />
                {searchResults && (
                  <div className="absolute left-0 right-0 top-11 bg-white border border-[#DCE8F7] rounded-xl shadow-xl p-2 z-50 max-h-80 overflow-y-auto text-[13px]">
                    {searchResults.orders.length === 0 &&
                    searchResults.products.length === 0 &&
                    searchResults.accounts.length === 0 &&
                    searchResults.shipments.length === 0 ? (
                      <div className="px-3 py-4 text-center text-[#5A759E]">No matching records found</div>
                    ) : (
                      <>
                        {searchResults.orders.map((o) => (
                          <button
                            key={o.id}
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              setSearchResults(null);
                              onNavigate('orders', o.id);
                            }}
                            className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#EEF5FF] flex items-center justify-between"
                          >
                            <span className="font-semibold text-[#0F2147]">
                              {o.orderRef} <span className="font-normal text-[#5A759E]">• {o.accountName}</span>
                            </span>
                            <span className="text-[11px] font-medium text-[#0066FF]">{o.operationalFlag}</span>
                          </button>
                        ))}
                        {searchResults.products.map((p) => (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              setSearchResults(null);
                              onNavigate('brands', p.id);
                            }}
                            className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#EEF5FF] flex items-center justify-between"
                          >
                            <span className="font-medium text-[#0F2147]">{p.name}</span>
                            <span className="font-mono text-[11px] text-[#5A759E]">{p.sku}</span>
                          </button>
                        ))}
                        {searchResults.accounts.map((a) => (
                          <button
                            key={a.id}
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              setSearchResults(null);
                              onNavigate('accounts', a.id);
                            }}
                            className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#EEF5FF] flex items-center justify-between"
                          >
                            <span className="font-medium text-[#0F2147]">{a.name}</span>
                            <span className="text-[11px] text-[#5A759E]">{a.channel}</span>
                          </button>
                        ))}
                        {searchResults.shipments.map((s) => (
                          <button
                            key={s.id}
                            type="button"
                            onClick={() => {
                              setSearchQuery('');
                              setSearchResults(null);
                              onNavigate('distribution', s.id);
                            }}
                            className="w-full text-left px-3 py-2 rounded-lg hover:bg-[#EEF5FF] flex items-center justify-between"
                          >
                            <span className="font-medium text-[#0F2147]">
                              {s.shipmentRef} <span className="font-normal text-[#5A759E]">• {s.carrierName}</span>
                            </span>
                            <span className="text-[11px] text-[#0066FF]">{s.status}</span>
                          </button>
                        ))}
                      </>
                    )}
                  </div>
                )}
              </div>

              {/* Market Selector */}
              <div className="relative">
                <select
                  aria-label="Market selector"
                  value={market}
                  onChange={(e) => onMarketChange(e.target.value as MarketScope)}
                  className="h-9 pl-3 pr-7 text-[13px] font-medium bg-white border border-[#DCE8F7] rounded-xl text-[#0F2147] focus:outline-none focus:ring-2 focus:ring-[#0066FF]/30 appearance-none cursor-pointer shadow-2xs"
                >
                  <option value="UK & Ireland">UK &amp; Ireland</option>
                  <option value="Great Britain">Great Britain</option>
                  <option value="Ireland">Ireland</option>
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-[#5A759E] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>

              {/* Reporting Period Selector */}
              <div className="relative">
                <Calendar className="w-3.5 h-3.5 text-[#5A759E] absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
                <select
                  aria-label="Reporting period selector"
                  value={period}
                  onChange={(e) => onPeriodChange(e.target.value as ReportingPeriod)}
                  className="h-9 pl-8 pr-7 text-[13px] font-medium bg-white border border-[#DCE8F7] rounded-xl text-[#0F2147] focus:outline-none focus:ring-2 focus:ring-[#0066FF]/30 appearance-none cursor-pointer shadow-2xs"
                >
                  <option value="2026-11">This month</option>
                  <option value="2026-10">Prior month</option>
                  <option value="2026-Q4">Q4 2026</option>
                </select>
                <ChevronDown className="w-3.5 h-3.5 text-[#5A759E] absolute right-2.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              </div>

              {/* Date & Refresh Status */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => setShowDateInfo((v) => !v)}
                  className="h-9 px-3 flex items-center gap-2 text-[13px] font-medium bg-white border border-[#DCE8F7] rounded-xl text-[#0F2147] hover:bg-[#F7FAFF] cursor-pointer shadow-2xs whitespace-nowrap"
                >
                  <Calendar className="w-3.5 h-3.5 text-[#0066FF]" />
                  <span className="tabular-nums">13 Nov 2026</span>
                </button>
                {showDateInfo && (
                  <div className="absolute right-0 top-11 w-72 bg-white border border-[#DCE8F7] rounded-xl shadow-xl p-3.5 z-50 text-[12.5px]">
                    <div className="flex items-center justify-between font-semibold text-[#0F2147]">
                      <span>Data Refresh Status</span>
                      <span className="text-emerald-700 font-medium">Reconciled</span>
                    </div>
                    <p className="text-[#5A759E] mt-1 tabular-nums">
                      Last synced: {new Date(lastRefreshedAt).toLocaleTimeString('en-GB')}
                    </p>
                    <p className="text-[#5A759E] mt-1">
                      Source: SQLite relational subledger &amp; WMS ledger (synthetic demo data).
                    </p>
                    <button
                      type="button"
                      onClick={() => {
                        onRefresh();
                        setShowDateInfo(false);
                      }}
                      className="mt-2.5 w-full flex items-center justify-center gap-1.5 py-1.5 px-3 bg-[#0066FF] text-white rounded-lg font-medium hover:bg-[#0052CC] cursor-pointer"
                    >
                      <RefreshCw className="w-3.5 h-3.5" />
                      <span>Refresh Operational Figures</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Operations Copilot Button */}
              <button
                type="button"
                onClick={onOpenCopilot}
                className="h-9 px-3 flex items-center gap-1.5 text-[13px] font-semibold bg-[#EAF2FF] text-[#003594] border border-[#C6DCFA] rounded-xl hover:bg-[#DCEBFF] transition-colors cursor-pointer whitespace-nowrap"
                title="Open Operations Copilot"
              >
                <Sparkles className="w-3.5 h-3.5 text-[#0066FF]" />
                <span>Copilot</span>
              </button>

              {/* Notifications */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setShowNotif((v) => !v);
                    setShowUserMenu(false);
                  }}
                  aria-label="Notifications"
                  className="w-9 h-9 flex items-center justify-center bg-white border border-[#DCE8F7] rounded-xl text-[#0F2147] hover:bg-[#F7FAFF] relative cursor-pointer shadow-2xs"
                >
                  <Bell className="w-4 h-4" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-[#E5171F]" />
                  )}
                </button>
                {showNotif && (
                  <div className="absolute right-0 top-11 w-80 bg-white border border-[#DCE8F7] rounded-xl shadow-xl p-3 z-50">
                    <div className="flex items-center justify-between pb-2 border-b border-[#EAF1FA]">
                      <span className="text-[13px] font-semibold text-[#0F2147]">Operational Alerts ({unreadCount} unread)</span>
                    </div>
                    <div className="divide-y divide-[#F0F5FC] max-h-72 overflow-y-auto">
                      {notifications.map((n) => (
                        <button
                          key={n.id}
                          type="button"
                          onClick={() => markRead(n.id, n.target_section, n.target_id)}
                          className={`w-full text-left py-2.5 px-2 rounded-lg hover:bg-[#F4F8FD] transition-colors ${
                            n.is_read ? 'opacity-70' : ''
                          }`}
                        >
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-[12.5px] font-semibold text-[#0F2147]">{n.title}</span>
                            <span className={`text-[11px] font-medium ${n.severity === 'High' ? 'text-amber-700' : 'text-[#0066FF]'}`}>
                              {n.severity}
                            </span>
                          </div>
                          <p className="text-[12px] text-[#5A759E] mt-0.5 line-clamp-2">{n.message}</p>
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* User Profile & Role Switcher + Administration */}
              <div className="relative">
                <button
                  type="button"
                  onClick={() => {
                    setShowUserMenu((v) => !v);
                    setShowNotif(false);
                  }}
                  className="w-9 h-9 rounded-full bg-[#003594] text-white text-[12.5px] font-bold flex items-center justify-center shadow-sm hover:bg-[#002875] cursor-pointer"
                  title={`${activeRole.userDisplayName} (${activeRole.name})`}
                >
                  {activeRole.userInitials}
                </button>
                {showUserMenu && (
                  <div className="absolute right-0 top-11 w-80 bg-white border border-[#DCE8F7] rounded-xl shadow-xl p-3 z-50">
                    <div className="pb-2.5 border-b border-[#EAF1FA]">
                      <div className="text-[13.5px] font-bold text-[#0F2147]">{activeRole.userDisplayName}</div>
                      <div className="text-[12px] text-[#0066FF] font-medium flex items-center gap-1 mt-0.5">
                        <ShieldCheck className="w-3.5 h-3.5" />
                        <span>{activeRole.name}</span>
                      </div>
                      <p className="text-[11.5px] text-[#5A759E] mt-1">{activeRole.description}</p>
                    </div>
                    <div className="py-2">
                      <label className="block text-[11.5px] font-semibold text-[#5A759E] mb-1.5">
                        Switch Active Role (RBAC Scope)
                      </label>
                      <div className="space-y-1 max-h-48 overflow-y-auto">
                        {roles.map((r) => (
                          <button
                            key={r.id}
                            type="button"
                            onClick={() => {
                              onRoleChange(r.id);
                              setShowUserMenu(false);
                            }}
                            className={`w-full text-left px-2.5 py-1.5 rounded-lg text-[12.5px] flex items-center justify-between cursor-pointer ${
                              r.id === activeRole.id
                                ? 'bg-[#EAF2FF] text-[#003594] font-semibold'
                                : 'text-[#0F2147] hover:bg-[#F4F8FD]'
                            }`}
                          >
                            <span>{r.name}</span>
                            <span className="text-[11px] font-mono text-[#5A759E]">{r.permissions.length} perms</span>
                          </button>
                        ))}
                      </div>
                    </div>
                    <div className="pt-2 border-t border-[#EAF1FA] flex flex-col gap-1">
                      <button
                        type="button"
                        onClick={() => {
                          setShowUserMenu(false);
                          onNavigate('admin');
                        }}
                        className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-[13px] font-medium text-[#0F2147] hover:bg-[#F4F8FD] cursor-pointer"
                      >
                        <Settings className="w-4 h-4 text-[#0066FF]" />
                        <span>Administration &amp; Audit Log</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          setShowUserMenu(false);
                          onNavigate('reports');
                        }}
                        className="w-full flex items-center gap-2 px-2.5 py-2 rounded-lg text-[13px] font-medium text-[#0F2147] hover:bg-[#F4F8FD] cursor-pointer"
                      >
                        <BarChart3 className="w-4 h-4 text-[#0066FF]" />
                        <span>API Docs &amp; Reconciliation</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Page Body */}
        <main className="flex-1 px-4 sm:px-6 py-4 max-w-[1440px] w-full mx-auto">
          {children}
        </main>

        {/* Subtle Concept Interface Footer matching screenshot */}
        <footer className="px-6 pb-4 pt-1 max-w-[1440px] w-full mx-auto flex flex-wrap items-center justify-between gap-2 text-[11.5px] text-[#5A759E]">
          <span>Independent Software Concept • No Official Unilever Affiliation</span>
          <span className="font-medium tracking-wide">CONCEPT INTERFACE • SYNTHETIC DEMO DATA</span>
        </footer>
      </div>
    </div>
  );
};
