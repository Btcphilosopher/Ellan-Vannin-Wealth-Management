import React, { useEffect, useState } from 'react';
import { CheckCircle2, Layers, Megaphone, SlidersHorizontal } from 'lucide-react';
import { apiFetch, formatGbp } from '../api';

interface PromotionsPageProps {
  onNotify: (type: 'success' | 'error' | 'info', title: string, detail?: string) => void;
  onRefreshAll: () => void;
}

export const PromotionsPage: React.FC<PromotionsPageProps> = ({ onNotify, onRefreshAll }) => {
  const [promotions, setPromotions] = useState<
    Array<{
      id: string;
      code: string;
      title: string;
      account_id: string;
      account_name: string;
      brand_name: string;
      product_id: string;
      sku: string;
      product_name: string;
      start_date: string;
      end_date: string;
      mechanic: string;
      discount_pct: number;
      precedence_rank: number;
      baseline_weekly_cases: number;
      expected_uplift_pct: number;
      measured_uplift_pct: number | null;
      funding_budget_pence: number;
      actual_cost_pence: number;
      proposed_volume_cases: number;
      actual_volume_cases: number;
      approval_state: string;
      baseline_method: string;
      ai_generated: number;
      unit_cost_pence: number;
      list_price_case_pence: number;
    }>
  >([]);

  // Scenario simulator sliders
  const [simDiscount, setSimDiscount] = useState(18);
  const [simUplift, setSimUplift] = useState(34);
  const [simWeeks, setSimWeeks] = useState(2);
  const [precedenceInfo, setPrecedenceInfo] = useState<{ rule: string; effectiveDiscountPct: number } | null>(null);

  const loadPromos = async () => {
    const res = await apiFetch<{ promotions: typeof promotions }>('/api/promotions');
    setPromotions(res.promotions);
  };

  useEffect(() => {
    loadPromos().catch(() => {});
  }, []);

  const approvePromo = async (id: string, decision: 'APPROVE' | 'REJECT') => {
    try {
      await apiFetch(`/api/promotions/${id}/approve`, {
        method: 'POST',
        body: JSON.stringify({ decision }),
      });
      onNotify('success', `Promotion ${decision === 'APPROVE' ? 'Approved' : 'Returned to Draft'}`);
      await loadPromos();
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'Approval blocked', (err as Error).message);
    }
  };

  const checkPrecedence = async (accountId: string, productId: string) => {
    const res = await apiFetch<{ rule: string; effectiveDiscountPct: number }>('/api/promotions/precedence', {
      method: 'POST',
      body: JSON.stringify({ accountId, productId }),
    });
    setPrecedenceInfo(res);
  };

  // Scenario math on Persil 24-wash baseline (1,950 cases/wk, £16.50 list, £9.80 COGS)
  const baselineCases = 1950 * simWeeks;
  const totalCases = Math.round(baselineCases * (1 + simUplift / 100));
  const incrementalCases = totalCases - baselineCases;
  const netCasePrice = 16.5 * (1 - simDiscount / 100);
  const netRevenue = totalCases * netCasePrice;
  const totalCost = totalCases * 9.8;
  const estContribution = netRevenue - totalCost;

  return (
    <div className="space-y-4">
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-[20px] font-bold text-[#0F2147]">Pricing, Trade Promotions &amp; Precedence Control</h2>
          <p className="text-[13px] text-[#5A759E]">
            Separates forecast uplift from measured uplift, enforces discount precedence rules, and gates AI suggestions behind human approval.
          </p>
        </div>
        <button
          type="button"
          onClick={() => checkPrecedence('acc-morrisons', 'prd-persil-24w')}
          className="h-9 px-3.5 rounded-xl bg-[#EAF2FF] text-[#003594] font-semibold text-[12.5px] hover:bg-[#DCEBFF] flex items-center gap-1.5 cursor-pointer"
        >
          <Layers className="w-4 h-4" />
          <span>Test Morrisons Persil Precedence Rule</span>
        </button>
      </div>

      {precedenceInfo && (
        <div className="bg-[#EEF5FF] border border-[#B8D2F2] rounded-xl px-4 py-3 text-[13px] text-[#0F2147] flex items-center justify-between">
          <span>
            <strong>Precedence Evaluation:</strong> {precedenceInfo.rule} (Effective discount: <strong>{precedenceInfo.effectiveDiscountPct}%</strong>)
          </span>
          <button type="button" onClick={() => setPrecedenceInfo(null)} className="text-[#0055D4] font-semibold text-[12px] cursor-pointer">
            Dismiss
          </button>
        </div>
      )}

      {/* Promotions Grid */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-[12.5px] border-collapse min-w-[960px]">
            <thead>
              <tr className="bg-[#EEF4FC] text-[#475D82] text-[11.5px] font-semibold">
                <th className="text-left py-2.5 px-4">Promotion &amp; Account</th>
                <th className="text-left py-2.5 px-3">SKU &amp; Window</th>
                <th className="text-right py-2.5 px-2">Precedence / Disc</th>
                <th className="text-right py-2.5 px-2">Baseline Wkly</th>
                <th className="text-right py-2.5 px-2">Est. vs Measured Uplift</th>
                <th className="text-right py-2.5 px-2">Funding Budget</th>
                <th className="text-left py-2.5 px-3">State</th>
                <th className="text-right py-2.5 px-4">Approval</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EEF3FA]">
              {promotions.map((pr) => (
                <tr key={pr.id} className="hover:bg-[#F7FAFF]">
                  <td className="py-3 px-4">
                    <div className="font-bold text-[#0F2147] flex items-center gap-1.5">
                      <Megaphone className="w-3.5 h-3.5 text-[#0066FF]" />
                      <span>{pr.title}</span>
                    </div>
                    <div className="text-[11.5px] text-[#5A759E]">
                      {pr.account_name} • {pr.mechanic}
                      {pr.ai_generated === 1 && <span className="ml-1.5 font-semibold text-[#0055D4]">[AI Proposal]</span>}
                    </div>
                  </td>
                  <td className="py-3 px-3">
                    <div className="font-mono font-semibold text-[#0F2147]">{pr.sku}</div>
                    <div className="text-[11.5px] text-[#5A759E] tabular-nums">
                      {pr.start_date} → {pr.end_date}
                    </div>
                  </td>
                  <td className="py-3 px-2 text-right tabular-nums">
                    <span className="font-mono font-bold text-[#0F2147]">P{pr.precedence_rank}</span>
                    <div className="text-[#0055D4] font-semibold">-{pr.discount_pct}%</div>
                  </td>
                  <td className="py-3 px-2 text-right tabular-nums">
                    <div className="font-semibold">{pr.baseline_weekly_cases.toLocaleString()} cs/wk</div>
                    <div className="text-[11px] text-[#5A759E] max-w-[160px] truncate ml-auto" title={pr.baseline_method}>
                      {pr.baseline_method}
                    </div>
                  </td>
                  <td className="py-3 px-2 text-right tabular-nums">
                    <div className="text-[#15803D] font-bold">+{pr.expected_uplift_pct}% (Est.)</div>
                    <div className="text-[11.5px] text-[#5A759E]">
                      {pr.measured_uplift_pct != null ? `+${pr.measured_uplift_pct}% measured` : 'Post-promo pending'}
                    </div>
                  </td>
                  <td className="py-3 px-2 text-right tabular-nums font-semibold">
                    {formatGbp(pr.funding_budget_pence)}
                    <div className="text-[11px] text-[#5A759E] font-normal">Spent {formatGbp(pr.actual_cost_pence)}</div>
                  </td>
                  <td className="py-3 px-3">
                    <span
                      className={`text-[11.5px] font-semibold ${
                        pr.approval_state === 'Active' || pr.approval_state === 'Approved'
                          ? 'text-[#15803D]'
                          : 'text-[#D97706]'
                      }`}
                    >
                      {pr.approval_state}
                    </span>
                  </td>
                  <td className="py-3 px-4 text-right">
                    {pr.approval_state === 'Pending Approval' ? (
                      <div className="inline-flex gap-1.5">
                        <button
                          type="button"
                          onClick={() => approvePromo(pr.id, 'APPROVE')}
                          className="px-2.5 py-1 rounded-lg bg-[#0055D4] text-white text-[11.5px] font-semibold hover:bg-[#003D99] cursor-pointer"
                        >
                          Approve
                        </button>
                        <button
                          type="button"
                          onClick={() => approvePromo(pr.id, 'REJECT')}
                          className="px-2.5 py-1 rounded-lg border border-[#DCE8F7] text-[11.5px] font-semibold hover:bg-[#F4F8FD] cursor-pointer"
                        >
                          Reject
                        </button>
                      </div>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[11.5px] text-[#5A759E]">
                        <CheckCircle2 className="w-3.5 h-3.5 text-[#16A34A]" /> Cleared
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Interactive Promotion Scenario Simulator */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
        <div className="flex items-center gap-2 mb-3">
          <SlidersHorizontal className="w-4.5 h-4.5 text-[#0066FF]" />
          <h3 className="text-[16px] font-bold text-[#0F2147]">Promotion Scenario Simulator (Persil 24-Wash • Estimated Impact)</h3>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div>
            <label className="flex justify-between text-[12.5px] font-semibold mb-1">
              <span>TPR Discount Depth</span>
              <span className="tabular-nums text-[#0055D4]">{simDiscount}%</span>
            </label>
            <input type="range" min={5} max={35} value={simDiscount} onChange={(e) => setSimDiscount(Number(e.target.value))} className="w-full" />
          </div>
          <div>
            <label className="flex justify-between text-[12.5px] font-semibold mb-1">
              <span>Expected Volume Uplift</span>
              <span className="tabular-nums text-[#15803D]">+{simUplift}%</span>
            </label>
            <input type="range" min={5} max={65} value={simUplift} onChange={(e) => setSimUplift(Number(e.target.value))} className="w-full" />
          </div>
          <div>
            <label className="flex justify-between text-[12.5px] font-semibold mb-1">
              <span>Promotion Duration</span>
              <span className="tabular-nums text-[#0F2147]">{simWeeks} weeks</span>
            </label>
            <input type="range" min={1} max={4} value={simWeeks} onChange={(e) => setSimWeeks(Number(e.target.value))} className="w-full" />
          </div>
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 pt-4 border-t border-[#EEF3FA] text-[13px] tabular-nums">
          <div className="bg-[#F8FBFF] rounded-xl p-3 border border-[#DCE8F7]">
            <div className="text-[11.5px] text-[#5A759E]">Estimated Total Volume</div>
            <div className="text-[18px] font-bold text-[#0F2147]">{totalCases.toLocaleString()} cs</div>
          </div>
          <div className="bg-[#F8FBFF] rounded-xl p-3 border border-[#DCE8F7]">
            <div className="text-[11.5px] text-[#5A759E]">Incremental Stock Required</div>
            <div className="text-[18px] font-bold text-[#0055D4]">+{incrementalCases.toLocaleString()} cs</div>
          </div>
          <div className="bg-[#F8FBFF] rounded-xl p-3 border border-[#DCE8F7]">
            <div className="text-[11.5px] text-[#5A759E]">Estimated Net Promo Revenue</div>
            <div className="text-[18px] font-bold text-[#0F2147]">£{Math.round(netRevenue).toLocaleString()}</div>
          </div>
          <div className="bg-[#F8FBFF] rounded-xl p-3 border border-[#DCE8F7]">
            <div className="text-[11.5px] text-[#5A759E]">Est. Gross Contribution (Pre-Fixed)</div>
            <div className="text-[18px] font-bold text-[#15803D]">£{Math.round(estContribution).toLocaleString()}</div>
          </div>
        </div>
      </div>
    </div>
  );
};
