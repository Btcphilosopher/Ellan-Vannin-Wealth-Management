import React, { useEffect, useState } from 'react';
import { AlertTriangle, ArrowRightLeft, Boxes, CheckCircle2, History, ShieldAlert, X } from 'lucide-react';
import { apiFetch } from '../api';

interface InventoryPageProps {
  focusId?: string;
  onNotify: (type: 'success' | 'error' | 'info', title: string, detail?: string) => void;
  onRefreshAll: () => void;
}

export const InventoryPage: React.FC<InventoryPageProps> = ({ focusId, onNotify, onRefreshAll }) => {
  const [batches, setBatches] = useState<
    Array<{
      id: string;
      product_id: string;
      sku: string;
      product_name: string;
      location_id: string;
      location_name: string;
      batch_number: string;
      expiry_date: string;
      status: string;
      on_hand_cases: number;
      reserved_cases: number;
      available_cases: number;
      quarantined_cases: number;
      damaged_cases: number;
      expired_cases: number;
      in_transit_cases: number;
    }>
  >([]);
  const [movements, setMovements] = useState<
    Array<{ id: string; sku: string; product_name: string; location_name: string; movement_type: string; cases_delta: number; reference_id: string; notes: string; created_at: string }>
  >([]);
  const [exceptions, setExceptions] = useState<
    Array<{
      id: string;
      product_id: string;
      sku: string;
      product_name: string;
      location_id: string;
      location_name: string;
      severity: string;
      title: string;
      subtitle: string;
      days_cover: number;
      demand_basis: string;
      recommended_action: string;
      status: string;
    }>
  >([]);
  const [locations, setLocations] = useState<Array<{ id: string; name: string }>>([]);
  const [products, setProducts] = useState<Array<{ id: string; sku: string; name: string }>>([]);
  const [tab, setTab] = useState<'batches' | 'exceptions' | 'movements'>('batches');
  const [filterSku, setFilterSku] = useState<string>('all');
  const [traceData, setTraceData] = useState<{
    batch: { id: string; batch_number: string; sku: string; product_name: string; location_name: string; expiry_date: string; status: string };
    movements: Array<{ movement_type: string; cases_delta: number; reference_id: string; created_at: string }>;
    affectedReservations: Array<{ order_ref: string; account_name: string; cases_reserved: number; order_status: string }>;
  } | null>(null);

  // Transfer form state
  const [xferProduct, setXferProduct] = useState('prd-persil-24w');
  const [xferFrom, setXferFrom] = useState('loc-mk');
  const [xferTo, setXferTo] = useState('loc-leeds');
  const [xferCases, setXferCases] = useState('1460');

  const loadInventory = async () => {
    const res = await apiFetch<{
      batches: typeof batches;
      movements: typeof movements;
      exceptions: typeof exceptions;
      locations: typeof locations;
      products: typeof products;
    }>('/api/inventory');
    setBatches(res.batches);
    setMovements(res.movements);
    setExceptions(res.exceptions);
    setLocations(res.locations);
    setProducts(res.products);
  };

  useEffect(() => {
    loadInventory().catch(() => {});
  }, []);

  useEffect(() => {
    if (!focusId) return;
    if (focusId === 'exceptions') setTab('exceptions');
    else if (focusId.startsWith('prd-')) {
      setTab('batches');
      setFilterSku(focusId);
    }
  }, [focusId]);

  const handleTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await apiFetch('/api/inventory/transfer', {
        method: 'POST',
        body: JSON.stringify({
          productId: xferProduct,
          fromLocationId: xferFrom,
          toLocationId: xferTo,
          cases: Number(xferCases),
          resolveExceptionId: xferProduct === 'prd-persil-24w' && xferTo === 'loc-leeds' ? 'exc-1' : undefined,
        }),
      });
      onNotify('success', 'Inter-DC Transfer Completed', `Transferred ${xferCases} cases to ${xferTo}.`);
      await loadInventory();
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'Transfer failed', (err as Error).message);
    }
  };

  const handleBatchAction = async (batchId: string, adjustmentType: 'GOODS_RECEIPT' | 'RELEASE_QUARANTINE') => {
    try {
      await apiFetch('/api/inventory/adjust', {
        method: 'POST',
        body: JSON.stringify({ batchId, adjustmentType, cases: 100, reason: 'Operational adjustment via Inventory Workbench' }),
      });
      onNotify('success', `Batch ${adjustmentType} recorded (+100 cases)`);
      await loadInventory();
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'Adjustment rejected', (err as Error).message);
    }
  };

  const openTrace = async (batchId: string) => {
    try {
      const res = await apiFetch<NonNullable<typeof traceData>>(`/api/inventory/batches/${batchId}/trace`);
      setTraceData(res);
    } catch (err) {
      onNotify('error', 'Unable to trace batch', (err as Error).message);
    }
  };

  const triggerRecall = async (batchId: string) => {
    try {
      await apiFetch(`/api/inventory/batches/${batchId}/recall`, { method: 'POST' });
      onNotify('info', 'Simulated Withdrawal Executed', 'Batch quarantined and excluded from all future FEFO allocations.');
      await loadInventory();
      await openTrace(batchId);
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'Recall blocked', (err as Error).message);
    }
  };

  const visibleBatches = batches.filter((b) => filterSku === 'all' || b.product_id === filterSku);
  const totals = visibleBatches.reduce(
    (acc, b) => ({
      onHand: acc.onHand + b.on_hand_cases,
      reserved: acc.reserved + b.reserved_cases,
      available: acc.available + b.available_cases,
      quarantined: acc.quarantined + b.quarantined_cases,
      damaged: acc.damaged + b.damaged_cases,
      expired: acc.expired + b.expired_cases,
      inTransit: acc.inTransit + b.in_transit_cases,
    }),
    { onHand: 0, reserved: 0, available: 0, quarantined: 0, damaged: 0, expired: 0, inTransit: 0 }
  );

  return (
    <div className="space-y-4">
      {/* Summary Stock Buckets */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-3">
        {[
          { label: 'On-Hand', val: totals.onHand, tone: 'text-[#0F2147]' },
          { label: 'Reserved', val: totals.reserved, tone: 'text-[#0055D4]' },
          { label: 'Available (ATP)', val: totals.available, tone: 'text-[#15803D]' },
          { label: 'Quarantined', val: totals.quarantined, tone: 'text-[#D97706]' },
          { label: 'Damaged', val: totals.damaged, tone: 'text-[#DC2626]' },
          { label: 'Expired (Blocked)', val: totals.expired, tone: 'text-[#DC2626]' },
          { label: 'In Transit', val: totals.inTransit, tone: 'text-[#0055D4]' },
        ].map((b) => (
          <div key={b.label} className="bg-white border border-[#DCE8F7] rounded-xl p-3 shadow-2xs">
            <div className="text-[11.5px] font-medium text-[#5A759E]">{b.label}</div>
            <div className={`text-[20px] font-bold tabular-nums mt-0.5 ${b.tone}`}>{b.val.toLocaleString()} cs</div>
          </div>
        ))}
      </div>

      {/* Controls & Inter-DC Transfer Bar */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-1 p-1 bg-[#F4F8FD] rounded-xl">
          {[
            { id: 'batches', label: 'FEFO Batch Ledger', icon: Boxes },
            { id: 'exceptions', label: `Supply Exceptions (${exceptions.filter((e) => e.status !== 'RESOLVED').length})`, icon: AlertTriangle },
            { id: 'movements', label: 'Movement Audit Ledger', icon: History },
          ].map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                type="button"
                onClick={() => setTab(t.id as typeof tab)}
                className={`px-3 py-1.5 rounded-lg text-[12.5px] font-semibold flex items-center gap-1.5 cursor-pointer ${
                  tab === t.id ? 'bg-white text-[#003594] shadow-2xs' : 'text-[#5A759E] hover:text-[#0F2147]'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        <form onSubmit={handleTransfer} className="flex flex-wrap items-center gap-2 text-[12.5px]">
          <span className="font-semibold text-[#0F2147] flex items-center gap-1">
            <ArrowRightLeft className="w-3.5 h-3.5 text-[#0066FF]" />
            Inter-DC Transfer:
          </span>
          <select value={xferProduct} onChange={(e) => setXferProduct(e.target.value)} className="h-8 px-2 border border-[#DCE8F7] rounded-lg bg-[#F8FBFF]">
            {products.map((p) => (
              <option key={p.id} value={p.id}>
                {p.sku}
              </option>
            ))}
          </select>
          <select value={xferFrom} onChange={(e) => setXferFrom(e.target.value)} className="h-8 px-2 border border-[#DCE8F7] rounded-lg bg-[#F8FBFF]">
            {locations.map((l) => (
              <option key={l.id} value={l.id}>
                From {l.name}
              </option>
            ))}
          </select>
          <select value={xferTo} onChange={(e) => setXferTo(e.target.value)} className="h-8 px-2 border border-[#DCE8F7] rounded-lg bg-[#F8FBFF]">
            {locations.map((l) => (
              <option key={l.id} value={l.id}>
                To {l.name}
              </option>
            ))}
          </select>
          <input
            type="number"
            value={xferCases}
            onChange={(e) => setXferCases(e.target.value)}
            className="w-20 h-8 px-2 border border-[#DCE8F7] rounded-lg tabular-nums"
          />
          <button type="submit" className="h-8 px-3 bg-[#0055D4] text-white rounded-lg font-semibold hover:bg-[#003D99] cursor-pointer">
            Execute Transfer
          </button>
        </form>
      </div>

      {/* Tab Content */}
      {tab === 'batches' && (
        <div className="bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-[15px] font-bold text-[#0F2147]">Inventory by SKU, Batch &amp; Warehouse Location (FEFO Sorted)</h3>
            <select
              value={filterSku}
              onChange={(e) => setFilterSku(e.target.value)}
              className="h-8 px-3 text-[12.5px] border border-[#DCE8F7] rounded-lg bg-[#F8FBFF]"
            >
              <option value="all">All SKUs</option>
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.sku} — {p.name}
                </option>
              ))}
            </select>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-[12.5px] border-collapse min-w-[920px]">
              <thead>
                <tr className="bg-[#EEF4FC] text-[#475D82] text-[11.5px] font-semibold">
                  <th className="text-left py-2 px-3">Batch / SKU</th>
                  <th className="text-left py-2 px-3">Location</th>
                  <th className="text-left py-2 px-3">Expiry (FEFO)</th>
                  <th className="text-left py-2 px-3">Batch State</th>
                  <th className="text-right py-2 px-2">On-Hand</th>
                  <th className="text-right py-2 px-2">Reserved</th>
                  <th className="text-right py-2 px-2">Available</th>
                  <th className="text-right py-2 px-2">Quar / Exp / Tr</th>
                  <th className="text-right py-2 px-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EEF3FA]">
                {visibleBatches.map((b) => (
                  <tr key={b.id} className="hover:bg-[#F7FAFF]">
                    <td className="py-2.5 px-3">
                      <div className="font-mono font-bold text-[#0F2147]">{b.batch_number}</div>
                      <div className="text-[11.5px] text-[#5A759E]">
                        {b.sku} • {b.product_name}
                      </div>
                    </td>
                    <td className="py-2.5 px-3 font-medium">{b.location_name}</td>
                    <td className="py-2.5 px-3 tabular-nums">{b.expiry_date}</td>
                    <td className="py-2.5 px-3">
                      <span
                        className={`text-[11.5px] font-semibold ${
                          b.status === 'AVAILABLE'
                            ? 'text-[#15803D]'
                            : b.status === 'IN_TRANSIT'
                              ? 'text-[#0055D4]'
                              : 'text-[#DC2626]'
                        }`}
                      >
                        {b.status}
                      </span>
                    </td>
                    <td className="py-2.5 px-2 text-right tabular-nums">{b.on_hand_cases.toLocaleString()}</td>
                    <td className="py-2.5 px-2 text-right tabular-nums text-[#0055D4]">{b.reserved_cases.toLocaleString()}</td>
                    <td className="py-2.5 px-2 text-right tabular-nums font-bold text-[#15803D]">{b.available_cases.toLocaleString()}</td>
                    <td className="py-2.5 px-2 text-right tabular-nums text-[#5A759E]">
                      {b.quarantined_cases} / {b.expired_cases} / {b.in_transit_cases}
                    </td>
                    <td className="py-2.5 px-3 text-right space-x-1.5 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => openTrace(b.id)}
                        className="px-2 py-1 rounded-md border border-[#C6DCFA] text-[#0055D4] font-semibold text-[11.5px] hover:bg-[#EEF5FF] cursor-pointer"
                      >
                        Trace / Recall
                      </button>
                      {b.status === 'AVAILABLE' && (
                        <button
                          type="button"
                          onClick={() => handleBatchAction(b.id, 'GOODS_RECEIPT')}
                          className="px-2 py-1 rounded-md bg-[#EEF5FF] text-[#003594] font-semibold text-[11.5px] hover:bg-[#DCEBFF] cursor-pointer"
                        >
                          +100 Receipt
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {tab === 'exceptions' && (
        <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs space-y-2">
          <h3 className="text-[16px] font-bold text-[#0F2147] mb-2">All Stock Alerts &amp; Supply Exceptions</h3>
          <div className="divide-y divide-[#EEF3FA]">
            {exceptions.map((e) => (
              <div key={e.id} className="py-3 flex flex-wrap items-center justify-between gap-3 text-[13px]">
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    {e.status === 'RESOLVED' ? (
                      <CheckCircle2 className="w-4 h-4 text-[#16A34A]" />
                    ) : (
                      <AlertTriangle className={`w-4 h-4 ${e.severity === 'High' ? 'text-[#DC2626]' : 'text-[#D97706]'}`} />
                    )}
                    <span className="font-bold text-[#0F2147]">{e.title}</span>
                    <span className="text-[11.5px] font-mono text-[#5A759E]">{e.sku}</span>
                  </div>
                  <div className="text-[#475D82] mt-0.5">{e.subtitle}</div>
                  <div className="text-[11.5px] text-[#5A759E] mt-0.5">
                    Demand basis: {e.demand_basis} • Recommended: {e.recommended_action}
                  </div>
                </div>
                <span className="text-[12px] font-semibold tabular-nums px-2.5 py-1 rounded-lg bg-[#F4F8FD] text-[#0F2147]">
                  {e.days_cover != null ? `${e.days_cover} days cover` : 'N/A'} • {e.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {tab === 'movements' && (
        <div className="bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs overflow-x-auto">
          <table className="w-full text-[12.5px] border-collapse">
            <thead>
              <tr className="bg-[#EEF4FC] text-[#475D82] text-[11.5px] font-semibold">
                <th className="text-left py-2 px-3">Timestamp</th>
                <th className="text-left py-2 px-3">Type</th>
                <th className="text-left py-2 px-3">SKU</th>
                <th className="text-left py-2 px-3">Location</th>
                <th className="text-right py-2 px-3">Delta Cases</th>
                <th className="text-left py-2 px-3">Reference</th>
                <th className="text-left py-2 px-3">Notes</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EEF3FA]">
              {movements.map((m) => (
                <tr key={m.id}>
                  <td className="py-2 px-3 font-mono text-[11.5px] text-[#5A759E]">{m.created_at.slice(0, 19).replace('T', ' ')}</td>
                  <td className="py-2 px-3 font-semibold text-[#0055D4]">{m.movement_type}</td>
                  <td className="py-2 px-3 font-mono">{m.sku}</td>
                  <td className="py-2 px-3">{m.location_name}</td>
                  <td className={`py-2 px-3 text-right font-bold tabular-nums ${m.cases_delta >= 0 ? 'text-[#15803D]' : 'text-[#0F2147]'}`}>
                    {m.cases_delta > 0 ? `+${m.cases_delta}` : m.cases_delta}
                  </td>
                  <td className="py-2 px-3 font-mono">{m.reference_id}</td>
                  <td className="py-2 px-3 text-[#5A759E]">{m.notes}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Batch Traceability & Simulated Withdrawal Modal */}
      {traceData && (
        <div className="fixed inset-0 z-50 bg-[#00174A]/45 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#DCE8F7] rounded-2xl shadow-2xl max-w-2xl w-full p-5 space-y-4">
            <div className="flex items-start justify-between border-b border-[#EAF1FA] pb-3">
              <div>
                <h3 className="text-[17px] font-bold text-[#0F2147]">Batch Traceability &amp; Simulated Withdrawal</h3>
                <p className="text-[12.5px] text-[#5A759E] font-mono">
                  {traceData.batch.batch_number} • {traceData.batch.sku} • {traceData.batch.location_name} • Status: {traceData.batch.status}
                </p>
              </div>
              <button type="button" onClick={() => setTraceData(null)} className="p-1 text-[#5A759E] hover:text-[#0F2147] cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3 text-[12.5px]">
              <div>
                <h4 className="font-bold text-[#0F2147] mb-1">Ledger Chain (Receipt → Transfers → Reservations)</h4>
                <div className="border border-[#DCE8F7] rounded-xl divide-y divide-[#EEF3FA] max-h-40 overflow-y-auto">
                  {traceData.movements.map((m, i) => (
                    <div key={i} className="px-3 py-1.5 flex justify-between">
                      <span className="font-semibold">{m.movement_type}</span>
                      <span className="font-mono">{m.reference_id}</span>
                      <span className="tabular-nums font-bold">{m.cases_delta} cs</span>
                    </div>
                  ))}
                  {traceData.movements.length === 0 && <div className="px-3 py-2 text-[#5A759E]">No movement events logged.</div>}
                </div>
              </div>
              <div>
                <h4 className="font-bold text-[#0F2147] mb-1">Affected Customer Orders &amp; Shipments</h4>
                <div className="border border-[#DCE8F7] rounded-xl divide-y divide-[#EEF3FA]">
                  {traceData.affectedReservations.map((r, i) => (
                    <div key={i} className="px-3 py-1.5 flex justify-between">
                      <span className="font-semibold">
                        {r.order_ref} • {r.account_name}
                      </span>
                      <span className="tabular-nums">
                        {r.cases_reserved} cs ({r.order_status})
                      </span>
                    </div>
                  ))}
                  {traceData.affectedReservations.length === 0 && (
                    <div className="px-3 py-2 text-[#5A759E]">No customer deliveries or active reservations linked.</div>
                  )}
                </div>
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2 border-t border-[#EAF1FA]">
              <button
                type="button"
                onClick={() => triggerRecall(traceData.batch.id)}
                className="px-3.5 py-2 rounded-xl bg-[#DC2626] text-white text-[12.5px] font-semibold flex items-center gap-1.5 hover:bg-[#B91C1C] cursor-pointer"
              >
                <ShieldAlert className="w-4 h-4" />
                <span>Execute Simulated Withdrawal Hold</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
