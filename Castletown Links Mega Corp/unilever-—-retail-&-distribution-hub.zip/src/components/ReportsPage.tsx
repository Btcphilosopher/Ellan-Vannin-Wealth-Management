import React, { useEffect, useState } from 'react';
import { BookOpen, CheckCircle2, Download, Plug } from 'lucide-react';
import { apiFetch, formatGbpMillions } from '../api';
import type { OverviewResponse } from '../types';

interface ReportsPageProps {
  overview: OverviewResponse | null;
  onNotify: (type: 'success' | 'error' | 'info', title: string, detail?: string) => void;
}

export const ReportsPage: React.FC<ReportsPageProps> = ({ overview, onNotify }) => {
  const [docs, setDocs] = useState<{
    info: { title: string; version: string };
    endpoints: Array<{ method: string; path: string; desc: string }>;
  } | null>(null);

  useEffect(() => {
    apiFetch<NonNullable<typeof docs>>('/api/docs').then(setDocs).catch(() => {});
  }, []);

  const exportCsv = () => {
    if (!overview) return;
    const rows = [
      ['Brand', 'NetSalesGBP', 'VsPlanPct', 'AvailabilityPct'],
      ...overview.brandPerformance.map((b) => [b.brandName, (b.netSalesPence / 100).toFixed(2), `${b.vsPlanPct}%`, `${b.availabilityPct}%`]),
    ];
    const csv = rows.map((r) => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `retail-hub-reconciliation-${overview.period}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    onNotify('success', 'CSV Report Exported', `Exported brand reconciliation for ${overview.period}.`);
  };

  const adapters = [
    { name: 'ERP Core (SAP S/4HANA Interface)', status: 'Simulated Adapter', detail: 'In-process SQLite subledger & invoice sync (no proprietary credentials claimed)' },
    { name: 'Warehouse Management (WMS)', status: 'Simulated Adapter', detail: 'Transactional FEFO batch reservation & movement ledger in SQLite WAL' },
    { name: 'Retailer EDI (EDIFACT ORDERS / ORDRSP)', status: 'Simulated Adapter', detail: 'Idempotent JSON/EDIFACT gateway deduplicated via edi_inbox' },
    { name: 'Carrier Telemetry Feed', status: 'Simulated / Stale Flagged', detail: 'Synthetic GPS ETA stream explicitly distinguished from confirmed POD' },
    { name: 'Accounting & Banking (BACS)', status: 'Simulated Adapter', detail: 'Double-entry journal generator & simulated BACS cash allocation' },
    { name: 'Operations Copilot AI', status: 'Gemini 4 Hydrogen + Mock Fallback', detail: 'Uses server-side GEMINI_API_KEY when present; deterministic mock adapter otherwise' },
  ];

  return (
    <div className="space-y-4">
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-[20px] font-bold text-[#0F2147]">Executive Reports, Reconciliation &amp; API Docs</h2>
          <p className="text-[13px] text-[#5A759E]">
            Cross-check brand and channel totals against underlying records, export CSV extracts, and inspect adapter boundaries.
          </p>
        </div>
        <button
          type="button"
          onClick={exportCsv}
          className="h-9 px-4 rounded-xl bg-[#0055D4] text-white text-[13px] font-semibold hover:bg-[#003D99] flex items-center gap-1.5 cursor-pointer"
        >
          <Download className="w-4 h-4" />
          <span>Export Brand Reconciliation CSV</span>
        </button>
      </div>

      {/* Reconciliation Verification */}
      {overview && (
        <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs space-y-3">
          <div className="flex items-center gap-2 text-[15px] font-bold text-[#0F2147]">
            <CheckCircle2 className="w-4.5 h-4.5 text-[#16A34A]" />
            <span>Live Dashboard Reconciliation ({overview.market} • {overview.period})</span>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-[13px] tabular-nums">
            <div className="p-3.5 rounded-xl bg-[#F8FBFF] border border-[#DCE8F7]">
              <div className="text-[#5A759E]">Total KPI Net Sales</div>
              <div className="text-[20px] font-bold text-[#0F2147]">{formatGbpMillions(overview.kpis.netSalesPence)}</div>
            </div>
            <div className="p-3.5 rounded-xl bg-[#F8FBFF] border border-[#DCE8F7]">
              <div className="text-[#5A759E]">Sum of 5 Brand Rows</div>
              <div className="text-[20px] font-bold text-[#15803D]">
                {formatGbpMillions(overview.brandPerformance.reduce((s, b) => s + b.netSalesPence, 0))}
              </div>
            </div>
            <div className="p-3.5 rounded-xl bg-[#F8FBFF] border border-[#DCE8F7]">
              <div className="text-[#5A759E]">Sum of 4 Channel Bars</div>
              <div className="text-[20px] font-bold text-[#15803D]">
                {formatGbpMillions(overview.salesByChannel.reduce((s, c) => s + c.netSalesPence, 0))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Integration Interfaces */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
        <h3 className="text-[16px] font-bold text-[#0F2147] flex items-center gap-2 mb-3">
          <Plug className="w-4.5 h-4.5 text-[#0066FF]" />
          Integration Adapter Boundaries (Independent Concept Simulation)
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-[12.5px]">
          {adapters.map((ad) => (
            <div key={ad.name} className="p-3 rounded-xl border border-[#DCE8F7] bg-[#FAFBFD]">
              <div className="flex items-center justify-between">
                <span className="font-bold text-[#0F2147]">{ad.name}</span>
                <span className="text-[11px] font-semibold text-[#0055D4]">{ad.status}</span>
              </div>
              <p className="text-[#5A759E] mt-1">{ad.detail}</p>
            </div>
          ))}
        </div>
      </div>

      {/* API Docs */}
      {docs && (
        <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
          <h3 className="text-[16px] font-bold text-[#0F2147] flex items-center gap-2 mb-3">
            <BookOpen className="w-4.5 h-4.5 text-[#0066FF]" />
            REST API Reference ({docs.info.title} v{docs.info.version})
          </h3>
          <div className="divide-y divide-[#EEF3FA] text-[12.5px]">
            {docs.endpoints.map((ep) => (
              <div key={ep.path} className="py-2 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2.5">
                  <span className="font-mono text-[11px] font-bold px-2 py-0.5 rounded bg-[#EEF5FF] text-[#0055D4]">{ep.method}</span>
                  <span className="font-mono font-semibold text-[#0F2147]">{ep.path}</span>
                </div>
                <span className="text-[#5A759E]">{ep.desc}</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
