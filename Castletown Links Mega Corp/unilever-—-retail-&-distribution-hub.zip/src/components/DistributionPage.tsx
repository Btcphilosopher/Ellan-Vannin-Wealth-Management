import React, { useEffect, useState } from 'react';
import { CheckCircle2, Clock, Radio, Truck, X } from 'lucide-react';
import { apiFetch } from '../api';

interface DistributionPageProps {
  focusId?: string;
  onNotify: (type: 'success' | 'error' | 'info', title: string, detail?: string) => void;
  onRefreshAll: () => void;
}

export const DistributionPage: React.FC<DistributionPageProps> = ({ focusId, onNotify, onRefreshAll }) => {
  const [shipments, setShipments] = useState<
    Array<{
      id: string;
      shipment_ref: string;
      order_id: string;
      order_ref: string;
      ordered_cases: number;
      account_name: string;
      account_logo_url: string;
      origin_name: string;
      destination_name: string;
      postcode: string;
      carrier_name: string;
      vehicle_reg: string;
      vehicle_capacity_pallets: number;
      loaded_pallets: number;
      delivery_window: string;
      status: string;
      tracking_feed_status: string;
      estimated_arrival: string;
      confirmed_delivery_at: string | null;
      dispatched_cases: number;
      delivered_cases: number;
      shortage_cases: number;
      damaged_cases: number;
      rejected_cases: number;
      pod_notes: string;
    }>
  >([]);
  const [metrics, setMetrics] = useState<{
    orderFillRatePct: number;
    fillNumerator: number;
    fillDenominator: number;
    onTimeDeliveryPct: number;
    otdNumerator: number;
    otdDenominator: number;
    period: string;
  } | null>(null);
  const [podModal, setPodModal] = useState<(typeof shipments)[0] | null>(null);
  const [deliveredCases, setDeliveredCases] = useState('');
  const [damagedCases, setDamagedCases] = useState('0');
  const [onTime, setOnTime] = useState(true);
  const [podNotes, setPodNotes] = useState('Signed POD with gatehouse variance note');

  const loadData = async () => {
    const res = await apiFetch<{ shipments: typeof shipments; serviceMetrics: typeof metrics }>('/api/distribution');
    setShipments(res.shipments);
    setMetrics(res.serviceMetrics);
  };

  useEffect(() => {
    loadData().catch(() => {});
  }, []);

  useEffect(() => {
    if (!focusId || shipments.length === 0) return;
    const match = shipments.find((s) => s.id === focusId || s.order_id === focusId);
    if (match && match.status === 'In Transit') {
      openPod(match);
    }
  }, [focusId, shipments.length]);

  const openPod = (s: (typeof shipments)[0]) => {
    setPodModal(s);
    // Default slightly lower for demonstration partial delivery if > 2000 cases, else full
    setDeliveredCases(String(s.dispatched_cases >= 2500 ? s.dispatched_cases - 180 : s.dispatched_cases));
    setDamagedCases('0');
    setOnTime(true);
  };

  const submitPod = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!podModal) return;
    try {
      const res = await apiFetch<{ status: string; deliveredCases: number; shortageCases: number }>(`/api/shipments/${podModal.id}/pod`, {
        method: 'POST',
        body: JSON.stringify({
          deliveredCases: Number(deliveredCases),
          damagedCases: Number(damagedCases),
          onTime,
          podNotes,
        }),
      });
      onNotify(
        res.shortageCases > 0 ? 'info' : 'success',
        `POD Recorded (${res.status})`,
        `Delivered ${res.deliveredCases.toLocaleString()} cases, shortage ${res.shortageCases} cases. Ready for delivered-quantity invoicing.`
      );
      setPodModal(null);
      await loadData();
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'POD submission failed', (err as Error).message);
    }
  };

  return (
    <div className="space-y-4">
      {/* Service Metric Definitions */}
      {metrics && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs">
            <div className="text-[12.5px] font-semibold text-[#5A759E]">Order Fill Rate Definition ({metrics.period})</div>
            <div className="text-[24px] font-bold text-[#0F2147] tabular-nums mt-0.5">{metrics.orderFillRatePct}%</div>
            <div className="text-[12.5px] text-[#475D82] mt-1 tabular-nums">
              Calculation: <strong>{metrics.fillNumerator.toLocaleString()}</strong> filled cases ÷{' '}
              <strong>{metrics.fillDenominator.toLocaleString()}</strong> ordered cases (case-level basis)
            </div>
          </div>
          <div className="bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs">
            <div className="text-[12.5px] font-semibold text-[#5A759E]">On-Time Delivery Definition ({metrics.period})</div>
            <div className="text-[24px] font-bold text-[#0F2147] tabular-nums mt-0.5">{metrics.onTimeDeliveryPct}%</div>
            <div className="text-[12.5px] text-[#475D82] mt-1 tabular-nums">
              Calculation: <strong>{metrics.otdNumerator}</strong> on-time confirmed PODs ÷{' '}
              <strong>{metrics.otdDenominator}</strong> confirmed deliveries within booking window
            </div>
          </div>
        </div>
      )}

      {/* Shipments Table */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs">
        <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
          <div>
            <h2 className="text-[18px] font-bold text-[#0F2147]">Distribution &amp; Carrier Shipments</h2>
            <p className="text-[12.5px] text-[#5A759E]">
              Synthetic tracking feeds are explicitly marked (Simulated / Stale). Estimated arrival is never presented as confirmed POD.
            </p>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-[12.5px] border-collapse min-w-[980px]">
            <thead>
              <tr className="bg-[#EEF4FC] text-[#475D82] text-[11.5px] font-semibold">
                <th className="text-left py-2.5 px-3">Shipment / Order</th>
                <th className="text-left py-2.5 px-3">Route &amp; Window</th>
                <th className="text-left py-2.5 px-3">Carrier &amp; Vehicle Load</th>
                <th className="text-left py-2.5 px-3">Tracking Feed</th>
                <th className="text-left py-2.5 px-3">Arrival / Confirmed POD</th>
                <th className="text-right py-2.5 px-3">Disp / Deliv / Short</th>
                <th className="text-right py-2.5 px-3">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EEF3FA]">
              {shipments.map((s) => {
                const utilPct = Math.round((s.loaded_pallets / Math.max(1, s.vehicle_capacity_pallets)) * 100);
                return (
                  <tr key={s.id} className="hover:bg-[#F7FAFF]">
                    <td className="py-3 px-3">
                      <div className="font-mono font-bold text-[#0F2147]">{s.shipment_ref}</div>
                      <div className="text-[11.5px] text-[#5A759E]">
                        {s.order_ref} • {s.account_name}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-medium text-[#0F2147]">
                        {s.origin_name} → {s.destination_name}
                      </div>
                      <div className="text-[11.5px] text-[#5A759E]">
                        {s.postcode} • Window {s.delivery_window}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-semibold text-[#0F2147]">{s.carrier_name}</div>
                      <div className="text-[11.5px] text-[#5A759E] tabular-nums">
                        {s.vehicle_reg} • {s.loaded_pallets}/{s.vehicle_capacity_pallets} pallets ({utilPct}%)
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <span
                        className={`inline-flex items-center gap-1 text-[11.5px] font-semibold ${
                          s.tracking_feed_status === 'Simulated' ? 'text-[#0055D4]' : 'text-[#D97706]'
                        }`}
                      >
                        <Radio className="w-3.5 h-3.5" />
                        {s.tracking_feed_status}
                      </span>
                      <div className="text-[11.5px] text-[#5A759E]">{s.status}</div>
                    </td>
                    <td className="py-3 px-3 tabular-nums">
                      {s.confirmed_delivery_at ? (
                        <div className="text-[#15803D] font-semibold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>POD: {s.confirmed_delivery_at.slice(0, 16).replace('T', ' ')}</span>
                        </div>
                      ) : (
                        <div className="text-[#475D82] flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5" />
                          <span>Est: {s.estimated_arrival.slice(0, 16).replace('T', ' ')} (Unconfirmed)</span>
                        </div>
                      )}
                    </td>
                    <td className="py-3 px-3 text-right tabular-nums">
                      <span className="font-semibold">{s.dispatched_cases.toLocaleString()}</span> /{' '}
                      <span className="font-bold text-[#15803D]">{s.delivered_cases.toLocaleString()}</span> /{' '}
                      <span className={s.shortage_cases > 0 ? 'text-[#DC2626] font-bold' : 'text-[#5A759E]'}>
                        {s.shortage_cases.toLocaleString()}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right">
                      {s.status === 'In Transit' && (
                        <button
                          type="button"
                          onClick={() => openPod(s)}
                          className="px-3 py-1.5 rounded-lg bg-[#0055D4] text-white text-[12px] font-semibold hover:bg-[#003D99] cursor-pointer whitespace-nowrap"
                        >
                          Record POD
                        </button>
                      )}
                      {s.status !== 'In Transit' && (
                        <span className="text-[11.5px] text-[#5A759E] inline-flex items-center gap-1">
                          <Truck className="w-3.5 h-3.5" /> {s.status}
                        </span>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Record POD Modal */}
      {podModal && (
        <div className="fixed inset-0 z-50 bg-[#00174A]/45 backdrop-blur-xs flex items-center justify-center p-4">
          <form onSubmit={submitPod} className="bg-white border border-[#DCE8F7] rounded-2xl shadow-2xl max-w-md w-full p-5 space-y-4">
            <div className="flex items-center justify-between border-b border-[#EAF1FA] pb-3">
              <div>
                <h3 className="text-[17px] font-bold text-[#0F2147]">Record Proof of Delivery ({podModal.shipment_ref})</h3>
                <p className="text-[12px] text-[#5A759E]">
                  Dispatched: {podModal.dispatched_cases.toLocaleString()} cases • {podModal.destination_name}
                </p>
              </div>
              <button type="button" onClick={() => setPodModal(null)} className="text-[#5A759E] hover:text-[#0F2147]">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="space-y-3 text-[13px]">
              <div>
                <label className="block font-semibold text-[#0F2147] mb-1">Confirmed Delivered Cases (Partial allowed)</label>
                <input
                  type="number"
                  min={0}
                  max={podModal.dispatched_cases}
                  value={deliveredCases}
                  onChange={(e) => setDeliveredCases(e.target.value)}
                  className="w-full h-9 px-3 border border-[#DCE8F7] rounded-xl tabular-nums"
                />
                <p className="text-[11.5px] text-[#5A759E] mt-1">
                  Shortage automatically calculated: {Math.max(0, podModal.dispatched_cases - Number(deliveredCases || 0)).toLocaleString()} cases. Only delivered cases will be invoiced.
                </p>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-[#0F2147] mb-1">Damaged Cases</label>
                  <input
                    type="number"
                    min={0}
                    value={damagedCases}
                    onChange={(e) => setDamagedCases(e.target.value)}
                    className="w-full h-9 px-3 border border-[#DCE8F7] rounded-xl tabular-nums"
                  />
                </div>
                <div className="flex items-end pb-2">
                  <label className="flex items-center gap-2 font-semibold text-[#0F2147] cursor-pointer">
                    <input type="checkbox" checked={onTime} onChange={(e) => setOnTime(e.target.checked)} />
                    <span>Arrived within SLA window</span>
                  </label>
                </div>
              </div>
              <div>
                <label className="block font-semibold text-[#0F2147] mb-1">POD Gatehouse Notes</label>
                <input
                  type="text"
                  value={podNotes}
                  onChange={(e) => setPodNotes(e.target.value)}
                  className="w-full h-9 px-3 border border-[#DCE8F7] rounded-xl"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button type="button" onClick={() => setPodModal(null)} className="px-3.5 py-2 rounded-xl border border-[#DCE8F7] text-[13px] font-semibold">
                Cancel
              </button>
              <button type="submit" className="px-4 py-2 rounded-xl bg-[#0055D4] text-white text-[13px] font-semibold hover:bg-[#003D99] cursor-pointer">
                Confirm POD
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
