import React, { useEffect, useState } from 'react';
import {
  AlertTriangle,
  ArrowRight,
  CheckCircle2,
  FileCode2,
  PackageCheck,
  Plus,
  Send,
  Truck,
} from 'lucide-react';
import { apiFetch, formatGbp } from '../api';
import type { SectionId } from '../types';

interface OrdersPageProps {
  focusId?: string;
  onNotify: (type: 'success' | 'error' | 'info', title: string, detail?: string) => void;
  onRefreshAll: () => void;
  onNavigate: (section: SectionId, focusId?: string) => void;
}

export const OrdersPage: React.FC<OrdersPageProps> = ({ focusId, onNotify, onRefreshAll, onNavigate }) => {
  const [orders, setOrders] = useState<
    Array<{
      id: string;
      order_ref: string;
      account_id: string;
      account_name: string;
      account_logo_url: string;
      invoice_recipient: string;
      delivery_location_name: string;
      source_location_id: string;
      source_location_name: string;
      requested_delivery_date: string;
      status: string;
      operational_flag: string;
      shipment_state: string;
      invoice_state: string;
      payment_state: string;
      total_cases: number;
      allocated_cases: number;
      delivered_cases: number;
      net_amount_pence: number;
      edi_message_id: string;
      notes: string;
    }>
  >([]);
  const [lines, setLines] = useState<
    Array<{
      id: string;
      order_id: string;
      product_id: string;
      sku: string;
      product_name: string;
      ordered_cases: number;
      allocated_cases: number;
      picked_cases: number;
      dispatched_cases: number;
      delivered_cases: number;
      units_per_case_snapshot: number;
      cases_per_pallet_snapshot: number;
      conversion_version: number;
      agreed_case_price_pence: number;
      line_net_pence: number;
    }>
  >([]);
  const [ediInbox, setEdiInbox] = useState<Array<{ message_id: string; sender_gln: string; message_type: string; status: string; received_at: string }>>([]);
  const [selectedOrderId, setSelectedOrderId] = useState<string>('ord-24084');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [showEdiModal, setShowEdiModal] = useState(false);
  const [ediMessageId, setEdiMessageId] = useState('EDI-MOR-20261113-901');
  const [ediCases, setEdiCases] = useState('640');
  const [busy, setBusy] = useState(false);

  const loadOrders = async () => {
    const query = statusFilter ? `?status=${encodeURIComponent(statusFilter)}` : '';
    const res = await apiFetch<{ orders: typeof orders; lines: typeof lines; ediInbox: typeof ediInbox }>(`/api/orders${query}`);
    setOrders(res.orders);
    setLines(res.lines);
    setEdiInbox(res.ediInbox);
  };

  useEffect(() => {
    loadOrders().catch(() => {});
  }, [statusFilter]);

  useEffect(() => {
    if (focusId && focusId.startsWith('ord-')) {
      setSelectedOrderId(focusId);
    }
  }, [focusId]);

  const selected = orders.find((o) => o.id === selectedOrderId) || orders[0];
  const selectedLines = lines.filter((l) => l.order_id === selected?.id);

  const runAction = async (fn: () => Promise<void>) => {
    setBusy(true);
    try {
      await fn();
      await loadOrders();
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'Action failed', (err as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const handleReplenishLeedsForMorrisons = () =>
    runAction(async () => {
      await apiFetch('/api/inventory/transfer', {
        method: 'POST',
        body: JSON.stringify({
          productId: 'prd-persil-24w',
          fromLocationId: 'loc-mk',
          toLocationId: 'loc-leeds',
          cases: 1460,
          resolveExceptionId: 'exc-1',
        }),
      });
      onNotify('success', 'Transferred 1,460 cases MK NDC → Leeds DC', 'Persil Leeds DC ATP replenished and exception resolved.');
    });

  const handleAllocate = (allowPartial: boolean) =>
    runAction(async () => {
      const res = await apiFetch<{ allocatedCases: number; totalCases: number; shortfallCases: number }>(`/api/orders/${selected.id}/allocate`, {
        method: 'POST',
        body: JSON.stringify({ allowPartial }),
      });
      onNotify(
        res.shortfallCases > 0 ? 'info' : 'success',
        `FEFO Allocated ${res.allocatedCases.toLocaleString()} / ${res.totalCases.toLocaleString()} cases`,
        res.shortfallCases > 0 ? `${res.shortfallCases} cases remain unallocated.` : 'Full stock reserved on eligible FEFO batches.'
      );
    });

  const handlePick = () =>
    runAction(async () => {
      await apiFetch(`/api/orders/${selected.id}/pick`, { method: 'POST' });
      onNotify('success', `FEFO Batches Picked for ${selected.order_ref}`, 'Order ready for carrier dispatch.');
    });

  const handleDispatch = () =>
    runAction(async () => {
      const res = await apiFetch<{ shipmentRef: string; dispatchedCases: number }>(`/api/orders/${selected.id}/dispatch`, {
        method: 'POST',
        body: JSON.stringify({ carrierName: 'DHL Supply Chain UK', vehicleReg: 'UK26 ULV' }),
      });
      onNotify('success', `Dispatched ${res.shipmentRef}`, `${res.dispatchedCases.toLocaleString()} cases loaded & dispatched.`);
    });

  const handleEdiSubmit = () =>
    runAction(async () => {
      const res = await apiFetch<{ duplicate: boolean; acknowledgement: string; order: { order_ref: string } }>('/api/edi/inbound', {
        method: 'POST',
        body: JSON.stringify({
          messageId: ediMessageId,
          senderGln: '5010002000088',
          accountId: 'acc-morrisons',
          deliveryLocationId: 'dloc-morr-wak',
          sourceLocationId: 'loc-leeds',
          productId: 'prd-persil-24w',
          orderedCases: Number(ediCases),
          requestedDeliveryDate: 'Thu 19 Nov 2026',
        }),
      });
      if (res.duplicate) {
        onNotify('info', `Duplicate EDI Ignored (${res.acknowledgement})`, `Idempotent replay matched existing order ${res.order?.order_ref}.`);
      } else {
        onNotify('success', `EDI Accepted (${res.acknowledgement})`, `Created order ${res.order?.order_ref}.`);
      }
      setShowEdiModal(false);
    });

  const lifecycleSteps = ['Draft', 'Submitted', 'Validated', 'Allocated', 'Picking', 'Dispatched', 'Delivered', 'Closed'];

  return (
    <div className="space-y-4">
      {/* Header Controls */}
      <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-[20px] font-bold text-[#0F2147]">Order Management &amp; EDI Workbench</h2>
          <p className="text-[13px] text-[#5A759E]">
            Separate Order, Shipment, Invoice &amp; Payment lifecycles with atomic FEFO reservation and idempotent EDI ingestion.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="h-9 px-3 text-[13px] font-medium bg-[#F4F8FD] border border-[#DCE8F7] rounded-xl"
          >
            <option value="">All Order States</option>
            {lifecycleSteps.map((st) => (
              <option key={st} value={st}>
                {st}
              </option>
            ))}
          </select>
          <button
            type="button"
            onClick={() => setShowEdiModal(true)}
            className="h-9 px-3.5 bg-[#0055D4] hover:bg-[#003D99] text-white text-[13px] font-semibold rounded-xl flex items-center gap-1.5 cursor-pointer"
          >
            <FileCode2 className="w-4 h-4" />
            <span>Simulate EDI Order</span>
          </button>
        </div>
      </div>

      {/* Orders Grid + Detail Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Orders List */}
        <div className="lg:col-span-5 bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs space-y-2 max-h-[680px] overflow-y-auto">
          <h3 className="text-[15px] font-bold text-[#0F2147] px-1 pb-1">Active Orders ({orders.length})</h3>
          {orders.map((o) => (
            <button
              key={o.id}
              type="button"
              onClick={() => setSelectedOrderId(o.id)}
              className={`w-full text-left p-3.5 rounded-xl border transition-colors cursor-pointer ${
                selected?.id === o.id ? 'bg-[#EEF5FF] border-[#0066FF]/50' : 'bg-white border-[#E8F0FA] hover:bg-[#F7FAFF]'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <img src={o.account_logo_url} alt="" className="w-14 h-5 object-contain" />
                  <span className="font-mono font-bold text-[13.5px] text-[#0F2147]">{o.order_ref}</span>
                </div>
                <span
                  className={`text-[11.5px] font-semibold px-2 py-0.5 rounded-full ${
                    o.operational_flag === 'Action needed'
                      ? 'bg-[#FEF3DC] text-[#9A5B04]'
                      : o.operational_flag === 'In transit'
                        ? 'bg-[#E8F2FF] text-[#0055D4]'
                        : 'bg-[#E8F7EE] text-[#157A36]'
                  }`}
                >
                  {o.operational_flag}
                </span>
              </div>
              <div className="mt-2 flex items-center justify-between text-[12.5px] text-[#475D82] tabular-nums">
                <span>
                  {o.total_cases.toLocaleString()} cases • {o.status}
                </span>
                <span className="font-bold text-[#0F2147]">{formatGbp(o.net_amount_pence)}</span>
              </div>
              <div className="mt-1 text-[11.5px] text-[#5A759E]">
                Ship: {o.shipment_state} • Inv: {o.invoice_state} • Pay: {o.payment_state}
              </div>
            </button>
          ))}
        </div>

        {/* Right Selected Order Detail + End-to-End 10-Step Workflow */}
        {selected && (
          <div className="lg:col-span-7 space-y-4">
            <div className="bg-white border border-[#DCE8F7] rounded-2xl p-5 shadow-2xs space-y-4">
              <div className="flex flex-wrap items-start justify-between gap-3 pb-3 border-b border-[#EAF1FA]">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-[18px] font-bold text-[#0F2147]">{selected.order_ref}</span>
                    <span className="text-[13px] font-semibold text-[#0055D4]">• {selected.account_name}</span>
                  </div>
                  <div className="text-[12.5px] text-[#5A759E] mt-0.5">
                    Origin: {selected.source_location_name} → Destination: {selected.delivery_location_name} • Due {selected.requested_delivery_date}
                  </div>
                  <div className="text-[11.5px] text-[#5A759E] mt-0.5">
                    EDI Ref: <span className="font-mono">{selected.edi_message_id || 'Manual'}</span> • Invoice to: {selected.invoice_recipient}
                  </div>
                </div>
                <div className="text-right tabular-nums">
                  <div className="text-[18px] font-bold text-[#0F2147]">{formatGbp(selected.net_amount_pence)}</div>
                  <div className="text-[12px] text-[#5A759E]">
                    {selected.allocated_cases.toLocaleString()} / {selected.total_cases.toLocaleString()} allocated
                  </div>
                </div>
              </div>

              {/* Lifecycle Stepper */}
              <div className="flex items-center gap-1 overflow-x-auto pb-1">
                {lifecycleSteps.map((step) => {
                  const currentIdx = lifecycleSteps.indexOf(selected.status);
                  const stepIdx = lifecycleSteps.indexOf(step);
                  const reached = stepIdx <= currentIdx && currentIdx >= 0;
                  return (
                    <div
                      key={step}
                      className={`px-2.5 py-1 rounded-lg text-[11.5px] font-semibold whitespace-nowrap ${
                        step === selected.status
                          ? 'bg-[#0055D4] text-white'
                          : reached
                            ? 'bg-[#E8F7EE] text-[#157A36]'
                            : 'bg-[#F4F8FD] text-[#7B92B2]'
                      }`}
                    >
                      {step}
                    </div>
                  );
                })}
              </div>

              {/* Guided Morrisons UL-24084 Shortage Resolution & 10-Step Workflow */}
              {selected.id === 'ord-24084' && (
                <div className="bg-[#F6FAFF] border border-[#C6DCFA] rounded-xl p-4 space-y-2.5">
                  <div className="flex items-start gap-2">
                    <AlertTriangle className="w-5 h-5 text-[#D97706] shrink-0 mt-0.5" />
                    <div className="text-[13px]">
                      <div className="font-bold text-[#0F2147]">UK Retail Demonstration Workflow: Morrisons Persil 24-Wash Shortage</div>
                      <p className="text-[#475D82] mt-0.5">
                        Morrisons requested 2,880 cases from Leeds DC (+34% Big Wash promotion uplift). Leeds DC holds only 1,420 eligible FEFO cases (220 quarantined &amp; 90 expired excluded). Execute the connected workflow below:
                      </p>
                    </div>
                  </div>
                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    {selected.allocated_cases < selected.total_cases && (
                      <button
                        type="button"
                        disabled={busy}
                        onClick={handleReplenishLeedsForMorrisons}
                        className="px-3 py-1.5 rounded-lg bg-[#0055D4] text-white text-[12px] font-semibold hover:bg-[#003D99] cursor-pointer disabled:opacity-50"
                      >
                        1. Transfer 1,460 cs MK → Leeds &amp; Resolve Alert
                      </button>
                    )}
                    <button
                      type="button"
                      disabled={busy || selected.allocated_cases >= selected.total_cases}
                      onClick={() => handleAllocate(false)}
                      className="px-3 py-1.5 rounded-lg bg-white border border-[#0055D4] text-[#0055D4] text-[12px] font-semibold hover:bg-[#EEF5FF] cursor-pointer disabled:opacity-45"
                    >
                      2. Allocate Full FEFO
                    </button>
                    <button
                      type="button"
                      disabled={busy || selected.allocated_cases >= selected.total_cases}
                      onClick={() => handleAllocate(true)}
                      className="px-3 py-1.5 rounded-lg bg-white border border-[#D97706] text-[#9A5B04] text-[12px] font-semibold hover:bg-[#FFF8EB] cursor-pointer disabled:opacity-45"
                    >
                      Or Partial Allocate (1,420 cs)
                    </button>
                  </div>
                </div>
              )}

              {/* Order Action Bar */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                {['Draft', 'Submitted', 'Validated'].includes(selected.status) && (
                  <>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleAllocate(false)}
                      className="px-3.5 py-2 rounded-xl bg-[#0055D4] text-white text-[12.5px] font-semibold hover:bg-[#003D99] flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Allocate FEFO Stock</span>
                    </button>
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleAllocate(true)}
                      className="px-3.5 py-2 rounded-xl bg-white border border-[#DCE8F7] text-[#0F2147] text-[12.5px] font-semibold hover:bg-[#F4F8FD] cursor-pointer disabled:opacity-50"
                    >
                      Allow Partial Allocation
                    </button>
                  </>
                )}
                {selected.status === 'Allocated' && (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handlePick}
                    className="px-3.5 py-2 rounded-xl bg-[#0055D4] text-white text-[12.5px] font-semibold hover:bg-[#003D99] flex items-center gap-1.5 cursor-pointer"
                  >
                    <PackageCheck className="w-4 h-4" />
                    <span>Pick Eligible FEFO Batches</span>
                  </button>
                )}
                {(selected.status === 'Picking' || selected.status === 'Allocated') && (
                  <button
                    type="button"
                    disabled={busy}
                    onClick={handleDispatch}
                    className="px-3.5 py-2 rounded-xl bg-[#15803D] text-white text-[12.5px] font-semibold hover:bg-[#166534] flex items-center gap-1.5 cursor-pointer"
                  >
                    <Truck className="w-4 h-4" />
                    <span>Dispatch Carrier Shipment</span>
                  </button>
                )}
                {selected.status === 'Dispatched' && (
                  <button
                    type="button"
                    onClick={() => onNavigate('distribution', selected.id)}
                    className="px-3.5 py-2 rounded-xl bg-[#0055D4] text-white text-[12.5px] font-semibold hover:bg-[#003D99] flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>Record POD / Partial Delivery in Distribution</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
                {selected.status === 'Delivered' && selected.invoice_state !== 'Issued' && (
                  <button
                    type="button"
                    onClick={() => onNavigate('finance', selected.id)}
                    className="px-3.5 py-2 rounded-xl bg-[#0055D4] text-white text-[12.5px] font-semibold hover:bg-[#003D99] flex items-center gap-1.5 cursor-pointer"
                  >
                    <span>Issue Delivered-Qty Invoice in Finance</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Order Lines Snapshot */}
              <div className="overflow-x-auto pt-2">
                <table className="w-full text-[12.5px] border border-[#DCE8F7] rounded-xl overflow-hidden">
                  <thead className="bg-[#EEF4FC] text-[#475D82]">
                    <tr>
                      <th className="text-left py-2 px-3">SKU / Product</th>
                      <th className="text-right py-2 px-2">Pack Snap</th>
                      <th className="text-right py-2 px-2">Ordered</th>
                      <th className="text-right py-2 px-2">Alloc</th>
                      <th className="text-right py-2 px-2">Picked</th>
                      <th className="text-right py-2 px-2">Delivered</th>
                      <th className="text-right py-2 px-3">Agreed Price</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#EEF3FA]">
                    {selectedLines.map((l) => (
                      <tr key={l.id}>
                        <td className="py-2 px-3">
                          <div className="font-semibold text-[#0F2147]">{l.product_name}</div>
                          <div className="font-mono text-[11px] text-[#5A759E]">{l.sku}</div>
                        </td>
                        <td className="py-2 px-2 text-right tabular-nums text-[#5A759E]">
                          {l.units_per_case_snapshot} u/cs (v{l.conversion_version})
                        </td>
                        <td className="py-2 px-2 text-right font-bold tabular-nums">{l.ordered_cases.toLocaleString()}</td>
                        <td className="py-2 px-2 text-right tabular-nums text-[#0055D4] font-semibold">{l.allocated_cases.toLocaleString()}</td>
                        <td className="py-2 px-2 text-right tabular-nums">{l.picked_cases.toLocaleString()}</td>
                        <td className="py-2 px-2 text-right tabular-nums text-[#15803D] font-semibold">{l.delivered_cases.toLocaleString()}</td>
                        <td className="py-2 px-3 text-right tabular-nums font-semibold">{formatGbp(l.agreed_case_price_pence)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Simulated EDI Inbox */}
            <div className="bg-white border border-[#DCE8F7] rounded-2xl p-4 shadow-2xs">
              <h4 className="text-[14px] font-bold text-[#0F2147] mb-2">Simulated EDI Gateway Inbox (Idempotent Deduplication)</h4>
              <div className="divide-y divide-[#EEF3FA] text-[12px]">
                {ediInbox.map((e) => (
                  <div key={e.message_id} className="py-1.5 flex items-center justify-between">
                    <span className="font-mono font-semibold text-[#0F2147]">{e.message_id}</span>
                    <span className="text-[#5A759E]">
                      GLN {e.sender_gln} • {e.message_type}
                    </span>
                    <span className="text-[#15803D] font-semibold">{e.status}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Simulated EDI Modal */}
      {showEdiModal && (
        <div className="fixed inset-0 z-50 bg-[#00174A]/45 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white border border-[#DCE8F7] rounded-2xl shadow-2xl max-w-md w-full p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-[17px] font-bold text-[#0F2147]">Send Simulated EDI ORDERS Message</h3>
              <button type="button" onClick={() => setShowEdiModal(false)} className="text-[#5A759E] hover:text-[#0F2147]">
                ✕
              </button>
            </div>
            <p className="text-[12.5px] text-[#5A759E]">
              Submitting the same Message ID twice tests EDI idempotency without creating duplicate orders or double-reserving stock.
            </p>
            <div className="space-y-3 text-[13px]">
              <div>
                <label className="block font-semibold text-[#0F2147] mb-1">EDI Message ID (Idempotency Key)</label>
                <input
                  type="text"
                  value={ediMessageId}
                  onChange={(e) => setEdiMessageId(e.target.value)}
                  className="w-full h-9 px-3 border border-[#DCE8F7] rounded-xl font-mono"
                />
              </div>
              <div>
                <label className="block font-semibold text-[#0F2147] mb-1">Persil 24-wash Cases (Morrisons Leeds DC)</label>
                <input
                  type="number"
                  value={ediCases}
                  onChange={(e) => setEdiCases(e.target.value)}
                  className="w-full h-9 px-3 border border-[#DCE8F7] rounded-xl tabular-nums"
                />
              </div>
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowEdiModal(false)}
                className="px-3.5 py-2 rounded-xl border border-[#DCE8F7] text-[13px] font-semibold cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={busy}
                onClick={handleEdiSubmit}
                className="px-4 py-2 rounded-xl bg-[#0055D4] text-white text-[13px] font-semibold flex items-center gap-1.5 cursor-pointer"
              >
                <Send className="w-3.5 h-3.5" />
                <span>Ingest EDI</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
