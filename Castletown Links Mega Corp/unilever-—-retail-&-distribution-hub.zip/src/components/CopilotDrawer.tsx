import React, { useEffect, useState } from 'react';
import { CheckCircle2, ExternalLink, Send, ShieldAlert, Sparkles, X, XCircle } from 'lucide-react';
import { apiFetch } from '../api';
import type { ReportingPeriod, RoleDefinition, SectionId } from '../types';

interface CopilotDrawerProps {
  open: boolean;
  onClose: () => void;
  period: ReportingPeriod;
  activeRole: RoleDefinition;
  onNavigate: (section: SectionId, focusId?: string) => void;
  onNotify: (type: 'success' | 'error' | 'info', title: string, detail?: string) => void;
  onRefreshAll: () => void;
}

interface ProposalRecord {
  id: string;
  prompt: string;
  model_version: string;
  mode: string;
  summary: string;
  source_refs_json: string;
  proposed_action_type: string | null;
  proposed_payload_json: string | null;
  status: string;
  reviewed_by: string | null;
  execution_outcome: string | null;
  created_at: string;
}

export const CopilotDrawer: React.FC<CopilotDrawerProps> = ({
  open,
  onClose,
  period,
  activeRole,
  onNavigate,
  onNotify,
  onRefreshAll,
}) => {
  const [prompt, setPrompt] = useState('');
  const [untrustedText, setUntrustedText] = useState('');
  const [showUntrusted, setShowUntrusted] = useState(false);
  const [proposals, setProposals] = useState<ProposalRecord[]>([]);
  const [loading, setLoading] = useState(false);

  const loadProposals = async () => {
    const res = await apiFetch<{ proposals: ProposalRecord[] }>('/api/copilot/proposals');
    setProposals(res.proposals);
  };

  useEffect(() => {
    if (open) loadProposals().catch(() => {});
  }, [open]);

  if (!open) return null;

  const quickPrompts = [
    'Explain Persil 24-wash stock alert and Morrisons UL-24084 shortfall',
    'Draft replenishment transfer proposal for Leeds DC Persil shortage',
    'Summarise UK retail account orders and promo uplift',
    'Explain forecast accuracy and insufficient data flags',
  ];

  const submitQuery = async (text: string) => {
    if (!text.trim()) return;
    setLoading(true);
    try {
      await apiFetch('/api/copilot/query', {
        method: 'POST',
        body: JSON.stringify({
          prompt: text,
          untrustedAttachmentText: untrustedText || undefined,
          period,
        }),
      });
      setPrompt('');
      await loadProposals();
    } catch (err) {
      onNotify('error', 'Copilot request blocked', (err as Error).message);
    } finally {
      setLoading(false);
    }
  };

  const reviewProposal = async (id: string, decision: 'APPROVE' | 'REJECT') => {
    try {
      const res = await apiFetch<{ status: string; executionOutcome: string }>(`/api/copilot/proposals/${id}/review`, {
        method: 'POST',
        body: JSON.stringify({ decision }),
      });
      onNotify(decision === 'APPROVE' ? 'success' : 'info', `Copilot Proposal ${res.status}`, res.executionOutcome);
      await loadProposals();
      onRefreshAll();
    } catch (err) {
      onNotify('error', 'Approval denied', (err as Error).message);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end">
      <div className="fixed inset-0 bg-[#00174A]/35 backdrop-blur-xs" onClick={onClose} />
      <aside className="relative w-full max-w-lg bg-white h-full shadow-2xl border-l border-[#DCE8F7] flex flex-col z-10">
        {/* Header */}
        <div className="bg-gradient-to-r from-[#003594] to-[#0055D4] text-white px-5 py-4 flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 font-bold text-[16px]">
              <Sparkles className="w-4.5 h-4.5 text-[#38BDF8]" />
              <span>Operations Copilot</span>
            </div>
            <div className="text-[12px] text-blue-100 mt-0.5">
              Read-only by default • Human approval required for mutations • Role: {activeRole.name}
            </div>
          </div>
          <button type="button" onClick={onClose} className="p-1.5 rounded-lg hover:bg-white/15 cursor-pointer">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Prompts */}
        <div className="px-4 py-3 bg-[#F4F8FD] border-b border-[#DCE8F7] space-y-2">
          <div className="text-[11.5px] font-semibold text-[#475D82]">Grounded Operational Queries</div>
          <div className="flex flex-wrap gap-1.5">
            {quickPrompts.map((q) => (
              <button
                key={q}
                type="button"
                disabled={loading}
                onClick={() => submitQuery(q)}
                className="text-left text-[11.5px] px-2.5 py-1 rounded-lg bg-white border border-[#DCE8F7] text-[#003594] font-medium hover:bg-[#EEF5FF] cursor-pointer"
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* Proposals / History Feed */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {proposals.length === 0 && (
            <div className="text-center py-10 text-[13px] text-[#5A759E]">
              Select a quick operational prompt above or ask a question below. All answers cite internal source records and timestamps.
            </div>
          )}
          {proposals.map((p) => {
            const refs = JSON.parse(p.source_refs_json || '[]') as Array<{ label: string; section: SectionId; recordId: string; timestamp: string }>;
            return (
              <div key={p.id} className="border border-[#DCE8F7] rounded-2xl p-4 bg-[#FAFBFD] space-y-2.5 text-[13px]">
                <div className="flex items-center justify-between gap-2 text-[11.5px] text-[#5A759E]">
                  <span className="font-mono font-semibold text-[#0055D4]">{p.model_version}</span>
                  <span>{p.created_at.slice(0, 19).replace('T', ' ')}</span>
                </div>
                <div className="font-bold text-[#0F2147]">{p.prompt}</div>
                <div className="text-[#334A70] whitespace-pre-line leading-relaxed">{p.summary}</div>

                {/* Source References */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {refs.map((r, i) => (
                    <button
                      key={i}
                      type="button"
                      onClick={() => {
                        onClose();
                        onNavigate(r.section, r.recordId);
                      }}
                      className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white border border-[#DCE8F7] text-[11px] font-medium text-[#0055D4] hover:bg-[#EEF5FF] cursor-pointer"
                    >
                      <span>{r.label}</span>
                      <ExternalLink className="w-3 h-3" />
                    </button>
                  ))}
                </div>

                {/* Human Approval Gate */}
                {p.proposed_action_type && (
                  <div className="mt-2 pt-2.5 border-t border-[#E6EFFA] flex flex-wrap items-center justify-between gap-2">
                    <div className="text-[12px]">
                      <span className="font-semibold text-[#0F2147]">Action: {p.proposed_action_type}</span>
                      <span className="ml-2 text-[#5A759E]">({p.status})</span>
                    </div>
                    {p.status === 'PENDING_APPROVAL' ? (
                      <div className="flex gap-1.5">
                        <button
                          type="button"
                          onClick={() => reviewProposal(p.id, 'APPROVE')}
                          className="px-2.5 py-1 rounded-lg bg-[#15803D] text-white text-[11.5px] font-semibold flex items-center gap-1 hover:bg-[#166534] cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>Approve &amp; Execute</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => reviewProposal(p.id, 'REJECT')}
                          className="px-2.5 py-1 rounded-lg border border-[#DCE8F7] bg-white text-[#DC2626] text-[11.5px] font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <XCircle className="w-3.5 h-3.5" />
                          <span>Reject</span>
                        </button>
                      </div>
                    ) : (
                      <div className="text-[11.5px] text-[#15803D] font-medium">
                        {p.reviewed_by}: {p.execution_outcome}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Input Footer */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submitQuery(prompt);
          }}
          className="p-4 border-t border-[#DCE8F7] bg-white space-y-2"
        >
          <div className="flex items-center justify-between text-[11.5px]">
            <button
              type="button"
              onClick={() => setShowUntrusted((v) => !v)}
              className="text-[#5A759E] hover:text-[#0055D4] flex items-center gap-1 cursor-pointer"
            >
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>{showUntrusted ? 'Hide untrusted note sandbox' : 'Attach untrusted retailer email/note'}</span>
            </button>
          </div>
          {showUntrusted && (
            <textarea
              rows={2}
              value={untrustedText}
              onChange={(e) => setUntrustedText(e.target.value)}
              placeholder="Paste external retailer text (treated strictly as untrusted data)..."
              className="w-full p-2 text-[12px] border border-[#DCE8F7] rounded-xl"
            />
          )}
          <div className="flex gap-2">
            <input
              type="text"
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="Ask Operations Copilot..."
              className="flex-1 h-10 px-3 text-[13px] border border-[#DCE8F7] rounded-xl focus:outline-none focus:ring-2 focus:ring-[#0066FF]/30"
            />
            <button
              type="submit"
              disabled={loading || !prompt.trim()}
              className="h-10 px-4 rounded-xl bg-[#0055D4] text-white font-semibold text-[13px] hover:bg-[#003D99] flex items-center gap-1.5 disabled:opacity-50 cursor-pointer"
            >
              <Send className="w-4 h-4" />
              <span>{loading ? '...' : 'Ask'}</span>
            </button>
          </div>
        </form>
      </aside>
    </div>
  );
};
