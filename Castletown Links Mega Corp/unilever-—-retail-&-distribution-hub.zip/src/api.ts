import type { RoleId } from './types';

let activeRoleHeader: RoleId = 'administrator';

export function setApiRole(roleId: RoleId) {
  activeRoleHeader = roleId;
}

export function getApiRole(): RoleId {
  return activeRoleHeader;
}

export class ApiError extends Error {
  status: number;
  code?: string;
  constructor(message: string, status: number, code?: string) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

export async function apiFetch<T>(url: string, options: RequestInit = {}): Promise<T> {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      'X-User-Role': activeRoleHeader,
      ...(options.headers || {}),
    },
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ApiError(data.message || data.error || `Request failed (${res.status})`, res.status, data.code);
  }
  return data as T;
}

export function formatGbpMillions(pence: number): string {
  const millions = pence / 100_000_000;
  return `£${millions.toFixed(1)}m`;
}

export function formatGbp(pence: number): string {
  return new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(pence / 100);
}
