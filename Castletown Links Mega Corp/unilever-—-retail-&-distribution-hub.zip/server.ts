import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { createServer as createViteServer } from 'vite';
import { getDb } from './server/db.ts';
import { seedDatabase } from './server/seed.ts';
import { createApiRouter } from './server/routes.ts';

async function startServer() {
  const db = getDb();
  seedDatabase(db, false);

  const app = express();
  const port = Number(process.env.PORT || 3000);

  app.use(express.json({ limit: '2mb' }));
  app.use('/api', createApiRouter(db));

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`UNILEVER Retail & Distribution Hub running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
