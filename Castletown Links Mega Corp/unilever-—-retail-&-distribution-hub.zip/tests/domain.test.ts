import test from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import { getDb, resetDbInstance } from '../server/db.ts';
import { seedDatabase } from '../server/seed.ts';
import { createApiRouter } from '../server/routes.ts';
import {
  allocateOrder,
  allocatePaymentToInvoice,
  convertQuantity,
  dispatchOrderShipment,
  evaluatePromotionPrecedence,
  getBatchAtp,
  getOverviewData,
  issueInvoiceForOrder,
  pickOrder,
  processEdiOrderMessage,
  recordShipmentPod,
  runWalkForwardBacktest,
  transferStock,
} from '../server/services/domainService.ts';
import { approveAndExecuteProposal, runCopilotQuery } from '../server/services/copilotService.ts';
import { ROLES } from '../server/rbac.ts';

function setupFreshDb() {
  resetDbInstance();
  const db = getDb(':memory:');
  seedDatabase(db, true);
  return db;
}

test('1. Unit, case, and pallet conversions respect versioned snapshots', () => {
  const db = setupFreshDb();
  // Active v2 for Persil 24-wash: 6 units/case, 64 cases/pallet
  const curr = convertQuantity(db, 'prd-persil-24w', 2, 'pallet', 'unit');
  assert.equal(curr.versionNum, 2);
  assert.equal(curr.convertedQty, 2 * 64 * 6); // 768 units

  // Historical v1: 8 units/case, 56 cases/pallet
  const hist = convertQuantity(db, 'prd-persil-24w', 2, 'pallet', 'unit', 'cnv-per24-v1');
  assert.equal(hist.versionNum, 1);
  assert.equal(hist.convertedQty, 2 * 56 * 8); // 896 units
});

test('2. Concurrent stock reservation prevents double-booking available stock', () => {
  const db = setupFreshDb();
  // Leeds DC Persil 24-wash has 1,420 eligible ATP cases
  const ordA = processEdiOrderMessage(
    db,
    {
      messageId: 'CONC-A-1',
      senderGln: '5010001000012',
      accountId: 'acc-morrisons',
      deliveryLocationId: 'dloc-morr-wak',
      sourceLocationId: 'loc-leeds',
      productId: 'prd-persil-24w',
      orderedCases: 1000,
      requestedDeliveryDate: 'Thu 19 Nov 2026',
    },
    'account_manager',
    'Oliver Grant'
  );
  const ordB = processEdiOrderMessage(
    db,
    {
      messageId: 'CONC-B-1',
      senderGln: '5010001000012',
      accountId: 'acc-tesco',
      deliveryLocationId: 'dloc-tesco-don',
      sourceLocationId: 'loc-leeds',
      productId: 'prd-persil-24w',
      orderedCases: 1000,
      requestedDeliveryDate: 'Thu 19 Nov 2026',
    },
    'account_manager',
    'Oliver Grant'
  );

  const resA = allocateOrder(db, (ordA.order as { id: string }).id, {
    allowPartial: false,
    actorRole: 'demand_planner',
    actorName: 'Priya Sharma',
  });
  assert.equal(resA.allocatedCases, 1000);

  // Second full allocation of 1,000 cases must fail because only 420 ATP remain!
  assert.throws(() => {
    allocateOrder(db, (ordB.order as { id: string }).id, {
      allowPartial: false,
      actorRole: 'demand_planner',
      actorName: 'Priya Sharma',
    });
  }, /Insufficient available-to-promise stock/);
});

test('3. Expired and quarantined batches are strictly excluded from FEFO allocation', () => {
  const db = setupFreshDb();
  const atp = getBatchAtp(db, 'prd-persil-24w', 'loc-leeds');
  // On-hand 1900 - 480 reserved = 1420 available. Quarantined (220) + Expired (90) must be excluded.
  assert.equal(atp.availableCases, 1420);
  assert.equal(atp.quarantinedCases, 220);
  assert.equal(atp.expiredCases, 90);
  assert.ok(atp.eligibleBatches.every((b) => b.status === 'AVAILABLE' && b.expiry_date > '2026-11-13'));
});

test('4. End-to-end partial delivery invoices strictly the delivered quantity & updates dashboard', () => {
  const db = setupFreshDb();
  // Step 1-5: Transfer 1,460 cases from MK NDC -> Leeds DC, allocate full 2,880 cases on Morrisons UL-24084
  transferStock(db, {
    productId: 'prd-persil-24w',
    fromLocationId: 'loc-mk',
    toLocationId: 'loc-leeds',
    cases: 1460,
    actorRole: 'demand_planner',
    actorName: 'Priya Sharma',
  });
  const alloc = allocateOrder(db, 'ord-24084', { allowPartial: false, actorRole: 'demand_planner', actorName: 'Priya Sharma' });
  assert.equal(alloc.allocatedCases, 2880);

  // Step 6: Warehouse picks FEFO batches
  const pick = pickOrder(db, 'ord-24084', 'warehouse_operator', 'Liam Gallagher');
  assert.equal(pick.pickedCases, 2880);

  // Step 7: Distribution dispatches and records PARTIAL delivery (2,700 delivered, 180 shortage)
  const disp = dispatchOrderShipment(db, {
    orderId: 'ord-24084',
    carrierName: 'DHL Supply Chain UK',
    vehicleReg: 'UK26 ULV',
    actorRole: 'distribution_coordinator',
    actorName: 'Hannah Reid',
  });
  const pod = recordShipmentPod(db, {
    shipmentId: disp.shipmentId,
    deliveredCases: 2700,
    damagedCases: 0,
    onTime: true,
    actorRole: 'distribution_coordinator',
    actorName: 'Hannah Reid',
  });
  assert.equal(pod.status, 'Partial POD');
  assert.equal(pod.shortageCases, 180);

  // Step 8: Invoice strictly 2,700 delivered cases @ 1,609p = 4,344,300p net
  const inv = issueInvoiceForOrder(db, { orderId: 'ord-24084', actorRole: 'finance_analyst', actorName: 'Marcus Vance' }) as {
    id: string;
    deliveredCases: number;
    netPence: number;
    totalPence: number;
  };
  assert.equal(inv.deliveredCases, 2700);
  assert.equal(inv.netPence, 2700 * 1609);

  // Step 9: Payment allocation
  const pay = allocatePaymentToInvoice(db, {
    invoiceId: inv.id,
    amountPence: inv.totalPence,
    actorRole: 'finance_analyst',
    actorName: 'Marcus Vance',
  });
  assert.equal(pay.invoiceStatus, 'Paid');

  // Step 10: Overview reconciles with newly invoiced £43,443
  const overview = getOverviewData(db, 'UK & Ireland', '2026-11');
  assert.equal(overview.kpis.netSalesPence, 4_280_000_000 + inv.netPence);
});

test('5. Promotion precedence rules prevent unintended discount stacking', () => {
  const db = setupFreshDb();
  // Insert a lower-priority overlapping promo on Morrisons Persil 24-wash
  db.prepare(
    `INSERT INTO promotions (
      id, code, title, account_id, brand_id, product_id, start_date, end_date, mechanic,
      discount_pct, precedence_rank, baseline_weekly_cases, expected_uplift_pct,
      funding_budget_pence, proposed_volume_cases, approval_state, baseline_method
    ) VALUES ('prm-overlap', 'PRM-MOR-OVR', 'Secondary Stack Attempt', 'acc-morrisons', 'brd-persil', 'prd-persil-24w',
      '2026-11-10', '2026-11-24', 'Coupon', 10.0, 3, 1950, 12.0, 100000, 2100, 'Approved', 'Baseline')`
  ).run();

  const evalRes = evaluatePromotionPrecedence(db, 'acc-morrisons', 'prd-persil-24w');
  assert.equal(evalRes.winningPromo?.code, 'PRM-MOR-PER11');
  assert.equal(evalRes.suppressedPromos.length, 1);
  assert.equal(evalRes.effectiveDiscountPct, 18.0);
});

test('6. Duplicate EDI messages are idempotent', () => {
  const db = setupFreshDb();
  const payload = {
    messageId: 'EDI-IDEMP-2026-77',
    senderGln: '5010002000088',
    accountId: 'acc-morrisons',
    deliveryLocationId: 'dloc-morr-wak',
    sourceLocationId: 'loc-leeds',
    productId: 'prd-persil-24w',
    orderedCases: 400,
    requestedDeliveryDate: 'Thu 19 Nov 2026',
  };
  const first = processEdiOrderMessage(db, payload, 'account_manager', 'Oliver Grant');
  const second = processEdiOrderMessage(db, payload, 'account_manager', 'Oliver Grant');
  assert.equal(first.duplicate, false);
  assert.equal(second.duplicate, true);
  assert.equal((first.order as { id: string }).id, (second.order as { id: string }).id);
});

test('7. Double-entry subledger entries remain strictly balanced', () => {
  const db = setupFreshDb();
  const sums = db.prepare('SELECT SUM(debit_pence) as debits, SUM(credit_pence) as credits FROM ledger_entries').get() as {
    debits: number;
    credits: number;
  };
  assert.equal(sums.debits, sums.credits);
  assert.ok(sums.debits > 0);
});

test('8. RBAC enforces 403 Forbidden for unauthorized role mutations', async () => {
  const db = setupFreshDb();
  const app = express();
  app.use(express.json());
  app.use('/api', createApiRouter(db));

  const server = app.listen(0);
  const address = server.address() as { port: number };
  const baseUrl = `http://127.0.0.1:${address.port}`;

  try {
    const res = await fetch(`${baseUrl}/api/orders/ord-24084/invoice`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-User-Role': 'read_only_reviewer' },
    });
    assert.equal(res.status, 403);
    const body = (await res.json()) as { code: string };
    assert.equal(body.code, 'FORBIDDEN');
  } finally {
    server.close();
  }
});

test('9. Walk-forward forecast backtesting is leak-free', () => {
  const history = [100, 100, 100, 100, 9999];
  const bt = runWalkForwardBacktest(history, 3);
  // Week 4 forecast uses only weeks 1-3 (100,100,100) and MUST NOT see 9999 from week 5
  assert.equal(bt.leakFreeVerified, true);
  assert.equal(bt.predictions[0].forecast, 100);
});

test('10. Overview dashboard KPIs, brands, channels, and stock alerts reconcile to underlying DB', () => {
  const db = setupFreshDb();
  const overview = getOverviewData(db, 'UK & Ireland', '2026-11');
  const brandSum = overview.brandPerformance.reduce((s, b) => s + b.netSalesPence, 0);
  const channelSum = overview.salesByChannel.reduce((s, c) => s + c.netSalesPence, 0);

  assert.equal(overview.kpis.netSalesPence, 4_280_000_000); // £42.8m
  assert.equal(brandSum, overview.kpis.netSalesPence);
  assert.equal(channelSum, overview.kpis.netSalesPence);
  assert.equal(overview.kpis.orderFillRatePct, 97.4);
  assert.equal(overview.kpis.onTimeDeliveryPct, 96.8);
  assert.equal(overview.kpis.stockAlertsCount, 18);
});

test('11. AI Operations Copilot proposals require explicit human approval before executing stock transfers', async () => {
  const db = setupFreshDb();
  const beforeLeeds = getBatchAtp(db, 'prd-persil-24w', 'loc-leeds').availableCases;
  const queryRes = await runCopilotQuery(db, {
    prompt: 'Draft replenishment transfer proposal for Persil 24-wash Leeds DC shortage',
    role: ROLES.demand_planner,
    period: '2026-11',
  });
  assert.equal(queryRes.status, 'PENDING_APPROVAL');
  // Stock must NOT move before approval
  assert.equal(getBatchAtp(db, 'prd-persil-24w', 'loc-leeds').availableCases, beforeLeeds);

  const execRes = approveAndExecuteProposal(db, queryRes.id, 'APPROVE', ROLES.demand_planner);
  assert.equal(execRes.status, 'EXECUTED');
  // Now Leeds DC ATP increased by 1,460 cases
  assert.equal(getBatchAtp(db, 'prd-persil-24w', 'loc-leeds').availableCases, beforeLeeds + 1460);
});
