package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.MenuItemEntity
import com.example.data.OrderEntity
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34]) // Use a stable robust SDK level (e.g. 34) for local JVM tests
class ExampleRobolectricTest {

    @Test
    fun `read string from context validates correct premium app name`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Aureom Table", appName)
    }

    @Test
    fun `validate private membership reduces carriage delivery charge to zero`() {
        // Mock data logic
        val subtotal = 100.00
        val deliveryFeeStandard = 7.00
        val deliveryFeePrivate = 0.00

        val totalStandard = subtotal + deliveryFeeStandard
        val totalPrivate = subtotal + deliveryFeePrivate

        assertEquals(107.00, totalStandard, 0.0)
        assertEquals(100.00, totalPrivate, 0.0)
    }

    @Test
    fun `validate illegal order state transitions are rejected`() {
        // Valid progression flow: KITCHEN_ACCEPTED -> PREPARING -> PACKED -> QUALITY_CHECKED -> COURIER_ASSIGNED -> COLLECTED -> IN_TRANSIT -> ARRIVING -> DELIVERED -> CUSTOMER_CONFIRMED
        val flow = listOf(
            "KITCHEN_ACCEPTED",
            "PREPARING",
            "PACKED",
            "QUALITY_CHECKED",
            "COURIER_ASSIGNED",
            "COLLECTED",
            "IN_TRANSIT",
            "ARRIVING",
            "DELIVERED",
            "CUSTOMER_CONFIRMED"
        )

        fun isValidTransition(from: String, to: String): Boolean {
            val fromIndex = flow.indexOf(from)
            val toIndex = flow.indexOf(to)
            if (fromIndex == -1 || toIndex == -1) return false
            return toIndex == fromIndex + 1
        }

        // DELIVERED to PREPARING must be rejected (Required)
        val testInvalid = isValidTransition("DELIVERED", "PREPARING")
        assertEquals(false, testInvalid)

        // KITCHEN_ACCEPTED to PREPARING is valid
        val testValid = isValidTransition("KITCHEN_ACCEPTED", "PREPARING")
        assertEquals(true, testValid)
    }

    @Test
    fun `validate structured allergen warnings exist before table checkout`() {
        val dish = MenuItemEntity(
            restaurantId = 1,
            name = "Roasted Cornish Cod",
            description = "Samphire and brown butter.",
            price = 34.00,
            category = "Main",
            allergens = "milk, fish",
            ingredients = "Cod, butter, samphire"
        )

        // Assert that allergen details are non-empty and accessible before ordering
        assertNotEquals("", dish.allergens)
        assert(dish.allergens.contains("fish"))
    }
}
