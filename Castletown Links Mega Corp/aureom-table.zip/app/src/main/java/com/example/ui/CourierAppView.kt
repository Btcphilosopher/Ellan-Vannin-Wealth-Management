package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AureomBrass
import com.example.ui.theme.AureomCharcoal
import com.example.ui.theme.AureomNavy

@Composable
fun CourierAppView(
    viewModel: AureomViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val activeOrder by viewModel.activeOrder.collectAsState()
    val courier by viewModel.courier.collectAsState()

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(AureomCharcoal)
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("courier_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = AureomBrass)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "CARRIAGE LOGISTICS TERMINAL",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White,
                    letterSpacing = 1.5.sp
                )
            }
        },
        containerColor = AureomCharcoal,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            // Courier Profile
            item {
                courier?.let { cr ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AureomNavy),
                        shape = RoundedCornerShape(0.dp),
                        border = BorderStroke(1.dp, AureomBrass),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "EXECUTIVE CARRIAGE",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureomBrass,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = cr.name,
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Vehicle: ${cr.vehicleType}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.LightGray
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = "Punctuality", style = MaterialTheme.typography.labelSmall, color = AureomBrass)
                                    Text(text = cr.punctualityRate, style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text(text = "Thermal SLA", style = MaterialTheme.typography.labelSmall, color = AureomBrass)
                                    Text(text = cr.temperatureSLA, style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text(text = "Score Rating", style = MaterialTheme.typography.labelSmall, color = AureomBrass)
                                    Text(text = "${cr.rating} ★", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            // Active Carriage Job Details
            item {
                Text(
                    text = "ACTIVE CARRIAGE JOB DETAILS",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureomBrass,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                val order = activeOrder
                if (order == null) {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AureomNavy),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "No active carriage job assigned. Status: On Call.",
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color.White.copy(alpha = 0.6f)
                            )
                        }
                    }
                } else {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = AureomNavy),
                        shape = RoundedCornerShape(0.dp),
                        border = BorderStroke(1.dp, AureomBrass),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "JOB #${order.id}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AureomBrass,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "WINDOW: ${order.deliveryWindow}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.White
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "Pickup Station: ${order.restaurantName}",
                                style = MaterialTheme.typography.bodyLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Delivery Residence: ${order.deliveryAddress}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.LightGray
                            )

                            Spacer(modifier = Modifier.height(16.dp))
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(AureomCharcoal)
                                    .padding(12.dp)
                            ) {
                                Icon(Icons.Default.Thermostat, contentDescription = null, tint = AureomBrass)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "THERMAL CASE COMPLIANCE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AureomBrass
                                    )
                                    Text(
                                        text = "Current Telemetry: ${order.temperatureReading}°C (Holding SLA: >65.0°C)",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.White
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.advanceActiveOrderStatus() },
                                colors = ButtonDefaults.buttonColors(containerColor = AureomBrass, contentColor = AureomNavy),
                                shape = RoundedCornerShape(0.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("courier_advance_job_button")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "ADVANCE CARRIAGE STATUS",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Carriage Safety Directives
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AureomNavy),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocalShipping, contentDescription = null, tint = AureomBrass)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "CARRIAGE DIRECTIVES",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureomBrass,
                                letterSpacing = 1.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Ensure thermal cases are fully locked before transit. Verify allergen confirmation safety seal is physically intact on delivery. Greet customer formally at the residence door with Rolls-Royce restraint.",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.LightGray,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}
