package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AureomBrass
import com.example.ui.theme.AureomCharcoal
import com.example.ui.theme.AureomNavy

@Composable
fun ProfileView(
    viewModel: AureomViewModel,
    modifier: Modifier = Modifier
) {
    val walletTransactions by viewModel.walletTransactions.collectAsState()
    val cbdcBalance by viewModel.cbdcBalance.collectAsState()
    val isPrivateMember by viewModel.isPrivateMember.collectAsState()
    val orders by viewModel.orders.collectAsState()

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AUREOM ACCOUNT",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = 2.sp,
                    modifier = Modifier.weight(1f)
                )
            }
        },
        bottomBar = {
            AureomBottomNavigation(
                activeScreen = "PROFILE",
                onTabClick = { screen -> viewModel.setScreen(screen) }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .testTag("profile_scroll_list"),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Account Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = AureomCharcoal),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text(
                            text = "AUREOM RESIDENT MEMBER",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureomBrass,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Thomas Aureom",
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Resident ID: #AR-1827A · London, SW1X",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.LightGray
                        )
                    }
                }
            }

            // Aureom Private Membership (Required)
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = if (isPrivateMember) AureomNavy else Color.Transparent),
                    border = BorderStroke(1.dp, AureomBrass),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "AUREOM TABLE PRIVATE",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureomBrass,
                                letterSpacing = 1.5.sp,
                                fontWeight = FontWeight.Bold
                            )

                            if (isPrivateMember) {
                                Surface(
                                    color = AureomBrass,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "ACTIVE",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AureomNavy,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "The elite British private dining club. Members receive priority kitchen slots, exclusive Michelin-level chef menus, and complimentary carriage on all table selections.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (isPrivateMember) Color.White else MaterialTheme.colorScheme.onBackground
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        Button(
                            onClick = { viewModel.togglePrivateMembership() },
                            colors = ButtonDefaults.buttonColors(containerColor = AureomBrass, contentColor = AureomNavy),
                            shape = RoundedCornerShape(0.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("toggle_private_membership_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isPrivateMember) "CANCEL MEMBERSHIP" else "UPGRADE TO PRIVATE CLUB",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // CBDC Wallet Conceptual Balance
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "BANK OF ENGLAND DIGITAL POUND (CBDC)",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureomBrass,
                                letterSpacing = 1.sp
                            )
                            Icon(Icons.Default.CreditCard, contentDescription = null, tint = AureomBrass)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "£${String.format("%.2f", cbdcBalance)}",
                            style = MaterialTheme.typography.displayMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.testTag("cbdc_wallet_balance_label")
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Concept Ledger Activity Log",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        val txs = walletTransactions.filter { it.walletType == "CBDC" }.take(3)
                        txs.forEach { tx ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(
                                        text = tx.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = tx.reference,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 10.sp
                                    )
                                }
                                Text(
                                    text = if (tx.transactionType == "DEPOSIT" || tx.transactionType == "REFUND") "+£${String.format("%.2f", tx.amount)}" else "-£${String.format("%.2f", tx.amount)}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = if (tx.transactionType == "DEPOSIT" || tx.transactionType == "REFUND") AureomBrass else MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                        }
                    }
                }
            }

            // Past Table Orders
            item {
                Text(
                    text = "PAST GOURMET ORDERS",
                    style = MaterialTheme.typography.labelSmall,
                    color = AureomBrass,
                    letterSpacing = 1.5.sp,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }

            val pastOrders = orders.filter { it.status == "CUSTOMER_CONFIRMED" || it.status == "DELIVERED" }

            if (pastOrders.isEmpty()) {
                item {
                    Text(
                        text = "No completed dining history found.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            } else {
                items(pastOrders) { ord ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = ord.restaurantName,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "£${String.format("%.2f", ord.totalPrice)}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Completed via ${ord.deliveryWindow}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
