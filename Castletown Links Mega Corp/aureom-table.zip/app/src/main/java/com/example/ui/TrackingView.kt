package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.OrderEntity
import com.example.ui.theme.AureomBrass
import com.example.ui.theme.AureomCharcoal
import com.example.ui.theme.AureomGoldAccent
import com.example.ui.theme.AureomNavy

@Composable
fun TrackingView(
    viewModel: AureomViewModel,
    modifier: Modifier = Modifier
) {
    val activeOrder by viewModel.activeOrder.collectAsState()
    val activeEvents by viewModel.activeOrderEvents.collectAsState()
    val courier by viewModel.courier.collectAsState()

    var ratingInput by remember { mutableStateOf(5) }
    var commentInput by remember { mutableStateOf("") }
    var reviewSubmitted by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 24.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "AUREOM TRACKING",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onBackground,
                    letterSpacing = 2.sp,
                    modifier = Modifier.weight(1f)
                )

                // Shortcut buttons to jump into roles for testing
                TextButton(
                    onClick = { viewModel.setScreen("RESTAURANT_DASHBOARD") },
                    modifier = Modifier.testTag("jump_to_restaurant_dashboard")
                ) {
                    Text("Station Dashboard", color = AureomBrass, fontSize = 11.sp)
                }
                Spacer(modifier = Modifier.width(4.dp))
                TextButton(
                    onClick = { viewModel.setScreen("COURIER_APP") },
                    modifier = Modifier.testTag("jump_to_courier_app")
                ) {
                    Text("Courier App", color = AureomBrass, fontSize = 11.sp)
                }
            }
        },
        bottomBar = {
            AureomBottomNavigation(
                activeScreen = "TRACKING",
                onTabClick = { screen -> viewModel.setScreen(screen) }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        val order = activeOrder

        if (order == null) {
            Box(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.RestaurantMenu,
                        contentDescription = "Vacancy",
                        tint = AureomBrass,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "No active dinner orders found.",
                        style = MaterialTheme.typography.displaySmall,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Curate an exquisite dining evening first by discovering our top seasonal selection.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .testTag("tracking_scroll_list"),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                // Tracking Status Headers
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 12.dp)
                    ) {
                        Text(
                            text = "ESTIMATED ARRIVAL ARRANGEMENT: ${order.deliveryWindow}",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureomBrass,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (order.status == "CUSTOMER_CONFIRMED" || order.status == "DELIVERED") "Enjoy Your Evening" else "Your dinner is on its way.",
                            style = MaterialTheme.typography.displayMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Status: ${order.status.replace("_", " ")}",
                            style = MaterialTheme.typography.titleSmall,
                            color = AureomBrass,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.testTag("active_order_status_label")
                        )
                    }
                }

                // Restrained Cartographic Map Canvas (Required)
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "CARRIAGE GEOLOCATION TELEMETRY",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureomBrass,
                            letterSpacing = 1.sp,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )

                        // Draw restrained British roadmap canvas
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(AureomCharcoal)
                                .border(1.dp, AureomBrass)
                        ) {
                            Canvas(modifier = Modifier.fillMaxSize()) {
                                // Background gridlines
                                for (i in 0..size.width.toInt() step 60) {
                                    drawLine(
                                        color = Color.White.copy(alpha = 0.05f),
                                        start = Offset(i.toFloat(), 0f),
                                        end = Offset(i.toFloat(), size.height)
                                    )
                                }
                                for (i in 0..size.height.toInt() step 60) {
                                    drawLine(
                                        color = Color.White.copy(alpha = 0.05f),
                                        start = Offset(0f, i.toFloat()),
                                        end = Offset(size.width, i.toFloat())
                                    )
                                }

                                // Restrained roadway coordinates
                                val startOffset = Offset(size.width * 0.15f, size.height * 0.75f) // Restaurant
                                val endOffset = Offset(size.width * 0.85f, size.height * 0.25f)   // Your Table
                                val midOffset = Offset(size.width * 0.5f, size.height * 0.45f)    // Courier location

                                // Road lines
                                drawLine(
                                    color = AureomBrass.copy(alpha = 0.3f),
                                    start = startOffset,
                                    end = endOffset,
                                    strokeWidth = 3f,
                                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(15f, 10f), 0f)
                                )

                                // Restaurant Node
                                drawCircle(color = AureomBrass, radius = 8f, center = startOffset)
                                // Destination Node
                                drawCircle(color = Color.White, radius = 8f, center = endOffset)

                                // Active Courier Position Node (if order in transit, move courier near destination)
                                val courierCenter = when (order.status) {
                                    "KITCHEN_ACCEPTED", "PREPARING", "PACKED", "QUALITY_CHECKED" -> startOffset
                                    "COURIER_ASSIGNED", "COLLECTED" -> startOffset
                                    "IN_TRANSIT" -> midOffset
                                    "ARRIVING" -> Offset(size.width * 0.75f, size.height * 0.32f)
                                    else -> endOffset
                                }

                                drawCircle(color = AureomBrass, radius = 14f, center = courierCenter)
                                drawCircle(color = AureomNavy, radius = 5f, center = courierCenter)
                            }

                            // Geolocation node indicators
                            Row(
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .fillMaxWidth()
                                    .background(AureomNavy.copy(alpha = 0.8f))
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(text = "STATION [RESTAURANT]", style = MaterialTheme.typography.labelSmall, color = AureomBrass)
                                Text(text = "CARRIAGE", style = MaterialTheme.typography.labelSmall, color = Color.White)
                                Text(text = "RESIDENCE [YOUR TABLE]", style = MaterialTheme.typography.labelSmall, color = AureomBrass)
                            }
                        }
                    }
                }

                // Demo Simulator Controls Row (Signature Demo Feature)
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                            .border(1.dp, AureomBrass.copy(alpha = 0.4f))
                            .background(AureomCharcoal.copy(alpha = 0.05f))
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "DEMONSTRATION SIMULATOR CONTROLS",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureomBrass,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Advance order event states to run the complete end-to-end system and test database settlement logs.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Button(
                                onClick = { viewModel.advanceActiveOrderStatus() },
                                colors = ButtonDefaults.buttonColors(containerColor = AureomNavy, contentColor = AureomBrass),
                                shape = RoundedCornerShape(0.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("demo_advance_status_button")
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("ADVANCE EVENT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Live Temperature Telemetry (Food safety requirements)
                item {
                    Surface(
                        color = AureomCharcoal,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 8.dp),
                        border = BorderStroke(1.dp, AureomBrass)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "CARGO HANDLING TELEMETRY",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AureomBrass,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Target temperature: >65.0°C (Hot Holding compliance)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.LightGray
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "${order.temperatureReading}°C",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                    color = if (order.temperatureReading >= 65.0) AureomBrass else Color.Red,
                                    modifier = Modifier.testTag("telemetry_temp_label")
                                )
                                Text(
                                    text = if (order.temperatureReading >= 65.0) "COMPLIANT" else "WARNING",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (order.temperatureReading >= 65.0) AureomBrass else Color.Red
                                )
                            }
                        }
                    }
                }

                // Event-Driven History Log (Enterprise Grade Audit)
                item {
                    Text(
                        text = "CARRIAGE HISTORICAL EVENT LOG",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureomBrass,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(start = 24.dp, end = 24.dp, top = 20.dp, bottom = 8.dp)
                    )
                }

                items(activeEvents) { ev ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Event Status",
                            tint = AureomBrass,
                            modifier = Modifier
                                .size(18.dp)
                                .offset(y = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = ev.state.replace("_", " "),
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = ev.note,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                            )
                        }
                    }
                    Divider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                    )
                }

                // Transition to Dining Mode: Reheating & Serving Suggestions (Only visible when DELIVERED or CUSTOMER_CONFIRMED)
                if (order.status == "DELIVERED" || order.status == "CUSTOMER_CONFIRMED") {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp)
                                .background(AureomNavy)
                                .border(1.dp, AureomBrass)
                                .padding(20.dp)
                        ) {
                            Text(
                                text = "YOUR TABLE IS SERVED",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureomBrass,
                                letterSpacing = 2.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Dinner Rehearsal & Serving Guide",
                                style = MaterialTheme.typography.titleLarge,
                                color = Color.White
                            )

                            Spacer(modifier = Modifier.height(12.dp))
                            Text(
                                text = "REHEATING RECOMMENDATIONS",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureomBrass,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "For optimal presentation, preheat oven to 160°C. Place Cornish Cod in oven for 6 to 8 minutes on fine china to preserve internal butter richness.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.9f)
                            )

                            Spacer(modifier = Modifier.height(16.dp))
                            Text(
                                text = "CHEF'S SERVING NOTES",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureomBrass,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Spoon warm samphire brown butter directly over cod fillet right before dining. Pair beautifully with chilled white Burgundy.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        }
                    }

                    // Feedbacks and reviews card
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 24.dp, vertical = 12.dp)
                                .border(1.dp, MaterialTheme.colorScheme.outline)
                                .padding(16.dp)
                        ) {
                            Text(
                                text = "RATE YOUR GOURMET EVENING",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureomBrass,
                                letterSpacing = 1.5.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            if (reviewSubmitted) {
                                Text(
                                    text = "Your feedback has been securely transmitted directly to the executive culinary station. Thank you.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = AureomBrass,
                                    fontWeight = FontWeight.Bold
                                )
                            } else {
                                // Star Selector
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(vertical = 8.dp)
                                ) {
                                    for (i in 1..5) {
                                        IconButton(
                                            onClick = { ratingInput = i },
                                            modifier = Modifier.testTag("rate_star_$i")
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Star,
                                                contentDescription = "Star $i",
                                                tint = if (i <= ratingInput) AureomGoldAccent else Color.LightGray,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(4.dp))
                                OutlinedTextField(
                                    value = commentInput,
                                    onValueChange = { commentInput = it },
                                    label = { Text("Culinary or service feedback") },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("feedback_comment_input"),
                                    singleLine = false,
                                    maxLines = 3
                                )

                                Spacer(modifier = Modifier.height(12.dp))
                                Button(
                                    onClick = {
                                        viewModel.submitReview(order.id, ratingInput, commentInput)
                                        reviewSubmitted = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = AureomNavy, contentColor = AureomBrass),
                                    shape = RoundedCornerShape(0.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("submit_feedback_button")
                                ) {
                                    Text("SUBMIT REVIEW")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
