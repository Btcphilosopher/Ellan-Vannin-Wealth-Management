package com.example

import android.app.Application
import com.example.data.AureomDatabase
import com.example.data.AureomRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob

class AureomApplication : Application() {

    // SupervisorJob keeps coroutines running even if one fails
    private val applicationScope = CoroutineScope(SupervisorJob())

    // Database and Repository instance initialized lazily
    val database by lazy { AureomDatabase.getDatabase(this, applicationScope) }
    val repository by lazy { AureomRepository(database.aureomDao()) }
}
