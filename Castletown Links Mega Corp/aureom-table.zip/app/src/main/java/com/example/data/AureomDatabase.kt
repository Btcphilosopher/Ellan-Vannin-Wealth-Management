package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        RestaurantEntity::class,
        MenuItemEntity::class,
        OrderEntity::class,
        OrderEventEntity::class,
        WalletTransactionEntity::class,
        CourierEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AureomDatabase : RoomDatabase() {

    abstract fun aureomDao(): AureomDao

    companion object {
        @Volatile
        private var INSTANCE: AureomDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AureomDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AureomDatabase::class.java,
                    "aureom_table_database"
                )
                .addCallback(AureomDatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class AureomDatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {

        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateDatabase(database.aureomDao())
                }
            }
        }

        suspend fun populateDatabase(dao: AureomDao) {
            // Check if restaurants are already added
            if (dao.getRestaurantCount() > 0) return

            // 1. Create Courier
            dao.insertCourier(
                CourierEntity(
                    id = 1,
                    name = "Alastair Sterling",
                    vehicleType = "Electric Executive Carriage",
                    latitude = 51.4988,
                    longitude = -0.1485,
                    rating = 4.98,
                    punctualityRate = "99.6%",
                    temperatureSLA = "100.0% Compliant"
                )
            )

            // 2. Insert Premium Restaurants
            val rest1Id = dao.insertRestaurant(
                RestaurantEntity(
                    name = "THE LEDBURY",
                    cuisine = "Contemporary British",
                    neighborhood = "Notting Hill",
                    chef = "Brett Graham",
                    biography = "A highly acclaimed three Michelin star British institution shaped around exceptional produce, precise cooking, and an extraordinary kitchen.",
                    deliveryRange = "Up to 4.5 miles",
                    deliveryTime = "18:30 — 20:30",
                    priceLevel = 4,
                    rating = 4.9,
                    hygieneRating = 5,
                    tableQualityScore = 98,
                    signatureDish = "Roast Cornish Cod",
                    isEditorial = true,
                    isRecommended = true,
                    isSponsored = false,
                    imageResName = "ledbury",
                    deliveryReliability = "99.8%"
                )
            )

            val rest2Id = dao.insertRestaurant(
                RestaurantEntity(
                    name = "GYMKHANA",
                    cuisine = "Premium Indian",
                    neighborhood = "Mayfair",
                    chef = "Siddharth Ahuja",
                    biography = "Inspired by elite colonial Indian gymkhana clubs, serving imperial tandoor roasts and rich curries in a stunning dark-oak aesthetic.",
                    deliveryRange = "Up to 5.0 miles",
                    deliveryTime = "18:00 — 21:00",
                    priceLevel = 4,
                    rating = 4.8,
                    hygieneRating = 5,
                    tableQualityScore = 96,
                    signatureDish = "Wild Muntjac Biryani",
                    isEditorial = true,
                    isRecommended = false,
                    isSponsored = false,
                    imageResName = "gymkhana",
                    deliveryReliability = "99.1%"
                )
            )

            val rest3Id = dao.insertRestaurant(
                RestaurantEntity(
                    name = "THE RIVER CAFÉ",
                    cuisine = "Modern Italian",
                    neighborhood = "Chelsea",
                    chef = "Ruth Rogers",
                    biography = "A legendary riverside kitchen serving high-quality rustic Italian dishes, celebrated for pristine ingredient sourcing and timeless wood-fired baking.",
                    deliveryRange = "Up to 3.8 miles",
                    deliveryTime = "17:30 — 20:00",
                    priceLevel = 3,
                    rating = 4.7,
                    hygieneRating = 5,
                    tableQualityScore = 94,
                    signatureDish = "Wild Seabass Carpaccio",
                    isEditorial = false,
                    isRecommended = true,
                    isSponsored = false,
                    imageResName = "river_cafe",
                    deliveryReliability = "98.7%"
                )
            )

            val rest4Id = dao.insertRestaurant(
                RestaurantEntity(
                    name = "CORE BY CLARE SMYTH",
                    cuisine = "Modern British",
                    neighborhood = "Kensington",
                    chef = "Clare Smyth OBE",
                    biography = "Headed by Great Britain's first female chef to hold three Michelin stars, emphasizing handcrafted artisanal British agricultural ingredients.",
                    deliveryRange = "Up to 4.0 miles",
                    deliveryTime = "19:00 — 21:30",
                    priceLevel = 4,
                    rating = 4.95,
                    hygieneRating = 5,
                    tableQualityScore = 99,
                    signatureDish = "Potato and Roe",
                    isEditorial = true,
                    isRecommended = true,
                    isSponsored = false,
                    imageResName = "core_clare",
                    deliveryReliability = "99.9%"
                )
            )

            val rest5Id = dao.insertRestaurant(
                RestaurantEntity(
                    name = "SKETCH LECTURE ROOM",
                    cuisine = "Modern French",
                    neighborhood = "Mayfair",
                    chef = "Pierre Gagnaire",
                    biography = "A theatrical playground of gourmet design. Highly sophisticated French technique combined with a futuristic London members' club dining aesthetic.",
                    deliveryRange = "Up to 3.0 miles",
                    deliveryTime = "18:00 — 20:45",
                    priceLevel = 4,
                    rating = 4.75,
                    hygieneRating = 4,
                    tableQualityScore = 92,
                    signatureDish = "Dorset Blue Lobster",
                    isEditorial = false,
                    isRecommended = false,
                    isSponsored = true,
                    imageResName = "sketch",
                    deliveryReliability = "98.2%"
                )
            )

            // 3. Insert Menu Items for each restaurant
            // The Ledbury
            dao.insertMenuItems(listOf(
                MenuItemEntity(
                    restaurantId = rest1Id,
                    name = "Roasted Cornish Cod",
                    description = "Brown butter, Jersey Royal potatoes, sea herbs and fresh English samphire.",
                    price = 34.00,
                    category = "Main",
                    allergens = "milk, fish",
                    ingredients = "Cornish Cod fillet, unsalted butter, Jersey Royal potatoes, samphire, parsley, sea salt."
                ),
                MenuItemEntity(
                    restaurantId = rest1Id,
                    name = "Herdwick Lamb Loin",
                    description = "Barbeque aubergine, black garlic emulsion, and rosemary jus.",
                    price = 42.00,
                    category = "Main",
                    allergens = "milk, celery",
                    ingredients = "Herdwick lamb loin, aubergine, black garlic, olive oil, rosemary, veal stock."
                ),
                MenuItemEntity(
                    restaurantId = rest1Id,
                    name = "Heritage Beetroot & Caviar",
                    description = "Salt-baked beetroots, white asparagus, Oscietra caviar and horseradish cream.",
                    price = 24.00,
                    category = "Starter",
                    allergens = "milk, fish",
                    ingredients = "Yellow & red beets, white asparagus, Caviar, double cream, grated horseradish."
                ),
                MenuItemEntity(
                    restaurantId = rest1Id,
                    name = "Tain L'Hermitage Chocolate Pâté",
                    description = "Rich Valrhona dark chocolate tart, candied pecans and sea salt crystals.",
                    price = 14.00,
                    category = "Dessert",
                    allergens = "milk, nuts, gluten",
                    ingredients = "Valrhona chocolate, heavy cream, sweet pastry, pecans, Maldon sea salt."
                )
            ))

            // Gymkhana
            dao.insertMenuItems(listOf(
                MenuItemEntity(
                    restaurantId = rest2Id,
                    name = "Wild Muntjac Biryani",
                    description = "Slow-cooked muntjac venison, basmati rice, mint, coriander and gold leaf garnish.",
                    price = 38.00,
                    category = "Main",
                    allergens = "milk, gluten",
                    ingredients = "Muntjac venison, Basmati rice, ghee, whole spices, mint, coriander leaves, edible gold leaf."
                ),
                MenuItemEntity(
                    restaurantId = rest2Id,
                    name = "Kid Goat Methi Keema",
                    description = "Minced kid goat, fresh fenugreek, served with hot buttered pao buns.",
                    price = 28.00,
                    category = "Main",
                    allergens = "milk, gluten",
                    ingredients = "Goat mince, fenugreek, green chillies, ginger, toasted pao buns, butter."
                ),
                MenuItemEntity(
                    restaurantId = rest2Id,
                    name = "Tandoori Broccoli",
                    description = "Marinated green broccoli florets, cardamom, cheese and cashew coating.",
                    price = 16.00,
                    category = "Starter",
                    allergens = "milk, nuts",
                    ingredients = "Broccoli, cream cheese, cardamom powder, crushed cashew nuts, lemon juice."
                ),
                MenuItemEntity(
                    restaurantId = rest2Id,
                    name = "Saffron Pistachio Kulfi",
                    description = "Traditional Indian frozen dessert flavored with organic Kashmiri saffron and pistachios.",
                    price = 12.00,
                    category = "Dessert",
                    allergens = "milk, nuts",
                    ingredients = "Condensed milk, saffron strands, pistachios, cardamom."
                )
            ))

            // The River Café
            dao.insertMenuItems(listOf(
                MenuItemEntity(
                    restaurantId = rest3Id,
                    name = "Wild Seabass Carpaccio",
                    description = "Thinly sliced Line-caught wild sea bass, Amalfi lemon juice, extra virgin olive oil and wild fennel pollen.",
                    price = 26.00,
                    category = "Starter",
                    allergens = "fish",
                    ingredients = "Wild sea bass, Amalfi lemons, cold-pressed olive oil, fennel pollen, sea salt."
                ),
                MenuItemEntity(
                    restaurantId = rest3Id,
                    name = "Beef Tagliata",
                    description = "Chargrilled dry-aged Aberdeen Angus ribeye, wild rocket, Parmesan shavings, and 12-year aged balsamic.",
                    price = 39.00,
                    category = "Main",
                    allergens = "milk",
                    ingredients = "Aberdeen Angus ribeye, rocket salad, Parmigiano-Reggiano, premium Modena balsamic vinegar."
                ),
                MenuItemEntity(
                    restaurantId = rest3Id,
                    name = "Chocolate Nemesis",
                    description = "Our legendary flourless chocolate cake with an incredibly rich, fudge-like centre.",
                    price = 15.00,
                    category = "Dessert",
                    allergens = "milk, eggs",
                    ingredients = "Single-origin dark chocolate, butter, sugar, fresh farm eggs."
                )
            ))

            // Core by Clare Smyth
            dao.insertMenuItems(listOf(
                MenuItemEntity(
                    restaurantId = rest4Id,
                    name = "Potato and Roe",
                    description = "Slow-cooked Jersey Royal potato, dulse seaweed, herring and trout roe, with a delicate butter sauce.",
                    price = 36.00,
                    category = "Starter",
                    allergens = "milk, fish",
                    ingredients = "Jersey Royal potato, dulse seaweed, herring roe, trout roe, beurre blanc."
                ),
                MenuItemEntity(
                    restaurantId = rest4Id,
                    name = "Core Apple Tart",
                    description = "Gala apple, Calvados, crisp puff pastry with a rich vanilla clotted cream.",
                    price = 16.00,
                    category = "Dessert",
                    allergens = "milk, gluten",
                    ingredients = "Gala apples, Calvados brandy, butter, puff pastry, Devon clotted cream."
                )
            ))

            // Wallet Initial Balance
            dao.insertWalletTransaction(
                WalletTransactionEntity(
                    walletType = "CBDC",
                    transactionType = "DEPOSIT",
                    amount = 300.00,
                    description = "Bank of England CBDC Wallet Top-Up",
                    reference = "BoE-TX-991823"
                )
            )
        }
    }
}
