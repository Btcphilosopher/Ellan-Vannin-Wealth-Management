package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Group
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AureomBrass
import com.example.ui.theme.AureomCharcoal
import com.example.ui.theme.AureomNavy

@Composable
fun DinnerPartyView(
    viewModel: AureomViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val guests by viewModel.dinnerPartyGuests.collectAsState()
    val cuisine by viewModel.dinnerPartyCuisine.collectAsState()
    val proposal by viewModel.dinnerPartyProposal.collectAsState()
    val selectedRestaurant by viewModel.selectedRestaurant.collectAsState()

    val cuisinesList = listOf("Contemporary British", "Premium Indian", "Modern Italian", "Modern French")

    // Generate proposal initially if vacant
    LaunchedEffect(Unit) {
        viewModel.generateDinnerPartyProposal()
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("concierge_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = AureomBrass)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "AUREOM CONCIERGE",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        },
        bottomBar = {
            AureomBottomNavigation(
                activeScreen = "DINNER_PARTY",
                onTabClick = { screen -> viewModel.setScreen(screen) }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(horizontal = 24.dp)
                .testTag("concierge_scroll_list"),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Editorial intro
            item {
                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                    Text(
                        text = "CONCIERGE DINNER PARTY MODE",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureomBrass,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "The Seamless Banquet",
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Specify guests and preferred culinary art style. Our concierge automatically builds an exceptional multi-person menu tailored perfectly to your residence.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                        lineHeight = 20.sp
                    )
                }
            }

            // Guests Count Selector
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    shape = RoundedCornerShape(0.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "NUMBER OF RESIDENT GUESTS",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureomBrass,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Group, contentDescription = null, tint = AureomBrass)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "$guests Guests",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.testTag("guests_count_label")
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Surface(
                                    modifier = Modifier
                                        .clickable { if (guests > 2) viewModel.setDinnerPartyGuests(guests - 2) }
                                        .testTag("decrease_guests_button"),
                                    color = AureomCharcoal.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(4.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Text(
                                        text = "—",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = AureomNavy,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                    )
                                }

                                Surface(
                                    modifier = Modifier
                                        .clickable { if (guests < 24) viewModel.setDinnerPartyGuests(guests + 2) }
                                        .testTag("increase_guests_button"),
                                    color = AureomCharcoal.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(4.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Text(
                                        text = "+",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = AureomNavy,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Cuisine Selector
            item {
                Column(modifier = Modifier.padding(vertical = 12.dp)) {
                    Text(
                        text = "CULINARY ART STYLE",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureomBrass,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        cuisinesList.forEach { style ->
                            val isSelected = cuisine == style
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .border(
                                        BorderStroke(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) AureomBrass else MaterialTheme.colorScheme.outline
                                        )
                                    )
                                    .background(if (isSelected) AureomNavy else Color.Transparent)
                                    .clickable { viewModel.setDinnerPartyCuisine(style) }
                                    .padding(vertical = 12.dp)
                                    .testTag("cuisine_option_${style.replace(" ", "_").lowercase()}"),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = style.replace(" ", "\n"),
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (isSelected) AureomBrass else MaterialTheme.colorScheme.onBackground,
                                    textAlign = TextAlign.Center,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }

            // Bespoke proposal card
            item {
                selectedRestaurant?.let { rest ->
                    val totalEstimate = proposal.sumOf { it.price } * guests

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp)
                            .background(AureomNavy)
                            .border(BorderStroke(1.dp, AureomBrass))
                            .padding(20.dp)
                    ) {
                        Text(
                            text = "PROPOSED BANQUET MENU",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureomBrass,
                            letterSpacing = 2.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "DINNER FOR $guests",
                            style = MaterialTheme.typography.displaySmall,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Curated from: ${rest.name} (${rest.neighborhood})",
                            style = MaterialTheme.typography.bodySmall,
                            color = AureomBrass
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        proposal.forEach { dish ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${dish.category.uppercase()} : ${dish.name}",
                                        style = MaterialTheme.typography.titleSmall,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = dish.description,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = Color.LightGray
                                    )
                                    Text(
                                        text = "Allergens: ${dish.allergens}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = AureomBrass,
                                        fontSize = 10.sp
                                    )
                                }
                                Text(
                                    text = "£${String.format("%.2f", dish.price * guests)}",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = Color.White,
                                    modifier = Modifier.padding(start = 8.dp)
                                )
                            }
                            Divider(color = Color.White.copy(alpha = 0.1f), modifier = Modifier.padding(vertical = 4.dp))
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "ESTIMATED TOTAL LEDGER",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AureomBrass
                                )
                                Text(
                                    text = "£${String.format("%.2f", totalEstimate)}",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                    color = Color.White
                                )
                            }

                            Button(
                                onClick = { viewModel.confirmDinnerParty() },
                                colors = ButtonDefaults.buttonColors(containerColor = AureomBrass, contentColor = AureomNavy),
                                shape = RoundedCornerShape(0.dp),
                                modifier = Modifier.testTag("confirm_concierge_banquet_button")
                            ) {
                                Text("LOAD TABLE MENU")
                            }
                        }
                    }
                }
            }
        }
    }
}
