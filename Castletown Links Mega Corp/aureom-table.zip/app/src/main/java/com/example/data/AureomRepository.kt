package com.example.data

import kotlinx.coroutines.flow.Flow

class AureomRepository(private val dao: AureomDao) {

    // Restaurants
    val allRestaurants: Flow<List<RestaurantEntity>> = dao.getAllRestaurants()

    fun getRestaurantById(id: Long): Flow<RestaurantEntity?> = dao.getRestaurantById(id)

    // Menu Items
    fun getMenuItemsForRestaurant(restaurantId: Long): Flow<List<MenuItemEntity>> =
        dao.getMenuItemsByRestaurantId(restaurantId)

    // Orders
    val allOrders: Flow<List<OrderEntity>> = dao.getAllOrders()

    fun getOrderById(id: Long): Flow<OrderEntity?> = dao.getOrderById(id)

    suspend fun createOrder(order: OrderEntity): Long {
        val orderId = dao.insertOrder(order)
        // Add initial event
        dao.insertOrderEvent(
            OrderEventEntity(
                orderId = orderId,
                state = "KITCHEN_ACCEPTED",
                note = "Order placed and authorized. Sent to chef's kitchen."
            )
        )
        return orderId
    }

    suspend fun updateOrderState(orderId: Long, nextState: String, note: String) {
        // Retrieve current order
        dao.getOrderById(orderId).collect { currentOrder ->
            if (currentOrder != null) {
                val updatedOrder = currentOrder.copy(status = nextState)
                dao.updateOrder(updatedOrder)
                // Append Event
                dao.insertOrderEvent(
                    OrderEventEntity(
                        orderId = orderId,
                        state = nextState,
                        note = note
                    )
                )
            }
        }
    }

    suspend fun updateOrderEntity(order: OrderEntity) {
        dao.updateOrder(order)
    }

    // Order Events
    fun getEventsForOrder(orderId: Long): Flow<List<OrderEventEntity>> = dao.getEventsForOrder(orderId)

    suspend fun addOrderEvent(event: OrderEventEntity): Long = dao.insertOrderEvent(event)

    // Wallet
    val allWalletTransactions: Flow<List<WalletTransactionEntity>> = dao.getAllWalletTransactions()

    suspend fun recordWalletTransaction(transaction: WalletTransactionEntity): Long =
        dao.insertWalletTransaction(transaction)

    // Courier
    val mainCourier: Flow<CourierEntity?> = dao.getCourierById(1)

    suspend fun updateCourierLocation(latitude: Double, longitude: Double) {
        dao.getCourierById(1).collect { courier ->
            if (courier != null) {
                dao.updateCourier(courier.copy(latitude = latitude, longitude = longitude))
            }
        }
    }
}
