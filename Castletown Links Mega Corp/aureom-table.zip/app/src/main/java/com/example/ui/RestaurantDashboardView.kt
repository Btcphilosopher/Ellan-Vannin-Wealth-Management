package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AureomBrass
import com.example.ui.theme.AureomCharcoal
import com.example.ui.theme.AureomGoldAccent
import com.example.ui.theme.AureomNavy

@Composable
fun RestaurantDashboardView(
    viewModel: AureomViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val orders by viewModel.orders.collectAsState()
    val walletTransactions by viewModel.walletTransactions.collectAsState()

    var activeTab by remember { mutableStateOf("KITCHEN QUEUE") }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(AureomNavy)
                    .padding(horizontal = 16.dp, vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("dashboard_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = AureomBrass)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "CULINARY CONTROL CENTRE",
                    style = MaterialTheme.typography.labelLarge,
                    color = Color.White,
                    letterSpacing = 2.sp
                )
            }
        },
        containerColor = AureomNavy, // Professional high contrast dark-mode kitchen terminal
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
        ) {
            // Dashboard Selector Tab Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                listOf("KITCHEN QUEUE", "STATION FINANCE", "SATISFACTION SCORE").forEach { tab ->
                    Button(
                        onClick = { activeTab = tab },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (activeTab == tab) AureomBrass else AureomCharcoal,
                            contentColor = if (activeTab == tab) AureomNavy else Color.White
                        ),
                        shape = RoundedCornerShape(0.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dashboard_tab_${tab.replace(" ", "_").lowercase()}")
                    ) {
                        Text(text = tab, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                when (activeTab) {
                    "KITCHEN QUEUE" -> {
                        item {
                            Text(
                                text = "ACTIVE PREPARATION QUEUE (SORTED BY READY-TIME)",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureomBrass,
                                letterSpacing = 1.sp,
                                modifier = Modifier.padding(bottom = 12.dp)
                            )
                        }

                        val activeQueue = orders.filter { it.status != "DELIVERED" && it.status != "CUSTOMER_CONFIRMED" }

                        if (activeQueue.isEmpty()) {
                            item {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(48.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "All culinary stations vacant. No orders pending.",
                                        style = MaterialTheme.typography.bodyLarge,
                                        color = Color.White.copy(alpha = 0.6f)
                                    )
                                }
                            }
                        } else {
                            items(activeQueue) { order ->
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = AureomCharcoal),
                                    shape = RoundedCornerShape(0.dp),
                                    border = BorderStroke(1.dp, AureomBrass),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 8.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "ORDER #${order.id}",
                                                style = MaterialTheme.typography.labelMedium,
                                                color = AureomBrass,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "TARGET WINDOW: ${order.deliveryWindow}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = Color.White
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = "Gourmet Selections for: ${order.customerName}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = Color.White
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Handling status: ${order.status}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = AureomBrass
                                        )

                                        Spacer(modifier = Modifier.height(12.dp))
                                        Surface(
                                            color = AureomNavy,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = "TEMPERATURE CRITICAL HOLDING: ${order.temperatureReading}°C",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = AureomBrass,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    "STATION FINANCE" -> {
                        item {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "COMMISSION & NET REVENUE LEDGER",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AureomBrass,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )

                                val settlements = walletTransactions.filter { it.transactionType == "DEPOSIT" && it.description.contains("Settlement") }

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = AureomCharcoal),
                                    shape = RoundedCornerShape(0.dp),
                                    border = BorderStroke(1.dp, AureomBrass),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(bottom = 16.dp)
                                ) {
                                    Column(modifier = Modifier.padding(16.dp)) {
                                        Text(
                                            text = "TOTAL COMPLETED REVENUE",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color.LightGray
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "£${String.format("%.2f", settlements.sumOf { it.amount })}",
                                            style = MaterialTheme.typography.displayMedium,
                                            color = AureomBrass
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Includes 85% merchant settlement payout. Platform fee remains exactly 15%.",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = Color.LightGray
                                        )
                                    }
                                }

                                Text(
                                    text = "RECENT LEDGER LOGS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AureomBrass,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(vertical = 12.dp)
                                )

                                settlements.forEach { tx ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column {
                                            Text(text = tx.description, style = MaterialTheme.typography.bodyMedium, color = Color.White)
                                            Text(text = tx.reference, style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                                        }
                                        Text(text = "+£${String.format("%.2f", tx.amount)}", style = MaterialTheme.typography.titleMedium, color = AureomBrass)
                                    }
                                    Divider(color = Color.White.copy(alpha = 0.1f))
                                }
                            }
                        }
                    }

                    "SATISFACTION SCORE" -> {
                        item {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "TABLE QUALITY CRITERIA METRICS",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = AureomBrass,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(bottom = 12.dp)
                                )

                                val ratedOrders = orders.filter { it.rating > 0 }

                                if (ratedOrders.isEmpty()) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(48.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "No customer reviews received yet.",
                                            style = MaterialTheme.typography.bodyLarge,
                                            color = Color.White.copy(alpha = 0.6f)
                                        )
                                    }
                                } else {
                                    ratedOrders.forEach { ord ->
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = AureomCharcoal),
                                            shape = RoundedCornerShape(0.dp),
                                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 8.dp)
                                        ) {
                                            Column(modifier = Modifier.padding(16.dp)) {
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Text(
                                                        text = ord.customerName,
                                                        style = MaterialTheme.typography.titleSmall,
                                                        color = Color.White
                                                    )
                                                    Row {
                                                        for (i in 1..ord.rating) {
                                                            Icon(
                                                                imageVector = Icons.Default.Star,
                                                                contentDescription = null,
                                                                tint = AureomGoldAccent,
                                                                modifier = Modifier.size(14.dp)
                                                            )
                                                        }
                                                    }
                                                }
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Text(
                                                    text = "\"${ord.ratingComment}\"",
                                                    style = MaterialTheme.typography.bodyMedium,
                                                    color = Color.White.copy(alpha = 0.85f)
                                                )
                                                Spacer(modifier = Modifier.height(4.dp))
                                                Text(
                                                    text = "Ordered from ${ord.restaurantName}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = AureomBrass
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
