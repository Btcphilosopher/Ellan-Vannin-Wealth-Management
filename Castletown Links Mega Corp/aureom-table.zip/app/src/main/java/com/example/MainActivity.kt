package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.*
import com.example.ui.theme.AureomTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            AureomTheme {
                val app = application as AureomApplication
                val factory = AureomViewModelFactory(app, app.repository)
                val viewModel: AureomViewModel = viewModel(factory = factory)

                AureomMainApp(viewModel)
            }
        }
    }
}

@Composable
fun AureomMainApp(viewModel: AureomViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    // Manage standard system Back button pop behavior using BackHandler (Required)
    when (currentScreen) {
        "HOME" -> {
            HomeView(viewModel = viewModel)
        }
        "RESTAURANT" -> {
            BackHandler { viewModel.setScreen("HOME") }
            RestaurantDetailView(
                viewModel = viewModel,
                onBackClick = { viewModel.setScreen("HOME") }
            )
        }
        "CART" -> {
            BackHandler { viewModel.setScreen("RESTAURANT") }
            CartCheckoutView(
                viewModel = viewModel,
                onBackClick = { viewModel.setScreen("RESTAURANT") }
            )
        }
        "TRACKING" -> {
            BackHandler { viewModel.setScreen("HOME") }
            TrackingView(viewModel = viewModel)
        }
        "PROFILE" -> {
            BackHandler { viewModel.setScreen("HOME") }
            ProfileView(viewModel = viewModel)
        }
        "DINNER_PARTY" -> {
            BackHandler { viewModel.setScreen("HOME") }
            DinnerPartyView(
                viewModel = viewModel,
                onBackClick = { viewModel.setScreen("HOME") }
            )
        }
        "RESTAURANT_DASHBOARD" -> {
            BackHandler { viewModel.setScreen("TRACKING") }
            RestaurantDashboardView(
                viewModel = viewModel,
                onBackClick = { viewModel.setScreen("TRACKING") }
            )
        }
        "COURIER_APP" -> {
            BackHandler { viewModel.setScreen("TRACKING") }
            CourierAppView(
                viewModel = viewModel,
                onBackClick = { viewModel.setScreen("TRACKING") }
            )
        }
        else -> {
            HomeView(viewModel = viewModel)
        }
    }
}
