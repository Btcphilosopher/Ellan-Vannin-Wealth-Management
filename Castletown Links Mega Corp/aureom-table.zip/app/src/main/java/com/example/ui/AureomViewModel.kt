package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.AureomApplication
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlin.random.Random

// Cart item helper
data class CartItem(
    val menuItem: MenuItemEntity,
    val quantity: Int
)

class AureomViewModel(
    application: Application,
    private val repository: AureomRepository
) : AndroidViewModel(application) {

    // --- State Streams ---
    val restaurants: StateFlow<List<RestaurantEntity>> = repository.allRestaurants
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<OrderEntity>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val walletTransactions: StateFlow<List<WalletTransactionEntity>> = repository.allWalletTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val courier: StateFlow<CourierEntity?> = repository.mainCourier
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // --- CBDC simulated balance ---
    val cbdcBalance: StateFlow<Double> = walletTransactions.map { txs ->
        txs.filter { it.walletType == "CBDC" }
            .fold(0.0) { sum, tx ->
                if (tx.transactionType == "DEPOSIT" || tx.transactionType == "REFUND") {
                    sum + tx.amount
                } else {
                    sum - tx.amount
                }
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 300.0)

    // --- Lightning simulated balance ---
    val lightningBalance: StateFlow<Double> = walletTransactions.map { txs ->
        txs.filter { it.walletType == "LIGHTNING" }
            .fold(0.0) { sum, tx ->
                if (tx.transactionType == "DEPOSIT" || tx.transactionType == "REFUND") {
                    sum + tx.amount
                } else {
                    sum - tx.amount
                }
            }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // --- UI Local Selection States ---
    private val _selectedRestaurant = MutableStateFlow<RestaurantEntity?>(null)
    val selectedRestaurant: StateFlow<RestaurantEntity?> = _selectedRestaurant.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _cart = MutableStateFlow<List<CartItem>>(emptyList())
    val cart: StateFlow<List<CartItem>> = _cart.asStateFlow()

    private val _selectedDeliveryWindow = MutableStateFlow("19:00 — 19:15")
    val selectedDeliveryWindow: StateFlow<String> = _selectedDeliveryWindow.asStateFlow()

    private val _activeOrder = MutableStateFlow<OrderEntity?>(null)
    val activeOrder: StateFlow<OrderEntity?> = _activeOrder.asStateFlow()

    private val _activeOrderEvents = MutableStateFlow<List<OrderEventEntity>>(emptyList())
    val activeOrderEvents: StateFlow<List<OrderEventEntity>> = _activeOrderEvents.asStateFlow()

    // --- Occasion Planner ---
    private val _selectedOccasion = MutableStateFlow<String?>(null)
    val selectedOccasion: StateFlow<String?> = _selectedOccasion.asStateFlow()

    // --- Dinner Party Mode ---
    private val _dinnerPartyGuests = MutableStateFlow(6)
    val dinnerPartyGuests: StateFlow<Int> = _dinnerPartyGuests.asStateFlow()

    private val _dinnerPartyCuisine = MutableStateFlow("Contemporary British")
    val dinnerPartyCuisine: StateFlow<String> = _dinnerPartyCuisine.asStateFlow()

    private val _dinnerPartyProposal = MutableStateFlow<List<MenuItemEntity>>(emptyList())
    val dinnerPartyProposal: StateFlow<List<MenuItemEntity>> = _dinnerPartyProposal.asStateFlow()

    // --- Navigation Screen State ---
    private val _currentScreen = MutableStateFlow("HOME") // HOME, RESTAURANT, CART, TRACKING, PROFILE, DINNER_PARTY, RESTAURANT_DASHBOARD, COURIER_APP
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    // --- Private Membership status ---
    private val _isPrivateMember = MutableStateFlow(false)
    val isPrivateMember: StateFlow<Boolean> = _isPrivateMember.asStateFlow()

    // Selected location postal code
    private val _selectedPostalCode = MutableStateFlow("London SW1X")
    val selectedPostalCode: StateFlow<String> = _selectedPostalCode.asStateFlow()

    // Temperature update job for simulated sensor telemetry
    private var telemetryJob: Job? = null

    init {
        // Automatically link latest active order events
        viewModelScope.launch {
            activeOrder.collectLatest { order ->
                if (order != null) {
                    repository.getEventsForOrder(order.id).collect { events ->
                        _activeOrderEvents.value = events
                    }
                } else {
                    _activeOrderEvents.value = emptyList()
                }
            }
        }
    }

    // --- Setters / User Actions ---
    fun setScreen(screen: String) {
        _currentScreen.value = screen
    }

    fun selectRestaurant(restaurant: RestaurantEntity) {
        _selectedRestaurant.value = restaurant
        _selectedCategory.value = "All"
        setScreen("RESTAURANT")
    }

    fun setCategory(category: String) {
        _selectedCategory.value = category
    }

    fun setPostalCode(pc: String) {
        _selectedPostalCode.value = pc
    }

    fun selectOccasion(occasion: String?) {
        _selectedOccasion.value = occasion
    }

    fun setDinnerPartyGuests(count: Int) {
        _dinnerPartyGuests.value = count
        generateDinnerPartyProposal()
    }

    fun setDinnerPartyCuisine(cuisine: String) {
        _dinnerPartyCuisine.value = cuisine
        generateDinnerPartyProposal()
    }

    fun togglePrivateMembership() {
        _isPrivateMember.value = !_isPrivateMember.value
    }

    fun getMenuItemsForSelectedRestaurant(): Flow<List<MenuItemEntity>> {
        val rest = _selectedRestaurant.value ?: return flowOf(emptyList())
        return repository.getMenuItemsForRestaurant(rest.id)
    }

    // --- Cart Actions ---
    fun addToCart(item: MenuItemEntity) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.menuItem.id == item.id }
        if (index >= 0) {
            current[index] = current[index].copy(quantity = current[index].quantity + 1)
        } else {
            current.add(CartItem(menuItem = item, quantity = 1))
        }
        _cart.value = current
    }

    fun removeFromCart(item: MenuItemEntity) {
        val current = _cart.value.toMutableList()
        val index = current.indexOfFirst { it.menuItem.id == item.id }
        if (index >= 0) {
            val updated = current[index].copy(quantity = current[index].quantity - 1)
            if (updated.quantity <= 0) {
                current.removeAt(index)
            } else {
                current[index] = updated
            }
        }
        _cart.value = current
    }

    fun clearCart() {
        _cart.value = emptyList()
    }

    fun setDeliveryWindow(window: String) {
        _selectedDeliveryWindow.value = window
    }

    // Pricing calculation
    fun getCartSubtotal(): Double {
        return _cart.value.sumOf { it.menuItem.price * it.quantity }
    }

    fun getCartTotal(): Double {
        val sub = getCartSubtotal()
        if (sub == 0.0) return 0.0
        val fee = if (_isPrivateMember.value) 0.0 else 7.00
        return sub + fee
    }

    // --- Dinner Party Generator ---
    fun generateDinnerPartyProposal() {
        viewModelScope.launch {
            // Find a restaurant matching the cuisine
            val matchingRests = restaurants.value.filter { it.cuisine.contains(_dinnerPartyCuisine.value, ignoreCase = true) || it.cuisine.contains("British", ignoreCase = true) }
            val rest = matchingRests.firstOrNull() ?: restaurants.value.firstOrNull()
            if (rest != null) {
                _selectedRestaurant.value = rest
                repository.getMenuItemsForRestaurant(rest.id).firstOrNull()?.let { items ->
                    // Pick Starter, Main, Side/Add-on, Dessert
                    val starter = items.firstOrNull { it.category == "Starter" } ?: items.firstOrNull()
                    val main = items.firstOrNull { it.category == "Main" && it.id != starter?.id } ?: items.firstOrNull()
                    val dessert = items.firstOrNull { it.category == "Dessert" && it.id != starter?.id && it.id != main?.id } ?: items.lastOrNull()

                    val proposal = mutableListOf<MenuItemEntity>()
                    starter?.let { proposal.add(it) }
                    main?.let { proposal.add(it) }
                    dessert?.let { proposal.add(it) }
                    _dinnerPartyProposal.value = proposal
                }
            }
        }
    }

    fun confirmDinnerParty() {
        // Add proposal items to cart multiplied by guests
        val proposal = _dinnerPartyProposal.value
        val guests = _dinnerPartyGuests.value
        val itemsList = mutableListOf<CartItem>()
        for (item in proposal) {
            itemsList.add(CartItem(menuItem = item, quantity = guests))
        }
        _cart.value = itemsList
        setScreen("CART")
    }

    // --- Checkout Process (Enterprise Grade Simulation) ---
    fun executeCheckout(paymentMethod: String) {
        val rest = _selectedRestaurant.value ?: return
        val total = getCartTotal()
        if (total == 0.0) return

        viewModelScope.launch {
            // Process simulated payments
            when (paymentMethod) {
                "Digital Pound (CBDC)" -> {
                    val balance = cbdcBalance.value
                    if (balance < total) {
                        // insufficient
                        return@launch
                    }
                    // record transaction
                    repository.recordWalletTransaction(
                        WalletTransactionEntity(
                            walletType = "CBDC",
                            transactionType = "PAYMENT",
                            amount = total,
                            description = "Aureom Table Purchase: ${rest.name}",
                            reference = "BoE-CBDC-${Random.nextInt(100000, 999999)}"
                        )
                    )
                }
                "Lightning Network" -> {
                    // simulate zero balance check, generate custom invoice
                    repository.recordWalletTransaction(
                        WalletTransactionEntity(
                            walletType = "LIGHTNING",
                            transactionType = "PAYMENT",
                            amount = total,
                            description = "Lightning micro-settlement for dinner",
                            reference = "LN-INVOICE-${Random.nextInt(100000, 999999)}"
                        )
                    )
                }
                else -> {
                    // standard credit card token simulation
                }
            }

            // Create Order
            val newOrder = OrderEntity(
                restaurantId = rest.id,
                restaurantName = rest.name,
                status = "KITCHEN_ACCEPTED",
                deliveryWindow = _selectedDeliveryWindow.value,
                totalPrice = total,
                deliveryFee = if (_isPrivateMember.value) 0.0 else 7.00,
                temperatureReading = 68.0
            )

            val orderId = repository.createOrder(newOrder)
            val insertedOrder = newOrder.copy(id = orderId)
            _activeOrder.value = insertedOrder

            // Clear Cart and Navigate to Tracking
            clearCart()
            setScreen("TRACKING")

            // Begin automatic/manual telemetry updates
            startTelemetrySimulation()
        }
    }

    // --- Status Telemetry Engine ---
    fun advanceActiveOrderStatus() {
        val order = _activeOrder.value ?: return
        viewModelScope.launch {
            val states = listOf(
                "KITCHEN_ACCEPTED" to "Order accepted by the head chef's kitchen. Preparing ingredients.",
                "PREPARING" to "Chef is handcrafting your seasonal selection in the kitchen.",
                "PACKED" to "Dinner is beautifully boxed in our dual-insulated thermal case.",
                "QUALITY_CHECKED" to "Kitchen director performed visual presentation and allergen seal checklist.",
                "COURIER_ASSIGNED" to "Alastair Sterling (Electric Executive Carriage) assigned to your table.",
                "COLLECTED" to "Executive courier collected the sealed thermal case. Holding temperature: 68°C.",
                "IN_TRANSIT" to "Your table is in transit via Mayfair. Perfect telemetry maintained.",
                "ARRIVING" to "Carriage approaching your residence. Preparing for arrival.",
                "DELIVERED" to "Delivered to your door. Enjoy your evening.",
                "CUSTOMER_CONFIRMED" to "Arrival confirmed. Dinner is properly served."
            )

            val currentIndex = states.indexOfFirst { it.first == order.status }
            if (currentIndex >= 0 && currentIndex < states.size - 1) {
                val next = states[currentIndex + 1]

                // For CBDC / Lightning settlement simulation upon confirmation
                if (next.first == "CUSTOMER_CONFIRMED") {
                    // Trigger simulated restaurant finance settlement
                    val netRevenue = order.totalPrice * 0.85 // 15% platform commission
                    val settlementRef = "AUREOM-SETTLE-${Random.nextInt(100000, 999999)}"
                    repository.recordWalletTransaction(
                        WalletTransactionEntity(
                            walletType = "CBDC",
                            transactionType = "DEPOSIT", // Simulator credit ledger
                            amount = netRevenue,
                            description = "Merchant Settlement for Order #${order.id}",
                            reference = settlementRef
                        )
                    )
                }

                // Update order state
                val updated = order.copy(
                    status = next.first,
                    temperatureReading = Math.max(60.0, order.temperatureReading - (Random.nextDouble() * 1.2))
                )
                repository.updateOrderEntity(updated)
                _activeOrder.value = updated

                // Append Event
                repository.addOrderEvent(
                    OrderEventEntity(
                        orderId = order.id,
                        state = next.first,
                        note = next.second
                    )
                )
            }
        }
    }

    private fun startTelemetrySimulation() {
        telemetryJob?.cancel()
        telemetryJob = viewModelScope.launch {
            while (true) {
                delay(12000) // update temp every 12 seconds
                val order = _activeOrder.value
                if (order != null && order.status != "DELIVERED" && order.status != "CUSTOMER_CONFIRMED") {
                    // Simulate minor temperature fluctuation
                    val currentTemp = order.temperatureReading
                    val fluctuation = (Random.nextDouble() * 0.6) - 0.4
                    val newTemp = Math.max(62.0, Math.min(72.0, currentTemp + fluctuation))
                    val updated = order.copy(temperatureReading = Math.round(newTemp * 10.0) / 10.0)
                    repository.updateOrderEntity(updated)
                    _activeOrder.value = updated
                } else {
                    break
                }
            }
        }
    }

    fun submitReview(orderId: Long, rating: Int, comment: String) {
        viewModelScope.launch {
            orders.value.firstOrNull { it.id == orderId }?.let { order ->
                val updated = order.copy(rating = rating, ratingComment = comment)
                repository.updateOrderEntity(updated)
                if (_activeOrder.value?.id == orderId) {
                    _activeOrder.value = updated
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        telemetryJob?.cancel()
    }
}

// Custom ViewModel Factory as we are using AndroidViewModel with custom repository injection
class AureomViewModelFactory(
    private val application: Application,
    private val repository: AureomRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(AureomViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return AureomViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
