package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.RestaurantEntity
import com.example.ui.theme.AureomBrass
import com.example.ui.theme.AureomCharcoal
import com.example.ui.theme.AureomGoldAccent
import com.example.ui.theme.AureomNavy
import com.example.ui.theme.AureomWarmWhite

@Composable
fun HomeView(
    viewModel: AureomViewModel,
    modifier: Modifier = Modifier
) {
    val restaurants by viewModel.restaurants.collectAsState()
    val selectedOccasion by viewModel.selectedOccasion.collectAsState()
    val postalCode by viewModel.selectedPostalCode.collectAsState()
    val isPrivateMember by viewModel.isPrivateMember.collectAsState()

    var showPostalDialog by remember { mutableStateOf(false) }
    var tempPostal by remember { mutableStateOf(postalCode) }

    Scaffold(
        topBar = {
            AureomHeader(
                postalCode = postalCode,
                onLocationClick = { showPostalDialog = true },
                isPrivateMember = isPrivateMember
            )
        },
        bottomBar = {
            AureomBottomNavigation(
                activeScreen = "HOME",
                onTabClick = { screen -> viewModel.setScreen(screen) }
            )
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .testTag("home_scrollable_list"),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Editorial Opening Banner
            item {
                EditorialHeroSection(onPlannerClick = { viewModel.setScreen("DINNER_PARTY") })
            }

            // Concierge Occasion Selector
            item {
                OccasionConciergeSelector(
                    selectedOccasion = selectedOccasion,
                    onOccasionSelect = { occ -> viewModel.selectOccasion(occ) }
                )
            }

            // Restaurant Curations Title
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 16.dp)
                ) {
                    Text(
                        text = if (selectedOccasion != null) "SUGGESTIONS FOR ${selectedOccasion?.uppercase()}" else "TONIGHT'S TABLE",
                        style = MaterialTheme.typography.labelLarge,
                        color = AureomBrass,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Dinner, properly considered.",
                        style = MaterialTheme.typography.displayMedium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }

            // Filter lists based on selected occasion or category
            val filteredRestaurants = when (selectedOccasion) {
                "Dinner party" -> restaurants.filter { it.priceLevel >= 3 }
                "Sunday lunch" -> restaurants.filter { it.cuisine.contains("British", ignoreCase = true) }
                "Dinner for two" -> restaurants.filter { it.isRecommended }
                "Late supper" -> restaurants.filter { it.id % 2 == 0L }
                else -> restaurants
            }

            if (filteredRestaurants.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(48.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No private dining tables open at this hour.",
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                    }
                }
            } else {
                items(filteredRestaurants) { rest ->
                    PremiumRestaurantCard(
                        restaurant = rest,
                        onClick = { viewModel.selectRestaurant(rest) }
                    )
                }
            }
        }
    }

    // Postal Code Dialog
    if (showPostalDialog) {
        AlertDialog(
            onDismissRequest = { showPostalDialog = false },
            title = {
                Text(
                    text = "SPECIFY RESIDENCE",
                    style = MaterialTheme.typography.titleLarge,
                    color = AureomNavy
                )
            },
            text = {
                Column {
                    Text(
                        text = "Enter your London residential postal area to verify direct courier carriage logistics.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.DarkGray
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = tempPostal,
                        onValueChange = { tempPostal = it },
                        label = { Text("Postal District (e.g. London SW1X)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("postal_code_input"),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setPostalCode(tempPostal)
                        showPostalDialog = false
                    },
                    modifier = Modifier.testTag("save_postal_code_button")
                ) {
                    Text("Confirm")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPostalDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AureomHeader(
    postalCode: String,
    onLocationClick: () -> Unit,
    isPrivateMember: Boolean
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            modifier = Modifier
                .clickable { onLocationClick() }
                .testTag("location_selector_header")
        ) {
            Text(
                text = "DELIVER TO",
                style = MaterialTheme.typography.labelSmall,
                color = AureomBrass,
                letterSpacing = 1.5.sp
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = postalCode,
                    style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.KeyboardArrowDown,
                    contentDescription = "Change location",
                    tint = AureomBrass,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        if (isPrivateMember) {
            Surface(
                color = AureomCharcoal,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, AureomBrass),
                modifier = Modifier.padding(start = 8.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Private Member",
                        tint = AureomBrass,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "PRIVATE",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureomBrass,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        } else {
            Text(
                text = "AUREOM",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onBackground,
                letterSpacing = 4.sp,
                fontWeight = FontWeight.Black
            )
        }
    }
}

@Composable
fun EditorialHeroSection(onPlannerClick: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(280.dp)
            .background(AureomNavy)
    ) {
        // Overlay banner pattern or general image asset
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "AUREOM TABLE",
                style = MaterialTheme.typography.labelLarge,
                color = AureomBrass,
                letterSpacing = 4.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Exceptional restaurants.\nBeautifully delivered.",
                style = MaterialTheme.typography.displayLarge,
                color = Color.White,
                lineHeight = 36.sp
            )
            Spacer(modifier = Modifier.height(20.dp))
            Button(
                onClick = onPlannerClick,
                colors = ButtonDefaults.buttonColors(containerColor = AureomBrass, contentColor = AureomNavy),
                shape = RoundedCornerShape(0.dp),
                modifier = Modifier
                    .testTag("concierge_planner_hero_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Restaurant, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PLAN EVENING",
                        style = MaterialTheme.typography.labelMedium,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}

@Composable
fun OccasionConciergeSelector(
    selectedOccasion: String?,
    onOccasionSelect: (String?) -> Unit
) {
    val occasions = listOf("Dinner for two", "Dinner party", "Sunday lunch", "Late supper")

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp)
    ) {
        PaddingValues(horizontal = 24.dp).let {
            Text(
                text = "WHAT ARE YOU PLANNING?",
                style = MaterialTheme.typography.labelMedium,
                color = AureomBrass,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(horizontal = 24.dp)
            )
        }
        Spacer(modifier = Modifier.height(12.dp))
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                FilterChip(
                    selected = selectedOccasion == null,
                    onClick = { onOccasionSelect(null) },
                    label = { Text("Standard Menu") },
                    shape = RoundedCornerShape(0.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AureomNavy,
                        selectedLabelColor = AureomBrass
                    )
                )
            }
            items(occasions) { occ ->
                FilterChip(
                    selected = selectedOccasion == occ,
                    onClick = { onOccasionSelect(occ) },
                    label = { Text(occ) },
                    shape = RoundedCornerShape(0.dp),
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AureomNavy,
                        selectedLabelColor = AureomBrass
                    ),
                    modifier = Modifier.testTag("occasion_chip_${occ.replace(" ", "_").lowercase()}")
                )
            }
        }
    }
}

@Composable
fun PremiumRestaurantCard(
    restaurant: RestaurantEntity,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 24.dp, vertical = 12.dp)
            .clickable { onClick() }
            .testTag("restaurant_card_${restaurant.name.replace(" ", "_").lowercase()}"),
        shape = RoundedCornerShape(0.dp), // Architectural sharp rectangular cards
        colors = CardDefaults.cardColors(
            containerColor = if (MaterialTheme.colorScheme.background == AureomWarmWhite) Color.White else AureomCharcoal
        ),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column {
            // Elegant top cover showing chef details & rating
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = restaurant.cuisine.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = AureomBrass,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = restaurant.name,
                        style = MaterialTheme.typography.titleLarge,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${restaurant.neighborhood} · Chef ${restaurant.chef}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Table Status Indicator
                Surface(
                    color = AureomNavy,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.padding(start = 8.dp)
                ) {
                    Text(
                        text = "TABLE OPEN",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureomBrass,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Restaurant Biography / Narrative (magazine style)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Text(
                    text = restaurant.biography,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                    textAlign = TextAlign.Start
                )
                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Key details (Service stats and signature dish)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Star,
                        contentDescription = "Rating",
                        tint = AureomGoldAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "${restaurant.rating} ★ (${restaurant.deliveryReliability} Reliability)",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Text(
                    text = "Signature: ${restaurant.signatureDish}",
                    style = MaterialTheme.typography.bodySmall,
                    color = AureomBrass,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
fun AureomBottomNavigation(
    activeScreen: String,
    onTabClick: (String) -> Unit
) {
    NavigationBar(
        containerColor = AureomNavy,
        tonalElevation = 8.dp,
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        NavigationBarItem(
            selected = activeScreen == "HOME",
            onClick = { onTabClick("HOME") },
            icon = { Icon(Icons.Outlined.Explore, contentDescription = "Discover") },
            label = { Text("Discover") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AureomNavy,
                selectedTextColor = AureomBrass,
                indicatorColor = AureomBrass,
                unselectedIconColor = Color.White.copy(alpha = 0.6f),
                unselectedTextColor = Color.White.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("nav_tab_home")
        )
        NavigationBarItem(
            selected = activeScreen == "DINNER_PARTY",
            onClick = { onTabClick("DINNER_PARTY") },
            icon = { Icon(Icons.Default.RestaurantMenu, contentDescription = "Occasions") },
            label = { Text("Concierge") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AureomNavy,
                selectedTextColor = AureomBrass,
                indicatorColor = AureomBrass,
                unselectedIconColor = Color.White.copy(alpha = 0.6f),
                unselectedTextColor = Color.White.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("nav_tab_concierge")
        )
        NavigationBarItem(
            selected = activeScreen == "TRACKING",
            onClick = { onTabClick("TRACKING") },
            icon = { Icon(Icons.Outlined.History, contentDescription = "Active Table") },
            label = { Text("Live Tracker") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AureomNavy,
                selectedTextColor = AureomBrass,
                indicatorColor = AureomBrass,
                unselectedIconColor = Color.White.copy(alpha = 0.6f),
                unselectedTextColor = Color.White.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("nav_tab_tracker")
        )
        NavigationBarItem(
            selected = activeScreen == "PROFILE",
            onClick = { onTabClick("PROFILE") },
            icon = { Icon(Icons.Outlined.Person, contentDescription = "Aureom Private") },
            label = { Text("Private") },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AureomNavy,
                selectedTextColor = AureomBrass,
                indicatorColor = AureomBrass,
                unselectedIconColor = Color.White.copy(alpha = 0.6f),
                unselectedTextColor = Color.White.copy(alpha = 0.6f)
            ),
            modifier = Modifier.testTag("nav_tab_profile")
        )
    }
}
