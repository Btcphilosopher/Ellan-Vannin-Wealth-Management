package com.example.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AureomBrass
import com.example.ui.theme.AureomCharcoal
import com.example.ui.theme.AureomNavy

@Composable
fun CartCheckoutView(
    viewModel: AureomViewModel,
    onBackClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val cart by viewModel.cart.collectAsState()
    val selectedWindow by viewModel.selectedDeliveryWindow.collectAsState()
    val isPrivateMember by viewModel.isPrivateMember.collectAsState()
    val cbdcBalance by viewModel.cbdcBalance.collectAsState()

    val windows = listOf("18:30 — 18:45", "18:45 — 19:00", "19:00 — 19:15", "19:15 — 19:30")
    val paymentMethods = listOf("Aureom Private Card", "Digital Pound (CBDC)", "Lightning Network")
    var selectedPayment by remember { mutableStateOf("Digital Pound (CBDC)") }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBackClick,
                    modifier = Modifier.testTag("back_to_menu_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = AureomBrass)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "YOUR DINNER TABLE",
                    style = MaterialTheme.typography.titleLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        },
        bottomBar = {
            if (cart.isNotEmpty()) {
                Surface(
                    color = AureomNavy,
                    tonalElevation = 12.dp,
                    modifier = Modifier.navigationBarsPadding()
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "TOTAL CARRIAGE",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureomBrass,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "£${String.format("%.2f", viewModel.getCartTotal())}",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = Color.White
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        val isBalanceLow = selectedPayment == "Digital Pound (CBDC)" && cbdcBalance < viewModel.getCartTotal()

                        Button(
                            onClick = { viewModel.executeCheckout(selectedPayment) },
                            enabled = !isBalanceLow,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AureomBrass,
                                contentColor = AureomNavy,
                                disabledContainerColor = Color.Gray,
                                disabledContentColor = Color.White
                            ),
                            shape = RoundedCornerShape(0.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp)
                                .testTag("confirm_evening_and_dispatch_button")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isBalanceLow) "INSUFFICIENT CBDC BALANCE" else "CONFIRM EVENING & DISPATCH",
                                    style = MaterialTheme.typography.labelMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        },
        containerColor = MaterialTheme.colorScheme.background,
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        if (cart.isEmpty()) {
            Box(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = "Empty",
                        tint = AureomBrass,
                        modifier = Modifier.size(48.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "Your table is currently vacant.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .padding(innerPadding)
                    .fillMaxSize()
                    .testTag("checkout_scroll_list"),
                contentPadding = PaddingValues(bottom = 32.dp)
            ) {
                // Section Title: Selected dishes
                item {
                    Text(
                        text = "SELECTED DISHES",
                        style = MaterialTheme.typography.labelSmall,
                        color = AureomBrass,
                        letterSpacing = 1.5.sp,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 12.dp)
                    )
                }

                items(cart) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(0.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.menuItem.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "£${String.format("%.2f", item.menuItem.price)} each",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                // Decrease qty button
                                Surface(
                                    modifier = Modifier
                                        .clickable { viewModel.removeFromCart(item.menuItem) }
                                        .testTag("decrease_qty_${item.menuItem.name.replace(" ", "_").lowercase()}"),
                                    color = AureomCharcoal.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(4.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Text(
                                        text = "—",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = AureomNavy,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                    )
                                }

                                Text(
                                    text = "${item.quantity}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.testTag("item_qty_label_${item.menuItem.name.replace(" ", "_").lowercase()}")
                                )

                                // Increase qty button
                                Surface(
                                    modifier = Modifier
                                        .clickable { viewModel.addToCart(item.menuItem) }
                                        .testTag("increase_qty_${item.menuItem.name.replace(" ", "_").lowercase()}"),
                                    color = AureomCharcoal.copy(alpha = 0.1f),
                                    shape = RoundedCornerShape(4.dp),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Text(
                                        text = "+",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = AureomNavy,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Delivery Window Selector
                item {
                    Column(modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)) {
                        Text(
                            text = "PRECISE CARRIAGE WINDOW",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureomBrass,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "FAST ENOUGH TO FEEL EFFORTLESS. PRECISE ENOUGH TO TRUST.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            windows.forEach { win ->
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .border(
                                            BorderStroke(
                                                width = if (selectedWindow == win) 2.dp else 1.dp,
                                                color = if (selectedWindow == win) AureomBrass else MaterialTheme.colorScheme.outline
                                            )
                                        )
                                        .background(if (selectedWindow == win) AureomNavy else Color.Transparent)
                                        .clickable { viewModel.setDeliveryWindow(win) }
                                        .padding(vertical = 12.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = win.replace(" — ", "\n"),
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                        color = if (selectedWindow == win) AureomBrass else MaterialTheme.colorScheme.onBackground,
                                        textAlign = TextAlign.Center,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }

                // Premium Payment Methods Simulation (including CBDC & Lightning Network)
                item {
                    Column(modifier = Modifier.padding(horizontal = 24.dp, vertical = 16.dp)) {
                        Text(
                            text = "BRITISH INSTITUTIONAL PAYMENT METHOD",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureomBrass,
                            letterSpacing = 1.5.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        paymentMethods.forEach { method ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { selectedPayment = method }
                                    .padding(vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedPayment == method,
                                    onClick = { selectedPayment = method }
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = method,
                                        style = MaterialTheme.typography.titleSmall,
                                        color = MaterialTheme.colorScheme.onBackground
                                    )
                                    if (method == "Digital Pound (CBDC)") {
                                        Text(
                                            text = "Bank of England Ledger Balance: £${String.format("%.2f", cbdcBalance)}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = AureomBrass,
                                            fontWeight = FontWeight.Bold
                                        )
                                    } else if (method == "Lightning Network") {
                                        Text(
                                            text = "Experimental micro-payment settlement channel",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Receipt/Ledger summary preview
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp)
                            .background(AureomCharcoal.copy(alpha = 0.05f))
                            .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outline))
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "PREVIEW ACCOUNT LEDGER",
                            style = MaterialTheme.typography.labelSmall,
                            color = AureomBrass,
                            letterSpacing = 1.sp
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Gastronomic Subtotal", style = MaterialTheme.typography.bodyMedium)
                            Text(text = "£${String.format("%.2f", viewModel.getCartSubtotal())}", style = MaterialTheme.typography.bodyMedium)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Carriage & Delivery Service", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = if (isPrivateMember) "£0.00 (PRIVATE)" else "£7.00",
                                style = MaterialTheme.typography.bodyMedium,
                                color = if (isPrivateMember) AureomBrass else MaterialTheme.colorScheme.onBackground
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "ESTIMATED TOTAL LEDGER",
                                style = MaterialTheme.typography.labelSmall,
                                color = AureomNavy,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "£${String.format("%.2f", viewModel.getCartTotal())}",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Bold),
                                color = AureomNavy
                            )
                        }
                    }
                }
            }
        }
    }
}
