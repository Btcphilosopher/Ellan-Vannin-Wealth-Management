package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AureomBrass,
    onPrimary = AureomNavy,
    secondary = AureomStone,
    onSecondary = TextPrimaryDark,
    background = AureomNavy,
    onBackground = TextPrimaryDark,
    surface = AureomCharcoal,
    onSurface = TextPrimaryDark,
    surfaceVariant = AureomCharcoal,
    onSurfaceVariant = TextSecondaryDark,
    tertiary = AureomBurgundy,
    onTertiary = Color.White,
    outline = AureomStone
)

private val LightColorScheme = lightColorScheme(
    primary = AureomNavy,
    onPrimary = AureomWarmWhite,
    secondary = AureomBurgundy,
    onSecondary = AureomWarmWhite,
    background = AureomWarmWhite,
    onBackground = TextPrimaryLight,
    surface = AureomIvory,
    onSurface = TextPrimaryLight,
    surfaceVariant = Color.White,
    onSurfaceVariant = TextSecondaryLight,
    tertiary = AureomBrass,
    onTertiary = AureomNavy,
    outline = AureomLightGray
)

@Composable
fun AureomTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Keep a premium, stable dark aesthetic by default, or light cream if system prefers light
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
