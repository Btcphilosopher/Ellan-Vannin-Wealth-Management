package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types

@Entity(tableName = "restaurants")
data class RestaurantEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val cuisine: String,
    val neighborhood: String,
    val chef: String,
    val biography: String,
    val deliveryRange: String,
    val deliveryTime: String,
    val priceLevel: Int, // 1 to 4 (£ to ££££)
    val rating: Double,
    val hygieneRating: Int, // FSA Food Hygiene Rating (e.g. 5)
    val tableQualityScore: Int, // 1-100 table quality calculation
    val signatureDish: String,
    val isEditorial: Boolean,
    val isRecommended: Boolean,
    val isSponsored: Boolean,
    val imageResName: String, // name of fallback drawable or icon
    val deliveryReliability: String = "99.2%",
    val preparationTime: String = "20-25 mins",
    val provenanceInfo: String = "Prepared with organic British ingredients directly sourced from local family estates."
)

@Entity(tableName = "menu_items")
data class MenuItemEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val restaurantId: Long,
    val name: String,
    val description: String,
    val price: Double,
    val category: String, // Starter, Main, Dessert, Pairing
    val allergens: String, // comma-separated e.g. "milk, fish"
    val ingredients: String,
    val servingSize: String = "Serves one",
    val preparationTimeMinutes: Int = 15
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val restaurantId: Long,
    val restaurantName: String,
    val status: String, // KITCHEN_ACCEPTED, PREPARING, PACKED, QUALITY_CHECKED, COURIER_ASSIGNED, COLLECTED, IN_TRANSIT, ARRIVING, DELIVERED, CUSTOMER_CONFIRMED
    val deliveryWindow: String, // e.g. "18:30 - 18:45"
    val totalPrice: Double,
    val deliveryFee: Double = 7.00,
    val createdAt: Long = System.currentTimeMillis(),
    val deliveryAddress: String = "London SW1X 7XL",
    val customerName: String = "Thomas Aureom",
    val reheatNotes: String = "Serve immediately. Keep warm at 65°C.",
    val temperatureReading: Double = 68.0, // simulated temperature telemetries
    val courierName: String = "Alastair Sterling",
    val rating: Int = 0, // 1-5 stars from customer review
    val ratingComment: String = ""
)

@Entity(tableName = "order_events")
data class OrderEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val orderId: Long,
    val state: String,
    val timestamp: Long = System.currentTimeMillis(),
    val note: String
)

@Entity(tableName = "wallet_transactions")
data class WalletTransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val walletType: String, // "CBDC" (Digital Pound) or "LIGHTNING"
    val transactionType: String, // "DEPOSIT", "PAYMENT", "REFUND"
    val amount: Double,
    val timestamp: Long = System.currentTimeMillis(),
    val description: String,
    val reference: String
)

@Entity(tableName = "couriers")
data class CourierEntity(
    @PrimaryKey val id: Long = 1,
    val name: String = "Alastair Sterling",
    val vehicleType: String = "Electric Executive Carriage",
    val latitude: Double = 51.4988,
    val longitude: Double = -0.1485,
    val rating: Double = 4.98,
    val punctualityRate: String = "99.6%",
    val temperatureSLA: String = "100.0% Compliant"
)
