package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Aureom Table Brand Color Palette (Premium British Luxury)
val AureomNavy = Color(0xFF0B0F19)       // Deep Luxury Navy (Primary Background / Contrast)
val AureomCharcoal = Color(0xFF1E2330)   // Dark Charcoal (Cards / Accent backgrounds)
val AureomStone = Color(0xFF4B5263)      // Elegant Slate Stone
val AureomBrass = Color(0xFFC5A880)      // Restrained, premium gold/brass (not yellow/neon)
val AureomWarmWhite = Color(0xFFF7F5F0)  // Cream Paper (Light theme Background)
val AureomIvory = Color(0xFFFCFAF5)      // Ivory White
val AureomBurgundy = Color(0xFF5E1A2B)   // Muted Burgundy
val AureomLightGray = Color(0xFFE5E7EB)  // Soft light gray for borders
val AureomGoldAccent = Color(0xFFD4AF37) // Subtle metallic gold
val TextPrimaryDark = Color(0xFFFCFAF5)  // Ivory for text on dark background
val TextSecondaryDark = Color(0xFF9EABB8)// Muted slate for subtitle text
val TextPrimaryLight = Color(0xFF0B0F19) // Deep navy for text on light background
val TextSecondaryLight = Color(0xFF4B5263)// Muted stone for text on light background
