package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

// 1. SavedEntity representing items pinned to "My Broadway" (Shows, Actors, Theatres)
@Entity(tableName = "saved_entities")
data class SavedEntity(
    @PrimaryKey val id: String, // e.g., "show_hamilton", "actor_leslie"
    val type: String,          // "show", "actor", "theatre"
    val name: String,
    val subtitle: String,
    val imageResName: String,  // reference to mock drawable or visual identifier
    val savedAt: Long = System.currentTimeMillis()
)

// 2. SimulatedTicket representing tickets booked by the user
@Entity(tableName = "simulated_tickets")
data class SimulatedTicket(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val showId: String,
    val showTitle: String,
    val theatreName: String,
    val dateTime: String,
    val section: String,
    val row: String,
    val seats: String,
    val totalPrice: Double,
    val quantity: Int,
    val bookedAt: Long = System.currentTimeMillis()
)

// 3. UserReview representing reviews submitted by the user
@Entity(tableName = "user_reviews")
data class UserReview(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val showId: String,
    val showTitle: String,
    val rating: Float,
    val reviewText: String,
    val reviewDate: Long = System.currentTimeMillis()
)

// DAO
@Dao
interface BroadwayDao {
    // Saved Entities
    @Query("SELECT * FROM saved_entities ORDER BY savedAt DESC")
    fun getSavedEntitiesFlow(): Flow<List<SavedEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveEntity(entity: SavedEntity)

    @Query("DELETE FROM saved_entities WHERE id = :id")
    suspend fun deleteEntityById(id: String)

    @Query("SELECT EXISTS(SELECT 1 FROM saved_entities WHERE id = :id)")
    fun isEntitySavedFlow(id: String): Flow<Boolean>

    // Simulated Tickets
    @Query("SELECT * FROM simulated_tickets ORDER BY bookedAt DESC")
    fun getTicketsFlow(): Flow<List<SimulatedTicket>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun bookTicket(ticket: SimulatedTicket)

    // User Reviews
    @Query("SELECT * FROM user_reviews WHERE showId = :showId ORDER BY reviewDate DESC")
    fun getReviewsForShowFlow(showId: String): Flow<List<UserReview>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addReview(review: UserReview)
}

// Database Room declaration
@Database(
    entities = [SavedEntity::class, SimulatedTicket::class, UserReview::class],
    version = 1,
    exportSchema = false
)
abstract class BroadwayDatabase : RoomDatabase() {
    abstract fun dao(): BroadwayDao
}
