package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.*
import com.example.ui.theme.*

// --- MAIN ENTRANCE CONTROLLER FOR ALL THEMED SCREENS ---
@Composable
fun BroadwayScreenRouter(viewModel: BroadwayViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    Box(modifier = Modifier.fillMaxSize().background(DeepBlack)) {
        AnimatedContent(
            targetState = currentScreen,
            transitionSpec = {
                fadeIn() togetherWith fadeOut()
            },
            label = "ScreenTransition"
        ) { screen ->
            when (screen) {
                "Home" -> HomeScreen(viewModel)
                "Shows" -> DiscoveryScreen(viewModel)
                "Tonight" -> TonightModeScreen(viewModel)
                "Tickets" -> SeatingMapScreen(viewModel)
                "Me" -> PersonalBroadwayScreen(viewModel)
                "News" -> NewsScreen(viewModel)
                "Music" -> MusicScreen(viewModel)
                "History" -> HistoryTimelineScreen(viewModel)
                "Concierge" -> ConciergeScreen(viewModel)
                "NightOut" -> NightOutScreen(viewModel)
                "Pass" -> BroadwayPassScreen(viewModel)
                "TheatreDetail" -> TheatreDetailScreen(viewModel)
                "ActorDetail" -> ActorDetailScreen(viewModel)
                "ShowDetail" -> ShowDetailScreen(viewModel)
                else -> HomeScreen(viewModel)
            }
        }
        
        // Fictional bottom player persistent on screens except checkout/detail
        if (currentScreen != "Tickets" && currentScreen != "ShowDetail") {
            Box(modifier = Modifier.align(Alignment.BottomCenter)) {
                BottomMusicPlayerBar(viewModel)
            }
        }
    }
}

// --- 1. HOME SCREEN & HERO BANNER ---
@Composable
fun HomeScreen(viewModel: BroadwayViewModel) {
    val context = LocalContext.current
    
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp), // Clear bottom player
        contentPadding = PaddingValues(bottom = 16.dp)
    ) {
        // Hero Image Cover
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(380.dp)
            ) {
                // Background image from generated asset
                Image(
                    painter = painterResource(id = R.drawable.broadway_hero),
                    contentDescription = "Manhattan Lights Nighttime",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                // Dark glass overlay gradient
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(
                                    Color.Transparent,
                                    DeepBlack.copy(alpha = 0.5f),
                                    DeepBlack
                                )
                            )
                        )
                )

                // Branding content overlay
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.Bottom
                ) {
                    Text(
                        text = "BROADWAY",
                        style = MaterialTheme.typography.displayLarge.copy(
                            color = WarmIvory,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 44.sp
                        ),
                        letterSpacing = 4.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "THE GREATEST THEATRE DISTRICT IN THE WORLD.",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = ChampagneGold,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Discover what's playing, find your seats, follow your favourite performers and experience Broadway before you even arrive in New York.",
                        style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvory.copy(alpha = 0.8f)),
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = { viewModel.navigateTo("Shows") },
                            colors = ButtonDefaults.buttonColors(containerColor = TheatreRed),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("EXPLORE SHOWS", style = MaterialTheme.typography.labelLarge.copy(color = Color.White))
                        }
                        OutlinedButton(
                            onClick = { viewModel.navigateTo("Tonight") },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = ChampagneGold),
                            shape = RoundedCornerShape(4.dp),
                            border = BorderStroke(1.dp, FineBorderColor),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("TONIGHT ON BROADWAY", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }

        // Tonight Live Ticker
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TONIGHT ON BROADWAY",
                        style = MaterialTheme.typography.displayMedium.copy(color = WarmIvory, fontSize = 22.sp),
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "LIVE SEATING AND REAL-TIME MARQUEES",
                        style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted)
                    )
                }
                Box(
                    modifier = Modifier
                        .background(LiveGreen.copy(alpha = 0.15f), CircleShape)
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .background(LiveGreen, CircleShape)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("LIVE", style = MaterialTheme.typography.labelSmall.copy(color = LiveGreen))
                    }
                }
            }
        }

        // Tonight Show Cards
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Static sample shows
                val staticShows = listOf(
                    Triple("HAMILTON", "Richard Rodgers Theatre", "From $99"),
                    Triple("THE LION KING", "Minskoff Theatre", "From $89"),
                    Triple("WICKED", "Gershwin Theatre", "From $109")
                )
                items(staticShows) { item ->
                    val show = viewModel.filteredShows.value.find { it.title == item.first }
                    LiveShowCard(
                        title = item.first,
                        theatre = item.second,
                        price = item.third,
                        showId = show?.id ?: "hamilton",
                        onClick = {
                            if (show != null) {
                                viewModel.selectShow(show)
                            }
                        }
                    )
                }
            }
        }

        // Quick Luxury Services Grid
        item {
            Text(
                text = "OPERATING SYSTEM",
                style = MaterialTheme.typography.labelLarge.copy(color = ChampagneGold),
                modifier = Modifier.padding(start = 16.dp, top = 28.dp, bottom = 8.dp)
            )
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionItem(
                    title = "Tonight",
                    subtitle = "Control Centre",
                    icon = Icons.Default.TheaterComedy,
                    onClick = { viewModel.navigateTo("Tonight") },
                    modifier = Modifier.weight(1f)
                )
                QuickActionItem(
                    title = "Night Out",
                    subtitle = "Plan Evening",
                    icon = Icons.Default.LocalBar,
                    onClick = { viewModel.navigateTo("NightOut") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                QuickActionItem(
                    title = "Concierge",
                    subtitle = "AI Recommendations",
                    icon = Icons.Default.Assistant,
                    onClick = { viewModel.navigateTo("Concierge") },
                    modifier = Modifier.weight(1f)
                )
                QuickActionItem(
                    title = "Pass",
                    subtitle = "Digital Member",
                    icon = Icons.Default.CardMembership,
                    onClick = { viewModel.navigateTo("Pass") },
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // History Sneak
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
                    .clickable { viewModel.navigateTo("History") },
                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                border = BorderStroke(1.dp, FineBorderColor)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "THE HISTORY OF BROADWAY",
                            style = MaterialTheme.typography.displayMedium.copy(color = ChampagneGold, fontSize = 16.sp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Explore the grand physical timeline of theatre from the 1900s birth of the Great White Way to 2030s technology.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvoryMuted)
                        )
                    }
                    Icon(
                        imageVector = Icons.Default.ArrowForward,
                        contentDescription = "Forward",
                        tint = ChampagneGold
                    )
                }
            }
        }
    }
}

@Composable
fun LiveShowCard(title: String, theatre: String, price: String, showId: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .width(200.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
        border = BorderStroke(1.dp, FineBorderColor)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .background(Color.DarkGray)
            ) {
                // Show generic themed graphic
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color(0xFF221111), Color(0xFF0F0000))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "✦",
                            style = androidx.compose.ui.text.TextStyle(color = ChampagneGold, fontSize = 28.sp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = title,
                            style = MaterialTheme.typography.headlineLarge.copy(
                                color = WarmIvory,
                                fontSize = 18.sp,
                                textAlign = TextAlign.Center
                            )
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(8.dp)
                        .background(DeepBlack.copy(alpha = 0.75f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(price, style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                }
            }
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = theatre,
                    style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Starts 7:30 PM", style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, "Rating", tint = ChampagneGold, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(2.dp))
                        Text("4.9", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvory))
                    }
                }
            }
        }
    }
}

@Composable
fun QuickActionItem(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .height(72.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
        border = BorderStroke(1.dp, FineBorderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(TheatreRed.copy(alpha = 0.12f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, title, tint = TheatreRed, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(title, style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory))
                Text(subtitle, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
            }
        }
    }
}


// --- 2. SHOW DISCOVERY SCREEN ---
@Composable
fun DiscoveryScreen(viewModel: BroadwayViewModel) {
    val shows by viewModel.filteredShows.collectAsState()
    val selectedFilter by viewModel.selectedFilter.collectAsState()
    val selectedSort by viewModel.selectedSort.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val searchResults by viewModel.searchResults.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp)
    ) {
        // Upper search header
        Column(
            modifier = Modifier
                .background(DarkManhattanGrey)
                .padding(top = 44.dp, start = 16.dp, end = 16.dp, bottom = 12.dp)
        ) {
            Text(
                text = "DISCOVER BROADWAY",
                style = MaterialTheme.typography.displayMedium.copy(color = WarmIvory),
                letterSpacing = 1.5.sp
            )
            Spacer(modifier = Modifier.height(12.dp))
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.updateSearchQuery(it) },
                placeholder = { Text("Search shows, performers, theatres...", color = WarmIvoryMuted) },
                leadingIcon = { Icon(Icons.Default.Search, "Search", tint = WarmIvoryMuted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = WarmIvory,
                    unfocusedTextColor = WarmIvory,
                    focusedContainerColor = DeepBlack,
                    unfocusedContainerColor = DeepBlack,
                    focusedBorderColor = ChampagneGold,
                    unfocusedBorderColor = FineBorderColor
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (searchQuery.isNotEmpty()) {
            // Search Results Mode
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                if (searchResults.isEmpty()) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth().padding(40.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(Icons.Default.SentimentDissatisfied, "No result", tint = WarmIvoryMuted, modifier = Modifier.size(48.dp))
                            Spacer(modifier = Modifier.height(12.dp))
                            Text("No results matching \"$searchQuery\"", style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvoryMuted))
                        }
                    }
                } else {
                    searchResults.forEach { (category, items) ->
                        item {
                            Text(category.uppercase(), style = MaterialTheme.typography.labelLarge.copy(color = ChampagneGold))
                        }
                        items(items) { item ->
                            when (item) {
                                is Show -> {
                                    SearchResultRow(
                                        title = item.title,
                                        subtitle = item.genre + " — " + item.theatre,
                                        onClick = { viewModel.selectShow(item) }
                                    )
                                }
                                is Actor -> {
                                    SearchResultRow(
                                        title = item.name,
                                        subtitle = item.roleType + " • " + item.currentShow,
                                        onClick = { viewModel.selectActor(item) }
                                    )
                                }
                                is Venue -> {
                                    SearchResultRow(
                                        title = item.name,
                                        subtitle = "Now playing: " + item.currentProduction,
                                        onClick = { viewModel.selectVenue(item) }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Main Discovery Filter view
            LazyRow(
                modifier = Modifier.padding(vertical = 12.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val filters = listOf("All", "Musicals", "Plays", "Tony Winners", "New")
                items(filters) { filter ->
                    FilterChip(
                        text = filter,
                        selected = selectedFilter == filter,
                        onClick = { viewModel.setFilter(filter) }
                    )
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${shows.size} productions",
                    style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted)
                )
                // Minimalist toggle for sorting
                Row(
                    modifier = Modifier.clickable {
                        val nextSort = if (selectedSort == "Popular") "Lowest Price" else "Popular"
                        viewModel.setSort(nextSort)
                    },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Sort, "Sort", tint = ChampagneGold, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(selectedSort, style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(shows) { show ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.selectShow(show) },
                        colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                        border = BorderStroke(1.dp, FineBorderColor)
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(180.dp)
                                    .background(
                                        Brush.verticalGradient(
                                            colors = listOf(Color(0xFF1F1212), Color(0xFF0C0707))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = show.title,
                                    style = MaterialTheme.typography.headlineLarge.copy(
                                        color = WarmIvory,
                                        fontSize = 15.sp,
                                        textAlign = TextAlign.Center
                                    ),
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = show.title,
                                    style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory, fontSize = 14.sp),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = show.theatre,
                                    style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("From \$${show.fromPrice.toInt()}", style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Star, "Rating", tint = ChampagneGold, modifier = Modifier.size(10.dp))
                                        Spacer(modifier = Modifier.width(2.dp))
                                        Text(show.rating.toString(), style = MaterialTheme.typography.labelSmall.copy(color = WarmIvory))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FilterChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        modifier = Modifier.clickable { onClick() },
        color = if (selected) TheatreRed else DarkManhattanGrey,
        shape = RoundedCornerShape(4.dp),
        border = BorderStroke(1.dp, if (selected) TheatreRed else FineBorderColor)
    ) {
        Text(
            text = text,
            style = MaterialTheme.typography.labelSmall.copy(color = Color.White),
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
        )
    }
}

@Composable
fun SearchResultRow(title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
        border = BorderStroke(1.dp, FineBorderColor)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory))
                Text(subtitle, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
            }
            Icon(Icons.Default.ArrowForward, "Open", tint = ChampagneGold, modifier = Modifier.size(16.dp))
        }
    }
}


// --- 3. SHOW DETAIL PAGE ---
@Composable
fun ShowDetailScreen(viewModel: BroadwayViewModel) {
    val show by viewModel.selectedShow.collectAsState()
    val savedEntities by viewModel.savedEntities.collectAsState()
    val listState = rememberScrollState()

    var activeSubTab by remember { mutableStateOf("SYNOPSIS") } // SYNOPSIS, CAST, REVIEWS, HISTORY

    if (show == null) return

    val currentShow = show!!
    val isSaved = savedEntities.any { it.id == "show_${currentShow.id}" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp)
    ) {
        // Back navigation
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 44.dp, start = 16.dp, end = 16.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Default.ArrowBack, "Back", tint = WarmIvory)
            }
            Text(currentShow.title, style = MaterialTheme.typography.headlineLarge.copy(color = WarmIvory))
            IconButton(onClick = {
                viewModel.toggleSaveEntity(
                    id = "show_${currentShow.id}",
                    type = "show",
                    name = currentShow.title,
                    subtitle = currentShow.genre + " — " + currentShow.theatre,
                    imageResName = "broadway_icon"
                )
            }) {
                Icon(
                    imageVector = if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                    contentDescription = "Save",
                    tint = if (isSaved) ChampagneGold else WarmIvory
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(listState)
        ) {
            // Visual Banner Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color(0xFF331111), DeepBlack)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(20.dp)) {
                    Text(
                        currentShow.title,
                        style = MaterialTheme.typography.displayLarge.copy(color = WarmIvory, textAlign = TextAlign.Center, fontSize = 28.sp)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        currentShow.theatre,
                        style = MaterialTheme.typography.titleMedium.copy(color = ChampagneGold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        Text(currentShow.genre, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                        Text("•", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                        Text(currentShow.duration, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                    }
                }
            }

            // Quick Buy Ticket section
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                border = BorderStroke(1.dp, FineBorderColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("TICKET STARTS AT", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                            Text("\$${currentShow.fromPrice.toInt()}", style = MaterialTheme.typography.displayMedium.copy(color = ChampagneGold, fontSize = 24.sp))
                        }
                        Button(
                            onClick = { viewModel.startBooking(currentShow) },
                            colors = ButtonDefaults.buttonColors(containerColor = TheatreRed),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("BUY TICKETS", style = MaterialTheme.typography.labelLarge.copy(color = Color.White))
                        }
                    }
                }
            }

            // Editorial Quote Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(FineBorderColor)
                    .padding(12.dp)
            ) {
                Text(
                    text = currentShow.bannerText,
                    style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold, textAlign = TextAlign.Center),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Tabs switcher
            ScrollableTabRow(
                selectedTabIndex = when (activeSubTab) {
                    "SYNOPSIS" -> 0
                    "CAST" -> 1
                    "REVIEWS" -> 2
                    "HISTORY" -> 3
                    else -> 0
                },
                containerColor = DeepBlack,
                contentColor = ChampagneGold,
                edgePadding = 16.dp,
                divider = {}
            ) {
                val subTabs = listOf("SYNOPSIS", "CAST", "REVIEWS", "HISTORY")
                subTabs.forEach { tab ->
                    Tab(
                        selected = activeSubTab == tab,
                        onClick = { activeSubTab = tab },
                        text = { Text(tab, style = MaterialTheme.typography.labelSmall) }
                    )
                }
            }

            // Sub tab content
            Column(modifier = Modifier.padding(16.dp)) {
                when (activeSubTab) {
                    "SYNOPSIS" -> {
                        Text(
                            text = currentShow.synopsis,
                            style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory, lineHeight = 24.sp)
                        )
                        Spacer(modifier = Modifier.height(16.dp))
                        Text("Creative Team", style = MaterialTheme.typography.titleMedium.copy(color = ChampagneGold))
                        Spacer(modifier = Modifier.height(8.dp))
                        currentShow.creativeTeam.forEach { creative ->
                            Text("• $creative", style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvoryMuted))
                        }
                    }
                    "CAST" -> {
                        Text("Featured Performers", style = MaterialTheme.typography.titleMedium.copy(color = ChampagneGold))
                        Spacer(modifier = Modifier.height(12.dp))
                        currentShow.cast.forEach { castMember ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                                border = BorderStroke(1.dp, FineBorderColor)
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(40.dp)
                                            .background(FineBorderColor, CircleShape),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Person, "Actor", tint = WarmIvory)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Text(
                                        text = castMember,
                                        style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory)
                                    )
                                }
                            }
                        }
                    }
                    "REVIEWS" -> {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Critic Sentiment", style = MaterialTheme.typography.titleMedium.copy(color = ChampagneGold))
                            // Write review button
                            Text(
                                text = "WRITE A REVIEW",
                                style = MaterialTheme.typography.labelSmall.copy(color = TheatreRed, fontWeight = FontWeight.Bold),
                                modifier = Modifier.clickable {
                                    // Simulated write review flow
                                }
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        currentShow.reviews.forEach { critic ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                                border = BorderStroke(1.dp, FineBorderColor)
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text(critic.criticName, style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory))
                                        Row {
                                            repeat(critic.rating) {
                                                Icon(Icons.Default.Star, "Star", tint = ChampagneGold, modifier = Modifier.size(12.dp))
                                            }
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "\"${critic.excerpt}\"",
                                        style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvoryMuted, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                                    )
                                }
                            }
                        }
                    }
                    "HISTORY" -> {
                        Text(
                            text = currentShow.history,
                            style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory, lineHeight = 24.sp)
                        )
                    }
                }
            }
        }
    }
}


// --- 4. TICKET EXPERIENCE / SEATING MAP ---
@Composable
fun SeatingMapScreen(viewModel: BroadwayViewModel) {
    val show by viewModel.bookingShow.collectAsState()
    val seatsCount by viewModel.bookingSeatsCount.collectAsState()
    val section by viewModel.bookingSection.collectAsState()
    val row by viewModel.bookingRow.collectAsState()
    val seats by viewModel.bookingSeats.collectAsState()
    val totalPrice by viewModel.bookingTotalPrice.collectAsState()
    val complete by viewModel.isCheckoutComplete.collectAsState()
    val loading by viewModel.isConciergeLoading.collectAsState()

    if (show == null) return

    val currentShow = show!!

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp)
            .background(DeepBlack)
    ) {
        // Upper back
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 44.dp, start = 16.dp, end = 16.dp, bottom = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.Default.ArrowBack, "Back", tint = WarmIvory)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text("RESERVE SEATS", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                Text(currentShow.title, style = MaterialTheme.typography.headlineLarge.copy(color = WarmIvory))
            }
        }

        if (complete) {
            // Confirmation Screen
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.CheckCircle, "Success", tint = LiveGreen, modifier = Modifier.size(72.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "RESERVATION CONFIRMED",
                    style = MaterialTheme.typography.displayMedium.copy(color = WarmIvory)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Your booking for ${currentShow.title} has been successfully registered on the Broadway 2030s Operating System.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvoryMuted, textAlign = TextAlign.Center)
                )
                
                Spacer(modifier = Modifier.height(32.dp))
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                    border = BorderStroke(1.dp, FineBorderColor)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("SMART TICKET CREDENTIAL", style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Section", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                            Text(section, style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Seats", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                            Text("Row $row, Seats $seats", style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory))
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Location", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                            Text(currentShow.theatre, style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(32.dp))
                Button(
                    onClick = { viewModel.navigateTo("Tonight") },
                    colors = ButtonDefaults.buttonColors(containerColor = TheatreRed),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("OPEN TONIGHT DASHBOARD", style = MaterialTheme.typography.labelLarge.copy(color = Color.White))
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Interactive Theatre Stage indicator
                item {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(0.6f)
                                .height(8.dp)
                                .background(ChampagneGold)
                        )
                        Text(
                            text = "STAGE",
                            style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold, letterSpacing = 2.sp),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                // Interactive Seating Map Selection Boxes
                item {
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(vertical = 12.dp)
                    ) {
                        SeatingSectionSelector(
                            name = "Orchestra",
                            desc = "Front-row visual proximity and premium spatial audio",
                            price = "\$199",
                            selected = section == "Orchestra",
                            onClick = { viewModel.updateSection("Orchestra") }
                        )
                        SeatingSectionSelector(
                            name = "Front Mezzanine",
                            desc = "Elevated, flawless panoramic view of full stage choreography",
                            price = "\$175",
                            selected = section == "Front Mezzanine",
                            onClick = { viewModel.updateSection("Front Mezzanine") }
                        )
                        SeatingSectionSelector(
                            name = "Rear Mezzanine",
                            desc = "Excellent vocal clarity and balanced acoustics",
                            price = "\$125",
                            selected = section == "Rear Mezzanine",
                            onClick = { viewModel.updateSection("Rear Mezzanine") }
                        )
                    }
                }

                // Seat Quantity Picker
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                        border = BorderStroke(1.dp, FineBorderColor)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("TICKET QUANTITY", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                                Text("$seatsCount Tickets", style = MaterialTheme.typography.headlineLarge.copy(color = WarmIvory, fontSize = 18.sp))
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(
                                    onClick = { viewModel.updateSeatsCount(seatsCount - 1) },
                                    modifier = Modifier.background(FineBorderColor, CircleShape)
                                ) {
                                    Icon(Icons.Default.Remove, "Less", tint = WarmIvory)
                                }
                                Spacer(modifier = Modifier.width(16.dp))
                                IconButton(
                                    onClick = { viewModel.updateSeatsCount(seatsCount + 1) },
                                    modifier = Modifier.background(FineBorderColor, CircleShape)
                                ) {
                                    Icon(Icons.Default.Add, "More", tint = WarmIvory)
                                }
                            }
                        }
                    }
                }

                // Simulated checkout panel
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                        border = BorderStroke(1.dp, FineBorderColor)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("BOOKING SUMMARY", style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Section", style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvoryMuted))
                                Text(section, style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvory))
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Row & Seats", style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvoryMuted))
                                Text("Row $row, Seats $seats", style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvory))
                            }
                            Divider(modifier = Modifier.padding(vertical = 10.dp), color = FineBorderColor)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Total", style = MaterialTheme.typography.headlineLarge.copy(color = WarmIvory, fontSize = 20.sp))
                                Text("\$${totalPrice.toInt()}", style = MaterialTheme.typography.displayMedium.copy(color = ChampagneGold, fontSize = 22.sp))
                            }
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = { viewModel.completeCheckout() },
                                colors = ButtonDefaults.buttonColors(containerColor = TheatreRed),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                if (loading) {
                                    CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                                } else {
                                    Text("CONTINUE TO CHECKOUT", style = MaterialTheme.typography.labelLarge.copy(color = Color.White))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SeatingSectionSelector(name: String, desc: String, price: String, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = if (selected) TheatreRed.copy(alpha = 0.1f) else DarkManhattanGrey),
        border = BorderStroke(1.dp, if (selected) ChampagneGold else FineBorderColor)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = selected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(selectedColor = ChampagneGold, unselectedColor = WarmIvoryMuted)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(name, style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory))
                Text(desc, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
            }
            Text(price, style = MaterialTheme.typography.displayMedium.copy(color = ChampagneGold, fontSize = 18.sp))
        }
    }
}


// --- 5. "TONIGHT" MODE CONTROL CENTRE ---
@Composable
fun TonightModeScreen(viewModel: BroadwayViewModel) {
    val bookedTickets by viewModel.bookedTickets.collectAsState()
    val countdownMinutes by viewModel.countdownMinutes.collectAsState()
    val subwayStatus by viewModel.subwayStatus.collectAsState()
    val congestionLevel by viewModel.congestionLevel.collectAsState()
    val currentTemp by viewModel.currentTemp.collectAsState()

    val nextShowName = if (bookedTickets.isNotEmpty()) bookedTickets.first().showTitle else "Wicked"
    val nextShowVenue = if (bookedTickets.isNotEmpty()) bookedTickets.first().theatreName else "Gershwin Theatre"
    val nextSeats = if (bookedTickets.isNotEmpty()) "Row ${bookedTickets.first().row}, Seats ${bookedTickets.first().seats}" else "Row F, Seats 12-13"

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp),
        contentPadding = PaddingValues(top = 44.dp, bottom = 16.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "TONIGHT",
                style = MaterialTheme.typography.displayLarge.copy(color = WarmIvory),
                letterSpacing = 2.sp
            )
            Text(
                text = "LIVE BROADWAY OPERATING SYSTEM",
                style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold)
            )
        }

        // Live Countdown Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                border = BorderStroke(1.dp, TheatreRed)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text("YOUR NEXT SHOW STARTS IN", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "1h 42m",
                        style = MaterialTheme.typography.displayLarge.copy(color = TheatreRed, fontSize = 48.sp),
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("$nextShowName — $nextShowVenue", style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory))
                    Text(nextSeats, style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                    
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            // Start navigation routing demo
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = TheatreRed),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("START JOURNEY IN PATHFINDER", style = MaterialTheme.typography.labelLarge.copy(color = Color.White))
                    }
                }
            }
        }

        // Real-Time Metropolitan Info System
        item {
            Text(
                text = "LIVE METROPOLITAN CONGESTION",
                style = MaterialTheme.typography.labelLarge.copy(color = ChampagneGold)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                border = BorderStroke(1.dp, FineBorderColor)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    MetropolitanMetricRow(
                        label = "Times Square Crowd Density",
                        value = congestionLevel,
                        icon = Icons.Default.Groups
                    )
                    MetropolitanMetricRow(
                        label = "Subway Status",
                        value = subwayStatus,
                        icon = Icons.Default.DirectionsSubway
                    )
                    MetropolitanMetricRow(
                        label = "Weather Midtown NY",
                        value = currentTemp,
                        icon = Icons.Default.WbSunny
                    )
                }
            }
        }

        // Smart Routing Alternatives
        item {
            Text(
                text = "SMART ROUTING RECOMMENDATIONS",
                style = MaterialTheme.typography.labelLarge.copy(color = ChampagneGold)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                border = BorderStroke(1.dp, FineBorderColor)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    RoutingOptionRow("Walking", "14 min walk", "0 calories • Direct footpath path", isRecommended = true)
                    RoutingOptionRow("MTA subway (Q Line)", "8 min transit", "Express route • Flawless luxury cars", isRecommended = false)
                    RoutingOptionRow("Autonomous Taxi/Rideshare", "6 min ride", "Estimated cost: \$18.00 • Low congestion path", isRecommended = false)
                }
            }
        }
    }
}

@Composable
fun MetropolitanMetricRow(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .background(FineBorderColor, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, label, tint = ChampagneGold, modifier = Modifier.size(16.dp))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(label, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
            Text(value, style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory))
        }
    }
}

@Composable
fun RoutingOptionRow(name: String, time: String, detail: String, isRecommended: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (isRecommended) TheatreRed.copy(alpha = 0.08f) else Color.Transparent)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(name, style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory))
                if (isRecommended) {
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .background(TheatreRed.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text("RECOMMENDED", style = MaterialTheme.typography.labelSmall.copy(color = TheatreRed, fontWeight = FontWeight.Bold))
                    }
                }
            }
            Text(detail, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
        }
        Text(time, style = MaterialTheme.typography.displayMedium.copy(color = ChampagneGold, fontSize = 16.sp))
    }
}


// --- 6. PERSONAL BROADWAY / "ME" SCREEN ---
@Composable
fun PersonalBroadwayScreen(viewModel: BroadwayViewModel) {
    val savedEntities by viewModel.savedEntities.collectAsState()
    val bookedTickets by viewModel.bookedTickets.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp),
        contentPadding = PaddingValues(top = 44.dp, bottom = 16.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "MY BROADWAY",
                style = MaterialTheme.typography.displayLarge.copy(color = WarmIvory),
                letterSpacing = 2.sp
            )
            Text(
                text = "YOUR EXCLUSIVE THEATRE DASHBOARD",
                style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold)
            )
        }

        // Tickets section
        item {
            Text("YOUR ACTIVE PASSES & TICKETS", style = MaterialTheme.typography.labelLarge.copy(color = ChampagneGold))
        }

        if (bookedTickets.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                    border = BorderStroke(1.dp, FineBorderColor)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.ConfirmationNumber, "No Tickets", tint = WarmIvoryMuted, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No tickets booked tonight", style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory))
                        Text("Purchase active seating to unlock digital programme guides and entry credentials.", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted), textAlign = TextAlign.Center)
                    }
                }
            }
        } else {
            items(bookedTickets) { ticket ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                    border = BorderStroke(1.dp, ChampagneGold)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(ticket.showTitle, style = MaterialTheme.typography.headlineLarge.copy(color = WarmIvory, fontSize = 20.sp))
                            Box(
                                modifier = Modifier
                                    .background(LiveGreen.copy(alpha = 0.15f), RoundedCornerShape(2.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("ACTIVE", style = MaterialTheme.typography.labelSmall.copy(color = LiveGreen))
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(ticket.theatreName, style = MaterialTheme.typography.bodyLarge.copy(color = ChampagneGold))
                        Text("Row ${ticket.row}, Seats ${ticket.seats}", style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvoryMuted))
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Digital Pass Locked", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                            Text("QR Code Ready ✦", style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Favourites list
        item {
            Text("SAVED SHOWS & THEATRES", style = MaterialTheme.typography.labelLarge.copy(color = ChampagneGold))
        }

        if (savedEntities.isEmpty()) {
            item {
                Text(
                    "You haven't saved any shows, actors, or theatres yet. Explore Broadway and add items to your watchlist.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvoryMuted)
                )
            }
        } else {
            items(savedEntities) { entity ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            // Navigate to details based on type
                        },
                    colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                    border = BorderStroke(1.dp, FineBorderColor)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .background(FineBorderColor, RoundedCornerShape(4.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Bookmark, "Saved", tint = ChampagneGold)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(entity.name, style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory))
                            Text(entity.subtitle, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                        }
                        IconButton(onClick = { viewModel.toggleSaveEntity(entity.id, entity.type, entity.name, entity.subtitle, entity.imageResName) }) {
                            Icon(Icons.Default.Delete, "Remove", tint = TheatreRed)
                        }
                    }
                }
            }
        }
    }
}


// --- 7. MUSIC STREAMING COMPOSABLE AND PERSISTENT FOOTER ---
@Composable
fun MusicScreen(viewModel: BroadwayViewModel) {
    val currentTrack by viewModel.currentPlayingTrack.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    
    val originalCastTracks = listOf(
        Track("t1", "Alexander Hamilton", "Hamilton Cast", "3:56"),
        Track("t2", "My Shot", "Lin-Manuel Miranda & Hamilton Cast", "5:33"),
        Track("t3", "Circle of Life", "Lindiwe Dlamini & Lion King Cast", "4:32"),
        Track("t4", "Defying Gravity", "Idina Menzel & Kristin Chenoweth", "5:56")
    )
    val classicsTracks = listOf(
        Track("t5", "The Phantom of the Opera", "Michael Crawford & Sarah Brightman", "4:20"),
        Track("t6", "Memory", "Betty Buckley", "4:15"),
        Track("t7", "Don't Rain on My Parade", "Barbra Streisand", "2:45")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp),
        contentPadding = PaddingValues(top = 44.dp, bottom = 16.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "BROADWAY MUSIC",
                style = MaterialTheme.typography.displayLarge.copy(color = WarmIvory),
                letterSpacing = 2.sp
            )
            Text(
                text = "THEATRICAL STREAMING LIBRARY",
                style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold)
            )
        }

        item {
            Text("Original Cast Albums", style = MaterialTheme.typography.labelLarge.copy(color = ChampagneGold))
        }

        items(originalCastTracks) { track ->
            TrackRow(
                track = track,
                isActive = currentTrack?.id == track.id,
                isPlaying = isPlaying,
                onPlayClick = { viewModel.selectTrack(track) }
            )
        }

        item {
            Text("Broadway Classics", style = MaterialTheme.typography.labelLarge.copy(color = ChampagneGold))
        }

        items(classicsTracks) { track ->
            TrackRow(
                track = track,
                isActive = currentTrack?.id == track.id,
                isPlaying = isPlaying,
                onPlayClick = { viewModel.selectTrack(track) }
            )
        }
    }
}

@Composable
fun TrackRow(track: Track, isActive: Boolean, isPlaying: Boolean, onPlayClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onPlayClick() },
        colors = CardDefaults.cardColors(containerColor = if (isActive) TheatreRed.copy(alpha = 0.12f) else DarkManhattanGrey),
        border = BorderStroke(1.dp, if (isActive) ChampagneGold else FineBorderColor)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .background(FineBorderColor, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isActive && isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Play",
                    tint = if (isActive) ChampagneGold else WarmIvory
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(track.title, style = MaterialTheme.typography.titleMedium.copy(color = if (isActive) ChampagneGold else WarmIvory))
                Text(track.artist, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
            }
            Text(track.duration, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
        }
    }
}

@Composable
fun BottomMusicPlayerBar(viewModel: BroadwayViewModel) {
    val currentTrack by viewModel.currentPlayingTrack.collectAsState()
    val isPlaying by viewModel.isPlaying.collectAsState()
    val progress by viewModel.musicProgress.collectAsState()

    val track = currentTrack ?: Track("t2", "My Shot", "Lin-Manuel Miranda & Hamilton Cast", "5:33")

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(68.dp)
            .clickable { viewModel.navigateTo("Music") },
        color = DarkManhattanGrey,
        border = BorderStroke(1.dp, FineBorderColor)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier.fillMaxWidth(),
                color = TheatreRed,
                trackColor = FineBorderColor
            )
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(FineBorderColor, RoundedCornerShape(4.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.MusicNote, "Music", tint = ChampagneGold, modifier = Modifier.size(16.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = track.title,
                            style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory, fontSize = 14.sp),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = track.artist,
                            style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.togglePlay() }) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = "PlayPause",
                            tint = WarmIvory
                        )
                    }
                    IconButton(onClick = {
                        // Skip
                    }) {
                        Icon(Icons.Default.SkipNext, "Skip", tint = WarmIvoryMuted)
                    }
                }
            }
        }
    }
}


// --- 8. SOPHISTICATED EDITORIAL NEWS ---
@Composable
fun NewsScreen(viewModel: BroadwayViewModel) {
    val staticNews = listOf(
        NewsArticle(
            "news_1",
            "BREAKING",
            "A NEW ERA OF BROADWAY BEGINS: 2030s SMART VENUES",
            "The Broadway League announces comprehensive spatial upgrades for 41 historic venues in New York.",
            "Sept 11, 2026",
            "",
            "4 min read"
        ),
        NewsArticle(
            "news_2",
            "REVIEWS",
            "HAMILTON RE-ENGINEERED: SPATIAL AUDIO MASTERPIECE",
            "A critical dive into the Richard Rodgers Theatre's modern multi-dimensional upgrade.",
            "Sept 05, 2026",
            "",
            "6 min read"
        )
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp),
        contentPadding = PaddingValues(top = 44.dp, bottom = 16.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "BROADWAY NEWS",
                style = MaterialTheme.typography.displayLarge.copy(color = WarmIvory),
                letterSpacing = 2.sp
            )
            Text(
                text = "PREMIUM THEATRICAL PUBLICATION",
                style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold)
            )
        }

        items(staticNews) { article ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                border = BorderStroke(1.dp, FineBorderColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(article.category, style = MaterialTheme.typography.labelSmall.copy(color = TheatreRed, fontWeight = FontWeight.Bold))
                        Text(article.readTime, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(article.title, style = MaterialTheme.typography.headlineLarge.copy(color = WarmIvory, fontSize = 18.sp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(article.subtitle, style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvoryMuted))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(article.date, style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                }
            }
        }
    }
}


// --- 9. BROADWAY HISTORY TIMELINE ---
@Composable
fun HistoryTimelineScreen(viewModel: BroadwayViewModel) {
    val historyTimeline = listOf(
        HistoryMilestone("1900s", "The Birth of the Great White Way", "Electric signs light up Longacre Square, renaming it Times Square.", "The Red Mill", "Established Broadway as the central entertainment hub of North America."),
        HistoryMilestone("1920s", "The Golden Age & The Revues", "Florenz Ziegfeld's Follies dominate, introducing high-end visual art.", "Show Boat", "Integrated narrative, music, and social commentary into a unified form."),
        HistoryMilestone("1940s", "The Rodgers & Hammerstein Era", "The golden age of cohesive narrative book musicals that shaped modern drama.", "Oklahoma!", "Pioneered structural integration where dance and songs advance the plot."),
        HistoryMilestone("1980s", "British Invasion & Spectacle", "Andrew Lloyd Webber's spectacles arrive, establishing unprecedented visual scales.", "The Phantom of the Opera", "Longest-running show in Broadway history, defining luxury commercial theatre."),
        HistoryMilestone("2030s", "The Operating System of Theatre", "Frictionless digital navigation, immersive spatial audio, and personalized concierge experiences.", "Broadway OS", "Blends classical staging with sophisticated futuristic digital luxury.")
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp),
        contentPadding = PaddingValues(top = 44.dp, bottom = 16.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            Text(
                text = "BROADWAY HISTORY",
                style = MaterialTheme.typography.displayLarge.copy(color = WarmIvory),
                letterSpacing = 2.sp
            )
            Text(
                text = "LANDMARKS, CULTURE AND TRADITION",
                style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold)
            )
        }

        items(historyTimeline) { milestone ->
            Row(modifier = Modifier.fillMaxWidth()) {
                // Century / Decade Badge
                Column(
                    modifier = Modifier
                        .width(72.dp)
                        .padding(top = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = milestone.era,
                        style = MaterialTheme.typography.displayMedium.copy(color = ChampagneGold, fontSize = 20.sp)
                    )
                    Box(
                        modifier = Modifier
                            .width(2.dp)
                            .height(80.dp)
                            .background(FineBorderColor)
                    )
                }
                
                // Details card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                    border = BorderStroke(1.dp, FineBorderColor)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(milestone.title, style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory))
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(milestone.description, style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvoryMuted))
                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Landmark Production:", style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                        Text(milestone.landmarkShow, style = MaterialTheme.typography.bodyMedium.copy(color = WarmIvory))
                    }
                }
            }
        }
    }
}


// --- 10. AI BROADWAY CONCIERGE CHAT ---
@Composable
fun ConciergeScreen(viewModel: BroadwayViewModel) {
    val messages by viewModel.chatMessages.collectAsState()
    val loading by viewModel.isConciergeLoading.collectAsState()
    var inputText by remember { mutableStateOf("") }
    val chatScrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp)
            .background(DeepBlack)
    ) {
        // Concierge Header
        Column(
            modifier = Modifier
                .background(DarkManhattanGrey)
                .padding(top = 44.dp, start = 16.dp, end = 16.dp, bottom = 12.dp)
        ) {
            Text(
                text = "BROADWAY CONCIERGE",
                style = MaterialTheme.typography.displayMedium.copy(color = WarmIvory),
                letterSpacing = 1.sp
            )
            Text(
                text = "YOUR LUXURIOUS THEATRE ASSISTANT",
                style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold)
            )
        }

        // Chat conversation bubble list
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(16.dp)
                .verticalScroll(chatScrollState)
        ) {
            messages.forEach { msg ->
                val isUser = msg.sender == "user"
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
                ) {
                    Box(
                        modifier = Modifier
                            .background(
                                color = if (isUser) TheatreRed else DarkManhattanGrey,
                                shape = RoundedCornerShape(
                                    topStart = 12.dp,
                                    topEnd = 12.dp,
                                    bottomStart = if (isUser) 12.dp else 0.dp,
                                    bottomEnd = if (isUser) 0.dp else 12.dp
                                )
                            )
                            .border(
                                width = 1.dp,
                                color = if (isUser) TheatreRed else FineBorderColor,
                                shape = RoundedCornerShape(
                                    topStart = 12.dp,
                                    topEnd = 12.dp,
                                    bottomStart = if (isUser) 12.dp else 0.dp,
                                    bottomEnd = if (isUser) 0.dp else 12.dp
                                )
                            )
                            .padding(14.dp)
                    ) {
                        Column {
                            Text(
                                text = msg.text,
                                style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory, fontSize = 14.sp)
                            )
                            if (msg.isRecommendation && msg.recommendedShowId != null) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Button(
                                    onClick = {
                                        // Auto go to booking
                                        viewModel.navigateTo("Shows")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ChampagneGold),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text("BOOK SEATS NOW", style = MaterialTheme.typography.labelSmall.copy(color = DeepBlack, fontWeight = FontWeight.Bold))
                                }
                            }
                        }
                    }
                }
            }
            if (loading) {
                Box(modifier = Modifier.padding(12.dp)) {
                    CircularProgressIndicator(color = ChampagneGold, modifier = Modifier.size(24.dp))
                }
            }
        }

        // Quick prompt recommendation options
        LazyRow(
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val suggestions = listOf(
                "Find me a musical for tonight.",
                "What's good for a first Broadway show?",
                "Find something under $100.",
                "I want something dramatic."
            )
            items(suggestions) { prompt ->
                Surface(
                    modifier = Modifier.clickable { viewModel.sendChatMessage(prompt) },
                    color = DarkManhattanGrey,
                    shape = RoundedCornerShape(20.dp),
                    border = BorderStroke(1.dp, FineBorderColor)
                ) {
                    Text(
                        text = prompt,
                        style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }

        // Bottom Chat Input Bar
        Row(
            modifier = Modifier
                .background(DarkManhattanGrey)
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = inputText,
                onValueChange = { inputText = it },
                placeholder = { Text("Ask the Concierge anything...", color = WarmIvoryMuted) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = WarmIvory,
                    unfocusedTextColor = WarmIvory,
                    focusedContainerColor = DeepBlack,
                    unfocusedContainerColor = DeepBlack,
                    focusedBorderColor = ChampagneGold,
                    unfocusedBorderColor = FineBorderColor
                ),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(12.dp))
            IconButton(
                onClick = {
                    if (inputText.isNotBlank()) {
                        viewModel.sendChatMessage(inputText)
                        inputText = ""
                    }
                },
                modifier = Modifier.background(TheatreRed, RoundedCornerShape(4.dp))
            ) {
                Icon(Icons.Default.Send, "Send", tint = Color.White)
            }
        }
    }
}


// --- 11. "BROADWAY NIGHT OUT" PLANNER ---
@Composable
fun NightOutScreen(viewModel: BroadwayViewModel) {
    val plan by viewModel.nightOutPlan.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp),
        contentPadding = PaddingValues(top = 44.dp, bottom = 16.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "YOUR BROADWAY NIGHT",
                style = MaterialTheme.typography.displayLarge.copy(color = WarmIvory),
                letterSpacing = 1.5.sp
            )
            Text(
                text = "DESIGN YOUR WHOLE MIDTOWN EVENING",
                style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                border = BorderStroke(1.dp, FineBorderColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Dinner Time
                    NightTimelineSegment("6:00 PM", "Dinner reservation", "Enjoy authentic Italian cuisine at Orso, a 3-minute walking distance from the theatre.")
                    
                    // Show Time
                    NightTimelineSegment("7:30 PM", "Showtime: Wicked", "Arrive Gershwin Theatre. Spatial audio cocoon activated.")
                    
                    // Cocktails
                    NightTimelineSegment("10:15 PM", "Post-theatre Cocktails", "Indulge in private luxury drinks at Bar Centrale with legendary performers.")
                    
                    // Hotel
                    NightTimelineSegment("11:30 PM", "Retreat to The Knickerbocker", "Fabulous historic hotel accommodations situated right on Times Square.")
                }
            }
        }

        item {
            Button(
                onClick = {
                    // Triggers planning customization flow
                    viewModel.navigateTo("Shows")
                },
                colors = ButtonDefaults.buttonColors(containerColor = TheatreRed),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("BUILD MY NIGHT OUT PLAN", style = MaterialTheme.typography.labelLarge.copy(color = Color.White))
            }
        }
    }
}

@Composable
fun NightTimelineSegment(time: String, title: String, desc: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(68.dp)) {
            Text(time, style = MaterialTheme.typography.titleMedium.copy(color = ChampagneGold, fontWeight = FontWeight.Bold))
            Box(modifier = Modifier.size(8.dp).background(TheatreRed, CircleShape).padding(top = 6.dp))
            Box(modifier = Modifier.width(2.dp).height(44.dp).background(FineBorderColor))
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory))
            Spacer(modifier = Modifier.height(2.dp))
            Text(desc, style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
        }
    }
}


// --- 12. DIGITAL BROADWAY PASS ---
@Composable
fun BroadwayPassScreen(viewModel: BroadwayViewModel) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp),
        contentPadding = PaddingValues(top = 44.dp, bottom = 16.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "BROADWAY PASS",
                style = MaterialTheme.typography.displayLarge.copy(color = WarmIvory),
                letterSpacing = 2.sp
            )
            Text(
                text = "PREMIUM CULTURAL MEMBERSHIP",
                style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold)
            )
        }

        // Virtual Member Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(Color(0xFF2E1919), Color(0xFF0F0606), Color(0xFF423419))
                        )
                    )
                    .border(BorderStroke(1.dp, ChampagneGold), RoundedCornerShape(12.dp))
                    .padding(20.dp)
            ) {
                Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("BROADWAY PASS", style = MaterialTheme.typography.headlineLarge.copy(color = ChampagneGold, letterSpacing = 2.sp))
                        Text("PLATINUM MEMBER", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                    }
                    Column {
                        Text("MEMBER ID", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                        Text("BWAY-2035-7842", style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory))
                    }
                }
            }
        }

        item {
            Text("MEMBER EXCLUSIVE BENEFITS", style = MaterialTheme.typography.labelLarge.copy(color = ChampagneGold))
        }

        val benefits = listOf(
            "Ticket Pre-sale Access to new limited theatrical runs",
            "Exclusive backstage walkthrough content and program notes",
            "15% Discount at Sardi's and Orso restaurants",
            "Priority entry lanes at Gershwin and Minskoff theatres",
            "Full digital archive access back to early 1900s Broadway"
        )

        items(benefits) { benefit ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                border = BorderStroke(1.dp, FineBorderColor)
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Verified, "Verified", tint = ChampagneGold, modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(benefit, style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory))
                }
            }
        }
    }
}


// --- 13. DETAILS FOR VENUES & ACTORS ---
@Composable
fun TheatreDetailScreen(viewModel: BroadwayViewModel) {
    val venue by viewModel.selectedVenue.collectAsState()
    if (venue == null) return
    val currentVenue = venue!!

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp),
        contentPadding = PaddingValues(top = 44.dp, bottom = 16.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { viewModel.navigateBack() }) {
                    Icon(Icons.Default.ArrowBack, "Back", tint = WarmIvory)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("THEATRE VENUE", style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                    Text(currentVenue.name, style = MaterialTheme.typography.displayMedium.copy(color = WarmIvory))
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                border = BorderStroke(1.dp, FineBorderColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("CURRENT PRODUCTION", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                    Text(currentVenue.currentProduction, style = MaterialTheme.typography.headlineLarge.copy(color = WarmIvory))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Capacity", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                    Text("${currentVenue.capacity} seats", style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("Address", style = MaterialTheme.typography.labelSmall.copy(color = WarmIvoryMuted))
                    Text(currentVenue.address, style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory))
                }
            }
        }

        item {
            Text("THEATRE HISTORY", style = MaterialTheme.typography.labelLarge.copy(color = ChampagneGold))
        }

        item {
            Text(currentVenue.history, style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory, lineHeight = 24.sp))
        }
    }
}

@Composable
fun ActorDetailScreen(viewModel: BroadwayViewModel) {
    val actor by viewModel.selectedActor.collectAsState()
    if (actor == null) return
    val currentActor = actor!!

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 72.dp),
        contentPadding = PaddingValues(top = 44.dp, bottom = 16.dp, start = 16.dp, end = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.Default.ArrowBack, "Back", tint = WarmIvory)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text("BROADWAY ARTIST", style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                        Text(currentActor.name, style = MaterialTheme.typography.displayMedium.copy(color = WarmIvory))
                    }
                }
                Button(
                    onClick = {
                        // Toggle follow logic
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = TheatreRed),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text("FOLLOW", style = MaterialTheme.typography.labelSmall.copy(color = Color.White))
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                border = BorderStroke(1.dp, FineBorderColor)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("BIO", style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(currentActor.bio, style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory, lineHeight = 22.sp))
                }
            }
        }

        item {
            Text("BROADWAY CREDITS", style = MaterialTheme.typography.labelLarge.copy(color = ChampagneGold))
        }

        items(currentActor.credits) { credit ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = DarkManhattanGrey),
                border = BorderStroke(1.dp, FineBorderColor)
            ) {
                Text(credit, style = MaterialTheme.typography.bodyLarge.copy(color = WarmIvory), modifier = Modifier.padding(16.dp))
            }
        }
    }
}
