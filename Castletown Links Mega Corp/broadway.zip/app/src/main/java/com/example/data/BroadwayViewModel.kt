package com.example.data

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

// --- AI Chat Message model ---
data class ChatMessage(
    val sender: String, // "user" or "concierge"
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isRecommendation: Boolean = false,
    val recommendedShowId: String? = null
)

// --- Night Out Plan Model ---
data class NightOutPlan(
    val dinnerTime: String = "6:00 PM",
    val dinnerRestaurant: String = "Joe Allen",
    val showTime: String = "7:30 PM",
    val showTitle: String = "Wicked",
    val cocktailsTime: String = "10:15 PM",
    val cocktailsBar: String = "Bar Centrale",
    val hotelName: String = "The Knickerbocker Hotel"
)

class BroadwayViewModel(application: Application, private val repository: BroadwayRepository) : AndroidViewModel(application) {

    // Navigation State
    private val _currentScreen = MutableStateFlow("Home") // Home, Shows, Tonight, Tickets, Me, News, Music, History, Concierge, NightOut, Pass, TheatreDetail, ActorDetail, ShowDetail
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    private val _screenBackStack = MutableStateFlow<List<String>>(listOf("Home"))
    val screenBackStack: StateFlow<List<String>> = _screenBackStack.asStateFlow()

    // Selection States for Detailed Views
    private val _selectedShow = MutableStateFlow<Show?>(null)
    val selectedShow: StateFlow<Show?> = _selectedShow.asStateFlow()

    private val _selectedVenue = MutableStateFlow<Venue?>(null)
    val selectedVenue: StateFlow<Venue?> = _selectedVenue.asStateFlow()

    private val _selectedActor = MutableStateFlow<Actor?>(null)
    val selectedActor: StateFlow<Actor?> = _selectedActor.asStateFlow()

    // Discovery Filters & Sorting
    private val _selectedFilter = MutableStateFlow("All") // Musicals, Plays, Tony Winners, Classics, Family, New
    val selectedFilter: StateFlow<String> = _selectedFilter.asStateFlow()

    private val _selectedSort = MutableStateFlow("Popular") // Popular, Best Rated, Lowest Price, Starting Soon
    val selectedSort: StateFlow<String> = _selectedSort.asStateFlow()

    // Ticketing & Booking Flow
    private val _bookingShow = MutableStateFlow<Show?>(null)
    val bookingShow: StateFlow<Show?> = _bookingShow.asStateFlow()

    private val _bookingSeatsCount = MutableStateFlow(2)
    val bookingSeatsCount: StateFlow<Int> = _bookingSeatsCount.asStateFlow()

    private val _bookingSection = MutableStateFlow("Orchestra") // Orchestra, Front Mezzanine, Rear Mezzanine, Balcony
    val bookingSection: StateFlow<String> = _bookingSection.asStateFlow()

    private val _bookingRow = MutableStateFlow("F")
    val bookingRow: StateFlow<String> = _bookingRow.asStateFlow()

    private val _bookingSeats = MutableStateFlow("12–13")
    val bookingSeats: StateFlow<String> = _bookingSeats.asStateFlow()

    private val _bookingTotalPrice = MutableStateFlow(398.0)
    val bookingTotalPrice: StateFlow<Double> = _bookingTotalPrice.asStateFlow()

    private val _isCheckoutComplete = MutableStateFlow(false)
    val isCheckoutComplete: StateFlow<Boolean> = _isCheckoutComplete.asStateFlow()

    // Global Search Query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Music Player State
    private val _currentPlayingTrack = MutableStateFlow<Track?>(null)
    val currentPlayingTrack: StateFlow<Track?> = _currentPlayingTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _musicProgress = MutableStateFlow(0.35f)
    val musicProgress: StateFlow<Float> = _musicProgress.asStateFlow()

    // Tonight Mode Metrics
    val congestionLevel = MutableStateFlow("Moderate (42% capacity surrounding Gershwin)")
    val subwayStatus = MutableStateFlow("On Time (1, 2, 3 running with minor luxury car delays)")
    val currentTemp = MutableStateFlow("68°F — Prefect Midtown evening breeze")
    val countdownMinutes = MutableStateFlow(102) // "1h 42m"

    // Custom Night Out Plan
    private val _nightOutPlan = MutableStateFlow(NightOutPlan())
    val nightOutPlan: StateFlow<NightOutPlan> = _nightOutPlan.asStateFlow()

    // Saved Items from Database
    val savedEntities: StateFlow<List<SavedEntity>> = repository.getSavedEntitiesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val bookedTickets: StateFlow<List<SimulatedTicket>> = repository.getTicketsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // AI Concierge Chat History
    private val _chatMessages = MutableStateFlow<List<ChatMessage>>(listOf(
        ChatMessage("concierge", "Welcome to the Broadway 2030s Concierge. I am your premium AI companion. What can I recommend for your luxurious New York theatre evening? Feel free to ask me to find musicals, high-end dramas, or show recommendations based on your unique tastes.")
    ))
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isConciergeLoading = MutableStateFlow(false)
    val isConciergeLoading: StateFlow<Boolean> = _isConciergeLoading.asStateFlow()

    init {
        // Start simulated timer progress
        viewModelScope.launch {
            while (true) {
                delay(10000)
                if (_isPlaying.value) {
                    var nextProgress = _musicProgress.value + 0.02f
                    if (nextProgress > 1f) {
                        nextProgress = 0f
                        // Skip to next track in playlist ideally
                    }
                    _musicProgress.value = nextProgress
                }
            }
        }
    }

    // --- Search Logic ---
    val searchResults = combine(_searchQuery, savedEntities) { query, saved ->
        if (query.isBlank()) {
            emptyMap<String, List<Any>>()
        } else {
            val q = query.lowercase()
            val filteredShows = repository.shows.filter { it.title.lowercase().contains(q) || it.genre.lowercase().contains(q) }
            val filteredActors = repository.actors.filter { it.name.lowercase().contains(q) || it.roleType.lowercase().contains(q) }
            val filteredVenues = repository.venues.filter { it.name.lowercase().contains(q) || it.currentProduction.lowercase().contains(q) }
            val filteredNews = repository.news.filter { it.title.lowercase().contains(q) || it.content.lowercase().contains(q) }
            
            mapOf(
                "Shows" to filteredShows,
                "Artists" to filteredActors,
                "Theatres" to filteredVenues,
                "News" to filteredNews
            ).filterValues { it.isNotEmpty() }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // --- Navigation ---
    fun navigateTo(screen: String) {
        val currentBackstack = _screenBackStack.value.toMutableList()
        currentBackstack.add(screen)
        _screenBackStack.value = currentBackstack
        _currentScreen.value = screen
    }

    fun navigateBack() {
        val currentBackstack = _screenBackStack.value.toMutableList()
        if (currentBackstack.size > 1) {
            currentBackstack.removeAt(currentBackstack.size - 1)
            _screenBackStack.value = currentBackstack
            _currentScreen.value = currentBackstack.last()
        }
    }

    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // --- Detail Selection ---
    fun selectShow(show: Show) {
        _selectedShow.value = show
        navigateTo("ShowDetail")
    }

    fun selectVenue(venue: Venue) {
        _selectedVenue.value = venue
        navigateTo("TheatreDetail")
    }

    fun selectActor(actor: Actor) {
        _selectedActor.value = actor
        navigateTo("ActorDetail")
    }

    // --- Save/Unsave Favourites ---
    fun toggleSaveEntity(id: String, type: String, name: String, subtitle: String, imageResName: String) {
        viewModelScope.launch {
            val isCurrentlySaved = savedEntities.value.any { it.id == id }
            if (isCurrentlySaved) {
                repository.unsaveEntityById(id)
            } else {
                repository.saveEntity(SavedEntity(id, type, name, subtitle, imageResName))
            }
        }
    }

    fun isEntitySaved(id: String): Boolean {
        return savedEntities.value.any { it.id == id }
    }

    // --- Filtering & Sorting ---
    fun setFilter(filter: String) {
        _selectedFilter.value = filter
    }

    fun setSort(sort: String) {
        _selectedSort.value = sort
    }

    // Filtered shows for discovery
    val filteredShows = combine(_selectedFilter, _selectedSort) { filter, sort ->
        var list = repository.shows
        if (filter != "All") {
            list = when (filter) {
                "Musicals" -> list.filter { it.genre == "Musical" }
                "Plays" -> list.filter { it.genre == "Play" }
                "Tony Winners" -> list // Hamilton, Wicked etc. are Tony winners
                "New" -> list.filter { it.id == "hadestown" }
                else -> list
            }
        }
        when (sort) {
            "Popular" -> list.sortedBy { it.rating }.reversed()
            "Best Rated" -> list.sortedBy { it.rating }.reversed()
            "Lowest Price" -> list.sortedBy { it.fromPrice }
            else -> list
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), repository.shows)

    // --- Booking Flow ---
    fun startBooking(show: Show) {
        _bookingShow.value = show
        _bookingSeatsCount.value = 2
        _bookingSection.value = "Orchestra"
        _bookingRow.value = "F"
        _bookingSeats.value = "12–13"
        _bookingTotalPrice.value = show.fromPrice * 2 * 2.0 // Orchestra multiplier
        _isCheckoutComplete.value = false
        navigateTo("Tickets")
    }

    fun updateSeatsCount(count: Int) {
        if (count in 1..8) {
            _bookingSeatsCount.value = count
            val seatsList = (12 until 12 + count).joinToString("–")
            _bookingSeats.value = seatsList
            val pricePerSeat = (_bookingShow.value?.fromPrice ?: 100.0) * if (_bookingSection.value == "Orchestra") 2.01 else 1.25
            _bookingTotalPrice.value = pricePerSeat * count
        }
    }

    fun updateSection(section: String) {
        _bookingSection.value = section
        val multiplier = when (section) {
            "Orchestra" -> 2.01
            "Front Mezzanine" -> 1.75
            "Rear Mezzanine" -> 1.25
            else -> 1.0
        }
        val count = _bookingSeatsCount.value
        val pricePerSeat = (_bookingShow.value?.fromPrice ?: 100.0) * multiplier
        _bookingTotalPrice.value = pricePerSeat * count
    }

    fun completeCheckout() {
        viewModelScope.launch {
            _isConciergeLoading.value = true
            delay(1500) // Simulated secure checkout
            val show = _bookingShow.value ?: return@launch
            val ticket = SimulatedTicket(
                showId = show.id,
                showTitle = show.title,
                theatreName = show.theatre,
                dateTime = "Tonight — 7:30 PM",
                section = _bookingSection.value,
                row = _bookingRow.value,
                seats = _bookingSeats.value,
                totalPrice = _bookingTotalPrice.value,
                quantity = _bookingSeatsCount.value
            )
            repository.bookTicket(ticket)
            _isCheckoutComplete.value = true
            _isConciergeLoading.value = false
        }
    }

    // --- Music Controls ---
    fun selectTrack(track: Track) {
        _currentPlayingTrack.value = track
        _isPlaying.value = true
        _musicProgress.value = 0.0f
    }

    fun togglePlay() {
        _isPlaying.value = !_isPlaying.value
    }

    // --- Night Out Planner ---
    fun updateNightOutPlan(plan: NightOutPlan) {
        _nightOutPlan.value = plan
    }

    // --- AI CONCIERGE CHAT ENGINE ---
    fun sendChatMessage(userText: String) {
        if (userText.isBlank()) return

        val userMessage = ChatMessage("user", userText)
        _chatMessages.value = _chatMessages.value + userMessage
        _isConciergeLoading.value = true

        viewModelScope.launch {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isNotEmpty() && apiKey != "MY_GEMINI_API_KEY") {
                    // Make actual Gemini REST call
                    val response = callGeminiREST(userText, apiKey)
                    processConciergeResponse(response)
                } else {
                    // Elegant fallback based on keyword parsing to make the demo incredibly smart
                    delay(1200)
                    val responseText = generateSmartTheatricalResponse(userText)
                    processConciergeResponse(responseText)
                }
            } catch (e: Exception) {
                Log.e("AI_CONCIERGE", "Error generating content", e)
                processConciergeResponse("Our digital connection to Times Square is bustling, but here is a refined recommendation: Hamilton is performing at 7:00 PM at the Richard Rodgers Theatre. It is highly praised for its 2030s theatrical sound engineering. Would you like to view ticket availability?")
            } finally {
                _isConciergeLoading.value = false
            }
        }
    }

    private fun processConciergeResponse(responseText: String) {
        val matchedShow = repository.shows.firstOrNull {
            responseText.lowercase().contains(it.title.lowercase()) ||
            responseText.lowercase().contains(it.id.lowercase())
        }
        val conciergeMessage = ChatMessage(
            sender = "concierge",
            text = responseText,
            isRecommendation = matchedShow != null,
            recommendedShowId = matchedShow?.id
        )
        _chatMessages.value = _chatMessages.value + conciergeMessage
    }

    private suspend fun callGeminiREST(prompt: String, apiKey: String): String = withContext(Dispatchers.IO) {
        val client = OkHttpClient.Builder()
            .connectTimeout(30, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .build()

        val systemInstruction = "You are a world-class Broadway Concierge for an premium Broadway app set in the 2030s. " +
                "You recommend Broadway shows (HAMILTON, THE LION KING, WICKED, HADESTOWN) and fine dining in Times Square. " +
                "Keep responses luxurious, sophisticated, informative, concise (1-3 paragraphs) and editorial."

        val jsonRequest = JSONObject().apply {
            put("contents", JSONArray().put(JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().apply {
                    put("text", prompt)
                }))
            }))
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().put(JSONObject().apply {
                    put("text", systemInstruction)
                }))
            })
        }

        val requestBody = jsonRequest.toString().toRequestBody("application/json".toMediaType())
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"

        val request = Request.Builder()
            .url(url)
            .post(requestBody)
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext "Error: Unexpected response code ${response.code}"
            val responseBody = response.body?.string() ?: return@withContext "No response from Times Square."
            
            val jsonResponse = JSONObject(responseBody)
            val candidates = jsonResponse.getJSONArray("candidates")
            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.getJSONObject("content")
            val parts = content.getJSONArray("parts")
            parts.getJSONObject(0).getString("text")
        }
    }

    private fun generateSmartTheatricalResponse(prompt: String): String {
        val p = prompt.lowercase()
        return when {
            p.contains("musical") -> {
                "For a spectacular musical tonight, I highly recommend 'HAMILTON' at the Richard Rodgers Theatre or 'THE LION KING' at the Minskoff Theatre. Both showcase incredible musical narratives with state-of-the-art staging. 'HAMILTON' is particularly suited for a rich, modern hip-hop historical voyage."
            }
            p.contains("first") || p.contains("newcomer") || p.contains("good for") -> {
                "'THE LION KING' at the Minskoff Theatre is the quintessential first-time Broadway experience. Julie Taymor's legendary puppetry and design provide a sensory, magnificent introduction to theatrical art. Another option is 'WICKED' for its soaring vocals and universal magic."
            }
            p.contains("under 100") || p.contains("budget") || p.contains("cheap") || p.contains("price") -> {
                "To enjoy world-class theatre under a $100 entry price point, 'HADESTOWN' at the Walter Kerr Theatre has tickets starting from $79. It is a stunning, intimate jazz and folk opera that won 8 Tony Awards including Best Musical. An absolute bargain for its luxury depth."
            }
            p.contains("drama") || p.contains("dramatic") || p.contains("serious") -> {
                "'HADESTOWN' is a masterclass in modern dramatic tragedy, beautifully weaving the mythic Greek Orpheus and Eurydice story. It offers exquisite atmosphere, incredible tension, and emotional weight."
            }
            p.contains("hamilton") || p.contains("after") -> {
                "If you thoroughly enjoyed the intricate rhythms of Hamilton, your next natural step is 'HADESTOWN'. Both are driven by powerful, Pulitzer and Tony-winning singer-songwriter creative forces and features complex, gorgeous ensembles."
            }
            p.contains("times square") || p.contains("near") || p.contains("location") -> {
                "All major shows are centered directly around Times Square. 'THE LION KING' is playing at the Minskoff, situated right on W 45th Street with panoramic lobby views of the Broadway marquees. It is surrounded by fantastic dining such as Joe Allen and Bar Centrale."
            }
            else -> {
                "Broadway is alive with extraordinary options tonight. We have 'HAMILTON' (Modern Hip-Hop Biography), 'THE LION KING' (Spectacular Serengeti Puppetry), 'WICKED' (Legendary Blockbuster Magic), and 'HADESTOWN' (Soulful Jazz Mythology). Let me know what specific genre or emotional palette you would like to explore!"
            }
        }
    }
}
