package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.room.Room
import com.example.data.*
import com.example.ui.BroadwayScreenRouter
import com.example.ui.theme.DeepBlack
import com.example.ui.theme.DarkManhattanGrey
import com.example.ui.theme.TheatreRed
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.WarmIvory
import com.example.ui.theme.WarmIvoryMuted
import com.example.ui.theme.FineBorderColor
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private lateinit var database: BroadwayDatabase
    private lateinit var repository: BroadwayRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // 1. Initialize local Room database and repository
        database = Room.databaseBuilder(
            applicationContext,
            BroadwayDatabase::class.java,
            "broadway_30s_os_db"
        ).fallbackToDestructiveMigration().build()

        repository = BroadwayRepository(database.dao())

        setContent {
            MyApplicationTheme {
                // Initialize ViewModel with custom factory
                val viewModel: BroadwayViewModel = androidx.lifecycle.viewmodel.compose.viewModel(
                    factory = BroadwayViewModelFactory(application, repository)
                )

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DeepBlack
                ) {
                    BroadwayAppShell(viewModel)
                }
            }
        }
    }
}

// Custom factory to pass Database Repository to ViewModel
class BroadwayViewModelFactory(
    private val application: Application,
    private val repository: BroadwayRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BroadwayViewModel::class.java)) {
            return BroadwayViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}

// Master shell determining Desktop layout vs Mobile layout adaptively
@Composable
fun BroadwayAppShell(viewModel: BroadwayViewModel) {
    val configuration = LocalConfiguration.current
    val isTabletOrDesktop = configuration.screenWidthDp >= 600

    if (isTabletOrDesktop) {
        DesktopLayoutShell(viewModel)
    } else {
        MobileLayoutShell(viewModel)
    }
}

// 1. Desktop layout side panel navigation & large editorial grid layout
@Composable
fun DesktopLayoutShell(viewModel: BroadwayViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()

    Row(modifier = Modifier.fillMaxSize()) {
        // Left Navigation Sidebar (Bloomberg-meets-Broadway dense information)
        Column(
            modifier = Modifier
                .width(260.dp)
                .fillMaxHeight()
                .background(DarkManhattanGrey)
                .border(BorderStroke(1.dp, FineBorderColor))
                .padding(top = 44.dp, start = 16.dp, end = 16.dp, bottom = 16.dp)
        ) {
            Text(
                text = "BROADWAY",
                style = MaterialTheme.typography.displayLarge.copy(
                    color = WarmIvory,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier.padding(bottom = 24.dp)
            )

            // Side Navigation Items
            val navItems = listOf(
                "Home" to Icons.Default.Home,
                "Shows" to Icons.Default.TheaterComedy,
                "Tonight" to Icons.Default.Schedule,
                "News" to Icons.Default.Newspaper,
                "Music" to Icons.Default.MusicNote,
                "History" to Icons.Default.History,
                "Concierge" to Icons.Default.Assistant,
                "Pass" to Icons.Default.CardMembership
            )

            navItems.forEach { (screen, icon) ->
                val isActive = currentScreen == screen
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isActive) TheatreRed.copy(alpha = 0.12f) else Color.Transparent)
                        .clickable { viewModel.navigateTo(screen) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = screen,
                        tint = if (isActive) TheatreRed else WarmIvoryMuted,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = screen,
                        style = MaterialTheme.typography.titleMedium.copy(
                            color = if (isActive) WarmIvory else WarmIvoryMuted,
                            fontSize = 15.sp
                        )
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
            }

            Spacer(modifier = Modifier.weight(1f))

            // User Info Badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.navigateTo("Me") }
                    .background(DeepBlack, RoundedCornerShape(4.dp))
                    .border(BorderStroke(1.dp, FineBorderColor))
                    .padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .background(TheatreRed.copy(alpha = 0.2f), RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Person, "Profile", tint = ChampagneGold)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text("PLATINUM MEMBER", style = MaterialTheme.typography.labelSmall.copy(color = ChampagneGold))
                    Text("Tom Ah", style = MaterialTheme.typography.titleMedium.copy(color = WarmIvory, fontSize = 14.sp))
                }
            }
        }

        // Main content panel
        Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
            BroadwayScreenRouter(viewModel)
        }
    }
}

// 2. Mobile Native layout Bottom Navigation
@Composable
fun MobileLayoutShell(viewModel: BroadwayViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DeepBlack,
        bottomBar = {
            NavigationBar(
                containerColor = DarkManhattanGrey,
                tonalElevation = 8.dp,
                modifier = Modifier.border(BorderStroke(1.dp, FineBorderColor))
            ) {
                val menu = listOf(
                    Triple("Home", "Home", Icons.Default.Home),
                    Triple("Shows", "Shows", Icons.Default.TheaterComedy),
                    Triple("Tonight", "Tonight", Icons.Default.Schedule),
                    Triple("Concierge", "Concierge", Icons.Default.Assistant),
                    Triple("Me", "Me", Icons.Default.Person)
                )
                menu.forEach { (route, label, icon) ->
                    val isActive = currentScreen == route
                    NavigationBarItem(
                        selected = isActive,
                        onClick = { viewModel.navigateTo(route) },
                        icon = {
                            Icon(
                                imageVector = icon,
                                contentDescription = label,
                                tint = if (isActive) TheatreRed else WarmIvoryMuted
                            )
                        },
                        label = {
                            Text(
                                text = label,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = if (isActive) WarmIvory else WarmIvoryMuted,
                                    fontSize = 11.sp
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = TheatreRed.copy(alpha = 0.15f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            BroadwayScreenRouter(viewModel)
        }
    }
}
