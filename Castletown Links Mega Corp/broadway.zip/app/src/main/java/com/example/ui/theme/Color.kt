package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Broadway Theme Colors
val DeepBlack = Color(0xFF090909)
val DarkManhattanGrey = Color(0xFF141414)
val ManhattanGreyCard = Color(0xFF1E1E1E)
val TheatreRed = Color(0xFFD31B1B) // Crimson Theatre Red
val WarmIvory = Color(0xFFFAF6EE) // Ivory text and highlights
val WarmIvoryMuted = Color(0xFFB5AFA2) // Muted text/labels
val ChampagneGold = Color(0xFFDFBA6B) // Champagne Accent Gold
val FineBorderColor = Color(0xFF2A2824) // Elegant fine border
val GlassSurface = Color(0x1EFAF6EE) // Glassy overlay
val TransparentBlack = Color(0xAA000000)
val LiveGreen = Color(0xFF1DB954)
