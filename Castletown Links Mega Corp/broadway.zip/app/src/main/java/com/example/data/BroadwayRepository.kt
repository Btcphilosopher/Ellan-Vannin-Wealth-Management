package com.example.data

import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// --- High-Fidelity Data Models ---

data class Show(
    val id: String,
    val title: String,
    val theatre: String,
    val genre: String,
    val startTime: String,
    val ticketAvailability: String,
    val fromPrice: Double,
    val rating: Double,
    val duration: String,
    val synopsis: String,
    val cast: List<String>,
    val creativeTeam: List<String>,
    val reviews: List<CriticReview>,
    val music: List<String>,
    val history: String,
    val bannerText: String,
    val scoreText: String = "9.8"
)

data class CriticReview(
    val criticName: String,
    val rating: Int,
    val excerpt: String
)

data class Venue(
    val id: String,
    val name: String,
    val currentProduction: String,
    val capacity: Int,
    val address: String,
    val transport: String,
    val history: String,
    val accessibility: String,
    val nearbyHotels: List<String>
)

data class Actor(
    val id: String,
    val name: String,
    val roleType: String, // "ACTOR", "DIRECTOR", "COMPOSER" etc.
    val bio: String,
    val currentShow: String,
    val credits: List<String>,
    val filmCredits: List<String>,
    val tvCredits: List<String>,
    val awards: List<String>
)

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val duration: String
)

data class NewsArticle(
    val id: String,
    val category: String, // "BREAKING", "REVIEWS", "CASTING", "NEW SHOWS", "TONY AWARDS", "INTERVIEWS"
    val title: String,
    val subtitle: String,
    val date: String,
    val content: String,
    val readTime: String
)

data class Restaurant(
    val name: String,
    val category: String, // "Pre-Theatre Dining", "Fine Dining", "Casual", "Bars", "Cocktails"
    val distance: String,
    val walkingTime: String,
    val price: String,
    val cuisine: String,
    val hours: String
)

data class HistoryMilestone(
    val era: String, // "1900s", "1950s", "2030s"
    val title: String,
    val description: String,
    val landmarkShow: String,
    val culturalImpact: String
)

data class TonyCategory(
    val categoryName: String,
    val winner: String,
    val nominees: List<String>
)

// --- Repository Implementation ---

class BroadwayRepository(private val dao: BroadwayDao) {

    // --- Room Database Operations ---
    
    fun getSavedEntitiesFlow(): Flow<List<SavedEntity>> = dao.getSavedEntitiesFlow()
    
    suspend fun saveEntity(entity: SavedEntity) = dao.saveEntity(entity)
    
    suspend fun unsaveEntityById(id: String) = dao.deleteEntityById(id)
    
    fun isEntitySavedFlow(id: String): Flow<Boolean> = dao.isEntitySavedFlow(id)
    
    fun getTicketsFlow(): Flow<List<SimulatedTicket>> = dao.getTicketsFlow()
    
    suspend fun bookTicket(ticket: SimulatedTicket) = dao.bookTicket(ticket)
    
    fun getReviewsForShowFlow(showId: String): Flow<List<UserReview>> = dao.getReviewsForShowFlow(showId)
    
    suspend fun addReview(review: UserReview) = dao.addReview(review)

    // --- Static Theatrical Database ---

    val shows = listOf(
        Show(
            id = "hamilton",
            title = "HAMILTON",
            theatre = "Richard Rodgers Theatre",
            genre = "Musical",
            startTime = "7:00 PM",
            ticketAvailability = "Limited",
            fromPrice = 99.0,
            rating = 4.9,
            duration = "2h 45m",
            synopsis = "Hamilton is the story of America's Founding Father Alexander Hamilton, an immigrant from the West Indies who became George Washington's right-hand man during the Revolutionary War and was the new nation's first Treasury Secretary. Featuring a score that blends hip-hop, jazz, R&B, and Broadway.",
            cast = listOf("Lin-Manuel Miranda as Alexander Hamilton", "Leslie Odom Jr. as Aaron Burr", "Phillipa Soo as Eliza Hamilton", "Daveed Diggs as Marquis de Lafayette"),
            creativeTeam = listOf("Lin-Manuel Miranda (Book, Music, Lyrics)", "Thomas Kail (Director)", "Andy Blankenbuehler (Choreography)", "Alex Lacamoire (Orchestrations)"),
            reviews = listOf(
                CriticReview("The New York Times", 5, "An epoch-making theatrical experience that completely rewrites the American musical format."),
                CriticReview("Variety", 5, "Sensational and historically electric. A production of infinite energy and gorgeous language.")
            ),
            music = listOf("Alexander Hamilton", "My Shot", "The Schuyler Sisters", "Satisfied", "Wait for It", "The Room Where It Happens", "Burn"),
            history = "Opened on August 6, 2015, at the Richard Rodgers Theatre and immediately became a cultural phenomenon, winning 11 Tony Awards, a Grammy Award, and the Pulitzer Prize for Drama.",
            bannerText = "THE REVOLUTIONARY HIP-HOP MASTERPIECE REBUILT FOR THE 2030S WITH ULTRA-IMMERSIVE ACOUSTICS."
        ),
        Show(
            id = "lion_king",
            title = "THE LION KING",
            theatre = "Minskoff Theatre",
            genre = "Musical",
            startTime = "7:30 PM",
            ticketAvailability = "Good",
            fromPrice = 89.0,
            rating = 4.8,
            duration = "2h 30m",
            synopsis = "Giraffes strut, birds swoop, gazelles leap. The entire Serengeti comes to life as music soars on Broadway. Under the creative direction of Julie Taymor, Disney's legendary film is reimagined with astonishing puppetry, visual elegance, and spectacular rhythms.",
            cast = listOf("Brandon A. McCall as Simba", "L. Steven Taylor as Mufasa", "Tshidi Manye as Rafiki", "Pearl Khwezi as Nala"),
            creativeTeam = listOf("Elton John (Music)", "Tim Rice (Lyrics)", "Julie Taymor (Director, Costume Design)", "Garth Fagan (Choreography)"),
            reviews = listOf(
                CriticReview("The Guardian", 5, "A visual masterpiece that remains the pinnacle of Broadway's technical and creative craft."),
                CriticReview("Entertainment Weekly", 5, "There is simply nothing else like it on Earth. A breathtaking achievement of theatrical imagination.")
            ),
            music = listOf("Circle of Life", "I Just Can't Wait to Be King", "Be Prepared", "Hakuna Matata", "Can You Feel the Love Tonight"),
            history = "Debuted in 1997 and won six Tony Awards including Best Musical. It holds the record as the highest-grossing Broadway show of all time.",
            bannerText = "JULIE TAYMOR'S TRIUMPHANT SERENGETI ODYSSEY WITH ADVANCED HOLOGRAPHIC SCENIC PROJECTIONS."
        ),
        Show(
            id = "wicked",
            title = "WICKED",
            theatre = "Gershwin Theatre",
            genre = "Musical",
            startTime = "8:00 PM",
            ticketAvailability = "Available",
            fromPrice = 109.0,
            rating = 4.9,
            duration = "2h 45m",
            synopsis = "Long before Dorothy drops in, two other girls meet in the Land of Oz. One, born with emerald-green skin, is smart, fiery, and misunderstood. The other is beautiful, ambitious, and very popular. How these two unlikely friends grow to become the Wicked Witch of the West and Glinda the Good makes for Broadway's biggest blockbuster.",
            cast = listOf("Cynthia Erivo as Elphaba", "Ariana Grande as Glinda", "Jeff Goldblum as The Wizard", "Jonathan Bailey as Fiyero"),
            creativeTeam = listOf("Stephen Schwartz (Music & Lyrics)", "Winnie Holzman (Book)", "Joe Mantello (Director)", "Wayne Cilento (Choreography)"),
            reviews = listOf(
                CriticReview("Time Out New York", 5, "A magical, gravity-defying marvel that is as brilliant and emotionally resonant today as its debut."),
                CriticReview("Bloomberg Culture", 4, "A stunning luxury spectacle with vocals that shake the rafters of the Gershwin.")
            ),
            music = listOf("No One Mourns the Wicked", "The Wizard and I", "Popular", "Defying Gravity", "For Good"),
            history = "Opened in October 2003 and has surpassed 8,000 performances. It remains a legendary monument of musical storytelling.",
            bannerText = "GRAVITY-DEFYING ORCHESTRAL REMIXES & A MIND-BENDING SPATIAL HOLOGRAPHIC OZ ATMOSPHERE."
        ),
        Show(
            id = "hadestown",
            title = "HADESTOWN",
            theatre = "Walter Kerr Theatre",
            genre = "Musical",
            startTime = "7:00 PM",
            ticketAvailability = "Selling Fast",
            fromPrice = 79.0,
            rating = 4.7,
            duration = "2h 30m",
            synopsis = "Hadestown intertwines two mythic tales—that of young dreamers Orpheus and Eurydice, and that of King Hades and his wife Persephone—on a hell-bent journey to the underworld and back. An enchanting score of jazz, folk, and blues.",
            cast = listOf("Reeve Carney as Orpheus", "Eva Noblezada as Eurydice", "Patrick Page as Hades", "Amber Gray as Persephone"),
            creativeTeam = listOf("Anaïs Mitchell (Book, Music, Lyrics)", "Rachel Chavkin (Director)", "David Neumann (Choreography)"),
            reviews = listOf(
                CriticReview("New York Magazine", 5, "An absolute triumph. Rich, evocative, deep, and deeply moving."),
                CriticReview("The Wall Street Journal", 5, "A gorgeous jazz opera that feels both ancient and completely of the moment.")
            ),
            music = listOf("Road to Hell", "Way Down Hadestown", "Wait for Me", "Why We Build the Wall", "Flowers"),
            history = "Winner of 8 Tony Awards in 2019 including Best Musical and Best Original Score. Developed from a conceptual indie folk album.",
            bannerText = "A HAUNTING UNDERWORLD OF SOULFUL JAZZ UPGRADED WITH AN EXQUISITE 3D ACOUSTIC COCOON DESIGN."
        )
    )

    val venues = listOf(
        Venue(
            id = "richard_rodgers",
            name = "Richard Rodgers Theatre",
            currentProduction = "Hamilton",
            capacity = 1319,
            address = "226 W 46th St, New York, NY 10036",
            transport = "Subway: N, Q, R, W to 49th St; 1, 2, 3, 7, S to Times Square-42nd St",
            history = "Built by Irwin Chanin in 1925 as the Chanin's 46th Street Theatre. It was renamed in 1990 to honor legendary composer Richard Rodgers. Known for hosting numerous Tony Award-winning Best Musicals.",
            accessibility = "Wheelchair accessible seating, assistive listening devices, open captioning, and audio description services.",
            nearbyHotels = listOf("The Knickerbocker Hotel", "Marriott Marquis Times Square", "The Chatwal Luxury Hotel")
        ),
        Venue(
            id = "minskoff",
            name = "Minskoff Theatre",
            currentProduction = "The Lion King",
            capacity = 1621,
            address = "200 W 45th St, New York, NY 10036",
            transport = "Subway: A, C, E to 42nd St-Port Authority; 1, 2, 3 to Times Square-42nd St",
            history = "Designed by architects Kahn and Jacobs, the Minskoff opened in 1973. It features a stunning third-floor lobby with panoramic views of Times Square. Home to The Lion King since 2006.",
            accessibility = "Escalators and elevators are available, accessible restrooms, and custom seating for patrons with limited mobility.",
            nearbyHotels = listOf("W New York Times Square", "LUMA Hotel Times Square", "The Westin Times Square")
        ),
        Venue(
            id = "gershwin",
            name = "Gershwin Theatre",
            currentProduction = "Wicked",
            capacity = 1933,
            address = "222 W 51st St, New York, NY 10019",
            transport = "Subway: C, E to 50th St; 1 to 50th St; N, R, W to 49th St",
            history = "Opened in 1972 as the Uris Theatre and renamed in 1983 to honor George and Ira Gershwin. It is the largest theatre on Broadway, famous for its grand scale and high-ceilinged acoustics.",
            accessibility = "Fully wheelchair accessible throughout the orchestra level, state-of-the-art infrared hearing systems, and tactile program booklets.",
            nearbyHotels = listOf("The Michelangelo Hotel", "CitizenM Times Square", "Baccarat Hotel New York")
        )
    )

    val actors = listOf(
        Actor(
            id = "lin_manuel",
            name = "Lin-Manuel Miranda",
            roleType = "Writer / Actor / Composer",
            bio = "Lin-Manuel Miranda is an American songwriter, actor, singer, filmmaker, and playwright. He is known for creating and starring in the Broadway musicals 'In the Heights' and 'Hamilton'. He is a recipient of a MacArthur Fellowship, three Tony Awards, three Grammy Awards, an Emmy Award, a Pulitzer Prize, and a Kennedy Center Honor.",
            currentShow = "Hamilton (Creative Team)",
            credits = listOf("Hamilton (Alexander Hamilton)", "In the Heights (Usnavi)", "Merrily We Roll Along (Charley Kringas)"),
            filmCredits = listOf("Mary Poppins Returns (Jack)", "Hamilton Disney+ Film", "Encanto (Composer)", "Moana (Composer)"),
            tvCredits = listOf("Fosse/Verdon (Executive Producer)", "His Dark Materials (Lee Scoresby)", "Sesame Street"),
            awards = listOf("Pulitzer Prize for Drama (2016)", "Tony Award for Best Musical (2016)", "Grammy Award for Best Musical Theater Album (2016)")
        ),
        Actor(
            id = "leslie_odom",
            name = "Leslie Odom Jr.",
            roleType = "Actor / Vocalist",
            bio = "Leslie Odom Jr. is an American actor and singer. He made his Broadway debut in 'Rent' in 1998 and achieved major recognition for originating the role of Aaron Burr in the musical 'Hamilton', for which he won the 2016 Tony Award for Best Actor in a Musical.",
            currentShow = "Purlie Victorious (Star)",
            credits = listOf("Hamilton (Aaron Burr)", "Rent (Paul)", "Leap of Faith (Isaiah Sturdevant)"),
            filmCredits = listOf("Murder on the Orient Express (Dr. Arbuthnot)", "One Night in Miami... (Sam Cooke)", "Glass Onion (Lionel Toussaint)"),
            tvCredits = listOf("Smash (Sam Strickland)", "Central Park (Owen Tillerman)", "The Good Wife"),
            awards = listOf("Tony Award for Best Lead Actor (2016)", "Grammy Award (2016)", "Academy Award Nomination (2021)")
        ),
        Actor(
            id = "cynthia_erivo",
            name = "Cynthia Erivo",
            roleType = "Actress / Vocal Artist",
            bio = "Cynthia Erivo is an English actress, singer, and songwriter. She is the recipient of several accolades, including a Tony Award, a Grammy Award, and an Emmy Award, as well as nominations for two Academy Awards. She rose to fame for her performance in the Broadway revival of 'The Color Purple'.",
            currentShow = "Wicked (Elphaba - Special performance)",
            credits = listOf("The Color Purple (Celie)", "Wicked (Elphaba)"),
            filmCredits = listOf("Harriet (Harriet Tubman)", "Widows (Belle)", "Wicked Movie Adaptation (Elphaba)", "Luther: The Fallen Sun"),
            tvCredits = listOf("Genius: Aretha (Aretha Franklin)", "The Outsider (Holly Gibney)"),
            awards = listOf("Tony Award for Best Actress in a Musical (2016)", "Grammy Award for Best Album (2017)", "Daytime Emmy (2017)")
        )
    )

    val musicCategories = mapOf(
        "Original Cast Albums" to listOf(
            Track("t1", "Alexander Hamilton", "Hamilton Cast", "3:56"),
            Track("t2", "My Shot", "Lin-Manuel Miranda & Hamilton Cast", "5:33"),
            Track("t3", "Circle of Life", "Lindiwe Dlamini & Lion King Cast", "4:32"),
            Track("t4", "Defying Gravity", "Idina Menzel & Kristin Chenoweth", "5:56")
        ),
        "Broadway Classics" to listOf(
            Track("t5", "The Phantom of the Opera", "Michael Crawford & Sarah Brightman", "4:20"),
            Track("t6", "Memory", "Betty Buckley", "4:15"),
            Track("t7", "Don't Rain on My Parade", "Barbra Streisand", "2:45"),
            Track("t8", "All That Jazz", "Chita Rivera & Chicago Cast", "3:05")
        ),
        "New Musicals" to listOf(
            Track("t9", "Road to Hell", "Hadestown Cast", "4:58"),
            Track("t10", "Wait for Me", "Reeve Carney &Hadestown Cast", "5:30"),
            Track("t11", "Waving Through a Window", "Ben Platt", "3:56")
        )
    )

    val news = listOf(
        NewsArticle(
            id = "news_1",
            category = "BREAKING",
            title = "A NEW ERA OF BROADWAY BEGINS: 2030s DIGITAL INTEGRATION",
            subtitle = "The Broadway League announces comprehensive smart spatial upgrades for 41 historic venues in New York.",
            date = "Sept 11, 2026",
            content = "Broadway is stepping into the future with state-of-the-art technological enhancements. In a landmark multi-million dollar agreement, the Broadway League and New York City authorities have finalized plans to implement advanced spatial audio configurations, interactive seat navigation systems, and smart routing protocols across the entire district. This will create a premium, frictionless entry experience for the estimated 15 million annual visitors by the year 2030.",
            readTime = "4 min read"
        ),
        NewsArticle(
            id = "news_2",
            category = "REVIEWS",
            title = "HAMILTON RE-ENGINEERED: HOW SPATIAL AUDIO COMPLEMENTS THE FLOW",
            subtitle = "A critical dive into the Richard Rodgers Theatre's modern multi-dimensional upgrade.",
            date = "Sept 05, 2026",
            content = "Walking into the Richard Rodgers Theatre tonight felt different. The air was charged, but more importantly, the theatre's soundscape has undergone a profound renaissance. The new spatial audio system doesn't overwhelm; rather, it isolates the intricate cadence of Lin-Manuel Miranda's verses with high-fidelity clarity, ensuring every syllable lands with perfect emotional weight. It is a stunning triumph of technical design.",
            readTime = "6 min read"
        ),
        NewsArticle(
            id = "news_3",
            category = "CASTING",
            title = "CYNTHIA ERIVO RETURNING TO GERSHWIN FOR EXCLUSIVE RECONCILED RUN",
            subtitle = "The Tony-winner will take the stage for a limited 20-performance engagement of Wicked in October.",
            date = "Aug 29, 2026",
            content = "In a stunning announcement that has sent shockwaves through the theatrical community, Cynthia Erivo is set to return to the Gershwin stage. Erivo, who won hearts worldwide, will perform Elphaba's landmark numbers in a highly anticipated, restricted engagement. Tickets are expected to sell out within minutes of the pre-sale launch for Broadway Pass members.",
            readTime = "3 min read"
        )
    )

    val restaurants = listOf(
        Restaurant("Joe Allen", "Pre-Theatre Dining", "0.1 mi", "2 min walk", "$$$", "American Bistro", "12 PM - 12 AM"),
        Restaurant("Orso", "Fine Dining", "0.1 mi", "3 min walk", "$$$$", "High-End Italian", "5 PM - 11:30 PM"),
        Restaurant("Bar Centrale", "Cocktails", "0.2 mi", "4 min walk", "$$$", "Private Lounge", "5 PM - 1:30 AM"),
        Restaurant("Junior's Restaurant", "Casual", "0.1 mi", "1 min walk", "$$", "Diner & Cheesecake", "6:30 AM - 12 AM"),
        Restaurant("Sardi's", "Fine Dining", "0.2 mi", "5 min walk", "$$$$", "Continental & Portraits", "11:30 AM - 11 PM")
    )

    val historyTimeline = listOf(
        HistoryMilestone("1900s", "The Birth of the Great White Way", "Electric signs light up Longacre Square, renaming it Times Square. Theatre moves uptown.", "The Red Mill (1906)", "Established Broadway as the central entertainment hub of North America."),
        HistoryMilestone("1920s", "The Golden Age & The Revues", "Florenz Ziegfeld's Follies dominate, introducing high-end visual art, scale, and luxury to the stage.", "Show Boat (1927)", "Integrated narrative, music, and social commentary into a unified artistic form."),
        HistoryMilestone("1940s", "The Rodgers & Hammerstein Era", "The golden age of cohesive narrative book musicals that shaped the storytelling format of modern drama.", "Oklahoma! (1943)", "Pioneered structural integration where dance and songs explicitly advance the plot."),
        HistoryMilestone("1970s", "The Mega-Musical Pioneers", "Conceptual musicals and high-end technical architecture transform visual and sonic expectations.", "A Chorus Line (1975)", "Shifted focus to the intense raw reality of actors behind the scenes, running for over 15 years."),
        HistoryMilestone("1980s", "British Invasion & Spectacle", "Andrew Lloyd Webber's spectacles arrive, establishing unprecedented visual scales and epic orchestrations.", "The Phantom of the Opera (1988)", "Became the longest-running show in Broadway history, defining luxury commercial theatre."),
        HistoryMilestone("2010s", "The Hip-Hop & Modern Revolution", "Hamilton merges historical biography with contemporary hip-hop rhythms, expanding representation.", "Hamilton (2015)", "Transformed the cultural landscape, bringing Broadway back to the top of mainstream global charts."),
        HistoryMilestone("2030s", "The Operating System of Theatre", "Frictionless digital navigation, immersive spatial audio, and personalized concierge experiences.", "Broadway OS (2035)", "Blends the majesty of classical staging with sophisticated futuristic digital luxury.")
    )

    val tonyWinners = listOf(
        TonyCategory("Best Musical", "Hadestown", listOf("Hadestown (WINNER)", "Ain't Too Proud", "Beetlejuice", "The Prom")),
        TonyCategory("Best Play", "The Ferryman", listOf("The Ferryman (WINNER)", "Choir Boy", "Gary: A Sequel to Titus Andronicus", "Ink")),
        TonyCategory("Best Revival of a Musical", "Oklahoma!", listOf("Oklahoma! (WINNER)", "Kiss Me, Kate")),
        TonyCategory("Best Actor in a Lead Role", "Santino Fontana", listOf("Santino Fontana - Tootsie (WINNER)", "Alex Brightman - Beetlejuice", "Derrick Baskin - Ain't Too Proud"))
    )

    // --- Interactive Helper Methods ---

    fun getShowById(id: String): Show? = shows.find { it.id == id }
    
    fun getVenueById(id: String): Venue? = venues.find { it.id == id }
    
    fun getActorById(id: String): Actor? = actors.find { it.id == id }
}
