package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val BroadwayColorScheme = darkColorScheme(
    primary = TheatreRed,
    onPrimary = Color.White,
    secondary = ChampagneGold,
    onSecondary = DeepBlack,
    tertiary = WarmIvory,
    background = DeepBlack,
    onBackground = WarmIvory,
    surface = DarkManhattanGrey,
    onSurface = WarmIvory,
    surfaceVariant = ManhattanGreyCard,
    onSurfaceVariant = WarmIvoryMuted,
    outline = FineBorderColor
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force dark/theatrical mode for Broadway 2030s experience
    dynamicColor: Boolean = false, // Disable dynamic colors to maintain strict luxury theatre brand identity
    content: @Composable () -> Unit,
) {
    val colorScheme = BroadwayColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
