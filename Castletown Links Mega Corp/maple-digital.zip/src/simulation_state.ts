/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  Participant,
  ParticipantType,
  Wallet,
  WalletType,
  Transaction,
  TransactionType,
  TransactionStatus,
  LedgerEntry,
  NetworkNode,
  NetworkNodeId,
  PrivacyMode,
  IdentityLevel,
  TokenisationArchitecture,
  OfflineDeviceState,
  ComplianceAlert,
  DigitalBond,
  MacroVariables,
  SimulationConfig,
  AuditEvent,
  ModelMetrics
} from "./types.js";

export class MapleDigitalTwin {
  // Database tables / data stores
  public participants: Participant[] = [];
  public wallets: Wallet[] = [];
  public transactions: Transaction[] = [];
  public ledger_entries: LedgerEntry[] = [];
  public alerts: ComplianceAlert[] = [];
  public bonds: DigitalBond[] = [];
  public audit_events: AuditEvent[] = [];
  public network_nodes: NetworkNode[] = [];
  public offline_devices: OfflineDeviceState[] = [];

  // Macro variables
  public macro: MacroVariables = {
    gdp: 2200000000000, // $2.2 Trillion CAD
    cpi: 2.1, // Inflation Rate %
    interest_rate: 4.25, // Bank of Canada target %
    money_supply: 2500000000000, // Total M2 CAD
    cbdc_supply: 18700000000, // Initial CAD 18.7 Billion
    bank_deposits: 1850000000000, // Total Commercial Bank Deposits
    velocity: 1.4, // Velocity of money
    consumption: 1300000000000,
    investment: 450000000000,
    unemployment: 6.2,
    exchange_rate: {
      USD: 0.74,
      EUR: 0.68,
      GBP: 0.57,
      JPY: 110.5
    }
  };

  // Configuration
  public config: SimulationConfig = {
    speed: "PAUSE",
    currentTick: 0,
    seed: 2026,
    cbdcAdoptionLevel: 0.15, // 15% adoption rate
    cbdcInterestRate: 0.00, // Default non-interest bearing
    limits: {
      individual: 5000,
      merchant: 100000,
      institution: 5000000
    },
    privacyConfig: PrivacyMode.BALANCED,
    tokenisationArch: TokenisationArchitecture.ACCOUNT_BASED_CBDC,
    currentScenario: "BASELINE",
    activeOutages: {
      networkOutage: false,
      regionalOutageNode: undefined,
      centralServiceFailure: false,
      databaseReplicationFailure: false
    }
  };

  // ML models metrics
  public mlModels: { [key: string]: ModelMetrics } = {};

  constructor() {
    this.initializeSystem();
  }

  /**
   * Set up all synthetic participants, wallets, network nodes, and core structures.
   */
  public initializeSystem() {
    this.participants = [];
    this.wallets = [];
    this.transactions = [];
    this.ledger_entries = [];
    this.alerts = [];
    this.bonds = [];
    this.audit_events = [];
    this.offline_devices = [];

    // Initialize network nodes
    const nodeNames: Record<NetworkNodeId, string> = {
      [NetworkNodeId.OTTAWA]: "Central Node - Ottawa HQ",
      [NetworkNodeId.TORONTO]: "Financial Hub Node - Toronto",
      [NetworkNodeId.MONTREAL]: "Eastern Corridor Node - Montreal",
      [NetworkNodeId.VANCOUVER]: "Pacific Gateway Node - Vancouver",
      [NetworkNodeId.CALGARY]: "Energy Hub Node - Calgary",
      [NetworkNodeId.EDMONTON]: "Prairie Node - Edmonton",
      [NetworkNodeId.WINNIPEG]: "Midwest Node - Winnipeg",
      [NetworkNodeId.HALIFAX]: "Atlantic Node - Halifax"
    };

    this.network_nodes = Object.values(NetworkNodeId).map(nodeId => ({
      id: nodeId,
      name: nodeNames[nodeId],
      status: "NOMINAL",
      latency: 4 + Math.random() * 8, // ~4-12ms latency
      throughput: 1200 + Math.floor(Math.random() * 800), // ~1200-2000 tps
      failedTransactions: 0
    }));

    // 1. Create Central Bank
    const cb: Participant = {
      id: "CA-CENTRAL-BANK",
      name: "Bank of Canada Digital Sandbox",
      type: ParticipantType.CENTRAL_BANK,
      node: NetworkNodeId.OTTAWA,
      identityLevel: IdentityLevel.INSTITUTIONAL
    };
    this.participants.push(cb);

    // CBDC Liability account at CB
    const cbWallet: Wallet = {
      id: "WA-CENTRAL-BANK",
      participantId: "CA-CENTRAL-BANK",
      type: WalletType.INSTITUTIONAL,
      balance: 100000000000, // Unlimited internal liquidity buffer
      offlineBalance: 0,
      holdingLimit: 999999999999,
      dailyVolume: 0,
      dailyVolumeLimit: 999999999999,
      identityStatus: IdentityLevel.INSTITUTIONAL,
      status: "ACTIVE"
    };
    this.wallets.push(cbWallet);

    // 2. Initialize 12 commercial financial institutions with realistic balance sheets
    const bankDetails = [
      { id: "CA-BANK-RBC", name: "RBC Digital Twin", node: NetworkNodeId.TORONTO, share: 0.22, deposits: 400000000000 },
      { id: "CA-BANK-TD", name: "TD Digital Twin", node: NetworkNodeId.TORONTO, share: 0.20, deposits: 370000000000 },
      { id: "CA-BANK-BNS", name: "Scotiabank Digital Twin", node: NetworkNodeId.HALIFAX, share: 0.15, deposits: 280000000000 },
      { id: "CA-BANK-BMO", name: "BMO Digital Twin", node: NetworkNodeId.MONTREAL, share: 0.13, deposits: 240000000000 },
      { id: "CA-BANK-CIBC", name: "CIBC Digital Twin", node: NetworkNodeId.TORONTO, share: 0.12, deposits: 220000000000 },
      { id: "CA-BANK-NBC", name: "National Bank Digital Twin", node: NetworkNodeId.MONTREAL, share: 0.06, deposits: 110000000000 },
      { id: "CA-BANK-DESJ", name: "Desjardins Digital Twin", node: NetworkNodeId.MONTREAL, share: 0.05, deposits: 92000000000 },
      { id: "CA-BANK-CWB", name: "Canadian Western Digital Twin", node: NetworkNodeId.EDMONTON, share: 0.02, deposits: 36000000000 },
      { id: "CA-BANK-LB", name: "Laurentian Digital Twin", node: NetworkNodeId.MONTREAL, share: 0.015, deposits: 28000000000 },
      { id: "CA-BANK-EQB", name: "EQ Bank Digital Twin", node: NetworkNodeId.TORONTO, share: 0.015, deposits: 28000000000 },
      { id: "CA-BANK-VC", name: "Vancity CU Digital Twin", node: NetworkNodeId.VANCOUVER, share: 0.01, deposits: 18000000000 },
      { id: "CA-BANK-MCU", name: "Meridian CU Digital Twin", node: NetworkNodeId.TORONTO, share: 0.01, deposits: 18000000000 }
    ];

    const targetTotalCbdcCirculation = 18700000000; // $18.7 Billion CAD

    bankDetails.forEach(b => {
      const bankCbdcHolding = targetTotalCbdcCirculation * b.share;
      const bankReserves = b.deposits * 0.08; // 8% reserves ratio
      const loans = b.deposits * 0.75;
      const securities = b.deposits * 0.15;
      const assetsTotal = bankReserves + loans + securities;
      const capital = assetsTotal - b.deposits;

      const bank: Participant = {
        id: b.id,
        name: b.name,
        type: ParticipantType.COMMERCIAL_BANK,
        node: b.node,
        identityLevel: IdentityLevel.INSTITUTIONAL,
        associatedWalletId: "WA-" + b.id.substring(3),
        assets: {
          reserves: bankReserves - bankCbdcHolding, // Swapped reserves for CBDC
          loans: loans,
          securities: securities,
          other: assetsTotal * 0.02
        },
        liabilities: {
          deposits: b.deposits,
          cbdcOutflows: bankCbdcHolding,
          capital: capital,
          liquiditySupport: 0
        },
        profitability: 1.2 + Math.random() * 1.5
      };

      this.participants.push(bank);

      const wallet: Wallet = {
        id: "WA-" + b.id.substring(3),
        participantId: b.id,
        type: WalletType.INSTITUTIONAL,
        balance: bankCbdcHolding,
        offlineBalance: 0,
        holdingLimit: this.config.limits.institution,
        dailyVolume: 0,
        dailyVolumeLimit: 5000000000,
        identityStatus: IdentityLevel.INSTITUTIONAL,
        status: "ACTIVE"
      };
      this.wallets.push(wallet);
    });

    // 3. Create interactive Payment Providers (40 in stats, let's create 6 main ones)
    const pspDetails = [
      { id: "CA-PSP-INTERAC", name: "Interac Digital Bridge", node: NetworkNodeId.TORONTO },
      { id: "CA-PSP-PAYPAL", name: "PayPal Canada CBDC", node: NetworkNodeId.TORONTO },
      { id: "CA-PSP-SQUARE", name: "Square Canada PSP", node: NetworkNodeId.VANCOUVER },
      { id: "CA-PSP-SHOPIFY", name: "Shopify Payments CAD", node: NetworkNodeId.OTTAWA },
      { id: "CA-PSP-STRIPE", name: "Stripe Canada Gateway", node: NetworkNodeId.TORONTO },
      { id: "CA-PSP-FINTECH-N", name: "Neo Financial Proxy", node: NetworkNodeId.CALGARY }
    ];

    pspDetails.forEach(p => {
      const psp: Participant = {
        id: p.id,
        name: p.name,
        type: ParticipantType.PAYMENT_PROVIDER,
        node: p.node,
        identityLevel: IdentityLevel.INSTITUTIONAL,
        associatedWalletId: "WA-" + p.id.substring(3)
      };
      this.participants.push(psp);

      const wallet: Wallet = {
        id: "WA-" + p.id.substring(3),
        participantId: p.id,
        type: WalletType.INSTITUTIONAL,
        balance: 15000000, // Pre-funded operations treasury
        offlineBalance: 0,
        holdingLimit: this.config.limits.institution,
        dailyVolume: 0,
        dailyVolumeLimit: 200000000,
        identityStatus: IdentityLevel.INSTITUTIONAL,
        status: "ACTIVE"
      };
      this.wallets.push(wallet);
    });

    // 4. Create Interactive Merchants (with balances)
    const merchantDetails = [
      { id: "CA-MER-TIMS", name: "Tim Hortons Ottawa-01", node: NetworkNodeId.OTTAWA, balance: 45000 },
      { id: "CA-MER-LOBLAWS", name: "Loblaws Toronto HQ", node: NetworkNodeId.TORONTO, balance: 890000 },
      { id: "CA-MER-CANTIRE", name: "Canadian Tire Vancouver", node: NetworkNodeId.VANCOUVER, balance: 450000 },
      { id: "CA-MER-PETRO", name: "Petro-Canada Calgary-12", node: NetworkNodeId.CALGARY, balance: 120000 },
      { id: "CA-MER-DOLLAR", name: "Dollarama Montreal-04", node: NetworkNodeId.MONTREAL, balance: 35000 },
      { id: "CA-MER-ROOTS", name: "Roots Canada Halifax", node: NetworkNodeId.HALIFAX, balance: 65000 },
      { id: "CA-MER-SHOPIFY", name: "Shopify Merchant Hub", node: NetworkNodeId.OTTAWA, balance: 1250000 }
    ];

    merchantDetails.forEach(m => {
      const merchant: Participant = {
        id: m.id,
        name: m.name,
        type: ParticipantType.MERCHANT,
        node: m.node,
        identityLevel: IdentityLevel.VERIFIED,
        associatedWalletId: "WA-" + m.id.substring(3)
      };
      this.participants.push(merchant);

      const wallet: Wallet = {
        id: "WA-" + m.id.substring(3),
        participantId: m.id,
        type: WalletType.MERCHANT,
        balance: m.balance,
        offlineBalance: 2500, // Small offline buffer for simulated terminals
        holdingLimit: this.config.limits.merchant,
        dailyVolume: 0,
        dailyVolumeLimit: 500000,
        identityStatus: IdentityLevel.VERIFIED,
        status: "ACTIVE"
      };
      this.wallets.push(wallet);
    });

    // 5. Create Interactive Consumers (the synthetic research panel)
    const consumerDetails = [
      { id: "CA-SIM-00000001", name: "Alex Tremblay", node: NetworkNodeId.MONTREAL, level: IdentityLevel.VERIFIED, balance: 1450, offline: 350 },
      { id: "CA-SIM-00000002", name: "Marcus Johnson", node: NetworkNodeId.TORONTO, level: IdentityLevel.VERIFIED, balance: 3200, offline: 0 },
      { id: "CA-SIM-00000003", name: "Sarah Campbell", node: NetworkNodeId.HALIFAX, level: IdentityLevel.VERIFIED, balance: 420, offline: 100 },
      { id: "CA-SIM-00000004", name: "Chao Chen", node: NetworkNodeId.VANCOUVER, level: IdentityLevel.VERIFIED, balance: 4900, offline: 500 },
      { id: "CA-SIM-00000005", name: "Aisha Gidado", node: NetworkNodeId.CALGARY, level: IdentityLevel.VERIFIED, balance: 1850, offline: 0 },
      { id: "CA-SIM-00000006", name: "Jean-Pierre Roy", node: NetworkNodeId.OTTAWA, level: IdentityLevel.BASIC, balance: 80, offline: 40 },
      { id: "CA-SIM-00000007", name: "Emily Smith", node: NetworkNodeId.WINNIPEG, level: IdentityLevel.UNVERIFIED, balance: 25, offline: 10 },
      { id: "CA-SIM-00000008", name: "Devon Sinclair", node: NetworkNodeId.EDMONTON, level: IdentityLevel.VERIFIED, balance: 2900, offline: 200 }
    ];

    consumerDetails.forEach(c => {
      const consumer: Participant = {
        id: c.id,
        name: c.name,
        type: ParticipantType.CONSUMER,
        node: c.node,
        identityLevel: c.level,
        associatedWalletId: "WA-" + c.id.substring(7)
      };
      this.participants.push(consumer);

      const wallet: Wallet = {
        id: "WA-" + c.id.substring(7),
        participantId: c.id,
        type: WalletType.CONSUMER,
        balance: c.balance,
        offlineBalance: c.offline,
        holdingLimit: this.config.limits.individual,
        dailyVolume: 0,
        dailyVolumeLimit: 2500,
        identityStatus: c.level,
        status: "ACTIVE"
      };
      this.wallets.push(wallet);

      // Create matching offline device entry
      this.offline_devices.push({
        deviceId: "DEV-OFF-" + c.id.substring(7),
        walletId: wallet.id,
        balance: c.offline,
        lastSyncTimestamp: new Date().toISOString(),
        isCompromised: false,
        pendingOfflineTransactions: []
      });
    });

    // 6. Create Government Entity Participant
    const gov: Participant = {
      id: "CA-GOV-TREASURY",
      name: "Treasury of Canada (Public Accounts)",
      type: ParticipantType.GOVERNMENT,
      node: NetworkNodeId.OTTAWA,
      identityLevel: IdentityLevel.INSTITUTIONAL,
      associatedWalletId: "WA-GOV-TREASURY"
    };
    this.participants.push(gov);

    const govWallet: Wallet = {
      id: "WA-GOV-TREASURY",
      participantId: "CA-GOV-TREASURY",
      type: WalletType.INSTITUTIONAL,
      balance: 1500000000, // $1.5B Treasury Balance
      offlineBalance: 0,
      holdingLimit: 999999999999,
      dailyVolume: 0,
      dailyVolumeLimit: 999999999999,
      identityStatus: IdentityLevel.INSTITUTIONAL,
      status: "ACTIVE"
    };
    this.wallets.push(govWallet);

    // 7. Initialize 5 Synthetic Government Bonds for the Tokenisation Lab
    this.bonds = [
      { bond_id: "BOND-CAN-2028-A", issuer: "Government of Canada", face_value: 100000000, coupon: 3.5, maturity: "2028-12-01", settlement_asset: "CAD-DIGITAL", owner: "CA-BANK-RBC" },
      { bond_id: "BOND-CAN-2030-B", issuer: "Government of Canada", face_value: 200000000, coupon: 3.75, maturity: "2030-06-01", settlement_asset: "CAD-DIGITAL", owner: "CA-BANK-TD" },
      { bond_id: "BOND-CAN-2035-C", issuer: "Government of Canada", face_value: 50000000, coupon: 4.0, maturity: "2035-09-01", settlement_asset: "CAD-DIGITAL", owner: "CA-BANK-BMO" },
      { bond_id: "BOND-CAN-2027-D", issuer: "Government of Canada", face_value: 150000000, coupon: 3.25, maturity: "2027-03-01", settlement_asset: "CAD-DIGITAL", owner: "CA-BANK-CIBC" },
      { bond_id: "BOND-CAN-2040-E", issuer: "Government of Canada", face_value: 75000000, coupon: 4.25, maturity: "2040-10-01", settlement_asset: "CAD-DIGITAL", owner: "CA-BANK-BNS" }
    ];

    // Seed some initial historical transactions and ledger entries to demonstrate double-entry instantly
    this.seedHistoricalData();

    // Setup ML Models
    this.initializeMLModels();

    // Log startup
    this.logAuditEvent(
      "SYSTEM",
      "INITIALIZE",
      "MAPLE DIGITAL TWIN",
      "UNINITIALIZED",
      "NOMINAL",
      "Successfully launched national central-bank digital money simulation sandbox with 18.7 billion pre-funded circulating CAD-DIGITAL across 12 banks.",
      "STARTUP-CORR-001"
    );
  }

  private seedHistoricalData() {
    // Generate initial issuing transactions
    const initialIssuances = [
      { dest: "WA-BANK-RBC", amount: 4114000000 },
      { dest: "WA-BANK-TD", amount: 3740000000 },
      { dest: "WA-BANK-BNS", amount: 2805000000 },
      { dest: "WA-BANK-BMO", amount: 2431000000 },
      { dest: "WA-BANK-CIBC", amount: 2244000000 }
    ];

    initialIssuances.forEach((iss, index) => {
      const txId = `TX-INIT-ISS-${100 + index}`;
      const timestamp = new Date(Date.now() - (6 - index) * 3600 * 1000).toISOString();

      const tx: Transaction = {
        transaction_id: txId,
        timestamp,
        sender: "WA-CENTRAL-BANK",
        receiver: iss.dest,
        amount: iss.amount,
        currency: "CAD-DIGITAL",
        type: TransactionType.ISSUE,
        status: TransactionStatus.SETTLED,
        settlement_reference: `SETTLE-INIT-CB-${1000 + index}`,
        payment_channel: "ONLINE",
        risk_status: "LOW",
        node: NetworkNodeId.OTTAWA,
        privacyMode: PrivacyMode.BALANCED
      };

      this.transactions.push(tx);

      // Double-entry accounting entries:
      // CB Balance Sheet: CBDC Liability +iss.amount
      // Bank Balance Sheet: CBDC Asset +iss.amount, CB Reserves Asset -iss.amount (Asset swap)
      this.ledger_entries.push({
        entry_id: `L-DB-INIT-ISS-A-${index}`,
        timestamp,
        account_debit: `${iss.dest}.CBDC_ASSETS`,
        account_credit: `WA-CENTRAL-BANK.CBDC_LIABILITIES`,
        amount: iss.amount,
        currency: "CAD-DIGITAL",
        transaction_id: txId,
        reconciled: true
      });
    });

    // Seed some general historical transactions to show user and compliance ledger activity
    const samplePurchases = [
      { sender: "WA-00000001", receiver: "WA-MER-TIMS", amount: 4.25, node: NetworkNodeId.MONTREAL },
      { sender: "WA-00000002", receiver: "WA-MER-LOBLAWS", amount: 154.20, node: NetworkNodeId.TORONTO },
      { sender: "WA-00000003", receiver: "WA-MER-CANTIRE", amount: 89.99, node: NetworkNodeId.HALIFAX },
      { sender: "WA-00000004", receiver: "WA-MER-SHOPIFY", amount: 299.00, node: NetworkNodeId.VANCOUVER },
      { sender: "WA-00000005", receiver: "WA-MER-PETRO", amount: 72.50, node: NetworkNodeId.CALGARY },
      { sender: "WA-00000008", receiver: "WA-MER-DOLLAR", amount: 18.15, node: NetworkNodeId.EDMONTON }
    ];

    samplePurchases.forEach((p, idx) => {
      const txId = `TX-HIST-${1000 + idx}`;
      const timestamp = new Date(Date.now() - (4 - idx) * 1800 * 1000).toISOString();

      const tx: Transaction = {
        transaction_id: txId,
        timestamp,
        sender: p.sender,
        receiver: p.receiver,
        amount: p.amount,
        currency: "CAD-DIGITAL",
        type: TransactionType.MERCHANT_PAYMENT,
        status: TransactionStatus.SETTLED,
        settlement_reference: `SETTLE-HIST-${5000 + idx}`,
        payment_channel: "ONLINE",
        risk_status: "LOW",
        node: p.node,
        privacyMode: PrivacyMode.BALANCED
      };

      this.transactions.push(tx);

      // Ledger Entry Debit Sender, Credit Receiver
      this.ledger_entries.push({
        entry_id: `L-HIST-P-${idx}-DB`,
        timestamp,
        account_debit: `${p.receiver}.BALANCE`,
        account_credit: `${p.sender}.BALANCE`,
        amount: p.amount,
        currency: "CAD-DIGITAL",
        transaction_id: txId,
        reconciled: true
      });
    });
  }

  private initializeMLModels() {
    this.mlModels = {
      anomaly_detection: {
        name: "Payment Anomaly Analyzer (XGBoost Classifier)",
        version: "v2.4.1",
        trainingSamples: 84500,
        validationMetrics: { "AUC-ROC": 0.982, "F1-Score": 0.914, "Precision": 0.932, "Recall": 0.897 },
        featureImportance: [
          { feature: "Time-Delta-Series (Velocity)", score: 0.38 },
          { feature: "KYC-Tier vs Amount Ratio", score: 0.25 },
          { feature: "Circular Path Loop Confidence", score: 0.21 },
          { feature: "Geographic Routing Shift Velocity", score: 0.16 }
        ],
        confidence: 94.2
      },
      liquidity_forecast: {
        name: "Interbank Liquidity Predictor (LSTM Neural Net)",
        version: "v3.1.0",
        trainingSamples: 142000,
        validationMetrics: { "RMSE": 0.041, "MAE": 0.028, "MAPE": 1.42 },
        featureImportance: [
          { feature: "Outflow-Deposits Substitution Velocity", score: 0.42 },
          { feature: "CB Lending Window Rate Spread", score: 0.28 },
          { feature: "National Settlement Queue Delay", score: 0.18 },
          { feature: "Regional Bank Outflow Concentration", score: 0.12 }
        ],
        confidence: 89.5
      },
      adoption_forecast: {
        name: "Adoption & Deposit Substitution Estimator (Ridge Regression)",
        version: "v1.8.2",
        trainingSamples: 12500,
        validationMetrics: { "R-Squared": 0.912, "Adjusted R-Squared": 0.899 },
        featureImportance: [
          { feature: "CBDC Holding Limit (Individual)", score: 0.48 },
          { feature: "Commercial Bank Deposit Interest Rates", score: 0.31 },
          { feature: "CBDC Interest Remuneration Rate", score: 0.15 },
          { feature: "Public Trust & Security Perceived Index", score: 0.06 }
        ],
        confidence: 91.0
      }
    };
  }

  /**
   * Safe transaction creation with double-entry validation.
   */
  public processTransfer(
    senderId: string,
    receiverId: string,
    amount: number,
    type: TransactionType = TransactionType.TRANSFER,
    channel: "ONLINE" | "OFFLINE" = "ONLINE",
    forcedTxId?: string
  ): Transaction {
    const txId = forcedTxId || `TX-${Math.floor(100000 + Math.random() * 900000)}`;
    const timestamp = new Date().toISOString();
    const correlation_id = `CORR-${Math.floor(100000 + Math.random() * 900000)}`;

    // Resolve wallets
    const senderWallet = this.wallets.find(w => w.id === senderId);
    const receiverWallet = this.wallets.find(w => w.id === receiverId);

    // Initial response scaffold
    const tx: Transaction = {
      transaction_id: txId,
      timestamp,
      sender: senderId,
      receiver: receiverId,
      amount,
      currency: "CAD-DIGITAL",
      type,
      status: TransactionStatus.PENDING,
      settlement_reference: `SETTLE-PENDING-${txId}`,
      payment_channel: channel,
      risk_status: "LOW",
      node: NetworkNodeId.TORONTO,
      privacyMode: this.config.privacyConfig
    };

    // 1. Pre-flight checks
    if (!senderWallet) {
      tx.status = TransactionStatus.FAILED;
      tx.settlement_reference = "FAILED-SENDER-NOT-FOUND";
      this.logAuditEvent("SYSTEM", "TRANSFER", txId, "PENDING", "FAILED", "Sender wallet not found", correlation_id);
      this.transactions.push(tx);
      return tx;
    }
    if (!receiverWallet) {
      tx.status = TransactionStatus.FAILED;
      tx.settlement_reference = "FAILED-RECEIVER-NOT-FOUND";
      this.logAuditEvent("SYSTEM", "TRANSFER", txId, "PENDING", "FAILED", "Receiver wallet not found", correlation_id);
      this.transactions.push(tx);
      return tx;
    }

    // Capture previous states for audit trail
    const prevSenderBalance = senderWallet.balance;
    const prevReceiverBalance = receiverWallet.balance;

    // Node resolution
    const senderPart = this.participants.find(p => p.associatedWalletId === senderWallet.id || p.id === senderWallet.participantId);
    if (senderPart) {
      tx.node = senderPart.node;
    }

    // 2. Validate Outages (Resilience simulator)
    if (this.config.activeOutages.centralServiceFailure) {
      tx.status = TransactionStatus.FAILED;
      tx.settlement_reference = "FAILED-CENTRAL-OUTAGE";
      this.logAuditEvent("SYSTEM", "TRANSFER", txId, "PENDING", "FAILED", "Core Central CBDC Ledger outage actively preventing transaction processing", correlation_id);
      this.transactions.push(tx);
      return tx;
    }

    if (this.config.activeOutages.networkOutage && channel === "ONLINE") {
      // Put transaction in Queued status for later resolution
      tx.status = TransactionStatus.QUEUED;
      tx.settlement_reference = "QUEUE-NETWORK-OUTAGE";
      this.logAuditEvent("SYSTEM", "TRANSFER", txId, "PENDING", "QUEUED", "National network outage detected. Transaction held in Settlement Queue.", correlation_id);
      this.transactions.push(tx);
      return tx;
    }

    if (this.config.activeOutages.regionalOutageNode === tx.node && channel === "ONLINE") {
      tx.status = TransactionStatus.QUEUED;
      tx.settlement_reference = `QUEUE-REGIONAL-OUTAGE-${tx.node}`;
      this.logAuditEvent("SYSTEM", "TRANSFER", txId, "PENDING", "QUEUED", `Regional Network Failure at Node ${tx.node}. Transaction placed in node settlement queue.`, correlation_id);
      this.transactions.push(tx);
      return tx;
    }

    // 3. Balance checks
    const senderAvailable = channel === "ONLINE" ? senderWallet.balance : senderWallet.offlineBalance;
    if (senderAvailable < amount) {
      tx.status = TransactionStatus.FAILED;
      tx.settlement_reference = "FAILED-INSUFFICIENT-FUNDS";
      this.logAuditEvent("SYSTEM", "TRANSFER", txId, "PENDING", "FAILED", `Insufficient ${channel} balance. Available: ${senderAvailable}, Requested: ${amount}`, correlation_id);
      this.transactions.push(tx);
      return tx;
    }

    // 4. Holding limits check (unless Central Bank or Treasury)
    const isSpecialUnit = senderWallet.id === "WA-CENTRAL-BANK" || receiverWallet.id === "WA-GOV-TREASURY";
    if (!isSpecialUnit) {
      const prospectiveBalance = (channel === "ONLINE" ? receiverWallet.balance : receiverWallet.offlineBalance) + amount;
      if (prospectiveBalance > receiverWallet.holdingLimit) {
        tx.status = TransactionStatus.FAILED;
        tx.settlement_reference = "FAILED-LIMIT-EXCEEDED";
        this.logAuditEvent(
          "SYSTEM",
          "TRANSFER",
          txId,
          "PENDING",
          "FAILED",
          `Receiver balance limit exceeded. Limit: ${receiverWallet.holdingLimit}, Prospective: ${prospectiveBalance}`,
          correlation_id
        );
        this.transactions.push(tx);
        return tx;
      }
    }

    // 5. Run Compliance & AML engine
    const scanResult = this.scanCompliance(tx, senderWallet, receiverWallet);
    if (scanResult.riskScore >= 85) {
      tx.risk_status = "HIGH";
      tx.risk_reason = scanResult.reason;
      // Depending on privacy setting, we flag or block
      if (this.config.privacyConfig === PrivacyMode.HIGH_TRACEABILITY) {
        tx.status = TransactionStatus.FAILED;
        tx.settlement_reference = "FAILED-COMPLIANCE-REJECTION";
        this.logAuditEvent(
          "COMPLIANCE_ENGINE",
          "SCAN",
          txId,
          "PENDING",
          "FAILED",
          `AML/CFT Risk score unacceptable (${scanResult.riskScore}/100) under High Traceability: ${scanResult.reason}`,
          correlation_id
        );
        this.transactions.push(tx);
        return tx;
      } else {
        tx.risk_status = "MEDIUM"; // Flagged for offline auditing
      }
    }

    // 6. Execute Accounting Transfer (Monetary Conservation guaranteed)
    if (channel === "ONLINE") {
      senderWallet.balance -= amount;
      receiverWallet.balance += amount;
      senderWallet.dailyVolume += amount;
    } else {
      senderWallet.offlineBalance -= amount;
      receiverWallet.offlineBalance += amount;
      senderWallet.dailyVolume += amount;

      // Update offline device caches
      const sDev = this.offline_devices.find(d => d.walletId === senderWallet.id);
      const rDev = this.offline_devices.find(d => d.walletId === receiverWallet.id);
      if (sDev) {
        sDev.balance = senderWallet.offlineBalance;
        sDev.pendingOfflineTransactions.push({ txId, amount, recipientId: receiverId, timestamp });
      }
      if (rDev) {
        rDev.balance = receiverWallet.offlineBalance;
      }
    }

    // Confirm settlement
    tx.status = TransactionStatus.SETTLED;
    tx.settlement_reference = `SETTLE-CORE-${Math.floor(100000 + Math.random() * 900000)}`;

    // Add transactions to standard lists
    this.transactions.push(tx);

    // Double-entry ledger postings (Immutable Audit Records)
    this.ledger_entries.push({
      entry_id: `L-DB-${txId}`,
      timestamp,
      account_debit: `${receiverId}.BALANCE`,
      account_credit: `${senderId}.BALANCE`,
      amount,
      currency: "CAD-DIGITAL",
      transaction_id: txId,
      reconciled: true
    });

    // Handle institutional balance sheet adjustment if it involves commercial bank balance shifts
    this.recalculateBankBalanceSheets();

    // Log the successful event
    this.logAuditEvent(
      senderWallet.id,
      "TRANSFER",
      txId,
      `Balance: ${prevSenderBalance} -> ${senderWallet.balance}`,
      `Balance: ${prevReceiverBalance} -> ${receiverWallet.balance}`,
      `Settled transfer of ${amount} CAD-DIGITAL`,
      correlation_id
    );

    return tx;
  }

  /**
   * Recalculates the balance sheets of synthetic commercial banks based on deposit outflows and reserves.
   */
  public recalculateBankBalanceSheets() {
    this.participants.forEach(p => {
      if (p.type === ParticipantType.COMMERCIAL_BANK) {
        const wallet = this.wallets.find(w => w.participantId === p.id);
        if (wallet && p.assets && p.liabilities) {
          // Track substitution: as customers transfer deposits to retail CBDC, banks lose deposits (liabilities)
          // and must cover them by transferring central-bank reserves to CBDC liability accounts.
          p.liabilities.cbdcOutflows = wallet.balance;

          // Recalculate reserves: deposits * 0.08 is typical. If substitution is high, reserves dry up.
          const baseReserveTarget = p.liabilities.deposits * 0.08;
          p.assets.reserves = Math.max(1000000, baseReserveTarget - p.liabilities.cbdcOutflows);

          // If reserves fall dangerously low, bank is forced to borrow liquidity support from CB
          if (p.assets.reserves < p.liabilities.deposits * 0.02) {
            const shortage = (p.liabilities.deposits * 0.04) - p.assets.reserves;
            p.liabilities.liquiditySupport = shortage;
            p.assets.reserves += shortage;

            this.logAuditEvent(
              "CENTRAL_BANK_RISK",
              "LIQUIDITY_INJECTION",
              p.id,
              "RESERVES_DEPLETED",
              "NOMINAL_INJECTED",
              `Injected emergency monetary support of ${shortage.toLocaleString()} CAD-DIGITAL into ${p.name} to avoid settlement failure.`,
              "EMERGENCY-L-001"
            );
          } else {
            p.liabilities.liquiditySupport = 0;
          }

          // Calculate capital and profitability adjustments
          p.liabilities.capital = (p.assets.reserves + p.assets.loans + p.assets.securities) - (p.liabilities.deposits + p.liabilities.liquiditySupport);
          p.profitability = Math.max(0.1, 2.5 - (p.liabilities.cbdcOutflows / p.liabilities.deposits) * 12);
        }
      }
    });

    // Keep macro variables synchronized with simulation sums
    const totalCirc = this.wallets
      .filter(w => w.id !== "WA-CENTRAL-BANK" && w.id !== "WA-GOV-TREASURY")
      .reduce((sum, w) => sum + w.balance + w.offlineBalance, 0);

    this.macro.cbdc_supply = totalCirc;

    const totalDeposits = this.participants
      .filter(p => p.type === ParticipantType.COMMERCIAL_BANK)
      .reduce((sum, p) => sum + (p.liabilities?.deposits || 0), 0);

    this.macro.bank_deposits = totalDeposits;
  }

  /**
   * Run synthetic machine-learning compliance engine.
   */
  private scanCompliance(tx: Transaction, sWallet: Wallet, rWallet: Wallet): { riskScore: number; reason: string; code: string } {
    // 1. Threshold rules
    if (tx.amount >= 2000000) {
      return {
        riskScore: 92,
        reason: "Institutional threshold alert: transaction value exceeds typical participant variance boundaries.",
        code: "ALERT_LARGE_VOLUME"
      };
    }

    // 2. Structuring rules (Multiple transactions of high amounts near limits)
    const recentSenderTx = this.transactions
      .filter(t => t.sender === tx.sender && t.status === TransactionStatus.SETTLED)
      .slice(-2);

    if (recentSenderTx.length >= 2) {
      const averageAmt = (recentSenderTx.reduce((sum, t) => sum + t.amount, 0) + tx.amount) / (recentSenderTx.length + 1);
      if (averageAmt > 4500 && tx.amount > 4500 && this.config.limits.individual <= 5000) {
        this.triggerComplianceAlert(tx, "STRUCTURING", 88, ["STRUC-04", "LIMIT-AVOID"]);
        return {
          riskScore: 88,
          reason: "Structuring Pattern: Multiple large transactions hovering immediately below standard individual holding thresholds.",
          code: "ALERT_STRUCTURING"
        };
      }
    }

    // 3. Velocity / Rapid Chains (Rapid balance sweep)
    if (recentSenderTx.length >= 2) {
      const lastTx = recentSenderTx[recentSenderTx.length - 1];
      const timeDiffSeconds = (new Date(tx.timestamp).getTime() - new Date(lastTx.timestamp).getTime()) / 1000;
      if (timeDiffSeconds < 10 && tx.amount > sWallet.balance * 0.8) {
        this.triggerComplianceAlert(tx, "RAPID_CHAIN", 82, ["VEL-01", "SWEEP-90"]);
        return {
          riskScore: 82,
          reason: "Rapid Chain Sweep: Heavy balance drainage initiated within seconds of preceding settle notifications.",
          code: "ALERT_RAPID_CHAIN"
        };
      }
    }

    // 4. Circular feedback loop (A -> B -> C -> A)
    if (tx.sender === "WA-00000001" && tx.receiver === "WA-00000002") {
      const loopingTx = this.transactions.find(t => t.sender === "WA-00000002" && t.receiver === "WA-00000001");
      if (loopingTx) {
        this.triggerComplianceAlert(tx, "CIRCULAR", 90, ["CIRC-02", "ROUND-TRIP"]);
        return {
          riskScore: 90,
          reason: "Circular Round-tripping: Loop detected passing funds dynamically across identical nodes to simulate adoption activity.",
          code: "ALERT_CIRCULAR"
        };
      }
    }

    // Default nominal
    return { riskScore: 5 + Math.floor(Math.random() * 15), reason: "Legitimate peer transaction confirmed via synthetic gateway.", code: "OK" };
  }

  private triggerComplianceAlert(tx: Transaction, type: ComplianceAlert["type"], riskScore: number, reasonCodes: string[]) {
    const alert: ComplianceAlert = {
      alert_id: `ALT-${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: new Date().toISOString(),
      transaction_id: tx.transaction_id,
      sender: tx.sender,
      receiver: tx.receiver,
      amount: tx.amount,
      type,
      risk_score: riskScore,
      status: "PENDING",
      reason_codes: reasonCodes
    };
    this.alerts.push(alert);
  }

  /**
   * Controlled issuance engine (Bank of Canada expansionary mechanism).
   */
  public issueCbdc(bankId: string, amount: number, reason: string): Transaction {
    const correlation_id = `ISSUE-${Math.floor(100000 + Math.random() * 900000)}`;

    const bank = this.participants.find(p => p.id === bankId);
    if (!bank || !bank.associatedWalletId) {
      throw new Error(`Target commercial participant ${bankId} not registered.`);
    }

    const txId = `TX-ISS-${Math.floor(100000 + Math.random() * 900000)}`;
    const timestamp = new Date().toISOString();

    // Create Issue Transaction
    const tx = this.processTransfer("WA-CENTRAL-BANK", bank.associatedWalletId, amount, TransactionType.ISSUE, "ONLINE", txId);

    if (tx.status === TransactionStatus.SETTLED) {
      // Record double-entry and update CB balance sheet
      // CB Balance Sheet: CBDC Liabilities +amount, Bank reserves (offset assets/deposit)
      this.logAuditEvent(
        "CENTRAL_BANK",
        "ISSUE_CBDC",
        txId,
        `Circulation: ${this.macro.cbdc_supply}`,
        `New Circulation: ${this.macro.cbdc_supply + amount}`,
        `Approved expansion of ${amount.toLocaleString()} CAD-DIGITAL to ${bank.name}. Reason: ${reason}`,
        correlation_id
      );
    }

    return tx;
  }

  /**
   * Controlled redemption engine (Monetary contraction).
   */
  public redeemCbdc(bankId: string, amount: number): Transaction {
    const correlation_id = `REDEEM-${Math.floor(100000 + Math.random() * 900000)}`;
    const bank = this.participants.find(p => p.id === bankId);
    if (!bank || !bank.associatedWalletId) {
      throw new Error(`Target commercial participant ${bankId} not registered.`);
    }

    const txId = `TX-RED-${Math.floor(100000 + Math.random() * 900000)}`;
    const timestamp = new Date().toISOString();

    // Process Transfer Bank -> Central Bank
    const tx = this.processTransfer(bank.associatedWalletId, "WA-CENTRAL-BANK", amount, TransactionType.REDEEM, "ONLINE", txId);

    if (tx.status === TransactionStatus.SETTLED) {
      this.logAuditEvent(
        "CENTRAL_BANK",
        "REDEEM_CBDC",
        txId,
        `Circulation: ${this.macro.cbdc_supply}`,
        `New Circulation: ${this.macro.cbdc_supply - amount}`,
        `Contracted and retired ${amount.toLocaleString()} CAD-DIGITAL from circulation via ${bank.name} redemption.`,
        correlation_id
      );
    }

    return tx;
  }

  /**
   * Deterministic clock ticks. Drives transactions, network events, and economic shifts.
   */
  public tick() {
    this.config.currentTick += 1;
    const speedMultiplier = this.getSpeedMultiplier();

    // Skip tick operations if paused
    if (this.config.speed === "PAUSE") return;

    // 1. Auto-generate payments dynamically based on adoption settings & speed
    const numPayments = Math.floor((1 + Math.random() * 3) * speedMultiplier);
    for (let i = 0; i < numPayments; i++) {
      this.generateRandomSimulatedPayment();
    }

    // 2. Perform macroeconomic updates based on current adoption and stress scenarios
    this.updateMacroeconomicSimulation();

    // 3. Resolve some queued network settlements if network nominal has recovered
    if (!this.config.activeOutages.networkOutage) {
      const queued = this.transactions.filter(t => t.status === TransactionStatus.QUEUED);
      if (queued.length > 0) {
        // Resolve first queued transaction
        const qTx = queued[0];
        qTx.status = TransactionStatus.SETTLED;
        qTx.settlement_reference = `SETTLE-QUEUED-${qTx.transaction_id}`;

        const sW = this.wallets.find(w => w.id === qTx.sender);
        const rW = this.wallets.find(w => w.id === qTx.receiver);
        if (sW && rW) {
          sW.balance -= qTx.amount;
          rW.balance += qTx.amount;
          this.recalculateBankBalanceSheets();
        }

        this.logAuditEvent(
          "NETWORK_ROUTING",
          "QUEUE_RESOLVE",
          qTx.transaction_id,
          "QUEUED",
          "SETTLED",
          `Restored connectivity: settled transaction of ${qTx.amount} CAD-DIGITAL dynamically.`,
          "QUEUE-RESTORE-01"
        );
      }
    }

    // 4. Reset daily limit volumes every 20 ticks
    if (this.config.currentTick % 20 === 0) {
      this.wallets.forEach(w => w.dailyVolume = 0);
    }
  }

  private getSpeedMultiplier(): number {
    switch (this.config.speed) {
      case "REALTIME": return 1;
      case "2X": return 2;
      case "5X": return 5;
      case "10X": return 10;
      default: return 0;
    }
  }

  private generateRandomSimulatedPayment() {
    // Pick random consumer wallet
    const consumers = this.wallets.filter(w => w.type === WalletType.CONSUMER && w.status === "ACTIVE" && w.balance > 10);
    const merchants = this.wallets.filter(w => w.type === WalletType.MERCHANT);

    if (consumers.length > 0 && merchants.length > 0) {
      const randomConsumer = consumers[Math.floor(Math.random() * consumers.length)];
      const randomMerchant = merchants[Math.floor(Math.random() * merchants.length)];

      const amount = Number((2 + Math.random() * 85).toFixed(2));
      this.processTransfer(randomConsumer.id, randomMerchant.id, amount, TransactionType.MERCHANT_PAYMENT);
    }
  }

  private updateMacroeconomicSimulation() {
    // Mathematical economic transmission channels
    const baseInterestRate = this.macro.interest_rate;
    const cbdcRemun = this.config.cbdcInterestRate;
    const adoption = this.config.cbdcAdoptionLevel;

    // Transmission 1: Bank deposit substitution
    // If CBDC adoption increases and holding limits are high, retail customers substitute deposits for risk-free central bank liabilities
    const depositDrainRatio = adoption * 0.18; // Up to 18% of bank deposits can substitute to CBDC
    const initialDeposits = 1850000000000;
    this.macro.bank_deposits = initialDeposits * (1 - depositDrainRatio);

    // Transmission 2: Credit contraction
    // As bank deposits drain, their liquidity shrinks, driving loan rates up and tightening borrowing, lowering investment
    const lendingMultiplier = Math.max(0.7, 1 - depositDrainRatio * 1.5);
    this.macro.investment = 450000000000 * lendingMultiplier;

    // Transmission 3: Velocity of CBDC
    // Non-interest bearing makes CBDC a pure payment vehicle with high velocity. Interest-bearing turns it into store of value, lowering velocity.
    this.macro.velocity = Number((1.4 - (cbdcRemun > 0 ? (cbdcRemun / 10) * 0.5 : 0)).toFixed(2));

    // Transmission 4: GDP adjustment
    const baselineGdp = 2200000000000;
    // GDP is C + I + G + (X-M). High bank drain could slightly lower short-term investment but increase financial inclusion efficiency.
    const inclusionBoost = adoption * 0.02 * baselineGdp;
    const investmentDip = (1 - lendingMultiplier) * 0.15 * baselineGdp;
    this.macro.gdp = baselineGdp + inclusionBoost - investmentDip;

    // Transmission 5: Unemployment link (Okun's law shift)
    const gdpGrowthPct = (this.macro.gdp / baselineGdp - 1) * 100;
    this.macro.unemployment = Number(Math.max(4.0, 6.2 - gdpGrowthPct * 0.4).toFixed(1));

    // Synchronize nodes statistics based on load
    this.network_nodes.forEach(node => {
      if (this.config.activeOutages.networkOutage) {
        node.status = "OUTAGE";
        node.latency = 999;
        node.throughput = 0;
      } else if (this.config.activeOutages.regionalOutageNode === node.id) {
        node.status = "OUTAGE";
        node.latency = 999;
        node.throughput = 0;
      } else {
        // Normal random jitter
        node.status = Math.random() > 0.85 ? "CONGESTED" : "NOMINAL";
        node.latency = Number((4 + Math.random() * 8 + (node.status === "CONGESTED" ? 45 : 0)).toFixed(1));
        node.throughput = Math.floor(1400 + Math.random() * 400 + (adoption * 200));
      }
    });
  }

  /**
   * Run Stress Testing Module - Severe Recession Shock
   */
  public injectStressTestRecession() {
    this.config.currentScenario = "BANKING_STRESS";
    this.config.cbdcAdoptionLevel = 0.45; // Panic flight to safety

    // Massive substitution: customers transfer $300 Billion into CBDC
    this.participants.forEach(p => {
      if (p.type === ParticipantType.COMMERCIAL_BANK && p.liabilities && p.assets) {
        // Simulate massive deposit runs (30% drainage)
        const drain = p.liabilities.deposits * 0.3;
        p.liabilities.deposits -= drain;

        // Balance sheet shrinks, loans are squeezed
        p.assets.loans -= drain * 0.6;
        p.assets.reserves = Math.max(100000, p.assets.reserves - drain * 0.4);

        // Record forced liquidity injection requirement from CB
        p.liabilities.cbdcOutflows += drain * 0.2;
      }
    });

    this.recalculateBankBalanceSheets();

    this.logAuditEvent(
      "CENTRAL_BANK_STABILITY",
      "STRESS_TEST_INJECT",
      "SEVERE_RECESSION",
      "BASELINE",
      "CRITICAL",
      "Simulating extreme macroeconomic recession: 30% commercial deposit drain, rapid flight to safety in retail CBDC, and critical reserves contraction.",
      "STRESS-RECES-2026"
    );
  }

  /**
   * Reset System back to baseline
   */
  public restoreNominalScenario() {
    this.config.currentScenario = "BASELINE";
    this.config.cbdcAdoptionLevel = 0.15;
    this.config.cbdcInterestRate = 0.00;
    this.config.activeOutages = {
      networkOutage: false,
      regionalOutageNode: undefined,
      centralServiceFailure: false,
      databaseReplicationFailure: false
    };

    // Re-initialize core structures to baseline ratios
    this.initializeSystem();

    this.logAuditEvent(
      "CENTRAL_BANK",
      "RESTORE_NOMINAL",
      "ALL_SYSTEMS",
      "STRESSED_OR_OUTAGE",
      "NOMINAL",
      "Restored national monetary sandbox to baseline nominal settings, clearing active stress testing environments.",
      "RESTORE-NOM-001"
    );
  }

  /**
   * Offline Laboratory Actions: Simulate offline payments and dual spending
   */
  public triggerOfflinePayment(fromWalletId: string, toWalletId: string, amount: number): Transaction {
    // Process offline transfers immediately without ledger clearance
    const tx = this.processTransfer(fromWalletId, toWalletId, amount, TransactionType.OFFLINE_TRANSFER, "OFFLINE");
    return tx;
  }

  /**
   * Sync offline device balances to central ledger. Detects double spending.
   */
  public syncOfflineDevice(deviceId: string): { status: "SUCCESS" | "CONFLICT_DETECTED"; resolvedTxCount: number; conflictDetails?: string } {
    const dev = this.offline_devices.find(d => d.deviceId === deviceId);
    if (!dev) {
      return { status: "SUCCESS", resolvedTxCount: 0 };
    }

    const wallet = this.wallets.find(w => w.id === dev.walletId);
    if (!wallet) {
      return { status: "SUCCESS", resolvedTxCount: 0 };
    }

    // Check if device is compromised
    if (dev.isCompromised) {
      // Flag double spend block
      this.logAuditEvent(
        "OFFLINE_CORE_SYNC",
        "SYNC_REJECTED",
        deviceId,
        "COMPROMISED",
        "ISOLATED",
        `Sync rejected: cryptographic terminal validation keys marked compromised or altered. Security quarantine enforced.`,
        "COMP-SYNC-ERR"
      );
      return { status: "CONFLICT_DETECTED", resolvedTxCount: 0, conflictDetails: "Security credentials compromised. Access token revoked." };
    }

    // Resolve transaction backlog
    let resolved = 0;
    const previousBalance = wallet.balance;

    // Check for double spending: if total balance exceeds expected limits
    if (dev.balance + wallet.balance > wallet.holdingLimit + 500) {
      // Trigger security quarantine
      dev.isCompromised = true;
      wallet.status = "COMPROMISED";

      this.logAuditEvent(
        "COMPLIANCE_ALARM",
        "DOUBLE_SPEND_DETECTED",
        deviceId,
        "NOMINAL",
        "QUARANTINED",
        `CRITICAL FRAUD ALERT: Duplicate spending signature mismatch on device. Total aggregated device and ledger value exceeds core system boundaries.`,
        "DBL-SPEND-AL-001"
      );

      return {
        status: "CONFLICT_DETECTED",
        resolvedTxCount: 0,
        conflictDetails: "Double spending violation detected. Cryptographic signature collision. Accounts frozen."
      };
    }

    // Successfully synchronize balances
    wallet.balance += (dev.balance - wallet.offlineBalance);
    wallet.offlineBalance = 0;
    dev.balance = 0;
    dev.pendingOfflineTransactions = [];
    dev.lastSyncTimestamp = new Date().toISOString();

    this.logAuditEvent(
      deviceId,
      "OFFLINE_SYNC",
      wallet.id,
      `Balance: ${previousBalance} -> ${wallet.balance}`,
      `Offline: ${wallet.offlineBalance} -> 0`,
      "Successfully merged and reconciled offline transactions back to central ledger. Monetary conservation verified.",
      "OFF-SYNC-CORR-01"
    );

    return { status: "SUCCESS", resolvedTxCount: resolved };
  }

  /**
   * Buy Government Bond using Retail CBDC (Tokenisation Lab)
   */
  public purchaseDigitalBond(participantId: string, bondId: string): { success: boolean; message: string } {
    const bond = this.bonds.find(b => b.bond_id === bondId);
    if (!bond) return { success: false, message: "Bond structure not found." };

    const buyer = this.participants.find(p => p.id === participantId);
    if (!buyer || !buyer.associatedWalletId) return { success: false, message: "Buyer wallet not resolved." };

    const w = this.wallets.find(wl => wl.id === buyer.associatedWalletId);
    if (!w || w.balance < bond.face_value) return { success: false, message: "Insufficient CBDC holdings to cover bond principal." };

    // Debit Buyer, Credit Government Account (Treasury)
    this.processTransfer(w.id, "WA-GOV-TREASURY", bond.face_value, TransactionType.TRANSFER);

    // Swap owner
    const oldOwner = bond.owner;
    bond.owner = participantId;

    this.logAuditEvent(
      participantId,
      "BOND_PURCHASE",
      bondId,
      `Previous Owner: ${oldOwner}`,
      `New Owner: ${participantId}`,
      `Exchanged ${bond.face_value.toLocaleString()} CAD-DIGITAL atomic settlement for coupon maturity rights of ${bond.bond_id}.`,
      "BOND-SWAP-01"
    );

    return { success: true, message: `Successfully completed atomic Delivery-vs-Payment (DvP) bond swap.` };
  }

  /**
   * Cross-Border Instant FX Settlement (Simulation Experiment)
   */
  public executeCrossBorderSettlement(
    sourceWalletId: string,
    targetCurrency: "USD" | "EUR" | "GBP" | "JPY",
    sourceAmount: number
  ): { success: boolean; txId: string; fxRate: number; foreignAmount: number; message: string } {
    const sWallet = this.wallets.find(w => w.id === sourceWalletId);
    if (!sWallet || sWallet.balance < sourceAmount) {
      return { success: false, txId: "", fxRate: 0, foreignAmount: 0, message: "Insufficient balance for FX remittance." };
    }

    const fxRate = this.macro.exchange_rate[targetCurrency];
    const foreignAmount = sourceAmount * fxRate;

    // Direct debit from source wallet
    sWallet.balance -= sourceAmount;

    // Core central bank settlement liability swap
    const txId = `TX-CROSS-${Math.floor(100000 + Math.random() * 900000)}`;

    const tx: Transaction = {
      transaction_id: txId,
      timestamp: new Date().toISOString(),
      sender: sourceWalletId,
      receiver: `FOREIGN-CORRESPONDENT-NODE-${targetCurrency}`,
      amount: sourceAmount,
      currency: "CAD-DIGITAL",
      type: TransactionType.TRANSFER,
      status: TransactionStatus.SETTLED,
      settlement_reference: `SETTLE-FX-GRID-${txId}`,
      payment_channel: "ONLINE",
      risk_status: "LOW",
      node: NetworkNodeId.TORONTO,
      privacyMode: this.config.privacyConfig
    };

    this.transactions.push(tx);

    this.logAuditEvent(
      sourceWalletId,
      "CROSS_BORDER_REMITTANCE",
      txId,
      `CAD Outflow: ${sourceAmount}`,
      `FX Received: ${foreignAmount.toFixed(2)} ${targetCurrency}`,
      `Atomic Cross-Border tokenised settlement finalized against currency rate ${fxRate}. Foreign asset credited instantly.`,
      "FX-REM-001"
    );

    return {
      success: true,
      txId,
      fxRate,
      foreignAmount,
      message: `Remitted ${sourceAmount} CAD to ${foreignAmount.toFixed(2)} ${targetCurrency} instantly on foreign settlement ledger.`
    };
  }

  private logAuditEvent(actor: string, action: string, object: string, previous_state: string, new_state: string, reason: string, correlation_id: string) {
    const event: AuditEvent = {
      event_id: `AUD-${Math.floor(100000 + Math.random() * 900000)}`,
      timestamp: new Date().toISOString(),
      actor,
      action,
      object,
      previous_state,
      new_state,
      reason,
      correlation_id
    };
    this.audit_events.push(event);
  }
}
