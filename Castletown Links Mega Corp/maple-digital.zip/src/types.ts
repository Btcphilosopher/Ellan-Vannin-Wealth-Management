/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum ParticipantType {
  CENTRAL_BANK = "CENTRAL_BANK",
  COMMERCIAL_BANK = "COMMERCIAL_BANK",
  CREDIT_UNION = "CREDIT_UNION",
  PAYMENT_PROVIDER = "PAYMENT_PROVIDER",
  FINTECH = "FINTECH",
  MERCHANT = "MERCHANT",
  CONSUMER = "CONSUMER",
  GOVERNMENT = "GOVERNMENT"
}

export enum WalletType {
  CONSUMER = "CONSUMER",
  MERCHANT = "MERCHANT",
  INSTITUTIONAL = "INSTITUTIONAL"
}

export enum TransactionType {
  ISSUE = "ISSUE",
  REDEEM = "REDEEM",
  TRANSFER = "TRANSFER",
  MERCHANT_PAYMENT = "MERCHANT_PAYMENT",
  REFUND = "REFUND",
  OFFLINE_TRANSFER = "OFFLINE_TRANSFER",
  SETTLEMENT = "SETTLEMENT",
  REVERSAL = "REVERSAL",
  FEE = "FEE",
  ADJUSTMENT = "ADJUSTMENT"
}

export enum TransactionStatus {
  PENDING = "PENDING",
  QUEUED = "QUEUED",
  SETTLED = "SETTLED",
  FAILED = "FAILED",
  REVERSED = "REVERSED"
}

export enum NetworkNodeId {
  OTTAWA = "OTTAWA",
  TORONTO = "TORONTO",
  MONTREAL = "MONTREAL",
  VANCOUVER = "VANCOUVER",
  CALGARY = "CALGARY",
  EDMONTON = "EDMONTON",
  WINNIPEG = "WINNIPEG",
  HALIFAX = "HALIFAX"
}

export enum PrivacyMode {
  HIGH_PRIVACY = "HIGH_PRIVACY", // Anonymous for low-value, zero CB visibility
  BALANCED = "BALANCED",         // Standard AML, masked user details
  HIGH_TRACEABILITY = "HIGH_TRACEABILITY" // Full central-bank auditing
}

export enum IdentityLevel {
  UNVERIFIED = "UNVERIFIED",
  BASIC = "BASIC",
  VERIFIED = "VERIFIED",
  INSTITUTIONAL = "INSTITUTIONAL"
}

export enum TokenisationArchitecture {
  TOKENISED_CBDC = "TOKENISED_CBDC",
  ACCOUNT_BASED_CBDC = "ACCOUNT_BASED_CBDC"
}

export interface Participant {
  id: string; // e.g., "CA-BANK-001" or "CA-SIM-00000001"
  name: string;
  type: ParticipantType;
  node: NetworkNodeId;
  identityLevel: IdentityLevel;
  associatedWalletId?: string;
  // For Commercial Banks:
  assets?: {
    reserves: number;
    loans: number;
    securities: number;
    other: number;
  };
  liabilities?: {
    deposits: number;
    cbdcOutflows: number;
    capital: number;
    liquiditySupport: number;
  };
  profitability?: number;
}

export interface Wallet {
  id: string;
  participantId: string;
  type: WalletType;
  balance: number;
  offlineBalance: number;
  holdingLimit: number;
  dailyVolume: number;
  dailyVolumeLimit: number;
  identityStatus: IdentityLevel;
  status: "ACTIVE" | "SUSPENDED" | "COMPROMISED";
}

export interface Transaction {
  transaction_id: string;
  timestamp: string;
  sender: string; // Participant / Wallet ID
  receiver: string; // Participant / Wallet ID
  amount: number;
  currency: "CAD-DIGITAL" | "CAD";
  type: TransactionType;
  status: TransactionStatus;
  settlement_reference: string;
  payment_channel: "ONLINE" | "OFFLINE";
  risk_status: "LOW" | "MEDIUM" | "HIGH";
  risk_reason?: string;
  node: NetworkNodeId;
  privacyMode: PrivacyMode;
}

export interface LedgerEntry {
  entry_id: string;
  timestamp: string;
  account_debit: string;
  account_credit: string;
  amount: number;
  currency: string;
  transaction_id: string;
  reconciled: boolean;
}

export interface NetworkNode {
  id: NetworkNodeId;
  name: string;
  status: "NOMINAL" | "OUTAGE" | "CONGESTED";
  latency: number; // in ms
  throughput: number; // tx/s
  failedTransactions: number;
}

export interface OfflineDeviceState {
  deviceId: string;
  walletId: string;
  balance: number;
  lastSyncTimestamp: string;
  isCompromised: boolean;
  pendingOfflineTransactions: {
    txId: string;
    amount: number;
    recipientId: string;
    timestamp: string;
  }[];
}

export interface ComplianceAlert {
  alert_id: string;
  timestamp: string;
  transaction_id: string;
  sender: string;
  receiver: string;
  amount: number;
  type: "RAPID_CHAIN" | "LARGE_VOLUME" | "STRUCTURING" | "CIRCULAR" | "MULE_BEHAVIOR";
  risk_score: number; // 0 to 100
  status: "PENDING" | "REVIEWED" | "DISMISSED";
  reason_codes: string[];
}

export interface DigitalBond {
  bond_id: string;
  issuer: string; // e.g., "Government of Canada"
  face_value: number;
  coupon: number; // as percentage
  maturity: string; // timestamp or date
  settlement_asset: "CAD-DIGITAL";
  owner: string; // participantId
}

export interface MacroVariables {
  gdp: number;
  cpi: number; // Inflation (percentage)
  interest_rate: number; // Policy interest rate (percentage)
  money_supply: number; // Total M2
  cbdc_supply: number; // CAD-DIGITAL total
  bank_deposits: number; // Commercial bank deposits total
  velocity: number; // velocity of CBDC
  consumption: number;
  investment: number;
  unemployment: number;
  exchange_rate: { [currency: string]: number }; // FX rates (CAD per unit)
}

export interface SimulationConfig {
  speed: "PAUSE" | "REALTIME" | "2X" | "5X" | "10X" | "STEP";
  currentTick: number;
  seed: number;
  cbdcAdoptionLevel: number; // scale from 0 to 1
  cbdcInterestRate: number; // CBDC remuneration rate
  limits: {
    individual: number;
    merchant: number;
    institution: number;
  };
  privacyConfig: PrivacyMode;
  tokenisationArch: TokenisationArchitecture;
  currentScenario: "BASELINE" | "HIGH_ADOPTION" | "BANKING_STRESS" | "PAYMENT_OUTAGE" | "CASH_DECLINE";
  activeOutages: {
    networkOutage: boolean;
    regionalOutageNode?: NetworkNodeId;
    centralServiceFailure: boolean;
    databaseReplicationFailure: boolean;
  };
}

export interface AuditEvent {
  event_id: string;
  timestamp: string;
  actor: string;
  action: string;
  object: string;
  previous_state: string;
  new_state: string;
  reason: string;
  correlation_id: string;
}

export interface ModelMetrics {
  name: string;
  version: string;
  trainingSamples: number;
  validationMetrics: { [key: string]: number };
  featureImportance: { feature: string; score: number }[];
  confidence: number;
}
