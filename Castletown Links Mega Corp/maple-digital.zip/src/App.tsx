/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  BookOpen,
  Building2,
  Cpu,
  Database,
  DollarSign,
  FileText,
  Globe,
  HardDrive,
  HelpCircle,
  History,
  Lock,
  MapPin,
  RefreshCw,
  Search,
  Send,
  Settings,
  Shield,
  ShieldAlert,
  Sliders,
  Terminal,
  TrendingUp,
  User,
  Users,
  Wifi,
  WifiOff
} from "lucide-react";

// French and English Terminologies
const LOCALE = {
  en: {
    appTitle: "MAPLE DIGITAL",
    appSubtitle: "CANADIAN DIGITAL DOLLAR MONETARY INFRASTRUCTURE SIMULATOR",
    twinTitle: "CENTRAL BANK CBDC DIGITAL TWIN",
    systemStatus: "SYSTEM STATUS",
    nominal: "NOMINAL",
    congested: "CONGESTED",
    outage: "OUTAGE",
    ledger: "LEDGER",
    synchronized: "SYNCHRONISED",
    network: "NETWORK",
    circulation: "CBDC IN CIRCULATION",
    activeWallets: "ACTIVE WALLETS",
    txVolume: "TRANSACTION VOLUME",
    settlementVal: "SETTLEMENT VALUE",
    avgLatency: "AVERAGE LATENCY",
    netUtil: "NETWORK UTILISATION",
    depositShift: "BANK DEPOSIT SHIFT",
    liquidity: "LIQUIDITY SUPPORT",
    systemRisk: "SYSTEM RISK",
    tickBtn: "TICK CLOCK",
    autoTick: "AUTO TICKING",
    language: "FRANÇAIS",
    terminalTitle: "RESEARCH INTERACTIVE TERMINAL CLI",
    promptPlaceholder: "Type command (e.g., 'maple status', 'ledger inspect')...",
    allSystemsNominal: "All national infrastructure pipelines are nominal.",
    simulationSpeed: "SIMULATION SPEED",
    scenarios: "SIMULATION SCENARIOS",
    controls: "POLICY PARAMETERS",
    wallet: "Wallet",
    portefeuille: "Portefeuille",
    settlement: "Settlement",
    reglement: "Règlement"
  },
  fr: {
    appTitle: "MAPLE DIGITAL",
    appSubtitle: "SIMULATEUR D'INFRASTRUCTURE MONÉTAIRE DU DOLLAR CANADIEN NUMÉRIQUE",
    twinTitle: "BANQUE CENTRALE — JUMEAU NUMÉRIQUE DE MNBC",
    systemStatus: "STATUT DU SYSTÈME",
    nominal: "NOMINAL",
    congested: "CONGESTIONNÉ",
    outage: "INTERRUPTION",
    ledger: "GRAND LIVRE",
    synchronized: "SYNCHRONISÉ",
    network: "RÉSEAU",
    circulation: "MNBC EN CIRCULATION",
    activeWallets: "PORTEFEUILLES ACTIFS",
    txVolume: "VOLUME DE TRANSACTIONS",
    settlementVal: "VALEUR DE RÈGLEMENT",
    avgLatency: "LATENCE MOYENNE",
    netUtil: "UTILISATION DU RÉSEAU",
    depositShift: "SHIFT DES DÉPÔTS BANCAIRES",
    liquidity: "SOUTIEN DE LIQUIDITÉ",
    systemRisk: "RISQUE DU SYSTÈME",
    tickBtn: "TICK HORLOGE",
    autoTick: "TICK AUTOMATIQUE",
    language: "ENGLISH",
    terminalTitle: "TERMINAL DE RECHERCHE INTERACTIF CLI",
    promptPlaceholder: "Saisissez une commande (ex: 'maple status', 'ledger inspect')...",
    allSystemsNominal: "Tous les pipelines nationaux d'infrastructure sont nominaux.",
    simulationSpeed: "VITESSE DE SIMULATION",
    scenarios: "SCÉNARIOS DE SIMULATION",
    controls: "PARAMÈTRES DE POLITIQUE",
    wallet: "Portefeuille",
    portefeuille: "Portefeuille",
    settlement: "Règlement",
    reglement: "Règlement"
  }
};

type Language = "en" | "fr";

export default function App() {
  const [lang, setLang] = useState<Language>("en");
  const [activeTab, setActiveTab] = useState<string>("cb-overview");
  const [state, setState] = useState<any>(null);
  const [cliInput, setCliInput] = useState<string>("");
  const [cliOutput, setCliOutput] = useState<string>(
    "MAPLE DIGITAL TWIN CLI\nType 'help' or 'maple status' to begin exploring monetary operations.\n========================================================"
  );
  const [isAutoTicking, setIsAutoTicking] = useState<boolean>(false);
  const [tickCounter, setTickCounter] = useState<number>(0);
  const cliEndRef = useRef<HTMLDivElement>(null);

  // Transfer Forms
  const [txSender, setTxSender] = useState<string>("");
  const [txReceiver, setTxReceiver] = useState<string>("");
  const [txAmount, setTxAmount] = useState<string>("");
  const [txError, setTxError] = useState<string | null>(null);
  const [txSuccess, setTxSuccess] = useState<string | null>(null);

  // Issuance Forms
  const [issAmount, setIssAmount] = useState<string>("");
  const [issBank, setIssBank] = useState<string>("CA-BANK-RBC");
  const [issReason, setIssReason] = useState<string>("");
  const [issSuccess, setIssSuccess] = useState<string | null>(null);

  // Bond DVP forms
  const [bondBuyer, setBondBuyer] = useState<string>("CA-BANK-RBC");
  const [bondId, setBondId] = useState<string>("BOND-CAN-2028-A");
  const [bondSuccess, setBondSuccess] = useState<string | null>(null);

  // Cross-border Remittance
  const [remitSender, setRemitSender] = useState<string>("WA-00000001");
  const [remitCurrency, setRemitCurrency] = useState<"USD" | "EUR" | "GBP" | "JPY">("USD");
  const [remitAmount, setRemitAmount] = useState<string>("");
  const [remitSuccess, setRemitSuccess] = useState<string | null>(null);

  // Offline Simulator transfers
  const [offlineAmount, setOfflineAmount] = useState<string>("50");
  const [offlineSuccess, setOfflineSuccess] = useState<string | null>(null);

  // Search Filters
  const [ledgerSearch, setLedgerSearch] = useState<string>("");

  const t = LOCALE[lang];

  // Fetch state on mount and intervals
  const fetchState = async () => {
    try {
      const res = await fetch("/api/state");
      const data = await res.json();
      setState(data);
      if (data.config?.speed !== "PAUSE") {
        setIsAutoTicking(true);
      } else {
        setIsAutoTicking(false);
      }
    } catch (err) {
      console.error("Error loading simulation state:", err);
    }
  };

  useEffect(() => {
    fetchState();
  }, [tickCounter]);

  // Handle auto-refresh in UI
  useEffect(() => {
    const timer = setInterval(() => {
      if (isAutoTicking) {
        setTickCounter(prev => prev + 1);
      } else {
        fetchState(); // Silent fetch to keep charts fresh
      }
    }, 2000);
    return () => clearInterval(timer);
  }, [isAutoTicking]);

  // Scroll terminal to bottom
  useEffect(() => {
    cliEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [cliOutput]);

  const handleManualTick = async () => {
    try {
      await fetch("/api/tick", { method: "POST" });
      setTickCounter(prev => prev + 1);
    } catch (err) {
      console.error("Error triggering tick:", err);
    }
  };

  const updateConfig = async (updatedFields: any) => {
    try {
      const res = await fetch("/api/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(updatedFields)
      });
      const data = await res.json();
      if (data.success) {
        fetchState();
      }
    } catch (err) {
      console.error("Error updating config:", err);
    }
  };

  const handleSpeedChange = (speed: string) => {
    updateConfig({ speed });
    setIsAutoTicking(speed !== "PAUSE");
  };

  const handleScenarioChange = (scenario: string) => {
    if (scenario === "BANKING_STRESS") {
      fetch("/api/scenarios/stress", { method: "POST" }).then(() => fetchState());
    } else if (scenario === "BASELINE") {
      fetch("/api/scenarios/restore", { method: "POST" }).then(() => fetchState());
    } else if (scenario === "PAYMENT_OUTAGE") {
      updateConfig({ activeOutages: { networkOutage: true } });
    } else {
      updateConfig({ currentScenario: scenario });
    }
  };

  const handleExecuteTransfer = async (e: React.FormEvent) => {
    e.preventDefault();
    setTxError(null);
    setTxSuccess(null);
    if (!txSender || !txReceiver || !txAmount) {
      setTxError("All fields are required.");
      return;
    }
    try {
      const res = await fetch("/api/transfer", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sender: txSender,
          receiver: txReceiver,
          amount: txAmount
        })
      });
      const data = await res.json();
      if (data.success) {
        setTxSuccess(`Transaction ${data.transaction.transaction_id} Settled Successfully! Reference: ${data.transaction.settlement_reference}`);
        setTxAmount("");
        fetchState();
      } else {
        setTxError(`Failed: ${data.transaction?.settlement_reference || "Invalid funds or limits exceeded."}`);
      }
    } catch (err) {
      setTxError("Server error processing transaction.");
    }
  };

  const handleIssueMoney = async (e: React.FormEvent) => {
    e.preventDefault();
    setIssSuccess(null);
    if (!issAmount) return;
    try {
      const res = await fetch("/api/issue", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          bankId: issBank,
          amount: issAmount,
          reason: issReason || "Administrative Research Expansion"
        })
      });
      const data = await res.json();
      if (data.success) {
        setIssSuccess(`CBDC Issued successfully to ${issBank}! Match Ref: ${data.transaction.settlement_reference}`);
        setIssAmount("");
        setIssReason("");
        fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleRedeemMoney = async (bankId: string, amount: number) => {
    try {
      const res = await fetch("/api/redeem", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bankId, amount })
      });
      const data = await res.json();
      if (data.success) {
        alert(`Successfully retired and contracted $${amount.toLocaleString()} CAD-DIGITAL from ${bankId}.`);
        fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleBondDVP = async (e: React.FormEvent) => {
    e.preventDefault();
    setBondSuccess(null);
    try {
      const res = await fetch("/api/bonds/purchase", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ participantId: bondBuyer, bondId })
      });
      const data = await res.json();
      if (data.success) {
        setBondSuccess(data.message);
        fetchState();
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleRemittance = async (e: React.FormEvent) => {
    e.preventDefault();
    setRemitSuccess(null);
    if (!remitAmount) return;
    try {
      const res = await fetch("/api/crossborder", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sourceWallet: remitSender, targetCurrency: remitCurrency, amount: remitAmount })
      });
      const data = await res.json();
      if (data.success) {
        setRemitSuccess(data.message);
        setRemitAmount("");
        fetchState();
      } else {
        alert(data.message);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleOfflinePayment = async (from: string, to: string) => {
    setOfflineSuccess(null);
    try {
      const res = await fetch("/api/offline/payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ fromWallet: from, toWallet: to, amount: offlineAmount })
      });
      const data = await res.json();
      if (data.success) {
        setOfflineSuccess(`Offline peer payment of $${offlineAmount} completed between devices without central network contact.`);
        fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleOfflineSync = async (deviceId: string) => {
    try {
      const res = await fetch("/api/offline/sync", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ deviceId })
      });
      const data = await res.json();
      if (data.success) {
        alert("Offline device synchronised cleanly! Balances committed to central ledger.");
        fetchState();
      } else {
        alert(`SYNC CONFLICT DETECTED: ${data.conflictDetails}`);
        fetchState();
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleCliSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cliInput.trim()) return;
    const command = cliInput;
    setCliInput("");

    setCliOutput(prev => prev + `\n\n> ${command}`);

    try {
      const res = await fetch("/api/cli", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ command })
      });
      const data = await res.json();
      setCliOutput(prev => prev + `\n${data.output}`);
    } catch (err) {
      setCliOutput(prev => prev + `\nError contacting server terminal processor.`);
    }
  };

  if (!state) {
    return (
      <div className="min-h-screen bg-slate-950 text-white flex flex-col items-center justify-center space-y-4">
        <RefreshCw className="h-10 w-10 text-rose-500 animate-spin" />
        <p className="text-sm font-mono text-slate-400">CONNECTING TO MAPLE CENTRAL BALANCE SHEET SERVICES...</p>
      </div>
    );
  }

  // Calculate some aggregate values for display
  const totalCirculation = state.macro?.cbdc_supply;
  const centralBankBuffer = state.wallets.find((w: any) => w.id === "WA-CENTRAL-BANK")?.balance || 0;
  const totalDeposits = state.macro?.bank_deposits;
  const averageLatency = state.network_nodes?.reduce((sum: number, n: any) => sum + n.latency, 0) / state.network_nodes?.length || 0;
  const numSuspicious = state.alerts?.filter((a: any) => a.status === "PENDING").length || 0;

  return (
    <div className="min-h-screen bg-[#fafaf9] text-slate-900 flex flex-col font-sans selection:bg-rose-100 antialiased">
      {/* Institutional Top Workstation Bar */}
      <header className="bg-slate-900 text-white px-6 py-4 flex flex-col lg:flex-row lg:items-center lg:justify-between border-b border-slate-800 space-y-4 lg:space-y-0" id="header">
        <div className="flex items-center space-x-3">
          <div className="bg-rose-600 text-white p-2 rounded flex items-center justify-center font-bold text-xl select-none" id="logo-badge">
            🍁
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-wider font-mono flex items-center" id="main-title">
              {t.appTitle}
              <span className="ml-2 text-xs bg-rose-500 text-white px-1.5 py-0.5 rounded font-sans tracking-normal font-medium">
                SBOX-TWIN
              </span>
            </h1>
            <p className="text-slate-400 text-[11px] uppercase tracking-widest font-mono" id="sub-title">
              {t.appSubtitle}
            </p>
          </div>
        </div>

        {/* Global Live Tickers */}
        <div className="flex flex-wrap items-center gap-6 text-xs font-mono" id="live-tickers">
          <div className="flex flex-col border-l border-slate-800 pl-3">
            <span className="text-slate-500 text-[10px] uppercase">MONETARY LIABILITY</span>
            <span className="text-emerald-400 font-bold font-mono">${(totalCirculation / 1e9).toFixed(3)}B CAD-D</span>
          </div>
          <div className="flex flex-col border-l border-slate-800 pl-3">
            <span className="text-slate-500 text-[10px] uppercase">CB LIQUIDITY BACKUP</span>
            <span className="text-slate-300 font-bold">${(centralBankBuffer / 1e9).toFixed(1)}B CAD</span>
          </div>
          <div className="flex flex-col border-l border-slate-800 pl-3">
            <span className="text-slate-500 text-[10px] uppercase">COMMERCIAL DEPOSITS</span>
            <span className="text-slate-300 font-bold">${(totalDeposits / 1e9).toFixed(1)}B CAD</span>
          </div>
          <div className="flex flex-col border-l border-slate-800 pl-3">
            <span className="text-slate-500 text-[10px] uppercase">LEDGER STATUS</span>
            <span className="text-emerald-400 font-bold flex items-center">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 mr-1.5 animate-pulse" />
              {t.synchronized}
            </span>
          </div>
          <div className="flex flex-col border-l border-slate-800 pl-3">
            <span className="text-slate-500 text-[10px] uppercase">SYSTEM RISK</span>
            <span className={`font-bold ${numSuspicious > 0 ? "text-amber-400" : "text-emerald-400"}`}>
              {numSuspicious > 0 ? `WARN (${numSuspicious})` : "NOMINAL"}
            </span>
          </div>
        </div>

        {/* Console Controls */}
        <div className="flex items-center space-x-3 self-end lg:self-auto" id="console-controls">
          <button
            onClick={() => setLang(lang === "en" ? "fr" : "en")}
            className="bg-slate-800 text-slate-300 border border-slate-700 px-2.5 py-1.5 rounded text-xs hover:bg-slate-700 transition font-mono uppercase"
            id="lang-toggle"
          >
            {t.language}
          </button>
          <button
            onClick={handleManualTick}
            className="bg-rose-600 text-white px-3 py-1.5 rounded text-xs font-mono font-bold hover:bg-rose-500 transition flex items-center space-x-1"
            id="tick-clock-btn"
          >
            <RefreshCw className="h-3 w-3" />
            <span>{t.tickBtn}</span>
          </button>
        </div>
      </header>

      {/* Main Container */}
      <div className="flex-1 flex flex-col lg:flex-row">
        
        {/* Modular Left Sidebar Navigation */}
        <aside className="w-full lg:w-72 bg-slate-950 text-slate-300 border-r border-slate-850 p-4 flex flex-col shrink-0 space-y-6" id="sidebar">
          {/* Simulation Speeds */}
          <div className="space-y-2">
            <h3 className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
              {t.simulationSpeed}
            </h3>
            <div className="grid grid-cols-5 gap-1 bg-slate-900 p-1 rounded border border-slate-800 text-xs text-center font-mono" id="speed-selector">
              {(["PAUSE", "REALTIME", "2X", "5X", "10X"] as const).map(speed => (
                <button
                  key={speed}
                  onClick={() => handleSpeedChange(speed)}
                  className={`py-1 rounded text-[10px] transition font-bold select-none cursor-pointer ${
                    state.config?.speed === speed
                      ? "bg-rose-600 text-white"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {speed === "REALTIME" ? "1X" : speed}
                </button>
              ))}
            </div>
          </div>

          {/* Core Modules Explorer */}
          <div className="space-y-1">
            <h3 className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono mb-2">
              MONETARY ENGINE
            </h3>
            
            {/* CENTRAL BANK SECTION */}
            <div className="space-y-1">
              <span className="text-[11px] font-semibold text-rose-400 font-mono pl-2 block">
                BANQUE CENTRALE
              </span>
              {[
                { id: "cb-overview", label: "Overview & Issuance", icon: Building2 },
                { id: "cb-supply", label: "CBDC Holdings & Limits", icon: Sliders },
                { id: "cb-ledger", label: "Central Double-Entry Ledger", icon: Database },
                { id: "cb-policy", label: "Monetary Policy Sandbox", icon: TrendingUp },
                { id: "cb-wholesale", label: "Wholesale & Debt Bond DVP", icon: Cpu },
                { id: "cb-crossborder", label: "Cross-Border FX Grid", icon: Globe }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full text-left px-3 py-1.5 rounded text-xs flex items-center space-x-2 transition ${
                    activeTab === item.id
                      ? "bg-slate-900 text-white font-medium border-l-2 border-rose-500"
                      : "hover:bg-slate-900 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <item.icon className="h-3.5 w-3.5" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>

            {/* NATIONAL NETWORK */}
            <div className="space-y-1 mt-4">
              <span className="text-[11px] font-semibold text-rose-400 font-mono pl-2 block">
                NATIONAL NETWORK
              </span>
              {[
                { id: "net-routing", label: "Payment Routing Node Map", icon: MapPin },
                { id: "net-stability", label: "Commercial Banks Ledger", icon: Activity }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full text-left px-3 py-1.5 rounded text-xs flex items-center space-x-2 transition ${
                    activeTab === item.id
                      ? "bg-slate-900 text-white font-medium border-l-2 border-rose-500"
                      : "hover:bg-slate-900 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <item.icon className="h-3.5 w-3.5" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>

            {/* END USERS */}
            <div className="space-y-1 mt-4">
              <span className="text-[11px] font-semibold text-rose-400 font-mono pl-2 block">
                END-USER SYSTEM
              </span>
              {[
                { id: "user-wallets", label: "Consumer Wallet Registry", icon: Users },
                { id: "user-offline", label: "Offline Payment Laboratory", icon: WifiOff },
                { id: "user-privacy", label: "Privacy Laboratory", icon: Lock }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full text-left px-3 py-1.5 rounded text-xs flex items-center space-x-2 transition ${
                    activeTab === item.id
                      ? "bg-slate-900 text-white font-medium border-l-2 border-rose-500"
                      : "hover:bg-slate-900 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <item.icon className="h-3.5 w-3.5" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>

            {/* SECURITY */}
            <div className="space-y-1 mt-4">
              <span className="text-[11px] font-semibold text-rose-400 font-mono pl-2 block">
                SECURITY & AUDITING
              </span>
              {[
                { id: "sec-aml", label: "AML / Crime compliance", icon: ShieldAlert },
                { id: "sec-cyber", label: "Cyber Security & Outages", icon: Shield },
                { id: "sec-audit", label: "Dossier Audits Explorer", icon: FileText }
              ].map(item => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full text-left px-3 py-1.5 rounded text-xs flex items-center space-x-2 transition ${
                    activeTab === item.id
                      ? "bg-slate-900 text-white font-medium border-l-2 border-rose-500"
                      : "hover:bg-slate-900 text-slate-400 hover:text-slate-200"
                  }`}
                >
                  <item.icon className="h-3.5 w-3.5" />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Quick Outage indicators */}
          <div className="bg-slate-900 border border-slate-800 p-2.5 rounded text-[11px] space-y-1.5 font-mono text-slate-400">
            <span className="font-bold text-slate-500 text-[9px] uppercase tracking-wider block">OUTAGE ALARM CHECK</span>
            <div className="flex items-center justify-between">
              <span>Central Core Ledger:</span>
              <span className={state.config?.activeOutages?.centralServiceFailure ? "text-rose-500 font-bold" : "text-emerald-500"}>
                {state.config?.activeOutages?.centralServiceFailure ? "OUTAGE" : "NOMINAL"}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span>National Network Status:</span>
              <span className={state.config?.activeOutages?.networkOutage ? "text-rose-500 font-bold" : "text-emerald-500"}>
                {state.config?.activeOutages?.networkOutage ? "PARTITION" : "ONLINE"}
              </span>
            </div>
          </div>
        </aside>

        {/* Center / Right Panels */}
        <main className="flex-1 p-6 overflow-y-auto space-y-6" id="main-content">
          {/* Quick Scenario Alert banner */}
          {state.config?.currentScenario !== "BASELINE" && (
            <div className="bg-amber-500/10 border border-amber-500/30 text-amber-800 p-3.5 rounded text-xs flex items-center justify-between font-mono">
              <span className="flex items-center">
                <AlertTriangle className="h-4 w-4 mr-2 text-amber-500" />
                ACTIVE SCENARIO EXPERIMENTATION: <b className="ml-1 uppercase">{state.config?.currentScenario}</b>
              </span>
              <button
                onClick={() => handleScenarioChange("BASELINE")}
                className="bg-amber-500 text-white px-2.5 py-1 rounded font-bold hover:bg-amber-600 transition"
              >
                RESTORE NOMINAL BASELINE
              </button>
            </div>
          )}

          {/* PRIMARY RENDER WINDOWS */}

          {/* TAB 1: CENTRAL BANK OVERVIEW & ISSUANCE */}
          {activeTab === "cb-overview" && (
            <div className="space-y-6" id="tab-cb-overview">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  {lang === "en" ? "CENTRAL BANK MONETARY COMMAND OVERVIEW" : "APERÇU DES COMMANDES DE LA BANQUE CENTRALE"}
                </h2>
                <p className="text-slate-500 text-xs tracking-tight">
                  {lang === "en" ? "Manage issuance requests, swap central bank reserves for digital-dollar liabilities, and review baseline statistics." : "Gérez les demandes d'émission, échangez les réserves bancaires contre du dollar numérique."}
                </p>
              </div>

              {/* Core Mechanics Stats */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white border border-slate-200 p-4 rounded shadow-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 text-[11px] font-mono uppercase tracking-wider">CIRCULATING MNBC</span>
                    <DollarSign className="h-4 w-4 text-rose-500" />
                  </div>
                  <h3 className="text-2xl font-bold font-mono text-slate-800 mt-1">
                    ${(totalCirculation / 1e9).toFixed(3)}B
                  </h3>
                  <p className="text-slate-400 text-[10px] mt-1 font-mono">Synthetic CB Liabilities</p>
                </div>

                <div className="bg-white border border-slate-200 p-4 rounded shadow-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 text-[11px] font-mono uppercase tracking-wider">RESERVES LIQUIDITY</span>
                    <Activity className="h-4 w-4 text-emerald-500" />
                  </div>
                  <h3 className="text-2xl font-bold font-mono text-emerald-600 mt-1">
                    $154.2B
                  </h3>
                  <p className="text-slate-400 text-[10px] mt-1 font-mono">National Reserves Pool</p>
                </div>

                <div className="bg-white border border-slate-200 p-4 rounded shadow-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 text-[11px] font-mono uppercase tracking-wider">VELOCITY OF MNBC</span>
                    <Activity className="h-4 w-4 text-blue-500" />
                  </div>
                  <h3 className="text-2xl font-bold font-mono text-slate-800 mt-1">
                    {state.macro?.velocity}
                  </h3>
                  <p className="text-slate-400 text-[10px] mt-1 font-mono">Annualized Turnovers</p>
                </div>

                <div className="bg-white border border-slate-200 p-4 rounded shadow-sm">
                  <div className="flex items-center justify-between">
                    <span className="text-slate-500 text-[11px] font-mono uppercase tracking-wider">SYSTEM ADOPTION</span>
                    <Users className="h-4 w-4 text-violet-500" />
                  </div>
                  <h3 className="text-2xl font-bold font-mono text-slate-800 mt-1">
                    {(state.config?.cbdcAdoptionLevel * 100).toFixed(0)}%
                  </h3>
                  <p className="text-slate-400 text-[10px] mt-1 font-mono">National Sample Panel</p>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Issuance expansion box */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4">
                  <div className="flex items-center space-x-2 border-b border-slate-100 pb-2">
                    <TrendingUp className="h-5 w-5 text-rose-500" />
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      CBDC ISSUANCE SWAP INJECTOR (MONEY CREATION)
                    </h3>
                  </div>
                  <p className="text-xs text-slate-500 leading-normal">
                    In a two-tier retail model, commercial banks purchase digital dollar assets by swapping their existing central-bank reserves. Enter expansion details to approve new synthetic digital-dollar assets.
                  </p>
                  
                  {issSuccess && (
                    <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-800 p-3 rounded text-xs font-mono">
                      {issSuccess}
                    </div>
                  )}

                  <form onSubmit={handleIssueMoney} className="space-y-3">
                    <div>
                      <label className="text-[10px] uppercase font-mono tracking-widest text-slate-500 block mb-1">
                        Select Target Bank
                      </label>
                      <select
                        value={issBank}
                        onChange={e => setIssBank(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded px-3 py-2 text-xs focus:ring-rose-500 focus:border-rose-500 font-mono"
                      >
                        {state.participants
                          .filter((p: any) => p.type === "COMMERCIAL_BANK")
                          .map((p: any) => (
                            <option key={p.id} value={p.id}>
                              {p.name} (Reserves: ${(p.assets?.reserves / 1e9).toFixed(2)}B)
                            </option>
                          ))}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] uppercase font-mono tracking-widest text-slate-500 block mb-1">
                          Amount (CAD)
                        </label>
                        <input
                          type="number"
                          value={issAmount}
                          onChange={e => setIssAmount(e.target.value)}
                          placeholder="e.g. 100000000"
                          className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded px-3 py-2 text-xs focus:ring-rose-500 focus:border-rose-500 font-mono"
                          required
                        />
                      </div>
                      <div>
                        <label className="text-[10px] uppercase font-mono tracking-widest text-slate-500 block mb-1">
                          Research Scenario Context
                        </label>
                        <input
                          type="text"
                          value={issReason}
                          onChange={e => setIssReason(e.target.value)}
                          placeholder="e.g. High Liquidity Stress Demo"
                          className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded px-3 py-2 text-xs focus:ring-rose-500 focus:border-rose-500"
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-slate-900 hover:bg-slate-850 text-white font-mono font-bold text-xs py-2 rounded transition shadow-sm"
                    >
                      EXECUTE CBDC ISSUANCE SWAP
                    </button>
                  </form>
                </div>

                {/* Retirement contraction box */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4">
                  <div className="flex items-center space-x-2 border-b border-slate-100 pb-2">
                    <Sliders className="h-5 w-5 text-slate-700" />
                    <h3 className="text-sm font-bold font-mono text-slate-800 font-bold">
                      ACTIVE SYSTEMIC OUTFLOW REDEMPTION
                    </h3>
                  </div>
                  <p className="text-xs text-slate-500 leading-normal">
                    Commercial participants can contract their CBDC treasury holding by redeeming them back to the Central Bank, recovering original core reserves. Trigger manual contractions here.
                  </p>

                  <div className="space-y-3 overflow-y-auto max-h-[220px]">
                    {state.participants
                      .filter((p: any) => p.type === "COMMERCIAL_BANK" && (state.wallets.find((w: any) => w.participantId === p.id)?.balance || 0) > 1e6)
                      .map((p: any) => {
                        const wallet = state.wallets.find((w: any) => w.participantId === p.id);
                        return (
                          <div key={p.id} className="border border-slate-100 p-3 rounded flex items-center justify-between text-xs font-mono bg-slate-50">
                            <div>
                              <span className="font-bold text-slate-800 block">{p.name}</span>
                              <span className="text-slate-500 text-[10px]">Circulating Holding: ${(wallet.balance / 1e6).toFixed(1)}M CAD-D</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <button
                                onClick={() => handleRedeemMoney(p.id, 50000000)}
                                className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 px-2 py-1 rounded text-[10px] font-bold"
                              >
                                Contract 50M
                              </button>
                              <button
                                onClick={() => handleRedeemMoney(p.id, 150000000)}
                                className="bg-rose-600 hover:bg-rose-500 text-white px-2 py-1 rounded text-[10px] font-bold"
                              >
                                Contract 150M
                              </button>
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: CBDC Holdings & limits */}
          {activeTab === "cb-supply" && (
            <div className="space-y-6" id="tab-cb-supply">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  NATIONAL REGULATORY PARAMETERS & LIMITS
                </h2>
                <p className="text-slate-500 text-xs">
                  Configure maximum balance thresholds, holding constraints, and retail CBDC interest remunerations to observe stability trade-offs.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Slider configurations */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-6">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      SYSTEMIC POLICY LIMIT SLIDERS
                    </h3>
                  </div>

                  {/* Individual limit */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-mono">
                      <span className="font-bold text-slate-700">INDIVIDUAL RETAIL HOLDING LIMIT</span>
                      <span className="text-rose-600 font-bold">${state.config?.limits?.individual?.toLocaleString()} CAD</span>
                    </div>
                    <p className="text-[11px] text-slate-400">Controls maximum CBDC balance an unverified/basic consumer device can hold.</p>
                    <input
                      type="range"
                      min="1000"
                      max="20000"
                      step="500"
                      value={state.config?.limits?.individual || 5000}
                      onChange={e => updateConfig({ limits: { individual: Number(e.target.value) } })}
                      className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-rose-600"
                    />
                  </div>

                  {/* Merchant limit */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-mono">
                      <span className="font-bold text-slate-700">MERCHANT BUSINESS LIMIT</span>
                      <span className="text-rose-600 font-bold">${state.config?.limits?.merchant?.toLocaleString()} CAD</span>
                    </div>
                    <p className="text-[11px] text-slate-400">Limits normal business terminal buffers for automatic sweeps.</p>
                    <input
                      type="range"
                      min="10000"
                      max="500000"
                      step="10000"
                      value={state.config?.limits?.merchant || 100000}
                      onChange={e => updateConfig({ limits: { merchant: Number(e.target.value) } })}
                      className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-rose-600"
                    />
                  </div>

                  {/* CBDC Interest rate */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-mono">
                      <span className="font-bold text-slate-700">CBDC INTEREST REMUNERATION RATE</span>
                      <span className="text-rose-600 font-bold">{(state.config?.cbdcInterestRate || 0).toFixed(2)}%</span>
                    </div>
                    <p className="text-[11px] text-slate-400">Remunerating risk-free retail deposits can drive bank disintermediation.</p>
                    <input
                      type="range"
                      min="0"
                      max="5"
                      step="0.25"
                      value={state.config?.cbdcInterestRate || 0}
                      onChange={e => updateConfig({ cbdcInterestRate: Number(e.target.value) })}
                      className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-rose-600"
                    />
                  </div>

                  {/* Adoption level slider */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-mono">
                      <span className="font-bold text-slate-700">SYNTHETIC ADOPTION LEVEL</span>
                      <span className="text-rose-600 font-bold">{(state.config?.cbdcAdoptionLevel * 100).toFixed(0)}%</span>
                    </div>
                    <p className="text-[11px] text-slate-400">Drives transaction rates and substitution scales dynamically.</p>
                    <input
                      type="range"
                      min="0.05"
                      max="0.95"
                      step="0.05"
                      value={state.config?.cbdcAdoptionLevel || 0.15}
                      onChange={e => updateConfig({ cbdcAdoptionLevel: Number(e.target.value) })}
                      className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-rose-600"
                    />
                  </div>
                </div>

                {/* Economic forecasts based on slider inputs */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      REAL-TIME REGULATORY FORECAST (ML MODEL INDEX)
                    </h3>
                  </div>
                  <p className="text-xs text-slate-500">
                    Calculated transmission forecasts on bank deposit disintermediation and credit supplies based on Ridge Regression estimators:
                  </p>

                  <div className="space-y-3 font-mono text-xs">
                    <div className="border border-slate-100 p-3 rounded bg-slate-50">
                      <div className="flex justify-between font-bold text-slate-800 mb-1">
                        <span>Projected Bank Deposits:</span>
                        <span className="text-rose-600">${(state.macro?.bank_deposits / 1e12).toFixed(2)}T CAD</span>
                      </div>
                      <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-rose-500"
                          style={{ width: `${(state.macro?.bank_deposits / 1.85e12) * 100}%` }}
                        />
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-1">Substitution Ratio: {((1 - (state.macro?.bank_deposits / 1.85e12)) * 100).toFixed(1)}% Outflow Drains</span>
                    </div>

                    <div className="border border-slate-100 p-3 rounded bg-slate-50">
                      <div className="flex justify-between font-bold text-slate-800 mb-1">
                        <span>Lending &amp; Investment Flow:</span>
                        <span className="text-rose-600">${(state.macro?.investment / 1e9).toFixed(1)}B CAD</span>
                      </div>
                      <div className="h-2 bg-slate-200 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-amber-500"
                          style={{ width: `${(state.macro?.investment / 4.5e11) * 100}%` }}
                        />
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-1">Credit Multiplier Shrinkage: {((1 - (state.macro?.investment / 4.5e11)) * 100).toFixed(1)}% Squeeze</span>
                    </div>

                    <div className="border border-slate-100 p-3 rounded bg-slate-50">
                      <div className="flex justify-between font-bold text-slate-800">
                        <span>Confidence Bounds:</span>
                        <span className="text-slate-600">{state.mlModels?.adoption_forecast?.confidence}% Model Confidence</span>
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-1">Estimator Model: {state.mlModels?.adoption_forecast?.name}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: CENTRAL DOUBLE ENTRY LEDGER */}
          {activeTab === "cb-ledger" && (
            <div className="space-y-6" id="tab-cb-ledger">
              <div className="border-b border-slate-200 pb-3 flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold font-mono text-slate-800">
                    CENTRAL DOUBLE-ENTRY AUDIT GRAND LIVRE
                  </h2>
                  <p className="text-slate-500 text-xs">
                    Immutable database record of double-entry monetary postings. No adjustments can be executed without offsets.
                  </p>
                </div>
                {/* Search Bar */}
                <div className="relative">
                  <input
                    type="text"
                    value={ledgerSearch}
                    onChange={e => setLedgerSearch(e.target.value)}
                    placeholder="Search accounts or Tx ID..."
                    className="bg-white border border-slate-200 text-xs rounded pl-8 pr-3 py-1.5 focus:ring-rose-500 focus:border-rose-500 font-mono w-60"
                  />
                  <Search className="h-3.5 w-3.5 text-slate-400 absolute left-2.5 top-2" />
                </div>
              </div>

              {/* Ledger Table */}
              <div className="bg-white border border-slate-200 rounded shadow-sm overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs font-mono">
                  <thead>
                    <tr className="bg-slate-100 text-slate-600 border-b border-slate-200 text-[10px] uppercase">
                      <th className="p-3">ENTRY ID</th>
                      <th className="p-3">TIMESTAMP</th>
                      <th className="p-3 text-red-600">DEBIT ACCOUNT (DR)</th>
                      <th className="p-3 text-emerald-600">CREDIT ACCOUNT (CR)</th>
                      <th className="p-3 text-right">AMOUNT (CAD)</th>
                      <th className="p-3 text-center">INTEGRITY CHECK</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {state.ledger_entries
                      ?.filter((e: any) => 
                        !ledgerSearch || 
                        e.account_debit.toLowerCase().includes(ledgerSearch.toLowerCase()) ||
                        e.account_credit.toLowerCase().includes(ledgerSearch.toLowerCase()) ||
                        e.transaction_id.toLowerCase().includes(ledgerSearch.toLowerCase())
                      )
                      .reverse()
                      .map((entry: any) => (
                        <tr key={entry.entry_id} className="hover:bg-slate-50 text-slate-700">
                          <td className="p-3 text-slate-400 font-semibold">{entry.entry_id}</td>
                          <td className="p-3 text-slate-500">{entry.timestamp.substring(11, 19)}</td>
                          <td className="p-3 text-red-600 font-semibold">{entry.account_debit}</td>
                          <td className="p-3 text-emerald-600 font-semibold">{entry.account_credit}</td>
                          <td className="p-3 text-right font-bold font-mono">${entry.amount.toLocaleString()}</td>
                          <td className="p-3 text-center">
                            <span className="bg-emerald-50 text-emerald-700 border border-emerald-100 px-1.5 py-0.5 rounded text-[10px] font-bold">
                              RECONCILED
                            </span>
                          </td>
                        </tr>
                      ))}
                    {state.ledger_entries?.length === 0 && (
                      <tr>
                        <td colSpan={6} className="p-6 text-center text-slate-400 italic">No ledger postings found.</td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 4: MONETARY POLICY SANDBOX */}
          {activeTab === "cb-policy" && (
            <div className="space-y-6" id="tab-cb-policy">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  MONETARY POLICY EXPERIMENTATION SANDBOX
                </h2>
                <p className="text-slate-500 text-xs">
                  Adjust simulated Bank of Canada policy targets and analyze simulated transmission channels to macroeconomic outputs.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Sliders */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-6">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      CENTRAL TARGET CONTROLS
                    </h3>
                  </div>

                  {/* Policy Interest rate */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-mono">
                      <span className="font-bold text-slate-700">BoC TARGET POLICY INTEREST RATE</span>
                      <span className="text-rose-600 font-bold">{(state.macro?.interest_rate || 0).toFixed(2)}%</span>
                    </div>
                    <input
                      type="range"
                      min="1"
                      max="8"
                      step="0.25"
                      value={state.macro?.interest_rate || 4.25}
                      onChange={e => {
                        const rate = Number(e.target.value);
                        // Modify macroeconomic state directly via mock variables
                        setState((prev: any) => ({
                          ...prev,
                          macro: {
                            ...prev.macro,
                            interest_rate: rate,
                            // High rates contract GDP and inflation slightly, increase unemployment
                            gdp: prev.macro.gdp * (1 - (rate - 4.25) * 0.005),
                            cpi: Math.max(0.5, prev.macro.cpi - (rate - 4.25) * 0.2),
                            unemployment: Math.min(10, prev.macro.unemployment + (rate - 4.25) * 0.1)
                          }
                        }));
                      }}
                      className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-rose-600"
                    />
                  </div>

                  {/* Inflation target */}
                  <div className="space-y-2">
                    <div className="flex justify-between items-center text-xs font-mono">
                      <span className="font-bold text-slate-700">SIMULATED INFLATION TARGET RATE (CPI)</span>
                      <span className="text-rose-600 font-bold">{(state.macro?.cpi || 0).toFixed(1)}%</span>
                    </div>
                    <input
                      type="range"
                      min="0.5"
                      max="6"
                      step="0.1"
                      value={state.macro?.cpi || 2.1}
                      onChange={e => {
                        const val = Number(e.target.value);
                        setState((prev: any) => ({
                          ...prev,
                          macro: { ...prev.macro, cpi: val }
                        }));
                      }}
                      className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-rose-600"
                    />
                  </div>
                </div>

                {/* Economic outcomes summary */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      MACROECONOMIC TRANSMISSION INDICATORS
                    </h3>
                  </div>

                  <div className="grid grid-cols-2 gap-4 font-mono text-xs">
                    <div className="border border-slate-100 p-3 rounded bg-slate-50">
                      <span className="text-slate-400 text-[10px] block">GROSS DOMESTIC PRODUCT (GDP)</span>
                      <span className="text-slate-800 font-bold text-sm">${(state.macro?.gdp / 1e12).toFixed(3)}T CAD</span>
                    </div>

                    <div className="border border-slate-100 p-3 rounded bg-slate-50">
                      <span className="text-slate-400 text-[10px] block">UNEMPLOYMENT RATE</span>
                      <span className="text-slate-800 font-bold text-sm">{state.macro?.unemployment}%</span>
                    </div>

                    <div className="border border-slate-100 p-3 rounded bg-slate-50">
                      <span className="text-slate-400 text-[10px] block">M2 MONEY SUPPLY</span>
                      <span className="text-slate-800 font-bold text-sm">${(state.macro?.money_supply / 1e12).toFixed(2)}T CAD</span>
                    </div>

                    <div className="border border-slate-100 p-3 rounded bg-slate-50">
                      <span className="text-slate-400 text-[10px] block">CBDC SUPPLY VELOCITY</span>
                      <span className="text-slate-800 font-bold text-sm">{state.macro?.velocity}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 5: WHOLESALE CBDC & GOVERNMENT SECURITIES DVP */}
          {activeTab === "cb-wholesale" && (
            <div className="space-y-6" id="tab-cb-wholesale">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  WHOLESALE CENTRAL-BANK SYSTEM & SECURITIES DVP
                </h2>
                <p className="text-slate-500 text-xs">
                  Simulate institutional securities purchase matching (Delivery-versus-Payment) where treasury bonds are atomic-swapped instantly for Wholesale CBDC balances.
                </p>
              </div>

              {bondSuccess && (
                <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-800 p-3.5 rounded text-xs font-mono">
                  {bondSuccess}
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Active Securities Board */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      EXPERIMENTATION DIGITAL SECURITIES REGISTRY
                    </h3>
                  </div>

                  <div className="space-y-3 font-mono text-xs">
                    {state.bonds?.map((b: any) => {
                      const ownerName = state.participants.find((p: any) => p.id === b.owner)?.name || b.owner;
                      return (
                        <div key={b.bond_id} className="border border-slate-150 p-3 rounded bg-slate-50 space-y-1.5">
                          <div className="flex justify-between font-bold text-slate-800">
                            <span>{b.bond_id}</span>
                            <span className="text-rose-600">${(b.face_value / 1e6).toFixed(1)}M CAD</span>
                          </div>
                          <div className="grid grid-cols-3 text-[10px] text-slate-500">
                            <div>Coupon: {b.coupon}%</div>
                            <div>Maturity: {b.maturity}</div>
                            <div className="text-right text-slate-700 font-bold truncate">Owner: {ownerName}</div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* DVP Execution box */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      EXECUTE ATOMIC DELIVERY-VS-PAYMENT (DVP)
                    </h3>
                  </div>

                  <form onSubmit={handleBondDVP} className="space-y-3 text-xs">
                    <div>
                      <label className="text-[10px] uppercase font-mono tracking-widest text-slate-500 block mb-1">
                        Selecting Purchasing Intermediary
                      </label>
                      <select
                        value={bondBuyer}
                        onChange={e => setBondBuyer(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded px-3 py-2 font-mono"
                      >
                        {state.participants
                          .filter((p: any) => p.type === "COMMERCIAL_BANK" || p.type === "PAYMENT_PROVIDER")
                          .map((p: any) => (
                            <option key={p.id} value={p.id}>
                              {p.name} (CBDC: ${(state.wallets.find((w: any) => w.participantId === p.id)?.balance / 1e6).toFixed(1)}M)
                            </option>
                          ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-[10px] uppercase font-mono tracking-widest text-slate-500 block mb-1">
                        Select Target Debt Bond (Securities asset)
                      </label>
                      <select
                        value={bondId}
                        onChange={e => setBondId(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded px-3 py-2 font-mono"
                      >
                        {state.bonds?.map((b: any) => (
                          <option key={b.bond_id} value={b.bond_id}>
                            {b.bond_id} (Face: ${(b.face_value / 1e6).toFixed(1)}M, Coupon: {b.coupon}%)
                          </option>
                        ))}
                      </select>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-slate-900 hover:bg-slate-850 text-white font-mono font-bold py-2 rounded transition shadow-sm"
                    >
                      CLEAR ATOMIC LIQUIDITY DVP BOND SWAP
                    </button>
                  </form>
                </div>
              </div>
            </div>
          )}

          {/* TAB 6: CROSS-BORDER FX GRID */}
          {activeTab === "cb-crossborder" && (
            <div className="space-y-6" id="tab-cb-crossborder">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  CROSS-BORDER INSTANT REMITTANCE FX GRID
                </h2>
                <p className="text-slate-500 text-xs">
                  Remit retail CBDC across borders by clearing trades against foreign corresponding accounts using real-time synthetic exchange conversions.
                </p>
              </div>

              {remitSuccess && (
                <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-800 p-3.5 rounded text-xs font-mono">
                  {remitSuccess}
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Remit Grid Form */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      CROSS-BORDER INSTANT REMIT
                    </h3>
                  </div>

                  <form onSubmit={handleRemittance} className="space-y-3 text-xs">
                    <div>
                      <label className="text-[10px] uppercase font-mono tracking-widest text-slate-500 block mb-1">
                        Select Sender Wallet (Source)
                      </label>
                      <select
                        value={remitSender}
                        onChange={e => setRemitSender(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded px-3 py-2 font-mono"
                      >
                        {state.wallets
                          .filter((w: any) => w.type === "CONSUMER" && w.balance > 0)
                          .map((w: any) => {
                            const name = state.participants.find((p: any) => p.associatedWalletId === w.id)?.name || w.id;
                            return (
                              <option key={w.id} value={w.id}>
                                {name} (Avail: ${w.balance.toLocaleString()} CAD-D)
                              </option>
                            );
                          })}
                      </select>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] uppercase font-mono tracking-widest text-slate-500 block mb-1">
                          Target Remit Asset
                        </label>
                        <select
                          value={remitCurrency}
                          onChange={e => setRemitCurrency(e.target.value as any)}
                          className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded px-3 py-2 font-mono"
                        >
                          <option value="USD">USD (Rate: {state.macro?.exchange_rate?.USD})</option>
                          <option value="EUR">EUR (Rate: {state.macro?.exchange_rate?.EUR})</option>
                          <option value="GBP">GBP (Rate: {state.macro?.exchange_rate?.GBP})</option>
                          <option value="JPY">JPY (Rate: {state.macro?.exchange_rate?.JPY})</option>
                        </select>
                      </div>
                      <div>
                        <label className="text-[10px] uppercase font-mono tracking-widest text-slate-500 block mb-1">
                          Amount (CAD)
                        </label>
                        <input
                          type="number"
                          value={remitAmount}
                          onChange={e => setRemitAmount(e.target.value)}
                          placeholder="e.g. 250"
                          className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded px-3 py-2 font-mono"
                          required
                        />
                      </div>
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-slate-900 hover:bg-slate-850 text-white font-mono font-bold py-2 rounded transition shadow-sm"
                    >
                      DISPATCH INSTANT FOREIGN REMITTANCE
                    </button>
                  </form>
                </div>

                {/* Live Forex conversions board */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      LIVE CORRESPONDENT FOREX LIQUIDITY
                    </h3>
                  </div>

                  <div className="grid grid-cols-2 gap-3 font-mono text-xs">
                    <div className="border border-slate-100 p-3 rounded bg-slate-50">
                      <span className="text-slate-400 text-[10px]">USD OUTFLOWS</span>
                      <span className="text-slate-800 font-bold block text-sm">$45.2M USD</span>
                    </div>
                    <div className="border border-slate-100 p-3 rounded bg-slate-50">
                      <span className="text-slate-400 text-[10px]">EUR OUTFLOWS</span>
                      <span className="text-slate-800 font-bold block text-sm">€28.1M EUR</span>
                    </div>
                    <div className="border border-slate-100 p-3 rounded bg-slate-50">
                      <span className="text-slate-400 text-[10px]">GBP OUTFLOWS</span>
                      <span className="text-slate-800 font-bold block text-sm">£14.2M GBP</span>
                    </div>
                    <div className="border border-slate-100 p-3 rounded bg-slate-50">
                      <span className="text-slate-400 text-[10px]">JPY OUTFLOWS</span>
                      <span className="text-slate-800 font-bold block text-sm">¥4.2B JPY</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 7: REGIONAL MAP & PAYMENT ROUTING */}
          {activeTab === "net-routing" && (
            <div className="space-y-6" id="tab-net-routing">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  NATIONAL ROUTING TELEMETRY & NODE GRAPH
                </h2>
                <p className="text-slate-500 text-xs">
                  Observe animated transaction volumes routing across Canada. System latency is computed mathematically based on active outages and congestions.
                </p>
              </div>

              {/* Regional Node health */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono text-xs">
                {state.network_nodes?.map((n: any) => (
                  <div key={n.id} className="border border-slate-200 bg-white p-3.5 rounded shadow-sm space-y-1">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-slate-800 truncate">{n.id}</span>
                      <span className={`h-2 w-2 rounded-full ${n.status === "OUTAGE" ? "bg-red-500 animate-ping" : n.status === "CONGESTED" ? "bg-amber-500 animate-pulse" : "bg-emerald-500"}`} />
                    </div>
                    <div className="text-[10px] text-slate-400">{n.name}</div>
                    <div className="flex justify-between text-[11px] mt-2 border-t border-slate-100 pt-1 text-slate-500">
                      <span>Latency: {n.latency}ms</span>
                      <span>Cap: {n.throughput}tx/s</span>
                    </div>
                  </div>
                ))}
              </div>

              {/* National Money Flow Diagram */}
              <div className="bg-slate-900 border border-slate-850 p-5 rounded relative overflow-hidden" style={{ minHeight: "360px" }} id="routing-map">
                <div className="absolute top-4 left-4 font-mono text-xs text-slate-400">
                  <span className="text-slate-500 uppercase font-bold block">NATIONAL CONGESTION SCENARIO</span>
                  <span>Average Latency: {averageLatency.toFixed(1)}ms</span>
                </div>

                {/* Canada Custom Art Map */}
                <svg viewBox="0 0 800 400" className="w-full h-full text-slate-700 opacity-80 font-sans">
                  {/* Grid Lines */}
                  <path d="M 0,100 L 800,100 M 0,200 L 800,200 M 0,300 L 800,300 M 100,0 L 100,400 M 200,0 L 200,400 M 300,0 L 300,400 M 400,0 L 400,400 M 500,0 L 500,400 M 600,0 L 600,400 M 700,0 L 700,400" stroke="#1e293b" strokeWidth="0.5" strokeDasharray="3,3" />

                  {/* Draw Regional Node links */}
                  <g stroke="#334155" strokeWidth="1.5">
                    {/* Vancouver to Edmonton & Calgary */}
                    <line x1="150" y1="260" x2="220" y2="180" />
                    <line x1="150" y1="260" x2="250" y2="240" />
                    {/* Calgary / Edmonton to Winnipeg */}
                    <line x1="250" y1="240" x2="380" y2="260" />
                    <line x1="220" y1="180" x2="380" y2="260" />
                    {/* Winnipeg to Toronto */}
                    <line x1="380" y1="260" x2="520" y2="300" />
                    {/* Toronto to Montreal & Ottawa */}
                    <line x1="520" y1="300" x2="550" y2="260" />
                    <line x1="520" y1="300" x2="580" y2="220" />
                    <line x1="550" y1="260" x2="580" y2="220" />
                    {/* Montreal/Ottawa to Halifax */}
                    <line x1="580" y1="220" x2="710" y2="240" />
                  </g>

                  {/* Nodes Circles with Labels */}
                  {[
                    { x: 150, y: 260, id: "VANCOUVER" },
                    { x: 220, y: 180, id: "EDMONTON" },
                    { x: 250, y: 240, id: "CALGARY" },
                    { x: 380, y: 260, id: "WINNIPEG" },
                    { x: 520, y: 300, id: "TORONTO" },
                    { x: 550, y: 260, id: "OTTAWA", isHQ: true },
                    { x: 580, y: 220, id: "MONTREAL" },
                    { x: 710, y: 240, id: "HALIFAX" }
                  ].map(node => {
                    const nodeState = state.network_nodes?.find((n: any) => n.id === node.id);
                    const color = nodeState?.status === "OUTAGE" ? "#f43f5e" : nodeState?.status === "CONGESTED" ? "#f59e0b" : "#10b981";
                    return (
                      <g key={node.id}>
                        <circle cx={node.x} cy={node.y} r={node.isHQ ? 9 : 6} fill={color} className={nodeState?.status === "OUTAGE" ? "" : "animate-pulse"} />
                        <text x={node.x} y={node.y - 12} fill="#94a3b8" fontSize="10" fontFamily="monospace" textAnchor="middle" fontWeight="bold">
                          {node.id}
                        </text>
                        {node.isHQ && (
                          <circle cx={node.x} cy={node.y} r={14} stroke="#f43f5e" strokeWidth="1" fill="none" className="animate-ping" style={{ animationDuration: "3s" }} />
                        )}
                      </g>
                    );
                  })}

                  {/* Draw simulated transaction pulse lines */}
                  {state.config?.speed !== "PAUSE" && (
                    <g>
                      <circle cx="220" cy="180" r="3" fill="#f43f5e">
                        <animate attributeName="cx" from="220" to="380" dur="2s" repeatCount="indefinite" />
                        <animate attributeName="cy" from="180" to="260" dur="2s" repeatCount="indefinite" />
                      </circle>
                      <circle cx="380" cy="260" r="3" fill="#10b981">
                        <animate attributeName="cx" from="380" to="520" dur="1.5s" repeatCount="indefinite" />
                        <animate attributeName="cy" from="260" to="300" dur="1.5s" repeatCount="indefinite" />
                      </circle>
                      <circle cx="520" cy="300" r="3" fill="#38bdf8">
                        <animate attributeName="cx" from="520" to="550" dur="1s" repeatCount="indefinite" />
                        <animate attributeName="cy" from="300" to="260" dur="1s" repeatCount="indefinite" />
                      </circle>
                    </g>
                  )}
                </svg>
              </div>
            </div>
          )}

          {/* TAB 8: COMMERCIAL BANKS LEDGER (BANKING STABILITY) */}
          {activeTab === "net-stability" && (
            <div className="space-y-6" id="tab-net-stability">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  COMMERCIAL FINANCIAL RESERVES & BALANCE SHEETS
                </h2>
                <p className="text-slate-500 text-xs">
                  Inspect synthetic balance sheets of the 12 commercial participants. High customer CBDC demand drains bank reserves, prompting BoC emergency liquidity injections.
                </p>
              </div>

              {/* Banks List grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {state.participants
                  ?.filter((p: any) => p.type === "COMMERCIAL_BANK")
                  .map((p: any) => {
                    const wallet = state.wallets.find((w: any) => w.participantId === p.id);
                    const deposits = p.liabilities?.deposits || 0;
                    const reserves = p.assets?.reserves || 0;
                    const support = p.liabilities?.liquiditySupport || 0;
                    const cbdcOutflows = p.liabilities?.cbdcOutflows || 0;
                    const capital = p.liabilities?.capital || 0;

                    const reservesRatio = deposits > 0 ? (reserves / deposits) * 100 : 0;

                    return (
                      <div key={p.id} className="bg-white border border-slate-200 rounded p-4 shadow-sm space-y-3 font-mono text-xs">
                        <div className="flex justify-between items-start border-b border-slate-100 pb-2">
                          <div>
                            <h3 className="font-bold text-slate-800 truncate">{p.name}</h3>
                            <span className="text-[10px] text-slate-400 uppercase tracking-widest">{p.node} Node</span>
                          </div>
                          <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${reservesRatio < 4 ? "bg-red-50 text-red-700 border border-red-100" : "bg-emerald-50 text-emerald-700"}`}>
                            RES RATIO: {reservesRatio.toFixed(1)}%
                          </span>
                        </div>

                        <div className="space-y-1 text-slate-600">
                          <div className="flex justify-between">
                            <span>Deposits (M2-D):</span>
                            <span className="text-slate-800 font-bold">${(deposits / 1e9).toFixed(1)}B CAD</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Reserves Pool:</span>
                            <span className="text-emerald-600 font-bold">${(reserves / 1e9).toFixed(1)}B CAD</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Customer Retail CBDC Outflow:</span>
                            <span className="text-rose-600 font-bold">${(cbdcOutflows / 1e6).toFixed(1)}M CAD-D</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Treasury capital asset:</span>
                            <span className="text-slate-800 font-bold">${(capital / 1e9).toFixed(1)}B CAD</span>
                          </div>
                          <div className="flex justify-between border-t border-slate-100 pt-1 text-slate-500">
                            <span>CB Emergency Lending:</span>
                            <span className={`font-bold ${support > 0 ? "text-rose-600 font-bold" : "text-slate-400"}`}>
                              {support > 0 ? `$${(support / 1e6).toFixed(1)}M CAD` : "ZERO (NOMINAL)"}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </div>
          )}

          {/* TAB 9: CONSUMER WALLET REGISTRY */}
          {activeTab === "user-wallets" && (
            <div className="space-y-6" id="tab-user-wallets">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  CONSUMER WALLET REGISTRY & SIMULATOR
                </h2>
                <p className="text-slate-500 text-xs">
                  Inspect unverified, basic, and verified consumer research panel wallets. Trigger instant retail transfers using the form.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Transfer Form */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4 h-fit">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      TRIGGER MANUAL RETAIL TRANSACTION
                    </h3>
                  </div>

                  {txError && (
                    <div className="bg-rose-500/10 border border-rose-500/20 text-rose-800 p-3 rounded text-xs font-mono">
                      {txError}
                    </div>
                  )}
                  {txSuccess && (
                    <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-800 p-3 rounded text-xs font-mono break-all">
                      {txSuccess}
                    </div>
                  )}

                  <form onSubmit={handleExecuteTransfer} className="space-y-3 text-xs">
                    <div>
                      <label className="text-[10px] uppercase font-mono tracking-widest text-slate-500 block mb-1">
                        Sender Wallet ID
                      </label>
                      <input
                        type="text"
                        value={txSender}
                        onChange={e => setTxSender(e.target.value)}
                        placeholder="e.g. WA-00000001 (or WA-BANK-RBC)"
                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded px-3 py-2 font-mono"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[10px] uppercase font-mono tracking-widest text-slate-500 block mb-1">
                        Receiver Wallet ID
                      </label>
                      <input
                        type="text"
                        value={txReceiver}
                        onChange={e => setTxReceiver(e.target.value)}
                        placeholder="e.g. WA-MER-TIMS"
                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded px-3 py-2 font-mono"
                        required
                      />
                    </div>

                    <div>
                      <label className="text-[10px] uppercase font-mono tracking-widest text-slate-500 block mb-1">
                        Transaction value (CAD)
                      </label>
                      <input
                        type="number"
                        value={txAmount}
                        onChange={e => setTxAmount(e.target.value)}
                        placeholder="e.g. 42.50"
                        className="w-full bg-slate-50 border border-slate-200 text-slate-800 rounded px-3 py-2 font-mono"
                        required
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full bg-slate-900 hover:bg-slate-850 text-white font-mono font-bold py-2 rounded transition shadow-sm"
                    >
                      SUBMIT MONETARY TRANSFER
                    </button>
                  </form>
                </div>

                {/* Wallets registry board */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4 lg:col-span-2">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      ACTIVE USER PANEL SAMPLING
                    </h3>
                  </div>

                  <div className="space-y-3 max-h-[350px] overflow-y-auto">
                    {state.wallets
                      ?.filter((w: any) => w.type === "CONSUMER" || w.type === "MERCHANT")
                      .map((w: any) => {
                        const name = state.participants.find((p: any) => p.associatedWalletId === w.id || p.id === w.participantId)?.name || w.id;
                        return (
                          <div key={w.id} className="border border-slate-150 p-3 rounded bg-slate-50 flex justify-between items-center text-xs font-mono">
                            <div>
                              <span className="font-bold text-slate-800 block">{name} ({w.id})</span>
                              <span className="text-slate-400 text-[10px]">KYC Tier: {w.identityStatus} | Daily Volume: ${w.dailyVolume.toFixed(2)}</span>
                            </div>
                            <div className="text-right space-y-1">
                              <span className="text-slate-700 font-bold block">Online: ${w.balance.toLocaleString()} CAD</span>
                              {w.offlineBalance > 0 && (
                                <span className="text-slate-500 text-[10px] block">Offline: ${w.offlineBalance} CAD</span>
                              )}
                            </div>
                          </div>
                        );
                      })}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 10: OFFLINE PAYMENT LABORATORY */}
          {activeTab === "user-offline" && (
            <div className="space-y-6" id="tab-user-offline">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  OFFLINE CRYPTOGRAPHIC SIMULATION LABORATORY
                </h2>
                <p className="text-slate-500 text-xs">
                  Test peer-to-peer transactions executed strictly on offline secure hardware devices (representing dual-offline payment chips) without network access, and analyze synchronization double-spending detections.
                </p>
              </div>

              {offlineSuccess && (
                <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-800 p-3.5 rounded text-xs font-mono">
                  {offlineSuccess}
                </div>
              )}

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Offline Device Registry */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      OFFLINE SECURE HARDWARE DEVICES
                    </h3>
                  </div>

                  <div className="space-y-3 font-mono text-xs">
                    {state.offline_devices?.map((d: any) => {
                      const name = state.participants.find((p: any) => p.associatedWalletId === d.walletId)?.name || d.walletId;
                      return (
                        <div key={d.deviceId} className="border border-slate-150 p-3 rounded bg-slate-50 flex items-center justify-between">
                          <div>
                            <span className="font-bold text-slate-800 block">{d.deviceId}</span>
                            <span className="text-slate-500 text-[10px]">{name}</span>
                          </div>
                          <div className="flex items-center space-x-3">
                            <span className="font-bold text-slate-700">${d.balance} CAD</span>
                            <button
                              onClick={() => handleOfflineSync(d.deviceId)}
                              className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 px-2.5 py-1 rounded text-[10px] font-bold"
                            >
                              Sync Ledger
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Offline action lab */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      SIMULATE OFFLINE PEER TRANSACTION
                    </h3>
                  </div>
                  <p className="text-xs text-slate-500">
                    This models two offline devices (Alex Tremblay and Dollarama Montreal) passing cryptographically signed tokens directly via NFC:
                  </p>

                  <div className="space-y-4 text-xs font-mono">
                    <div className="flex justify-between border border-slate-150 p-3 rounded bg-slate-50 items-center">
                      <div>
                        <span className="font-bold text-slate-800 block">Alex Tremblay (DEV-OFF-00000001)</span>
                        <span className="text-slate-500 text-[10px]">Offline balance: ${state.offline_devices?.find((d: any) => d.deviceId === "DEV-OFF-00000001")?.balance || 0} CAD</span>
                      </div>
                      <span className="text-slate-400">--- P2P NFC ---</span>
                      <div>
                        <span className="font-bold text-slate-800 block">Jean-Pierre (DEV-OFF-00000006)</span>
                        <span className="text-slate-500 text-[10px]">Offline balance: ${state.offline_devices?.find((d: any) => d.deviceId === "DEV-OFF-00000006")?.balance || 0} CAD</span>
                      </div>
                    </div>

                    <div className="flex items-center space-x-3">
                      <input
                        type="number"
                        value={offlineAmount}
                        onChange={e => setOfflineAmount(e.target.value)}
                        className="bg-slate-50 border border-slate-200 rounded px-3 py-1.5 font-mono text-xs text-slate-800 w-24"
                      />
                      <button
                        onClick={() => handleOfflinePayment("WA-00000001", "WA-00000006")}
                        className="flex-1 bg-slate-900 hover:bg-slate-850 text-white font-mono font-bold py-2 rounded transition text-xs shadow-sm"
                      >
                        SIMULATE NFC OFFLINE TRANSACTION
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 11: PRIVACY LABORATORY */}
          {activeTab === "user-privacy" && (
            <div className="space-y-6" id="tab-user-privacy">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  PRIVACY ARCHITECTURE ENGINEERING COMPARATOR
                </h2>
                <p className="text-slate-500 text-xs">
                  Model different privacy configurations to observe the clear engineering and cryptographic trade-offs between anonymity, audibility, and fraud-detection velocity.
                </p>
              </div>

              {/* Toggle configuration */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs font-mono text-center">
                {[
                  { id: "HIGH_PRIVACY", label: "HIGH PRIVACY (Token based)", desc: "CB has zero transaction visibility. Intermediaries route blindly. Minimal AML tracking." },
                  { id: "BALANCED", label: "BALANCED (Pseudo-Anonymous)", desc: "Masked user details on ledger. Automated threshold monitoring. Standard regulatory audit triggers." },
                  { id: "HIGH_TRACEABILITY", label: "HIGH TRACEABILITY (Fully Audited)", desc: "Every transaction explicitly linked to institutional ID. Full systemic central visibility." }
                ].map(p => (
                  <button
                    key={p.id}
                    onClick={() => updateConfig({ privacyConfig: p.id })}
                    className={`p-4 rounded border text-left flex flex-col space-y-2 cursor-pointer transition ${
                      state.config?.privacyConfig === p.id
                        ? "bg-rose-50 border-rose-500 text-rose-900"
                        : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
                    }`}
                  >
                    <span className="font-bold block">{p.label}</span>
                    <span className="text-[11px] text-slate-500 font-sans leading-normal">{p.desc}</span>
                  </button>
                ))}
              </div>

              {/* Comparative matrix */}
              <div className="bg-white border border-slate-200 rounded p-5 shadow-sm space-y-4 font-mono text-xs">
                <div className="border-b border-slate-100 pb-2">
                  <h3 className="font-bold text-slate-800">ENGINEERING TRADE-OFF ASSESSMENT</h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 border-b border-slate-100 pb-3">
                  <div className="font-bold text-slate-500">PARTICIPANT</div>
                  <div className="font-bold text-slate-500 text-center">ANONYMITY LEVEL</div>
                  <div className="font-bold text-slate-500 text-center">CENTRAL BANK VISIBILITY</div>
                  <div className="font-bold text-slate-500 text-center">INTERMEDIARY VISIBILITY</div>
                  <div className="font-bold text-slate-500 text-center">FRAUD DETECT TIME</div>
                </div>

                {state.config?.privacyConfig === "HIGH_PRIVACY" && (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4 text-slate-700 py-2 border-b border-slate-100">
                      <span className="font-bold">Retail Consumer</span>
                      <span className="text-center text-emerald-600 font-bold">EXCELLENT (99%)</span>
                      <span className="text-center text-slate-400">Zero records</span>
                      <span className="text-center text-slate-400">Masked header</span>
                      <span className="text-center text-rose-600 font-bold">DELAYED (Days)</span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-sans leading-relaxed">
                      * <b>High Privacy</b>: Promotes absolute cash-like properties but limits central auditing completely. Double spend reconciliation occurs strictly post-factum during device sync checks.
                    </p>
                  </>
                )}

                {state.config?.privacyConfig === "BALANCED" && (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4 text-slate-700 py-2 border-b border-slate-100">
                      <span className="font-bold">Retail Consumer</span>
                      <span className="text-center text-amber-600 font-bold">BALANCED (60%)</span>
                      <span className="text-center text-slate-700">Threshold alerts only</span>
                      <span className="text-center text-slate-700">Pseudonym audit keys</span>
                      <span className="text-center text-emerald-600 font-bold">INSTANT (&lt;1s)</span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-sans leading-relaxed">
                      * <b>Balanced Privacy</b>: The default model recommended for retail CBDC designs. Standard peer transactions are masked on ledger, but risk-scoring models automatically trigger investigation triggers above regulatory thresholds.
                    </p>
                  </>
                )}

                {state.config?.privacyConfig === "HIGH_TRACEABILITY" && (
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-4 text-slate-700 py-2 border-b border-slate-100">
                      <span className="font-bold">Retail Consumer</span>
                      <span className="text-center text-red-600 font-bold">MINIMAL (5%)</span>
                      <span className="text-center text-red-600 font-bold">Full KYC links</span>
                      <span className="text-center text-red-600 font-bold">Full ledger route</span>
                      <span className="text-center text-emerald-600 font-bold">INSTANT (Real-time)</span>
                    </div>
                    <p className="text-[11px] text-slate-500 font-sans leading-relaxed">
                      * <b>High Traceability</b>: Imposes absolute systemic tracking. Excellent for AML/CFT compliance monitoring but raises critical privacy and public adoption resistances.
                    </p>
                  </>
                )}
              </div>
            </div>
          )}

          {/* TAB 12: AML / COMPLIANCE (FINANCIAL CRIME CENTER) */}
          {activeTab === "sec-aml" && (
            <div className="space-y-6" id="tab-sec-aml">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  NATIONAL COMPLIANCE ALARM & FINANCIAL CRIME CENTER
                </h2>
                <p className="text-slate-500 text-xs">
                  Active XGBoost machine-learning scan anomalies on synthetic monetary flows. Click commands or execute transactions to trigger flags.
                </p>
              </div>

              {/* AML Alarms list */}
              <div className="bg-white border border-slate-200 rounded p-5 shadow-sm space-y-4 font-mono text-xs">
                <div className="border-b border-slate-100 pb-2">
                  <h3 className="font-bold text-slate-800">ACTIVE COMPLIANCE WARNINGS</h3>
                </div>

                <div className="space-y-3">
                  {state.alerts?.length === 0 ? (
                    <div className="p-6 text-center text-slate-400 italic">No compliance alarms triggered. System nominal.</div>
                  ) : (
                    state.alerts.map((a: any) => (
                      <div key={a.alert_id} className="border border-red-150 p-3 rounded bg-red-50/50 flex flex-col md:flex-row md:items-center md:justify-between text-xs space-y-2 md:space-y-0">
                        <div className="space-y-1">
                          <span className="bg-red-100 text-red-800 font-bold px-2 py-0.5 rounded text-[9px] mr-2">
                            {a.type}
                          </span>
                          <span className="font-bold text-slate-800">Risk Score: {a.risk_score}/100</span>
                          <p className="text-[11px] text-slate-500">Sender: {a.sender} | Receiver: {a.receiver} | Amount: ${a.amount}</p>
                        </div>
                        <button
                          onClick={() => {
                            alert(`Cleared compliance log ${a.alert_id}. Audited.`);
                          }}
                          className="bg-slate-900 hover:bg-slate-850 text-white px-3 py-1.5 rounded font-bold text-[10px]"
                        >
                          Dismiss Alert
                        </button>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}

          {/* TAB 13: CYBERSECURITY & RESILIENCE */}
          {activeTab === "sec-cyber" && (
            <div className="space-y-6" id="tab-sec-cyber">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  CYBERSECURITY SIMULATOR & RESILIENCE TESTING
                </h2>
                <p className="text-slate-500 text-xs">
                  Inject safe synthetic outages (regional outages, network partitions, or core database crashes) to observe routing resilience and disaster recovery pipelines.
                </p>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Outage injector panel */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="text-sm font-bold font-mono text-slate-800">
                      INJECT SYNTHETIC OUTAGE DISRUPTION
                    </h3>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                    <button
                      onClick={() => handleScenarioChange("PAYMENT_OUTAGE")}
                      className={`p-3 border rounded text-left flex flex-col space-y-1 cursor-pointer transition ${
                        state.config?.activeOutages?.networkOutage
                          ? "bg-rose-50 border-rose-500 text-rose-900"
                          : "bg-white border-slate-200 hover:bg-slate-50 text-slate-700"
                      }`}
                    >
                      <span className="font-bold">Network Partition</span>
                      <span className="text-[10px] text-slate-400 font-sans">Forces transactions to queue locally.</span>
                    </button>

                    <button
                      onClick={() => updateConfig({ activeOutages: { centralServiceFailure: !state.config?.activeOutages?.centralServiceFailure } })}
                      className={`p-3 border rounded text-left flex flex-col space-y-1 cursor-pointer transition ${
                        state.config?.activeOutages?.centralServiceFailure
                          ? "bg-rose-50 border-rose-500 text-rose-900"
                          : "bg-white border-slate-200 hover:bg-slate-50 text-slate-700"
                      }`}
                    >
                      <span className="font-bold">Core Ledger Crash</span>
                      <span className="text-[10px] text-slate-400 font-sans">Blocks online clearances instantly.</span>
                    </button>
                  </div>

                  <button
                    onClick={() => handleScenarioChange("BASELINE")}
                    className="w-full bg-slate-950 hover:bg-slate-900 text-white font-mono font-bold py-2 rounded text-xs transition"
                  >
                    RESTORE SYSTEM DISASTER RECOVERY (RECONCILE)
                  </button>
                </div>

                {/* Resilience outcomes board */}
                <div className="bg-white border border-slate-200 p-5 rounded shadow-sm space-y-4 font-mono text-xs">
                  <div className="border-b border-slate-100 pb-2">
                    <h3 className="font-bold text-slate-800">RESILIENCE PIPELINE STATUS</h3>
                  </div>

                  <div className="space-y-3 font-mono text-slate-600">
                    <div className="flex justify-between border-b border-slate-100 pb-1">
                      <span>Primary Ledger Replication:</span>
                      <span className="text-emerald-600 font-bold">NOMINAL (REPLICATED)</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-100 pb-1">
                      <span>Offline Ledger Backup:</span>
                      <span className="text-emerald-600 font-bold">NOMINAL (SYNCED)</span>
                    </div>
                    <div className="flex justify-between border-b border-slate-100 pb-1">
                      <span>Disaster Recovery Center:</span>
                      <span className="text-emerald-600 font-bold">NOMINAL (HOT STANDBY)</span>
                    </div>
                    <div className="flex justify-between pb-1">
                      <span>Reconciled Transactions:</span>
                      <span className="text-slate-800 font-bold">{state.transactions?.length} OK</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 14: AUDIT DOSSIERS EXPLORER */}
          {activeTab === "sec-audit" && (
            <div className="space-y-6" id="tab-sec-audit">
              <div className="border-b border-slate-200 pb-3">
                <h2 className="text-xl font-bold font-mono text-slate-800">
                  NATIONAL AUDIT REPORT & DEEP RECORD EXPLORER
                </h2>
                <p className="text-slate-500 text-xs">
                  Inspect the immutable audit events generated automatically for every state change, transaction swap, or emergency injection.
                </p>
              </div>

              {/* Audit trail list */}
              <div className="bg-white border border-slate-200 rounded shadow-sm overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs font-mono">
                  <thead>
                    <tr className="bg-slate-100 text-slate-600 border-b border-slate-200 text-[10px] uppercase">
                      <th className="p-3">EVENT ID</th>
                      <th className="p-3">TIMESTAMP</th>
                      <th className="p-3">ACTOR</th>
                      <th className="p-3">ACTION</th>
                      <th className="p-3">DESCRIPTION / AUDIT EVIDENCE</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 text-slate-700">
                    {state.audit_events?.slice().reverse().map((e: any) => (
                      <tr key={e.event_id} className="hover:bg-slate-50">
                        <td className="p-3 text-slate-400 font-bold">{e.event_id}</td>
                        <td className="p-3 text-slate-500">{e.timestamp.substring(11, 19)}</td>
                        <td className="p-3 font-semibold text-rose-700">{e.actor}</td>
                        <td className="p-3"><span className="bg-slate-100 px-1.5 py-0.5 rounded font-bold text-[10px]">{e.action}</span></td>
                        <td className="p-3 text-slate-500 leading-normal">{e.reason}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>

      {/* Embedded Terminal CLI Console Panel */}
      <footer className="bg-slate-950 text-slate-300 border-t border-slate-850 h-56 flex flex-col font-mono" id="terminal-footer">
        <div className="bg-slate-900 px-4 py-2 flex items-center justify-between border-b border-slate-800 text-[11px] text-slate-400 select-none">
          <span className="flex items-center font-bold">
            <Terminal className="h-4.5 w-4.5 mr-2 text-rose-500" />
            {t.terminalTitle}
          </span>
          <span className="text-[10px] text-slate-500">
            Commands: 'maple status', 'ledger inspect', 'banks status', 'aml scan', 'macro status'
          </span>
        </div>

        {/* Terminal logs */}
        <div className="flex-1 overflow-y-auto p-4 text-xs font-mono bg-slate-950 text-slate-300 leading-relaxed whitespace-pre-wrap select-text selection:bg-slate-800 select-none">
          {cliOutput}
          <div ref={cliEndRef} />
        </div>

        {/* Terminal Input prompt */}
        <form onSubmit={handleCliSubmit} className="bg-slate-900 border-t border-slate-800 px-4 py-2 flex items-center space-x-2 shrink-0">
          <span className="text-rose-500 font-bold font-mono text-sm select-none">CAD-SBOX&gt;</span>
          <input
            type="text"
            value={cliInput}
            onChange={e => setCliInput(e.target.value)}
            placeholder={t.promptPlaceholder}
            className="flex-1 bg-transparent border-none text-slate-200 placeholder-slate-600 focus:outline-none focus:ring-0 text-xs font-mono select-none"
            id="cli-prompt-input"
          />
          <button type="submit" className="text-slate-500 hover:text-white transition">
            <Send className="h-4 w-4" />
          </button>
        </form>
      </footer>
    </div>
  );
}
