/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { MapleDigitalTwin } from "./src/simulation_state.js";
import { TransactionType } from "./src/types.js";

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Single source of truth for our CBDC Digital Twin
  const digitalTwin = new MapleDigitalTwin();

  // Setup interval for auto-ticking if the clock speed isn't PAUSE
  let tickInterval: NodeJS.Timeout | null = null;
  const runInterval = () => {
    if (tickInterval) clearInterval(tickInterval);
    if (digitalTwin.config.speed !== "PAUSE") {
      let ms = 2000;
      if (digitalTwin.config.speed === "2X") ms = 1000;
      if (digitalTwin.config.speed === "5X") ms = 400;
      if (digitalTwin.config.speed === "10X") ms = 200;

      tickInterval = setInterval(() => {
        digitalTwin.tick();
      }, ms);
    }
  };

  app.use(express.json());

  // 1. API: Retrieve entire state
  app.get("/api/state", (req, res) => {
    res.json({
      config: digitalTwin.config,
      participants: digitalTwin.participants,
      wallets: digitalTwin.wallets,
      transactions: digitalTwin.transactions.slice(-150), // Send last 150 transactions for display
      ledger_entries: digitalTwin.ledger_entries.slice(-150),
      alerts: digitalTwin.alerts,
      bonds: digitalTwin.bonds,
      audit_events: digitalTwin.audit_events.slice(-150),
      network_nodes: digitalTwin.network_nodes,
      offline_devices: digitalTwin.offline_devices,
      macro: digitalTwin.macro,
      mlModels: digitalTwin.mlModels
    });
  });

  // 2. API: Trigger a single manual tick
  app.post("/api/tick", (req, res) => {
    digitalTwin.tick();
    res.json({ success: true, tick: digitalTwin.config.currentTick });
  });

  // 3. API: Update Configuration and speeds
  app.post("/api/config", (req, res) => {
    const { speed, cbdcInterestRate, limits, privacyConfig, tokenisationArch, activeOutages, cbdcAdoptionLevel } = req.body;

    if (speed !== undefined) {
      digitalTwin.config.speed = speed;
      runInterval();
    }
    if (cbdcInterestRate !== undefined) {
      digitalTwin.config.cbdcInterestRate = Number(cbdcInterestRate);
    }
    if (cbdcAdoptionLevel !== undefined) {
      digitalTwin.config.cbdcAdoptionLevel = Number(cbdcAdoptionLevel);
    }
    if (limits !== undefined) {
      digitalTwin.config.limits = { ...digitalTwin.config.limits, ...limits };
      // Sync wallet limit records
      digitalTwin.wallets.forEach(w => {
        if (w.type === "CONSUMER") w.holdingLimit = digitalTwin.config.limits.individual;
        if (w.type === "MERCHANT") w.holdingLimit = digitalTwin.config.limits.merchant;
        if (w.type === "INSTITUTIONAL") w.holdingLimit = digitalTwin.config.limits.institution;
      });
    }
    if (privacyConfig !== undefined) {
      digitalTwin.config.privacyConfig = privacyConfig;
    }
    if (tokenisationArch !== undefined) {
      digitalTwin.config.tokenisationArch = tokenisationArch;
    }
    if (activeOutages !== undefined) {
      digitalTwin.config.activeOutages = { ...digitalTwin.config.activeOutages, ...activeOutages };
    }

    res.json({ success: true, config: digitalTwin.config });
  });

  // 4. API: Execute Transfers
  app.post("/api/transfer", (req, res) => {
    const { sender, receiver, amount, type, channel } = req.body;
    try {
      const tx = digitalTwin.processTransfer(
        sender,
        receiver,
        Number(amount),
        type || TransactionType.TRANSFER,
        channel || "ONLINE"
      );
      res.json({ success: tx.status === "SETTLED", transaction: tx });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // 5. API: Issue Money
  app.post("/api/issue", (req, res) => {
    const { bankId, amount, reason } = req.body;
    try {
      const tx = digitalTwin.issueCbdc(bankId, Number(amount), reason || "Synthetic Sandbox Issuance");
      res.json({ success: tx.status === "SETTLED", transaction: tx });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // 6. API: Redeem Money
  app.post("/api/redeem", (req, res) => {
    const { bankId, amount } = req.body;
    try {
      const tx = digitalTwin.redeemCbdc(bankId, Number(amount));
      res.json({ success: tx.status === "SETTLED", transaction: tx });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // 7. API: Offline payment trigger
  app.post("/api/offline/payment", (req, res) => {
    const { fromWallet, toWallet, amount } = req.body;
    try {
      const tx = digitalTwin.triggerOfflinePayment(fromWallet, toWallet, Number(amount));
      res.json({ success: tx.status === "SETTLED", transaction: tx });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // 8. API: Offline Sync
  app.post("/api/offline/sync", (req, res) => {
    const { deviceId } = req.body;
    try {
      const result = digitalTwin.syncOfflineDevice(deviceId);
      res.json({ success: result.status === "SUCCESS", ...result });
    } catch (err: any) {
      res.status(400).json({ success: false, error: err.message });
    }
  });

  // 9. API: Bond DwP Swaps
  app.post("/api/bonds/purchase", (req, res) => {
    const { participantId, bondId } = req.body;
    try {
      const result = digitalTwin.purchaseDigitalBond(participantId, bondId);
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  });

  // 10. API: Cross Border Instant FX
  app.post("/api/crossborder", (req, res) => {
    const { sourceWallet, targetCurrency, amount } = req.body;
    try {
      const result = digitalTwin.executeCrossBorderSettlement(sourceWallet, targetCurrency, Number(amount));
      res.json(result);
    } catch (err: any) {
      res.status(400).json({ success: false, message: err.message });
    }
  });

  // 11. API: Stress testing
  app.post("/api/scenarios/stress", (req, res) => {
    digitalTwin.injectStressTestRecession();
    res.json({ success: true, config: digitalTwin.config });
  });

  // 12. API: Restore Nominal
  app.post("/api/scenarios/restore", (req, res) => {
    digitalTwin.restoreNominalScenario();
    res.json({ success: true, config: digitalTwin.config });
  });

  // 13. API: Interactive Terminal CLI Parser
  app.post("/api/cli", (req, res) => {
    const { command } = req.body;
    if (!command || typeof command !== "string") {
      return res.json({ output: "Error: No command input." });
    }

    const args = command.trim().split(/\s+/);
    const cmd = args[0].toLowerCase();

    try {
      switch (cmd) {
        case "maple":
          if (args[1] === "status") {
            const totCirc = digitalTwin.macro.cbdc_supply.toLocaleString();
            res.json({
              output: `MAPLE DIGITAL SYSTEM STATUS:\n============================\nLEDGER STATUS: SYNCHRONISED\nNETWORK NODE: NOMINAL\nACTIVE WALLETS: ${digitalTwin.wallets.length}\nCIRCULATING SUPPLY: $${totCirc} CAD-DIGITAL\nCENTRAL BANK INTERCEPT: RUNNING\nSYSTEM RISK METRIC: NOMINAL\n============================`
            });
          } else {
            res.json({ output: "Usage: maple status" });
          }
          break;

        case "ledger":
          if (args[1] === "status") {
            const totalCbdc = digitalTwin.wallets.reduce((sum, w) => sum + w.balance, 0).toLocaleString();
            res.json({
              output: `LEDGER STATUS: INTEGRITY NOMINAL\n-------------------------------\nTotal Records Verified: ${digitalTwin.ledger_entries.length}\nConservation Constraint Check: PASS\nConsensus Engine: PBFT Digital Twin\nCirculating Ledger Balance: $${totalCbdc} CAD-DIGITAL`
            });
          } else if (args[1] === "inspect") {
            const lastEntries = digitalTwin.ledger_entries.slice(-5).map(e => 
              `[${e.timestamp.substring(11,19)}] DEBIT: ${e.account_debit} | CREDIT: ${e.account_credit} | AMOUNT: $${e.amount.toFixed(2)} CAD`
            ).join("\n");
            res.json({
              output: `INSPECTING CENTRAL CORE LEDGER (LAST 5 POSTINGS):\n-------------------------------------------------\n${lastEntries || "No recent postings recorded."}`
            });
          } else {
            res.json({ output: "Usage: ledger status | ledger inspect" });
          }
          break;

        case "cbdc":
          if (args[1] === "supply") {
            res.json({
              output: `CAD-DIGITAL SUPPLY AUDIT:\n-------------------------\nCirculating Retail: $${digitalTwin.macro.cbdc_supply.toLocaleString()} CAD-DIGITAL\nCentral Bank Buffer: $${digitalTwin.wallets.find(w => w.id === "WA-CENTRAL-BANK")?.balance.toLocaleString()} CAD-DIGITAL\nMonetary Conservation Status: OK (Conservation confirmed)`
            });
          } else if (args[1] === "issue") {
            const amount = parseFloat(args[2]);
            if (isNaN(amount) || amount <= 0) {
              return res.json({ output: "Usage: cbdc issue <amount>" });
            }
            const tx = digitalTwin.issueCbdc("CA-BANK-RBC", amount, "CLI Manual Issuance Request");
            res.json({
              output: `APPROVED ISSUANCE AT CENTRAL LEDGER:\n-------------------------------------\nTransaction ID: ${tx.transaction_id}\nRecipient: Royal Bank of Canada (RBC) Digital Twin\nValue: $${amount.toLocaleString()} CAD-DIGITAL\nStatus: SETTLED\nAccounting Impact: RBC Reserves swapped for Central Bank CBDC liability.`
            });
          } else if (args[1] === "redeem") {
            const amount = parseFloat(args[2]);
            if (isNaN(amount) || amount <= 0) {
              return res.json({ output: "Usage: cbdc redeem <amount>" });
            }
            const tx = digitalTwin.redeemCbdc("CA-BANK-RBC", amount);
            res.json({
              output: `APPROVED CONTRACTIVE REDEMPTION AT LEDGER:\n-----------------------------------------\nTransaction ID: ${tx.transaction_id}\nFrom: Royal Bank of Canada (RBC) Digital Twin\nRetired Amount: $${amount.toLocaleString()} CAD-DIGITAL\nStatus: SETTLED\nMonetary retirement audit recorded.`
            });
          } else {
            res.json({ output: "Usage: cbdc supply | cbdc issue <amount> | cbdc redeem <amount>" });
          }
          break;

        case "wallet":
          if (args[1] === "list") {
            const list = digitalTwin.wallets.slice(0, 10).map(w => 
              `Wallet ID: ${w.id} | Owner: ${w.participantId} | Balance: $${w.balance.toLocaleString()} CAD`
            ).join("\n");
            res.json({ output: `WALLETS SYSTEM SAMPLING (FIRST 10):\n----------------------------------\n${list}` });
          } else if (args[1] === "inspect") {
            const id = args[2];
            if (!id) return res.json({ output: "Usage: wallet inspect <wallet_id>" });
            const w = digitalTwin.wallets.find(wl => wl.id === id);
            if (!w) return res.json({ output: `Error: Wallet ${id} not found.` });
            res.json({
              output: `WALLET DOSSIER: ${w.id}\n---------------------------\nOwner: ${w.participantId}\nBalance: $${w.balance.toLocaleString()} CAD\nOffline Balance: $${w.offlineBalance.toLocaleString()} CAD\nLimit Level: $${w.holdingLimit.toLocaleString()} CAD\nIdentity KYC Tier: ${w.identityStatus}\nOperational Status: ${w.status}`
            });
          } else {
            res.json({ output: "Usage: wallet list | wallet inspect <wallet_id>" });
          }
          break;

        case "payment":
          if (args[1] === "simulate") {
            const consumers = digitalTwin.wallets.filter(wl => wl.type === "CONSUMER" && wl.balance > 20);
            const merchants = digitalTwin.wallets.filter(wl => wl.type === "MERCHANT");
            if (consumers.length === 0 || merchants.length === 0) {
              return res.json({ output: "Error: Insufficient simulation agents in workspace to trigger transaction." });
            }
            const sender = consumers[0].id;
            const receiver = merchants[0].id;
            const amt = 42.50;
            const tx = digitalTwin.processTransfer(sender, receiver, amt, TransactionType.MERCHANT_PAYMENT);
            res.json({
              output: `SIMULATED RETIAL TRANSACTION SUCCEEDED:\n----------------------------------------\nTransaction ID: ${tx.transaction_id}\nFrom Consumer: ${sender}\nTo Merchant: ${receiver}\nValue: $${amt.toFixed(2)} CAD-DIGITAL\nChannel: ONLINE\nSettlement Ledger Clearance Reference: ${tx.settlement_reference}`
            });
          } else {
            res.json({ output: "Usage: payment simulate" });
          }
          break;

        case "banks":
          if (args[1] === "status") {
            const status = digitalTwin.participants
              .filter(p => p.type === "COMMERCIAL_BANK")
              .map(p => `Bank: ${p.name} | Deposits: $${p.liabilities?.deposits.toLocaleString()} | Reserves: $${p.assets?.reserves.toLocaleString()} | CBDC Outflow: $${p.liabilities?.cbdcOutflows.toLocaleString()}`)
              .join("\n");
            res.json({ output: `COMMERCIAL FINANCIAL STABILITY MONITORS:\n----------------------------------------\n${status}` });
          } else if (args[1] === "stress") {
            digitalTwin.injectStressTestRecession();
            res.json({ output: `CRITICAL ACTION DETECTED: Macro Stress Shock (Severe Recession) successfully injected into national financial engine.` });
          } else {
            res.json({ output: "Usage: banks status | banks stress" });
          }
          break;

        case "network":
          if (args[1] === "status") {
            const health = digitalTwin.network_nodes.map(n => 
              `Node: ${n.id} (${n.name}) | Status: ${n.status} | Latency: ${n.latency}ms | Throughput: ${n.throughput} tx/s`
            ).join("\n");
            res.json({ output: `NATIONAL PAYMENT NETWORK GRAPH TELEMETRY:\n-----------------------------------------\n${health}` });
          } else {
            res.json({ output: "Usage: network status" });
          }
          break;

        case "aml":
          if (args[1] === "scan") {
            const highRisk = digitalTwin.transactions.filter(t => t.risk_status === "HIGH" || t.risk_status === "MEDIUM");
            const alarms = digitalTwin.alerts.map(a => `[ALT-${a.alert_id}] Type: ${a.type} | Risk Score: ${a.risk_score}/100 | Target: ${a.sender} -> ${a.receiver}`).join("\n");
            res.json({
              output: `AML RISK SIMULATION DETECTIONS:\n-----------------------------\nActive Suspicious Alarms:\n${alarms || "Zero high-threat alarms flagged."}\n\nRecent Scanned Logs: ${digitalTwin.transactions.length} synthetic payments verified.`
            });
          } else {
            res.json({ output: "Usage: aml scan" });
          }
          break;

        case "macro":
          if (args[1] === "status") {
            res.json({
              output: `MACROECONOMIC METRICS (SYNTHETIC NATIONAL ENGINE):\n-------------------------------------------------\nGDP Total: $${(digitalTwin.macro.gdp / 1e12).toFixed(2)} Trillion CAD\nCPI (Inflation): ${digitalTwin.macro.cpi}%\nTarget Policy Rate: ${digitalTwin.macro.interest_rate}%\nCBDC Money Velocity: ${digitalTwin.macro.velocity}\nUnemployment Rate: ${digitalTwin.macro.unemployment}%\nCAD/USD Rate: ${digitalTwin.macro.exchange_rate.USD}`
            });
          } else {
            res.json({ output: "Usage: macro status" });
          }
          break;

        case "audit":
          if (args[1] === "transaction" && args[2]) {
            const txId = args[2];
            const tx = digitalTwin.transactions.find(t => t.transaction_id === txId);
            if (!tx) return res.json({ output: `Error: Transaction ${txId} not found.` });
            const entries = digitalTwin.ledger_entries.filter(e => e.transaction_id === txId);
            const entryLines = entries.map(e => `  [Ledger Double-Entry] Account DB: ${e.account_debit} | Account CR: ${e.account_credit} | Amount: $${e.amount}`).join("\n");
            res.json({
              output: `TRANSACTION AUDIT REPORT: ${txId}\n---------------------------------------\nTimestamp: ${tx.timestamp}\nType: ${tx.type}\nSender Wallet: ${tx.sender}\nReceiver Wallet: ${tx.receiver}\nGross Amount: $${tx.amount.toFixed(2)} CAD-DIGITAL\nSettlement Reference: ${tx.settlement_reference}\nStatus: ${tx.status}\nLedger Integration Ledger Postings:\n${entryLines || "  No direct core ledger entries matched."}`
            });
          } else {
            res.json({ output: "Usage: audit transaction <tx_id>" });
          }
          break;

        default:
          res.json({
            output: `Command not recognized: '${cmd}'.\nAvailable: maple status, ledger status, ledger inspect, cbdc supply, cbdc issue, cbdc redeem, wallet list, wallet inspect, payment simulate, banks status, banks stress, network status, aml scan, macro status, audit transaction <tx_id>`
          });
      }
    } catch (e: any) {
      res.json({ output: `Error executing command: ${e.message}` });
    }
  });

  // Start checking background ticking
  runInterval();

  // Vite Integration for Hot Reloading and Front-end Hosting
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa"
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Maple Digital Twin Express server running on port ${PORT}`);
  });
}

startServer();
