/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { MapleDigitalTwin } from "./src/simulation_state.js";
import { TransactionType, TransactionStatus, PrivacyMode } from "./src/types.js";

function runTests() {
  console.log("==========================================");
  console.log("MAPLE DIGITAL: CORE LEDGER & MONETARY SUITE");
  console.log("==========================================");

  let passed = 0;
  let failed = 0;

  const assert = (condition: boolean, message: string) => {
    if (condition) {
      console.log(`[PASS] ${message}`);
      passed++;
    } else {
      console.error(`[FAIL] ${message}`);
      failed++;
    }
  };

  try {
    // Test 1: Initialization
    const twin = new MapleDigitalTwin();
    assert(twin.wallets.length > 0, "System wallets successfully populated");
    assert(twin.participants.length > 0, "System synthetic participants registered");

    const initialTotalCbdc = twin.wallets
      .filter(w => w.id !== "WA-CENTRAL-BANK" && w.id !== "WA-GOV-TREASURY")
      .reduce((sum, w) => sum + w.balance + w.offlineBalance, 0);

    assert(Math.abs(initialTotalCbdc - 18792888525) < 1e5, `Initial circulating CBDC is correct: $${initialTotalCbdc.toLocaleString()} CAD`);

    // Test 2: Core Double-Entry Ledger Transfer
    const sender = twin.wallets.find(w => w.id === "WA-00000001"); // Balance: 1450
    const receiver = twin.wallets.find(w => w.id === "WA-MER-TIMS"); // Balance: 45000
    assert(!!sender && !!receiver, "Sender and receiver interactive wallets resolved");

    if (sender && receiver) {
      const prevSenderBal = sender.balance;
      const prevRecvBal = receiver.balance;
      const amount = 50;

      const tx = twin.processTransfer(sender.id, receiver.id, amount, TransactionType.MERCHANT_PAYMENT);
      assert(tx.status === TransactionStatus.SETTLED, "Transfer status SETTLED successfully");
      assert(sender.balance === prevSenderBal - amount, "Sender debited correctly on online transfer");
      assert(receiver.balance === prevRecvBal + amount, "Receiver credited correctly on online transfer");

      // Verify double entry ledger balances match
      const ledgerDebit = twin.ledger_entries.find(e => e.transaction_id === tx.transaction_id && e.account_debit === `${receiver.id}.BALANCE`);
      assert(!!ledgerDebit, "Ledger debit entry recorded with proper account routing");
    }

    // Test 3: Issuance Audit Trail & Balance Sheet Expansion
    const rbcWallet = twin.wallets.find(w => w.id === "WA-BANK-RBC");
    assert(!!rbcWallet, "RBC Institutional wallet resolved");

    if (rbcWallet) {
      const prevBalance = rbcWallet.balance;
      const issueAmount = 100000000; // $100 Million
      const tx = twin.issueCbdc("CA-BANK-RBC", issueAmount, "Liquidity Injection Scenario");

      assert(tx.status === TransactionStatus.SETTLED, "Central Bank CBDC Issuance settled");
      assert(rbcWallet.balance === prevBalance + issueAmount, "RBC balance sheet reflects newly issued CBDC holding");
    }

    // Test 4: Contraction Redemption Trail
    if (rbcWallet) {
      const prevBalance = rbcWallet.balance;
      const redeemAmount = 50000000; // $50 Million
      const tx = twin.redeemCbdc("CA-BANK-RBC", redeemAmount);

      assert(tx.status === TransactionStatus.SETTLED, "Central Bank CBDC Redemption settled");
      assert(rbcWallet.balance === prevBalance - redeemAmount, "RBC wallet balance contracted properly");
    }

    // Test 5: Wallet Holding Limits Enforcement
    const consumer = twin.wallets.find(w => w.id === "WA-00000003"); // Balance: 420, Limit: 5000
    const bmoWallet = twin.wallets.find(w => w.id === "WA-BANK-BMO");

    if (consumer && bmoWallet) {
      // Attempt to transfer $6,000 to consumer (limit is $5,000)
      const tx = twin.processTransfer(bmoWallet.id, consumer.id, 6000, TransactionType.TRANSFER);
      assert(tx.status === TransactionStatus.FAILED, "Transfer exceeding holding limits correctly blocked");
      assert(tx.settlement_reference === "FAILED-LIMIT-EXCEEDED", "Error reason correctly flags Limit Exceeded");
    }

    // Test 6: Offline Payment and Reconciliation
    const offConsumer = twin.wallets.find(w => w.id === "WA-00000006"); // Balance: 80, Offline: 40
    const offMerch = twin.wallets.find(w => w.id === "WA-MER-DOLLAR"); // Balance: 35000, Offline: 2500

    if (offConsumer && offMerch) {
      const prevConsOffline = offConsumer.offlineBalance;
      const prevMerchOffline = offMerch.offlineBalance;
      const amount = 20;

      const tx = twin.triggerOfflinePayment(offConsumer.id, offMerch.id, amount);
      assert(tx.status === TransactionStatus.SETTLED, "Offline peer payment settled immediately");
      assert(offConsumer.offlineBalance === prevConsOffline - amount, "Offline consumer balance decremented");
      assert(offMerch.offlineBalance === prevMerchOffline + amount, "Offline merchant balance incremented");

      // Sync device and check double spend resistance
      const deviceId = "DEV-OFF-00000006";
      const syncResult = twin.syncOfflineDevice(deviceId);
      assert(syncResult.status === "SUCCESS", "Offline device synchronization verified");
    }

    // Test 7: Double Spending & Fraud Resistance
    const offConsumer2 = twin.wallets.find(w => w.id === "WA-00000008"); // Balance: 2900, Offline: 200, limit 5000
    const deviceId2 = "DEV-OFF-00000008";
    const dev = twin.offline_devices.find(d => d.deviceId === deviceId2);

    if (offConsumer2 && dev) {
      // Fabricate malicious double spend state by modifying device balance to bypass conservation rules
      dev.balance = 10000; // Artificially high bypass
      const syncResult = twin.syncOfflineDevice(deviceId2);
      assert(syncResult.status === "CONFLICT_DETECTED", "Double spend signature collision detected and quarantined");
      assert(offConsumer2.status === "COMPROMISED", "Offending wallet successfully suspended");
    }

    // Test 8: AML Structuring Detection
    const structuredWallet = twin.wallets.find(w => w.id === "WA-00000004");
    const targetWallet = twin.wallets.find(w => w.id === "WA-MER-TIMS");

    if (structuredWallet && targetWallet) {
      // Pre-fund the wallet to ensure transactions can actually settle instead of failing on insufficient funds
      structuredWallet.balance = 20000;
      twin.config.privacyConfig = PrivacyMode.HIGH_TRACEABILITY;
      // Force three sequential large transfers close to individual limits
      const tx1 = twin.processTransfer(structuredWallet.id, targetWallet.id, 4600, TransactionType.MERCHANT_PAYMENT);
      const tx2 = twin.processTransfer(structuredWallet.id, targetWallet.id, 4700, TransactionType.MERCHANT_PAYMENT);
      const tx = twin.processTransfer(structuredWallet.id, targetWallet.id, 4800, TransactionType.MERCHANT_PAYMENT);

      console.log("DEBUG structuring - tx1 status:", tx1.status, "tx1 risk_status:", tx1.risk_status);
      console.log("DEBUG structuring - tx2 status:", tx2.status, "tx2 risk_status:", tx2.risk_status);
      console.log("DEBUG structuring - tx3 status:", tx.status, "tx3 risk_status:", tx.risk_status, "risk_reason:", tx.risk_reason);

      assert(tx.risk_status === "HIGH", "Compliance scanner successfully flags rapid structuring behavioral patterns");
    }

  } catch (err: any) {
    console.error("Test suite crashed with error:", err);
    failed++;
  }

  console.log("==========================================");
  console.log(`TEST SUITE RESULTS: ${passed} PASSED, ${failed} FAILED`);
  console.log("==========================================");

  if (failed > 0) {
    process.exit(1);
  } else {
    process.exit(0);
  }
}

runTests();
