package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.simulation.SimulationEngine
import com.example.ui.components.AppBottomNav
import com.example.ui.components.SimulationControlsSheet
import com.example.ui.components.TopBanner
import com.example.ui.screens.*
import com.example.ui.theme.CathayIvory
import com.example.ui.theme.CathayTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            CathayTheme {
                CathayPacificApp()
            }
        }
    }
}

@Composable
fun CathayPacificApp() {
    val state by SimulationEngine.state.collectAsStateWithLifecycle()
    var currentRoute by remember { mutableStateOf("home") }
    var showSimSheet by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopBanner(
                state = state,
                onOpenSimControls = { showSimSheet = true },
                onOpenNotifications = { currentRoute = "notifications" }
            )
        },
        bottomBar = {
            AppBottomNav(
                currentRoute = currentRoute,
                onNavigate = { route -> currentRoute = route }
            )
        },
        containerColor = CathayIvory,
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentRoute) {
                "home" -> HomeScreen(state = state, onNavigate = { currentRoute = it })
                "book" -> BookingScreen(state = state, onNavigate = { currentRoute = it })
                "trips" -> MyTripsScreen(state = state, onNavigate = { currentRoute = it })
                "checkin" -> CheckInScreen(state = state, onNavigate = { currentRoute = it })
                "boarding" -> BoardingPassScreen(state = state)
                "status" -> FlightStatusScreen(state = state)
                "airport" -> AirportScreen(state = state)
                "lounges" -> LoungesScreen(state = state)
                "destinations" -> DestinationsScreen(state = state, onNavigateToBook = { currentRoute = "book" })
                "loyalty" -> LoyaltyScreen(state = state)
                "inflight" -> InflightScreen(state = state)
                "more" -> MoreHubScreen(onNavigateTo = { currentRoute = it })
                "shop" -> CathayShopScreen(state = state)
                "assistant" -> AssistantScreen(state = state)
                "disruption" -> DisruptionScreen(state = state)
                "operations" -> OperationsScreen(state = state)
                "documents" -> DocumentsScreen(state = state)
                "notifications" -> NotificationsScreen(state = state)
                "support" -> SupportScreen(state = state)
                else -> HomeScreen(state = state, onNavigate = { currentRoute = it })
            }
        }

        if (showSimSheet) {
            SimulationControlsSheet(
                state = state,
                onDismiss = { showSimSheet = false },
                onNavigateToOps = { currentRoute = "operations" },
                onNavigateToDisruption = { currentRoute = "disruption" }
            )
        }
    }
}
