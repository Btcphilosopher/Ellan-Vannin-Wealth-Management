package com.example.data.mock

import com.example.data.model.*

object SyntheticData {

    val samplePassenger = Passenger(
        id = "P1001",
        title = "Mr",
        firstName = "Thomas",
        lastName = "Lee",
        dob = "1988-06-15",
        nationality = "Hong Kong (SAR)",
        passportNumber = "H88294012",
        passportExpiry = "2031-10-20",
        email = "thomas.lee@cathay-prototype.test",
        phone = "+852 9123 4567",
        emergencyContact = "Sarah Lee (+852 9876 5432)",
        frequentFlyerNo = "CX-88392019",
        specialAssistance = "None Required",
        dietaryReqs = "Hong Kong Gourmet / Standard"
    )

    val sampleFlights = listOf(
        Flight(
            id = "F001",
            flightNumber = "CX257",
            originCode = "HKG",
            originCity = "Hong Kong",
            originAirportName = "Hong Kong International Airport",
            destCode = "LHR",
            destCity = "London",
            destAirportName = "London Heathrow",
            scheduledDeparture = "2026-09-23T10:15",
            scheduledArrival = "2026-09-23T17:45",
            estimatedDeparture = "2026-09-23T10:15",
            estimatedArrival = "2026-09-23T17:45",
            durationFormatted = "12h 30m",
            aircraftType = "Boeing 777-300ER",
            basePriceHkd = 24800,
            status = FlightStatusEnum.BOARDING,
            gate = "Gate 31",
            terminal = "T1",
            baggageBelt = "Belt 8",
            stops = 0,
            asiaMilesEarn = 5980,
            statusPointsEarn = 75,
            operationalMessage = "Boarding Group 1 now proceeding at Gate 31."
        ),
        Flight(
            id = "F002",
            flightNumber = "CX500",
            originCode = "HKG",
            originCity = "Hong Kong",
            originAirportName = "Hong Kong International Airport",
            destCode = "HND",
            destCity = "Tokyo",
            destAirportName = "Tokyo Haneda Airport",
            scheduledDeparture = "2026-09-23T15:20",
            scheduledArrival = "2026-09-23T20:35",
            estimatedDeparture = "2026-09-23T15:20",
            estimatedArrival = "2026-09-23T20:35",
            durationFormatted = "4h 15m",
            aircraftType = "Airbus A350-1000",
            basePriceHkd = 7800,
            status = FlightStatusEnum.CHECKIN_OPEN,
            gate = "Gate 24",
            terminal = "T1",
            baggageBelt = "Belt 3",
            stops = 0,
            asiaMilesEarn = 1800,
            statusPointsEarn = 25
        ),
        Flight(
            id = "F003",
            flightNumber = "CX715",
            originCode = "HKG",
            originCity = "Hong Kong",
            originAirportName = "Hong Kong International Airport",
            destCode = "SIN",
            destCity = "Singapore",
            destAirportName = "Singapore Changi Airport",
            scheduledDeparture = "2026-09-23T20:00",
            scheduledArrival = "2026-09-23T23:55",
            estimatedDeparture = "2026-09-23T20:00",
            estimatedArrival = "2026-09-23T23:55",
            durationFormatted = "3h 55m",
            aircraftType = "Airbus A330-300",
            basePriceHkd = 4900,
            status = FlightStatusEnum.SCHEDULED,
            gate = "Gate 16",
            terminal = "T1",
            baggageBelt = "Belt 5",
            stops = 0,
            asiaMilesEarn = 1200,
            statusPointsEarn = 20
        ),
        Flight(
            id = "F004",
            flightNumber = "CX888",
            originCode = "HKG",
            originCity = "Hong Kong",
            originAirportName = "Hong Kong International Airport",
            destCode = "YVR",
            destCity = "Vancouver",
            destAirportName = "Vancouver Intl Airport",
            scheduledDeparture = "2026-09-24T00:45",
            scheduledArrival = "2026-09-23T21:25",
            estimatedDeparture = "2026-09-24T00:45",
            estimatedArrival = "2026-09-23T21:25",
            durationFormatted = "11h 40m",
            aircraftType = "Airbus A350-900",
            basePriceHkd = 18900,
            status = FlightStatusEnum.SCHEDULED,
            gate = "Gate 42",
            terminal = "T1",
            baggageBelt = "Belt 12",
            stops = 0,
            asiaMilesEarn = 5100,
            statusPointsEarn = 65
        ),
        Flight(
            id = "F005",
            flightNumber = "CX872",
            originCode = "HKG",
            originCity = "Hong Kong",
            originAirportName = "Hong Kong International Airport",
            destCode = "SFO",
            destCity = "San Francisco",
            destAirportName = "San Francisco Intl",
            scheduledDeparture = "2026-09-24T01:10",
            scheduledArrival = "2026-09-23T22:30",
            estimatedDeparture = "2026-09-24T01:10",
            estimatedArrival = "2026-09-23T22:30",
            durationFormatted = "12h 20m",
            aircraftType = "Boeing 777-300ER",
            basePriceHkd = 21500,
            status = FlightStatusEnum.SCHEDULED,
            gate = "Gate 65",
            terminal = "T1",
            stops = 0,
            asiaMilesEarn = 5800,
            statusPointsEarn = 70
        ),
        Flight(
            id = "F006",
            flightNumber = "CX101",
            originCode = "HKG",
            originCity = "Hong Kong",
            originAirportName = "Hong Kong International Airport",
            destCode = "SYD",
            destCity = "Sydney",
            destAirportName = "Sydney Kingsford Smith",
            scheduledDeparture = "2026-09-23T23:55",
            scheduledArrival = "2026-09-24T11:10",
            estimatedDeparture = "2026-09-23T23:55",
            estimatedArrival = "2026-09-24T11:10",
            durationFormatted = "9h 15m",
            aircraftType = "Airbus A350-1000",
            basePriceHkd = 16400,
            status = FlightStatusEnum.SCHEDULED,
            gate = "Gate 28",
            terminal = "T1",
            stops = 0,
            asiaMilesEarn = 4200,
            statusPointsEarn = 55
        ),
        Flight(
            id = "F007",
            flightNumber = "CX261",
            originCode = "HKG",
            originCity = "Hong Kong",
            originAirportName = "Hong Kong International Airport",
            destCode = "CDG",
            destCity = "Paris",
            destAirportName = "Paris Charles de Gaulle",
            scheduledDeparture = "2026-09-24T00:05",
            scheduledArrival = "2026-09-24T07:15",
            estimatedDeparture = "2026-09-24T00:05",
            estimatedArrival = "2026-09-24T07:15",
            durationFormatted = "13h 10m",
            aircraftType = "Boeing 777-300ER",
            basePriceHkd = 22100,
            status = FlightStatusEnum.SCHEDULED,
            gate = "Gate 35",
            terminal = "T1",
            stops = 0,
            asiaMilesEarn = 5900,
            statusPointsEarn = 75
        ),
        Flight(
            id = "F008",
            flightNumber = "CX701",
            originCode = "HKG",
            originCity = "Hong Kong",
            originAirportName = "Hong Kong International Airport",
            destCode = "BKK",
            destCity = "Bangkok",
            destAirportName = "Suvarnabhumi Airport",
            scheduledDeparture = "2026-09-23T16:10",
            scheduledArrival = "2026-09-23T18:00",
            estimatedDeparture = "2026-09-23T16:10",
            estimatedArrival = "2026-09-23T18:00",
            durationFormatted = "2h 50m",
            aircraftType = "Airbus A330-300",
            basePriceHkd = 3800,
            status = FlightStatusEnum.CHECKIN_OPEN,
            gate = "Gate 19",
            terminal = "T1",
            stops = 0,
            asiaMilesEarn = 1050,
            statusPointsEarn = 18
        ),
        Flight(
            id = "F009",
            flightNumber = "CX418",
            originCode = "HKG",
            originCity = "Hong Kong",
            originAirportName = "Hong Kong International Airport",
            destCode = "ICN",
            destCity = "Seoul",
            destAirportName = "Incheon Intl Airport",
            scheduledDeparture = "2026-09-23T14:25",
            scheduledArrival = "2026-09-23T19:05",
            estimatedDeparture = "2026-09-23T14:25",
            estimatedArrival = "2026-09-23T19:05",
            durationFormatted = "3h 40m",
            aircraftType = "Airbus A350-900",
            basePriceHkd = 5200,
            status = FlightStatusEnum.CHECKIN_OPEN,
            gate = "Gate 22",
            terminal = "T1",
            stops = 0,
            asiaMilesEarn = 1300,
            statusPointsEarn = 22
        ),
        Flight(
            id = "F010",
            flightNumber = "CX252",
            originCode = "LHR",
            originCity = "London",
            originAirportName = "London Heathrow",
            destCode = "HKG",
            destCity = "Hong Kong",
            destAirportName = "Hong Kong International Airport",
            scheduledDeparture = "2026-09-23T12:20",
            scheduledArrival = "2026-09-24T07:10",
            estimatedDeparture = "2026-09-23T12:20",
            estimatedArrival = "2026-09-24T07:10",
            durationFormatted = "11h 50m",
            aircraftType = "Boeing 777-300ER",
            basePriceHkd = 25100,
            status = FlightStatusEnum.SCHEDULED,
            gate = "Gate C32",
            terminal = "T3",
            stops = 0,
            asiaMilesEarn = 5980,
            statusPointsEarn = 75
        ),
        Flight(
            id = "F011",
            flightNumber = "CX521",
            originCode = "NRT",
            originCity = "Tokyo",
            originAirportName = "Tokyo Narita Airport",
            destCode = "HKG",
            destCity = "Hong Kong",
            destAirportName = "Hong Kong International Airport",
            scheduledDeparture = "2026-09-23T16:45",
            scheduledArrival = "2026-09-23T20:40",
            estimatedDeparture = "2026-09-23T16:45",
            estimatedArrival = "2026-09-23T20:40",
            durationFormatted = "4h 55m",
            aircraftType = "Airbus A350-900",
            basePriceHkd = 7100,
            status = FlightStatusEnum.SCHEDULED,
            gate = "Gate 71",
            terminal = "T2",
            stops = 0,
            asiaMilesEarn = 1850,
            statusPointsEarn = 25
        ),
        Flight(
            id = "F012",
            flightNumber = "CX739",
            originCode = "SIN",
            originCity = "Singapore",
            originAirportName = "Singapore Changi Airport",
            destCode = "HKG",
            destCity = "Hong Kong",
            destAirportName = "Hong Kong International Airport",
            scheduledDeparture = "2026-09-23T11:20",
            scheduledArrival = "2026-09-23T15:15",
            estimatedDeparture = "2026-09-23T11:20",
            estimatedArrival = "2026-09-23T15:15",
            durationFormatted = "3h 55m",
            aircraftType = "Airbus A330-300",
            basePriceHkd = 4800,
            status = FlightStatusEnum.DEPARTED,
            gate = "Gate B4",
            terminal = "T4",
            stops = 0,
            asiaMilesEarn = 1200,
            statusPointsEarn = 20
        )
    )

    val samplePrimaryBooking = Booking(
        bookingReference = "CX-HKG882",
        passenger = samplePassenger,
        flight = sampleFlights[0], // CX257 HKG -> LHR
        returnFlight = sampleFlights[9], // CX252 LHR -> HKG
        cabinClass = CabinClass.BUSINESS,
        fareFamily = FareFamily.FLEX,
        selectedSeat = "12A",
        selectedMeal = "Pan-Seared Sea Bass with Ginger-Soy Glaze & Jasmine Rice",
        baggageAllowanceKg = 40,
        extraBaggageKg = 0,
        isCheckedIn = true,
        boardingGroup = "Group 1",
        gate = "Gate 31",
        boardingTime = "09:30 AM",
        insuranceAdded = true,
        totalPaidHkd = 38200,
        status = "Confirmed"
    )

    val sampleSecondaryBookings = listOf(
        Booking(
            bookingReference = "CX-TYO994",
            passenger = samplePassenger,
            flight = sampleFlights[1], // CX500 HKG -> HND
            cabinClass = CabinClass.PREMIUM_ECONOMY,
            fareFamily = FareFamily.ESSENTIAL,
            selectedSeat = "31K",
            selectedMeal = "Japanese Bento Box - Grilled Unagi",
            baggageAllowanceKg = 35,
            isCheckedIn = false,
            boardingGroup = "Group 2",
            gate = "Gate 24",
            boardingTime = "02:40 PM",
            totalPaidHkd = 8900,
            status = "Confirmed"
        ),
        Booking(
            bookingReference = "CX-SIN102",
            passenger = samplePassenger,
            flight = sampleFlights[2], // CX715 HKG -> SIN
            cabinClass = CabinClass.ECONOMY,
            fareFamily = FareFamily.LIGHT,
            selectedSeat = "48C",
            selectedMeal = "Hainanese Chicken Rice",
            baggageAllowanceKg = 23,
            isCheckedIn = false,
            boardingGroup = "Group 3",
            gate = "Gate 16",
            boardingTime = "07:20 PM",
            totalPaidHkd = 4900,
            status = "Confirmed"
        )
    )

    val sampleLounges = listOf(
        Lounge(
            id = "L01",
            name = "The Wing, First",
            airportCode = "HKG",
            terminal = "T1",
            openingHours = "05:30 AM - 00:30 AM",
            eligibility = "First Class Passengers & Diamond Members",
            amenities = listOf("Champagne Bar", "Private Cabanas", "A la carte Dining Room", "Full Bar", "Showers", "High-speed Wi-Fi"),
            diningDescription = "Fine dining menu crafted with fresh local and international ingredients, featuring signature Dan Dan Noodles and vintage champagne.",
            occupancyPercent = 42
        ),
        Lounge(
            id = "L02",
            name = "The Pier, Business",
            airportCode = "HKG",
            terminal = "T1 Near Gate 65",
            openingHours = "05:30 AM - 00:30 AM",
            eligibility = "Business Class Passengers, Gold/Silver Members, Oneworld Sapphire/Emerald",
            amenities = listOf("Noodle Bar", "Tea House", "Food Hall", "Relaxation Room", "Bureau Workstations", "14 Showers"),
            diningDescription = "Authentic noodle bar offering fresh Wonton Noodles and Dan Dan Mian, plus traditional herbal teas.",
            occupancyPercent = 68
        ),
        Lounge(
            id = "L03",
            name = "The Deck",
            airportCode = "HKG",
            terminal = "T1 Near Gate 6",
            openingHours = "05:30 AM - 00:30 AM",
            eligibility = "Business & First Class, Gold/Diamond Members",
            amenities = listOf("Open-air Balcony Terrace", "Noodle Bar", "Showers", "Relaxation Lounge"),
            diningDescription = "Panoramic runway views with fresh dim sum, wok-fried Asian specialties, and freshly brewed barista coffee.",
            occupancyPercent = 55
        ),
        Lounge(
            id = "L04",
            name = "Cathay Lounge London Heathrow",
            airportCode = "LHR",
            terminal = "T3 Near Gate 11",
            openingHours = "05:30 AM - 22:00 PM",
            eligibility = "First & Business Class Passengers, Cathay Members",
            amenities = listOf("Noodle Bar", "Full Cocktail Bar", "Private Showers", "Floor-to-ceiling Runway Views"),
            diningDescription = "Artisanal cocktails, British afternoon tea service, and signature noodle bar classics.",
            occupancyPercent = 38
        ),
        Lounge(
            id = "L05",
            name = "Cathay Lounge Tokyo Haneda",
            airportCode = "HND",
            terminal = "International Terminal 6F",
            openingHours = "07:30 AM - 17:00 PM",
            eligibility = "First & Business Class, Oneworld Emerald/Sapphire",
            amenities = listOf("Custom Noodle & Bento Bar", "Japanese Whiskey Bar", "Quiet Work Pods", "Scenic Mt. Fuji Views"),
            diningDescription = "Made-to-order Tonkotsu Ramen, Japanese curry rice, and seasonal wagashi desserts.",
            occupancyPercent = 48
        )
    )

    val sampleFacilities = listOf(
        AirportFacility("FAC01", "Gate 31 - CX257 Boarding", FacilityCategory.GATE, "T1", "Level 6 Departure Concourse", 4, 0, "Current departure gate for London Heathrow flight."),
        AirportFacility("FAC02", "The Pier, Business Lounge", FacilityCategory.LOUNGE, "T1", "Near Gate 65", 8, 2, "Premium lounge with Noodle Bar and Tea House."),
        AirportFacility("FAC03", "The Wing, First Lounge", FacilityCategory.LOUNGE, "T1", "Near Gate 1-4", 2, 0, "Exclusive First Class dining and private cabanas."),
        AirportFacility("FAC04", "Security Screening Zone A", FacilityCategory.SECURITY, "T1", "Departure Hall L7", 3, 6, "Express security clearance lane available for Business & First."),
        AirportFacility("FAC05", "e-Channel Immigration", FacilityCategory.IMMIGRATION, "T1", "Level 7", 2, 3, "Automated smart passport gates."),
        AirportFacility("FAC06", "Ho Lee Fook Pop-Up Dining", FacilityCategory.RESTAURANT, "T1", "Food Court Level 7", 5, 4, "Modern Hong Kong Cantonese roast meats & noodles."),
        AirportFacility("FAC07", "Cathay Duty Free Lifestyle", FacilityCategory.SHOP, "T1", "Level 6 Central Concourse", 4, 0, "Exclusive fragrances, watches, travel gear, and fine tea."),
        AirportFacility("FAC08", "Prayer & Quiet Meditation Room", FacilityCategory.PRAYER_ROOM, "T1", "Near Gate 42", 10, 0, "Quiet multi-faith prayer area."),
        AirportFacility("FAC09", "Accessible Restrooms & Nursery", FacilityCategory.ACCESSIBLE, "T1", "Near Gate 30", 3, 0, "Spacious accessible facilities with braille signage."),
        AirportFacility("FAC10", "APM Automated People Mover Station", FacilityCategory.TRANSFER, "T1", "Sub-level 1", 5, 2, "High-speed shuttle connecting Gates 1-80.")
    )

    val sampleAirports = listOf(
        Airport("HKG", "Hong Kong International Airport", "Hong Kong", "Hong Kong SAR", "T1", sampleFacilities),
        Airport("LHR", "London Heathrow Airport", "London", "United Kingdom", "T3", emptyList()),
        Airport("HND", "Tokyo Haneda Airport", "Tokyo", "Japan", "International Terminal", emptyList()),
        Airport("SIN", "Singapore Changi Airport", "Singapore", "Singapore", "T4", emptyList()),
        Airport("ICN", "Incheon International Airport", "Seoul", "South Korea", "T1", emptyList()),
        Airport("BKK", "Suvarnabhumi Airport", "Bangkok", "Thailand", "Main Terminal", emptyList())
    )

    val sampleLoyaltyTransactions = listOf(
        LoyaltyTransaction("TX1001", "2026-09-10", "Flight CX251 HKG to LHR (Business Class)", "EARN", 5980, 75),
        LoyaltyTransaction("TX1002", "2026-09-02", "The Peninsula Hong Kong Dining Partner", "EARN", 1250, 0),
        LoyaltyTransaction("TX1003", "2026-08-20", "Flight Upgrade HKG to HND (Economy to Business)", "REDEEM", -25000, 0),
        LoyaltyTransaction("TX1004", "2026-08-11", "Cathay Shop Duty Free Lifestyle Purchase", "EARN", 420, 0),
        LoyaltyTransaction("TX1005", "2026-07-28", "Flight CX888 HKG to YVR (Business Class)", "EARN", 5100, 65)
    )

    val sampleLoyaltyAccount = LoyaltyAccount(
        memberName = "Thomas Lee",
        memberNumber = "88392019",
        tier = LoyaltyTier.GOLD,
        asiaMilesBalance = 142800,
        statusPoints = 780,
        nextMilestonePoints = 1200,
        transactions = sampleLoyaltyTransactions
    )

    val sampleMeals = listOf(
        MealOption("M01", "Pan-Seared Sea Bass with Ginger-Soy Glaze", "Gourmet Asian", "Fresh Chilean sea bass served with steamed jasmine rice, pak choy, and ginger-soy reduction.", "Sea Bass, Soy, Ginger, Rice, Sesame", "Fish, Soy, Sesame"),
        MealOption("M02", "Roasted Black Angus Beef Tenderloin", "Western Fine Dining", "Grain-fed tenderloin with truffle potato mousseline, baby carrots, and rosemary jus.", "Beef, Potato, Cream, Rosemary, Truffle", "Dairy"),
        MealOption("M03", "Traditional Braised Abalone & Shiitake Mushrooms", "Hong Kong Signature", "Slow-braised premium abalone with dried scallops and supreme broth over egg noodles.", "Abalone, Scallop, Pork Broth, Wheat Noodles", "Mollusc, Crustacean, Wheat"),
        MealOption("M04", "Plant-Based Thai Green Curry (Vegan)", "Vegan / Vegetarian", "Fragrant Thai basil green curry with organic tofu, bamboo shoots, and coconut rice.", "Tofu, Coconut Milk, Green Curry, Lemongrass, Rice", "Soy"),
        MealOption("M05", "Steamed Halal Cod with Lemon Herbs", "Halal Certified", "Halal-certified cod fillet steamed with fresh Mediterranean herbs and olive oil quinoa.", "Halal Cod, Quinoa, Olive Oil, Lemon, Herbs", "Fish")
    )

    val sampleEntertainment = listOf(
        EntertainmentItem("E01", "Hong Kong Skyline: A Design Legacy", "Documentaries", 52, "Architecture", "PG", "An inside look into the iconic skyline and modern engineering marvels of Hong Kong."),
        EntertainmentItem("E02", "The Grand Eastern Express", "Films", 128, "Drama / Travel", "PG-13", "An elegant tale of international travelers crossing continents in luxury."),
        EntertainmentItem("E03", "Symphony of Victoria Harbour", "Music", 45, "Classical / Ambient", "G", "Relaxing acoustic soundscapes recorded in Victoria Harbour for inflight peace."),
        EntertainmentItem("E04", "Aviation Futures: Sustainable Skies", "Podcasts", 38, "Technology", "G", "Exploring zero-emission aviation, sustainable aviation fuel, and smart travel."),
        EntertainmentItem("E05", "Hong Kong Foodie Adventure 3D", "Games", 0, "Interactive Puzzle", "G", "A delightful puzzle game exploring dim sum markets and tea houses.")
    )

    val sampleShopProducts = listOf(
        ShopProduct("P01", "Cathay Limited Edition Leather Travel Wallet", "Travel Accessories", 1280, 18500, "Crafted from fine Italian calfskin with RFID protection and dual passport slots."),
        ShopProduct("P02", "A350 Titanium Aircraft Desktop Model (1:200)", "Lifestyle & Design", 890, 12800, "Precision-cast titanium alloy collector's item with wooden stand."),
        ShopProduct("P03", "Penhaligon's Juniper Sling Eau de Toilette (100ml)", "Fragrances", 1450, 21000, "Crisp gin-inspired fragrance with juniper, pepper, and warm amber notes."),
        ShopProduct("P04", "Bose QuietComfort Ultra Noise-Cancelling Headphones", "Electronics", 2980, 42000, "Immersive audio with custom aircraft noise-cancellation profiles.")
    )

    val sampleDocuments = listOf(
        TravelDocument("D01", "PASSPORT", "Hong Kong SAR Passport", "H88294012", "2031-10-20", true),
        TravelDocument("D02", "VISA", "UK eVISA Electronic Waiver", "UK-EV883921", "2027-05-12", true),
        TravelDocument("D03", "INSURANCE", "AIG Global Premium Travel Cover", "POL-9920194", "2026-10-01", true),
        TravelDocument("D04", "VACCINATION", "International Health Card", "WHO-88201", "2028-12-31", true)
    )

    val sampleNotifications = listOf(
        NotificationItem("N01", "10 min ago", "Flight CX257 Boarding Now", "Boarding Group 1 is now called at Gate 31. Please have your digital boarding pass ready.", false, true, "FLIGHT"),
        NotificationItem("N02", "30 min ago", "Lounge Access Reminder", "You are eligible for The Wing First & The Pier Business. Nearest lounge is 4 min walk.", false, false, "LOUNGE"),
        NotificationItem("N03", "2 hours ago", "Security Queue Express Lane", "Business Class security queue estimated time is under 3 minutes.", true, false, "AIRPORT"),
        NotificationItem("N04", " Yesterday", "Asia Miles Credited (+5,980)", "Your flight CX251 has been credited to your Gold loyalty account.", true, false, "LOYALTY")
    )

    val sampleDestinations = listOf(
        DestinationGuide("DEST01", "Hong Kong", "Hong Kong SAR", "City Breaks", "Where harbour lights meet dramatic mountain peaks.", "Oct - Dec", "Dim Sum & Egg Tarts", "Victoria Peak & Star Ferry", "Experience the vibrant energy, Michelin dining, and rich cultural heritage of Cathay's global home."),
        DestinationGuide("DEST02", "London", "United Kingdom", "Culture", "Timeless history, theatre, and contemporary design.", "May - Sep", "Afternoon Tea & Fish 'n' Chips", "British Museum & West End", "Immerse yourself in world-class museums, royal parks, and cutting-edge gastronomy."),
        DestinationGuide("DEST03", "Tokyo", "Japan", "Design", "Ultra-modern innovation meets centuries-old traditions.", "Mar - May", "Sashimi & Tonkotsu Ramen", "Shibuya Crossing & Meiji Shrine", "Discover Michelin dining, tranquil gardens, and neon-lit nightscapes."),
        DestinationGuide("DEST04", "Singapore", "Singapore", "City Breaks", "A futuristic garden city of botanical wonders.", "Year-round", "Hainanese Chicken Rice", "Gardens by the Bay", "Explore lush sky-gardens, hawker feasts, and world-class hospitality."),
        DestinationGuide("DEST05", "Vancouver", "Canada", "Nature", "Ocean breezes and snow-capped mountain horizons.", "Jun - Sep", "Wild Pacific Salmon", "Stanley Park & Whistler", "A serene coastal sanctuary blending mountain wilderness with urban elegance."),
        DestinationGuide("DEST06", "Paris", "France", "Culture", "Boulevards, haute couture, and timeless romance.", "Apr - Oct", "Croissants & Duck Confit", "Eiffel Tower & Musée du Louvre", "Indulge in art, world-renowned bakeries, and romantic Seine river cruises.")
    )
}
