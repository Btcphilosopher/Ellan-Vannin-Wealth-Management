package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.mock.SyntheticData
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    state: SimulationState,
    onNavigate: (String) -> Unit
) {
    val booking = state.primaryBooking
    val flight = booking.flight

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // Welcome Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Welcome back,",
                    color = CathayMutedGrey,
                    fontSize = 14.sp
                )
                Text(
                    text = "${state.passenger.firstName} ${state.passenger.lastName}",
                    color = CathayCharcoal,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Surface(
                color = CathayGoldLight,
                shape = RoundedCornerShape(16.dp),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CathayGoldAccent))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Stars, contentDescription = null, tint = CathayGoldAccent, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "GOLD MEMBER",
                        color = CathayCharcoal,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // HERO CARD: NEXT JOURNEY
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp)),
            colors = CardDefaults.cardColors(containerColor = CathayForestGreen),
            elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Header tag
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            color = CathayJade,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "NEXT JOURNEY",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Ref: ${booking.bookingReference}",
                            color = Color.White.copy(alpha = 0.7f),
                            fontSize = 12.sp
                        )
                    }

                    Surface(
                        color = Color.White.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = "Boarding in 45m",
                            color = CathayGoldAccent,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Route Overview
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(flight.originCode, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text(flight.originCity, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(flight.flightNumber, color = CathayJade, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            HorizontalDivider(modifier = Modifier.width(30.dp), color = CathayJade)
                            Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = CathayJade, modifier = Modifier.size(20.dp))
                            HorizontalDivider(modifier = Modifier.width(30.dp), color = CathayJade)
                        }
                        Text(flight.durationFormatted, color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(flight.destCode, color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                        Text(flight.destCity, color = Color.White.copy(alpha = 0.8f), fontSize = 13.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(12.dp))

                // Details Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Departure", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                        Text("10:15 AM", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("Gate 31 • T1", color = CathayGoldAccent, fontSize = 11.sp)
                    }
                    Column {
                        Text("Cabin / Seat", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                        Text("${booking.cabinClass.displayName} • ${booking.selectedSeat}", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("Group 1", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Aircraft", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                        Text(flight.aircraftType, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        Text("Boeing 777-300ER", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Primary Quick Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onNavigate("boarding") },
                        colors = ButtonDefaults.buttonColors(containerColor = CathayJade),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Boarding Pass", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { onNavigate("checkin") },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.5f))),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Check-In", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { onNavigate("trips") },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                        border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.5f))),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Manage", fontSize = 12.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // HERO BANNER VISUAL (Generated Editorial Image)
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(150.dp)
                .clip(RoundedCornerShape(16.dp))
                .clickable { onNavigate("destinations") },
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(id = R.drawable.cathay_hero_banner_1790153913051),
                    contentDescription = "Cathay Experience Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            androidx.compose.ui.graphics.Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.75f))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(16.dp)
                ) {
                    Text(
                        text = "DISCOVER HONG KONG & BEYOND",
                        color = CathayGoldAccent,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Curated Editorial Destination Guides",
                        color = Color.White,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // SECONDARY QUICK CARDS
        Text(
            text = "LOUNGE & TRAVEL SERVICES",
            color = CathayCharcoal,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Lounge Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigate("lounges") },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Icon(Icons.Default.Weekend, contentDescription = null, tint = CathayForestGreen, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("The Pier & Wing", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CathayCharcoal)
                    Text("Complimentary Lounge Access", fontSize = 11.sp, color = CathayMutedGrey)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Reserve Space →", fontSize = 11.sp, color = CathayJade, fontWeight = FontWeight.Bold)
                }
            }

            // Airport Wayfinding
            Card(
                modifier = Modifier
                    .weight(1f)
                    .clickable { onNavigate("airport") },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Icon(Icons.Default.Place, contentDescription = null, tint = CathayForestGreen, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Airport Companion", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CathayCharcoal)
                    Text("HKG Terminal 1 Gate Map", fontSize = 11.sp, color = CathayMutedGrey)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Navigate Gate 31 →", fontSize = 11.sp, color = CathayJade, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Asia Miles Overview Card
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onNavigate("loyalty") },
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = ButtonDefaults.outlinedButtonBorder
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("ASIA MILES & STATUS", fontSize = 11.sp, color = CathayMutedGrey, fontWeight = FontWeight.Bold)
                    Text("${state.loyaltyAccount.asiaMilesBalance} Miles", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = CathayCharcoal)
                    Text("${state.loyaltyAccount.statusPoints} / ${state.loyaltyAccount.nextMilestonePoints} Status Points to Diamond", fontSize = 11.sp, color = CathayMutedGrey)
                }
                Button(
                    onClick = { onNavigate("loyalty") },
                    colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)
                ) {
                    Text("Redeem", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}
