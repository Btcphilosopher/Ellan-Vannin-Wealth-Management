package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Weekend
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Lounge
import com.example.simulation.SimulationEngine
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@Composable
fun LoungesScreen(
    state: SimulationState
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("CATHAY LOUNGE DISCOVERY", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Sanctuaries of Calm & Culinary Excellence", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(state.lounges) { lounge ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(lounge.name, fontWeight = FontWeight.Bold, fontSize = 17.sp, color = CathayForestGreen)
                            Surface(
                                color = if (lounge.occupancyPercent < 50) CathayJadeLight else CathayGoldLight,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("${lounge.occupancyPercent}% Capacity", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = CathayCharcoal, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${lounge.airportCode} • ${lounge.terminal} • Open: ${lounge.openingHours}", fontSize = 12.sp, color = CathayMutedGrey)

                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Eligibility: ${lounge.eligibility}", fontSize = 11.sp, color = CathayGoldAccent, fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(lounge.diningDescription, fontSize = 12.sp, color = CathayCharcoal)

                        Spacer(modifier = Modifier.height(10.dp))

                        // Amenities Chips
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            lounge.amenities.take(3).forEach { am ->
                                Surface(
                                    color = Color(0xFFEFF2EE),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(am, fontSize = 10.sp, color = CathayMutedGrey, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { SimulationEngine.reserveLounge(lounge.id) },
                            enabled = !lounge.reserved,
                            colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (lounge.reserved) "Space Reserved ✓" else "Reserve Lounge Entry")
                        }
                    }
                }
            }
        }
    }
}
