package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.mock.SyntheticData
import com.example.data.model.*
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BookingScreen(
    state: SimulationState,
    onNavigate: (String) -> Unit
) {
    var activeStep by remember { mutableStateOf(0) } // 0: Search, 1: Results, 2: Fare Compare, 3: Passenger, 4: Seats, 5: Meals, 6: Confirmation
    var origin by remember { mutableStateOf("HKG") }
    var destination by remember { mutableStateOf("LHR") }
    var selectedCabin by remember { mutableStateOf(CabinClass.BUSINESS) }
    var selectedFlight by remember { mutableStateOf<Flight?>(SyntheticData.sampleFlights.first()) }
    var selectedFareFamily by remember { mutableStateOf(FareFamily.FLEX) }
    var selectedSeatNum by remember { mutableStateOf("12A") }
    var selectedMealName by remember { mutableStateOf("Pan-Seared Sea Bass with Ginger-Soy Glaze") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        // Step Header Bar
        Surface(
            color = CathayForestGreen,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text(
                    text = "FLIGHT RESERVATION ENGINE",
                    color = CathayGoldAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = when (activeStep) {
                        0 -> "Search Flights"
                        1 -> "Select Outbound Flight"
                        2 -> "Cabin & Fare Comparison"
                        3 -> "Passenger Information"
                        4 -> "Select Aircraft Seat"
                        5 -> "Inflight Culinary Selection"
                        else -> "Reservation Complete"
                    },
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                // Step Progress Pill Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (i in 0..5) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(4.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(if (i <= activeStep) CathayJade else Color.White.copy(alpha = 0.2f))
                        )
                    }
                }
            }
        }

        Box(modifier = Modifier.weight(1f)) {
            when (activeStep) {
                0 -> SearchFormStep(
                    origin = origin,
                    destination = destination,
                    selectedCabin = selectedCabin,
                    onOriginChange = { origin = it },
                    onDestChange = { destination = it },
                    onCabinChange = { selectedCabin = it },
                    onSearch = { activeStep = 1 }
                )
                1 -> SearchResultsStep(
                    flights = SyntheticData.sampleFlights,
                    selectedCabin = selectedCabin,
                    onSelectFlight = { flight ->
                        selectedFlight = flight
                        activeStep = 2
                    }
                )
                2 -> FareComparisonStep(
                    flight = selectedFlight ?: SyntheticData.sampleFlights.first(),
                    selectedFare = selectedFareFamily,
                    onSelectFare = { fare ->
                        selectedFareFamily = fare
                        activeStep = 3
                    }
                )
                3 -> PassengerDetailsStep(
                    passenger = state.passenger,
                    onConfirmPassenger = { activeStep = 4 }
                )
                4 -> SeatSelectionStep(
                    selectedSeat = selectedSeatNum,
                    onSeatSelected = { seat ->
                        selectedSeatNum = seat
                        activeStep = 5
                    }
                )
                5 -> MealSelectionStep(
                    meals = SyntheticData.sampleMeals,
                    selectedMeal = selectedMealName,
                    onMealSelected = { meal ->
                        selectedMealName = meal
                        activeStep = 6
                    }
                )
                6 -> ConfirmationStep(
                    flight = selectedFlight ?: SyntheticData.sampleFlights.first(),
                    seat = selectedSeatNum,
                    meal = selectedMealName,
                    fare = selectedFareFamily,
                    passenger = state.passenger,
                    onDone = { onNavigate("trips") }
                )
            }
        }
    }
}

@Composable
private fun SearchFormStep(
    origin: String,
    destination: String,
    selectedCabin: CabinClass,
    onOriginChange: (String) -> Unit,
    onDestChange: (String) -> Unit,
    onCabinChange: (CabinClass) -> Unit,
    onSearch: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = ButtonDefaults.outlinedButtonBorder,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("TRIP TYPE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CathayMutedGrey)
                Spacer(modifier = Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = true, onClick = {}, label = { Text("Return") })
                    FilterChip(selected = false, onClick = {}, label = { Text("One-Way") })
                    FilterChip(selected = false, onClick = {}, label = { Text("Multi-City") })
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Origin & Dest
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = origin,
                        onValueChange = onOriginChange,
                        label = { Text("Origin Airport") },
                        modifier = Modifier.weight(1f)
                    )
                    Icon(Icons.Default.SwapHoriz, contentDescription = "Swap", tint = CathayForestGreen)
                    OutlinedTextField(
                        value = destination,
                        onValueChange = onDestChange,
                        label = { Text("Destination") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("CABIN CLASS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CathayMutedGrey)
                Spacer(modifier = Modifier.height(6.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(CabinClass.values()) { cabin ->
                        FilterChip(
                            selected = selectedCabin == cabin,
                            onClick = { onCabinChange(cabin) },
                            label = { Text(cabin.displayName) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Direct Flights Only", fontSize = 14.sp, color = CathayCharcoal)
                    Switch(checked = true, onCheckedChange = {})
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onSearch,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)
                ) {
                    Icon(Icons.Default.Search, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Search Synthetic Flights", fontSize = 15.sp)
                }
            }
        }
    }
}

@Composable
private fun SearchResultsStep(
    flights: List<Flight>,
    selectedCabin: CabinClass,
    onSelectFlight: (Flight) -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Surface(
                color = CathayGoldLight,
                shape = RoundedCornerShape(8.dp),
                border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CathayGoldAccent))
            ) {
                Text(
                    text = "SYNTHETIC FARE — All prices, seat availability & mileage calculations are fictional simulation models.",
                    fontSize = 11.sp,
                    color = CathayCharcoal,
                    modifier = Modifier.padding(12.dp),
                    fontWeight = FontWeight.Medium
                )
            }
        }

        items(flights) { flight ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectFlight(flight) },
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(flight.flightNumber, color = CathayForestGreen, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("HKD $${flight.basePriceHkd}", color = CathayCharcoal, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(flight.scheduledDeparture.substringAfter("T"), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text(flight.originCode, fontSize = 12.sp, color = CathayMutedGrey)
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(flight.durationFormatted, fontSize = 11.sp, color = CathayMutedGrey)
                            HorizontalDivider(modifier = Modifier.width(60.dp), color = CathayJade)
                            Text("Direct", fontSize = 10.sp, color = CathayJade, fontWeight = FontWeight.Bold)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(flight.scheduledArrival.substringAfter("T"), fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text(flight.destCode, fontSize = 12.sp, color = CathayMutedGrey)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = CathayBorderGrey)
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Aircraft: ${flight.aircraftType}", fontSize = 11.sp, color = CathayMutedGrey)
                        Text("+${flight.asiaMilesEarn} Asia Miles", fontSize = 11.sp, color = CathayJade, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun FareComparisonStep(
    flight: Flight,
    selectedFare: FareFamily,
    onSelectFare: (FareFamily) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Select Fare Family for Flight ${flight.flightNumber}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        FareFamily.values().forEach { fare ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clickable { onSelectFare(fare) },
                colors = CardDefaults.cardColors(containerColor = if (selectedFare == fare) CathayJadeLight else Color.White),
                border = ButtonDefaults.outlinedButtonBorder
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(fare.displayName, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CathayForestGreen)
                        Text("HKD $${flight.basePriceHkd + if (fare == FareFamily.FLEX) 3600 else 0}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    fare.features.forEach { feature ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = CathayJade, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(feature, fontSize = 12.sp, color = CathayCharcoal)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PassengerDetailsStep(
    passenger: Passenger,
    onConfirmPassenger: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = ButtonDefaults.outlinedButtonBorder
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("PASSENGER DETAILS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CathayForestGreen)
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(value = "${passenger.title} ${passenger.firstName} ${passenger.lastName}", onValueChange = {}, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = passenger.passportNumber, onValueChange = {}, label = { Text("Passport Number") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(value = passenger.email, onValueChange = {}, label = { Text("Email Address") }, modifier = Modifier.fillMaxWidth())
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = onConfirmPassenger,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)
                ) {
                    Text("Confirm Passenger & Choose Seat")
                }
            }
        }
    }
}

@Composable
private fun SeatSelectionStep(
    selectedSeat: String,
    onSeatSelected: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Boeing 777-300ER Business Class Seat Map", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Select your preferred window or aisle seat:", fontSize = 12.sp, color = CathayMutedGrey)

        Spacer(modifier = Modifier.height(16.dp))

        val seats = listOf("11A", "11K", "12A", "12K", "15A", "15K", "16A", "16K")

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(seats) { seat ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSeatSelected(seat) },
                    colors = CardDefaults.cardColors(containerColor = if (selectedSeat == seat) CathayJadeLight else Color.White),
                    border = ButtonDefaults.outlinedButtonBorder
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AirlineSeatReclineExtra, contentDescription = null, tint = CathayForestGreen)
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text("Seat $seat", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("Window • Direct Aisle Access • Fully Flat Bed", fontSize = 11.sp, color = CathayMutedGrey)
                            }
                        }
                        if (selectedSeat == seat) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CathayJade)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MealSelectionStep(
    meals: List<MealOption>,
    selectedMeal: String,
    onMealSelected: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Inflight Gourmet Menu Selection", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text("Pre-select your signature inflight meal:", fontSize = 12.sp, color = CathayMutedGrey)

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(meals) { meal ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onMealSelected(meal.name) },
                    colors = CardDefaults.cardColors(containerColor = if (selectedMeal == meal.name) CathayJadeLight else Color.White),
                    border = ButtonDefaults.outlinedButtonBorder
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(meal.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = CathayForestGreen, modifier = Modifier.weight(1f))
                            if (selectedMeal == meal.name) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CathayJade)
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(meal.description, fontSize = 12.sp, color = CathayCharcoal)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Category: ${meal.category} • Allergens: ${meal.allergens}", fontSize = 10.sp, color = CathayMutedGrey)
                    }
                }
            }
        }
    }
}

@Composable
private fun ConfirmationStep(
    flight: Flight,
    seat: String,
    meal: String,
    fare: FareFamily,
    passenger: Passenger,
    onDone: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CathayJade, modifier = Modifier.size(64.dp))
        Spacer(modifier = Modifier.height(16.dp))
        Text("Synthetic Booking Reserved!", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = CathayForestGreen)
        Text("Your synthetic flight is linked to your itinerary.", fontSize = 12.sp, color = CathayMutedGrey)

        Spacer(modifier = Modifier.height(24.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = ButtonDefaults.outlinedButtonBorder,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("Booking Summary", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Passenger: ${passenger.firstName} ${passenger.lastName}", fontSize = 13.sp)
                Text("Flight: ${flight.flightNumber} (${flight.originCode} → ${flight.destCode})", fontSize = 13.sp)
                Text("Seat: $seat • Cabin: ${flight.aircraftType}", fontSize = 13.sp)
                Text("Meal: $meal", fontSize = 13.sp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onDone,
            colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("View in My Trips")
        }
    }
}
