package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@Composable
fun BoardingPassScreen(
    state: SimulationState
) {
    val booking = state.primaryBooking
    val flight = booking.flight

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Warning Banner
        Surface(
            color = CathayWarningBg,
            shape = RoundedCornerShape(8.dp),
            border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CathayWarningRed)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "DEMO BOARDING PASS — NOT VALID FOR TRAVEL",
                color = CathayWarningRed,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(10.dp)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Digital Boarding Pass Ticket Container
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp)),
            colors = CardDefaults.cardColors(containerColor = CathayForestGreen),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                // Airline Title
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("CATHAY PACIFIC", color = Color.White, fontWeight = FontWeight.Light, letterSpacing = 2.sp, fontSize = 16.sp)
                    Surface(color = CathayJade, shape = RoundedCornerShape(4.dp)) {
                        Text("BUSINESS CLASS", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Passenger Name
                Text("PASSENGER", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                Text("${booking.passenger.firstName} ${booking.passenger.lastName}", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(16.dp))

                // Route Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(flight.originCode, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        Text(flight.originCity, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(flight.flightNumber, color = CathayJade, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = CathayJade, modifier = Modifier.size(24.dp))
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(flight.destCode, color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        Text(flight.destCity, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.2f))
                Spacer(modifier = Modifier.height(16.dp))

                // Key Info Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("GATE", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                        Text(booking.gate, color = CathayGoldAccent, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("BOARDING TIME", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                        Text(booking.boardingTime, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("SEAT", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                        Text(booking.selectedSeat, color = CathayJade, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("GROUP", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                        Text("Group 1", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Synthetic QR / Barcode Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCode2,
                            contentDescription = "Synthetic QR",
                            tint = CathayCharcoal,
                            modifier = Modifier.size(120.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "M1LEE/THOMAS  E${booking.bookingReference} HKGLHR CX257 267C12A",
                            fontSize = 10.sp,
                            color = CathayMutedGrey,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }
    }
}
