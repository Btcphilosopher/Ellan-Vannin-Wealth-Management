package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CathayForestGreen
import com.example.ui.theme.CathayJade

sealed class NavItem(val route: String, val title: String, val icon: ImageVector) {
    object Home : NavItem("home", "Home", Icons.Default.Home)
    object Book : NavItem("book", "Book", Icons.Default.FlightTakeoff)
    object Trips : NavItem("trips", "My Trips", Icons.Default.ConfirmationNumber)
    object CheckIn : NavItem("checkin", "Check-In", Icons.Default.AssignmentTurnedIn)
    object Boarding : NavItem("boarding", "Pass", Icons.Default.QrCode)
    object Status : NavItem("status", "Status", Icons.Default.Schedule)
    object Airport : NavItem("airport", "Airport", Icons.Default.Place)
    object Lounges : NavItem("lounges", "Lounges", Icons.Default.Weekend)
    object Loyalty : NavItem("loyalty", "Miles", Icons.Default.Stars)
    object Inflight : NavItem("inflight", "Inflight", Icons.Default.AirplanemodeActive)
    object More : NavItem("more", "More", Icons.Default.Menu)
}

@Composable
fun AppBottomNav(
    currentRoute: String,
    onNavigate: (String) -> Unit
) {
    val items = listOf(
        NavItem.Home,
        NavItem.Book,
        NavItem.Trips,
        NavItem.CheckIn,
        NavItem.Boarding,
        NavItem.Status,
        NavItem.Airport,
        NavItem.Lounges,
        NavItem.Loyalty,
        NavItem.Inflight,
        NavItem.More
    )

    ScrollableTabRow(
        selectedTabIndex = items.indexOfFirst { it.route == currentRoute }.coerceAtLeast(0),
        containerColor = CathayForestGreen,
        contentColor = Color.White,
        edgePadding = 8.dp,
        indicator = {},
        divider = {},
        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
    ) {
        items.forEach { item ->
            val isSelected = currentRoute == item.route
            Tab(
                selected = isSelected,
                onClick = { onNavigate(item.route) },
                text = {
                    Text(
                        text = item.title,
                        fontSize = 11.sp,
                        color = if (isSelected) CathayJade else Color.White.copy(alpha = 0.7f)
                    )
                },
                icon = {
                    Icon(
                        imageVector = item.icon,
                        contentDescription = item.title,
                        tint = if (isSelected) CathayJade else Color.White.copy(alpha = 0.7f),
                        modifier = Modifier.size(20.dp)
                    )
                },
                modifier = Modifier.testTag("nav_${item.route}")
            )
        }
    }
}
