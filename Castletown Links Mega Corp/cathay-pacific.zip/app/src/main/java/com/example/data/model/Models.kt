package com.example.data.model

enum class CabinClass(val displayName: String) {
    ECONOMY("Economy"),
    PREMIUM_ECONOMY("Premium Economy"),
    BUSINESS("Business"),
    FIRST("First")
}

enum class FareFamily(val displayName: String, val features: List<String>) {
    LIGHT("Light", listOf("Hand baggage only", "Standard earning", "Fee for changes")),
    ESSENTIAL("Essential", listOf("1 x 23kg Checked baggage", "Standard seat selection", "Flexible changes")),
    FLEX("Flex", listOf("2 x 23kg Checked baggage", "Free seat selection", "Refundable", "Priority check-in"))
}

enum class FlightStatusEnum(val displayName: String) {
    SCHEDULED("Scheduled"),
    CHECKIN_OPEN("Check-in Open"),
    BOARDING_SOON("Boarding Soon"),
    BOARDING("Boarding"),
    GATE_CHANGED("Gate Changed"),
    DELAYED("Delayed"),
    DEPARTED("Departed"),
    AIRBORNE("Airborne"),
    LANDED("Landed"),
    BAGGAGE_RECLAIM("Baggage Reclaim"),
    COMPLETED("Completed"),
    CANCELLED("Cancelled")
}

data class Passenger(
    val id: String = "P1",
    val title: String = "Mr",
    val firstName: String = "Thomas",
    val lastName: String = "Lee",
    val dob: String = "1988-06-15",
    val nationality: String = "Hong Kong (SAR)",
    val passportNumber: String = "H88294012",
    val passportExpiry: String = "2031-10-20",
    val email: String = "thomas.lee@example.com",
    val phone: String = "+852 9123 4567",
    val emergencyContact: String = "Sarah Lee (+852 9876 5432)",
    val frequentFlyerNo: String = "CX-88392019",
    val specialAssistance: String = "None",
    val dietaryReqs: String = "Standard"
)

data class Flight(
    val id: String,
    val flightNumber: String,
    val originCode: String,
    val originCity: String,
    val originAirportName: String,
    val destCode: String,
    val destCity: String,
    val destAirportName: String,
    val scheduledDeparture: String, // e.g. "2026-09-23T10:15"
    val scheduledArrival: String,   // e.g. "2026-09-23T17:45"
    val estimatedDeparture: String,
    val estimatedArrival: String,
    val durationFormatted: String,
    val aircraftType: String,
    val basePriceHkd: Int,
    val status: FlightStatusEnum = FlightStatusEnum.SCHEDULED,
    val gate: String = "31",
    val terminal: String = "T1",
    val baggageBelt: String = "Belt 7",
    val stops: Int = 0,
    val asiaMilesEarn: Int = 5800,
    val statusPointsEarn: Int = 60,
    val operationalMessage: String = "Flight operating normally on schedule."
)

data class SeatInfo(
    val seatNumber: String,
    val cabin: CabinClass,
    val row: Int,
    val column: String,
    val isAvailable: Boolean = true,
    val isOccupied: Boolean = false,
    val isSelected: Boolean = false,
    val isExtraLegroom: Boolean = false,
    val isExitRow: Boolean = false,
    val isBassinet: Boolean = false,
    val extraFeeHkd: Int = 0
)

data class MealOption(
    val id: String,
    val name: String,
    val category: String,
    val description: String,
    val ingredients: String,
    val allergens: String,
    val serviceTiming: String = "After Takeoff"
)

data class Booking(
    val bookingReference: String = "CX-HKG882",
    val passenger: Passenger = Passenger(),
    val flight: Flight,
    val returnFlight: Flight? = null,
    val cabinClass: CabinClass = CabinClass.BUSINESS,
    val fareFamily: FareFamily = FareFamily.FLEX,
    val selectedSeat: String = "12A",
    val selectedMeal: String = "Pan-Seared Sea Bass with Ginger-Soy Glaze",
    val baggageAllowanceKg: Int = 40,
    val extraBaggageKg: Int = 0,
    val isCheckedIn: Boolean = true,
    val boardingGroup: String = "Group 1",
    val gate: String = "Gate 31",
    val boardingTime: String = "09:30 AM",
    val insuranceAdded: Boolean = true,
    val totalPaidHkd: Int = 28450,
    val status: String = "Confirmed"
)

enum class FacilityCategory {
    GATE, LOUNGE, RESTAURANT, SHOP, TOILET, PRAYER_ROOM, ACCESSIBLE, SECURITY, IMMIGRATION, BAGGAGE_CLAIM, TRANSFER
}

data class AirportFacility(
    val id: String,
    val name: String,
    val category: FacilityCategory,
    val terminal: String,
    val locationDescription: String,
    val walkingMinutesFromSecurity: Int,
    val queueMinutes: Int = 5,
    val description: String = ""
)

data class Airport(
    val code: String,
    val name: String,
    val city: String,
    val country: String,
    val terminal: String,
    val facilities: List<AirportFacility>
)

data class Lounge(
    val id: String,
    val name: String,
    val airportCode: String,
    val terminal: String,
    val openingHours: String,
    val eligibility: String,
    val amenities: List<String>,
    val diningDescription: String,
    val occupancyPercent: Int,
    val reserved: Boolean = false
)

enum class LoyaltyTier(val title: String, val requiredPoints: Int) {
    GREEN("Green", 0),
    SILVER("Silver", 300),
    GOLD("Gold", 600),
    DIAMOND("Diamond", 1200)
}

data class LoyaltyTransaction(
    val id: String,
    val date: String,
    val description: String,
    val type: String, // "EARN" or "REDEEM"
    val miles: Int,
    val statusPoints: Int
)

data class LoyaltyAccount(
    val memberName: String = "Thomas Lee",
    val memberNumber: String = "88392019",
    val tier: LoyaltyTier = LoyaltyTier.GOLD,
    val asiaMilesBalance: Int = 142800,
    val statusPoints: Int = 780,
    val nextMilestonePoints: Int = 1200,
    val transactions: List<LoyaltyTransaction> = emptyList()
)

data class InflightState(
    val flightNumber: String = "CX257",
    val currentAltitudeFt: Int = 38000,
    val groundSpeedKts: Int = 515,
    val remainingMinutes: Int = 280,
    val progressPercent: Float = 0.58f,
    val localTimeDestination: String = "11:45 AM GMT",
    val currentMealService: String = "Mid-flight Refreshments & Dim Sum",
    val wifiConnected: Boolean = true,
    val wifiPackage: String = "Flight Pass (Complimentary Business)",
    val crewRequestStatus: String = "No Active Request"
)

data class EntertainmentItem(
    val id: String,
    val title: String,
    val category: String, // "Films", "TV", "Music", "Podcasts", "Games"
    val durationMinutes: Int,
    val genre: String,
    val rating: String,
    val synopsis: String,
    val isFavorite: Boolean = false,
    val isPlaying: Boolean = false
)

data class ShopProduct(
    val id: String,
    val name: String,
    val category: String,
    val priceHkd: Int,
    val priceMiles: Int,
    val description: String,
    val inCartQuantity: Int = 0
)

data class TravelDocument(
    val id: String,
    val type: String, // "PASSPORT", "VISA", "INSURANCE", "VACCINATION"
    val title: String,
    val docNumber: String,
    val expiryDate: String,
    val isVerified: Boolean = true,
    val warningMessage: String? = null
)

data class NotificationItem(
    val id: String,
    val timeLabel: String,
    val title: String,
    val message: String,
    val isRead: Boolean = false,
    val isPriority: Boolean = false,
    val category: String = "FLIGHT"
)

data class SupportTicket(
    val id: String,
    val category: String,
    val status: String, // "OPEN", "IN_PROGRESS", "RESOLVED"
    val timestamp: String,
    val lastMessage: String
)

data class DisruptionEvent(
    val id: String,
    val flightNumber: String,
    val type: String, // "DELAY", "GATE_CHANGE", "CANCELLED", "MISSED_CONNECTION"
    val title: String,
    val description: String,
    val actionOptions: List<String>,
    val isResolved: Boolean = false
)

data class DestinationGuide(
    val id: String,
    val city: String,
    val country: String,
    val category: String,
    val tagLine: String,
    val bestSeason: String,
    val highlightFood: String,
    val topAttraction: String,
    val introduction: String
)
