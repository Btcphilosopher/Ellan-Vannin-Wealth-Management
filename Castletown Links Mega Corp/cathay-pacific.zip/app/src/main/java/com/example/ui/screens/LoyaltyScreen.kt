package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.simulation.SimulationEngine
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@Composable
fun LoyaltyScreen(
    state: SimulationState
) {
    val account = state.loyaltyAccount
    var redeemDialogOpen by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        // Gold Member Card
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("CATHAY MEMBERSHIP", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(account.memberName, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Member ID: ${account.memberNumber}", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                    }

                    Surface(color = CathayGoldLight, shape = RoundedCornerShape(12.dp)) {
                        Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Stars, contentDescription = null, tint = CathayGoldAccent, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(account.tier.title.uppercase(), color = CathayCharcoal, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Miles Balance
                Text("ASIA MILES BALANCE", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
                Text("${account.asiaMilesBalance} Miles", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(12.dp))

                // Status Bar
                Text("STATUS POINTS PROGRESS TO DIAMOND (${account.statusPoints} / ${account.nextMilestonePoints})", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                LinearProgressIndicator(
                    progress = { account.statusPoints.toFloat() / account.nextMilestonePoints.toFloat() },
                    modifier = Modifier.fillMaxWidth(),
                    color = CathayGoldAccent,
                    trackColor = Color.White.copy(alpha = 0.2f)
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("RECENT TRANSACTIONS", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CathayCharcoal)
                    Button(
                        onClick = { redeemDialogOpen = true },
                        colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)
                    ) {
                        Text("Redeem Rewards")
                    }
                }
            }

            items(account.transactions) { tx ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(tx.description, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = CathayCharcoal)
                            Text("Date: ${tx.date}", fontSize = 11.sp, color = CathayMutedGrey)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = if (tx.miles > 0) "+${tx.miles} Miles" else "${tx.miles} Miles",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = if (tx.miles > 0) CathayJade else CathayWarningRed
                            )
                            if (tx.statusPoints > 0) {
                                Text("+${tx.statusPoints} Status Pts", fontSize = 11.sp, color = CathayGoldAccent)
                            }
                        }
                    }
                }
            }
        }
    }

    if (redeemDialogOpen) {
        AlertDialog(
            onDismissRequest = { redeemDialogOpen = false },
            title = { Text("Redeem Asia Miles") },
            text = { Text("Redeem 25,000 Asia Miles for a One-Way Business Class Flight Upgrade?") },
            confirmButton = {
                Button(onClick = {
                    SimulationEngine.redeemMiles(25000, "One-Way Business Upgrade")
                    redeemDialogOpen = false
                }) {
                    Text("Confirm 25,000 Miles Redemption")
                }
            },
            dismissButton = {
                TextButton(onClick = { redeemDialogOpen = false }) { Text("Cancel") }
            }
        )
    }
}
