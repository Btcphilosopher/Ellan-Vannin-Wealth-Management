package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cathay Pacific inspired Palette
val CathayForestGreen = Color(0xFF003126)
val CathayDeepGreen = Color(0xFF0B251C)
val CathayJade = Color(0xFF1DA07E)
val CathayJadeLight = Color(0xFFE2F6F0)
val CathayJadeDark = Color(0xFF0A4335)
val CathayIvory = Color(0xFFF8F9F7)
val CathayIvoryCard = Color(0xFFFFFFFF)
val CathayCharcoal = Color(0xFF191C1B)
val CathayMutedGrey = Color(0xFF6F7975)
val CathayBorderGrey = Color(0xFFE0E4E1)
val CathayGoldAccent = Color(0xFFC6A875)
val CathayGoldLight = Color(0xFFF9F5EB)
val CathayWarningRed = Color(0xFFBA1A1A)
val CathayWarningBg = Color(0xFFFFDAD6)
val CathayAlertOrange = Color(0xFFD97706)
val CathayAlertBg = Color(0xFFFEF3C7)

val DarkCathayBackground = Color(0xFF08120F)
val DarkCathaySurface = Color(0xFF12231E)
val DarkCathayCard = Color(0xFF1A2F29)
val DarkCathayOnSurface = Color(0xFFE1E4E1)
