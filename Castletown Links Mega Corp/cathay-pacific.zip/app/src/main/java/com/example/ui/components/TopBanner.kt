package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.simulation.SimulationEngine
import com.example.simulation.SimulationState
import com.example.ui.theme.CathayForestGreen
import com.example.ui.theme.CathayGoldAccent
import com.example.ui.theme.CathayJade

@Composable
fun TopBanner(
    state: SimulationState,
    onOpenSimControls: () -> Unit,
    onOpenNotifications: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(CathayForestGreen)
    ) {
        // Prototype Banner
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF00221A))
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "CONCEPT PROTOTYPE — SIMULATED TRAVEL DATA",
                color = CathayGoldAccent,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = state.simDateFormatted,
                    color = Color.White.copy(alpha = 0.8f),
                    fontSize = 11.sp
                )
                Icon(
                    imageVector = if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = "Sim Toggle",
                    tint = CathayJade,
                    modifier = Modifier
                        .size(16.dp)
                        .clickable { SimulationEngine.togglePlayPause() }
                )
            }
        }

        // Header Title Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "CATHAY PACIFIC",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Light,
                    letterSpacing = 2.sp
                )
            }

            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                // Notifications Icon with badge
                val unreadCount = state.notifications.count { !it.isRead }
                BadgedBox(
                    badge = {
                        if (unreadCount > 0) {
                            Badge(containerColor = CathayGoldAccent) {
                                Text("$unreadCount", color = CathayForestGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    },
                    modifier = Modifier.clickable { onOpenNotifications() }
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Ops & Simulation Trigger Button
                IconButton(
                    onClick = onOpenSimControls,
                    modifier = Modifier
                        .size(36.dp)
                        .background(CathayJade.copy(alpha = 0.2f), shape = MaterialTheme.shapes.small)
                ) {
                    Icon(
                        imageVector = Icons.Default.Build,
                        contentDescription = "Simulation Controls",
                        tint = CathayJade,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}
