package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.simulation.SimulationEngine
import com.example.simulation.SimulationState
import com.example.ui.theme.CathayForestGreen
import com.example.ui.theme.CathayGoldAccent
import com.example.ui.theme.CathayJade
import com.example.ui.theme.CathayWarningRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimulationControlsSheet(
    state: SimulationState,
    onDismiss: () -> Unit,
    onNavigateToOps: () -> Unit,
    onNavigateToDisruption: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF0F201B)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .verticalScroll(rememberScrollState())
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SIMULATION CONTROL ENGINE",
                    color = CathayGoldAccent,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            Text(
                text = "Simulate real-world flight operations, delays, gate changes, and travel recovery scenarios across the passenger ecosystem.",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 13.sp,
                modifier = Modifier.padding(vertical = 8.dp)
            )

            HorizontalDivider(color = Color.White.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 12.dp))

            // Time Controls
            Text(
                text = "SIMULATED TIME CONTROL",
                color = CathayJade,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { SimulationEngine.togglePlayPause() },
                    colors = ButtonDefaults.buttonColors(containerColor = if (state.isPlaying) CathayWarningRed else CathayJade),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(if (state.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (state.isPlaying) "Pause Time" else "Play Time", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = { SimulationEngine.advanceHours(1) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("+1 Hour", fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = { SimulationEngine.advanceDays(1) },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("+1 Day", fontSize = 12.sp)
                }
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 16.dp))

            // Scenario Triggers
            Text(
                text = "TRIGGER DISRUPTION SCENARIOS",
                color = CathayGoldAccent,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        SimulationEngine.triggerFlightDelay()
                        onNavigateToDisruption()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                ) {
                    Icon(Icons.Default.Schedule, contentDescription = null, tint = CathayGoldAccent, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Trigger Flight Delay (CX257 +1h 15m)", fontSize = 13.sp)
                }

                OutlinedButton(
                    onClick = {
                        SimulationEngine.triggerGateChange()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                ) {
                    Icon(Icons.Default.MeetingRoom, contentDescription = null, tint = CathayJade, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Trigger Gate Change (Gate 31 → Gate 18)", fontSize = 13.sp)
                }

                OutlinedButton(
                    onClick = {
                        SimulationEngine.triggerMissedConnection()
                        onNavigateToDisruption()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                ) {
                    Icon(Icons.Default.SyncProblem, contentDescription = null, tint = CathayWarningRed, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Trigger Missed Connection Recovery", fontSize = 13.sp)
                }

                OutlinedButton(
                    onClick = {
                        SimulationEngine.triggerBaggageDelay()
                        onNavigateToDisruption()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                ) {
                    Icon(Icons.Default.Luggage, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Trigger Baggage Sorting Delay", fontSize = 13.sp)
                }
            }

            HorizontalDivider(color = Color.White.copy(alpha = 0.15f), modifier = Modifier.padding(vertical = 16.dp))

            // Operations Workspace Link
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = {
                        onNavigateToOps()
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(Icons.Default.FlightTakeoff, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Open Flight Operations Dashboard", fontSize = 12.sp)
                }

                Spacer(modifier = Modifier.width(8.dp))

                TextButton(
                    onClick = { SimulationEngine.resetSimulation() }
                ) {
                    Text("Reset Sim", color = CathayWarningRed, fontSize = 12.sp)
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
