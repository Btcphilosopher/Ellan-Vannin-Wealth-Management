package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.simulation.SimulationEngine
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@Composable
fun InflightScreen(
    state: SimulationState
) {
    val inflight = state.inflightState
    var playingMediaId by remember { mutableStateOf<String?>(null) }
    var crewRequested by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        // Flight Radar Header
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("INFLIGHT ONBOARD COMPANION", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Flight CX257 • Cruise Altitude", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("ALTITUDE", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                        Text("${inflight.currentAltitudeFt} FT", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("GROUND SPEED", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                        Text("${inflight.groundSpeedKts} KTS", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                    Column {
                        Text("REMAINING", color = Color.White.copy(alpha = 0.6f), fontSize = 10.sp)
                        Text("4h 40m", color = CathayGoldAccent, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                LinearProgressIndicator(
                    progress = { inflight.progressPercent },
                    modifier = Modifier.fillMaxWidth(),
                    color = CathayJade,
                    trackColor = Color.White.copy(alpha = 0.2f)
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Wi-Fi Controls Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("INFLIGHT SATELLITE WI-FI", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(if (inflight.wifiConnected) "Connected • ${inflight.wifiPackage}" else "Wi-Fi Disconnected", fontSize = 12.sp, color = CathayMutedGrey)
                        }
                        Switch(
                            checked = inflight.wifiConnected,
                            onCheckedChange = { SimulationEngine.toggleWifi(it) }
                        )
                    }
                }
            }

            // Crew Call Button Card
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("CABIN CREW ASSISTANCE", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Request extra pillow, water, or dining service.", fontSize = 12.sp, color = CathayMutedGrey)
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = { crewRequested = !crewRequested },
                            colors = ButtonDefaults.buttonColors(containerColor = if (crewRequested) CathayGoldAccent else CathayForestGreen),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(if (crewRequested) "Crew Notified ✓" else "Call Cabin Crew")
                        }
                    }
                }
            }

            // Inflight Entertainment Catalogue
            item {
                Text("INFLIGHT ENTERTAINMENT CATALOGUE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CathayMutedGrey)
            }

            items(state.entertainmentList) { item ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = CathayForestGreen)
                            Text("${item.category} • ${item.durationMinutes} mins • ${item.genre}", fontSize = 11.sp, color = CathayMutedGrey)
                            Text(item.synopsis, fontSize = 11.sp, color = CathayCharcoal, maxLines = 2)
                        }
                        IconButton(onClick = { playingMediaId = if (playingMediaId == item.id) null else item.id }) {
                            Icon(
                                imageVector = if (playingMediaId == item.id) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                                contentDescription = "Play",
                                tint = CathayJade,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
