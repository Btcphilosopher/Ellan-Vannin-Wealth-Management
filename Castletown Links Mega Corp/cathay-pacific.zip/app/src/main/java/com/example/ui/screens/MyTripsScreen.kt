package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.simulation.SimulationEngine
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@Composable
fun MyTripsScreen(
    state: SimulationState,
    onNavigate: (String) -> Unit
) {
    var selectedView by remember { mutableStateOf(0) } // 0: Timeline, 1: Calendar, 2: Map, 3: Documents
    val booking = state.primaryBooking
    var showBaggageDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        // Header
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("ITINERARY & TRIP MANAGER", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Hong Kong → London Journey", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(12.dp))

                // View Selector
                TabRow(
                    selectedTabIndex = selectedView,
                    containerColor = Color.Transparent,
                    contentColor = CathayJade,
                    divider = {}
                ) {
                    Tab(selected = selectedView == 0, onClick = { selectedView = 0 }, text = { Text("Timeline", fontSize = 12.sp, color = Color.White) })
                    Tab(selected = selectedView == 1, onClick = { selectedView = 1 }, text = { Text("Calendar", fontSize = 12.sp, color = Color.White) })
                    Tab(selected = selectedView == 2, onClick = { selectedView = 2 }, text = { Text("Route Map", fontSize = 12.sp, color = Color.White) })
                    Tab(selected = selectedView == 3, onClick = { selectedView = 3 }, text = { Text("Docs", fontSize = 12.sp, color = Color.White) })
                }
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            when (selectedView) {
                0 -> {
                    // Timeline View
                    item {
                        Text("ACTIVE JOURNEY TIMELINE", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CathayMutedGrey)
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = ButtonDefaults.outlinedButtonBorder,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = CathayForestGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Outbound Flight • CX257", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Hong Kong (HKG) → London Heathrow (LHR)", fontSize = 13.sp, color = CathayCharcoal)
                                Text("Departure: 10:15 AM • Gate 31", fontSize = 12.sp, color = CathayMutedGrey)
                                Text("Seat: ${booking.selectedSeat} • Meal: ${booking.selectedMeal}", fontSize = 12.sp, color = CathayJade, fontWeight = FontWeight.Bold)

                                Spacer(modifier = Modifier.height(12.dp))
                                HorizontalDivider(color = CathayBorderGrey)
                                Spacer(modifier = Modifier.height(8.dp))

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { showBaggageDialog = true }) {
                                        Text("+ Baggage (${booking.extraBaggageKg}kg)", fontSize = 11.sp)
                                    }
                                    OutlinedButton(onClick = { onNavigate("boarding") }) {
                                        Text("Boarding Pass", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = ButtonDefaults.outlinedButtonBorder,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Hotel, contentDescription = null, tint = CathayForestGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Hotel Reservation • The Savoy London", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                }
                                Text("Check-in: Sep 23, 15:00 • Deluxe River View Suite", fontSize = 12.sp, color = CathayMutedGrey)
                            }
                        }
                    }

                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = ButtonDefaults.outlinedButtonBorder,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = CathayForestGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Chauffeur Airport Transfer", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                }
                                Text("LHR Terminal 3 → Central London Hotel", fontSize = 12.sp, color = CathayMutedGrey)
                            }
                        }
                    }
                }

                1 -> {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("September 2026 Trip Calendar", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("• Sep 23: CX257 HKG → LHR Departure (10:15 AM)", fontSize = 13.sp)
                                Text("• Sep 23 - Sep 28: London Hotel Stay", fontSize = 13.sp)
                                Text("• Sep 28: CX252 LHR → HKG Return (12:20 PM)", fontSize = 13.sp)
                            }
                        }
                    }
                }

                2 -> {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = CathayForestGreen), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Intercontinental Route Map", color = Color.White, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Great Circle Track: HKG → LHR (9,630 km)", color = CathayGoldAccent, fontSize = 12.sp)
                                Text("Waypoints: Hong Kong • Chengdu • Tashkent • Warsaw • London", color = Color.White.copy(alpha = 0.8f), fontSize = 11.sp)
                            }
                        }
                    }
                }

                3 -> {
                    item {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("Travel Documents Checklist", fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(8.dp))
                                Text("✓ Passport Valid (Exp: Oct 2031)", fontSize = 12.sp, color = CathayJade)
                                Text("✓ UK eVISA Confirmed", fontSize = 12.sp, color = CathayJade)
                                Text("✓ Travel Insurance Active", fontSize = 12.sp, color = CathayJade)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showBaggageDialog) {
        AlertDialog(
            onDismissRequest = { showBaggageDialog = false },
            title = { Text("Add Extra Baggage") },
            text = { Text("Standard Allowance: 40kg. Add +10kg extra baggage for HKD 1,200?") },
            confirmButton = {
                Button(onClick = {
                    SimulationEngine.addBaggage(10)
                    showBaggageDialog = false
                }) {
                    Text("Add 10kg (+HKD 1,200)")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBaggageDialog = false }) { Text("Cancel") }
            }
        )
    }
}
