package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.mock.SyntheticData
import com.example.data.model.AirportFacility
import com.example.data.model.FacilityCategory
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@Composable
fun AirportScreen(
    state: SimulationState
) {
    var selectedAirportCode by remember { mutableStateOf("HKG") }
    var activeCategoryFilter by remember { mutableStateOf<FacilityCategory?>(null) }
    var activeRouteTarget by remember { mutableStateOf<AirportFacility?>(null) }

    val currentAirport = state.airports.find { it.code == selectedAirportCode } ?: state.airports.first()
    val filteredFacilities = currentAirport.facilities.filter {
        activeCategoryFilter == null || it.category == activeCategoryFilter
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("AIRPORT WAYFINDING & COMPANION", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(currentAirport.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(12.dp))

                // Airport Selector Row
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(state.airports) { ap ->
                        FilterChip(
                            selected = ap.code == selectedAirportCode,
                            onClick = { selectedAirportCode = ap.code },
                            label = { Text("${ap.code} - ${ap.city}") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CathayJade,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        Column(modifier = Modifier.padding(16.dp)) {
            // Quick Navigation Action Buttons
            Text("QUICK WAYFINDING", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = CathayMutedGrey)
            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { activeCategoryFilter = FacilityCategory.GATE },
                    colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Gate 31", fontSize = 11.sp)
                }
                Button(
                    onClick = { activeCategoryFilter = FacilityCategory.LOUNGE },
                    colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Lounges", fontSize = 11.sp)
                }
                Button(
                    onClick = { activeCategoryFilter = FacilityCategory.RESTAURANT },
                    colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen),
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Food", fontSize = 11.sp)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Active Route Banner if selected
            activeRouteTarget?.let { fac ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = CathayJadeLight),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(CathayJade)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ROUTE PLANNER ACTIVE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = CathayForestGreen)
                            IconButton(onClick = { activeRouteTarget = null }) {
                                Icon(Icons.Default.Close, contentDescription = null, tint = CathayForestGreen, modifier = Modifier.size(16.dp))
                            }
                        }
                        Text("Destination: ${fac.name}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = CathayCharcoal)
                        Text("Estimated Walking Time: ${fac.walkingMinutesFromSecurity} mins from current position.", fontSize = 12.sp, color = CathayMutedGrey)
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // Facilities List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(filteredFacilities) { fac ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = ButtonDefaults.outlinedButtonBorder,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(fac.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CathayForestGreen)
                                Text("${fac.terminal} • ${fac.locationDescription}", fontSize = 12.sp, color = CathayMutedGrey)
                                Text("Walk: ~${fac.walkingMinutesFromSecurity} mins • Queue: ~${fac.queueMinutes} mins", fontSize = 11.sp, color = CathayJade, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { activeRouteTarget = fac },
                                colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)
                            ) {
                                Text("Navigate", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}
