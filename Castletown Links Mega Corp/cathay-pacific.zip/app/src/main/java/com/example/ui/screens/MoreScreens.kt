package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.mock.SyntheticData
import com.example.simulation.SimulationEngine
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@Composable
fun MoreHubScreen(
    onNavigateTo: (String) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
            .padding(16.dp)
    ) {
        Text("MORE CATHAY SERVICES", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = CathayForestGreen)
        Text("Complete Passenger Operating Environment", fontSize = 12.sp, color = CathayMutedGrey)

        Spacer(modifier = Modifier.height(16.dp))

        val menuItems = listOf(
            Triple("shop", "Cathay Shop Duty Free", Icons.Default.ShoppingBag),
            Triple("documents", "Travel Document Centre", Icons.Default.Folder),
            Triple("assistant", "Digital Travel Assistant", Icons.Default.SmartToy),
            Triple("disruption", "Travel Recovery Workspace", Icons.Default.Warning),
            Triple("notifications", "Notification Centre", Icons.Default.Notifications),
            Triple("support", "Customer Support & Chat", Icons.Default.SupportAgent),
            Triple("operations", "Airline Flight Operations Simulator", Icons.Default.AirplanemodeActive)
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(menuItems) { (route, title, icon) ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onNavigateTo(route) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(icon, contentDescription = null, tint = CathayForestGreen, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CathayCharcoal, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = CathayMutedGrey)
                    }
                }
            }
        }
    }
}

@Composable
fun CathayShopScreen(state: SimulationState) {
    var checkoutDone by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("CATHAY SHOP DUTY FREE", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Curated Luxury & Travel Accessories", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(SyntheticData.sampleShopProducts) { prod ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(prod.name, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = CathayForestGreen)
                        Text(prod.description, fontSize = 12.sp, color = CathayMutedGrey)
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("HKD $${prod.priceHkd} • ${prod.priceMiles} Miles", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Button(
                                onClick = { SimulationEngine.addToCart(prod) },
                                colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)
                            ) {
                                Text("Add to Cart")
                            }
                        }
                    }
                }
            }

            if (state.shopCart.isNotEmpty()) {
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = CathayJadeLight), modifier = Modifier.fillMaxWidth()) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("CART TOTAL (${state.shopCart.sumOf { it.inCartQuantity }} Items)", fontWeight = FontWeight.Bold)
                            Text("Total: HKD $${state.shopCart.sumOf { it.priceHkd * it.inCartQuantity }}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(8.dp))
                            Button(
                                onClick = {
                                    checkoutDone = true
                                    SimulationEngine.clearCart()
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Complete Duty Free Order Simulation")
                            }
                        }
                    }
                }
            }
        }
    }

    if (checkoutDone) {
        AlertDialog(
            onDismissRequest = { checkoutDone = false },
            title = { Text("Order Confirmed") },
            text = { Text("Your duty free order will be delivered directly to seat 12A on flight CX257.") },
            confirmButton = { Button(onClick = { checkoutDone = false }) { Text("OK") } }
        )
    }
}

@Composable
fun AssistantScreen(state: SimulationState) {
    var query by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("Hello Thomas! I am your Cathay Concierge Assistant. Ask me about flight CX257, lounge access, baggage rules, or connection plans.")) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("DIGITAL TRAVEL ASSISTANT", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Intelligent Passenger Concierge", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        Column(modifier = Modifier.weight(1f).padding(16.dp)) {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages) { msg ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                        Text(msg, modifier = Modifier.padding(12.dp), fontSize = 13.sp)
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    placeholder = { Text("Ask about CX257, lounge, or gate...") },
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(onClick = {
                    if (query.isNotBlank()) {
                        val reply = "Based on simulated data for flight CX257: Departure is 10:15 AM at Gate 31. Lounge access: The Wing First & The Pier Business."
                        messages = messages + "You: $query" + "Cathay Assistant: $reply"
                        query = ""
                    }
                }) {
                    Icon(Icons.Default.Send, contentDescription = "Send", tint = CathayForestGreen)
                }
            }
        }
    }
}

@Composable
fun DisruptionScreen(state: SimulationState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("TRAVEL RECOVERY WORKSPACE", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Proactive Disruption Management", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (state.activeDisruptions.isEmpty()) {
                item {
                    Text("No active flight disruptions. All flights operating normally on schedule.", fontSize = 14.sp, color = CathayMutedGrey)
                }
            } else {
                items(state.activeDisruptions) { dis ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White), border = ButtonDefaults.outlinedButtonBorder) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(dis.title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CathayWarningRed)
                            Text(dis.description, fontSize = 12.sp, color = CathayCharcoal)
                            Spacer(modifier = Modifier.height(12.dp))
                            dis.actionOptions.forEach { opt ->
                                Button(
                                    onClick = {},
                                    colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                                ) {
                                    Text(opt, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun OperationsScreen(state: SimulationState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("AIRLINE FLIGHT OPERATIONS SIMULATOR", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Operational Ecosystem Dashboard", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Active Fleet Status", fontWeight = FontWeight.Bold)
                        Text("12 Active Flights • 8 Aircraft • 6 Hub Airports", fontSize = 12.sp, color = CathayMutedGrey)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("• CX257 (B77W): Boarding at HKG Gate 31")
                        Text("• CX500 (A351): Check-in Open at HKG Gate 24")
                        Text("• CX739 (A333): Airborne SIN → HKG")
                    }
                }
            }
        }
    }
}

@Composable
fun DocumentsScreen(state: SimulationState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("TRAVEL DOCUMENT CENTRE", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Secure Passport & Visa Workspace", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(state.documents) { doc ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), border = ButtonDefaults.outlinedButtonBorder) {
                    Row(modifier = Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(doc.title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            Text("Number: ${doc.docNumber} • Expiry: ${doc.expiryDate}", fontSize = 12.sp, color = CathayMutedGrey)
                        }
                        Text("✓ Verified", color = CathayJade, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
fun NotificationsScreen(state: SimulationState) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("NOTIFICATION CENTRE", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Flight & Airport Alerts", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(state.notifications) { notif ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), border = ButtonDefaults.outlinedButtonBorder) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(notif.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = CathayForestGreen)
                            Text(notif.timeLabel, fontSize = 11.sp, color = CathayMutedGrey)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(notif.message, fontSize = 12.sp, color = CathayCharcoal)
                    }
                }
            }
        }
    }
}

@Composable
fun SupportScreen(state: SimulationState) {
    var ticketText by remember { mutableStateOf("") }
    var createdId by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("CUSTOMER SUPPORT CENTRE", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Passenger Care & Assistance", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Create Support Ticket", fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = ticketText,
                            onValueChange = { ticketText = it },
                            placeholder = { Text("Describe enquiry or assistance needed...") },
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Button(
                            onClick = {
                                if (ticketText.isNotBlank()) {
                                    createdId = SimulationEngine.addSupportTicket("General Assistance", ticketText)
                                    ticketText = ""
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)
                        ) {
                            Text("Submit Support Ticket")
                        }
                    }
                }
            }

            items(state.supportTickets) { tick ->
                Card(colors = CardDefaults.cardColors(containerColor = Color.White), border = ButtonDefaults.outlinedButtonBorder) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Ticket: ${tick.id}", fontWeight = FontWeight.Bold)
                            Text(tick.status, color = CathayJade, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Text("Category: ${tick.category} • ${tick.timestamp}", fontSize = 11.sp, color = CathayMutedGrey)
                        Text(tick.lastMessage, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
    }
}
