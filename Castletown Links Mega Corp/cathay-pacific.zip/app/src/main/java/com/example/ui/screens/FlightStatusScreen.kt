package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Flight
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@Composable
fun FlightStatusScreen(
    state: SimulationState
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredFlights = state.flights.filter {
        it.flightNumber.contains(searchQuery, ignoreCase = true) ||
        it.originCode.contains(searchQuery, ignoreCase = true) ||
        it.destCode.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("FLIGHT STATUS & OPERATIONS ENGINE", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Live Simulated Radar & Status", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search by flight # or airport code (e.g. CX257, LHR)...", color = Color.White.copy(alpha = 0.6f)) },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = Color.White) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedBorderColor = CathayJade,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.5f)
                    )
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(filteredFlights) { flight ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(flight.flightNumber, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CathayForestGreen)

                            Surface(
                                color = when (flight.status) {
                                    com.example.data.model.FlightStatusEnum.BOARDING -> CathayJade
                                    com.example.data.model.FlightStatusEnum.DELAYED -> CathayWarningRed
                                    com.example.data.model.FlightStatusEnum.GATE_CHANGED -> CathayAlertOrange
                                    else -> CathayForestGreen
                                },
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = flight.status.displayName.uppercase(),
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("${flight.originCode} (${flight.originCity})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("Sch: ${flight.scheduledDeparture.substringAfter("T")}", fontSize = 12.sp, color = CathayMutedGrey)
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("${flight.destCode} (${flight.destCity})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text("Sch: ${flight.scheduledArrival.substringAfter("T")}", fontSize = 12.sp, color = CathayMutedGrey)
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = CathayBorderGrey)
                        Spacer(modifier = Modifier.height(8.dp))

                        Text("Gate: ${flight.gate} • Terminal: ${flight.terminal} • Aircraft: ${flight.aircraftType}", fontSize = 11.sp, color = CathayCharcoal)
                        if (flight.operationalMessage.isNotBlank()) {
                            Text("Ops Note: ${flight.operationalMessage}", fontSize = 11.sp, color = CathayJade, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
    }
}
