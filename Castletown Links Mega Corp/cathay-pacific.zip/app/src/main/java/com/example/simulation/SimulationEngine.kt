package com.example.simulation

import com.example.data.mock.SyntheticData
import com.example.data.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class SimulationState(
    val simDateFormatted: String = "2026-09-23 09:15 AM",
    val simTimestamp: Long = 1790157300000L, // Simulated timestamp
    val isPlaying: Boolean = false,
    val primaryBooking: Booking = SyntheticData.samplePrimaryBooking,
    val secondaryBookings: List<Booking> = SyntheticData.sampleSecondaryBookings,
    val flights: List<Flight> = SyntheticData.sampleFlights,
    val passenger: Passenger = SyntheticData.samplePassenger,
    val loyaltyAccount: LoyaltyAccount = SyntheticData.sampleLoyaltyAccount,
    val lounges: List<Lounge> = SyntheticData.sampleLounges,
    val airports: List<Airport> = SyntheticData.sampleAirports,
    val inflightState: InflightState = InflightState(),
    val notifications: List<NotificationItem> = SyntheticData.sampleNotifications,
    val supportTickets: List<SupportTicket> = listOf(
        SupportTicket("TICK-9081", "Baggage Enquiry", "RESOLVED", "2026-09-20 14:20", "Priority baggage tag confirmed for flight CX257."),
        SupportTicket("TICK-9104", "Special Assistance", "OPEN", "2026-09-22 18:00", "Request for electric buggy transfer at LHR terminal.")
    ),
    val activeDisruptions: List<DisruptionEvent> = emptyList(),
    val shopCart: List<ShopProduct> = emptyList(),
    val documents: List<TravelDocument> = SyntheticData.sampleDocuments,
    val entertainmentList: List<EntertainmentItem> = SyntheticData.sampleEntertainment,
    val activeTabRoute: String = "home"
)

object SimulationEngine {

    private val _state = MutableStateFlow(SimulationState())
    val state: StateFlow<SimulationState> = _state.asStateFlow()

    fun togglePlayPause() {
        _state.update { it.copy(isPlaying = !it.isPlaying) }
    }

    fun advanceHours(hours: Int = 1) {
        _state.update { current ->
            val updatedFlights = current.flights.map { flight ->
                if (flight.flightNumber == "CX257") {
                    when (flight.status) {
                        FlightStatusEnum.CHECKIN_OPEN -> flight.copy(status = FlightStatusEnum.BOARDING)
                        FlightStatusEnum.BOARDING -> flight.copy(status = FlightStatusEnum.DEPARTED)
                        FlightStatusEnum.DEPARTED -> flight.copy(status = FlightStatusEnum.AIRBORNE)
                        FlightStatusEnum.AIRBORNE -> flight.copy(status = FlightStatusEnum.LANDED)
                        else -> flight
                    }
                } else flight
            }
            current.copy(
                simDateFormatted = "2026-09-23 10:15 AM",
                flights = updatedFlights
            )
        }
    }

    fun advanceDays(days: Int = 1) {
        _state.update { current ->
            current.copy(
                simDateFormatted = "2026-09-24 09:15 AM"
            )
        }
    }

    // Scenario Triggers as requested in spec
    fun triggerFlightDelay() {
        _state.update { current ->
            val targetFlight = current.primaryBooking.flight.copy(
                status = FlightStatusEnum.DELAYED,
                estimatedDeparture = "2026-09-23 11:30 AM (Delayed 1h 15m)",
                operationalMessage = "Delayed due to late incoming aircraft arrival. New departure time 11:30 AM."
            )
            val updatedBooking = current.primaryBooking.copy(
                flight = targetFlight,
                boardingTime = "10:45 AM"
            )
            val newNotification = NotificationItem(
                id = "N_${System.currentTimeMillis()}",
                timeLabel = "Just Now",
                title = "FLIGHT DELAY ALERT — CX257",
                message = "Flight CX257 to London Heathrow is delayed to 11:30 AM. Lounge access remains open.",
                isRead = false,
                isPriority = true,
                category = "DELAY"
            )
            val disruption = DisruptionEvent(
                id = "DIS_${System.currentTimeMillis()}",
                flightNumber = "CX257",
                type = "DELAY",
                title = "1h 15m Flight Delay",
                description = "Aircraft turnaround delay at HKG. Rebooking options available if connection is at risk.",
                actionOptions = listOf("Accept New Departure", "Request Lounge Refreshment Voucher", "Rebook Alternative Flight")
            )
            current.copy(
                primaryBooking = updatedBooking,
                notifications = listOf(newNotification) + current.notifications,
                activeDisruptions = listOf(disruption) + current.activeDisruptions
            )
        }
    }

    fun triggerGateChange() {
        _state.update { current ->
            val newGate = "Gate 18 (Concourse A)"
            val targetFlight = current.primaryBooking.flight.copy(
                gate = newGate,
                status = FlightStatusEnum.GATE_CHANGED,
                operationalMessage = "Gate changed from Gate 31 to Gate 18. Please proceed to Concourse A."
            )
            val updatedBooking = current.primaryBooking.copy(
                flight = targetFlight,
                gate = newGate
            )
            val newNotification = NotificationItem(
                id = "N_${System.currentTimeMillis()}",
                timeLabel = "Just Now",
                title = "GATE CHANGE ALERT — CX257",
                message = "Boarding gate changed to Gate 18. Estimated walking time from current position is 5 minutes.",
                isRead = false,
                isPriority = true,
                category = "GATE_CHANGE"
            )
            current.copy(
                primaryBooking = updatedBooking,
                notifications = listOf(newNotification) + current.notifications
            )
        }
    }

    fun triggerMissedConnection() {
        _state.update { current ->
            val disruption = DisruptionEvent(
                id = "DIS_CONN_${System.currentTimeMillis()}",
                flightNumber = "CX252",
                type = "MISSED_CONNECTION",
                title = "Tight Connection Risk at LHR",
                description = "Connection to BA592 reduced to 35 mins. Cathay Travel Recovery has auto-reserved alternative flight CX256.",
                actionOptions = listOf("Confirm Auto-Rebooked Flight CX256", "Request Hotel & Transit Voucher", "Speak to Cathay Assistant")
            )
            val newNotification = NotificationItem(
                id = "N_CONN_${System.currentTimeMillis()}",
                timeLabel = "Just Now",
                title = "TRAVEL RECOVERY ALERT",
                message = "Missed connection detected. Complimentary rebooking & hotel voucher generated.",
                isRead = false,
                isPriority = true,
                category = "DISRUPTION"
            )
            current.copy(
                activeDisruptions = listOf(disruption) + current.activeDisruptions,
                notifications = listOf(newNotification) + current.notifications
            )
        }
    }

    fun triggerBaggageDelay() {
        _state.update { current ->
            val disruption = DisruptionEvent(
                id = "DIS_BAG_${System.currentTimeMillis()}",
                flightNumber = "CX257",
                type = "BAGGAGE_DELAY",
                title = "Baggage Tracking Update",
                description = "Checked bag #CX-99210 delayed in sorting hall. Express delivery to London hotel arranged.",
                actionOptions = listOf("Track Bag Live", "Submit Delivery Address", "Claim Baggage Allowance Voucher")
            )
            current.copy(
                activeDisruptions = listOf(disruption) + current.activeDisruptions
            )
        }
    }

    fun resetSimulation() {
        _state.value = SimulationState()
    }

    // User Interactive Actions
    fun updateSeat(newSeat: String) {
        _state.update { current ->
            val updatedBooking = current.primaryBooking.copy(selectedSeat = newSeat)
            current.copy(primaryBooking = updatedBooking)
        }
    }

    fun updateMeal(newMeal: String) {
        _state.update { current ->
            val updatedBooking = current.primaryBooking.copy(selectedMeal = newMeal)
            current.copy(primaryBooking = updatedBooking)
        }
    }

    fun addBaggage(extraKg: Int) {
        _state.update { current ->
            val updatedKg = current.primaryBooking.extraBaggageKg + extraKg
            val updatedTotal = current.primaryBooking.totalPaidHkd + (extraKg * 120)
            val updatedBooking = current.primaryBooking.copy(
                extraBaggageKg = updatedKg,
                totalPaidHkd = updatedTotal
            )
            current.copy(primaryBooking = updatedBooking)
        }
    }

    fun completeCheckIn() {
        _state.update { current ->
            val updatedBooking = current.primaryBooking.copy(isCheckedIn = true)
            val notif = NotificationItem(
                id = "N_CHECKIN_${System.currentTimeMillis()}",
                timeLabel = "Just Now",
                title = "CHECK-IN SUCCESSFUL",
                message = "Your digital boarding pass for CX257 is ready. Present at security & gate.",
                isRead = false,
                category = "CHECK_IN"
            )
            current.copy(
                primaryBooking = updatedBooking,
                notifications = listOf(notif) + current.notifications
            )
        }
    }

    fun reserveLounge(loungeId: String) {
        _state.update { current ->
            val updatedLounges = current.lounges.map {
                if (it.id == loungeId) it.copy(reserved = true) else it
            }
            val notif = NotificationItem(
                id = "N_LOUNGE_${System.currentTimeMillis()}",
                timeLabel = "Just now",
                title = "LOUNGE RESERVATION CONFIRMED",
                message = "Entry reserved at ${current.lounges.find { it.id == loungeId }?.name ?: "Cathay Lounge"}.",
                isRead = false,
                category = "LOUNGE"
            )
            current.copy(
                lounges = updatedLounges,
                notifications = listOf(notif) + current.notifications
            )
        }
    }

    fun toggleWifi(connected: Boolean) {
        _state.update { current ->
            val updatedInflight = current.inflightState.copy(wifiConnected = connected)
            current.copy(inflightState = updatedInflight)
        }
    }

    fun addToCart(product: ShopProduct) {
        _state.update { current ->
            val existing = current.shopCart.find { it.id == product.id }
            val updatedCart = if (existing != null) {
                current.shopCart.map { if (it.id == product.id) it.copy(inCartQuantity = it.inCartQuantity + 1) else it }
            } else {
                current.shopCart + product.copy(inCartQuantity = 1)
            }
            current.copy(shopCart = updatedCart)
        }
    }

    fun clearCart() {
        _state.update { it.copy(shopCart = emptyList()) }
    }

    fun redeemMiles(amount: Int, rewardName: String) {
        _state.update { current ->
            val currentAccount = current.loyaltyAccount
            if (currentAccount.asiaMilesBalance >= amount) {
                val newTx = LoyaltyTransaction(
                    id = "TX_${System.currentTimeMillis()}",
                    date = "2026-09-23",
                    description = "Redeemed for $rewardName",
                    type = "REDEEM",
                    miles = -amount,
                    statusPoints = 0
                )
                val updatedAccount = currentAccount.copy(
                    asiaMilesBalance = currentAccount.asiaMilesBalance - amount,
                    transactions = listOf(newTx) + currentAccount.transactions
                )
                current.copy(loyaltyAccount = updatedAccount)
            } else current
        }
    }

    fun addSupportTicket(category: String, message: String): String {
        val ticketId = "TICK-${(1000..9999).random()}"
        _state.update { current ->
            val newTicket = SupportTicket(
                id = ticketId,
                category = category,
                status = "OPEN",
                timestamp = "2026-09-23 09:20",
                lastMessage = message
            )
            current.copy(supportTickets = listOf(newTicket) + current.supportTickets)
        }
        return ticketId
    }

    fun markNotificationsRead() {
        _state.update { current ->
            current.copy(notifications = current.notifications.map { it.copy(isRead = true) })
        }
    }
}
