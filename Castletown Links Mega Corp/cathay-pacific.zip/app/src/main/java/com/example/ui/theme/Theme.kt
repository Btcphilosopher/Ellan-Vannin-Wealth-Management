package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColorScheme = lightColorScheme(
    primary = CathayForestGreen,
    onPrimary = Color.White,
    primaryContainer = CathayJadeLight,
    onPrimaryContainer = CathayJadeDark,
    secondary = CathayJade,
    onSecondary = Color.White,
    secondaryContainer = CathayGoldLight,
    onSecondaryContainer = CathayCharcoal,
    tertiary = CathayGoldAccent,
    onTertiary = Color.White,
    background = CathayIvory,
    onBackground = CathayCharcoal,
    surface = CathayIvoryCard,
    onSurface = CathayCharcoal,
    surfaceVariant = Color(0xFFEFF2EE),
    onSurfaceVariant = CathayMutedGrey,
    outline = CathayBorderGrey,
    error = CathayWarningRed,
    errorContainer = CathayWarningBg,
    onError = Color.White
)

private val DarkColorScheme = darkColorScheme(
    primary = CathayJade,
    onPrimary = DarkCathayBackground,
    primaryContainer = CathayJadeDark,
    onPrimaryContainer = CathayJadeLight,
    secondary = CathayGoldAccent,
    onSecondary = DarkCathayBackground,
    secondaryContainer = CathayJadeDark,
    onSecondaryContainer = Color.White,
    tertiary = CathayGoldAccent,
    onTertiary = Color.Black,
    background = DarkCathayBackground,
    onBackground = DarkCathayOnSurface,
    surface = DarkCathaySurface,
    onSurface = DarkCathayOnSurface,
    surfaceVariant = DarkCathayCard,
    onSurfaceVariant = Color(0xFFA0ABA6),
    outline = Color(0xFF2C4039),
    error = Color(0xFFFFB4AB),
    errorContainer = Color(0xFF93000A),
    onError = Color.Black
)

@Composable
fun CathayTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use our signature Cathay Pacific palette by default
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
