package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.simulation.SimulationEngine
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@Composable
fun CheckInScreen(
    state: SimulationState,
    onNavigate: (String) -> Unit
) {
    var checkInStage by remember { mutableStateOf(1) }
    val booking = state.primaryBooking

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("DIGITAL CHECK-IN WIZARD", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Flight CX257 • Hong Kong to London", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                Spacer(modifier = Modifier.height(8.dp))
                LinearProgressIndicator(
                    progress = { checkInStage / 7f },
                    modifier = Modifier.fillMaxWidth(),
                    color = CathayJade,
                    trackColor = Color.White.copy(alpha = 0.2f)
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                border = ButtonDefaults.outlinedButtonBorder,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    when (checkInStage) {
                        1 -> {
                            Text("1. Booking Lookup", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CathayForestGreen)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Booking Reference: ${booking.bookingReference}", fontSize = 14.sp)
                            Text("Passenger: ${booking.passenger.firstName} ${booking.passenger.lastName}", fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(onClick = { checkInStage = 2 }, colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)) {
                                Text("Verify Passport Data →")
                            }
                        }
                        2 -> {
                            Text("2. Travel Document Verification", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CathayForestGreen)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Passport No: ${booking.passenger.passportNumber}", fontSize = 13.sp)
                            Text("Expiry: ${booking.passenger.passportExpiry} (Valid)", fontSize = 13.sp, color = CathayJade)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(onClick = { checkInStage = 3 }, colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)) {
                                Text("Confirm Entry Requirements →")
                            }
                        }
                        3 -> {
                            Text("3. Entry & Visa Declaration", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CathayForestGreen)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("UK eVISA status checked with UK Border Force.", fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(onClick = { checkInStage = 4 }, colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)) {
                                Text("Confirm Seat Selection →")
                            }
                        }
                        4 -> {
                            Text("4. Seat & Cabin Confirmation", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CathayForestGreen)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Confirmed Seat: ${booking.selectedSeat} (Business Class)", fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(onClick = { checkInStage = 5 }, colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)) {
                                Text("Declare Baggage →")
                            }
                        }
                        5 -> {
                            Text("5. Baggage & Restricted Items", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = CathayForestGreen)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Allowance: ${booking.baggageAllowanceKg}kg. I confirm no prohibited hazardous items in baggage.", fontSize = 13.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(onClick = { checkInStage = 6 }, colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)) {
                                Text("Finalize Check-In →")
                            }
                        }
                        6 -> {
                            Text("6. Check-In Complete!", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = CathayJade)
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("You are officially checked in for flight CX257.", fontSize = 14.sp)
                            Spacer(modifier = Modifier.height(16.dp))
                            Button(
                                onClick = {
                                    SimulationEngine.completeCheckIn()
                                    onNavigate("boarding")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen)
                            ) {
                                Text("Generate Digital Boarding Pass")
                            }
                        }
                    }
                }
            }
        }
    }
}
