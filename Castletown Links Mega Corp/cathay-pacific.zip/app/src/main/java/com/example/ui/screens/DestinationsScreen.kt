package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.mock.SyntheticData
import com.example.simulation.SimulationState
import com.example.ui.theme.*

@Composable
fun DestinationsScreen(
    state: SimulationState,
    onNavigateToBook: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CathayIvory)
    ) {
        Surface(color = CathayForestGreen, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text("EDITORIAL DESTINATION GUIDES", color = CathayGoldAccent, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Inspiring Global Travel Horizons", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(SyntheticData.sampleDestinations) { dest ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(dest.city, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = CathayForestGreen)
                            Surface(color = CathayJadeLight, shape = RoundedCornerShape(4.dp)) {
                                Text(dest.category, fontSize = 10.sp, color = CathayForestGreen, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        Text(dest.country, fontSize = 12.sp, color = CathayMutedGrey)

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(dest.tagLine, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = CathayCharcoal)

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(dest.introduction, fontSize = 12.sp, color = CathayCharcoal)

                        Spacer(modifier = Modifier.height(10.dp))
                        Text("Best Season: ${dest.bestSeason} • Highlights: ${dest.topAttraction}", fontSize = 11.sp, color = CathayMutedGrey)

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = onNavigateToBook,
                            colors = ButtonDefaults.buttonColors(containerColor = CathayForestGreen),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.FlightTakeoff, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Find Flights to ${dest.city}")
                        }
                    }
                }
            }
        }
    }
}
