package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import com.example.model.PostalRole
import com.example.ui.components.BarcodeScannerOverlay
import com.example.ui.components.DemoBanner
import com.example.ui.components.PostalHeader
import com.example.ui.dialogs.AIAssistantSheet
import com.example.ui.dialogs.UniversalSearchDialog
import com.example.ui.theme.USPSLightBg
import com.example.ui.theme.USPSPostalOSTheme
import com.example.ui.workspaces.*
import com.example.viewmodel.PostalOSViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: PostalOSViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            USPSPostalOSTheme {
                USPSPostalOSApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun USPSPostalOSApp(viewModel: PostalOSViewModel) {
    val currentPersona by viewModel.currentPersona.collectAsState()
    val packages by viewModel.packages.collectAsState()
    val carrierRoute by viewModel.carrierRoute.collectAsState()
    val facilityTelemetry by viewModel.facilityTelemetry.collectAsState()
    val equipmentAssets by viewModel.equipmentAssets.collectAsState()
    val smartLockers by viewModel.smartLockers.collectAsState()
    val poBoxes by viewModel.poBoxes.collectAsState()
    val mailpieces by viewModel.mailpieces.collectAsState()
    val transactions by viewModel.transactions.collectAsState()
    val exceptions by viewModel.exceptions.collectAsState()
    val auditEvents by viewModel.auditEvents.collectAsState()
    val syncQueue by viewModel.syncQueue.collectAsState()

    val isOnline by viewModel.isOnline.collectAsState()
    val selectedPackage by viewModel.selectedPackage.collectAsState()
    val liveWeightOz by viewModel.liveWeightOz.collectAsState()

    val customerTab by viewModel.customerTab.collectAsState()
    val carrierTab by viewModel.carrierTab.collectAsState()
    val retailTab by viewModel.retailTab.collectAsState()
    val stationTab by viewModel.stationTab.collectAsState()
    val plantTab by viewModel.plantTab.collectAsState()
    val adminTab by viewModel.adminTab.collectAsState()

    val isUniversalSearchOpen by viewModel.isUniversalSearchOpen.collectAsState()
    val isAIAssistantOpen by viewModel.isAIAssistantOpen.collectAsState()
    val aiMessages by viewModel.aiMessages.collectAsState()
    val isBarcodeScannerOpen by viewModel.isBarcodeScannerOpen.collectAsState()
    val activeCarrierStopId by viewModel.activeCarrierStopId.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            Column {
                PostalHeader(
                    currentPersona = currentPersona,
                    onPersonaSelected = { viewModel.switchPersona(it) },
                    isOnline = isOnline,
                    onToggleOnline = { viewModel.toggleNetworkConnectivity() },
                    onOpenSearch = { viewModel.isUniversalSearchOpen.value = true },
                    onOpenAI = { viewModel.isAIAssistantOpen.value = true }
                )
                DemoBanner(
                    isOnline = isOnline,
                    pendingSyncCount = syncQueue.size
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(USPSLightBg)
        ) {
            // Role-Aware Main Workspace Content
            when (currentPersona.role) {
                PostalRole.CUSTOMER -> CustomerWorkspace(
                    packages = packages,
                    mailpieces = mailpieces,
                    smartLockers = smartLockers,
                    poBoxes = poBoxes,
                    activeTab = customerTab,
                    onTabChange = { viewModel.customerTab.value = it },
                    selectedPackage = selectedPackage,
                    onSelectPackage = { viewModel.selectedPackage.value = it },
                    onCreateShipment = { srv, snd, rec, w, l, wi, h, sig, pay ->
                        viewModel.createShipmentAndLabel(srv, snd, rec, w, l, wi, h, sig, pay)
                    },
                    onPickupLocker = { id, pin -> viewModel.pickupLocker(id, pin) },
                    onPrintLabel = { viewModel.printThermalLabel(it) }
                )

                PostalRole.CARRIER -> CarrierWorkspace(
                    carrierRoute = carrierRoute,
                    activeStopId = activeCarrierStopId,
                    onSelectStop = { viewModel.activeCarrierStopId.value = it },
                    onExecuteDelivery = { outcome, note, sigPoints ->
                        viewModel.executeCarrierDelivery(outcome, note, sigPoints)
                    },
                    onOpenScanner = { viewModel.isBarcodeScannerOpen.value = true },
                    activeTab = carrierTab,
                    onTabChange = { viewModel.carrierTab.value = it }
                )

                PostalRole.RETAIL_ASSOCIATE -> RetailWorkspace(
                    transactions = transactions,
                    poBoxes = poBoxes,
                    liveWeightOz = liveWeightOz,
                    onTareScale = { viewModel.tareScale() },
                    onSetWeight = { viewModel.setScaleWeight(it) },
                    onCreateShipment = { srv, snd, rec, w, l, wi, h, sig, pay ->
                        viewModel.createShipmentAndLabel(srv, snd, rec, w, l, wi, h, sig, pay)
                    },
                    onPrintLabel = { viewModel.printThermalLabel(it) },
                    activeTab = retailTab,
                    onTabChange = { viewModel.retailTab.value = it }
                )

                PostalRole.STATION_MANAGER -> StationManagerWorkspace(
                    carrierRoute = carrierRoute,
                    exceptions = exceptions,
                    onReportException = { trk, type, sev, desc ->
                        viewModel.reportNewException(trk, type, sev, desc)
                    },
                    activeTab = stationTab,
                    onTabChange = { viewModel.stationTab.value = it }
                )

                PostalRole.PROCESSING_OPERATOR -> ProcessingPlantWorkspace(
                    telemetry = facilityTelemetry,
                    equipment = equipmentAssets,
                    activeTab = plantTab,
                    onTabChange = { viewModel.plantTab.value = it }
                )

                PostalRole.SYSTEM_ADMIN -> AdminWorkspace(
                    auditEvents = auditEvents,
                    syncQueue = syncQueue,
                    activeTab = adminTab,
                    onTabChange = { viewModel.adminTab.value = it }
                )
            }

            // Universal Search Modal
            if (isUniversalSearchOpen) {
                UniversalSearchDialog(
                    packages = packages,
                    onPackageSelected = { pkg ->
                        viewModel.selectedPackage.value = pkg
                        viewModel.customerTab.value = "TRACK"
                    },
                    onDismiss = { viewModel.isUniversalSearchOpen.value = false }
                )
            }

            // AI Postal Assistant Modal Sheet
            if (isAIAssistantOpen) {
                AIAssistantSheet(
                    messages = aiMessages,
                    onSendMessage = { viewModel.sendAIMessage(it) },
                    onDismiss = { viewModel.isAIAssistantOpen.value = false }
                )
            }

            // Barcode Optical Scanner Overlay
            if (isBarcodeScannerOpen) {
                BarcodeScannerOverlay(
                    onBarcodeScanned = { scannedCode ->
                        viewModel.isBarcodeScannerOpen.value = false
                        val matchedPkg = packages.find { it.trackingNumber == scannedCode }
                        if (matchedPkg != null) {
                            viewModel.selectedPackage.value = matchedPkg
                            viewModel.customerTab.value = "TRACK"
                        }
                    },
                    onDismiss = { viewModel.isBarcodeScannerOpen.value = false }
                )
            }
        }
    }
}
