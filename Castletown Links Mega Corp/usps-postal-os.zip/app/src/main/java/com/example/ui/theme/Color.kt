package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// USPS Brand & Enterprise Color Palette
val USPSBluePrimary = Color(0xFF002F6C)     // Official Postal Navy/Blue
val USPSBlueDark = Color(0xFF0A1931)        // Command Center Background
val USPSBlueContainer = Color(0xFF1E3A8A)   // Surface Containers
val USPSRedAccent = Color(0xFFDA291C)       // Official Postal Red (Express/Priority)
val USPSRedLight = Color(0xFFFFECEB)        // Red tint

val USPSGold = Color(0xFFD97706)            // Priority Mail Express Gold
val USPSLightBg = Color(0xFFF8FAFC)         // Slate 50 clean background
val USPSSurface = Color(0xFFFFFFFF)
val USPSSurfaceVariant = Color(0xFFF1F5F9)  // Slate 100
val USPSBorder = Color(0xFFE2E8F0)          // Slate 200
val USPSTextPrimary = Color(0xFF0F172A)     // Slate 900
val USPSTextSecondary = Color(0xFF475569)   // Slate 600
val USPSTextMuted = Color(0xFF94A3B8)       // Slate 400

// Functional Status Tokens
val StatusGreen = Color(0xFF10B981)         // Delivered / Online / Normal
val StatusGreenBg = Color(0xFFD1FAE5)
val StatusAmber = Color(0xFFF59E0B)         // In Transit / Degraded / Processing
val StatusAmberBg = Color(0xFFFEF3C7)
val StatusRed = Color(0xFFEF4444)           // Exception / Fault / Late
val StatusRedBg = Color(0xFFFEE2E2)
val StatusBlue = Color(0xFF2563EB)          // Out for delivery / Accepted
val StatusBlueBg = Color(0xFFDBEAFE)
val StatusPurple = Color(0xFF7C3AED)        // Locker / Registered / Special
val StatusPurpleBg = Color(0xFFEDE9FE)
