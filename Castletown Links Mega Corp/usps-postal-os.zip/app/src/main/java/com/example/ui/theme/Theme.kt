package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val USPSDarkColorScheme = darkColorScheme(
    primary = Color(0xFF60A5FA),
    onPrimary = Color(0xFF0F172A),
    primaryContainer = Color(0xFF1E3A8A),
    onPrimaryContainer = Color(0xFFDBEAFE),
    secondary = Color(0xFFF87171),
    onSecondary = Color(0xFF450A0A),
    secondaryContainer = Color(0xFF7F1D1D),
    onSecondaryContainer = Color(0xFFFEE2E2),
    tertiary = Color(0xFFFBBF24),
    background = Color(0xFF0B1329),
    surface = Color(0xFF111C44),
    surfaceVariant = Color(0xFF1E293B),
    onBackground = Color(0xFFF8FAFC),
    onSurface = Color(0xFFF8FAFC),
    onSurfaceVariant = Color(0xFF94A3B8),
    outline = Color(0xFF334155)
)

private val USPSLightColorScheme = lightColorScheme(
    primary = USPSBluePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E7FF),
    onPrimaryContainer = Color(0xFF002F6C),
    secondary = USPSRedAccent,
    onSecondary = Color.White,
    secondaryContainer = USPSRedLight,
    onSecondaryContainer = Color(0xFF7F1D1D),
    tertiary = USPSGold,
    background = USPSLightBg,
    surface = USPSSurface,
    surfaceVariant = USPSSurfaceVariant,
    onBackground = USPSTextPrimary,
    onSurface = USPSTextPrimary,
    onSurfaceVariant = USPSTextSecondary,
    outline = USPSBorder
)

@Composable
fun USPSPostalOSTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Use intentional USPS enterprise brand colors by default
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> USPSDarkColorScheme
        else -> USPSLightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
