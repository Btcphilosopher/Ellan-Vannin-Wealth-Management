package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Done
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.USPSBluePrimary
import com.example.ui.theme.USPSRedAccent

@Composable
fun SignaturePad(
    signerName: String,
    onSignatureConfirmed: (pointCount: Int) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val points = remember { mutableStateListOf<Offset?>() }

    Surface(
        color = Color.White,
        shape = RoundedCornerShape(16.dp),
        tonalElevation = 8.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "ELECTRONIC SIGNATURE CAPTURE",
                        fontWeight = FontWeight.Black,
                        fontSize = 13.sp,
                        color = USPSBluePrimary,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Signer: $signerName (Apple Pencil / Stylus / Touch Enabled)",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }

                Surface(
                    color = Color(0xFFEFF6FF),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text(
                        text = "PS FORM 3849",
                        color = USPSBluePrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Interactive Drawing Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
                    .background(Color(0xFFFAFAFA), RoundedCornerShape(8.dp))
                    .border(1.5.dp, Color(0xFF94A3B8), RoundedCornerShape(8.dp))
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                points.add(offset)
                            },
                            onDrag = { change, _ ->
                                points.add(change.position)
                            },
                            onDragEnd = {
                                points.add(null) // Delimiter for separate strokes
                            }
                        )
                    }
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val path = Path()
                    var isNewStroke = true

                    for (pt in points) {
                        if (pt == null) {
                            isNewStroke = true
                        } else {
                            if (isNewStroke) {
                                path.moveTo(pt.x, pt.y)
                                isNewStroke = false
                            } else {
                                path.lineTo(pt.x, pt.y)
                            }
                        }
                    }

                    drawPath(
                        path = path,
                        color = Color(0xFF0F172A),
                        style = Stroke(
                            width = 4.dp.toPx(),
                            cap = StrokeCap.Round,
                            join = StrokeJoin.Round
                        )
                    )

                    // Signature baseline guide
                    drawLine(
                        color = Color(0xFFCBD5E1),
                        start = Offset(20f, size.height - 40f),
                        end = Offset(size.width - 20f, size.height - 40f),
                        strokeWidth = 1.5.dp.toPx()
                    )
                }

                if (points.isEmpty()) {
                    Text(
                        text = "Sign on the line above using Stylus or Finger",
                        color = Color(0xFF94A3B8),
                        fontSize = 12.sp,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }

                Text(
                    text = "✕ SIGN HERE",
                    color = USPSRedAccent,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(start = 16.dp, bottom = 12.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = { points.clear() },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Clear", fontSize = 12.sp)
                }

                Button(
                    onClick = {
                        onSignatureConfirmed(points.size)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusGreen),
                    modifier = Modifier.weight(2f),
                    shape = RoundedCornerShape(8.dp),
                    enabled = points.isNotEmpty()
                ) {
                    Icon(Icons.Default.Done, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Accept Signature & Proof", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }
    }
}
