package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PackageStatus
import com.example.model.TrackingEvent
import com.example.ui.theme.*

@Composable
fun TrackingTimeline(
    status: PackageStatus,
    events: List<TrackingEvent>,
    modifier: Modifier = Modifier
) {
    val stages = listOf(
        "Label Created" to (status.ordinal >= PackageStatus.LABEL_CREATED.ordinal),
        "Accepted" to (status.ordinal >= PackageStatus.ACCEPTED.ordinal),
        "In Transit" to (status.ordinal >= PackageStatus.IN_TRANSIT.ordinal),
        "Sort Facility" to (status.ordinal >= PackageStatus.ARRIVED_AT_FACILITY.ordinal),
        "Out for Delivery" to (status.ordinal >= PackageStatus.OUT_FOR_DELIVERY.ordinal),
        "Delivered" to (status == PackageStatus.DELIVERED)
    )

    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "DELIVERY MILESTONES",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = USPSBluePrimary,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Visual Milestone Horizontal Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                stages.forEachIndexed { index, (label, isCompleted) ->
                    val isCurrent = (label == "Delivered" && status == PackageStatus.DELIVERED) ||
                            (label == "Out for Delivery" && status == PackageStatus.OUT_FOR_DELIVERY) ||
                            (label == "In Transit" && (status == PackageStatus.IN_TRANSIT || status == PackageStatus.ARRIVED_AT_FACILITY))

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .background(
                                    color = when {
                                        status == PackageStatus.DELIVERED && label == "Delivered" -> StatusGreen
                                        isCurrent -> USPSBluePrimary
                                        isCompleted -> Color(0xFF3B82F6)
                                        else -> Color(0xFFE2E8F0)
                                    },
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCompleted) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(14.dp)
                                )
                            } else {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(Color(0xFF94A3B8), CircleShape)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = label,
                            fontSize = 9.sp,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                            color = if (isCurrent) USPSBluePrimary else Color(0xFF64748B),
                            maxLines = 1
                        )
                    }

                    if (index < stages.size - 1) {
                        Box(
                            modifier = Modifier
                                .height(2.dp)
                                .weight(0.6f)
                                .background(
                                    if (stages[index + 1].second) Color(0xFF3B82F6) else Color(0xFFE2E8F0)
                                )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Divider(color = Color(0xFFF1F5F9))
            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = "OFFICIAL EVENT HISTORY",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = USPSBluePrimary,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            events.forEachIndexed { idx, ev ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .background(
                                    if (idx == 0) USPSBluePrimary else Color(0xFFCBD5E1),
                                    CircleShape
                                )
                        )
                        if (idx < events.size - 1) {
                            Box(
                                modifier = Modifier
                                    .width(2.dp)
                                    .height(36.dp)
                                    .background(Color(0xFFE2E8F0))
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = ev.scanType,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = USPSTextPrimary
                            )
                            Text(
                                text = ev.timestamp,
                                fontSize = 11.sp,
                                color = Color(0xFF64748B)
                            )
                        }

                        Text(
                            text = ev.description,
                            fontSize = 11.sp,
                            color = USPSTextSecondary
                        )

                        Text(
                            text = "${ev.facility} • ${ev.location}",
                            fontSize = 10.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                }
            }
        }
    }
}
