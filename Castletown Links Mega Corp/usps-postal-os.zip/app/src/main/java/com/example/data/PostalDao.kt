package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface PostalDao {
    // Packages
    @Query("SELECT * FROM packages ORDER BY latestEventTime DESC")
    fun getAllPackages(): Flow<List<PackageEntity>>

    @Query("SELECT * FROM packages WHERE trackingNumber = :trackingNumber LIMIT 1")
    suspend fun getPackageByTracking(trackingNumber: String): PackageEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackages(packages: List<PackageEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackage(pkg: PackageEntity)

    @Update
    suspend fun updatePackage(pkg: PackageEntity)

    // Tracking Events
    @Query("SELECT * FROM tracking_events WHERE trackingNumber = :trackingNumber ORDER BY timestamp DESC")
    fun getEventsForPackage(trackingNumber: String): Flow<List<TrackingEventEntity>>

    @Query("SELECT * FROM tracking_events ORDER BY timestamp DESC")
    fun getAllTrackingEvents(): Flow<List<TrackingEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrackingEvents(events: List<TrackingEventEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTrackingEvent(event: TrackingEventEntity)

    // Retail Transactions
    @Query("SELECT * FROM retail_transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<RetailTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(tx: RetailTransactionEntity)

    // Exceptions
    @Query("SELECT * FROM exceptions ORDER BY createdAt DESC")
    fun getAllExceptions(): Flow<List<ExceptionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertExceptions(exceptions: List<ExceptionEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertException(exception: ExceptionEntity)

    // Audit Log
    @Query("SELECT * FROM audit_events ORDER BY timestamp DESC")
    fun getAllAuditEvents(): Flow<List<AuditEventEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditEvent(event: AuditEventEntity)

    // Sync Queue
    @Query("SELECT * FROM sync_queue ORDER BY timestamp ASC")
    fun getSyncQueue(): Flow<List<SyncQueueEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSyncItem(item: SyncQueueEntity)

    @Query("DELETE FROM sync_queue WHERE id = :id")
    suspend fun deleteSyncItem(id: String)

    @Query("DELETE FROM sync_queue")
    suspend fun clearSyncQueue()
}
