package com.example.engine

import com.example.model.PostalServiceType
import kotlin.math.ceil
import kotlin.math.max

data class RateBreakdown(
    val baseRateCents: Int,
    val weightSurchargeCents: Int,
    val dimensionalSurchargeCents: Int,
    val signatureConfirmationCents: Int,
    val zoneMultiplier: Double,
    val totalCents: Int,
    val engineVersion: String = "USPS-DMM-2026.1"
) {
    val formattedTotal: String
        get() = String.format("$%.2f", totalCents / 100.0)
    val formattedBase: String
        get() = String.format("$%.2f", baseRateCents / 100.0)
}

object RateEngine {
    const val VERSION = "USPS-DMM-2026.1"

    /**
     * Exact rate calculation using integer minor units (Cents).
     * Strictly avoids floating-point currency arithmetic errors.
     */
    fun calculatePostage(
        serviceType: PostalServiceType,
        weightOz: Double,
        lengthIn: Double,
        widthIn: Double,
        heightIn: Double,
        originZip: String,
        destinationZip: String,
        signatureRequired: Boolean = false
    ): RateBreakdown {
        val baseCents = serviceType.baseRateCents

        // Weight bracket calculation
        val weightLbs = max(1, ceil(weightOz / 16.0).toInt())
        val weightSurcharge = when (serviceType) {
            PostalServiceType.PRIORITY_MAIL_EXPRESS -> (weightLbs - 1) * 350
            PostalServiceType.PRIORITY_MAIL -> (weightLbs - 1) * 125
            PostalServiceType.USPS_GROUND_ADVANTAGE -> (weightLbs - 1) * 85
            PostalServiceType.FIRST_CLASS_MAIL -> if (weightOz > 1.0) ((ceil(weightOz).toInt() - 1) * 28) else 0
            PostalServiceType.MEDIA_MAIL -> (weightLbs - 1) * 75
            PostalServiceType.CERTIFIED_MAIL -> (weightLbs - 1) * 110
        }

        // Dimensional weight calculation for Priority Mail (if volume > 1 cubic foot / 1728 cu in)
        val cubicInches = lengthIn * widthIn * heightIn
        val dimensionalSurcharge = if (cubicInches > 1728 && serviceType == PostalServiceType.PRIORITY_MAIL) {
            val dimWeight = (cubicInches / 166.0).toInt()
            if (dimWeight > weightLbs) (dimWeight - weightLbs) * 90 else 0
        } else {
            0
        }

        // Zone estimate derived from first digit of ZIP code difference
        val originDigit = originZip.firstOrNull()?.digitToIntOrNull() ?: 6
        val destDigit = destinationZip.firstOrNull()?.digitToIntOrNull() ?: 6
        val zoneDiff = kotlin.math.abs(originDigit - destDigit)
        val zoneMultiplier = when (zoneDiff) {
            0, 1 -> 1.0
            2, 3 -> 1.08
            4, 5 -> 1.15
            else -> 1.25
        }

        val subtotal = ((baseCents + weightSurcharge + dimensionalSurcharge) * zoneMultiplier).toInt()
        val signatureFee = if (signatureRequired) 365 else 0
        val total = subtotal + signatureFee

        return RateBreakdown(
            baseRateCents = baseCents,
            weightSurchargeCents = weightSurcharge,
            dimensionalSurchargeCents = dimensionalSurcharge,
            signatureConfirmationCents = signatureFee,
            zoneMultiplier = zoneMultiplier,
            totalCents = total,
            engineVersion = VERSION
        )
    }
}
