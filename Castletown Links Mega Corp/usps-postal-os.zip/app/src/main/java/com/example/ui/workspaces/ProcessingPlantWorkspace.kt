package com.example.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun ProcessingPlantWorkspace(
    telemetry: FacilityTelemetry,
    equipment: List<EquipmentAsset>,
    activeTab: String,
    onTabChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(USPSLightBg)
    ) {
        ScrollableTabRow(
            selectedTabIndex = when (activeTab) {
                "SORTATION_FLOW" -> 0
                "EQUIPMENT" -> 1
                "LOGISTICS_DOCKS" -> 2
                else -> 0
            },
            containerColor = Color.White,
            contentColor = USPSBluePrimary,
            edgePadding = 12.dp
        ) {
            Tab(selected = activeTab == "SORTATION_FLOW", onClick = { onTabChange("SORTATION_FLOW") }, text = { Text("Sortation Flow & Lanes") }, icon = { Icon(Icons.Default.AltRoute, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "EQUIPMENT", onClick = { onTabChange("EQUIPMENT") }, text = { Text("High-Speed Sorters (${equipment.size})") }, icon = { Icon(Icons.Default.Memory, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "LOGISTICS_DOCKS", onClick = { onTabChange("LOGISTICS_DOCKS") }, text = { Text("Truck Docks & Containers") }, icon = { Icon(Icons.Default.LocalShipping, null, Modifier.size(18.dp)) })
        }

        Divider(color = USPSBorder)

        when (activeTab) {
            "SORTATION_FLOW" -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text("REAL-TIME FACILITY TELEMETRY: ${telemetry.facilityName}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = USPSBluePrimary)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), modifier = Modifier.weight(1f)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Hourly Throughput", color = Color(0xFF94A3B8), fontSize = 10.sp)
                                Text("${telemetry.hourlyThroughputPieces} PPH", color = Color(0xFF38BDF8), fontSize = 20.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                                Text("Target: 60,000 PPH", color = Color(0xFF64748B), fontSize = 10.sp)
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), modifier = Modifier.weight(1f)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Plant Backlog", color = Color(0xFF94A3B8), fontSize = 10.sp)
                                Text("${telemetry.dailyBacklogPieces}", color = Color(0xFFFBBF24), fontSize = 20.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                                Text("Estimated clearance 2.1 hrs", color = Color(0xFF64748B), fontSize = 10.sp)
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)), modifier = Modifier.weight(1f)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Active Containers", color = Color(0xFF94A3B8), fontSize = 10.sp)
                                Text("${telemetry.activeContainersCount} OTRs", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                                Text("Pallets & Rolling Carts", color = Color(0xFF64748B), fontSize = 10.sp)
                            }
                        }
                    }

                    // Sortation Lanes
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("SORTATION BINS & CONVEYOR LANES", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = USPSBluePrimary)

                            telemetry.sortationLanes.forEach { lane ->
                                val pct = lane.currentVolumePieces.toFloat() / lane.capacityPieces
                                Column {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Lane #${lane.laneNumber}: ${lane.destinationZone}", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        Text("${lane.currentVolumePieces} / ${lane.capacityPieces} (${(pct * 100).toInt()}%)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Spacer(Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { pct },
                                        color = if (pct > 0.9f) StatusRed else USPSBluePrimary,
                                        modifier = Modifier.fillMaxWidth().height(6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            "EQUIPMENT" -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(equipment) { eq ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(eq.machineName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Type: ${eq.machineType} • Serial: ${eq.serialNumber}", fontSize = 10.sp, color = Color(0xFF64748B))
                                    Text("Current Speed: ${eq.throughputPiecesPerHour} PPH (Target: ${eq.targetThroughput} PPH)", fontSize = 11.sp, color = USPSTextPrimary, fontWeight = FontWeight.SemiBold)
                                    Text("Runtime: ${eq.runtimeHoursToday} hrs • Last Service: ${eq.lastMaintenance}", fontSize = 10.sp, color = Color(0xFF94A3B8))
                                }

                                Surface(
                                    color = when (eq.status) {
                                        EquipmentStatus.ONLINE -> StatusGreenBg
                                        EquipmentStatus.DEGRADED -> StatusAmberBg
                                        else -> StatusRedBg
                                    },
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = eq.status.label,
                                        color = when (eq.status) {
                                            EquipmentStatus.ONLINE -> StatusGreen
                                            EquipmentStatus.DEGRADED -> StatusAmber
                                            else -> StatusRed
                                        },
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            "LOGISTICS_DOCKS" -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("DOCK LOGISTICS & TRUCK QUEUE", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = USPSBluePrimary)

                            listOf(
                                Triple("Inbound Dock #04 - Semi Trailer #7741", "Arrived from Chicago NDC (38 Pallets)", "UNLOADING"),
                                Triple("Inbound Dock #06 - Expedited Shuttle #1209", "Arrived from O'Hare Air Mail Facility", "COMPLETED"),
                                Triple("Outbound Dock #12 - Line-Haul Rig #9910", "Staging for Springfield Station Delivery Unit", "LOADING (85%)")
                            ).forEach { (dock, desc, stat) ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column {
                                        Text(dock, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text(desc, fontSize = 11.sp, color = USPSTextSecondary)
                                    }
                                    Surface(color = StatusBlueBg, shape = RoundedCornerShape(4.dp)) {
                                        Text(stat, color = USPSBluePrimary, fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                                Divider(color = Color(0xFFF1F5F9))
                            }
                        }
                    }
                }
            }
        }
    }
}
