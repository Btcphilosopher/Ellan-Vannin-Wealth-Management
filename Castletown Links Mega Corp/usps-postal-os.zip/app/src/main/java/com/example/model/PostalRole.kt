package com.example.model

enum class PostalRole(
    val title: String,
    val description: String,
    val accessBadge: String
) {
    CUSTOMER(
        title = "Customer Mode",
        description = "Track packages, Informed Delivery, ship items, locate post offices, lockboxes",
        accessBadge = "PUBLIC / CITIZEN"
    ),
    CARRIER(
        title = "City & Rural Carrier",
        description = "Route C-042 manifest, rapid barcode scanning, delivery evidence & signature",
        accessBadge = "FIELD OPS / MDD"
    ),
    RETAIL_ASSOCIATE(
        title = "Retail Counter Associate",
        description = "Full POS counter, automated scale/dims, rating, label printing, acceptance",
        accessBadge = "RETAIL CLERK / POS"
    ),
    STATION_MANAGER(
        title = "Station Manager",
        description = "Facility KPIs, route completion gauges, exception triage, workforce duty",
        accessBadge = "STATION MGMT"
    ),
    PROCESSING_OPERATOR(
        title = "Processing Plant Operator",
        description = "High-speed DBCS/APPS throughput, mail flow sortation, equipment telemetry",
        accessBadge = "PLANT OPS / NETWORK"
    ),
    SYSTEM_ADMIN(
        title = "System Administrator",
        description = "Zero-trust identity, device governance, immutable audit trail, system health",
        accessBadge = "SEC OPS / ROOT"
    )
}

data class UserPersona(
    val id: String,
    val name: String,
    val email: String,
    val role: PostalRole,
    val employeeId: String?,
    val facilityName: String,
    val avatarInitial: String
) {
    companion object {
        val ALL_PERSONAS = listOf(
            UserPersona(
                id = "pers_customer_01",
                name = "Alex Morgan",
                email = "alex.morgan@email.com",
                role = PostalRole.CUSTOMER,
                employeeId = null,
                facilityName = "742 Evergreen Terrace, Springfield",
                avatarInitial = "AM"
            ),
            UserPersona(
                id = "pers_carrier_02",
                name = "Jordan Williams",
                email = "jordan.williams@usps.gov",
                role = PostalRole.CARRIER,
                employeeId = "EMP-88421",
                facilityName = "Springfield Station Delivery Unit #4",
                avatarInitial = "JW"
            ),
            UserPersona(
                id = "pers_retail_03",
                name = "Taylor Johnson",
                email = "taylor.johnson@usps.gov",
                role = PostalRole.RETAIL_ASSOCIATE,
                employeeId = "EMP-41092",
                facilityName = "Downtown Main Post Office Retail Counter",
                avatarInitial = "TJ"
            ),
            UserPersona(
                id = "pers_station_04",
                name = "Morgan Davis",
                email = "morgan.davis@usps.gov",
                role = PostalRole.STATION_MANAGER,
                employeeId = "MGR-00214",
                facilityName = "Springfield Central Postal Station (Zone 97401)",
                avatarInitial = "MD"
            ),
            UserPersona(
                id = "pers_plant_05",
                name = "Chris Wilson",
                email = "chris.wilson@usps.gov",
                role = PostalRole.PROCESSING_OPERATOR,
                employeeId = "PLT-55109",
                facilityName = "Metro P&DC (Processing & Distribution Center)",
                avatarInitial = "CW"
            ),
            UserPersona(
                id = "pers_admin_06",
                name = "Jamie Carter",
                email = "jamie.carter@usps.gov",
                role = PostalRole.SYSTEM_ADMIN,
                employeeId = "ADM-00001",
                facilityName = "USPS National Operations & Security Command",
                avatarInitial = "JC"
            )
        )
    }
}
