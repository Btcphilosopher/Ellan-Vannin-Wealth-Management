package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Print
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PostalPackage
import com.example.model.PostalServiceType
import com.example.ui.theme.USPSBluePrimary
import com.example.ui.theme.USPSRedAccent

@Composable
fun ThermalLabelCard(
    postalPackage: PostalPackage,
    onPrintClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, Color(0xFF0F172A), RoundedCornerShape(8.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Service Top Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        if (postalPackage.serviceType.isExpress) USPSRedAccent else USPSBluePrimary
                    )
                    .padding(vertical = 8.dp, horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = postalPackage.serviceType.displayName.uppercase(),
                    color = Color.White,
                    fontWeight = FontWeight.Black,
                    fontSize = 14.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "US POSTAGE PAID",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Indicia Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(
                        text = "SHIP FROM:",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = postalPackage.sender.residentName,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = postalPackage.sender.streetAddress,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "${postalPackage.sender.city}, ${postalPackage.sender.state} ${postalPackage.sender.zipCode}",
                        fontSize = 10.sp
                    )
                }

                Surface(
                    color = Color(0xFFF8FAFC),
                    border = CardDefaults.outlinedCardBorder(),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(8.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(
                            text = "WT: ${postalPackage.weightOz} OZ",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "ZONE: LOCAL/REG",
                            fontSize = 9.sp
                        )
                        Text(
                            text = String.format("PAID: $%.2f", postalPackage.postageCents / 100.0),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = USPSBluePrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = Color(0xFF0F172A), thickness = 1.5.dp)
            Spacer(modifier = Modifier.height(12.dp))

            // Ship To Block
            Text(
                text = "SHIP TO:",
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF64748B)
            )
            Text(
                text = postalPackage.recipient.residentName.uppercase(),
                fontSize = 14.sp,
                fontWeight = FontWeight.Black
            )
            Text(
                text = postalPackage.recipient.streetAddress.uppercase(),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "${postalPackage.recipient.city.uppercase()} ${postalPackage.recipient.state.uppercase()} ${postalPackage.recipient.zipCode}-${postalPackage.recipient.zipPlus4}",
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp
            )

            if (postalPackage.signatureRequired) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = Color(0xFFFEF2F2),
                    border = CardDefaults.outlinedCardBorder(),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "SIGNATURE REQUIRED UPON DELIVERY",
                        color = USPSRedAccent,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
            Divider(color = Color(0xFF0F172A), thickness = 2.dp)
            Spacer(modifier = Modifier.height(12.dp))

            // Simulated USPS Barcode Block
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "USPS TRACKING # eVS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Simulated High-Contrast Barcode Lines
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .background(Color.White)
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    for (i in 0 until 52) {
                        val barWidth = if (i % 3 == 0) 4.dp else if (i % 2 == 0) 2.dp else 1.dp
                        val isSpace = (i % 7 == 2)
                        if (!isSpace) {
                            Box(
                                modifier = Modifier
                                    .width(barWidth)
                                    .fillMaxHeight()
                                    .background(Color.Black)
                            )
                        } else {
                            Spacer(modifier = Modifier.width(2.dp))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = postalPackage.trackingNumber.chunked(4).joinToString(" "),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onPrintClick,
                colors = ButtonDefaults.buttonColors(containerColor = USPSBluePrimary),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Print, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("PRINT 4x6 THERMAL LABEL (ZEBRA / AIRPRINT)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}
