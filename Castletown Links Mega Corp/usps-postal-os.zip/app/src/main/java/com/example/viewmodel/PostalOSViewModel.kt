package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PostalRepository
import com.example.engine.*
import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class PostalOSViewModel(application: Application) : AndroidViewModel(application) {
    val repository = PostalRepository(application.applicationContext)

    val currentPersona = MutableStateFlow(UserPersona.ALL_PERSONAS.first())
    val selectedPackage = MutableStateFlow<PostalPackage?>(null)

    // Tab state per role
    val customerTab = MutableStateFlow("HOME")
    val carrierTab = MutableStateFlow("ROUTE_HUD")
    val retailTab = MutableStateFlow("POS_COUNTER")
    val stationTab = MutableStateFlow("OPERATIONS_KPI")
    val plantTab = MutableStateFlow("SORTATION_FLOW")
    val adminTab = MutableStateFlow("IDENTITY_ROLES")

    // UI overlays & Dialogs
    val isUniversalSearchOpen = MutableStateFlow(false)
    val searchQuery = MutableStateFlow("")
    val isAIAssistantOpen = MutableStateFlow(false)
    val aiMessages = MutableStateFlow<List<AIMessage>>(
        listOf(
            AIMessage(
                id = "msg_welcome",
                sender = "ASSISTANT",
                content = "Welcome to USPS Postal OS Assistant. How can I assist your dispatch, delivery, tracking or counter operation today?"
            )
        )
    )

    // Hardware State
    val isOnline = repository.isOnline
    val mockScale = MockScaleProvider()
    val mockDims = MockDimensionProvider()
    val mockPrinter = MockThermalPrinterProvider()
    val mockPaymentTerminal = MockPaymentTerminalProvider()

    val liveWeightOz = MutableStateFlow(18.5)
    val liveDimsInches = MutableStateFlow(Triple(12.0, 9.0, 4.0))
    val isPrinting = MutableStateFlow(false)
    val lastPrintedPackage = MutableStateFlow<PostalPackage?>(null)

    // Scanner
    val isBarcodeScannerOpen = MutableStateFlow(false)
    val scannerFeedbackMessage = MutableStateFlow<String?>(null)

    // Carrier Active Stop & Signature
    val activeCarrierStopId = MutableStateFlow<String?>("ST-01")
    val isSignatureDialogOpen = MutableStateFlow(false)

    // Data streams from repository
    val packages = repository.packages.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val carrierRoute = repository.carrierRoute.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = repository.carrierRoute.value
    )

    val facilityTelemetry = repository.facilityTelemetry.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = repository.facilityTelemetry.value
    )

    val equipmentAssets = repository.equipmentAssets.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val smartLockers = repository.smartLockers.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val poBoxes = repository.poBoxes.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val mailpieces = repository.mailpieces.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val transactions = repository.transactions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val exceptions = repository.exceptions.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val auditEvents = repository.auditEvents.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val syncQueue = repository.syncQueue.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    fun switchPersona(persona: UserPersona) {
        currentPersona.value = persona
        repository.recordAuditEvent(
            actor = persona.name,
            role = persona.role.name,
            facility = persona.facilityName,
            action = "ROLE_SESSION_SWITCH",
            resource = "UserPersona",
            resourceId = persona.id,
            result = "SUCCESS - Access Granted to ${persona.role.title}"
        )
    }

    fun toggleNetworkConnectivity() {
        val newStatus = !isOnline.value
        repository.setNetworkOnline(newStatus)
    }

    fun sendAIMessage(query: String) {
        if (query.isBlank()) return
        val userMsg = AIMessage(
            id = java.util.UUID.randomUUID().toString(),
            sender = "USER",
            content = query
        )
        aiMessages.value = aiMessages.value + userMsg

        viewModelScope.launch {
            val response = AIPostalAssistant.processQuery(
                query = query,
                role = currentPersona.value.role,
                packages = packages.value,
                carrierRoute = carrierRoute.value,
                facilityTelemetry = facilityTelemetry.value,
                exceptions = exceptions.value
            )
            aiMessages.value = aiMessages.value + response
        }
    }

    fun tareScale() {
        mockScale.tare()
        liveWeightOz.value = 0.0
    }

    fun setScaleWeight(oz: Double) {
        mockScale.setSimulatedWeight(oz)
        liveWeightOz.value = oz
    }

    fun printThermalLabel(pkg: PostalPackage) {
        viewModelScope.launch {
            isPrinting.value = true
            mockPrinter.printThermalLabel(pkg.trackingNumber, pkg.recipient.fullFormatted)
            lastPrintedPackage.value = pkg
            isPrinting.value = false
        }
    }

    fun createShipmentAndLabel(
        service: PostalServiceType,
        sender: PostalAddress,
        recipient: PostalAddress,
        weightOz: Double,
        lengthIn: Double,
        widthIn: Double,
        heightIn: Double,
        signatureRequired: Boolean,
        paymentMethod: String
    ): PostalPackage {
        val rate = RateEngine.calculatePostage(
            serviceType = service,
            weightOz = weightOz,
            lengthIn = lengthIn,
            widthIn = widthIn,
            heightIn = heightIn,
            originZip = sender.zipCode,
            destinationZip = recipient.zipCode,
            signatureRequired = signatureRequired
        )

        val pkg = repository.createShipment(
            service = service,
            sender = sender,
            recipient = recipient,
            weightOz = weightOz,
            lengthIn = lengthIn,
            widthIn = widthIn,
            heightIn = heightIn,
            postageCents = rate.totalCents,
            signatureRequired = signatureRequired,
            paymentMethod = paymentMethod
        )

        printThermalLabel(pkg)
        return pkg
    }

    fun executeCarrierDelivery(outcome: DeliveryOutcome, note: String, signaturePoints: Int = 0) {
        val stopId = activeCarrierStopId.value ?: "ST-01"
        repository.completeCarrierDelivery(stopId, outcome, note, signaturePoints)
        // Advance to next pending stop if available
        val stops = carrierRoute.value.stops
        val currentIndex = stops.indexOfFirst { it.stopId == stopId }
        val nextPending = stops.drop(currentIndex + 1).firstOrNull { it.deliveryStatus == "PENDING" }
            ?: stops.firstOrNull { it.deliveryStatus == "PENDING" }
        activeCarrierStopId.value = nextPending?.stopId
    }

    fun pickupLocker(lockerId: String, pin: String): Boolean {
        return repository.pickupSmartLocker(lockerId, pin)
    }

    fun reportNewException(trackingNumber: String, type: String, severity: String, description: String) {
        repository.reportException(
            trackingNumber = trackingNumber,
            type = type,
            severity = severity,
            description = description,
            assignedTo = currentPersona.value.name
        )
    }
}
