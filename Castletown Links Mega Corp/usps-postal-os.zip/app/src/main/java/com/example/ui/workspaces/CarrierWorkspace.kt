package com.example.ui.workspaces

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.SignaturePad
import com.example.ui.theme.*

@Composable
fun CarrierWorkspace(
    carrierRoute: CarrierRoute,
    activeStopId: String?,
    onSelectStop: (String) -> Unit,
    onExecuteDelivery: (DeliveryOutcome, String, Int) -> Unit,
    onOpenScanner: () -> Unit,
    activeTab: String,
    onTabChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var isSignaturePadOpen by remember { mutableStateOf(false) }
    var selectedOutcome by remember { mutableStateOf(DeliveryOutcome.DELIVERED_FRONT_PORCH) }
    var deliveryNote by remember { mutableStateOf("") }

    val currentStop = carrierRoute.stops.find { it.stopId == activeStopId } ?: carrierRoute.stops.firstOrNull()
    val progressPercent = if (carrierRoute.totalStops > 0) (carrierRoute.completedStops.toFloat() / carrierRoute.totalStops) else 0f

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(USPSLightBg)
    ) {
        // MDD Carrier Route Header
        Surface(
            color = Color(0xFF0F172A),
            tonalElevation = 4.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            color = USPSRedAccent,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "ROUTE ${carrierRoute.routeId}",
                                color = Color.White,
                                fontWeight = FontWeight.Black,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        Text(
                            text = carrierRoute.routeName,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }

                    Surface(
                        color = if (carrierRoute.shiftStatus == "COMPLETED") StatusGreen else Color(0xFF1E3A8A),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(
                            text = carrierRoute.shiftStatus,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Carrier: ${carrierRoute.carrierName} • Vehicle: ${carrierRoute.vehicleId}",
                        color = Color(0xFF94A3B8),
                        fontSize = 11.sp
                    )
                    Text(
                        text = "${carrierRoute.completedStops} / ${carrierRoute.totalStops} Stops Completed (${(progressPercent * 100).toInt()}%)",
                        color = Color(0xFF38BDF8),
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                LinearProgressIndicator(
                    progress = { progressPercent },
                    color = Color(0xFF38BDF8),
                    trackColor = Color(0xFF334155),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                )
            }
        }

        // Secondary Carrier Toolbar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.White)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = onOpenScanner,
                    colors = ButtonDefaults.buttonColors(containerColor = USPSBluePrimary),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("RAPID SCANNER", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = { onTabChange("ROUTE_HUD") },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.FormatListNumbered, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("MANIFEST", fontSize = 11.sp)
                }
            }

            Text(
                text = "${carrierRoute.packageCount} Parcels • ${carrierRoute.mailVolumeTotal} Letters",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = USPSBluePrimary
            )
        }

        Divider(color = USPSBorder)

        // Main Dual-Pane Carrier View
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Left Stop Manifest List
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .width(320.dp)
                    .fillMaxHeight()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = "DELIVERY STOP SEQUENCE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = USPSBluePrimary,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(carrierRoute.stops) { stop ->
                            val isSelected = stop.stopId == currentStop?.stopId
                            val isDone = stop.deliveryStatus == "DELIVERED"
                            val isAttempted = stop.deliveryStatus == "ATTEMPTED"

                            Surface(
                                color = when {
                                    isSelected -> Color(0xFFEFF6FF)
                                    isDone -> Color(0xFFF0FDF4)
                                    isAttempted -> Color(0xFFFEF2F2)
                                    else -> Color(0xFFF8FAFC)
                                },
                                border = if (isSelected) BorderStroke(1.5.dp, USPSBluePrimary) else null,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { onSelectStop(stop.stopId) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .background(
                                                color = when {
                                                    isDone -> StatusGreen
                                                    isAttempted -> StatusRed
                                                    isSelected -> USPSBluePrimary
                                                    else -> Color(0xFF64748B)
                                                },
                                                shape = CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "${stop.stopNumber}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = stop.address.streetAddress,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = USPSTextPrimary,
                                                maxLines = 1
                                            )
                                            if (stop.signatureRequired) {
                                                Surface(
                                                    color = Color(0xFFFEE2E2),
                                                    shape = RoundedCornerShape(2.dp)
                                                ) {
                                                    Text(
                                                        text = "SIG",
                                                        color = USPSRedAccent,
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.ExtraBold,
                                                        modifier = Modifier.padding(horizontal = 3.dp, vertical = 1.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Text(
                                            text = "${stop.address.residentName} • ${stop.packageTrackingNumbers.size} pkgs, ${stop.mailVolumeLetters} letters",
                                            fontSize = 10.sp,
                                            color = Color(0xFF64748B)
                                        )

                                        if (stop.deliveryStatus != "PENDING") {
                                            Text(
                                                text = "${stop.deliveryStatus}: ${stop.outcomeNote ?: ""}",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = if (isDone) StatusGreen else StatusRed
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Right Stop Execution HUD
            if (currentStop != null) {
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Current Stop Detail Card
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = "STOP #${currentStop.stopNumber} OF ${carrierRoute.totalStops}",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = USPSBluePrimary,
                                        letterSpacing = 1.sp
                                    )
                                    Text(
                                        text = currentStop.address.fullFormatted,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Black,
                                        color = USPSTextPrimary
                                    )
                                    Text(
                                        text = "Resident: ${currentStop.address.residentName}",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = USPSTextSecondary
                                    )
                                }

                                Surface(
                                    color = when (currentStop.deliveryStatus) {
                                        "DELIVERED" -> StatusGreenBg
                                        "ATTEMPTED" -> StatusRedBg
                                        else -> StatusAmberBg
                                    },
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = currentStop.deliveryStatus,
                                        color = when (currentStop.deliveryStatus) {
                                            "DELIVERED" -> StatusGreen
                                            "ATTEMPTED" -> StatusRed
                                            else -> StatusAmber
                                        },
                                        fontWeight = FontWeight.Black,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            if (!currentStop.specialInstructions.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Surface(
                                    color = Color(0xFFFEF3C7),
                                    border = BorderStroke(1.dp, Color(0xFFF59E0B)),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFD97706), modifier = Modifier.size(18.dp))
                                        Text(
                                            text = "CARRIER INSTRUCTION: ${currentStop.specialInstructions}",
                                            color = Color(0xFF92400E),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            Divider(color = USPSBorder)
                            Spacer(modifier = Modifier.height(10.dp))

                            Text("PARCELS FOR THIS STOP (${currentStop.packageTrackingNumbers.size})", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))

                            currentStop.packageTrackingNumbers.forEach { trk ->
                                Surface(
                                    color = Color(0xFFF8FAFC),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 3.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(trk.chunked(4).joinToString(" "), fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Text("Scanned for Delivery", fontSize = 10.sp, color = StatusGreen, fontWeight = FontWeight.SemiBold)
                                    }
                                }
                            }
                        }
                    }

                    // Delivery Action HUD Form
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "RECORD DELIVERY OUTCOME",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = USPSBluePrimary,
                                letterSpacing = 1.sp
                            )

                            // Delivery Outcome Chips
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                OutcomeButton("Front Porch", DeliveryOutcome.DELIVERED_FRONT_PORCH, selectedOutcome) { selectedOutcome = it }
                                OutcomeButton("Mailbox", DeliveryOutcome.DELIVERED_MAILBOX, selectedOutcome) { selectedOutcome = it }
                                OutcomeButton("In-Person", DeliveryOutcome.DELIVERED_IN_PERSON, selectedOutcome) { selectedOutcome = it }
                                OutcomeButton("No Access", DeliveryOutcome.ATTEMPTED_NO_ACCESS, selectedOutcome) { selectedOutcome = it }
                            }

                            OutlinedTextField(
                                value = deliveryNote,
                                onValueChange = { deliveryNote = it },
                                label = { Text("Delivery Note / Location Details") },
                                placeholder = { Text("e.g. Left behind storm door pillar") },
                                singleLine = true,
                                modifier = Modifier.fillMaxWidth()
                            )

                            // Signature Capture Trigger if required
                            if (currentStop.signatureRequired) {
                                Button(
                                    onClick = { isSignaturePadOpen = true },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4338CA)),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Draw, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("OPEN ELECTRONIC SIGNATURE CAPTURE (PS-3849)", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }

                            Button(
                                onClick = {
                                    onExecuteDelivery(selectedOutcome, deliveryNote.ifBlank { "Carrier scan recorded" }, 1)
                                    deliveryNote = ""
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedOutcome.name.startsWith("DELIVERED")) StatusGreen else StatusRed
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "CONFIRM & TRANSMIT DELIVERY PROOF",
                                    fontWeight = FontWeight.Black,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    // Signature Pad Modal
                    if (isSignaturePadOpen) {
                        SignaturePad(
                            signerName = currentStop.address.residentName,
                            onSignatureConfirmed = { points ->
                                isSignaturePadOpen = false
                                onExecuteDelivery(DeliveryOutcome.DELIVERED_IN_PERSON, "In-Person Signature Recorded ($points strokes)", points)
                            },
                            onDismiss = { isSignaturePadOpen = false }
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RowScope.OutcomeButton(
    label: String,
    outcome: DeliveryOutcome,
    current: DeliveryOutcome,
    onSelect: (DeliveryOutcome) -> Unit
) {
    val isSelected = outcome == current
    Surface(
        color = if (isSelected) USPSBluePrimary else Color(0xFFF1F5F9),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .weight(1f)
            .clickable { onSelect(outcome) }
    ) {
        Box(
            modifier = Modifier.padding(vertical = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                color = if (isSelected) Color.White else USPSTextPrimary,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
        }
    }
}
