package com.example.engine

import kotlinx.coroutines.delay

interface ScaleProvider {
    suspend fun readWeightOz(): Double
    fun tare()
    fun getHardwareModel(): String
}

class MockScaleProvider : ScaleProvider {
    private var isTared = true
    private var currentWeight = 18.5

    override suspend fun readWeightOz(): Double {
        delay(120) // Hardware bus read simulation
        return if (isTared) currentWeight else currentWeight + 1.2
    }

    override fun tare() {
        isTared = true
    }

    fun setSimulatedWeight(oz: Double) {
        currentWeight = oz
    }

    override fun getHardwareModel(): String = "Toledo PS-60 Retail Counter Scale (USB-HID)"
}

interface DimensionProvider {
    suspend fun measureDimensionsInches(): Triple<Double, Double, Double>
}

class MockDimensionProvider : DimensionProvider {
    private var dims = Triple(12.0, 9.0, 4.0)

    override suspend fun measureDimensionsInches(): Triple<Double, Double, Double> {
        delay(150)
        return dims
    }

    fun setSimulatedDimensions(l: Double, w: Double, h: Double) {
        dims = Triple(l, w, h)
    }
}

interface PrinterProvider {
    suspend fun printThermalLabel(labelId: String, data: String): Boolean
    fun getStatus(): String
}

class MockThermalPrinterProvider : PrinterProvider {
    private var isOnline = true

    override suspend fun printThermalLabel(labelId: String, data: String): Boolean {
        delay(800) // Physical thermal print head simulation
        return isOnline
    }

    override fun getStatus(): String = if (isOnline) "READY (Zebra ZP-450 Thermal 4x6 Roll)" else "OFFLINE"
}

interface PaymentTerminalProvider {
    suspend fun processTokenizedPayment(
        amountCents: Int,
        paymentMethod: String
    ): PaymentResult
}

data class PaymentResult(
    val success: Boolean,
    val transactionToken: String,
    val authCode: String,
    val message: String
)

class MockPaymentTerminalProvider : PaymentTerminalProvider {
    override suspend fun processTokenizedPayment(
        amountCents: Int,
        paymentMethod: String
    ): PaymentResult {
        delay(700) // EMV / NFC token exchange simulation
        val token = "tok_usps_" + java.util.UUID.randomUUID().toString().take(12)
        val auth = "AUTH-" + (100000 + (Math.random() * 899999).toInt())
        return PaymentResult(
            success = true,
            transactionToken = token,
            authCode = auth,
            message = "Approved: $paymentMethod - Transferred $$amountCents Cents"
        )
    }
}
