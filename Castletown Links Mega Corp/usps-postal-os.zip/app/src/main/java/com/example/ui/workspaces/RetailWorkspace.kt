package com.example.ui.workspaces

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.RateEngine
import com.example.model.*
import com.example.ui.components.ThermalLabelCard
import com.example.ui.theme.*

@Composable
fun RetailWorkspace(
    transactions: List<RetailTransaction>,
    poBoxes: List<POBoxItem>,
    liveWeightOz: Double,
    onTareScale: () -> Unit,
    onSetWeight: (Double) -> Unit,
    onCreateShipment: (PostalServiceType, PostalAddress, PostalAddress, Double, Double, Double, Double, Boolean, String) -> PostalPackage,
    onPrintLabel: (PostalPackage) -> Unit,
    activeTab: String,
    onTabChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var customerName by remember { mutableStateOf("Walk-in Retail Patron") }
    var destZip by remember { mutableStateOf("90210") }
    var destCity by remember { mutableStateOf("Beverly Hills") }
    var destState by remember { mutableStateOf("CA") }
    var destStreet by remember { mutableStateOf("100 Rodeo Drive Suite 4") }

    var selectedService by remember { mutableStateOf(PostalServiceType.PRIORITY_MAIL) }
    var signatureOption by remember { mutableStateOf(false) }
    var printedPackage by remember { mutableStateOf<PostalPackage?>(null) }

    val rate = remember(selectedService, liveWeightOz, destZip, signatureOption) {
        RateEngine.calculatePostage(
            serviceType = selectedService,
            weightOz = liveWeightOz,
            lengthIn = 12.0,
            widthIn = 9.0,
            heightIn = 4.0,
            originZip = "62704",
            destinationZip = destZip,
            signatureRequired = signatureOption
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(USPSLightBg)
    ) {
        // Retail Navigation Bar
        ScrollableTabRow(
            selectedTabIndex = when (activeTab) {
                "POS_COUNTER" -> 0
                "PO_BOX_DESK" -> 1
                "TRANSACTIONS" -> 2
                else -> 0
            },
            containerColor = Color.White,
            contentColor = USPSBluePrimary,
            edgePadding = 12.dp
        ) {
            Tab(selected = activeTab == "POS_COUNTER", onClick = { onTabChange("POS_COUNTER") }, text = { Text("POS Counter & Scale") }, icon = { Icon(Icons.Default.PointOfSale, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "PO_BOX_DESK", onClick = { onTabChange("PO_BOX_DESK") }, text = { Text("PO Box & Hold Desk (${poBoxes.size})") }, icon = { Icon(Icons.Default.Inbox, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "TRANSACTIONS", onClick = { onTabChange("TRANSACTIONS") }, text = { Text("Daily Ledger (${transactions.size})") }, icon = { Icon(Icons.Default.ReceiptLong, null, Modifier.size(18.dp)) })
        }

        Divider(color = USPSBorder)

        when (activeTab) {
            "POS_COUNTER" -> {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Left: Scale & Destination Input
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        // Toledo PS-60 Integrated Scale Readout Card
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Icon(Icons.Default.Scale, contentDescription = null, tint = Color(0xFF38BDF8))
                                        Text("TOLEDO PS-60 RETAIL COUNTER SCALE", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                    Surface(color = Color(0xFF065F46), shape = RoundedCornerShape(4.dp)) {
                                        Text("CALIBRATED", color = Color(0xFF34D399), fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.Bottom
                                ) {
                                    Column {
                                        Text("LIVE WEIGHT READOUT", color = Color(0xFF94A3B8), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                        Text(
                                            text = String.format("%.1f OZ", liveWeightOz),
                                            color = Color(0xFF38BDF8),
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Black,
                                            fontSize = 28.sp
                                        )
                                        Text(
                                            text = String.format("(%.2f LBS)", liveWeightOz / 16.0),
                                            color = Color(0xFF94A3B8),
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 13.sp
                                        )
                                    }

                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        OutlinedButton(
                                            onClick = onTareScale,
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text("ZERO / TARE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }

                                        Button(
                                            onClick = {
                                                // Cycle through realistic parcel weights
                                                val nextW = if (liveWeightOz < 16.0) 32.0 else if (liveWeightOz < 48.0) 64.0 else 14.5
                                                onSetWeight(nextW)
                                            },
                                            colors = ButtonDefaults.buttonColors(containerColor = USPSBluePrimary),
                                            shape = RoundedCornerShape(6.dp)
                                        ) {
                                            Text("SIMULATE WT", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }

                        // Customer & Destination Intake Form
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("CUSTOMER & DESTINATION DISPATCH", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = USPSBluePrimary)

                                OutlinedTextField(value = customerName, onValueChange = { customerName = it }, label = { Text("Customer Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = destStreet, onValueChange = { destStreet = it }, label = { Text("Destination Street Address") }, singleLine = true, modifier = Modifier.fillMaxWidth())

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedTextField(value = destCity, onValueChange = { destCity = it }, label = { Text("City") }, modifier = Modifier.weight(2f))
                                    OutlinedTextField(value = destState, onValueChange = { destState = it }, label = { Text("State") }, modifier = Modifier.weight(1f))
                                    OutlinedTextField(value = destZip, onValueChange = { destZip = it }, label = { Text("ZIP") }, modifier = Modifier.weight(1.5f))
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text("Add Signature Confirmation (+$3.65)", fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                                    Switch(checked = signatureOption, onCheckedChange = { signatureOption = it })
                                }
                            }
                        }

                        // Service Class Comparison
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("DOMESTIC SERVICE COMPARISON", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = USPSBluePrimary)

                                listOf(PostalServiceType.PRIORITY_MAIL_EXPRESS, PostalServiceType.PRIORITY_MAIL, PostalServiceType.USPS_GROUND_ADVANTAGE).forEach { srv ->
                                    val isSel = srv == selectedService
                                    Surface(
                                        color = if (isSel) Color(0xFFEFF6FF) else Color(0xFFF8FAFC),
                                        shape = RoundedCornerShape(8.dp),
                                        border = if (isSel) BorderStroke(1.5.dp, USPSBluePrimary) else null,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clickable { selectedService = srv }
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(10.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(srv.displayName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                Text(srv.deliverySpeed, fontSize = 10.sp, color = Color(0xFF64748B))
                                            }
                                            Text(
                                                text = String.format("$%.2f", srv.baseRateCents / 100.0),
                                                fontWeight = FontWeight.Black,
                                                fontSize = 13.sp,
                                                color = USPSBluePrimary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Right: POS Checkout & Thermal Print
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("RETAIL TRANSACTION TOTAL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)

                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Service", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                    Text(selectedService.displayName, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Calculated Weight", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                    Text("${liveWeightOz} oz", color = Color.White, fontSize = 11.sp)
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Base Rate", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                    Text(rate.formattedBase, color = Color.White, fontSize = 11.sp)
                                }
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("Weight Surcharge", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                    Text(String.format("$%.2f", rate.weightSurchargeCents / 100.0), color = Color.White, fontSize = 11.sp)
                                }
                                if (signatureOption) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text("Signature Confirmation", color = Color(0xFF94A3B8), fontSize = 11.sp)
                                        Text("$3.65", color = Color.White, fontSize = 11.sp)
                                    }
                                }

                                Divider(color = Color(0xFF334155))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("TOTAL DUE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 15.sp)
                                    Text(rate.formattedTotal, color = Color(0xFF38BDF8), fontWeight = FontWeight.Black, fontSize = 20.sp)
                                }

                                Spacer(modifier = Modifier.height(6.dp))

                                Button(
                                    onClick = {
                                        val pkg = onCreateShipment(
                                            selectedService,
                                            PostalAddress("USPS Springfield Retail Counter", "400 Main St", null, "Springfield", "IL", "62704"),
                                            PostalAddress(customerName, destStreet, null, destCity, destState, destZip),
                                            liveWeightOz,
                                            12.0,
                                            9.0,
                                            4.0,
                                            signatureOption,
                                            "EMV / Contactless Card"
                                        )
                                        printedPackage = pkg
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = USPSBluePrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Icon(Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("COLLECT PAYMENT & PRINT THERMAL LABEL", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                }
                            }
                        }

                        if (printedPackage != null) {
                            ThermalLabelCard(
                                postalPackage = printedPackage!!,
                                onPrintClick = { onPrintLabel(printedPackage!!) }
                            )
                        }
                    }
                }
            }

            "PO_BOX_DESK" -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(poBoxes) { box ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(10.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(box.boxNumber, fontWeight = FontWeight.Black, fontSize = 14.sp, color = USPSBluePrimary)
                                    Text("Renter: ${box.customerName} • ${box.sizeCategory}", fontSize = 11.sp, color = USPSTextSecondary)
                                    Text("Renewal: ${box.renewalDate}", fontSize = 10.sp, color = Color(0xFF94A3B8))
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Surface(color = Color(0xFFEFF6FF), shape = RoundedCornerShape(6.dp)) {
                                        Text("${box.uncollectedLetters} Letters / ${box.uncollectedParcels} Parcels", color = USPSBluePrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                    }
                                    Button(
                                        onClick = {},
                                        colors = ButtonDefaults.buttonColors(containerColor = USPSBluePrimary),
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("Handout Mail", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            "TRANSACTIONS" -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(transactions) { tx ->
                        Card(
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            shape = RoundedCornerShape(8.dp),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("${tx.transactionId} • ${tx.timestamp}", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    Text("Customer: ${tx.customerName} (Dest: ${tx.destinationZip})", fontSize = 11.sp, color = USPSTextSecondary)
                                    Text("Barcode: ${tx.labelBarcode}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF64748B))
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = String.format("$%.2f", tx.totalCents / 100.0),
                                        fontWeight = FontWeight.Black,
                                        fontSize = 14.sp,
                                        color = USPSBluePrimary
                                    )
                                    Text(tx.paymentMethod, fontSize = 9.sp, color = Color(0xFF64748B))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
