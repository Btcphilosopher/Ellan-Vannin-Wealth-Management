package com.example.ui.workspaces

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.InitialSyntheticData
import com.example.engine.RateEngine
import com.example.model.*
import com.example.ui.components.ThermalLabelCard
import com.example.ui.components.TrackingTimeline
import com.example.ui.theme.*

@Composable
fun CustomerWorkspace(
    packages: List<PostalPackage>,
    mailpieces: List<Mailpiece>,
    smartLockers: List<SmartLocker>,
    poBoxes: List<POBoxItem>,
    activeTab: String,
    onTabChange: (String) -> Unit,
    selectedPackage: PostalPackage?,
    onSelectPackage: (PostalPackage?) -> Unit,
    onCreateShipment: (PostalServiceType, PostalAddress, PostalAddress, Double, Double, Double, Double, Boolean, String) -> PostalPackage,
    onPickupLocker: (String, String) -> Boolean,
    onPrintLabel: (PostalPackage) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(USPSLightBg)
    ) {
        // Navigation Tabs for Customer
        ScrollableTabRow(
            selectedTabIndex = when (activeTab) {
                "HOME" -> 0
                "TRACK" -> 1
                "SHIP" -> 2
                "INFORMED_DELIVERY" -> 3
                "LOCKERS" -> 4
                "RETURNS" -> 5
                else -> 0
            },
            containerColor = Color.White,
            contentColor = USPSBluePrimary,
            edgePadding = 12.dp
        ) {
            Tab(selected = activeTab == "HOME", onClick = { onTabChange("HOME") }, text = { Text("Overview") }, icon = { Icon(Icons.Default.Home, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "TRACK", onClick = { onTabChange("TRACK") }, text = { Text("Track (${packages.size})") }, icon = { Icon(Icons.Default.LocalShipping, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "SHIP", onClick = { onTabChange("SHIP") }, text = { Text("Ship & Labels") }, icon = { Icon(Icons.Default.AddBox, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "INFORMED_DELIVERY", onClick = { onTabChange("INFORMED_DELIVERY") }, text = { Text("Informed Delivery® (${mailpieces.size})") }, icon = { Icon(Icons.Default.Mail, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "LOCKERS", onClick = { onTabChange("LOCKERS") }, text = { Text("Lockers & PO Box") }, icon = { Icon(Icons.Default.Lock, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "RETURNS", onClick = { onTabChange("RETURNS") }, text = { Text("Returns & Help") }, icon = { Icon(Icons.Default.AssignmentReturn, null, Modifier.size(18.dp)) })
        }

        Divider(color = USPSBorder)

        Box(modifier = Modifier.weight(1f)) {
            when (activeTab) {
                "HOME" -> CustomerHomeOverview(
                    packages = packages,
                    mailpieces = mailpieces,
                    smartLockers = smartLockers,
                    onNavigateTab = onTabChange,
                    onSelectPackage = {
                        onSelectPackage(it)
                        onTabChange("TRACK")
                    }
                )
                "TRACK" -> CustomerTrackView(
                    packages = packages,
                    selectedPackage = selectedPackage ?: packages.firstOrNull(),
                    onSelectPackage = onSelectPackage
                )
                "SHIP" -> CustomerShipView(
                    onCreateShipment = onCreateShipment,
                    onPrintLabel = onPrintLabel
                )
                "INFORMED_DELIVERY" -> CustomerInformedDeliveryView(mailpieces = mailpieces)
                "LOCKERS" -> CustomerLockersAndPOBoxesView(
                    lockers = smartLockers,
                    poBoxes = poBoxes,
                    onPickupLocker = onPickupLocker
                )
                "RETURNS" -> CustomerReturnsAndSupportView()
            }
        }
    }
}

@Composable
fun CustomerHomeOverview(
    packages: List<PostalPackage>,
    mailpieces: List<Mailpiece>,
    smartLockers: List<SmartLocker>,
    onNavigateTab: (String) -> Unit,
    onSelectPackage: (PostalPackage) -> Unit
) {
    val scrollState = rememberScrollState()
    val urgentDelivery = packages.firstOrNull { it.status == PackageStatus.OUT_FOR_DELIVERY } ?: packages.firstOrNull()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Active Delivery Card
        if (urgentDelivery != null) {
            Card(
                colors = CardDefaults.cardColors(containerColor = USPSBlueDark),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectPackage(urgentDelivery) }
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = if (urgentDelivery.status == PackageStatus.OUT_FOR_DELIVERY) USPSRedAccent else Color(0xFF2563EB),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = urgentDelivery.status.label.uppercase(),
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Black,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        Text(
                            text = urgentDelivery.serviceType.displayName,
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Expected Delivery: ${urgentDelivery.estimatedDelivery}",
                        color = Color.White,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = "Tracking: ${urgentDelivery.trackingNumber}",
                        color = Color(0xFF38BDF8),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "From: ${urgentDelivery.sender.residentName} (${urgentDelivery.sender.city}, ${urgentDelivery.sender.state})",
                        color = Color(0xFFE2E8F0),
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = urgentDelivery.latestEventTime,
                            color = Color(0xFF94A3B8),
                            fontSize = 11.sp
                        )

                        Text(
                            text = "View Full Tracking →",
                            color = Color(0xFF38BDF8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Summary Quick Counters
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            QuickCounterCard(
                title = "Incoming Parcels",
                count = packages.count { it.status != PackageStatus.DELIVERED }.toString(),
                icon = Icons.Default.LocalShipping,
                accentColor = USPSBluePrimary,
                modifier = Modifier.weight(1f),
                onClick = { onNavigateTab("TRACK") }
            )

            QuickCounterCard(
                title = "Informed Mail",
                count = mailpieces.size.toString(),
                icon = Icons.Default.Mail,
                accentColor = Color(0xFF4338CA),
                modifier = Modifier.weight(1f),
                onClick = { onNavigateTab("INFORMED_DELIVERY") }
            )

            QuickCounterCard(
                title = "Smart Lockers",
                count = smartLockers.count { it.status == "OCCUPIED" }.toString(),
                icon = Icons.Default.Lock,
                accentColor = StatusPurple,
                modifier = Modifier.weight(1f),
                onClick = { onNavigateTab("LOCKERS") }
            )
        }

        // Quick Postal Actions Grid
        Text(
            text = "QUICK POSTAL ACTIONS",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = USPSBluePrimary,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ActionTile(
                title = "Ship Package",
                subtitle = "Print 4x6 labels",
                icon = Icons.Default.AddBox,
                color = USPSBluePrimary,
                modifier = Modifier.weight(1f),
                onClick = { onNavigateTab("SHIP") }
            )
            ActionTile(
                title = "Track Number",
                subtitle = "Live scanner & map",
                icon = Icons.Default.Search,
                color = Color(0xFF0F172A),
                modifier = Modifier.weight(1f),
                onClick = { onNavigateTab("TRACK") }
            )
            ActionTile(
                title = "Smart Lockers",
                subtitle = "Enter 6-digit PIN",
                icon = Icons.Default.LockClock,
                color = StatusPurple,
                modifier = Modifier.weight(1f),
                onClick = { onNavigateTab("LOCKERS") }
            )
            ActionTile(
                title = "Returns",
                subtitle = "Prepaid labels",
                icon = Icons.Default.AssignmentReturn,
                color = USPSRedAccent,
                modifier = Modifier.weight(1f),
                onClick = { onNavigateTab("RETURNS") }
            )
        }

        // Active Packages List
        Text(
            text = "RECENT SHIPMENTS & DELIVERIES",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = USPSBluePrimary,
            letterSpacing = 1.sp
        )

        packages.forEach { pkg ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectPackage(pkg) }
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Surface(
                        color = when (pkg.status) {
                            PackageStatus.DELIVERED -> StatusGreenBg
                            PackageStatus.OUT_FOR_DELIVERY -> StatusBlueBg
                            else -> StatusAmberBg
                        },
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.size(42.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (pkg.status == PackageStatus.DELIVERED) Icons.Default.CheckCircle else Icons.Default.LocalShipping,
                                contentDescription = null,
                                tint = when (pkg.status) {
                                    PackageStatus.DELIVERED -> StatusGreen
                                    PackageStatus.OUT_FOR_DELIVERY -> USPSBluePrimary
                                    else -> StatusAmber
                                }
                            )
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = pkg.serviceType.displayName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = USPSTextPrimary
                            )
                            Surface(
                                color = when (pkg.status) {
                                    PackageStatus.DELIVERED -> StatusGreen
                                    PackageStatus.OUT_FOR_DELIVERY -> USPSBluePrimary
                                    else -> StatusAmber
                                },
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = pkg.status.label,
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = "To: ${pkg.recipient.residentName} (${pkg.recipient.city}, ${pkg.recipient.state})",
                            fontSize = 11.sp,
                            color = USPSTextSecondary
                        )

                        Text(
                            text = pkg.trackingNumber,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun QuickCounterCard(
    title: String,
    count: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(12.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.height(6.dp))
            Text(count, fontSize = 20.sp, fontWeight = FontWeight.Black, color = USPSTextPrimary)
            Text(title, fontSize = 10.sp, color = USPSTextSecondary, maxLines = 1)
        }
    }
}

@Composable
fun ActionTile(
    title: String,
    subtitle: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(10.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.Start
        ) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .background(color.copy(alpha = 0.1f), RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = USPSTextPrimary, maxLines = 1)
            Text(subtitle, fontSize = 9.sp, color = USPSTextSecondary, maxLines = 1)
        }
    }
}

@Composable
fun CustomerTrackView(
    packages: List<PostalPackage>,
    selectedPackage: PostalPackage?,
    onSelectPackage: (PostalPackage?) -> Unit
) {
    val scrollState = rememberScrollState()

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Package Selector List
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .width(280.dp)
                .fillMaxHeight()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = "ACTIVE PACKAGES (${packages.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = USPSBluePrimary
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(packages) { pkg ->
                        val isSelected = pkg.trackingNumber == selectedPackage?.trackingNumber
                        Surface(
                            color = if (isSelected) Color(0xFFEFF6FF) else Color(0xFFF8FAFC),
                            border = if (isSelected) BorderStroke(1.5.dp, USPSBluePrimary) else null,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectPackage(pkg) }
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = pkg.serviceType.displayName,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSelected) USPSBluePrimary else USPSTextPrimary
                                )
                                Text(
                                    text = pkg.trackingNumber.chunked(4).joinToString(" "),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = Color(0xFF64748B)
                                )
                                Text(
                                    text = pkg.status.label,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = when (pkg.status) {
                                        PackageStatus.DELIVERED -> StatusGreen
                                        PackageStatus.OUT_FOR_DELIVERY -> USPSBluePrimary
                                        else -> StatusAmber
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // Right Package Detail & Timeline
        if (selectedPackage != null) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Tracking Header Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(12.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = selectedPackage.trackingNumber.chunked(4).joinToString(" "),
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = USPSBluePrimary
                                )
                                Text(
                                    text = "${selectedPackage.serviceType.displayName} • ${selectedPackage.weightOz} oz",
                                    fontSize = 11.sp,
                                    color = USPSTextSecondary
                                )
                            }

                            Surface(
                                color = when (selectedPackage.status) {
                                    PackageStatus.DELIVERED -> StatusGreen
                                    PackageStatus.OUT_FOR_DELIVERY -> USPSBluePrimary
                                    else -> StatusAmber
                                },
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = selectedPackage.status.label.uppercase(),
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = USPSBorder)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text("FROM:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                                Text(selectedPackage.sender.residentName, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("${selectedPackage.sender.streetAddress}, ${selectedPackage.sender.city} ${selectedPackage.sender.state}", fontSize = 10.sp, color = USPSTextSecondary)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text("TO:", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF64748B))
                                Text(selectedPackage.recipient.residentName, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Text("${selectedPackage.recipient.streetAddress}, ${selectedPackage.recipient.city} ${selectedPackage.recipient.state}", fontSize = 10.sp, color = USPSTextSecondary)
                            }
                        }

                        if (selectedPackage.signatureRequired) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Surface(color = Color(0xFFFEF2F2), shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = "⚠ Signature Required by Recipient upon delivery",
                                    color = USPSRedAccent,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }
                }

                // Milestones & Event Log
                TrackingTimeline(
                    status = selectedPackage.status,
                    events = InitialSyntheticData.SAMPLE_EVENTS.filter { it.trackingNumber == selectedPackage.trackingNumber }.ifEmpty {
                        listOf(
                            TrackingEvent(
                                eventId = "evt_gen",
                                trackingNumber = selectedPackage.trackingNumber,
                                timestamp = "Today",
                                location = "${selectedPackage.recipient.city}, ${selectedPackage.recipient.state}",
                                facility = selectedPackage.currentFacility,
                                scanType = selectedPackage.status.label.uppercase(),
                                status = selectedPackage.status,
                                description = selectedPackage.latestEventTime
                            )
                        )
                    }
                )
            }
        }
    }
}

@Composable
fun CustomerShipView(
    onCreateShipment: (PostalServiceType, PostalAddress, PostalAddress, Double, Double, Double, Double, Boolean, String) -> PostalPackage,
    onPrintLabel: (PostalPackage) -> Unit
) {
    val scrollState = rememberScrollState()

    var senderName by remember { mutableStateOf("Alex Morgan") }
    var senderStreet by remember { mutableStateOf("742 Evergreen Terrace") }
    var senderCity by remember { mutableStateOf("Springfield") }
    var senderState by remember { mutableStateOf("IL") }
    var senderZip by remember { mutableStateOf("62704") }

    var recipientName by remember { mutableStateOf("Elena Rostova") }
    var recipientStreet by remember { mutableStateOf("1540 Market St Suite 200") }
    var recipientCity by remember { mutableStateOf("San Francisco") }
    var recipientState by remember { mutableStateOf("CA") }
    var recipientZip by remember { mutableStateOf("94102") }

    var weightOz by remember { mutableStateOf("18.5") }
    var lengthIn by remember { mutableStateOf("12.0") }
    var widthIn by remember { mutableStateOf("9.0") }
    var heightIn by remember { mutableStateOf("4.0") }
    var selectedService by remember { mutableStateOf(PostalServiceType.PRIORITY_MAIL) }
    var isSignatureReq by remember { mutableStateOf(false) }
    var paymentMethod by remember { mutableStateOf("Apple Pay (Digital Wallet)") }

    var generatedPackage by remember { mutableStateOf<PostalPackage?>(null) }

    val rateBreakdown = remember(selectedService, weightOz, lengthIn, widthIn, heightIn, senderZip, recipientZip, isSignatureReq) {
        val w = weightOz.toDoubleOrNull() ?: 16.0
        val l = lengthIn.toDoubleOrNull() ?: 10.0
        val wi = widthIn.toDoubleOrNull() ?: 6.0
        val h = heightIn.toDoubleOrNull() ?: 4.0
        RateEngine.calculatePostage(
            serviceType = selectedService,
            weightOz = w,
            lengthIn = l,
            widthIn = wi,
            heightIn = h,
            originZip = senderZip,
            destinationZip = recipientZip,
            signatureRequired = isSignatureReq
        )
    }

    Row(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Left Column: Shipping Form
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("1. SENDER ADDRESS (FROM)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = USPSBluePrimary)
                    OutlinedTextField(value = senderName, onValueChange = { senderName = it }, label = { Text("Sender Full Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = senderStreet, onValueChange = { senderStreet = it }, label = { Text("Street Address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = senderCity, onValueChange = { senderCity = it }, label = { Text("City") }, modifier = Modifier.weight(2f))
                        OutlinedTextField(value = senderState, onValueChange = { senderState = it }, label = { Text("State") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = senderZip, onValueChange = { senderZip = it }, label = { Text("ZIP") }, modifier = Modifier.weight(1.5f))
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("2. RECIPIENT ADDRESS (SHIP TO)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = USPSBluePrimary)
                    OutlinedTextField(value = recipientName, onValueChange = { recipientName = it }, label = { Text("Recipient Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = recipientStreet, onValueChange = { recipientStreet = it }, label = { Text("Street Address") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = recipientCity, onValueChange = { recipientCity = it }, label = { Text("City") }, modifier = Modifier.weight(2f))
                        OutlinedTextField(value = recipientState, onValueChange = { recipientState = it }, label = { Text("State") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = recipientZip, onValueChange = { recipientZip = it }, label = { Text("ZIP") }, modifier = Modifier.weight(1.5f))
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("3. PACKAGE WEIGHT & DIMENSIONS", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = USPSBluePrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(value = weightOz, onValueChange = { weightOz = it }, label = { Text("Weight (Oz)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = lengthIn, onValueChange = { lengthIn = it }, label = { Text("Length (in)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = widthIn, onValueChange = { widthIn = it }, label = { Text("Width (in)") }, modifier = Modifier.weight(1f))
                        OutlinedTextField(value = heightIn, onValueChange = { heightIn = it }, label = { Text("Height (in)") }, modifier = Modifier.weight(1f))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Signature Confirmation (+$3.65)", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        Switch(checked = isSignatureReq, onCheckedChange = { isSignatureReq = it })
                    }
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("4. SELECT POSTAL SERVICE", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = USPSBluePrimary)
                    PostalServiceType.entries.filter { it != PostalServiceType.FIRST_CLASS_MAIL }.forEach { srv ->
                        Surface(
                            color = if (selectedService == srv) Color(0xFFEFF6FF) else Color(0xFFF8FAFC),
                            border = if (selectedService == srv) BorderStroke(1.5.dp, USPSBluePrimary) else null,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedService = srv }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(srv.displayName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(srv.deliverySpeed, fontSize = 10.sp, color = Color(0xFF64748B))
                                }
                                Text(
                                    text = String.format("$%.2f", srv.baseRateCents / 100.0),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 14.sp,
                                    color = USPSBluePrimary
                                )
                            }
                        }
                    }
                }
            }
        }

        // Right Column: Summary & Label Output
        Column(
            modifier = Modifier
                .weight(1f)
                .fillMaxHeight()
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("POSTAGE SUMMARY (EXACT MINOR CENTS)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Base Rate", color = Color(0xFF94A3B8), fontSize = 11.sp)
                        Text(rateBreakdown.formattedBase, color = Color.White, fontSize = 11.sp)
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Weight Surcharge", color = Color(0xFF94A3B8), fontSize = 11.sp)
                        Text(String.format("$%.2f", rateBreakdown.weightSurchargeCents / 100.0), color = Color.White, fontSize = 11.sp)
                    }
                    if (rateBreakdown.signatureConfirmationCents > 0) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Signature Fee", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            Text(String.format("$%.2f", rateBreakdown.signatureConfirmationCents / 100.0), color = Color.White, fontSize = 11.sp)
                        }
                    }

                    Divider(color = Color(0xFF334155))

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("TOTAL POSTAGE", color = Color.White, fontWeight = FontWeight.Black, fontSize = 14.sp)
                        Text(rateBreakdown.formattedTotal, color = Color(0xFF38BDF8), fontWeight = FontWeight.Black, fontSize = 18.sp)
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = {
                            val pkg = onCreateShipment(
                                selectedService,
                                PostalAddress(senderName, senderStreet, null, senderCity, senderState, senderZip),
                                PostalAddress(recipientName, recipientStreet, null, recipientCity, recipientState, recipientZip),
                                weightOz.toDoubleOrNull() ?: 16.0,
                                lengthIn.toDoubleOrNull() ?: 10.0,
                                widthIn.toDoubleOrNull() ?: 6.0,
                                heightIn.toDoubleOrNull() ?: 4.0,
                                isSignatureReq,
                                paymentMethod
                            )
                            generatedPackage = pkg
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = USPSBluePrimary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.CreditCard, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("PURCHASE & GENERATE 4x6 THERMAL LABEL", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }

            if (generatedPackage != null) {
                ThermalLabelCard(
                    postalPackage = generatedPackage!!,
                    onPrintClick = { onPrintLabel(generatedPackage!!) }
                )
            }
        }
    }
}

@Composable
fun CustomerInformedDeliveryView(mailpieces: List<Mailpiece>) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = USPSBlueDark),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(USPSBluePrimary, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Mail, contentDescription = null, tint = Color.White)
                    }
                    Column {
                        Text("INFORMED DELIVERY® DIGITAL DAILY DIGEST", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("Preview scanned grayscale images of incoming letter mail arriving at your address today.", color = Color(0xFF94A3B8), fontSize = 11.sp)
                    }
                }
            }
        }

        items(mailpieces) { mp ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = mp.mailClass.title,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = USPSBluePrimary
                        )
                        Text(
                            text = "Arriving: ${mp.receivedDate}",
                            fontSize = 10.sp,
                            color = Color(0xFF64748B)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Simulated Scanned Envelope Visual Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(120.dp)
                            .background(Color(0xFFF1F5F9), RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0xFFCBD5E1), RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column(modifier = Modifier.align(Alignment.TopStart)) {
                            Text(mp.senderName, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color(0xFF334155))
                            Text("Official Postal Dispatch", fontSize = 9.sp, color = Color(0xFF64748B))
                        }

                        // Synthetic stamp in top right
                        Surface(
                            color = USPSBluePrimary,
                            shape = RoundedCornerShape(2.dp),
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .size(30.dp, 36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("USPS\nUSA", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Bold, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                            }
                        }

                        // Recipient address in center
                        Column(modifier = Modifier.align(Alignment.Center)) {
                            Text(mp.recipientName, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text(mp.address, fontSize = 10.sp)
                        }

                        // Intelligent Mail Barcode on bottom
                        Text(
                            text = "|||'|''|''||''|||''|'|''|||''|||'|''||''|||",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Color.Black,
                            modifier = Modifier.align(Alignment.BottomCenter)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(mp.note, fontSize = 11.sp, color = USPSTextSecondary)

                    if (mp.hasActionRequired) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(color = Color(0xFFFEF3C7), shape = RoundedCornerShape(4.dp)) {
                            Text(
                                text = "⚡ Action Recommended - Tax Documentation Enclosed",
                                color = Color(0xFFB45309),
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerLockersAndPOBoxesView(
    lockers: List<SmartLocker>,
    poBoxes: List<POBoxItem>,
    onPickupLocker: (String, String) -> Boolean
) {
    var pinInput by remember { mutableStateOf("") }
    var selectedLockerId by remember { mutableStateOf("LCK-01") }
    var pickupResultMsg by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                text = "SMART PARCEL LOCKER BANK (24/7 SELF-SERVICE)",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = USPSBluePrimary
            )
        }

        items(lockers) { locker ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .background(if (locker.status == "OCCUPIED") StatusPurpleBg else Color(0xFFF1F5F9), RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "#${locker.compartmentNumber}",
                            fontWeight = FontWeight.Black,
                            fontSize = 14.sp,
                            color = if (locker.status == "OCCUPIED") StatusPurple else Color(0xFF64748B)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(locker.locationName, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Surface(
                                color = if (locker.status == "OCCUPIED") StatusPurple else StatusGreen,
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = if (locker.status == "OCCUPIED") "READY FOR PICKUP" else "AVAILABLE",
                                    color = Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        if (locker.status == "OCCUPIED") {
                            Text("Tracking: ${locker.trackingNumber}", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF64748B))
                            Text("Pickup PIN: ${locker.pickupPin} • Expires ${locker.expiresAt}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = StatusPurple)
                        } else {
                            Text("Compartment empty / ready for carrier dispatch", fontSize = 10.sp, color = Color(0xFF94A3B8))
                        }
                    }
                }
            }
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ONE-TOUCH SMART LOCKER RETRIEVAL KIOSK", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = { pinInput = it },
                            placeholder = { Text("Enter 6-digit PIN (e.g. 849201)", color = Color(0xFF94A3B8), fontSize = 11.sp) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0xFF475569)
                            ),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        Button(
                            onClick = {
                                val success = onPickupLocker("LCK-01", pinInput.trim())
                                pickupResultMsg = if (success) "✓ Compartment #12 Unlocked! Package Retrieved." else "✕ Invalid PIN or Empty Locker."
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusPurple),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Unlock Door", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    if (pickupResultMsg != null) {
                        Text(
                            text = pickupResultMsg!!,
                            color = if (pickupResultMsg!!.startsWith("✓")) Color(0xFF34D399) else Color(0xFFF87171),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
            Text("YOUR POST OFFICE BOXES", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = USPSBluePrimary)
        }

        items(poBoxes) { box ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Color.White),
                shape = RoundedCornerShape(10.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(box.boxNumber, fontWeight = FontWeight.Black, fontSize = 13.sp, color = USPSBluePrimary)
                        Text("${box.sizeCategory} • Assigned: ${box.customerName}", fontSize = 11.sp, color = USPSTextSecondary)
                        Text("Renewal: ${box.renewalDate}", fontSize = 10.sp, color = Color(0xFF94A3B8))
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Surface(color = StatusGreenBg, shape = RoundedCornerShape(4.dp)) {
                            Text(box.status, color = StatusGreen, fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${box.uncollectedLetters} letters • ${box.uncollectedParcels} parcel", fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}

@Composable
fun CustomerReturnsAndSupportView() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("INSTANT MERCHANDISE RETURN (USPS RETURNS®)", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = USPSBluePrimary)
                Text("Generate a digital QR code for retail counter drop-off (Label Broker®) or print a return label at home.", fontSize = 11.sp, color = USPSTextSecondary)

                OutlinedTextField(value = "RET-9400-AMAZON-88192", onValueChange = {}, label = { Text("Retailer Return Authorization RMA") }, modifier = Modifier.fillMaxWidth(), singleLine = true)

                Button(
                    onClick = {},
                    colors = ButtonDefaults.buttonColors(containerColor = USPSBluePrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.QrCode, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("GENERATE LABEL BROKER® QR CODE", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
        }

        Card(
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("CUSTOMER SERVICE & DELIVERY INQUIRIES", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = USPSBluePrimary)
                Text("Direct escalation ticket linked to Springfield Delivery Station.", fontSize = 11.sp, color = USPSTextSecondary)

                Surface(color = Color(0xFFF8FAFC), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Case #USPS-99201: Package Instructions Confirmation", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Status: Resolved by Carrier Jordan Williams (Left inside storm porch)", fontSize = 11.sp, color = StatusGreen)
                    }
                }
            }
        }
    }
}
