package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "packages")
data class PackageEntity(
    @PrimaryKey val trackingNumber: String,
    val serviceCode: String,
    val senderName: String,
    val senderStreet: String,
    val senderCity: String,
    val senderState: String,
    val senderZip: String,
    val recipientName: String,
    val recipientStreet: String,
    val recipientCity: String,
    val recipientState: String,
    val recipientZip: String,
    val status: String,
    val weightOz: Double,
    val lengthIn: Double,
    val widthIn: Double,
    val heightIn: Double,
    val postageCents: Int,
    val signatureRequired: Boolean,
    val estimatedDelivery: String,
    val latestEventTime: String,
    val currentFacility: String,
    val deliveryLocationNote: String? = null,
    val lockerCode: String? = null
)

@Entity(tableName = "tracking_events")
data class TrackingEventEntity(
    @PrimaryKey val eventId: String,
    val trackingNumber: String,
    val timestamp: String,
    val location: String,
    val facility: String,
    val scanType: String,
    val status: String,
    val description: String,
    val lat: Double,
    val lon: Double,
    val source: String
)

@Entity(tableName = "retail_transactions")
data class RetailTransactionEntity(
    @PrimaryKey val transactionId: String,
    val timestamp: String,
    val customerName: String,
    val destinationZip: String,
    val serviceCode: String,
    val weightOz: Double,
    val totalCents: Int,
    val paymentMethod: String,
    val isPaid: Boolean,
    val labelBarcode: String,
    val receiptId: String
)

@Entity(tableName = "exceptions")
data class ExceptionEntity(
    @PrimaryKey val exceptionId: String,
    val trackingNumber: String,
    val type: String,
    val severity: String,
    val description: String,
    val status: String,
    val assignedTo: String,
    val createdAt: String
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
    @PrimaryKey val eventId: String,
    val timestamp: String,
    val actor: String,
    val role: String,
    val facility: String,
    val action: String,
    val resource: String,
    val resourceId: String,
    val result: String,
    val correlationId: String
)

@Entity(tableName = "sync_queue")
data class SyncQueueEntity(
    @PrimaryKey val id: String,
    val actionType: String,
    val payloadSummary: String,
    val timestamp: String,
    val status: String
)
