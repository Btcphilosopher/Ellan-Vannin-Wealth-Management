package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.USPSBluePrimary
import com.example.ui.theme.USPSRedAccent

@Composable
fun BarcodeScannerOverlay(
    onBarcodeScanned: (String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var manualCodeInput by remember { mutableStateOf("") }
    val infiniteTransition = rememberInfiniteTransition(label = "laser")
    val laserY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laserY"
    )

    Surface(
        color = Color(0xEE0A1931),
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(
                        imageVector = Icons.Default.QrCodeScanner,
                        contentDescription = null,
                        tint = Color.White
                    )
                    Text(
                        text = "RAPID OPTICAL POSTAL SCANNER",
                        color = Color.White,
                        fontWeight = FontWeight.Black,
                        fontSize = 14.sp
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                }
            }

            // Central Viewfinder Reticle
            Box(
                modifier = Modifier
                    .size(280.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x33000000))
                    .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                // Animated red laser scan line
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp)
                        .align(Alignment.TopCenter)
                        .offset(y = (laserY * 270).dp)
                        .background(USPSRedAccent)
                )

                Text(
                    text = "Align USPS 1D Barcode, QR Code, or Intelligent Mail Barcode within frame",
                    color = Color(0xFFE2E8F0),
                    fontSize = 11.sp,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                    modifier = Modifier.padding(24.dp)
                )
            }

            // Quick Simulation Scan Triggers & Manual Entry
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "SIMULATE HARDWARE SCAN (QUICK TEST CODES)",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF94A3B8)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = Color(0xFF334155),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onBarcodeScanned("9400109205568123908122") }
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Priority Mail", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("9400 1092...", color = Color(0xFF38BDF8), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }

                        Surface(
                            color = Color(0xFF334155),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onBarcodeScanned("9205590164917382910233") }
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Express Signature", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("9205 5901...", color = USPSRedAccent, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }

                        Surface(
                            color = Color(0xFF334155),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onBarcodeScanned("9400109205568999887766") }
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Smart Locker", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("PIN: 849201", color = Color(0xFF34D399), fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Manual Entry Input
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = manualCodeInput,
                            onValueChange = { manualCodeInput = it },
                            placeholder = { Text("Or enter tracking / barcode string...", fontSize = 11.sp, color = Color(0xFF94A3B8)) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White,
                                focusedBorderColor = Color(0xFF38BDF8),
                                unfocusedBorderColor = Color(0xFF475569)
                            ),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        Button(
                            onClick = {
                                if (manualCodeInput.isNotBlank()) {
                                    onBarcodeScanned(manualCodeInput.trim())
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = USPSBluePrimary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("Process", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
