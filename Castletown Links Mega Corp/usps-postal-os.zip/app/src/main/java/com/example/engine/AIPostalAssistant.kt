package com.example.engine

import com.example.model.*

data class AIMessage(
    val id: String,
    val sender: String, // "USER" or "ASSISTANT"
    val content: String,
    val toolInvoked: String? = null,
    val timestamp: String = "Just now"
)

object AIPostalAssistant {

    fun processQuery(
        query: String,
        role: PostalRole,
        packages: List<PostalPackage>,
        carrierRoute: CarrierRoute,
        facilityTelemetry: FacilityTelemetry,
        exceptions: List<ExceptionItem>
    ): AIMessage {
        val q = query.lowercase()

        val responseContent = when {
            q.contains("where is my package") || q.contains("track") || q.contains("status") -> {
                val latest = packages.firstOrNull()
                if (latest != null) {
                    "Tool: `track_package(${latest.trackingNumber})`\n\nPackage **#${latest.trackingNumber}** (${latest.serviceType.displayName}) is currently **${latest.status.label}** at ${latest.currentFacility}.\n\nEstimated Delivery: **${latest.estimatedDelivery}**\nLatest Event: ${latest.latestEventTime}."
                } else {
                    "No active packages found in your tracking queue."
                }
            }

            q.contains("route") || q.contains("stops") || q.contains("carrier") -> {
                if (role == PostalRole.CUSTOMER) {
                    "Your carrier Jordan Williams is currently delivering on Route C-042. Your address at 742 Evergreen Terrace is scheduled for delivery today by 4:00 PM."
                } else {
                    "Tool: `get_carrier_route(${carrierRoute.routeId})`\n\n**Route ${carrierRoute.routeId}** Status: ${carrierRoute.shiftStatus}\n- Total Stops: ${carrierRoute.totalStops} (${carrierRoute.completedStops} completed, ${carrierRoute.totalStops - carrierRoute.completedStops} pending)\n- Parcels: ${carrierRoute.packageCount}\n- Mail Volume: ${carrierRoute.mailVolumeTotal} letters\n- Vehicle: ${carrierRoute.vehicleId}"
                }
            }

            q.contains("signature") -> {
                val sigCount = carrierRoute.stops.count { it.signatureRequired && it.deliveryStatus == "PENDING" }
                "Tool: `filter_manifest(signatureRequired=true)`\n\nThere are **$sigCount stop(s)** requiring physical or Apple Pencil signature on today's route:\n- Stop #1: Alex Morgan (742 Evergreen Terrace) - Express Legal Envelope\n- Stop #4: Charles Montgomery (1000 Mammon Lane) - Certified Mail"
            }

            q.contains("facility") || q.contains("backlog") || q.contains("throughput") -> {
                "Tool: `get_plant_telemetry(${facilityTelemetry.facilityId})`\n\n**${facilityTelemetry.facilityName}** Real-time Status:\n- Hourly Throughput: **${facilityTelemetry.hourlyThroughputPieces} pieces/hr**\n- Current Backlog: **${facilityTelemetry.dailyBacklogPieces} pieces**\n- Inbound / Outbound Docks: ${facilityTelemetry.currentInboundTrucks} Inbound / ${facilityTelemetry.currentOutboundTrucks} Outbound\n- Active Sortation Lanes: ${facilityTelemetry.sortationLanes.size} lanes online"
            }

            q.contains("exception") || q.contains("issue") || q.contains("damage") -> {
                "Tool: `get_active_exceptions()`\n\nThere are **${exceptions.size} active operational exceptions** recorded:\n" +
                        exceptions.joinToString("\n") { "• [${it.severity}] ${it.type} (Pkg: ${it.trackingNumber.take(12)}...): ${it.description}" }
            }

            q.contains("locker") || q.contains("pin") || q.contains("box") -> {
                "Tool: `lookup_smart_locker_inventory()`\n\nYou have 1 package ready for self-service pickup in **Springfield Central Station Hub**:\n- Compartment: **#12**\n- 6-Digit PIN: **849201**\n- Tracking: 9400 1092 0556 8999 8877 66\n- Available 24/7."
            }

            q.contains("rate") || q.contains("cost") || q.contains("ship") || q.contains("price") -> {
                "Tool: `calculate_rate_quote(Weight=16oz, Zone=Local)`\n\nEstimated USPS Postage Rates for 1 lb Standard Package:\n- **USPS Ground Advantage™**: $4.90 (2-5 days)\n- **Priority Mail®**: $9.35 (1-3 days)\n- **Priority Mail Express®**: $30.45 (Guaranteed Next-Day)"
            }

            else -> {
                "I am your USPS Enterprise Postal Assistant. I can check real-time package tracking, carrier route manifests, facility sortation throughput, smart locker pickup codes, and live postage rates. How can I assist your operation today?"
            }
        }

        return AIMessage(
            id = java.util.UUID.randomUUID().toString(),
            sender = "ASSISTANT",
            content = responseContent,
            toolInvoked = if (responseContent.startsWith("Tool: `")) responseContent.substringAfter("Tool: `").substringBefore("`") else null
        )
    }
}
