package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PackageEntity::class,
        TrackingEventEntity::class,
        RetailTransactionEntity::class,
        ExceptionEntity::class,
        AuditEventEntity::class,
        SyncQueueEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PostalDatabase : RoomDatabase() {
    abstract fun postalDao(): PostalDao

    companion object {
        @Volatile
        private var INSTANCE: PostalDatabase? = null

        fun getDatabase(context: Context): PostalDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PostalDatabase::class.java,
                    "usps_postal_os.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
