package com.example.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun AdminWorkspace(
    auditEvents: List<AuditEvent>,
    syncQueue: List<SyncQueueItem>,
    activeTab: String,
    onTabChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .background(USPSLightBg)
    ) {
        ScrollableTabRow(
            selectedTabIndex = when (activeTab) {
                "IDENTITY_ROLES" -> 0
                "AUDIT_LOG" -> 1
                "DEVICES" -> 2
                "SYSTEM_HEALTH" -> 3
                else -> 0
            },
            containerColor = Color.White,
            contentColor = USPSBluePrimary,
            edgePadding = 12.dp
        ) {
            Tab(selected = activeTab == "IDENTITY_ROLES", onClick = { onTabChange("IDENTITY_ROLES") }, text = { Text("Zero-Trust Roles") }, icon = { Icon(Icons.Default.VerifiedUser, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "AUDIT_LOG", onClick = { onTabChange("AUDIT_LOG") }, text = { Text("Immutable Audit Trail (${auditEvents.size})") }, icon = { Icon(Icons.Default.HistoryEdu, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "DEVICES", onClick = { onTabChange("DEVICES") }, text = { Text("Device Fleet (MDD/iPad)") }, icon = { Icon(Icons.Default.Devices, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "SYSTEM_HEALTH", onClick = { onTabChange("SYSTEM_HEALTH") }, text = { Text("Sync & Gateway") }, icon = { Icon(Icons.Default.CloudSync, null, Modifier.size(18.dp)) })
        }

        Divider(color = USPSBorder)

        when (activeTab) {
            "IDENTITY_ROLES" -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text("ENTERPRISE ZERO-TRUST ROLE ROSTER", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = USPSBluePrimary)
                    }

                    items(UserPersona.ALL_PERSONAS) { p ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Text(p.name, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Surface(color = Color(0xFFEFF6FF), shape = RoundedCornerShape(4.dp)) {
                                            Text(p.role.accessBadge, color = USPSBluePrimary, fontSize = 9.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                        }
                                    }
                                    Text("Employee ID: ${p.employeeId ?: "N/A (Customer Persona)"} • ${p.email}", fontSize = 11.sp, color = USPSTextSecondary)
                                    Text("Facility: ${p.facilityName}", fontSize = 10.sp, color = Color(0xFF64748B))
                                }

                                Surface(color = StatusGreenBg, shape = RoundedCornerShape(4.dp)) {
                                    Text("CERTIFIED ACTIVE", color = StatusGreen, fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                                }
                            }
                        }
                    }
                }
            }

            "AUDIT_LOG" -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        Text("IMMUTABLE POSTAL AUDIT TRAIL", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = USPSBluePrimary)
                    }

                    items(auditEvents) { aud ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(12.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text(aud.action, fontWeight = FontWeight.Black, fontSize = 11.sp, color = USPSBluePrimary)
                                    Text(aud.timestamp, fontSize = 10.sp, color = Color(0xFF64748B))
                                }
                                Text("Actor: ${aud.actor} [${aud.role}] @ ${aud.facility}", fontSize = 10.sp, color = USPSTextPrimary)
                                Text("Target: ${aud.resource} (${aud.resourceId}) • Result: ${aud.result}", fontSize = 10.sp, color = Color(0xFF334155))
                                Text("Correlation: ${aud.correlationId}", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF94A3B8))
                            }
                        }
                    }
                }
            }

            "DEVICES" -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("FIELD MDD & IPAD ENTERPRISE FLEET", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = USPSBluePrimary)

                            listOf(
                                Triple("Apple iPad Pro 11\" (Zone 97401 Dispatch Hub)", "OS Version 18.2 • Secure Enclave Active", "COMPLIANT"),
                                Triple("Zebra TC77 Rugged Carrier Terminal #42", "Android Postal OS • GPS Accurate 1.2m", "COMPLIANT"),
                                Triple("Zebra ZP-450 Thermal Counter Printer #01", "USB Host Interface • Ready", "ONLINE")
                            ).forEach { (dev, desc, stat) ->
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                    Column {
                                        Text(dev, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text(desc, fontSize = 11.sp, color = USPSTextSecondary)
                                    }
                                    Surface(color = StatusGreenBg, shape = RoundedCornerShape(4.dp)) {
                                        Text(stat, color = StatusGreen, fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                }
                                Divider(color = Color(0xFFF1F5F9))
                            }
                        }
                    }
                }
            }

            "SYSTEM_HEALTH" -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A))) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("OFFLINE SYNC & RECONCILIATION GATEWAY", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("Queue Items Pending Sync: ${syncQueue.size}", color = Color(0xFF38BDF8), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("Local Storage: Room SQLite Database (usps_postal_os.db) • WAL Mode Active", color = Color(0xFF94A3B8), fontSize = 11.sp)
                            Text("Encryption: SQLCipher 256-bit AES at Rest", color = Color(0xFF94A3B8), fontSize = 11.sp)
                        }
                    }
                }
            }
        }
    }
}
