package com.example.data

import android.content.Context
import com.example.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class PostalRepository(private val context: Context) {
    private val db = PostalDatabase.getDatabase(context)
    private val dao = db.postalDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    // In-memory operational states for real-time fleet & facility
    private val _carrierRoute = MutableStateFlow<CarrierRoute>(InitialSyntheticData.SAMPLE_CARRIER_ROUTE)
    val carrierRoute = _carrierRoute.asStateFlow()

    private val _facilityTelemetry = MutableStateFlow<FacilityTelemetry>(InitialSyntheticData.SAMPLE_FACILITY_TELEMETRY)
    val facilityTelemetry = _facilityTelemetry.asStateFlow()

    private val _equipmentAssets = MutableStateFlow<List<EquipmentAsset>>(InitialSyntheticData.SAMPLE_EQUIPMENT)
    val equipmentAssets = _equipmentAssets.asStateFlow()

    private val _smartLockers = MutableStateFlow<List<SmartLocker>>(InitialSyntheticData.SAMPLE_SMART_LOCKERS)
    val smartLockers = _smartLockers.asStateFlow()

    private val _poBoxes = MutableStateFlow<List<POBoxItem>>(InitialSyntheticData.SAMPLE_PO_BOXES)
    val poBoxes = _poBoxes.asStateFlow()

    private val _mailpieces = MutableStateFlow<List<Mailpiece>>(InitialSyntheticData.SAMPLE_MAILPIECES)
    val mailpieces = _mailpieces.asStateFlow()

    private val _isOnline = MutableStateFlow(true)
    val isOnline = _isOnline.asStateFlow()

    init {
        scope.launch {
            seedInitialDataIfNeeded()
        }
    }

    private suspend fun seedInitialDataIfNeeded() {
        val existingPackages = dao.getAllPackages().first()
        if (existingPackages.isEmpty()) {
            val entities = InitialSyntheticData.SAMPLE_PACKAGES.map { it.toEntity() }
            dao.insertPackages(entities)

            val eventEntities = InitialSyntheticData.SAMPLE_EVENTS.map { it.toEntity() }
            dao.insertTrackingEvents(eventEntities)

            val exceptionEntities = InitialSyntheticData.SAMPLE_EXCEPTIONS.map { it.toEntity() }
            dao.insertExceptions(exceptionEntities)

            InitialSyntheticData.SAMPLE_AUDIT_LOG.forEach {
                dao.insertAuditEvent(it.toEntity())
            }
        }
    }

    fun setNetworkOnline(online: Boolean) {
        _isOnline.value = online
        if (online) {
            syncQueuedItems()
        }
    }

    private fun syncQueuedItems() {
        scope.launch {
            val queue = dao.getSyncQueue().first()
            if (queue.isNotEmpty()) {
                // Process each queued offline transaction/scan
                queue.forEach { item ->
                    dao.deleteSyncItem(item.id)
                    recordAuditEvent(
                        actor = "OfflineSyncEngine",
                        role = "SYSTEM",
                        facility = "SyncGateway",
                        action = "RECONCILE_OFFLINE_PAYLOAD",
                        resource = item.actionType,
                        resourceId = item.id,
                        result = "SUCCESS - Idempotent Sync Complete"
                    )
                }
            }
        }
    }

    // Packages Flow
    val packages: Flow<List<PostalPackage>> = dao.getAllPackages().map { list ->
        list.map { it.toDomain() }
    }

    // Tracking Events Flow
    fun getEventsForTracking(trackingNumber: String): Flow<List<TrackingEvent>> {
        return dao.getEventsForPackage(trackingNumber).map { list ->
            list.map { it.toDomain() }
        }
    }

    val allTrackingEvents: Flow<List<TrackingEvent>> = dao.getAllTrackingEvents().map { list ->
        list.map { it.toDomain() }
    }

    val transactions: Flow<List<RetailTransaction>> = dao.getAllTransactions().map { list ->
        list.map { it.toDomain() }
    }

    val exceptions: Flow<List<ExceptionItem>> = dao.getAllExceptions().map { list ->
        list.map { it.toDomain() }
    }

    val auditEvents: Flow<List<AuditEvent>> = dao.getAllAuditEvents().map { list ->
        list.map { it.toDomain() }
    }

    val syncQueue: Flow<List<SyncQueueItem>> = dao.getSyncQueue().map { list ->
        list.map { it.toDomain() }
    }

    // Carrier stop actions
    fun completeCarrierDelivery(
        stopId: String,
        outcome: DeliveryOutcome,
        notes: String,
        signaturePoints: Int = 0
    ) {
        val currentRoute = _carrierRoute.value
        val updatedStops = currentRoute.stops.map { stop ->
            if (stop.stopId == stopId) {
                val isDelivered = outcome == DeliveryOutcome.DELIVERED_FRONT_PORCH ||
                        outcome == DeliveryOutcome.DELIVERED_MAILBOX ||
                        outcome == DeliveryOutcome.DELIVERED_PARCEL_LOCKER ||
                        outcome == DeliveryOutcome.DELIVERED_IN_PERSON
                val statusStr = if (isDelivered) "DELIVERED" else "ATTEMPTED"
                val outcomeText = when (outcome) {
                    DeliveryOutcome.DELIVERED_FRONT_PORCH -> "Delivered to Front Porch"
                    DeliveryOutcome.DELIVERED_MAILBOX -> "Delivered, In/At Mailbox"
                    DeliveryOutcome.DELIVERED_PARCEL_LOCKER -> "Delivered to Smart Parcel Locker"
                    DeliveryOutcome.DELIVERED_IN_PERSON -> "Delivered In-Person / Signature Captured"
                    DeliveryOutcome.ATTEMPTED_NO_ACCESS -> "Attempted - Gated / No Access"
                    DeliveryOutcome.ATTEMPTED_ANIMAL_INTERFERENCE -> "Attempted - Animal Interference"
                    DeliveryOutcome.ATTEMPTED_SIGNATURE_REQUIRED -> "Attempted - Notice Left (Signature Required)"
                    DeliveryOutcome.EXCEPTION_DAMAGED -> "Exception - Damaged Package"
                    DeliveryOutcome.EXCEPTION_WRONG_ADDRESS -> "Exception - Address Issue"
                }

                stop.copy(
                    deliveryStatus = statusStr,
                    outcomeNote = "$outcomeText: $notes",
                    deliveryTimestamp = SimpleDateFormat("hh:mm a", Locale.US).format(Date()),
                    signatureDataPoints = signaturePoints
                )
            } else {
                stop
            }
        }

        val completedCount = updatedStops.count { it.deliveryStatus != "PENDING" }
        _carrierRoute.value = currentRoute.copy(
            stops = updatedStops,
            completedStops = completedCount,
            shiftStatus = if (completedCount == updatedStops.size) "COMPLETED" else "IN_PROGRESS"
        )

        // Update tracking status for associated packages
        val targetedStop = currentRoute.stops.find { it.stopId == stopId }
        targetedStop?.packageTrackingNumbers?.forEach { trk ->
            scope.launch {
                val pkg = dao.getPackageByTracking(trk)
                if (pkg != null) {
                    val newStatus = if (outcome.name.startsWith("DELIVERED")) PackageStatus.DELIVERED else PackageStatus.DELIVERY_ATTEMPTED
                    dao.updatePackage(
                        pkg.copy(
                            status = newStatus.name,
                            latestEventTime = "Today - ${outcome.name.replace("_", " ")}"
                        )
                    )

                    // Add tracking event
                    val newEvent = TrackingEvent(
                        eventId = "evt_${UUID.randomUUID().toString().take(8)}",
                        trackingNumber = trk,
                        timestamp = SimpleDateFormat("MMM dd hh:mm a", Locale.US).format(Date()),
                        location = "${targetedStop.address.city}, ${targetedStop.address.state} ${targetedStop.address.zipCode}",
                        facility = "Springfield Station Delivery Unit #4",
                        scanType = outcome.name,
                        status = newStatus,
                        description = "Carrier Jordan Williams: $notes"
                    )
                    dao.insertTrackingEvent(newEvent.toEntity())
                }
            }
        }

        recordAuditEvent(
            actor = "Jordan Williams (Carrier)",
            role = "CARRIER",
            facility = "Route C-042",
            action = "RECORD_DELIVERY_SCAN",
            resource = "RouteStop",
            resourceId = stopId,
            result = outcome.name
        )
    }

    fun createShipment(
        service: PostalServiceType,
        sender: PostalAddress,
        recipient: PostalAddress,
        weightOz: Double,
        lengthIn: Double,
        widthIn: Double,
        heightIn: Double,
        postageCents: Int,
        signatureRequired: Boolean,
        paymentMethod: String
    ): PostalPackage {
        val trackingNum = "9400" + (1000000000000000L + (Math.random() * 8999999999999999L).toLong()).toString().take(18)
        val newPkg = PostalPackage(
            trackingNumber = trackingNum,
            serviceType = service,
            sender = sender,
            recipient = recipient,
            status = PackageStatus.LABEL_CREATED,
            weightOz = weightOz,
            lengthIn = lengthIn,
            widthIn = widthIn,
            heightIn = heightIn,
            postageCents = postageCents,
            signatureRequired = signatureRequired,
            estimatedDelivery = "In 2-3 Business Days",
            latestEventTime = "Just now - Shipping Label Created",
            currentFacility = "USPS Origin Electronic Intake"
        )

        val txId = "TX-" + UUID.randomUUID().toString().take(8).uppercase()
        val tx = RetailTransaction(
            transactionId = txId,
            timestamp = SimpleDateFormat("MMM dd, yyyy hh:mm a", Locale.US).format(Date()),
            customerName = sender.residentName,
            destinationZip = recipient.zipCode,
            serviceType = service,
            weightOz = weightOz,
            totalCents = postageCents,
            paymentMethod = paymentMethod,
            isPaid = true,
            labelBarcode = trackingNum,
            receiptId = "RCP-$txId"
        )

        scope.launch {
            if (_isOnline.value) {
                dao.insertPackage(newPkg.toEntity())
                dao.insertTransaction(tx.toEntity())
                dao.insertTrackingEvent(
                    TrackingEvent(
                        eventId = "evt_${UUID.randomUUID().toString().take(8)}",
                        trackingNumber = trackingNum,
                        timestamp = "Just now",
                        location = "${sender.city}, ${sender.state}",
                        facility = "Retail Counter Intake / Digital Postal OS",
                        scanType = "SHIPPING LABEL CREATED",
                        status = PackageStatus.LABEL_CREATED,
                        description = "Shipping Label Created with $paymentMethod payment."
                    ).toEntity()
                )
            } else {
                // Queue for offline sync
                dao.insertPackage(newPkg.toEntity())
                dao.insertTransaction(tx.toEntity())
                dao.insertSyncItem(
                    SyncQueueEntity(
                        id = UUID.randomUUID().toString(),
                        actionType = "SHIPMENT_LABEL_OFFLINE",
                        payloadSummary = "Shipment $trackingNum - $${postageCents / 100.0} ($paymentMethod)",
                        timestamp = SimpleDateFormat("hh:mm:ss a", Locale.US).format(Date()),
                        status = "QUEUED"
                    )
                )
            }

            recordAuditEvent(
                actor = sender.residentName,
                role = "RETAIL_OR_CUSTOMER",
                facility = "Intake Point",
                action = "PURCHASE_POSTAGE_AND_LABEL",
                resource = "PostalPackage",
                resourceId = trackingNum,
                result = "SUCCESS - $${postageCents / 100.0} Cents"
            )
        }

        return newPkg
    }

    fun reportException(
        trackingNumber: String,
        type: String,
        severity: String,
        description: String,
        assignedTo: String
    ) {
        val excId = "EXC-" + UUID.randomUUID().toString().take(6).uppercase()
        val exc = ExceptionItem(
            exceptionId = excId,
            trackingNumber = trackingNumber,
            type = type,
            severity = severity,
            description = description,
            status = "OPEN",
            assignedTo = assignedTo,
            createdAt = SimpleDateFormat("MMM dd, hh:mm a", Locale.US).format(Date())
        )

        scope.launch {
            dao.insertException(exc.toEntity())
            recordAuditEvent(
                actor = assignedTo,
                role = "OPERATOR",
                facility = "Active Facility",
                action = "FLAG_EXCEPTION",
                resource = "PostalException",
                resourceId = excId,
                result = "LOGGED - $severity"
            )
        }
    }

    fun pickupSmartLocker(lockerId: String, pin: String): Boolean {
        val list = _smartLockers.value
        val locker = list.find { it.lockerId == lockerId }
        if (locker != null && locker.pickupPin == pin) {
            _smartLockers.value = list.map {
                if (it.lockerId == lockerId) {
                    it.copy(
                        status = "AVAILABLE",
                        trackingNumber = null,
                        recipientName = null,
                        pickupPin = null,
                        expiresAt = null
                    )
                } else it
            }
            recordAuditEvent(
                actor = "SmartLockerStation",
                role = "CUSTOMER_KIOSK",
                facility = locker.locationName,
                action = "COMPARTMENT_OPENED_AND_RETRIEVED",
                resource = "SmartLocker",
                resourceId = lockerId,
                result = "SUCCESS"
            )
            return true
        }
        return false
    }

    fun recordAuditEvent(
        actor: String,
        role: String,
        facility: String,
        action: String,
        resource: String,
        resourceId: String,
        result: String
    ) {
        scope.launch {
            val event = AuditEvent(
                eventId = "AUD-" + UUID.randomUUID().toString().take(8).uppercase(),
                timestamp = SimpleDateFormat("MMM dd hh:mm:ss a", Locale.US).format(Date()),
                actor = actor,
                role = role,
                facility = facility,
                action = action,
                resource = resource,
                resourceId = resourceId,
                result = result,
                correlationId = "CORR-" + UUID.randomUUID().toString().take(6).uppercase()
            )
            dao.insertAuditEvent(event.toEntity())
        }
    }
}

// Mapper extensions between Entities and Domain models
fun PostalPackage.toEntity(): PackageEntity = PackageEntity(
    trackingNumber = trackingNumber,
    serviceCode = serviceType.code,
    senderName = sender.residentName,
    senderStreet = sender.streetAddress,
    senderCity = sender.city,
    senderState = sender.state,
    senderZip = sender.zipCode,
    recipientName = recipient.residentName,
    recipientStreet = recipient.streetAddress,
    recipientCity = recipient.city,
    recipientState = recipient.state,
    recipientZip = recipient.zipCode,
    status = status.name,
    weightOz = weightOz,
    lengthIn = lengthIn,
    widthIn = widthIn,
    heightIn = heightIn,
    postageCents = postageCents,
    signatureRequired = signatureRequired,
    estimatedDelivery = estimatedDelivery,
    latestEventTime = latestEventTime,
    currentFacility = currentFacility,
    deliveryLocationNote = deliveryLocationNote,
    lockerCode = lockerCode
)

fun PackageEntity.toDomain(): PostalPackage {
    val service = PostalServiceType.entries.find { it.code == serviceCode } ?: PostalServiceType.PRIORITY_MAIL
    val pkgStatus = try { PackageStatus.valueOf(status) } catch (e: Exception) { PackageStatus.IN_TRANSIT }
    return PostalPackage(
        trackingNumber = trackingNumber,
        serviceType = service,
        sender = PostalAddress(senderName, senderStreet, null, senderCity, senderState, senderZip),
        recipient = PostalAddress(recipientName, recipientStreet, null, recipientCity, recipientState, recipientZip),
        status = pkgStatus,
        weightOz = weightOz,
        lengthIn = lengthIn,
        widthIn = widthIn,
        heightIn = heightIn,
        postageCents = postageCents,
        signatureRequired = signatureRequired,
        estimatedDelivery = estimatedDelivery,
        latestEventTime = latestEventTime,
        currentFacility = currentFacility,
        deliveryLocationNote = deliveryLocationNote,
        lockerCode = lockerCode
    )
}

fun TrackingEvent.toEntity(): TrackingEventEntity = TrackingEventEntity(
    eventId = eventId,
    trackingNumber = trackingNumber,
    timestamp = timestamp,
    location = location,
    facility = facility,
    scanType = scanType,
    status = status.name,
    description = description,
    lat = lat,
    lon = lon,
    source = source
)

fun TrackingEventEntity.toDomain(): TrackingEvent {
    val pkgStatus = try { PackageStatus.valueOf(status) } catch (e: Exception) { PackageStatus.IN_TRANSIT }
    return TrackingEvent(
        eventId = eventId,
        trackingNumber = trackingNumber,
        timestamp = timestamp,
        location = location,
        facility = facility,
        scanType = scanType,
        status = pkgStatus,
        description = description,
        lat = lat,
        lon = lon,
        source = source
    )
}

fun RetailTransaction.toEntity(): RetailTransactionEntity = RetailTransactionEntity(
    transactionId = transactionId,
    timestamp = timestamp,
    customerName = customerName,
    destinationZip = destinationZip,
    serviceCode = serviceType.code,
    weightOz = weightOz,
    totalCents = totalCents,
    paymentMethod = paymentMethod,
    isPaid = isPaid,
    labelBarcode = labelBarcode,
    receiptId = receiptId
)

fun RetailTransactionEntity.toDomain(): RetailTransaction {
    val service = PostalServiceType.entries.find { it.code == serviceCode } ?: PostalServiceType.PRIORITY_MAIL
    return RetailTransaction(
        transactionId = transactionId,
        timestamp = timestamp,
        customerName = customerName,
        destinationZip = destinationZip,
        serviceType = service,
        weightOz = weightOz,
        totalCents = totalCents,
        paymentMethod = paymentMethod,
        isPaid = isPaid,
        labelBarcode = labelBarcode,
        receiptId = receiptId
    )
}

fun ExceptionItem.toEntity(): ExceptionEntity = ExceptionEntity(
    exceptionId = exceptionId,
    trackingNumber = trackingNumber,
    type = type,
    severity = severity,
    description = description,
    status = status,
    assignedTo = assignedTo,
    createdAt = createdAt
)

fun ExceptionEntity.toDomain(): ExceptionItem = ExceptionItem(
    exceptionId = exceptionId,
    trackingNumber = trackingNumber,
    type = type,
    severity = severity,
    description = description,
    status = status,
    assignedTo = assignedTo,
    createdAt = createdAt
)

fun AuditEvent.toEntity(): AuditEventEntity = AuditEventEntity(
    eventId = eventId,
    timestamp = timestamp,
    actor = actor,
    role = role,
    facility = facility,
    action = action,
    resource = resource,
    resourceId = resourceId,
    result = result,
    correlationId = correlationId
)

fun AuditEventEntity.toDomain(): AuditEvent = AuditEvent(
    eventId = eventId,
    timestamp = timestamp,
    actor = actor,
    role = role,
    facility = facility,
    action = action,
    resource = resource,
    resourceId = resourceId,
    result = result,
    correlationId = correlationId
)

fun SyncQueueEntity.toDomain(): SyncQueueItem = SyncQueueItem(
    id = id,
    actionType = actionType,
    payloadSummary = payloadSummary,
    timestamp = timestamp,
    status = status
)
