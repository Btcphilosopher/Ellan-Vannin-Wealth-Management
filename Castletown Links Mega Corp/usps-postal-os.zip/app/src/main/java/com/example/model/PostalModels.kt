package com.example.model

enum class PostalServiceType(
    val code: String,
    val displayName: String,
    val deliverySpeed: String,
    val baseRateCents: Int,
    val isExpress: Boolean = false
) {
    PRIORITY_MAIL_EXPRESS("PME", "Priority Mail Express®", "Next-Day to 2-Day Guarantee", 3045, true),
    PRIORITY_MAIL("PM", "Priority Mail®", "1-3 Business Days", 935),
    USPS_GROUND_ADVANTAGE("UGA", "USPS Ground Advantage™", "2-5 Business Days", 490),
    FIRST_CLASS_MAIL("FCM", "First-Class Mail®", "1-5 Business Days", 73),
    MEDIA_MAIL("MM", "Media Mail®", "2-8 Business Days", 413),
    CERTIFIED_MAIL("CERT", "Certified Mail® with Electronic Return Receipt", "2-3 Days (Signature Recorded)", 810)
}

enum class PackageStatus(val label: String, val badgeColorType: String) {
    LABEL_CREATED("Label Created", "BLUE"),
    ACCEPTED("Accepted at USPS Facility", "BLUE"),
    IN_TRANSIT("In Transit", "AMBER"),
    ARRIVED_AT_FACILITY("Arrived at Sort Facility", "AMBER"),
    DEPARTED_FACILITY("Departed Sort Facility", "AMBER"),
    OUT_FOR_DELIVERY("Out for Delivery", "BLUE"),
    DELIVERY_ATTEMPTED("Delivery Attempted", "AMBER"),
    DELIVERED("Delivered", "GREEN"),
    AVAILABLE_FOR_PICKUP("Available for Pickup / Locker", "PURPLE"),
    HELD("Held at Post Office", "AMBER"),
    RETURNED("Returned to Sender", "RED"),
    EXCEPTION("Delivery Exception", "RED")
}

data class PostalAddress(
    val residentName: String,
    val streetAddress: String,
    val secondaryAddress: String? = null,
    val city: String,
    val state: String,
    val zipCode: String,
    val zipPlus4: String = "0001"
) {
    val fullFormatted: String
        get() = "$streetAddress${if (!secondaryAddress.isNullOrBlank()) ", $secondaryAddress" else ""}, $city, $state $zipCode-$zipPlus4"
}

data class TrackingEvent(
    val eventId: String,
    val trackingNumber: String,
    val timestamp: String,
    val location: String,
    val facility: String,
    val scanType: String,
    val status: PackageStatus,
    val description: String,
    val lat: Double = 40.7128,
    val lon: Double = -74.0060,
    val source: String = "SYNTHETIC_USPS_SCANNER_v2.4"
)

data class PostalPackage(
    val trackingNumber: String,
    val serviceType: PostalServiceType,
    val sender: PostalAddress,
    val recipient: PostalAddress,
    val status: PackageStatus,
    val weightOz: Double,
    val lengthIn: Double,
    val widthIn: Double,
    val heightIn: Double,
    val postageCents: Int,
    val signatureRequired: Boolean = false,
    val estimatedDelivery: String,
    val latestEventTime: String,
    val currentFacility: String,
    val deliveryLocationNote: String? = null,
    val lockerCode: String? = null
)

enum class MailClass(val title: String) {
    FIRST_CLASS("First-Class Mail"),
    MARKETING_MAIL("USPS Marketing Mail"),
    PERIODICAL("Periodical / Publication")
}

data class Mailpiece(
    val id: String,
    val mailClass: MailClass,
    val senderName: String,
    val recipientName: String,
    val address: String,
    val receivedDate: String,
    val syntheticEnvelopeType: String, // "TAX_DOC", "CARD", "UTILITY", "MAGAZINE"
    val hasActionRequired: Boolean = false,
    val note: String = ""
)

enum class DeliveryOutcome {
    DELIVERED_FRONT_PORCH,
    DELIVERED_MAILBOX,
    DELIVERED_PARCEL_LOCKER,
    DELIVERED_IN_PERSON,
    ATTEMPTED_NO_ACCESS,
    ATTEMPTED_ANIMAL_INTERFERENCE,
    ATTEMPTED_SIGNATURE_REQUIRED,
    EXCEPTION_DAMAGED,
    EXCEPTION_WRONG_ADDRESS
}

data class RouteStop(
    val stopNumber: Int,
    val stopId: String,
    val address: PostalAddress,
    val packageTrackingNumbers: List<String>,
    val mailVolumeLetters: Int,
    val signatureRequired: Boolean,
    val specialInstructions: String?,
    val deliveryStatus: String, // "PENDING", "DELIVERED", "ATTEMPTED", "EXCEPTION"
    val outcomeNote: String? = null,
    val deliveryTimestamp: String? = null,
    val signatureDataPoints: Int = 0
)

data class CarrierRoute(
    val routeId: String,
    val routeName: String,
    val carrierName: String,
    val vehicleId: String,
    val totalStops: Int,
    val completedStops: Int,
    val packageCount: Int,
    val mailVolumeTotal: Int,
    val shiftStatus: String, // "NOT_STARTED", "IN_PROGRESS", "COMPLETED"
    val stops: List<RouteStop>
)

data class RetailTransaction(
    val transactionId: String,
    val timestamp: String,
    val customerName: String,
    val destinationZip: String,
    val serviceType: PostalServiceType,
    val weightOz: Double,
    val totalCents: Int,
    val paymentMethod: String,
    val isPaid: Boolean,
    val labelBarcode: String,
    val receiptId: String
)

data class SortationLane(
    val laneNumber: Int,
    val destinationZone: String,
    val currentVolumePieces: Int,
    val capacityPieces: Int,
    val isJammed: Boolean = false
)

enum class EquipmentStatus(val label: String, val colorType: String) {
    ONLINE("Operational", "GREEN"),
    DEGRADED("Degraded Speed", "AMBER"),
    MAINTENANCE("Scheduled Maintenance", "AMBER"),
    FAULT("Jammed / Fault Alert", "RED"),
    OFFLINE("Offline", "RED")
}

data class EquipmentAsset(
    val equipmentId: String,
    val machineName: String,
    val machineType: String, // "DBCS (Delivery Bar Code Sorter)", "APPS (Automated Parcel & Bundle Sorter)", "NPI Tray Sorter", "AGV Autonomous Carrier"
    val status: EquipmentStatus,
    val serialNumber: String,
    val throughputPiecesPerHour: Int,
    val targetThroughput: Int,
    val runtimeHoursToday: Double,
    val lastMaintenance: String,
    val activeWorkOrderId: String? = null
)

data class FacilityTelemetry(
    val facilityId: String,
    val facilityName: String,
    val facilityType: String,
    val currentInboundTrucks: Int,
    val currentOutboundTrucks: Int,
    val hourlyThroughputPieces: Int,
    val dailyBacklogPieces: Int,
    val activeContainersCount: Int,
    val exceptionCount: Int,
    val sortationLanes: List<SortationLane>
)

data class ExceptionItem(
    val exceptionId: String,
    val trackingNumber: String,
    val type: String, // "Damaged Barcode", "Incorrect ZIP", "Customer Refused", "Delivery Blocked", "Equipment Stoppage"
    val severity: String, // "LOW", "MEDIUM", "HIGH", "CRITICAL"
    val description: String,
    val status: String, // "OPEN", "INVESTIGATING", "RESOLVED"
    val assignedTo: String,
    val createdAt: String
)

data class SmartLocker(
    val lockerId: String,
    val locationName: String,
    val compartmentNumber: Int,
    val status: String, // "AVAILABLE", "OCCUPIED"
    val trackingNumber: String?,
    val recipientName: String?,
    val pickupPin: String?,
    val expiresAt: String?
)

data class POBoxItem(
    val boxNumber: String,
    val customerName: String,
    val sizeCategory: String, // "Small", "Medium", "Large", "Drawer"
    val status: String, // "ACTIVE", "PAYMENT_DUE", "HOLD"
    val renewalDate: String,
    val uncollectedLetters: Int,
    val uncollectedParcels: Int
)

data class AuditEvent(
    val eventId: String,
    val timestamp: String,
    val actor: String,
    val role: String,
    val facility: String,
    val action: String,
    val resource: String,
    val resourceId: String,
    val result: String,
    val correlationId: String
)

data class SyncQueueItem(
    val id: String,
    val actionType: String,
    val payloadSummary: String,
    val timestamp: String,
    val status: String // "QUEUED", "SYNCED", "CONFLICT"
)

data class SupportTicket(
    val ticketId: String,
    val customerName: String,
    val topic: String,
    val trackingNumber: String?,
    val status: String, // "OPEN", "IN_REVIEW", "RESOLVED"
    val messages: List<String>
)
