package com.example.data

import com.example.model.*

object InitialSyntheticData {

    val SAMPLE_PACKAGES = listOf(
        PostalPackage(
            trackingNumber = "9400109205568123908122",
            serviceType = PostalServiceType.PRIORITY_MAIL,
            sender = PostalAddress(
                residentName = "Midwest Tech Fulfillment",
                streetAddress = "450 Industrial Parkway",
                city = "Chicago",
                state = "IL",
                zipCode = "60607"
            ),
            recipient = PostalAddress(
                residentName = "Alex Morgan",
                streetAddress = "742 Evergreen Terrace",
                city = "Springfield",
                state = "IL",
                zipCode = "62704"
            ),
            status = PackageStatus.OUT_FOR_DELIVERY,
            weightOz = 28.5,
            lengthIn = 12.0,
            widthIn = 9.0,
            heightIn = 4.0,
            postageCents = 1040,
            signatureRequired = false,
            estimatedDelivery = "Today by 4:00 PM",
            latestEventTime = "07:45 AM - Out for Delivery (Carrier Jordan Williams)",
            currentFacility = "Springfield Station Delivery Unit #4",
            deliveryLocationNote = "Front Porch requested"
        ),
        PostalPackage(
            trackingNumber = "9205590164917382910233",
            serviceType = PostalServiceType.PRIORITY_MAIL_EXPRESS,
            sender = PostalAddress(
                residentName = "Apex Legal Document Services",
                streetAddress = "120 Broadway Suite 400",
                city = "New York",
                state = "NY",
                zipCode = "10005"
            ),
            recipient = PostalAddress(
                residentName = "Alex Morgan",
                streetAddress = "742 Evergreen Terrace",
                city = "Springfield",
                state = "IL",
                zipCode = "62704"
            ),
            status = PackageStatus.OUT_FOR_DELIVERY,
            weightOz = 6.2,
            lengthIn = 12.5,
            widthIn = 9.5,
            heightIn = 0.5,
            postageCents = 3045,
            signatureRequired = true,
            estimatedDelivery = "Today by 12:00 PM Guaranteed",
            latestEventTime = "08:10 AM - Out for Delivery (Carrier Jordan Williams)",
            currentFacility = "Springfield Station Delivery Unit #4",
            deliveryLocationNote = "Signature Required upon delivery"
        ),
        PostalPackage(
            trackingNumber = "9405511202555081992011",
            serviceType = PostalServiceType.USPS_GROUND_ADVANTAGE,
            sender = PostalAddress(
                residentName = "Pacific Apparel Co.",
                streetAddress = "880 Harrison St",
                city = "Seattle",
                state = "WA",
                zipCode = "98109"
            ),
            recipient = PostalAddress(
                residentName = "Alex Morgan",
                streetAddress = "742 Evergreen Terrace",
                city = "Springfield",
                state = "IL",
                zipCode = "62704"
            ),
            status = PackageStatus.IN_TRANSIT,
            weightOz = 14.0,
            lengthIn = 10.0,
            widthIn = 7.0,
            heightIn = 3.0,
            postageCents = 620,
            signatureRequired = false,
            estimatedDelivery = "Tomorrow by 6:00 PM",
            latestEventTime = "04:15 AM - Departed USPS Regional Facility",
            currentFacility = "Chicago IL Network Distribution Center"
        ),
        PostalPackage(
            trackingNumber = "9302111002938491029384",
            serviceType = PostalServiceType.PRIORITY_MAIL,
            sender = PostalAddress(
                residentName = "Alex Morgan",
                streetAddress = "742 Evergreen Terrace",
                city = "Springfield",
                state = "IL",
                zipCode = "62704"
            ),
            recipient = PostalAddress(
                residentName = "Elena Rostova",
                streetAddress = "1540 Market St Suite 200",
                city = "San Francisco",
                state = "CA",
                zipCode = "94102"
            ),
            status = PackageStatus.DELIVERED,
            weightOz = 36.0,
            lengthIn = 14.0,
            widthIn = 10.0,
            heightIn = 6.0,
            postageCents = 1485,
            signatureRequired = false,
            estimatedDelivery = "Delivered Yesterday 2:15 PM",
            latestEventTime = "Yesterday 2:15 PM - Delivered, In/At Mailbox",
            currentFacility = "San Francisco Post Office 94102",
            deliveryLocationNote = "Delivered to Parcel Locker #4"
        ),
        PostalPackage(
            trackingNumber = "9400109205568999887766",
            serviceType = PostalServiceType.PRIORITY_MAIL,
            sender = PostalAddress(
                residentName = "Cascade Specialty Goods",
                streetAddress = "210 Pine St",
                city = "Portland",
                state = "OR",
                zipCode = "97201"
            ),
            recipient = PostalAddress(
                residentName = "Alex Morgan",
                streetAddress = "742 Evergreen Terrace",
                city = "Springfield",
                state = "IL",
                zipCode = "62704"
            ),
            status = PackageStatus.AVAILABLE_FOR_PICKUP,
            weightOz = 20.0,
            lengthIn = 8.0,
            widthIn = 6.0,
            heightIn = 4.0,
            postageCents = 890,
            signatureRequired = false,
            estimatedDelivery = "Ready for Self-Service Pickup",
            latestEventTime = "Today 09:30 AM - Stored in Smart Locker Compartment #12",
            currentFacility = "Springfield Central Station Smart Locker Hub",
            lockerCode = "849201"
        )
    )

    val SAMPLE_EVENTS = listOf(
        // Events for Package 9400109205568123908122
        TrackingEvent(
            eventId = "evt_01",
            trackingNumber = "9400109205568123908122",
            timestamp = "Today 07:45 AM",
            location = "SPRINGFIELD, IL 62704",
            facility = "Springfield Station Delivery Unit",
            scanType = "OUT FOR DELIVERY",
            status = PackageStatus.OUT_FOR_DELIVERY,
            description = "Out for Delivery, Expected by 4:00 PM (Carrier Jordan Williams)"
        ),
        TrackingEvent(
            eventId = "evt_02",
            trackingNumber = "9400109205568123908122",
            timestamp = "Today 05:30 AM",
            location = "SPRINGFIELD, IL 62703",
            facility = "Springfield IL Processing Center",
            scanType = "ARRIVED AT FACILITY",
            status = PackageStatus.ARRIVED_AT_FACILITY,
            description = "Arrived at USPS Regional Destination Facility"
        ),
        TrackingEvent(
            eventId = "evt_03",
            trackingNumber = "9400109205568123908122",
            timestamp = "Yesterday 09:15 PM",
            location = "CHICAGO, IL 60607",
            facility = "Chicago IL Network Distribution Center",
            scanType = "PROCESSED THROUGH FACILITY",
            status = PackageStatus.IN_TRANSIT,
            description = "Processed through USPS Sort Facility on DBCS Sorter #4"
        ),
        TrackingEvent(
            eventId = "evt_04",
            trackingNumber = "9400109205568123908122",
            timestamp = "Sep 10 02:30 PM",
            location = "CHICAGO, IL 60607",
            facility = "Downtown Chicago Retail Post Office",
            scanType = "USPS IN POSSESSION OF ITEM",
            status = PackageStatus.ACCEPTED,
            description = "Accepted at USPS Origin Facility Counter"
        ),
        TrackingEvent(
            eventId = "evt_05",
            trackingNumber = "9400109205568123908122",
            timestamp = "Sep 10 11:00 AM",
            location = "CHICAGO, IL",
            facility = "Electronic Shipping System",
            scanType = "SHIPPING LABEL CREATED",
            status = PackageStatus.LABEL_CREATED,
            description = "Shipping Label Created, USPS Awaiting Item"
        ),

        // Events for Package 9205590164917382910233 (Express Signature)
        TrackingEvent(
            eventId = "evt_06",
            trackingNumber = "9205590164917382910233",
            timestamp = "Today 08:10 AM",
            location = "SPRINGFIELD, IL 62704",
            facility = "Springfield Station Delivery Unit",
            scanType = "OUT FOR DELIVERY",
            status = PackageStatus.OUT_FOR_DELIVERY,
            description = "Out for Delivery - Signature Required Guarantee 12:00 PM"
        ),
        TrackingEvent(
            eventId = "evt_07",
            trackingNumber = "9205590164917382910233",
            timestamp = "Today 04:00 AM",
            location = "CHICAGO, IL 60666",
            facility = "O'Hare Air Mail Facility",
            scanType = "AIR HUB DEPARTURE",
            status = PackageStatus.IN_TRANSIT,
            description = "Departed USPS Air Hub via Expedited Surface Shuttle"
        ),
        TrackingEvent(
            eventId = "evt_08",
            trackingNumber = "9205590164917382910233",
            timestamp = "Yesterday 06:45 PM",
            location = "NEW YORK, NY 10001",
            facility = "JFK Airport Air Mail Facility",
            scanType = "ACCEPTED AT AIR POSTAL HUB",
            status = PackageStatus.ACCEPTED,
            description = "Accepted at JFK Express Postal Center"
        )
    )

    val SAMPLE_MAILPIECES = listOf(
        Mailpiece(
            id = "mp_01",
            mailClass = MailClass.FIRST_CLASS,
            senderName = "State Department of Revenue",
            recipientName = "Alex Morgan",
            address = "742 Evergreen Terrace, Springfield, IL",
            receivedDate = "Today",
            syntheticEnvelopeType = "TAX_DOC",
            hasActionRequired = true,
            note = "Official State Document - Tax Statement enclosed"
        ),
        Mailpiece(
            id = "mp_02",
            mailClass = MailClass.FIRST_CLASS,
            senderName = "City Water & Power Utility",
            recipientName = "Alex Morgan",
            address = "742 Evergreen Terrace, Springfield, IL",
            receivedDate = "Today",
            syntheticEnvelopeType = "UTILITY",
            hasActionRequired = false,
            note = "Monthly Utility Billing Statement"
        ),
        Mailpiece(
            id = "mp_03",
            mailClass = MailClass.MARKETING_MAIL,
            senderName = "National Geographic Society",
            recipientName = "Alex Morgan",
            address = "742 Evergreen Terrace, Springfield, IL",
            receivedDate = "Yesterday",
            syntheticEnvelopeType = "MAGAZINE",
            hasActionRequired = false,
            note = "Monthly Explorer Magazine & Digest"
        )
    )

    val SAMPLE_ROUTE_STOPS = listOf(
        RouteStop(
            stopNumber = 1,
            stopId = "ST-01",
            address = PostalAddress("Alex Morgan", "742 Evergreen Terrace", null, "Springfield", "IL", "62704"),
            packageTrackingNumbers = listOf("9400109205568123908122", "9205590164917382910233"),
            mailVolumeLetters = 2,
            signatureRequired = true,
            specialInstructions = "Leave package inside porch storm door. Beware of dog behind side fence.",
            deliveryStatus = "PENDING"
        ),
        RouteStop(
            stopNumber = 2,
            stopId = "ST-02",
            address = PostalAddress("Ned Flanders", "740 Evergreen Terrace", null, "Springfield", "IL", "62704"),
            packageTrackingNumbers = listOf("9400109205568910293844"),
            mailVolumeLetters = 3,
            signatureRequired = false,
            specialInstructions = "Place in mailbox by garden gate.",
            deliveryStatus = "PENDING"
        ),
        RouteStop(
            stopNumber = 3,
            stopId = "ST-03",
            address = PostalAddress("Ruth Powers", "744 Evergreen Terrace", null, "Springfield", "IL", "62704"),
            packageTrackingNumbers = emptyList(),
            mailVolumeLetters = 4,
            signatureRequired = false,
            specialInstructions = null,
            deliveryStatus = "DELIVERED",
            deliveryTimestamp = "08:42 AM",
            outcomeNote = "Delivered to Curbside Mailbox"
        ),
        RouteStop(
            stopNumber = 4,
            stopId = "ST-04",
            address = PostalAddress("Charles Montgomery", "1000 Mammon Lane", "Mansion Gate", "Springfield", "IL", "62704"),
            packageTrackingNumbers = listOf("9102948572019482710492"),
            mailVolumeLetters = 12,
            signatureRequired = true,
            specialInstructions = "Security intercom at guardhouse before entry.",
            deliveryStatus = "PENDING"
        ),
        RouteStop(
            stopNumber = 5,
            stopId = "ST-05",
            address = PostalAddress("Seymour Skinner", "330 Elm Street", null, "Springfield", "IL", "62704"),
            packageTrackingNumbers = listOf("9405511202555099887766"),
            mailVolumeLetters = 1,
            signatureRequired = false,
            specialInstructions = "Leave under covered front step.",
            deliveryStatus = "PENDING"
        )
    )

    val SAMPLE_CARRIER_ROUTE = CarrierRoute(
        routeId = "C-042",
        routeName = "Springfield West - Route C-042",
        carrierName = "Jordan Williams (EMP-88421)",
        vehicleId = "LLV-71402 (Long Life Vehicle)",
        totalStops = 5,
        completedStops = 1,
        packageCount = 5,
        mailVolumeTotal = 22,
        shiftStatus = "IN_PROGRESS",
        stops = SAMPLE_ROUTE_STOPS
    )

    val SAMPLE_EQUIPMENT = listOf(
        EquipmentAsset(
            equipmentId = "EQ-DBCS-04",
            machineName = "Delivery Bar Code Sorter #04",
            machineType = "DBCS High-Speed Optical Sorter",
            status = EquipmentStatus.ONLINE,
            serialNumber = "USPS-DBCS-2024-8891",
            throughputPiecesPerHour = 36500,
            targetThroughput = 38000,
            runtimeHoursToday = 7.4,
            lastMaintenance = "Sep 08, 2026 - Preventive Optical Clean"
        ),
        EquipmentAsset(
            equipmentId = "EQ-APPS-02",
            machineName = "Automated Parcel & Bundle Sorter #02",
            machineType = "APPS Automated Matrix Sorter",
            status = EquipmentStatus.ONLINE,
            serialNumber = "USPS-APPS-9942-01A",
            throughputPiecesPerHour = 9200,
            targetThroughput = 9500,
            runtimeHoursToday = 6.8,
            lastMaintenance = "Sep 02, 2026 - Roller Alignment"
        ),
        EquipmentAsset(
            equipmentId = "EQ-NPI-01",
            machineName = "NPI High-Speed Flat/Tray Sorter #01",
            machineType = "NPI Flats Sequence Sorter",
            status = EquipmentStatus.DEGRADED,
            serialNumber = "USPS-NPI-1049-X",
            throughputPiecesPerHour = 14200,
            targetThroughput = 22000,
            runtimeHoursToday = 5.2,
            lastMaintenance = "Aug 29, 2026 - Jam Sensor Recalibration",
            activeWorkOrderId = "WO-88910 (Feeder Belt Friction Inspection)"
        ),
        EquipmentAsset(
            equipmentId = "EQ-AGV-07",
            machineName = "Autonomous Guided Vehicle #07",
            machineType = "AGV Pallet & Rolling Cart Transporter",
            status = EquipmentStatus.ONLINE,
            serialNumber = "AGV-LIDAR-7740",
            throughputPiecesPerHour = 120,
            targetThroughput = 120,
            runtimeHoursToday = 8.1,
            lastMaintenance = "Sep 10, 2026 - Battery Cycle"
        )
    )

    val SAMPLE_FACILITY_TELEMETRY = FacilityTelemetry(
        facilityId = "P&DC-CHI-01",
        facilityName = "Metro P&DC Regional Processing Facility",
        facilityType = "Processing & Distribution Center",
        currentInboundTrucks = 14,
        currentOutboundTrucks = 9,
        hourlyThroughputPieces = 58400,
        dailyBacklogPieces = 12450,
        activeContainersCount = 380,
        exceptionCount = 3,
        sortationLanes = listOf(
            SortationLane(1, "Zone 1 - Local Metro Deliveries (606xx)", 14200, 15000),
            SortationLane(2, "Zone 2 - Midwest Regional (600xx - 629xx)", 22800, 25000),
            SortationLane(3, "Zone 3 - East Coast Air Logistics Hub", 11400, 20000),
            SortationLane(4, "Zone 4 - West Coast Air Logistics Hub", 10000, 20000)
        )
    )

    val SAMPLE_EXCEPTIONS = listOf(
        ExceptionItem(
            exceptionId = "EXC-9014",
            trackingNumber = "9400109205568123908199",
            type = "Damaged Barcode on Induction",
            severity = "MEDIUM",
            description = "Optical reader unreadable on DBCS Feeder #2. Repaired manual 2D reprint generated.",
            status = "INVESTIGATING",
            assignedTo = "Chris Wilson (Plant Ops)",
            createdAt = "Today 06:14 AM"
        ),
        ExceptionItem(
            exceptionId = "EXC-9015",
            trackingNumber = "9205590164917382910881",
            type = "Hazardous Material Flag Alert",
            severity = "HIGH",
            description = "Lithium Battery without UN3481 warning label detected on APPS Scale #2.",
            status = "OPEN",
            assignedTo = "Morgan Davis (Safety Supervisor)",
            createdAt = "Today 07:22 AM"
        ),
        ExceptionItem(
            exceptionId = "EXC-9016",
            trackingNumber = "9405511202555081992444",
            type = "Incorrect ZIP Code Routing",
            severity = "LOW",
            description = "Address OCR detected Springfield MA instead of Springfield IL. Re-routed to Bin 4.",
            status = "RESOLVED",
            assignedTo = "Taylor Johnson (Clerk)",
            createdAt = "Yesterday 04:50 PM"
        )
    )

    val SAMPLE_SMART_LOCKERS = listOf(
        SmartLocker(
            lockerId = "LCK-01",
            locationName = "Springfield Central Station Hub",
            compartmentNumber = 12,
            status = "OCCUPIED",
            trackingNumber = "9400109205568999887766",
            recipientName = "Alex Morgan",
            pickupPin = "849201",
            expiresAt = "In 3 days"
        ),
        SmartLocker(
            lockerId = "LCK-02",
            locationName = "Springfield Central Station Hub",
            compartmentNumber = 14,
            status = "AVAILABLE",
            trackingNumber = null,
            recipientName = null,
            pickupPin = null,
            expiresAt = null
        ),
        SmartLocker(
            lockerId = "LCK-03",
            locationName = "Springfield Central Station Hub",
            compartmentNumber = 15,
            status = "AVAILABLE",
            trackingNumber = null,
            recipientName = null,
            pickupPin = null,
            expiresAt = null
        )
    )

    val SAMPLE_PO_BOXES = listOf(
        POBoxItem("PO-Box 1042", "Alex Morgan", "Medium (5x11 in)", "ACTIVE", "Dec 31, 2026", 2, 1),
        POBoxItem("PO-Box 1043", "Evergreen Floral Studio", "Large (11x11 in)", "ACTIVE", "Nov 15, 2026", 5, 3),
        POBoxItem("PO-Box 1044", "Vacant", "Small (3x5 in)", "AVAILABLE", "-", 0, 0)
    )

    val SAMPLE_AUDIT_LOG = listOf(
        AuditEvent(
            eventId = "AUD-99201",
            timestamp = "Today 08:10 AM",
            actor = "Jordan Williams (EMP-88421)",
            role = "CARRIER",
            facility = "Springfield Station Delivery Unit #4",
            action = "MANIFEST_DOWNLOAD_AND_DEPARTURE",
            resource = "CarrierRoute",
            resourceId = "C-042",
            result = "SUCCESS",
            correlationId = "CORR-88421-0912"
        ),
        AuditEvent(
            eventId = "AUD-99200",
            timestamp = "Today 07:45 AM",
            actor = "Taylor Johnson (EMP-41092)",
            role = "RETAIL_ASSOCIATE",
            facility = "Downtown Main Post Office Retail Counter",
            action = "CASH_DRAWER_OPEN_AND_SCALE_ZERO_TARE",
            resource = "ScaleProvider",
            resourceId = "USPS-SCALE-POS-01",
            result = "SUCCESS",
            correlationId = "CORR-41092-0912"
        ),
        AuditEvent(
            eventId = "AUD-99199",
            timestamp = "Today 06:30 AM",
            actor = "Jamie Carter (ADM-00001)",
            role = "SYSTEM_ADMIN",
            facility = "USPS National Command",
            action = "ZERO_TRUST_DEVICE_ATTESTATION_CHECK",
            resource = "DevicePolicy",
            resourceId = "MDD-FLEET-IL-WEST",
            result = "SUCCESS - 148 Devices Verified",
            correlationId = "CORR-00001-0912"
        )
    )
}
