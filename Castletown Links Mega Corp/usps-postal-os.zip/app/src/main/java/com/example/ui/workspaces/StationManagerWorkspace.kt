package com.example.ui.workspaces

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.theme.*

@Composable
fun StationManagerWorkspace(
    carrierRoute: CarrierRoute,
    exceptions: List<ExceptionItem>,
    onReportException: (String, String, String, String) -> Unit,
    activeTab: String,
    onTabChange: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var newExcTracking by remember { mutableStateOf("") }
    var newExcType by remember { mutableStateOf("Damaged Label") }
    var newExcDesc by remember { mutableStateOf("") }
    var showAddDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(USPSLightBg)
    ) {
        ScrollableTabRow(
            selectedTabIndex = when (activeTab) {
                "OPERATIONS_KPI" -> 0
                "ROUTES_ROSTER" -> 1
                "EXCEPTIONS" -> 2
                else -> 0
            },
            containerColor = Color.White,
            contentColor = USPSBluePrimary,
            edgePadding = 12.dp
        ) {
            Tab(selected = activeTab == "OPERATIONS_KPI", onClick = { onTabChange("OPERATIONS_KPI") }, text = { Text("Station KPIs") }, icon = { Icon(Icons.Default.Analytics, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "ROUTES_ROSTER", onClick = { onTabChange("ROUTES_ROSTER") }, text = { Text("Carrier Fleet Roster") }, icon = { Icon(Icons.Default.DirectionsCar, null, Modifier.size(18.dp)) })
            Tab(selected = activeTab == "EXCEPTIONS", onClick = { onTabChange("EXCEPTIONS") }, text = { Text("Exception Triage (${exceptions.size})") }, icon = { Icon(Icons.Default.Warning, null, Modifier.size(18.dp)) })
        }

        Divider(color = USPSBorder)

        when (activeTab) {
            "OPERATIONS_KPI" -> {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text("STATION PERFORMANCE DASHBOARD (SPRINGFIELD ZONE 62704)", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = USPSBluePrimary)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.weight(1f)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Route Completion", fontSize = 10.sp, color = Color(0xFF64748B))
                                Text("82.4%", fontSize = 22.sp, fontWeight = FontWeight.Black, color = StatusGreen)
                                Text("18 of 22 routes completed", fontSize = 10.sp, color = Color(0xFF94A3B8))
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.weight(1f)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Parcels Dispatched", fontSize = 10.sp, color = Color(0xFF64748B))
                                Text("1,420", fontSize = 22.sp, fontWeight = FontWeight.Black, color = USPSBluePrimary)
                                Text("1,392 Delivered on time", fontSize = 10.sp, color = Color(0xFF94A3B8))
                            }
                        }
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.weight(1f)) {
                            Column(Modifier.padding(14.dp)) {
                                Text("Active Exceptions", fontSize = 10.sp, color = Color(0xFF64748B))
                                Text("${exceptions.size}", fontSize = 22.sp, fontWeight = FontWeight.Black, color = USPSRedAccent)
                                Text("Requires supervisor review", fontSize = 10.sp, color = Color(0xFF94A3B8))
                            }
                        }
                    }

                    // Carrier Performance Table
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("ACTIVE ROUTE DISPATCH GAUGES", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = USPSBluePrimary)
                            Spacer(Modifier.height(10.dp))

                            listOf(
                                Triple("Route C-041 (Downtown Core)", "Carrier Marcus Vance", 0.95f),
                                Triple("Route C-042 (West District - Jordan Williams)", "Carrier Jordan Williams", 0.40f),
                                Triple("Route C-043 (North Hills Rural)", "Carrier Samantha Lee", 0.75f),
                                Triple("Route C-044 (Industrial Park)", "Carrier David Miller", 1.0f)
                            ).forEach { (rName, cName, prog) ->
                                Column(Modifier.padding(vertical = 6.dp)) {
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(rName, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                        Text("${(prog * 100).toInt()}%", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = USPSBluePrimary)
                                    }
                                    Text(cName, fontSize = 10.sp, color = Color(0xFF64748B))
                                    Spacer(Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { prog },
                                        color = if (prog == 1.0f) StatusGreen else USPSBluePrimary,
                                        modifier = Modifier.fillMaxWidth().height(6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            "ROUTES_ROSTER" -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text("DELIVERY WORKFORCE & FLEET STATUS", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = USPSBluePrimary)
                    }
                    items(listOf(
                        CarrierRoute("C-041", "Springfield Downtown #1", "Marcus Vance (EMP-33109)", "LLV-68190", 24, 23, 42, 140, "IN_PROGRESS", emptyList()),
                        carrierRoute,
                        CarrierRoute("C-043", "Springfield North Hills #3", "Samantha Lee (EMP-77182)", "Metris-4011", 30, 22, 60, 210, "IN_PROGRESS", emptyList()),
                        CarrierRoute("C-044", "Industrial East Loop #4", "David Miller (EMP-99201)", "Promaster-902", 18, 18, 55, 90, "COMPLETED", emptyList())
                    )) { r ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                                Column {
                                    Text("ROUTE ${r.routeId} • ${r.routeName}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text(r.carrierName, fontSize = 11.sp, color = USPSTextSecondary)
                                    Text("Vehicle: ${r.vehicleId} • ${r.packageCount} Parcels", fontSize = 10.sp, color = Color(0xFF64748B))
                                }
                                Surface(
                                    color = if (r.shiftStatus == "COMPLETED") StatusGreenBg else StatusBlueBg,
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = r.shiftStatus,
                                        color = if (r.shiftStatus == "COMPLETED") StatusGreen else USPSBluePrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            "EXCEPTIONS" -> {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("STATION EXCEPTION TRIAGE LOG", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = USPSBluePrimary)
                            Button(
                                onClick = { showAddDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = USPSRedAccent),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("LOG INCIDENT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    items(exceptions) { exc ->
                        Card(colors = CardDefaults.cardColors(containerColor = Color.White), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(14.dp)) {
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("${exc.exceptionId} • ${exc.type}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Surface(
                                        color = if (exc.severity == "HIGH") StatusRedBg else StatusAmberBg,
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text(
                                            text = exc.severity,
                                            color = if (exc.severity == "HIGH") StatusRed else StatusAmber,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.ExtraBold,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Text("Tracking: ${exc.trackingNumber}", fontSize = 10.sp, color = Color(0xFF64748B))
                                Text(exc.description, fontSize = 11.sp, color = USPSTextPrimary)
                                Spacer(Modifier.height(4.dp))
                                Text("Assigned: ${exc.assignedTo} • ${exc.createdAt}", fontSize = 10.sp, color = Color(0xFF94A3B8))
                            }
                        }
                    }
                }
            }
        }
    }
}
