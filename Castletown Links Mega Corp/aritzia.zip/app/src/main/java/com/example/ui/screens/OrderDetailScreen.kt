package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Order
import com.example.ui.theme.AritziaBlack
import com.example.ui.theme.AritziaBorderGray
import com.example.ui.theme.AritziaGold
import com.example.ui.theme.AritziaIvory
import com.example.ui.theme.AritziaMutedGray
import com.example.ui.viewmodel.AppViewModel

@Composable
fun OrderDetailScreen(
    order: Order,
    viewModel: AppViewModel,
    onBack: () -> Unit
) {
    var showReturnDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "ORDER #${order.orderNumber}",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Serif,
                        letterSpacing = 2.sp
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // ORDER STATUS TIMELINE
            item {
                Text("ORDER STATUS TIMELINE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp))
                Spacer(modifier = Modifier.height(12.dp))

                val states = listOf("PLACED", "CONFIRMED", "PROCESSING", "DISPATCHED", "DELIVERED")
                val activeIndex = states.indexOf(order.status).let { if (it == -1) 4 else it }

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        states.forEachIndexed { index, st ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .background(
                                            if (index <= activeIndex) AritziaBlack else AritziaBorderGray,
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (index <= activeIndex) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AritziaGold, modifier = Modifier.size(16.dp))
                                    }
                                }
                                Text(
                                    text = st,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = if (index == activeIndex) FontWeight.Bold else FontWeight.Normal,
                                        color = if (index <= activeIndex) AritziaBlack else AritziaMutedGray
                                    )
                                )
                            }
                            if (index < states.size - 1) {
                                Box(
                                    modifier = Modifier
                                        .padding(start = 11.dp)
                                        .width(2.dp)
                                        .height(16.dp)
                                        .background(if (index < activeIndex) AritziaBlack else AritziaBorderGray)
                                )
                            }
                        }
                    }
                }
            }

            // CARRIER TRACKING DETAILS
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = AritziaIvory)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("SHIPMENT TRACKING", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Carrier: ${order.carrier}", style = MaterialTheme.typography.bodyMedium)
                        Text("Tracking #: ${order.trackingNumber}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        Text("Estimated Delivery: ${order.estimatedDelivery}", style = MaterialTheme.typography.bodySmall, color = AritziaMutedGray)
                    }
                }
            }

            // DELIVERY ADDRESS & TOTALS
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("DELIVERY ADDRESS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(order.shippingAddress, style = MaterialTheme.typography.bodyMedium)

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = AritziaBorderGray)
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Subtotal", style = MaterialTheme.typography.bodyMedium)
                            Text("$${String.format("%.2f", order.subtotal)} CAD", style = MaterialTheme.typography.bodyMedium)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Tax (12%)", style = MaterialTheme.typography.bodyMedium)
                            Text("$${String.format("%.2f", order.tax)} CAD", style = MaterialTheme.typography.bodyMedium)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Shipping", style = MaterialTheme.typography.bodyMedium)
                            Text(if (order.shipping == 0.0) "FREE" else "$${String.format("%.2f", order.shipping)} CAD", style = MaterialTheme.typography.bodyMedium)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                            Text("$${String.format("%.2f", order.total)} CAD", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }

            // RETURN INITIATION ACTION
            if (order.returnEligible) {
                item {
                    Button(
                        onClick = { showReturnDialog = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("initiate_return_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = AritziaBlack)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("INITIATE COMPLIMENTARY RETURN", style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }
    }

    if (showReturnDialog) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable { showReturnDialog = false },
            contentAlignment = Alignment.Center
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth(0.9f)
                    .clickable(enabled = false) {},
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("INITIATE RETURN", style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Select return reason:", style = MaterialTheme.typography.labelMedium)
                    Spacer(modifier = Modifier.height(8.dp))

                    val reasons = listOf("Size too large", "Size too small", "Changed mind", "Style preference")
                    reasons.forEach { r ->
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clickable {
                                    viewModel.initiateReturn(order.orderId, r)
                                    showReturnDialog = false
                                },
                            color = AritziaIvory,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(r, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
            }
        }
    }
}
