package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Category
import com.example.data.model.Product
import com.example.data.model.SearchFilter
import com.example.ui.theme.AritziaBlack
import com.example.ui.theme.AritziaBorderGray
import com.example.ui.theme.AritziaIvory
import com.example.ui.theme.AritziaMutedGray
import com.example.ui.theme.AritziaStone
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShopScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val categories by viewModel.categories.collectAsState()
    val filter by viewModel.searchFilter.collectAsState()
    val products by viewModel.filteredProducts.collectAsState()
    var showFilterSheet by remember { mutableStateOf(false) }
    var quickAddProduct by remember { mutableStateOf<Product?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Search Input Bar
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            OutlinedTextField(
                value = filter.query,
                onValueChange = { q ->
                    viewModel.updateProductFilter(filter.copy(query = q))
                },
                placeholder = {
                    Text(
                        text = "Search coat, Effortless pant, cashmere...",
                        style = MaterialTheme.typography.bodyMedium,
                        color = AritziaMutedGray
                    )
                },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = "Search", tint = AritziaMutedGray)
                },
                trailingIcon = {
                    if (filter.query.isNotEmpty()) {
                        IconButton(onClick = { viewModel.updateProductFilter(filter.copy(query = "")) }) {
                            Icon(Icons.Default.Close, contentDescription = "Clear search", tint = AritziaMutedGray)
                        }
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("shop_search_input"),
                singleLine = true,
                shape = RoundedCornerShape(4.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = AritziaBlack,
                    unfocusedBorderColor = AritziaBorderGray
                )
            )
        }

        // Category Filter Tabs Row
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            item {
                FilterChip(
                    selected = filter.category == null,
                    onClick = { viewModel.selectCategoryFilter(null) },
                    label = { Text("All Clothing") },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AritziaBlack,
                        selectedLabelColor = Color.White
                    )
                )
            }
            items(categories, key = { it.id }) { cat ->
                FilterChip(
                    selected = filter.category == cat.name,
                    onClick = {
                        val newCat = if (filter.category == cat.name) null else cat.name
                        viewModel.selectCategoryFilter(newCat)
                    },
                    label = { Text(cat.name) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AritziaBlack,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // Filter Bar (Count + Filter Modal Trigger)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "${products.size} STYLES",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.5.sp
                ),
                color = AritziaMutedGray
            )

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Surface(
                    modifier = Modifier.clickable { showFilterSheet = true },
                    shape = RoundedCornerShape(4.dp),
                    color = AritziaStone.copy(alpha = 0.5f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.FilterList, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("FILTERS", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        Divider(color = AritziaBorderGray, thickness = 0.5.dp)

        // Product Grid
        if (products.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "No products found matching your search.",
                        style = MaterialTheme.typography.titleMedium,
                        color = AritziaMutedGray
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.updateProductFilter(SearchFilter()) },
                        colors = ButtonDefaults.buttonColors(containerColor = AritziaBlack)
                    ) {
                        Text("RESET FILTERS")
                    }
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(products, key = { it.id }) { product ->
                    ShopProductGridCard(
                        product = product,
                        onClick = { viewModel.openProductDetail(product.id) },
                        onQuickAdd = { quickAddProduct = product },
                        onWishlistToggle = { viewModel.toggleWishlist(product.id) },
                        isWishlisted = viewModel.isWishlisted(product.id)
                    )
                }
            }
        }
    }

    // Quick Add Size Sheet Modal
    quickAddProduct?.let { product ->
        QuickAddSizeModal(
            product = product,
            onClose = { quickAddProduct = null },
            onSelectSize = { size, color ->
                viewModel.addToCart(product, color, size, 1)
                quickAddProduct = null
            }
        )
    }

    // Advanced Filter Sheet Modal
    if (showFilterSheet) {
        FilterSheetModal(
            currentFilter = filter,
            onClose = { showFilterSheet = false },
            onApplyFilter = { newFilter ->
                viewModel.updateProductFilter(newFilter)
                showFilterSheet = false
            }
        )
    }
}

@Composable
fun ShopProductGridCard(
    product: Product,
    onClick: () -> Unit,
    onQuickAdd: () -> Unit,
    onWishlistToggle: () -> Unit,
    isWishlisted: Boolean
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.72f)
                .clip(RoundedCornerShape(4.dp))
                .background(AritziaStone)
        ) {
            AsyncImage(
                model = product.imageUrl,
                contentDescription = product.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            IconButton(
                onClick = onWishlistToggle,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(32.dp)
                    .background(Color.White.copy(alpha = 0.85f), CircleShape)
            ) {
                Icon(
                    imageVector = Icons.Default.FilterList,
                    contentDescription = null,
                    tint = AritziaBlack,
                    modifier = Modifier.size(16.dp)
                )
            }

            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(8.dp)
                    .clickable { onQuickAdd() },
                color = AritziaBlack.copy(alpha = 0.9f),
                shape = RoundedCornerShape(2.dp)
            ) {
                Text(
                    text = "+ QUICK ADD",
                    style = MaterialTheme.typography.labelSmall.copy(
                        letterSpacing = 1.sp,
                        fontSize = 10.sp
                    ),
                    color = Color.White,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = product.brand.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = AritziaMutedGray
        )
        Text(
            text = product.name,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = "$${String.format("%.2f", product.price)} CAD",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
        )

        Row(
            modifier = Modifier.padding(top = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            product.colors.take(4).forEach { col ->
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(
                            try {
                                Color(android.graphics.Color.parseColor(col.hexCode))
                            } catch (e: Exception) {
                                AritziaBlack
                            }
                        )
                        .border(0.5.dp, AritziaBorderGray, CircleShape)
                )
            }
        }
    }
}

@Composable
fun QuickAddSizeModal(
    product: Product,
    onClose: () -> Unit,
    onSelectSize: (String, String) -> Unit
) {
    var selectedColor by remember { mutableStateOf(product.colors.first().colorName) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable { onClose() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = false) {},
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "QUICK ADD TO BAG",
                        style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Serif)
                    )
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.Close, contentDescription = null)
                    }
                }

                Text(
                    text = "${product.brand} — ${product.name}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AritziaMutedGray
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text("Select Color: $selectedColor", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(product.colors) { col ->
                        Surface(
                            modifier = Modifier.clickable { selectedColor = col.colorName },
                            shape = RoundedCornerShape(4.dp),
                            color = if (selectedColor == col.colorName) AritziaBlack else AritziaIvory,
                            border = if (selectedColor == col.colorName) null else androidx.compose.foundation.BorderStroke(1.dp, AritziaBorderGray)
                        ) {
                            Text(
                                text = col.colorName,
                                style = MaterialTheme.typography.bodySmall,
                                color = if (selectedColor == col.colorName) Color.White else AritziaBlack,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Select Size:", style = MaterialTheme.typography.labelMedium)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    product.sizes.forEach { size ->
                        Surface(
                            modifier = Modifier
                                .weight(1f)
                                .clickable { onSelectSize(size, selectedColor) },
                            shape = RoundedCornerShape(4.dp),
                            color = AritziaIvory,
                            border = androidx.compose.foundation.BorderStroke(1.dp, AritziaBorderGray)
                        ) {
                            Box(
                                modifier = Modifier.padding(vertical = 12.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(size, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun FilterSheetModal(
    currentFilter: SearchFilter,
    onClose: () -> Unit,
    onApplyFilter: (SearchFilter) -> Unit
) {
    var brand by remember { mutableStateOf(currentFilter.brand) }
    var sortBy by remember { mutableStateOf(currentFilter.sortBy) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable { onClose() },
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clickable(enabled = false) {},
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "SORT & FILTER",
                    style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif)
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text("SORT BY", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(8.dp))
                val sortOptions = listOf("Featured", "Newest", "PriceLow", "PriceHigh", "Rating")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(sortOptions) { opt ->
                        FilterChip(
                            selected = sortBy == opt,
                            onClick = { sortBy = opt },
                            label = { Text(opt) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AritziaBlack,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("BRAND", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(8.dp))
                val brands = listOf("Wilfred", "Babaton", "TNA", "Sunday Best", "Ten by Babaton", "Denim Forum")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(brands) { b ->
                        FilterChip(
                            selected = brand == b,
                            onClick = { brand = if (brand == b) null else b },
                            label = { Text(b) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AritziaBlack,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            onApplyFilter(SearchFilter())
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AritziaStone)
                    ) {
                        Text("RESET", color = AritziaBlack)
                    }

                    Button(
                        onClick = {
                            onApplyFilter(currentFilter.copy(brand = brand, sortBy = sortBy))
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AritziaBlack)
                    ) {
                        Text("APPLY FILTERS", color = Color.White)
                    }
                }
            }
        }
    }
}
