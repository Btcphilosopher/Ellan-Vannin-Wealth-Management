package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ClosetItem
import com.example.ui.theme.AritziaBlack
import com.example.ui.theme.AritziaBorderGray
import com.example.ui.theme.AritziaGold
import com.example.ui.theme.AritziaIvory
import com.example.ui.theme.AritziaMutedGray
import com.example.ui.theme.AritziaStone
import com.example.ui.viewmodel.AppViewModel

@Composable
fun ClosetScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val closetItems by viewModel.closetItems.collectAsState()
    var selectedTab by remember { mutableStateOf("All Wardrobe") }
    var selectedItem by remember { mutableStateOf<ClosetItem?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Closet Header
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "DIGITAL CLOSET",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 2.sp,
                            fontWeight = FontWeight.Bold
                        ),
                        color = AritziaGold
                    )
                    Text(
                        text = "My Aritzia Wardrobe",
                        style = MaterialTheme.typography.displaySmall.copy(fontFamily = FontFamily.Serif)
                    )
                }

                Surface(
                    color = AritziaIvory,
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "${closetItems.size} PIECES",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Verified online and in-store purchases synced with care instructions and wear history.",
                style = MaterialTheme.typography.bodySmall,
                color = AritziaMutedGray
            )
        }

        // Closet Filter Tabs
        val tabs = listOf("All Wardrobe", "Coats", "Trousers", "Tops", "Sweaters")
        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tabs) { tab ->
                FilterChip(
                    selected = selectedTab == tab,
                    onClick = { selectedTab = tab },
                    label = { Text(tab) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = AritziaBlack,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (closetItems.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Checkroom,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = AritziaMutedGray
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Your digital closet is empty.",
                        style = MaterialTheme.typography.titleMedium,
                        color = AritziaMutedGray
                    )
                    Text(
                        text = "Purchases made in-store or online automatically sync here.",
                        style = MaterialTheme.typography.bodySmall,
                        color = AritziaMutedGray
                    )
                }
            }
        } else {
            val filteredList = closetItems.filter { item ->
                when (selectedTab) {
                    "Coats" -> item.productName.contains("Coat", ignoreCase = true) || item.productName.contains("Puff", ignoreCase = true)
                    "Trousers" -> item.productName.contains("Pant", ignoreCase = true) || item.productName.contains("Trouser", ignoreCase = true)
                    "Tops" -> item.productName.contains("Tank", ignoreCase = true) || item.productName.contains("Shirt", ignoreCase = true)
                    "Sweaters" -> item.productName.contains("Sweater", ignoreCase = true)
                    else -> true
                }
            }

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(20.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredList, key = { it.id }) { item ->
                    ClosetGridCard(
                        item = item,
                        onClick = { selectedItem = item }
                    )
                }
            }
        }
    }

    // CLOSET ITEM DETAIL MODAL
    selectedItem?.let { item ->
        ClosetItemDetailModal(
            item = item,
            onClose = { selectedItem = null }
        )
    }
}

@Composable
fun ClosetGridCard(
    item: ClosetItem,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(4.dp)
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(0.8f)
                    .background(AritziaStone)
            ) {
                AsyncImage(
                    model = item.imageUrl,
                    contentDescription = item.productName,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // OWNED BADGE
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp),
                    color = AritziaBlack,
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AritziaGold, modifier = Modifier.size(10.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "OWNED",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                            color = Color.White
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(10.dp)) {
                Text(
                    text = item.brand.uppercase(),
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                    color = AritziaMutedGray
                )
                Text(
                    text = item.productName,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "${item.color} • Size ${item.size}",
                    style = MaterialTheme.typography.bodySmall,
                    color = AritziaMutedGray
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Worn ${item.timesWorn} times",
                    style = MaterialTheme.typography.labelSmall.copy(color = AritziaGold)
                )
            }
        }
    }
}

@Composable
fun ClosetItemDetailModal(
    item: ClosetItem,
    onClose: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable { onClose() },
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.9f)
                .clickable(enabled = false) {},
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = item.brand.uppercase(),
                            style = MaterialTheme.typography.labelSmall,
                            color = AritziaMutedGray
                        )
                        Text(
                            text = item.productName,
                            style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Serif)
                        )
                    }
                    IconButton(onClick = onClose) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AritziaGold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    AsyncImage(
                        model = item.imageUrl,
                        contentDescription = item.productName,
                        modifier = Modifier
                            .size(110.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        contentScale = ContentScale.Crop
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text("Size: ${item.size}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        Text("Color: ${item.color}", style = MaterialTheme.typography.bodyMedium)
                        Text("Purchased: ${item.purchaseDate}", style = MaterialTheme.typography.bodySmall, color = AritziaMutedGray)
                        Text("Order Ref: ${item.orderRef}", style = MaterialTheme.typography.bodySmall, color = AritziaMutedGray)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Times Worn: ${item.timesWorn}", style = MaterialTheme.typography.labelSmall.copy(color = AritziaGold))
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = AritziaBorderGray)
                Spacer(modifier = Modifier.height(12.dp))

                Text("CARE INSTRUCTIONS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
                Text(item.careInfo, style = MaterialTheme.typography.bodyMedium, color = AritziaMutedGray)

                Spacer(modifier = Modifier.height(12.dp))

                Text("PERSONAL STYLING NOTES", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(4.dp))
                Text(item.notes, style = MaterialTheme.typography.bodyMedium)

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onClose,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = AritziaBlack)
                ) {
                    Text("CLOSE GARMENT CARD")
                }
            }
        }
    }
}
