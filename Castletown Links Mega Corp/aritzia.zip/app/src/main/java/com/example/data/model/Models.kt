package com.example.data.model

data class ProductColor(
    val colorName: String,
    val hexCode: String
)

data class Product(
    val id: String,
    val name: String,
    val brand: String,
    val category: String,
    val price: Double,
    val salePrice: Double? = null,
    val rating: Float = 4.8f,
    val reviewCount: Int = 124,
    val isNewArrival: Boolean = false,
    val isBestSeller: Boolean = false,
    val isExclusive: Boolean = false,
    val fabricComposition: String,
    val fitDescription: String,
    val careInstructions: String,
    val imageUrl: String,
    val altImages: List<String> = emptyList(),
    val colors: List<ProductColor>,
    val sizes: List<String> = listOf("XXS", "XS", "S", "M", "L", "XL"),
    val tags: List<String> = emptyList(),
    val silhouette: String = "Regular",
    val season: String = "Core Essentials",
    val isAvailable: Boolean = true
)

data class ProductVariant(
    val variantId: String,
    val productId: String,
    val colorName: String,
    val size: String,
    val sku: String,
    val stockCount: Int
)

data class Category(
    val id: String,
    val name: String,
    val itemCount: Int,
    val subcategories: List<String>
)

data class CollectionLaunch(
    val id: String,
    val name: String,
    val title: String,
    val description: String,
    val launchTimestamp: Long,
    val region: String = "Global",
    val status: String = "AVAILABLE", // UPCOMING, AVAILABLE, ENDED
    val bannerUrl: String,
    val productIds: List<String> = emptyList(),
    val isReminded: Boolean = false
)

data class OutfitItem(
    val productId: String,
    val productName: String,
    val brand: String,
    val colorName: String,
    val size: String,
    val price: Double,
    val imageUrl: String,
    val posX: Float = 0f,
    val posY: Float = 0f
)

data class Outfit(
    val id: String,
    val title: String,
    val description: String,
    val occasion: String,
    val weather: String,
    val season: String,
    val colorPalette: String,
    val items: List<OutfitItem>,
    val bannerUrl: String,
    val isSaved: Boolean = false
)

data class ClosetItem(
    val id: String,
    val productId: String,
    val productName: String,
    val brand: String,
    val variantId: String,
    val size: String,
    val color: String,
    val purchaseDate: String,
    val orderRef: String,
    val imageUrl: String,
    val careInfo: String,
    val notes: String = "",
    val timesWorn: Int = 1,
    val rating: Float = 5.0f
)

data class CartItem(
    val id: String,
    val productId: String,
    val productName: String,
    val brand: String,
    val colorName: String,
    val size: String,
    val price: Double,
    val quantity: Int,
    val imageUrl: String,
    val inStock: Boolean = true
)

data class WishlistItem(
    val id: String,
    val productId: String,
    val addedDate: String
)

data class Order(
    val orderId: String,
    val orderNumber: String,
    val datePlaced: String,
    val status: String, // PLACED, CONFIRMED, PROCESSING, DISPATCHED, DELIVERED
    val items: List<CartItem>,
    val subtotal: Double,
    val tax: Double,
    val shipping: Double,
    val total: Double,
    val shippingAddress: String,
    val trackingNumber: String,
    val carrier: String,
    val estimatedDelivery: String,
    val returnEligible: Boolean = true
)

data class Store(
    val id: String,
    val name: String,
    val city: String,
    val address: String,
    val postalCode: String,
    val phone: String,
    val hours: String,
    val latitude: Double,
    val longitude: Double,
    val distanceKm: Double,
    val hasInventory: Boolean = true
)

data class FitProfile(
    val usualSize: String = "M",
    val preferredFit: String = "REGULAR", // FITTED, REGULAR, OVERSIZED
    val bustInches: Float = 35f,
    val waistInches: Float = 27f,
    val hipInches: Float = 38f,
    val preferredLength: String = "REGULAR", // PETITE, REGULAR, TALL
    val fitConfidence: Int = 92
)

data class UserProfile(
    val name: String = "Sophia Vance",
    val email: String = "sophia.vance@example.com",
    val tier: String = "Aritzia Insider",
    val memberSince: String = "2024",
    val defaultAddress: String = "1055 W Georgia St, Vancouver, BC V6E 3P3"
)

data class SearchFilter(
    val query: String = "",
    val category: String? = null,
    val brand: String? = null,
    val minPrice: Double? = null,
    val maxPrice: Double? = null,
    val selectedColor: String? = null,
    val selectedSize: String? = null,
    val selectedMaterial: String? = null,
    val selectedSilhouette: String? = null,
    val sortBy: String = "Featured" // Featured, Newest, PriceLow, PriceHigh, Rating
)
