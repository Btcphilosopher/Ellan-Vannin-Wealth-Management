package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        CartItemEntity::class,
        WishlistItemEntity::class,
        ClosetItemEntity::class,
        SavedOutfitEntity::class,
        OrderEntity::class,
        FitProfileEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AritziaDatabase : RoomDatabase() {

    abstract fun aritziaDao(): AritziaDao

    companion object {
        @Volatile
        private var INSTANCE: AritziaDatabase? = null

        fun getDatabase(context: Context): AritziaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AritziaDatabase::class.java,
                    "aritzia_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
