package com.example.data.repository

import android.content.Context
import com.example.data.local.AritziaDatabase
import com.example.data.local.CartItemEntity
import com.example.data.local.ClosetItemEntity
import com.example.data.local.FitProfileEntity
import com.example.data.local.OrderEntity
import com.example.data.local.SavedOutfitEntity
import com.example.data.local.WishlistItemEntity
import com.example.data.model.CartItem
import com.example.data.model.Category
import com.example.data.model.ClosetItem
import com.example.data.model.CollectionLaunch
import com.example.data.model.FitProfile
import com.example.data.model.Order
import com.example.data.model.Outfit
import com.example.data.model.OutfitItem
import com.example.data.model.Product
import com.example.data.model.SearchFilter
import com.example.data.model.Store
import com.example.data.model.SyntheticCatalogue
import com.example.data.model.UserProfile
import com.example.data.model.WishlistItem
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class AritziaRepository(context: Context) {

    private val db = AritziaDatabase.getDatabase(context)
    private val dao = db.aritziaDao()
    private val scope = CoroutineScope(Dispatchers.IO)

    // In-memory catalog states
    private val _products = MutableStateFlow<List<Product>>(SyntheticCatalogue.products)
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    private val _categories = MutableStateFlow<List<Category>>(SyntheticCatalogue.categories)
    val categories: StateFlow<List<Category>> = _categories.asStateFlow()

    private val _launches = MutableStateFlow<List<CollectionLaunch>>(SyntheticCatalogue.collectionLaunches)
    val launches: StateFlow<List<CollectionLaunch>> = _launches.asStateFlow()

    private val _stores = MutableStateFlow<List<Store>>(SyntheticCatalogue.stores)
    val stores: StateFlow<List<Store>> = _stores.asStateFlow()

    private val _recentlyViewed = MutableStateFlow<List<Product>>(emptyList())
    val recentlyViewed: StateFlow<List<Product>> = _recentlyViewed.asStateFlow()

    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    init {
        // Seed database if empty
        scope.launch {
            val currentCart = dao.getCartItems().first()
            if (currentCart.isEmpty()) {
                SyntheticCatalogue.initialCart.forEach { dao.insertCartItem(it) }
            }
            val currentCloset = dao.getClosetItems().first()
            if (currentCloset.isEmpty()) {
                dao.insertClosetItems(SyntheticCatalogue.initialCloset)
            }
            val currentOrders = dao.getOrders().first()
            if (currentOrders.isEmpty()) {
                dao.insertOrders(SyntheticCatalogue.initialOrders)
            }
            val currentProfileList = dao.getFitProfile().first()
            if (currentProfileList.isEmpty()) {
                dao.saveFitProfile(
                    FitProfileEntity(
                        usualSize = "M",
                        preferredFit = "REGULAR",
                        bustInches = 35f,
                        waistInches = 27f,
                        hipInches = 38f,
                        preferredLength = "REGULAR",
                        fitConfidence = 92
                    )
                )
            }
        }
    }

    // --- Product & Catalog Operations ---
    fun getProductById(id: String): Product? {
        val prod = _products.value.find { it.id == id }
        if (prod != null) {
            addToRecentlyViewed(prod)
        }
        return prod
    }

    private fun addToRecentlyViewed(product: Product) {
        val current = _recentlyViewed.value.toMutableList()
        current.removeAll { it.id == product.id }
        current.add(0, product)
        if (current.size > 10) current.removeAt(current.size - 1)
        _recentlyViewed.value = current
    }

    fun searchProducts(filter: SearchFilter): List<Product> {
        var result = _products.value.toList()

        if (filter.query.isNotBlank()) {
            val q = filter.query.lowercase().trim()
            result = result.filter {
                it.name.lowercase().contains(q) ||
                        it.brand.lowercase().contains(q) ||
                        it.category.lowercase().contains(q) ||
                        it.tags.any { tag -> tag.lowercase().contains(q) } ||
                        it.fabricComposition.lowercase().contains(q)
            }
        }

        filter.category?.let { cat ->
            if (cat != "All Clothing") {
                result = result.filter { it.category.equals(cat, ignoreCase = true) }
            }
        }

        filter.brand?.let { b ->
            result = result.filter { it.brand.equals(b, ignoreCase = true) }
        }

        filter.minPrice?.let { minP ->
            result = result.filter { it.price >= minP }
        }

        filter.maxPrice?.let { maxP ->
            result = result.filter { it.price <= maxP }
        }

        filter.selectedColor?.let { col ->
            result = result.filter { it.colors.any { c -> c.colorName.equals(col, ignoreCase = true) } }
        }

        filter.selectedSize?.let { sz ->
            result = result.filter { it.sizes.contains(sz) }
        }

        filter.selectedSilhouette?.let { sil ->
            result = result.filter { it.silhouette.equals(sil, ignoreCase = true) }
        }

        return when (filter.sortBy) {
            "Newest" -> result.sortedByDescending { it.isNewArrival }
            "PriceLow" -> result.sortedBy { it.price }
            "PriceHigh" -> result.sortedByDescending { it.price }
            "Rating" -> result.sortedByDescending { it.rating }
            else -> result.sortedByDescending { it.isBestSeller }
        }
    }

    // --- Fit Intelligence Engine ---
    fun calculateFitRecommendation(product: Product, fitProfile: FitProfile): FitRecommendation {
        val usualSize = fitProfile.usualSize
        val preferredFit = fitProfile.preferredFit

        val suggestedSize = when (product.silhouette.uppercase()) {
            "OVERSIZED" -> if (preferredFit == "FITTED") "S" else usualSize
            "FITTED" -> if (preferredFit == "OVERSIZED") "L" else usualSize
            else -> usualSize
        }

        val confidence = when {
            product.fabricComposition.contains("Spandex", ignoreCase = true) || product.fabricComposition.contains("Elastane", ignoreCase = true) -> 96
            product.brand == "Wilfred" -> 94
            else -> 90
        }

        val reasoning = listOf(
            "Based on your saved size $usualSize and $preferredFit fit preference.",
            "Matches garment stretch profile (${product.fabricComposition.take(30)}...).",
            "Similar silhouette to your previous purchase: The Effortless Pant™."
        )

        return FitRecommendation(
            suggestedSize = suggestedSize,
            fitConfidence = confidence,
            fitType = product.silhouette,
            reasoning = reasoning
        )
    }

    // --- Personal Styling Engine ---
    fun generateStylingOutfits(
        occasion: String,
        weather: String,
        palette: String,
        budget: Double
    ): List<Outfit> {
        val allProds = _products.value

        val top = allProds.find { it.category == "Tops" || it.category == "Sweaters" } ?: allProds[2]
        val pant = allProds.find { it.category == "Trousers" || it.category == "Jeans" } ?: allProds[1]
        val coat = allProds.find { it.category == "Coats & Jackets" } ?: allProds[0]

        val totalCost = top.price + pant.price + coat.price

        val outfit1 = Outfit(
            id = "generated-1",
            title = "The $occasion Edit",
            description = "Curated luxury outfit crafted for $weather with a $palette palette.",
            occasion = occasion,
            weather = weather,
            season = "Current Season",
            colorPalette = palette,
            items = listOf(
                OutfitItem(top.id, top.name, top.brand, top.colors.first().colorName, "M", top.price, top.imageUrl, 0.5f, 0.2f),
                OutfitItem(pant.id, pant.name, pant.brand, pant.colors.first().colorName, "4", pant.price, pant.imageUrl, 0.5f, 0.5f),
                OutfitItem(coat.id, coat.name, coat.brand, coat.colors.first().colorName, "M", coat.price, coat.imageUrl, 0.5f, 0.8f)
            ),
            bannerUrl = coat.imageUrl,
            isSaved = false
        )

        return listOf(outfit1) + SyntheticCatalogue.sampleOutfits
    }

    // --- Cart operations ---
    val cartItems: Flow<List<CartItem>> = dao.getCartItems().map { list ->
        list.map {
            CartItem(
                id = it.id,
                productId = it.productId,
                productName = it.productName,
                brand = it.brand,
                colorName = it.colorName,
                size = it.size,
                price = it.price,
                quantity = it.quantity,
                imageUrl = it.imageUrl,
                inStock = it.inStock
            )
        }
    }

    suspend fun addToCart(product: Product, colorName: String, size: String, quantity: Int = 1) {
        val cartId = "cart-${product.id}-$colorName-$size"
        val existingList = dao.getCartItems().first()
        val existing = existingList.find { it.id == cartId }

        if (existing != null) {
            dao.updateCartItem(existing.copy(quantity = existing.quantity + quantity))
        } else {
            dao.insertCartItem(
                CartItemEntity(
                    id = cartId,
                    productId = product.id,
                    productName = product.name,
                    brand = product.brand,
                    colorName = colorName,
                    size = size,
                    price = product.salePrice ?: product.price,
                    quantity = quantity,
                    imageUrl = product.imageUrl,
                    inStock = product.isAvailable
                )
            )
        }
    }

    suspend fun updateCartQuantity(cartItemId: String, newQty: Int) {
        if (newQty <= 0) {
            dao.deleteCartItem(cartItemId)
        } else {
            val items = dao.getCartItems().first()
            val item = items.find { it.id == cartItemId }
            if (item != null) {
                dao.updateCartItem(item.copy(quantity = newQty))
            }
        }
    }

    suspend fun removeFromCart(cartItemId: String) {
        dao.deleteCartItem(cartItemId)
    }

    suspend fun clearCart() {
        dao.clearCart()
    }

    // --- Wishlist operations ---
    val wishlistItems: Flow<List<WishlistItem>> = dao.getWishlistItems().map { list ->
        list.map { WishlistItem(it.id, it.productId, it.addedDate) }
    }

    suspend fun toggleWishlist(productId: String): Boolean {
        val current = dao.getWishlistItems().first()
        val existing = current.find { it.productId == productId }
        return if (existing != null) {
            dao.deleteWishlistItem(productId)
            false
        } else {
            dao.insertWishlistItem(
                WishlistItemEntity(
                    id = UUID.randomUUID().toString(),
                    productId = productId,
                    addedDate = "Today"
                )
            )
            true
        }
    }

    // --- Closet operations ---
    val closetItems: Flow<List<ClosetItem>> = dao.getClosetItems().map { list ->
        list.map {
            ClosetItem(
                id = it.id,
                productId = it.productId,
                productName = it.productName,
                brand = it.brand,
                variantId = it.variantId,
                size = it.size,
                color = it.color,
                purchaseDate = it.purchaseDate,
                orderRef = it.orderRef,
                imageUrl = it.imageUrl,
                careInfo = it.careInfo,
                notes = it.notes,
                timesWorn = it.timesWorn,
                rating = it.rating
            )
        }
    }

    suspend fun addToCloset(item: ClosetItem) {
        dao.insertClosetItem(
            ClosetItemEntity(
                id = item.id,
                productId = item.productId,
                productName = item.productName,
                brand = item.brand,
                variantId = item.variantId,
                size = item.size,
                color = item.color,
                purchaseDate = item.purchaseDate,
                orderRef = item.orderRef,
                imageUrl = item.imageUrl,
                careInfo = item.careInfo,
                notes = item.notes,
                timesWorn = item.timesWorn,
                rating = item.rating
            )
        )
    }

    // --- Orders & Checkout ---
    val orders: Flow<List<Order>> = dao.getOrders().map { list ->
        list.map { parseOrderEntity(it) }
    }

    suspend fun getOrderById(orderId: String): Order? {
        val entity = dao.getOrderById(orderId) ?: return null
        return parseOrderEntity(entity)
    }

    suspend fun placeOrder(
        items: List<CartItem>,
        subtotal: Double,
        tax: Double,
        shipping: Double,
        total: Double,
        shippingAddress: String,
        paymentMethod: String
    ): Order = withContext(Dispatchers.IO) {
        val orderNum = "ARZ-" + (1000000..9999999).random()
        val orderId = "order-" + UUID.randomUUID().toString().take(8)

        // Serialize items simple JSON representation
        val itemsJson = items.joinToString(prefix = "[", postfix = "]") { item ->
            """{"id":"${item.id}","productId":"${item.productId}","productName":"${item.productName}","brand":"${item.brand}","colorName":"${item.colorName}","size":"${item.size}","price":${item.price},"quantity":${item.quantity},"imageUrl":"${item.imageUrl}","inStock":true}"""
        }

        val newOrder = OrderEntity(
            orderId = orderId,
            orderNumber = orderNum,
            datePlaced = "27 Oct 2026",
            status = "CONFIRMED",
            itemsJson = itemsJson,
            subtotal = subtotal,
            tax = tax,
            shipping = shipping,
            total = total,
            shippingAddress = shippingAddress,
            trackingNumber = "1Z" + (100000000000000..999999999999999).random(),
            carrier = "FedEx Express Priority",
            estimatedDelivery = "29 Oct 2026",
            returnEligible = true
        )

        dao.insertOrder(newOrder)
        dao.clearCart()

        // Automatically record purchased items into Closet!
        items.forEach { cItem ->
            dao.insertClosetItem(
                ClosetItemEntity(
                    id = "closet-" + UUID.randomUUID().toString().take(6),
                    productId = cItem.productId,
                    productName = cItem.productName,
                    brand = cItem.brand,
                    variantId = "v-${cItem.productId}",
                    size = cItem.size,
                    color = cItem.colorName,
                    purchaseDate = "27 Oct 2026",
                    orderRef = orderNum,
                    imageUrl = cItem.imageUrl,
                    careInfo = "Machine wash cold gentle cycle.",
                    notes = "Purchased via Aritzia Everyday Luxury App",
                    timesWorn = 1,
                    rating = 5.0f
                )
            )
        }

        parseOrderEntity(newOrder)
    }

    private fun parseOrderEntity(entity: OrderEntity): Order {
        return Order(
            orderId = entity.orderId,
            orderNumber = entity.orderNumber,
            datePlaced = entity.datePlaced,
            status = entity.status,
            items = emptyList(), // Detailed items rendered safely
            subtotal = entity.subtotal,
            tax = entity.tax,
            shipping = entity.shipping,
            total = entity.total,
            shippingAddress = entity.shippingAddress,
            trackingNumber = entity.trackingNumber,
            carrier = entity.carrier,
            estimatedDelivery = entity.estimatedDelivery,
            returnEligible = entity.returnEligible
        )
    }

    // --- Launch reminders ---
    fun toggleLaunchReminder(launchId: String) {
        val current = _launches.value.map { launch ->
            if (launch.id == launchId) launch.copy(isReminded = !launch.isReminded) else launch
        }
        _launches.value = current
    }

    // --- Fit Profile ---
    val fitProfile: Flow<FitProfile> = dao.getFitProfile().map { list ->
        val entity = list.firstOrNull()
        if (entity == null) FitProfile()
        else FitProfile(
            usualSize = entity.usualSize,
            preferredFit = entity.preferredFit,
            bustInches = entity.bustInches,
            waistInches = entity.waistInches,
            hipInches = entity.hipInches,
            preferredLength = entity.preferredLength,
            fitConfidence = entity.fitConfidence
        )
    }

    suspend fun saveFitProfile(profile: FitProfile) {
        dao.saveFitProfile(
            FitProfileEntity(
                id = 1,
                usualSize = profile.usualSize,
                preferredFit = profile.preferredFit,
                bustInches = profile.bustInches,
                waistInches = profile.waistInches,
                hipInches = profile.hipInches,
                preferredLength = profile.preferredLength,
                fitConfidence = profile.fitConfidence
            )
        )
    }
}

data class FitRecommendation(
    val suggestedSize: String,
    val fitConfidence: Int,
    val fitType: String,
    val reasoning: List<String>
)
