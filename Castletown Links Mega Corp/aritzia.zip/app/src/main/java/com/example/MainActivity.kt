package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.example.ui.components.AritziaBottomBar
import com.example.ui.components.AritziaTopBar
import com.example.ui.components.ShoppingBagDrawer
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.CheckoutScreen
import com.example.ui.screens.ClosetScreen
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.FitProfileScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.screens.OrderDetailScreen
import com.example.ui.screens.ProductDetailScreen
import com.example.ui.screens.ShopScreen
import com.example.ui.screens.StoresScreen
import com.example.ui.screens.StyleScreen
import com.example.ui.theme.AritziaTheme
import com.example.ui.viewmodel.AppViewModel
import com.example.ui.viewmodel.Screen

class MainActivity : ComponentActivity() {

    private val viewModel: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AritziaTheme {
                AritziaMainApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun AritziaMainApp(viewModel: AppViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isBagOpen by viewModel.isBagOpen.collectAsState()
    val cartItems by viewModel.cartItems.collectAsState()
    val cartTotal by viewModel.cartTotal.collectAsState()
    val cartCount by viewModel.cartCount.collectAsState()
    val selectedProduct by viewModel.selectedProduct.collectAsState()
    val selectedOrder by viewModel.selectedOrder.collectAsState()
    val toastMessage by viewModel.toastMessage.collectAsState()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    // Handle Back Press on Secondary Screens
    val isSecondaryScreen = currentScreen !is Screen.Discover &&
            currentScreen !is Screen.Shop &&
            currentScreen !is Screen.Style &&
            currentScreen !is Screen.Closet &&
            currentScreen !is Screen.Account

    if (isSecondaryScreen) {
        BackHandler {
            viewModel.navigateTo(Screen.Discover)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            if (!isSecondaryScreen) {
                AritziaTopBar(
                    currentScreen = currentScreen,
                    cartCount = cartCount,
                    onOpenBag = { viewModel.setBagOpen(true) },
                    onOpenStores = { viewModel.navigateTo(Screen.StoreLocator) },
                    onOpenFitProfile = { viewModel.navigateTo(Screen.FitProfileStudio) },
                    onNavigateHome = { viewModel.navigateTo(Screen.Discover) }
                )
            }
        },
        bottomBar = {
            if (!isSecondaryScreen) {
                AritziaBottomBar(
                    currentScreen = currentScreen,
                    onScreenSelected = { viewModel.navigateTo(it) }
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(targetState = currentScreen, label = "ScreenTransition") { screen ->
                when (screen) {
                    is Screen.Discover -> DiscoverScreen(viewModel = viewModel)
                    is Screen.Shop -> ShopScreen(viewModel = viewModel)
                    is Screen.Style -> StyleScreen(viewModel = viewModel)
                    is Screen.Closet -> ClosetScreen(viewModel = viewModel)
                    is Screen.Account -> AccountScreen(viewModel = viewModel)
                    is Screen.ProductDetail -> {
                        selectedProduct?.let { product ->
                            ProductDetailScreen(
                                product = product,
                                viewModel = viewModel,
                                onBack = { viewModel.navigateTo(Screen.Discover) }
                            )
                        }
                    }
                    is Screen.ShoppingBag -> {
                        viewModel.setBagOpen(true)
                        DiscoverScreen(viewModel = viewModel)
                    }
                    is Screen.Checkout -> {
                        CheckoutScreen(
                            viewModel = viewModel,
                            onBack = { viewModel.navigateTo(Screen.Discover) }
                        )
                    }
                    is Screen.OrderDetail -> {
                        selectedOrder?.let { order ->
                            OrderDetailScreen(
                                order = order,
                                viewModel = viewModel,
                                onBack = { viewModel.navigateTo(Screen.Account) }
                            )
                        }
                    }
                    is Screen.StoreLocator -> {
                        StoresScreen(
                            viewModel = viewModel,
                            onBack = { viewModel.navigateTo(Screen.Account) }
                        )
                    }
                    is Screen.FitProfileStudio -> {
                        FitProfileScreen(
                            viewModel = viewModel,
                            onBack = { viewModel.navigateTo(Screen.Account) }
                        )
                    }
                }
            }

            // Shopping Bag Drawer Overlay
            ShoppingBagDrawer(
                isOpen = isBagOpen,
                cartItems = cartItems,
                subtotal = cartTotal,
                onClose = { viewModel.setBagOpen(false) },
                onUpdateQty = { id, qty -> viewModel.updateCartQty(id, qty) },
                onRemoveItem = { id -> viewModel.removeFromCart(id) },
                onCheckout = {
                    viewModel.setBagOpen(false)
                    viewModel.navigateTo(Screen.Checkout)
                }
            )
        }
    }
}
