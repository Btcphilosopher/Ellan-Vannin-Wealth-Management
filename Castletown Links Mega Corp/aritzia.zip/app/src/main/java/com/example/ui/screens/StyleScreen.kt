package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Outfit
import com.example.ui.theme.AritziaBlack
import com.example.ui.theme.AritziaGold
import com.example.ui.theme.AritziaIvory
import com.example.ui.theme.AritziaMutedGray
import com.example.ui.theme.AritziaStone
import com.example.ui.viewmodel.AppViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StyleScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val generatedOutfits by viewModel.generatedOutfits.collectAsState()

    var selectedOccasion by remember { mutableStateOf("Workwear & Tailoring") }
    var selectedWeather by remember { mutableStateOf("Mild Autumn (15°C)") }
    var selectedPalette by remember { mutableStateOf("Classic Cream & Black") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(
                    text = "ARITZIA STYLE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AritziaGold
                )
                Text(
                    text = "Personal Styling & Lookbook",
                    style = MaterialTheme.typography.displaySmall.copy(fontFamily = FontFamily.Serif)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "AI-powered outfit recommendations matched with real Aritzia catalogue inventory.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AritziaMutedGray
                )
            }
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                colors = CardDefaults.cardColors(containerColor = AritziaIvory),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "1. SELECT OCCASION",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    val occasions = listOf("Workwear & Tailoring", "Evening & Cocktails", "Weekend & Travel", "Sub-Zero Winter")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(occasions) { occ ->
                            FilterChip(
                                selected = selectedOccasion == occ,
                                onClick = {
                                    selectedOccasion = occ
                                    viewModel.generateStyling(selectedOccasion, selectedWeather, selectedPalette, 500.0)
                                },
                                label = { Text(occ) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AritziaBlack,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "2. WEATHER CONTEXT",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    val weathers = listOf("Mild Autumn (15°C)", "Sub-Zero (-10°C)", "Warm Spring (22°C)")
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(weathers) { w ->
                            FilterChip(
                                selected = selectedWeather == w,
                                onClick = {
                                    selectedWeather = w
                                    viewModel.generateStyling(selectedOccasion, selectedWeather, selectedPalette, 500.0)
                                },
                                label = { Text(w) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AritziaBlack,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            viewModel.generateStyling(selectedOccasion, selectedWeather, selectedPalette, 500.0)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("generate_look_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = AritziaBlack)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("GENERATE COORDINATED LOOK", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "RECOMMENDED LOOKS",
                style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif),
                modifier = Modifier.padding(horizontal = 20.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
        }

        items(generatedOutfits, key = { it.id }) { outfit ->
            OutfitCard(
                outfit = outfit,
                onItemClick = { viewModel.openProductDetail(it) },
                onAddAllToBag = {
                    outfit.items.forEach { oItem ->
                        val prod = viewModel.repository.getProductById(oItem.productId)
                        if (prod != null) {
                            viewModel.addToCart(prod, oItem.colorName, oItem.size, 1)
                        }
                    }
                    viewModel.showToast("Added full look to Bag!")
                }
            )
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun OutfitCard(
    outfit: Outfit,
    onItemClick: (String) -> Unit,
    onAddAllToBag: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = outfit.title,
                        style = MaterialTheme.typography.titleLarge.copy(fontFamily = FontFamily.Serif)
                    )
                    Text(
                        text = "${outfit.occasion} • ${outfit.weather}",
                        style = MaterialTheme.typography.bodySmall,
                        color = AritziaMutedGray
                    )
                }

                Surface(
                    color = AritziaIvory,
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text(
                        text = "$${String.format("%.2f", outfit.items.sumOf { it.price })} CAD",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = AritziaBlack),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Text(text = outfit.description, style = MaterialTheme.typography.bodyMedium)
            Spacer(modifier = Modifier.height(16.dp))

            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                outfit.items.forEach { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(AritziaStone.copy(alpha = 0.4f))
                            .clickable { onItemClick(item.productId) }
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        AsyncImage(
                            model = item.imageUrl,
                            contentDescription = item.productName,
                            modifier = Modifier
                                .size(60.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            contentScale = ContentScale.Crop
                        )

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.brand.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = AritziaMutedGray
                            )
                            Text(
                                text = item.productName,
                                style = MaterialTheme.typography.titleSmall
                            )
                            Text(
                                text = "${item.colorName} • Size ${item.size}",
                                style = MaterialTheme.typography.bodySmall,
                                color = AritziaMutedGray
                            )
                        }

                        Text(
                            text = "$${String.format("%.2f", item.price)}",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = onAddAllToBag,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("add_look_to_bag_button"),
                colors = ButtonDefaults.buttonColors(containerColor = AritziaBlack),
                shape = RoundedCornerShape(2.dp)
            ) {
                Icon(Icons.Default.ShoppingBag, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("SHOP THE FULL LOOK", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}
