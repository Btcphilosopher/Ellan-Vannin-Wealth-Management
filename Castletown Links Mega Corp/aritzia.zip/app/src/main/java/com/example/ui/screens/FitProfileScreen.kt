package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FitProfile
import com.example.ui.theme.AritziaBlack
import com.example.ui.theme.AritziaBorderGray
import com.example.ui.theme.AritziaGold
import com.example.ui.theme.AritziaIvory
import com.example.ui.theme.AritziaMutedGray
import com.example.ui.viewmodel.AppViewModel

@Composable
fun FitProfileScreen(
    viewModel: AppViewModel,
    onBack: () -> Unit
) {
    val currentFitProfile by viewModel.fitProfile.collectAsState()

    var usualSize by remember { mutableStateOf(currentFitProfile.usualSize) }
    var preferredFit by remember { mutableStateOf(currentFitProfile.preferredFit) }
    var bust by remember { mutableStateOf(currentFitProfile.bustInches.toString()) }
    var waist by remember { mutableStateOf(currentFitProfile.waistInches.toString()) }
    var hips by remember { mutableStateOf(currentFitProfile.hipInches.toString()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Surface(color = MaterialTheme.colorScheme.surface, tonalElevation = 2.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBack) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Text(
                    text = "FIT PROFILE STUDIO",
                    style = MaterialTheme.typography.titleLarge.copy(
                        fontFamily = FontFamily.Serif,
                        letterSpacing = 2.sp
                    ),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            item {
                Text(
                    text = "FIT INTELLIGENCE",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp),
                    color = AritziaGold
                )
                Text(
                    text = "Personalized Garment Fit Engine",
                    style = MaterialTheme.typography.displaySmall.copy(fontFamily = FontFamily.Serif)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Your measurements are used to calculate fit confidence ratings and size recommendations for every Aritzia garment.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = AritziaMutedGray
                )
            }

            // Usual Size Selector
            item {
                Text("1. USUAL ARITZIA SIZE", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(8.dp))
                val sizes = listOf("XXS", "XS", "S", "M", "L", "XL", "2 (0-2)", "4 (4-6)", "6 (8-10)")
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(sizes) { sz ->
                        FilterChip(
                            selected = usualSize == sz,
                            onClick = { usualSize = sz },
                            label = { Text(sz) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AritziaBlack,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            // Fit Preference
            item {
                Text("2. PREFERRED SILHOUETTE FIT", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(8.dp))
                val fits = listOf("FITTED", "REGULAR", "OVERSIZED")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    fits.forEach { fit ->
                        FilterChip(
                            selected = preferredFit == fit,
                            onClick = { preferredFit = fit },
                            label = { Text(fit) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AritziaBlack,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }

            // Measurements Form
            item {
                Text("3. BODY MEASUREMENTS (INCHES)", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(
                        value = bust,
                        onValueChange = { bust = it },
                        label = { Text("Bust (in)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("bust_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = waist,
                        onValueChange = { waist = it },
                        label = { Text("Waist (in)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("waist_input"),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = hips,
                        onValueChange = { hips = it },
                        label = { Text("Hips (in)") },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("hips_input"),
                        singleLine = true
                    )
                }
            }

            // Save Button
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = {
                        val updated = FitProfile(
                            usualSize = usualSize,
                            preferredFit = preferredFit,
                            bustInches = bust.toFloatOrNull() ?: 35f,
                            waistInches = waist.toFloatOrNull() ?: 27f,
                            hipInches = hips.toFloatOrNull() ?: 38f,
                            preferredLength = "REGULAR",
                            fitConfidence = 94
                        )
                        viewModel.saveFitProfile(updated)
                        onBack()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_fit_profile_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = AritziaBlack),
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text("SAVE FIT PROFILE & CALIBRATE", style = MaterialTheme.typography.labelLarge)
                }
            }
        }
    }
}
