package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.model.CollectionLaunch
import com.example.data.model.Outfit
import com.example.data.model.Product
import com.example.ui.theme.AritziaBlack
import com.example.ui.theme.AritziaBorderGray
import com.example.ui.theme.AritziaGold
import com.example.ui.theme.AritziaIvory
import com.example.ui.theme.AritziaMutedGray
import com.example.ui.theme.AritziaStone
import com.example.ui.viewmodel.AppViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun DiscoverScreen(
    viewModel: AppViewModel,
    modifier: Modifier = Modifier
) {
    val products by viewModel.products.collectAsState()
    val launches by viewModel.launches.collectAsState()
    val recentlyViewed by viewModel.recentlyViewed.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 32.dp)
    ) {
        // 1. EDITORIAL HERO CAMPAIGN BANNER
        item {
            HeroEditorialBanner(
                onShopCampaign = { viewModel.navigateTo(Screen.Shop) }
            )
        }

        // 2. EXCLUSIVE COLLECTION LAUNCHES
        item {
            ExclusiveLaunchesSection(
                launches = launches,
                onToggleReminder = { viewModel.toggleLaunchReminder(it) },
                onShopLaunch = { viewModel.navigateTo(Screen.Shop) }
            )
        }

        // 3. THE LATEST / NEW ARRIVALS CAROUSEL
        item {
            EditorialSectionHeader(
                title = "THE LATEST",
                subtitle = "New Arrivals for Autumn / Winter '26",
                onSeeAll = {
                    viewModel.selectCategoryFilter(null)
                    viewModel.navigateTo(Screen.Shop)
                }
            )
            val newArrivals = products.filter { it.isNewArrival }.take(8)
            HorizontalProductList(
                products = newArrivals,
                onProductClick = { viewModel.openProductDetail(it.id) },
                onWishlistToggle = { viewModel.toggleWishlist(it.id) },
                isWishlisted = { id -> viewModel.isWishlisted(id) }
            )
        }

        // 4. THE ARITZIA EDIT - ICONIC PIECES
        item {
            Spacer(modifier = Modifier.height(24.dp))
            TheAritziaEditSection(
                products = products.filter { it.isBestSeller }.take(4),
                onProductClick = { viewModel.openProductDetail(it.id) }
            )
        }

        // 5. SHOP THE LOOK (EDITORIAL LOOKBOOK)
        item {
            Spacer(modifier = Modifier.height(28.dp))
            ShopTheLookSection(
                onExploreStyle = { viewModel.navigateTo(Screen.Style) }
            )
        }

        // 6. EVERYDAY ESSENTIALS
        item {
            Spacer(modifier = Modifier.height(24.dp))
            EditorialSectionHeader(
                title = "EVERYDAY ESSENTIALS",
                subtitle = "Tailored suiting, Sculpt Knit™, and fine wools",
                onSeeAll = { viewModel.navigateTo(Screen.Shop) }
            )
            val essentials = products.take(6)
            HorizontalProductList(
                products = essentials,
                onProductClick = { viewModel.openProductDetail(it.id) },
                onWishlistToggle = { viewModel.toggleWishlist(it.id) },
                isWishlisted = { id -> viewModel.isWishlisted(id) }
            )
        }

        // 7. RECENTLY VIEWED (if any)
        if (recentlyViewed.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(24.dp))
                EditorialSectionHeader(
                    title = "RECENTLY VIEWED",
                    subtitle = "Continue exploring your wishlist and saved silhouettes",
                    onSeeAll = {}
                )
                HorizontalProductList(
                    products = recentlyViewed,
                    onProductClick = { viewModel.openProductDetail(it.id) },
                    onWishlistToggle = { viewModel.toggleWishlist(it.id) },
                    isWishlisted = { id -> viewModel.isWishlisted(id) }
                )
            }
        }
    }
}

@Composable
fun HeroEditorialBanner(onShopCampaign: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(440.dp)
            .clickable { onShopCampaign() }
    ) {
        Image(
            painter = painterResource(id = R.drawable.img_hero_editorial_1793095261972),
            contentDescription = "Aritzia Editorial Campaign",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.3f),
                            Color.Black.copy(alpha = 0.85f)
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(24.dp)
        ) {
            Surface(
                color = AritziaIvory.copy(alpha = 0.9f),
                shape = RoundedCornerShape(2.dp)
            ) {
                Text(
                    text = "CAMPAIGN • FALL/WINTER '26",
                    style = MaterialTheme.typography.labelSmall.copy(
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    color = AritziaBlack
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Architectural Wool &\nCity Crepe Suiting",
                style = MaterialTheme.typography.displayMedium.copy(
                    color = Color.White,
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Light,
                    lineHeight = 36.sp
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Discover high-precision tailoring engineered for modern everyday luxury.",
                style = MaterialTheme.typography.bodyMedium.copy(color = Color.White.copy(alpha = 0.9f))
            )

            Spacer(modifier = Modifier.height(16.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "EXPLORE THE CAMPAIGN",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = Color.White,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun ExclusiveLaunchesSection(
    launches: List<CollectionLaunch>,
    onToggleReminder: (String) -> Unit,
    onShopLaunch: () -> Unit
) {
    if (launches.isEmpty()) return

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 20.dp)
            .background(AritziaStone.copy(alpha = 0.3f))
            .padding(vertical = 16.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "EXCLUSIVE LAUNCHES",
                    style = MaterialTheme.typography.labelSmall.copy(
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = AritziaGold
                )
                Text(
                    text = "Upcoming Collections & Drops",
                    style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        LazyRow(
            contentPadding = PaddingValues(horizontal = 20.dp),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            items(launches, key = { it.id }) { launch ->
                Card(
                    modifier = Modifier
                        .width(300.dp)
                        .clickable { onShopLaunch() },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Column {
                        Box(modifier = Modifier.height(140.dp)) {
                            AsyncImage(
                                model = launch.bannerUrl,
                                contentDescription = launch.title,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                            Surface(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp),
                                color = AritziaBlack.copy(alpha = 0.8f),
                                shape = RoundedCornerShape(2.dp)
                            ) {
                                Text(
                                    text = launch.status,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = launch.title,
                                style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Serif)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = launch.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = AritziaMutedGray,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Button(
                                    onClick = { onShopLaunch() },
                                    colors = ButtonDefaults.buttonColors(containerColor = AritziaBlack),
                                    shape = RoundedCornerShape(2.dp),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Text("EXPLORE DROP", style = MaterialTheme.typography.labelSmall)
                                }

                                IconButton(onClick = { onToggleReminder(launch.id) }) {
                                    Icon(
                                        imageVector = if (launch.isReminded) Icons.Default.NotificationsActive else Icons.Default.Notifications,
                                        contentDescription = "Remind Me",
                                        tint = if (launch.isReminded) AritziaGold else AritziaMutedGray
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditorialSectionHeader(
    title: String,
    subtitle: String,
    onSeeAll: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom
    ) {
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.headlineMedium.copy(
                    fontFamily = FontFamily.Serif,
                    fontWeight = FontWeight.Normal,
                    letterSpacing = 1.sp
                )
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = AritziaMutedGray
            )
        }
        Text(
            text = "VIEW ALL",
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.5.sp
            ),
            modifier = Modifier.clickable { onSeeAll() },
            color = AritziaBlack
        )
    }
}

@Composable
fun HorizontalProductList(
    products: List<Product>,
    onProductClick: (Product) -> Unit,
    onWishlistToggle: (Product) -> Unit,
    isWishlisted: (String) -> Boolean
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        items(products, key = { it.id }) { product ->
            ProductCardItem(
                product = product,
                onClick = { onProductClick(product) },
                onWishlistToggle = { onWishlistToggle(product) },
                isWishlisted = isWishlisted(product.id)
            )
        }
    }
}

@Composable
fun ProductCardItem(
    product: Product,
    onClick: () -> Unit,
    onWishlistToggle: () -> Unit,
    isWishlisted: Boolean
) {
    Column(
        modifier = Modifier
            .width(170.dp)
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(AritziaStone)
        ) {
            AsyncImage(
                model = product.imageUrl,
                contentDescription = product.name,
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            IconButton(
                onClick = onWishlistToggle,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp)
                    .size(32.dp)
                    .background(Color.White.copy(alpha = 0.85f), CircleShape)
            ) {
                Icon(
                    imageVector = if (isWishlisted) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Save to Wishlist",
                    tint = if (isWishlisted) Color.Red else AritziaBlack,
                    modifier = Modifier.size(16.dp)
                )
            }

            if (product.isBestSeller) {
                Surface(
                    modifier = Modifier
                        .align(Alignment.TopStart)
                        .padding(8.dp),
                    color = AritziaBlack,
                    shape = RoundedCornerShape(2.dp)
                ) {
                    Text(
                        text = "ICONIC",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp),
                        color = Color.White,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = product.brand.uppercase(),
            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
            color = AritziaMutedGray
        )
        Text(
            text = product.name,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(2.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "$${String.format("%.2f", product.price)}",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
            )
            if (product.salePrice != null) {
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "$${String.format("%.2f", product.salePrice)}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = Color.Red,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }
    }
}

@Composable
fun TheAritziaEditSection(
    products: List<Product>,
    onProductClick: (Product) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
    ) {
        Text(
            text = "THE ARITZIA EDIT",
            style = MaterialTheme.typography.headlineLarge.copy(
                fontFamily = FontFamily.Serif,
                letterSpacing = 2.sp
            )
        )
        Text(
            text = "Curated wardrobe pillars designed to last a lifetime.",
            style = MaterialTheme.typography.bodyMedium,
            color = AritziaMutedGray
        )
        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .clickable {
                    if (products.isNotEmpty()) onProductClick(products.first())
                },
            shape = RoundedCornerShape(4.dp)
        ) {
            Box(modifier = Modifier.fillMaxSize()) {
                Image(
                    painter = painterResource(id = R.drawable.img_super_puff_campaign_1793095279211),
                    contentDescription = "The Super Puff Edit",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                            )
                        )
                )

                Column(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(20.dp)
                ) {
                    Text(
                        text = "THE SUPER PUFF™",
                        style = MaterialTheme.typography.displaySmall.copy(
                            color = Color.White,
                            fontFamily = FontFamily.Serif
                        )
                    )
                    Text(
                        text = "700+ Fill Power Responsibly Sourced Goose Down",
                        style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.85f))
                    )
                }
            }
        }
    }
}

@Composable
fun ShopTheLookSection(onExploreStyle: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(AritziaIvory)
            .padding(20.dp)
    ) {
        Text(
            text = "ARITZIA STYLE STUDIO",
            style = MaterialTheme.typography.labelSmall.copy(
                letterSpacing = 2.sp,
                fontWeight = FontWeight.Bold
            ),
            color = AritziaGold
        )
        Text(
            text = "Personal Styling & Outfit Builder",
            style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif)
        )
        Spacer(modifier = Modifier.height(12.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(200.dp)
                .clip(RoundedCornerShape(4.dp))
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_style_lookbook_1793095292903),
                contentDescription = "Style Lookbook",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = onExploreStyle,
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("open_style_studio_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = AritziaBlack,
                contentColor = Color.White
            ),
            shape = RoundedCornerShape(2.dp)
        ) {
            Text(
                text = "OPEN STYLE STUDIO",
                style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp)
            )
        }
    }
}
