package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.outlined.Checkroom
import androidx.compose.material.icons.outlined.CompassCalibration
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.ShoppingBag
import androidx.compose.material.icons.outlined.Style
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.CartItem
import com.example.ui.theme.AritziaBlack
import com.example.ui.theme.AritziaBorderGray
import com.example.ui.theme.AritziaGold
import com.example.ui.theme.AritziaIvory
import com.example.ui.theme.AritziaMutedGray
import com.example.ui.viewmodel.Screen

@Composable
fun AritziaTopBar(
    currentScreen: Screen,
    cartCount: Int,
    onOpenBag: () -> Unit,
    onOpenStores: () -> Unit,
    onOpenFitProfile: () -> Unit,
    onNavigateHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp
    ) {
        Column {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Left action icon: Boutique Store Locator
                IconButton(
                    onClick = onOpenStores,
                    modifier = Modifier.testTag("store_locator_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Find Boutique Stores",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Brand Title Header
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { onNavigateHome() }
                ) {
                    Text(
                        text = "ARITZIA",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 4.sp,
                            fontSize = 20.sp
                        ),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "EVERYDAY LUXURY",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 2.sp,
                            fontSize = 9.sp
                        ),
                        color = AritziaMutedGray
                    )
                }

                // Right actions: Fit Profile & Shopping Bag
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onOpenFitProfile,
                        modifier = Modifier.testTag("fit_profile_button")
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.CompassCalibration,
                            contentDescription = "Fit Profile Studio",
                            tint = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    IconButton(
                        onClick = onOpenBag,
                        modifier = Modifier.testTag("cart_bag_button")
                    ) {
                        BadgedBox(
                            badge = {
                                if (cartCount > 0) {
                                    Badge(
                                        containerColor = AritziaBlack,
                                        contentColor = Color.White
                                    ) {
                                        Text(text = cartCount.toString())
                                    }
                                }
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ShoppingBag,
                                contentDescription = "Shopping Bag",
                                tint = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
            Divider(color = AritziaBorderGray, thickness = 0.5.dp)
        }
    }
}

@Composable
fun AritziaBottomBar(
    currentScreen: Screen,
    onScreenSelected: (Screen) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp
    ) {
        NavigationBarItem(
            selected = currentScreen is Screen.Discover,
            onClick = { onScreenSelected(Screen.Discover) },
            icon = { Icon(Icons.Outlined.Explore, contentDescription = "Discover") },
            label = { Text("Discover", style = MaterialTheme.typography.labelMedium) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AritziaBlack,
                selectedTextColor = AritziaBlack,
                indicatorColor = AritziaIvory
            ),
            modifier = Modifier.testTag("nav_discover")
        )

        NavigationBarItem(
            selected = currentScreen is Screen.Shop,
            onClick = { onScreenSelected(Screen.Shop) },
            icon = { Icon(Icons.Outlined.ShoppingBag, contentDescription = "Shop") },
            label = { Text("Shop", style = MaterialTheme.typography.labelMedium) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AritziaBlack,
                selectedTextColor = AritziaBlack,
                indicatorColor = AritziaIvory
            ),
            modifier = Modifier.testTag("nav_shop")
        )

        NavigationBarItem(
            selected = currentScreen is Screen.Style,
            onClick = { onScreenSelected(Screen.Style) },
            icon = { Icon(Icons.Outlined.Style, contentDescription = "Style") },
            label = { Text("Style", style = MaterialTheme.typography.labelMedium) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AritziaBlack,
                selectedTextColor = AritziaBlack,
                indicatorColor = AritziaIvory
            ),
            modifier = Modifier.testTag("nav_style")
        )

        NavigationBarItem(
            selected = currentScreen is Screen.Closet,
            onClick = { onScreenSelected(Screen.Closet) },
            icon = { Icon(Icons.Outlined.Checkroom, contentDescription = "Closet") },
            label = { Text("Closet", style = MaterialTheme.typography.labelMedium) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AritziaBlack,
                selectedTextColor = AritziaBlack,
                indicatorColor = AritziaIvory
            ),
            modifier = Modifier.testTag("nav_closet")
        )

        NavigationBarItem(
            selected = currentScreen is Screen.Account,
            onClick = { onScreenSelected(Screen.Account) },
            icon = { Icon(Icons.Outlined.Person, contentDescription = "Account") },
            label = { Text("Account", style = MaterialTheme.typography.labelMedium) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = AritziaBlack,
                selectedTextColor = AritziaBlack,
                indicatorColor = AritziaIvory
            ),
            modifier = Modifier.testTag("nav_account")
        )
    }
}

@Composable
fun ShoppingBagDrawer(
    isOpen: Boolean,
    cartItems: List<CartItem>,
    subtotal: Double,
    onClose: () -> Unit,
    onUpdateQty: (String, Int) -> Unit,
    onRemoveItem: (String) -> Unit,
    onCheckout: () -> Unit
) {
    AnimatedVisibility(
        visible = isOpen,
        enter = fadeIn(),
        exit = fadeOut()
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.5f))
                .clickable { onClose() }
        ) {
            Surface(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(0.9f)
                    .align(Alignment.CenterEnd)
                    .clickable(enabled = false) {},
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    // Drawer Header
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "SHOPPING BAG (${cartItems.sumOf { it.quantity }})",
                            style = MaterialTheme.typography.headlineMedium.copy(
                                fontFamily = FontFamily.Serif,
                                letterSpacing = 1.sp
                            )
                        )
                        IconButton(onClick = onClose) {
                            Icon(Icons.Default.Close, contentDescription = "Close Bag")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = AritziaBorderGray)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Free Shipping Progress
                    val freeShippingThreshold = 150.0
                    val progress = (subtotal / freeShippingThreshold).coerceAtMost(1.0).toFloat()
                    val amountRemaining = (freeShippingThreshold - subtotal).coerceAtLeast(0.0)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(AritziaIvory, RoundedCornerShape(8.dp))
                            .padding(12.dp)
                    ) {
                        Column {
                            Text(
                                text = if (amountRemaining == 0.0) "You unlocked FREE Express Delivery!"
                                else "Add $${String.format("%.2f", amountRemaining)} more for FREE Express Delivery",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                color = AritziaBlack
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = progress,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(4.dp)
                                    .clip(RoundedCornerShape(2.dp)),
                                color = AritziaBlack,
                                trackColor = AritziaBorderGray
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (cartItems.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Outlined.ShoppingBag,
                                    contentDescription = null,
                                    modifier = Modifier.size(64.dp),
                                    tint = AritziaMutedGray
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Your bag is currently empty.",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = AritziaMutedGray
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            items(cartItems, key = { it.id }) { item ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    AsyncImage(
                                        model = item.imageUrl,
                                        contentDescription = item.productName,
                                        modifier = Modifier
                                            .size(80.dp)
                                            .clip(RoundedCornerShape(6.dp)),
                                        contentScale = ContentScale.Crop
                                    )

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.brand.uppercase(),
                                            style = MaterialTheme.typography.labelSmall,
                                            color = AritziaMutedGray
                                        )
                                        Text(
                                            text = item.productName,
                                            style = MaterialTheme.typography.titleSmall,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${item.colorName} • Size ${item.size}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = AritziaMutedGray
                                        )
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "$${String.format("%.2f", item.price)}",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))

                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Row(
                                                modifier = Modifier
                                                    .border(0.5.dp, AritziaBorderGray, RoundedCornerShape(4.dp)),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                IconButton(
                                                    onClick = { onUpdateQty(item.id, item.quantity - 1) },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(14.dp))
                                                }
                                                Text(
                                                    text = item.quantity.toString(),
                                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                                    modifier = Modifier.padding(horizontal = 8.dp)
                                                )
                                                IconButton(
                                                    onClick = { onUpdateQty(item.id, item.quantity + 1) },
                                                    modifier = Modifier.size(28.dp)
                                                ) {
                                                    Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(14.dp))
                                                }
                                            }

                                            IconButton(
                                                onClick = { onRemoveItem(item.id) },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Default.DeleteOutline,
                                                    contentDescription = "Remove",
                                                    tint = Color.Red.copy(alpha = 0.7f),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                                Divider(color = AritziaBorderGray, thickness = 0.5.dp, modifier = Modifier.padding(top = 16.dp))
                            }
                        }
                    }

                    // Bottom Order Total Summary & Checkout Button
                    if (cartItems.isNotEmpty()) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp)
                        ) {
                            Divider(color = AritziaBorderGray)
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "Estimated Subtotal",
                                    style = MaterialTheme.typography.bodyLarge
                                )
                                Text(
                                    text = "$${String.format("%.2f", subtotal)} CAD",
                                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Text(
                                text = "Taxes & shipping calculated at checkout",
                                style = MaterialTheme.typography.bodySmall,
                                color = AritziaMutedGray
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = {
                                    onClose()
                                    onCheckout()
                                },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(52.dp)
                                    .testTag("checkout_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = AritziaBlack,
                                    contentColor = Color.White
                                ),
                                shape = RoundedCornerShape(2.dp)
                            ) {
                                Text(
                                    text = "PROCEED TO CHECKOUT",
                                    style = MaterialTheme.typography.labelLarge.copy(
                                        letterSpacing = 2.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
