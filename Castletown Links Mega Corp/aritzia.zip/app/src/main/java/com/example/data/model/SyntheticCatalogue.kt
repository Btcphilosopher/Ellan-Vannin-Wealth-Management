package com.example.data.model

import com.example.data.local.CartItemEntity
import com.example.data.local.ClosetItemEntity
import com.example.data.local.OrderEntity

object SyntheticCatalogue {

    val categories = listOf(
        Category("clothing", "All Clothing", 150, listOf("Coats & Jackets", "Sweaters", "Trousers", "Tops", "Dresses", "Activewear", "Lounge", "Accessories")),
        Category("coats", "Coats & Jackets", 24, listOf("Puffers", "Wool Coats", "Blazers", "Trench Coats", "Parkas")),
        Category("sweaters", "Sweaters & Knitwear", 28, listOf("Cardigans", "Crewnecks", "Turtlenecks", "Vest Knits", "Cashmere")),
        Category("trousers", "Trousers & Pants", 26, listOf("Tailored Pants", "Wide-Leg", "Cargo", "Pleated", "Leather Pants")),
        Category("tops", "Tops & Shirts", 22, listOf("Sculpt Knit", "Blouses", "Button-Downs", "Camis", "Bodysuits")),
        Category("tshirts", "T-Shirts & Shirts", 18, listOf("Graphic Tees", "Ribbed Tees", "Long Sleeves", "Oversized Tees")),
        Category("jeans", "Jeans & Denim", 16, listOf("High-Rise Wide", "Straight Leg", "Relaxed Fit", "Denim Jackets")),
        Category("dresses", "Dresses & Jumpsuits", 18, listOf("Midi Dresses", "Mini Dresses", "Slip Dresses", "Jumpsuits")),
        Category("activewear", "Activewear & TNA", 14, listOf("Divinity Jumpsuit", "Leggings", "Sports Bras", "Bike Shorts")),
        Category("lounge", "Lounge & Sweatshirts", 12, listOf("Cozy Fleece", "Sweatpants", "Hoodies", "Robes")),
        Category("accessories", "Accessories & Bags", 10, listOf("Handbags", "Scarves", "Beanies", "Belts", "Jewellery"))
    )

    val colors = listOf(
        ProductColor("Black", "#111111"),
        ProductColor("Birch / Off-White", "#F4F0E8"),
        ProductColor("Heather Cloud", "#DCD6CD"),
        ProductColor("Cognac", "#7A4E3A"),
        ProductColor("Rich Mocha", "#3D2B24"),
        ProductColor("Espace Grey", "#A6A6A6"),
        ProductColor("Matte Black", "#1E1E1E"),
        ProductColor("Olive Leaf", "#4E5340"),
        ProductColor("Modern Plum", "#4A2E3D"),
        ProductColor("Midnight Navy", "#1A2436")
    )

    private val sampleImageUrls = listOf(
        "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1550614000-4895a10e1bfd?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1485230895905-ec40ba36b9bc?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1529139574466-a303027c1d8b?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=800&q=80"
    )

    val products: List<Product> by lazy {
        val list = mutableListOf<Product>()
        
        // Iconic flagship products
        list.add(
            Product(
                id = "p-101",
                name = "The Super Puff™ Shorty",
                brand = "TNA",
                category = "Coats & Jackets",
                price = 250.0,
                rating = 4.9f,
                reviewCount = 840,
                isBestSeller = true,
                isNewArrival = true,
                fabricComposition = "100% Recycled Nylon outer shell with 700+ fill power 100% responsibly sourced goose down insulation.",
                fitDescription = "Engineered to deliver warmth down to -22°C / -8°F. Relaxed puffy silhouette with storm cuffs.",
                careInstructions = "Machine wash cold inside out with mild detergent. Tumble dry low with tennis balls.",
                imageUrl = "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=800&q=80",
                altImages = listOf(
                    "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80",
                    "https://images.unsplash.com/photo-1485230895905-ec40ba36b9bc?auto=format&fit=crop&w=800&q=80"
                ),
                colors = listOf(colors[0], colors[1], colors[3], colors[6], colors[7]),
                sizes = listOf("XXS", "XS", "S", "M", "L", "XL"),
                tags = listOf("Outerwear", "Goose Down", "Winter Warmth", "Iconic"),
                silhouette = "Oversized",
                season = "Fall/Winter '26"
            )
        )

        list.add(
            Product(
                id = "p-102",
                name = "The Effortless Pant™ Crepe",
                brand = "Wilfred",
                category = "Trousers",
                price = 148.0,
                rating = 4.95f,
                reviewCount = 1420,
                isBestSeller = true,
                fabricComposition = "City Crepe: 82% Triacetate, 18% Polyester. Japanese origin wrinkle-resistant suiting fabric.",
                fitDescription = "High-rise, wide-leg trouser featuring tailored front pleats and a relaxed drapey drape.",
                careInstructions = "Machine wash cold gentle cycle. Line dry or dry clean for crisp pleats.",
                imageUrl = "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80",
                altImages = listOf(
                    "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80"
                ),
                colors = listOf(colors[0], colors[1], colors[2], colors[4], colors[9]),
                sizes = listOf("00", "0", "2", "4", "6", "8", "10", "12", "14"),
                tags = listOf("Tailored", "Workwear", "Japanese Fabric", "Iconic"),
                silhouette = "Wide-Leg",
                season = "Core Essentials"
            )
        )

        list.add(
            Product(
                id = "p-103",
                name = "The Peggy Sweater™ Cashmere",
                brand = "Babaton",
                category = "Sweaters",
                price = 198.0,
                rating = 4.88f,
                reviewCount = 430,
                isBestSeller = true,
                isNewArrival = true,
                fabricComposition = "100% Grade-A Mongolian Cashmere. Ultra-soft 2-ply rib knit.",
                fitDescription = "Relaxed crewneck silhouette with dropped shoulders and thick ribbed hem details.",
                careInstructions = "Hand wash cold with wool shampoo or dry clean. Lay flat to dry.",
                imageUrl = "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=800&q=80",
                colors = listOf(colors[1], colors[2], colors[3], colors[0]),
                sizes = listOf("2XS", "XS", "S", "M", "L"),
                tags = listOf("Cashmere", "Knitwear", "Luxe", "Cozy"),
                silhouette = "Relaxed",
                season = "Fall/Winter '26"
            )
        )

        list.add(
            Product(
                id = "p-104",
                name = "Sculpt Knit Squareneck Tank",
                brand = "Babaton",
                category = "Tops",
                price = 68.0,
                rating = 4.9f,
                reviewCount = 980,
                isBestSeller = true,
                fabricComposition = "Sculpt Knit yarn: 81% Viscose, 17% Nylon, 2% Elastane. Holds-you-in smoothing knit.",
                fitDescription = "Fitted contoured top with structured architectural square neckline.",
                careInstructions = "Machine wash cold inside wash bag. Lay flat to dry.",
                imageUrl = "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80",
                colors = listOf(colors[0], colors[1], colors[5], colors[8]),
                sizes = listOf("XXS", "XS", "S", "M", "L", "XL"),
                tags = listOf("Sculpt Knit", "Essential", "Layering"),
                silhouette = "Fitted",
                season = "Core Essentials"
            )
        )

        list.add(
            Product(
                id = "p-105",
                name = "The Slouch Coat™ Wool",
                brand = "Wilfred",
                category = "Coats & Jackets",
                price = 398.0,
                salePrice = 348.0,
                rating = 4.92f,
                reviewCount = 610,
                isBestSeller = true,
                fabricComposition = "100% Virgin Wool sourced from top Italian mills. Cupro lining.",
                fitDescription = "Double-breasted oversized long coat with exaggerated peak lapels and deep welt pockets.",
                careInstructions = "Dry clean only.",
                imageUrl = "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80",
                colors = listOf(colors[3], colors[0], colors[1], colors[4]),
                sizes = listOf("1 (XS-S)", "2 (M-L)", "3 (XL-XXL)"),
                tags = listOf("Italian Wool", "Statement Coat", "Luxury Outerwear"),
                silhouette = "Oversized",
                season = "Fall/Winter '26"
            )
        )

        list.add(
            Product(
                id = "p-106",
                name = "The Melina Pant™ Vegan Leather",
                brand = "Wilfred",
                category = "Trousers",
                price = 148.0,
                rating = 4.87f,
                reviewCount = 1150,
                isBestSeller = true,
                fabricComposition = "Innovative Japanese Vegan Leather: 100% Polyurethane coating on 100% Polyester base.",
                fitDescription = "High-rise straight leg five-pocket design with soft buttery interior fleece lining.",
                careInstructions = "Wipe clean with moist cloth. Do not dry clean or iron.",
                imageUrl = "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80",
                colors = listOf(colors[0], colors[3], colors[4], colors[8]),
                sizes = listOf("00", "0", "2", "4", "6", "8", "10", "12"),
                tags = listOf("Vegan Leather", "Night Out", "Iconic"),
                silhouette = "Straight Leg",
                season = "Core Essentials"
            )
        )

        list.add(
            Product(
                id = "p-107",
                name = "The Divinity Jumpsuit™",
                brand = "TNA",
                category = "Activewear",
                price = 98.0,
                rating = 4.91f,
                reviewCount = 520,
                isBestSeller = true,
                fabricComposition = "ButterCheek™ fabric: 81% Nylon, 19% Elastane. Peach-fuzz soft performance stretch.",
                fitDescription = "Second-skin fitted scoop-neck unitard jumpsuit with flattering contour seams.",
                careInstructions = "Machine wash cold. Hang to dry.",
                imageUrl = "https://images.unsplash.com/photo-1518310383802-640c2de311b2?auto=format&fit=crop&w=800&q=80",
                colors = listOf(colors[0], colors[1], colors[7]),
                sizes = listOf("XXS", "XS", "S", "M", "L"),
                tags = listOf("Activewear", "Jumpsuit", "ButterSoft"),
                silhouette = "Fitted",
                season = "Core Essentials"
            )
        )

        list.add(
            Product(
                id = "p-108",
                name = "The Agency Blazer™",
                brand = "Babaton",
                category = "Coats & Jackets",
                price = 228.0,
                rating = 4.85f,
                reviewCount = 380,
                fabricComposition = "Hold Suiting: 68% Polyester, 28% Viscose, 4% Elastane.",
                fitDescription = "Structured single-breasted power blazer with padded shoulders and notched lapels.",
                careInstructions = "Dry clean only.",
                imageUrl = "https://images.unsplash.com/photo-1548624149-f1e1f7c180eb?auto=format&fit=crop&w=800&q=80",
                colors = listOf(colors[0], colors[1], colors[9]),
                sizes = listOf("0", "2", "4", "6", "8", "10", "12"),
                tags = listOf("Blazer", "Power Suiting", "Workwear"),
                silhouette = "Tailored",
                season = "Core Essentials"
            )
        )

        list.add(
            Product(
                id = "p-109",
                name = "The Contest Slip Dress",
                brand = "Ten by Babaton",
                category = "Dresses",
                price = 128.0,
                rating = 4.89f,
                reviewCount = 290,
                isExclusive = true,
                fabricComposition = "100% Japanese High-Lustre Liquid Satin.",
                fitDescription = "Bias-cut midi slip dress featuring adjustable dainty straps and low cowl back.",
                careInstructions = "Hand wash cold or dry clean.",
                imageUrl = "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=800&q=80",
                colors = listOf(colors[0], colors[1], colors[8]),
                sizes = listOf("XXS", "XS", "S", "M", "L"),
                tags = listOf("Evening", "Satin", "Occasionwear"),
                silhouette = "A-Line",
                season = "Spring/Summer '26"
            )
        )

        list.add(
            Product(
                id = "p-110",
                name = "The Farrah Silk Shirt",
                brand = "Wilfred",
                category = "Tops",
                price = 168.0,
                rating = 4.86f,
                reviewCount = 210,
                fabricComposition = "100% Pure Mulberry Silk Crepe de Chine.",
                fitDescription = "Classic button-down collar blouse with pearlescent buttons and French seams.",
                careInstructions = "Dry clean or gentle hand wash in silk detergent.",
                imageUrl = "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80",
                colors = listOf(colors[1], colors[0], colors[2]),
                sizes = listOf("XS", "S", "M", "L"),
                tags = listOf("Pure Silk", "Luxury Top", "Workwear"),
                silhouette = "Regular",
                season = "Core Essentials"
            )
        )

        // Generate additional catalogue products up to 150 items synthetically
        val brands = listOf("Wilfred", "Babaton", "TNA", "Sunday Best", "Ten by Babaton", "Denim Forum")
        val categoryList = listOf(
            "Coats & Jackets", "Sweaters", "Trousers", "Tops", "T-Shirts & Shirts",
            "Jeans", "Dresses", "Activewear", "Lounge", "Accessories"
        )
        val adjectives = listOf("Minimal", "Structured", "Architectural", "Cozy", "Essential", "Modern", "Relaxed", "Contour", "Luxe", "Silk Touch", "Merino")
        val garmentTypes = listOf("Cardigan", "Vest", "Wide Pant", "Rib Tank", "Midi Skirt", "Denim Jacket", "Crew Knit", "Wrap Dress", "Cropped Tee", "Leather Tote", "Wool Scarf")
        val silhouettes = listOf("Tailored", "Oversized", "Fitted", "Relaxed", "A-Line")

        for (i in 111..255) {
            val brand = brands[(i % brands.size)]
            val cat = categoryList[(i % categoryList.size)]
            val adj = adjectives[(i % adjectives.size)]
            val type = garmentTypes[(i % garmentTypes.size)]
            val name = "The $adj $type"
            val price = 48.0 + (i % 25) * 12.0
            val img = sampleImageUrls[(i % sampleImageUrls.size)]
            val silhouette = silhouettes[(i % silhouettes.size)]
            val isNew = i % 4 == 0
            val isBest = i % 5 == 0

            list.add(
                Product(
                    id = "p-$i",
                    name = name,
                    brand = brand,
                    category = cat,
                    price = price,
                    rating = 4.7f + (i % 3) * 0.1f,
                    reviewCount = 45 + (i * 3) % 400,
                    isNewArrival = isNew,
                    isBestSeller = isBest,
                    fabricComposition = "Premium Aritzia blend: 75% Organic Cotton, 20% Recycled Viscose, 5% Elastane.",
                    fitDescription = "Tailored with precision. Designed for everyday luxury and effortless drape.",
                    careInstructions = "Machine wash cold gentle cycle. Lay flat to dry.",
                    imageUrl = img,
                    colors = listOf(colors[i % colors.size], colors[(i + 1) % colors.size]),
                    sizes = listOf("XXS", "XS", "S", "M", "L", "XL"),
                    tags = listOf(brand, cat, silhouette),
                    silhouette = silhouette,
                    season = if (i % 2 == 0) "Fall/Winter '26" else "Core Essentials"
                )
            )
        }
        list
    }

    val collectionLaunches = listOf(
        CollectionLaunch(
            id = "launch-01",
            name = "Super Puff™ Winter Drop '26",
            title = "THE SUPER PUFF™ WINTER DROP",
            description = "100% responsibly sourced 700+ fill power goose down. 60+ new high-gloss colors, ultra-matte finishes, and climate-engineered warmth down to -30°C.",
            launchTimestamp = System.currentTimeMillis() + 86400000L * 2, // 2 days in future
            region = "Global & Online",
            status = "UPCOMING",
            bannerUrl = "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=1200&q=80",
            productIds = listOf("p-101", "p-105"),
            isReminded = true
        ),
        CollectionLaunch(
            id = "launch-02",
            name = "Wilfred Atelier Spring '27 Preview",
            title = "WILFRED ATELIER SPRING '27",
            description = "Architectural pleating, Italian virgin wool suiting, and Japanese silk crepes inspired by mid-century Parisian couture.",
            launchTimestamp = System.currentTimeMillis() - 100000L,
            region = "Exclusive Boutiques",
            status = "AVAILABLE",
            bannerUrl = "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=1200&q=80",
            productIds = listOf("p-102", "p-106", "p-110")
        )
    )

    val stores = listOf(
        Store(
            id = "store-vanc",
            name = "Aritzia Flagship — Robson Street",
            city = "Vancouver, BC",
            address = "1100 Robson St",
            postalCode = "V6E 1B2",
            phone = "(604) 684-3430",
            hours = "Mon-Sat: 10:00 - 21:00 | Sun: 11:00 - 19:00",
            latitude = 49.2847,
            longitude = -123.1251,
            distanceKm = 1.2,
            hasInventory = true
        ),
        Store(
            id = "store-tor",
            name = "Aritzia — Toronto Eaton Centre",
            city = "Toronto, ON",
            address = "220 Yonge St, Suite 2-108",
            postalCode = "M5B 2H1",
            phone = "(416) 598-1111",
            hours = "Mon-Sat: 10:00 - 21:00 | Sun: 10:00 - 19:00",
            latitude = 43.6544,
            longitude = -79.3807,
            distanceKm = 4.8,
            hasInventory = true
        ),
        Store(
            id = "store-soho",
            name = "Aritzia Boutique — SoHo",
            city = "New York, NY",
            address = "524 Broadway",
            postalCode = "10012",
            phone = "(212) 965-9850",
            hours = "Mon-Sat: 11:00 - 20:00 | Sun: 11:00 - 19:00",
            latitude = 40.7233,
            longitude = -73.9984,
            distanceKm = 12.5,
            hasInventory = true
        ),
        Store(
            id = "store-la",
            name = "Aritzia — Westfield Century City",
            city = "Los Angeles, CA",
            address = "10250 Santa Monica Blvd",
            postalCode = "90067",
            phone = "(310) 553-1200",
            hours = "Mon-Sat: 10:00 - 21:00 | Sun: 11:00 - 19:00",
            latitude = 34.0588,
            longitude = -118.4178,
            distanceKm = 18.0,
            hasInventory = false
        )
    )

    val sampleOutfits = listOf(
        Outfit(
            id = "outfit-01",
            title = "The Tailored Evening Edit",
            description = "Crisp pleated Japanese crepe trousers paired with Mongolian cashmere and gold minimal accents.",
            occasion = "Evening & Cocktails",
            weather = "Cool Urban (12°C)",
            season = "Fall/Winter '26",
            colorPalette = "Monochrome & Cognac",
            items = listOf(
                OutfitItem("p-102", "The Effortless Pant™ Crepe", "Wilfred", "Black", "4", 148.0, "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80"),
                OutfitItem("p-103", "The Peggy Sweater™ Cashmere", "Babaton", "Birch / Off-White", "M", 198.0, "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=800&q=80"),
                OutfitItem("p-105", "The Slouch Coat™ Wool", "Wilfred", "Cognac", "2 (M-L)", 398.0, "https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=800&q=80")
            ),
            bannerUrl = "https://images.unsplash.com/photo-1496747611176-843222e1e57c?auto=format&fit=crop&w=1200&q=80",
            isSaved = true
        ),
        Outfit(
            id = "outfit-02",
            title = "Off-Duty Winter Luxe",
            description = "Iconic goose down outerwear styled over ButterCheek™ unitard jumpsuit for warmth without bulk.",
            occasion = "Weekend & Travel",
            weather = "Sub-Zero (-10°C)",
            season = "Winter '26",
            colorPalette = "Matte Black & Ivory",
            items = listOf(
                OutfitItem("p-101", "The Super Puff™ Shorty", "TNA", "Matte Black", "M", 250.0, "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=800&q=80"),
                OutfitItem("p-107", "The Divinity Jumpsuit™", "TNA", "Black", "S", 98.0, "https://images.unsplash.com/photo-1518310383802-640c2de311b2?auto=format&fit=crop&w=800&q=80")
            ),
            bannerUrl = "https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&w=1200&q=80",
            isSaved = true
        )
    )

    val initialCloset = listOf(
        ClosetItemEntity(
            id = "c-01",
            productId = "p-102",
            productName = "The Effortless Pant™ Crepe",
            brand = "Wilfred",
            variantId = "v-102-black-4",
            size = "4",
            color = "Black",
            purchaseDate = "14 Oct 2026",
            orderRef = "ARZ-8829104",
            imageUrl = "https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80",
            careInfo = "Machine wash cold gentle cycle inside out.",
            notes = "Favorite workwear trouser. Pairs with everything.",
            timesWorn = 12,
            rating = 5.0f
        ),
        ClosetItemEntity(
            id = "c-02",
            productId = "p-104",
            productName = "Sculpt Knit Squareneck Tank",
            brand = "Babaton",
            variantId = "v-104-birch-m",
            size = "M",
            color = "Birch / Off-White",
            purchaseDate = "02 Sep 2026",
            orderRef = "ARZ-7718290",
            imageUrl = "https://images.unsplash.com/photo-1503342217505-b0a15ec3261c?auto=format&fit=crop&w=800&q=80",
            careInfo = "Lay flat to dry. Do not tumble dry.",
            notes = "Super flattering neckline.",
            timesWorn = 8,
            rating = 5.0f
        )
    )

    val initialCart = listOf(
        CartItemEntity(
            id = "cart-1",
            productId = "p-103",
            productName = "The Peggy Sweater™ Cashmere",
            brand = "Babaton",
            colorName = "Birch / Off-White",
            size = "M",
            price = 198.0,
            quantity = 1,
            imageUrl = "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=800&q=80",
            inStock = true
        )
    )

    val initialOrders = listOf(
        OrderEntity(
            orderId = "order-9901",
            orderNumber = "ARZ-8829104",
            datePlaced = "14 Oct 2026",
            status = "DELIVERED",
            itemsJson = """[{"id":"cart-sub-1","productId":"p-102","productName":"The Effortless Pant™ Crepe","brand":"Wilfred","colorName":"Black","size":"4","price":148.0,"quantity":1,"imageUrl":"https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80","inStock":true}]""",
            subtotal = 148.0,
            tax = 17.76,
            shipping = 0.0,
            total = 165.76,
            shippingAddress = "1055 W Georgia St, Vancouver, BC V6E 3P3",
            trackingNumber = "1Z9999999999999999",
            carrier = "FedEx Express Priority",
            estimatedDelivery = "16 Oct 2026",
            returnEligible = true
        )
    )
}
