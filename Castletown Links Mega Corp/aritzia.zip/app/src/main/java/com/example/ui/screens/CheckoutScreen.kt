package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Order
import com.example.ui.theme.AritziaBlack
import com.example.ui.theme.AritziaBorderGray
import com.example.ui.theme.AritziaGold
import com.example.ui.theme.AritziaIvory
import com.example.ui.theme.AritziaMutedGray
import com.example.ui.theme.AritziaStone
import com.example.ui.viewmodel.AppViewModel
import com.example.ui.viewmodel.Screen

@Composable
fun CheckoutScreen(
    viewModel: AppViewModel,
    onBack: () -> Unit
) {
    val cartItems by viewModel.cartItems.collectAsState()
    val subtotal by viewModel.cartTotal.collectAsState()
    val userProfile by viewModel.userProfile.collectAsState()

    var shippingAddress by remember { mutableStateOf(userProfile.defaultAddress) }
    var selectedDeliveryMethod by remember { mutableStateOf("EXPRESS") } // EXPRESS, BOUTIQUE
    var selectedPaymentMethod by remember { mutableStateOf("GOOGLE_PAY") } // GOOGLE_PAY, CREDIT_CARD, KLARNA
    var completedOrder by remember { mutableStateOf<Order?>(null) }
    var isPlacingOrder by remember { mutableStateOf(false) }

    val shippingCost = if (subtotal > 150.0 || selectedDeliveryMethod == "BOUTIQUE") 0.0 else 15.0
    val tax = subtotal * 0.12
    val grandTotal = subtotal + tax + shippingCost

    if (completedOrder != null) {
        OrderConfirmationView(
            order = completedOrder!!,
            onDone = {
                viewModel.navigateTo(Screen.Account)
            }
        )
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Checkout Top Bar
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 2.dp
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                    Text(
                        text = "SECURE CHECKOUT",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontFamily = FontFamily.Serif,
                            letterSpacing = 2.sp
                        ),
                        modifier = Modifier.weight(1f)
                    )
                    Icon(Icons.Default.Lock, contentDescription = null, tint = AritziaGold)
                }
            }

            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // 1. DELIVERY ADDRESS
                item {
                    Text("1. DELIVERY ADDRESS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp))
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = shippingAddress,
                        onValueChange = { shippingAddress = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("shipping_address_input"),
                        label = { Text("Shipping Address") },
                        singleLine = false
                    )
                }

                // 2. DELIVERY METHOD
                item {
                    Text("2. DELIVERY METHOD", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp))
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedDeliveryMethod = "EXPRESS" },
                            shape = RoundedCornerShape(4.dp),
                            color = if (selectedDeliveryMethod == "EXPRESS") AritziaIvory else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selectedDeliveryMethod == "EXPRESS") AritziaBlack else AritziaBorderGray)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedDeliveryMethod == "EXPRESS",
                                    onClick = { selectedDeliveryMethod = "EXPRESS" },
                                    colors = RadioButtonDefaults.colors(selectedColor = AritziaBlack)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Express Priority Delivery (2-3 Business Days)", style = MaterialTheme.typography.titleSmall)
                                    Text("Free on orders over $150 CAD", style = MaterialTheme.typography.bodySmall, color = AritziaMutedGray)
                                }
                                Text(if (subtotal > 150.0) "FREE" else "$15.00", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedDeliveryMethod = "BOUTIQUE" },
                            shape = RoundedCornerShape(4.dp),
                            color = if (selectedDeliveryMethod == "BOUTIQUE") AritziaIvory else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selectedDeliveryMethod == "BOUTIQUE") AritziaBlack else AritziaBorderGray)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedDeliveryMethod == "BOUTIQUE",
                                    onClick = { selectedDeliveryMethod = "BOUTIQUE" },
                                    colors = RadioButtonDefaults.colors(selectedColor = AritziaBlack)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Boutique Click & Collect (Vancouver Robson St)", style = MaterialTheme.typography.titleSmall)
                                    Text("Ready for pickup within 2 hours", style = MaterialTheme.typography.bodySmall, color = AritziaMutedGray)
                                }
                                Text("FREE", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            }
                        }
                    }
                }

                // 3. PAYMENT METHOD
                item {
                    Text("3. PAYMENT METHOD", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp))
                    Spacer(modifier = Modifier.height(8.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedPaymentMethod = "GOOGLE_PAY" },
                            shape = RoundedCornerShape(4.dp),
                            color = if (selectedPaymentMethod == "GOOGLE_PAY") AritziaIvory else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selectedPaymentMethod == "GOOGLE_PAY") AritziaBlack else AritziaBorderGray)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedPaymentMethod == "GOOGLE_PAY",
                                    onClick = { selectedPaymentMethod = "GOOGLE_PAY" },
                                    colors = RadioButtonDefaults.colors(selectedColor = AritziaBlack)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Google Pay", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedPaymentMethod = "CREDIT_CARD" },
                            shape = RoundedCornerShape(4.dp),
                            color = if (selectedPaymentMethod == "CREDIT_CARD") AritziaIvory else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selectedPaymentMethod == "CREDIT_CARD") AritziaBlack else AritziaBorderGray)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedPaymentMethod == "CREDIT_CARD",
                                    onClick = { selectedPaymentMethod = "CREDIT_CARD" },
                                    colors = RadioButtonDefaults.colors(selectedColor = AritziaBlack)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Credit / Debit Card (Visa, Mastercard, Amex)", style = MaterialTheme.typography.titleSmall)
                            }
                        }

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedPaymentMethod = "KLARNA" },
                            shape = RoundedCornerShape(4.dp),
                            color = if (selectedPaymentMethod == "KLARNA") AritziaIvory else MaterialTheme.colorScheme.surface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (selectedPaymentMethod == "KLARNA") AritziaBlack else AritziaBorderGray)
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = selectedPaymentMethod == "KLARNA",
                                    onClick = { selectedPaymentMethod = "KLARNA" },
                                    colors = RadioButtonDefaults.colors(selectedColor = AritziaBlack)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Klarna — 4 Interest-Free Payments", style = MaterialTheme.typography.titleSmall)
                            }
                        }
                    }
                }

                // 4. ORDER SUMMARY
                item {
                    Text("4. ORDER SUMMARY", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.sp))
                    Spacer(modifier = Modifier.height(8.dp))

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = AritziaIvory)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Subtotal", style = MaterialTheme.typography.bodyMedium)
                                Text("$${String.format("%.2f", subtotal)} CAD", style = MaterialTheme.typography.bodyMedium)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Estimated Tax (12%)", style = MaterialTheme.typography.bodyMedium)
                                Text("$${String.format("%.2f", tax)} CAD", style = MaterialTheme.typography.bodyMedium)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Delivery", style = MaterialTheme.typography.bodyMedium)
                                Text(if (shippingCost == 0.0) "FREE" else "$${String.format("%.2f", shippingCost)} CAD", style = MaterialTheme.typography.bodyMedium)
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            Divider(color = AritziaBorderGray)
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Total", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                                Text("$${String.format("%.2f", grandTotal)} CAD", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                            }
                        }
                    }
                }
            }

            // PLACE ORDER BUTTON
            Surface(
                modifier = Modifier.fillMaxWidth(),
                tonalElevation = 8.dp
            ) {
                Box(modifier = Modifier.padding(16.dp)) {
                    Button(
                        onClick = {
                            isPlacingOrder = true
                            viewModel.placeOrder(
                                shippingAddress = shippingAddress,
                                paymentMethod = selectedPaymentMethod,
                                onSuccess = { newOrder ->
                                    isPlacingOrder = false
                                    completedOrder = newOrder
                                }
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("place_order_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = AritziaBlack),
                        enabled = !isPlacingOrder
                    ) {
                        Text(
                            text = if (isPlacingOrder) "AUTHORIZING..." else "AUTHORIZE & PLACE ORDER — $${String.format("%.2f", grandTotal)} CAD",
                            style = MaterialTheme.typography.labelLarge.copy(letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun OrderConfirmationView(
    order: Order,
    onDone: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = AritziaGold,
                modifier = Modifier.size(72.dp)
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "THANK YOU FOR YOUR ORDER",
                style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 2.sp, fontWeight = FontWeight.Bold),
                color = AritziaGold
            )
            Text(
                text = "Order #${order.orderNumber}",
                style = MaterialTheme.typography.displaySmall.copy(fontFamily = FontFamily.Serif)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "A confirmation email and digital receipt have been dispatched.",
                style = MaterialTheme.typography.bodyMedium,
                color = AritziaMutedGray
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = AritziaIvory)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Carrier: ${order.carrier}", style = MaterialTheme.typography.bodySmall)
                    Text("Tracking Number: ${order.trackingNumber}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    Text("Estimated Delivery: ${order.estimatedDelivery}", style = MaterialTheme.typography.bodySmall, color = AritziaMutedGray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Garments automatically added to your Digital Closet!", style = MaterialTheme.typography.labelSmall.copy(color = AritziaBlack))
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = onDone,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AritziaBlack)
            ) {
                Text("VIEW ORDER & DIGITAL CLOSET", style = MaterialTheme.typography.labelLarge)
            }
        }
    }
}
