package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "cart_items")
data class CartItemEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val productName: String,
    val brand: String,
    val colorName: String,
    val size: String,
    val price: Double,
    val quantity: Int,
    val imageUrl: String,
    val inStock: Boolean
)

@Entity(tableName = "wishlist_items")
data class WishlistItemEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val addedDate: String
)

@Entity(tableName = "closet_items")
data class ClosetItemEntity(
    @PrimaryKey val id: String,
    val productId: String,
    val productName: String,
    val brand: String,
    val variantId: String,
    val size: String,
    val color: String,
    val purchaseDate: String,
    val orderRef: String,
    val imageUrl: String,
    val careInfo: String,
    val notes: String,
    val timesWorn: Int,
    val rating: Float
)

@Entity(tableName = "saved_outfits")
data class SavedOutfitEntity(
    @PrimaryKey val id: String,
    val title: String,
    val description: String,
    val occasion: String,
    val weather: String,
    val season: String,
    val colorPalette: String,
    val bannerUrl: String,
    val itemsJson: String, // Serialized list of OutfitItem
    val isSaved: Boolean
)

@Entity(tableName = "orders")
data class OrderEntity(
    @PrimaryKey val orderId: String,
    val orderNumber: String,
    val datePlaced: String,
    val status: String,
    val itemsJson: String, // Serialized list of CartItem
    val subtotal: Double,
    val tax: Double,
    val shipping: Double,
    val total: Double,
    val shippingAddress: String,
    val trackingNumber: String,
    val carrier: String,
    val estimatedDelivery: String,
    val returnEligible: Boolean
)

@Entity(tableName = "fit_profile")
data class FitProfileEntity(
    @PrimaryKey val id: Int = 1,
    val usualSize: String,
    val preferredFit: String,
    val bustInches: Float,
    val waistInches: Float,
    val hipInches: Float,
    val preferredLength: String,
    val fitConfidence: Int
)
