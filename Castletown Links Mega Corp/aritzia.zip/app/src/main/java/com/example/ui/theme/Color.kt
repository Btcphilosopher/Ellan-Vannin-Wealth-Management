package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AritziaBlack = Color(0xFF111111)
val AritziaWhite = Color(0xFFFFFFFF)
val AritziaIvory = Color(0xFFF7F5F0)
val AritziaOffWhite = Color(0xFFFAF9F6)
val AritziaCharcoal = Color(0xFF2C2C2C)
val AritziaStone = Color(0xFFEAE6E1)
val AritziaLightStone = Color(0xFFF3EFEA)
val AritziaMutedGray = Color(0xFF757575)
val AritziaBorderGray = Color(0xFFE0DDD7)
val AritziaGold = Color(0xFFC5A059)
val AritziaTerracotta = Color(0xFFA85E46)
val AritziaSage = Color(0xFF8A9A86)
