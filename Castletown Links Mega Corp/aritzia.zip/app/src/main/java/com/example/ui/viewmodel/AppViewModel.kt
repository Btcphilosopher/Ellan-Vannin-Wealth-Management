package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.CartItem
import com.example.data.model.Category
import com.example.data.model.ClosetItem
import com.example.data.model.CollectionLaunch
import com.example.data.model.FitProfile
import com.example.data.model.Order
import com.example.data.model.Outfit
import com.example.data.model.Product
import com.example.data.model.SearchFilter
import com.example.data.model.Store
import com.example.data.model.UserProfile
import com.example.data.model.WishlistItem
import com.example.data.repository.AritziaRepository
import com.example.data.repository.FitRecommendation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed class Screen(val route: String) {
    object Discover : Screen("discover")
    object Shop : Screen("shop")
    object Style : Screen("style")
    object Closet : Screen("closet")
    object Account : Screen("account")
    data class ProductDetail(val productId: String) : Screen("pdp/$productId")
    object ShoppingBag : Screen("bag")
    object Checkout : Screen("checkout")
    data class OrderDetail(val orderId: String) : Screen("order/$orderId")
    object StoreLocator : Screen("stores")
    object FitProfileStudio : Screen("fit_profile")
}

class AppViewModel(application: Application) : AndroidViewModel(application) {

    val repository = AritziaRepository(application)

    // Navigation & Global UI state
    private val _currentScreen = MutableStateFlow<Screen>(Screen.Discover)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _isBagOpen = MutableStateFlow(false)
    val isBagOpen: StateFlow<Boolean> = _isBagOpen.asStateFlow()

    private val _selectedProduct = MutableStateFlow<Product?>(null)
    val selectedProduct: StateFlow<Product?> = _selectedProduct.asStateFlow()

    private val _selectedOrder = MutableStateFlow<Order?>(null)
    val selectedOrder: StateFlow<Order?> = _selectedOrder.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    // Data streams from repository
    val products: StateFlow<List<Product>> = repository.products
    val categories: StateFlow<List<Category>> = repository.categories
    val launches: StateFlow<List<CollectionLaunch>> = repository.launches
    val stores: StateFlow<List<Store>> = repository.stores
    val recentlyViewed: StateFlow<List<Product>> = repository.recentlyViewed
    val userProfile: StateFlow<UserProfile> = repository.userProfile

    val cartItems: StateFlow<List<CartItem>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartTotal: StateFlow<Double> = cartItems.map { list ->
        list.sumOf { it.price * it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val cartCount: StateFlow<Int> = cartItems.map { list ->
        list.sumOf { it.quantity }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val wishlistItems: StateFlow<List<WishlistItem>> = repository.wishlistItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val closetItems: StateFlow<List<ClosetItem>> = repository.closetItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<Order>> = repository.orders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val fitProfile: StateFlow<FitProfile> = repository.fitProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FitProfile())

    // Shop search filter state
    private val _searchFilter = MutableStateFlow(SearchFilter())
    val searchFilter: StateFlow<SearchFilter> = _searchFilter.asStateFlow()

    private val _filteredProducts = MutableStateFlow<List<Product>>(repository.products.value)
    val filteredProducts: StateFlow<List<Product>> = _filteredProducts.asStateFlow()

    // Style generator state
    private val _generatedOutfits = MutableStateFlow<List<Outfit>>(emptyList())
    val generatedOutfits: StateFlow<List<Outfit>> = _generatedOutfits.asStateFlow()

    init {
        updateProductFilter(SearchFilter())
        generateStyling("Workwear & Tailoring", "Mild Autumn (15°C)", "Classic Cream & Black", 500.0)
    }

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun openProductDetail(productId: String) {
        val prod = repository.getProductById(productId)
        if (prod != null) {
            _selectedProduct.value = prod
            _currentScreen.value = Screen.ProductDetail(productId)
        }
    }

    fun openOrderDetail(orderId: String) {
        viewModelScope.launch {
            val order = repository.getOrderById(orderId)
            if (order != null) {
                _selectedOrder.value = order
                _currentScreen.value = Screen.OrderDetail(orderId)
            }
        }
    }

    fun setBagOpen(isOpen: Boolean) {
        _isBagOpen.value = isOpen
    }

    fun showToast(msg: String) {
        _toastMessage.value = msg
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    // Cart actions
    fun addToCart(product: Product, colorName: String, size: String, qty: Int = 1) {
        viewModelScope.launch {
            repository.addToCart(product, colorName, size, qty)
            showToast("Added ${product.name} ($colorName, Size $size) to Bag")
        }
    }

    fun updateCartQty(cartItemId: String, newQty: Int) {
        viewModelScope.launch {
            repository.updateCartQuantity(cartItemId, newQty)
        }
    }

    fun removeFromCart(cartItemId: String) {
        viewModelScope.launch {
            repository.removeFromCart(cartItemId)
            showToast("Removed from Bag")
        }
    }

    // Wishlist actions
    fun toggleWishlist(productId: String) {
        viewModelScope.launch {
            val isAdded = repository.toggleWishlist(productId)
            if (isAdded) showToast("Saved to Wishlist") else showToast("Removed from Wishlist")
        }
    }

    fun isWishlisted(productId: String): Boolean {
        return wishlistItems.value.any { it.productId == productId }
    }

    // Shop search filter actions
    fun updateProductFilter(filter: SearchFilter) {
        _searchFilter.value = filter
        _filteredProducts.value = repository.searchProducts(filter)
    }

    fun selectCategoryFilter(categoryName: String?) {
        val newFilter = _searchFilter.value.copy(category = categoryName)
        updateProductFilter(newFilter)
    }

    fun selectBrandFilter(brandName: String?) {
        val newFilter = _searchFilter.value.copy(brand = brandName)
        updateProductFilter(newFilter)
    }

    // Style generator actions
    fun generateStyling(occasion: String, weather: String, palette: String, budget: Double) {
        _generatedOutfits.value = repository.generateStylingOutfits(occasion, weather, palette, budget)
    }

    // Fit Intelligence Calculation
    fun getFitRecommendation(product: Product): FitRecommendation {
        return repository.calculateFitRecommendation(product, fitProfile.value)
    }

    fun saveFitProfile(updated: FitProfile) {
        viewModelScope.launch {
            repository.saveFitProfile(updated)
            showToast("Fit Profile Updated successfully")
        }
    }

    // Launch Reminder Toggle
    fun toggleLaunchReminder(launchId: String) {
        repository.toggleLaunchReminder(launchId)
        showToast("Reminder preference updated")
    }

    // Checkout placement
    fun placeOrder(
        shippingAddress: String,
        paymentMethod: String,
        onSuccess: (Order) -> Unit
    ) {
        viewModelScope.launch {
            val items = cartItems.value
            val sub = cartTotal.value
            val tax = sub * 0.12 // 12% GST/PST
            val shipping = if (sub > 150.0) 0.0 else 15.0
            val total = sub + tax + shipping

            val newOrder = repository.placeOrder(
                items = items,
                subtotal = sub,
                tax = tax,
                shipping = shipping,
                total = total,
                shippingAddress = shippingAddress,
                paymentMethod = paymentMethod
            )

            _selectedOrder.value = newOrder
            showToast("Order #${newOrder.orderNumber} placed successfully!")
            onSuccess(newOrder)
        }
    }

    // Return initiation
    fun initiateReturn(orderId: String, reason: String) {
        showToast("Return request initiated for Order $orderId. Return label generated.")
    }
}
