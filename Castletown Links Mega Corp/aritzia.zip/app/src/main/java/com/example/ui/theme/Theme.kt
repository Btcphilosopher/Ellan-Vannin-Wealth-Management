package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val LightColorScheme = lightColorScheme(
    primary = AritziaBlack,
    onPrimary = AritziaWhite,
    primaryContainer = AritziaIvory,
    onPrimaryContainer = AritziaBlack,
    secondary = AritziaCharcoal,
    onSecondary = AritziaWhite,
    secondaryContainer = AritziaStone,
    onSecondaryContainer = AritziaBlack,
    tertiary = AritziaGold,
    onTertiary = AritziaWhite,
    background = AritziaOffWhite,
    onBackground = AritziaBlack,
    surface = AritziaWhite,
    onSurface = AritziaBlack,
    surfaceVariant = AritziaLightStone,
    onSurfaceVariant = AritziaMutedGray,
    outline = AritziaBorderGray,
    outlineVariant = AritziaStone
)

private val DarkColorScheme = darkColorScheme(
    primary = AritziaIvory,
    onPrimary = AritziaBlack,
    primaryContainer = AritziaCharcoal,
    onPrimaryContainer = AritziaIvory,
    secondary = AritziaStone,
    onSecondary = AritziaBlack,
    secondaryContainer = AritziaBlack,
    onSecondaryContainer = AritziaIvory,
    tertiary = AritziaGold,
    onTertiary = AritziaBlack,
    background = AritziaBlack,
    onBackground = AritziaIvory,
    surface = Color(0xFF1E1E1E),
    onSurface = AritziaIvory,
    surfaceVariant = Color(0xFF2B2B2B),
    onSurfaceVariant = Color(0xFFA0A0A0),
    outline = Color(0xFF3E3E3E),
    outlineVariant = Color(0xFF2C2C2C)
)

@Composable
fun AritziaTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val activity = view.context as? Activity
            activity?.window?.let { window ->
                window.statusBarColor = colorScheme.background.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
