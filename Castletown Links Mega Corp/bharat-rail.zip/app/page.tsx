'use client';

import React from 'react';
import { SupportedLanguage, isRTLLanguage } from '../lib/locales';
import { Station, Train, TravelClass, QuotaType, PNRRecord } from '../lib/railway/types';
import { STATIONS, TRAINS } from '../lib/railway/data';
import { RoutingEngine, JourneyOption } from '../lib/railway/engine';
import { Header, NavTab } from '../components/Header';
import { JourneySearch } from '../components/JourneySearch';
import { TrainCard } from '../components/TrainCard';
import { BookingModal } from '../components/BookingModal';
import { PNRTracker } from '../components/PNRTracker';
import { LiveStatusTracker } from '../components/LiveStatusTracker';
import { StationGuide } from '../components/StationGuide';
import { TourismGuide } from '../components/TourismGuide';
import { DisruptionBoard } from '../components/DisruptionBoard';
import { VoiceAssistant } from '../components/VoiceAssistant';
import { CoachLayoutModal } from '../components/CoachLayoutModal';
import { ScheduleModal } from '../components/ScheduleModal';
import {
  Train as TrainIcon,
  ShieldCheck,
  PhoneCall,
  Sparkles,
  ArrowRight,
  Info,
  Layers,
  HeartHandshake,
} from 'lucide-react';

export default function HomePage() {
  const [currentLang, setCurrentLang] = React.useState<SupportedLanguage>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('bharat_rail_lang') as SupportedLanguage;
      if (saved) return saved;
    }
    return 'en';
  });
  const [activeTab, setActiveTab] = React.useState<NavTab>('SEARCH');
  const [highContrast, setHighContrast] = React.useState(false);

  // Search form states
  const [fromStation, setFromStation] = React.useState<Station>(STATIONS[0]); // NDLS
  const [toStation, setToStation] = React.useState<Station>(STATIONS[1]); // MMCT
  const [journeyDate, setJourneyDate] = React.useState<string>(() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().split('T')[0];
  });
  const [quota, setQuota] = React.useState<QuotaType>('GN');
  const [selectedClassFilter, setSelectedClassFilter] = React.useState('ALL');

  // Search Results
  const [journeyOptions, setJourneyOptions] = React.useState<JourneyOption[]>(() =>
    RoutingEngine.findJourneys('NDLS', 'MMCT')
  );

  // Modal states
  const [bookingTrain, setBookingTrain] = React.useState<{
    train: Train;
    travelClass: TravelClass;
  } | null>(null);
  const [activeCoachLayoutTrain, setActiveCoachLayoutTrain] = React.useState<Train | null>(null);
  const [activeScheduleTrain, setActiveScheduleTrain] = React.useState<Train | null>(null);
  const [showVoiceAssistant, setShowVoiceAssistant] = React.useState(false);

  const handleSelectLanguage = (lang: SupportedLanguage) => {
    setCurrentLang(lang);
    try {
      localStorage.setItem('bharat_rail_lang', lang);
    } catch {
      // Ignore
    }
  };

  const handleSearchTrains = () => {
    const results = RoutingEngine.findJourneys(fromStation.code, toStation.code);
    setJourneyOptions(results);
    setActiveTab('SEARCH');
  };

  const handleCircuitBooking = (fromCode: string, toCode: string) => {
    const stFrom = STATIONS.find((s) => s.code === fromCode) || STATIONS[0];
    const stTo = STATIONS.find((s) => s.code === toCode) || STATIONS[1];
    setFromStation(stFrom);
    setToStation(stTo);
    const results = RoutingEngine.findJourneys(fromCode, toCode);
    setJourneyOptions(results);
    setActiveTab('SEARCH');
  };

  const isRTL = isRTLLanguage(currentLang);

  return (
    <div
      dir={isRTL ? 'rtl' : 'ltr'}
      className={`min-h-screen flex flex-col transition-colors ${
        highContrast
          ? 'bg-black text-amber-300'
          : 'bg-slate-100/70 text-slate-800'
      }`}
    >
      {/* Universal Header */}
      <Header
        currentLang={currentLang}
        onSelectLanguage={handleSelectLanguage}
        activeTab={activeTab}
        onSelectTab={setActiveTab}
        onOpenVoiceSearch={() => setShowVoiceAssistant(true)}
        highContrast={highContrast}
        onToggleHighContrast={() => setHighContrast(!highContrast)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* TAB 1: TRAIN SEARCH & JOURNEY PLANNER */}
        {activeTab === 'SEARCH' && (
          <div className="space-y-6">
            <JourneySearch
              currentLang={currentLang}
              fromStation={fromStation}
              toStation={toStation}
              journeyDate={journeyDate}
              quota={quota}
              selectedClass={selectedClassFilter}
              onFromStationChange={setFromStation}
              onToStationChange={setToStation}
              onJourneyDateChange={setJourneyDate}
              onQuotaChange={setQuota}
              onSelectedClassChange={setSelectedClassFilter}
              onSearch={handleSearchTrains}
            />

            {/* Results Counter & Fast Corridor Filter */}
            <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-4 rounded-xl border border-slate-200 text-xs">
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-sm">
                  {journeyOptions.length} Direct & Express Service{journeyOptions.length !== 1 ? 's' : ''} Found
                </span>
                <span className="text-slate-400">|</span>
                <span className="text-slate-600 font-medium">
                  {fromStation.code} → {toStation.code} on {journeyDate} ({quota} Quota)
                </span>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-slate-500">Fast popular routes:</span>
                <button
                  type="button"
                  onClick={() => {
                    const ndls = STATIONS.find((s) => s.code === 'NDLS')!;
                    const bsb = STATIONS.find((s) => s.code === 'BSB')!;
                    setFromStation(ndls);
                    setToStation(bsb);
                    setJourneyOptions(RoutingEngine.findJourneys('NDLS', 'BSB'));
                  }}
                  className="px-2 py-0.5 bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold rounded border border-amber-200"
                >
                  Delhi ⇄ Varanasi
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const ndls = STATIONS.find((s) => s.code === 'NDLS')!;
                    const mmct = STATIONS.find((s) => s.code === 'MMCT')!;
                    setFromStation(ndls);
                    setToStation(mmct);
                    setJourneyOptions(RoutingEngine.findJourneys('NDLS', 'MMCT'));
                  }}
                  className="px-2 py-0.5 bg-amber-50 hover:bg-amber-100 text-amber-900 font-bold rounded border border-amber-200"
                >
                  Delhi ⇄ Mumbai
                </button>
              </div>
            </div>

            {/* Train List */}
            {journeyOptions.length > 0 ? (
              <div className="space-y-4">
                {journeyOptions.map((opt, idx) => (
                  <TrainCard
                    key={`${opt.firstLeg.number}-${idx}`}
                    train={opt.firstLeg}
                    currentLang={currentLang}
                    journeyDate={journeyDate}
                    quota={quota}
                    selectedClassFilter={selectedClassFilter}
                    onBookClass={(train, travelClass) => {
                      setBookingTrain({ train, travelClass });
                    }}
                    onViewSchedule={(train) => setActiveScheduleTrain(train)}
                    onViewCoachLayout={(train) => setActiveCoachLayoutTrain(train)}
                  />
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-700 flex items-center justify-center mx-auto">
                  <TrainIcon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-slate-900">No Direct Trains on this specific route</h3>
                <p className="text-xs text-slate-500 max-w-md mx-auto">
                  Try swapping stations or search for connecting hubs like New Delhi (NDLS), Mumbai Central (MMCT), or Bhopal (BPL).
                </p>
                <button
                  type="button"
                  onClick={() => {
                    const ndls = STATIONS.find((s) => s.code === 'NDLS')!;
                    const mmct = STATIONS.find((s) => s.code === 'MMCT')!;
                    setFromStation(ndls);
                    setToStation(mmct);
                    setJourneyOptions(RoutingEngine.findJourneys('NDLS', 'MMCT'));
                  }}
                  className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Reset to Delhi - Mumbai Route
                </button>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: PNR STATUS & E-TICKET RETRIEVAL */}
        {activeTab === 'PNR' && <PNRTracker currentLang={currentLang} />}

        {/* TAB 3: LIVE TRAIN STATUS & TELEMETRY */}
        {activeTab === 'LIVE' && <LiveStatusTracker currentLang={currentLang} />}

        {/* TAB 4: STATION INFORMATION & ACCESSIBILITY AUDIT */}
        {activeTab === 'STATIONS' && <StationGuide currentLang={currentLang} />}

        {/* TAB 5: TOURISM & BHARAT GAURAV CIRCUITS */}
        {activeTab === 'TOURISM' && (
          <TourismGuide
            currentLang={currentLang}
            onSelectCircuitForBooking={handleCircuitBooking}
          />
        )}

        {/* TAB 6: DISRUPTION ADVISORIES & BULLETINS */}
        {activeTab === 'DISRUPTIONS' && <DisruptionBoard currentLang={currentLang} />}
      </main>

      {/* Booking Modal */}
      {bookingTrain && (
        <BookingModal
          train={bookingTrain.train}
          fromStation={fromStation}
          toStation={toStation}
          journeyDate={journeyDate}
          travelClass={bookingTrain.travelClass}
          quota={quota}
          currentLang={currentLang}
          onClose={() => setBookingTrain(null)}
          onBookingSuccess={(pnr) => {
            // Keep open in confirmation mode
          }}
        />
      )}

      {/* Coach Layout Modal */}
      {activeCoachLayoutTrain && (
        <CoachLayoutModal
          train={activeCoachLayoutTrain}
          currentLang={currentLang}
          onClose={() => setActiveCoachLayoutTrain(null)}
        />
      )}

      {/* Schedule Timetable Modal */}
      {activeScheduleTrain && (
        <ScheduleModal
          train={activeScheduleTrain}
          currentLang={currentLang}
          onClose={() => setActiveScheduleTrain(null)}
        />
      )}

      {/* Voice Assistant Modal */}
      {showVoiceAssistant && (
        <VoiceAssistant
          currentLang={currentLang}
          onClose={() => setShowVoiceAssistant(false)}
          onQueryExecute={(intent, params) => {
            if (intent === 'SEARCH') {
              const stFrom = STATIONS.find((s) => s.code === params.from) || STATIONS[0];
              const stTo = STATIONS.find((s) => s.code === params.to) || STATIONS[1];
              setFromStation(stFrom);
              setToStation(stTo);
              setJourneyOptions(RoutingEngine.findJourneys(stFrom.code, stTo.code));
              setActiveTab('SEARCH');
            } else if (intent === 'PNR') {
              setActiveTab('PNR');
            } else if (intent === 'LIVE') {
              setActiveTab('LIVE');
            }
          }}
        />
      )}

      {/* Footer */}
      <footer className="mt-12 bg-slate-900 text-slate-400 border-t border-slate-800 text-xs py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-6">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-amber-600 flex items-center justify-center text-white font-bold">
                <TrainIcon className="w-5 h-5" />
              </div>
              <div>
                <span className="font-bold text-white text-base">BHARAT RAIL</span>
                <p className="text-[11px] text-slate-400">
                  National Railway Passenger Information & Ticketing Infrastructure • GOI
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4 text-xs">
              <span className="flex items-center gap-1 text-emerald-400 font-semibold">
                <ShieldCheck className="w-4 h-4" />
                <span>Kavach 4.0 SIL-4 Certified</span>
              </span>
              <span className="flex items-center gap-1 text-amber-400 font-semibold">
                <HeartHandshake className="w-4 h-4" />
                <span>Sugamya Bharat Divyangjan Friendly</span>
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-[11px]">
            <div>
              <div className="font-bold text-white mb-2 uppercase">Official Portals</div>
              <ul className="space-y-1">
                <li>• Ministry of Railways</li>
                <li>• IRCTC Next Generation e-Ticketing</li>
                <li>• National Train Enquiry System (NTES)</li>
                <li>• CRIS (Centre for Railway Info Systems)</li>
              </ul>
            </div>
            <div>
              <div className="font-bold text-white mb-2 uppercase">Passenger Services</div>
              <ul className="space-y-1">
                <li>• Rail Madad 24x7 Helpline (139)</li>
                <li>• Divyangjan Wheelchair Assistance</li>
                <li>• Medical Emergency at Platforms</li>
                <li>• Tatkal & Premium Tatkal Booking</li>
              </ul>
            </div>
            <div>
              <div className="font-bold text-white mb-2 uppercase">Indian Languages</div>
              <ul className="space-y-1">
                <li>• हिन्दी, বাংলা, తెలుగు, मराठी</li>
                <li>• தமிழ், ગુજરાતી, ಕನ್ನಡ, മലയാളം</li>
                <li>• ଓଡ଼ିଆ, ਪੰਜਾਬੀ, অসমীয়া, اردو</li>
                <li>• Standard English (India)</li>
              </ul>
            </div>
            <div>
              <div className="font-bold text-white mb-2 uppercase">Compliance</div>
              <ul className="space-y-1">
                <li>• WCAG 2.1 AA Accessibility</li>
                <li>• Digital Personal Data Protection (DPDP)</li>
                <li>• Dynamic Fare Rule IR-2026-V4</li>
                <li>• ISO 27001 Security Certified</li>
              </ul>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-800 flex flex-wrap justify-between items-center text-[10px] text-slate-500">
            <div>© 2026 Bharat Rail. Government of India. All Rights Reserved.</div>
            <div>Demonstration Environment • Synthetic Data Engine</div>
          </div>
        </div>
      </footer>
    </div>
  );
}
