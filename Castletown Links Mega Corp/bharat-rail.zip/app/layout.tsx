import type {Metadata} from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Bharat Rail — National Multilingual Railway Passenger Platform',
  description: 'National-scale multilingual railway journey planner, real-time availability, PNR enquiry, live train running status, platform coach locator, and digital ticketing system.',
  openGraph: {
    title: 'Bharat Rail — National Multilingual Railway Passenger Platform',
    description: 'National-scale multilingual railway journey planner, real-time availability, PNR enquiry, live train running status, platform coach locator, and digital ticketing system.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Bharat Rail — National Multilingual Railway Passenger Platform',
    description: 'National-scale multilingual railway journey planner, real-time availability, PNR enquiry, live train running status, platform coach locator, and digital ticketing system.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;500;700&family=Noto+Sans+Devanagari:wght@400;500;700&family=Noto+Sans+Tamil:wght@400;600&family=Noto+Sans+Bengali:wght@400;600&family=Noto+Sans+Telugu:wght@400;600&family=Noto+Nastaliq+Urdu:wght@400;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-slate-900 text-slate-100 font-sans antialiased min-h-screen selection:bg-amber-500 selection:text-slate-950">
        {children}
      </body>
    </html>
  );
}
