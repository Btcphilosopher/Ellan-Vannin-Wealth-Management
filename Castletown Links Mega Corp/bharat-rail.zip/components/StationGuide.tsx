'use client';

import React from 'react';
import { Station } from '../lib/railway/types';
import { STATIONS } from '../lib/railway/data';
import { SupportedLanguage, getTranslation } from '../lib/locales';
import {
  MapPin,
  Accessibility,
  Wifi,
  Coffee,
  Car,
  Compass,
  Train,
  ShieldCheck,
  Zap,
  Building,
  HeartPulse,
} from 'lucide-react';

interface StationGuideProps {
  currentLang: SupportedLanguage;
}

export const StationGuide: React.FC<StationGuideProps> = ({ currentLang }) => {
  const [selectedStationCode, setSelectedStationCode] = React.useState('NDLS');
  const station = STATIONS.find((s) => s.code === selectedStationCode) || STATIONS[0];

  const t = (key: Parameters<typeof getTranslation>[0]) => getTranslation(key, currentLang);
  const localizedName = station.names[currentLang] || station.names.en;
  const localizedCity = station.cityNames[currentLang] || station.cityNames.en;

  const facilitiesList = [
    { label: 'Wheelchair Assistance', available: station.facilities.wheelchairAccessible, icon: Accessibility },
    { label: 'Lifts & Escalator Ramps', available: station.facilities.rampsAndLifts, icon: Building },
    { label: 'Braille Navigation Signage', available: station.facilities.brailleSignage, icon: Accessibility },
    { label: 'Battery Buggy for Seniors', available: station.facilities.batteryCarBuggy, icon: Car },
    { label: 'Executive AC Lounge', available: station.facilities.executiveLounge, icon: Coffee },
    { label: 'RailWire High-Speed Wi-Fi', available: station.facilities.wifi, icon: Wifi },
    { label: 'Luggage Cloak Room & Lockers', available: station.facilities.cloakRoom, icon: ShieldCheck },
    { label: 'Retiring Dormitory Rooms', available: station.facilities.dormitoryRetiringRooms, icon: Building },
    { label: 'Direct Metro Rail Interchange', available: station.facilities.metroInterchange, icon: Train },
    { label: 'Prepaid Taxi / Auto Booths', available: station.facilities.prepaidTaxi, icon: Car },
    { label: 'Emergency Medical First-Aid', available: station.facilities.medicalEmergencyRoom, icon: HeartPulse },
    { label: 'Fast EV Charging Station', available: station.facilities.evCharging, icon: Zap },
  ];

  return (
    <div className="space-y-6">
      {/* Station Selector Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-5 sm:p-7">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white shadow-xs">
            <MapPin className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-serif">
              {t('stationInformation')} & Passenger Facilities
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Station accessibility audit, wheelchair buggy booking, platform directories & tourism connections
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
            Select Station:
          </label>
          <select
            id="station-guide-select"
            value={selectedStationCode}
            onChange={(e) => setSelectedStationCode(e.target.value)}
            className="px-3.5 py-2 text-sm font-bold rounded-xl border border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-amber-500"
          >
            {STATIONS.map((s) => (
              <option key={s.code} value={s.code}>
                {s.names[currentLang] || s.names.en} ({s.code}) - {s.state} [{s.zone} Zone]
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Station Overview Hero */}
      <div className="bg-slate-900 text-white rounded-2xl p-6 sm:p-8 shadow-md">
        <div className="flex flex-wrap items-start justify-between gap-4">
          <div>
            <div className="text-xs font-bold uppercase tracking-widest text-amber-400">
              {station.zone} ZONE • {station.division.toUpperCase()} DIVISION
            </div>
            <h3 className="text-2xl sm:text-4xl font-black font-serif mt-1">
              {localizedName}
            </h3>
            <p className="text-sm text-slate-400 mt-1">
              {localizedCity}, {station.state} • Station Code:{' '}
              <span className="font-mono text-amber-300 font-bold">{station.code}</span>
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-slate-800/90 border border-slate-700 px-4 py-2.5 rounded-xl text-center">
              <div className="text-2xl font-black font-mono text-amber-400">{station.platformCount}</div>
              <div className="text-[10px] text-slate-400 uppercase font-semibold">Platforms</div>
            </div>
          </div>
        </div>
      </div>

      {/* Facilities & Accessibility Grid */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-5 sm:p-7">
        <h3 className="text-base font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Accessibility className="w-5 h-5 text-amber-600" />
          <span>Station Amenities & Divyangjan Accessibility Audit</span>
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {facilitiesList.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={idx}
                className={`p-3.5 rounded-xl border flex items-center gap-3 transition-colors ${
                  item.available
                    ? 'bg-emerald-50/40 border-emerald-200 text-emerald-950'
                    : 'bg-slate-50 border-slate-200 text-slate-400 opacity-60'
                }`}
              >
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                    item.available ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-200 text-slate-500'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </div>
                <div className="text-xs font-semibold">{item.label}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Nearby Tourism Attractions & Local Connectivity */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-5 sm:p-7">
        <h3 className="text-base font-bold text-slate-900 mb-4 flex items-center gap-2">
          <Compass className="w-5 h-5 text-amber-600" />
          <span>Nearby Tourism Attractions & City Connectivity</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {station.tourismSpots.map((spot, idx) => (
            <div key={idx} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start mb-2">
                  <span className="text-xs font-black uppercase tracking-wider px-2 py-0.5 rounded bg-amber-100 text-amber-900">
                    {spot.category}
                  </span>
                  <span className="text-xs font-mono font-bold text-slate-600">{spot.distanceKm} km</span>
                </div>
                <h4 className="font-bold text-sm text-slate-900 mb-1">{spot.name}</h4>
                <p className="text-xs text-slate-600 mb-3">{spot.description}</p>
              </div>

              <div className="text-[11px] text-slate-500 font-medium pt-2 border-t border-slate-200 flex items-center gap-1.5">
                <Car className="w-3.5 h-3.5 text-amber-700" />
                <span>Transit: {spot.transportAvailable}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
