'use client';

import React from 'react';
import { Train } from '../lib/railway/types';
import { SupportedLanguage } from '../lib/locales';
import { X, Clock, MapPin, Train as TrainIcon, ShieldCheck } from 'lucide-react';

interface ScheduleModalProps {
  train: Train;
  currentLang: SupportedLanguage;
  onClose: () => void;
}

export const ScheduleModal: React.FC<ScheduleModalProps> = ({
  train,
  currentLang,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg font-serif">
                {train.names[currentLang] || train.names.en} (#{train.number})
              </h3>
              <p className="text-xs text-slate-400">
                Timetable & Route Map • {train.originStationCode} → {train.destinationStationCode} ({train.totalDistanceKm} km)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Schedule Table */}
        <div className="p-6 overflow-y-auto flex-1">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="border-b border-slate-200 uppercase font-bold text-slate-500 bg-slate-50">
                <th className="py-2.5 px-3">#</th>
                <th className="py-2.5 px-3">Station Code & Name</th>
                <th className="py-2.5 px-3">Day</th>
                <th className="py-2.5 px-3">Arr</th>
                <th className="py-2.5 px-3">Dep</th>
                <th className="py-2.5 px-3">Halt</th>
                <th className="py-2.5 px-3">Distance</th>
                <th className="py-2.5 px-3">PF</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {train.schedule.map((stop, index) => (
                <tr key={stop.stationCode} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3 px-3 font-mono font-bold text-slate-400">{index + 1}</td>
                  <td className="py-3 px-3">
                    <span className="font-bold text-slate-900">{stop.stationName}</span>
                    <span className="ml-1 text-slate-500 font-mono">({stop.stationCode})</span>
                  </td>
                  <td className="py-3 px-3 font-semibold text-slate-700">Day {stop.day}</td>
                  <td className="py-3 px-3 font-mono font-bold text-slate-800">
                    {stop.arrivalTime}
                  </td>
                  <td className="py-3 px-3 font-mono font-bold text-slate-800">
                    {stop.departureTime}
                  </td>
                  <td className="py-3 px-3 text-amber-800 font-semibold">
                    {stop.dwellMinutes > 0 ? `${stop.dwellMinutes}m` : '-'}
                  </td>
                  <td className="py-3 px-3 font-mono text-slate-600">{stop.distanceKm} km</td>
                  <td className="py-3 px-3 font-bold text-slate-900">PF {stop.platform}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
