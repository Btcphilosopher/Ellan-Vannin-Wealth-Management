'use client';

import React from 'react';
import { Train } from '../lib/railway/types';
import { TRAINS } from '../lib/railway/data';
import { LiveTrackingEngine } from '../lib/railway/engine';
import { SupportedLanguage, getTranslation } from '../lib/locales';
import {
  Activity,
  Gauge,
  MapPin,
  Clock,
  ShieldCheck,
  AlertTriangle,
  Radio,
  Search,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';

interface LiveStatusTrackerProps {
  currentLang: SupportedLanguage;
}

export const LiveStatusTracker: React.FC<LiveStatusTrackerProps> = ({ currentLang }) => {
  const [selectedTrainNumber, setSelectedTrainNumber] = React.useState<string>('22436');
  const [telemetry, setTelemetry] = React.useState(() => LiveTrackingEngine.getTelemetry('22436'));
  const [autoRefresh, setAutoRefresh] = React.useState(true);

  const t = (key: Parameters<typeof getTranslation>[0]) => getTranslation(key, currentLang);

  const currentTrain = TRAINS.find((t) => t.number === selectedTrainNumber) || TRAINS[0];

  const handleTrainChange = (trainNo: string) => {
    setSelectedTrainNumber(trainNo);
    setTelemetry(LiveTrackingEngine.getTelemetry(trainNo));
  };

  React.useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      setTelemetry(LiveTrackingEngine.getTelemetry(selectedTrainNumber));
    }, 15000);
    return () => clearInterval(interval);
  }, [selectedTrainNumber, autoRefresh]);

  const scheduleStops = currentTrain.schedule;
  const currentStationIndex = scheduleStops.findIndex(
    (s) => s.stationCode === telemetry.currentStationCode
  );

  return (
    <div className="space-y-6">
      {/* Train Selector & Control Bar */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-5 sm:p-7">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white shadow-xs">
            <Activity className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-serif">
              {t('liveTrainStatus')} & GPS Telemetry
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Direct telemetry from locomotive RTIS (Real-Time Information System) & Kavach 4.0 Automatic Train Protection
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <label className="text-xs font-bold text-slate-600 uppercase tracking-wider">
              Select Train:
            </label>
            <select
              id="live-train-select"
              value={selectedTrainNumber}
              onChange={(e) => handleTrainChange(e.target.value)}
              className="px-3.5 py-2 text-sm font-bold rounded-xl border border-slate-300 bg-white text-slate-900 focus:ring-2 focus:ring-amber-500"
            >
              {TRAINS.map((t) => (
                <option key={t.number} value={t.number}>
                  {t.number} - {t.names[currentLang] || t.names.en} ({t.originStationCode} → {t.destinationStationCode})
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-800 rounded-lg font-semibold border border-emerald-200">
              <Radio className="w-4 h-4 text-emerald-600 animate-pulse" />
              <span>RTIS Satellite Sync: Active</span>
            </div>

            <button
              type="button"
              onClick={() => setTelemetry(LiveTrackingEngine.getTelemetry(selectedTrainNumber))}
              className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold rounded-lg transition-colors"
            >
              Refresh Ping
            </button>
          </div>
        </div>
      </div>

      {/* Telemetry Dashboard Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Speed */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Current Speed
            </div>
            <div className="text-3xl font-black font-mono text-slate-900 mt-1">
              {telemetry.currentSpeedKmh} <span className="text-sm font-normal text-slate-500">km/h</span>
            </div>
            <div className="text-[11px] text-emerald-600 font-semibold mt-0.5">
              Target MPS: 130 km/h
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
            <Gauge className="w-6 h-6" />
          </div>
        </div>

        {/* Punctuality / Delay */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Running Status
            </div>
            <div className="text-2xl font-black font-mono mt-1">
              {telemetry.delayMinutes === 0 ? (
                <span className="text-emerald-600">ON TIME</span>
              ) : (
                <span className="text-amber-700">Late by {telemetry.delayMinutes}m</span>
              )}
            </div>
            <div className="text-[11px] text-slate-500 font-medium mt-0.5">
              Last Ping: {new Date(telemetry.lastTelemetryPing).toLocaleTimeString()}
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
            <Clock className="w-6 h-6" />
          </div>
        </div>

        {/* Next Stop */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              Next Approach
            </div>
            <div className="text-2xl font-black text-slate-900 mt-1">
              {telemetry.nextStationCode}
            </div>
            <div className="text-[11px] text-slate-500 font-medium mt-0.5">
              ETA: {telemetry.estimatedNextArrival}
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-orange-50 text-orange-600 flex items-center justify-center">
            <MapPin className="w-6 h-6" />
          </div>
        </div>

        {/* Safety & ATP */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex items-center justify-between">
          <div>
            <div className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              ATP Safety Shield
            </div>
            <div className="text-lg font-black text-emerald-800 mt-1">
              Kavach 4.0 SIL-4
            </div>
            <div className="text-[11px] text-slate-500 font-medium mt-0.5">
              Automatic Braking Armed
            </div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
            <ShieldCheck className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Disruption Alert if any */}
      {telemetry.disruptionNote && (
        <div className="p-4 rounded-xl bg-amber-50 border border-amber-200 flex items-center gap-3 text-amber-900 text-xs">
          <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0" />
          <div>
            <span className="font-bold">Locomotive Advisory:</span> {telemetry.disruptionNote}
          </div>
        </div>
      )}

      {/* Live Route Station Timeline */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-5 sm:p-7">
        <h3 className="text-base font-bold text-slate-900 mb-6 flex items-center gap-2">
          <MapPin className="w-5 h-5 text-amber-600" />
          <span>Interactive Station Progress Timeline</span>
        </h3>

        <div className="relative pl-6 sm:pl-8 space-y-8 before:absolute before:left-3 before:top-3 before:bottom-3 before:w-0.5 before:bg-slate-200">
          {scheduleStops.map((stop, idx) => {
            const isPassed = currentStationIndex !== -1 && idx < currentStationIndex;
            const isCurrent = idx === currentStationIndex;
            const isUpcoming = idx > currentStationIndex;

            return (
              <div key={stop.stationCode} className="relative flex items-start gap-4">
                {/* Timeline Node Dot */}
                <div
                  className={`absolute -left-6 sm:-left-8 top-1 w-6 h-6 rounded-full flex items-center justify-center text-white text-xs font-bold ring-4 ring-white ${
                    isPassed
                      ? 'bg-emerald-600'
                      : isCurrent
                      ? 'bg-amber-600 animate-pulse'
                      : 'bg-slate-300'
                  }`}
                >
                  {isPassed ? <CheckCircle2 className="w-3.5 h-3.5" /> : idx + 1}
                </div>

                {/* Stop Card */}
                <div
                  className={`flex-1 p-4 rounded-xl border transition-all ${
                    isCurrent
                      ? 'bg-amber-50/70 border-amber-300 shadow-xs'
                      : isPassed
                      ? 'bg-slate-50/50 border-slate-200 opacity-80'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-slate-900">{stop.stationName}</span>
                        <span className="px-2 py-0.5 bg-slate-100 font-mono text-xs font-bold text-slate-700 rounded">
                          {stop.stationCode}
                        </span>
                        {isCurrent && (
                          <span className="px-2 py-0.5 bg-amber-600 text-white text-[10px] font-black uppercase tracking-wider rounded">
                            Current Train Location
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-500 mt-0.5">
                        Distance: {stop.distanceKm} km • Dwell: {stop.dwellMinutes} mins • Platform {stop.platform}
                      </div>
                    </div>

                    <div className="text-right">
                      <div className="text-sm font-mono font-bold text-slate-800">
                        {stop.arrivalTime === 'START' ? 'Dep ' + stop.departureTime : stop.arrivalTime}
                      </div>
                      <div className="text-[11px] text-slate-400">
                        {stop.departureTime !== 'END' ? `Dep: ${stop.departureTime}` : 'Terminating'}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
