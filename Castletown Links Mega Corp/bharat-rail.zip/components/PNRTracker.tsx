'use client';

import React from 'react';
import { PNRRecord } from '../lib/railway/types';
import { PNREngine } from '../lib/railway/engine';
import { SupportedLanguage, getTranslation } from '../lib/locales';
import {
  Ticket,
  Search,
  CheckCircle2,
  AlertCircle,
  Clock,
  Printer,
  Share2,
  QrCode,
  ShieldCheck,
  Train,
  ArrowRight,
} from 'lucide-react';

interface PNRTrackerProps {
  currentLang: SupportedLanguage;
}

export const PNRTracker: React.FC<PNRTrackerProps> = ({ currentLang }) => {
  const [pnrQuery, setPnrQuery] = React.useState('248-8192039');
  const [result, setResult] = React.useState<PNRRecord | null>(() => PNREngine.searchPNR('248-8192039'));
  const [searched, setSearched] = React.useState(true);
  const [loading, setLoading] = React.useState(false);

  const t = (key: Parameters<typeof getTranslation>[0]) => getTranslation(key, currentLang);

  const handleSearch = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!pnrQuery.trim()) return;

    setLoading(true);
    setTimeout(() => {
      const res = PNREngine.searchPNR(pnrQuery);
      setResult(res);
      setSearched(true);
      setLoading(false);
    }, 400);
  };

  const samplePNRs = ['248-8192039', '612-4091823', '855-9281740'];

  return (
    <div className="space-y-6">
      {/* PNR Search Box */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-5 sm:p-7">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white shadow-xs">
            <Ticket className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-serif">
              {t('pnrStatus')} & E-Ticket Retrieval
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Verify real-time berth allocation, chart preparation status, and download verifiable digital rail passes
            </p>
          </div>
        </div>

        <form onSubmit={handleSearch} className="max-w-2xl">
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <input
                id="pnr-search-input"
                type="text"
                value={pnrQuery}
                maxLength={12}
                onChange={(e) => setPnrQuery(e.target.value)}
                placeholder="Enter 10-Digit PNR Number (e.g. 248-8192039)"
                className="w-full px-4 py-3 text-base font-mono font-bold tracking-wider rounded-xl border border-slate-300 bg-slate-50/50 hover:bg-white focus:bg-white text-slate-900 focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
              />
            </div>
            <button
              id="search-pnr-button"
              type="submit"
              disabled={loading}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-amber-600 hover:bg-amber-700 text-white font-bold text-sm rounded-xl shadow-md transition-all disabled:opacity-50"
            >
              <Search className="w-4 h-4" />
              <span>{loading ? 'Checking...' : 'Check Status'}</span>
            </button>
          </div>

          {/* Sample quick buttons */}
          <div className="flex items-center gap-2 mt-3 text-xs text-slate-500">
            <span>Try sample PNRs:</span>
            {samplePNRs.map((pnr) => (
              <button
                key={pnr}
                type="button"
                onClick={() => {
                  setPnrQuery(pnr);
                  setLoading(true);
                  setTimeout(() => {
                    setResult(PNREngine.searchPNR(pnr));
                    setSearched(true);
                    setLoading(false);
                  }, 300);
                }}
                className="font-mono font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 px-2 py-0.5 rounded border border-amber-200 transition-colors"
              >
                {pnr}
              </button>
            ))}
          </div>
        </form>
      </div>

      {/* PNR Results Section */}
      {searched && result && (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden animate-fadeIn">
          {/* Header Status Banner */}
          <div className="bg-slate-900 text-white p-5 sm:p-6 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-4">
              <div>
                <div className="text-xs font-semibold uppercase tracking-widest text-amber-400">
                  PNR NUMBER
                </div>
                <div className="text-2xl sm:text-3xl font-black font-mono tracking-tight">
                  {result.pnrNumber}
                </div>
              </div>
              <div className="h-10 w-px bg-slate-700 hidden sm:block" />
              <div>
                <div className="text-sm font-bold text-slate-200">
                  {result.trainName} (#{result.trainNumber})
                </div>
                <div className="text-xs text-slate-400 flex items-center gap-2 mt-0.5">
                  <span>{result.fromStationCode}</span>
                  <ArrowRight className="w-3 h-3 text-amber-400" />
                  <span>{result.toStationCode}</span>
                  <span>•</span>
                  <span>{result.journeyDate}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3">
              <div className="text-right">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 font-bold text-xs rounded-lg">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span>{result.currentStatus}</span>
                </span>
                <div className="text-[11px] text-slate-400 mt-1">
                  {result.chartStatus === 'CHART_PREPARED' ? 'Chart Prepared' : 'Chart Not Prepared'}
                </div>
              </div>
            </div>
          </div>

          {/* Passenger Berth Allocation Table */}
          <div className="p-5 sm:p-7">
            <h3 className="text-base font-bold text-slate-900 mb-4 flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-amber-600" />
              <span>Passenger Berth & Reservation Status</span>
            </h3>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-200 text-xs font-bold uppercase text-slate-500 bg-slate-50">
                    <th className="py-3 px-4">#</th>
                    <th className="py-3 px-4">Passenger Name</th>
                    <th className="py-3 px-4">Age / Gender</th>
                    <th className="py-3 px-4">Booking Status</th>
                    <th className="py-3 px-4">Current Status</th>
                    <th className="py-3 px-4">Coach / Berth</th>
                    <th className="py-3 px-4">Meal</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 text-sm">
                  {result.passengers.map((passenger, index) => (
                    <tr key={passenger.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-400">{index + 1}</td>
                      <td className="py-3.5 px-4 font-bold text-slate-900">{passenger.name}</td>
                      <td className="py-3.5 px-4 text-slate-600 text-xs">
                        {passenger.age} yrs / {passenger.gender}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2 py-0.5 text-xs font-bold rounded bg-slate-100 text-slate-700">
                          {passenger.assignedStatus}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="px-2.5 py-1 text-xs font-bold rounded-md bg-emerald-100 text-emerald-800 border border-emerald-300">
                          CONFIRMED (CNF)
                        </span>
                      </td>
                      <td className="py-3.5 px-4 font-mono font-bold text-slate-900">
                        {passenger.assignedCoach ? `${passenger.assignedCoach} / ${passenger.assignedBerth}` : passenger.assignedBerth}
                      </td>
                      <td className="py-3.5 px-4 text-xs font-medium text-slate-600">
                        {passenger.foodPreference}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Verification Security Footer */}
            <div className="mt-6 pt-5 border-t border-slate-200 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-slate-100 rounded-lg p-1 border border-slate-300 flex items-center justify-center">
                  <QrCode className="w-8 h-8 text-slate-800" />
                </div>
                <div>
                  <div className="text-xs font-bold text-slate-800">Verifiable Digital Pass</div>
                  <div className="text-[11px] font-mono text-slate-500 truncate max-w-xs">
                    {result.qrSignature}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition-colors"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Slip</span>
                </button>
                <button
                  type="button"
                  onClick={() => alert(`PNR ${result.pnrNumber} details copied to clipboard!`)}
                  className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold transition-colors shadow-xs"
                >
                  <Share2 className="w-4 h-4" />
                  <span>Share Status</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {searched && !result && (
        <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center">
          <div className="w-12 h-12 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center mx-auto mb-3">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900 mb-1">PNR Not Found</h3>
          <p className="text-xs text-slate-500 max-w-md mx-auto mb-4">
            Please verify the 10-digit number. PNRs older than 9 months or cancelled without records may be archived.
          </p>
        </div>
      )}
    </div>
  );
};
