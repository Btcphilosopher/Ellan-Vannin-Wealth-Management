'use client';

import React from 'react';
import { Train, TravelClass, QuotaType, ClassAvailability } from '../lib/railway/types';
import { AvailabilityEngine } from '../lib/railway/engine';
import { SupportedLanguage, getTranslation } from '../lib/locales';
import {
  Clock,
  MapPin,
  Utensils,
  ShieldCheck,
  ChevronDown,
  ChevronUp,
  Info,
  Sparkles,
  Layers,
  ArrowRight,
} from 'lucide-react';

interface TrainCardProps {
  train: Train;
  currentLang: SupportedLanguage;
  journeyDate: string;
  quota: QuotaType;
  selectedClassFilter: string;
  onBookClass: (train: Train, travelClass: TravelClass) => void;
  onViewSchedule: (train: Train) => void;
  onViewCoachLayout: (train: Train) => void;
}

export const TrainCard: React.FC<TrainCardProps> = ({
  train,
  currentLang,
  journeyDate,
  quota,
  selectedClassFilter,
  onBookClass,
  onViewSchedule,
  onViewCoachLayout,
}) => {
  const [isExpanded, setIsExpanded] = React.useState(false);
  const t = (key: Parameters<typeof getTranslation>[0]) => getTranslation(key, currentLang);

  const localizedName = train.names[currentLang] || train.names.en;

  const classAvailabilities: { travelClass: TravelClass; avail: ClassAvailability }[] = React.useMemo(() => {
    return train.classesAvailable
      .filter((cls) => selectedClassFilter === 'ALL' || cls === selectedClassFilter)
      .map((cls) => ({
        travelClass: cls,
        avail: AvailabilityEngine.getAvailability(train.number, journeyDate, cls, quota),
      }));
  }, [train, journeyDate, quota, selectedClassFilter]);

  const daysOfWeek = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];

  const getTypeBadgeStyle = (type: Train['type']) => {
    switch (type) {
      case 'VANDE_BHARAT':
        return 'bg-gradient-to-r from-blue-700 to-indigo-800 text-white border-blue-600';
      case 'RAJDHANI':
        return 'bg-gradient-to-r from-red-700 to-rose-800 text-white border-red-600';
      case 'SHATABDI':
        return 'bg-gradient-to-r from-cyan-700 to-teal-800 text-white border-cyan-600';
      default:
        return 'bg-slate-800 text-amber-300 border-slate-700';
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200/90 shadow-sm hover:shadow-md transition-all overflow-hidden mb-4">
      {/* Top Train Header */}
      <div className="p-4 sm:p-5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-3 bg-slate-50/50">
        <div className="flex items-center gap-3">
          <span className={`px-2.5 py-1 text-xs font-black tracking-wider uppercase rounded-lg border shadow-2xs ${getTypeBadgeStyle(train.type)}`}>
            {train.type.replace('_', ' ')}
          </span>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-bold text-slate-900 font-serif">
                {localizedName}
              </h3>
              <span className="px-2 py-0.5 bg-slate-200 text-slate-800 font-mono text-xs font-bold rounded">
                #{train.number}
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Runs on:{' '}
              {train.runsOnDays.map((runs, idx) => (
                <span
                  key={idx}
                  className={`inline-block mx-0.5 font-bold ${
                    runs ? 'text-emerald-700 bg-emerald-50 px-1 rounded' : 'text-slate-300'
                  }`}
                >
                  {daysOfWeek[idx]}
                </span>
              ))}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 sm:gap-3 text-xs">
          {train.pantried && (
            <span className="flex items-center gap-1 px-2 py-1 bg-amber-50 text-amber-900 font-medium rounded-md border border-amber-200">
              <Utensils className="w-3.5 h-3.5 text-amber-700" />
              <span>IRCTC Pantry</span>
            </span>
          )}

          <span className="flex items-center gap-1 px-2 py-1 bg-emerald-50 text-emerald-900 font-medium rounded-md border border-emerald-200">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
            <span>{train.punctualityScorePct}% On-Time</span>
          </span>
        </div>
      </div>

      {/* Train Timing & Route Bar */}
      <div className="p-4 sm:p-5 grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
        <div className="md:col-span-3">
          <div className="text-2xl font-black text-slate-900 font-mono tracking-tight">
            {train.departureTime}
          </div>
          <div className="text-sm font-bold text-slate-700">{train.originStationCode}</div>
          <div className="text-xs text-slate-500">Origin Departure</div>
        </div>

        <div className="md:col-span-6 flex flex-col items-center justify-center">
          <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 mb-1">
            <Clock className="w-3.5 h-3.5" />
            <span>
              {Math.floor(train.durationMinutes / 60)}h {train.durationMinutes % 60}m
            </span>
            <span>•</span>
            <span>{train.totalDistanceKm} km</span>
            <span>•</span>
            <span className="text-amber-700">{train.schedule.length} Stops</span>
          </div>
          <div className="w-full flex items-center gap-2">
            <div className="w-2.5 h-2.5 rounded-full bg-amber-600 ring-2 ring-amber-200" />
            <div className="flex-1 h-0.5 bg-gradient-to-r from-amber-500 via-orange-400 to-amber-600 relative">
              <div className="absolute -top-2 left-1/2 -translate-x-1/2 bg-white px-1 text-[10px] text-slate-400 font-mono">
                {train.avgSpeedKmh} km/h
              </div>
            </div>
            <div className="w-2.5 h-2.5 rounded-full bg-orange-600 ring-2 ring-orange-200" />
          </div>
        </div>

        <div className="md:col-span-3 text-right">
          <div className="text-2xl font-black text-slate-900 font-mono tracking-tight">
            {train.arrivalTime}
          </div>
          <div className="text-sm font-bold text-slate-700">{train.destinationStationCode}</div>
          <div className="text-xs text-slate-500">Destination Arrival</div>
        </div>
      </div>

      {/* Availability & Travel Class Grid */}
      <div className="p-4 sm:p-5 pt-0">
        <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2.5 flex items-center justify-between">
          <span>Available Classes & Fares ({quota} Quota)</span>
          <span className="text-[11px] font-normal lowercase text-slate-400">
            Click class to book ticket
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5">
          {classAvailabilities.map(({ travelClass, avail }) => {
            const isAvail = avail.status === 'AVAILABLE';
            const isRac = avail.status === 'RAC';

            return (
              <button
                key={travelClass}
                id={`book-class-${train.number}-${travelClass}`}
                type="button"
                onClick={() => onBookClass(train, travelClass)}
                className={`text-left p-3 rounded-xl border transition-all hover:scale-[1.02] shadow-2xs ${
                  isAvail
                    ? 'border-emerald-300 bg-emerald-50/40 hover:bg-emerald-50 hover:border-emerald-500'
                    : isRac
                    ? 'border-amber-300 bg-amber-50/40 hover:bg-amber-50 hover:border-amber-500'
                    : 'border-orange-300 bg-orange-50/40 hover:bg-orange-50 hover:border-orange-500'
                }`}
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="font-extrabold text-sm text-slate-900">{travelClass}</span>
                  <span className="font-mono font-bold text-sm text-slate-800">
                    ₹{avail.baseFare}
                  </span>
                </div>

                <div className="text-xs font-bold mb-1">
                  {isAvail && (
                    <span className="text-emerald-700">AVAILABLE - {avail.availableCount}</span>
                  )}
                  {isRac && (
                    <span className="text-amber-800">RAC - {avail.racCount}</span>
                  )}
                  {!isAvail && !isRac && (
                    <span className="text-orange-800">
                      {avail.waitlistType || 'GNWL'} #{avail.waitlistCount}
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-between text-[10px] text-slate-500 font-medium">
                  <span>{avail.confirmationProbabilityPct}% Chance</span>
                  <span className="text-amber-700 font-bold">Book →</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Card Action Footer */}
      <div className="px-4 sm:px-5 py-2.5 bg-slate-50 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-3">
          <button
            id={`view-schedule-btn-${train.number}`}
            type="button"
            onClick={() => onViewSchedule(train)}
            className="text-amber-800 hover:text-amber-950 font-bold flex items-center gap-1 transition-colors"
          >
            <Info className="w-3.5 h-3.5" />
            <span>View Full Schedule ({train.schedule.length} Stops)</span>
          </button>

          <button
            id={`view-coach-layout-btn-${train.number}`}
            type="button"
            onClick={() => onViewCoachLayout(train)}
            className="text-slate-600 hover:text-slate-900 font-medium flex items-center gap-1 transition-colors"
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Coach Position & Rake Layout</span>
          </button>
        </div>

        <span className="text-slate-400 font-mono text-[11px]">
          Dynamic Pricing Active • Kavach 4.0
        </span>
      </div>
    </div>
  );
};
