'use client';

import React from 'react';
import { SupportedLanguage, getTranslation } from '../lib/locales';
import { Mic, MicOff, Volume2, Sparkles, X, ArrowRight, Train } from 'lucide-react';

interface VoiceAssistantProps {
  currentLang: SupportedLanguage;
  onClose: () => void;
  onQueryExecute: (intent: 'SEARCH' | 'PNR' | 'LIVE', params: any) => void;
}

export const VoiceAssistant: React.FC<VoiceAssistantProps> = ({
  currentLang,
  onClose,
  onQueryExecute,
}) => {
  const [isListening, setIsListening] = React.useState(false);
  const [transcript, setTranscript] = React.useState('');
  const [assistantReply, setAssistantReply] = React.useState(
    'Namaste! I am your Bharat Rail Voice Assistant. Speak your journey plan, train name, or PNR number.'
  );

  const t = (key: Parameters<typeof getTranslation>[0]) => getTranslation(key, currentLang);

  const sampleVoicePrompts = [
    { text: 'Trains from New Delhi to Mumbai', type: 'SEARCH', from: 'NDLS', to: 'MMCT' },
    { text: 'Book Vande Bharat to Varanasi', type: 'SEARCH', from: 'NDLS', to: 'BSB' },
    { text: 'Check PNR 2488192039', type: 'PNR', pnr: '248-8192039' },
    { text: 'Live GPS status of 22436', type: 'LIVE', trainNumber: '22436' },
  ];

  const handleStartListening = () => {
    if (typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      try {
        const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
        const recognition = new SpeechRecognition();
        recognition.lang = currentLang === 'hi' ? 'hi-IN' : currentLang === 'ta' ? 'ta-IN' : 'en-IN';
        recognition.interimResults = false;
        recognition.maxAlternatives = 1;

        setIsListening(true);
        setTranscript('Listening to your voice...');

        recognition.onresult = (event: any) => {
          const text = event.results[0][0].transcript;
          setTranscript(`"${text}"`);
          setIsListening(false);
          processVoiceQuery(text);
        };

        recognition.onerror = () => {
          setIsListening(false);
          setTranscript('Could not detect audio clearly. Click a sample prompt below.');
        };

        recognition.onend = () => {
          setIsListening(false);
        };

        recognition.start();
      } catch (e) {
        setIsListening(false);
        setTranscript('Speech recognition initialized in fallback mode.');
      }
    } else {
      setIsListening(true);
      setTimeout(() => {
        setIsListening(false);
        setTranscript('"New Delhi to Varanasi Vande Bharat"');
        processVoiceQuery('New Delhi to Varanasi Vande Bharat');
      }, 1500);
    }
  };

  const processVoiceQuery = (query: string) => {
    const q = query.toLowerCase();
    if (q.includes('pnr')) {
      setAssistantReply('Retrieved your PNR Status and Berth Allocation.');
      setTimeout(() => {
        onQueryExecute('PNR', { pnr: '248-8192039' });
        onClose();
      }, 1000);
    } else if (q.includes('live') || q.includes('status') || q.includes('22436')) {
      setAssistantReply('Opening live GPS telemetry for Vande Bharat 22436.');
      setTimeout(() => {
        onQueryExecute('LIVE', { trainNumber: '22436' });
        onClose();
      }, 1000);
    } else {
      setAssistantReply('Searching fastest superfast trains for your requested route.');
      setTimeout(() => {
        onQueryExecute('SEARCH', { from: 'NDLS', to: 'MMCT' });
        onClose();
      }, 1000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border border-slate-200 overflow-hidden text-center p-6 sm:p-8 animate-fadeIn">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-amber-600" />
            <span className="font-bold text-sm text-slate-800 uppercase tracking-wider">
              Multilingual Voice Assistant
            </span>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 flex items-center justify-center"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Big Mic Button */}
        <div className="my-6">
          <button
            id="mic-listen-button"
            type="button"
            onClick={handleStartListening}
            className={`w-24 h-24 rounded-full flex items-center justify-center mx-auto shadow-xl transition-all ${
              isListening
                ? 'bg-red-600 text-white animate-pulse ring-8 ring-red-200'
                : 'bg-gradient-to-tr from-amber-600 to-orange-600 text-white hover:scale-105'
            }`}
          >
            {isListening ? <MicOff className="w-10 h-10" /> : <Mic className="w-10 h-10" />}
          </button>
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mt-3">
            {isListening ? 'Listening in your chosen language...' : 'Tap Mic to Speak (Hindi, Tamil, English, etc.)'}
          </div>
        </div>

        {/* Transcript Box */}
        <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 mb-6 text-sm">
          <div className="text-slate-700 font-semibold mb-1">{transcript || 'Say: "New Delhi se Mumbai Rajdhani"'}</div>
          <p className="text-xs text-amber-800 font-medium">{assistantReply}</p>
        </div>

        {/* Quick Voice Suggestions */}
        <div className="text-left">
          <div className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
            Or tap a voice command:
          </div>
          <div className="space-y-1.5">
            {sampleVoicePrompts.map((p, i) => (
              <button
                key={i}
                type="button"
                onClick={() => {
                  setTranscript(`"${p.text}"`);
                  processVoiceQuery(p.text);
                }}
                className="w-full text-left px-3 py-2 rounded-lg bg-amber-50/60 hover:bg-amber-100 text-xs font-semibold text-amber-950 flex items-center justify-between border border-amber-200/60 transition-colors"
              >
                <span>{p.text}</span>
                <ArrowRight className="w-3.5 h-3.5 text-amber-700" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
