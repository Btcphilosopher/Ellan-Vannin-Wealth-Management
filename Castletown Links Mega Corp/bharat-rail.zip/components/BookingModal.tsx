'use client';

import React from 'react';
import { Train, TravelClass, QuotaType, PNRRecord, Station } from '../lib/railway/types';
import { FareEngine, PNREngine } from '../lib/railway/engine';
import { SupportedLanguage, getTranslation } from '../lib/locales';
import confetti from 'canvas-confetti';
import {
  X,
  User,
  Plus,
  Trash2,
  CreditCard,
  QrCode,
  ShieldCheck,
  CheckCircle2,
  Download,
  Printer,
  Smartphone,
  Sparkles,
  Train as TrainIcon,
} from 'lucide-react';

interface BookingModalProps {
  train: Train;
  fromStation: Station;
  toStation: Station;
  journeyDate: string;
  travelClass: TravelClass;
  quota: QuotaType;
  currentLang: SupportedLanguage;
  onClose: () => void;
  onBookingSuccess: (pnr: PNRRecord) => void;
}

interface PassengerInput {
  name: string;
  age: number;
  gender: 'MALE' | 'FEMALE' | 'TRANSGENDER';
  berthPreference: 'LOWER' | 'MIDDLE' | 'UPPER' | 'SIDE_LOWER' | 'SIDE_UPPER' | 'CABIN' | 'NO_PREF';
  foodPreference: 'VEG' | 'NON_VEG' | 'JAIN' | 'NO_FOOD';
  isSenior?: boolean;
  isDivyangjan?: boolean;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  train,
  fromStation,
  toStation,
  journeyDate,
  travelClass,
  quota,
  currentLang,
  onClose,
  onBookingSuccess,
}) => {
  const t = (key: Parameters<typeof getTranslation>[0]) => getTranslation(key, currentLang);

  const [step, setStep] = React.useState<'PASSENGERS' | 'PAYMENT' | 'CONFIRMATION'>('PASSENGERS');
  const [passengers, setPassengers] = React.useState<PassengerInput[]>([
    {
      name: '',
      age: 32,
      gender: 'MALE',
      berthPreference: 'LOWER',
      foodPreference: 'VEG',
    },
  ]);
  const [contactMobile, setContactMobile] = React.useState('+91 98765 43210');
  const [contactEmail, setContactEmail] = React.useState('passenger@bharatrail.gov.in');
  const [paymentMethod, setPaymentMethod] = React.useState<'UPI' | 'NET_BANKING' | 'CARDS'>('UPI');
  const [isProcessing, setIsProcessing] = React.useState(false);
  const [confirmedPNR, setConfirmedPNR] = React.useState<PNRRecord | null>(null);

  const fareBreakdown = React.useMemo(() => {
    return FareEngine.calculateFare(
      train.totalDistanceKm,
      travelClass,
      quota,
      train.pantried,
      passengers.length,
      passengers.some((p) => p.isSenior),
      passengers.some((p) => p.isDivyangjan)
    );
  }, [train, travelClass, quota, passengers]);

  const addPassenger = () => {
    if (passengers.length < 6) {
      setPassengers([
        ...passengers,
        {
          name: '',
          age: 28,
          gender: 'FEMALE',
          berthPreference: 'LOWER',
          foodPreference: 'VEG',
        },
      ]);
    }
  };

  const removePassenger = (index: number) => {
    if (passengers.length > 1) {
      setPassengers(passengers.filter((_, i) => i !== index));
    }
  };

  const updatePassenger = (index: number, field: keyof PassengerInput, value: any) => {
    const updated = [...passengers];
    updated[index] = { ...updated[index], [field]: value };
    setPassengers(updated);
  };

  const handleProceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (passengers.some((p) => !p.name.trim())) {
      alert('Please fill in names for all passengers.');
      return;
    }
    setStep('PAYMENT');
  };

  const handleProcessBooking = () => {
    setIsProcessing(true);
    setTimeout(() => {
      const pnr = PNREngine.createBooking({
        train,
        journeyDate,
        fromStation,
        toStation,
        travelClass,
        quota,
        passengers,
        contactMobile,
        contactEmail,
      });

      setConfirmedPNR(pnr);
      setIsProcessing(false);
      setStep('CONFIRMATION');
      onBookingSuccess(pnr);

      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch (e) {
        // Safe fallback
      }
    }, 1200);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto">
      <div className="bg-white w-full max-w-3xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto">
        {/* Modal Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white">
              <TrainIcon className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-lg font-serif">{train.names[currentLang] || train.names.en}</h3>
                <span className="px-2 py-0.5 bg-slate-800 text-amber-400 font-mono text-xs font-bold rounded">
                  #{train.number}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                {fromStation.code} → {toStation.code} • {journeyDate} • Class {travelClass} ({quota})
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-7 max-h-[75vh] overflow-y-auto">
          {/* STEP 1: PASSENGERS */}
          {step === 'PASSENGERS' && (
            <form onSubmit={handleProceedToPayment}>
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-bold text-base text-slate-900 flex items-center gap-2">
                  <User className="w-5 h-5 text-amber-600" />
                  <span>Passenger Details ({passengers.length}/6)</span>
                </h4>
                {passengers.length < 6 && (
                  <button
                    type="button"
                    onClick={addPassenger}
                    className="flex items-center gap-1 text-xs font-bold text-amber-700 hover:text-amber-900 bg-amber-50 px-2.5 py-1.5 rounded-lg border border-amber-200 transition-colors"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add Passenger</span>
                  </button>
                )}
              </div>

              <div className="space-y-4 mb-6">
                {passengers.map((passenger, idx) => (
                  <div key={idx} className="p-4 rounded-xl border border-slate-200 bg-slate-50/50 relative">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                        Passenger #{idx + 1}
                      </span>
                      {passengers.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removePassenger(idx)}
                          className="text-red-600 hover:text-red-800 text-xs font-semibold flex items-center gap-1"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                          <span>Remove</span>
                        </button>
                      )}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
                      <div className="sm:col-span-5">
                        <label className="block text-xs font-medium text-slate-600 mb-1">
                          Full Name (as per Govt ID)*
                        </label>
                        <input
                          type="text"
                          required
                          value={passenger.name}
                          placeholder="e.g. Ramesh Sharma"
                          onChange={(e) => updatePassenger(idx, 'name', e.target.value)}
                          className="w-full px-3 py-2 text-sm font-semibold rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-amber-500"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-medium text-slate-600 mb-1">Age</label>
                        <input
                          type="number"
                          min={1}
                          max={110}
                          value={passenger.age}
                          onChange={(e) => updatePassenger(idx, 'age', parseInt(e.target.value, 10))}
                          className="w-full px-3 py-2 text-sm font-semibold rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-amber-500"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-xs font-medium text-slate-600 mb-1">Gender</label>
                        <select
                          value={passenger.gender}
                          onChange={(e) => updatePassenger(idx, 'gender', e.target.value)}
                          className="w-full px-2.5 py-2 text-xs font-semibold rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-amber-500"
                        >
                          <option value="MALE">Male</option>
                          <option value="FEMALE">Female</option>
                          <option value="TRANSGENDER">Other</option>
                        </select>
                      </div>

                      <div className="sm:col-span-3">
                        <label className="block text-xs font-medium text-slate-600 mb-1">Berth Pref</label>
                        <select
                          value={passenger.berthPreference}
                          onChange={(e) => updatePassenger(idx, 'berthPreference', e.target.value)}
                          className="w-full px-2.5 py-2 text-xs font-semibold rounded-lg border border-slate-300 bg-white focus:ring-2 focus:ring-amber-500"
                        >
                          <option value="NO_PREF">No Preference</option>
                          <option value="LOWER">Lower Berth (LB)</option>
                          <option value="MIDDLE">Middle Berth (MB)</option>
                          <option value="UPPER">Upper Berth (UB)</option>
                          <option value="SIDE_LOWER">Side Lower (SLB)</option>
                          <option value="SIDE_UPPER">Side Upper (SUB)</option>
                          <option value="CABIN">Cabin / Coupe</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex flex-wrap items-center gap-4 mt-3 pt-3 border-t border-slate-200/60 text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-medium text-slate-600">Meal:</span>
                        <select
                          value={passenger.foodPreference}
                          onChange={(e) => updatePassenger(idx, 'foodPreference', e.target.value)}
                          className="px-2 py-1 text-xs rounded border border-slate-300 bg-white"
                        >
                          <option value="VEG">Veg Meal</option>
                          <option value="NON_VEG">Non-Veg Meal</option>
                          <option value="JAIN">Jain Meal (No Onion/Garlic)</option>
                          <option value="NO_FOOD">No Catering</option>
                        </select>
                      </div>

                      <label className="flex items-center gap-1.5 text-slate-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={passenger.isSenior}
                          onChange={(e) => updatePassenger(idx, 'isSenior', e.target.checked)}
                          className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                        />
                        <span>Senior Citizen Concession (60+ yrs)</span>
                      </label>

                      <label className="flex items-center gap-1.5 text-slate-700 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={passenger.isDivyangjan}
                          onChange={(e) => updatePassenger(idx, 'isDivyangjan', e.target.checked)}
                          className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                        />
                        <span>Divyangjan (Differently Abled)</span>
                      </label>
                    </div>
                  </div>
                ))}
              </div>

              {/* Contact Information */}
              <div className="border-t border-slate-200 pt-4 mb-6">
                <h4 className="font-bold text-sm text-slate-800 mb-3 flex items-center gap-2">
                  <Smartphone className="w-4 h-4 text-amber-600" />
                  <span>Ticket Delivery & SMS Updates</span>
                </h4>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Mobile Number (SMS Updates)</label>
                    <input
                      type="tel"
                      required
                      value={contactMobile}
                      onChange={(e) => setContactMobile(e.target.value)}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 mb-1">Email ID (PDF E-Ticket)</label>
                    <input
                      type="email"
                      required
                      value={contactEmail}
                      onChange={(e) => setContactEmail(e.target.value)}
                      className="w-full px-3 py-2 text-sm rounded-lg border border-slate-300 bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Fare Summary & CTA */}
              <div className="bg-amber-50/70 rounded-xl p-4 border border-amber-200 flex flex-wrap items-center justify-between gap-4">
                <div>
                  <div className="text-xs text-amber-900 font-medium">
                    Total Estimated Fare ({passengers.length} Passenger{passengers.length > 1 ? 's' : ''})
                  </div>
                  <div className="text-2xl font-black text-slate-900 font-mono">
                    ₹{fareBreakdown.totalFare}
                  </div>
                </div>
                <button
                  id="proceed-to-pay-button"
                  type="submit"
                  className="px-6 py-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold text-sm rounded-xl shadow-md transition-all"
                >
                  Proceed to Payment →
                </button>
              </div>
            </form>
          )}

          {/* STEP 2: PAYMENT */}
          {step === 'PAYMENT' && (
            <div>
              <h4 className="font-bold text-base text-slate-900 mb-4 flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-amber-600" />
                <span>Select Payment Mode (Simulated Gateway)</span>
              </h4>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-6">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('UPI')}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    paymentMethod === 'UPI'
                      ? 'border-amber-600 bg-amber-50/80 font-bold text-amber-950'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <QrCode className="w-5 h-5 text-amber-600" />
                    <span>Instant UPI</span>
                  </div>
                  <p className="text-xs text-slate-500">Google Pay, PhonePe, Paytm, BHIM</p>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('NET_BANKING')}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    paymentMethod === 'NET_BANKING'
                      ? 'border-amber-600 bg-amber-50/80 font-bold text-amber-950'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <ShieldCheck className="w-5 h-5 text-amber-600" />
                    <span>Net Banking</span>
                  </div>
                  <p className="text-xs text-slate-500">SBI, HDFC, ICICI, Axis, PNB</p>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('CARDS')}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    paymentMethod === 'CARDS'
                      ? 'border-amber-600 bg-amber-50/80 font-bold text-amber-950'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <CreditCard className="w-5 h-5 text-amber-600" />
                    <span>Credit / Debit Card</span>
                  </div>
                  <p className="text-xs text-slate-500">RuPay, Visa, Mastercard</p>
                </button>
              </div>

              {/* Detailed Breakdown */}
              <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 mb-6 text-xs space-y-1.5">
                <div className="flex justify-between text-slate-600">
                  <span>Base Rail Fare ({passengers.length} Pax):</span>
                  <span className="font-mono">₹{fareBreakdown.baseFare}</span>
                </div>
                <div className="flex justify-between text-slate-600">
                  <span>Reservation & Superfast Charges:</span>
                  <span className="font-mono">₹{fareBreakdown.reservationCharge + fareBreakdown.superfastCharge}</span>
                </div>
                {fareBreakdown.tatkalCharge > 0 && (
                  <div className="flex justify-between text-amber-700">
                    <span>Tatkal Surcharge ({quota}):</span>
                    <span className="font-mono">₹{fareBreakdown.tatkalCharge}</span>
                  </div>
                )}
                {fareBreakdown.cateringCharge > 0 && (
                  <div className="flex justify-between text-slate-600">
                    <span>IRCTC Pantry Catering:</span>
                    <span className="font-mono">₹{fareBreakdown.cateringCharge}</span>
                  </div>
                )}
                {fareBreakdown.concessionDiscount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>Senior / Divyangjan Concession:</span>
                    <span className="font-mono">-₹{fareBreakdown.concessionDiscount}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>GST (5% on AC Classes):</span>
                  <span className="font-mono">₹{fareBreakdown.gstAmount}</span>
                </div>
                <div className="border-t border-slate-200 pt-2 flex justify-between font-bold text-sm text-slate-900">
                  <span>Grand Total:</span>
                  <span className="font-mono text-base text-amber-800">₹{fareBreakdown.totalFare}</span>
                </div>
              </div>

              <div className="flex items-center justify-between gap-4">
                <button
                  type="button"
                  onClick={() => setStep('PASSENGERS')}
                  className="px-4 py-2 text-sm font-semibold text-slate-600 hover:text-slate-900"
                >
                  ← Back to Details
                </button>

                <button
                  id="pay-and-confirm-button"
                  type="button"
                  disabled={isProcessing}
                  onClick={handleProcessBooking}
                  className="flex items-center gap-2 px-7 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-sm rounded-xl shadow-md transition-all disabled:opacity-50"
                >
                  {isProcessing ? (
                    <span>Allocating Berths & Generating PNR...</span>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Pay ₹{fareBreakdown.totalFare} & Generate Ticket</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: CONFIRMATION */}
          {step === 'CONFIRMATION' && confirmedPNR && (
            <div className="text-center py-4">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-10 h-10" />
              </div>

              <h4 className="text-2xl font-black text-slate-900 font-serif mb-1">
                Booking Confirmed!
              </h4>
              <p className="text-xs text-slate-500 mb-6">
                Electronic Reservation Slip (ERS) dispatched to {confirmedPNR.contactMobile} and {confirmedPNR.contactEmail}
              </p>

              {/* Digital Boarding Pass */}
              <div className="bg-gradient-to-br from-amber-50 to-orange-50/40 rounded-2xl p-6 border-2 border-amber-300 text-left max-w-lg mx-auto shadow-md mb-6">
                <div className="flex justify-between items-start border-b border-amber-200 pb-3 mb-4">
                  <div>
                    <div className="text-xs font-bold text-amber-900 uppercase tracking-widest">
                      PNR NUMBER
                    </div>
                    <div className="text-2xl font-black font-mono text-slate-950">
                      {confirmedPNR.pnrNumber}
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="px-2.5 py-1 bg-emerald-600 text-white font-bold text-xs rounded-md">
                      {confirmedPNR.bookingStatus}
                    </span>
                    <div className="text-[10px] text-slate-500 mt-1 font-mono">{confirmedPNR.digitalTicketId}</div>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs mb-4">
                  <div>
                    <span className="text-slate-500 block">Train:</span>
                    <span className="font-bold text-slate-900">{confirmedPNR.trainName} (#{confirmedPNR.trainNumber})</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Date & Class:</span>
                    <span className="font-bold text-slate-900">{confirmedPNR.journeyDate} • {confirmedPNR.travelClass} ({confirmedPNR.quota})</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Route:</span>
                    <span className="font-bold text-slate-900">{confirmedPNR.fromStationCode} → {confirmedPNR.toStationCode}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Total Fare Paid:</span>
                    <span className="font-bold font-mono text-slate-900">₹{confirmedPNR.fareBreakdown.totalFare}</span>
                  </div>
                </div>

                {/* Passenger Seats */}
                <div className="border-t border-amber-200 pt-3">
                  <div className="text-xs font-bold text-slate-700 mb-2">Allocated Berths:</div>
                  <div className="space-y-1.5">
                    {confirmedPNR.passengers.map((p, i) => (
                      <div key={i} className="flex justify-between items-center text-xs bg-white/80 p-2 rounded-lg border border-amber-100">
                        <span className="font-semibold text-slate-900">{p.name} ({p.age}, {p.gender[0]})</span>
                        <span className="font-mono font-bold text-emerald-800 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                          {p.assignedCoach ? `${p.assignedCoach} / Berth ${p.assignedBerth}` : p.assignedBerth}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => window.print()}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold shadow-sm"
                >
                  <Printer className="w-4 h-4" />
                  <span>Print Ticket</span>
                </button>

                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold shadow-sm"
                >
                  Done
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
