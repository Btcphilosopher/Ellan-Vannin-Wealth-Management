'use client';

import React from 'react';
import { SupportedLanguage, getTranslation } from '../lib/locales';
import { LanguageSelector } from './LanguageSelector';
import {
  Train,
  Ticket,
  Activity,
  MapPin,
  Compass,
  AlertTriangle,
  PhoneCall,
  Mic,
  Clock,
  Accessibility,
  Sparkles,
} from 'lucide-react';

export type NavTab = 'SEARCH' | 'PNR' | 'LIVE' | 'STATIONS' | 'TOURISM' | 'DISRUPTIONS';

interface HeaderProps {
  currentLang: SupportedLanguage;
  onSelectLanguage: (lang: SupportedLanguage) => void;
  activeTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  onOpenVoiceSearch: () => void;
  highContrast: boolean;
  onToggleHighContrast: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentLang,
  onSelectLanguage,
  activeTab,
  onSelectTab,
  onOpenVoiceSearch,
  highContrast,
  onToggleHighContrast,
}) => {
  const [istTime, setIstTime] = React.useState<string>('');

  React.useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const options: Intl.DateTimeFormatOptions = {
        timeZone: 'Asia/Kolkata',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true,
      };
      setIstTime(now.toLocaleTimeString('en-IN', options) + ' IST');
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const t = (key: Parameters<typeof getTranslation>[0]) => getTranslation(key, currentLang);

  const navItems = [
    { id: 'SEARCH' as NavTab, label: t('bookTickets'), icon: Train },
    { id: 'PNR' as NavTab, label: t('pnrStatus'), icon: Ticket },
    { id: 'LIVE' as NavTab, label: t('liveTrainStatus'), icon: Activity },
    { id: 'STATIONS' as NavTab, label: t('stationInformation'), icon: MapPin },
    { id: 'TOURISM' as NavTab, label: t('tourismCircuits'), icon: Compass },
    { id: 'DISRUPTIONS' as NavTab, label: t('disruptionAdvisories'), icon: AlertTriangle },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-xs">
      {/* Top Ministry Bar */}
      <div className="bg-slate-900 text-slate-300 text-xs px-4 py-1.5 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="inline-flex items-center gap-1 font-semibold text-amber-400">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            GOVERNMENT OF INDIA
          </span>
          <span className="text-slate-500">|</span>
          <span className="hidden sm:inline text-slate-300">Ministry of Railways & Indian Railway Catering and Tourism</span>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5 text-slate-300">
            <Clock className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-mono text-xs">{istTime || 'Loading IST...'}</span>
          </div>

          <a
            href="tel:139"
            className="flex items-center gap-1 text-emerald-400 hover:text-emerald-300 font-medium transition-colors"
            title="24x7 Rail Madad Passenger Helpline"
          >
            <PhoneCall className="w-3 h-3" />
            <span>Rail Madad 139</span>
          </a>

          <button
            onClick={onToggleHighContrast}
            className={`flex items-center gap-1 px-1.5 py-0.5 rounded text-xs transition-colors ${
              highContrast ? 'bg-amber-400 text-slate-950 font-bold' : 'hover:bg-slate-800 text-slate-300'
            }`}
            title="Toggle High Contrast & Accessibility Display"
          >
            <Accessibility className="w-3 h-3" />
            <span className="hidden md:inline">{highContrast ? 'Standard Mode' : 'High Contrast'}</span>
          </button>
        </div>
      </div>

      {/* Main Branding Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
        {/* Logo & National Identity */}
        <div className="flex items-center gap-3 cursor-pointer" onClick={() => onSelectTab('SEARCH')}>
          <div className="w-11 h-11 rounded-xl bg-gradient-to-tr from-amber-600 via-orange-600 to-amber-700 flex items-center justify-center text-white shadow-md ring-2 ring-amber-500/20">
            <Train className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-bold tracking-tight text-slate-900 font-serif">BHARAT RAIL</span>
              <span className="px-2 py-0.5 text-[10px] font-bold uppercase bg-amber-100 text-amber-900 rounded-md border border-amber-300">
                National Portal
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              {t('brandTagline')} • भारतीय रेल यात्री मंच
            </p>
          </div>
        </div>

        {/* Action Controls: Voice + Multilingual */}
        <div className="flex items-center gap-2 sm:gap-3">
          <button
            id="voice-assistant-trigger"
            type="button"
            onClick={onOpenVoiceSearch}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-orange-50 to-amber-50 hover:from-orange-100 hover:to-amber-100 text-amber-900 border border-amber-300 rounded-lg text-sm font-semibold transition-all shadow-xs"
            title="Ask Bharat Rail Voice Assistant in your language"
          >
            <Mic className="w-4 h-4 text-orange-600 animate-pulse" />
            <span className="hidden sm:inline">Voice Assistant</span>
          </button>

          <LanguageSelector currentLang={currentLang} onSelectLanguage={onSelectLanguage} />
        </div>
      </div>

      {/* Navigation Sub-bar */}
      <div className="border-t border-slate-100 bg-slate-50/75">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex overflow-x-auto no-scrollbar space-x-1 sm:space-x-2 py-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-tab-${item.id.toLowerCase()}`}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-sm font-medium whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-amber-600 text-white shadow-xs font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/60'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-500'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
