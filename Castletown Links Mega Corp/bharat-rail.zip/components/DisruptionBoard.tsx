'use client';

import React from 'react';
import { DISRUPTIONS } from '../lib/railway/data';
import { SupportedLanguage, getTranslation } from '../lib/locales';
import { AlertTriangle, ShieldCheck, CheckCircle2, CloudFog, Wrench, ArrowRight } from 'lucide-react';

interface DisruptionBoardProps {
  currentLang: SupportedLanguage;
}

export const DisruptionBoard: React.FC<DisruptionBoardProps> = ({ currentLang }) => {
  const t = (key: Parameters<typeof getTranslation>[0]) => getTranslation(key, currentLang);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-5 sm:p-7">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white shadow-xs">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-serif">
              {t('disruptionAdvisories')} & Safety Bulletins
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Official Indian Railways real-time operational bulletins, weather fog advisories, and planned maintenance blocks
            </p>
          </div>
        </div>
      </div>

      {/* Advisories Grid */}
      <div className="space-y-4">
        {DISRUPTIONS.map((alert) => {
          const localizedTitle = alert.titles[currentLang] || alert.titles.en;
          const localizedDesc = alert.descriptions[currentLang] || alert.descriptions.en;
          const isCritical = alert.severity === 'CRITICAL';
          const isWarning = alert.severity === 'WARNING';

          return (
            <div
              key={alert.id}
              className={`p-5 sm:p-6 rounded-2xl border shadow-xs transition-all ${
                isCritical
                  ? 'bg-red-50/60 border-red-300'
                  : isWarning
                  ? 'bg-amber-50/60 border-amber-300'
                  : 'bg-emerald-50/60 border-emerald-300'
              }`}
            >
              <div className="flex flex-wrap items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-2.5">
                  <div
                    className={`w-9 h-9 rounded-xl flex items-center justify-center ${
                      isWarning ? 'bg-amber-200 text-amber-900' : 'bg-emerald-200 text-emerald-900'
                    }`}
                  >
                    {alert.type === 'WEATHER_FOG' ? (
                      <CloudFog className="w-5 h-5" />
                    ) : (
                      <Wrench className="w-5 h-5" />
                    )}
                  </div>
                  <div>
                    <span
                      className={`px-2 py-0.5 text-[10px] font-black uppercase tracking-wider rounded ${
                        isWarning ? 'bg-amber-200 text-amber-900' : 'bg-emerald-200 text-emerald-900'
                      }`}
                    >
                      {alert.severity} • {alert.zone} ZONE
                    </span>
                    <h3 className="text-base font-bold text-slate-900 mt-0.5">{localizedTitle}</h3>
                  </div>
                </div>

                <div className="text-xs text-slate-500 font-mono">
                  Valid: {new Date(alert.validFrom).toLocaleDateString()} – {new Date(alert.validUntil).toLocaleDateString()}
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-700 leading-relaxed mb-4">
                {localizedDesc}
              </p>

              <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-200/60 text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-600">Affected Train Numbers:</span>
                  {alert.affectedTrainNumbers.map((num) => (
                    <span key={num} className="px-2 py-0.5 bg-white font-mono font-bold rounded border border-slate-300 text-slate-800">
                      #{num}
                    </span>
                  ))}
                </div>

                <div className="text-amber-800 font-semibold flex items-center gap-1">
                  <ShieldCheck className="w-4 h-4 text-emerald-600" />
                  <span>{alert.alternativeSuggestion}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
