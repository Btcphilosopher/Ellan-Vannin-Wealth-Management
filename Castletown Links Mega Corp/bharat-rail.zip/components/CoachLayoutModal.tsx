'use client';

import React from 'react';
import { Train } from '../lib/railway/types';
import { SupportedLanguage } from '../lib/locales';
import { X, Layers, Train as TrainIcon, Utensils, ShieldCheck, ArrowRight } from 'lucide-react';

interface CoachLayoutModalProps {
  train: Train;
  currentLang: SupportedLanguage;
  onClose: () => void;
}

export const CoachLayoutModal: React.FC<CoachLayoutModalProps> = ({
  train,
  currentLang,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-4xl rounded-2xl shadow-2xl border border-slate-200 overflow-hidden my-auto max-h-[85vh] flex flex-col">
        {/* Header */}
        <div className="bg-slate-900 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-lg font-serif">
                Coach Position & Rake Layout - {train.names[currentLang] || train.names.en} (#{train.number})
              </h3>
              <p className="text-xs text-slate-400">
                LHB Coach Sequence • Distance from Electric Locomotive (WAP-7 / Vande Bharat DTC)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Coach Train Rake Schematic */}
        <div className="p-6 overflow-y-auto flex-1">
          <div className="mb-4 flex items-center justify-between text-xs text-slate-500 font-medium border-b border-slate-100 pb-2">
            <span>← Locomotive Engine (Front)</span>
            <span>Guard Car / Rear Power (End) →</span>
          </div>

          <div className="overflow-x-auto pb-4 mb-6">
            <div className="flex items-center gap-2 min-w-max p-2 bg-slate-100/70 rounded-2xl border border-slate-200">
              {train.composition.map((coach, idx) => {
                const isLoco = coach.coachType === 'LOCO';
                const isPantry = coach.coachType === 'PANTRY';
                const isAC1 = coach.coachType === '1A' || coach.coachType === 'EC';

                return (
                  <div
                    key={idx}
                    className={`p-3 rounded-xl border flex flex-col items-center justify-center text-center w-24 min-h-[90px] shadow-2xs transition-transform hover:scale-105 ${
                      isLoco
                        ? 'bg-red-900 text-white border-red-700 font-bold'
                        : isPantry
                        ? 'bg-amber-100 text-amber-950 border-amber-300 font-bold'
                        : isAC1
                        ? 'bg-blue-900 text-white border-blue-700 font-bold'
                        : 'bg-white text-slate-800 border-slate-300'
                    }`}
                  >
                    <div className="font-mono text-sm font-black">{coach.coachNumber}</div>
                    <div className="text-[10px] mt-1 font-medium leading-tight line-clamp-2">
                      {coach.displayName}
                    </div>
                    <div className="text-[9px] text-slate-400 mt-1 font-mono">
                      {coach.distanceFromEngineMeters}m
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Detailed Specifications */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50">
              <h4 className="font-bold text-slate-900 mb-2">Berth Code Terminology:</h4>
              <ul className="space-y-1 text-slate-600">
                <li>• <strong>LB:</strong> Lower Berth (Preferred for Seniors & Divyangjan)</li>
                <li>• <strong>MB:</strong> Middle Berth</li>
                <li>• <strong>UB:</strong> Upper Berth</li>
                <li>• <strong>SLB / SUB:</strong> Side Lower / Side Upper Berth</li>
                <li>• <strong>WS / AS:</strong> Window Seat / Aisle Seat (Vande Bharat & Shatabdi)</li>
              </ul>
            </div>

            <div className="p-4 rounded-xl border border-slate-200 bg-slate-50">
              <h4 className="font-bold text-slate-900 mb-2">Rake Safety & Specs:</h4>
              <ul className="space-y-1 text-slate-600">
                <li>• <strong>Coach Standard:</strong> LHB Stainless Steel Anti-Telescopic Rakes</li>
                <li>• <strong>Braking:</strong> Electro-Pneumatic Disc Brakes with ABS</li>
                <li>• <strong>Catering:</strong> Flame-less IRCTC Induction Modular Pantry</li>
                <li>• <strong>Emergency:</strong> CCTV, Bio-Vacuum Toilets & Emergency Alarm Chains</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
