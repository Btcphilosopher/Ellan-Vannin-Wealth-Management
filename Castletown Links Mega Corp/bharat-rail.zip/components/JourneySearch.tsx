'use client';

import React from 'react';
import { Station, TravelClass, QuotaType } from '../lib/railway/types';
import { STATIONS } from '../lib/railway/data';
import { SupportedLanguage, getTranslation } from '../lib/locales';
import { ArrowLeftRight, Calendar, Search, ShieldCheck, Sparkles, Filter } from 'lucide-react';

interface JourneySearchProps {
  currentLang: SupportedLanguage;
  fromStation: Station;
  toStation: Station;
  journeyDate: string;
  quota: QuotaType;
  selectedClass: string;
  onFromStationChange: (station: Station) => void;
  onToStationChange: (station: Station) => void;
  onJourneyDateChange: (date: string) => void;
  onQuotaChange: (quota: QuotaType) => void;
  onSelectedClassChange: (cls: string) => void;
  onSearch: () => void;
}

export const JourneySearch: React.FC<JourneySearchProps> = ({
  currentLang,
  fromStation,
  toStation,
  journeyDate,
  quota,
  selectedClass,
  onFromStationChange,
  onToStationChange,
  onJourneyDateChange,
  onQuotaChange,
  onSelectedClassChange,
  onSearch,
}) => {
  const [fromSearchQuery, setFromSearchQuery] = React.useState('');
  const [toSearchQuery, setToSearchQuery] = React.useState('');
  const [showFromDropdown, setShowFromDropdown] = React.useState(false);
  const [showToDropdown, setShowToDropdown] = React.useState(false);

  const t = (key: Parameters<typeof getTranslation>[0]) => getTranslation(key, currentLang);

  const handleSwap = () => {
    const temp = fromStation;
    onFromStationChange(toStation);
    onToStationChange(temp);
  };

  const getStationLabel = (s: Station) => {
    const localizedName = s.names[currentLang] || s.names.en;
    return `${localizedName} (${s.code}) - ${s.state}`;
  };

  const filteredFromStations = STATIONS.filter(
    (s) =>
      s.code.toLowerCase().includes(fromSearchQuery.toLowerCase()) ||
      (s.names[currentLang] || '').toLowerCase().includes(fromSearchQuery.toLowerCase()) ||
      s.names.en.toLowerCase().includes(fromSearchQuery.toLowerCase()) ||
      s.state.toLowerCase().includes(fromSearchQuery.toLowerCase())
  );

  const filteredToStations = STATIONS.filter(
    (s) =>
      s.code.toLowerCase().includes(toSearchQuery.toLowerCase()) ||
      (s.names[currentLang] || '').toLowerCase().includes(toSearchQuery.toLowerCase()) ||
      s.names.en.toLowerCase().includes(toSearchQuery.toLowerCase()) ||
      s.state.toLowerCase().includes(toSearchQuery.toLowerCase())
  );

  const setQuickDate = (daysAhead: number) => {
    const d = new Date();
    d.setDate(d.getDate() + daysAhead);
    const yyyy = d.getFullYear();
    const mm = String(d.getMonth() + 1).padStart(2, '0');
    const dd = String(d.getDate()).padStart(2, '0');
    onJourneyDateChange(`${yyyy}-${mm}-${dd}`);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-5 sm:p-7">
      <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-5">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-serif">
            {t('bookTickets')}
          </h2>
          <p className="text-xs sm:text-sm text-slate-500 mt-0.5">
            Real-time Indian Railways seat availability, Tatkal booking & Vande Bharat superfast routes
          </p>
        </div>
        <div className="hidden md:flex items-center gap-2 px-3 py-1.5 bg-amber-50 rounded-lg text-amber-800 text-xs font-semibold border border-amber-200">
          <ShieldCheck className="w-4 h-4 text-amber-600" />
          <span>Kavach 4.0 ATP Protected Network</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-end">
        {/* Origin Station */}
        <div className="md:col-span-4 relative">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
            {t('fromStation')}
          </label>
          <div className="relative">
            <input
              id="from-station-input"
              type="text"
              value={showFromDropdown ? fromSearchQuery : getStationLabel(fromStation)}
              onChange={(e) => {
                setFromSearchQuery(e.target.value);
                setShowFromDropdown(true);
              }}
              onFocus={() => {
                setFromSearchQuery('');
                setShowFromDropdown(true);
              }}
              placeholder="Enter station or code (e.g. NDLS)"
              className="w-full px-3.5 py-3 rounded-xl border border-slate-300 text-slate-900 bg-slate-50/50 hover:bg-white focus:bg-white text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
            />
          </div>

          {showFromDropdown && (
            <div className="absolute z-30 mt-1 w-full bg-white border border-slate-200 rounded-xl shadow-2xl max-h-64 overflow-y-auto p-1.5">
              {filteredFromStations.map((s) => (
                <button
                  key={s.code}
                  type="button"
                  onClick={() => {
                    onFromStationChange(s);
                    setShowFromDropdown(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs rounded-lg hover:bg-amber-50 hover:text-amber-900 flex justify-between items-center transition-colors"
                >
                  <div>
                    <span className="font-bold text-slate-800">{s.names[currentLang] || s.names.en}</span>
                    <span className="text-slate-500 ml-1">({s.names.en})</span>
                  </div>
                  <span className="px-1.5 py-0.5 bg-slate-100 font-mono text-[10px] font-bold text-slate-700 rounded">
                    {s.code}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Station Swap Button */}
        <div className="md:col-span-1 flex justify-center pb-2">
          <button
            id="swap-stations-button"
            type="button"
            onClick={handleSwap}
            className="w-10 h-10 rounded-full border border-slate-200 bg-slate-100 hover:bg-amber-100 text-slate-700 hover:text-amber-800 flex items-center justify-center transition-transform hover:rotate-180 duration-300 shadow-xs"
            title="Swap Origin and Destination"
          >
            <ArrowLeftRight className="w-4 h-4" />
          </button>
        </div>

        {/* Destination Station */}
        <div className="md:col-span-4 relative">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
            {t('toStation')}
          </label>
          <div className="relative">
            <input
              id="to-station-input"
              type="text"
              value={showToDropdown ? toSearchQuery : getStationLabel(toStation)}
              onChange={(e) => {
                setToSearchQuery(e.target.value);
                setShowToDropdown(true);
              }}
              onFocus={() => {
                setToSearchQuery('');
                setShowToDropdown(true);
              }}
              placeholder="Enter destination (e.g. MMCT, BSB)"
              className="w-full px-3.5 py-3 rounded-xl border border-slate-300 text-slate-900 bg-slate-50/50 hover:bg-white focus:bg-white text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
            />
          </div>

          {showToDropdown && (
            <div className="absolute z-30 mt-1 w-full bg-white border border-slate-200 rounded-xl shadow-2xl max-h-64 overflow-y-auto p-1.5">
              {filteredToStations.map((s) => (
                <button
                  key={s.code}
                  type="button"
                  onClick={() => {
                    onToStationChange(s);
                    setShowToDropdown(false);
                  }}
                  className="w-full text-left px-3 py-2 text-xs rounded-lg hover:bg-amber-50 hover:text-amber-900 flex justify-between items-center transition-colors"
                >
                  <div>
                    <span className="font-bold text-slate-800">{s.names[currentLang] || s.names.en}</span>
                    <span className="text-slate-500 ml-1">({s.names.en})</span>
                  </div>
                  <span className="px-1.5 py-0.5 bg-slate-100 font-mono text-[10px] font-bold text-slate-700 rounded">
                    {s.code}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Journey Date */}
        <div className="md:col-span-3">
          <label className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1.5">
            {t('journeyDate')}
          </label>
          <div className="relative">
            <input
              id="journey-date-input"
              type="date"
              value={journeyDate}
              min={new Date().toISOString().split('T')[0]}
              onChange={(e) => onJourneyDateChange(e.target.value)}
              className="w-full px-3.5 py-3 rounded-xl border border-slate-300 text-slate-900 bg-slate-50/50 hover:bg-white focus:bg-white text-sm font-semibold focus:outline-none focus:ring-2 focus:ring-amber-500 transition-all"
            />
          </div>
        </div>
      </div>

      {/* Quick Date Pills & Filters */}
      <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-4 border-t border-slate-100">
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-500 font-medium">Quick Dates:</span>
          <button
            type="button"
            onClick={() => setQuickDate(0)}
            className="px-2.5 py-1 text-xs font-semibold rounded-md bg-slate-100 hover:bg-amber-100 text-slate-700 hover:text-amber-900 transition-colors"
          >
            Today
          </button>
          <button
            type="button"
            onClick={() => setQuickDate(1)}
            className="px-2.5 py-1 text-xs font-semibold rounded-md bg-slate-100 hover:bg-amber-100 text-slate-700 hover:text-amber-900 transition-colors"
          >
            Tomorrow
          </button>
          <button
            type="button"
            onClick={() => setQuickDate(3)}
            className="px-2.5 py-1 text-xs font-semibold rounded-md bg-slate-100 hover:bg-amber-100 text-slate-700 hover:text-amber-900 transition-colors"
          >
            +3 Days
          </button>
        </div>

        {/* Quota & Class Selector */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1.5">
            <label className="text-xs font-medium text-slate-600">{t('quota')}:</label>
            <select
              id="quota-select"
              value={quota}
              onChange={(e) => onQuotaChange(e.target.value as QuotaType)}
              className="px-2.5 py-1 text-xs font-semibold rounded-lg border border-slate-300 bg-white text-slate-800 focus:ring-2 focus:ring-amber-500"
            >
              <option value="GN">{t('generalQuota')} (GN)</option>
              <option value="TQ">{t('tatkalQuota')} (TQ)</option>
              <option value="PT">Premium Tatkal (PT)</option>
              <option value="LD">{t('ladiesQuota')} (LD)</option>
              <option value="SS">{t('seniorCitizenQuota')} (SS)</option>
              <option value="HP">{t('divyangjanQuota')} (HP)</option>
              <option value="FT">Foreign Tourist (FT)</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <label className="text-xs font-medium text-slate-600">{t('travelClass')}:</label>
            <select
              id="class-filter-select"
              value={selectedClass}
              onChange={(e) => onSelectedClassChange(e.target.value)}
              className="px-2.5 py-1 text-xs font-semibold rounded-lg border border-slate-300 bg-white text-slate-800 focus:ring-2 focus:ring-amber-500"
            >
              <option value="ALL">All Travel Classes</option>
              <option value="1A">First AC (1A)</option>
              <option value="2A">AC 2 Tier (2A)</option>
              <option value="3A">AC 3 Tier (3A)</option>
              <option value="3E">3 AC Economy (3E)</option>
              <option value="EC">Executive Class (EC)</option>
              <option value="CC">AC Chair Car (CC)</option>
              <option value="SL">Sleeper Class (SL)</option>
              <option value="2S">Second Sitting (2S)</option>
            </select>
          </div>

          <button
            id="search-trains-submit-button"
            type="button"
            onClick={onSearch}
            className="flex items-center gap-2 px-6 py-2.5 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold text-sm rounded-xl shadow-md hover:shadow-lg transition-all"
          >
            <Search className="w-4 h-4" />
            <span>{t('searchTrains')}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
