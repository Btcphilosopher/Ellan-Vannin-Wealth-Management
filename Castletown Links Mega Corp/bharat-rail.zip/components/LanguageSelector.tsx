'use client';

import React from 'react';
import { SupportedLanguage, SUPPORTED_LANGUAGES, getLanguageMetadata } from '../lib/locales';
import { Globe, Check } from 'lucide-react';

interface LanguageSelectorProps {
  currentLang: SupportedLanguage;
  onSelectLanguage: (lang: SupportedLanguage) => void;
}

export const LanguageSelector: React.FC<LanguageSelectorProps> = ({
  currentLang,
  onSelectLanguage,
}) => {
  const [isOpen, setIsOpen] = React.useState(false);
  const dropdownRef = React.useRef<HTMLDivElement>(null);

  React.useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const currentMeta = getLanguageMetadata(currentLang);

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        id="language-selector-button"
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-haspopup="true"
        className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-800 text-sm font-medium shadow-xs transition-colors focus:outline-none focus:ring-2 focus:ring-amber-500"
      >
        <Globe className="w-4 h-4 text-amber-700" />
        <span className="font-semibold">{currentMeta.nativeName}</span>
        <span className="text-xs text-slate-500">({currentMeta.code.toUpperCase()})</span>
      </button>

      {isOpen && (
        <div
          id="language-dropdown-menu"
          className="origin-top-right absolute right-0 mt-2 w-72 rounded-xl shadow-xl bg-white border border-slate-200 ring-1 ring-black/5 z-50 p-2 max-h-96 overflow-y-auto"
          role="menu"
        >
          <div className="px-3 py-2 text-xs font-semibold text-slate-400 uppercase tracking-wider border-b border-slate-100">
            Select Rail Language / भाषा चुनें (13)
          </div>
          <div className="grid grid-cols-1 gap-1 mt-1">
            {SUPPORTED_LANGUAGES.map((lang) => {
              const isSelected = currentLang === lang.code;
              return (
                <button
                  key={lang.code}
                  id={`lang-option-${lang.code}`}
                  onClick={() => {
                    onSelectLanguage(lang.code);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2 text-sm rounded-lg transition-colors ${
                    isSelected
                      ? 'bg-amber-50 text-amber-900 font-semibold'
                      : 'text-slate-700 hover:bg-slate-100'
                  }`}
                  role="menuitem"
                >
                  <div className="flex flex-col text-left">
                    <span className="text-base">{lang.nativeName}</span>
                    <span className="text-xs text-slate-500">{lang.name}</span>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-amber-700" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
