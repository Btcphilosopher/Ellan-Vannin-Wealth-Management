'use client';

import React from 'react';
import { TourismCircuit, Station } from '../lib/railway/types';
import { TOURISM_CIRCUITS, STATIONS } from '../lib/railway/data';
import { SupportedLanguage, getTranslation } from '../lib/locales';
import { Compass, Train, Clock, MapPin, CheckCircle2, ArrowRight } from 'lucide-react';

interface TourismGuideProps {
  currentLang: SupportedLanguage;
  onSelectCircuitForBooking: (fromStationCode: string, toStationCode: string) => void;
}

export const TourismGuide: React.FC<TourismGuideProps> = ({
  currentLang,
  onSelectCircuitForBooking,
}) => {
  const t = (key: Parameters<typeof getTranslation>[0]) => getTranslation(key, currentLang);

  return (
    <div className="space-y-6">
      {/* Hero Header */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-md p-5 sm:p-7">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-amber-600 flex items-center justify-center text-white shadow-xs">
            <Compass className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-slate-900 font-serif">
              {t('tourismCircuits')} & Bharat Gaurav Rail Itineraries
            </h2>
            <p className="text-xs sm:text-sm text-slate-500">
              Curated spiritual, coastal, and heritage rail journeys connecting UNESCO monuments, Western Ghats, and sacred shrines
            </p>
          </div>
        </div>
      </div>

      {/* Circuit Cards */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {TOURISM_CIRCUITS.map((circuit) => {
          const localizedName = circuit.name[currentLang] || circuit.name.en;
          const localizedDesc = circuit.description[currentLang] || circuit.description.en;
          const fromCode = circuit.keyStations[0];
          const toCode = circuit.keyStations[circuit.keyStations.length - 1];

          return (
            <div
              key={circuit.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-md overflow-hidden flex flex-col justify-between hover:shadow-lg transition-all"
            >
              {/* Header Gradient */}
              <div className="bg-gradient-to-br from-slate-900 via-amber-950 to-slate-900 text-white p-6">
                <span className="px-2.5 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/40 text-[10px] font-black uppercase tracking-widest rounded-md inline-block mb-3">
                  {circuit.tag}
                </span>
                <h3 className="text-lg sm:text-xl font-bold font-serif mb-2 leading-tight">
                  {localizedName}
                </h3>
                <div className="flex items-center gap-2 text-xs text-slate-300 font-medium">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  <span>Duration: {circuit.durationDays}</span>
                </div>
              </div>

              {/* Body */}
              <div className="p-6 flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-xs text-slate-600 leading-relaxed mb-4">
                    {localizedDesc}
                  </p>

                  <div className="mb-4">
                    <div className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                      Key Rail Corridor Stations:
                    </div>
                    <div className="flex flex-wrap items-center gap-1.5">
                      {circuit.keyStations.map((code, idx) => {
                        const st = STATIONS.find((s) => s.code === code);
                        return (
                          <React.Fragment key={code}>
                            <span className="px-2 py-1 bg-amber-50 text-amber-900 font-bold text-xs rounded border border-amber-200">
                              {st?.names[currentLang] || code} ({code})
                            </span>
                            {idx < circuit.keyStations.length - 1 && (
                              <ArrowRight className="w-3 h-3 text-slate-400" />
                            )}
                          </React.Fragment>
                        );
                      })}
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                      Highlights:
                    </div>
                    <ul className="space-y-1">
                      {circuit.highlights.map((h, i) => (
                        <li key={i} className="text-xs text-slate-600 flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                          <span>{h}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-100">
                  <button
                    type="button"
                    onClick={() => onSelectCircuitForBooking(fromCode, toCode)}
                    className="w-full flex items-center justify-center gap-2 py-2.5 px-4 bg-gradient-to-r from-amber-600 to-orange-600 hover:from-amber-700 hover:to-orange-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all"
                  >
                    <Train className="w-4 h-4" />
                    <span>Search Trains on This Circuit ({fromCode} → {toCode})</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
