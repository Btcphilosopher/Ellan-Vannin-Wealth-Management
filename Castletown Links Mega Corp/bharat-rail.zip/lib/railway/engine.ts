import { STATIONS, TRAINS, DISRUPTIONS } from './data';
import {
  Station,
  Train,
  TravelClass,
  QuotaType,
  ClassAvailability,
  FareBreakdown,
  PNRRecord,
  PassengerDetail,
  TrainTelemetry,
  LiveRunningStatus,
} from './types';

// ==========================================
// 1. FARE CALCULATION ENGINE
// ==========================================
export class FareEngine {
  private static BASE_RATE_PER_KM: Record<TravelClass, number> = {
    '1A': 4.15,
    'EC': 3.45,
    '2A': 2.45,
    '3A': 1.65,
    '3E': 1.45,
    'CC': 1.35,
    'SL': 0.65,
    '2S': 0.35,
    'GN': 0.28,
  };

  private static RESERVATION_FEES: Record<TravelClass, number> = {
    '1A': 60,
    'EC': 60,
    '2A': 50,
    '3A': 40,
    '3E': 40,
    'CC': 40,
    'SL': 20,
    '2S': 15,
    'GN': 0,
  };

  private static SUPERFAST_SURCHARGE: Record<TravelClass, number> = {
    '1A': 75,
    'EC': 75,
    '2A': 45,
    '3A': 45,
    '3E': 45,
    'CC': 45,
    'SL': 30,
    '2S': 15,
    'GN': 0,
  };

  public static calculateFare(
    distanceKm: number,
    travelClass: TravelClass,
    quota: QuotaType = 'GN',
    pantried: boolean = false,
    passengerCount: number = 1,
    isSeniorCitizen: boolean = false,
    isDivyangjan: boolean = false
  ): FareBreakdown {
    const rawBase = Math.round(distanceKm * (this.BASE_RATE_PER_KM[travelClass] || 0.8));
    const reservation = this.RESERVATION_FEES[travelClass] || 20;
    const superfast = this.SUPERFAST_SURCHARGE[travelClass] || 30;

    let tatkalCharge = 0;
    if (quota === 'TQ') {
      tatkalCharge = Math.max(100, Math.round(rawBase * 0.3));
    } else if (quota === 'PT') {
      tatkalCharge = Math.max(150, Math.round(rawBase * 0.5));
    }

    let catering = 0;
    if (pantried && ['1A', 'EC', '2A', '3A', 'CC'].includes(travelClass)) {
      catering = travelClass === '1A' || travelClass === 'EC' ? 385 : 240;
    }

    let concessionDiscount = 0;
    if (isDivyangjan) {
      concessionDiscount = Math.round((rawBase + reservation) * 0.5);
    } else if (isSeniorCitizen && (travelClass === 'SL' || travelClass === '2S')) {
      concessionDiscount = Math.round((rawBase + reservation) * 0.4);
    }

    const taxableTotalPerPassenger = rawBase + reservation + superfast + tatkalCharge + catering - concessionDiscount;
    const isAC = ['1A', '2A', '3A', '3E', 'CC', 'EC'].includes(travelClass);
    const gstRate = isAC ? 0.05 : 0;
    const gstAmountPerPassenger = Math.round(taxableTotalPerPassenger * gstRate);
    const totalPerPassenger = taxableTotalPerPassenger + gstAmountPerPassenger;

    return {
      ruleVersion: 'IR-TICKETING-2026-V4',
      baseFare: rawBase * passengerCount,
      reservationCharge: reservation * passengerCount,
      superfastCharge: superfast * passengerCount,
      tatkalCharge: tatkalCharge * passengerCount,
      cateringCharge: catering * passengerCount,
      concessionDiscount: concessionDiscount * passengerCount,
      gstAmount: gstAmountPerPassenger * passengerCount,
      totalFare: totalPerPassenger * passengerCount,
      currency: 'INR',
    };
  }
}

// ==========================================
// 2. AVAILABILITY SIMULATOR & ENGINE
// ==========================================
export class AvailabilityEngine {
  public static getAvailability(
    trainNumber: string,
    journeyDateStr: string,
    travelClass: TravelClass,
    quota: QuotaType = 'GN'
  ): ClassAvailability {
    // Deterministic pseudo-random seed based on train, date, class, and quota
    const seed = `${trainNumber}-${journeyDateStr}-${travelClass}-${quota}`;
    let hash = 0;
    for (let i = 0; i < seed.length; i++) {
      hash = (hash << 5) - hash + seed.charCodeAt(i);
      hash |= 0;
    }
    const positiveHash = Math.abs(hash);
    const modulo = positiveHash % 100;

    const train = TRAINS.find((t) => t.number === trainNumber);
    const distance = train?.totalDistanceKm || 800;
    const baseFare = FareEngine.calculateFare(distance, travelClass, quota).totalFare;

    if (modulo < 45) {
      const seats = 12 + (positiveHash % 68);
      return {
        travelClass,
        status: 'AVAILABLE',
        availableCount: seats,
        confirmationProbabilityPct: 100,
        baseFare,
        tatkalFare: quota === 'TQ' ? baseFare : Math.round(baseFare * 1.3),
        updatedAt: new Date().toISOString(),
        isSimulated: true,
      };
    } else if (modulo < 70) {
      const racNum = 4 + (positiveHash % 18);
      return {
        travelClass,
        status: 'RAC',
        racCount: racNum,
        confirmationProbabilityPct: 88 + (positiveHash % 10),
        baseFare,
        updatedAt: new Date().toISOString(),
        isSimulated: true,
      };
    } else {
      const wlNum = 3 + (positiveHash % 32);
      const prob = Math.max(35, 95 - wlNum * 2);
      return {
        travelClass,
        status: 'WAITLIST',
        waitlistCount: wlNum,
        waitlistType: quota === 'TQ' ? 'TQWL' : 'GNWL',
        confirmationProbabilityPct: prob,
        baseFare,
        updatedAt: new Date().toISOString(),
        isSimulated: true,
      };
    }
  }
}

// ==========================================
// 3. PNR & DIGITAL TICKET ENGINE
// ==========================================
export class PNREngine {
  private static STORAGE_KEY = 'bharat_rail_pnrs_v1';

  private static getStoredPNRs(): PNRRecord[] {
    if (typeof window === 'undefined') return [];
    try {
      const raw = localStorage.getItem(this.STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch {
      return [];
    }
  }

  private static saveStoredPNRs(records: PNRRecord[]) {
    if (typeof window === 'undefined') return;
    try {
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(records));
    } catch (e) {
      console.error('Failed to persist PNR locally:', e);
    }
  }

  public static generatePNRNumber(): string {
    const prefix = Math.floor(100 + Math.random() * 900);
    const suffix = Math.floor(1000000 + Math.random() * 9000000);
    return `${prefix}-${suffix}`;
  }

  public static createBooking(params: {
    train: Train;
    journeyDate: string;
    fromStation: Station;
    toStation: Station;
    travelClass: TravelClass;
    quota: QuotaType;
    passengers: { name: string; age: number; gender: 'MALE' | 'FEMALE' | 'TRANSGENDER'; berthPreference: any; foodPreference: any; isSenior?: boolean; isDivyangjan?: boolean }[];
    contactMobile: string;
    contactEmail: string;
  }): PNRRecord {
    const pnrNumber = this.generatePNRNumber();
    const availability = AvailabilityEngine.getAvailability(
      params.train.number,
      params.journeyDate,
      params.travelClass,
      params.quota
    );

    const coachPrefix = params.travelClass === '1A' ? 'H1' : params.travelClass === '2A' ? 'A1' : params.travelClass === '3A' ? 'B1' : params.travelClass === 'CC' ? 'C1' : params.travelClass === 'EC' ? 'E1' : 'S1';

    const processedPassengers: PassengerDetail[] = params.passengers.map((p, idx) => {
      let status: 'CNF' | 'RAC' | 'WL' = 'CNF';
      let coach = coachPrefix;
      let berth = `${(idx + 1) * 6}`;

      if (availability.status === 'RAC') {
        status = 'RAC';
        berth = `RAC-${(availability.racCount || 1) + idx}`;
      } else if (availability.status === 'WAITLIST') {
        status = 'WL';
        berth = `WL-${(availability.waitlistCount || 1) + idx}`;
      }

      return {
        id: `pax-${Date.now()}-${idx}`,
        name: p.name,
        age: p.age,
        gender: p.gender,
        berthPreference: p.berthPreference || 'NO_PREF',
        foodPreference: p.foodPreference || 'VEG',
        isSeniorCitizen: p.isSenior,
        isDivyangjan: p.isDivyangjan,
        assignedCoach: status === 'WL' ? undefined : coach,
        assignedBerth: berth,
        assignedStatus: status,
      };
    });

    const isAllConfirmed = processedPassengers.every((p) => p.assignedStatus === 'CNF');
    const isAnyRAC = processedPassengers.some((p) => p.assignedStatus === 'RAC');

    const bookingStatus = isAllConfirmed ? 'CONFIRMED' : isAnyRAC ? 'RAC' : 'WAITLIST';

    const fare = FareEngine.calculateFare(
      params.train.totalDistanceKm,
      params.travelClass,
      params.quota,
      params.train.pantried,
      params.passengers.length
    );

    const record: PNRRecord = {
      pnrNumber,
      trainNumber: params.train.number,
      trainName: params.train.names.en,
      journeyDate: params.journeyDate,
      fromStationCode: params.fromStation.code,
      toStationCode: params.toStation.code,
      boardingStationCode: params.fromStation.code,
      travelClass: params.travelClass,
      quota: params.quota,
      bookingStatus,
      currentStatus: bookingStatus,
      chartStatus: 'CHART_NOT_PREPARED',
      passengers: processedPassengers,
      fareBreakdown: fare,
      bookedAt: new Date().toISOString(),
      contactMobile: params.contactMobile,
      contactEmail: params.contactEmail,
      qrSignature: `BHARATRAIL:SECURE:${pnrNumber}:${params.train.number}:${bookingStatus}:${fare.totalFare}`,
      digitalTicketId: `ETICK-${Math.random().toString(36).substring(2, 9).toUpperCase()}`,
      isSimulated: true,
    };

    const stored = this.getStoredPNRs();
    this.saveStoredPNRs([record, ...stored]);
    return record;
  }

  public static searchPNR(query: string): PNRRecord | null {
    const cleanQuery = query.replace(/[^0-9]/g, '');
    const stored = this.getStoredPNRs();
    const found = stored.find((p) => p.pnrNumber.replace(/[^0-9]/g, '') === cleanQuery);
    if (found) return found;

    // If query looks like a valid 10 digit, synthesize a deterministic high-fidelity PNR record
    if (cleanQuery.length === 10) {
      const train = TRAINS[parseInt(cleanQuery[0], 10) % TRAINS.length] || TRAINS[0];
      const stations = STATIONS;
      const origin = stations.find((s) => s.code === train.originStationCode) || stations[0];
      const dest = stations.find((s) => s.code === train.destinationStationCode) || stations[1];
      const travelClass = train.classesAvailable[0] || '3A';

      const fare = FareEngine.calculateFare(train.totalDistanceKm, travelClass, 'GN', train.pantried, 2);

      const syntheticPNR: PNRRecord = {
        pnrNumber: `${cleanQuery.slice(0, 3)}-${cleanQuery.slice(3)}`,
        trainNumber: train.number,
        trainName: train.names.en,
        journeyDate: '2026-09-18',
        fromStationCode: origin.code,
        toStationCode: dest.code,
        boardingStationCode: origin.code,
        travelClass,
        quota: 'GN',
        bookingStatus: 'CONFIRMED',
        currentStatus: 'CONFIRMED',
        chartStatus: 'CHART_PREPARED',
        passengers: [
          {
            id: 'pax-1',
            name: 'R. Sharma',
            age: 38,
            gender: 'MALE',
            berthPreference: 'LOWER',
            foodPreference: 'VEG',
            assignedCoach: 'B2',
            assignedBerth: '24 (LB)',
            assignedStatus: 'CNF',
          },
          {
            id: 'pax-2',
            name: 'P. Sharma',
            age: 34,
            gender: 'FEMALE',
            berthPreference: 'MIDDLE',
            foodPreference: 'VEG',
            assignedCoach: 'B2',
            assignedBerth: '25 (MB)',
            assignedStatus: 'CNF',
          },
        ],
        fareBreakdown: fare,
        bookedAt: '2026-09-02T10:15:00Z',
        contactMobile: '+91 98765 43210',
        contactEmail: 'passenger@bharatrail.gov.in',
        qrSignature: `BHARATRAIL:VERIFIED:${cleanQuery}:${train.number}:CNF:${fare.totalFare}`,
        digitalTicketId: `ETICK-${cleanQuery.slice(4)}`,
        isSimulated: true,
      };

      return syntheticPNR;
    }

    return null;
  }
}

// ==========================================
// 4. LIVE TELEMETRY & STATUS TRACKER
// ==========================================
export class LiveTrackingEngine {
  public static getTelemetry(trainNumber: string): TrainTelemetry {
    const train = TRAINS.find((t) => t.number === trainNumber) || TRAINS[0];
    const stops = train.schedule;
    const now = new Date();
    const currentHour = now.getHours();

    // Select a realistic mid-journey stop based on current time
    const stopIdx = Math.min(Math.max(1, currentHour % stops.length), stops.length - 1);
    const currStop = stops[stopIdx];
    const prevStop = stops[stopIdx - 1];
    const nextStop = stops[Math.min(stopIdx + 1, stops.length - 1)];

    const delayMinutes = (parseInt(train.number.slice(-2), 10) * 3) % 25;
    const status: LiveRunningStatus = delayMinutes === 0 ? 'ON_TIME' : delayMinutes < 30 ? 'DELAYED' : 'DELAYED';

    return {
      trainNumber: train.number,
      trainName: train.names.en,
      currentStationCode: currStop.stationCode,
      nextStationCode: nextStop.stationCode,
      lastPassedStationCode: prevStop.stationCode,
      delayMinutes,
      status,
      currentSpeedKmh: status === 'ON_TIME' ? train.avgSpeedKmh : Math.round(train.avgSpeedKmh * 0.85),
      distanceCoveredKm: currStop.distanceKm,
      estimatedNextArrival: nextStop.arrivalTime,
      currentPlatform: currStop.platform,
      telemetrySource: 'SYNTHETIC_SIMULATOR',
      lastTelemetryPing: new Date().toISOString(),
      disruptionNote: delayMinutes > 15 ? 'Speed restricted in ghat section due to wet track protocol' : undefined,
    };
  }
}

// ==========================================
// 5. ROUTING & JOURNEY PLANNER ENGINE
// ==========================================
export interface JourneyOption {
  type: 'DIRECT' | 'CONNECTING';
  firstLeg: Train;
  secondLeg?: Train;
  interchangeStation?: Station;
  totalDurationMinutes: number;
  departureTime: string;
  arrivalTime: string;
  classesAvailable: TravelClass[];
}

export class RoutingEngine {
  public static findJourneys(fromCode: string, toCode: string): JourneyOption[] {
    const directTrains = TRAINS.filter((t) => {
      const stops = t.schedule.map((s) => s.stationCode);
      const fromIdx = stops.indexOf(fromCode);
      const toIdx = stops.indexOf(toCode);
      return fromIdx !== -1 && toIdx !== -1 && fromIdx < toIdx;
    });

    const results: JourneyOption[] = directTrains.map((t) => {
      const fromStop = t.schedule.find((s) => s.stationCode === fromCode)!;
      const toStop = t.schedule.find((s) => s.stationCode === toCode)!;
      return {
        type: 'DIRECT',
        firstLeg: t,
        departureTime: fromStop.departureTime === 'START' ? t.departureTime : fromStop.departureTime,
        arrivalTime: toStop.arrivalTime === 'END' ? t.arrivalTime : toStop.arrivalTime,
        totalDurationMinutes: t.durationMinutes,
        classesAvailable: t.classesAvailable,
      };
    });

    // If no direct routes, synthesize smart connecting corridor routes
    if (results.length === 0) {
      // Find candidate hubs
      const hubs = ['NDLS', 'BPL', 'CNB', 'AGC', 'MMCT'];
      for (const hubCode of hubs) {
        if (hubCode === fromCode || hubCode === toCode) continue;

        const leg1 = TRAINS.find((t) => {
          const s = t.schedule.map((x) => x.stationCode);
          return s.includes(fromCode) && s.includes(hubCode) && s.indexOf(fromCode) < s.indexOf(hubCode);
        });

        const leg2 = TRAINS.find((t) => {
          const s = t.schedule.map((x) => x.stationCode);
          return s.includes(hubCode) && s.includes(toCode) && s.indexOf(hubCode) < s.indexOf(toCode);
        });

        if (leg1 && leg2 && leg1.number !== leg2.number) {
          const hubStation = STATIONS.find((s) => s.code === hubCode);
          results.push({
            type: 'CONNECTING',
            firstLeg: leg1,
            secondLeg: leg2,
            interchangeStation: hubStation,
            departureTime: leg1.departureTime,
            arrivalTime: leg2.arrivalTime,
            totalDurationMinutes: leg1.durationMinutes + leg2.durationMinutes + 60,
            classesAvailable: ['3A', '2A', 'SL'],
          });
          break; // Return best connector
        }
      }
    }

    return results;
  }
}
