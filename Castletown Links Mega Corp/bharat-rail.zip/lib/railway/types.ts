import { SupportedLanguage } from '../locales';

export type RailwayZone =
  | 'NR' // Northern Railway
  | 'WR' // Western Railway
  | 'CR' // Central Railway
  | 'SR' // Southern Railway
  | 'ER' // Eastern Railway
  | 'ECoR' // East Coast Railway
  | 'SWR' // South Western Railway
  | 'SCR' // South Central Railway
  | 'NCR' // North Central Railway
  | 'NWR' // North Western Railway
  | 'WCR' // West Central Railway
  | 'SECR' // South East Central Railway
  | 'NFR' // Northeast Frontier Railway
  | 'ECR' // East Central Railway
  | 'NER' // North Eastern Railway
  | 'SER' // South Eastern Railway
  | 'KR'; // Konkan Railway

export interface StationFacility {
  wheelchairAccessible: boolean;
  rampsAndLifts: boolean;
  brailleSignage: boolean;
  batteryCarBuggy: boolean;
  executiveLounge: boolean;
  cloakRoom: boolean;
  dormitoryRetiringRooms: boolean;
  metroInterchange: boolean;
  prepaidTaxi: boolean;
  wifi: boolean;
  foodCourtPantry: boolean;
  medicalEmergencyRoom: boolean;
  evCharging: boolean;
}

export interface StationTourismSpot {
  name: string;
  category: 'HERITAGE' | 'SPIRITUAL' | 'NATURE' | 'MODERN' | 'BEACH';
  distanceKm: number;
  description: string;
  transportAvailable: string;
}

export interface Station {
  id: string;
  code: string; // e.g. NDLS, MMCT, CSMT, HWH, MAS, SBC, BSB
  names: Record<SupportedLanguage, string>;
  cityNames: Record<SupportedLanguage, string>;
  state: string;
  zone: RailwayZone;
  division: string;
  platformCount: number;
  coordinates: {
    lat: number;
    lng: number;
  };
  facilities: StationFacility;
  tourismSpots: StationTourismSpot[];
}

export type TrainType =
  | 'VANDE_BHARAT'
  | 'RAJDHANI'
  | 'SHATABDI'
  | 'DURONTO'
  | 'TEJAS'
  | 'SUPERFAST'
  | 'MAIL_EXPRESS'
  | 'JAN_SHATABDI'
  | 'GARIB_RATH'
  | 'HUMSAFAR';

export type TravelClass =
  | '1A' // First AC
  | '2A' // Second AC
  | '3A' // Third AC
  | '3E' // 3 AC Economy
  | 'SL' // Sleeper Class
  | 'CC' // AC Chair Car
  | 'EC' // Executive Anubhuti / Chair Car
  | '2S' // Second Sitting
  | 'GN'; // General

export type QuotaType =
  | 'GN' // General
  | 'TQ' // Tatkal
  | 'PT' // Premium Tatkal
  | 'LD' // Ladies
  | 'SS' // Senior Citizen / Lower Berth
  | 'HP' // Divyangjan / Differently Abled
  | 'FT' // Foreign Tourist
  | 'DF'; // Defence

export type AvailabilityStatusType =
  | 'AVAILABLE'
  | 'RAC'
  | 'WAITLIST'
  | 'REGRET'
  | 'NOT_AVAILABLE'
  | 'CHARTING_CLOSED';

export interface ClassAvailability {
  travelClass: TravelClass;
  status: AvailabilityStatusType;
  availableCount?: number;
  racCount?: number;
  waitlistCount?: number;
  waitlistType?: 'GNWL' | 'RLWL' | 'TQWL' | 'PQWL';
  confirmationProbabilityPct: number; // e.g. 92%
  baseFare: number;
  tatkalFare?: number;
  updatedAt: string;
  isSimulated: boolean;
}

export interface CoachInfo {
  coachNumber: string; // e.g. H1, A1, B1, B2, S1, S2, GS1, EOG, LOCO
  coachType: 'LOCO' | 'EOG' | '1A' | '2A' | '3A' | '3E' | 'SL' | 'CC' | 'EC' | 'EA' | '2S' | 'GEN' | 'PANTRY';
  displayName: string;
  deckCount: 1 | 2;
  berthLayout: ('LB' | 'MB' | 'UB' | 'SLB' | 'SUB' | 'WS' | 'AS' | 'MS')[];
  distanceFromEngineMeters: number;
}

export interface ScheduleStop {
  stationCode: string;
  stationName: string;
  day: number; // 1, 2, 3
  arrivalTime: string; // "16:55" or "START"
  departureTime: string; // "17:05" or "END"
  dwellMinutes: number;
  distanceKm: number;
  platform: number;
  speedKmh: number;
}

export interface Train {
  number: string; // e.g. "12951"
  names: Record<SupportedLanguage, string>;
  type: TrainType;
  originStationCode: string;
  destinationStationCode: string;
  departureTime: string;
  arrivalTime: string;
  durationMinutes: number;
  totalDistanceKm: number;
  runsOnDays: boolean[]; // [Sun, Mon, Tue, Wed, Thu, Fri, Sat]
  classesAvailable: TravelClass[];
  pantried: boolean;
  composition: CoachInfo[];
  schedule: ScheduleStop[];
  punctualityScorePct: number;
  avgSpeedKmh: number;
}

export interface PassengerDetail {
  id: string;
  name: string;
  age: number;
  gender: 'MALE' | 'FEMALE' | 'TRANSGENDER';
  berthPreference: 'LOWER' | 'MIDDLE' | 'UPPER' | 'SIDE_LOWER' | 'SIDE_UPPER' | 'CABIN' | 'NO_PREF';
  foodPreference: 'VEG' | 'NON_VEG' | 'JAIN' | 'NO_FOOD';
  isSeniorCitizen?: boolean;
  isDivyangjan?: boolean;
  assignedCoach?: string;
  assignedBerth?: string;
  assignedStatus: 'CNF' | 'RAC' | 'WL';
}

export interface FareBreakdown {
  ruleVersion: string;
  baseFare: number;
  reservationCharge: number;
  superfastCharge: number;
  tatkalCharge: number;
  cateringCharge: number;
  concessionDiscount: number;
  gstAmount: number;
  totalFare: number;
  currency: 'INR';
}

export interface PNRRecord {
  pnrNumber: string; // 10 digits canonical, e.g. "248-8192039"
  trainNumber: string;
  trainName: string;
  journeyDate: string;
  fromStationCode: string;
  toStationCode: string;
  boardingStationCode: string;
  travelClass: TravelClass;
  quota: QuotaType;
  bookingStatus: 'CONFIRMED' | 'RAC' | 'WAITLIST' | 'CANCELLED';
  currentStatus: 'CONFIRMED' | 'RAC' | 'WAITLIST' | 'CANCELLED';
  chartStatus: 'CHART_PREPARED' | 'CHART_NOT_PREPARED';
  passengers: PassengerDetail[];
  fareBreakdown: FareBreakdown;
  bookedAt: string;
  contactMobile: string;
  contactEmail: string;
  qrSignature: string;
  digitalTicketId: string;
  isSimulated: boolean;
}

export type LiveRunningStatus =
  | 'ON_TIME'
  | 'DELAYED'
  | 'EARLY'
  | 'DIVERTED'
  | 'CANCELLED'
  | 'TERMINATED_SHORT';

export interface TrainTelemetry {
  trainNumber: string;
  trainName: string;
  currentStationCode: string;
  nextStationCode: string;
  lastPassedStationCode: string;
  delayMinutes: number;
  status: LiveRunningStatus;
  currentSpeedKmh: number;
  distanceCoveredKm: number;
  estimatedNextArrival: string;
  currentPlatform: number;
  telemetrySource: 'SYNTHETIC_SIMULATOR' | 'ADAPTER_MOCK';
  lastTelemetryPing: string;
  disruptionNote?: string;
}

export interface DisruptionAlert {
  id: string;
  zone: RailwayZone;
  section: string;
  affectedTrainNumbers: string[];
  severity: 'CRITICAL' | 'WARNING' | 'INFO';
  type: 'WEATHER_FOG' | 'TRACK_MAINTENANCE' | 'DIVERSION' | 'PLATFORM_REVISION' | 'SPECIAL_EVENT';
  titles: Record<SupportedLanguage, string>;
  descriptions: Record<SupportedLanguage, string>;
  validFrom: string;
  validUntil: string;
  alternativeSuggestion: string;
}

export interface TourismCircuit {
  id: string;
  name: Record<SupportedLanguage, string>;
  tag: string;
  durationDays: string;
  keyStations: string[];
  highlights: string[];
  recommendedTrains: string[];
  description: Record<SupportedLanguage, string>;
  imageSlug: string;
}
