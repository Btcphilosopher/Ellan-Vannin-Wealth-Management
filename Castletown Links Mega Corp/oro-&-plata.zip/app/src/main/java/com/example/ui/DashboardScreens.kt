package com.example.ui

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.*
import com.example.ui.theme.*
import com.example.viewmodel.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.absoluteValue

// --- Beautiful Custom Canvas Chart ---
@Composable
fun PriceHistoryChart(
    history: List<Double>,
    accentColor: Color,
    unit: String,
    modifier: Modifier = Modifier
) {
    if (history.isEmpty()) {
        Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text("No hay datos históricos disponibles", style = MaterialTheme.typography.bodyMedium, color = TextMuted)
        }
        return
    }

    val minVal = history.minOrNull() ?: 0.0
    val maxVal = history.maxOrNull() ?: 1.0
    val diff = (maxVal - minVal).coerceAtLeast(0.01)

    // Add padding to chart boundaries
    val yMin = minVal - (diff * 0.1)
    val yMax = maxVal + (diff * 0.1)
    val yDiff = yMax - yMin

    Canvas(modifier = modifier.background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f))) {
        val width = size.width
        val height = size.height

        // Draw horizontal grid lines
        val gridLines = 4
        for (i in 0..gridLines) {
            val y = height * i / gridLines
            drawLine(
                color = Color.Gray.copy(alpha = 0.15f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1.dp.toPx()
            )
        }

        val points = history.mapIndexed { index, valItem ->
            val x = width * index / (history.size - 1).coerceAtLeast(1)
            val y = height - ((valItem - yMin) / yDiff * height).toFloat()
            Offset(x, y)
        }

        // Draw smooth path
        val strokePath = Path()
        val fillPath = Path()

        if (points.isNotEmpty()) {
            strokePath.moveTo(points[0].x, points[0].y)
            fillPath.moveTo(points[0].x, height)
            fillPath.lineTo(points[0].x, points[0].y)

            for (i in 1 until points.size) {
                strokePath.lineTo(points[i].x, points[i].y)
                fillPath.lineTo(points[i].x, points[i].y)
            }
            fillPath.lineTo(points.last().x, height)
            fillPath.close()

            // Draw area gradient filled
            drawPath(
                path = fillPath,
                brush = Brush.verticalGradient(
                    colors = listOf(accentColor.copy(alpha = 0.35f), Color.Transparent),
                    startY = 0f,
                    endY = height
                )
            )

            // Draw line
            drawPath(
                path = strokePath,
                color = accentColor,
                style = Stroke(width = 2.5.dp.toPx())
            )

            // Draw active/last point highlight
            val lastPoint = points.last()
            drawCircle(
                color = accentColor,
                radius = 5.dp.toPx(),
                center = lastPoint
            )
            drawCircle(
                color = Color.White,
                radius = 2.dp.toPx(),
                center = lastPoint
            )
        }
    }
}

// --- Main Layout Container with Adaptive Navigation ---
@Composable
fun MainBrokerageScreen(viewModel: MarketViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val currentRole by viewModel.currentRole.collectAsState()
    val selectedClient by viewModel.selectedClient.collectAsState()
    val clients by viewModel.clients.collectAsState()

    // Screen size support
    val configuration = LocalConfiguration.current
    val isTablet = configuration.screenWidthDp >= 840

    Scaffold(
        topBar = {
            InstitutionalHeader(
                viewModel = viewModel,
                currentRole = currentRole,
                selectedClient = selectedClient,
                clients = clients
            )
        },
        bottomBar = {
            if (!isTablet) {
                BottomNavigationWidget(currentScreen = currentScreen, onSelect = { viewModel.setScreen(it) }, role = currentRole)
            }
        }
    ) { innerPadding ->
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            if (isTablet) {
                SidebarNavigationWidget(
                    currentScreen = currentScreen,
                    onSelect = { viewModel.setScreen(it) },
                    role = currentRole,
                    modifier = Modifier.width(260.dp)
                )
                Divider(modifier = Modifier.fillMaxHeight().width(1.dp), color = Color.LightGray.copy(alpha = 0.3f))
            }

            Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = {
                        fadeIn() togetherWith fadeOut()
                    },
                    label = "ScreenTransition"
                ) { screen ->
                    when (screen) {
                        "dashboard" -> MarketScreen(viewModel = viewModel)
                        "trading" -> TradingScreen(viewModel = viewModel)
                        "portfolio" -> PortfolioScreen(viewModel = viewModel)
                        "inventory" -> InventoryScreen(viewModel = viewModel)
                        "risk" -> RiskScreen(viewModel = viewModel)
                        "compliance" -> ComplianceScreen(viewModel = viewModel)
                        "reports" -> ReportsScreen(viewModel = viewModel)
                        "clients" -> ClientsManagementScreen(viewModel = viewModel)
                        else -> MarketScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

// --- Header Component with Roles and Client Switcher ---
@Composable
fun InstitutionalHeader(
    viewModel: MarketViewModel,
    currentRole: UserRole,
    selectedClient: Client?,
    clients: List<Client>
) {
    var showClientMenu by remember { mutableStateOf(false) }
    var showRoleMenu by remember { mutableStateOf(false) }

    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.primary,
        tonalElevation = 6.dp
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Title and Subtitle
                Column {
                    Text(
                        text = "ORO & PLATA",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Serif,
                            letterSpacing = 2.sp
                        ),
                        color = GoldAccent
                    )
                    Text(
                        text = "MESA DE METALES PRECIOSOS | PRECIOUS METALS DESK",
                        style = MaterialTheme.typography.labelSmall.copy(
                            letterSpacing = 1.sp
                        ),
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }

                // Dropdowns & Buttons
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Role Selector
                    Box {
                        TextButton(
                            onClick = { showRoleMenu = true },
                            modifier = Modifier
                                .background(Color.White.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                .testTag("role_select_button"),
                            colors = ButtonDefaults.textButtonColors(contentColor = Color.White)
                        ) {
                            Icon(Icons.Filled.AccountBalance, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                when (currentRole) {
                                    UserRole.CLIENTE -> "Cliente Minorista"
                                    UserRole.INSTITUCIONAL -> "Institucional"
                                    UserRole.MESA_DE_OPERACIONES -> "Mesa de Operaciones (Dealer)"
                                },
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                        }

                        DropdownMenu(
                            expanded = showRoleMenu,
                            onDismissRequest = { showRoleMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Cliente Minorista (Retail)") },
                                onClick = {
                                    viewModel.setRole(UserRole.CLIENTE)
                                    viewModel.setScreen("dashboard")
                                    showRoleMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Cliente Institucional (RFQ)") },
                                onClick = {
                                    viewModel.setRole(UserRole.INSTITUCIONAL)
                                    viewModel.setScreen("trading")
                                    showRoleMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("Mesa de Operaciones (Dealer Workbench)") },
                                onClick = {
                                    viewModel.setRole(UserRole.MESA_DE_OPERACIONES)
                                    viewModel.setScreen("dashboard")
                                    showRoleMenu = false
                                }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    // Client Context Selector (if appropriate)
                    if (currentRole != UserRole.MESA_DE_OPERACIONES && selectedClient != null) {
                        Box {
                            TextButton(
                                onClick = { showClientMenu = true },
                                modifier = Modifier
                                    .border(1.dp, GoldAccent.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                    .testTag("client_select_button"),
                                colors = ButtonDefaults.textButtonColors(contentColor = GoldAccent)
                            ) {
                                Icon(Icons.Filled.Person, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    selectedClient.name,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.widthIn(max = 140.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                            }

                            DropdownMenu(
                                expanded = showClientMenu,
                                onDismissRequest = { showClientMenu = false }
                            ) {
                                clients.take(15).forEach { client ->
                                    DropdownMenuItem(
                                        text = {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(client.name)
                                                Spacer(modifier = Modifier.width(16.dp))
                                                Text(
                                                    client.category.displayName,
                                                    color = GoldAccent,
                                                    style = MaterialTheme.typography.bodySmall
                                                )
                                            }
                                        },
                                        onClick = {
                                            viewModel.selectClient(client)
                                            showClientMenu = false
                                        }
                                    )
                                }
                                Divider()
                                DropdownMenuItem(
                                    text = { Text("Buscar más clientes...", color = GoldAccent, fontWeight = FontWeight.Bold) },
                                    onClick = {
                                        viewModel.setScreen("clients")
                                        showClientMenu = false
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// --- Navigation Widgets (Adaptive) ---
@Composable
fun BottomNavigationWidget(currentScreen: String, onSelect: (String) -> Unit, role: UserRole) {
    NavigationBar(
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = Color.White
    ) {
        val items = getNavItems(role)
        items.forEach { item ->
            NavigationBarItem(
                selected = currentScreen == item.screen,
                onClick = { onSelect(item.screen) },
                icon = { Icon(if (currentScreen == item.screen) item.selectedIcon else item.unselectedIcon, contentDescription = item.title) },
                label = { Text(item.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 10.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = MaterialTheme.colorScheme.primary,
                    selectedTextColor = GoldAccent,
                    indicatorColor = GoldAccent,
                    unselectedIconColor = Color.White.copy(alpha = 0.7f),
                    unselectedTextColor = Color.White.copy(alpha = 0.6f)
                )
            )
        }
    }
}

@Composable
fun SidebarNavigationWidget(currentScreen: String, onSelect: (String) -> Unit, role: UserRole, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier.fillMaxHeight(),
        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.98f),
        contentColor = Color.White
    ) {
        Column(
            modifier = Modifier
                .fillMaxHeight()
                .padding(16.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                val items = getNavItems(role)
                items.forEach { item ->
                    val isSelected = currentScreen == item.screen
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) GoldAccent else Color.Transparent)
                            .clickable { onSelect(item.screen) }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                            contentDescription = null,
                            tint = if (isSelected) MaterialTheme.colorScheme.primary else Color.White
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = item.title,
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            ),
                            color = if (isSelected) MaterialTheme.colorScheme.primary else Color.White
                        )
                    }
                }
            }

            // Institutional Seal / Brand
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Divider(color = Color.White.copy(alpha = 0.2f), modifier = Modifier.padding(bottom = 12.dp))
                Icon(Icons.Outlined.Gavel, contentDescription = null, tint = GoldAccent, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "ORO & PLATA MESA DESK",
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.4f)
                )
                Text(
                    "SISTEMA DE DEMOSTRACIÓN",
                    style = MaterialTheme.typography.labelSmall,
                    color = AlertAmber.copy(alpha = 0.7f),
                    fontSize = 8.sp
                )
            }
        }
    }
}

class NavigationItem(
    val title: String,
    val screen: String,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector
)

fun getNavItems(role: UserRole): List<NavigationItem> {
    return when (role) {
        UserRole.CLIENTE -> listOf(
            NavigationItem("Precios", "dashboard", Icons.Filled.TrendingUp, Icons.Outlined.TrendingUp),
            NavigationItem("Operar", "trading", Icons.Filled.ShoppingCart, Icons.Outlined.ShoppingCart),
            NavigationItem("Cartera", "portfolio", Icons.Filled.PieChart, Icons.Outlined.PieChart),
            NavigationItem("Logística", "inventory", Icons.Filled.LocalShipping, Icons.Outlined.LocalShipping),
            NavigationItem("Informes", "reports", Icons.Filled.Assessment, Icons.Outlined.Assessment)
        )
        UserRole.INSTITUCIONAL -> listOf(
            NavigationItem("Precios Spot", "dashboard", Icons.Filled.TrendingUp, Icons.Outlined.TrendingUp),
            NavigationItem("RFQ Bulk", "trading", Icons.Filled.Business, Icons.Outlined.Business),
            NavigationItem("Custodia Fí.", "portfolio", Icons.Filled.PieChart, Icons.Outlined.PieChart),
            NavigationItem("Informes", "reports", Icons.Filled.Assessment, Icons.Outlined.Assessment)
        )
        UserRole.MESA_DE_OPERACIONES -> listOf(
            NavigationItem("Mesa", "dashboard", Icons.Filled.Monitor, Icons.Outlined.Monitor),
            NavigationItem("Bóvedas", "inventory", Icons.Filled.Warehouse, Icons.Outlined.Warehouse),
            NavigationItem("Riesgo", "risk", Icons.Filled.Shield, Icons.Outlined.Shield),
            NavigationItem("Cumplimiento", "compliance", Icons.Filled.VerifiedUser, Icons.Outlined.VerifiedUser),
            NavigationItem("Clientes", "clients", Icons.Filled.Group, Icons.Outlined.Group)
        )
    }
}

// --- Screen 1: Market Screen (Mesa o Precios) ---
@Composable
fun MarketScreen(viewModel: MarketViewModel) {
    val spotGold by viewModel.spotGold.collectAsState()
    val spotSilver by viewModel.spotSilver.collectAsState()
    val goldChange by viewModel.gold24hChange.collectAsState()
    val silverChange by viewModel.silver24hChange.collectAsState()
    val selectedUnit by viewModel.selectedUnit.collectAsState()
    val isSimulating by viewModel.isSimulating.collectAsState()
    val marketRegime by viewModel.marketRegime.collectAsState()
    val role by viewModel.currentRole.collectAsState()

    val goldHistory by viewModel.goldHistory.collectAsState()
    val silverHistory by viewModel.silverHistory.collectAsState()

    val goldSpread by viewModel.dealerGoldSpreadEur.collectAsState()
    val silverSpread by viewModel.dealerSilverSpreadEur.collectAsState()

    val goldBid = viewModel.getBidPriceInUnit(Metal.ORO, selectedUnit)
    val goldAsk = viewModel.getAskPriceInUnit(Metal.ORO, selectedUnit)
    val silverBid = viewModel.getBidPriceInUnit(Metal.PLATA, selectedUnit)
    val silverAsk = viewModel.getAskPriceInUnit(Metal.PLATA, selectedUnit)

    val ratio = if (spotSilver > 0) spotGold / spotSilver else 0.0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("market_screen")
    ) {
        // Upper banner: Simulating / Live Feed
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(RoundedCornerShape(5.dp))
                                .background(if (isSimulating) GreenSuccess else AlertBurgundy)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSimulating) "MERCADO SIMULADO ACTIVO" else "MERCADO EN PAUSA",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Play/Pause Control & Speed
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { viewModel.toggleSimulation() }) {
                            Icon(
                                imageVector = if (isSimulating) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = "Controles"
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        UnitSelectionChip(current = selectedUnit, onSelect = { viewModel.setSelectedUnit(it) })
                    }
                }
            }
        }

        // Main Spot Cards Grid
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                // Gold card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ORO (Au)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = GoldAccent)
                            Text(
                                text = String.format("%+.2f%%", goldChange),
                                style = MaterialTheme.typography.bodySmall,
                                color = if (goldChange >= 0) GreenSuccess else AlertBurgundy,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = String.format("%.2f %s", viewModel.getMidPriceInUnit(Metal.ORO, selectedUnit), selectedUnit.split("/").first()),
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("BID: " + String.format("%.2f", goldBid), fontSize = 11.sp, color = TextMuted)
                            Text("ASK: " + String.format("%.2f", goldAsk), fontSize = 11.sp, color = TextMuted)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        PriceHistoryChart(
                            history = goldHistory,
                            accentColor = GoldAccent,
                            unit = selectedUnit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                    }
                }

                // Silver card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    border = BorderStroke(1.dp, SilverAccent.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("PLATA (Ag)", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = SilverAccent)
                            Text(
                                text = String.format("%+.2f%%", silverChange),
                                style = MaterialTheme.typography.bodySmall,
                                color = if (silverChange >= 0) GreenSuccess else AlertBurgundy,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = String.format("%.2f %s", viewModel.getMidPriceInUnit(Metal.PLATA, selectedUnit), selectedUnit.split("/").first()),
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("BID: " + String.format("%.2f", silverBid), fontSize = 11.sp, color = TextMuted)
                            Text("ASK: " + String.format("%.2f", silverAsk), fontSize = 11.sp, color = TextMuted)
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        PriceHistoryChart(
                            history = silverHistory,
                            accentColor = SilverAccent,
                            unit = selectedUnit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp)
                                .clip(RoundedCornerShape(4.dp))
                        )
                    }
                }
            }
        }

        // Ratio Oro/Plata Display
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("RATIO ORO/PLATA (Au/Ag)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text(
                            "Relación de precios onza-por-onza. Muestra cuántas onzas de plata se necesitan para comprar una de oro.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextMuted
                        )
                    }
                    Text(
                        text = String.format("%.2f", ratio),
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = GoldAccent
                    )
                }
            }
        }

        // Dealer Workbench settings (If role is MESA_DE_OPERACIONES)
        if (role == UserRole.MESA_DE_OPERACIONES) {
            item {
                Text(
                    "CONTROLES DE LA MESA (DEALER WORKBENCH)",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 12.dp)
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Configuración de Spreads y Margen Comercial", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Gold spread
                        Text("Spread de Oro: ${String.format("%.2f EUR/oz", goldSpread)}", fontSize = 12.sp)
                        Slider(
                            value = goldSpread.toFloat(),
                            onValueChange = { viewModel.adjustGoldSpread(it.toDouble()) },
                            valueRange = 0.5f..50.0f,
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Silver spread
                        Text("Spread de Plata: ${String.format("%.2f EUR/oz", silverSpread)}", fontSize = 12.sp)
                        Slider(
                            value = silverSpread.toFloat(),
                            onValueChange = { viewModel.adjustSilverSpread(it.toDouble()) },
                            valueRange = 0.05f..5.0f,
                            modifier = Modifier.fillMaxWidth()
                        )

                        // Margen del dealer
                        val marginPercent by viewModel.dealerMarginPercent.collectAsState()
                        Text("Margen Comercial del Intermediario: ${String.format("%.3f%%", marginPercent * 100.0)}", fontSize = 12.sp)
                        Slider(
                            value = marginPercent.toFloat(),
                            onValueChange = { viewModel.adjustDealerMargin(it.toDouble()) },
                            valueRange = 0.001f..0.05f,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }

        // Scenarios Lab Section
        item {
            Text(
                "LABORATORIO DE ESCENARIOS DE MERCADO",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    ScenarioButton(text = "Mercado Normal", isActive = marketRegime == MarketRegime.NORMAL) {
                        viewModel.changeRegime(MarketRegime.NORMAL)
                    }
                }
                Box(modifier = Modifier.weight(1f)) {
                    ScenarioButton(text = "Volatilidad Alta", isActive = marketRegime == MarketRegime.VOLATILIDAD_ALTA) {
                        viewModel.changeRegime(MarketRegime.VOLATILIDAD_ALTA)
                    }
                }
                Box(modifier = Modifier.weight(1f)) {
                    ScenarioButton(text = "Shock Alcista", isActive = marketRegime == MarketRegime.SHOCK_ALCISTA) {
                        viewModel.changeRegime(MarketRegime.SHOCK_ALCISTA)
                    }
                }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(modifier = Modifier.weight(1f)) {
                    ScenarioButton(text = "Liquidez Reducida", isActive = marketRegime == MarketRegime.LIQUIDEZ_REDUCIDA) {
                        viewModel.changeRegime(MarketRegime.LIQUIDEZ_REDUCIDA)
                    }
                }
                Box(modifier = Modifier.weight(1f)) {
                    ScenarioButton(text = "Demanda Física", isActive = marketRegime == MarketRegime.DEMANDA_FISICA_ELEVADA) {
                        viewModel.changeRegime(MarketRegime.DEMANDA_FISICA_ELEVADA)
                    }
                }
                Box(modifier = Modifier.weight(1f)) {
                    ScenarioButton(text = "Shock Bajista", isActive = marketRegime == MarketRegime.SHOCK_BAJISTA) {
                        viewModel.changeRegime(MarketRegime.SHOCK_BAJISTA)
                    }
                }
            }
        }

        // Institutional Notice footer
        item {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "ORO & PLATA de Demostración - Los precios que se muestran son puramente sintéticos y simulados de forma estocástica mediante un modelo de difusión de movimiento Browniano. Este sistema no se conecta a mercados reales.",
                style = MaterialTheme.typography.labelSmall,
                color = TextMuted,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun ScenarioButton(text: String, isActive: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isActive) GoldAccent else MaterialTheme.colorScheme.surfaceVariant,
            contentColor = if (isActive) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
        ),
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(4.dp),
        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
    ) {
        Text(text, fontSize = 10.sp, textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, maxLines = 1)
    }
}

@Composable
fun UnitSelectionChip(current: String, onSelect: (String) -> Unit) {
    val options = listOf("EUR/oz", "USD/oz", "EUR/kg", "EUR/g")
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(2.dp)
    ) {
        options.forEach { opt ->
            Text(
                text = opt,
                modifier = Modifier
                    .clip(RoundedCornerShape(2.dp))
                    .background(if (current == opt) GoldAccent else Color.Transparent)
                    .clickable { onSelect(opt) }
                    .padding(horizontal = 6.dp, vertical = 4.dp),
                fontSize = 10.sp,
                color = if (current == opt) Color.White else MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

// --- Screen 2: Trading Screen (Cotización RFQ y Compra/Venta) ---
@Composable
fun TradingScreen(viewModel: MarketViewModel) {
    val selectedClient by viewModel.selectedClient.collectAsState()
    val products = DemoData.productList
    val quotes by viewModel.quotes.collectAsState()
    val isSimulating by viewModel.isSimulating.collectAsState()

    var selectedProduct by remember { mutableStateOf(products.first()) }
    var inputQtyString by remember { mutableStateOf("1") }
    var activeTabIsBuy by remember { mutableStateOf(true) } // true = Client Buys, false = Client Sells

    val clientQuote = quotes.find { q -> q.clientId == selectedClient?.id && q.productId == selectedProduct.id && q.isBuy == activeTabIsBuy }

    var tradeError by remember { mutableStateOf<String?>(null) }
    var tradeSuccess by remember { mutableStateOf<Trade?>(null) }

    val qty = inputQtyString.toIntOrNull() ?: 1

    val breakdown = viewModel.calculateCostBreakdown(selectedProduct, qty, activeTabIsBuy)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("trading_screen")
    ) {
        item {
            Text(
                "MESA DE COTIZACIÓN Y EJECUCIÓN (RFQ)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // Compra/Venta tab switcher
        item {
            TabRow(
                selectedTabIndex = if (activeTabIsBuy) 0 else 1,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            ) {
                Tab(
                    selected = activeTabIsBuy,
                    onClick = {
                        activeTabIsBuy = true
                        tradeError = null
                        tradeSuccess = null
                    },
                    text = { Text("COMPRAR (A Mesa)", fontWeight = FontWeight.Bold) }
                )
                Tab(
                    selected = !activeTabIsBuy,
                    onClick = {
                        activeTabIsBuy = false
                        tradeError = null
                        tradeSuccess = null
                    },
                    text = { Text("VENDER (A Mesa)", fontWeight = FontWeight.Bold) }
                )
            }
        }

        // Product selection & inputs
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Selección de Formato de Inversión", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))

                    // Simulated product list dropdown substitute
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 160.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        products.forEach { prod ->
                            val isSelected = prod.id == selectedProduct.id
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (isSelected) GoldAccent.copy(alpha = 0.15f) else Color.Transparent)
                                    .clickable {
                                        selectedProduct = prod
                                        tradeError = null
                                        tradeSuccess = null
                                    }
                                    .padding(horizontal = 8.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (prod.metal == Metal.ORO) Icons.Filled.Stars else Icons.Filled.Layers,
                                        contentDescription = null,
                                        tint = if (prod.metal == Metal.ORO) GoldAccent else SilverAccent,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(prod.name, fontSize = 12.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                                }
                                Text(
                                    "${prod.weightGrams}g | Pureza ${prod.purity * 100}%",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Quantity input
                    OutlinedTextField(
                        value = inputQtyString,
                        onValueChange = {
                            if (it.isEmpty() || it.toIntOrNull() != null) {
                                inputQtyString = it
                                tradeError = null
                                tradeSuccess = null
                            }
                        },
                        label = { Text("Cantidad (Unidades)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("quantity_input"),
                        singleLine = true
                    )
                }
            }
        }

        // Live Cost Breakdown
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "DESGLOSE DE PRECIOS ESTIMADO (EUR)",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    CostRow("Valor del metal puro", breakdown.metalValue)

                    if (activeTabIsBuy) {
                        CostRow("Prima de fabricación/formato", breakdown.premium)
                        CostRow("Coste acuñación de refinería", breakdown.manufacturing)
                        CostRow("Margen comercial mesa de corretaje", breakdown.dealerMargin)
                        CostRow("Amortización custodia", breakdown.custody)
                        CostRow("Logística y transporte asegurado", breakdown.logistics)
                    } else {
                        CostRow("Margen descuento de recompra (Spread)", breakdown.dealerMargin)
                        CostRow("Logística devolución", breakdown.logistics)
                    }

                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("PRECIO FINAL ESTIMADO", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(
                            String.format("%,.2f EUR", breakdown.total),
                            fontWeight = FontWeight.Bold,
                            color = if (activeTabIsBuy) GoldAccent else GreenSuccess
                        )
                    }
                    Text(
                        "Precio unitario: ${String.format("%,.2f EUR", breakdown.unitPrice)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted,
                        textAlign = TextAlign.End,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Interactive Quote Area (RFQ)
        item {
            if (clientQuote == null) {
                Button(
                    onClick = {
                        if (selectedClient != null) {
                            viewModel.requestRFQ(selectedClient!!.id, selectedProduct, qty, activeTabIsBuy)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("request_quote_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent, contentColor = Color.White),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Icon(Icons.Filled.Bolt, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("SOLICITAR COTIZACIÓN EN TIEMPO REAL (RFQ)", fontWeight = FontWeight.Bold)
                }
            } else {
                // Display active quote with validity countdown
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = LightSurfaceGold),
                    border = BorderStroke(2.dp, GoldAccent)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "COTIZACIÓN RECIBIDA: ${clientQuote.id}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = GoldAccent
                            )
                            Card(
                                colors = CardDefaults.cardColors(containerColor = AlertAmber)
                            ) {
                                Text(
                                    "Válida: ${clientQuote.validForSeconds} s",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        Text(
                            text = String.format("%,.2f EUR", clientQuote.totalEur),
                            style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Cancel
                            OutlinedButton(
                                onClick = {
                                    // Let it expire or remove
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text("Rechazar")
                            }

                            // Accept
                            Button(
                                onClick = {
                                    val res = viewModel.executeQuote(clientQuote.id)
                                    if (res is TradeResult.Success) {
                                        tradeSuccess = res.trade
                                        tradeError = null
                                    } else if (res is TradeResult.Failure) {
                                        tradeError = res.message
                                        tradeSuccess = null
                                    }
                                },
                                modifier = Modifier
                                    .weight(1.5f)
                                    .testTag("execute_trade_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = GreenSuccess, contentColor = Color.White),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Icon(Icons.Filled.Check, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("EJECUTAR TRADING", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Result banners
        item {
            tradeError?.let { err ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = AlertBurgundy.copy(alpha = 0.15f)),
                    border = BorderStroke(1.dp, AlertBurgundy)
                ) {
                    Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Error, contentDescription = null, tint = AlertBurgundy)
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(err, style = MaterialTheme.typography.bodySmall, color = AlertBurgundy, fontWeight = FontWeight.Bold)
                    }
                }
            }

            tradeSuccess?.let { trade ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp),
                    colors = CardDefaults.cardColors(containerColor = GreenSuccess.copy(alpha = 0.15f)),
                    border = BorderStroke(1.dp, GreenSuccess)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = GreenSuccess)
                            Spacer(modifier = Modifier.width(12.dp))
                            Text("TRANSACCIÓN COMPLETADA", style = MaterialTheme.typography.titleSmall, color = GreenSuccess, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Trade ID: ${trade.id}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text("Producto: ${trade.productName}", fontSize = 11.sp)
                        Text("Unidades: ${trade.quantity}", fontSize = 11.sp)
                        Text(String.format("Total: %,.2f EUR", trade.totalEur), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        if (trade.allocatedBarIds.isNotEmpty()) {
                            Text("Lingotes físicos asignados:", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                            Text(trade.allocatedBarIds.joinToString(", "), fontSize = 10.sp, color = GoldAccent)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CostRow(label: String, value: Double) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 11.sp, color = TextMuted)
        Text(String.format("%,.2f EUR", value), fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

// --- Screen 3: Client Portfolio Screen ---
@Composable
fun PortfolioScreen(viewModel: MarketViewModel) {
    val selectedClient by viewModel.selectedClient.collectAsState()
    val bars by viewModel.bars.collectAsState()
    val spotGold by viewModel.spotGold.collectAsState()
    val spotSilver by viewModel.spotSilver.collectAsState()

    if (selectedClient == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Seleccione un cliente para ver su cartera", style = MaterialTheme.typography.bodyMedium)
        }
        return
    }

    val client = selectedClient!!
    val clientBars = bars.filter { it.ownerId == client.id }

    // Valuation calculations
    val goldPerG = spotGold / 31.1034768
    val silverPerG = spotSilver / 31.1034768

    // Allocated holdings
    val allocatedGoldWeight = clientBars.filter { it.metal == Metal.ORO }.sumOf { it.fineWeightGrams }
    val allocatedSilverWeight = clientBars.filter { it.metal == Metal.PLATA }.sumOf { it.fineWeightGrams }

    val allocatedGoldValue = allocatedGoldWeight * goldPerG
    val allocatedSilverValue = allocatedSilverWeight * silverPerG

    // Unallocated holdings
    val unallocatedGoldValue = client.unallocatedGoldGrams * goldPerG
    val unallocatedSilverValue = client.unallocatedSilverGrams * silverPerG

    val totalGoldValue = allocatedGoldValue + unallocatedGoldValue
    val totalSilverValue = allocatedSilverValue + unallocatedSilverValue
    val totalMetalValue = totalGoldValue + totalSilverValue

    val totalPortfolioValue = totalMetalValue + client.cashBalanceEur

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("portfolio_screen")
    ) {
        item {
            Text(
                "CARTERA DE METALES PRECIOSOS",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 4.dp)
            )
            Text(
                "Cliente: ${client.name} | Cuenta: ${client.accountNumber}",
                style = MaterialTheme.typography.bodySmall,
                color = TextMuted,
                modifier = Modifier.padding(bottom = 16.dp)
            )
        }

        // Summary Card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("VALOR TOTAL DE LA CARTERA", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.7f))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = String.format("%,.2f EUR", totalPortfolioValue),
                        style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                        color = GoldAccent
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text("Metales en Custodia", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.5f))
                            Text(String.format("%,.2f EUR", totalMetalValue), fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Efectivo Liquidado (EUR)", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.5f))
                            Text(String.format("%,.2f EUR", client.cashBalanceEur), fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        // Detailed holdings split ORO vs PLATA
        item {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                // Gold Detail Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("ORO", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = GoldAccent)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(String.format("%,.2f EUR", totalGoldValue), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(String.format("Total: %,.3f g", allocatedGoldWeight + client.unallocatedGoldGrams), fontSize = 11.sp, color = TextMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Asignado: " + String.format("%.1f g", allocatedGoldWeight), fontSize = 10.sp)
                        Text("No asignado: " + String.format("%.1f g", client.unallocatedGoldGrams), fontSize = 10.sp)
                    }
                }

                // Silver Detail Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                    border = BorderStroke(1.dp, SilverAccent.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("PLATA", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = SilverAccent)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(String.format("%,.2f EUR", totalSilverValue), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(String.format("Total: %,.3f g", allocatedSilverWeight + client.unallocatedSilverGrams), fontSize = 11.sp, color = TextMuted)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Asignado: " + String.format("%.1f g", allocatedSilverWeight), fontSize = 10.sp)
                        Text("No asignado: " + String.format("%.1f g", client.unallocatedSilverGrams), fontSize = 10.sp)
                    }
                }
            }
        }

        // List of allocated physical bars with tracing details
        item {
            Text(
                "LINGOTES FÍSICOS ASIGNADOS EN CUSTODIA (CADENA DE CUSTODIA)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 20.dp, bottom = 12.dp)
            )
        }

        if (clientBars.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "No posee lingotes físicos asignados. Utilice la pantalla 'Operar' para adquirir lingotes con entrega asignada.",
                            style = MaterialTheme.typography.bodySmall,
                            textAlign = TextAlign.Center,
                            color = TextMuted
                        )
                    }
                }
            }
        } else {
            items(clientBars) { bar ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Filled.Verified,
                                    contentDescription = null,
                                    tint = if (bar.metal == Metal.ORO) GoldAccent else SilverAccent,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(bar.serialNumber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = when (bar.status) {
                                        BarStatus.ASIGNADO -> GreenSuccess.copy(alpha = 0.15f)
                                        BarStatus.RESERVADO -> AlertAmber.copy(alpha = 0.15f)
                                        else -> Color.Gray.copy(alpha = 0.15f)
                                    }
                                )
                            ) {
                                Text(
                                    bar.status.displayName,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (bar.status) {
                                        BarStatus.ASIGNADO -> GreenSuccess
                                        BarStatus.RESERVADO -> AlertAmber
                                        else -> Color.Gray
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(bar.productName, fontSize = 12.sp, fontWeight = FontWeight.Bold)

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Peso Bruto: ${bar.grossWeightGrams} g", fontSize = 11.sp, color = TextMuted)
                            Text("Pureza: ${bar.purity * 100}%", fontSize = 11.sp, color = TextMuted)
                            Text("Peso Fino: ${String.format("%.3f g", bar.fineWeightGrams)}", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Divider(modifier = Modifier.padding(vertical = 6.dp), color = Color.LightGray.copy(alpha = 0.2f))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Warehouse, contentDescription = null, modifier = Modifier.size(12.dp), tint = TextMuted)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Ubicación: ${bar.custodyLocation}", fontSize = 10.sp, color = TextMuted)
                            }
                            Text("Refinería: ${bar.refinery}", fontSize = 10.sp, color = TextMuted)
                        }
                    }
                }
            }
        }
    }
}

// --- Screen 4: Bullion Inventory / Vault & Logistics Screen ---
@Composable
fun InventoryScreen(viewModel: MarketViewModel) {
    val bars by viewModel.bars.collectAsState()
    val deliveryRequests by viewModel.deliveryRequests.collectAsState()
    val selectedClient by viewModel.selectedClient.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var locationFilter by remember { mutableStateOf("TODOS") }
    var metalFilter by remember { mutableStateOf("TODOS") }

    val locations = listOf("TODOS", "BÓVEDA MADRID", "BÓVEDA BARCELONA", "CUSTODIA EXTERNA", "EN TRÁNSITO")

    val filteredBars = bars.filter { bar ->
        val matchesSearch = bar.serialNumber.contains(searchQuery, ignoreCase = true) || bar.productName.contains(searchQuery, ignoreCase = true)
        val matchesLoc = locationFilter == "TODOS" || bar.custodyLocation == locationFilter
        val matchesMetal = metalFilter == "TODOS" || (metalFilter == "ORO" && bar.metal == Metal.ORO) || (metalFilter == "PLATA" && bar.metal == Metal.PLATA)
        matchesSearch && matchesLoc && matchesMetal
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("inventory_screen")
    ) {
        item {
            Text(
                "SISTEMA DE INVENTARIO Y BÓVEDAS (VAULTS)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // Search and filter area
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Buscar por número de serie o lingote") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        // Location filter
                        Box(modifier = Modifier.weight(1.5f)) {
                            var showLocDropdown by remember { mutableStateOf(false) }
                            OutlinedButton(onClick = { showLocDropdown = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Loc: $locationFilter", maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 11.sp)
                            }
                            DropdownMenu(expanded = showLocDropdown, onDismissRequest = { showLocDropdown = false }) {
                                locations.forEach { loc ->
                                    DropdownMenuItem(text = { Text(loc) }, onClick = {
                                        locationFilter = loc
                                        showLocDropdown = false
                                    })
                                }
                            }
                        }

                        // Metal filter
                        Box(modifier = Modifier.weight(1f)) {
                            var showMetalDropdown by remember { mutableStateOf(false) }
                            OutlinedButton(onClick = { showMetalDropdown = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Metal: $metalFilter", fontSize = 11.sp)
                            }
                            DropdownMenu(expanded = showMetalDropdown, onDismissRequest = { showMetalDropdown = false }) {
                                listOf("TODOS", "ORO", "PLATA").forEach { met ->
                                    DropdownMenuItem(text = { Text(met) }, onClick = {
                                        metalFilter = met
                                        showMetalDropdown = false
                                    })
                                }
                            }
                        }
                    }
                }
            }
        }

        // Vault status overview stats
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("TOTAL LINGOTES", fontSize = 10.sp, color = TextMuted)
                        Text("${bars.size}", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Mesa + Clientes", fontSize = 9.sp, color = TextMuted)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("DISPONIBLE MESA", fontSize = 10.sp, color = TextMuted)
                        Text("${bars.count { it.ownerId == null && it.status == BarStatus.DISPONIBLE }}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = GoldAccent)
                        Text("Para cotizaciones", fontSize = 9.sp, color = TextMuted)
                    }
                }

                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("ASIGNADO CLIENTE", fontSize = 10.sp, color = TextMuted)
                        Text("${bars.count { it.ownerId != null }}", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = GreenSuccess)
                        Text("En custodia directa", fontSize = 9.sp, color = TextMuted)
                    }
                }
            }
        }

        // List of bars
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("LINGOTES REGISTRADOS (${filteredBars.size})", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                Text("Mostrando hasta 30", fontSize = 11.sp, color = TextMuted)
            }
        }

        items(filteredBars.take(30)) { bar ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.5f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (bar.metal == Metal.ORO) Icons.Filled.Stars else Icons.Filled.Layers,
                                contentDescription = null,
                                tint = if (bar.metal == Metal.ORO) GoldAccent else SilverAccent,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(bar.serialNumber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Text(bar.productName, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("Ubicación: ${bar.custodyLocation} • Refinería: ${bar.refinery}", fontSize = 10.sp, color = TextMuted)
                    }

                    Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f)) {
                        Text(String.format("%.2f g", bar.fineWeightGrams), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(if (bar.ownerId == null) "Propio Mesa" else "Cliente: ${bar.ownerId}", fontSize = 10.sp, color = GoldAccent)

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = when (bar.status) {
                                    BarStatus.DISPONIBLE -> GreenSuccess.copy(alpha = 0.1f)
                                    BarStatus.ASIGNADO -> GoldAccent.copy(alpha = 0.1f)
                                    else -> AlertAmber.copy(alpha = 0.1f)
                                }
                            )
                        ) {
                            Text(
                                bar.status.displayName,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp),
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (bar.status) {
                                    BarStatus.DISPONIBLE -> GreenSuccess
                                    BarStatus.ASIGNADO -> GoldAccent
                                    else -> AlertAmber
                                }
                            )
                        }
                    }
                }
            }
        }

        // Logística / Physical Deliveries simulation
        item {
            Text(
                "SEGUIMIENTO DE LOGÍSTICA FÍSICA (ENTREGAS)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 20.dp, bottom = 12.dp)
            )
        }

        if (deliveryRequests.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(modifier = Modifier.padding(16.dp), contentAlignment = Alignment.Center) {
                        Text("No hay solicitudes de tránsito o recogida física activas.", fontSize = 11.sp, color = TextMuted)
                    }
                }
            }
        } else {
            items(deliveryRequests) { req ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(req.id, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Card(
                                colors = CardDefaults.cardColors(containerColor = GoldAccent)
                            ) {
                                Text(
                                    req.logisticsStatus,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Destinatario: ${req.clientName}", fontSize = 11.sp)
                        Text("Destino: ${req.destination}", fontSize = 11.sp)
                        Text("Formato de Entrega: ${req.deliveryType.displayName}", fontSize = 11.sp)
                        Text("Lingotes en tránsito: ${req.barIds.joinToString(", ")}", fontSize = 10.sp, color = TextMuted)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(String.format("Valor Asegurado: %,.2f EUR", req.insuredValueEur), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}

// --- Screen 5: Dealer Risk & Hedging Panel ---
@Composable
fun RiskScreen(viewModel: MarketViewModel) {
    val spotGold by viewModel.spotGold.collectAsState()
    val spotSilver by viewModel.spotSilver.collectAsState()
    val goldHedgeGrams by viewModel.goldHedgeGrams.collectAsState()
    val silverHedgeGrams by viewModel.silverHedgeGrams.collectAsState()

    val risk = viewModel.getRiskSnapshot()

    // Shock simulations
    var simulatedGoldPriceOffset by remember { mutableStateOf(0f) } // -20% to +20%
    var simulatedSilverPriceOffset by remember { mutableStateOf(0f) }

    val simulatedGoldSpot = spotGold * (1 + simulatedGoldPriceOffset)
    val simulatedSilverSpot = spotSilver * (1 + simulatedSilverPriceOffset)

    // Formula simulated P&L = NetExposureGrams * DeltaPricePerGram
    val goldPerG = spotGold / 31.1034768
    val simGoldPerG = simulatedGoldSpot / 31.1034768
    val goldDeltaPriceG = simGoldPerG - goldPerG
    val goldSimPnL = -risk.goldNetExposureGrams * goldDeltaPriceG // short exposure suffers when price goes up

    val silverPerG = spotSilver / 31.1034768
    val simSilverPerG = simulatedSilverSpot / 31.1034768
    val silverDeltaPriceG = simSilverPerG - silverPerG
    val silverSimPnL = -risk.silverNetExposureGrams * silverDeltaPriceG

    val totalSimPnL = goldSimPnL + silverSimPnL

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("risk_screen")
    ) {
        item {
            Text(
                "ANÁLISIS DE RIESGO Y COBERTURAS (HEDGING)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // Exposure Cards ORO
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, GoldAccent.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("EXPOSICIÓN GLOBAL DE ORO (Au)", fontWeight = FontWeight.Bold, color = GoldAccent)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Pasivos Totales Clientes:", fontSize = 11.sp)
                        Text(String.format("%,.3f g", risk.goldClientLiabilitiesGrams), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Inventario Físico Propio:", fontSize = 11.sp)
                        Text(String.format("%,.3f g", risk.goldInventoryGrams), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Coberturas en Derivados:", fontSize = 11.sp)
                        Text(String.format("%,.3f g", goldHedgeGrams), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = GreenSuccess)
                    }

                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("EXPOSICIÓN NETA:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(
                            String.format("%,.3f g", risk.goldNetExposureGrams),
                            fontWeight = FontWeight.Bold,
                            color = if (risk.goldNetExposureGrams.absoluteValue < 1000) GreenSuccess else AlertAmber
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.executeDealerHedge(Metal.ORO, risk.goldNetExposureGrams) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
                    ) {
                        Icon(Icons.Filled.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Autocubrir Desbalance de Oro", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Exposure Cards PLATA
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, SilverAccent.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("EXPOSICIÓN GLOBAL DE PLATA (Ag)", fontWeight = FontWeight.Bold, color = SilverAccent)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Pasivos Totales Clientes:", fontSize = 11.sp)
                        Text(String.format("%,.3f g", risk.silverClientLiabilitiesGrams), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Inventario Físico Propio:", fontSize = 11.sp)
                        Text(String.format("%,.3f g", risk.silverInventoryGrams), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Coberturas en Derivados:", fontSize = 11.sp)
                        Text(String.format("%,.3f g", silverHedgeGrams), fontWeight = FontWeight.Bold, fontSize = 11.sp, color = GreenSuccess)
                    }

                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("EXPOSICIÓN NETA:", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Text(
                            String.format("%,.3f g", risk.silverNetExposureGrams),
                            fontWeight = FontWeight.Bold,
                            color = if (risk.silverNetExposureGrams.absoluteValue < 5000) GreenSuccess else AlertAmber
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.executeDealerHedge(Metal.PLATA, risk.silverNetExposureGrams) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = SilverAccent)
                    ) {
                        Icon(Icons.Filled.Security, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Autocubrir Desbalance de Plata", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Simulation Stress Testing Lab
        item {
            Text(
                "SIMULACIÓN DE PRUEBAS DE ESFUERZO (STRESS TESTING)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 12.dp)
            )

            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Desplace para simular shocks en precios y ver impacto financiero en la mesa", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(12.dp))

                    // Gold Shock slider
                    Text("Shock de Oro: " + String.format("%+d%%", (simulatedGoldPriceOffset * 100).toInt()), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Slider(
                        value = simulatedGoldPriceOffset,
                        onValueChange = { simulatedGoldPriceOffset = it },
                        valueRange = -0.3f..0.3f,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Silver Shock slider
                    Text("Shock de Plata: " + String.format("%+d%%", (simulatedSilverPriceOffset * 100).toInt()), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Slider(
                        value = simulatedSilverPriceOffset,
                        onValueChange = { simulatedSilverPriceOffset = it },
                        valueRange = -0.3f..0.3f,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Divider(modifier = Modifier.padding(vertical = 8.dp))

                    // P&L simulated outcome
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Impacto Estimado en P&L Mesa:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(
                            text = String.format("%+,.2f EUR", totalSimPnL),
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (totalSimPnL >= 0) GreenSuccess else AlertBurgundy
                        )
                    }
                }
            }
        }
    }
}

// --- Screen 6: Compliance and Audit Trail Screen ---
@Composable
fun ComplianceScreen(viewModel: MarketViewModel) {
    val alerts by viewModel.complianceAlerts.collectAsState()
    val auditEvents by viewModel.auditEvents.collectAsState()

    var activeAlertIdForResolution by remember { mutableStateOf<String?>(null) }
    var resolutionNotes by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("compliance_screen")
    ) {
        item {
            Text(
                "MONITORIZACIÓN DE CUMPLIMIENTO (COMPLIANCE)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        // Active Alerts header
        item {
            Text(
                "ALERTAS PREVENTIVAS ACTULIZADAS",
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = AlertBurgundy,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        if (alerts.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text("No hay alertas de cumplimiento pendientes de revisión analítica.", style = MaterialTheme.typography.bodySmall, color = TextMuted)
                    }
                }
            }
        } else {
            items(alerts) { alert ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(
                        width = 1.2.dp,
                        color = when (alert.severity) {
                            AlertSeverity.ALTA -> AlertBurgundy
                            AlertSeverity.MEDIA -> AlertAmber
                            AlertSeverity.BAJA -> Color.Gray
                        }
                    )
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(alert.id, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = TextMuted)
                            Card(
                                colors = CardDefaults.cardColors(
                                    containerColor = when (alert.status) {
                                        AlertStatus.PENDIENTE -> AlertBurgundy.copy(alpha = 0.15f)
                                        AlertStatus.INVESTIGADO -> AlertAmber.copy(alpha = 0.15f)
                                        else -> Color.Gray.copy(alpha = 0.15f)
                                    }
                                )
                            ) {
                                Text(
                                    alert.status.displayName,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (alert.status) {
                                        AlertStatus.PENDIENTE -> AlertBurgundy
                                        AlertStatus.INVESTIGADO -> AlertAmber
                                        else -> Color.Gray
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(alert.ruleName, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                        Text(alert.description, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("Cliente: ${alert.clientName} (ID: ${alert.clientId})", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text("Notas de Analista: ${alert.analystNotes}", fontSize = 10.sp, color = TextMuted)

                        if (alert.status == AlertStatus.PENDIENTE || alert.status == AlertStatus.INVESTIGADO) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                Button(
                                    onClick = {
                                        activeAlertIdForResolution = alert.id
                                        resolutionNotes = ""
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldAccent),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    shape = RoundedCornerShape(2.dp)
                                ) {
                                    Text("Resolver Alerta", fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Audit Trail chronological listing
        item {
            Text(
                "TRAZA DE AUDITORÍA CRONOLÓGICA (AUDIT TRAIL)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 24.dp, bottom = 12.dp)
            )
        }

        items(auditEvents) { event ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(event.id, fontWeight = FontWeight.Bold, fontSize = 10.sp, color = TextMuted)
                        Text(
                            SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault()).format(Date(event.timestamp)),
                            fontSize = 9.sp,
                            color = TextMuted
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("[${event.actor}] - ${event.action}", fontWeight = FontWeight.Bold, fontSize = 11.sp, color = GoldAccent)
                    Text(event.description, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Correlación: ${event.correlationId}", fontSize = 9.sp, color = TextMuted)
                        Text("ID Destino: ${event.targetId}", fontSize = 9.sp, color = TextMuted)
                    }
                }
            }
        }
    }

    // Interactive Resolution Dialog
    activeAlertIdForResolution?.let { alertId ->
        Dialog(onDismissRequest = { activeAlertIdForResolution = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("RESOLVER ALERTA $alertId", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = resolutionNotes,
                        onValueChange = { resolutionNotes = it },
                        label = { Text("Notas analíticas / Conclusiones") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { activeAlertIdForResolution = null }, modifier = Modifier.weight(1f)) {
                            Text("Cancelar")
                        }
                        Button(
                            onClick = {
                                viewModel.resolveComplianceAlert(alertId, AlertStatus.ARCHIVADO, resolutionNotes)
                                activeAlertIdForResolution = null
                            },
                            modifier = Modifier.weight(1.5f),
                            colors = ButtonDefaults.buttonColors(containerColor = GreenSuccess)
                        ) {
                            Text("Confirmar y Archivar")
                        }
                    }
                }
            }
        }
    }
}

// --- Screen 7: Spanish Institutional Reports Screen ---
@Composable
fun ReportsScreen(viewModel: MarketViewModel) {
    val selectedClient by viewModel.selectedClient.collectAsState()
    val trades by viewModel.trades.collectAsState()
    val bars by viewModel.bars.collectAsState()

    var activeReportData by remember { mutableStateOf<ReportDisplayData?>(null) }

    val format = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("reports_screen")
    ) {
        item {
            Text(
                "CENTRO DE INFORMES INSTITUCIONALES",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 12.dp)
            )
        }

        val itemsList = listOf(
            Triple("Estado de Cartera de Metales", "Resumen valorado y desglose de peso asignado/no asignado por metal.", "ESTADO_CARTERA"),
            Triple("Certificado de Custodia Física Asignada", "Documento formal certificando la titularidad de los lingotes serializados.", "CERTIFICADO_CUSTODIA"),
            Triple("Informe de Exposición y Riesgo Mesa", "Cálculo formal de desbalances de bóvedas y posiciones de derivados.", "RISK_REPORT"),
            Triple("Confirmación de Operaciones de Compra/Venta", "Trade Ticket institucional con ID de transacciones, pesos finos y contrapartida.", "TRADE_TICKET")
        )

        items(itemsList) { item ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(2f)) {
                        Text(item.first, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(item.second, fontSize = 11.sp, color = TextMuted)
                    }
                    Button(
                        onClick = {
                            val clientName = selectedClient?.name ?: "SISTEMA INTEGRAL"
                            val clientCategory = selectedClient?.category?.displayName ?: "ADMINISTRATIVO"
                            val timestampStr = format.format(Date())

                            val content = when (item.third) {
                                "ESTADO_CARTERA" -> {
                                    val clientBars = bars.filter { it.ownerId == selectedClient?.id }
                                    """
                                    =========================================
                                    INFORMES DE CORRETAJE ORO & PLATA S.A.
                                    =========================================
                                    TÍTULO: ESTADO DE CARTERA DE METALES
                                    GENERADO EL: $timestampStr
                                    VERSIÓN DEL MOTOR: Gemini 3.5 Pro / OP-v1.8
                                    
                                    TITULAR DE CUENTA: $clientName
                                    CATEGORÍA: $clientCategory
                                    
                                    DESGLOSE DE METALES EN CUSTODIA:
                                    - ORO ASIGNADO FÍSICO: ${clientBars.filter { it.metal == Metal.ORO }.sumOf { it.fineWeightGrams }} g fine
                                    - PLATA ASIGNADA FÍSICA: ${clientBars.filter { it.metal == Metal.PLATA }.sumOf { it.fineWeightGrams }} g fine
                                    - BALANCE ORO NO ASIGNADO: ${selectedClient?.unallocatedGoldGrams} g
                                    - BALANCE PLATA NO ASIGNADA: ${selectedClient?.unallocatedSilverGrams} g
                                    
                                    EFECTIVO DISPONIBLE:
                                    - EUR: ${selectedClient?.cashBalanceEur} EUR
                                    - USD: ${selectedClient?.cashBalanceUsd} USD
                                    
                                    DECLARACIÓN DE INTEGRIDAD:
                                    Los saldos representados en esta traza coinciden plenamente con las conciliaciones diarias de bóvedas físicas en los centros de Madrid y Barcelona.
                                    """.trimIndent()
                                }
                                "CERTIFICADO_CUSTODIA" -> {
                                    val clientBars = bars.filter { it.ownerId == selectedClient?.id }
                                    val barLines = clientBars.joinToString("\n") { bar ->
                                        "  - SERIE: ${bar.serialNumber} | Peso Fino: ${bar.fineWeightGrams} g (${bar.purity * 100}%) | Ubicación: ${bar.custodyLocation}"
                                    }
                                    """
                                    =========================================
                                    CERTIFICADO OFICIAL DE CUSTODIA ASIGNADA
                                    =========================================
                                    CERTIFICADO ID: CERT-ES-${kotlin.random.Random.nextInt(100000, 999999)}
                                    GENERADO EL: $timestampStr
                                    
                                    Por medio del presente documento, ORO & PLATA certifica la titularidad legítima y segregada de los siguientes lingotes físicos de inversión custodiados a nombre del cliente: $clientName
                                    
                                    LINGOTES CON TITULARIDAD EXCLUSIVA:
                                    $barLines
                                    
                                    GARANTÍA DE SEGREGACIÓN:
                                    Cada lingote físico detallado anteriormente cuenta con asignación física real y serializada, aislado de las liabilities generales del intermediario. Las bóvedas de custodia cuentan con seguro a todo riesgo provisto por consorcios europeos de primer nivel.
                                    """.trimIndent()
                                }
                                "RISK_REPORT" -> {
                                    val snapshot = viewModel.getRiskSnapshot()
                                    """
                                    =========================================
                                    INFORME DE EXPOSICIÓN DE RIESGO DE LA MESA
                                    =========================================
                                    INFORME ID: RISK-ES-${kotlin.random.Random.nextInt(10000, 99999)}
                                    EMITIDO EL: $timestampStr
                                    
                                    MESA DE TRADING: ORO & PLATA Madrid Trading Desk
                                    
                                    ESTADO DE EXPOSICIÓN NETO EN GRAMOS (Au/Ag):
                                    - Pasivos Oro Clientes (Short offset): ${snapshot.goldClientLiabilitiesGrams} g
                                    - Inventario Físico de Oro (Long asset): ${snapshot.goldInventoryGrams} g
                                    - Coberturas de Oro: ${snapshot.totalHedgedGoldGrams} g
                                    - EXPOSICIÓN NETA ORO: ${snapshot.goldNetExposureGrams} g
                                    
                                    - Pasivos Plata Clientes (Short offset): ${snapshot.silverClientLiabilitiesGrams} g
                                    - Inventario Físico de Plata (Long asset): ${snapshot.silverInventoryGrams} g
                                    - Coberturas de Plata: ${snapshot.totalHedgedSilverGrams} g
                                    - EXPOSICIÓN NETA PLATA: ${snapshot.silverNetExposureGrams} g
                                    
                                    MÉTRICAS DE COMPORTAMIENTO:
                                    - Ratio de Cobertura de Oro: ${if (snapshot.goldClientLiabilitiesGrams > 0) (snapshot.goldInventoryGrams + snapshot.totalHedgedGoldGrams) / snapshot.goldClientLiabilitiesGrams * 100 else 100.0}%
                                    - Ratio de Cobertura de Plata: ${if (snapshot.silverClientLiabilitiesGrams > 0) (snapshot.silverInventoryGrams + snapshot.totalHedgedSilverGrams) / snapshot.silverClientLiabilitiesGrams * 100 else 100.0}%
                                    """.trimIndent()
                                }
                                else -> {
                                    val lastTrade = trades.lastOrNull { t -> t.clientId == selectedClient?.id }
                                    if (lastTrade == null) {
                                        "No se registran operaciones comerciales recientes para este cliente en la sesión de hoy."
                                    } else {
                                        """
                                        =========================================
                                        TICKET DE CONFIRMACIÓN DE OPERACIÓN
                                        =========================================
                                        TRADE ID: ${lastTrade.id}
                                        EJECUTADO EL: ${format.format(Date(lastTrade.timestamp))}
                                        
                                        CONTRAPARTIDA: ORO & PLATA Madrid Desk
                                        CLIENTE: ${lastTrade.clientName}
                                        PRODUCTO: ${lastTrade.productName}
                                        CANTIDAD: ${lastTrade.quantity} unidades
                                        TIPO DE ORDEN: ${if (lastTrade.isBuy) "COMPRA" else "VENTA"}
                                        
                                        PRECIO EJECUCIÓN: ${lastTrade.executionPriceEur} EUR / u
                                        VALOR BRUTO: ${lastTrade.totalEur} EUR
                                        
                                        LINGOTES FÍSICOS TRANSFERIDOS:
                                        ${if (lastTrade.allocatedBarIds.isNotEmpty()) lastTrade.allocatedBarIds.joinToString(", ") else "Metales no asignados"}
                                        
                                        LIQUIDACIÓN: Completada por compensación bancaria directa.
                                        """.trimIndent()
                                    }
                                }
                            }

                            activeReportData = ReportDisplayData(
                                title = item.first,
                                content = content
                            )
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = GoldAccent)
                    ) {
                        Text("Ver", fontSize = 11.sp)
                    }
                }
            }
        }
    }

    // Modal display for report
    activeReportData?.let { report ->
        Dialog(onDismissRequest = { activeReportData = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                shape = RoundedCornerShape(4.dp)
            ) {
                Column(
                    modifier = Modifier
                        .background(NavyDark)
                        .padding(16.dp)
                ) {
                    Text(
                        text = report.title.uppercase(),
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.titleMedium,
                        color = GoldAccent
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f, fill = false)
                            .background(Color.Black.copy(alpha = 0.5f))
                            .border(1.dp, GoldAccent.copy(alpha = 0.3f))
                            .verticalScroll(rememberScrollState())
                            .padding(12.dp)
                    ) {
                        Text(
                            text = report.content,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = Color.White
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(
                            onClick = { activeReportData = null },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Text("Cerrar Certificado")
                        }
                    }
                }
            }
        }
    }
}

data class ReportDisplayData(
    val title: String,
    val content: String
)

// --- Screen 8: Clients List Management (Demo Seeder View) ---
@Composable
fun ClientsManagementScreen(viewModel: MarketViewModel) {
    val clients by viewModel.clients.collectAsState()
    val selectedClient by viewModel.selectedClient.collectAsState()

    var searchQuery by remember { mutableStateOf("") }

    val filtered = clients.filter {
        it.name.contains(searchQuery, ignoreCase = true) || it.id.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("clients_screen")
    ) {
        Text(
            "GESTIÓN Y BÚSQUEDA DE PORTAFOLIOS DE CLIENTES",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            label = { Text("Buscar cliente por nombre o código de cuenta") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 16.dp),
            singleLine = true
        )

        Text(
            "Carteras encontradas (${filtered.size})",
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        Box(modifier = Modifier.weight(1f)) {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(filtered.take(50)) { client ->
                    val isSelected = client.id == selectedClient?.id
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { viewModel.selectClient(client) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) LightSurfaceGold else MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, if (isSelected) GoldAccent else Color.LightGray.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    client.name,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = if (isSelected) GoldAccent else MaterialTheme.colorScheme.onSurface
                                )
                                Text("ID: ${client.id} | Cuenta: ${client.accountNumber}", fontSize = 11.sp, color = TextMuted)
                                Text("Categoría: ${client.category.displayName}", fontSize = 11.sp, color = GoldAccent)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(String.format("%,.2f %s", client.cashBalanceEur, "EUR"), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text("Oro: ${String.format("%.1f g", client.unallocatedGoldGrams)}", fontSize = 10.sp, color = TextMuted)
                            }
                        }
                    }
                }
            }
        }
    }
}
