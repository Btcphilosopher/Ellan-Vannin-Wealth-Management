package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.math.sqrt
import kotlin.random.Random

enum class UserRole {
    CLIENTE,
    INSTITUCIONAL,
    MESA_DE_OPERACIONES
}

enum class MarketRegime {
    NORMAL,
    VOLATILIDAD_ALTA,
    SHOCK_ALCISTA,
    SHOCK_BAJISTA,
    LIQUIDEZ_REDUCIDA,
    SPREAD_AMPLIADO,
    DEMANDA_FISICA_ELEVADA,
    INVENTARIO_REDUCIDO
}

class MarketViewModel : ViewModel() {

    // --- Market Spot Prices (EUR/oz) ---
    private val _spotGold = MutableStateFlow(2410.50)
    val spotGold: StateFlow<Double> = _spotGold

    private val _spotSilver = MutableStateFlow(29.85)
    val spotSilver: StateFlow<Double> = _spotSilver

    private val _gold24hChange = MutableStateFlow(1.45) // Percentage
    val gold24hChange: StateFlow<Double> = _gold24hChange

    private val _silver24hChange = MutableStateFlow(-0.85) // Percentage
    val silver24hChange: StateFlow<Double> = _silver24hChange

    // --- Price Units ---
    // Supported: EUR/oz, USD/oz, EUR/kg, EUR/g
    private val _selectedUnit = MutableStateFlow("EUR/oz")
    val selectedUnit: StateFlow<String> = _selectedUnit

    // --- Exchange Rate EUR/USD ---
    val eurToUsdRate = 1.0825

    // --- Simulation State ---
    private val _isSimulating = MutableStateFlow(true)
    val isSimulating: StateFlow<Boolean> = _isSimulating

    private val _simulationSpeedMs = MutableStateFlow(2000L) // tick speed
    val simulationSpeedMs: StateFlow<Long> = _simulationSpeedMs

    private val _marketRegime = MutableStateFlow(MarketRegime.NORMAL)
    val marketRegime: StateFlow<MarketRegime> = _marketRegime

    // --- Dealer Settings ---
    private val _dealerGoldSpreadEur = MutableStateFlow(3.5) // EUR/oz
    val dealerGoldSpreadEur: StateFlow<Double> = _dealerGoldSpreadEur

    private val _dealerSilverSpreadEur = MutableStateFlow(0.15) // EUR/oz
    val dealerSilverSpreadEur: StateFlow<Double> = _dealerSilverSpreadEur

    private val _dealerMarginPercent = MutableStateFlow(0.005) // 0.5% default broker margin
    val dealerMarginPercent: StateFlow<Double> = _dealerMarginPercent

    // --- Core Data Stores ---
    private val _clients = MutableStateFlow<List<Client>>(emptyList())
    val clients: StateFlow<List<Client>> = _clients

    private val _bars = MutableStateFlow<List<Bar>>(emptyList())
    val bars: StateFlow<List<Bar>> = _bars

    private val _quotes = MutableStateFlow<List<Quote>>(emptyList())
    val quotes: StateFlow<List<Quote>> = _quotes

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    val orders: StateFlow<List<Order>> = _orders

    private val _trades = MutableStateFlow<List<Trade>>(emptyList())
    val trades: StateFlow<List<Trade>> = _trades

    private val _settlements = MutableStateFlow<List<Settlement>>(emptyList())
    val settlements: StateFlow<List<Settlement>> = _settlements

    private val _deliveryRequests = MutableStateFlow<List<DeliveryRequest>>(emptyList())
    val deliveryRequests: StateFlow<List<DeliveryRequest>> = _deliveryRequests

    private val _complianceAlerts = MutableStateFlow<List<ComplianceAlert>>(emptyList())
    val complianceAlerts: StateFlow<List<ComplianceAlert>> = _complianceAlerts

    private val _auditEvents = MutableStateFlow<List<AuditEvent>>(emptyList())
    val auditEvents: StateFlow<List<AuditEvent>> = _auditEvents

    // --- Current Active User (Demo context) ---
    private val _currentRole = MutableStateFlow(UserRole.CLIENTE)
    val currentRole: StateFlow<UserRole> = _currentRole

    private val _selectedClient = MutableStateFlow<Client?>(null)
    val selectedClient: StateFlow<Client?> = _selectedClient

    // --- Hedge Sim State ---
    private val _goldHedgeGrams = MutableStateFlow(0.0)
    val goldHedgeGrams: StateFlow<Double> = _goldHedgeGrams

    private val _silverHedgeGrams = MutableStateFlow(0.0)
    val silverHedgeGrams: StateFlow<Double> = _silverHedgeGrams

    // --- Navigation Screen (custom in-app state switching) ---
    private val _currentScreen = MutableStateFlow("dashboard") // dashboard, trading, orders, inventory, compliance, risk, reports, clients
    val currentScreen: StateFlow<String> = _currentScreen

    // --- Historical Spot Data (For Charts) ---
    private val _goldHistory = MutableStateFlow<List<Double>>(emptyList())
    val goldHistory: StateFlow<List<Double>> = _goldHistory

    private val _silverHistory = MutableStateFlow<List<Double>>(emptyList())
    val silverHistory: StateFlow<List<Double>> = _silverHistory

    // Correlation ID generator
    private var currentCorrelationId = "CORR-000000"

    private var simulationJob: Job? = null
    private var quoteExpiryJob: Job? = null

    init {
        resetToInitialDemo()
        startSimulation()
        startQuoteExpiryTimer()
    }

    fun setScreen(screenName: String) {
        _currentScreen.value = screenName
    }

    fun setRole(role: UserRole) {
        _currentRole.value = role
        // Auto-select first client if switching to client or institutional role
        if (role != UserRole.MESA_DE_OPERACIONES && _selectedClient.value == null) {
            _selectedClient.value = _clients.value.find { it.id == "CLI-005" } ?: _clients.value.firstOrNull()
        }
    }

    fun selectClient(client: Client) {
        _selectedClient.value = client
        logAudit(
            actor = "SISTEMA",
            action = "SELECCIONAR_CLIENTE",
            targetId = client.id,
            description = "Cambio de cliente activo a: ${client.name}",
            beforeState = "",
            afterState = client.id
        )
    }

    fun setSelectedUnit(unit: String) {
        _selectedUnit.value = unit
    }

    fun toggleSimulation() {
        _isSimulating.update { !it }
        logAudit(
            actor = "MESA_DE_OPERACIONES",
            action = "TOGGLE_SIMULACION",
            targetId = "MOTOR_MERCADO",
            description = if (_isSimulating.value) "Simulación de mercado reanudada" else "Simulación de mercado pausada",
            beforeState = (!_isSimulating.value).toString(),
            afterState = _isSimulating.value.toString()
        )
    }

    fun setSimulationSpeed(speedMs: Long) {
        _simulationSpeedMs.value = speedMs
    }

    fun changeRegime(regime: MarketRegime) {
        _marketRegime.value = regime
        logAudit(
            actor = "MESA_DE_OPERACIONES",
            action = "CAMBIO_REGIMEN_MERCADO",
            targetId = "MOTOR_MERCADO",
            description = "Régimen del mercado actualizado a: ${regime.name}",
            beforeState = "",
            afterState = regime.name
        )

        // Apply instant scenario shocks or volatility adjustments
        when (regime) {
            MarketRegime.VOLATILIDAD_ALTA -> {
                _dealerGoldSpreadEur.value = 12.0
                _dealerSilverSpreadEur.value = 0.55
            }
            MarketRegime.SHOCK_ALCISTA -> {
                _spotGold.update { it * 1.05 }
                _spotSilver.update { it * 1.08 }
                _gold24hChange.update { it + 5.0 }
                _silver24hChange.update { it + 8.0 }
            }
            MarketRegime.SHOCK_BAJISTA -> {
                _spotGold.update { it * 0.95 }
                _spotSilver.update { it * 0.92 }
                _gold24hChange.update { it - 5.0 }
                _silver24hChange.update { it - 8.0 }
            }
            MarketRegime.LIQUIDEZ_REDUCIDA -> {
                _dealerGoldSpreadEur.value = 25.0
                _dealerSilverSpreadEur.value = 1.20
            }
            MarketRegime.SPREAD_AMPLIADO -> {
                _dealerGoldSpreadEur.value = 18.5
                _dealerSilverSpreadEur.value = 0.95
            }
            MarketRegime.DEMANDA_FISICA_ELEVADA -> {
                _dealerMarginPercent.value = 0.015 // Increase premium to 1.5%
            }
            MarketRegime.INVENTARIO_REDUCIDO -> {
                _dealerGoldSpreadEur.value = 10.0
            }
            MarketRegime.NORMAL -> {
                _dealerGoldSpreadEur.value = 3.5
                _dealerSilverSpreadEur.value = 0.15
                _dealerMarginPercent.value = 0.005
            }
        }
    }

    fun adjustGoldSpread(newValue: Double) {
        _dealerGoldSpreadEur.value = newValue
    }

    fun adjustSilverSpread(newValue: Double) {
        _dealerSilverSpreadEur.value = newValue
    }

    fun adjustDealerMargin(newValue: Double) {
        _dealerMarginPercent.value = newValue
    }

    fun resetToInitialDemo() {
        val initialClients = DemoData.generateClients()
        val initialBars = DemoData.generateBars(initialClients)
        val initialOrders = DemoData.generateHistoricalOrders(initialClients)
        val initialTrades = DemoData.generateHistoricalTrades(initialOrders, initialBars)
        val initialSettlements = DemoData.generateHistoricalSettlements(initialTrades)
        val initialAlerts = DemoData.generateInitialAlerts(initialClients)

        _clients.value = initialClients
        _bars.value = initialBars
        _orders.value = initialOrders
        _trades.value = initialTrades
        _settlements.value = initialSettlements
        _complianceAlerts.value = initialAlerts

        // Historical spots
        val r = Random(101)
        val goldHist = mutableListOf<Double>()
        val silverHist = mutableListOf<Double>()
        var g = 2410.50
        var s = 29.85
        for (i in 1..20) {
            g += r.nextDouble(-8.0, 9.0)
            s += r.nextDouble(-0.3, 0.35)
            goldHist.add(g)
            silverHist.add(s)
        }
        _goldHistory.value = goldHist
        _silverHistory.value = silverHist

        _spotGold.value = 2410.50
        _spotSilver.value = 29.85
        _gold24hChange.value = 1.45
        _silver24hChange.value = -0.85

        _goldHedgeGrams.value = 0.0
        _silverHedgeGrams.value = 0.0

        _quotes.value = emptyList()
        _deliveryRequests.value = emptyList()

        _auditEvents.value = listOf(
            AuditEvent(
                id = "AUD-ES-0001",
                timestamp = System.currentTimeMillis() - 86400000,
                actor = "SISTEMA",
                action = "INICIALIZAR_ENTORNO",
                targetId = "DEMO_01",
                description = "Entorno de corretaje de metales ORO & PLATA inicializado correctamente con 1,000 clientes, catálogo institucional y 3,000 lingotes serializados asignados.",
                beforeState = "VACÍO",
                afterState = "PREPARADO_DEMO_01",
                correlationId = "CORR-000001"
            )
        )

        // Select default client
        _selectedClient.value = _clients.value.find { it.id == "CLI-005" }
    }

    // --- Market Ticker Ticking Logic ---
    private fun startSimulation() {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            val random = java.util.Random(System.currentTimeMillis())
            while (true) {
                delay(_simulationSpeedMs.value)
                if (_isSimulating.value) {
                    // Update Prices
                    val drift = 0.0001
                    var volG = 0.001
                    var volS = 0.0025

                    // Affect drift & vol based on regimes
                    when (_marketRegime.value) {
                        MarketRegime.VOLATILIDAD_ALTA -> {
                            volG *= 4.0
                            volS *= 4.5
                        }
                        MarketRegime.SHOCK_ALCISTA -> {
                            volG *= 1.5
                            volS *= 1.5
                        }
                        MarketRegime.SHOCK_BAJISTA -> {
                            volG *= 1.5
                            volS *= 1.5
                        }
                        MarketRegime.LIQUIDEZ_REDUCIDA -> {
                            volG *= 2.0
                            volS *= 2.0
                        }
                        MarketRegime.SPREAD_AMPLIADO -> {
                            volG *= 1.2
                        }
                        else -> {}
                    }

                    val gChange = (drift + volG * random.nextGaussian())
                    val sChange = (drift + volS * random.nextGaussian())

                    _spotGold.update { (it * (1.0 + gChange)).coerceAtLeast(100.0) }
                    _spotSilver.update { (it * (1.0 + sChange)).coerceAtLeast(1.0) }

                    // Add to history (keep last 30)
                    _goldHistory.update { (it + _spotGold.value).takeLast(35) }
                    _silverHistory.update { (it + _spotSilver.value).takeLast(35) }

                    // Accumulate 24h Change
                    _gold24hChange.update { (it + gChange * 100).coerceIn(-10.0, 10.0) }
                    _silver24hChange.update { (it + sChange * 100).coerceIn(-15.0, 15.0) }

                    // Occasionally trigger minor compliance alerts randomly for visual variety!
                    if (random.nextDouble() < 0.03) {
                        triggerRandomComplianceAlert()
                    }
                }
            }
        }
    }

    private fun startQuoteExpiryTimer() {
        quoteExpiryJob?.cancel()
        quoteExpiryJob = viewModelScope.launch {
            while (true) {
                delay(1000L)
                _quotes.update { currentList ->
                    currentList.mapNotNull { quote ->
                        if (quote.validForSeconds > 1) {
                            quote.copy(validForSeconds = quote.validForSeconds - 1)
                        } else {
                            // Expired
                            logAudit(
                                actor = "SISTEMA",
                                action = "CADUCIDAD_COTIZACION",
                                targetId = quote.id,
                                description = "Cotización de ${quote.metal.displayName} para ${quote.clientName} ha caducado por validez temporal (30s)",
                                beforeState = "VÁLIDA",
                                afterState = "CADUCADA"
                            )
                            null // removes it
                        }
                    }
                }
            }
        }
    }

    // --- Helpers for price conversions ---
    fun getMidPriceInUnit(metal: Metal, unit: String): Double {
        val spot = if (metal == Metal.ORO) _spotGold.value else _spotSilver.value
        return convertOzSpotToUnit(spot, unit)
    }

    fun getBidPriceInUnit(metal: Metal, unit: String): Double {
        val spot = if (metal == Metal.ORO) _spotGold.value else _spotSilver.value
        val spread = if (metal == Metal.ORO) _dealerGoldSpreadEur.value else _dealerSilverSpreadEur.value
        val bidEur = spot - (spread / 2.0)
        return convertOzSpotToUnit(bidEur, unit)
    }

    fun getAskPriceInUnit(metal: Metal, unit: String): Double {
        val spot = if (metal == Metal.ORO) _spotGold.value else _spotSilver.value
        val spread = if (metal == Metal.ORO) _dealerGoldSpreadEur.value else _dealerSilverSpreadEur.value
        val askEur = spot + (spread / 2.0)
        return convertOzSpotToUnit(askEur, unit)
    }

    private fun convertOzSpotToUnit(priceEurPerOz: Double, unit: String): Double {
        // 1 troy ounce = 31.1034768 grams
        val gramsPerOz = 31.1034768
        return when (unit) {
            "EUR/oz" -> priceEurPerOz
            "USD/oz" -> priceEurPerOz * eurToUsdRate
            "EUR/kg" -> (priceEurPerOz / gramsPerOz) * 1000.0
            "EUR/g" -> priceEurPerOz / gramsPerOz
            else -> priceEurPerOz
        }
    }

    // --- Pricing Engine Breakdown Calculation ---
    fun calculateCostBreakdown(product: Product, quantity: Int, isBuy: Boolean): DetailedCostBreakdown {
        val spotPerG = getMidPriceInUnit(product.metal, "EUR/g")
        val fineWeight = product.weightGrams * product.purity
        val metalValueSingle = spotPerG * fineWeight

        val premiumSingle = metalValueSingle * product.premiumPercent
        val mfgSingle = product.manufacturingCostEur
        val custodySingle = metalValueSingle * 0.002 // Simulated custody fee component
        val dealerSingle = metalValueSingle * _dealerMarginPercent.value
        val logisticsSingle = product.weightGrams * 0.015 // €0.015 per gram logistics

        val unitPrice = metalValueSingle + premiumSingle + mfgSingle + custodySingle + dealerSingle + logisticsSingle
        val finalUnitPrice = if (isBuy) unitPrice else metalValueSingle * 0.985 // Selling back has a discount instead of premiums

        val totalMetalValue = metalValueSingle * quantity
        val totalPremium = premiumSingle * quantity
        val totalMfg = mfgSingle * quantity
        val totalCustody = custodySingle * quantity
        val totalDealer = dealerSingle * quantity
        val totalLogistics = logisticsSingle * quantity
        val totalSum = finalUnitPrice * quantity

        return DetailedCostBreakdown(
            metal = product.metal,
            productName = product.name,
            quantity = quantity,
            metalValue = totalMetalValue,
            premium = if (isBuy) totalPremium else 0.0,
            manufacturing = if (isBuy) totalMfg else 0.0,
            custody = if (isBuy) totalCustody else 0.0,
            dealerMargin = if (isBuy) totalDealer else - (totalMetalValue * 0.015), // discount
            logistics = if (isBuy) totalLogistics else totalLogistics * 0.5,
            total = totalSum,
            unitPrice = finalUnitPrice
        )
    }

    // --- RFQ Engine ---
    fun requestRFQ(clientId: String, product: Product, quantity: Int, isBuy: Boolean): Quote {
        val client = _clients.value.find { it.id == clientId } ?: _clients.value.first()
        val breakdown = calculateCostBreakdown(product, quantity, isBuy)

        val newQuote = Quote(
            id = "RQ-ES-${String.format("%06d", Random.nextInt(100000, 999999))}",
            clientId = client.id,
            clientName = client.name,
            metal = product.metal,
            productId = product.id,
            productName = product.name,
            quantity = quantity,
            isBuy = isBuy,
            unitPriceEur = breakdown.unitPrice,
            premiumEur = breakdown.premium,
            totalEur = breakdown.total,
            currency = client.preferredCurrency,
            validForSeconds = 30,
            timestamp = System.currentTimeMillis()
        )

        _quotes.update { it + newQuote }

        logAudit(
            actor = "MOTOR_COTIZACION",
            action = "GENERAR_COTIZACION",
            targetId = newQuote.id,
            description = "Cotización generada para ${client.name}: ${quantity}x ${product.name}. Total: EUR ${String.format("%.2f", breakdown.total)}",
            beforeState = "NO_EXISTE",
            afterState = "COTIZADO_VALIDEZ_30S"
        )

        return newQuote
    }

    // --- Execution Engine ---
    fun executeQuote(quoteId: String): TradeResult {
        val quote = _quotes.value.find { id -> id.id == quoteId } ?: return TradeResult.Failure("Cotización no encontrada o caducada.")

        // 1. Lock/validate
        val client = _clients.value.find { it.id == quote.clientId } ?: return TradeResult.Failure("Cliente no encontrado.")

        if (quote.isBuy) {
            // Verify Cash
            val requiredCash = quote.totalEur
            if (client.cashBalanceEur < requiredCash) {
                return TradeResult.Failure("Fondos insuficientes en efectivo. Requerido: EUR ${String.format("%.2f", requiredCash)}, Disponible: EUR ${String.format("%.2f", client.cashBalanceEur)}")
            }
        } else {
            // Verify Client Holding (Allocated/Unallocated)
            val product = DemoData.productList.find { it.id == quote.productId } ?: return TradeResult.Failure("Producto inválido.")
            if (product.allocated) {
                val clientBarsCount = _bars.value.count { it.ownerId == client.id && it.productName == product.name }
                if (clientBarsCount < quote.quantity) {
                    return TradeResult.Failure("Lingotes asignados insuficientes. Cliente posee $clientBarsCount de los ${quote.quantity} requeridos.")
                }
            } else {
                val weightNeeded = product.weightGrams * quote.quantity
                if (product.metal == Metal.ORO && client.unallocatedGoldGrams < weightNeeded) {
                    return TradeResult.Failure("Balance de Oro no asignado insuficiente.")
                }
                if (product.metal == Metal.PLATA && client.unallocatedSilverGrams < weightNeeded) {
                    return TradeResult.Failure("Balance de Plata no asignado insuficiente.")
                }
            }
        }

        // 2. Compliance checks
        if (quote.totalEur > 200000.0) {
            // Alert triggered automatically
            triggerComplianceAlert(
                clientId = client.id,
                clientName = client.name,
                ruleName = "Transacción Elevada sobre Umbral",
                description = "Operación de metales por valor de EUR ${String.format("%.2f", quote.totalEur)} superó el umbral automático de €200k. Requiere supervisión.",
                severity = AlertSeverity.MEDIA
            )
        }

        val product = DemoData.productList.find { it.id == quote.productId }!!

        // 3. Allocate bars or update unallocated grams
        val allocatedBarIds = mutableListOf<String>()
        val beforeBarsState = _bars.value.map { it.copy() }

        if (product.allocated) {
            if (quote.isBuy) {
                // Dealer sells to Client -> Find dealer bars (ownerId == null) that match product, assign to client
                val matchingDealerBars = _bars.value.filter { it.ownerId == null && it.productName == product.name && it.status == BarStatus.DISPONIBLE }
                if (matchingDealerBars.size < quote.quantity) {
                    return TradeResult.Failure("Inventario físico disponible insuficiente en bóveda para entrega inmediata asignada.")
                }
                val barsToAssign = matchingDealerBars.take(quote.quantity)
                allocatedBarIds.addAll(barsToAssign.map { it.id })

                _bars.update { currentBars ->
                    currentBars.map { bar ->
                        if (allocatedBarIds.contains(bar.id)) {
                            bar.copy(ownerId = client.id, status = BarStatus.ASIGNADO)
                        } else bar
                    }
                }
            } else {
                // Client sells back to Dealer -> Find client bars, unassign them
                val matchingClientBars = _bars.value.filter { it.ownerId == client.id && it.productName == product.name && it.status == BarStatus.ASIGNADO }
                val barsToDeassign = matchingClientBars.take(quote.quantity)
                allocatedBarIds.addAll(barsToDeassign.map { it.id })

                _bars.update { currentBars ->
                    currentBars.map { bar ->
                        if (allocatedBarIds.contains(bar.id)) {
                            bar.copy(ownerId = null, status = BarStatus.DISPONIBLE)
                        } else bar
                    }
                }
            }
        }

        // 4. Update cash balances and unallocated balances
        _clients.update { currentClients ->
            currentClients.map { c ->
                if (c.id == client.id) {
                    val cashDiff = if (quote.isBuy) -quote.totalEur else quote.totalEur
                    val goldDiff = if (product.allocated) 0.0 else {
                        val g = product.weightGrams * quote.quantity
                        if (quote.isBuy) g else -g
                    }
                    val silverDiff = if (product.allocated) 0.0 else {
                        val g = product.weightGrams * quote.quantity
                        if (quote.isBuy) g else -g
                    }

                    c.copy(
                        cashBalanceEur = c.cashBalanceEur + cashDiff,
                        unallocatedGoldGrams = if (product.metal == Metal.ORO) c.unallocatedGoldGrams + goldDiff else c.unallocatedGoldGrams,
                        unallocatedSilverGrams = if (product.metal == Metal.PLATA) c.unallocatedSilverGrams + silverDiff else c.unallocatedSilverGrams
                    )
                } else c
            }
        }

        // Update selected client cache
        _selectedClient.value = _clients.value.find { it.id == client.id }

        // 5. Generate Trade
        val tradeId = "TRD-ES-${String.format("%06d", Random.nextInt(100000, 999999))}"
        val newTrade = Trade(
            id = tradeId,
            orderId = quote.id,
            clientId = client.id,
            clientName = client.name,
            productName = product.name,
            quantity = quote.quantity,
            executionPriceEur = quote.unitPriceEur,
            totalEur = quote.totalEur,
            isBuy = quote.isBuy,
            allocatedBarIds = allocatedBarIds,
            timestamp = System.currentTimeMillis()
        )

        _trades.update { it + newTrade }

        // 6. Generate Settlement Step
        val settlementId = "SET-ES-${String.format("%05d", Random.nextInt(10000, 99999))}"
        val newSettlement = Settlement(
            id = settlementId,
            tradeId = tradeId,
            clientId = client.id,
            clientName = client.name,
            amountEur = quote.totalEur,
            status = SettlementStatus.PENDIENTE,
            paymentConfirmed = true,
            allocationConfirmed = true,
            timestamp = System.currentTimeMillis()
        )
        _settlements.update { it + newSettlement }

        // Remove active quote
        _quotes.update { it.filter { q -> q.id != quoteId } }

        logAudit(
            actor = "MOTOR_EJECUCION",
            action = "EJECUTAR_ORDEN",
            targetId = tradeId,
            description = "Operación de ${if (quote.isBuy) "COMPRA" else "VENTA"} ejecutada con éxito. Cliente: ${client.name}, Producto: ${product.name}, Cantidad: ${quote.quantity}, Total: EUR ${String.format("%.2f", quote.totalEur)}",
            beforeState = "COTIZACIÓN_PENDIENTE",
            afterState = "TRANSACCIÓN_EJECUTADA"
        )

        // Simulate asynchronous settlement finalisation in 3 seconds!
        viewModelScope.launch {
            delay(3000L)
            _settlements.update { currentSetts ->
                currentSetts.map { s ->
                    if (s.id == settlementId) {
                        s.copy(status = SettlementStatus.LIQUIDADO)
                    } else s
                }
            }
            logAudit(
                actor = "MOTOR_LIQUIDACION",
                action = "COMPLETAR_LIQUIDACION",
                targetId = settlementId,
                description = "Liquidación y compensación de fondos finalizada para el Trade ID: $tradeId",
                beforeState = "PENDIENTE",
                afterState = "LIQUIDADO"
            )
        }

        return TradeResult.Success(newTrade)
    }

    // --- Direct Buy/Sell for Market Orders ---
    fun submitMarketOrder(clientId: String, product: Product, quantity: Int, isBuy: Boolean): TradeResult {
        // Generates an RFQ automatically, then executes it instantly
        val quote = requestRFQ(clientId, product, quantity, isBuy)
        return executeQuote(quote.id)
    }

    // --- Direct Allocated Bar Delivery Request ---
    fun requestPhysicalDelivery(clientId: String, barIds: List<String>, type: DeliveryType, destination: String): Boolean {
        val client = _clients.value.find { it.id == clientId } ?: return false
        val selectedBars = _bars.value.filter { barIds.contains(it.id) && it.ownerId == client.id }

        if (selectedBars.isEmpty()) return false

        val totalValue = selectedBars.sumOf { getMidPriceInUnit(it.metal, "EUR/g") * it.fineWeightGrams }

        // Change bar statuses to RESERVADO
        _bars.update { currentBars ->
            currentBars.map { bar ->
                if (barIds.contains(bar.id)) {
                    bar.copy(status = BarStatus.RESERVADO, custodyLocation = "EN TRÁNSITO")
                } else bar
            }
        }

        val deliveryId = "DLV-ES-${String.format("%05d", Random.nextInt(10000, 99999))}"
        val request = DeliveryRequest(
            id = deliveryId,
            clientId = client.id,
            clientName = client.name,
            barIds = barIds,
            deliveryType = type,
            destination = destination,
            insuredValueEur = totalValue,
            logisticsStatus = "PENDIENTE",
            timestamp = System.currentTimeMillis()
        )

        _deliveryRequests.update { it + request }

        logAudit(
            actor = "LOGISTICA",
            action = "SOLICITUD_ENTREGA",
            targetId = deliveryId,
            description = "Solicitud de logística física (${type.displayName}) creada para ${client.name} por ${barIds.size} lingotes. Valor asegurado: EUR ${String.format("%.2f", totalValue)}",
            beforeState = "EN_BOVEDA",
            afterState = "PENDIENTE_LOGISTICA"
        )

        // Simulate logistics progress
        viewModelScope.launch {
            delay(4000L)
            _deliveryRequests.update { list ->
                list.map { req ->
                    if (req.id == deliveryId) req.apply { logisticsStatus = "EN_TRÁNSITO" } else req
                }
            }
            delay(4000L)
            _deliveryRequests.update { list ->
                list.map { req ->
                    if (req.id == deliveryId) req.apply { logisticsStatus = "ENTREGADO" } else req
                }
            }
            // Update bar status to final Delivery State (let's remove ownerId since they took physical delivery!)
            _bars.update { currentBars ->
                currentBars.map { bar ->
                    if (barIds.contains(bar.id)) {
                        bar.copy(status = BarStatus.ASIGNADO, custodyLocation = "ENTREGADO_A_CLIENTE", ownerId = client.id)
                    } else bar
                }
            }
            logAudit(
                actor = "LOGISTICA",
                action = "ENTREGA_CONFIRMADA",
                targetId = deliveryId,
                description = "Entrega física de metales confirmada y firmada por el destinatario en: $destination",
                beforeState = "EN_TRÁNSITO",
                afterState = "ENTREGADO"
            )
        }

        return true
    }

    // --- Hedging execution ---
    fun executeDealerHedge(metal: Metal, gramsToHedge: Double) {
        val corrId = "CORR-${Random.nextInt(100000, 999999)}"
        if (metal == Metal.ORO) {
            _goldHedgeGrams.update { it + gramsToHedge }
        } else {
            _silverHedgeGrams.update { it + gramsToHedge }
        }

        logAudit(
            actor = "MESA_DE_OPERACIONES",
            action = "EJECUTAR_COBERTURA",
            targetId = "CARTERA_COBERTURAS",
            description = "Ejecutada orden de cobertura institucional de ${metal.displayName} por ${String.format("%.3f", gramsToHedge)} gramos en derivados de futuros.",
            beforeState = "",
            afterState = "HEDGE_AJUSTADO",
            correlationId = corrId
        )
    }

    // --- Risk Analytics Summaries ---
    fun getRiskSnapshot(): RiskSnapshot {
        val physicalGoldGrams = _bars.value.filter { it.ownerId == null && it.metal == Metal.ORO && it.status == BarStatus.DISPONIBLE }.sumOf { it.fineWeightGrams }
        val physicalSilverGrams = _bars.value.filter { it.ownerId == null && it.metal == Metal.PLATA && it.status == BarStatus.DISPONIBLE }.sumOf { it.fineWeightGrams }

        val clientAllocatedGold = _bars.value.filter { it.ownerId != null && it.metal == Metal.ORO }.sumOf { it.fineWeightGrams }
        val clientAllocatedSilver = _bars.value.filter { it.ownerId != null && it.metal == Metal.PLATA }.sumOf { it.fineWeightGrams }

        val clientUnallocatedGold = _clients.value.sumOf { it.unallocatedGoldGrams }
        val clientUnallocatedSilver = _clients.value.sumOf { it.unallocatedSilverGrams }

        val totalLiabilitiesGold = clientAllocatedGold + clientUnallocatedGold
        val totalLiabilitiesSilver = clientAllocatedSilver + clientUnallocatedSilver

        // Net exposure = Client liabilities (our short offset) + Physical inventory (our long asset) + Deriv hedges (our long asset)
        // Let's model:
        val netGoldExp = totalLiabilitiesGold - physicalGoldGrams - _goldHedgeGrams.value
        val netSilverExp = totalLiabilitiesSilver - physicalSilverGrams - _silverHedgeGrams.value

        return RiskSnapshot(
            goldInventoryGrams = physicalGoldGrams,
            silverInventoryGrams = physicalSilverGrams,
            goldClientLiabilitiesGrams = totalLiabilitiesGold,
            silverClientLiabilitiesGrams = totalLiabilitiesSilver,
            goldGrossExposureGrams = totalLiabilitiesGold + physicalGoldGrams,
            goldNetExposureGrams = netGoldExp,
            silverGrossExposureGrams = totalLiabilitiesSilver + physicalSilverGrams,
            silverNetExposureGrams = netSilverExp,
            totalHedgedGoldGrams = _goldHedgeGrams.value,
            totalHedgedSilverGrams = _silverHedgeGrams.value,
            timestamp = System.currentTimeMillis()
        )
    }

    // --- Compliance Rules Trigger ---
    fun triggerComplianceAlert(clientId: String, clientName: String, ruleName: String, description: String, severity: AlertSeverity) {
        val alert = ComplianceAlert(
            id = "ALR-ES-${String.format("%03d", _complianceAlerts.value.size + 1)}",
            clientId = clientId,
            clientName = clientName,
            ruleName = ruleName,
            description = description,
            severity = severity,
            status = AlertStatus.PENDIENTE,
            timestamp = System.currentTimeMillis(),
            analystNotes = "Alerta generada automáticamente por motor de cumplimiento en tiempo real."
        )

        _complianceAlerts.update { it + alert }
    }

    fun resolveComplianceAlert(alertId: String, nextStatus: AlertStatus, notes: String) {
        _complianceAlerts.update { list ->
            list.map { alert ->
                if (alert.id == alertId) {
                    alert.copy(status = nextStatus, analystNotes = notes)
                } else alert
            }
        }
        logAudit(
            actor = "ANALISTA_CUMPLIMIENTO",
            action = "RESOLVER_ALERTA",
            targetId = alertId,
            description = "Alerta de cumplimiento resuelta a estado: ${nextStatus.displayName}. Notas: $notes",
            beforeState = "PENDIENTE",
            afterState = nextStatus.name
        )
    }

    private fun triggerRandomComplianceAlert() {
        val random = Random(System.currentTimeMillis())
        val pool = _clients.value.take(15)
        if (pool.isNotEmpty()) {
            val client = pool[random.nextInt(pool.size)]
            val rules = listOf(
                Pair("Patrón de Órdenes Repetitivas", "Múltiples solicitudes de cotización en menos de 10 segundos sin ejecución."),
                Pair("Desajuste de Perfil Financiero", "Transacción física excede el perfil patrimonial estimado para el cliente particular."),
                Pair("Intento de Transacción de Cuenta Bloqueada", "Petición de RFQ rechazada por filtros AML preventivos de la Eurozona.")
            )
            val selectedRule = rules[random.nextInt(rules.size)]
            triggerComplianceAlert(
                clientId = client.id,
                clientName = client.name,
                ruleName = selectedRule.first,
                description = selectedRule.second,
                severity = AlertSeverity.MEDIA
            )
        }
    }

    // --- Audit Logging System ---
    private fun logAudit(
        actor: String,
        action: String,
        targetId: String,
        description: String,
        beforeState: String,
        afterState: String,
        correlationId: String? = null
    ) {
        val corrId = correlationId ?: "CORR-${Random.nextInt(100000, 999999)}"
        val event = AuditEvent(
            id = "AUD-ES-${String.format("%06d", _auditEvents.value.size + 1)}",
            timestamp = System.currentTimeMillis(),
            actor = actor,
            action = action,
            targetId = targetId,
            description = description,
            beforeState = beforeState,
            afterState = afterState,
            correlationId = corrId
        )

        _auditEvents.update { listOf(event) + it } // Add to top
    }
}

data class DetailedCostBreakdown(
    val metal: Metal,
    val productName: String,
    val quantity: Int,
    val metalValue: Double,
    val premium: Double,
    val manufacturing: Double,
    val custody: Double,
    val dealerMargin: Double,
    val logistics: Double,
    val total: Double,
    val unitPrice: Double
)

sealed class TradeResult {
    data class Success(val trade: Trade) : TradeResult()
    data class Failure(val message: String) : TradeResult()
}
