package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// ORO & PLATA Institutional Premium Color Palette
val BaseIvory = Color(0xFFFDFDFB)
val LightSurfaceGold = Color(0xFFFAF6EE)
val WarmGrey = Color(0xFFF3F2EE)
val GraphiteDark = Color(0xFF191B1F)
val NavyDark = Color(0xFF0E141D)

val GoldAccent = Color(0xFFC5A059) // Muted elegant Gold
val SilverAccent = Color(0xFF9EA3A9) // Muted Silver
val AlertBurgundy = Color(0xFF8B1E1E) // Restrained alert red
val AlertAmber = Color(0xFFD4822B) // Restrained alert orange
val GreenSuccess = Color(0xFF2E6B40) // Restrained success green

// Dark mode overrides
val DarkBackground = Color(0xFF0A0C10)
val DarkSurface = Color(0xFF14171D)
val DarkCard = Color(0xFF1A1E26)
val TextLight = Color(0xFFE5E7EB)
val TextMuted = Color(0xFF9CA3AF)
val TextDark = Color(0xFF1F2937)
