package com.example.data

enum class Metal(val displayName: String, val symbol: String) {
    ORO("Oro", "Au"),
    PLATA("Plata", "Ag")
}

enum class BarStatus(val displayName: String) {
    DISPONIBLE("Disponible"),
    RESERVADO("Reservado"),
    ASIGNADO("Asignado"),
    EN_TRANSITO("En Tránsito"),
    BLOQUEADO("Bloqueado")
}

enum class ClientCategory(val displayName: String) {
    PARTICULAR("Particular"),
    PROFESIONAL("Profesional"),
    EMPRESA("Empresa"),
    INSTITUCION("Institución"),
    FAMILY_OFFICE("Family Office"),
    GESTOR_PATRIMONIAL("Gestor Patrimonial")
}

enum class OrderStatus(val displayName: String) {
    CREADA("Creada"),
    VALIDADA("Validada"),
    COTIZADA("Cotizada"),
    ACEPTADA("Aceptada"),
    EJECUTADA("Ejecutada"),
    LIQUIDADA("Liquidada"),
    CANCELADA("Cancelada")
}

enum class SettlementStatus(val displayName: String) {
    PENDIENTE("Pendiente"),
    EN_PROCESO("En Proceso"),
    LIQUIDADO("Liquidado"),
    FALLIDO("Fallido")
}

enum class DeliveryType(val displayName: String) {
    RECOGIDA("Recogida en Bóveda"),
    ENTREGA("Entrega Asegurada")
}

enum class AlertSeverity(val displayName: String) {
    BAJA("Baja"),
    MEDIA("Media"),
    ALTA("Alta")
}

enum class AlertStatus(val displayName: String) {
    PENDIENTE("Pendiente"),
    INVESTIGADO("En Investigación"),
    BLOQUEADO("Cuenta Bloqueada"),
    ARCHIVADO("Archivado")
}

data class Product(
    val id: String,
    val name: String,
    val metal: Metal,
    val weightGrams: Double,
    val purity: Double,
    val manufacturer: String,
    val premiumPercent: Double,
    val manufacturingCostEur: Double,
    val allocated: Boolean,
    val serialNumberPattern: String
)

data class Bar(
    val id: String,
    val serialNumber: String,
    val productName: String,
    val metal: Metal,
    val purity: Double,
    val grossWeightGrams: Double,
    val fineWeightGrams: Double,
    val refinery: String,
    val custodyLocation: String, // BÓVEDA MADRID, BÓVEDA BARCELONA, CUSTODIA EXTERNA, EN TRÁNSITO
    val status: BarStatus,
    val ownerId: String? = null // Null means owned by Dealer
)

data class Client(
    val id: String,
    val name: String,
    val category: ClientCategory,
    val accountNumber: String,
    val preferredCurrency: String, // "EUR" or "USD"
    val cashBalanceEur: Double,
    val cashBalanceUsd: Double,
    val unallocatedGoldGrams: Double,
    val unallocatedSilverGrams: Double
)

data class Quote(
    val id: String,
    val clientId: String,
    val clientName: String,
    val metal: Metal,
    val productId: String?,
    val productName: String,
    val quantity: Int,
    val isBuy: Boolean, // True = client buys from dealer, False = client sells to dealer
    val unitPriceEur: Double,
    val premiumEur: Double,
    val totalEur: Double,
    val currency: String,
    var validForSeconds: Int,
    val timestamp: Long
)

data class Order(
    val id: String,
    val clientId: String,
    val clientName: String,
    val metal: Metal,
    val productId: String?,
    val productName: String,
    val quantity: Int,
    val priceEur: Double,
    val totalEur: Double,
    val isBuy: Boolean,
    val status: OrderStatus,
    val timestamp: Long
)

data class Trade(
    val id: String,
    val orderId: String,
    val clientId: String,
    val clientName: String,
    val productName: String,
    val quantity: Int,
    val executionPriceEur: Double,
    val totalEur: Double,
    val isBuy: Boolean,
    val allocatedBarIds: List<String>,
    val timestamp: Long
)

data class Settlement(
    val id: String,
    val tradeId: String,
    val clientId: String,
    val clientName: String,
    val amountEur: Double,
    val status: SettlementStatus,
    val paymentConfirmed: Boolean,
    val allocationConfirmed: Boolean,
    val timestamp: Long
)

data class DeliveryRequest(
    val id: String,
    val clientId: String,
    val clientName: String,
    val barIds: List<String>,
    val deliveryType: DeliveryType,
    val destination: String,
    val insuredValueEur: Double,
    var logisticsStatus: String, // PENDIENTE, EN_PREPARACIÓN, EN_TRÁNSITO, ENTREGADO
    val timestamp: Long
)

data class ComplianceAlert(
    val id: String,
    val clientId: String,
    val clientName: String,
    val ruleName: String,
    val description: String,
    val severity: AlertSeverity,
    var status: AlertStatus,
    val timestamp: Long,
    var analystNotes: String
)

data class AuditEvent(
    val id: String,
    val timestamp: Long,
    val actor: String,
    val action: String,
    val targetId: String,
    val description: String,
    val beforeState: String,
    val afterState: String,
    val correlationId: String
)

data class RiskSnapshot(
    val goldInventoryGrams: Double,
    val silverInventoryGrams: Double,
    val goldClientLiabilitiesGrams: Double,
    val silverClientLiabilitiesGrams: Double,
    val goldGrossExposureGrams: Double,
    val goldNetExposureGrams: Double,
    val silverGrossExposureGrams: Double,
    val silverNetExposureGrams: Double,
    val totalHedgedGoldGrams: Double,
    val totalHedgedSilverGrams: Double,
    val timestamp: Long
)
