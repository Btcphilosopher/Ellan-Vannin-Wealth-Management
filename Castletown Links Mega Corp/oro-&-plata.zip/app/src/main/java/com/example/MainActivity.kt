package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.MainBrokerageScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.MarketViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Initialize the central shared state view model
                val marketViewModel: MarketViewModel = viewModel()
                MainBrokerageScreen(viewModel = marketViewModel)
            }
        }
    }
}
