package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = GoldAccent,
    secondary = SilverAccent,
    tertiary = AlertAmber,
    background = DarkBackground,
    surface = DarkSurface,
    onPrimary = GraphiteDark,
    onSecondary = GraphiteDark,
    onBackground = TextLight,
    onSurface = TextLight,
    surfaceVariant = DarkCard,
    onSurfaceVariant = TextMuted,
    error = AlertBurgundy
)

private val LightColorScheme = lightColorScheme(
    primary = GraphiteDark,
    secondary = GoldAccent,
    tertiary = SilverAccent,
    background = BaseIvory,
    surface = WarmGrey,
    onPrimary = BaseIvory,
    onSecondary = GraphiteDark,
    onBackground = GraphiteDark,
    onSurface = GraphiteDark,
    surfaceVariant = LightSurfaceGold,
    onSurfaceVariant = GraphiteDark,
    error = AlertBurgundy
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Disable dynamic colors so our customized ORO & PLATA palette is preserved!
    content: @Composable () -> Unit,
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
