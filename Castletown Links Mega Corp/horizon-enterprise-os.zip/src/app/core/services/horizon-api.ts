import { Injectable, signal, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, catchError, of, tap } from 'rxjs';
import {
  Asset,
  TrainUnit,
  PowerSubstation,
  FactoryMachine,
  DataCenterRack,
  AIAgent,
  AIRecommendation,
  WorkOrder,
  SecurityIncident,
  AuditRecord,
  IndustrialEvent,
  TelemetryReading,
  WhatIfScenarioResult
} from '../../../server/types';

export interface InfrastructureSummary {
  executive_summary_ja: string;
  cross_domain_correlations: string[];
  risk_level: string;
  recommended_ceo_actions: string[];
}

export interface ApiResponse<T> {
  status: string;
  data?: T;
  incidents?: T;
  count?: number;
  message?: string;
}

@Injectable({
  providedIn: 'root'
})
export class HorizonApiService {
  private http = inject(HttpClient);

  // Reactive state signals with explicit domain types
  public executiveSummary = signal<InfrastructureSummary | null>(null);
  public assets = signal<Asset[]>([]);
  public trains = signal<TrainUnit[]>([]);
  public substations = signal<PowerSubstation[]>([]);
  public factoryMachines = signal<FactoryMachine[]>([]);
  public dcRacks = signal<DataCenterRack[]>([]);
  public aiAgents = signal<AIAgent[]>([]);
  public aiRecommendations = signal<AIRecommendation[]>([]);
  public workOrders = signal<WorkOrder[]>([]);
  public securityIncidents = signal<SecurityIncident[]>([]);
  public auditRecords = signal<AuditRecord[]>([]);
  public events = signal<IndustrialEvent[]>([]);
  public liveTelemetry = signal<TelemetryReading[]>([]);
  public isDemoScenarioActive = signal<boolean>(false);
  public lastUpdated = signal<string>(new Date().toLocaleTimeString());

  public loadAllData() {
    this.fetchExecutiveSummary().subscribe();
    this.fetchAssets().subscribe();
    this.fetchTrains().subscribe();
    this.fetchSubstations().subscribe();
    this.fetchFactoryMachines().subscribe();
    this.fetchDcRacks().subscribe();
    this.fetchAiAgents().subscribe();
    this.fetchAiRecommendations().subscribe();
    this.fetchWorkOrders().subscribe();
    this.fetchSecurityIncidents().subscribe();
    this.fetchAuditRecords().subscribe();
    this.fetchEvents().subscribe();
    this.fetchTelemetry().subscribe();
    this.lastUpdated.set(new Date().toLocaleTimeString());
  }

  public fetchExecutiveSummary(): Observable<ApiResponse<InfrastructureSummary>> {
    return this.http.get<ApiResponse<InfrastructureSummary>>('/api/ai/executive-summary').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.executiveSummary.set(res.data); }),
      catchError(err => of({ status: 'ERROR', message: err instanceof Error ? err.message : 'Error' }))
    );
  }

  public fetchAssets(): Observable<ApiResponse<Asset[]>> {
    return this.http.get<ApiResponse<Asset[]>>('/api/assets').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.assets.set(res.data); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public fetchTrains(): Observable<ApiResponse<TrainUnit[]>> {
    return this.http.get<ApiResponse<TrainUnit[]>>('/api/rail/trains').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.trains.set(res.data); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public fetchSubstations(): Observable<ApiResponse<PowerSubstation[]>> {
    return this.http.get<ApiResponse<PowerSubstation[]>>('/api/energy/grid').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.substations.set(res.data); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public fetchFactoryMachines(): Observable<ApiResponse<FactoryMachine[]>> {
    return this.http.get<ApiResponse<FactoryMachine[]>>('/api/factories/machines').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.factoryMachines.set(res.data); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public fetchDcRacks(): Observable<ApiResponse<DataCenterRack[]>> {
    return this.http.get<ApiResponse<DataCenterRack[]>>('/api/dc/racks').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.dcRacks.set(res.data); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public fetchAiAgents(): Observable<ApiResponse<AIAgent[]>> {
    return this.http.get<ApiResponse<AIAgent[]>>('/api/ai/agents').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.aiAgents.set(res.data); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public fetchAiRecommendations(): Observable<ApiResponse<AIRecommendation[]>> {
    return this.http.get<ApiResponse<AIRecommendation[]>>('/api/ai/recommendations').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.aiRecommendations.set(res.data); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public fetchWorkOrders(): Observable<ApiResponse<WorkOrder[]>> {
    return this.http.get<ApiResponse<WorkOrder[]>>('/api/maintenance/work-orders').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.workOrders.set(res.data); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public fetchSecurityIncidents(): Observable<ApiResponse<SecurityIncident[]>> {
    return this.http.get<ApiResponse<SecurityIncident[]>>('/api/security/soc').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.incidents) this.securityIncidents.set(res.incidents); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public fetchAuditRecords(): Observable<ApiResponse<AuditRecord[]>> {
    return this.http.get<ApiResponse<AuditRecord[]>>('/api/audit').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.auditRecords.set(res.data); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public fetchEvents(): Observable<ApiResponse<IndustrialEvent[]>> {
    return this.http.get<ApiResponse<IndustrialEvent[]>>('/api/events').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.events.set(res.data); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public fetchTelemetry(): Observable<ApiResponse<TelemetryReading[]>> {
    return this.http.get<ApiResponse<TelemetryReading[]>>('/api/telemetry').pipe(
      tap(res => { if (res.status === 'SUCCESS' && res.data) this.liveTelemetry.set(res.data); }),
      catchError(() => of({ status: 'ERROR' }))
    );
  }

  public approveRecommendation(recommendation_id: string, action: 'APPROVE' | 'REJECT', approver_name: string): Observable<ApiResponse<unknown>> {
    return this.http.post<ApiResponse<unknown>>('/api/ai/approve', {
      recommendation_id,
      action,
      approver_name,
      approver_role: 'COMMANDER'
    }).pipe(
      tap(() => this.loadAllData())
    );
  }

  public triggerDemoScenario(): Observable<ApiResponse<unknown>> {
    return this.http.post<ApiResponse<unknown>>('/api/demo-scenario', {}).pipe(
      tap(() => {
        this.isDemoScenarioActive.set(true);
        this.loadAllData();
      })
    );
  }

  public createWorkOrder(data: Partial<WorkOrder>): Observable<ApiResponse<unknown>> {
    return this.http.post<ApiResponse<unknown>>('/api/maintenance/work-orders', data).pipe(
      tap(() => this.loadAllData())
    );
  }

  public runWhatIf(input: Record<string, unknown>): Observable<ApiResponse<WhatIfScenarioResult>> {
    return this.http.post<ApiResponse<WhatIfScenarioResult>>('/api/simulations/run', input);
  }
}
