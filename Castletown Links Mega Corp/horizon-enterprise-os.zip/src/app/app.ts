import { ChangeDetectionStrategy, Component, inject, OnInit, signal, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from './core/services/horizon-api';

// Imports of domain views
import { ExecutiveTowerComponent } from './components/executive-tower/executive-tower';
import { OperationsRoomComponent } from './components/operations-room/operations-room';
import { RailControlComponent } from './components/rail-control/rail-control';
import { EnergyControlComponent } from './components/energy-control/energy-control';
import { FactoryControlComponent } from './components/factory-control/factory-control';
import { DatacenterControlComponent } from './components/datacenter-control/datacenter-control';
import { AssetFinanceComponent } from './components/asset-finance/asset-finance';
import { SupplyChainComponent } from './components/supply-chain/supply-chain';
import { AiCommandComponent } from './components/ai-command/ai-command';
import { WhatIfComponent } from './components/what-if/what-if';
import { CyberSocComponent } from './components/cyber-soc/cyber-soc';
import { AuditViewComponent } from './components/audit-view/audit-view';

export type NavTab = 
  | 'EXECUTIVE'
  | 'OPERATIONS'
  | 'RAIL'
  | 'ENERGY'
  | 'FACTORY'
  | 'DATACENTER'
  | 'FINANCE'
  | 'SUPPLY_CHAIN'
  | 'AI_COMMAND'
  | 'WHAT_IF'
  | 'CYBER_SOC'
  | 'AUDIT';

@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    ExecutiveTowerComponent,
    OperationsRoomComponent,
    RailControlComponent,
    EnergyControlComponent,
    FactoryControlComponent,
    DatacenterControlComponent,
    AssetFinanceComponent,
    SupplyChainComponent,
    AiCommandComponent,
    WhatIfComponent,
    CyberSocComponent,
    AuditViewComponent
  ],
  templateUrl: './app.html',
  styleUrl: './app.css',
})
export class App implements OnInit, OnDestroy {
  public api = inject(HorizonApiService);
  public activeTab = signal<NavTab>('EXECUTIVE');
  public currentTime = signal<string>(new Date().toLocaleTimeString());

  private clockInterval: ReturnType<typeof setInterval> | null = null;
  private telemetryInterval: ReturnType<typeof setInterval> | null = null;

  ngOnInit() {
    this.api.loadAllData();

    this.clockInterval = setInterval(() => {
      this.currentTime.set(new Date().toLocaleTimeString());
    }, 1000);

    // Live telemetry telemetry pull every 4 seconds
    this.telemetryInterval = setInterval(() => {
      this.api.fetchTelemetry().subscribe();
    }, 4000);
  }

  ngOnDestroy() {
    if (this.clockInterval) clearInterval(this.clockInterval);
    if (this.telemetryInterval) clearInterval(this.telemetryInterval);
  }

  setTab(tab: NavTab) {
    this.activeTab.set(tab);
  }

  triggerDemo() {
    this.api.triggerDemoScenario().subscribe();
  }
}
