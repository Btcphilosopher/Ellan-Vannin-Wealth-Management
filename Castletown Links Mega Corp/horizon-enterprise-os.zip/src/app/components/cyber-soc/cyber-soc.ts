import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from '../../core/services/horizon-api';

@Component({
  selector: 'app-cyber-soc',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- Cyber SOC Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-xs font-bold rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/30">
              OT CYBERSECURITY SOC & ZERO TRUST INDUSTRIAL GATEWAY
            </span>
            <span class="text-xs text-slate-400">IT/OTエアギャップ隔離・PLC書き込み検知・ゼロトラスト</span>
          </div>
          <h1 class="text-xl font-bold text-slate-100 mt-1">OT 産業サイバーセキュリティ統制センター</h1>
        </div>
        <div class="flex items-center gap-3 text-xs text-slate-300">
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            ブロック済み攻撃試行: <strong class="text-emerald-400">142 件</strong>
          </div>
        </div>
      </div>

      <!-- Security Incidents List -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h2 class="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
          <span class="material-icons text-purple-400 text-base">security</span>
          リアルタイム OT 脅威検知ログ (OT Threat Events)
        </h2>

        <div class="space-y-3">
          @for (inc of api.securityIncidents(); track inc.id) {
            <div class="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
              <div class="flex items-center justify-between text-xs">
                <div class="flex items-center gap-2">
                  <span class="px-2 py-0.5 bg-rose-500/20 text-rose-400 rounded font-bold">{{ inc.severity }}</span>
                  <span class="font-bold text-slate-100">{{ inc.threat_type }}</span>
                </div>
                <span class="text-slate-400">{{ inc.detected_at | date:'yyyy-MM-dd HH:mm:ss' }}</span>
              </div>
              <p class="text-xs text-slate-300">{{ inc.action_taken }} (ソース: {{ inc.source_network }})</p>
              <div class="flex items-center justify-between text-[11px] text-slate-400 pt-1 border-t border-slate-900">
                <span>対象ゲートウェイ: <strong class="text-slate-200">{{ inc.target_asset_name }}</strong></span>
                <span class="text-emerald-400 font-bold bg-emerald-500/10 px-2 py-0.5 rounded">ステータス: {{ inc.status }}</span>
              </div>
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class CyberSocComponent implements OnInit {
  public api = inject(HorizonApiService);

  ngOnInit() {
    this.api.fetchSecurityIncidents().subscribe();
  }
}
