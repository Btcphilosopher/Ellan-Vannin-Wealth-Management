import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from '../../core/services/horizon-api';

@Component({
  selector: 'app-audit-view',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- Audit Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-xs font-bold rounded-full bg-slate-700 text-slate-300 border border-slate-600">
              IMMUTABLE AUDIT TRAIL & AI ACTION PROVENANCE
            </span>
            <span class="text-xs text-slate-400">誰が・いつ・何のAI提案を・どの根拠で承認したかの完全改ざん防止ログ</span>
          </div>
          <h1 class="text-xl font-bold text-slate-100 mt-1">エンタープライズ統合監査トレイル (Audit Log)</h1>
        </div>
      </div>

      <!-- Audit Log Table -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <h2 class="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <span class="material-icons text-slate-400 text-base">history</span>
            全社操作 & AI制御実行 履歴一覧
          </h2>
          <span class="text-xs text-slate-400">総計 {{ api.auditRecords().length }} 件のレコード</span>
        </div>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs text-slate-300">
            <thead class="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th class="p-3">タイムスタンプ (Timestamp)</th>
                <th class="p-3">実行者 (Who & Role)</th>
                <th class="p-3">操作内容 (What)</th>
                <th class="p-3">対象領域 (Where)</th>
                <th class="p-3">ステータス (Status)</th>
                <th class="p-3">実行結果 (Outcome)</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/80">
              @for (rec of api.auditRecords(); track rec.id) {
                <tr class="hover:bg-slate-800/50 transition">
                  <td class="p-3 font-mono text-slate-400 text-[11px] whitespace-nowrap">{{ rec.timestamp | date:'yyyy-MM-dd HH:mm:ss' }}</td>
                  <td class="p-3">
                    <div class="font-bold text-slate-100">{{ rec.who }}</div>
                    <div class="text-[10px] text-slate-500">{{ rec.role }}</div>
                  </td>
                  <td class="p-3 font-semibold text-cyan-400">{{ rec.what }}</td>
                  <td class="p-3 text-slate-300">{{ rec.where }}</td>
                  <td class="p-3">
                    <span 
                      [class.bg-emerald-500/20]="rec.approval_status === 'APPROVED' || rec.approval_status === 'EXECUTED'"
                      [class.text-emerald-400]="rec.approval_status === 'APPROVED' || rec.approval_status === 'EXECUTED'"
                      [class.bg-rose-500/20]="rec.approval_status === 'REJECTED'"
                      [class.text-rose-400]="rec.approval_status === 'REJECTED'"
                      class="px-2 py-0.5 rounded font-bold text-[10px]">
                      {{ rec.approval_status }}
                    </span>
                  </td>
                  <td class="p-3 text-slate-300 max-w-xs truncate">{{ rec.result }}</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class AuditViewComponent implements OnInit {
  public api = inject(HorizonApiService);

  ngOnInit() {
    this.api.fetchAuditRecords().subscribe();
  }
}
