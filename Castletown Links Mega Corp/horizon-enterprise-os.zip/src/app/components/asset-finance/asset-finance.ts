import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from '../../core/services/horizon-api';

@Component({
  selector: 'app-asset-finance',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- Finance Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-xs font-bold rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
              ENTERPRISE ASSET ECONOMICS & GENERAL LEDGER
            </span>
            <span class="text-xs text-slate-400">CapEx / OpEx / TCO / 設備減価償却 / ROIC</span>
          </div>
          <h1 class="text-xl font-bold text-slate-100 mt-1">社会インフラ 資産経済 & 財務統制</h1>
        </div>
        <div class="flex items-center gap-3 text-xs text-slate-300">
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            当期 CapEx 投資額: <strong class="text-amber-400">¥125.0 億円</strong>
          </div>
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            当期 OpEx 保全費: <strong class="text-slate-200">¥34.2 億円</strong>
          </div>
        </div>
      </div>

      <!-- Financial Metrics Grid -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <h2 class="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
          <span class="material-icons text-amber-400 text-base">account_balance_wallet</span>
          主要インフラ資産 経済価値・減価償却・TCO（総所有コスト）
        </h2>

        <div class="overflow-x-auto">
          <table class="w-full text-left text-xs text-slate-300">
            <thead class="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
              <tr>
                <th class="p-3">資産名称 (Asset Name)</th>
                <th class="p-3">取得原価 (CapEx)</th>
                <th class="p-3">ブックバリュー (Book Value)</th>
                <th class="p-3">年間保守OpEx</th>
                <th class="p-3">耐用年数</th>
                <th class="p-3">リスクアジャステッドROIC</th>
              </tr>
            </thead>
            <tbody class="divide-y divide-slate-800/80">
              @for (item of metrics; track item.asset_name) {
                <tr class="hover:bg-slate-800/50 transition">
                  <td class="p-3 font-bold text-slate-100">{{ item.asset_name }}</td>
                  <td class="p-3 text-slate-200">¥{{ (item.capex / 100000000).toFixed(2) }} 億円</td>
                  <td class="p-3 text-amber-400 font-medium">¥{{ (item.book_value / 100000000).toFixed(2) }} 億円</td>
                  <td class="p-3 text-slate-300">¥{{ (item.annual_opex / 1000000).toFixed(0) }} 百万円</td>
                  <td class="p-3 text-slate-400">{{ item.useful_life_years }} 年</td>
                  <td class="p-3 font-bold text-emerald-400">{{ item.roic_pct }} %</td>
                </tr>
              }
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class AssetFinanceComponent implements OnInit {
  public api = inject(HorizonApiService);

  public metrics = [
    { asset_name: '特急ホライゾン 104号 電車編成', capex: 2400000000, book_value: 1850000000, annual_opex: 82000000, useful_life_years: 30, roic_pct: 14.2 },
    { asset_name: '茨城500kV基幹変電所 T-801変圧器', capex: 1800000000, book_value: 1120000000, annual_opex: 45000000, useful_life_years: 40, roic_pct: 12.8 },
    { asset_name: '横浜工場 溶接ロボットセル RC-04', capex: 350000000, book_value: 180000000, annual_opex: 28000000, useful_life_years: 15, roic_pct: 18.5 },
    { asset_name: '千葉AI DC H100 GPUサーバーラック群', capex: 4200000000, book_value: 3900000000, annual_opex: 190000000, useful_life_years: 5, roic_pct: 22.4 }
  ];

  ngOnInit() {
    this.api.fetchAuditRecords().subscribe();
  }
}
