import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from '../../core/services/horizon-api';

@Component({
  selector: 'app-ai-command',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- AI Governance Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-xs font-bold rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
              PHYSICAL AI AGENTS & COMMAND GATEWAY GOVERNANCE
            </span>
            <span class="text-xs text-slate-400">Human-in-the-loop 人間最終承認プロトコル</span>
          </div>
          <h1 class="text-xl font-bold text-slate-100 mt-1">Physical AI エージェントガバナンス & 承認センター</h1>
        </div>
        <div class="flex items-center gap-3 text-xs text-slate-300">
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            登録エージェント数: <strong class="text-cyan-400">{{ api.aiAgents().length }} 体</strong>
          </div>
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            安全設計: <strong class="text-emerald-400">OT直結禁止 (Command Gateway経由)</strong>
          </div>
        </div>
      </div>

      <!-- AI Agents Grid -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        @for (agent of api.aiAgents(); track agent.agent_id) {
          <div class="bg-slate-900/90 border border-slate-800 rounded-xl p-4 flex flex-col justify-between space-y-3 hover:border-slate-700 transition">
            <div class="flex items-center justify-between">
              <span class="material-icons text-cyan-400 text-lg">smart_toy</span>
              <span 
                [class.bg-emerald-500/20]="agent.risk_level === 'LOW'"
                [class.text-emerald-400]="agent.risk_level === 'LOW'"
                [class.bg-amber-500/20]="agent.risk_level === 'MEDIUM'"
                [class.text-amber-400]="agent.risk_level === 'MEDIUM'"
                [class.bg-rose-500/20]="agent.risk_level === 'HIGH' || agent.risk_level === 'CRITICAL'"
                [class.text-rose-400]="agent.risk_level === 'HIGH' || agent.risk_level === 'CRITICAL'"
                class="text-[10px] font-bold px-2 py-0.5 rounded-full">
                {{ agent.risk_level }} RISK
              </span>
            </div>
            <div>
              <h3 class="font-bold text-slate-100 text-xs truncate">{{ agent.name }}</h3>
              <p class="text-[11px] text-slate-400 mt-0.5">{{ agent.sector }} 領域</p>
            </div>
            <div class="text-[10px] text-slate-400 bg-slate-950 p-2 rounded border border-slate-800/80">
              役割: <strong class="text-slate-200">{{ agent.purpose }}</strong>
            </div>
          </div>
        }
      </div>

      <!-- Recommendations Approval Queue -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <div class="flex items-center gap-2">
            <span class="material-icons text-amber-400">task_alt</span>
            <h2 class="font-bold text-slate-100 text-sm">Physical AI 提案承認キュー (Human-in-the-Loop Queue)</h2>
          </div>
          <span class="text-xs text-slate-400">※ 指令長の承認後のみOT制御プロトコルが発行されます</span>
        </div>

        <div class="space-y-4">
          @for (rec of api.aiRecommendations(); track rec.recommendation_id) {
            <div class="bg-slate-950 p-5 rounded-2xl border border-slate-800 space-y-3">
              <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div class="flex items-center gap-3">
                  <span class="px-2.5 py-1 text-xs font-bold rounded bg-amber-500/20 text-amber-400 border border-amber-500/30">
                    {{ rec.sector }}
                  </span>
                  <h3 class="font-bold text-slate-100 text-sm">{{ rec.title }}</h3>
                </div>
                <div class="flex items-center gap-2">
                  <span class="text-xs text-slate-400">確信度: <strong class="text-cyan-400">{{ (rec.confidence * 100).toFixed(0) }}%</strong></span>
                  <span 
                    [class.bg-amber-500/20]="rec.approval_state === 'PENDING'"
                    [class.text-amber-400]="rec.approval_state === 'PENDING'"
                    [class.bg-emerald-500/20]="rec.approval_state === 'APPROVED'"
                    [class.text-emerald-400]="rec.approval_state === 'APPROVED'"
                    [class.bg-rose-500/20]="rec.approval_state === 'REJECTED'"
                    [class.text-rose-400]="rec.approval_state === 'REJECTED'"
                    class="px-2.5 py-1 rounded-full text-xs font-bold uppercase">
                    {{ rec.approval_state }}
                  </span>
                </div>
              </div>

              <div class="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-slate-300">
                <div class="md:col-span-2 bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span class="text-slate-500 block text-[10px]">根拠 & 根本原因 (Root Cause / Recommendation):</span>
                  <p class="leading-relaxed font-semibold text-slate-200">{{ rec.recommendation_action }}</p>
                  <p class="text-slate-400 text-[11px] mt-1">{{ rec.root_cause }}</p>
                </div>
                <div class="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-1">
                  <span class="text-slate-500 block text-[10px]">リスク評価 & コマンドプロトコル:</span>
                  <div>リスクレベル: <strong class="text-rose-400">{{ rec.risk_level }}</strong></div>
                  <div>対象機器: <strong class="text-slate-200">{{ rec.target_entity_name }}</strong></div>
                  <div>結果: <span class="text-emerald-400 font-medium">{{ rec.execution_outcome || '待機中' }}</span></div>
                </div>
              </div>

              @if (rec.approval_state === 'PENDING') {
                <div class="flex items-center justify-end gap-3 pt-2 border-t border-slate-900">
                  <button 
                    (click)="approve(rec.recommendation_id, 'REJECT')"
                    class="px-4 py-2 text-xs font-bold rounded-xl bg-slate-800 hover:bg-slate-700 text-rose-400 border border-slate-700 transition">
                    提案を拒否 (Reject Action)
                  </button>
                  <button 
                    (click)="approve(rec.recommendation_id, 'APPROVE')"
                    class="px-5 py-2 text-xs font-bold rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-lg transition flex items-center gap-1.5">
                    <span class="material-icons text-sm">check_circle</span>
                    Human-in-the-loop 承認・Command Gateway送信
                  </button>
                </div>
              }
            </div>
          }
        </div>
      </div>
    </div>
  `
})
export class AiCommandComponent implements OnInit {
  public api = inject(HorizonApiService);

  ngOnInit() {
    this.api.fetchAiAgents().subscribe();
    this.api.fetchAiRecommendations().subscribe();
  }

  approve(id: string, action: 'APPROVE' | 'REJECT') {
    this.api.approveRecommendation(id, action, '人間統括指令長 (Chief Human Operator)').subscribe();
  }
}
