import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from '../../core/services/horizon-api';

@Component({
  selector: 'app-rail-control',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- Rail OS Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-xs font-bold rounded-full bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
              RAILWAY OPERATING SYSTEM & DIGITAL TWIN
            </span>
            <span class="text-xs text-slate-400">リアルタイム列車位置・ダイヤ追従・AI抑止指令</span>
          </div>
          <h1 class="text-xl font-bold text-slate-100 mt-1">社会インフラ 鉄道運行管理センター</h1>
        </div>
        <div class="flex items-center gap-3 text-xs text-slate-300">
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            稼働列車数: <strong class="text-indigo-400">{{ api.trains().length }} 編成</strong>
          </div>
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            最大遅延: <strong class="text-amber-400">+12 分</strong>
          </div>
        </div>
      </div>

      <!-- Live Trains Grid & Digital Twin Simulator -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Train Units List -->
        <div class="lg:col-span-2 space-y-4">
          <h2 class="text-sm font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <span class="material-icons text-indigo-400 text-base">train</span>
            リアルタイム編成位置・制御状態 (Active Train Units)
          </h2>

          <div class="space-y-3">
            @for (train of api.trains(); track train.id) {
              <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3 hover:border-slate-700 transition">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                  <div class="flex items-center gap-3">
                    <span class="w-10 h-10 rounded-xl bg-indigo-950 border border-indigo-700/50 text-indigo-300 flex items-center justify-center font-extrabold text-sm">
                      {{ train.code }}
                    </span>
                    <div>
                      <h3 class="text-base font-bold text-slate-100">{{ train.line_name }}</h3>
                      <p class="text-xs text-slate-400">現在位置: {{ train.current_station }} → 次駅: {{ train.next_station }} ({{ train.position_km }} km)</p>
                    </div>
                  </div>
                  <div class="flex items-center gap-2">
                    <span 
                      [class.bg-emerald-500/20]="train['delay_minutes'] === 0"
                      [class.text-emerald-400]="train['delay_minutes'] === 0"
                      [class.bg-amber-500/20]="(train['delay_minutes'] || 0) > 0"
                      [class.text-amber-400]="(train['delay_minutes'] || 0) > 0"
                      class="px-3 py-1 rounded-full text-xs font-bold">
                      {{ train['delay_minutes'] === 0 ? '定時運行 (On Time)' : '遅延 +' + train['delay_minutes'] + ' 分' }}
                    </span>
                  </div>
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                    <span class="text-slate-500 block text-[10px]">現在速度 (Speed)</span>
                    <span class="font-bold text-slate-200 text-sm">{{ train.speed_kmh }} km/h</span>
                  </div>
                  <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                    <span class="text-slate-500 block text-[10px]">乗車率 (Occupancy)</span>
                    <span class="font-bold text-amber-400 text-sm">{{ train.occupancy_pct }}%</span>
                  </div>
                  <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                    <span class="text-slate-500 block text-[10px]">信号状態 (Signal)</span>
                    <span class="font-bold text-emerald-400 text-sm">{{ train.signal_state }}</span>
                  </div>
                  <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                    <span class="text-slate-500 block text-[10px]">電力消費 (Energy)</span>
                    <span class="font-bold text-slate-200 text-sm">{{ train.energy_kwh }} kWh</span>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Rail Physical AI Recommendations & Rerouting -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4 flex flex-col">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800">
            <span class="font-bold text-slate-200 text-sm flex items-center gap-2">
              <span class="material-icons text-amber-400 text-base">alt_route</span>
              RailOperationsAgent 指令キュー
            </span>
            <span class="text-xs bg-indigo-500/20 text-indigo-300 px-2 py-0.5 rounded font-bold">高精度シミュレーション</span>
          </div>

          <div class="space-y-3 flex-1 overflow-y-auto pr-1">
            <div class="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
              <div class="flex items-center justify-between">
                <span class="text-xs font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded">推奨案 #REC-RAIL-101</span>
                <span class="text-[10px] text-slate-400">確信度 88%</span>
              </div>
              <h4 class="text-xs font-bold text-slate-100">104号電車の遅延回復・立川駅待避線退避制御</h4>
              <p class="text-xs text-slate-300 leading-relaxed bg-slate-900 p-2.5 rounded border border-slate-800">
                1. 立川駅にて104号を3分間抑止・後続特急を待避線へ誘導<br>
                2. 新宿駅の降車ホームを3番線から5番線へ変更<br>
                3. 予備車両E235-H-108の緊急出庫準備
              </p>
              <div class="text-[11px] text-slate-400 space-y-1">
                <div>・予想遅延削減効果: <strong class="text-emerald-400">-8 分</strong></div>
                <div>・乗客影響数: <strong class="text-slate-200">850 名</strong></div>
              </div>
              <button 
                (click)="approveRec('rec-rail-101')"
                class="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow transition">
                指令長として代替運行案を承認 (Approve Dispatch)
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class RailControlComponent implements OnInit {
  public api = inject(HorizonApiService);

  ngOnInit() {
    this.api.fetchTrains().subscribe();
  }

  approveRec(id: string) {
    this.api.approveRecommendation(id, 'APPROVE', '鉄道運行指令長 (Rail Dispatch Commander)').subscribe();
  }
}
