import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from '../../core/services/horizon-api';

@Component({
  selector: 'app-factory-control',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- Factory OS Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-xs font-bold rounded-full bg-rose-500/20 text-rose-400 border border-rose-500/30">
              SMART FACTORY OS & MOM (MANUFACTURING OPERATIONS)
            </span>
            <span class="text-xs text-slate-400">MES / MOM / PLC / 予知保全 (Predictive Maintenance)</span>
          </div>
          <h1 class="text-xl font-bold text-slate-100 mt-1">横浜スマートプラント 生産統合統制</h1>
        </div>
        <div class="flex items-center gap-3 text-xs text-slate-300">
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            総合設備効率 (OEE): <strong class="text-rose-400">81.7 %</strong>
          </div>
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            品質合格率 (Pass Rate): <strong class="text-emerald-400">99.86 %</strong>
          </div>
        </div>
      </div>

      <!-- Factory Machines & MOM Flow Grid -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Machine Status List -->
        <div class="lg:col-span-2 space-y-4">
          <h2 class="text-sm font-bold text-slate-300 uppercase tracking-wider flex items-center gap-2">
            <span class="material-icons text-rose-400 text-base">precision_manufacturing</span>
            主要製造設備 & 振動作動ステータス (Machine SCADA/PLC)
          </h2>

          <div class="space-y-3">
            @for (mch of api.factoryMachines(); track mch.id) {
              <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3 hover:border-slate-700 transition">
                <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-800">
                  <div class="flex items-center gap-3">
                    <span class="w-10 h-10 rounded-xl bg-rose-950 border border-rose-700/50 text-rose-300 flex items-center justify-center font-extrabold text-sm">
                      {{ mch.machine_code }}
                    </span>
                    <div>
                      <h3 class="text-base font-bold text-slate-100">{{ mch.factory_name }} - {{ mch.line_name }}</h3>
                      <p class="text-xs text-slate-400">{{ mch.type }} | PLC: {{ mch.plc_status }}</p>
                    </div>
                  </div>
                  <span 
                    [class.bg-emerald-500/20]="mch.status === 'NORMAL'"
                    [class.text-emerald-400]="mch.status === 'NORMAL'"
                    [class.bg-rose-500/20]="mch.status === 'WARNING' || mch.status === 'CRITICAL'"
                    [class.text-rose-400]="mch.status === 'WARNING' || mch.status === 'CRITICAL'"
                    class="px-3 py-1 rounded-full text-xs font-bold">
                    {{ mch.status }}
                  </span>
                </div>

                <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                  <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                    <span class="text-slate-500 block text-[10px]">軸受振動 (Vibration)</span>
                    <span class="font-bold text-rose-400 text-sm">{{ mch.vibration_mm_s }} mm/s</span>
                  </div>
                  <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                    <span class="text-slate-500 block text-[10px]">設備OEE (Effectiveness)</span>
                    <span class="font-bold text-slate-200 text-sm">{{ mch.oee_pct }} %</span>
                  </div>
                  <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                    <span class="text-slate-500 block text-[10px]">故障予測確率 (Fail Prob)</span>
                    <span class="font-bold text-amber-400 text-sm">{{ (mch.failure_probability * 100).toFixed(0) }} %</span>
                  </div>
                  <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                    <span class="text-slate-500 block text-[10px]">推定残寿命 (Window)</span>
                    <span class="font-bold text-rose-400 text-sm">{{ mch.estimated_failure_window_hours }} 時間</span>
                  </div>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Predictive Work Order Generator -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800">
            <span class="font-bold text-slate-200 text-sm flex items-center gap-2">
              <span class="material-icons text-amber-400 text-base">build</span>
              Physical AI 予知保全ワークオーダー
            </span>
            <span class="text-xs bg-rose-500/20 text-rose-300 px-2 py-0.5 rounded font-bold">RUL推論完了</span>
          </div>

          <div class="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3 text-xs">
            <h4 class="font-bold text-slate-100">ロボットセル RC-04 軸受予防交換指令</h4>
            <p class="text-slate-300 leading-relaxed bg-slate-900 p-2.5 rounded border border-slate-800">
              軸受振動値（7.2mm/s）が管理限界（5.0mm/s）を超過しました。36時間以内の軸受焼損を回避するため、今夜22:00の計画点検での予防パーツ（BRG-9921）交換指示を発行します。
            </p>
            <button 
              (click)="approveWO()"
              class="w-full py-2.5 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded-xl shadow transition flex items-center justify-center gap-1.5">
              <span class="material-icons text-sm">assignment_turned_in</span>
              予防保全ワークオーダー承認・発行
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class FactoryControlComponent implements OnInit {
  public api = inject(HorizonApiService);

  ngOnInit() {
    this.api.fetchFactoryMachines().subscribe();
  }

  approveWO() {
    this.api.approveRecommendation('rec-factory-303', 'APPROVE', '工場生産統括長 (Plant Operations Director)').subscribe();
  }
}
