import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from '../../core/services/horizon-api';

@Component({
  selector: 'app-datacenter-control',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- DC & Building Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-xs font-bold rounded-full bg-sky-500/20 text-sky-400 border border-sky-500/30">
              DATA CENTER & BUILDING INFRASTRUCTURE OS
            </span>
            <span class="text-xs text-slate-400">GPUラック・PUE冷却効率・HVAC空調・スマートビル</span>
          </div>
          <h1 class="text-xl font-bold text-slate-100 mt-1">千葉ハイパースケール AI データセンター</h1>
        </div>
        <div class="flex items-center gap-3 text-xs text-slate-300">
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            エネルギー効率 PUE: <strong class="text-emerald-400">1.14</strong>
          </div>
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            全系 GPU 使用率: <strong class="text-sky-400">91.4 %</strong>
          </div>
        </div>
      </div>

      <!-- DC Rack Status Matrix -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        @for (rack of dcRacks; track rack.id) {
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3 hover:border-slate-700 transition">
            <div class="flex items-center justify-between pb-2 border-b border-slate-800">
              <div class="flex items-center gap-2">
                <span class="material-icons text-sky-400">dns</span>
                <span class="font-bold text-slate-100 text-sm">{{ rack.name }}</span>
              </div>
              <span class="text-xs text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded font-bold">OPTIMAL</span>
            </div>

            <div class="space-y-2 text-xs">
              <div class="flex justify-between text-slate-400">
                <span>GPUクラスター負荷:</span>
                <strong class="text-slate-200">{{ rack.gpu_load_pct }}%</strong>
              </div>
              <div class="w-full bg-slate-950 h-2 rounded-full overflow-hidden border border-slate-800">
                <div [style.width.%]="rack.gpu_load_pct" class="h-full bg-sky-500"></div>
              </div>

              <div class="grid grid-cols-2 gap-2 pt-2 text-[11px]">
                <div class="bg-slate-950 p-2 rounded">
                  <span class="text-slate-500 block">電力 (Power)</span>
                  <span class="font-bold text-slate-200">{{ rack.power_kw }} kW</span>
                </div>
                <div class="bg-slate-950 p-2 rounded">
                  <span class="text-slate-500 block">排熱温度 (Temp)</span>
                  <span class="font-bold text-amber-400">{{ rack.temp_c }} °C</span>
                </div>
              </div>
            </div>
          </div>
        }
      </div>
    </div>
  `
})
export class DatacenterControlComponent implements OnInit {
  public api = inject(HorizonApiService);

  public dcRacks = [
    { id: 'rack-01', name: 'GPU-Cluster Rack #01 (H100)', gpu_load_pct: 94, power_kw: 38.4, temp_c: 42.1 },
    { id: 'rack-02', name: 'GPU-Cluster Rack #02 (H100)', gpu_load_pct: 88, power_kw: 35.1, temp_c: 39.8 },
    { id: 'rack-03', name: 'AI Inference Rack #03', gpu_load_pct: 92, power_kw: 36.8, temp_c: 41.2 },
    { id: 'rack-04', name: 'Core Storage & Network', gpu_load_pct: 45, power_kw: 14.2, temp_c: 32.5 }
  ];

  ngOnInit() {
    this.api.fetchEvents().subscribe();
  }
}
