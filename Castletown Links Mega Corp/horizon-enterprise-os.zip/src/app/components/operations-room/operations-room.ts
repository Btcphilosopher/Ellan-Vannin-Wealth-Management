import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from '../../core/services/horizon-api';
import { Asset } from '../../../server/types';

@Component({
  selector: 'app-operations-room',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- Operations Room Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-xs font-bold rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              運用統制ルーム / OPERATIONS CONTROL ROOM
            </span>
            <span class="text-xs text-slate-400">IT / OT 統合キャンバス & 資産ツリー</span>
          </div>
          <h1 class="text-xl font-bold text-slate-100 mt-1">社会インフラリアルタイム監視キャンバス</h1>
        </div>
        <div class="flex items-center gap-2">
          <button 
            (click)="selectedDomain.set('ALL')"
            [class.bg-cyan-600]="selectedDomain() === 'ALL'"
            class="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition">
            全領域 (All Domains)
          </button>
          <button 
            (click)="selectedDomain.set('RAIL')"
            [class.bg-indigo-600]="selectedDomain() === 'RAIL'"
            class="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition">
            鉄道 (Rail)
          </button>
          <button 
            (click)="selectedDomain.set('ENERGY')"
            [class.bg-emerald-600]="selectedDomain() === 'ENERGY'"
            class="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition">
            電力 (Energy)
          </button>
          <button 
            (click)="selectedDomain.set('MANUFACTURING')"
            [class.bg-rose-600]="selectedDomain() === 'MANUFACTURING'"
            class="px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition">
            工場 (Factory)
          </button>
        </div>
      </div>

      <!-- Main Operations Control Grid Layout -->
      <div class="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <!-- Left: Asset Tree Hierarchy -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col h-[600px] overflow-hidden">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
            <span class="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
              <span class="material-icons text-sm text-cyan-400">account_tree</span>
              資産階層ツリー (Asset Tree)
            </span>
            <span class="text-[10px] text-slate-400">全 {{ api.assets().length }} 設備</span>
          </div>

          <div class="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
            @for (asset of filteredAssets(); track asset.id) {
              <div 
                role="button"
                tabindex="0"
                (click)="selectAsset(asset)"
                (keyup.enter)="selectAsset(asset)"
                [class.border-cyan-500]="selectedAsset()?.id === asset.id"
                [class.bg-slate-800]="selectedAsset()?.id === asset.id"
                class="p-3 bg-slate-950 rounded-xl border border-slate-800/80 hover:border-slate-700 transition cursor-pointer space-y-1">
                <div class="flex items-center justify-between">
                  <span class="text-xs font-bold text-slate-200 truncate">{{ asset.name }}</span>
                  <span 
                    [class.bg-emerald-500/20]="asset.state === 'NORMAL'"
                    [class.text-emerald-400]="asset.state === 'NORMAL'"
                    [class.bg-amber-500/20]="asset.state === 'WARNING' || asset.state === 'DEGRADED'"
                    [class.text-amber-400]="asset.state === 'WARNING' || asset.state === 'DEGRADED'"
                    [class.bg-rose-500/20]="asset.state === 'CRITICAL'"
                    [class.text-rose-400]="asset.state === 'CRITICAL'"
                    class="text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
                    {{ asset.state }}
                  </span>
                </div>
                <div class="flex items-center justify-between text-[11px] text-slate-400">
                  <span>{{ asset.code }} | {{ asset.type }}</span>
                  <span>Health: {{ asset.health_score }}%</span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- Center: Interactive Digital Twin Graphical Diagram -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col h-[600px] relative overflow-hidden">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800 mb-2">
            <div class="flex items-center gap-2">
              <span class="material-icons text-emerald-400">view_in_ar</span>
              <span class="text-xs font-bold text-slate-200">デジタルツインキャンバス (Digital Twin Canvas)</span>
            </div>
            <div class="flex items-center gap-2 text-xs text-slate-400">
              <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              OT SCADA & SENSOR STREAM
            </div>
          </div>

          <!-- Digital Twin Interactive SVG Map -->
          <div class="flex-1 bg-slate-950 rounded-xl border border-slate-800/80 p-4 relative flex items-center justify-center overflow-hidden">
            <svg class="w-full h-full" viewBox="0 0 800 500" fill="none">
              <!-- Grid background lines -->
              <defs>
                <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                  <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#1e293b" stroke-width="0.5"/>
                </pattern>
              </defs>
              <rect width="800" height="500" fill="url(#grid)" />

              <!-- Railway Line Path -->
              <path d="M 50 150 Q 250 80 450 180 T 750 120" stroke="#6366f1" stroke-width="4" stroke-dasharray="8 4" class="animate-pulse" />
              <!-- Power Grid Flow Path -->
              <path d="M 120 400 L 350 320 L 600 380" stroke="#10b981" stroke-width="3" stroke-dasharray="4 2" />

              <!-- Railway Nodes -->
              <g transform="translate(150, 115)">
                <circle r="16" fill="#1e1b4b" stroke="#818cf8" stroke-width="2" />
                <text x="0" y="4" text-anchor="middle" fill="#e0e7ff" font-size="10" font-weight="bold">STN-01</text>
                <text x="0" y="28" text-anchor="middle" fill="#94a3b8" font-size="9">新宿 (Shinjuku)</text>
              </g>

              <!-- Moving Train Node on Railway -->
              <g transform="translate(320, 140)">
                <circle r="22" fill="#78350f" stroke="#f59e0b" stroke-width="3" class="animate-ping opacity-30" />
                <rect x="-18" y="-12" width="36" height="24" rx="6" fill="#b45309" stroke="#fbbf24" stroke-width="2" />
                <text x="0" y="3" text-anchor="middle" fill="#fff" font-size="9" font-weight="bold">特急104</text>
                <text x="0" y="26" text-anchor="middle" fill="#fbbf24" font-size="9">+12m 遅延</text>
              </g>

              <g transform="translate(550, 155)">
                <circle r="16" fill="#1e1b4b" stroke="#818cf8" stroke-width="2" />
                <text x="0" y="4" text-anchor="middle" fill="#e0e7ff" font-size="10" font-weight="bold">STN-02</text>
                <text x="0" y="28" text-anchor="middle" fill="#94a3b8" font-size="9">立川 (Tachikawa)</text>
              </g>

              <!-- Power Substation Node -->
              <g transform="translate(120, 400)">
                <rect x="-24" y="-20" width="48" height="40" rx="8" fill="#064e3b" stroke="#34d399" stroke-width="2" />
                <text x="0" y="-2" text-anchor="middle" fill="#a7f3d0" font-size="9" font-weight="bold">変電所</text>
                <text x="0" y="10" text-anchor="middle" fill="#a7f3d0" font-size="8">T-801</text>
                <text x="0" y="32" text-anchor="middle" fill="#f59e0b" font-size="9">420MW (88%)</text>
              </g>

              <!-- Smart Factory Node -->
              <g transform="translate(350, 320)">
                <rect x="-26" y="-22" width="52" height="44" rx="8" fill="#881337" stroke="#f43f5e" stroke-width="2" />
                <text x="0" y="-4" text-anchor="middle" fill="#fecdd3" font-size="9" font-weight="bold">横浜工場</text>
                <text x="0" y="8" text-anchor="middle" fill="#fecdd3" font-size="8">RC-04</text>
                <text x="0" y="34" text-anchor="middle" fill="#f43f5e" font-size="9">7.2 mm/s (振)</text>
              </g>

              <!-- Data Center Node -->
              <g transform="translate(600, 380)">
                <rect x="-24" y="-20" width="48" height="40" rx="8" fill="#0c4a6e" stroke="#38bdf8" stroke-width="2" />
                <text x="0" y="-2" text-anchor="middle" fill="#bae6fd" font-size="9" font-weight="bold">千葉AI DC</text>
                <text x="0" y="10" text-anchor="middle" fill="#bae6fd" font-size="8">RACK-08</text>
                <text x="0" y="32" text-anchor="middle" fill="#38bdf8" font-size="9">GPU 91%</text>
              </g>

              <!-- Connection Flow Lines -->
              <path d="M 120 400 Q 230 300 320 140" stroke="#f59e0b" stroke-width="1.5" stroke-dasharray="3 3" />
              <path d="M 120 400 L 350 320" stroke="#f43f5e" stroke-width="1.5" stroke-dasharray="3 3" />
            </svg>

            <!-- Overlay Legend -->
            <div class="absolute bottom-3 left-3 bg-slate-900/90 border border-slate-800 p-2.5 rounded-lg text-[11px] text-slate-300 space-y-1">
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-2.5 rounded-full bg-indigo-500"></span>
                <span>鉄道線路・ステーション (Rail)</span>
              </div>
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
                <span>電力送電網 (Power Grid)</span>
              </div>
              <div class="flex items-center gap-2">
                <span class="w-2.5 h-2.5 rounded-full bg-rose-500"></span>
                <span>スマート工場 (Smart Factory)</span>
              </div>
            </div>
          </div>
        </div>

        <!-- Right: Real-time Telemetry & Active Events Feed -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 flex flex-col h-[600px] space-y-4">
          <!-- Active Asset Details -->
          <div class="pb-3 border-b border-slate-800 space-y-2">
            <span class="text-xs font-bold text-slate-400 uppercase tracking-wider">選択中資産詳細 (Selected Asset)</span>
            @if (selectedAsset(); as a) {
              <div class="p-3 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div class="flex items-center justify-between">
                  <span class="text-xs font-bold text-slate-100">{{ a.name }}</span>
                  <span class="text-[10px] text-amber-400 font-bold bg-amber-500/10 px-2 py-0.5 rounded">{{ a.state }}</span>
                </div>
                <div class="grid grid-cols-2 gap-2 text-[11px]">
                  <div class="bg-slate-900 p-2 rounded">
                    <span class="text-slate-500 block">設置場所:</span>
                    <span class="text-slate-200 font-medium">{{ a.location_name }}</span>
                  </div>
                  <div class="bg-slate-900 p-2 rounded">
                    <span class="text-slate-500 block">残有用年数:</span>
                    <span class="text-slate-200 font-medium">{{ a.remaining_useful_life_days }} 日</span>
                  </div>
                </div>
              </div>
            } @else {
              <p class="text-xs text-slate-500">左側ツリーから設備を選択してください。</p>
            }
          </div>

          <!-- Live Telemetry Stream -->
          <div class="flex-1 flex flex-col min-h-0 space-y-2">
            <div class="flex items-center justify-between">
              <span class="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1">
                <span class="material-icons text-sm text-amber-400">sensors</span>
                高頻度テレメトリタイムライン
              </span>
              <span class="text-[10px] text-emerald-400">100Hz Ingest</span>
            </div>

            <div class="flex-1 overflow-y-auto space-y-2 pr-1 custom-scrollbar">
              @for (telemetry of api.liveTelemetry(); track telemetry.telemetry_id) {
                <div class="p-2.5 bg-slate-950 rounded-lg border border-slate-800/80 text-[11px] space-y-1">
                  <div class="flex items-center justify-between text-slate-300">
                    <span class="font-semibold text-slate-200">Sensor: {{ telemetry.telemetry_id }}</span>
                    <span class="text-[10px] text-slate-500">{{ telemetry.timestamp | date:'HH:mm:ss' }}</span>
                  </div>
                  <div class="flex items-center justify-between text-slate-400">
                    <span>Vibration: <strong class="text-amber-400">{{ telemetry.vibration }} mm/s</strong></span>
                    <span>Temp: <strong class="text-slate-200">{{ telemetry.temperature }}°C</strong></span>
                  </div>
                </div>
              }
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class OperationsRoomComponent implements OnInit {
  public api = inject(HorizonApiService);
  public selectedDomain = signal<string>('ALL');
  public selectedAsset = signal<Asset | null>(null);

  ngOnInit() {
    this.api.fetchAssets().subscribe(res => {
      if (res.data && res.data.length > 0) {
        this.selectedAsset.set(res.data[0]);
      }
    });
    this.api.fetchTelemetry().subscribe();
  }

  filteredAssets(): Asset[] {
    const domain = this.selectedDomain();
    const all = this.api.assets();
    if (domain === 'ALL') return all;
    return all.filter(a => a.sector === domain);
  }

  selectAsset(asset: Asset) {
    this.selectedAsset.set(asset);
  }
}
