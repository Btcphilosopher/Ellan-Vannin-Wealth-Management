import { Component, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HorizonApiService } from '../../core/services/horizon-api';
import { WhatIfScenarioResult } from '../../../server/types';

@Component({
  selector: 'app-what-if',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="space-y-6">
      <!-- What-If Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-xs font-bold rounded-full bg-purple-500/20 text-purple-400 border border-purple-500/30">
              WHAT-IF SCENARIO SIMULATION ENGINE
            </span>
            <span class="text-xs text-slate-400">デジタルツイン・モンテカルロ推定・財務影響算出</span>
          </div>
          <h1 class="text-xl font-bold text-slate-100 mt-1">社会インフラ What-If 仮説検証シミュレータ</h1>
        </div>
      </div>

      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Input Parameters Panel -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h2 class="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <span class="material-icons text-purple-400 text-base">tune</span>
            シミュレーションシナリオ設定
          </h2>

          <div class="space-y-3 text-xs">
            <div>
              <label for="scen-type" class="block text-slate-400 mb-1">検証タイプ (Scenario Type)</label>
              <select 
                id="scen-type"
                [(ngModel)]="scenarioType"
                class="w-full bg-slate-950 border border-slate-800 rounded-xl p-2.5 text-slate-200 focus:outline-none focus:border-purple-500">
                <option value="RAIL_LINE_CLOSURE">鉄道全線運行抑止 (Rail Line Closure)</option>
                <option value="POWER_DEMAND_SPIKE">電力需要スパイク (Power Demand Spike)</option>
                <option value="FACTORY_OUTAGE">スマート工場ライン停止 (Factory Line Outage)</option>
              </select>
            </div>

            @if (scenarioType === 'RAIL_LINE_CLOSURE') {
              <div>
                <label for="scen-duration" class="block text-slate-400 mb-1">影響想定時間 (Hours): {{ durationHours }} 時間</label>
                <input id="scen-duration" type="range" min="1" max="12" [(ngModel)]="durationHours" class="w-full accent-purple-500">
              </div>
            }

            @if (scenarioType === 'POWER_DEMAND_SPIKE') {
              <div>
                <label for="scen-spike" class="block text-slate-400 mb-1">需要増加率 (Spike %): {{ demandSpikePct }} %</label>
                <input id="scen-spike" type="range" min="5" max="30" [(ngModel)]="demandSpikePct" class="w-full accent-purple-500">
              </div>
            }

            <button 
              (click)="runSim()"
              class="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-bold rounded-xl shadow-lg transition flex items-center justify-center gap-2 mt-4">
              <span class="material-icons text-sm">play_arrow</span>
              What-If シミュレーション実行
            </button>
          </div>
        </div>

        <!-- Simulation Results Output -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <h2 class="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <span class="material-icons text-emerald-400 text-base">analytics</span>
            シミュレーション結果 (Estimated Impact Analysis)
          </h2>

          @if (simResult(); as res) {
            <div class="space-y-4">
              <div class="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between">
                <div>
                  <h3 class="font-bold text-slate-100 text-sm">{{ res.scenario_name }}</h3>
                  <p class="text-xs text-slate-400 mt-0.5">計算日時: {{ res.simulated_at | date:'HH:mm:ss' }}</p>
                </div>
                <span class="px-3 py-1 bg-purple-500/20 text-purple-400 font-bold text-xs rounded-full border border-purple-500/30">
                  リスクスコア: {{ res.risk_score }} / 100
                </span>
              </div>

              <!-- Output Metrics Grid -->
              <div class="grid grid-cols-2 md:grid-cols-3 gap-3 text-xs">
                <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span class="text-slate-500 block text-[10px]">想定財務損失 (Financial Loss)</span>
                  <span class="font-bold text-rose-400 text-base">¥{{ (res.estimated_financial_loss_jpy / 1000000).toFixed(0) }} 百万円</span>
                </div>
                <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span class="text-slate-500 block text-[10px]">キャパシティ低下 (Capacity Drop)</span>
                  <span class="font-bold text-amber-400 text-base">{{ res.capacity_drop_pct }} %</span>
                </div>
                <div class="bg-slate-950 p-3 rounded-xl border border-slate-800">
                  <span class="text-slate-500 block text-[10px]">CO2増加影響 (Carbon Impact)</span>
                  <span class="font-bold text-slate-200 text-base">{{ res.carbon_footprint_ton }} t-CO2</span>
                </div>
              </div>

              <!-- Recommended Mitigations -->
              <div class="bg-slate-950 p-4 rounded-xl border border-slate-800 space-y-2">
                <span class="text-xs font-bold text-slate-300 uppercase tracking-wider">自動算出された推奨緩和対策 (Mitigation Actions)</span>
                <div class="space-y-1.5 text-xs text-slate-300">
                  @for (mit of res.recommended_mitigations; track mit) {
                    <div class="flex items-center gap-2">
                      <span class="material-icons text-emerald-400 text-sm">check_circle_outline</span>
                      <span>{{ mit }}</span>
                    </div>
                  }
                </div>
              </div>
            </div>
          } @else {
            <p class="text-xs text-slate-500 py-12 text-center">左パネルから条件を設定し、「シミュレーション実行」をクリックしてください。</p>
          }
        </div>
      </div>
    </div>
  `
})
export class WhatIfComponent {
  public api = inject(HorizonApiService);

  public scenarioType = 'RAIL_LINE_CLOSURE';
  public durationHours = 4;
  public demandSpikePct = 15;
  public simResult = signal<WhatIfScenarioResult | null>(null);

  runSim() {
    const input = {
      type: this.scenarioType,
      scenario_name: this.scenarioType,
      parameters: {
        duration_hours: this.durationHours,
        demand_increase_pct: this.demandSpikePct
      }
    };

    this.api.runWhatIf(input).subscribe(res => {
      if (res.status === 'SUCCESS') {
        this.simResult.set(res.data || null);
      }
    });
  }
}
