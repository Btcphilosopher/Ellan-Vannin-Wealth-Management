import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from '../../core/services/horizon-api';

@Component({
  selector: 'app-executive-tower',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- CEO Executive Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl backdrop-blur-md">
        <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div>
            <div class="flex items-center gap-3 mb-1">
              <span class="px-3 py-1 text-xs font-bold tracking-wider rounded-full bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
                経営統制タワー / EXECUTIVE CONTROL TOWER
              </span>
              <span class="text-xs text-slate-400">リアルタイムAIクロスドメイン診断</span>
            </div>
            <h1 class="text-2xl font-bold text-slate-100 tracking-tight">全社インフラ統合状況・CEOサマリー</h1>
          </div>
          <div class="flex items-center gap-3">
            <button 
              (click)="refresh()"
              class="px-4 py-2 text-xs font-semibold rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition flex items-center gap-2">
              <span class="material-icons text-sm">refresh</span>
              AI再診断
            </button>
            <button 
              (click)="api.triggerDemoScenario().subscribe()"
              class="px-4 py-2 text-xs font-bold rounded-xl bg-gradient-to-r from-red-600 to-amber-600 hover:from-red-500 hover:to-amber-500 text-white shadow-lg transition flex items-center gap-2 animate-pulse">
              <span class="material-icons text-sm">warning</span>
              複合インフラ障害発動 (Demo Trigger)
            </button>
          </div>
        </div>
      </div>

      <!-- Domain KPI Cards Matrix -->
      <div class="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <!-- Rail KPI -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition">
          <div class="flex items-center justify-between">
            <span class="text-xs font-medium text-slate-400">鉄道モビリティ</span>
            <span class="material-icons text-indigo-400 text-lg">train</span>
          </div>
          <div class="my-3">
            <div class="text-xl font-extrabold text-amber-400">+12分 遅延</div>
            <div class="text-xs text-slate-400 mt-1">中央線104号 特急</div>
          </div>
          <div class="text-[10px] text-amber-400/80 bg-amber-500/10 px-2 py-1 rounded">ステータス: 減速抑止中</div>
        </div>

        <!-- Energy KPI -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition">
          <div class="flex items-center justify-between">
            <span class="text-xs font-medium text-slate-400">エネルギーグリッド</span>
            <span class="material-icons text-emerald-400 text-lg">bolt</span>
          </div>
          <div class="my-3">
            <div class="text-xl font-extrabold text-amber-400">88.4% 負荷</div>
            <div class="text-xs text-slate-400 mt-1">茨城500kV変電所</div>
          </div>
          <div class="text-[10px] text-amber-400/80 bg-amber-500/10 px-2 py-1 rounded">予備率: 6.7% (逼迫)</div>
        </div>

        <!-- Manufacturing KPI -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition">
          <div class="flex items-center justify-between">
            <span class="text-xs font-medium text-slate-400">スマート製造</span>
            <span class="material-icons text-cyan-400 text-lg">precision_manufacturing</span>
          </div>
          <div class="my-3">
            <div class="text-xl font-extrabold text-rose-400">7.2 mm/s</div>
            <div class="text-xs text-slate-400 mt-1">溶接ロボット RC-04</div>
          </div>
          <div class="text-[10px] text-rose-400/80 bg-rose-500/10 px-2 py-1 rounded">36h内故障確率 78%</div>
        </div>

        <!-- Data Center KPI -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition">
          <div class="flex items-center justify-between">
            <span class="text-xs font-medium text-slate-400">データセンター</span>
            <span class="material-icons text-sky-400 text-lg">dns</span>
          </div>
          <div class="my-3">
            <div class="text-xl font-extrabold text-emerald-400">PUE 1.14</div>
            <div class="text-xs text-slate-400 mt-1">千葉AI DC (GPU 91%)</div>
          </div>
          <div class="text-[10px] text-emerald-400/80 bg-emerald-500/10 px-2 py-1 rounded">冷却状態: 最適</div>
        </div>

        <!-- Security KPI -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition">
          <div class="flex items-center justify-between">
            <span class="text-xs font-medium text-slate-400">OTセキュリティ</span>
            <span class="material-icons text-purple-400 text-lg">shield</span>
          </div>
          <div class="my-3">
            <div class="text-xl font-extrabold text-amber-400">ELEVATED</div>
            <div class="text-xs text-slate-400 mt-1">不正PLC書き込み検知</div>
          </div>
          <div class="text-[10px] text-emerald-400/80 bg-emerald-500/10 px-2 py-1 rounded">DMZ隔離: 100%成功</div>
        </div>

        <!-- Finance KPI -->
        <div class="bg-slate-900/80 border border-slate-800 rounded-xl p-4 flex flex-col justify-between hover:border-slate-700 transition">
          <div class="flex items-center justify-between">
            <span class="text-xs font-medium text-slate-400">財務 & CapEx</span>
            <span class="material-icons text-amber-400 text-lg">account_balance</span>
          </div>
          <div class="my-3">
            <div class="text-xl font-extrabold text-slate-100">¥125.0 億円</div>
            <div class="text-xs text-slate-400 mt-1">Q3 設備投資 (CapEx)</div>
          </div>
          <div class="text-[10px] text-slate-400 bg-slate-800 px-2 py-1 rounded">ROIC: 13.1%</div>
        </div>
      </div>

      <!-- Physical AI Executive Analysis Panel -->
      <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <!-- Physical AI Gemini Insights -->
        <div class="lg:col-span-2 bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <span class="material-icons text-cyan-400">psychology</span>
              <h2 class="font-bold text-slate-100">Physical AI クロスドメイン全社統合診断 (Gemini 3.8 Flash)</h2>
            </div>
            <span class="text-xs text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-2.5 py-1 rounded-full flex items-center gap-1">
              <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              リアルタイム自律解析
            </span>
          </div>

          <div class="bg-slate-950/80 rounded-xl p-5 border border-slate-800 font-mono text-sm leading-relaxed text-slate-200 whitespace-pre-line">
            {{ api.executiveSummary()?.executive_summary_ja || 'Gemini Physical AI Engineが社会インフラデータを解析中...' }}
          </div>

          <!-- Cross-Domain Correlations -->
          <div class="space-y-2">
            <h3 class="text-xs font-bold text-slate-400 uppercase tracking-wider">自動検出された領域間相関モデル (Cross-Domain Correlations)</h3>
            <div class="space-y-1.5">
              @for (corr of api.executiveSummary()?.cross_domain_correlations; track corr) {
                <div class="flex items-center gap-2 text-xs text-slate-300 bg-slate-950 px-3 py-2 rounded-lg border border-slate-800/80">
                  <span class="material-icons text-amber-400 text-sm">link</span>
                  <span>{{ corr }}</span>
                </div>
              }
            </div>
          </div>
        </div>

        <!-- Recommended CEO Actions & Approvals Queue -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
          <div class="flex items-center justify-between pb-3 border-b border-slate-800">
            <div class="flex items-center gap-2">
              <span class="material-icons text-amber-400">gavel</span>
              <h2 class="font-bold text-slate-100">経営推奨決定事項 (CEO Decision)</h2>
            </div>
            <span class="text-xs bg-amber-500/20 text-amber-400 px-2 py-0.5 rounded font-bold">承認保留 3件</span>
          </div>

          <div class="space-y-3">
            @for (action of api.executiveSummary()?.recommended_ceo_actions; track $index) {
              <div class="bg-slate-950 p-3.5 rounded-xl border border-slate-800 space-y-2">
                <div class="flex items-start gap-2">
                  <span class="bg-amber-500/20 text-amber-400 text-xs font-bold px-2 py-0.5 rounded mt-0.5">要承認</span>
                  <p class="text-xs font-medium text-slate-200 leading-snug">{{ action }}</p>
                </div>
                <div class="flex items-center justify-end gap-2 pt-1 border-t border-slate-900">
                  <span class="text-[10px] text-slate-400">AI確信度: 94%</span>
                </div>
              </div>
            }
          </div>

          <div class="pt-2">
            <div class="p-3 bg-cyan-950/30 border border-cyan-800/40 rounded-xl text-xs text-cyan-300 flex items-center gap-2">
              <span class="material-icons text-cyan-400 text-base">verified_user</span>
              <span>すべての操作はCommand Gatewayでゼロトラスト検証され、監査ログに保存されます。</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class ExecutiveTowerComponent implements OnInit {
  public api = inject(HorizonApiService);

  ngOnInit() {
    this.api.fetchExecutiveSummary().subscribe();
  }

  refresh() {
    this.api.fetchExecutiveSummary().subscribe();
  }
}
