import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from '../../core/services/horizon-api';

@Component({
  selector: 'app-supply-chain',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- Supply Chain Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-xs font-bold rounded-full bg-teal-500/20 text-teal-400 border border-teal-500/30">
              SUPPLY CHAIN & CRITICAL PROCUREMENT OS
            </span>
            <span class="text-xs text-slate-400">サプライヤーリスク・調達見積RFQ・クリティカル在庫</span>
          </div>
          <h1 class="text-xl font-bold text-slate-100 mt-1">社会インフラ 部品サプライチェーン & 調達管理</h1>
        </div>
        <div class="flex items-center gap-3 text-xs text-slate-300">
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            サプライチェーンリスク評価: <strong class="text-emerald-400">LOW (正常)</strong>
          </div>
        </div>
      </div>

      <!-- Suppliers & RFQs List -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <!-- Suppliers List -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h2 class="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <span class="material-icons text-teal-400 text-base">local_shipping</span>
            主要パートナーサプライヤー & 信頼性スコア
          </h2>

          <div class="space-y-3">
            @for (sup of suppliers; track sup.id) {
              <div class="p-3.5 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
                <div class="flex items-center justify-between">
                  <span class="font-bold text-slate-100 text-xs">{{ sup.name }}</span>
                  <span class="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded">スコア: {{ sup.score }}点</span>
                </div>
                <div class="flex items-center justify-between text-xs text-slate-400">
                  <span>供給部品: {{ sup.component }}</span>
                  <span>納期遵守率: {{ sup.lead_time_compliance }}%</span>
                </div>
              </div>
            }
          </div>
        </div>

        <!-- RFQ Procurements -->
        <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h2 class="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <span class="material-icons text-amber-400 text-base">receipt_long</span>
            緊急自動見積・部品調達注文 (RFQ)
          </h2>

          <div class="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3 text-xs">
            <div class="flex justify-between items-center">
              <span class="font-bold text-slate-100">RFQ-2026-901: RC-04用 精密軸受 BRG-9921</span>
              <span class="bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-bold">発注完了 (APPROVED)</span>
            </div>
            <p class="text-slate-300 leading-relaxed bg-slate-900 p-2.5 rounded border border-slate-800">
              日本ベアリングテクノロジー社への即時納品要請（金額: ¥380,000 JPY）。本日18:00までに横浜スマートプラント受入ドック着。
            </p>
          </div>
        </div>
      </div>
    </div>
  `
})
export class SupplyChainComponent implements OnInit {
  public api = inject(HorizonApiService);

  public suppliers = [
    { id: 'sup-01', name: '日本ベアリングテクノロジー Inc.', component: '精密ロボット用軸受 (Bearings)', score: 96, lead_time_compliance: 99.2 },
    { id: 'sup-02', name: '関関東超高圧電線・導体工業', component: '500kV超高圧ケーブル (XHV Cable)', score: 92, lead_time_compliance: 98.5 },
    { id: 'sup-03', name: 'グローバルパワーセミコン社', component: 'SiCパワーモジュール', score: 88, lead_time_compliance: 94.1 }
  ];

  ngOnInit() {
    this.api.fetchAuditRecords().subscribe();
  }
}
