import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HorizonApiService } from '../../core/services/horizon-api';

@Component({
  selector: 'app-energy-control',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="space-y-6">
      <!-- Energy OS Header -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-0.5 text-xs font-bold rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              SMART ENERGY & POWER GRID OS
            </span>
            <span class="text-xs text-slate-400">変電所 SCADA ・周波数・BESS蓄電池制御</span>
          </div>
          <h1 class="text-xl font-bold text-slate-100 mt-1">基幹電力系統・エネルギーデジタルツイン</h1>
        </div>
        <div class="flex items-center gap-3 text-xs text-slate-300">
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            系統周波数: <strong class="text-emerald-400">50.04 Hz</strong>
          </div>
          <div class="px-3 py-1.5 bg-slate-800 rounded-lg border border-slate-700">
            再生可能エネルギー比率: <strong class="text-cyan-400">38.2 %</strong>
          </div>
        </div>
      </div>

      <!-- Grid Overview Cards -->
      <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        @for (sub of api.substations(); track sub.id) {
          <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4 hover:border-slate-700 transition">
            <div class="flex items-center justify-between pb-3 border-b border-slate-800">
              <div class="flex items-center gap-2">
                <span class="material-icons text-emerald-400">electric_bolt</span>
                <h3 class="font-bold text-slate-100 text-sm">{{ sub.name }}</h3>
              </div>
              <span 
                [class.bg-emerald-500/20]="sub.status === 'NORMAL'"
                [class.text-emerald-400]="sub.status === 'NORMAL'"
                [class.bg-amber-500/20]="sub.status === 'WARNING'"
                [class.text-amber-400]="sub.status === 'WARNING'"
                class="px-2.5 py-0.5 rounded-full text-xs font-bold">
                {{ sub.status }}
              </span>
            </div>

            <div class="space-y-3">
              <div>
                <div class="flex items-center justify-between text-xs text-slate-400 mb-1">
                  <span>主変圧器負荷率 (Current Load)</span>
                  <span class="font-bold text-slate-200">{{ sub.current_load_mw }} MW / {{ sub.capacity_mw }} MW</span>
                </div>
                <div class="w-full bg-slate-950 h-2.5 rounded-full overflow-hidden border border-slate-800">
                  <div 
                    [style.width.%]="(sub.current_load_mw / sub.capacity_mw) * 100"
                    [class.bg-emerald-500]="(sub.current_load_mw / sub.capacity_mw) < 0.8"
                    [class.bg-amber-500]="(sub.current_load_mw / sub.capacity_mw) >= 0.8"
                    class="h-full transition-all duration-500">
                  </div>
                </div>
              </div>

              <div class="grid grid-cols-2 gap-2 text-xs">
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                  <span class="text-slate-500 block text-[10px]">送電電圧 (Voltage)</span>
                  <span class="font-bold text-slate-200">{{ sub.voltage_kv }} kV</span>
                </div>
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                  <span class="text-slate-500 block text-[10px]">変圧器油温 (Temp)</span>
                  <span class="font-bold text-amber-400">{{ sub.transformer_temp_c }} °C</span>
                </div>
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                  <span class="text-slate-500 block text-[10px]">予備力 (Reserve)</span>
                  <span class="font-bold text-emerald-400">{{ sub.reserve_capacity_pct }} %</span>
                </div>
                <div class="bg-slate-950 p-2.5 rounded-xl border border-slate-800/80">
                  <span class="text-slate-500 block text-[10px]">再エネ貢献度</span>
                  <span class="font-bold text-cyan-400">{{ sub.renewable_contribution_pct }} %</span>
                </div>
              </div>
            </div>
          </div>
        }
      </div>

      <!-- Energy Agent Dispatch Recommendation -->
      <div class="bg-slate-900/90 border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div class="flex items-center justify-between pb-3 border-b border-slate-800">
          <div class="flex items-center gap-2">
            <span class="material-icons text-emerald-400">battery_charging_full</span>
            <h3 class="font-bold text-slate-100">EnergyAgent 蓄電池 (BESS) 放電自動提案</h3>
          </div>
          <span class="text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-3 py-1 rounded-full font-bold">
            推奨 #REC-ENERGY-202
          </span>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-6 items-center">
          <div class="lg:col-span-2 space-y-2">
            <h4 class="text-sm font-bold text-slate-200">茨城基幹変電所 T-801 過負荷防止用 15MW BESS 即時制御</h4>
            <p class="text-xs text-slate-300 leading-relaxed bg-slate-950 p-3 rounded-xl border border-slate-800">
              茨城蓄電パークの定置型BESS(20MWh)から15MWを120分間放電し、主変圧器T-801の負荷率を88.4%から74.0%へ即時引き下げ、温度上昇（88°C）を抑制して送電トリップ事故を防止します。
            </p>
          </div>
          <div>
            <button 
              (click)="approveEnergy()"
              class="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg transition flex items-center justify-center gap-2">
              <span class="material-icons text-sm">flash_on</span>
              BESS 15MW 放電指令を承認実行
            </button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class EnergyControlComponent implements OnInit {
  public api = inject(HorizonApiService);

  ngOnInit() {
    this.api.fetchSubstations().subscribe();
  }

  approveEnergy() {
    this.api.approveRecommendation('rec-energy-202', 'APPROVE', '系統運用指令長 (Power Grid Commander)').subscribe();
  }
}
