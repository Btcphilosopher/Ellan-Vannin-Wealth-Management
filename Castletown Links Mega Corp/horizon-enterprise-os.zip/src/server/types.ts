export type UUID = string;

export type AssetState = 'NORMAL' | 'DEGRADED' | 'WARNING' | 'CRITICAL' | 'OFFLINE' | 'MAINTENANCE' | 'UNKNOWN';

export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';

export type WorkOrderStatus = 'CREATED' | 'ASSIGNED' | 'IN_PROGRESS' | 'BLOCKED' | 'COMPLETED' | 'VERIFIED';

export type AIApprovalState = 'PENDING' | 'APPROVED' | 'REJECTED' | 'AUTO_EXECUTED' | 'SIMULATING';

export interface BaseEntity {
  id: UUID;
  created_at: string;
  updated_at: string;
  version: number;
  status: AssetState | string;
  owner: string;
  source: string;
  classification: string;
}

export interface Organization extends BaseEntity {
  name: string;
  code: string;
  sector: 'DIGITAL_SYSTEMS' | 'ENERGY' | 'RAIL' | 'MOBILITY' | 'INDUSTRIAL' | 'MANUFACTURING' | 'BUILDINGS' | 'DATA_CENTERS' | 'FINANCE' | 'PUBLIC_SERVICES';
  region: string;
  country: string;
  legal_entity: string;
}

export interface Site extends BaseEntity {
  organization_id: UUID;
  name: string;
  type: 'COMMAND_CENTER' | 'SUBSTATION' | 'FACTORY' | 'RAIL_STATION' | 'DATA_CENTER' | 'BUILDING' | 'WAREHOUSE';
  latitude: number;
  longitude: number;
  country: string;
  address: string;
}

export interface AssetRelation {
  source_asset_id: UUID;
  target_asset_id: UUID;
  relationship: 'OWNS' | 'LOCATED_AT' | 'DEPENDS_ON' | 'CONNECTED_TO' | 'PRODUCES' | 'SERVICES' | 'SUPPLIED_BY' | 'MAINTAINED_BY' | 'CONSUMES' | 'AFFECTS';
}

export interface Asset extends BaseEntity {
  site_id: UUID;
  name: string;
  code: string;
  type: 'TRAIN' | 'SIGNAL' | 'TRACK' | 'TRANSFORMER' | 'SWITCHGEAR' | 'MACHINE' | 'ROBOT' | 'PLC' | 'SERVER_RACK' | 'HVAC_CHILLER' | 'ELEVATOR';
  sector: string;
  criticality: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  health_score: number; // 0 - 100
  state: AssetState;
  location_name: string;
  serial_number: string;
  purchase_cost: number; // Decimal
  purchase_currency: 'JPY' | 'USD' | 'EUR' | 'GBP' | 'CHF';
  installed_date: string;
  useful_life_years: number;
  remaining_useful_life_days: number;
  telemetry_metrics?: Record<string, number>;
}

export interface TelemetryReading {
  telemetry_id: UUID;
  asset_id: UUID;
  timestamp: string;
  temperature?: number;
  vibration?: number;
  voltage?: number;
  current?: number;
  power?: number;
  speed?: number;
  pressure?: number;
  frequency?: number;
  humidity?: number;
  load_factor?: number;
  status: AssetState;
  anomaly_detected: boolean;
  anomaly_confidence: number; // 0 - 1
}

export interface IndustrialEvent {
  event_id: UUID;
  timestamp: string;
  source: string;
  entity_id: UUID;
  entity_name: string;
  event_type: 
    | 'SensorReadingReceived'
    | 'AssetStateChanged'
    | 'MachineFailurePredicted'
    | 'TrainDelayed'
    | 'PowerDemandChanged'
    | 'FactoryOutputChanged'
    | 'MaintenanceRequired'
    | 'QualityDeviationDetected'
    | 'EnergyThresholdExceeded'
    | 'CybersecurityIncidentDetected';
  severity: 'INFO' | 'WARNING' | 'CRITICAL';
  payload: Record<string, unknown>;
  schema_version: string;
}

// Domain-Specific Models
export interface TrainUnit {
  id: UUID;
  code: string; // e.g., "TRAIN-104"
  line_name: string;
  current_station: string;
  next_station: string;
  position_km: number;
  speed_kmh: number;
  delay_minutes: number;
  occupancy_pct: number;
  signal_state: 'GREEN' | 'YELLOW' | 'RED';
  energy_kwh: number;
  status: AssetState;
}

export interface PowerSubstation {
  id: UUID;
  name: string;
  grid_zone: string;
  voltage_kv: number;
  current_load_mw: number;
  capacity_mw: number;
  frequency_hz: number;
  reserve_capacity_pct: number;
  transformer_temp_c: number;
  renewable_contribution_pct: number;
  status: AssetState;
}

export interface FactoryMachine {
  id: UUID;
  factory_name: string;
  line_name: string;
  machine_code: string; // e.g. "RC-04"
  type: string;
  vibration_mm_s: number;
  temperature_c: number;
  cycle_time_s: number;
  oee_pct: number; // Overall Equipment Effectiveness
  plc_status: 'RUNNING' | 'ALARM' | 'STOPPED' | 'MAINTENANCE';
  failure_probability: number; // 0 - 1
  estimated_failure_window_hours: number;
  status: AssetState;
}

export interface DataCenterRack {
  id: UUID;
  dc_name: string;
  rack_code: string;
  power_kw: number;
  gpu_utilization_pct: number;
  cpu_utilization_pct: number;
  temp_inlet_c: number;
  pue_efficiency: number; // Power Usage Effectiveness e.g. 1.15
  cooling_status: 'OPTIMAL' | 'HIGH_TEMP' | 'OVERHEATING';
  status: AssetState;
}

export interface AIAgent {
  agent_id: UUID;
  name: string;
  purpose: string;
  sector: string;
  permissions: string[];
  data_sources: string[];
  tools: string[];
  risk_level: RiskLevel;
  human_owner: string;
  status: 'ACTIVE' | 'IDLE' | 'EXECUTING' | 'PAUSED';
  last_action_timestamp: string;
  active_confidence: number;
}

export interface AIRecommendation {
  recommendation_id: UUID;
  agent_id: UUID;
  agent_name: string;
  target_entity_id: UUID;
  target_entity_name: string;
  sector: string;
  title: string;
  root_cause: string;
  impact_analysis: {
    delay_impact_min?: number;
    cost_impact_jpy?: number;
    passenger_impact?: number;
    power_mw_saved?: number;
    risk_reduction_pct?: number;
  };
  recommendation_action: string;
  risk_level: RiskLevel;
  approval_state: AIApprovalState;
  confidence: number; // 0 - 1
  created_at: string;
  approver_role?: string;
  approver_name?: string;
  execution_outcome?: string;
}

export interface WorkOrder {
  id: UUID;
  code: string;
  asset_id: UUID;
  asset_name: string;
  site_name: string;
  title: string;
  type: 'INSPECTION' | 'MAINTENANCE' | 'REPAIR' | 'REPLACEMENT' | 'UPGRADE';
  priority: 'EMERGENCY' | 'HIGH' | 'MEDIUM' | 'LOW';
  status: WorkOrderStatus;
  assigned_to: string;
  created_at: string;
  estimated_cost_jpy: number;
  description: string;
}

export interface SecurityIncident {
  id: UUID;
  code: string;
  source_network: 'IT_NETWORK' | 'DMZ' | 'INDUSTRIAL_GATEWAY' | 'OT_NETWORK';
  target_asset_name: string;
  threat_type: 'ANOMALOUS_TRAFFIC' | 'UNAUTHORIZED_PLC_COMMAND' | 'PORT_SCAN' | 'CERT_EXPIRATION' | 'MALWARE_SIGNATURE';
  severity: 'CRITICAL' | 'HIGH' | 'MEDIUM' | 'LOW';
  status: 'OPEN' | 'CONTAINED' | 'MITIGATED' | 'RESOLVED';
  detected_at: string;
  action_taken: string;
}

export interface FinancialMetric {
  asset_id: UUID;
  asset_name: string;
  purchase_cost: number;
  maintenance_cost_ytd: number;
  energy_cost_ytd: number;
  downtime_cost_ytd: number;
  revenue_generated_ytd: number;
  tco: number; // Total Cost of Ownership
  roi_pct: number;
  roic_pct: number;
  useful_life_years: number;
  depreciation_ytd: number;
  currency: string;
}

export interface WhatIfScenarioInput {
  scenario_name: string;
  type: 'RAIL_LINE_CLOSURE' | 'POWER_DEMAND_SPIKE' | 'FACTORY_OUTAGE' | 'DATA_CENTER_GPU_SPIKE' | 'TRANSFORMER_FAILURE';
  parameters: {
    duration_hours?: number;
    demand_increase_pct?: number;
    line_affected?: string;
    factory_affected?: string;
  };
}

export interface WhatIfScenarioResult {
  scenario_name: string;
  simulated_at: string;
  estimated_financial_loss_jpy: number;
  capacity_drop_pct: number;
  delay_increase_min: number;
  carbon_footprint_ton: number;
  risk_score: number; // 0-100
  recommended_mitigations: string[];
}

export interface AuditRecord {
  id: UUID;
  timestamp: string;
  who: string;
  role: string;
  what: string;
  where: string;
  why: string;
  before_state?: string;
  after_state?: string;
  approval_status: string;
  result: string;
  model_id?: string;
  model_version?: string;
}
