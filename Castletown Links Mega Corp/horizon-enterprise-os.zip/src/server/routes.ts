import { Express, Request, Response } from 'express';
import { db } from './synthetic-data';
import { aiEngine } from './ai-engine';
import { AuditRecord, WorkOrder } from './types';

export function setupApiRoutes(app: Express) {
  // JSON Body Parser middleware
  app.use(expressJsonMiddleware);

  // 1. Organizations
  app.get('/api/organizations', (req: Request, res: Response) => {
    res.json({ status: 'SUCCESS', count: db.organizations.length, data: db.organizations });
  });

  // 2. Sites
  app.get('/api/sites', (req: Request, res: Response) => {
    res.json({ status: 'SUCCESS', count: db.sites.length, data: db.sites });
  });

  // 3. Assets & Graph
  app.get('/api/assets', (req: Request, res: Response) => {
    const { site_id, sector, state } = req.query;
    let filtered = [...db.assets];
    if (site_id) filtered = filtered.filter(a => a.site_id === site_id);
    if (sector) filtered = filtered.filter(a => a.sector === sector);
    if (state) filtered = filtered.filter(a => a.state === state);
    res.json({ status: 'SUCCESS', count: filtered.length, data: filtered });
  });

  app.get('/api/assets/graph', (req: Request, res: Response) => {
    res.json({
      status: 'SUCCESS',
      nodes: db.assets.map(a => ({ id: a.id, name: a.name, type: a.type, state: a.state })),
      edges: db.assetRelations
    });
  });

  app.get('/api/assets/:id', (req: Request, res: Response) => {
    const asset = db.assets.find(a => a.id === req.params['id']);
    if (!asset) {
      res.status(404).json({ status: 'ERROR', message: 'Asset not found' });
      return;
    }
    const relations = db.assetRelations.filter(r => r.source_asset_id === asset.id || r.target_asset_id === asset.id);
    res.json({ status: 'SUCCESS', asset, relations });
  });

  // 4. Telemetry Stream Simulation
  app.get('/api/telemetry', (req: Request, res: Response) => {
    const asset_id = req.query['asset_id'] as string;
    const now = new Date().toISOString();
    
    // Generate live real-time telemetry points
    const telemetryPoints = db.assets.map(a => {
      const isTarget = asset_id ? a.id === asset_id : true;
      if (!isTarget) return null;

      const baseVib = a.type === 'ROBOT' ? 7.2 : 2.1;
      const baseTemp = a.type === 'TRANSFORMER' ? 88 : 45;
      const baseSpeed = a.type === 'TRAIN' ? 92 : 0;

      return {
        telemetry_id: `tel-${Date.now()}-${a.id}`,
        asset_id: a.id,
        asset_name: a.name,
        timestamp: now,
        vibration: parseFloat((baseVib + (Math.random() * 0.6 - 0.3)).toFixed(2)),
        temperature: parseFloat((baseTemp + (Math.random() * 1.2 - 0.6)).toFixed(1)),
        voltage: parseFloat((500 + (Math.random() * 4 - 2)).toFixed(1)),
        current: parseFloat((820 + (Math.random() * 10 - 5)).toFixed(1)),
        speed: parseFloat((baseSpeed + (Math.random() * 2 - 1)).toFixed(1)),
        power: parseFloat((42 + (Math.random() * 2 - 1)).toFixed(1)),
        status: a.state,
        anomaly_detected: a.state === 'WARNING' || a.state === 'CRITICAL' || a.state === 'DEGRADED',
        anomaly_confidence: a.state === 'NORMAL' ? 0.02 : 0.88
      };
    }).filter(Boolean);

    res.json({ status: 'SUCCESS', timestamp: now, data: telemetryPoints });
  });

  // 5. Industrial Events
  app.get('/api/events', (req: Request, res: Response) => {
    res.json({ status: 'SUCCESS', count: db.recentEvents.length, data: db.recentEvents });
  });

  // 6. Digital Twins Engine
  app.get('/api/digital-twins', (req: Request, res: Response) => {
    res.json({
      status: 'SUCCESS',
      twins: {
        rail_twin: { status: 'DEGRADED', active_trains: db.trains.length, total_delays_min: db.trains.reduce((acc, t) => acc + t.delay_minutes, 0) },
        energy_twin: { status: 'WARNING', grid_frequency_hz: 50.04, total_load_mw: db.substations.reduce((acc, s) => acc + s.current_load_mw, 0) },
        factory_twin: { status: 'DEGRADED', plant_oee_pct: 81.7, active_machines: db.factoryMachines.length },
        datacenter_twin: { status: 'OPTIMAL', avg_pue: 1.15, gpu_utilization_pct: 94.5 }
      }
    });
  });

  // 7. Railway OS
  app.get('/api/rail/network', (req: Request, res: Response) => {
    res.json({
      status: 'SUCCESS',
      lines: [
        { id: 'line-chuo', name: '中央本線 (Chuo Main Line)', stations_count: 32, active_trains: 18, delay_status: 'DELAYED (+12m)' },
        { id: 'line-yamanote', name: '山手線 (Yamanote Line)', stations_count: 30, active_trains: 34, delay_status: 'NORMAL' },
        { id: 'line-tohoku-shinkansen', name: '東北新幹線 (Tohoku Shinkansen)', stations_count: 23, active_trains: 12, delay_status: 'NORMAL' }
      ]
    });
  });

  app.get('/api/rail/trains', (req: Request, res: Response) => {
    res.json({ status: 'SUCCESS', count: db.trains.length, data: db.trains });
  });

  app.get('/api/rail/stations', (req: Request, res: Response) => {
    res.json({
      status: 'SUCCESS',
      data: [
        { id: 'stn-shinjuku', name: '新宿駅 (Shinjuku)', platforms: 16, congestion_pct: 92, status: 'NORMAL' },
        { id: 'stn-tachikawa', name: '立川駅 (Tachikawa)', platforms: 8, congestion_pct: 78, status: 'HOLDING_PATTERN' },
        { id: 'stn-shinagawa', name: '品川駅 (Shinagawa)', platforms: 14, congestion_pct: 84, status: 'NORMAL' }
      ]
    });
  });

  // 8. Energy OS & Grid
  app.get('/api/energy/grid', (req: Request, res: Response) => {
    res.json({ status: 'SUCCESS', count: db.substations.length, data: db.substations });
  });

  app.get('/api/energy/metrics', (req: Request, res: Response) => {
    res.json({
      status: 'SUCCESS',
      metrics: {
        total_generation_mw: 850,
        total_demand_mw: 730,
        reserve_margin_pct: 14.1,
        frequency_hz: 50.04,
        co2_emissions_ton_hr: 124.5,
        renewable_ratio_pct: 38.2
      }
    });
  });

  // 9. Smart Factory OS & MOM
  app.get('/api/factories', (req: Request, res: Response) => {
    res.json({
      status: 'SUCCESS',
      factories: [
        { id: 'fact-yokohama', name: '横浜スマートプラント', OEE: 81.7, status: 'DEGRADED', active_lines: 4 }
      ]
    });
  });

  app.get('/api/factories/machines', (req: Request, res: Response) => {
    res.json({ status: 'SUCCESS', count: db.factoryMachines.length, data: db.factoryMachines });
  });

  app.get('/api/production', (req: Request, res: Response) => {
    res.json({
      status: 'SUCCESS',
      mom_flow: [
        { step: '1. PLAN', code: 'MOM-PLN-991', target_units: 1200, actual_units: 1180, yield_pct: 98.3, status: 'NORMAL' },
        { step: '2. MATERIAL', code: 'MOM-MAT-402', raw_material_stock: 'SUFFICIENT', status: 'NORMAL' },
        { step: '3. PRODUCTION', code: 'MOM-PRD-102', line_speed_pct: 92, bottleneck: 'Robot RC-04 vibration', status: 'WARNING' },
        { step: '4. QUALITY', code: 'MOM-QLT-801', defect_rate_ppm: 140, pass_rate_pct: 99.86, status: 'NORMAL' },
        { step: '5. PACKAGING', code: 'MOM-PKG-303', throughput_units_hr: 450, status: 'NORMAL' },
        { step: '6. SHIPMENT', code: 'MOM-SHP-201', pending_orders: 14, status: 'NORMAL' }
      ]
    });
  });

  // 10. Work Management
  app.get('/api/maintenance/work-orders', (req: Request, res: Response) => {
    res.json({ status: 'SUCCESS', count: db.workOrders.length, data: db.workOrders });
  });

  app.post('/api/maintenance/work-orders', (req: Request, res: Response) => {
    const body = req.body || {};
    const newWO: WorkOrder = {
      id: `wo-${Date.now()}`,
      code: `WO-${Math.floor(1000 + Math.random() * 9000)}`,
      asset_id: body.asset_id || 'asset-robot-rc04',
      asset_name: body.asset_name || '手動発行設備 (Manual Target Asset)',
      site_name: body.site_name || '現場拠点 (Local Site)',
      title: body.title || '手動保守指示 (Manual Work Order)',
      type: body.type || 'MAINTENANCE',
      priority: body.priority || 'HIGH',
      status: 'ASSIGNED',
      assigned_to: body.assigned_to || '保全チーム (Maintenance Team)',
      created_at: new Date().toISOString(),
      estimated_cost_jpy: body.estimated_cost_jpy || 500000,
      description: body.description || 'オペレータ手動作成ワークオーダー'
    };
    db.workOrders.unshift(newWO);

    // Audit log
    const audit: AuditRecord = {
      id: `audit-wo-${Date.now()}`,
      timestamp: new Date().toISOString(),
      who: 'USER_OPERATOR',
      role: 'MAINTENANCE_MANAGER',
      what: 'WORK_ORDER_CREATED',
      where: newWO.site_name,
      why: 'Manual work order issued from HORIZON UI',
      approval_status: 'APPROVED',
      result: `Work order ${newWO.code} created and assigned to ${newWO.assigned_to}`
    };
    db.auditRecords.unshift(audit);

    res.json({ status: 'SUCCESS', data: newWO });
  });

  // 11. Supply Chain & Procurement
  app.get('/api/supply-chain', (req: Request, res: Response) => {
    res.json({
      status: 'SUCCESS',
      inventory_risk_level: 'LOW',
      suppliers: [
        { id: 'sup-01', name: '日本ベアリングテクノロジー Inc.', component: '精密ロボット用軸受 (Bearings)', score: 96, risk: 'LOW' },
        { id: 'sup-02', name: '関東北部電線・導体工業', component: '500kV超高圧ケーブル (XHV Cable)', score: 92, risk: 'LOW' },
        { id: 'sup-03', name: 'グローバルパワーセミコン社', component: 'SiCパワーモジュール', score: 88, risk: 'MEDIUM' }
      ]
    });
  });

  app.get('/api/procurement', (req: Request, res: Response) => {
    res.json({
      status: 'SUCCESS',
      rfqs: [
        { id: 'rfq-2026-901', item: '交換用ベアリングユニット BRG-9921', supplier: '日本ベアリングテクノロジー Inc.', amount_jpy: 380000, status: 'APPROVED' }
      ]
    });
  });

  // 12. Finance & Asset Economics
  app.get('/api/finance/gl', (req: Request, res: Response) => {
    res.json({
      status: 'SUCCESS',
      summary: {
        total_capex_jpy: 12500000000,
        total_opex_jpy: 3420000000,
        currency: 'JPY',
        fiscal_year: 'FY2026 Q3'
      }
    });
  });

  app.get('/api/finance/asset-economics', (req: Request, res: Response) => {
    res.json({ status: 'SUCCESS', count: db.financialMetrics.length, data: db.financialMetrics });
  });

  // 13. AI Agents & Governance
  app.get('/api/ai/agents', (req: Request, res: Response) => {
    res.json({ status: 'SUCCESS', count: db.aiAgents.length, data: db.aiAgents });
  });

  app.get('/api/ai/recommendations', (req: Request, res: Response) => {
    res.json({ status: 'SUCCESS', count: db.aiRecommendations.length, data: db.aiRecommendations });
  });

  app.post('/api/ai/approve', (req: Request, res: Response) => {
    const { recommendation_id, approver_name, approver_role, action } = req.body || {};
    const rec = db.aiRecommendations.find(r => r.recommendation_id === recommendation_id);

    if (!rec) {
      res.status(404).json({ status: 'ERROR', message: 'Recommendation not found' });
      return;
    }

    rec.approval_state = action === 'REJECT' ? 'REJECTED' : 'APPROVED';
    rec.approver_name = approver_name || '指令長 (Dispatch Commander)';
    rec.approver_role = approver_role || 'HUMAN_EXECUTIVE';
    rec.execution_outcome = action === 'REJECT' ? '人間判断により指令を拒否・代替手動制御へ移行' : 'Command Gatewayを介してOT制御信号送信・実行を完了';

    // Automatically create a Work Order if recommendation is Maintenance
    if (action !== 'REJECT' && rec.sector === 'MANUFACTURING') {
      const wo: WorkOrder = {
        id: `wo-auto-${Date.now()}`,
        code: `WO-${Math.floor(1000 + Math.random() * 9000)}`,
        asset_id: rec.target_entity_id,
        asset_name: rec.target_entity_name,
        site_name: '横浜スマートプラント',
        title: rec.title,
        type: 'REPAIR',
        priority: 'EMERGENCY',
        status: 'ASSIGNED',
        assigned_to: '自動割り当て: 横浜プラント緊急保全チーム',
        created_at: new Date().toISOString(),
        estimated_cost_jpy: 450000,
        description: `Physical AI Recommendation ${rec.recommendation_id} approved by ${rec.approver_name}`
      };
      db.workOrders.unshift(wo);
    }

    // Add Audit Record
    const audit: AuditRecord = {
      id: `audit-appr-${Date.now()}`,
      timestamp: new Date().toISOString(),
      who: rec.approver_name || 'System Operator',
      role: rec.approver_role || 'COMMANDER',
      what: rec.approval_state === 'APPROVED' ? 'AI_RECOMMENDATION_APPROVED' : 'AI_RECOMMENDATION_REJECTED',
      where: `${rec.sector} Domain / ${rec.target_entity_name}`,
      why: rec.title,
      approval_status: rec.approval_state,
      result: rec.execution_outcome || 'Executed',
      model_id: 'gemini-3.8-flash'
    };
    db.auditRecords.unshift(audit);

    res.json({ status: 'SUCCESS', data: rec, audit });
  });

  app.get('/api/ai/executive-summary', async (req: Request, res: Response) => {
    try {
      const summary = await aiEngine.analyzeInfrastructureState();
      res.json({ status: 'SUCCESS', data: summary });
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      res.status(500).json({ status: 'ERROR', message: msg });
    }
  });

  // 14. Simulation & What-If Engine
  app.post('/api/simulations/run', (req: Request, res: Response) => {
    const input = req.body || {};
    const result = aiEngine.runWhatIfSimulation(input);
    res.json({ status: 'SUCCESS', data: result });
  });

  // 15. Cybersecurity OS
  app.get('/api/security/soc', (req: Request, res: Response) => {
    res.json({
      status: 'SUCCESS',
      soc_overview: {
        zero_trust_status: 'ACTIVE_ENFORCED',
        it_ot_segmentation: 'ISOLATED_DMZ_GATEWAY',
        active_threat_level: 'ELEVATED',
        unauthorized_plc_attempts_blocked: 142
      },
      incidents: db.securityIncidents
    });
  });

  // 16. Enterprise Audit Log
  app.get('/api/audit', (req: Request, res: Response) => {
    res.json({ status: 'SUCCESS', count: db.auditRecords.length, data: db.auditRecords });
  });

  // 17. Demo Scenario Trigger
  app.post('/api/demo-scenario', (req: Request, res: Response) => {
    const result = aiEngine.triggerDemoScenario();
    res.json({ status: 'SUCCESS', data: result });
  });
}

function expressJsonMiddleware(req: Request, res: Response, next: () => void) {
  if (req.headers['content-type'] === 'application/json') {
    let data = '';
    req.on('data', chunk => { data += chunk; });
    req.on('end', () => {
      try {
        if (data) req.body = JSON.parse(data);
      } catch {
        req.body = {};
      }
      next();
    });
  } else {
    next();
  }
}
