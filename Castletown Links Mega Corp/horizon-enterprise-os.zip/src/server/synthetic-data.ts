import {
  Organization,
  Site,
  Asset,
  AssetRelation,
  TrainUnit,
  PowerSubstation,
  FactoryMachine,
  DataCenterRack,
  AIAgent,
  AIRecommendation,
  WorkOrder,
  SecurityIncident,
  FinancialMetric,
  AuditRecord,
  IndustrialEvent
} from './types';

export class SyntheticDataRepository {
  public organizations: Organization[] = [];
  public sites: Site[] = [];
  public assets: Asset[] = [];
  public assetRelations: AssetRelation[] = [];
  public trains: TrainUnit[] = [];
  public substations: PowerSubstation[] = [];
  public factoryMachines: FactoryMachine[] = [];
  public dcRacks: DataCenterRack[] = [];
  public aiAgents: AIAgent[] = [];
  public aiRecommendations: AIRecommendation[] = [];
  public workOrders: WorkOrder[] = [];
  public securityIncidents: SecurityIncident[] = [];
  public financialMetrics: FinancialMetric[] = [];
  public auditRecords: AuditRecord[] = [];
  public recentEvents: IndustrialEvent[] = [];

  constructor() {
    this.seedAll();
  }

  private seedAll() {
    const now = new Date().toISOString();

    // Organizations
    this.organizations = [
      {
        id: 'org-001-hq',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'NORMAL',
        owner: 'ExecBoard',
        source: 'HORIZON-ERP',
        classification: 'CONFIDENTIAL',
        name: 'HORIZON Global Infrastructure Group HQ',
        code: 'HGIG-JP',
        sector: 'DIGITAL_SYSTEMS',
        region: 'Global HQ',
        country: 'Japan',
        legal_entity: 'HORIZON Corporation Inc.'
      },
      {
        id: 'org-002-rail',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'NORMAL',
        owner: 'RailBU',
        source: 'HORIZON-ERP',
        classification: 'RESTRICTED',
        name: 'HORIZON Rail Mobility Systems BU',
        code: 'HRMS-BU',
        sector: 'RAIL',
        region: 'East Japan',
        country: 'Japan',
        legal_entity: 'HORIZON Rail Mobility Systems Ltd.'
      },
      {
        id: 'org-003-energy',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'NORMAL',
        owner: 'EnergyBU',
        source: 'HORIZON-ERP',
        classification: 'RESTRICTED',
        name: 'HORIZON Smart Energy & Power Grid BU',
        code: 'HSEG-BU',
        sector: 'ENERGY',
        region: 'Kanto Grid',
        country: 'Japan',
        legal_entity: 'HORIZON Power Solutions Inc.'
      },
      {
        id: 'org-004-mfg',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'NORMAL',
        owner: 'IndustrialBU',
        source: 'HORIZON-ERP',
        classification: 'RESTRICTED',
        name: 'HORIZON Industrial Smart Manufacturing BU',
        code: 'HISM-BU',
        sector: 'MANUFACTURING',
        region: 'Yokohama Hub',
        country: 'Japan',
        legal_entity: 'HORIZON Manufacturing Technologies'
      }
    ];

    // Sites
    this.sites = [
      {
        id: 'site-rail-tokyo',
        organization_id: 'org-002-rail',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'NORMAL',
        owner: 'TokyoRailManager',
        source: 'OT-GIS',
        classification: 'PUBLIC_INFRA',
        name: '東京中央鉄道運行管理センター / Tokyo Rail Ops Center',
        type: 'COMMAND_CENTER',
        latitude: 35.6812,
        longitude: 139.7671,
        country: 'Japan',
        address: '東京都千代田区丸の内1-1-1'
      },
      {
        id: 'site-grid-ibaraki',
        organization_id: 'org-003-energy',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'WARNING',
        owner: 'IbarakiGridChief',
        source: 'OT-SCADA',
        classification: 'CRITICAL_INFRA',
        name: '茨城基幹変電所・蓄電パーク / Ibaraki Main Substation & Battery Park',
        type: 'SUBSTATION',
        latitude: 36.3418,
        longitude: 140.4468,
        country: 'Japan',
        address: '茨城県水戸市100'
      },
      {
        id: 'site-mfg-yokohama',
        organization_id: 'org-004-mfg',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'DEGRADED',
        owner: 'YokohamaPlantDirector',
        source: 'OT-MES',
        classification: 'INTERNAL',
        name: '横浜スマートマニュファクチャリングプラント / Yokohama Smart Factory',
        type: 'FACTORY',
        latitude: 35.4437,
        longitude: 139.638,
        country: 'Japan',
        address: '神奈川県横浜市鶴見区2-5'
      },
      {
        id: 'site-dc-chiba',
        organization_id: 'org-001-hq',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'NORMAL',
        owner: 'DCOperations',
        source: 'DCIM',
        classification: 'CONFIDENTIAL',
        name: '千葉AIグリーンデータセンター / Chiba Green AI Data Center',
        type: 'DATA_CENTER',
        latitude: 35.6074,
        longitude: 140.1065,
        country: 'Japan',
        address: '千葉県千葉市美浜区3-1'
      }
    ];

    // Assets
    this.assets = [
      {
        id: 'asset-train-104',
        site_id: 'site-rail-tokyo',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'DEGRADED',
        owner: 'RailOps',
        source: 'OT-TCMS',
        classification: 'CRITICAL_ASSET',
        name: '特急ホライゾン 104号電車 / Express Train 104',
        code: 'TRAIN-104',
        type: 'TRAIN',
        sector: 'RAIL',
        criticality: 'CRITICAL',
        health_score: 72,
        state: 'DEGRADED',
        location_name: '中央本線 新宿-立川区間 (Shinjuku-Tachikawa)',
        serial_number: 'E235-H-104',
        purchase_cost: 1850000000,
        purchase_currency: 'JPY',
        installed_date: '2022-03-15',
        useful_life_years: 25,
        remaining_useful_life_days: 7420,
        telemetry_metrics: { speed_kmh: 94, vibration_mm_s: 4.8, motor_temp_c: 82 }
      },
      {
        id: 'asset-substation-t801',
        site_id: 'site-grid-ibaraki',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'WARNING',
        owner: 'GridOps',
        source: 'OT-SCADA',
        classification: 'CRITICAL_ASSET',
        name: '500kV 主変圧器 T-801 / Main Transformer T-801',
        code: 'TRF-801',
        type: 'TRANSFORMER',
        sector: 'ENERGY',
        criticality: 'CRITICAL',
        health_score: 68,
        state: 'WARNING',
        location_name: '茨城基幹変電所 Bay-A',
        serial_number: 'XFMR-500K-801',
        purchase_cost: 3200000000,
        purchase_currency: 'JPY',
        installed_date: '2018-11-20',
        useful_life_years: 30,
        remaining_useful_life_days: 8100,
        telemetry_metrics: { voltage_kv: 502, load_mw: 420, temp_c: 88, oil_gas_ppm: 145 }
      },
      {
        id: 'asset-robot-rc04',
        site_id: 'site-mfg-yokohama',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'WARNING',
        owner: 'FactoryOps',
        source: 'OT-PLC',
        classification: 'HIGH_PRIORITY',
        name: '精密溶接ロボットセル RC-04 / Robotic Welding Cell RC-04',
        code: 'RBT-RC04',
        type: 'ROBOT',
        sector: 'MANUFACTURING',
        criticality: 'HIGH',
        health_score: 61,
        state: 'WARNING',
        location_name: '第2組立ライン (Line 2)',
        serial_number: 'HRB-6X-9004',
        purchase_cost: 85000000,
        purchase_currency: 'JPY',
        installed_date: '2021-06-10',
        useful_life_years: 12,
        remaining_useful_life_days: 2540,
        telemetry_metrics: { vibration_mm_s: 7.2, motor_temp_c: 78, cycle_time_s: 14.2 }
      },
      {
        id: 'asset-dc-gpu-rack01',
        site_id: 'site-dc-chiba',
        created_at: '2026-01-01T00:00:00Z',
        updated_at: now,
        version: 1,
        status: 'NORMAL',
        owner: 'DCOps',
        source: 'DCIM',
        classification: 'HIGH_PRIORITY',
        name: 'High-Density GPU Compute Rack R-08',
        code: 'DC-RACK-R08',
        type: 'SERVER_RACK',
        sector: 'DATA_CENTERS',
        criticality: 'HIGH',
        health_score: 95,
        state: 'NORMAL',
        location_name: 'Zone-A Rack-R08',
        serial_number: 'GPU-H100-NV8',
        purchase_cost: 350000000,
        purchase_currency: 'JPY',
        installed_date: '2024-01-15',
        useful_life_years: 5,
        remaining_useful_life_days: 1200,
        telemetry_metrics: { power_kw: 42, gpu_utilization_pct: 88, temp_inlet_c: 24.5 }
      }
    ];

    // Asset Relations (Graph Abstraction)
    this.assetRelations = [
      { source_asset_id: 'site-rail-tokyo', target_asset_id: 'asset-train-104', relationship: 'LOCATED_AT' },
      { source_asset_id: 'asset-substation-t801', target_asset_id: 'site-rail-tokyo', relationship: 'CONNECTED_TO' },
      { source_asset_id: 'asset-substation-t801', target_asset_id: 'asset-train-104', relationship: 'CONSUMES' },
      { source_asset_id: 'site-grid-ibaraki', target_asset_id: 'asset-substation-t801', relationship: 'LOCATED_AT' },
      { source_asset_id: 'site-mfg-yokohama', target_asset_id: 'asset-robot-rc04', relationship: 'LOCATED_AT' },
      { source_asset_id: 'asset-substation-t801', target_asset_id: 'site-mfg-yokohama', relationship: 'CONNECTED_TO' }
    ];

    // Trains
    this.trains = [
      {
        id: 'asset-train-104',
        code: 'TRAIN-104',
        line_name: '中央本線 / Chuo Line',
        current_station: '新宿 (Shinjuku)',
        next_station: '立川 (Tachikawa)',
        position_km: 32.4,
        speed_kmh: 92,
        delay_minutes: 12,
        occupancy_pct: 124,
        signal_state: 'YELLOW',
        energy_kwh: 1420,
        status: 'DEGRADED'
      },
      {
        id: 'train-202',
        code: 'TRAIN-202',
        line_name: '山手線 / Yamanote Outer Loop',
        current_station: '品川 (Shinagawa)',
        next_station: '田町 (Tamachi)',
        position_km: 12.1,
        speed_kmh: 65,
        delay_minutes: 0,
        occupancy_pct: 85,
        signal_state: 'GREEN',
        energy_kwh: 680,
        status: 'NORMAL'
      },
      {
        id: 'train-305',
        code: 'TRAIN-305',
        line_name: '東北新幹線 / Tohoku Shinkansen',
        current_station: '大宮 (Omiya)',
        next_station: '宇都宮 (Utsunomiya)',
        position_km: 64.8,
        speed_kmh: 275,
        delay_minutes: 2,
        occupancy_pct: 92,
        signal_state: 'GREEN',
        energy_kwh: 4850,
        status: 'NORMAL'
      }
    ];

    // Substations / Grid
    this.substations = [
      {
        id: 'asset-substation-t801',
        name: '茨城基幹変電所 (Ibaraki Main)',
        grid_zone: '首都圏東部グリッド (East Kanto Grid)',
        voltage_kv: 502,
        current_load_mw: 420,
        capacity_mw: 450,
        frequency_hz: 50.04,
        reserve_capacity_pct: 6.7,
        transformer_temp_c: 88,
        renewable_contribution_pct: 34,
        status: 'WARNING'
      },
      {
        id: 'sub-tokyo-west',
        name: '西東京開閉所 (West Tokyo Switching Station)',
        grid_zone: '首都圏西部グリッド (West Kanto Grid)',
        voltage_kv: 275,
        current_load_mw: 310,
        capacity_mw: 500,
        frequency_hz: 50.01,
        reserve_capacity_pct: 38.0,
        transformer_temp_c: 62,
        renewable_contribution_pct: 42,
        status: 'NORMAL'
      }
    ];

    // Factory Machines
    this.factoryMachines = [
      {
        id: 'asset-robot-rc04',
        factory_name: '横浜スマート工場 (Yokohama Plant)',
        line_name: '第2フレーム溶接ライン (Line 2)',
        machine_code: 'RC-04',
        type: 'Robotic Weld Cell',
        vibration_mm_s: 7.2,
        temperature_c: 78,
        cycle_time_s: 14.2,
        oee_pct: 71.4,
        plc_status: 'RUNNING',
        failure_probability: 0.78,
        estimated_failure_window_hours: 36,
        status: 'WARNING'
      },
      {
        id: 'mch-press-01',
        factory_name: '横浜スマート工場 (Yokohama Plant)',
        line_name: '第1大型プレスライン (Line 1)',
        machine_code: 'PRS-101',
        type: '3000 Ton Servo Press',
        vibration_mm_s: 2.1,
        temperature_c: 48,
        cycle_time_s: 8.5,
        oee_pct: 92.1,
        plc_status: 'RUNNING',
        failure_probability: 0.04,
        estimated_failure_window_hours: 840,
        status: 'NORMAL'
      }
    ];

    // Data Center Racks
    this.dcRacks = [
      {
        id: 'asset-dc-gpu-rack01',
        dc_name: '千葉AIグリーンデータセンター (Chiba DC)',
        rack_code: 'GPU-R8',
        power_kw: 42,
        gpu_utilization_pct: 91,
        cpu_utilization_pct: 78,
        temp_inlet_c: 24.5,
        pue_efficiency: 1.14,
        cooling_status: 'OPTIMAL',
        status: 'NORMAL'
      },
      {
        id: 'dc-rack-r9',
        dc_name: '千葉AIグリーンデータセンター (Chiba DC)',
        rack_code: 'GPU-R9',
        power_kw: 48,
        gpu_utilization_pct: 98,
        cpu_utilization_pct: 88,
        temp_inlet_c: 28.2,
        pue_efficiency: 1.21,
        cooling_status: 'HIGH_TEMP',
        status: 'DEGRADED'
      }
    ];

    // AI Agents
    this.aiAgents = [
      {
        agent_id: 'agent-maint-01',
        name: 'MaintenanceAgent (予知保全エージェント)',
        purpose: 'Vibration & thermal telemetry analysis to predict Remaining Useful Life (RUL) and schedule preventive maintenance.',
        sector: 'CROSS_SECTOR',
        permissions: ['READ_TELEMETRY', 'PROPOSE_WORK_ORDER', 'TRIGGER_ALARM'],
        data_sources: ['Sensors', 'OT-PLC', 'Vibration-FFT', 'WorkOrderHistory'],
        tools: ['FFT_Analyzer', 'RUL_Predictor', 'WorkOrderGenerator'],
        risk_level: 'MEDIUM',
        human_owner: '設備保全総括 (Chief Maintenance Officer)',
        status: 'ACTIVE',
        last_action_timestamp: now,
        active_confidence: 0.92
      },
      {
        agent_id: 'agent-rail-02',
        name: 'RailOperationsAgent (鉄道運行最適化エージェント)',
        purpose: 'Real-time train tracking, delay mitigation, signal routing & dynamic platform holding.',
        sector: 'RAIL',
        permissions: ['READ_TCMS', 'PROPOSE_SCHEDULE_CHANGE', 'PROPOSE_PLATFORM_SWAP'],
        data_sources: ['TCMS', 'SignalSCADA', 'PassengerDensitySensors'],
        tools: ['TimetableSimulator', 'CongestionModeler', 'RoutingOptimizer'],
        risk_level: 'HIGH',
        human_owner: '鉄道運行指令長 (Rail Operations Dispatch Commander)',
        status: 'ACTIVE',
        last_action_timestamp: now,
        active_confidence: 0.88
      },
      {
        agent_id: 'agent-energy-03',
        name: 'EnergyAgent (グリッド需給調停エージェント)',
        purpose: 'Grid frequency monitoring, renewable fluctuation compensation & peak load battery dispatch.',
        sector: 'ENERGY',
        permissions: ['READ_SCADA', 'PROPOSE_BATTERY_DISPATCH', 'ALERT_OVERLOAD'],
        data_sources: ['GridSCADA', 'WeatherForecast', 'SpotMarketPrices'],
        tools: ['OptimalPowerFlowEngine', 'BatteryDispatchSimulator'],
        risk_level: 'HIGH',
        human_owner: '系統運用指令員 (Power Grid System Controller)',
        status: 'ACTIVE',
        last_action_timestamp: now,
        active_confidence: 0.95
      },
      {
        agent_id: 'agent-factory-04',
        name: 'FactoryAgent (スマート製造調停エージェント)',
        purpose: 'OEE optimization, cycle time balancing, PLC anomaly tracking & MOM flow management.',
        sector: 'MANUFACTURING',
        permissions: ['READ_MES', 'PROPOSE_LINE_SPEED_ADJUSTMENT', 'CREATE_MOM_ALERT'],
        data_sources: ['MES', 'PLC', 'QualityVisionSensors'],
        tools: ['OEECalculator', 'YieldOptimizer'],
        risk_level: 'MEDIUM',
        human_owner: '工場生産統括長 (Plant Operations Director)',
        status: 'ACTIVE',
        last_action_timestamp: now,
        active_confidence: 0.89
      },
      {
        agent_id: 'agent-cyber-05',
        name: 'CyberSecurityAgent (IT/OTゼロトラスト監視エージェント)',
        purpose: 'Anomalous traffic detection in OT gateways, unauthorized PLC modification blocking.',
        sector: 'SECURITY',
        permissions: ['READ_FIREWALL_LOGS', 'ISOLATE_GATEWAY_NODE', 'TRIGGER_SOC_ALERT'],
        data_sources: ['OT-Gateway-Logs', 'NetFlow', 'CertificateStore'],
        tools: ['ZeroTrustPolicyEngine', 'AnomalyDetector'],
        risk_level: 'HIGH',
        human_owner: 'CISO / OTセキュリティ管理者 (Chief Information Security Officer)',
        status: 'ACTIVE',
        last_action_timestamp: now,
        active_confidence: 0.96
      },
      {
        agent_id: 'agent-exec-06',
        name: 'ExecutiveAgent (全社クロスドメイン相関解析エージェント)',
        purpose: 'Cross-sector root cause correlation (e.g. Energy spike + Rail delay + Factory slowdown) and CEO decision synthesis.',
        sector: 'EXECUTIVE',
        permissions: ['READ_ALL_METRICS', 'GENERATE_EXECUTIVE_REPORT'],
        data_sources: ['All-Sector-Digital-Twins', 'Finance-GL', 'RiskMatrix'],
        tools: ['CrossDomainCorrelationEngine', 'GeminiPhysicalAISynthesizer'],
        risk_level: 'LOW',
        human_owner: '最高経営責任者 (CEO Office)',
        status: 'ACTIVE',
        last_action_timestamp: now,
        active_confidence: 0.94
      }
    ];

    // Initial AI Recommendations
    this.aiRecommendations = [
      {
        recommendation_id: 'rec-rail-101',
        agent_id: 'agent-rail-02',
        agent_name: 'RailOperationsAgent',
        target_entity_id: 'asset-train-104',
        target_entity_name: '特急ホライゾン 104号電車 (Express Train 104)',
        sector: 'RAIL',
        title: '中央線104号 遅延12分に伴う抑止・代替待避指令 / Train 104 Hold & Alternative Reroute',
        root_cause: '先行列車遅延及びモータ軸受振動値（4.8mm/s）上昇による減速走行',
        impact_analysis: {
          delay_impact_min: -8,
          cost_impact_jpy: 120000,
          passenger_impact: 850
        },
        recommendation_action: '1. 立川駅にて3分間抑止・後続特急を待避線へ誘導\n2. 新宿駅の降車ホームを3番線から5番線へ変更し混雑緩和\n3. 予備車両E235-H-108の出庫準備指示',
        risk_level: 'HIGH',
        approval_state: 'PENDING',
        confidence: 0.88,
        created_at: now
      },
      {
        recommendation_id: 'rec-energy-202',
        agent_id: 'agent-energy-03',
        agent_name: 'EnergyAgent',
        target_entity_id: 'asset-substation-t801',
        target_entity_name: '500kV 主変圧器 T-801 (Ibaraki Main Transformer)',
        sector: 'ENERGY',
        title: '茨城基幹変電所 T-801 過負荷防止用BESS 15MW即時放電 / 15MW BESS Discharge',
        root_cause: '産業用負荷急増（+8.2%）および太陽光出力急減による変圧器容量圧迫（88%上限接近）',
        impact_analysis: {
          power_mw_saved: 15,
          cost_impact_jpy: 350000,
          risk_reduction_pct: 42
        },
        recommendation_action: '茨城蓄電パークのBESS（20MWh）から15MWを120分間放電し、主変圧器T-801の負荷率を88%から74%へ引き下げ安定化。',
        risk_level: 'MEDIUM',
        approval_state: 'PENDING',
        confidence: 0.95,
        created_at: now
      },
      {
        recommendation_id: 'rec-factory-303',
        agent_id: 'agent-maint-01',
        agent_name: 'MaintenanceAgent',
        target_entity_id: 'asset-robot-rc04',
        target_entity_name: '溶接ロボットセル RC-04 (Welding Cell RC-04)',
        sector: 'MANUFACTURING',
        title: 'ロボットRC-04 ベアリング異常振動検出に伴う予知保全ワークオーダー発行 / Predictive Work Order',
        root_cause: '軸受振動実測値7.2mm/s（閾値5.0mm/s超過）。36時間以内の軸受焼き付き確率78%',
        impact_analysis: {
          cost_impact_jpy: 4500000, // saved downtime cost
          risk_reduction_pct: 85
        },
        recommendation_action: '本日22:00の計画停止時間帯にベアリングユニット(Part #BRG-9921)の予防交換ワークオーダーを緊急発行。',
        risk_level: 'MEDIUM',
        approval_state: 'PENDING',
        confidence: 0.91,
        created_at: now
      }
    ];

    // Initial Work Orders
    this.workOrders = [
      {
        id: 'wo-2026-001',
        code: 'WO-8801',
        asset_id: 'asset-robot-rc04',
        asset_name: '溶接ロボットセル RC-04',
        site_name: '横浜スマートプラント',
        title: '軸受ユニット予防交換および軸合わせ精密検査',
        type: 'REPAIR',
        priority: 'HIGH',
        status: 'ASSIGNED',
        assigned_to: '保全第1課 佐藤技術長',
        created_at: now,
        estimated_cost_jpy: 380000,
        description: 'Predictive Maintenance triggered by Physical AI vibration anomaly.'
      },
      {
        id: 'wo-2026-002',
        code: 'WO-8802',
        asset_id: 'asset-substation-t801',
        asset_name: '500kV 主変圧器 T-801',
        site_name: '茨城基幹変電所',
        title: '油中ガス分析および絶縁油循環冷却装置点検',
        type: 'INSPECTION',
        priority: 'MEDIUM',
        status: 'IN_PROGRESS',
        assigned_to: '電力設備課 鈴木エンジニア',
        created_at: '2026-09-10T09:00:00Z',
        estimated_cost_jpy: 1200000,
        description: 'Scheduled transformer DGA and cooling fan diagnostic.'
      }
    ];

    // Security Incidents
    this.securityIncidents = [
      {
        id: 'sec-inc-01',
        code: 'SEC-901',
        source_network: 'OT_NETWORK',
        target_asset_name: '横浜工場 Line-2 PLC-04 (IP: 192.168.10.45)',
        threat_type: 'UNAUTHORIZED_PLC_COMMAND',
        severity: 'HIGH',
        status: 'CONTAINED',
        detected_at: now,
        action_taken: 'Industrial Gateway DMZで接続セッション遮断。OT分離ポリシー自動適用。'
      },
      {
        id: 'sec-inc-02',
        code: 'SEC-902',
        source_network: 'IT_NETWORK',
        target_asset_name: '東京鉄道指令データサーバ',
        threat_type: 'ANOMALOUS_TRAFFIC',
        severity: 'MEDIUM',
        status: 'OPEN',
        detected_at: now,
        action_taken: 'Rate limiting applied on edge firewall. AI Cyber Agent monitoring.'
      }
    ];

    // Financial Metrics
    this.financialMetrics = [
      {
        asset_id: 'asset-train-104',
        asset_name: '特急ホライゾン 104号電車',
        purchase_cost: 1850000000,
        maintenance_cost_ytd: 24500000,
        energy_cost_ytd: 48200000,
        downtime_cost_ytd: 3200000,
        revenue_generated_ytd: 182000000,
        tco: 1925900000,
        roi_pct: 12.8,
        roic_pct: 11.2,
        useful_life_years: 25,
        depreciation_ytd: 74000000,
        currency: 'JPY'
      },
      {
        asset_id: 'asset-substation-t801',
        asset_name: '500kV 主変圧器 T-801',
        purchase_cost: 3200000000,
        maintenance_cost_ytd: 18000000,
        energy_cost_ytd: 12500000,
        downtime_cost_ytd: 0,
        revenue_generated_ytd: 410000000,
        tco: 3230500000,
        roi_pct: 14.5,
        roic_pct: 13.1,
        useful_life_years: 30,
        depreciation_ytd: 106600000,
        currency: 'JPY'
      }
    ];

    // Initial Audit Records
    this.auditRecords = [
      {
        id: 'audit-001',
        timestamp: now,
        who: 'SYSTEM (Physical AI Engine)',
        role: 'AI_AGENT',
        what: 'AI_RECOMMENDATION_CREATED',
        where: 'Rail Digital Twin / Train-104',
        why: 'Vibration spike & delay detected',
        approval_status: 'PENDING_HUMAN_APPROVAL',
        result: 'Recommendation rec-rail-101 created for Commander review',
        model_id: 'gemini-3.8-flash',
        model_version: '3.8.0-2026'
      }
    ];

    // Recent Industrial Events
    this.recentEvents = [
      {
        event_id: 'evt-1001',
        timestamp: now,
        source: 'OT-TCMS-SENSORS',
        entity_id: 'asset-train-104',
        entity_name: '特急ホライゾン 104号電車',
        event_type: 'TrainDelayed',
        severity: 'WARNING',
        payload: { delay_minutes: 12, speed: 92, cause: 'vibration_anomaly' },
        schema_version: '1.0'
      },
      {
        event_id: 'evt-1002',
        timestamp: now,
        source: 'OT-GRID-SCADA',
        entity_id: 'asset-substation-t801',
        entity_name: '500kV 主変圧器 T-801',
        event_type: 'EnergyThresholdExceeded',
        severity: 'WARNING',
        payload: { load_mw: 420, max_mw: 450, temp_c: 88 },
        schema_version: '1.0'
      },
      {
        event_id: 'evt-1003',
        timestamp: now,
        source: 'OT-PLC-SENSORS',
        entity_id: 'asset-robot-rc04',
        entity_name: '溶接ロボットセル RC-04',
        event_type: 'MachineFailurePredicted',
        severity: 'CRITICAL',
        payload: { vibration_mm_s: 7.2, failure_probability: 0.78, window_hours: 36 },
        schema_version: '1.0'
      }
    ];
  }
}

export const db = new SyntheticDataRepository();
