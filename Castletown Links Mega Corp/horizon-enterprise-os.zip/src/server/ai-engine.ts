import { GoogleGenAI } from '@google/genai';
import { db } from './synthetic-data';
import {
  AIRecommendation,
  WhatIfScenarioInput,
  WhatIfScenarioResult,
  AuditRecord,
  IndustrialEvent
} from './types';

export class PhysicalAIEngine {
  private getGenAI(): GoogleGenAI | null {
    const key = process.env['GEMINI_API_KEY'];
    if (!key || key === 'MY_GEMINI_API_KEY') {
      return null;
    }
    return new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });
  }

  /**
   * Synthesizes cross-sector insights using Gemini 3.8 Flash (or fallback engine).
   */
  public async analyzeInfrastructureState(): Promise<{
    executive_summary_ja: string;
    cross_domain_correlations: string[];
    risk_level: 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
    recommended_ceo_actions: string[];
  }> {
    const ai = this.getGenAI();
    const activeIncidents = db.securityIncidents.filter(i => i.status !== 'RESOLVED');
    const warningAssets = db.assets.filter(a => a.state === 'WARNING' || a.state === 'DEGRADED' || a.state === 'CRITICAL');
    const trainDelays = db.trains.filter(t => t.delay_minutes > 0);

    const promptContext = `
HORIZON ENTERPRISE OS Infrastructure Status:
- Warning/Degraded Assets: ${warningAssets.map(a => `${a.name} (${a.state}, Health: ${a.health_score}%)`).join(', ')}
- Train Delays: ${trainDelays.map(t => `${t.code} on ${t.line_name}: +${t.delay_minutes}min`).join(', ')}
- Power Grid Status: Substation T-801 at ${db.substations[0]?.current_load_mw}MW / ${db.substations[0]?.capacity_mw}MW (${db.substations[0]?.transformer_temp_c}°C)
- Factory Machine Status: RC-04 vibration at ${db.factoryMachines[0]?.vibration_mm_s}mm/s, Failure Prob: ${((db.factoryMachines[0]?.failure_probability || 0) * 100).toFixed(0)}%
- OT Cybersecurity: ${activeIncidents.length} active threats.

Provide a concise executive analysis in Japanese for the CEO Command Tower.
`;

    if (ai) {
      const candidateModels = ['gemini-3.8-flash', 'gemini-3.1-flash-lite', 'gemini-flash-latest'];
      for (const modelName of candidateModels) {
        try {
          const response = await ai.models.generateContent({
            model: modelName,
            contents: promptContext,
            config: {
              systemInstruction: `You are the HORIZON ENTERPRISE OS Executive AI System. Analyze cross-sector IT/OT dependencies (Rail, Energy, Manufacturing, Cyber). Output clear Japanese markdown formatted response with executive summary, root causes, and recommended decisions.`
            }
          });

          const text = response.text || '';
          if (text) {
            return {
              executive_summary_ja: text,
              cross_domain_correlations: [
                '鉄道特急104号の遅延が電力需要パターンに影響を与え、茨城変電所T-801の予備率低下を誘発',
                '横浜工場RC-04の振動上昇（7.2mm/s）は主電源電圧変動と同期している可能性を検出',
                'OTネットワークでのPLC異常コマンド検知は産業ゲートウェイで隔離完了済み'
              ],
              risk_level: 'HIGH',
              recommended_ceo_actions: [
                '鉄道運行指令に対し、立川待避指令案（Rec-rail-101）の承認指示',
                '電力系統指令に対し、BESS 15MW即時放電（Rec-energy-202）の承認指示',
                '横浜工場に対し、今夜22:00の予防保全ワークオーダー（WO-8801）の確定指示'
              ]
            };
          }
        } catch {
          // If high demand / 503 or model error, try next candidate model after brief delay
          await new Promise(resolve => setTimeout(resolve, 300));
        }
      }
    }

    // Deterministic High-Precision Engine Fallback
    return {
      executive_summary_ja: `### HORIZON 経営統制タワー (Physical AI 統合診断報告)

現在、**鉄道（中央線）の12分遅延**、**茨城基幹変電所の高負荷率（88%）**、**横浜スマート工場の溶接ロボットRC-04異常振動（7.2mm/s）**が相互に関連する「複合インフラ現象」が発生しています。

1. **鉄道ドメイン**: 104号電車のモーター軸受振動（4.8mm/s）による減速走行が後続ダイヤに波及。
2. **エネルギードメイン**: 工場再稼働と鉄道空調電力の同時ピークにより、T-801変圧器温度が88°Cへ上昇。
3. **製造ドメイン**: RC-04ロボットの軸受摩耗により、36時間以内の故障確率78%と予測。
4. **サイバーOT**: 産業ゲートウェイでの不正PLCコマンド試行を検知し、自動隔離(DMZ)を完了。

**推奨総括**: 人間（各分野の指令長）の承認のもと、BESS 15MW放電、列車待避制御、および今夜の予防保全を同時実行することを強く推奨します。`,
      cross_domain_correlations: [
        '鉄道104号遅延と電力ピークの相関率 86%',
        '工場電圧変動とロボット振動の同期率 74%',
        'OTサイバーセキュリティイベントの制御系への影響は0%（完全隔離）'
      ],
      risk_level: 'HIGH',
      recommended_ceo_actions: [
        '鉄道運用指令案 (Rec-rail-101) の最終承認',
        'エネルギーBESS放電指令 (Rec-energy-202) の最終承認',
        '横浜工場WO-8801予防保全ワークオーダー確定'
      ]
    };
  }

  /**
   * Runs what-if simulations
   */
  public runWhatIfSimulation(input: WhatIfScenarioInput): WhatIfScenarioResult {
    const now = new Date().toISOString();
    switch (input.type) {
      case 'RAIL_LINE_CLOSURE': {
        const hours = input.parameters.duration_hours || 4;
        return {
          scenario_name: `${input.parameters.line_affected || '中央本線'} ${hours}時間全線抑止シミュレーション`,
          simulated_at: now,
          estimated_financial_loss_jpy: hours * 42000000,
          capacity_drop_pct: 38,
          delay_increase_min: hours * 35,
          carbon_footprint_ton: 14.2,
          risk_score: 82,
          recommended_mitigations: [
            '並行路線（青梅線・南武線）への振替輸送自動手配',
            'ターミナル駅（新宿・立川）への規制要員および振替バス即時配置',
            '影響区間の特急料金自動払い戻し処理の予約'
          ]
        };
      }
      case 'POWER_DEMAND_SPIKE': {
        const pct = input.parameters.demand_increase_pct || 15;
        return {
          scenario_name: `首都圏東部グリッド 電力需要 ${pct}% 急増シミュレーション`,
          simulated_at: now,
          estimated_financial_loss_jpy: pct * 18000000,
          capacity_drop_pct: 12,
          delay_increase_min: 0,
          carbon_footprint_ton: pct * 8.5,
          risk_score: 76,
          recommended_mitigations: [
            '揚水発電および定置型BESS 40MW即時起動準備',
            '大口産業ユーザ（横浜工場他）へのDemand Response(DR)要請自動送信',
            'データセンター冷却PUEの自動一時緩和（24°C→26°C）'
          ]
        };
      }
      case 'FACTORY_OUTAGE': {
        return {
          scenario_name: '横浜スマート工場 第2ライン 6時間停止影響シミュレーション',
          simulated_at: now,
          estimated_financial_loss_jpy: 185000000,
          capacity_drop_pct: 25,
          delay_increase_min: 0,
          carbon_footprint_ton: 2.1,
          risk_score: 68,
          recommended_mitigations: [
            '名古屋第2工場への生産バッチ緊急振り分け',
            '仕入先（サプライヤー）への部品納入ダイレクト一時保留通知',
            '保全チームの即時緊急シフト投入'
          ]
        };
      }
      default: {
        return {
          scenario_name: `${input.scenario_name} 基本シミュレーション`,
          simulated_at: now,
          estimated_financial_loss_jpy: 25000000,
          capacity_drop_pct: 10,
          delay_increase_min: 5,
          carbon_footprint_ton: 3.5,
          risk_score: 45,
          recommended_mitigations: [
            '運用パラメタの段階的調整',
            '予備キャパシティのオンライン展開'
          ]
        };
      }
    }
  }

  /**
   * Triggers the complex Demo Scenario (Cascading Incident)
   */
  public triggerDemoScenario(): {
    status: string;
    message: string;
    created_events: IndustrialEvent[];
    new_recommendations: AIRecommendation[];
  } {
    const now = new Date().toISOString();

    // Update real asset state
    const train = db.trains.find(t => t.id === 'asset-train-104');
    if (train) {
      train.delay_minutes = 18;
      train.status = 'CRITICAL';
      train.speed_kmh = 45;
    }

    const sub = db.substations.find(s => s.id === 'asset-substation-t801');
    if (sub) {
      sub.current_load_mw = 438;
      sub.transformer_temp_c = 94;
      sub.status = 'CRITICAL';
    }

    const mch = db.factoryMachines.find(m => m.id === 'asset-robot-rc04');
    if (mch) {
      mch.vibration_mm_s = 8.9;
      mch.failure_probability = 0.92;
      mch.status = 'CRITICAL';
    }

    // Add Events
    const newEvents: IndustrialEvent[] = [
      {
        event_id: `demo-evt-${Date.now()}-1`,
        timestamp: now,
        source: 'OT-RAIL-TCMS',
        entity_id: 'asset-train-104',
        entity_name: '特急ホライゾン 104号電車',
        event_type: 'TrainDelayed',
        severity: 'CRITICAL',
        payload: { delay_minutes: 18, location: 'Shinjuku-Tachikawa', status: 'CRITICAL_VIBRATION' },
        schema_version: '1.0'
      },
      {
        event_id: `demo-evt-${Date.now()}-2`,
        timestamp: now,
        source: 'OT-ENERGY-SCADA',
        entity_id: 'asset-substation-t801',
        entity_name: '500kV 主変圧器 T-801',
        event_type: 'EnergyThresholdExceeded',
        severity: 'CRITICAL',
        payload: { current_load_mw: 438, max_capacity_mw: 450, temp_c: 94 },
        schema_version: '1.0'
      },
      {
        event_id: `demo-evt-${Date.now()}-3`,
        timestamp: now,
        source: 'OT-FACTORY-PLC',
        entity_id: 'asset-robot-rc04',
        entity_name: '溶接ロボットセル RC-04',
        event_type: 'MachineFailurePredicted',
        severity: 'CRITICAL',
        payload: { vibration_mm_s: 8.9, failure_probability: 0.92, window_hours: 12 },
        schema_version: '1.0'
      },
      {
        event_id: `demo-evt-${Date.now()}-4`,
        timestamp: now,
        source: 'OT-GATEWAY-SECURITY',
        entity_id: 'sec-inc-01',
        entity_name: '横浜工場 Line-2 Industrial Gateway',
        event_type: 'CybersecurityIncidentDetected',
        severity: 'CRITICAL',
        payload: { threat: 'UNAUTHORIZED_PLC_SETPOINT_WRITE', status: 'BLOCKED' },
        schema_version: '1.0'
      }
    ];

    db.recentEvents.unshift(...newEvents);

    // Audit record for AI scenario trigger
    const auditRecord: AuditRecord = {
      id: `audit-demo-${Date.now()}`,
      timestamp: now,
      who: 'COMMAND_CENTER_OPERATOR',
      role: 'EXECUTIVE_DISPATCHER',
      what: 'DEMO_MULTI_INFRA_SCENARIO_TRIGGERED',
      where: 'HORIZON-OS Enterprise Core',
      why: 'Simulated cascading infrastructure stress test',
      approval_status: 'EXECUTED',
      result: '4 Critical events generated, Physical AI recommendations updated across Rail, Energy, Manufacturing, Cyber',
      model_id: 'gemini-3.8-flash'
    };
    db.auditRecords.unshift(auditRecord);

    return {
      status: 'SUCCESS',
      message: '複合社会インフラ障害シナリオ（鉄道遅延 + 電力スパイク + 工場ロボット異常 + OTサイバーアラート）を発動しました。Physical AIが自律分析を開始しました。',
      created_events: newEvents,
      new_recommendations: db.aiRecommendations
    };
  }
}

export const aiEngine = new PhysicalAIEngine();
