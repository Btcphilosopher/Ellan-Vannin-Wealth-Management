package com.example.features.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.MixueDatabase
import com.example.data.model.*
import com.example.data.repository.MixueRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.math.BigDecimal
import java.util.Locale

class MixueViewModel(application: Application) : AndroidViewModel(application) {

    private val database = MixueDatabase.getDatabase(application)
    private val repository = MixueRepository(database.mixueDao())

    // UI Tab Navigation
    private val _currentTab = MutableStateFlow(0) // 0: 首页, 1: 点单, 2: 雪王币, 3: 会员, 4: 我的
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    // Active User states
    val memberProfile: StateFlow<MemberProfile?> = repository.memberProfile
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val pointsLedger: StateFlow<List<PointsRecord>> = repository.pointsLedger
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val availableCoupons: StateFlow<List<Coupon>> = repository.availableCoupons
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val stores: StateFlow<List<Store>> = repository.allStores
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cartItems: StateFlow<List<CartItem>> = repository.cartItems
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val orders: StateFlow<List<Order>> = repository.allOrders
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val campaigns: StateFlow<List<Campaign>> = repository.allCampaigns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val mallProducts: StateFlow<List<MallProduct>> = repository.mallProducts
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Selected Store
    private val _selectedStore = MutableStateFlow<Store?>(null)
    val selectedStore: StateFlow<Store?> = _selectedStore.asStateFlow()

    // Ordering parameters
    private val _selectedCategory = MutableStateFlow("冰鲜柠檬水")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _isDelivery = MutableStateFlow(false) // false: 自提, true: 外卖
    val isDelivery: StateFlow<Boolean> = _isDelivery.asStateFlow()

    // Customize dialog state
    private val _customizingProduct = MutableStateFlow<Product?>(null)
    val customizingProduct: StateFlow<Product?> = _customizingProduct.asStateFlow()

    val tempSelection = MutableStateFlow("正常冰")
    val sweetSelection = MutableStateFlow("标准糖")
    val sizeSelection = MutableStateFlow("标准")
    private val _selectedToppings = MutableStateFlow<Set<String>>(emptySet())
    val selectedToppings: StateFlow<Set<String>> = _selectedToppings.asStateFlow()

    // Checkout configurations
    private val _selectedCoupon = MutableStateFlow<Coupon?>(null)
    val selectedCoupon: StateFlow<Coupon?> = _selectedCoupon.asStateFlow()

    val usePointsLedger = MutableStateFlow(false)

    // Price breakdowns
    private val _priceBreakdown = MutableStateFlow(
        MixueRepository.PriceBreakdown(BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO)
    )
    val priceBreakdown: StateFlow<MixueRepository.PriceBreakdown> = _priceBreakdown.asStateFlow()

    // AI Snow King Chat assistant
    private val _chatHistory = MutableStateFlow<List<Pair<String, String>>>(listOf(
        "AI_KING" to "主子好！我是您的雪王贴身小助手 ❄️！我可以帮您查询附近的门店、查看您的雪王币余额、看优惠券，或者安利好喝的，快来考考我吧！"
    ))
    val chatHistory: StateFlow<List<Pair<String, String>>> = _chatHistory.asStateFlow()

    val chatInputText = MutableStateFlow("")

    // Mini game status (雪王送甜蜜)
    val miniGameScore = MutableStateFlow(0)
    val miniGamePlaying = MutableStateFlow(false)

    // Master Demo 4 & 5 conditions
    val isPeakHourCongestion = MutableStateFlow(false) // Demo 4
    val isLemonadeLowStock = MutableStateFlow(false)   // Demo 5

    // Global notifications
    private val _notification = MutableStateFlow<String?>(null)
    val notification: StateFlow<String?> = _notification.asStateFlow()

    // Simulated Active Order tracker
    private val _currentActiveOrder = MutableStateFlow<Order?>(null)
    val currentActiveOrder: StateFlow<Order?> = _currentActiveOrder.asStateFlow()

    private val _orderTimelineStatus = MutableStateFlow("CREATED")
    val orderTimelineStatus: StateFlow<String> = _orderTimelineStatus.asStateFlow()

    private var simulationJob: Job? = null

    init {
        // Automatically select the default store (人民广场店) once database stores are loaded
        viewModelScope.launch {
            stores.collect { list ->
                if (_selectedStore.value == null && list.isNotEmpty()) {
                    _selectedStore.value = list.find { it.id == 101 } ?: list.first()
                }
            }
        }

        // Keep price calculations synced to cart items, delivery option, coupon option, points option
        viewModelScope.launch {
            combine(cartItems, _isDelivery, _selectedCoupon, usePointsLedger) { _, _, _, _ -> }
                .collect {
                    recalculatePrice()
                }
        }
    }

    fun setTab(index: Int) {
        _currentTab.value = index
    }

    fun selectStore(store: Store) {
        _selectedStore.value = store
        showNotification("已选择门店: ${store.name}")
    }

    fun selectCategory(category: String) {
        _selectedCategory.value = category
    }

    fun toggleDelivery(delivery: Boolean) {
        _isDelivery.value = delivery
        // Reset coupon or calculate delivery fee adjustments
        recalculatePrice()
    }

    fun showNotification(msg: String) {
        viewModelScope.launch {
            _notification.value = msg
            delay(3000)
            if (_notification.value == msg) {
                _notification.value = null
            }
        }
    }

    fun clearNotification() {
        _notification.value = null
    }

    // Recalculate price Breakdown
    fun recalculatePrice() {
        viewModelScope.launch {
            val breakdown = repository.calculateCartPrice(
                isDelivery = _isDelivery.value,
                selectedCouponId = _selectedCoupon.value?.id,
                redeemPoints = usePointsLedger.value
            )
            _priceBreakdown.value = breakdown
        }
    }

    // Customized product dialog controls
    fun startCustomizing(product: Product) {
        // Master Demo 5: Low stock check
        if (isLemonadeLowStock.value && product.id == 1) {
            showNotification("⚠️ 该商品目前排队过载，暂时售罄！已为您智能推荐替代饮品「蜜桃四季春」！")
            val peach = products.value.find { it.id == 6 }
            if (peach != null) {
                _customizingProduct.value = peach
            }
            return
        }

        _customizingProduct.value = product
        tempSelection.value = "正常冰"
        sweetSelection.value = "标准糖"
        sizeSelection.value = "标准"
        _selectedToppings.value = emptySet()
    }

    fun dismissCustomizing() {
        _customizingProduct.value = null
    }

    fun toggleTopping(topping: String) {
        val currentSet = _selectedToppings.value.toMutableSet()
        if (currentSet.contains(topping)) {
            currentSet.remove(topping)
        } else {
            currentSet.add(topping)
        }
        _selectedToppings.value = currentSet
    }

    fun addCustomizedToCart() {
        val product = _customizingProduct.value ?: return
        viewModelScope.launch {
            var finalPrice = BigDecimal(product.price)
            val toppingsStr = _selectedToppings.value.joinToString(",")

            // Each topping is +1.00 Yuan in simulation
            val toppingCount = _selectedToppings.value.size
            if (toppingCount > 0) {
                finalPrice = finalPrice.add(BigDecimal(toppingCount.toString()))
            }

            val item = CartItem(
                productId = product.id,
                productName = product.name,
                price = finalPrice.setScale(2).toString(),
                quantity = 1,
                temperature = tempSelection.value,
                sweetness = sweetSelection.value,
                size = sizeSelection.value,
                toppings = toppingsStr
            )

            repository.addToCart(item)
            dismissCustomizing()
            showNotification("🥤「${product.name}」已加入购物车")
        }
    }

    // Direct add for standard (no topping/default ice)
    fun quickAddProduct(product: Product) {
        if (isLemonadeLowStock.value && product.id == 1) {
            showNotification("⚠️ 冰鲜柠檬水配料不足，已智能推荐「蜜桃四季春」")
            val peach = products.value.find { it.id == 6 }
            if (peach != null) {
                quickAddProduct(peach)
            }
            return
        }

        viewModelScope.launch {
            val item = CartItem(
                productId = product.id,
                productName = product.name,
                price = product.price,
                quantity = 1,
                temperature = "正常冰",
                sweetness = "标准糖",
                size = "标准",
                toppings = ""
            )
            repository.addToCart(item)
            showNotification("🥤 已加入: ${product.name}")
        }
    }

    fun updateCartQty(item: CartItem, isAdd: Boolean) {
        viewModelScope.launch {
            val newQty = if (isAdd) item.quantity + 1 else item.quantity - 1
            if (newQty <= 0) {
                repository.deleteCartItem(item.id)
                showNotification("已移出购物车")
            } else {
                repository.updateCartItem(item.copy(quantity = newQty))
            }
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            repository.clearCart()
            showNotification("购物车已清空")
        }
    }

    fun selectCouponForCheckout(coupon: Coupon?) {
        _selectedCoupon.value = coupon
    }

    // Submit and simulate order state engine
    fun submitCheckout() {
        viewModelScope.launch {
            val store = _selectedStore.value ?: return@launch
            val order = repository.checkoutAndCreateOrder(
                storeId = store.id,
                isDelivery = _isDelivery.value,
                selectedCouponId = _selectedCoupon.value?.id,
                redeemPoints = usePointsLedger.value
            )

            if (order != null) {
                _currentActiveOrder.value = order
                _selectedCoupon.value = null
                usePointsLedger.value = false
                showNotification("🎉 模拟支付成功！雪王收到您的快乐订单！")

                // Open active tracking directly in My (or keep in a dedicated tracking mode)
                _currentTab.value = 4 // Navigate to "My" profile orders instantly
                runOrderTimelineSimulation(order.id)
            }
        }
    }

    private fun runOrderTimelineSimulation(orderId: Int) {
        simulationJob?.cancel()
        simulationJob = viewModelScope.launch {
            repository.runSimulatedOrderProgress(orderId).collect { status ->
                _orderTimelineStatus.value = status
                val order = repository.getOrderById(orderId)
                if (order != null) {
                    _currentActiveOrder.value = order
                }

                // Push a push notification/log
                when (status) {
                    "PAID" -> showNotification("雪王：小店已收到订单，正在打印小票！")
                    "ACCEPTED" -> showNotification("雪王：店员小帅已接单，准备开始配置配料！")
                    "PREPARING" -> showNotification("雪王：杯子正在疯狂旋转，美味正在爆发！")
                    "READY" -> {
                        showNotification("🔔 叮咚！取餐码为【${order?.orderCode}】的饮品已做完！请点击扫码核销！")
                    }
                }
            }
        }
    }

    fun simulateQRPickup() {
        val order = _currentActiveOrder.value ?: return
        viewModelScope.launch {
            repository.progressOrder(order.id, "COMPLETED")
            _orderTimelineStatus.value = "COMPLETED"
            _currentActiveOrder.value = repository.getOrderById(order.id)
            showNotification("🎁 核销成功！雪王已经把快乐亲手奉上啦！已赠送积分并计入成长值！")
        }
    }

    fun repeatLastOrder(order: Order) {
        viewModelScope.launch {
            // Parses the serialized item text from order
            repository.clearCart()
            // To keep it simple, find products by name or add them
            val productList = repository.allProducts.first()
            // Simple match adding
            val name = order.storeName
            val matchStore = stores.value.find { it.name == name }
            if (matchStore != null) {
                _selectedStore.value = matchStore
            }

            // Since it's a demo reorder, we add a lemonade or standard item back to cart to simulate reorder
            val lemon = productList.find { it.id == 1 } ?: productList.first()
            quickAddProduct(lemon)
            _currentTab.value = 1 // navigate back to 点单/cart instantly
            showNotification("已自动载入上次点单配置，您可以直接去结算！")
        }
    }

    // Sign In Trigger
    fun triggerDailySignIn() {
        viewModelScope.launch {
            val result = repository.performDailySignIn()
            showNotification(result.second)
        }
    }

    // AI Snow King Chat assistant submit
    fun sendAssistantMessage() {
        val txt = chatInputText.value.trim()
        if (txt.isEmpty()) return

        _chatHistory.value = _chatHistory.value + ("USER" to txt)
        chatInputText.value = ""

        viewModelScope.launch {
            delay(800) // slight organic chat delay
            val reply = repository.querySnowKingAssistant(txt)
            _chatHistory.value = _chatHistory.value + ("AI_KING" to reply)
        }
    }

    // ----------------------------------------------------
    // MASTER DEMOS ORCHESTRATION (Requirements 80 to 84)
    // ----------------------------------------------------

    // Master Demo 1: The Master User Journey (Run sequentially via trigger)
    fun runMasterDemoJourney1() {
        viewModelScope.launch {
            showNotification("🚀 正在载入王小明全链路 Master Demo 旅程...")
            delay(1500)
            _currentTab.value = 0 // Home
            showNotification("王小明查看首页 [雪王夏日甜蜜季] 轮播与推荐")
            delay(2500)

            _currentTab.value = 1 // Ordering Page
            _selectedStore.value = stores.value.find { it.id == 101 } // People's Square Store
            showNotification("选择 [蜜雪冰城·人民广场店] (自提)")
            delay(2500)

            val lemon = products.value.find { it.id == 1 } ?: return@launch
            startCustomizing(lemon)
            showNotification("选择「冰鲜柠檬水」：选择「少冰」、「少糖」并加珍珠！")
            delay(2000)

            tempSelection.value = "少冰"
            sweetSelection.value = "少糖"
            _selectedToppings.value = setOf("珍珠")
            delay(1500)

            addCustomizedToCart()
            delay(2000)

            showNotification("进入购物车，系统自动计算 [会员半价优惠] 与 [优惠券减免]")
            delay(2500)

            // Auto-check points deduction and select 2 Yuan cash coupon
            val claimCoupon = availableCoupons.value.find { it.amount == "2.00" }
            _selectedCoupon.value = claimCoupon
            usePointsLedger.value = true
            showNotification("勾选雪王币抵用扣减，最终应付 ¥1.50 元")
            delay(3000)

            submitCheckout() // Payments completes, triggers timeline simulation
        }
    }

    // Master Demo 2: Simulated New Product Release ("草莓雪顶茶")
    fun runMasterDemoNewProductRelease() {
        viewModelScope.launch {
            showNotification("🚀 [Master Demo 2] 模拟后台发布新品「草莓雪顶茶」")
            delay(1500)

            // Inject Product synthetically
            val newProd = Product(
                id = 9,
                name = "草莓雪顶茶",
                description = "2026全新顶流新品！鲜草莓果泥融入清雅四季春，盖上一大座浓郁香甜的牛乳冰淇淋雪顶，提前购可享优惠！",
                category = "果茶",
                price = "9.00",
                memberPrice = "8.00",
                isNew = true,
                isHot = false,
                isAvailable = true,
                stock = 150,
                imageResName = "ic_strawberry_snow",
                salesCount = 0,
                discountTag = "新品专享折扣"
            )

            repository.insertProducts(listOf(newProd))
            // Inject coupon template automatically too
            repository.claimCoupon(
                Coupon(
                    name = "草莓雪顶茶尝鲜立减3元",
                    couponType = "NEW_PRODUCT",
                    amount = "3.00",
                    minSpend = "8.00",
                    isUsed = false,
                    expiryDate = "2026-10-15",
                    applicableCategory = "果茶"
                )
            )

            _selectedCategory.value = "果茶"
            _currentTab.value = 1 // Ordering Page
            showNotification("【新品播报】新品「草莓雪顶茶」已全面上架！已自动分发『尝鲜3元代金券』至您的券包！")
        }
    }

    // Master Demo 3: Simulated Mega Campaigns ("雪王夏日甜蜜季")
    fun runMasterDemoSummerCampaign() {
        viewModelScope.launch {
            showNotification("🚀 [Master Demo 3] 启动「雪王夏日甜蜜季」嘉年华活动")
            delay(1500)
            _currentTab.value = 2 // Snow King Coins Page
            showNotification("夏日甜蜜季限时启动！解锁签到礼包、周边商城，并进入迷你游戏！")
        }
    }

    // Master Demo 4: Peak Hour Congestion (High traffic ordering splitting)
    fun runMasterDemoPeakHourCongestion() {
        viewModelScope.launch {
            isPeakHourCongestion.value = true
            showNotification("🚀 [Master Demo 4] 模拟午高峰期间客流增加 +300%！")
            delay(1500)

            // Increase Store queue & prep times dynamically
            val currentStores = stores.value
            for (st in currentStores) {
                if (st.id == 101) {
                    repository.updateStore(st.copy(
                        queueCount = 42,
                        prepTimeMin = 35,
                        status = "BUSY"
                    ))
                } else if (st.id == 102) {
                    repository.updateStore(st.copy(
                        queueCount = 88,
                        prepTimeMin = 50,
                        status = "BUSY"
                    ))
                }
            }

            showNotification("⚠️ 预警：附近人民广场店排队已达42杯！建议切换至静安寺店(排队2杯，仅需5分钟)！")
        }
    }

    // Master Demo 5: Low Stock and Automatic Inventory Splitting
    fun runMasterDemoLowStock() {
        viewModelScope.launch {
            isLemonadeLowStock.value = true
            showNotification("🚀 [Master Demo 5] 模拟「冰鲜柠檬水」库存不足！")
            delay(1500)

            // Update item stock to 0
            val lemon = products.value.find { it.id == 1 }
            if (lemon != null) {
                repository.updateProduct(lemon.copy(stock = 0, isAvailable = false))
            }

            _currentTab.value = 1 // ordering tab
            _selectedCategory.value = "冰鲜柠檬水"
            showNotification("⚠️ 冰鲜柠檬水售罄！前端已启动自动阻断锁单，点击自动智能替换为「蜜桃四季春」！")
        }
    }

    // Reset all synthetic states
    fun resetAllMasterDemos() {
        viewModelScope.launch {
            isPeakHourCongestion.value = false
            isLemonadeLowStock.value = false
            _selectedCoupon.value = null
            usePointsLedger.value = false
            _chatHistory.value = listOf(
                "AI_KING" to "主子好！我是您的雪王贴身小助手 ❄️！我可以帮您查询附近的门店、查看您的雪王币余额、看优惠券，或者安利好喝的，快来考考我吧！"
            )

            // Restore original database state
            val freshDB = MixueDatabase.getDatabase(getApplication())
            freshDB.clearAllTables()

            // Prepopulate database fresh manually
            // This is equivalent to triggering onCreate
            showNotification("已重置所有模拟数据，数据平台数据已刷新。")
            _currentTab.value = 0
        }
    }

    // Mini game logic
    fun playMiniGameTap() {
        miniGameScore.value = miniGameScore.value + 1
        if (miniGameScore.value >= 15) {
            viewModelScope.launch {
                miniGamePlaying.value = false
                val profile = memberProfile.value
                if (profile != null) {
                    val reward = 150
                    val newPts = profile.points + reward
                    repository.updateMemberProfile(profile.copy(points = newPts))
                    repository.insertPointsRecord(
                        PointsRecord(
                            amount = reward,
                            eventType = "EARN",
                            source = "雪王送甜蜜小游戏",
                            referenceId = "GAME_${System.currentTimeMillis()}",
                            timestamp = System.currentTimeMillis(),
                            balanceAfter = newPts
                        )
                    )
                    showNotification("🏆 哇哦！雪王饮品完美送达！获得游戏奖励 🪙 150 雪王币！")
                }
            }
        }
    }

    fun startMiniGame() {
        miniGameScore.value = 0
        miniGamePlaying.value = true
    }

    // Peripheral Mall Redemption
    fun redeemMallProduct(item: MallProduct) {
        val profile = memberProfile.value ?: return
        if (profile.points < item.pointsPrice) {
            showNotification("❌ 您的雪王币余额不足，快去点单积攒更多雪王币吧！")
            return
        }

        viewModelScope.launch {
            val newPoints = profile.points - item.pointsPrice
            repository.updateMemberProfile(profile.copy(points = newPoints))
            repository.insertPointsRecord(
                PointsRecord(
                    amount = -item.pointsPrice,
                    eventType = "REDEEM",
                    source = "周边兑换: ${item.name}",
                    referenceId = "MALL_${item.id}",
                    timestamp = System.currentTimeMillis(),
                    balanceAfter = newPoints
                )
            )
            showNotification("🎁 兑换成功！雪王周边「${item.name}」正在打包，将送至您的默认地址！")
        }
    }
}
