package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.platform.testTag
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

// ----------------------------------------------------
// 1. MIXUE Branded Button
// ----------------------------------------------------
@Composable
fun MIXUEButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    backgroundColor: Color = MixueRed,
    contentColor: Color = MixueWhite,
    shape: RoundedCornerShape = RoundedCornerShape(24.dp)
) {
    Button(
        onClick = onClick,
        enabled = enabled,
        modifier = modifier
            .height(48.dp)
            .minimumInteractiveComponentSize()
            .testTag("mixue_button_${text.lowercase().replace(" ", "_")}"),
        colors = ButtonDefaults.buttonColors(
            containerColor = backgroundColor,
            contentColor = contentColor,
            disabledContainerColor = Color.LightGray,
            disabledContentColor = Color.DarkGray
        ),
        shape = shape,
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp, pressedElevation = 4.dp)
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            maxLines = 1
        )
    }
}

// ----------------------------------------------------
// 2. MIXUE Card (Drop shadow container)
// ----------------------------------------------------
@Composable
fun MIXUECard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = MixueWhite,
    borderColor: Color? = null,
    elevation: androidx.compose.ui.unit.Dp = 2.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .shadow(elevation, shape = RoundedCornerShape(16.dp))
            .clip(RoundedCornerShape(16.dp))
            .background(backgroundColor),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = backgroundColor),
        border = borderColor?.let { borderStroke -> BorderStroke(1.dp, borderStroke) }
    ) {
        Column(
            modifier = Modifier.padding(16.dp)
        ) {
            content()
        }
    }
}

// ----------------------------------------------------
// 3. MIXUE Price tag with standard currency icon
// ----------------------------------------------------
@Composable
fun MIXUEPrice(
    price: String,
    modifier: Modifier = Modifier,
    isMemberPrice: Boolean = false,
    fontSize: Int = 16,
    originalPrice: String? = null
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.Bottom
    ) {
        if (isMemberPrice) {
            Text(
                text = "会员专享 ",
                color = MixueGold,
                fontSize = (fontSize - 4).sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(bottom = 1.dp)
            )
        }
        Text(
            text = "¥",
            color = if (isMemberPrice) MixueGold else MixueRed,
            fontSize = (fontSize - 4).sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 1.dp)
        )
        Text(
            text = price,
            color = if (isMemberPrice) MixueGold else MixueRed,
            fontSize = fontSize.sp,
            fontWeight = FontWeight.ExtraBold
        )

        if (originalPrice != null) {
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "¥$originalPrice",
                color = Color.Gray,
                fontSize = (fontSize - 4).sp,
                textDecoration = TextDecoration.LineThrough,
                modifier = Modifier.padding(bottom = 1.dp)
            )
        }
    }
}

// ----------------------------------------------------
// 4. MIXUE Product Card Card Widget
// ----------------------------------------------------
@Composable
fun MIXUEProductCard(
    name: String,
    description: String,
    price: String,
    memberPrice: String,
    discountTag: String,
    isNew: Boolean,
    isHot: Boolean,
    imageResName: String,
    stock: Int,
    onAddClick: () -> Unit,
    onCardClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        onClick = onCardClick,
        modifier = modifier
            .fillMaxWidth()
            .testTag("product_card_${name.replace(" ", "_")}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MixueWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(12.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Simulated Product Image Vector placeholder
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MixueRedLight),
                contentAlignment = Alignment.Center
            ) {
                // Background artistic shape
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCircle(
                        color = Color.White.copy(alpha = 0.5f),
                        radius = size.minDimension / 3,
                        center = Offset(size.width / 2, size.height / 2)
                    )
                }

                // Render vector icon depending on imageResName
                Icon(
                    imageVector = when {
                        imageResName.contains("lemon") -> Icons.Filled.LocalActivity
                        imageResName.contains("ice_cream") -> Icons.Filled.Icecream
                        imageResName.contains("milkshake") -> Icons.Filled.Blender
                        imageResName.contains("tea") -> Icons.Filled.LocalCafe
                        imageResName.contains("milktea") -> Icons.Filled.WaterDrop
                        imageResName.contains("coffee") -> Icons.Filled.Coffee
                        imageResName.contains("sundae") -> Icons.Filled.Icecream
                        imageResName.contains("peach") -> Icons.Filled.Favorite
                        else -> Icons.Filled.LocalDrink
                    },
                    contentDescription = name,
                    tint = MixueRed,
                    modifier = Modifier.size(36.dp)
                )

                // Tags for New or Hot
                if (isNew) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .background(MixueGreenAccent, RoundedCornerShape(bottomEnd = 6.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text("新品", color = MixueWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                } else if (isHot) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .background(MixueRed, RoundedCornerShape(bottomEnd = 6.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text("人气", color = MixueWhite, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text(
                    text = name,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = description,
                    fontSize = 11.sp,
                    color = Color.Gray,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.padding(vertical = 2.dp)
                )

                if (discountTag.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .background(MixueRedLight, RoundedCornerShape(4.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = discountTag,
                            color = MixueRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        MIXUEPrice(price = price, fontSize = 16)
                        MIXUEPrice(price = memberPrice, isMemberPrice = true, fontSize = 13)
                    }

                    // Stock check
                    if (stock <= 0) {
                        Box(
                            modifier = Modifier
                                .background(Color.LightGray, RoundedCornerShape(12.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("已售罄", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        // Interactive Add Button
                        IconButton(
                            onClick = onAddClick,
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(MixueRed)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Add,
                                contentDescription = "加入购物车",
                                tint = MixueWhite,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 5. MIXUE Coupon Display Card (Interactive with dashed separator)
// ----------------------------------------------------
@Composable
fun MIXUECouponCard(
    coupon: Coupon,
    onUseClick: (() -> Unit)? = null,
    isSelected: Boolean = false,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(if (isSelected) MixueRedLight else MixueWhite)
            .border(
                1.5.dp,
                if (isSelected) MixueRed else Color(0xFFEFEFEF),
                RoundedCornerShape(12.dp)
            )
            .clickable(enabled = onUseClick != null) { onUseClick?.invoke() }
    ) {
        Row(
            modifier = Modifier
                .height(84.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Left Value Column
            Column(
                modifier = Modifier
                    .width(88.dp)
                    .background(
                        if (isSelected) MixueRed else MixueRedLight
                    )
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(
                        text = "¥",
                        color = if (isSelected) MixueWhite else MixueRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )
                    Text(
                        text = coupon.amount.substringBefore("."),
                        color = if (isSelected) MixueWhite else MixueRed,
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black
                    )
                }
                Text(
                    text = "满${coupon.minSpend.substringBefore(".")}元可用",
                    color = if (isSelected) MixueWhite.copy(alpha = 0.8f) else Color.Gray,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            // Dashed Divider Canvas
            Canvas(
                modifier = Modifier
                    .width(1.dp)
                    .fillMaxHeight()
            ) {
                val pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f), 0f)
                drawLine(
                    color = Color.LightGray,
                    start = Offset(0f, 0f),
                    end = Offset(0f, size.height),
                    pathEffect = pathEffect,
                    strokeWidth = 2f
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            // Right text fields
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(vertical = 8.dp),
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = coupon.name,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "适用范围：${if (coupon.applicableCategory == "ALL") "全品类通用" else coupon.applicableCategory}",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
                Text(
                    text = "有效期至 ${coupon.expiryDate}",
                    fontSize = 10.sp,
                    color = Color.LightGray
                )
            }

            if (isSelected) {
                Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = "已选择",
                    tint = MixueRed,
                    modifier = Modifier
                        .padding(end = 12.dp)
                        .size(24.dp)
                )
            }
        }
    }
}

// ----------------------------------------------------
// 6. MIXUE Membership Card Widget (Highly distinct, red and gold)
// ----------------------------------------------------
@Composable
fun MIXUEMemberCard(
    nickname: String,
    level: String,
    points: Int,
    growth: Int,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp)
            .shadow(4.dp, shape = RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.linearGradient(
                        colors = listOf(MixueRed, MixueRedDark)
                    )
                )
                .padding(18.dp)
        ) {
            // Stylized background graphics
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.05f),
                    radius = size.maxDimension / 2.5f,
                    center = Offset(size.width, size.height)
                )
                drawCircle(
                    color = MixueGold.copy(alpha = 0.15f),
                    radius = size.maxDimension / 4f,
                    center = Offset(0f, 0f)
                )
            }

            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header (Nickname & Level badge)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Avatar placeholder with gold frame
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(MixueWhite)
                                .border(1.5.dp, MixueGold, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "❄️",
                                fontSize = 24.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = nickname,
                                color = MixueWhite,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(MixueGold, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = level,
                                        color = MixueBlack,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }

                    // Gold Crown IP badge
                    Icon(
                        imageVector = Icons.Filled.CardGiftcard,
                        contentDescription = "礼品卡",
                        tint = MixueGold,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // Center Progress bar
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        Text(
                            text = "成长值 $growth/1000",
                            color = MixueWhite.copy(alpha = 0.8f),
                            fontSize = 11.sp
                        )
                        Text(
                            text = "雪王币 🪙 $points",
                            color = MixueGold,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    // Progress slider
                    LinearProgressIndicator(
                        progress = { (growth.toFloat() / 1000f).coerceIn(0f, 1f) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(RoundedCornerShape(3.dp)),
                        color = MixueGold,
                        trackColor = Color.White.copy(alpha = 0.2f)
                    )
                }

                // Footer Barcode simulated area
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "让全球每个人享受高质平价的美味与快乐",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Light
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.QrCode2,
                            contentDescription = "会员二维码",
                            tint = MixueWhite,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "付款码",
                            color = MixueWhite,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// 7. MIXUE Store Card (Detailed Store metrics)
// ----------------------------------------------------
@Composable
fun MIXUEStoreCard(
    store: Store,
    onSelectClick: () -> Unit,
    isSelected: Boolean = false,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onSelectClick() },
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) MixueRedLight else MixueWhite
        ),
        border = if (isSelected) BorderStroke(1.5.dp, MixueRed) else null,
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = store.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MixueBlack
                    )
                    Text(
                        text = store.address,
                        fontSize = 11.sp,
                        color = Color.Gray,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }

                // Distance Badge
                Box(
                    modifier = Modifier
                        .background(MixueLightGray, RoundedCornerShape(12.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "${store.distanceMeter}m",
                        color = MixueBlack,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Queue info and prep time
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(
                                if (store.status == "OPEN") MixueGreenAccent.copy(alpha = 0.15f) else MixueRed.copy(alpha = 0.15f)
                            )
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = if (store.status == "OPEN") "营业中" else "繁忙中",
                            color = if (store.status == "OPEN") MixueGreenAccent else MixueRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Text(
                        text = "排队: ${store.queueCount}杯 | 预计: ${store.prepTimeMin}分钟",
                        fontSize = 12.sp,
                        color = Color.DarkGray
                    )
                }

                // Interactive Switch Store Button
                Button(
                    onClick = onSelectClick,
                    modifier = Modifier.height(32.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) MixueRed else MixueLightGray,
                        contentColor = if (isSelected) MixueWhite else MixueBlack
                    ),
                    shape = RoundedCornerShape(16.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp)
                ) {
                    Text(
                        text = if (isSelected) "已选择" else "去点单",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

// ----------------------------------------------------
// 8. MIXUE IP Box: Speech Bubble Snow King Speeches
// ----------------------------------------------------
@Composable
fun MIXUESnowKingCard(
    speech: String,
    modifier: Modifier = Modifier,
    characterPoseRotation: Float = 0f
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Snow king sticker avatar
        Box(
            modifier = Modifier
                .size(60.dp)
                .clip(CircleShape)
                .background(MixueRedLight)
                .rotate(characterPoseRotation),
            contentAlignment = Alignment.Center
        ) {
            Text("❄️", fontSize = 34.sp)
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Speech Bubble Box
        Box(
            modifier = Modifier
                .weight(1f)
                .shadow(2.dp, shape = RoundedCornerShape(12.dp))
                .clip(RoundedCornerShape(12.dp))
                .background(MixueWhite)
                .border(1.dp, MixueRedLight, RoundedCornerShape(12.dp))
                .padding(12.dp)
        ) {
            Text(
                text = speech,
                color = MixueBlack,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}
