package com.example.features.membership

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardMembership
import androidx.compose.material.icons.filled.CardTravel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Discount
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.features.viewmodel.MixueViewModel
import com.example.ui.components.MIXUEButton
import com.example.ui.components.MIXUECard
import com.example.ui.components.MIXUECouponCard
import com.example.ui.components.MIXUEMemberCard
import com.example.ui.theme.*

@Composable
fun MembershipScreen(
    viewModel: MixueViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.memberProfile.collectAsState()
    val availableCoupons by viewModel.availableCoupons.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MixueWarmWhite)
            .testTag("membership_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // 1. MEMBERSHIP BANNER
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MixueRed)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = "雪王甜蜜会员中心",
                    color = MixueWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 2. LARGE DYNAMIC RED-AND-GOLD CARD (Requirement 24)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                MIXUEMemberCard(
                    nickname = profile?.nickname ?: "王小明",
                    level = profile?.level ?: "甜蜜会员",
                    points = profile?.points ?: 1280,
                    growth = profile?.growthValue ?: 350
                )
            }
        }

        // 3. TIER BENEFIT CHECKLIST (Requirement 38)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "👑 会员专属甜蜜权益",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                MIXUECard {
                    val benefits = listOf(
                        Triple(Icons.Filled.Discount, "饮品专享折扣", "会员下单每杯饮品立减 ¥0.50 ~ ¥1.00，价格超级亲民！"),
                        Triple(Icons.Filled.CardTravel, "生日双倍成长", "生日当天任意消费可享双倍雪王币和双倍成长值奖励！"),
                        Triple(Icons.Filled.WorkspacePremium, "新品尝鲜特权", "重磅爆款新品，尊享会员提前认购通道和专属立减尝鲜券！"),
                        Triple(Icons.Filled.CardMembership, "雪王线下店打卡", "支持扫码专属会员核销码，获取线下店连续到访数字勋章！")
                    )

                    benefits.forEachIndexed { idx, item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = item.first,
                                contentDescription = item.second,
                                tint = MixueGold,
                                modifier = Modifier
                                    .padding(top = 2.dp)
                                    .size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = item.second,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MixueBlack
                                )
                                Text(
                                    text = item.third,
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    lineHeight = 15.sp,
                                    modifier = Modifier.padding(top = 1.dp)
                                )
                            }
                        }
                        if (idx < benefits.size - 1) {
                            Divider(color = MixueLightGray, modifier = Modifier.padding(vertical = 4.dp))
                        }
                    }
                }
            }
        }

        // 4. AVAILABLE OWNED COUPONS LIST
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "🎟️ 我已领取的模拟券包 (${availableCoupons.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (availableCoupons.isEmpty()) {
                    MIXUECard {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("您的券包空空的哦，去连续签到领一些吧！", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        availableCoupons.forEach { coupon ->
                            MIXUECouponCard(
                                coupon = coupon,
                                onUseClick = {
                                    viewModel.setTab(1) // switch back to ordering instantly
                                    viewModel.showNotification("已帮您切换至点单！结算时将自动勾选此优惠。")
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
