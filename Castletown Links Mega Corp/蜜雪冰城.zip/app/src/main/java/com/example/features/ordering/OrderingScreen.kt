package com.example.features.ordering

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import java.math.BigDecimal
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.features.viewmodel.MixueViewModel
import com.example.ui.components.*
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderingScreen(
    viewModel: MixueViewModel,
    modifier: Modifier = Modifier
) {
    val selectedStore by viewModel.selectedStore.collectAsState()
    val stores by viewModel.stores.collectAsState()
    val products by viewModel.products.collectAsState()
    val selectedCategory by viewModel.selectedCategory.collectAsState()
    val isDelivery by viewModel.isDelivery.collectAsState()

    // Customize dialog
    val customizingProduct by viewModel.customizingProduct.collectAsState()
    val tempSelection by viewModel.tempSelection.collectAsState()
    val sweetSelection by viewModel.sweetSelection.collectAsState()

    // Cart and pricing
    val cartItems by viewModel.cartItems.collectAsState()
    val priceBreakdown by viewModel.priceBreakdown.collectAsState()
    val availableCoupons by viewModel.availableCoupons.collectAsState()
    val selectedCoupon by viewModel.selectedCoupon.collectAsState()
    val usePointsLedger by viewModel.usePointsLedger.collectAsState()
    val memberProfile by viewModel.memberProfile.collectAsState()

    // Local UI states
    var showStoreSelector by remember { mutableStateOf(false) }
    var showCheckoutSheet by remember { mutableStateOf(false) }
    var showCartDetailPopup by remember { mutableStateOf(false) }

    val categories = listOf("冰鲜柠檬水", "新鲜冰淇淋", "茶饮", "奶茶", "咖啡")

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MixueWarmWhite)
            .testTag("ordering_screen")
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 1. TOP STORE HEADER
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MixueWhite)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { showStoreSelector = true }
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = selectedStore?.name ?: "选择门店",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = MixueBlack
                            )
                            Icon(
                                imageVector = Icons.Filled.ArrowDropDown,
                                contentDescription = "切换门店",
                                tint = MixueRed
                            )
                        }
                        Text(
                            text = "排队中：${selectedStore?.queueCount ?: 0}杯 | 距离您：${selectedStore?.distanceMeter ?: 0}m",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }

                    // Self-pickup/Delivery Toggle Switch
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(18.dp))
                            .background(MixueLightGray)
                            .padding(2.dp)
                    ) {
                        Row {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (!isDelivery) MixueRed else Color.Transparent)
                                    .clickable { viewModel.toggleDelivery(false) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    "自提",
                                    color = if (!isDelivery) MixueWhite else Color.Gray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(if (isDelivery) MixueRed else Color.Transparent)
                                    .clickable { viewModel.toggleDelivery(true) }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    "外卖",
                                    color = if (isDelivery) MixueWhite else Color.Gray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Divider(color = MixueLightGray)

            // 2. TWO-PANE LAYOUT
            Row(modifier = Modifier.weight(1f)) {
                // Left Categories Tab Column
                LazyColumn(
                    modifier = Modifier
                        .width(96.dp)
                        .fillMaxHeight()
                        .background(MixueLightGray)
                ) {
                    items(categories) { cat ->
                        val isSelected = cat == selectedCategory
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { viewModel.selectCategory(cat) }
                                .background(if (isSelected) MixueWarmWhite else Color.Transparent)
                                .padding(vertical = 18.dp, horizontal = 12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .width(4.dp)
                                        .height(20.dp)
                                        .background(MixueRed)
                                        .align(Alignment.CenterStart)
                                )
                            }
                            Text(
                                text = cat,
                                fontSize = 13.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MixueRed else MixueBlack,
                                modifier = Modifier.padding(start = 6.dp)
                            )
                        }
                        Divider(color = Color.White.copy(alpha = 0.5f))
                    }
                }

                // Right Catalog grid
                val filteredProducts = products.filter { it.category == selectedCategory }
                LazyColumn(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            text = selectedCategory,
                            fontSize = 13.sp,
                            color = Color.Gray,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 2.dp)
                        )
                    }

                    if (filteredProducts.isEmpty()) {
                        item {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("该品类暂时下架或调整中...", color = Color.Gray, fontSize = 13.sp)
                            }
                        }
                    } else {
                        items(filteredProducts) { prod ->
                            MIXUEProductCard(
                                name = prod.name,
                                description = prod.description,
                                price = prod.price,
                                memberPrice = prod.memberPrice,
                                discountTag = prod.discountTag,
                                isNew = prod.isNew,
                                isHot = prod.isHot,
                                imageResName = prod.imageResName,
                                stock = prod.stock,
                                onAddClick = { viewModel.quickAddProduct(prod) },
                                onCardClick = { viewModel.startCustomizing(prod) }
                            )
                        }
                    }
                }
            }
        }

        // 3. BOTTOM FLOATING SHOPPING CART BAR
        AnimatedVisibility(
            visible = cartItems.isNotEmpty(),
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 12.dp)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp)
                    .shadow(8.dp, shape = RoundedCornerShape(28.dp))
                    .clip(RoundedCornerShape(28.dp))
                    .background(MixueBlack)
                    .clickable { showCartDetailPopup = true }
                    .padding(horizontal = 18.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        // Badge count bubble
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MixueRed),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "${cartItems.sumOf { it.quantity }}",
                                color = MixueWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Row(verticalAlignment = Alignment.Bottom) {
                                Text("¥", color = MixueWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(
                                    text = priceBreakdown.finalAmount.toString(),
                                    color = MixueWhite,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Black
                                )
                                if (priceBreakdown.memberDiscount > BigDecimal.ZERO) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "已省 ¥${priceBreakdown.memberDiscount}",
                                        color = MixueGold,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                            Text("让全球每个人享受平价美味", color = Color.Gray, fontSize = 9.sp)
                        }
                    }

                    // Proceed to checkout button
                    Button(
                        onClick = { showCheckoutSheet = true },
                        colors = ButtonDefaults.buttonColors(containerColor = MixueRed),
                        shape = RoundedCornerShape(18.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("去结算", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MixueWhite)
                    }
                }
            }
        }

        // 4. DIALOGS & SHEET MODALS (SIMULATION OVERLAYS)

        // 4A. Store Selector Sheet Dialog
        if (showStoreSelector) {
            AlertDialog(
                onDismissRequest = { showStoreSelector = false },
                title = { Text("附近营业门店列表", fontWeight = FontWeight.Bold) },
                text = {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(stores) { st ->
                            MIXUEStoreCard(
                                store = st,
                                onSelectClick = {
                                    viewModel.selectStore(st)
                                    showStoreSelector = false
                                },
                                isSelected = st.id == selectedStore?.id
                            )
                        }
                    }
                },
                confirmButton = {
                    TextButton(onClick = { showStoreSelector = false }) { Text("关闭", color = MixueRed) }
                }
            )
        }

        // 4B. Customized Product Sheet Dialog (Sugar/Ice level specs)
        if (customizingProduct != null) {
            val prod = customizingProduct!!
            val selectedToppings by viewModel.selectedToppings.collectAsState()
            val availableToppings = listOf("珍珠", "椰果", "红豆", "芝士")

            AlertDialog(
                onDismissRequest = { viewModel.dismissCustomizing() },
                confirmButton = {
                    MIXUEButton(
                        text = "加入购物车",
                        onClick = { viewModel.addCustomizedToCart() }
                    )
                },
                dismissButton = {
                    TextButton(onClick = { viewModel.dismissCustomizing() }) {
                        Text("取消", color = Color.Gray)
                    }
                },
                title = {
                    Text(text = prod.name, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(androidx.compose.foundation.rememberScrollState())
                    ) {
                        Text(
                            text = prod.description,
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        // Base price display
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("基础价：", fontSize = 12.sp, color = MixueBlack)
                            MIXUEPrice(price = prod.price)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Temp Select Row
                        Text("温度", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val tempOptions = listOf("正常冰", "少冰", "去冰", "温热")
                            tempOptions.forEach { opt ->
                                val active = opt == tempSelection
                                FilterChip(
                                    selected = active,
                                    onClick = { viewModel.tempSelection.value = opt },
                                    label = { Text(opt, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MixueRed,
                                        selectedLabelColor = MixueWhite
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Sweetness Select Row
                        Text("甜度", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val sweetOptions = listOf("标准糖", "少糖", "微糖", "无糖")
                            sweetOptions.forEach { opt ->
                                val active = opt == sweetSelection
                                FilterChip(
                                    selected = active,
                                    onClick = { viewModel.sweetSelection.value = opt },
                                    label = { Text(opt, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MixueRed,
                                        selectedLabelColor = MixueWhite
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Toppings Select Row
                        Text("添加加料 (每样 +¥1.00)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            availableToppings.forEach { top ->
                                val active = selectedToppings.contains(top)
                                FilterChip(
                                    selected = active,
                                    onClick = { viewModel.toggleTopping(top) },
                                    label = { Text(top, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MixueRed,
                                        selectedLabelColor = MixueWhite
                                    )
                                )
                            }
                        }
                    }
                }
            )
        }

        // 4C. Cart details listing sheet Dialog
        if (showCartDetailPopup) {
            AlertDialog(
                onDismissRequest = { showCartDetailPopup = false },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("已加购物车商品", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        TextButton(onClick = {
                            viewModel.clearCart()
                            showCartDetailPopup = false
                        }) {
                            Text("清空", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                },
                text = {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(cartItems) { item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(item.productName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                    Text(
                                        text = "${item.temperature} / ${item.sweetness}${if (item.toppings.isNotEmpty()) " / +${item.toppings}" else ""}",
                                        fontSize = 11.sp,
                                        color = Color.Gray
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    MIXUEPrice(price = item.price)
                                    Spacer(modifier = Modifier.width(12.dp))
                                    IconButton(
                                        onClick = { viewModel.updateCartQty(item, false) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Filled.RemoveCircleOutline, contentDescription = "减")
                                    }
                                    Text(
                                        "${item.quantity}",
                                        fontSize = 13.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp)
                                    )
                                    IconButton(
                                        onClick = { viewModel.updateCartQty(item, true) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Filled.AddCircleOutline, contentDescription = "加", tint = MixueRed)
                                    }
                                }
                            }
                        }
                    }
                },
                confirmButton = {
                    MIXUEButton(text = "关闭", onClick = { showCartDetailPopup = false })
                }
            )
        }

        // 4D. checkout billing Details overlay sheet (Payment Simulator)
        if (showCheckoutSheet) {
            AlertDialog(
                onDismissRequest = { showCheckoutSheet = false },
                title = {
                    Text(
                        "提交订单（模拟账单及结算）",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                text = {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .verticalScroll(androidx.compose.foundation.rememberScrollState())
                    ) {
                        // Deliver mode metrics
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MixueRedLight, RoundedCornerShape(8.dp))
                                .padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Storefront, contentDescription = "自提", tint = MixueRed)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "取餐门店：「${selectedStore?.name}」\n服务类型：${if (isDelivery) "【外卖配送】" else "【到店自提】"}",
                                fontSize = 12.sp,
                                color = MixueRed,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Choose available coupons
                        Text("🎟️ 使用模拟优惠券", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        if (availableCoupons.isEmpty()) {
                            Text("无可用优惠券", fontSize = 11.sp, color = Color.Gray)
                        } else {
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(1),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(130.dp),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                items(availableCoupons) { coupon ->
                                    val isCurrent = selectedCoupon?.id == coupon.id
                                    MIXUECouponCard(
                                        coupon = coupon,
                                        onUseClick = {
                                            if (isCurrent) {
                                                viewModel.selectCouponForCheckout(null)
                                            } else {
                                                viewModel.selectCouponForCheckout(coupon)
                                            }
                                        },
                                        isSelected = isCurrent
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Points coin use toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("🪙 雪王币抵扣 (100币 = ¥1.00)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    "(余额:${memberProfile?.points ?: 0})",
                                    fontSize = 10.sp,
                                    color = Color.Gray
                                )
                            }
                            Switch(
                                checked = usePointsLedger,
                                onCheckedChange = { viewModel.usePointsLedger.value = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = MixueRed, checkedTrackColor = MixueRedLight)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Price details breakdown (Deterministic Calculation audit check)
                        Text("📊 最终账单明细 (BigDecimal)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(6.dp))
                        MIXUECard(backgroundColor = MixueWarmWhite) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("商品总原价", fontSize = 11.sp, color = Color.Gray)
                                Text("¥${priceBreakdown.subtotal}", fontSize = 11.sp, color = Color.Gray)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("会员半价抵用优惠", fontSize = 11.sp, color = MixueGold)
                                Text("-¥${priceBreakdown.memberDiscount}", fontSize = 11.sp, color = MixueGold)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("优惠券减免", fontSize = 11.sp, color = MixueRed)
                                Text("-¥${priceBreakdown.couponDiscount}", fontSize = 11.sp, color = MixueRed)
                            }
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("雪王币折扣", fontSize = 11.sp, color = Color.DarkGray)
                                Text("-¥${priceBreakdown.pointsDeduction}", fontSize = 11.sp, color = Color.DarkGray)
                            }
                            if (isDelivery) {
                                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Text("外卖配送费", fontSize = 11.sp, color = Color.Gray)
                                    Text("+¥${priceBreakdown.deliveryFee}", fontSize = 11.sp, color = Color.Gray)
                                }
                            }
                            Divider(modifier = Modifier.padding(vertical = 4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("实付款", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MixueBlack)
                                MIXUEPrice(price = priceBreakdown.finalAmount.toString(), fontSize = 18)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Warnings
                        Text(
                            text = "💡 本项目为虚构/合成数字原型，所有支付行为皆为完全模拟，绝不产生真实扣费及实物配送。",
                            color = Color.LightGray,
                            fontSize = 9.sp,
                            lineHeight = 12.sp
                        )
                    }
                },
                confirmButton = {
                    MIXUEButton(
                        text = "微信/支付宝 模拟支付 (¥${priceBreakdown.finalAmount})",
                        onClick = {
                            viewModel.submitCheckout()
                            showCheckoutSheet = false
                        },
                        modifier = Modifier.fillMaxWidth()
                    )
                },
                dismissButton = {
                    TextButton(
                        onClick = { showCheckoutSheet = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("再改改", color = Color.Gray)
                    }
                }
            )
        }
    }
}
