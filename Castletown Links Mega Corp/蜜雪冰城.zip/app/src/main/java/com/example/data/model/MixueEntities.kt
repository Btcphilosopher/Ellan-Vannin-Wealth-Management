package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.math.BigDecimal

@Entity(tableName = "stores")
data class Store(
    @PrimaryKey val id: Int,
    val name: String,
    val address: String,
    val status: String, // "OPEN", "BUSY", "CLOSED"
    val distanceMeter: Int,
    val queueCount: Int,
    val prepTimeMin: Int,
    val latitude: Double,
    val longitude: Double,
    val businessHours: String,
    val phone: String,
    val isFavorite: Boolean = false
)

@Entity(tableName = "products")
data class Product(
    @PrimaryKey val id: Int,
    val name: String,
    val description: String,
    val category: String, // "柠檬水", "冰淇淋", "茶饮", "果茶", "奶茶", "咖啡", "周边"
    val price: String, // stored as String representation of BigDecimal
    val memberPrice: String,
    val isNew: Boolean,
    val isHot: Boolean,
    val isAvailable: Boolean,
    val stock: Int,
    val imageResName: String, // name of synthetic drawable or system icon name
    val salesCount: Int = 0,
    val discountTag: String = ""
)

@Entity(tableName = "cart_items")
data class CartItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val productId: Int,
    val productName: String,
    val price: String,
    val quantity: Int,
    val temperature: String, // "正常冰", "少冰", "去冰", "温热"
    val sweetness: String,   // "标准糖", "少糖", "微糖", "无糖"
    val size: String,        // "标准"
    val toppings: String     // comma separated, e.g. "珍珠,椰果"
)

@Entity(tableName = "orders")
data class Order(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val storeId: Int,
    val storeName: String,
    val orderCode: String, // e.g. "A238"
    val status: String,    // "CREATED", "PENDING_PAYMENT", "PAID", "ACCEPTED", "PREPARING", "READY", "PICKED_UP", "COMPLETED", "CANCELLED"
    val totalAmount: String,
    val subtotal: String,
    val discount: String,
    val pointDeduction: String,
    val deliveryFee: String,
    val isDelivery: Boolean,
    val timestamp: Long,
    val itemsJson: String, // serialized representation of ordered items
    val verificationCode: String, // string representation for QR code
    val isRefunded: Boolean = false
)

@Entity(tableName = "points_ledger")
data class PointsRecord(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val amount: Int, // positive for earn, negative for redeem
    val eventType: String, // "EARN", "REDEEM", "EXPIRE", "ADJUST", "REFUND_REVERSAL", "DONATION"
    val source: String, // e.g., "点单奖励", "每日签到", "公益支持", "兑换周边"
    val referenceId: String, // order id or other ref ID
    val timestamp: Long,
    val balanceAfter: Int
)

@Entity(tableName = "member_profile")
data class MemberProfile(
    @PrimaryKey val id: Int = 1, // single-user app
    val nickname: String,
    val avatarUrl: String,
    val level: String, // "普通会员", "甜蜜会员", "雪王会员", "超级甜蜜会员"
    val points: Int,
    val growthValue: Int,
    val consecutiveSignInDays: Int,
    val lastSignInDate: String, // e.g., "2026-09-15"
    val monthlySpend: String,
    val avatarDecoration: String = "" // Special Snow King avatar frame
)

@Entity(tableName = "coupons")
data class Coupon(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val couponType: String, // "CASH", "DISCOUNT", "NEW_PRODUCT", "FREE_DELIVERY"
    val amount: String,
    val minSpend: String,
    val isUsed: Boolean,
    val expiryDate: String,
    val applicableCategory: String = "ALL"
)

@Entity(tableName = "campaigns")
data class Campaign(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val description: String,
    val bannerImage: String,
    val startDate: String,
    val endDate: String,
    val type: String, // "SUMMER", "NEW_PRODUCT", "SIGN_IN"
    val status: String // "ACTIVE", "COMPLETED"
)

@Entity(tableName = "mall_products")
data class MallProduct(
    @PrimaryKey val id: Int,
    val name: String,
    val description: String,
    val price: String,
    val pointsPrice: Int,
    val isPointsOnly: Boolean,
    val imageResName: String,
    val stock: Int
)
