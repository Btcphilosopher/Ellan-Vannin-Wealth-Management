package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MixueRed = Color(0xFFFF1A30)
val MixueRedDark = Color(0xFFCC0012)
val MixueRedLight = Color(0xFFFFECEE)
val MixueWhite = Color(0xFFFFFFFF)
val MixueBlack = Color(0xFF111111)
val MixueWarmWhite = Color(0xFFFAF6F0)
val MixueGold = Color(0xFFFFC107)
val MixueGreenAccent = Color(0xFF00C853)
val MixueGray = Color(0xFF666666)
val MixueLightGray = Color(0xFFF5F5F5)

// Keeping old variables for fallback/reference if used elsewhere
val Purple80 = MixueRedLight
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = MixueGold

val Purple40 = MixueRed
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = MixueRedDark

