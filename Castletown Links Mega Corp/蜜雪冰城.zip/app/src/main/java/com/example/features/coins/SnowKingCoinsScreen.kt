package com.example.features.coins

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.features.viewmodel.MixueViewModel
import com.example.ui.components.MIXUEButton
import com.example.ui.components.MIXUECard
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date

@Composable
fun SnowKingCoinsScreen(
    viewModel: MixueViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.memberProfile.collectAsState()
    val ledger by viewModel.pointsLedger.collectAsState()
    val mallProducts by viewModel.mallProducts.collectAsState()
    val miniGameScore by viewModel.miniGameScore.collectAsState()
    val miniGamePlaying by viewModel.miniGamePlaying.collectAsState()

    var showLedgerDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MixueWarmWhite)
            .testTag("coins_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // 1. HEADER COIN BANNER
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(MixueRed, MixueRedDark)
                        )
                    )
                    .statusBarsPadding()
                    .padding(18.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "我的雪王币 🪙",
                        color = MixueWhite.copy(alpha = 0.85f),
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${profile?.points ?: 0}",
                        color = MixueGold,
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Black
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "雪王币可用于兑换专属无门槛优惠券及雪王激萌限定周边！",
                        color = MixueWhite.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = { showLedgerDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MixueWhite, contentColor = MixueRed),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.height(32.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp)
                        ) {
                            Icon(Icons.Filled.ListAlt, contentDescription = "明细", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("收支明细", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.triggerDailySignIn() },
                            colors = ButtonDefaults.buttonColors(containerColor = MixueGold, contentColor = MixueBlack),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.height(32.dp),
                            contentPadding = PaddingValues(horizontal = 14.dp)
                        ) {
                            Icon(Icons.Filled.EventAvailable, contentDescription = "签到", modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("每日签到", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // 2. DAILY SIGN-IN CALENDAR CALENDAR PROGRESS (Requirement 31)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "📅 签到领福利",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                MIXUECard {
                    val streak = profile?.consecutiveSignInDays ?: 0
                    val todayStr = SimpleDateFormat("yyyy-MM-dd").format(Date())
                    val alreadySignedInToday = profile?.lastSignInDate == todayStr

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (alreadySignedInToday) "今日已签到！" else "今日未签到",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MixueRed
                            )
                            Text(
                                text = "连续签到第 ${streak} 天",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }

                        // Giant sign in stamp button
                        Button(
                            onClick = { viewModel.triggerDailySignIn() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (alreadySignedInToday) Color.LightGray else MixueRed,
                                contentColor = MixueWhite
                            ),
                            shape = RoundedCornerShape(20.dp),
                            enabled = !alreadySignedInToday
                        ) {
                            Text(if (alreadySignedInToday) "已签到" else "立即签到", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Simulated 7 day calendar
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        val days = listOf("1天", "2天", "3天", "4天", "5天", "6天", "7天")
                        days.forEachIndexed { idx, label ->
                            val isCompleted = streak > idx
                            val isMegaDay = idx == 2 || idx == 6

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                modifier = Modifier
                                    .weight(1f)
                                    .padding(horizontal = 2.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (isCompleted) MixueRed else if (isMegaDay) MixueGold.copy(alpha = 0.2f) else MixueLightGray
                                        )
                                        .border(
                                            1.dp,
                                            if (isMegaDay) MixueGold else Color.Transparent,
                                            CircleShape
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isCompleted) {
                                        Icon(Icons.Filled.Check, contentDescription = "完成", tint = MixueWhite, modifier = Modifier.size(16.dp))
                                    } else {
                                        Text(
                                            text = if (idx == 2) "+30" else if (idx == 6) "+100" else "+10",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = if (isMegaDay) MixueGold else Color.Gray
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(label, fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "💡 提示：连续签到3天和7天，雪王将分别送出【半价折扣券】及【5元无门槛现金券】哦！",
                        fontSize = 9.sp,
                        color = Color.LightGray,
                        lineHeight = 12.sp
                    )
                }
            }
        }

        // 3. MINI-GAME MODULE: "雪王送甜蜜" (Requirement 33)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "🎮 趣味小游戏: 雪王送甜蜜",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                MIXUECard {
                    if (!miniGamePlaying) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "👑 雪王快乐点击大赛",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = MixueBlack
                            )
                            Text(
                                text = "帮助雪王摇晃调制冰爽饮料！快速点击瓶身满 15 次，就能赢取 🪙 150 雪王币 奖励哦！快来挑战吧！",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                            Button(
                                onClick = { viewModel.startMiniGame() },
                                colors = ButtonDefaults.buttonColors(containerColor = MixueRed)
                            ) {
                                Text("立即挑战", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "冲啊！疯狂摇晃瓶子！",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = MixueRed
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            // Shake cup illustration
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .background(MixueRedLight)
                                    .clickable { viewModel.playMiniGameTap() },
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🥤", fontSize = 44.sp)
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "当前摇晃次数: $miniGameScore / 15",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = MixueBlack
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            LinearProgressIndicator(
                                progress = { miniGameScore.toFloat() / 15f },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = MixueRed,
                                trackColor = MixueLightGray
                            )
                        }
                    }
                }
            }
        }

        // 4. PERIPHERAL MERCHANDISE SHOP (Requirement 36)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "🎁 雪王周边积分兑换中心",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                LazyVerticalGrid(
                    columns = GridCells.Fixed(1),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(340.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(mallProducts) { item ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MixueWhite),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Product Icon Placeholder
                                Box(
                                    modifier = Modifier
                                        .size(64.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MixueWarmWhite),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = when (item.id) {
                                            501 -> "🥤"
                                            502 -> "🧦"
                                            503 -> "🧸"
                                            else -> "🎁"
                                        },
                                        fontSize = 32.sp
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.name,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MixueBlack
                                    )
                                    Text(
                                        text = item.description,
                                        fontSize = 10.sp,
                                        color = Color.Gray,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )

                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Row(verticalAlignment = Alignment.Bottom) {
                                            Text(
                                                text = "🪙 ${item.pointsPrice}",
                                                color = MixueRed,
                                                fontSize = 15.sp,
                                                fontWeight = FontWeight.Black
                                            )
                                            if (!item.isPointsOnly) {
                                                Text(
                                                    text = " + ¥${item.price}",
                                                    color = Color.Gray,
                                                    fontSize = 11.sp
                                                )
                                            }
                                        }

                                        // Redeem trigger button
                                        Button(
                                            onClick = { viewModel.redeemMallProduct(item) },
                                            colors = ButtonDefaults.buttonColors(containerColor = MixueGold, contentColor = MixueBlack),
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier.height(28.dp),
                                            contentPadding = PaddingValues(horizontal = 10.dp)
                                        ) {
                                            Text("立即兑换", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // 5. LEDGER TRANSACTIONS HISTORY DIALOG Dialog
    if (showLedgerDialog) {
        AlertDialog(
            onDismissRequest = { showLedgerDialog = false },
            title = { Text("雪王币收支电子明细账本", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                if (ledger.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(100.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("暂无收支明细哦", color = Color.Gray)
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(ledger) { record ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(record.source, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(Date(record.timestamp))
                                    Text(dateStr, fontSize = 10.sp, color = Color.LightGray)
                                }

                                Column(horizontalAlignment = Alignment.End) {
                                    val isAdd = record.amount > 0
                                    Text(
                                        text = if (isAdd) "+${record.amount}" else "${record.amount}",
                                        color = if (isAdd) MixueGreenAccent else MixueRed,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.ExtraBold
                                    )
                                    Text(
                                        text = "余额: ${record.balanceAfter}",
                                        fontSize = 9.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                            Divider(color = MixueLightGray, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            },
            confirmButton = {
                MIXUEButton(text = "关闭", onClick = { showLedgerDialog = false })
            }
        )
    }
}
