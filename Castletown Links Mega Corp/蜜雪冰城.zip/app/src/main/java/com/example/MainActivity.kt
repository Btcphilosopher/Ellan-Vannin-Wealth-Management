package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.features.coins.SnowKingCoinsScreen
import com.example.features.home.HomeScreen
import com.example.features.membership.MembershipScreen
import com.example.features.ordering.OrderingScreen
import com.example.features.profile.MyProfileScreen
import com.example.features.viewmodel.MixueViewModel
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MixueAppScaffolding()
            }
        }
    }
}

@Composable
fun MixueAppScaffolding(
    viewModel: MixueViewModel = viewModel()
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val notification by viewModel.notification.collectAsState()
    val cartItems by viewModel.cartItems.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        bottomBar = {
            NavigationBar(
                containerColor = MixueWhite,
                tonalElevation = 8.dp,
                modifier = Modifier
                    .height(68.dp)
                    .testTag("mixue_bottom_bar")
            ) {
                val tabs = listOf(
                    Triple("首页", Icons.Filled.Home, 0),
                    Triple("点单", Icons.Filled.LocalCafe, 1),
                    Triple("雪王币", Icons.Filled.Stars, 2),
                    Triple("会员", Icons.Filled.CardMembership, 3),
                    Triple("我的", Icons.Filled.AccountCircle, 4)
                )

                tabs.forEach { (label, icon, index) ->
                    val isSelected = currentTab == index
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.setTab(index) },
                        icon = {
                            Box {
                                Icon(
                                    imageVector = icon,
                                    contentDescription = label,
                                    tint = if (isSelected) MixueRed else Color.Gray,
                                    modifier = Modifier.size(24.dp)
                                )

                                // Cart counter badge on "点单" tab
                                if (index == 1 && cartItems.isNotEmpty()) {
                                    val count = cartItems.sumOf { it.quantity }
                                    Box(
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .offset(x = 10.dp, y = (-6).dp)
                                            .size(16.dp)
                                            .clip(androidx.compose.foundation.shape.CircleShape)
                                            .background(MixueRed),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = "$count",
                                            color = MixueWhite,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        },
                        label = {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) MixueRed else Color.Gray
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = MixueRedLight
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = innerPadding.calculateBottomPadding())
        ) {
            // Main content transition
            when (currentTab) {
                0 -> HomeScreen(viewModel = viewModel)
                1 -> OrderingScreen(viewModel = viewModel)
                2 -> SnowKingCoinsScreen(viewModel = viewModel)
                3 -> MembershipScreen(viewModel = viewModel)
                4 -> MyProfileScreen(viewModel = viewModel)
                else -> HomeScreen(viewModel = viewModel)
            }

            // Global floating alert toast notification
            AnimatedVisibility(
                visible = notification != null,
                enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
                exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .statusBarsPadding()
                    .padding(top = 16.dp, start = 16.dp, end = 16.dp)
            ) {
                notification?.let { msg ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.clearNotification() }
                            .testTag("notification_toast"),
                        colors = CardDefaults.cardColors(containerColor = MixueRed),
                        shape = RoundedCornerShape(12.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "❄️",
                                fontSize = 18.sp,
                                modifier = Modifier.padding(end = 10.dp)
                            )
                            Text(
                                text = msg,
                                color = MixueWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "关闭",
                                tint = MixueWhite.copy(alpha = 0.8f),
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
