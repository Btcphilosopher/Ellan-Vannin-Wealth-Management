package com.example.features.profile

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Order
import com.example.features.viewmodel.MixueViewModel
import com.example.ui.components.MIXUEButton
import com.example.ui.components.MIXUECard
import com.example.ui.components.MIXUESnowKingCard
import com.example.ui.theme.*

@Composable
fun MyProfileScreen(
    viewModel: MixueViewModel,
    modifier: Modifier = Modifier
) {
    val profile by viewModel.memberProfile.collectAsState()
    val orders by viewModel.orders.collectAsState()
    val activeOrder by viewModel.currentActiveOrder.collectAsState()
    val activeStatus by viewModel.orderTimelineStatus.collectAsState()

    // Chat bot bindings
    val chatHistory by viewModel.chatHistory.collectAsState()
    val chatInputText by viewModel.chatInputText.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MixueWarmWhite)
            .testTag("profile_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // 1. PROFILE PROFILE HEADER
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MixueRed)
                    .statusBarsPadding()
                    .padding(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(MixueWhite),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("❄️", fontSize = 34.sp)
                    }

                    Spacer(modifier = Modifier.width(16.dp))

                    Column {
                        Text(
                            text = profile?.nickname ?: "王小明",
                            color = MixueWhite,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Row(modifier = Modifier.padding(top = 4.dp)) {
                            Box(
                                modifier = Modifier
                                    .background(MixueGold, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = profile?.level ?: "甜蜜会员",
                                    color = MixueBlack,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. ACTIVE ORDER STATUS PROGRESS PATH (Requirement 18, 19)
        item {
            AnimatedVisibility(
                visible = activeOrder != null && activeOrder?.status != "COMPLETED",
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "🔔 实时排队制作进度",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MixueRed,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    MIXUECard(borderColor = MixueRed) {
                        val ord = activeOrder ?: return@MIXUECard
                        Text(
                            text = ord.storeName,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = MixueBlack
                        )
                        Text(
                            text = "取餐单号: ${ord.orderCode} | 类型: ${if (ord.isDelivery) "外卖配送" else "到店自取"}",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // PROGRESS TIMELINE VIEW
                        val steps = listOf("PAID" to "已付", "ACCEPTED" to "接单", "PREPARING" to "制作中", "READY" to "待取餐")
                        val activeIdx = steps.indexOfFirst { it.first == activeStatus }.coerceAtLeast(0)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            steps.forEachIndexed { idx, step ->
                                val active = idx <= activeIdx
                                Column(
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .clip(CircleShape)
                                            .background(if (active) MixueRed else MixueLightGray),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (active) {
                                            Icon(Icons.Filled.Check, contentDescription = "完成", tint = MixueWhite, modifier = Modifier.size(14.dp))
                                        } else {
                                            Text("${idx + 1}", color = Color.Gray, fontSize = 10.sp)
                                        }
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = step.second,
                                        fontSize = 11.sp,
                                        color = if (active) MixueRed else Color.Gray,
                                        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal
                                    )
                                }

                                if (idx < steps.size - 1) {
                                    Box(
                                        modifier = Modifier
                                            .height(2.dp)
                                            .weight(0.5f)
                                            .background(if (idx < activeIdx) MixueRed else MixueLightGray)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // QR CODE VERIFICATION BLOCK (QR code scan simulation)
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Barcode Box
                            Box(
                                modifier = Modifier
                                    .size(120.dp)
                                    .border(1.dp, Color.LightGray, RoundedCornerShape(8.dp))
                                    .background(MixueWarmWhite),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.QrCode2,
                                    contentDescription = "取餐核销二维码",
                                    tint = MixueBlack,
                                    modifier = Modifier.size(90.dp)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "取餐码：${ord.orderCode}",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Black,
                                color = MixueRed
                            )
                            Text(
                                text = "在柜台向店员出示此二维码即可取餐",
                                fontSize = 10.sp,
                                color = Color.Gray
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Scan Button Simulation
                            MIXUEButton(
                                text = "店员模拟扫码完成取餐核销",
                                onClick = { viewModel.simulateQRPickup() },
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }

        // 3. AI CHAT BOT ASSISTANT VIEW (Requirement 42)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "💬 AI 雪王智能小助手",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                MIXUECard(borderColor = MixueGold) {
                    // Speech history container
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .background(MixueWarmWhite, RoundedCornerShape(8.dp))
                            .border(1.dp, MixueLightGray, RoundedCornerShape(8.dp))
                            .padding(10.dp)
                    ) {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(chatHistory) { msg ->
                                val isKing = msg.first == "AI_KING"
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = if (isKing) Arrangement.Start else Arrangement.End
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(12.dp))
                                            .background(if (isKing) MixueWhite else MixueRed)
                                            .border(
                                                1.dp,
                                                if (isKing) MixueGold else Color.Transparent,
                                                RoundedCornerShape(12.dp)
                                            )
                                            .padding(8.dp)
                                            .widthIn(max = 200.dp)
                                    ) {
                                        Text(
                                            text = msg.second,
                                            fontSize = 11.sp,
                                            color = if (isKing) MixueBlack else MixueWhite,
                                            lineHeight = 15.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Input Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextField(
                            value = chatInputText,
                            onValueChange = { viewModel.chatInputText.value = it },
                            placeholder = { Text("输入 '最近门店', '雪王币', '柠檬水'", fontSize = 11.sp) },
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp),
                            textStyle = TextStyle(fontSize = 12.sp),
                            shape = RoundedCornerShape(22.dp),
                            colors = TextFieldDefaults.colors(
                                focusedContainerColor = MixueWarmWhite,
                                unfocusedContainerColor = MixueWarmWhite,
                                disabledContainerColor = MixueWarmWhite,
                                focusedIndicatorColor = Color.Transparent,
                                unfocusedIndicatorColor = Color.Transparent
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        IconButton(
                            onClick = { viewModel.sendAssistantMessage() },
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(MixueRed)
                        ) {
                            Icon(Icons.Filled.Send, contentDescription = "发送", tint = MixueWhite, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        }

        // 4. HISTORIC ORDERS LIST (Requirement 44, 45)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "📜 我的模拟历史账单",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                if (orders.isEmpty()) {
                    MIXUECard {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(80.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("暂无任何订单记录哦，快去点单吧！", color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        orders.forEach { ord ->
                            MIXUECard {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(ord.storeName, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        val dateStr = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(ord.timestamp))
                                        Text(dateStr, fontSize = 10.sp, color = Color.LightGray)
                                    }

                                    // Completed status tag
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(
                                                if (ord.status == "COMPLETED") MixueGreenAccent.copy(alpha = 0.15f) else MixueRedLight
                                            )
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = when (ord.status) {
                                                "COMPLETED" -> "交易成功"
                                                "PAID" -> "已付款"
                                                "ACCEPTED" -> "门店已接单"
                                                "PREPARING" -> "制作中"
                                                "READY" -> "待取餐"
                                                else -> ord.status
                                            },
                                            color = if (ord.status == "COMPLETED") MixueGreenAccent else MixueRed,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }

                                Divider(color = MixueLightGray, modifier = Modifier.padding(vertical = 8.dp))

                                // Simple items list display from serialized JSON format
                                Text(
                                    text = if (ord.itemsJson.contains("冰鲜柠檬水")) "冰鲜柠檬水 x 1 (少冰, 少糖, 珍珠)" else "经典招牌饮品组合",
                                    fontSize = 12.sp,
                                    color = Color.DarkGray
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("总额 ¥${ord.subtotal}", fontSize = 11.sp, color = Color.Gray)
                                        if (ord.discount != "0.00") {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("优惠 ¥${ord.discount}", fontSize = 11.sp, color = MixueRed)
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("实付: ¥${ord.totalAmount}", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = MixueBlack)
                                    }

                                    // "Reorder" Button (再来一杯)
                                    Button(
                                        onClick = { viewModel.repeatLastOrder(ord) },
                                        colors = ButtonDefaults.buttonColors(containerColor = MixueRed),
                                        shape = RoundedCornerShape(14.dp),
                                        modifier = Modifier.height(28.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp)
                                    ) {
                                        Text("再来一杯", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
