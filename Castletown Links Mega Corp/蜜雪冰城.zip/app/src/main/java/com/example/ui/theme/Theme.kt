package com.example.ui.theme

import android.os.Build
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = MixueRed,
    onPrimary = MixueWhite,
    secondary = MixueGold,
    onSecondary = MixueBlack,
    tertiary = MixueRedLight,
    background = MixueBlack,
    surface = Color(0xFF1E1E1E),
    onBackground = MixueWhite,
    onSurface = MixueWhite,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = MixueRed,
    onPrimary = MixueWhite,
    secondary = MixueGold,
    onSecondary = MixueBlack,
    tertiary = MixueRedDark,
    background = MixueWarmWhite,
    surface = MixueWhite,
    onBackground = MixueBlack,
    onSurface = MixueBlack,
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  // For Mixue's strong brand identity, we prefer our custom theme over dynamic system color
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme =
    when {
      dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
        val context = LocalContext.current
        if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
      }

      darkTheme -> DarkColorScheme
      else -> LightColorScheme
    }

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
