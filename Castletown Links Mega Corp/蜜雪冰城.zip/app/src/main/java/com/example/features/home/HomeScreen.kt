package com.example.features.home

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.features.viewmodel.MixueViewModel
import com.example.ui.components.MIXUEButton
import com.example.ui.components.MIXUECard
import com.example.ui.components.MIXUESnowKingCard
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    viewModel: MixueViewModel,
    modifier: Modifier = Modifier
) {
    val selectedStore by viewModel.selectedStore.collectAsState()
    val memberProfile by viewModel.memberProfile.collectAsState()
    val isPeakHour by viewModel.isPeakHourCongestion.collectAsState()
    val isLowStock by viewModel.isLemonadeLowStock.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(MixueWarmWhite)
            .testTag("home_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // 1. BRAND HEADER BLOCK
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(MixueRed, MixueRedDark)
                        )
                    )
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Location Indicator
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            viewModel.showNotification("模拟GPS：已刷新附近门店列表！")
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Filled.LocationOn,
                            contentDescription = "定位",
                            tint = MixueWhite,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "上海人民广场 ▼",
                            color = MixueWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Top brand title
                    Text(
                        text = "蜜雪冰城",
                        color = MixueWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 1.sp
                    )

                    // Messages & Assistance shortcut
                    Row {
                        IconButton(
                            onClick = {
                                viewModel.setTab(4) // Navigate to My Profile
                                viewModel.showNotification("欢迎咨询客服！AI雪王随时待命。")
                            }
                        ) {
                            Icon(
                                imageVector = Icons.Filled.SupportAgent,
                                contentDescription = "雪王助手",
                                tint = MixueWhite
                            )
                        }
                    }
                }
            }
        }

        // 2. HERO SLIDING BANNER & MOTTO
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(MixueRedDark, MixueWarmWhite)
                        )
                    )
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .clip(RoundedCornerShape(16.dp))
                        .background(
                            Brush.linearGradient(
                                colors = listOf(Color(0xFFFF5252), MixueRed)
                            )
                        )
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Box(
                                modifier = Modifier
                                    .background(MixueGold, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "雪王夏日甜蜜季 🍦",
                                    color = MixueBlack,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "今天，也要甜一点",
                                color = MixueWhite,
                                fontSize = 22.sp,
                                fontWeight = FontWeight.Black
                            )
                            Text(
                                text = "满15减3限时领 / 柠檬水4元特惠",
                                color = MixueWhite.copy(alpha = 0.9f),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }

                        // Big snow king graphic
                        Text(
                            text = "👑\n❄️",
                            fontSize = 42.sp,
                            lineHeight = 46.sp
                        )
                    }
                }
            }
        }

        // 3. MASTER DEMO SIMULATOR DECK (Requirement 80 to 84)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "🛠️ 蜜雪数字平台 · 仿真控制台",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueRed,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MixueWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = "点击以下任何Master Demo，全链路自动流转沙盒数据与状态：",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(bottom = 10.dp)
                        )

                        // Top buttons grid
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = { viewModel.runMasterDemoJourney1() },
                                colors = ButtonDefaults.buttonColors(containerColor = MixueRed),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("① 王小明全链路", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Button(
                                onClick = { viewModel.runMasterDemoNewProductRelease() },
                                colors = ButtonDefaults.buttonColors(containerColor = MixueRed),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("② 草莓雪顶新品", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = { viewModel.runMasterDemoSummerCampaign() },
                                colors = ButtonDefaults.buttonColors(containerColor = MixueRed),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("③ 开启甜蜜季", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Button(
                                onClick = { viewModel.runMasterDemoPeakHourCongestion() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isPeakHour) Color.DarkGray else MixueRed
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("④ 模拟午高峰", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = { viewModel.runMasterDemoLowStock() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isLowStock) Color.DarkGray else MixueRed
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("⑤ 模拟缺货智能推荐", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Button(
                                onClick = { viewModel.resetAllMasterDemos() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.LightGray, contentColor = MixueBlack),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(34.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("🔄 重置沙盒", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // 4. INSTANT ORDER PORTAL CARD (自提外卖双快捷)
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MixueWhite),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Filled.Storefront,
                                        contentDescription = "门店",
                                        tint = MixueRed,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = selectedStore?.name ?: "正在选择门店...",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MixueBlack
                                    )
                                }
                                Text(
                                    text = "距离您 ${selectedStore?.distanceMeter ?: 0}米 | 预计制作时间 ${selectedStore?.prepTimeMin ?: 0}分钟",
                                    fontSize = 11.sp,
                                    color = Color.Gray,
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }

                            // Store Navigation Action Arrow
                            IconButton(
                                onClick = { viewModel.setTab(1) } // Navigate to ordering Store Map/List
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.ArrowForwardIos,
                                    contentDescription = "选择门店",
                                    tint = Color.LightGray,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }

                        Divider(modifier = Modifier.padding(vertical = 12.dp), color = MixueLightGray)

                        // Delivery Select Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            // Self-Pickup Button
                            Card(
                                onClick = {
                                    viewModel.toggleDelivery(false)
                                    viewModel.setTab(1)
                                    viewModel.showNotification("已选择自提")
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(64.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MixueRedLight)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.Center,
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Filled.DirectionsWalk, contentDescription = "自提", tint = MixueRed)
                                    Text("到店自取", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MixueRed)
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            // Delivery Button
                            Card(
                                onClick = {
                                    viewModel.toggleDelivery(true)
                                    viewModel.setTab(1)
                                    viewModel.showNotification("已选择外卖配送")
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(64.dp),
                                shape = RoundedCornerShape(10.dp),
                                colors = CardDefaults.cardColors(containerColor = MixueRedLight)
                            ) {
                                Column(
                                    modifier = Modifier.fillMaxSize(),
                                    verticalArrangement = Arrangement.Center,
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Icon(Icons.Filled.DeliveryDining, contentDescription = "外卖", tint = MixueRed)
                                    Text("外卖配送", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = MixueRed)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 5. CAMPAIGN BANNERS & BRAND STORY (Requirement 35)
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "🏆 热门新品推荐",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack
                )
                Spacer(modifier = Modifier.height(8.dp))

                // Scroll list
                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        MIXUECard(
                            modifier = Modifier
                                .width(140.dp)
                                .clickable {
                                    viewModel.setTab(1)
                                    viewModel.selectCategory("冰鲜柠檬水")
                                }
                        ) {
                            Text("🍋", fontSize = 34.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("冰鲜柠檬水", fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("当季切片, 酷爽柠檬", fontSize = 10.sp, color = Color.Gray, maxLines = 1)
                            Text("¥4.00", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = MixueRed)
                        }
                    }
                    item {
                        MIXUECard(
                            modifier = Modifier
                                .width(140.dp)
                                .clickable {
                                    viewModel.setTab(1)
                                    viewModel.selectCategory("新鲜冰淇淋")
                                }
                        ) {
                            Text("🍦", fontSize = 34.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("新鲜冰淇淋", fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("奶香细腻, 丝滑华夫", fontSize = 10.sp, color = Color.Gray, maxLines = 1)
                            Text("¥3.00", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = MixueRed)
                        }
                    }
                    item {
                        MIXUECard(
                            modifier = Modifier
                                .width(140.dp)
                                .clickable {
                                    viewModel.setTab(1)
                                    viewModel.selectCategory("新鲜冰淇淋")
                                }
                        ) {
                            Text("🍓", fontSize = 34.sp, modifier = Modifier.align(Alignment.CenterHorizontally))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("草莓摇摇奶昔", fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            Text("草莓果肉 疯狂摇一摇", fontSize = 10.sp, color = Color.Gray, maxLines = 1)
                            Text("¥6.00", fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, color = MixueRed)
                        }
                    }
                }
            }
        }

        // 6. SNOW KING SAYINGS IN BUBBLE
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Text(
                    text = "❄️ 雪王动态",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack
                )
                MIXUESnowKingCard(
                    speech = "哈罗！主子好！听说多喝柠檬水，好运天天来哦！雪王的人民广场旗舰店目前排队很空哦，快快安排上吧！"
                )
            }
        }

        // 7. BRAND MAGAZINE CORNER
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "📖 蜜雪品牌杂志",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = MixueBlack
                )
                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MixueRed)
                        .padding(16.dp)
                ) {
                    Column {
                        Text(
                            text = "如何做一杯最棒的柠檬水？",
                            color = MixueWhite,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "蜜雪冰城坚守：挑选来自高海拔、日照充足的柠檬，并在进店的48小时内纯手工切片，这样才能爆发出完美的清新果香。配合古法熬制冰糖，酸甜一绝！",
                            color = MixueWhite.copy(alpha = 0.85f),
                            fontSize = 11.sp,
                            lineHeight = 16.sp,
                            modifier = Modifier.padding(top = 6.dp)
                        )
                    }
                }
            }
        }
    }
}
