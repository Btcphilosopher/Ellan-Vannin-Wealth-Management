package com.example.data.repository

import com.example.data.database.MixueDao
import com.example.data.model.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flow
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class MixueRepository(private val dao: MixueDao) {

    // Member Flow
    val memberProfile: Flow<MemberProfile?> = dao.getMemberProfile()

    // Store Flows
    val allStores: Flow<List<Store>> = dao.getAllStores()

    // Product Flows
    val allProducts: Flow<List<Product>> = dao.getAllProducts()

    // Cart Flows
    val cartItems: Flow<List<CartItem>> = dao.getCartItems()

    // Orders Flow
    val allOrders: Flow<List<Order>> = dao.getAllOrders()

    // Coupon Flow
    val availableCoupons: Flow<List<Coupon>> = dao.getAvailableCoupons()

    // Campaigns
    val allCampaigns: Flow<List<Campaign>> = dao.getAllCampaigns()

    // Mall Products
    val mallProducts: Flow<List<MallProduct>> = dao.getMallProducts()

    // Points Ledger
    val pointsLedger: Flow<List<PointsRecord>> = dao.getPointsLedger()

    // Store operations
    suspend fun getStoreById(id: Int): Store? = dao.getStoreById(id)
    suspend fun updateStore(store: Store) = dao.updateStore(store)

    // Product operations
    suspend fun getProductById(id: Int): Product? = dao.getProductById(id)
    suspend fun updateProduct(product: Product) = dao.updateProduct(product)
    suspend fun insertProducts(products: List<Product>) = dao.insertProducts(products)

    // Member profile operations
    suspend fun updateMemberProfile(profile: MemberProfile) = dao.updateMemberProfile(profile)
    suspend fun insertPointsRecord(record: PointsRecord) = dao.insertPointsRecord(record)

    // Cart Operations
    suspend fun addToCart(item: CartItem) = dao.addToCart(item)
    suspend fun updateCartItem(item: CartItem) = dao.updateCartItem(item)
    suspend fun deleteCartItem(id: Int) = dao.deleteCartItem(id)
    suspend fun clearCart() = dao.clearCart()

    // Order operations
    suspend fun getOrderById(id: Int): Order? = dao.getOrderById(id)
    suspend fun updateOrder(order: Order) = dao.updateOrder(order)

    // Coupon operations
    suspend fun claimCoupon(coupon: Coupon) = dao.insertCoupons(listOf(coupon.copy(isUsed = false)))
    suspend fun useCoupon(couponId: Int) {
        val all = availableCoupons.first()
        val match = all.find { it.id == couponId }
        if (match != null) {
            dao.updateCoupon(match.copy(isUsed = true))
        }
    }

    // ----------------------------------------------------
    // 1. Cart Pricing Engine (with Decimal/BigDecimal calculations)
    // ----------------------------------------------------
    data class PriceBreakdown(
        val subtotal: BigDecimal,
        val memberDiscount: BigDecimal,
        val couponDiscount: BigDecimal,
        val pointsDeduction: BigDecimal,
        val deliveryFee: BigDecimal,
        val finalAmount: BigDecimal
    )

    suspend fun calculateCartPrice(
        isDelivery: Boolean,
        selectedCouponId: Int?,
        redeemPoints: Boolean
    ): PriceBreakdown {
        val items = cartItems.first()
        val profile = dao.getMemberProfileSync()

        var subtotal = BigDecimal.ZERO
        var memberDiscount = BigDecimal.ZERO

        for (item in items) {
            val basePrice = BigDecimal(item.price)
            val qty = BigDecimal(item.quantity)

            // Calculate standard price subtotal
            subtotal = subtotal.add(basePrice.multiply(qty))

            // Member price is usually slightly lower (e.g. 0.50 off per beverage)
            val itemProduct = dao.getProductById(item.productId)
            if (itemProduct != null) {
                val std = BigDecimal(itemProduct.price)
                val mem = BigDecimal(itemProduct.memberPrice)
                val diff = std.subtract(mem)
                if (diff > BigDecimal.ZERO) {
                    memberDiscount = memberDiscount.add(diff.multiply(qty))
                }
            }
        }

        // Apply coupon discount if selected
        var couponDiscount = BigDecimal.ZERO
        if (selectedCouponId != null) {
            val coupons = availableCoupons.first()
            val coupon = coupons.find { it.id == selectedCouponId }
            if (coupon != null) {
                val couponVal = BigDecimal(coupon.amount)
                val minSpend = BigDecimal(coupon.minSpend)
                if (subtotal.subtract(memberDiscount) >= minSpend) {
                    couponDiscount = couponVal
                }
            }
        }

        // Points (雪王币) redemption
        // Formula: 100 points = 1.00 Yuan discount. Max deduction: cannot make total negative
        var pointsDeduction = BigDecimal.ZERO
        if (redeemPoints && profile != null && profile.points > 0) {
            val spendableAmount = subtotal.subtract(memberDiscount).subtract(couponDiscount)
            if (spendableAmount > BigDecimal.ZERO) {
                // Determine max points to use
                val maxYuanByPoints = profile.points.toBigDecimal().divide(BigDecimal("100"), 2, RoundingMode.HALF_UP)
                pointsDeduction = if (maxYuanByPoints >= spendableAmount) {
                    spendableAmount
                } else {
                    maxYuanByPoints
                }
            }
        }

        // Delivery fee (3.00 Yuan unless free delivery coupon is applied)
        var deliveryFee = BigDecimal.ZERO
        if (isDelivery) {
            deliveryFee = BigDecimal("3.00")
            if (selectedCouponId != null) {
                val coupons = availableCoupons.first()
                val coupon = coupons.find { it.id == selectedCouponId }
                if (coupon != null && coupon.couponType == "FREE_DELIVERY") {
                    deliveryFee = BigDecimal.ZERO
                    couponDiscount = BigDecimal("3.00") // standard delivery cost offset
                }
            }
        }

        // Final Amount calculation (subtotal - memberDiscount - couponDiscount - pointsDeduction + deliveryFee)
        var finalAmount = subtotal
            .subtract(memberDiscount)
            .subtract(couponDiscount)
            .subtract(pointsDeduction)
            .add(deliveryFee)

        if (finalAmount < BigDecimal.ZERO) {
            finalAmount = BigDecimal.ZERO
        }

        return PriceBreakdown(
            subtotal = subtotal.setScale(2, RoundingMode.HALF_UP),
            memberDiscount = memberDiscount.setScale(2, RoundingMode.HALF_UP),
            couponDiscount = couponDiscount.setScale(2, RoundingMode.HALF_UP),
            pointsDeduction = pointsDeduction.setScale(2, RoundingMode.HALF_UP),
            deliveryFee = deliveryFee.setScale(2, RoundingMode.HALF_UP),
            finalAmount = finalAmount.setScale(2, RoundingMode.HALF_UP)
        )
    }

    // ----------------------------------------------------
    // 2. Order Submission & State Machine progression
    // ----------------------------------------------------
    suspend fun checkoutAndCreateOrder(
        storeId: Int,
        isDelivery: Boolean,
        selectedCouponId: Int?,
        redeemPoints: Boolean,
        notes: String = ""
    ): Order? {
        val items = cartItems.first()
        if (items.isEmpty()) return null

        val store = dao.getStoreById(storeId) ?: return null
        val profile = dao.getMemberProfileSync() ?: return null

        val breakdown = calculateCartPrice(isDelivery, selectedCouponId, redeemPoints)

        // Generate取餐码/OrderCode
        val alphabet = "ABCDEFGH"
        val codeLetter = alphabet[Random.nextInt(alphabet.length)]
        val codeNum = String.format(Locale.getDefault(), "%03d", Random.nextInt(100, 999))
        val orderCode = "$codeLetter$codeNum"

        // Serialize items
        val sb = StringBuilder("[")
        items.forEachIndexed { i, item ->
            sb.append("""{"name":"${item.productName}","qty":${item.quantity},"price":"${item.price}","specs":"${item.temperature}, ${item.sweetness}, ${item.toppings}"}""")
            if (i < items.size - 1) sb.append(",")
        }
        sb.append("]")

        val order = Order(
            storeId = storeId,
            storeName = store.name,
            orderCode = orderCode,
            status = "PAID", // Create directly in PAID (since simulate payment completes instantly)
            totalAmount = breakdown.finalAmount.toString(),
            subtotal = breakdown.subtotal.toString(),
            discount = breakdown.memberDiscount.add(breakdown.couponDiscount).toString(),
            pointDeduction = breakdown.pointsDeduction.toString(),
            deliveryFee = breakdown.deliveryFee.toString(),
            isDelivery = isDelivery,
            timestamp = System.currentTimeMillis(),
            itemsJson = sb.toString(),
            verificationCode = "MIXUE_VERIFY_${System.currentTimeMillis()}_$orderCode"
        )

        // Deduct used coupon
        if (selectedCouponId != null) {
            useCoupon(selectedCouponId)
        }

        // Deduct points if used
        if (redeemPoints && breakdown.pointsDeduction > BigDecimal.ZERO) {
            val ptsUsed = breakdown.pointsDeduction.multiply(BigDecimal("100")).toInt()
            val newPoints = (profile.points - ptsUsed).coerceAtLeast(0)
            dao.updateMemberProfile(profile.copy(points = newPoints))

            // Points Ledger Deduct
            dao.insertPointsRecord(
                PointsRecord(
                    amount = -ptsUsed,
                    eventType = "REDEEM",
                    source = "点单抵扣",
                    referenceId = orderCode,
                    timestamp = System.currentTimeMillis(),
                    balanceAfter = newPoints
                )
            )
        }

        // Save order
        val id = dao.insertOrder(order)

        // Pre-deplete stock (Demonstrates Atomic Inventory Locking)
        for (item in items) {
            val prod = dao.getProductById(item.productId)
            if (prod != null) {
                val newStock = (prod.stock - item.quantity).coerceAtLeast(0)
                dao.updateProduct(prod.copy(stock = newStock, salesCount = prod.salesCount + item.quantity))
            }
        }

        // Clear cart
        dao.clearCart()

        return order.copy(id = id.toInt())
    }

    // Progress the state machine
    suspend fun progressOrder(orderId: Int, nextStatus: String) {
        val order = dao.getOrderById(orderId) ?: return
        dao.updateOrder(order.copy(status = nextStatus))

        // If completed or picked up, reward points!
        if (nextStatus == "COMPLETED" || nextStatus == "PICKED_UP" || nextStatus == "DELIVERED") {
            val profile = dao.getMemberProfileSync()
            if (profile != null) {
                // Earn rules: 1 Snow King coin per 1 Yuan spent
                val earned = BigDecimal(order.totalAmount).setScale(0, RoundingMode.DOWN).toInt().coerceAtLeast(1)
                val newPoints = profile.points + earned
                val newGrowth = profile.growthValue + earned

                // Automatic Member Upgrade check
                val newLevel = when {
                    newGrowth >= 1000 -> "超级甜蜜会员"
                    newGrowth >= 600 -> "雪王会员"
                    newGrowth >= 200 -> "甜蜜会员"
                    else -> "普通会员"
                }

                dao.updateMemberProfile(profile.copy(
                    points = newPoints,
                    growthValue = newGrowth,
                    level = newLevel
                ))

                // Insert ledger points
                dao.insertPointsRecord(
                    PointsRecord(
                        amount = earned,
                        eventType = "EARN",
                        source = "点单赠送",
                        referenceId = order.orderCode,
                        timestamp = System.currentTimeMillis(),
                        balanceAfter = newPoints
                    )
                )
            }
        }
    }

    // ----------------------------------------------------
    // 3. Simulated Store Order Flow (Auto progresses order states for Master Demo)
    // ----------------------------------------------------
    fun runSimulatedOrderProgress(orderId: Int) = flow {
        emit("PAID") // Paid instantly
        delay(2500)
        progressOrder(orderId, "ACCEPTED")
        emit("ACCEPTED") // Store accepted
        delay(3000)
        progressOrder(orderId, "PREPARING")
        emit("PREPARING") // Making beverage
        delay(4000)
        progressOrder(orderId, "READY")
        emit("READY") // Beverage ready for pickup
    }

    // ----------------------------------------------------
    // 4. Daily Sign-In logic
    // ----------------------------------------------------
    suspend fun performDailySignIn(): Pair<Boolean, String> {
        val profile = dao.getMemberProfileSync() ?: return Pair(false, "未找到会员信息")
        val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

        if (profile.lastSignInDate == todayStr) {
            return Pair(false, "今天已经签到过了哦，雪王爱你！")
        }

        // Check if yesterday was last sign in to calculate continuous streak
        val yesterdayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(System.currentTimeMillis() - 86400000))
        val newStreak = if (profile.lastSignInDate == yesterdayStr) {
            profile.consecutiveSignInDays + 1
        } else {
            1
        }

        // Calculate rewards
        val rewardPoints = when (newStreak) {
            1 -> 10
            3 -> 30
            7 -> 100 // Mega bonus for 7 days
            14 -> 150
            30 -> 300
            else -> 10
        }

        val newPoints = profile.points + rewardPoints
        val updated = profile.copy(
            points = newPoints,
            consecutiveSignInDays = newStreak,
            lastSignInDate = todayStr
        )
        dao.updateMemberProfile(updated)

        // Ledger
        dao.insertPointsRecord(
            PointsRecord(
                amount = rewardPoints,
                eventType = "EARN",
                source = "每日签到(连签${newStreak}天)",
                referenceId = "SIGNIN_${System.currentTimeMillis()}",
                timestamp = System.currentTimeMillis(),
                balanceAfter = newPoints
            )
        )

        // Claim bonus coupon if hit continuous milestones
        if (newStreak == 3) {
            dao.insertCoupons(listOf(
                Coupon(name = "连签3天赠送：茉莉奶绿半价券", couponType = "DISCOUNT", amount = "3.00", minSpend = "6.00", isUsed = false, expiryDate = "2026-10-31", applicableCategory = "茶饮")
            ))
        } else if (newStreak == 7) {
            dao.insertCoupons(listOf(
                Coupon(name = "神级连签7天：5元无门槛通用券", couponType = "CASH", amount = "5.00", minSpend = "0.00", isUsed = false, expiryDate = "2026-10-31")
            ))
        }

        return Pair(true, "签到成功！连签${newStreak}天，获得 $rewardPoints 雪王币！")
    }

    // ----------------------------------------------------
    // 5. Intelligent Query Parser & AI Snow King Assistant (雪王小助手)
    // ----------------------------------------------------
    suspend fun querySnowKingAssistant(question: String): String {
        val query = question.lowercase(Locale.getDefault()).trim()
        val profile = dao.getMemberProfileSync()
        val stores = dao.getAllStores().first()
        val products = dao.getAllProducts().first()
        val activeOrders = dao.getAllOrders().first()

        return when {
            // Check points (雪王币)
            query.contains("雪王币") || query.contains("积分") || query.contains("余额") || query.contains("coins") -> {
                val pts = profile?.points ?: 0
                "【雪王播报】主子，您的雪王币余额是 🪙 $pts 枚！再消费一点点，又可以兑换雪王的萌趣周边或优惠券啦！"
            }

            // Check nearest store
            query.contains("最近") || query.contains("附近") || query.contains("门店") || query.contains("店") -> {
                val sorted = stores.sortedBy { it.distanceMeter }
                if (sorted.isNotEmpty()) {
                    val nearest = sorted.first()
                    "【雪王指路】主子，离您最近的门店是「${nearest.name}」，距离您只有 ${nearest.distanceMeter} 米，目前排队 ${nearest.queueCount} 杯，预计制作时间大约需要 ${nearest.prepTimeMin} 分钟！雪王在店里等您哦！"
                } else {
                    "【雪王抱抱】哎呀，雪王迷路了，没能探测到附近的门店，您看下GPS定位开启了吗？"
                }
            }

            // Recommendation queries
            query.contains("推荐") || query.contains("喝什么") || query.contains("好喝") || query.contains("清爽") || query.contains("不太甜") -> {
                val bestLemon = products.find { it.id == 1 }
                val bestPeach = products.find { it.id == 6 }
                "【雪王安利】\n1. 🍋 **${bestLemon?.name}**（${bestLemon?.price}元）- 现切鲜拧，酸甜冰爽！最适合要求“不太甜、清凉解暑”的主子！\n2. 🍑 **${bestPeach?.name}**（${bestPeach?.price}元）- 满口香甜蜜桃果肉，精选四季春茶，热销首选！"
            }

            // Current Order statuses
            query.contains("订单") || query.contains("进度") || query.contains("取餐") || query.contains("上次点了") -> {
                if (activeOrders.isNotEmpty()) {
                    val latest = activeOrders.first()
                    val statusText = when (latest.status) {
                        "PAID" -> "已付款，等待门店接单"
                        "ACCEPTED" -> "门店已接单"
                        "PREPARING" -> "正在紧锣密鼓制作中"
                        "READY" -> "制作完成，取餐码是【${latest.orderCode}】，快去柜台领快乐吧！"
                        "COMPLETED", "PICKED_UP" -> "订单已完成啦"
                        else -> latest.status
                    }
                    "【订单速报】主子，您最新的订单「${latest.orderCode}」（门店: ${latest.storeName}）状态为：**$statusText**！"
                } else {
                    "【雪王空空】主子，您最近没有未完成的订单哦，肚子是不是在唱空城计啦？快去点一杯吧！"
                }
            }

            // Price queries
            query.contains("柠檬水") || query.contains("ningmengshui") || query.contains("ning meng shui") -> {
                val lemon = products.find { it.id == 1 }
                "【饮品报价】🍋 **${lemon?.name}** 基础价格只需 **¥${lemon?.price}** (会员专享价 ¥${lemon?.memberPrice})！极致性价比，平价又好喝，快加入购物车吧！"
            }

            query.contains("冰淇淋") || query.contains("bingqilin") || query.contains("ice cream") -> {
                val ice = products.find { it.id == 2 }
                "【饮品报价】🍦 **${ice?.name}** 华夫蛋筒经典款仅需 **¥${ice?.price}**！超甜超浓郁，甜到心坎里！"
            }

            query.contains("优惠") || query.contains("省钱") || query.contains("便宜") || query.contains("代金券") -> {
                val coupons = dao.getAvailableCoupons().first()
                if (coupons.isNotEmpty()) {
                    val text = coupons.joinToString("\n") { "• ${it.name} (有效期至 ${it.expiryDate})" }
                    "【省钱秘籍】主子，您手里目前有这些闲置的模拟优惠券哦，结算时能省不少银子：\n$text"
                } else {
                    "【省钱秘籍】主子，目前优惠券包空空的，可以通过连续签到或升级会员获取更多专属券包哦！"
                }
            }

            else -> {
                "【雪王歪头】喵呜～主子说的是什么深奥密码呀，雪王没听懂。您可以问我：「我的雪王币」、「附近有什么店」、「柠檬水多少钱」或者「进度怎么样」！"
            }
        }
    }
}
