package com.example.data.database

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.Update
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Dao
interface MixueDao {
    // Stores
    @Query("SELECT * FROM stores")
    fun getAllStores(): Flow<List<Store>>

    @Query("SELECT * FROM stores WHERE id = :id")
    suspend fun getStoreById(id: Int): Store?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStores(stores: List<Store>)

    @Update
    suspend fun updateStore(store: Store)

    // Products
    @Query("SELECT * FROM products")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE category = :category")
    fun getProductsByCategory(category: String): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE id = :id")
    suspend fun getProductById(id: Int): Product?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<Product>)

    @Update
    suspend fun updateProduct(product: Product)

    // Cart Items
    @Query("SELECT * FROM cart_items")
    fun getCartItems(): Flow<List<CartItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addToCart(item: CartItem)

    @Update
    suspend fun updateCartItem(item: CartItem)

    @Query("DELETE FROM cart_items WHERE id = :id")
    suspend fun deleteCartItem(id: Int)

    @Query("DELETE FROM cart_items")
    suspend fun clearCart()

    // Orders
    @Query("SELECT * FROM orders ORDER BY timestamp DESC")
    fun getAllOrders(): Flow<List<Order>>

    @Query("SELECT * FROM orders WHERE id = :id")
    suspend fun getOrderById(id: Int): Order?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: Order): Long

    @Update
    suspend fun updateOrder(order: Order)

    // Points Ledger
    @Query("SELECT * FROM points_ledger ORDER BY timestamp DESC")
    fun getPointsLedger(): Flow<List<PointsRecord>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPointsRecord(record: PointsRecord)

    // Member Profile
    @Query("SELECT * FROM member_profile WHERE id = 1")
    fun getMemberProfile(): Flow<MemberProfile?>

    @Query("SELECT * FROM member_profile WHERE id = 1")
    suspend fun getMemberProfileSync(): MemberProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemberProfile(profile: MemberProfile)

    @Update
    suspend fun updateMemberProfile(profile: MemberProfile)

    // Coupons
    @Query("SELECT * FROM coupons WHERE isUsed = 0")
    fun getAvailableCoupons(): Flow<List<Coupon>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCoupons(coupons: List<Coupon>)

    @Update
    suspend fun updateCoupon(coupon: Coupon)

    // Campaigns
    @Query("SELECT * FROM campaigns")
    fun getAllCampaigns(): Flow<List<Campaign>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCampaigns(campaigns: List<Campaign>)

    // Mall Products
    @Query("SELECT * FROM mall_products")
    fun getMallProducts(): Flow<List<MallProduct>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMallProducts(products: List<MallProduct>)
}

@Database(
    entities = [
        Store::class,
        Product::class,
        CartItem::class,
        Order::class,
        PointsRecord::class,
        MemberProfile::class,
        Coupon::class,
        Campaign::class,
        MallProduct::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MixueDatabase : RoomDatabase() {
    abstract fun mixueDao(): MixueDao

    companion object {
        @Volatile
        private var INSTANCE: MixueDatabase? = null

        fun getDatabase(context: Context): MixueDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    MixueDatabase::class.java,
                    "mixue_digital_life_db"
                )
                .addCallback(DatabasePrepopulateCallback(context))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabasePrepopulateCallback(
        private val context: Context
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                CoroutineScope(Dispatchers.IO).launch {
                    prepopulateData(database.mixueDao())
                }
            }
        }

        private suspend fun prepopulateData(dao: MixueDao) {
            // 1. Prepopulate Member Profile
            val defaultProfile = MemberProfile(
                id = 1,
                nickname = "王小明",
                avatarUrl = "", // empty will use a nice synthetic avatar drawing
                level = "甜蜜会员",
                points = 1280,
                growthValue = 350,
                consecutiveSignInDays = 3,
                lastSignInDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(System.currentTimeMillis() - 86400000)), // yesterday
                monthlySpend = "48.00"
            )
            dao.insertMemberProfile(defaultProfile)

            // 2. Prepopulate Points Ledger History
            val now = System.currentTimeMillis()
            val ledgerList = listOf(
                PointsRecord(amount = 1000, eventType = "EARN", source = "新人专享赠礼", referenceId = "INIT", timestamp = now - 86400000 * 5, balanceAfter = 1000),
                PointsRecord(amount = 200, eventType = "EARN", source = "连续签到奖励", referenceId = "SIGNIN", timestamp = now - 86400000 * 3, balanceAfter = 1200),
                PointsRecord(amount = -100, eventType = "REDEEM", source = "兑换5元优惠券", referenceId = "COUPON_REDEEM", timestamp = now - 86400000 * 2, balanceAfter = 1100),
                PointsRecord(amount = 180, eventType = "EARN", source = "点单消费奖励", referenceId = "ORDER_9982", timestamp = now - 86400000, balanceAfter = 1280)
            )
            for (record in ledgerList) {
                dao.insertPointsRecord(record)
            }

            // 3. Prepopulate Stores (Nearby Stores)
            val storeList = listOf(
                Store(
                    id = 101,
                    name = "蜜雪冰城·人民广场店",
                    address = "上海市黄浦区南京西路128号",
                    status = "OPEN",
                    distanceMeter = 420,
                    queueCount = 4,
                    prepTimeMin = 8,
                    latitude = 31.2304,
                    longitude = 121.4737,
                    businessHours = "09:00 - 22:30",
                    phone = "021-88888888"
                ),
                Store(
                    id = 102,
                    name = "蜜雪冰城·南京东路步行街店",
                    address = "上海市黄浦区南京东路358号",
                    status = "BUSY",
                    distanceMeter = 850,
                    queueCount = 18,
                    prepTimeMin = 22,
                    latitude = 31.2397,
                    longitude = 121.4822,
                    businessHours = "09:00 - 23:00",
                    phone = "021-99999999"
                ),
                Store(
                    id = 103,
                    name = "蜜雪冰城·静安寺店",
                    address = "上海市静安区南京西路1601号",
                    status = "OPEN",
                    distanceMeter = 2100,
                    queueCount = 2,
                    prepTimeMin = 5,
                    latitude = 31.2245,
                    longitude = 121.4468,
                    businessHours = "09:30 - 22:00",
                    phone = "021-77777777"
                ),
                Store(
                    id = 104,
                    name = "蜜雪冰城·徐家汇店",
                    address = "上海市徐汇区漕溪北路33号",
                    status = "OPEN",
                    distanceMeter = 4500,
                    queueCount = 1,
                    prepTimeMin = 4,
                    latitude = 31.1924,
                    longitude = 121.4392,
                    businessHours = "09:30 - 22:00",
                    phone = "021-66666666"
                )
            )
            dao.insertStores(storeList)

            // 4. Prepopulate Beverages / Products Catalog
            val productList = listOf(
                // 柠檬水 category
                Product(
                    id = 1,
                    name = "冰鲜柠檬水",
                    description = "精选新鲜柠檬，当季现切，酸甜清爽，MIXUE绝对的快乐之源！",
                    category = "冰鲜柠檬水",
                    price = "4.00",
                    memberPrice = "3.50",
                    isNew = false,
                    isHot = true,
                    isAvailable = true,
                    stock = 500,
                    imageResName = "ic_lemon",
                    salesCount = 88200,
                    discountTag = "招牌必点"
                ),
                // 新鲜冰淇淋 category
                Product(
                    id = 2,
                    name = "新鲜冰淇淋",
                    description = "纯正奶香，细腻丝滑。雪王最爱的经典华夫蛋筒冰淇淋！",
                    category = "新鲜冰淇淋",
                    price = "3.00",
                    memberPrice = "2.50",
                    isNew = false,
                    isHot = true,
                    isAvailable = true,
                    stock = 300,
                    imageResName = "ic_ice_cream",
                    salesCount = 99999,
                    discountTag = "超值热销"
                ),
                Product(
                    id = 3,
                    name = "草莓摇摇奶昔",
                    description = "真材实料草莓果肉，浓郁冰淇淋奶奶，疯狂摇一摇，美味加倍！",
                    category = "新鲜冰淇淋",
                    price = "6.00",
                    memberPrice = "5.50",
                    isNew = false,
                    isHot = true,
                    isAvailable = true,
                    stock = 120,
                    imageResName = "ic_milkshake",
                    salesCount = 42100,
                    discountTag = "爆款推荐"
                ),
                Product(
                    id = 4,
                    name = "黑糖珍珠大圣代",
                    description = "Q弹软糯黑糖珍珠，淋上浓郁黑糖浆，搭配细腻牛乳冰淇淋，多重满足！",
                    category = "新鲜冰淇淋",
                    price = "7.00",
                    memberPrice = "6.50",
                    isNew = false,
                    isHot = false,
                    isAvailable = true,
                    stock = 150,
                    imageResName = "ic_sundae",
                    salesCount = 31200
                ),
                // 茶饮 category
                Product(
                    id = 5,
                    name = "茉莉奶绿",
                    description = "清雅茉莉茶香，融合醇厚奶香，清爽不腻口，余韵悠长。",
                    category = "茶饮",
                    price = "6.00",
                    memberPrice = "5.50",
                    isNew = false,
                    isHot = false,
                    isAvailable = true,
                    stock = 250,
                    imageResName = "ic_tea_green",
                    salesCount = 18400
                ),
                Product(
                    id = 6,
                    name = "蜜桃四季春",
                    description = "精选高山四季春茶，加入大颗粒香甜蜜桃果肉，满口清甜，果味十足！",
                    category = "茶饮",
                    price = "7.00",
                    memberPrice = "6.00",
                    isNew = false,
                    isHot = true,
                    isAvailable = true,
                    stock = 180,
                    imageResName = "ic_peach",
                    salesCount = 54000,
                    discountTag = "果肉满满"
                ),
                // 奶茶 category
                Product(
                    id = 7,
                    name = "雪王黑糖珍珠奶茶",
                    description = "经典港式浓郁奶茶，融入每日现煮Q弹珍珠，古法黑糖，甜蜜回甘！",
                    category = "奶茶",
                    price = "8.00",
                    memberPrice = "7.20",
                    isNew = false,
                    isHot = true,
                    isAvailable = true,
                    stock = 220,
                    imageResName = "ic_milktea",
                    salesCount = 65200
                ),
                // 咖啡 category
                Product(
                    id = 8,
                    name = "雪王雪顶咖啡",
                    description = "现磨浓郁黑咖啡，盖上一整座牛乳冰淇淋雪山，冰爽浓醇双重奏！",
                    category = "咖啡",
                    price = "6.00",
                    memberPrice = "5.50",
                    isNew = false,
                    isHot = false,
                    isAvailable = true,
                    stock = 100,
                    imageResName = "ic_coffee_snow",
                    salesCount = 12000,
                    discountTag = "提神解暑"
                )
            )
            dao.insertProducts(productList)

            // 5. Prepopulate Coupons
            val couponList = listOf(
                Coupon(name = "新人专享2元无门槛券", couponType = "CASH", amount = "2.00", minSpend = "0.00", isUsed = false, expiryDate = "2026-10-31"),
                Coupon(name = "柠檬水专属1元优惠券", couponType = "CASH", amount = "1.00", minSpend = "4.00", isUsed = false, expiryDate = "2026-10-15", applicableCategory = "冰鲜柠檬水"),
                Coupon(name = "夏日满15减3元代金券", couponType = "CASH", amount = "3.00", minSpend = "15.00", isUsed = false, expiryDate = "2026-09-30"),
                Coupon(name = "免费配送券", couponType = "FREE_DELIVERY", amount = "3.00", minSpend = "0.00", isUsed = false, expiryDate = "2026-09-25")
            )
            dao.insertCoupons(couponList)

            // 6. Prepopulate Active Campaign (for Mini-games / Events)
            val campaignList = listOf(
                Campaign(
                    name = "雪王夏日甜蜜季",
                    description = "蜜雪冰城年度夏日嘉年华！每日签到送代金券，挑战“雪王送甜蜜”小游戏，赢取限定雪王币，兑换激萌周边！",
                    bannerImage = "ic_campaign_summer",
                    startDate = "2026-06-01",
                    endDate = "2026-09-30",
                    type = "SUMMER",
                    status = "ACTIVE"
                )
            )
            dao.insertCampaigns(campaignList)

            // 7. Prepopulate Mall Products
            val mallProductList = listOf(
                MallProduct(id = 501, name = "雪王不倒翁吸管杯", description = "爆款激萌吸管杯，双层防烫，食品级硅胶，陪伴你的每一次甜蜜饮水！", price = "29.00", pointsPrice = 500, isPointsOnly = false, imageResName = "mall_cup", stock = 80),
                MallProduct(id = 502, name = "雪王限定刺绣中筒袜", description = "纯棉舒适，雪王标志萌趣刺绣，男女同款，潮流必备！", price = "12.00", pointsPrice = 300, isPointsOnly = true, imageResName = "mall_socks", stock = 120),
                MallProduct(id = 503, name = "雪王大号毛绒公仔", description = "45cm大尺寸雪王毛绒玩偶，亲肤手感，雪王本王亲自给你温暖拥抱！", price = "39.00", pointsPrice = 800, isPointsOnly = false, imageResName = "mall_toy", stock = 40)
            )
            dao.insertMallProducts(mallProductList)
        }
    }
}
