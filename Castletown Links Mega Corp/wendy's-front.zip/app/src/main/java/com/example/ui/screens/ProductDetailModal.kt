package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ModifierGroup
import com.example.data.models.Screen
import com.example.ui.theme.WendysGold
import com.example.ui.theme.WendysRed
import com.example.viewmodel.KioskViewModel

@Composable
fun ProductDetailModal(
    viewModel: KioskViewModel,
    onNavigate: (Screen) -> Unit
) {
    val menuItem by viewModel.selectedMenuItem.collectAsState()
    val customizingModifiers by viewModel.customizingModifiers.collectAsState()
    var quantity by remember { mutableStateOf(1) }

    val item = menuItem ?: run {
        LaunchedEffect(Unit) { onNavigate(Screen.MENU) }
        return
    }

    val context = LocalContext.current
    val imageResId = when (item.imageResName) {
        "img_baconator" -> context.resources.getIdentifier("img_baconator", "drawable", context.packageName)
        "img_spicy_chicken" -> context.resources.getIdentifier("img_spicy_chicken", "drawable", context.packageName)
        "img_frosty" -> context.resources.getIdentifier("img_frosty", "drawable", context.packageName)
        else -> context.resources.getIdentifier("img_hero_banner", "drawable", context.packageName)
    }

    val calculatedPrice = remember(item, quantity, customizingModifiers) {
        val base = item.price
        val modCost = customizingModifiers.sumOf { it.priceAdjustment }
        (base + modCost) * quantity
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Back Nav Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onNavigate(Screen.MENU) }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Customise Item",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Row(modifier = Modifier.weight(1f)) {
            // Left Column: Product Summary Card
            Card(
                modifier = Modifier
                    .width(360.dp)
                    .fillMaxHeight()
                    .padding(24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    if (imageResId != 0) {
                        Image(
                            painter = painterResource(id = imageResId),
                            contentDescription = item.name,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(200.dp)
                                .clip(RoundedCornerShape(16.dp))
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = item.name,
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Black,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = item.description,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${item.calories} Calories", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            if (item.allergens.isNotEmpty()) {
                                Text(" • Allergens: ${item.allergens.joinToString()}", fontSize = 12.sp, color = Color.Gray)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.weight(1f))

                    // Quantity Counter
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        OutlinedIconButton(
                            onClick = { if (quantity > 1) quantity-- },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Decrease")
                        }

                        Text(
                            text = "$quantity",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 24.dp)
                        )

                        OutlinedIconButton(
                            onClick = { quantity++ },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Increase")
                        }
                    }
                }
            }

            // Right Column: Modifier Groups Options List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(top = 24.dp, end = 24.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                items(item.modifierGroups, key = { it.id }) { group ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text(
                                text = group.name,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (group.isRequired) "Required choice" else "Optional customisations",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            group.options.forEach { option ->
                                val isChecked = customizingModifiers.any { it.id == option.id }
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Checkbox(
                                            checked = isChecked,
                                            onCheckedChange = { viewModel.toggleModifier(option, group) },
                                            colors = CheckboxDefaults.colors(checkedColor = WendysRed)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = option.name,
                                            fontSize = 15.sp,
                                            fontWeight = if (isChecked) FontWeight.Bold else FontWeight.Normal
                                        )
                                    }

                                    if (option.priceAdjustment > 0) {
                                        Text(
                                            text = "+$${String.format("%.2f", option.priceAdjustment)}",
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = WendysRed
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom CTA Bar
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 12.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Total Price", fontSize = 13.sp, color = Color.Gray)
                    Text(
                        text = "$${String.format("%.2f", calculatedPrice)}",
                        fontSize = 28.sp,
                        fontWeight = FontWeight.Black,
                        color = WendysRed
                    )
                }

                Button(
                    onClick = { viewModel.addSelectedProductToBasket(quantity) },
                    colors = ButtonDefaults.buttonColors(containerColor = WendysRed),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .height(56.dp)
                        .width(320.dp)
                        .testTag("add_to_basket_confirm_button")
                ) {
                    Text("ADD TO BASKET", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
