package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Screen
import com.example.data.models.ServiceMethod
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.WendysGold
import com.example.ui.theme.WendysRed
import com.example.viewmodel.KioskViewModel
import kotlinx.coroutines.delay

@Composable
fun OrderConfirmationScreen(
    viewModel: KioskViewModel,
    onNavigate: (Screen) -> Unit
) {
    val order by viewModel.lastConfirmedOrder.collectAsState()
    var countdown by remember { mutableStateOf(20) }

    // Automatic session reset timer
    LaunchedEffect(Unit) {
        while (countdown > 0) {
            delay(1000)
            countdown--
        }
        viewModel.resetKioskSession()
    }

    val currentOrder = order ?: run {
        LaunchedEffect(Unit) { onNavigate(Screen.WELCOME) }
        return
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Success Header
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(StatusGreen, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Check, contentDescription = "Success", tint = Color.White, modifier = Modifier.size(48.dp))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text("THANK YOU FOR YOUR ORDER!", fontSize = 28.sp, fontWeight = FontWeight.Black, color = WendysRed)
            Text("Payment Approved • Order Sent to Kitchen", fontSize = 16.sp, color = Color.Gray)
        }

        // Center Order Card
        Card(
            modifier = Modifier
                .width(520.dp)
                .padding(vertical = 16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(24.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("ORDER NUMBER", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "#${currentOrder.orderNumber}",
                    fontSize = 56.sp,
                    fontWeight = FontWeight.Black,
                    color = WendysRed
                )

                Spacer(modifier = Modifier.height(16.dp))

                Divider()

                Spacer(modifier = Modifier.height(16.dp))

                // Service Instruction Box
                Surface(
                    color = if (currentOrder.serviceMethod == ServiceMethod.DINE_IN_TABLE_DELIVERY) WendysGold.copy(alpha = 0.25f) else MaterialTheme.colorScheme.secondaryContainer,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = if (currentOrder.serviceMethod == ServiceMethod.DINE_IN_TABLE_DELIVERY) Icons.Default.RoomService else Icons.Default.TakeoutDining,
                            contentDescription = null,
                            tint = WendysRed,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (currentOrder.serviceMethod == ServiceMethod.DINE_IN_TABLE_DELIVERY) {
                                "WE'LL BRING YOUR FOOD TO TABLE #${currentOrder.tableNumber}"
                            } else {
                                "PLEASE COLLECT AT COUNTER WHEN CALLED"
                            },
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            textAlign = TextAlign.Center
                        )
                        if (currentOrder.diningZone != null) {
                            Text("Zone: ${currentOrder.diningZone}", fontSize = 13.sp, color = Color.DarkGray)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text("Receipt: Printed at kiosk terminal", fontSize = 13.sp, color = Color.Gray)
            }
        }

        // Bottom Reset & Countdown Row
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "Session auto-resets in $countdown seconds for privacy",
                fontSize = 13.sp,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = { viewModel.resetKioskSession() },
                colors = ButtonDefaults.buttonColors(containerColor = WendysRed),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .width(320.dp)
                    .height(52.dp)
                    .testTag("done_reset_button")
            ) {
                Text("FINISH & RETURN TO HOME", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
