package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.WendysGold
import com.example.viewmodel.KioskViewModel

@Composable
fun AccessibilityBar(
    viewModel: KioskViewModel,
    onRequestAssistance: () -> Unit
) {
    val isHighContrast by viewModel.isHighContrast.collectAsState()
    val isLargeText by viewModel.isLargeText.collectAsState()
    val soundEnabled by viewModel.soundEnabled.collectAsState()

    Surface(
        color = if (isHighContrast) Color(0xFF1F1F1F) else Color(0xFF2C2523),
        contentColor = Color.White,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left Accessibility Controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { viewModel.toggleHighContrast() }
                ) {
                    Icon(
                        Icons.Default.Contrast,
                        contentDescription = "High Contrast",
                        tint = if (isHighContrast) WendysGold else Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isHighContrast) "High Contrast ON" else "High Contrast",
                        fontSize = 13.sp,
                        fontWeight = if (isHighContrast) FontWeight.Bold else FontWeight.Normal
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { viewModel.toggleLargeText() }
                ) {
                    Icon(
                        Icons.Default.FormatSize,
                        contentDescription = "Text Size",
                        tint = if (isLargeText) WendysGold else Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isLargeText) "Large Text ON" else "Text Size",
                        fontSize = 13.sp,
                        fontWeight = if (isLargeText) FontWeight.Bold else FontWeight.Normal
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { viewModel.toggleSound() }
                ) {
                    Icon(
                        if (soundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                        contentDescription = "Audio Guidance",
                        tint = if (soundEnabled) Color.White else Color.Gray,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (soundEnabled) "Audio Prompts ON" else "Muted",
                        fontSize = 13.sp
                    )
                }
            }

            // Right: Staff Assistance Button
            Button(
                onClick = onRequestAssistance,
                colors = ButtonDefaults.buttonColors(containerColor = WendysGold, contentColor = Color.Black),
                shape = RoundedCornerShape(20.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp),
                modifier = Modifier.testTag("request_assistance_bar_button")
            ) {
                Icon(Icons.Default.SupportAgent, contentDescription = "Assistance", modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Assistance", fontSize = 13.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
