package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Screen
import com.example.data.models.ServiceMethod
import com.example.ui.theme.WendysGold
import com.example.ui.theme.WendysRed
import com.example.viewmodel.KioskViewModel

@Composable
fun BasketCheckoutScreen(
    viewModel: KioskViewModel,
    onNavigate: (Screen) -> Unit
) {
    val basket by viewModel.activeBasket.collectAsState()
    val subtotal by viewModel.basketSubtotal.collectAsState()
    val tax by viewModel.basketTax.collectAsState()
    val total by viewModel.basketTotal.collectAsState()
    val serviceMethod by viewModel.selectedServiceMethod.collectAsState()
    val selectedTable by viewModel.selectedTableNumber.collectAsState()
    val diningTables by viewModel.diningTables.collectAsState()
    val diningZones = viewModel.diningZones

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onNavigate(Screen.MENU) }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("CHECKOUT & SERVICE DETAILS", fontSize = 22.sp, fontWeight = FontWeight.Black, color = WendysRed)
                    Text("Review your order and select where you'll enjoy your food", fontSize = 13.sp, color = Color.Gray)
                }
            }
        }

        Row(modifier = Modifier.weight(1f)) {
            // Left Column: Service Mode & Table Selector
            Column(
                modifier = Modifier
                    .weight(1.3f)
                    .fillMaxHeight()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("1. Select Service Method", fontSize = 18.sp, fontWeight = FontWeight.Bold)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { viewModel.selectServiceMethod(ServiceMethod.DINE_IN_TABLE_DELIVERY) }
                            .testTag("service_table_delivery"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (serviceMethod == ServiceMethod.DINE_IN_TABLE_DELIVERY) WendysRed.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (serviceMethod == ServiceMethod.DINE_IN_TABLE_DELIVERY) androidx.compose.foundation.BorderStroke(2.dp, WendysRed) else null
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Icon(Icons.Default.TableRestaurant, contentDescription = null, tint = WendysRed, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Dine In — Table Delivery", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text("We bring your hot food to your table", fontSize = 12.sp, color = Color.Gray)
                        }
                    }

                    Card(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { viewModel.selectServiceMethod(ServiceMethod.TAKEAWAY) }
                            .testTag("service_takeaway"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (serviceMethod == ServiceMethod.TAKEAWAY) WendysRed.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (serviceMethod == ServiceMethod.TAKEAWAY) androidx.compose.foundation.BorderStroke(2.dp, WendysRed) else null
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Icon(Icons.Default.TakeoutDining, contentDescription = null, tint = WendysRed, modifier = Modifier.size(28.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Takeaway / Pickup", fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text("Collect your order at the counter", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }

                // Table Selector Grid if Table Delivery chosen
                if (serviceMethod == ServiceMethod.DINE_IN_TABLE_DELIVERY) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("2. Where are you sitting?", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = if (selectedTable != null) "Selected Table #$selectedTable" else "Tap your table number below",
                                        fontSize = 13.sp,
                                        color = if (selectedTable != null) WendysRed else Color.Gray,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Surface(color = WendysGold, shape = RoundedCornerShape(8.dp)) {
                                    Text("TABLE SERVICE ENABLED", fontSize = 11.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Tables Grid
                            LazyVerticalGrid(
                                columns = GridCells.Fixed(4),
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                verticalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                items(count = diningTables.size, key = { index -> diningTables[index].tableNumber }) { index ->
                                    val table = diningTables[index]
                                    val isSelected = selectedTable == table.tableNumber
                                    val zoneObj = diningZones.firstOrNull { it.id == table.zoneId }
                                    val zoneName = zoneObj?.name ?: "Dining Area"

                                    Surface(
                                        modifier = Modifier
                                            .height(70.dp)
                                            .clip(RoundedCornerShape(12.dp))
                                            .clickable { viewModel.selectTable(table.tableNumber, zoneName) }
                                            .testTag("table_chip_${table.tableNumber}"),
                                        color = when {
                                            isSelected -> WendysRed
                                            table.isOccupied -> MaterialTheme.colorScheme.surfaceVariant
                                            else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                                        },
                                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, WendysRed) else null
                                    ) {
                                        Column(
                                            modifier = Modifier.fillMaxSize(),
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            verticalArrangement = Arrangement.Center
                                        ) {
                                            Text(
                                                text = "TABLE ${table.tableNumber}",
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Black,
                                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = zoneName,
                                                fontSize = 10.sp,
                                                color = if (isSelected) Color.White.copy(alpha = 0.8f) else Color.Gray
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Right Column: Order Summary Card
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .padding(top = 24.dp, end = 24.dp, bottom = 24.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(20.dp)
                ) {
                    Text("Order Summary", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier.weight(1f),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(basket, key = { it.id }) { item ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("${item.quantity}x ${item.menuItem.name}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                    if (item.selectedModifiers.isNotEmpty()) {
                                        Text(item.selectedModifiers.joinToString { it.name }, fontSize = 11.sp, color = Color.Gray)
                                    }
                                }
                                Text("$${String.format("%.2f", item.totalPrice)}", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Divider(modifier = Modifier.padding(vertical = 12.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Subtotal", fontSize = 14.sp, color = Color.Gray)
                            Text("$${String.format("%.2f", subtotal)}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Estimated Tax (8%)", fontSize = 14.sp, color = Color.Gray)
                            Text("$${String.format("%.2f", tax)}", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Payable", fontSize = 20.sp, fontWeight = FontWeight.Black)
                            Text("$${String.format("%.2f", total)}", fontSize = 22.sp, fontWeight = FontWeight.Black, color = WendysRed)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { onNavigate(Screen.PAYMENT) },
                        enabled = serviceMethod != ServiceMethod.DINE_IN_TABLE_DELIVERY || selectedTable != null,
                        colors = ButtonDefaults.buttonColors(containerColor = WendysRed),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("proceed_to_payment_button")
                    ) {
                        Text(
                            text = if (serviceMethod == ServiceMethod.DINE_IN_TABLE_DELIVERY && selectedTable == null) "Select a Table First" else "PROCEED TO PAYMENT ($${String.format("%.2f", total)})",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
