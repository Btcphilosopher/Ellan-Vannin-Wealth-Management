package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.PaymentMethod
import com.example.data.models.Screen
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.WendysGold
import com.example.ui.theme.WendysRed
import com.example.viewmodel.KioskViewModel

@Composable
fun PaymentScreen(
    viewModel: KioskViewModel,
    onNavigate: (Screen) -> Unit
) {
    val total by viewModel.basketTotal.collectAsState()
    val isProcessing by viewModel.isPaymentProcessing.collectAsState()
    val paymentMethod by viewModel.selectedPaymentMethod.collectAsState()

    // Pulse animation for simulated NFC reader
    val infiniteTransition = rememberInfiniteTransition(label = "nfc_pulse")
    val scale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Nav Header
        Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onNavigate(Screen.BASKET_CHECKOUT) }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("SECURE PAYMENT TERMINAL", fontSize = 22.sp, fontWeight = FontWeight.Black, color = WendysRed)
                    Text("PCI-Compliant Kiosk Card Reader & Mobile Wallet", fontSize = 13.sp, color = Color.Gray)
                }
            }
        }

        Row(
            modifier = Modifier
                .weight(1f)
                .padding(32.dp),
            horizontalArrangement = Arrangement.spacedBy(32.dp)
        ) {
            // Left: Payment Method Options
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Select Payment Method", fontSize = 20.sp, fontWeight = FontWeight.Bold)

                PaymentMethod.values().forEach { method ->
                    val isSelected = paymentMethod == method
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { viewModel.selectPaymentMethod(method) }
                            .testTag("pay_method_${method.name}"),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isSelected) WendysRed.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                        ),
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, WendysRed) else null
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = when (method) {
                                        PaymentMethod.CONTACTLESS -> Icons.Default.Contactless
                                        PaymentMethod.CHIP_PIN -> Icons.Default.CreditCard
                                        PaymentMethod.MOBILE_WALLET -> Icons.Default.PhoneAndroid
                                        PaymentMethod.GIFT_CARD -> Icons.Default.CardGiftcard
                                    },
                                    contentDescription = null,
                                    tint = WendysRed,
                                    modifier = Modifier.size(32.dp)
                                )
                                Spacer(modifier = Modifier.width(16.dp))
                                Text(method.label, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                            }

                            RadioButton(
                                selected = isSelected,
                                onClick = { viewModel.selectPaymentMethod(method) },
                                colors = RadioButtonDefaults.colors(selectedColor = WendysRed)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.weight(1f))

                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(10.dp))
                        Text("256-Bit SSL Encrypted • No raw card data stored", fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }

            // Right: Interactive Terminal Simulator & Tap/Insert Graphic
            Card(
                modifier = Modifier
                    .weight(1.2f)
                    .fillMaxHeight(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("TOTAL AMOUNT DUE", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "$${String.format("%.2f", total)}",
                            fontSize = 42.sp,
                            fontWeight = FontWeight.Black,
                            color = WendysRed
                        )
                    }

                    // Terminal Animation Circle
                    Box(
                        modifier = Modifier
                            .size(180.dp)
                            .scale(if (isProcessing) scale else 1f)
                            .background(
                                if (isProcessing) WendysRed.copy(alpha = 0.15f) else WendysGold.copy(alpha = 0.2f),
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isProcessing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(140.dp),
                                color = WendysRed,
                                strokeWidth = 6.dp
                            )
                        } else {
                            Icon(
                                imageVector = when (paymentMethod) {
                                    PaymentMethod.CONTACTLESS -> Icons.Default.Contactless
                                    PaymentMethod.CHIP_PIN -> Icons.Default.CreditCard
                                    PaymentMethod.MOBILE_WALLET -> Icons.Default.Nfc
                                    PaymentMethod.GIFT_CARD -> Icons.Default.CardGiftcard
                                },
                                contentDescription = null,
                                tint = WendysRed,
                                modifier = Modifier.size(80.dp)
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isProcessing) "Authorising Payment..." else "TAP, SWIPE OR INSERT CARD",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Black,
                            color = if (isProcessing) WendysRed else MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isProcessing) "Communicating with POS card reader..." else "Please follow terminal screen prompts",
                            fontSize = 14.sp,
                            color = Color.Gray
                        )
                    }

                    // Simulated Tap / Authorize Action Button
                    Button(
                        onClick = { viewModel.processPaymentAndSubmitOrder() },
                        enabled = !isProcessing,
                        colors = ButtonDefaults.buttonColors(containerColor = WendysRed),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .testTag("simulate_payment_tap_button")
                    ) {
                        Icon(Icons.Default.TouchApp, contentDescription = null)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isProcessing) "AUTHORISING..." else "TAP CARD HERE (SIMULATE)",
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
