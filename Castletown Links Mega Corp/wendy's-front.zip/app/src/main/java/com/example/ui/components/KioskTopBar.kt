package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Screen
import com.example.ui.theme.WendysGold
import com.example.ui.theme.WendysRed
import com.example.ui.theme.WendysRedDark
import com.example.viewmodel.KioskViewModel

@Composable
fun KioskTopBar(
    viewModel: KioskViewModel,
    onNavigate: (Screen) -> Unit
) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    val location by viewModel.currentLocation.collectAsState()
    val userLang by viewModel.userLanguage.collectAsState()
    val isHighContrast by viewModel.isHighContrast.collectAsState()

    var showStaffMenu by remember { mutableStateOf(false) }

    Surface(
        color = if (isHighContrast) Color.Black else WendysRed,
        contentColor = Color.White,
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 24.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Left: Brand Logo & Restaurant Location
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .clickable { onNavigate(Screen.WELCOME) }
                    .padding(4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .background(WendysGold, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Fastfood,
                        contentDescription = "Wendy's Logo",
                        tint = WendysRedDark,
                        modifier = Modifier.size(30.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "WENDY'S",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Black,
                            letterSpacing = 1.sp,
                            color = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            color = WendysGold,
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "FRONT",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = WendysRedDark,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        text = location.name,
                        fontSize = 13.sp,
                        color = Color.White.copy(alpha = 0.85f)
                    )
                }
            }

            // Right: Navigation Mode Switcher & Quick Controls
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (currentScreen != Screen.WELCOME) {
                    Button(
                        onClick = { onNavigate(Screen.WELCOME) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(24.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                        modifier = Modifier.testTag("home_button")
                    ) {
                        Icon(Icons.Default.Home, contentDescription = "Home", modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Start Screen", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }

                // Language Indicator Button
                OutlinedButton(
                    onClick = {
                        val nextLang = when (userLang) {
                            "EN" -> "ES"
                            "ES" -> "FR"
                            else -> "EN"
                        }
                        viewModel.setLanguage(nextLang)
                    },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = ButtonDefaults.outlinedButtonBorder.copy(brush = androidx.compose.ui.graphics.SolidColor(Color.White.copy(alpha = 0.6f))),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.testTag("lang_toggle_button")
                ) {
                    Icon(Icons.Default.Translate, contentDescription = "Language", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(userLang, fontWeight = FontWeight.Bold)
                }

                // Staff / Mode Switcher Dropdown
                Box {
                    IconButton(
                        onClick = { showStaffMenu = true },
                        modifier = Modifier
                            .background(Color.White.copy(alpha = 0.2f), CircleShape)
                            .testTag("staff_menu_button")
                    ) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = "Staff Views", tint = Color.White)
                    }

                    DropdownMenu(
                        expanded = showStaffMenu,
                        onDismissRequest = { showStaffMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Kiosk Customer View") },
                            leadingIcon = { Icon(Icons.Default.TouchApp, contentDescription = null) },
                            onClick = {
                                showStaffMenu = false
                                onNavigate(Screen.WELCOME)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Kitchen Display System (KDS)") },
                            leadingIcon = { Icon(Icons.Default.SoupKitchen, contentDescription = null) },
                            onClick = {
                                showStaffMenu = false
                                onNavigate(Screen.KITCHEN_KDS)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Food Runner (Table Service)") },
                            leadingIcon = { Icon(Icons.Default.DirectionsRun, contentDescription = null) },
                            onClick = {
                                showStaffMenu = false
                                onNavigate(Screen.FOOD_RUNNER)
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Staff & Manager Dashboard") },
                            leadingIcon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                            onClick = {
                                showStaffMenu = false
                                onNavigate(Screen.STAFF_DASHBOARD)
                            }
                        )
                    }
                }
            }
        }
    }
}
