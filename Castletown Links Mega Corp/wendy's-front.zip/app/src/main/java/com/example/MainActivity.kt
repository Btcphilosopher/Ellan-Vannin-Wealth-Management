package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.models.Screen
import com.example.ui.components.AccessibilityBar
import com.example.ui.components.KioskTopBar
import com.example.ui.screens.*
import com.example.ui.theme.WendysFrontTheme
import com.example.viewmodel.KioskViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: KioskViewModel = viewModel()
            val isHighContrast by viewModel.isHighContrast.collectAsState()

            WendysFrontTheme(isHighContrast = isHighContrast) {
                WendysFrontApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun WendysFrontApp(viewModel: KioskViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()

    // Handle Android system back button to pop stack safely
    BackHandler(enabled = currentScreen != Screen.WELCOME) {
        when (currentScreen) {
            Screen.PRODUCT_DETAIL -> viewModel.navigateTo(Screen.MENU)
            Screen.COMBO_BUILDER -> viewModel.navigateTo(Screen.MENU)
            Screen.BASKET_CHECKOUT -> viewModel.navigateTo(Screen.MENU)
            Screen.PAYMENT -> viewModel.navigateTo(Screen.BASKET_CHECKOUT)
            Screen.ORDER_CONFIRMATION -> viewModel.resetKioskSession()
            Screen.PICKUP_CHECKIN -> viewModel.navigateTo(Screen.WELCOME)
            Screen.ASSISTANCE -> viewModel.navigateTo(Screen.WELCOME)
            Screen.KITCHEN_KDS -> viewModel.navigateTo(Screen.WELCOME)
            Screen.FOOD_RUNNER -> viewModel.navigateTo(Screen.WELCOME)
            Screen.STAFF_DASHBOARD -> viewModel.navigateTo(Screen.WELCOME)
            else -> viewModel.navigateTo(Screen.WELCOME)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            Column {
                KioskTopBar(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                if (currentScreen != Screen.KITCHEN_KDS && currentScreen != Screen.FOOD_RUNNER) {
                    AccessibilityBar(
                        viewModel = viewModel,
                        onRequestAssistance = { viewModel.requestStaffAssistance("Accessibility / General Help") }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                Screen.WELCOME -> WelcomeScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.MENU -> MenuBrowsingScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.PRODUCT_DETAIL -> ProductDetailModal(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.COMBO_BUILDER -> ComboBuilderScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.BASKET_CHECKOUT -> BasketCheckoutScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.PAYMENT -> PaymentScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.ORDER_CONFIRMATION -> OrderConfirmationScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.PICKUP_CHECKIN -> PickUpCheckInScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.ASSISTANCE -> AssistanceScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.KITCHEN_KDS -> KitchenDssScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.FOOD_RUNNER -> FoodRunnerScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.TABLE_SELECTION -> BasketCheckoutScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
                Screen.STAFF_DASHBOARD -> StaffDashboardScreen(
                    viewModel = viewModel,
                    onNavigate = { viewModel.navigateTo(it) }
                )
            }
        }
    }
}
