package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.MenuItem
import com.example.data.models.Screen
import com.example.ui.theme.WendysGold
import com.example.ui.theme.WendysRed
import com.example.viewmodel.KioskViewModel

@Composable
fun ComboBuilderScreen(
    viewModel: KioskViewModel,
    onNavigate: (Screen) -> Unit
) {
    val mainItem by viewModel.comboMainItem.collectAsState()
    val sideItem by viewModel.comboSideItem.collectAsState()
    val drinkItem by viewModel.comboDrinkItem.collectAsState()
    val menuItems by viewModel.menuItems.collectAsState()

    val availableSides = remember(menuItems) { menuItems.filter { it.categoryId == "cat_sides" } }
    val availableDrinks = remember(menuItems) { menuItems.filter { it.categoryId == "cat_drinks" || it.categoryId == "cat_frosty" } }

    val comboTotalPrice = remember(mainItem, sideItem, drinkItem) {
        val mPrice = mainItem?.price ?: 0.0
        val sPrice = (sideItem?.price ?: 0.0) * 0.8
        val dPrice = (drinkItem?.price ?: 0.0) * 0.8
        mPrice + sPrice + dPrice
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onNavigate(Screen.MENU) }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("BUILD YOUR MEAL COMBO", fontSize = 22.sp, fontWeight = FontWeight.Black, color = WendysRed)
                    Text("Select your favorite side and drink to complete your meal", fontSize = 13.sp, color = Color.Gray)
                }
            }
        }

        Column(
            modifier = Modifier
                .weight(1f)
                .padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Main Item Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(color = WendysGold, shape = RoundedCornerShape(8.dp)) {
                        Text("STEP 1: MAIN", fontSize = 11.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                    }
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(mainItem?.name ?: "Main Entree", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Text("$${String.format("%.2f", mainItem?.price ?: 0.0)}", fontSize = 14.sp, color = WendysRed, fontWeight = FontWeight.Bold)
                    }
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = WendysRed)
                }
            }

            // Step 2: Choose Side
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = WendysGold, shape = RoundedCornerShape(8.dp)) {
                            Text("STEP 2: CHOOSE SIDE", fontSize = 11.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(sideItem?.name ?: "Select a side", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(availableSides, key = { it.id }) { item ->
                            val isSelected = sideItem?.id == item.id
                            Surface(
                                modifier = Modifier
                                    .width(180.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { viewModel.selectComboSide(item) }
                                    .testTag("combo_side_${item.id}"),
                                color = if (isSelected) WendysRed.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, WendysRed) else null
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(item.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text("$${String.format("%.2f", item.price * 0.8)} (Combo Price)", fontSize = 12.sp, color = WendysRed, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }

            // Step 3: Choose Drink
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(color = WendysGold, shape = RoundedCornerShape(8.dp)) {
                            Text("STEP 3: CHOOSE DRINK", fontSize = 11.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(drinkItem?.name ?: "Select a drink", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(availableDrinks, key = { it.id }) { item ->
                            val isSelected = drinkItem?.id == item.id
                            Surface(
                                modifier = Modifier
                                    .width(180.dp)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { viewModel.selectComboDrink(item) }
                                    .testTag("combo_drink_${item.id}"),
                                color = if (isSelected) WendysRed.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                                border = if (isSelected) androidx.compose.foundation.BorderStroke(2.dp, WendysRed) else null
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(item.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                    Text("$${String.format("%.2f", item.price * 0.8)} (Combo Price)", fontSize = 12.sp, color = WendysRed, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Bar
        Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 12.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Combo Meal Price", fontSize = 13.sp, color = Color.Gray)
                    Text("$${String.format("%.2f", comboTotalPrice)}", fontSize = 28.sp, fontWeight = FontWeight.Black, color = WendysRed)
                }

                Button(
                    onClick = { viewModel.addComboToBasket() },
                    colors = ButtonDefaults.buttonColors(containerColor = WendysRed),
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .height(56.dp)
                        .width(320.dp)
                        .testTag("add_combo_to_basket_button")
                ) {
                    Text("ADD COMBO TO BASKET", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
