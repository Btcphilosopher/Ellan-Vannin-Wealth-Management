package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Screen
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.WendysGold
import com.example.ui.theme.WendysRed
import com.example.viewmodel.KioskViewModel

@Composable
fun StaffDashboardScreen(
    viewModel: KioskViewModel,
    onNavigate: (Screen) -> Unit
) {
    val orders by viewModel.orders.collectAsState()
    val menuItems by viewModel.menuItems.collectAsState()
    val queueTickets by viewModel.queueTickets.collectAsState()
    val assistanceRequests by viewModel.assistanceRequests.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: Live KPIs, 1: Menu Stock Control, 2: Queue & Assistance, 3: Kiosk Diagnostics

    val totalSales = remember(orders) { orders.sumOf { it.total } }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Staff Header
        Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onNavigate(Screen.WELCOME) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Exit Dashboard")
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(WendysRed, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Dashboard, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("RESTAURANT MANAGER & STAFF DASHBOARD", fontSize = 20.sp, fontWeight = FontWeight.Black, color = WendysRed)
                        Text("Kiosk Metrics, Menu Stock Control & Customer Assistance", fontSize = 13.sp, color = Color.Gray)
                    }
                }

                // Tabs
                TabRow(
                    selectedTabIndex = activeTab,
                    modifier = Modifier.width(540.dp)
                ) {
                    Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text("KPI Analytics", fontWeight = FontWeight.Bold) })
                    Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text("Menu Stock", fontWeight = FontWeight.Bold) })
                    Tab(selected = activeTab == 2, onClick = { activeTab = 2 }, text = { Text("Queue & Calls", fontWeight = FontWeight.Bold) })
                    Tab(selected = activeTab == 3, onClick = { activeTab = 3 }, text = { Text("Kiosk Health", fontWeight = FontWeight.Bold) })
                }
            }
        }

        // Tab Content
        Box(
            modifier = Modifier
                .weight(1f)
                .padding(24.dp)
        ) {
            when (activeTab) {
                0 -> {
                    // KPI Analytics
                    Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(16.dp), modifier = Modifier.fillMaxWidth()) {
                            KpiCard("TOTAL KIOSK SALES", "$${String.format("%.2f", totalSales)}", "+18.4% today", Icons.Default.AttachMoney, WendysRed, Modifier.weight(1f))
                            KpiCard("TOTAL ORDERS", "${orders.size}", "12 table deliveries", Icons.Default.ReceiptLong, WendysGold, Modifier.weight(1f))
                            KpiCard("AVG PREP TIME", "4m 12s", "Target < 5.0m", Icons.Default.Timer, StatusGreen, Modifier.weight(1f))
                            KpiCard("ACTIVE QUEUE", "${queueTickets.count { it.status == "WAITING" }}", "0 calls pending", Icons.Default.People, Color(0xFF0277BD), Modifier.weight(1f))
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text("Recent Kiosk Transactions", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(12.dp))
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    items(orders) { o ->
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text("#${o.orderNumber}", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                                Spacer(modifier = Modifier.width(12.dp))
                                                Text(o.serviceMethod.name, fontSize = 12.sp, color = Color.Gray)
                                            }
                                            Text("$${String.format("%.2f", o.total)}", fontWeight = FontWeight.Bold, color = WendysRed)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> {
                    // Menu Stock Control
                    Card(
                        modifier = Modifier.fillMaxSize(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(20.dp)) {
                            Text("Real-Time Menu Stock & Availability", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("Toggle items off when out of stock. Changes apply instantly across all kiosks.", fontSize = 13.sp, color = Color.Gray)

                            Spacer(modifier = Modifier.height(16.dp))

                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                items(menuItems, key = { it.id }) { item ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(item.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                            Text("$${String.format("%.2f", item.price)} • ${item.categoryId}", fontSize = 12.sp, color = Color.Gray)
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = if (item.isAvailable) "IN STOCK" else "SOLD OUT",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (item.isAvailable) StatusGreen else MaterialTheme.colorScheme.error
                                            )
                                            Spacer(modifier = Modifier.width(12.dp))
                                            Switch(
                                                checked = item.isAvailable,
                                                onCheckedChange = { viewModel.toggleItemAvailability(item.id) },
                                                colors = SwitchDefaults.colors(checkedThumbColor = WendysRed)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                2 -> {
                    // Queue & Assistance Calls
                    Row(modifier = Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                        Card(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(modifier = Modifier.padding(20.dp)) {
                                Text("Customer Assistance Requests", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(12.dp))
                                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    items(assistanceRequests) { req ->
                                        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                                            Row(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(12.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Column(modifier = Modifier.weight(1f)) {
                                                    Text(req.kioskId, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                                    Text(req.reason, fontSize = 12.sp, color = Color.Gray)
                                                }
                                                if (!req.isResolved) {
                                                    Button(
                                                        onClick = { viewModel.resolveAssistanceRequest(req.requestId) },
                                                        colors = ButtonDefaults.buttonColors(containerColor = StatusGreen)
                                                    ) {
                                                        Text("RESOLVE", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                                    }
                                                } else {
                                                    Text("RESOLVED", fontSize = 12.sp, color = StatusGreen, fontWeight = FontWeight.Bold)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                3 -> {
                    // Kiosk Diagnostics
                    Card(
                        modifier = Modifier.fillMaxSize(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(24.dp)) {
                            Text("Kiosk Terminal Diagnostics & Hardware Health", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(16.dp))

                            DiagnosticItem("Kiosk Terminal #1 (Entrance)", "ONLINE — Heartbeat 2s ago", StatusGreen)
                            DiagnosticItem("Verifone Card Reader", "CONNECTED — Contactless & EMV Active", StatusGreen)
                            DiagnosticItem("Thermal Receipt Printer", "PAPER LOW — 15% Roll Remaining", WendysGold)
                            DiagnosticItem("2D Barcode & QR Scanner", "READY — Camera Auto-Focus Active", StatusGreen)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KpiCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.onSurface)
            Spacer(modifier = Modifier.height(2.dp))
            Text(subtitle, fontSize = 11.sp, color = accentColor, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun DiagnosticItem(title: String, status: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            Text(status, fontSize = 13.sp, color = Color.Gray)
        }
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(color, CircleShape)
        )
    }
    Divider()
}
