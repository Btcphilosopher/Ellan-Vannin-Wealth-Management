package com.example.data.repository

import com.example.data.models.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

class RestaurantRepository {

    val locations = listOf(
        LocationInfo("loc_1", "Wendy's Downtown Flagship", "101 Main St, City Center"),
        LocationInfo("loc_2", "Wendy's Airport Terminal 2", "Gateway Airport, Concourse B"),
        LocationInfo("loc_3", "Wendy's Westside Drive-Thru", "405 Highway 99 West")
    )

    private val _currentLocation = MutableStateFlow(locations[0])
    val currentLocation: StateFlow<LocationInfo> = _currentLocation.asStateFlow()

    val categories = listOf(
        MenuCategory("cat_combos", "Combos & Meals", "Full meal combos with fries & drink", "local_dining"),
        MenuCategory("cat_burgers", "Burgers", "Fresh 100% beef hamburgers made to order", "lunch_dining"),
        MenuCategory("cat_chicken", "Chicken & Nuggets", "Crispy fillets & tender 100% white meat nuggets", "kebab_dining"),
        MenuCategory("cat_sides", "Fries & Sides", "Natural-cut sea salt fries, chili & cheese fries", "fastfood"),
        MenuCategory("cat_frosty", "Frosty® & Desserts", "Classic thick & creamy Frosty treats", "icecream"),
        MenuCategory("cat_drinks", "Beverages", "Coca-Cola Freestyle® & Dave's Craft Lemonade", "local_bar"),
        MenuCategory("cat_salads", "Fresh Salads", "Hand-shredded parmesan & grilled chicken salads", "rice_bowl")
    )

    private val defaultBurgerModifiers = listOf(
        ModifierGroup(
            id = "mod_toppings",
            name = "Customise Ingredients",
            isRequired = false,
            minSelection = 0,
            maxSelection = 6,
            options = listOf(
                ModifierOption("opt_no_pickle", "No Pickles", 0.0),
                ModifierOption("opt_no_mayo", "No Mayo", 0.0),
                ModifierOption("opt_no_onion", "No Onions", 0.0),
                ModifierOption("opt_no_ketchup", "No Ketchup", 0.0),
                ModifierOption("opt_extra_cheese", "Extra American Cheese", 0.75),
                ModifierOption("opt_extra_bacon", "Extra Applewood Bacon (2 strips)", 1.50),
                ModifierOption("opt_extra_patty", "Extra Fresh Beef Patty", 2.50)
            )
        )
    )

    private val defaultSauceModifiers = listOf(
        ModifierGroup(
            id = "mod_sauces",
            name = "Choice of Dipping Sauce",
            isRequired = true,
            minSelection = 1,
            maxSelection = 2,
            options = listOf(
                ModifierOption("sauce_honey_mustard", "Honey Mustard", 0.0, isDefault = true),
                ModifierOption("sauce_bbq", "Smoky BBQ", 0.0),
                ModifierOption("sauce_ranch", "Buttermilk Ranch", 0.0),
                ModifierOption("sauce_ghost_pepper", "Ghost Pepper Ranch", 0.0)
            )
        )
    )

    private val defaultSizeModifiers = listOf(
        ModifierGroup(
            id = "mod_size",
            name = "Select Size",
            isRequired = true,
            minSelection = 1,
            maxSelection = 1,
            options = listOf(
                ModifierOption("size_small", "Small", 0.0, isDefault = true),
                ModifierOption("size_medium", "Medium", 0.60),
                ModifierOption("size_large", "Large", 1.20)
            )
        )
    )

    private val initialMenuItems = listOf(
        MenuItem(
            id = "item_baconator",
            name = "Baconator®",
            description = "Half-pound of fresh beef, 6 strips of crispy Applewood smoked bacon, American cheese, ketchup, and mayo.",
            price = 8.99,
            categoryId = "cat_burgers",
            imageResName = "img_baconator",
            isAvailable = true,
            isComboEligible = true,
            calories = 960,
            allergens = listOf("Milk", "Wheat", "Soy", "Egg"),
            modifierGroups = defaultBurgerModifiers
        ),
        MenuItem(
            id = "item_daves_single",
            name = "Dave's Single®",
            description = "A quarter-pound of fresh beef, American cheese, crisp lettuce, tomato, pickle, ketchup, mayo, and onion on a toasted bun.",
            price = 6.49,
            categoryId = "cat_burgers",
            imageResName = "img_baconator",
            isAvailable = true,
            isComboEligible = true,
            calories = 590,
            allergens = listOf("Milk", "Wheat", "Soy"),
            modifierGroups = defaultBurgerModifiers
        ),
        MenuItem(
            id = "item_daves_double",
            name = "Dave's Double®",
            description = "Half-pound of fresh beef, two slices of American cheese, crisp lettuce, tomato, pickle, ketchup, mayo, and onion.",
            price = 7.79,
            categoryId = "cat_burgers",
            imageResName = "img_baconator",
            isAvailable = true,
            isComboEligible = true,
            calories = 860,
            allergens = listOf("Milk", "Wheat", "Soy"),
            modifierGroups = defaultBurgerModifiers
        ),
        MenuItem(
            id = "item_spicy_chicken",
            name = "Spicy Chicken Sandwich",
            description = "Juicy chicken breast marinated and breaded in fiery blend of peppers and spices, topped with lettuce, mayo, and tomato.",
            price = 7.29,
            categoryId = "cat_chicken",
            imageResName = "img_spicy_chicken",
            isAvailable = true,
            isComboEligible = true,
            calories = 510,
            allergens = listOf("Wheat", "Egg"),
            modifierGroups = defaultBurgerModifiers
        ),
        MenuItem(
            id = "item_nuggets_10",
            name = "10 Pc. Chicken Nuggets",
            description = "100% white-meat chicken nuggets, crispy fried to golden perfection with your favorite dipping sauce.",
            price = 5.99,
            categoryId = "cat_chicken",
            imageResName = "img_spicy_chicken",
            isAvailable = true,
            isComboEligible = true,
            calories = 420,
            allergens = listOf("Wheat"),
            modifierGroups = defaultSauceModifiers
        ),
        MenuItem(
            id = "item_fries",
            name = "Natural-Cut Sea Salt Fries",
            description = "Skin-on, natural-cut potatoes cooked crisp and sprinkled with real sea salt.",
            price = 2.99,
            categoryId = "cat_sides",
            imageResName = "img_hero_banner",
            isAvailable = true,
            isComboEligible = true,
            calories = 350,
            allergens = emptyList(),
            modifierGroups = defaultSizeModifiers
        ),
        MenuItem(
            id = "item_bacon_fries",
            name = "Bacon Supreme Cheese Fries",
            description = "Natural-cut fries smothered in warm creamy cheese sauce, shredded cheddar, and crispy Applewood bacon.",
            price = 4.49,
            categoryId = "cat_sides",
            imageResName = "img_hero_banner",
            isAvailable = true,
            isComboEligible = false,
            calories = 510,
            allergens = listOf("Milk"),
            modifierGroups = emptyList()
        ),
        MenuItem(
            id = "item_chili",
            name = "Wendy's Famous Chili",
            description = "Hearty chili cooked slow with fresh ground beef, beans, onions, tomatoes, and peppers.",
            price = 3.99,
            categoryId = "cat_sides",
            imageResName = "img_hero_banner",
            isAvailable = true,
            isComboEligible = false,
            calories = 340,
            allergens = emptyList(),
            modifierGroups = emptyList()
        ),
        MenuItem(
            id = "item_frosty_choco",
            name = "Classic Chocolate Frosty®",
            description = "The iconic thick, creamy chocolate dessert spoonable treat loved for over 50 years.",
            price = 2.49,
            categoryId = "cat_frosty",
            imageResName = "img_frosty",
            isAvailable = true,
            isComboEligible = false,
            calories = 350,
            allergens = listOf("Milk"),
            modifierGroups = defaultSizeModifiers
        ),
        MenuItem(
            id = "item_frosty_strawberry",
            name = "Strawberry Frosty®",
            description = "Smooth and sweet strawberry twist on our classic thick Frosty recipe.",
            price = 2.49,
            categoryId = "cat_frosty",
            imageResName = "img_frosty",
            isAvailable = true,
            isComboEligible = false,
            calories = 340,
            allergens = listOf("Milk"),
            modifierGroups = defaultSizeModifiers
        ),
        MenuItem(
            id = "item_lemonade",
            name = "Dave's Craft Strawberry Lemonade",
            description = "Real lemon juice blended with natural strawberry puree for a refreshing tart beverage.",
            price = 3.49,
            categoryId = "cat_drinks",
            imageResName = "img_hero_banner",
            isAvailable = true,
            isComboEligible = true,
            calories = 230,
            allergens = emptyList(),
            modifierGroups = defaultSizeModifiers
        ),
        MenuItem(
            id = "item_cola",
            name = "Coca-Cola® Freestyle",
            description = "Ice cold fountain drink with over 100 customizable flavor choices.",
            price = 2.79,
            categoryId = "cat_drinks",
            imageResName = "img_hero_banner",
            isAvailable = true,
            isComboEligible = true,
            calories = 190,
            allergens = emptyList(),
            modifierGroups = defaultSizeModifiers
        ),
        MenuItem(
            id = "item_salad_parm",
            name = "Parmesan Caesar Chicken Salad",
            description = "Fresh romaine lettuce, greenhouse tomatoes, grilled chicken breast, shaved parmesan cheese, and croutons with Caesar dressing.",
            price = 8.49,
            categoryId = "cat_salads",
            imageResName = "img_spicy_chicken",
            isAvailable = true,
            isComboEligible = false,
            calories = 440,
            allergens = listOf("Milk", "Wheat", "Egg"),
            modifierGroups = emptyList()
        )
    )

    private val _menuItems = MutableStateFlow(initialMenuItems)
    val menuItems: StateFlow<List<MenuItem>> = _menuItems.asStateFlow()

    val diningZones = listOf(
        DiningZone("zone_a", "Main Dining Hall", "Central dining seating near kiosk"),
        DiningZone("zone_b", "Window Booths", "Cozy booths facing main window"),
        DiningZone("zone_c", "Patio Garden", "Outdoor covered patio area")
    )

    private val initialTables = (1..24).map { tableNum ->
        val zone = when {
            tableNum <= 10 -> "zone_a"
            tableNum <= 18 -> "zone_b"
            else -> "zone_c"
        }
        val capacity = if (tableNum % 4 == 0) 6 else 4
        val isOccupied = tableNum == 5 || tableNum == 12
        DiningTable(
            tableNumber = tableNum,
            zoneId = zone,
            capacity = capacity,
            isOccupied = isOccupied,
            activeOrderId = if (tableNum == 5) "ORD-1038" else if (tableNum == 12) "ORD-1039" else null
        )
    }

    private val _diningTables = MutableStateFlow(initialTables)
    val diningTables: StateFlow<List<DiningTable>> = _diningTables.asStateFlow()

    private val initialOrders = mutableListOf(
        Order(
            orderId = "ORD-1038",
            orderNumber = 1038,
            timestamp = System.currentTimeMillis() - 8 * 60 * 1000,
            serviceMethod = ServiceMethod.DINE_IN_TABLE_DELIVERY,
            tableNumber = 5,
            diningZone = "Main Dining Hall",
            items = listOf(
                BasketItem(
                    id = "b1",
                    menuItem = initialMenuItems[0], // Baconator
                    quantity = 1,
                    selectedModifiers = listOf(ModifierOption("opt_extra_cheese", "Extra American Cheese", 0.75))
                ),
                BasketItem(
                    id = "b2",
                    menuItem = initialMenuItems[5], // Fries
                    quantity = 1
                ),
                BasketItem(
                    id = "b3",
                    menuItem = initialMenuItems[11], // Cola
                    quantity = 1
                )
            ),
            subtotal = 14.77,
            tax = 1.18,
            total = 15.95,
            paymentMethod = PaymentMethod.CONTACTLESS,
            paymentStatus = PaymentStatus.CAPTURED,
            prepStatus = PrepStatus.PREPARING,
            fulfilmentStatus = FulfilmentStatus.NOT_READY
        ),
        Order(
            orderId = "ORD-1039",
            orderNumber = 1039,
            timestamp = System.currentTimeMillis() - 14 * 60 * 1000,
            serviceMethod = ServiceMethod.DINE_IN_TABLE_DELIVERY,
            tableNumber = 12,
            diningZone = "Window Booths",
            items = listOf(
                BasketItem(
                    id = "b4",
                    menuItem = initialMenuItems[3], // Spicy chicken
                    quantity = 1
                ),
                BasketItem(
                    id = "b5",
                    menuItem = initialMenuItems[7], // Frosty
                    quantity = 1
                )
            ),
            subtotal = 9.78,
            tax = 0.78,
            total = 10.56,
            paymentMethod = PaymentMethod.MOBILE_WALLET,
            paymentStatus = PaymentStatus.CAPTURED,
            prepStatus = PrepStatus.READY,
            fulfilmentStatus = FulfilmentStatus.AWAITING_TABLE_DELIVERY
        ),
        Order(
            orderId = "ORD-1040",
            orderNumber = 1040,
            timestamp = System.currentTimeMillis() - 20 * 60 * 1000,
            serviceMethod = ServiceMethod.TAKEAWAY,
            pickupToken = "ORD-9921",
            items = listOf(
                BasketItem(
                    id = "b6",
                    menuItem = initialMenuItems[1], // Dave's single
                    quantity = 2
                )
            ),
            subtotal = 12.98,
            tax = 1.04,
            total = 14.02,
            paymentMethod = PaymentMethod.CHIP_PIN,
            paymentStatus = PaymentStatus.CAPTURED,
            prepStatus = PrepStatus.READY,
            fulfilmentStatus = FulfilmentStatus.AWAITING_PICKUP,
            arrivalStatus = ArrivalStatus.NOT_ARRIVED
        )
    )

    private val _orders = MutableStateFlow<List<Order>>(initialOrders)
    val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _queueTickets = MutableStateFlow<List<QueueTicket>>(
        listOf(
            QueueTicket("q1", "A041", "Alex M.", "Special Order Allergy Check", System.currentTimeMillis() - 5 * 60 * 1000, "WAITING")
        )
    )
    val queueTickets: StateFlow<List<QueueTicket>> = _queueTickets.asStateFlow()

    private val _assistanceRequests = MutableStateFlow<List<AssistanceRequest>>(
        listOf(
            AssistanceRequest("req1", "Kiosk #2 (Drive-thru Door)", "Need help choosing gluten-free item", System.currentTimeMillis() - 2 * 60 * 1000)
        )
    )
    val assistanceRequests: StateFlow<List<AssistanceRequest>> = _assistanceRequests.asStateFlow()

    private var nextOrderNumber = 1041

    fun toggleItemAvailability(itemId: String) {
        _menuItems.update { current ->
            current.map { item ->
                if (item.id == itemId) item.copy(isAvailable = !item.isAvailable) else item
            }
        }
    }

    fun submitOrder(
        serviceMethod: ServiceMethod,
        tableNumber: Int?,
        diningZone: String?,
        basketItems: List<BasketItem>,
        paymentMethod: PaymentMethod,
        customerPhone: String?,
        pickupToken: String?
    ): Order {
        val orderNum = nextOrderNumber++
        val subtotal = basketItems.sumOf { it.totalPrice }
        val tax = subtotal * 0.08
        val total = subtotal + tax

        val order = Order(
            orderId = "ORD-$orderNum",
            orderNumber = orderNum,
            timestamp = System.currentTimeMillis(),
            serviceMethod = serviceMethod,
            tableNumber = tableNumber,
            diningZone = diningZone,
            items = basketItems,
            subtotal = subtotal,
            tax = tax,
            total = total,
            paymentMethod = paymentMethod,
            paymentStatus = PaymentStatus.CAPTURED,
            prepStatus = PrepStatus.RECEIVED,
            fulfilmentStatus = when (serviceMethod) {
                ServiceMethod.DINE_IN_TABLE_DELIVERY -> FulfilmentStatus.NOT_READY
                ServiceMethod.DINE_IN_COUNTER_PICKUP -> FulfilmentStatus.NOT_READY
                ServiceMethod.TAKEAWAY -> FulfilmentStatus.NOT_READY
            },
            customerPhone = customerPhone,
            pickupToken = pickupToken ?: "PICK-$orderNum"
        )

        _orders.update { listOf(order) + it }

        if (tableNumber != null) {
            _diningTables.update { tables ->
                tables.map { t ->
                    if (t.tableNumber == tableNumber) {
                        t.copy(isOccupied = true, activeOrderId = order.orderId)
                    } else t
                }
            }
        }

        return order
    }

    fun updatePrepStatus(orderId: String, newPrepStatus: PrepStatus) {
        _orders.update { list ->
            list.map { o ->
                if (o.orderId == orderId) {
                    val newFulfilment = when (newPrepStatus) {
                        PrepStatus.READY -> {
                            if (o.serviceMethod == ServiceMethod.DINE_IN_TABLE_DELIVERY) {
                                FulfilmentStatus.AWAITING_TABLE_DELIVERY
                            } else {
                                FulfilmentStatus.AWAITING_PICKUP
                            }
                        }
                        else -> o.fulfilmentStatus
                    }
                    o.copy(prepStatus = newPrepStatus, fulfilmentStatus = newFulfilment)
                } else o
            }
        }
    }

    fun updateFulfilmentStatus(orderId: String, newFulfilment: FulfilmentStatus, runnerName: String? = null) {
        _orders.update { list ->
            list.map { o ->
                if (o.orderId == orderId) {
                    o.copy(fulfilmentStatus = newFulfilment, runnerName = runnerName ?: o.runnerName)
                } else o
            }
        }
    }

    fun confirmArrival(orderIdOrToken: String): Order? {
        var found: Order? = null
        _orders.update { list ->
            list.map { o ->
                if (o.orderId.equals(orderIdOrToken, ignoreCase = true) ||
                    o.pickupToken?.equals(orderIdOrToken, ignoreCase = true) == true ||
                    o.orderNumber.toString() == orderIdOrToken
                ) {
                    val updated = o.copy(arrivalStatus = ArrivalStatus.ARRIVED)
                    found = updated
                    updated
                } else o
            }
        }
        return found
    }

    fun requestAssistance(reason: String, kioskId: String = "Kiosk #1 (Entrance)"): AssistanceRequest {
        val req = AssistanceRequest(
            requestId = "req_${System.currentTimeMillis()}",
            kioskId = kioskId,
            reason = reason
        )
        _assistanceRequests.update { listOf(req) + it }
        return req
    }

    fun resolveAssistance(requestId: String) {
        _assistanceRequests.update { list ->
            list.map { if (it.requestId == requestId) it.copy(isResolved = true) else it }
        }
    }

    fun joinQueue(customerName: String, reason: String): QueueTicket {
        val ticketNum = "A" + (100 + (_queueTickets.value.size + 1))
        val ticket = QueueTicket(
            ticketId = "q_${System.currentTimeMillis()}",
            ticketNumber = ticketNum,
            customerName = customerName,
            reason = reason
        )
        _queueTickets.update { listOf(ticket) + it }
        return ticket
    }

    fun callQueueTicket(ticketId: String, counter: String) {
        _queueTickets.update { list ->
            list.map { if (it.ticketId == ticketId) it.copy(status = "CALLED", counter = counter) else it }
        }
    }

    fun completeQueueTicket(ticketId: String) {
        _queueTickets.update { list ->
            list.map { if (it.ticketId == ticketId) it.copy(status = "COMPLETED") else it }
        }
    }
}
