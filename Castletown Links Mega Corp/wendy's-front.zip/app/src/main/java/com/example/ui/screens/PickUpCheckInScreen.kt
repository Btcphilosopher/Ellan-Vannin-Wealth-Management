package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.ArrivalStatus
import com.example.data.models.Screen
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.WendysGold
import com.example.ui.theme.WendysRed
import com.example.viewmodel.KioskViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PickUpCheckInScreen(
    viewModel: KioskViewModel,
    onNavigate: (Screen) -> Unit
) {
    val pickupInput by viewModel.pickupInput.collectAsState()
    val foundOrder by viewModel.foundPickupOrder.collectAsState()
    val pickupMessage by viewModel.pickupMessage.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Bar
        Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = { onNavigate(Screen.WELCOME) }) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text("I'M HERE TO PICK UP — ORDER CHECK-IN", fontSize = 22.sp, fontWeight = FontWeight.Black, color = WendysRed)
                    Text("Notify restaurant staff of your arrival for quick collection", fontSize = 13.sp, color = Color.Gray)
                }
            }
        }

        Row(
            modifier = Modifier
                .weight(1f)
                .padding(32.dp),
            horizontalArrangement = Arrangement.spacedBy(32.dp)
        ) {
            // Left Column: Manual Reference Input
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(28.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("Enter Order Reference", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Enter your Order # (e.g. 1040) or Pickup Code (e.g. ORD-9921)", fontSize = 13.sp, color = Color.Gray)

                        Spacer(modifier = Modifier.height(24.dp))

                        OutlinedTextField(
                            value = pickupInput,
                            onValueChange = { viewModel.setPickupInput(it) },
                            label = { Text("Order # or Pickup Code") },
                            leadingIcon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = null) },
                            singleLine = true,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("pickup_input_field")
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = { viewModel.searchPickupOrder() },
                            colors = ButtonDefaults.buttonColors(containerColor = WendysRed),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("checkin_search_button")
                        ) {
                            Icon(Icons.Default.Search, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("CONFIRM MY ARRIVAL", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        }

                        // Demo Quick Chips
                        Spacer(modifier = Modifier.height(20.dp))
                        Text("Demo Test Orders:", fontSize = 12.sp, color = Color.Gray)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SuggestionChip(
                                onClick = {
                                    viewModel.setPickupInput("ORD-9921")
                                    viewModel.searchPickupOrder()
                                },
                                label = { Text("ORD-9921") }
                            )
                            SuggestionChip(
                                onClick = {
                                    viewModel.setPickupInput("1039")
                                    viewModel.searchPickupOrder()
                                },
                                label = { Text("#1039") }
                            )
                        }
                    }

                    // Result Alert
                    if (pickupMessage != null) {
                        Surface(
                            color = if (foundOrder != null) StatusGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(16.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (foundOrder != null) Icons.Default.CheckCircle else Icons.Default.Error,
                                    contentDescription = null,
                                    tint = if (foundOrder != null) StatusGreen else MaterialTheme.colorScheme.error
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Text(
                                    text = pickupMessage!!,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = if (foundOrder != null) StatusGreen else MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                }
            }

            // Right Column: Simulated QR Code Viewfinder Scanner
            Card(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(24.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("SCAN YOUR QR RECEIPT", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Hold your mobile phone QR receipt below camera scanner", fontSize = 13.sp, color = Color.Gray)
                    }

                    // QR Camera Viewfinder Box
                    Box(
                        modifier = Modifier
                            .size(240.dp)
                            .clip(RoundedCornerShape(24.dp))
                            .background(Color.Black)
                            .border(3.dp, WendysRed, RoundedCornerShape(24.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            Icons.Default.QrCodeScanner,
                            contentDescription = "QR Scanner",
                            tint = WendysGold,
                            modifier = Modifier.size(100.dp)
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.setPickupInput("ORD-9921")
                            viewModel.searchPickupOrder()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = WendysGold, contentColor = Color.Black),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("simulate_qr_scan_button")
                    ) {
                        Icon(Icons.Default.CameraAlt, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SIMULATE QR CODE SCAN", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
