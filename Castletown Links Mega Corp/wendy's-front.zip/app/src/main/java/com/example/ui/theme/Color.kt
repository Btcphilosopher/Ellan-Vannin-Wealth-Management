package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val WendysRed = Color(0xFFDA291C)
val WendysRedDark = Color(0xFFB01C13)
val WendysRedLight = Color(0xFFFF5247)
val WendysGold = Color(0xFFFFB81C)
val WendysGoldDark = Color(0xFFD69400)

val SurfaceWarmLight = Color(0xFFFAF8F5)
val SurfaceCardWhite = Color(0xFFFFFFFF)
val SurfaceContainerRed = Color(0xFFFFF0F0)

val TextPrimaryDark = Color(0xFF1E1B1E)
val TextSecondaryMuted = Color(0xFF5A5458)

val StatusGreen = Color(0xFF1B873F)
val StatusGreenContainer = Color(0xFFE8F5E9)
val StatusOrange = Color(0xFFE65100)
val StatusOrangeContainer = Color(0xFFFFF3E0)
val StatusBlue = Color(0xFF0277BD)
val StatusBlueContainer = Color(0xFFE1F5FE)

val HighContrastBackground = Color(0xFF000000)
val HighContrastSurface = Color(0xFF1C1C1E)
val HighContrastText = Color(0xFFFFFFFF)
val HighContrastAccent = Color(0xFFFFD600)
