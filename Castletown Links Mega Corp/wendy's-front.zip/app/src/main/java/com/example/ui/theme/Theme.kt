package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = WendysRed,
    onPrimary = Color.White,
    primaryContainer = SurfaceContainerRed,
    onPrimaryContainer = WendysRedDark,
    secondary = WendysGold,
    onSecondary = TextPrimaryDark,
    secondaryContainer = Color(0xFFFFF3D6),
    onSecondaryContainer = WendysGoldDark,
    tertiary = StatusBlue,
    onTertiary = Color.White,
    background = SurfaceWarmLight,
    onBackground = TextPrimaryDark,
    surface = SurfaceCardWhite,
    onSurface = TextPrimaryDark,
    surfaceVariant = Color(0xFFF2ECE6),
    onSurfaceVariant = TextSecondaryMuted,
    outline = Color(0xFFD3C9C1),
    error = Color(0xFFBA1A1A),
    onError = Color.White
)

private val HighContrastColorScheme = darkColorScheme(
    primary = HighContrastAccent,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF333300),
    onPrimaryContainer = HighContrastAccent,
    secondary = Color(0xFFFFFFFF),
    onSecondary = Color.Black,
    background = HighContrastBackground,
    onBackground = HighContrastText,
    surface = HighContrastSurface,
    onSurface = HighContrastText,
    outline = Color(0xFF888888)
)

@Composable
fun WendysFrontTheme(
    isHighContrast: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = if (isHighContrast) HighContrastColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
