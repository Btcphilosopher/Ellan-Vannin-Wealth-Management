package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.FulfilmentStatus
import com.example.data.models.Order
import com.example.data.models.Screen
import com.example.data.models.ServiceMethod
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.WendysGold
import com.example.ui.theme.WendysRed
import com.example.viewmodel.KioskViewModel

@Composable
fun FoodRunnerScreen(
    viewModel: KioskViewModel,
    onNavigate: (Screen) -> Unit
) {
    val orders by viewModel.orders.collectAsState()

    val tableDeliveryOrders = remember(orders) {
        orders.filter {
            it.serviceMethod == ServiceMethod.DINE_IN_TABLE_DELIVERY &&
                    it.fulfilmentStatus != FulfilmentStatus.COMPLETED
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Header
        Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onNavigate(Screen.WELCOME) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Exit Runner Screen")
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .background(WendysRed, RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.DirectionsRun, contentDescription = null, tint = Color.White, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("FOOD RUNNER — TABLE DELIVERY QUEUE", fontSize = 20.sp, fontWeight = FontWeight.Black, color = WendysRed)
                        Text("Dispatch prepared orders to guest tables", fontSize = 13.sp, color = Color.Gray)
                    }
                }
            }
        }

        if (tableDeliveryOrders.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("NO PENDING TABLE DELIVERIES", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("All dine-in table orders have been delivered to guests", fontSize = 14.sp, color = Color.Gray)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(tableDeliveryOrders, key = { it.orderId }) { order ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(20.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    color = WendysGold,
                                    shape = RoundedCornerShape(16.dp),
                                    modifier = Modifier.size(80.dp)
                                ) {
                                    Column(
                                        modifier = Modifier.fillMaxSize(),
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        verticalArrangement = Arrangement.Center
                                    ) {
                                        Text("TABLE", fontSize = 11.sp, fontWeight = FontWeight.Black, color = Color.Black)
                                        Text("${order.tableNumber}", fontSize = 32.sp, fontWeight = FontWeight.Black, color = WendysRed)
                                    }
                                }

                                Spacer(modifier = Modifier.width(20.dp))

                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("ORDER #${order.orderNumber}", fontSize = 20.sp, fontWeight = FontWeight.Black)
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Surface(color = MaterialTheme.colorScheme.secondaryContainer, shape = RoundedCornerShape(6.dp)) {
                                            Text(order.diningZone ?: "Main Dining", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    Text(
                                        text = order.items.joinToString(", ") { "${it.quantity}x ${it.menuItem.name}" },
                                        fontSize = 14.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            // Runner Workflow Actions
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                when (order.fulfilmentStatus) {
                                    FulfilmentStatus.NOT_READY -> {
                                        Surface(color = Color.LightGray.copy(alpha = 0.3f), shape = RoundedCornerShape(12.dp)) {
                                            Text("Kitchen Preparing...", fontSize = 13.sp, color = Color.DarkGray, modifier = Modifier.padding(12.dp))
                                        }
                                    }
                                    FulfilmentStatus.AWAITING_TABLE_DELIVERY -> {
                                        Button(
                                            onClick = { viewModel.updateFulfilmentStatus(order.orderId, FulfilmentStatus.OUT_FOR_TABLE_DELIVERY, "Runner Sarah") },
                                            colors = ButtonDefaults.buttonColors(containerColor = WendysGold, contentColor = Color.Black),
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier.testTag("collect_runner_${order.orderId}")
                                        ) {
                                            Icon(Icons.Default.TakeoutDining, contentDescription = null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("COLLECT ORDER", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    FulfilmentStatus.OUT_FOR_TABLE_DELIVERY -> {
                                        Button(
                                            onClick = { viewModel.updateFulfilmentStatus(order.orderId, FulfilmentStatus.COMPLETED) },
                                            colors = ButtonDefaults.buttonColors(containerColor = StatusGreen, contentColor = Color.White),
                                            shape = RoundedCornerShape(14.dp),
                                            modifier = Modifier.testTag("delivered_runner_${order.orderId}")
                                        ) {
                                            Icon(Icons.Default.Check, contentDescription = null)
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("MARK DELIVERED", fontWeight = FontWeight.Bold)
                                        }
                                    }
                                    else -> {}
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
