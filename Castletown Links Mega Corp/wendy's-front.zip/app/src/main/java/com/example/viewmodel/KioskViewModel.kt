package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.models.*
import com.example.data.repository.RestaurantRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class KioskViewModel(
    val repository: RestaurantRepository = RestaurantRepository()
) : ViewModel() {

    // Global flows from repo
    val menuItems = repository.menuItems
    val categories = repository.categories
    val diningTables = repository.diningTables
    val diningZones = repository.diningZones
    val orders = repository.orders
    val queueTickets = repository.queueTickets
    val assistanceRequests = repository.assistanceRequests
    val currentLocation = repository.currentLocation

    // UI Session State
    private val _currentScreen = MutableStateFlow(Screen.WELCOME)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    private val _selectedCategory = MutableStateFlow("cat_combos")
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedMenuItem = MutableStateFlow<MenuItem?>(null)
    val selectedMenuItem: StateFlow<MenuItem?> = _selectedMenuItem.asStateFlow()

    private val _customizingModifiers = MutableStateFlow<List<ModifierOption>>(emptyList())
    val customizingModifiers: StateFlow<List<ModifierOption>> = _customizingModifiers.asStateFlow()

    private val _activeBasket = MutableStateFlow<List<BasketItem>>(emptyList())
    val activeBasket: StateFlow<List<BasketItem>> = _activeBasket.asStateFlow()

    private val _selectedServiceMethod = MutableStateFlow(ServiceMethod.DINE_IN_TABLE_DELIVERY)
    val selectedServiceMethod: StateFlow<ServiceMethod> = _selectedServiceMethod.asStateFlow()

    private val _selectedTableNumber = MutableStateFlow<Int?>(null)
    val selectedTableNumber: StateFlow<Int?> = _selectedTableNumber.asStateFlow()

    private val _selectedDiningZone = MutableStateFlow<String?>(null)
    val selectedDiningZone: StateFlow<String?> = _selectedDiningZone.asStateFlow()

    private val _selectedPaymentMethod = MutableStateFlow(PaymentMethod.CONTACTLESS)
    val selectedPaymentMethod: StateFlow<PaymentMethod> = _selectedPaymentMethod.asStateFlow()

    private val _isPaymentProcessing = MutableStateFlow(false)
    val isPaymentProcessing: StateFlow<Boolean> = _isPaymentProcessing.asStateFlow()

    private val _lastConfirmedOrder = MutableStateFlow<Order?>(null)
    val lastConfirmedOrder: StateFlow<Order?> = _lastConfirmedOrder.asStateFlow()

    // Preferences & Localization
    private val _userLanguage = MutableStateFlow("EN")
    val userLanguage: StateFlow<String> = _userLanguage.asStateFlow()

    private val _isHighContrast = MutableStateFlow(false)
    val isHighContrast: StateFlow<Boolean> = _isHighContrast.asStateFlow()

    private val _isLargeText = MutableStateFlow(false)
    val isLargeText: StateFlow<Boolean> = _isLargeText.asStateFlow()

    private val _soundEnabled = MutableStateFlow(true)
    val soundEnabled: StateFlow<Boolean> = _soundEnabled.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Pickup & Check-in
    private val _pickupInput = MutableStateFlow("")
    val pickupInput: StateFlow<String> = _pickupInput.asStateFlow()

    private val _foundPickupOrder = MutableStateFlow<Order?>(null)
    val foundPickupOrder: StateFlow<Order?> = _foundPickupOrder.asStateFlow()

    private val _pickupMessage = MutableStateFlow<String?>(null)
    val pickupMessage: StateFlow<String?> = _pickupMessage.asStateFlow()

    // Assistance & Queue
    private val _userQueueTicket = MutableStateFlow<QueueTicket?>(null)
    val userQueueTicket: StateFlow<QueueTicket?> = _userQueueTicket.asStateFlow()

    // Combo Builder state
    private val _comboStep = MutableStateFlow(1)
    val comboStep: StateFlow<Int> = _comboStep.asStateFlow()

    private val _comboMainItem = MutableStateFlow<MenuItem?>(null)
    val comboMainItem: StateFlow<MenuItem?> = _comboMainItem.asStateFlow()

    private val _comboSideItem = MutableStateFlow<MenuItem?>(null)
    val comboSideItem: StateFlow<MenuItem?> = _comboSideItem.asStateFlow()

    private val _comboDrinkItem = MutableStateFlow<MenuItem?>(null)
    val comboDrinkItem: StateFlow<MenuItem?> = _comboDrinkItem.asStateFlow()

    val basketSubtotal: StateFlow<Double> = activeBasket.map { list ->
        list.sumOf { it.totalPrice }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, 0.0)

    val basketTax: StateFlow<Double> = basketSubtotal.map { sub ->
        sub * 0.08
    }.stateIn(viewModelScope, SharingStarted.Eagerly, 0.0)

    val basketTotal: StateFlow<Double> = combine(basketSubtotal, basketTax) { sub, tax ->
        sub + tax
    }.stateIn(viewModelScope, SharingStarted.Eagerly, 0.0)

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    fun selectCategory(categoryId: String) {
        _selectedCategory.value = categoryId
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setLanguage(lang: String) {
        _userLanguage.value = lang
    }

    fun toggleHighContrast() {
        _isHighContrast.update { !it }
    }

    fun toggleLargeText() {
        _isLargeText.update { !it }
    }

    fun toggleSound() {
        _soundEnabled.update { !it }
    }

    fun openProductDetail(menuItem: MenuItem) {
        _selectedMenuItem.value = menuItem
        // Pre-select default modifiers
        val defaults = menuItem.modifierGroups.flatMap { group ->
            group.options.filter { it.isDefault }
        }
        _customizingModifiers.value = defaults
        _currentScreen.value = Screen.PRODUCT_DETAIL
    }

    fun toggleModifier(option: ModifierOption, group: ModifierGroup) {
        _customizingModifiers.update { current ->
            val isSelected = current.any { it.id == option.id }
            if (isSelected) {
                current.filterNot { it.id == option.id }
            } else {
                if (group.maxSelection == 1) {
                    val groupOptIds = group.options.map { it.id }.toSet()
                    current.filterNot { it.id in groupOptIds } + option
                } else {
                    current + option
                }
            }
        }
    }

    fun addSelectedProductToBasket(quantity: Int = 1) {
        val item = _selectedMenuItem.value ?: return
        val basketItem = BasketItem(
            id = UUID.randomUUID().toString(),
            menuItem = item,
            quantity = quantity,
            selectedModifiers = _customizingModifiers.value
        )
        _activeBasket.update { it + basketItem }
        _selectedMenuItem.value = null
        _currentScreen.value = Screen.MENU
    }

    fun startComboBuilder(mainItem: MenuItem) {
        _comboMainItem.value = mainItem
        _comboSideItem.value = menuItems.value.firstOrNull { it.id == "item_fries" }
        _comboDrinkItem.value = menuItems.value.firstOrNull { it.id == "item_cola" }
        _comboStep.value = 1
        _currentScreen.value = Screen.COMBO_BUILDER
    }

    fun selectComboSide(side: MenuItem) {
        _comboSideItem.value = side
    }

    fun selectComboDrink(drink: MenuItem) {
        _comboDrinkItem.value = drink
    }

    fun addComboToBasket() {
        val main = _comboMainItem.value ?: return
        val side = _comboSideItem.value
        val drink = _comboDrinkItem.value
        val comboItems = listOfNotNull(side, drink)

        val basketItem = BasketItem(
            id = UUID.randomUUID().toString(),
            menuItem = main,
            quantity = 1,
            selectedModifiers = emptyList(),
            comboItems = comboItems,
            specialNotes = "Combo Meal (${side?.name ?: "No Side"} + ${drink?.name ?: "No Drink"})"
        )
        _activeBasket.update { it + basketItem }
        _currentScreen.value = Screen.MENU
    }

    fun updateBasketItemQuantity(basketItemId: String, delta: Int) {
        _activeBasket.update { list ->
            list.mapNotNull { item ->
                if (item.id == basketItemId) {
                    val newQty = item.quantity + delta
                    if (newQty > 0) item.copy(quantity = newQty) else null
                } else item
            }
        }
    }

    fun removeBasketItem(basketItemId: String) {
        _activeBasket.update { list -> list.filterNot { it.id == basketItemId } }
    }

    fun selectServiceMethod(method: ServiceMethod) {
        _selectedServiceMethod.value = method
        if (method != ServiceMethod.DINE_IN_TABLE_DELIVERY) {
            _selectedTableNumber.value = null
            _selectedDiningZone.value = null
        }
    }

    fun selectTable(tableNumber: Int, zoneName: String) {
        _selectedTableNumber.value = tableNumber
        _selectedDiningZone.value = zoneName
        _currentScreen.value = Screen.BASKET_CHECKOUT
    }

    fun selectPaymentMethod(method: PaymentMethod) {
        _selectedPaymentMethod.value = method
    }

    fun processPaymentAndSubmitOrder() {
        val basket = _activeBasket.value
        if (basket.isEmpty()) return

        viewModelScope.launch {
            _isPaymentProcessing.value = true
            delay(1500) // Simulate terminal authorization
            _isPaymentProcessing.value = false

            val createdOrder = repository.submitOrder(
                serviceMethod = _selectedServiceMethod.value,
                tableNumber = _selectedTableNumber.value,
                diningZone = _selectedDiningZone.value,
                basketItems = basket,
                paymentMethod = _selectedPaymentMethod.value,
                customerPhone = null,
                pickupToken = null
            )

            _lastConfirmedOrder.value = createdOrder
            _activeBasket.value = emptyList()
            _currentScreen.value = Screen.ORDER_CONFIRMATION
        }
    }

    fun setPickupInput(input: String) {
        _pickupInput.value = input
    }

    fun searchPickupOrder() {
        val query = _pickupInput.value.trim()
        if (query.isEmpty()) return
        val found = repository.confirmArrival(query)
        if (found != null) {
            _foundPickupOrder.value = found
            _pickupMessage.value = "Order #${found.orderNumber} Verified! Kitchen notified of your arrival."
        } else {
            _foundPickupOrder.value = null
            _pickupMessage.value = "Order '$query' not found. Please check your order reference or phone number."
        }
    }

    fun requestStaffAssistance(reason: String) {
        val req = repository.requestAssistance(reason)
        val ticket = repository.joinQueue("Kiosk Guest", reason)
        _userQueueTicket.value = ticket
        _currentScreen.value = Screen.ASSISTANCE
    }

    fun updatePrepStatus(orderId: String, newPrepStatus: PrepStatus) {
        repository.updatePrepStatus(orderId, newPrepStatus)
    }

    fun updateFulfilmentStatus(orderId: String, newFulfilment: FulfilmentStatus, runnerName: String? = null) {
        repository.updateFulfilmentStatus(orderId, newFulfilment, runnerName)
    }

    fun toggleItemAvailability(itemId: String) {
        repository.toggleItemAvailability(itemId)
    }

    fun resolveAssistanceRequest(requestId: String) {
        repository.resolveAssistance(requestId)
    }

    fun resetKioskSession() {
        _activeBasket.value = emptyList()
        _selectedMenuItem.value = null
        _customizingModifiers.value = emptyList()
        _selectedServiceMethod.value = ServiceMethod.DINE_IN_TABLE_DELIVERY
        _selectedTableNumber.value = null
        _selectedDiningZone.value = null
        _lastConfirmedOrder.value = null
        _foundPickupOrder.value = null
        _pickupInput.value = ""
        _pickupMessage.value = null
        _userQueueTicket.value = null
        _searchQuery.value = ""
        _currentScreen.value = Screen.WELCOME
    }
}
