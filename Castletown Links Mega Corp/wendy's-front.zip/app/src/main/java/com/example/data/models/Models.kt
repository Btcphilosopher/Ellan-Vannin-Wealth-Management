package com.example.data.models

enum class ServiceMethod {
    DINE_IN_TABLE_DELIVERY,
    DINE_IN_COUNTER_PICKUP,
    TAKEAWAY
}

enum class PaymentMethod(val label: String) {
    CONTACTLESS("Contactless Card (NFC)"),
    CHIP_PIN("Chip & PIN Terminal"),
    MOBILE_WALLET("Google Pay / Apple Pay"),
    GIFT_CARD("Wendy's Gift Card")
}

enum class PaymentStatus {
    NOT_STARTED, PENDING, AUTHORISED, CAPTURED, FAILED, REFUNDED
}

enum class PrepStatus {
    RECEIVED, ACCEPTED, PREPARING, READY, CANCELLED
}

enum class FulfilmentStatus {
    NOT_READY, AWAITING_PICKUP, AWAITING_TABLE_DELIVERY, OUT_FOR_TABLE_DELIVERY, HANDED_OFF, COMPLETED
}

enum class ArrivalStatus {
    NOT_REQUIRED, NOT_ARRIVED, ARRIVED
}

enum class Screen {
    WELCOME,
    MENU,
    PRODUCT_DETAIL,
    COMBO_BUILDER,
    BASKET_CHECKOUT,
    TABLE_SELECTION,
    PAYMENT,
    ORDER_CONFIRMATION,
    PICKUP_CHECKIN,
    ASSISTANCE,
    KITCHEN_KDS,
    FOOD_RUNNER,
    STAFF_DASHBOARD
}

data class MenuCategory(
    val id: String,
    val name: String,
    val description: String,
    val iconName: String
)

data class ModifierOption(
    val id: String,
    val name: String,
    val priceAdjustment: Double = 0.0,
    val isDefault: Boolean = false,
    val isSelected: Boolean = false
)

data class ModifierGroup(
    val id: String,
    val name: String,
    val isRequired: Boolean = false,
    val minSelection: Int = 0,
    val maxSelection: Int = 5,
    val options: List<ModifierOption> = emptyList()
)

data class MenuItem(
    val id: String,
    val name: String,
    val description: String,
    val price: Double,
    val categoryId: String,
    val imageResName: String,
    val isAvailable: Boolean = true,
    val isComboEligible: Boolean = true,
    val calories: Int = 550,
    val allergens: List<String> = emptyList(),
    val modifierGroups: List<ModifierGroup> = emptyList()
)

data class ComboStep(
    val stepIndex: Int,
    val title: String,
    val categoryId: String,
    val selectedItem: MenuItem? = null,
    val selectedModifiers: List<ModifierOption> = emptyList()
)

data class BasketItem(
    val id: String,
    val menuItem: MenuItem,
    val quantity: Int = 1,
    val selectedModifiers: List<ModifierOption> = emptyList(),
    val comboItems: List<MenuItem> = emptyList(),
    val specialNotes: String = ""
) {
    val unitPrice: Double
        get() {
            val base = menuItem.price
            val mods = selectedModifiers.sumOf { it.priceAdjustment }
            val comboExtra = comboItems.sumOf { it.price * 0.8 } // discounted combo side/drink
            return base + mods + comboExtra
        }

    val totalPrice: Double
        get() = unitPrice * quantity
}

data class DiningZone(
    val id: String,
    val name: String,
    val description: String
)

data class DiningTable(
    val tableNumber: Int,
    val zoneId: String,
    val capacity: Int,
    val isOccupied: Boolean = false,
    val activeOrderId: String? = null
)

data class Order(
    val orderId: String,
    val orderNumber: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val serviceMethod: ServiceMethod,
    val tableNumber: Int? = null,
    val diningZone: String? = null,
    val items: List<BasketItem>,
    val subtotal: Double,
    val tax: Double,
    val total: Double,
    val paymentMethod: PaymentMethod,
    val paymentStatus: PaymentStatus = PaymentStatus.CAPTURED,
    val prepStatus: PrepStatus = PrepStatus.RECEIVED,
    val fulfilmentStatus: FulfilmentStatus = FulfilmentStatus.NOT_READY,
    val arrivalStatus: ArrivalStatus = ArrivalStatus.NOT_REQUIRED,
    val customerPhone: String? = null,
    val pickupToken: String? = null,
    val receiptType: String = "Printed",
    val runnerName: String? = null
)

data class QueueTicket(
    val ticketId: String,
    val ticketNumber: String,
    val customerName: String,
    val reason: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "WAITING", // WAITING, CALLED, COMPLETED
    val counter: String? = null
)

data class AssistanceRequest(
    val requestId: String,
    val kioskId: String = "Kiosk #1 (Entrance)",
    val reason: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isResolved: Boolean = false
)

data class LocationInfo(
    val id: String,
    val name: String,
    val address: String,
    val isOpen: Boolean = true
)
