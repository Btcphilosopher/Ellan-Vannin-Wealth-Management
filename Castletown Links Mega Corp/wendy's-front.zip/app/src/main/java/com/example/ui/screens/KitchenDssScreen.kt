package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.models.Order
import com.example.data.models.PrepStatus
import com.example.data.models.Screen
import com.example.data.models.ServiceMethod
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusOrange
import com.example.ui.theme.WendysGold
import com.example.ui.theme.WendysRed
import com.example.viewmodel.KioskViewModel

@Composable
fun KitchenDssScreen(
    viewModel: KioskViewModel,
    onNavigate: (Screen) -> Unit
) {
    val orders by viewModel.orders.collectAsState()
    var selectedStation by remember { mutableStateOf("ALL") }

    val activeKitchenOrders = remember(orders) {
        orders.filter { it.prepStatus != PrepStatus.CANCELLED }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E1B1E)) // Kitchen dark theme
    ) {
        // Kitchen KDS Header
        Surface(color = Color(0xFF2C2528), shadowElevation = 4.dp) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { onNavigate(Screen.WELCOME) }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Exit KDS", tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(WendysRed, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.SoupKitchen, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text("KITCHEN DISPLAY SYSTEM (KDS)", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Text("Real-Time Kiosk Ticket Routing & Expediting", fontSize = 12.sp, color = Color.LightGray)
                    }
                }

                // Station Selector Filter Chips
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("ALL", "GRILL", "FRY", "ASSEMBLY", "DRINKS").forEach { station ->
                        val isSelected = selectedStation == station
                        FilterChip(
                            selected = isSelected,
                            onClick = { selectedStation = station },
                            label = { Text(station, fontSize = 12.sp, fontWeight = FontWeight.Bold) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = WendysGold,
                                selectedLabelColor = Color.Black,
                                containerColor = Color(0xFF3E3639),
                                labelColor = Color.White
                            ),
                            shape = RoundedCornerShape(16.dp)
                        )
                    }
                }
            }
        }

        // KDS Ticket Grid
        if (activeKitchenOrders.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.CheckCircleOutline, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(64.dp))
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("ALL ORDERS PREPARED!", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Standing by for incoming kiosk orders...", fontSize = 14.sp, color = Color.Gray)
                }
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                items(activeKitchenOrders, key = { it.orderId }) { order ->
                    KitchenTicketCard(
                        order = order,
                        onUpdatePrepStatus = { newStatus -> viewModel.updatePrepStatus(order.orderId, newStatus) }
                    )
                }
            }
        }
    }
}

@Composable
fun KitchenTicketCard(
    order: Order,
    onUpdatePrepStatus: (PrepStatus) -> Unit
) {
    val elapsedMinutes = remember(order.timestamp) {
        val diff = System.currentTimeMillis() - order.timestamp
        (diff / 60000).toInt()
    }

    val headerColor = when {
        elapsedMinutes >= 10 -> Color(0xFFD32F2F) // Red urgent
        elapsedMinutes >= 5 -> StatusOrange // Yellow warning
        else -> StatusGreen // Green normal
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF2B2628)),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Header Bar
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(headerColor)
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("#${order.orderNumber}", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White)
                        Spacer(modifier = Modifier.width(10.dp))
                        if (order.tableNumber != null) {
                            Surface(color = Color.Black.copy(alpha = 0.3f), shape = RoundedCornerShape(6.dp)) {
                                Text("TBL ${order.tableNumber}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        } else {
                            Surface(color = Color.Black.copy(alpha = 0.3f), shape = RoundedCornerShape(6.dp)) {
                                Text("TAKEAWAY", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                    }

                    Text("${elapsedMinutes}m ago", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }

            // Body Ticket Items
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                order.items.forEach { item ->
                    Column(modifier = Modifier.padding(vertical = 4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${item.quantity}x ${item.menuItem.name}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.White)
                        }

                        if (item.selectedModifiers.isNotEmpty()) {
                            Text(
                                text = "  > " + item.selectedModifiers.joinToString(", ") { it.name },
                                fontSize = 12.sp,
                                color = WendysGold,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        if (item.specialNotes.isNotEmpty()) {
                            Text(
                                text = "  * " + item.specialNotes,
                                fontSize = 12.sp,
                                color = Color.LightGray
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Prep Status Action Buttons
                when (order.prepStatus) {
                    PrepStatus.RECEIVED -> {
                        Button(
                            onClick = { onUpdatePrepStatus(PrepStatus.PREPARING) },
                            colors = ButtonDefaults.buttonColors(containerColor = WendysGold, contentColor = Color.Black),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("prep_start_${order.orderId}")
                        ) {
                            Text("START PREPARING", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                    PrepStatus.PREPARING -> {
                        Button(
                            onClick = { onUpdatePrepStatus(PrepStatus.READY) },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusGreen, contentColor = Color.White),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("prep_ready_${order.orderId}")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("MARK READY", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                    PrepStatus.READY -> {
                        Surface(
                            color = StatusGreen.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "READY FOR RUNNER / PICKUP",
                                color = StatusGreen,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                    else -> {}
                }
            }
        }
    }
}
