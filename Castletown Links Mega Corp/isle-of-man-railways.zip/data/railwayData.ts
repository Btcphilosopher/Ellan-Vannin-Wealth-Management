export interface Station {
  id: string;
  name: string;
  railway: 'Steam Railway' | 'Electric Railway' | 'Snaefell Mountain' | 'Shared';
  description: string;
  facilities: string[];
  image: string;
  x: number; // Percentage coordinate on map (0-100)
  y: number; // Percentage coordinate on map (0-100)
  isMajor: boolean;
}

export interface RailwayLine {
  id: string;
  name: string;
  secondary: string;
  route: string;
  description: string;
  longDescription: string;
  established: string;
  gauge: string;
  length: string;
  image: string;
  accentColor: string;
}

export interface TimetableEntry {
  id: string;
  lineId: string;
  trainNo: string;
  from: string;
  to: string;
  depTime: string;
  arrTime: string;
  stops: { station: string; time: string }[];
  runsOn: string;
}

export interface Destination {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  details: string;
  image: string;
}

export interface TicketType {
  id: string;
  name: string;
  description: string;
  farePlaceholder: string;
  benefits: string[];
}

export interface HeritageMilestone {
  year: string;
  title: string;
  description: string;
}

export interface NewsItem {
  id: string;
  category: 'Service updates' | 'Seasonal journeys' | 'Railway news';
  title: string;
  date: string;
  summary: string;
  content: string;
  image: string;
}

export const RAILWAY_LINES: RailwayLine[] = [
  {
    id: 'steam',
    name: 'Isle of Man Steam Railway',
    secondary: 'Steam • Southern Countryside',
    route: 'Douglas ↔ Port Erin',
    description: "Historic narrow-gauge steam railway travelling through the island's serene southern countryside.",
    longDescription: "Operating continuously since 1874, the Isle of Man Steam Railway is the longest narrow-gauge steam line in the British Isles. It still utilizes its original locomotives and elegant wooden carriages, carrying passengers through unspoilt landscape from Douglas to the seaside town of Port Erin.",
    established: '1874',
    gauge: '3ft (914mm)',
    length: '15.3 miles',
    image: 'https://images.unsplash.com/photo-1541417904950-b855846fe074?q=80&w=1200&auto=format&fit=crop', // Beautiful cinematic steam train in countryside
    accentColor: '#8C2928',
  },
  {
    id: 'electric',
    name: 'Manx Electric Railway',
    secondary: 'Electric • Coastal Cliffs',
    route: 'Douglas ↔ Ramsey',
    description: 'A spectacular cliffside journey along the eastern coast, climbing through the island\'s rugged hills.',
    longDescription: "Dating back to 1893, this iconic tramway holds the record as the oldest continually operating electric tramway in the world. Using original Victorian rolling stock, the line hugs the dramatic eastern cliffs, offering breathtaking views of the Irish Sea before terminating at the northern town of Ramsey.",
    established: '1893',
    gauge: '3ft (914mm)',
    length: '17.7 miles',
    image: 'https://images.unsplash.com/photo-1519074069444-1ba4e6664104?q=80&w=1200&auto=format&fit=crop', // Nostalgic electric tram/railway look
    accentColor: '#18372F',
  },
  {
    id: 'snaefell',
    name: 'Snaefell Mountain Railway',
    secondary: 'Mountain • Island Summit',
    route: 'Laxey ↔ Summit',
    description: 'A remarkable Victorian mountain railway climbing towards the windy summit of Snaefell, 2,036 feet above.',
    longDescription: "Constructed in just seven months in 1895, this pioneering mountain railway climbs over 1,800 feet from Laxey to the summit of Snaefell, the island's only mountain. From the top, on a clear day, the famous 'Six Kingdoms' are visible: the Isle of Man, England, Scotland, Ireland, Wales, and Heaven.",
    established: '1895',
    gauge: '3ft 6in (1067mm) with Fell Rail',
    length: '5 miles',
    image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=1200&auto=format&fit=crop', // Mountain scenic peaks look
    accentColor: '#B69A63',
  },
];

export const STATIONS: Station[] = [
  {
    id: 'douglas',
    name: 'Douglas',
    railway: 'Shared',
    description: 'The majestic red-brick capital terminus and central hub for both Steam and Electric lines.',
    facilities: ['Ticket Office', 'Tea Rooms', 'Waiting Room', 'Souvenir Shop', 'Toilets', 'Museum', 'Disabled Access'],
    image: 'https://images.unsplash.com/photo-1563911302283-d2bc1d98c757?q=80&w=600&auto=format&fit=crop', // Grand Victorian terminal feel
    x: 48,
    y: 72,
    isMajor: true,
  },
  {
    id: 'port-soderick',
    name: 'Port Soderick',
    railway: 'Steam Railway',
    description: 'A quiet countryside halt situated near a beautiful wooded glen and beach cove.',
    facilities: ['Waiting Shelter', 'Scenic Walkway'],
    image: 'https://images.unsplash.com/photo-1441974231531-c6227db76b6e?q=80&w=600&auto=format&fit=crop',
    x: 43,
    y: 77,
    isMajor: false,
  },
  {
    id: 'santon',
    name: 'Santon',
    railway: 'Steam Railway',
    description: 'A charming rustic rural stop serving local crofts and walking paths.',
    facilities: ['Waiting Shelter'],
    image: 'https://images.unsplash.com/photo-1502082553048-f009c37129b9?q=80&w=600&auto=format&fit=crop',
    x: 37,
    y: 81,
    isMajor: false,
  },
  {
    id: 'ballasalla',
    name: 'Ballasalla',
    railway: 'Steam Railway',
    description: 'Home to the ruins of Rushen Abbey, with a beautifully restored stone station cottage.',
    facilities: ['Ticket Office', 'Waiting Room', 'Nearby Abbey Ruins'],
    image: 'https://images.unsplash.com/photo-1546182990-dffeafbe841d?q=80&w=600&auto=format&fit=crop',
    x: 31,
    y: 84,
    isMajor: false,
  },
  {
    id: 'castletown',
    name: 'Castletown',
    railway: 'Steam Railway',
    description: 'The island\'s ancient medieval capital, dominated by the imposing stone walls of Castle Rushen.',
    facilities: ['Ticket Office', 'Waiting Room', 'Tea Rooms', 'Toilets', 'Disabled Access'],
    image: 'https://images.unsplash.com/photo-1605538032432-a9f0c8d9baac?q=80&w=600&auto=format&fit=crop', // Castles, historic
    x: 24,
    y: 88,
    isMajor: true,
  },
  {
    id: 'ballabeg',
    name: 'Ballabeg',
    railway: 'Steam Railway',
    description: 'A delightful wayside halt popular with ramblers heading into the southern hills.',
    facilities: ['Waiting Shelter'],
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=600&auto=format&fit=crop',
    x: 18,
    y: 86,
    isMajor: false,
  },
  {
    id: 'colby',
    name: 'Colby',
    railway: 'Steam Railway',
    description: 'A scenic village station set amidst wild garlic glens and traditional Manx cottages.',
    facilities: ['Ticket Box', 'Waiting Room', 'Pub Nearby'],
    image: 'https://images.unsplash.com/photo-1510312305653-8ed496efae75?q=80&w=600&auto=format&fit=crop',
    x: 14,
    y: 84,
    isMajor: false,
  },
  {
    id: 'port-erin',
    name: 'Port Erin',
    railway: 'Steam Railway',
    description: 'The final destination on the steam line, known for its pristine sandy bay and railway museum.',
    facilities: ['Ticket Office', 'Station Cafe', 'Museum', 'Souvenir Shop', 'Toilets', 'Disabled Access'],
    image: 'https://images.unsplash.com/photo-1506929562872-bb421503ef21?q=80&w=600&auto=format&fit=crop', // Coastal bay
    x: 8,
    y: 83,
    isMajor: true,
  },
  {
    id: 'laxey',
    name: 'Laxey',
    railway: 'Shared',
    description: 'The picturesque valley hub where the coastal Electric tramway connects with the mountain line.',
    facilities: ['Ticket Office', 'Waiting Room', 'Vintage Cafe', 'Laxey Wheel Access', 'Toilets'],
    image: 'https://images.unsplash.com/photo-1583212292454-1fe6229603b7?q=80&w=600&auto=format&fit=crop', // Valley view / wheel
    x: 65,
    y: 45,
    isMajor: true,
  },
  {
    id: 'snaefell-summit',
    name: 'Snaefell',
    railway: 'Snaefell Mountain',
    description: 'The highest point on the island, boasting spectacular views across all surrounding Celtic nations.',
    facilities: ['Summit Cafe', 'Bar', 'Viewing Platform', 'Toilets', 'Postal Box'],
    image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=600&auto=format&fit=crop',
    x: 58,
    y: 35,
    isMajor: true,
  },
  {
    id: 'ramsey',
    name: 'Ramsey',
    railway: 'Electric Railway',
    description: 'The northern coastal terminus, resting beside the tranquil waters of Mooragh Park and the bay.',
    facilities: ['Ticket Office', 'Waiting Hall', 'Tea Rooms', 'Toilets', 'Disabled Access'],
    image: 'https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?q=80&w=600&auto=format&fit=crop', // Northern landscape coastal harbour
    x: 75,
    y: 18,
    isMajor: true,
  },
];

export const TIMETABLES: TimetableEntry[] = [
  // Steam Railway departures (Douglas -> Port Erin)
  {
    id: 'st-01',
    lineId: 'steam',
    trainNo: 'Steam No. 4',
    from: 'Douglas',
    to: 'Port Erin',
    depTime: '09:45',
    arrTime: '10:45',
    stops: [
      { station: 'Douglas', time: '09:45' },
      { station: 'Castletown', time: '10:15' },
      { station: 'Colby', time: '10:33' },
      { station: 'Port Erin', time: '10:45' },
    ],
    runsOn: 'Daily (Mar - Nov)',
  },
  {
    id: 'st-02',
    lineId: 'steam',
    trainNo: 'Steam No. 12',
    from: 'Port Erin',
    to: 'Douglas',
    depTime: '12:05',
    arrTime: '13:05',
    stops: [
      { station: 'Port Erin', time: '12:05' },
      { station: 'Colby', time: '12:17' },
      { station: 'Castletown', time: '12:35' },
      { station: 'Douglas', time: '13:05' },
    ],
    runsOn: 'Daily (Mar - Nov)',
  },
  {
    id: 'st-03',
    lineId: 'steam',
    trainNo: 'Steam No. 4',
    from: 'Douglas',
    to: 'Port Erin',
    depTime: '14:15',
    arrTime: '15:15',
    stops: [
      { station: 'Douglas', time: '14:15' },
      { station: 'Castletown', time: '14:45' },
      { station: 'Colby', time: '15:03' },
      { station: 'Port Erin', time: '15:15' },
    ],
    runsOn: 'Daily (Mar - Nov)',
  },
  {
    id: 'st-04',
    lineId: 'steam',
    trainNo: 'Steam No. 12',
    from: 'Port Erin',
    to: 'Douglas',
    depTime: '16:30',
    arrTime: '17:30',
    stops: [
      { station: 'Port Erin', time: '16:30' },
      { station: 'Colby', time: '16:42' },
      { station: 'Castletown', time: '17:00' },
      { station: 'Douglas', time: '17:30' },
    ],
    runsOn: 'Daily (Mar - Nov)',
  },

  // Electric Railway departures (Douglas -> Ramsey)
  {
    id: 'el-01',
    lineId: 'electric',
    trainNo: 'Car No. 1',
    from: 'Douglas',
    to: 'Ramsey',
    depTime: '10:10',
    arrTime: '11:25',
    stops: [
      { station: 'Douglas (Derby Castle)', time: '10:10' },
      { station: 'Laxey', time: '10:45' },
      { station: 'Ramsey', time: '11:25' },
    ],
    runsOn: 'Daily (Apr - Oct)',
  },
  {
    id: 'el-02',
    lineId: 'electric',
    trainNo: 'Car No. 9',
    from: 'Ramsey',
    to: 'Douglas',
    depTime: '11:45',
    arrTime: '13:00',
    stops: [
      { station: 'Ramsey', time: '11:45' },
      { station: 'Laxey', time: '12:25' },
      { station: 'Douglas (Derby Castle)', time: '13:00' },
    ],
    runsOn: 'Daily (Apr - Oct)',
  },
  {
    id: 'el-03',
    lineId: 'electric',
    trainNo: 'Car No. 1',
    from: 'Douglas',
    to: 'Ramsey',
    depTime: '14:40',
    arrTime: '15:55',
    stops: [
      { station: 'Douglas (Derby Castle)', time: '14:40' },
      { station: 'Laxey', time: '15:15' },
      { station: 'Ramsey', time: '15:55' },
    ],
    runsOn: 'Daily (Apr - Oct)',
  },
  {
    id: 'el-04',
    lineId: 'electric',
    trainNo: 'Car No. 9',
    from: 'Ramsey',
    to: 'Douglas',
    depTime: '16:20',
    arrTime: '17:35',
    stops: [
      { station: 'Ramsey', time: '16:20' },
      { station: 'Laxey', time: '17:00' },
      { station: 'Douglas (Derby Castle)', time: '17:35' },
    ],
    runsOn: 'Daily (Apr - Oct)',
  },

  // Snaefell Mountain Railway departures (Laxey -> Summit)
  {
    id: 'sn-01',
    lineId: 'snaefell',
    trainNo: 'Tram No. 3',
    from: 'Laxey',
    to: 'Snaefell Summit',
    depTime: '10:30',
    arrTime: '11:00',
    stops: [
      { station: 'Laxey', time: '10:30' },
      { station: 'Bungalow', time: '10:48' },
      { station: 'Snaefell Summit', time: '11:00' },
    ],
    runsOn: 'Daily Weather Permitting (Apr - Oct)',
  },
  {
    id: 'sn-02',
    lineId: 'snaefell',
    trainNo: 'Tram No. 3',
    from: 'Snaefell Summit',
    to: 'Laxey',
    depTime: '11:30',
    arrTime: '12:00',
    stops: [
      { station: 'Snaefell Summit', time: '11:30' },
      { station: 'Bungalow', time: '11:42' },
      { station: 'Laxey', time: '12:00' },
    ],
    runsOn: 'Daily Weather Permitting (Apr - Oct)',
  },
  {
    id: 'sn-03',
    lineId: 'snaefell',
    trainNo: 'Tram No. 6',
    from: 'Laxey',
    to: 'Snaefell Summit',
    depTime: '13:30',
    arrTime: '14:00',
    stops: [
      { station: 'Laxey', time: '13:30' },
      { station: 'Bungalow', time: '13:48' },
      { station: 'Snaefell Summit', time: '14:00' },
    ],
    runsOn: 'Daily Weather Permitting (Apr - Oct)',
  },
  {
    id: 'sn-04',
    lineId: 'snaefell',
    trainNo: 'Tram No. 6',
    from: 'Snaefell Summit',
    to: 'Laxey',
    depTime: '15:15',
    arrTime: '15:45',
    stops: [
      { station: 'Snaefell Summit', time: '15:15' },
      { station: 'Bungalow', time: '15:27' },
      { station: 'Laxey', time: '15:45' },
    ],
    runsOn: 'Daily Weather Permitting (Apr - Oct)',
  },
];

export const DESTINATIONS: Destination[] = [
  {
    id: 'douglas',
    name: 'Douglas',
    subtitle: 'Sea, culture and Victorian architecture.',
    description: "Nestled along a crescent beach, the island's capital displays majestic sweep of pastel-coloured Victorian boarding houses, a horse-drawn tramway, and the grand terminus of the Steam and Electric railways.",
    details: 'Take a stroll down the Loch Promenade, explore the vintage arcade theatres, or visit the Manx Museum to uncover Celtic and Viking ancestry.',
    image: 'https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=800&auto=format&fit=crop', // Victorian coast town
  },
  {
    id: 'castletown',
    name: 'Castletown',
    subtitle: 'History, harbour and the ancient capital.',
    description: "Dominated by Castle Rushen, one of Europe's best-preserved medieval fortresses, Castletown is an echo of limestone cottages, cobblestones, and fishing boats drifting in a sleepy historic harbour.",
    details: "Tour the Old House of Keys, examine the ancient maritime vessels at the Nautical Museum, or dine at rustic harbour-side inns served by fresh seafood catches.",
    image: 'https://images.unsplash.com/photo-1516483638261-f4dbaf036963?q=80&w=800&auto=format&fit=crop', // Medieval coastal vibes
  },
  {
    id: 'ramsey',
    name: 'Ramsey',
    subtitle: 'Coastline, countryside and northern landscapes.',
    description: "Boasting wider horizons, a grand Victorian iron pier, and salt-lashed northern headlands, Ramsey showcases a quieter side of the island where the hills give way to sandy dunes and northern pine forests.",
    details: "Rent a small rowing boat at Mooragh Park Lake, explore the Queen's Pier restoration project, or hike through the rich ancient oak forests of Ballaugh and Elfin Glen.",
    image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=800&auto=format&fit=crop', // Scenic quiet landscape
  },
];

export const TICKET_TYPES: TicketType[] = [
  {
    id: 'single',
    name: 'Single Journey',
    description: 'Travel between any two stations on our network.',
    farePlaceholder: '£—',
    benefits: ['Valid on day of purchase', 'Perfect for point-to-point exploring', 'Hop off at intermediate halts'],
  },
  {
    id: 'rover',
    name: 'Day Rover',
    description: 'Unlimited, unrestricted exploration across the island.',
    farePlaceholder: '£—',
    benefits: ['Covers Steam, Electric, and Mountain Lines', 'Valid on all scheduled timetabled services', 'Includes Douglas Horse Tramway privileges'],
  },
  {
    id: 'family',
    name: 'Family Explorer',
    description: 'Travel together and share the wonder of the heritage lines.',
    farePlaceholder: '£—',
    benefits: ['Admits 2 Adults and up to 3 Children', 'All-network Day Rover accessibility', 'Discounted entry at partner heritage museums'],
  },
];

export const HERITAGE_TIMELINE: HeritageMilestone[] = [
  {
    year: '1873',
    title: 'The Steam Age Arrives',
    description: 'The Isle of Man Railway Company begins service between Douglas and Peel, introducing lightweight 3ft narrow-gauge locomotives.',
  },
  {
    year: '1874',
    title: 'Southern Expansion',
    description: 'The southern line to Castletown and Port Erin opens, unlocking the stunning coastal landscape for tourists and agricultural freight.',
  },
  {
    year: '1893',
    title: 'Victorian Electric Innovation',
    description: 'The Manx Electric Railway launches, tracing cliffside contours toward Laxey, demonstrating global pioneering in electric traction.',
  },
  {
    year: '1895',
    title: 'Conquering the Mountain Peak',
    description: 'In just seven months, Victorian engineers build the Snaefell Mountain Railway, climbing 2,036 feet using the innovative Fell central rail brake.',
  },
  {
    year: '1970s',
    title: 'Preservation & Living Heritage',
    description: 'The Isle of Man Government acts to preserve the railways as a national heritage treasure, safeguarding original locomotives, trackbeds, and carriages.',
  },
  {
    year: 'Today',
    title: 'The 2026 Living Legacy',
    description: 'An operational monument to 19th-century British transport, seamlessly serving as both an emotional travel destination and part of Manx identity.',
  },
];

export const NEWS_ITEMS: NewsItem[] = [
  {
    id: 'news-01',
    category: 'Service updates',
    title: 'Autumn Timetables & Golden Leaves Tours',
    date: '10 Sep 2026',
    summary: 'Our seasonal Autumn schedule is now active. Book now for our popular heritage foliage excursions.',
    content: 'Experience the spectacular changes of the Manx countryside as the hills transform. Additional morning services have been scheduled on the Steam line for peak photography locations.',
    image: 'https://images.unsplash.com/photo-1506744038136-46273834b3fb?q=80&w=400&auto=format&fit=crop',
  },
  {
    id: 'news-02',
    category: 'Seasonal journeys',
    title: 'Sunset over Snaefell: Dinner on the Peak',
    date: '02 Sep 2026',
    summary: 'Our famous high-altitude twilight dining excursions return. Climb to the summit for custom Manx feasts.',
    content: 'Board the Snaefell tram at Laxey under late summer rays, ascend to the peak, and dine on traditional cuisine as the sun sinks into the Irish Sea, casting golden light over the surrounding coast.',
    image: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=400&auto=format&fit=crop',
  },
  {
    id: 'news-03',
    category: 'Railway news',
    title: 'Locomotive No. 4 "Loch" Restored to Service',
    date: '28 Aug 2026',
    summary: 'The original 1874 steam engine has completed a full heritage boiler rebuild and returns to active duty.',
    content: 'No. 4 "Loch", built by Beyer, Peacock & Co. in Manchester back in 1874, is back on the rails in its gorgeous authentic deep dark green livery, ready to haul daily southern services after three years of meticulous engineering care.',
    image: 'https://images.unsplash.com/photo-1519074069444-1ba4e6664104?q=80&w=400&auto=format&fit=crop',
  },
];
