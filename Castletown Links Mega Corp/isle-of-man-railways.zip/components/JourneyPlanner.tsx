'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Calendar, Users, Train, ArrowRight, Search, Landmark, Clock, RefreshCw } from 'lucide-react';
import { STATIONS, TIMETABLES, TimetableEntry } from '@/data/railwayData';

interface JourneyPlannerProps {
  onSearchCompleted?: (results: TimetableEntry[]) => void;
}

export function JourneyPlanner({ onSearchCompleted }: JourneyPlannerProps) {
  const [fromStation, setFromStation] = React.useState('');
  const [toStation, setToStation] = React.useState('');
  const [journeyDate, setJourneyDate] = React.useState('2026-09-12');
  const [passengerCount, setPassengerCount] = React.useState('1');
  
  const [searchResults, setSearchResults] = React.useState<TimetableEntry[] | null>(null);
  const [hasSearched, setHasSearched] = React.useState(false);

  // Filter stations based on selection to prevent same origin/destination
  const originStations = STATIONS.filter(s => s.isMajor);
  const destinationStations = STATIONS.filter(s => s.isMajor && s.id !== fromStation);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fromStation || !toStation) return;

    // Direct match or indirect line match simulation
    // We look in TIMETABLES to find rides matching the from / to, or running on that general direction.
    // To make it fun and responsive, we look at lines that contain both from and to.
    const results = TIMETABLES.filter(entry => {
      const stopsNames = entry.stops.map(s => s.station.toLowerCase());
      const fromIdx = stopsNames.findIndex(name => name.includes(fromStation.split('-')[0].toLowerCase()) || fromStation.toLowerCase().includes(name));
      const toIdx = stopsNames.findIndex(name => name.includes(toStation.split('-')[0].toLowerCase()) || toStation.toLowerCase().includes(name));
      
      // Valid if from station is before to station in the schedule
      return fromIdx !== -1 && toIdx !== -1 && fromIdx < toIdx;
    });

    setSearchResults(results);
    setHasSearched(true);

    if (onSearchCompleted) {
      onSearchCompleted(results);
    }
  };

  const handleReset = () => {
    setFromStation('');
    setToStation('');
    setSearchResults(null);
    setHasSearched(false);
  };

  return (
    <div className="relative z-20 max-w-5xl mx-auto px-4 -mt-16 mb-16" id="planner">
      <div className="bg-manx-cream border border-manx-brass/30 p-6 md:p-8 shadow-2xl relative overflow-hidden">
        {/* Ticket border notch effect at sides */}
        <div className="absolute top-1/2 -left-3 w-6 h-12 bg-manx-green/10 border-r border-manx-brass/20 rounded-full transform -translate-y-1/2" />
        <div className="absolute top-1/2 -right-3 w-6 h-12 bg-manx-green/10 border-l border-manx-brass/20 rounded-full transform -translate-y-1/2" />

        <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 mb-6 border-b border-manx-brass/20">
          <div className="flex items-center space-x-2.5">
            <Train className="w-5 h-5 text-manx-red" />
            <h2 className="font-serif text-2xl tracking-wide text-manx-green">
              Plan Your Journey
            </h2>
          </div>
          <p className="font-sans text-[10px] tracking-widest text-manx-brass uppercase font-bold mt-1 md:mt-0">
            Victorian Lines • Living Heritage
          </p>
        </div>

        <form onSubmit={handleSearch} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 items-end">
          {/* Origin Selector */}
          <div className="space-y-1.5">
            <label className="block font-sans text-[10px] tracking-wider uppercase text-manx-green/75 font-bold">
              From Station
            </label>
            <div className="relative">
              <select
                required
                value={fromStation}
                onChange={(e) => setFromStation(e.target.value)}
                className="w-full bg-white border border-manx-brass/30 px-3 py-3 font-sans text-xs uppercase tracking-wider font-semibold text-manx-charcoal focus:outline-none focus:border-manx-red rounded-none appearance-none cursor-pointer"
              >
                <option value="" disabled>Select Origin</option>
                {originStations.map((station) => (
                  <option key={station.id} value={station.id}>
                    {station.name}
                  </option>
                ))}
              </select>
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none border-l border-manx-brass/20 pl-2">
                <span className="text-[10px] text-manx-brass">▼</span>
              </div>
            </div>
          </div>

          {/* Destination Selector */}
          <div className="space-y-1.5">
            <label className="block font-sans text-[10px] tracking-wider uppercase text-manx-green/75 font-bold">
              To Station
            </label>
            <div className="relative">
              <select
                required
                value={toStation}
                onChange={(e) => setToStation(e.target.value)}
                className="w-full bg-white border border-manx-brass/30 px-3 py-3 font-sans text-xs uppercase tracking-wider font-semibold text-manx-charcoal focus:outline-none focus:border-manx-red rounded-none appearance-none cursor-pointer"
              >
                <option value="" disabled>Select Destination</option>
                {destinationStations.map((station) => (
                  <option key={station.id} value={station.id}>
                    {station.name}
                  </option>
                ))}
              </select>
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none border-l border-manx-brass/20 pl-2">
                <span className="text-[10px] text-manx-brass">▼</span>
              </div>
            </div>
          </div>

          {/* Date Picker */}
          <div className="space-y-1.5">
            <label className="block font-sans text-[10px] tracking-wider uppercase text-manx-green/75 font-bold">
              Travel Date
            </label>
            <div className="relative flex items-center">
              <input
                type="date"
                required
                min="2026-09-11"
                value={journeyDate}
                onChange={(e) => setJourneyDate(e.target.value)}
                className="w-full bg-white border border-manx-brass/30 px-3 py-2.5 font-sans text-xs font-semibold text-manx-charcoal focus:outline-none focus:border-manx-red rounded-none"
              />
            </div>
          </div>

          {/* Passenger Select */}
          <div className="space-y-1.5">
            <label className="block font-sans text-[10px] tracking-wider uppercase text-manx-green/75 font-bold">
              Passengers
            </label>
            <div className="relative">
              <select
                value={passengerCount}
                onChange={(e) => setPassengerCount(e.target.value)}
                className="w-full bg-white border border-manx-brass/30 px-3 py-3 font-sans text-xs font-semibold text-manx-charcoal focus:outline-none focus:border-manx-red rounded-none appearance-none cursor-pointer"
              >
                <option value="1">1 Passenger</option>
                <option value="2">2 Passengers</option>
                <option value="3">3 Passengers</option>
                <option value="4">4 Passengers</option>
                <option value="5">5+ Passengers</option>
              </select>
              <div className="absolute right-3 top-1/2 transform -translate-y-1/2 pointer-events-none border-l border-manx-brass/20 pl-2">
                <span className="text-[10px] text-manx-brass">▼</span>
              </div>
            </div>
          </div>

          {/* Submit Search */}
          <div>
            <button
              type="submit"
              className="w-full bg-manx-green hover:bg-manx-green/90 text-manx-cream py-3.5 px-4 font-sans text-xs tracking-widest uppercase font-bold border border-manx-brass/40 flex items-center justify-center space-x-2 transition-all duration-300"
            >
              <span>SEARCH</span>
              <ArrowRight className="w-4 h-4 text-manx-brass" />
            </button>
          </div>
        </form>

        {/* Results Showcase Section */}
        <AnimatePresence>
          {hasSearched && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.4 }}
              className="mt-8 pt-6 border-t border-manx-brass/20"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-serif text-lg text-manx-green font-semibold">
                  Available Departures on {new Date(journeyDate).toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' })}
                </h3>
                <button
                  type="button"
                  onClick={handleReset}
                  className="flex items-center space-x-1.5 text-xs font-semibold text-manx-red hover:text-manx-red/80 font-sans tracking-wide"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Reset Planner</span>
                </button>
              </div>

              {searchResults && searchResults.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {searchResults.map((ride, index) => (
                    <motion.div
                      key={ride.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="bg-white border-l-4 border-manx-red border-t border-b border-r border-manx-brass/20 p-4 relative shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
                    >
                      {/* Ticket Notch decoration */}
                      <div className="absolute top-2 right-2 w-1.5 h-1.5 rounded-full bg-manx-red" />
                      
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-sans text-[10px] bg-manx-green/10 text-manx-green font-bold tracking-widest uppercase px-2 py-0.5">
                            {ride.lineId === 'steam' ? 'Steam Line' : ride.lineId === 'electric' ? 'Electric Line' : 'Mountain Line'}
                          </span>
                          <span className="font-sans text-[10px] text-manx-brass font-bold uppercase tracking-wider">
                            {ride.trainNo}
                          </span>
                        </div>

                        <div className="grid grid-cols-5 items-center my-3 text-center">
                          <div className="col-span-2 text-left">
                            <span className="block font-serif text-xl text-manx-green font-bold">{ride.depTime}</span>
                            <span className="block font-sans text-[10px] text-manx-charcoal/70 uppercase tracking-wider truncate">{ride.from}</span>
                          </div>
                          <div className="col-span-1 flex flex-col items-center justify-center">
                            <ArrowRight className="w-4 h-4 text-manx-brass" />
                            <span className="text-[8px] text-manx-brass uppercase font-bold mt-0.5">Direct</span>
                          </div>
                          <div className="col-span-2 text-right">
                            <span className="block font-serif text-xl text-manx-green font-bold">{ride.arrTime}</span>
                            <span className="block font-sans text-[10px] text-manx-charcoal/70 uppercase tracking-wider truncate">{ride.to}</span>
                          </div>
                        </div>
                      </div>

                      <div className="pt-2 border-t border-manx-brass/10 mt-2 flex items-center justify-between text-[10px]">
                        <span className="text-manx-charcoal/60 font-semibold">{ride.runsOn}</span>
                        <span className="text-manx-red font-bold uppercase tracking-widest">
                          Seats Available
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="bg-white border border-manx-brass/20 p-6 text-center text-manx-charcoal/70">
                  <p className="font-serif italic text-base">
                    No direct schedules match your selected parameters.
                  </p>
                  <p className="font-sans text-xs mt-2">
                    Please try searching between major stations like <strong className="text-manx-green">Douglas ↔ Port Erin</strong> (Steam) or <strong className="text-manx-green">Douglas ↔ Ramsey</strong> (Electric).
                  </p>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
