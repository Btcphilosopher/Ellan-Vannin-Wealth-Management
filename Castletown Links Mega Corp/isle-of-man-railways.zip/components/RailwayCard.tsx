'use client';

import { motion } from 'motion/react';
import { ArrowRight, Calendar, Compass, Ruler } from 'lucide-react';
import { RailwayLine } from '@/data/railwayData';

interface RailwayCardProps {
  line: RailwayLine;
  onExplore: (lineId: string) => void;
}

export function RailwayCard({ line, onExplore }: RailwayCardProps) {
  return (
    <div 
      className="bg-white border border-manx-brass/20 flex flex-col h-full hover:shadow-xl transition-shadow duration-300 relative group"
      id={`railway-${line.id}`}
    >
      {/* Decorative Stamp Edge / Ticket Stub Accent */}
      <div className="absolute top-4 right-4 w-2 h-2 rounded-full bg-manx-red z-10" />

      {/* Image Container with Gentle Zoom Hover */}
      <div className="relative aspect-[4/3] w-full overflow-hidden border-b border-manx-brass/20">
        <img
          src={line.image}
          alt={line.name}
          className="w-full h-full object-cover transform duration-700 ease-out group-hover:scale-105 select-none"
          referrerPolicy="no-referrer"
        />
        {/* Subtle Warm Overlay */}
        <div className="absolute inset-0 bg-manx-green/5 mix-blend-multiply" />
        
        {/* Established Badge in Bottom Right Corner */}
        <div className="absolute bottom-0 right-0 bg-manx-cream border-t border-l border-manx-brass/30 px-3 py-1 text-[9px] tracking-widest font-sans font-bold text-manx-green uppercase">
          Est. {line.established}
        </div>
      </div>

      {/* Content Area - Styled like a British Editorial Travel Journal */}
      <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between bg-[#FCFAF6]">
        <div>
          {/* Eyebrow Section */}
          <div className="flex items-center space-x-2 mb-3">
            <span className="font-sans text-[10px] tracking-widest text-manx-brass uppercase font-extrabold">
              {line.secondary}
            </span>
            <span className="text-manx-red">•</span>
            <span className="font-sans text-[10px] tracking-wider text-manx-green/80 font-bold uppercase">
              {line.route}
            </span>
          </div>

          {/* Large Serif Title */}
          <h3 className="font-serif text-2xl sm:text-3xl text-manx-green leading-tight mb-4 tracking-wide group-hover:text-manx-red transition-colors duration-300">
            {line.name}
          </h3>

          {/* Divider Track Design */}
          <div className="relative h-1.5 w-full flex items-center mb-5">
            <div className="absolute left-0 right-0 h-[1px] bg-manx-brass/20" />
            <div className="absolute left-0 right-0 h-[1px] bg-manx-brass/20 translate-y-[2px]" />
            <div className="absolute left-4 w-1.5 h-1.5 rounded-full bg-manx-red" />
            <div className="absolute right-4 w-1.5 h-1.5 rounded-full bg-manx-red" />
          </div>

          {/* Description */}
          <p className="font-sans text-xs sm:text-sm text-manx-charcoal/80 font-light leading-relaxed mb-6">
            {line.description}
          </p>
        </div>

        {/* Technical Data Tags & Button */}
        <div className="space-y-4 pt-4 border-t border-manx-brass/10">
          <div className="grid grid-cols-2 gap-2 text-[10px] font-sans font-bold tracking-wider text-manx-green uppercase">
            <div className="flex items-center space-x-1.5 bg-manx-cream/50 p-1.5 border border-manx-brass/10">
              <Ruler className="w-3.5 h-3.5 text-manx-brass" />
              <span>Gauge: {line.gauge}</span>
            </div>
            <div className="flex items-center space-x-1.5 bg-manx-cream/50 p-1.5 border border-manx-brass/10">
              <Compass className="w-3.5 h-3.5 text-manx-brass" />
              <span>Length: {line.length}</span>
            </div>
          </div>

          <button
            onClick={() => onExplore(line.id)}
            className="w-full flex items-center justify-between bg-transparent hover:bg-manx-green hover:text-manx-cream text-manx-green px-4 py-3 border border-manx-green rounded-none font-sans text-xs tracking-widest uppercase font-extrabold transition-all duration-300 group-hover:border-manx-red"
          >
            <span>EXPLORE THE LINE</span>
            <ArrowRight className="w-3.5 h-3.5 text-manx-brass group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </div>
  );
}
