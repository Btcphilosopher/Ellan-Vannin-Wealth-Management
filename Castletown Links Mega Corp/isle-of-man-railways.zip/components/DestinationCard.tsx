'use client';

import * as React from 'react';
import { Destination } from '@/data/railwayData';
import { ArrowRight, ChevronRight, MapPin } from 'lucide-react';

interface DestinationCardProps {
  destination: Destination;
}

export function DestinationCard({ destination }: DestinationCardProps) {
  const [isExpanded, setIsExpanded] = React.useState(false);

  return (
    <div 
      className="bg-white border border-manx-brass/20 flex flex-col justify-between h-full hover:shadow-lg transition-all duration-300 relative group"
      id={`destination-card-${destination.id}`}
    >
      <div>
        {/* Aspect Photo container */}
        <div className="relative aspect-[16/10] w-full overflow-hidden">
          <img
            src={destination.image}
            alt={destination.name}
            className="w-full h-full object-cover transform duration-500 ease-out group-hover:scale-103"
            referrerPolicy="no-referrer"
          />
          {/* Subtle warm, faded filter overlay */}
          <div className="absolute inset-0 bg-manx-green/5 mix-blend-multiply" />
          <div className="absolute top-3 left-3 bg-manx-cream text-manx-green border border-manx-brass/30 px-2 py-0.5 text-[8px] font-sans font-bold uppercase tracking-wider flex items-center space-x-1">
            <MapPin className="w-3.5 h-3.5 text-manx-red" />
            <span>Manx Destination</span>
          </div>
        </div>

        {/* Content body */}
        <div className="p-6">
          <h3 className="font-serif text-2xl text-manx-green leading-tight mb-1 font-semibold">
            {destination.name}
          </h3>
          <p className="font-sans text-[10px] tracking-wider text-manx-brass uppercase font-bold mb-4">
            {destination.subtitle}
          </p>
          <p className="font-sans text-xs text-manx-charcoal/85 leading-relaxed font-light mb-4">
            {destination.description}
          </p>

          {/* Collapsible Details Panel */}
          {isExpanded && (
            <div className="mt-4 pt-4 border-t border-manx-brass/10 text-xs font-sans text-manx-charcoal/80 leading-relaxed font-light bg-manx-cream/30 p-3 border border-dashed border-manx-brass/20 animate-fadeIn">
              <strong>Heritage Highlights:</strong> {destination.details}
            </div>
          )}
        </div>
      </div>

      {/* Interact Button */}
      <div className="px-6 pb-6 pt-2">
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="w-full text-center bg-transparent hover:bg-manx-green hover:text-manx-cream text-manx-green font-sans text-[10px] tracking-widest uppercase font-extrabold py-2.5 border border-manx-green transition-all duration-300 flex items-center justify-center space-x-1.5"
        >
          <span>{isExpanded ? 'LESS DETAILS' : 'DISCOVER DESTINATION'}</span>
          <ChevronRight className={`w-3.5 h-3.5 transition-transform ${isExpanded ? 'rotate-90 text-manx-red' : 'text-manx-brass'}`} />
        </button>
      </div>

    </div>
  );
}
