'use client';

import { Compass } from 'lucide-react';

interface FooterProps {
  onSectionClick: (sectionId: string) => void;
}

export function Footer({ onSectionClick }: FooterProps) {
  return (
    <footer className="bg-manx-green text-manx-cream border-t-2 border-manx-brass/35 pt-20 pb-12 z-10 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Large Statement Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center pb-12 border-b border-manx-cream/10 mb-12">
          <div className="max-w-lg mb-6 md:mb-0">
            <span className="font-sans text-[10px] tracking-[0.35em] text-manx-brass uppercase font-bold block mb-2">
              DISCOVER THE ISLE BY RAILWAY
            </span>
            <h2 className="font-serif text-4xl sm:text-5xl text-manx-cream tracking-wide font-normal leading-tight">
              See the island <br />
              <span className="italic font-light text-manx-brass">differently.</span>
            </h2>
          </div>

          <div className="flex items-center space-x-3 bg-manx-cream/5 border border-manx-brass/25 p-4 max-w-sm">
            <Compass className="w-8 h-8 text-manx-brass flex-shrink-0" />
            <p className="font-sans text-xs text-manx-cream/70 leading-relaxed font-light">
              We operate three of the most unique vintage railways in Europe. Hop on, slow down, and experience the Isle of Man.
            </p>
          </div>
        </div>

        {/* Navigation Grid Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mb-16">
          
          {/* Column 1: Journey */}
          <div>
            <h3 className="font-serif text-base text-manx-brass uppercase tracking-wider font-semibold mb-5 pb-1.5 border-b border-manx-cream/10">
              Journey
            </h3>
            <ul className="space-y-3 font-sans text-xs text-manx-cream/70 font-semibold uppercase tracking-wider">
              <li>
                <button onClick={() => onSectionClick('timetable')} className="hover:text-manx-brass transition-colors">
                  Timetables
                </button>
              </li>
              <li>
                <button onClick={() => onSectionClick('tickets')} className="hover:text-manx-brass transition-colors">
                  Tickets & Fares
                </button>
              </li>
              <li>
                <button onClick={() => onSectionClick('lines')} className="hover:text-manx-brass transition-colors">
                  Lines
                </button>
              </li>
              <li>
                <button onClick={() => onSectionClick('stations')} className="hover:text-manx-brass transition-colors">
                  Stations
                </button>
              </li>
            </ul>
          </div>

          {/* Column 2: Discover */}
          <div>
            <h3 className="font-serif text-base text-manx-brass uppercase tracking-wider font-semibold mb-5 pb-1.5 border-b border-manx-cream/10">
              Discover
            </h3>
            <ul className="space-y-3 font-sans text-xs text-manx-cream/70 font-semibold uppercase tracking-wider">
              <li>
                <button onClick={() => onSectionClick('lines')} className="hover:text-manx-brass transition-colors">
                  Steam Railway
                </button>
              </li>
              <li>
                <button onClick={() => onSectionClick('lines')} className="hover:text-manx-brass transition-colors">
                  Electric Railway
                </button>
              </li>
              <li>
                <button onClick={() => onSectionClick('lines')} className="hover:text-manx-brass transition-colors">
                  Snaefell
                </button>
              </li>
              <li>
                <button onClick={() => onSectionClick('visit')} className="hover:text-manx-brass transition-colors">
                  Island Destinations
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Information */}
          <div>
            <h3 className="font-serif text-base text-manx-brass uppercase tracking-wider font-semibold mb-5 pb-1.5 border-b border-manx-cream/10">
              Information
            </h3>
            <ul className="space-y-3 font-sans text-xs text-manx-cream/70 font-semibold uppercase tracking-wider">
              <li>
                <button onClick={() => onSectionClick('timetable')} className="hover:text-manx-brass transition-colors">
                  Accessibility
                </button>
              </li>
              <li>
                <button onClick={() => onSectionClick('timetable')} className="hover:text-manx-brass transition-colors">
                  Travel Information
                </button>
              </li>
              <li>
                <button onClick={() => onSectionClick('news')} className="hover:text-manx-brass transition-colors">
                  Service Updates
                </button>
              </li>
              <li>
                <a href="mailto:info@railways.im" className="hover:text-manx-brass transition-colors">
                  Contact Office
                </a>
              </li>
            </ul>
          </div>

          {/* Column 4: About */}
          <div>
            <h3 className="font-serif text-base text-manx-brass uppercase tracking-wider font-semibold mb-5 pb-1.5 border-b border-manx-cream/10">
              About
            </h3>
            <ul className="space-y-3 font-sans text-xs text-manx-cream/70 font-semibold uppercase tracking-wider">
              <li>
                <button onClick={() => onSectionClick('heritage')} className="hover:text-manx-brass transition-colors">
                  Heritage History
                </button>
              </li>
              <li>
                <button onClick={() => onSectionClick('heritage')} className="hover:text-manx-brass transition-colors">
                  About the Railway
                </button>
              </li>
              <li>
                <a href="#" className="hover:text-manx-brass transition-colors">
                  Careers
                </a>
              </li>
              <li>
                <button onClick={() => onSectionClick('news')} className="hover:text-manx-brass transition-colors">
                  News Releases
                </button>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Section */}
        <div className="pt-8 border-t border-manx-cream/10 flex flex-col md:flex-row justify-between items-center text-[10px] font-sans font-bold tracking-widest text-manx-cream/40 uppercase">
          <div className="mb-4 md:mb-0 text-center md:text-left">
            <span className="block text-manx-cream/70 text-xs font-serif font-semibold tracking-wider mb-1">
              ISLE OF MAN RAILWAYS
            </span>
            <span>© 2026 Isle of Man Railways. All rights reserved.</span>
          </div>

          <div className="flex flex-wrap gap-x-6 gap-y-2 justify-center">
            <a href="#" className="hover:text-manx-cream transition-colors">Privacy Policy</a>
            <span>•</span>
            <a href="#" className="hover:text-manx-cream transition-colors">Accessibility Charter</a>
            <span>•</span>
            <a href="#" className="hover:text-manx-cream transition-colors">Terms of Carriage</a>
            <span>•</span>
            <a href="#" className="hover:text-manx-cream transition-colors">Cookies Settings</a>
          </div>
        </div>

      </div>
    </footer>
  );
}
