'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { STATIONS, Station } from '@/data/railwayData';
import { MapPin, CheckCircle, Navigation, Info, Compass, Sparkles } from 'lucide-react';

export function RailwayMap() {
  const [selectedStation, setSelectedStation] = React.useState<Station>(
    STATIONS.find((s) => s.id === 'douglas') || STATIONS[0]
  );

  return (
    <section className="py-24 bg-[#EFE9DC] border-t border-b border-manx-brass/30 relative" id="stations">
      {/* Vintage paper grain styling */}
      <div className="absolute inset-0 bg-noise opacity-5 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-sans text-[10px] tracking-[0.25em] text-manx-brass uppercase font-bold block mb-3">
            HISTORIC GEOGRAPHY
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-manx-green font-semibold">
            The Island by Railway
          </h2>
          <p className="font-sans text-xs sm:text-sm text-manx-charcoal/70 mt-3 font-light">
            Select any station marker on our vintage cartographic guide to explore its facilities and heritage details.
          </p>
          <div className="w-16 h-0.5 bg-manx-red mx-auto mt-4" />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* LEFT: Clickable Cartographic Map Layout (7 Columns) */}
          <div className="lg:col-span-7 bg-[#F6F1E5] border border-manx-brass/40 p-4 sm:p-8 relative min-h-[450px] sm:min-h-[600px] flex flex-col justify-between shadow-lg">
            
            {/* Vintage Double Border Frame */}
            <div className="absolute inset-2 border border-manx-brass/20 pointer-events-none" />
            
            {/* Map Header Detail */}
            <div className="flex justify-between items-start z-10">
              <div className="border border-manx-brass/30 p-2 bg-manx-cream/80 font-serif text-[10px] tracking-wide text-manx-green">
                <span className="block font-bold">ISLE OF MAN</span>
                <span className="block text-[8px] uppercase tracking-wider text-manx-brass mt-0.5">Scale 1:150,000</span>
              </div>

              {/* Decorative Compass with Triskelion */}
              <div className="flex flex-col items-center">
                <div className="relative w-16 h-16 text-manx-green">
                  {/* Outer circle of compass */}
                  <svg viewBox="0 0 100 100" className="w-full h-full text-manx-green stroke-current fill-none">
                    <circle cx="50" cy="50" r="45" strokeWidth="1" strokeDasharray="2,2" />
                    <circle cx="50" cy="50" r="40" strokeWidth="1.5" />
                    {/* Compass North/South/East/West lines */}
                    <line x1="50" y1="5" x2="50" y2="95" strokeWidth="0.75" />
                    <line x1="5" y1="50" x2="95" y2="50" strokeWidth="0.75" />
                    {/* Decorative star pointers */}
                    <polygon points="50,15 54,46 50,50 46,46" fill="currentColor" stroke="none" />
                    <polygon points="50,85 54,54 50,50 46,54" fill="currentColor" stroke="none" />
                    <polygon points="15,50 46,46 50,50 46,54" fill="currentColor" stroke="none" />
                    <polygon points="85,50 54,46 50,50 54,54" fill="currentColor" stroke="none" />
                    {/* Central Golden Triskelion Symbol */}
                    <circle cx="50" cy="50" r="10" fill="#F6F1E5" stroke="#B69A63" strokeWidth="1.5" />
                    <path 
                      d="M 50 44 C 54 44, 54 50, 50 50 C 46 50, 48 54, 52 54" 
                      stroke="#8C2928" 
                      strokeWidth="1.5" 
                      strokeLinecap="round" 
                    />
                  </svg>
                  <span className="absolute top-0.5 left-1/2 transform -translate-x-1/2 font-sans text-[8px] font-bold text-manx-green">N</span>
                </div>
              </div>
            </div>

            {/* Interactive Vector Map Grid Canvas */}
            <div className="relative flex-1 w-full h-[350px] sm:h-[450px] mt-4 select-none">
              
              {/* Illustrative Stylized Coastal SVG Silhouette background */}
              <svg 
                viewBox="0 0 100 100" 
                preserveAspectRatio="none"
                className="absolute inset-0 w-full h-full text-manx-green/5 stroke-manx-brass/15 fill-current pointer-events-none"
              >
                {/* Simplified Coastline of Isle of Man */}
                <path 
                  d="M 40,5 C 48,8 60,12 65,18 C 70,24 82,30 85,38 C 88,46 78,55 74,62 C 70,69 58,82 52,90 C 46,95 38,96 30,92 C 22,88 12,85 8,75 C 4,65 5,55 10,48 C 15,41 22,35 25,28 C 28,21 32,10 40,5 Z" 
                  strokeWidth="0.5" 
                  fill="currentColor"
                />
              </svg>

              {/* Physical Railway Track Lines plotted geographically */}
              <svg 
                viewBox="0 0 100 100" 
                preserveAspectRatio="none"
                className="absolute inset-0 w-full h-full fill-none pointer-events-none z-10"
              >
                {/* 1. STEAM RAILWAY LINE (Port Erin ↔ Douglas) */}
                <path 
                  d="M 8,83 L 14,84 L 18,86 L 24,88 L 31,84 L 37,81 L 43,77 L 48,72" 
                  stroke="var(--color-manx-green)" 
                  strokeWidth="1.2" 
                  strokeLinecap="round"
                />
                {/* Steam track sleepers cross marks */}
                <path 
                  d="M 8,83 L 14,84 L 18,86 L 24,88 L 31,84 L 37,81 L 43,77 L 48,72" 
                  stroke="var(--color-manx-cream)" 
                  strokeWidth="1" 
                  strokeDasharray="1,4" 
                  strokeLinecap="round"
                />

                {/* 2. ELECTRIC RAILWAY LINE (Douglas ↔ Ramsey) */}
                <path 
                  d="M 48,72 L 65,45 L 75,18" 
                  stroke="var(--color-manx-green)" 
                  strokeWidth="1.2" 
                  strokeLinecap="round"
                />
                {/* Electric sleepers cross marks */}
                <path 
                  d="M 48,72 L 65,45 L 75,18" 
                  stroke="var(--color-manx-cream)" 
                  strokeWidth="1" 
                  strokeDasharray="1,4" 
                  strokeLinecap="round"
                />

                {/* 3. SNAEFELL MOUNTAIN LINE (Laxey ↔ Summit) */}
                <path 
                  d="M 65,45 L 58,35" 
                  stroke="var(--color-manx-brass)" 
                  strokeWidth="1.5" 
                  strokeLinecap="round"
                />
                {/* Mountain cog center rail (Fell System) */}
                <path 
                  d="M 65,45 L 58,35" 
                  stroke="var(--color-manx-red)" 
                  strokeWidth="0.5" 
                  strokeLinecap="round"
                />
              </svg>

              {/* Station Markers Overlay */}
              {STATIONS.map((station) => {
                const isSelected = selectedStation.id === station.id;
                return (
                  <button
                    key={station.id}
                    onClick={() => setSelectedStation(station)}
                    style={{ left: `${station.x}%`, top: `${station.y}%` }}
                    className="absolute transform -translate-x-1/2 -translate-y-1/2 z-20 group focus:outline-none"
                    aria-label={`Select ${station.name} Station`}
                  >
                    {/* Ring Indicator */}
                    <span className="relative flex h-5 w-5 items-center justify-center">
                      {isSelected && (
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-manx-red opacity-40" />
                      )}
                      <span className={`relative rounded-full h-3.5 w-3.5 border-2 transition-all duration-300 ${
                        isSelected 
                          ? 'bg-manx-red border-manx-cream scale-125' 
                          : 'bg-manx-cream border-manx-green group-hover:bg-manx-brass'
                      }`} />
                    </span>

                    {/* Label tooltip floating above */}
                    <span className={`absolute bottom-6 left-1/2 transform -translate-x-1/2 px-2 py-1 text-[8px] font-sans font-extrabold uppercase tracking-widest whitespace-nowrap shadow-sm border transition-all duration-300 ${
                      isSelected 
                        ? 'bg-manx-green text-manx-cream border-manx-brass' 
                        : 'bg-manx-cream text-manx-charcoal border-manx-brass/20 opacity-0 group-hover:opacity-100'
                    }`}>
                      {station.name}
                    </span>
                  </button>
                );
              })}

            </div>

            {/* Map Legend Footer */}
            <div className="z-10 bg-manx-cream/90 border border-manx-brass/20 p-3 flex flex-wrap gap-4 items-center justify-center sm:justify-start text-[9px] font-sans font-bold tracking-widest uppercase text-manx-green">
              <div className="flex items-center space-x-2">
                <span className="w-5 h-1 bg-manx-green" />
                <span>Steam Railway Line</span>
              </div>
              <div className="flex items-center space-x-2">
                <span className="w-5 h-1 bg-manx-green" style={{ strokeDasharray: '2,2' }} />
                <span>Electric Tramway</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-5 h-1 bg-manx-brass relative">
                  <div className="absolute inset-0 h-[1px] bg-manx-red" />
                </div>
                <span>Snaefell Mountain Cog</span>
              </div>
              <div className="flex items-center space-x-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-manx-red border border-manx-cream" />
                <span>Interactive Halt</span>
              </div>
            </div>

          </div>

          {/* RIGHT: Sophisticated Editorial Station Overview Details Card (5 Columns) */}
          <div className="lg:col-span-5 flex flex-col">
            <AnimatePresence mode="wait">
              <motion.div
                key={selectedStation.id}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.4 }}
                className="bg-white border border-manx-brass/30 p-6 sm:p-8 flex-1 flex flex-col justify-between shadow-lg relative"
              >
                {/* Ticket punches style decoration */}
                <div className="absolute top-8 left-[-1px] w-1.5 h-3 bg-[#EFE9DC] border-r border-t border-b border-manx-brass/30" />
                <div className="absolute top-8 right-[-1px] w-1.5 h-3 bg-[#EFE9DC] border-l border-t border-b border-manx-brass/30" />

                <div>
                  {/* Category / Railway Badge */}
                  <span className="font-sans text-[10px] bg-manx-green/10 text-manx-green font-bold tracking-[0.2em] px-3 py-1 uppercase inline-block mb-4">
                    {selectedStation.railway === 'Shared' ? 'Interconnection Hub' : selectedStation.railway}
                  </span>

                  {/* Station Name */}
                  <h3 className="font-serif text-3xl sm:text-4xl text-manx-green tracking-tight font-semibold mb-3">
                    {selectedStation.name} Station
                  </h3>

                  {/* Tiny brass ruler divider */}
                  <div className="h-[2px] bg-manx-brass/20 w-1/4 mb-5" />

                  {/* Description text */}
                  <p className="font-sans text-xs sm:text-sm text-manx-charcoal/80 font-light leading-relaxed mb-6">
                    {selectedStation.description}
                  </p>

                  {/* Photographic snapshot representation */}
                  <div className="relative aspect-[16/9] w-full overflow-hidden border border-manx-brass/25 mb-6 shadow-inner">
                    <img
                      src={selectedStation.image}
                      alt={`${selectedStation.name} Station view`}
                      className="w-full h-full object-cover select-none"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent" />
                    <span className="absolute bottom-2 left-3 text-[9px] font-sans text-manx-cream/80 uppercase font-bold tracking-widest flex items-center space-x-1">
                      <Info className="w-3 h-3 text-manx-brass" />
                      <span>Heritage Site Reference</span>
                    </span>
                  </div>

                  {/* Station Facilities list */}
                  <div className="space-y-3">
                    <h4 className="font-sans text-[10px] tracking-widest text-manx-brass uppercase font-bold border-b border-manx-brass/15 pb-2">
                      Station Facilities
                    </h4>
                    <div className="grid grid-cols-2 gap-2 text-xs text-manx-charcoal/90">
                      {selectedStation.facilities.map((fac, idx) => (
                        <div key={idx} className="flex items-center space-x-2 font-sans font-semibold text-manx-green">
                          <CheckCircle className="w-3.5 h-3.5 text-manx-red flex-shrink-0" />
                          <span className="truncate">{fac}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Interactive button trigger linking to scheduling */}
                <div className="pt-6 mt-8 border-t border-manx-brass/20">
                  <a
                    href="#timetable"
                    className="w-full flex items-center justify-center space-x-2.5 bg-manx-green hover:bg-manx-green/90 text-manx-cream py-3 font-sans text-xs tracking-widest uppercase font-bold border border-manx-brass/40 block text-center"
                  >
                    <span>VIEW DEPARTURES FROM {selectedStation.name.toUpperCase()}</span>
                    <Navigation className="w-3.5 h-3.5 text-manx-brass" />
                  </a>
                </div>

              </motion.div>
            </AnimatePresence>
          </div>

        </div>
      </div>
    </section>
  );
}
