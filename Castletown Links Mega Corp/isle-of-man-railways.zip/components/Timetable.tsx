'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Clock, Calendar, MapPin, ArrowDown, ChevronRight, X, Sparkles } from 'lucide-react';
import { TIMETABLES, TimetableEntry } from '@/data/railwayData';

export function Timetable() {
  const [activeTab, setActiveTab] = React.useState<'steam' | 'electric' | 'snaefell'>('steam');
  const [selectedRide, setSelectedRide] = React.useState<TimetableEntry | null>(null);
  const [showFullModal, setShowFullModal] = React.useState(false);

  const tabs = [
    { id: 'steam', label: 'Steam Railway' },
    { id: 'electric', label: 'Electric Railway' },
    { id: 'snaefell', label: 'Snaefell Mountain Railway' },
  ] as const;

  const currentRides = TIMETABLES.filter(ride => ride.lineId === activeTab);

  return (
    <section className="py-20 bg-manx-cream border-t border-manx-brass/10" id="timetable">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Title */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="font-sans text-[10px] tracking-[0.25em] text-manx-brass uppercase font-bold block mb-3">
            LIVE SCHEDULES
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-manx-green font-semibold">
            Today&apos;s Journeys
          </h2>
          <div className="w-16 h-0.5 bg-manx-red mx-auto mt-4" />
        </div>

        {/* Tab Selectors */}
        <div className="flex flex-col sm:flex-row justify-center items-center space-y-2 sm:space-y-0 sm:space-x-4 mb-10">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id);
                setSelectedRide(null);
              }}
              className={`w-full sm:w-auto px-6 py-3 font-sans text-xs tracking-widest uppercase font-bold transition-all duration-300 border-b-2 rounded-none ${
                activeTab === tab.id
                  ? 'border-manx-red text-manx-green bg-white/50 shadow-sm'
                  : 'border-transparent text-manx-charcoal/60 hover:text-manx-green hover:border-manx-brass/40'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Dynamic Timetable List */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
          {currentRides.map((ride, index) => (
            <motion.div
              key={ride.id}
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              onClick={() => setSelectedRide(ride)}
              className="bg-[#FCFAF6] hover:bg-white border border-manx-brass/20 hover:border-manx-brass/40 p-6 shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer relative flex flex-col justify-between group"
            >
              {/* Top Details bar */}
              <div className="flex justify-between items-center pb-4 mb-4 border-b border-manx-brass/10">
                <span className="font-sans text-[10px] bg-manx-green text-manx-cream font-semibold tracking-widest px-2.5 py-1 uppercase">
                  {ride.trainNo}
                </span>
                <span className="font-sans text-[10px] text-manx-brass font-bold tracking-wider uppercase flex items-center space-x-1">
                  <Clock className="w-3 h-3" />
                  <span>Scheduled Daily</span>
                </span>
              </div>

              {/* Graphical Segment Journey Block */}
              <div className="grid grid-cols-7 items-center py-4 relative">
                {/* Visual connecting railway track graphic */}
                <div className="absolute top-[40%] left-[22%] right-[22%] h-[2px] bg-manx-brass/25 pointer-events-none" />
                <div className="absolute top-[40%] left-[22%] right-[22%] h-[2px] bg-manx-brass/25 translate-y-[2px] pointer-events-none" />
                
                {/* Origin */}
                <div className="col-span-2 text-center sm:text-left">
                  <span className="block font-serif text-3xl text-manx-green font-bold tracking-tight">
                    {ride.depTime}
                  </span>
                  <span className="block font-sans text-[11px] text-manx-charcoal/70 uppercase tracking-widest font-semibold mt-1">
                    {ride.from}
                  </span>
                </div>

                {/* Vertical arrows and track symbols */}
                <div className="col-span-3 flex flex-col items-center justify-center">
                  <div className="flex items-center space-x-1 text-manx-brass">
                    <div className="w-1.5 h-1.5 rounded-full bg-manx-red" />
                    <ChevronRight className="w-4 h-4" />
                    <div className="w-1.5 h-1.5 rounded-full bg-manx-red" />
                  </div>
                  <span className="text-[9px] text-manx-brass uppercase font-bold tracking-widest mt-1.5">
                    {ride.stops.length - 2} STOP{ride.stops.length - 2 !== 1 ? 'S' : ''}
                  </span>
                </div>

                {/* Destination */}
                <div className="col-span-2 text-center sm:text-right">
                  <span className="block font-serif text-3xl text-manx-green font-bold tracking-tight">
                    {ride.arrTime}
                  </span>
                  <span className="block font-sans text-[11px] text-manx-charcoal/70 uppercase tracking-widest font-semibold mt-1">
                    {ride.to}
                  </span>
                </div>
              </div>

              {/* Bottom footer button prompt */}
              <div className="mt-4 pt-4 border-t border-manx-brass/10 flex justify-between items-center text-[10px] font-sans font-extrabold uppercase tracking-widest text-manx-red">
                <span>View Route Stopover Times</span>
                <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* View Full Timetable CTA */}
        <div className="text-center mt-12">
          <button
            onClick={() => setShowFullModal(true)}
            className="inline-flex items-center space-x-2.5 bg-transparent hover:bg-manx-green/10 text-manx-green hover:text-manx-green border border-manx-green px-8 py-3.5 rounded-none font-sans text-xs tracking-widest uppercase font-bold transition-all duration-300"
          >
            <span>VIEW FULL SYSTEM TIMETABLE</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>

        {/* Selected Route Intermediate Stops Details Popup Overlay */}
        <AnimatePresence>
          {selectedRide && (
            <div className="fixed inset-0 bg-manx-charcoal/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="bg-manx-cream border-2 border-manx-brass w-full max-w-md p-6 relative shadow-2xl overflow-hidden"
              >
                {/* Decorative Circular ticket punches */}
                <div className="absolute top-12 -left-4 w-8 h-8 rounded-full bg-manx-charcoal" />
                <div className="absolute top-12 -right-4 w-8 h-8 rounded-full bg-manx-charcoal" />

                <button
                  onClick={() => setSelectedRide(null)}
                  className="absolute right-4 top-4 text-manx-green/60 hover:text-manx-green"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="border-b-2 border-dashed border-manx-brass/40 pb-4 mb-6">
                  <span className="font-sans text-[9px] font-extrabold tracking-widest bg-manx-red text-manx-cream px-2 py-0.5 uppercase">
                    Heritage Ticket Stub
                  </span>
                  <h3 className="font-serif text-2xl text-manx-green mt-2 font-bold">
                    {selectedRide.trainNo} Service
                  </h3>
                  <p className="font-sans text-[10px] uppercase text-manx-brass font-bold tracking-wider">
                    {selectedRide.runsOn}
                  </p>
                </div>

                <div className="space-y-4 relative pl-8">
                  {/* Central timeline line */}
                  <div className="absolute top-2 bottom-2 left-[15px] w-0.5 bg-manx-green/30" />

                  {selectedRide.stops.map((stop, sIdx) => (
                    <div key={sIdx} className="flex items-center justify-between relative py-1">
                      {/* Node circle */}
                      <div className={`absolute left-[-21px] w-[11px] h-[11px] rounded-full border border-manx-brass ${
                        sIdx === 0 || sIdx === selectedRide.stops.length - 1 
                          ? 'bg-manx-red' 
                          : 'bg-white'
                      }`} />
                      
                      <span className="font-sans text-xs sm:text-sm text-manx-green font-bold uppercase tracking-wider">
                        {stop.station}
                      </span>
                      <span className="font-serif text-sm font-bold text-manx-brass">
                        {stop.time}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="mt-8 pt-4 border-t border-manx-brass/20 flex justify-end">
                  <button
                    onClick={() => setSelectedRide(null)}
                    className="bg-manx-green hover:bg-manx-green/90 text-manx-cream px-6 py-2.5 font-sans text-xs tracking-widest uppercase font-bold"
                  >
                    Close Schedule
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

        {/* Full Timetable System Modal */}
        <AnimatePresence>
          {showFullModal && (
            <div className="fixed inset-0 bg-manx-charcoal/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
              <motion.div
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 50 }}
                className="bg-manx-cream border-2 border-manx-brass w-full max-w-4xl max-h-[85vh] overflow-y-auto p-6 sm:p-8 relative shadow-2xl"
              >
                <button
                  onClick={() => setShowFullModal(false)}
                  className="absolute right-4 top-4 text-manx-green/60 hover:text-manx-green p-2 border border-transparent hover:border-manx-brass/20"
                >
                  <X className="w-5 h-5" />
                </button>

                <div className="border-b border-manx-brass/30 pb-4 mb-6">
                  <span className="font-sans text-[10px] tracking-widest text-manx-brass uppercase font-bold">
                    Official 2026 Timetable Log
                  </span>
                  <h3 className="font-serif text-3xl text-manx-green font-bold">
                    Complete Scheduled Services
                  </h3>
                  <p className="font-sans text-xs text-manx-charcoal/70 mt-1">
                    Interactive timetables for Steam, Electric, and Mountain networks.
                  </p>
                </div>

                {/* Table Content */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b-2 border-manx-green text-[10px] font-sans font-bold uppercase tracking-widest text-manx-green">
                        <th className="py-3">Line</th>
                        <th className="py-3">Service</th>
                        <th className="py-3">Origin</th>
                        <th className="py-3">Departure</th>
                        <th className="py-3">Destination</th>
                        <th className="py-3">Arrival</th>
                        <th className="py-3">Frequency</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-manx-brass/10 font-sans text-xs font-semibold text-manx-charcoal/90">
                      {TIMETABLES.map((ride) => (
                        <tr key={ride.id} className="hover:bg-white/50 transition-colors">
                          <td className="py-4">
                            <span className={`px-2 py-0.5 text-[9px] font-bold uppercase tracking-widest ${
                              ride.lineId === 'steam' 
                                ? 'bg-manx-red/10 text-manx-red' 
                                : ride.lineId === 'electric' 
                                ? 'bg-manx-green/10 text-manx-green' 
                                : 'bg-manx-brass/15 text-manx-charcoal'
                            }`}>
                              {ride.lineId}
                            </span>
                          </td>
                          <td className="py-4 font-bold">{ride.trainNo}</td>
                          <td className="py-4">{ride.from}</td>
                          <td className="py-4 font-serif font-bold text-sm text-manx-green">{ride.depTime}</td>
                          <td className="py-4">{ride.to}</td>
                          <td className="py-4 font-serif font-bold text-sm text-manx-green">{ride.arrTime}</td>
                          <td className="py-4 text-manx-charcoal/60">{ride.runsOn}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="mt-8 pt-6 border-t border-manx-brass/30 flex justify-end space-x-4">
                  <button
                    onClick={() => {
                      setShowFullModal(false);
                      const printSection = document.getElementById('timetable');
                      if (printSection) printSection.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="px-6 py-3 border border-manx-brass text-manx-green font-sans text-xs tracking-widest uppercase font-bold"
                  >
                    Back To Today&apos;s
                  </button>
                  <button
                    onClick={() => setShowFullModal(false)}
                    className="bg-manx-green hover:bg-manx-green/90 text-manx-cream px-6 py-3 font-sans text-xs tracking-widest uppercase font-bold"
                  >
                    Done Viewing
                  </button>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}
