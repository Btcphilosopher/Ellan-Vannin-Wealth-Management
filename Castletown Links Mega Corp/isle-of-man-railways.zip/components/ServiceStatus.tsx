'use client';

import * as React from 'react';
import { motion } from 'motion/react';
import { NEWS_ITEMS, NewsItem } from '@/data/railwayData';
import { AlertTriangle, CheckCircle, Calendar, ArrowRight, Rss, Clock, ShieldAlert } from 'lucide-react';

export function ServiceStatus() {
  const [isDisrupted, setIsDisrupted] = React.useState(false);
  const [selectedNews, setSelectedNews] = React.useState<NewsItem | null>(null);

  return (
    <section className="py-24 bg-[#FAF7F2] border-t border-manx-brass/10" id="news">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-sans text-[10px] tracking-[0.25em] text-manx-brass uppercase font-bold block mb-3">
            ANNOUNCEMENTS & NEWS
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-manx-green font-semibold">
            From the Railway
          </h2>
          <div className="w-16 h-0.5 bg-manx-red mx-auto mt-4" />
        </div>

        {/* SERVICE STATUS BANNER */}
        <div className="max-w-4xl mx-auto mb-16" id="status-banner">
          <div className={`border-l-4 p-5 sm:p-6 transition-colors duration-500 flex flex-col sm:flex-row sm:items-center sm:justify-between shadow-sm relative overflow-hidden ${
            isDisrupted 
              ? 'bg-amber-50 border-manx-red text-manx-charcoal' 
              : 'bg-emerald-50/55 border-manx-green text-manx-charcoal'
          }`}>
            
            {/* Stamp notch details */}
            <div className="absolute top-0 right-0 w-8 h-8 bg-manx-cream border-b border-l border-manx-brass/10 rotate-45 transform translate-x-4 -translate-y-4" />

            <div className="flex items-start space-x-4">
              <div className="mt-1">
                {isDisrupted ? (
                  <AlertTriangle className="w-6 h-6 text-manx-red animate-pulse" />
                ) : (
                  <CheckCircle className="w-6 h-6 text-manx-green" />
                )}
              </div>
              <div>
                <span className="block font-sans text-[10px] tracking-widest text-manx-brass uppercase font-bold">
                  SERVICE INFORMATION
                </span>
                <p className="font-serif text-lg font-bold text-manx-green mt-1">
                  {isDisrupted 
                    ? 'Weather Alert: Heavy coastal fog near Snaefell. Delays expected on mountain lines.' 
                    : 'All services currently operating normally.'
                  }
                </p>
                <p className="font-sans text-xs text-manx-charcoal/60 mt-0.5 font-light">
                  Last updated: Today at 13:47 BST • System Live Update
                </p>
              </div>
            </div>

            {/* Simulated Live API toggle button */}
            <div className="mt-4 sm:mt-0">
              <button
                onClick={() => setIsDisrupted(!isDisrupted)}
                className="inline-flex items-center space-x-2 text-[9px] font-sans font-extrabold tracking-widest uppercase border border-manx-brass/30 px-4 py-2 hover:bg-white text-manx-green bg-[#FCFAF6] transition-all"
              >
                <span>SIMULATE DISRUPTION</span>
                <Clock className="w-3.5 h-3.5 text-manx-brass" />
              </button>
            </div>
          </div>
        </div>

        {/* NEWS & UPDATES CARDS (Three Columns) */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {NEWS_ITEMS.map((item) => (
            <div 
              key={item.id}
              className="bg-white border border-manx-brass/20 flex flex-col justify-between h-full hover:shadow-lg transition-shadow duration-300 p-6 relative"
              id={`news-item-${item.id}`}
            >
              {/* Corner accent notch */}
              <div className="absolute top-0 right-0 w-3 h-3 bg-[#FAF7F2] border-b border-l border-manx-brass/25" />

              <div>
                {/* Category & Date */}
                <div className="flex items-center justify-between font-sans text-[9px] font-bold tracking-wider text-manx-brass uppercase mb-4 pb-2 border-b border-manx-brass/10">
                  <span>{item.category}</span>
                  <span className="text-manx-charcoal/50 flex items-center space-x-1">
                    <Calendar className="w-3 h-3 text-manx-brass/60" />
                    <span>{item.date}</span>
                  </span>
                </div>

                {/* News Title */}
                <h3 className="font-serif text-lg sm:text-xl text-manx-green leading-snug font-bold mb-3">
                  {item.title}
                </h3>

                {/* News Summary */}
                <p className="font-sans text-xs text-manx-charcoal/80 leading-relaxed font-light mb-6">
                  {item.summary}
                </p>
              </div>

              {/* View Article trigger button */}
              <button
                onClick={() => setSelectedNews(item)}
                className="w-full text-left bg-transparent hover:text-manx-red text-manx-green font-sans text-[10px] tracking-widest uppercase font-extrabold flex items-center justify-between pt-4 border-t border-manx-brass/10 group"
              >
                <span>READ ARTICLE</span>
                <ArrowRight className="w-3.5 h-3.5 text-manx-brass group-hover:translate-x-1.5 transition-transform" />
              </button>
            </div>
          ))}
        </div>

        {/* Article Details Modal Backdrop */}
        {selectedNews && (
          <div className="fixed inset-0 bg-manx-charcoal/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-manx-cream border-2 border-manx-brass w-full max-w-lg p-6 sm:p-8 relative shadow-2xl"
            >
              <button
                onClick={() => setSelectedNews(null)}
                className="absolute right-4 top-4 text-manx-green/60 hover:text-manx-green p-2 font-bold"
              >
                ✕ Close
              </button>

              <span className="font-sans text-[9px] font-extrabold tracking-widest bg-manx-green text-manx-cream px-2 py-0.5 uppercase">
                {selectedNews.category}
              </span>

              <h3 className="font-serif text-2xl sm:text-3xl text-manx-green mt-3 mb-2 font-bold leading-tight">
                {selectedNews.title}
              </h3>
              <span className="font-sans text-[10px] text-manx-brass uppercase font-bold">
                Published: {selectedNews.date} • Isle of Man Railways Press Office
              </span>

              <div className="mt-6 pt-4 border-t border-manx-brass/10 text-xs sm:text-sm font-sans text-manx-charcoal/90 leading-relaxed font-light space-y-4">
                <p className="italic font-normal text-manx-green">
                  {selectedNews.summary}
                </p>
                <p>
                  {selectedNews.content}
                </p>
                <p>
                  Additional historical and service bulletins are pushed to our local networks daily. To connect with live feeds, check intermediate terminal announcements.
                </p>
              </div>

              <div className="mt-8 pt-4 border-t border-manx-brass/25 flex justify-end">
                <button
                  onClick={() => setSelectedNews(null)}
                  className="bg-manx-green hover:bg-manx-green/90 text-manx-cream px-6 py-2.5 font-sans text-xs tracking-widest uppercase font-bold"
                >
                  Done Reading
                </button>
              </div>
            </motion.div>
          </div>
        )}

      </div>
    </section>
  );
}
