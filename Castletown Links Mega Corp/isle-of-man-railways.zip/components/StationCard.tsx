'use client';

import { Station } from '@/data/railwayData';
import { ArrowRight, Landmark } from 'lucide-react';

interface StationCardProps {
  station: Station;
  onExplore: (stationId: string) => void;
}

export function StationCard({ station, onExplore }: StationCardProps) {
  return (
    <div 
      className="bg-white border-2 border-manx-green p-4 flex flex-col justify-between h-full shadow-md hover:shadow-xl transition-all duration-300 relative group"
      id={`station-card-${station.id}`}
    >
      {/* Visual Header Stamp mimicking postage marks */}
      <div className="absolute top-6 right-6 w-10 h-10 border border-manx-red/40 rounded-full flex items-center justify-center p-0.5 pointer-events-none select-none opacity-40 group-hover:scale-105 duration-500">
        <span className="font-serif text-[7px] text-manx-red font-bold uppercase text-center leading-none">
          Manx <br /> Post
        </span>
      </div>

      <div>
        {/* Frame Boundary Container representing travel poster photography */}
        <div className="relative aspect-[3/4] w-full overflow-hidden border border-manx-green/20 mb-4 bg-manx-charcoal">
          <img
            src={station.image}
            alt={station.name}
            className="w-full h-full object-cover transform duration-700 ease-out group-hover:scale-105 filter grayscale-[25%] contrast-[110%]"
            referrerPolicy="no-referrer"
          />
          {/* Subtle warm, faded filter overlay */}
          <div className="absolute inset-0 bg-manx-green/5 mix-blend-multiply" />
          <div className="absolute inset-0 bg-gradient-to-t from-manx-green/40 to-transparent" />
          
          {/* Station Name Printed directly in bottom of the photo container */}
          <div className="absolute bottom-4 left-4 right-4 text-left">
            <span className="font-sans text-[8px] tracking-widest text-manx-brass uppercase font-bold block mb-1">
              {station.railway === 'Shared' ? 'STEAM & ELECTRIC HUB' : station.railway.toUpperCase()}
            </span>
            <h3 className="font-serif text-2xl text-manx-cream tracking-wider font-semibold uppercase">
              {station.name}
            </h3>
          </div>
        </div>

        {/* Short description */}
        <p className="font-sans text-xs text-manx-charcoal/80 font-light leading-relaxed mb-4 min-h-[48px]">
          {station.description}
        </p>

        {/* Small facilities badges list */}
        <div className="flex flex-wrap gap-1 mb-5">
          {station.facilities.slice(0, 3).map((facility, index) => (
            <span 
              key={index} 
              className="font-sans text-[8px] font-bold tracking-wider text-manx-green bg-manx-cream px-2 py-0.5 border border-manx-brass/20 uppercase"
            >
              {facility}
            </span>
          ))}
          {station.facilities.length > 3 && (
            <span className="font-sans text-[8px] text-manx-brass bg-manx-cream px-1.5 py-0.5 font-bold">
              +{station.facilities.length - 3} MORE
            </span>
          )}
        </div>
      </div>

      {/* Explore Station Trigger Button */}
      <button
        onClick={() => onExplore(station.id)}
        className="w-full bg-manx-green hover:bg-manx-red text-manx-cream py-2.5 font-sans text-[10px] tracking-widest uppercase font-extrabold border border-manx-brass/30 flex items-center justify-center space-x-2 transition-all duration-300"
      >
        <span>EXPLORE STATION</span>
        <ArrowRight className="w-3 h-3 text-manx-brass" />
      </button>
    </div>
  );
}
