'use client';

import * as React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Menu, X, ArrowRight, Compass } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HeaderProps {
  onPlanClick: () => void;
  onSectionClick: (sectionId: string) => void;
  activeSection: string;
}

export function Header({ onPlanClick, onSectionClick, activeSection }: HeaderProps) {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = React.useState(false);

  const navLinks = [
    { label: 'Timetables', href: 'timetable' },
    { label: 'Tickets', href: 'tickets' },
    { label: 'Lines', href: 'lines' },
    { label: 'Stations', href: 'stations' },
    { label: 'Visit', href: 'visit' },
    { label: 'About', href: 'heritage' },
  ];

  const handleLinkClick = (href: string) => {
    setIsMobileMenuOpen(false);
    onSectionClick(href);
  };

  return (
    <header className="sticky top-0 z-50 w-full bg-manx-green text-manx-cream border-b border-manx-brass/20 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Left Side: Refined Isle of Man Railways Logo */}
          <div 
            onClick={() => handleLinkClick('hero')} 
            className="flex items-center space-x-3 cursor-pointer group"
            id="logo-container"
          >
            <div className="relative w-11 h-11 bg-manx-cream rounded-none flex items-center justify-center border border-manx-brass p-1 shadow-sm transition-transform duration-300 group-hover:scale-105">
              {/* Elegant Simplified Manx Triskelion + Railway Track Geometry vector */}
              <svg 
                viewBox="0 0 100 100" 
                className="w-full h-full text-manx-green fill-current"
                aria-hidden="true"
              >
                {/* Outer vintage track circular boundary */}
                <circle cx="50" cy="50" r="45" fill="none" stroke="currentColor" strokeWidth="2.5" strokeDasharray="3,3" />
                <circle cx="50" cy="50" r="39" fill="none" stroke="currentColor" strokeWidth="1.5" />
                
                {/* 3 spokes representing tracks meeting in the center like a triskelion */}
                <path d="M 50 11 L 50 42" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                <path d="M 16 70 L 43 54" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                <path d="M 84 70 L 57 54" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
                
                {/* Standard locomotive buffer block / central triskelion leg nodes */}
                <circle cx="50" cy="50" r="7" className="text-manx-red fill-current" />
                
                {/* Small track sleepers crossing */}
                <line x1="44" y1="20" x2="56" y2="20" stroke="currentColor" strokeWidth="2" />
                <line x1="44" y1="30" x2="56" y2="30" stroke="currentColor" strokeWidth="2" />
                
                <line x1="22" y1="60" x2="31" y2="65" stroke="currentColor" strokeWidth="2" />
                <line x1="28" y1="52" x2="37" y2="57" stroke="currentColor" strokeWidth="2" />
                
                <line x1="78" y1="60" x2="69" y2="65" stroke="currentColor" strokeWidth="2" />
                <line x1="72" y1="52" x2="63" y2="57" stroke="currentColor" strokeWidth="2" />
              </svg>
            </div>
            <div className="flex flex-col select-none">
              <span className="font-serif text-lg tracking-wider font-semibold leading-tight group-hover:text-manx-brass transition-colors">
                ISLE OF MAN
              </span>
              <span className="font-sans text-[10px] tracking-[0.25em] text-manx-brass uppercase font-bold leading-none">
                RAILWAYS • STEAM • ELECTRIC • ISLAND
              </span>
            </div>
          </div>

          {/* Center Navigation: Desktop */}
          <nav className="hidden lg:flex space-x-8">
            {navLinks.map((link) => (
              <button
                key={link.href}
                onClick={() => onSectionClick(link.href)}
                className={cn(
                  "font-sans text-xs tracking-widest uppercase font-semibold transition-all duration-300 relative py-2 border-b-2",
                  activeSection === link.href 
                    ? "text-manx-cream border-manx-red" 
                    : "text-manx-cream/70 border-transparent hover:text-manx-cream hover:border-manx-brass"
                )}
              >
                {link.label}
              </button>
            ))}
          </nav>

          {/* Right Button: Desktop PLAN YOUR JOURNEY */}
          <div className="hidden lg:block">
            <button
              onClick={onPlanClick}
              className="group flex items-center space-x-2 bg-manx-red hover:bg-manx-red/90 text-manx-cream px-5 py-2.5 rounded-none font-sans text-xs tracking-widest uppercase font-bold border border-manx-brass/40 shadow-md transition-all duration-300 hover:scale-[1.02] active:scale-95"
            >
              <span>Plan Your Journey</span>
              <ArrowRight className="w-3.5 h-3.5 text-manx-brass transition-transform duration-300 group-hover:translate-x-1" />
            </button>
          </div>

          {/* Mobile Hamburguer Button */}
          <div className="flex items-center lg:hidden">
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-manx-cream hover:text-manx-brass p-2 focus:outline-none"
              aria-label="Toggle Menu"
            >
              {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Slide-out Drawer */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsMobileMenuOpen(false)}
              className="fixed inset-0 bg-black z-40 lg:hidden"
            />

            {/* Panel */}
            <motion.div
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'tween', duration: 0.3 }}
              className="fixed top-0 right-0 bottom-0 w-[280px] bg-manx-green text-manx-cream border-l border-manx-brass/30 p-6 z-50 flex flex-col justify-between lg:hidden"
            >
              <div>
                <div className="flex items-center justify-between pb-6 border-b border-manx-cream/10 mb-8">
                  <div className="flex items-center space-x-2">
                    <Compass className="w-5 h-5 text-manx-brass" />
                    <span className="font-serif font-bold tracking-widest uppercase text-sm">Discover the Isle</span>
                  </div>
                  <button 
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="text-manx-cream/70 hover:text-manx-cream"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <nav className="flex flex-col space-y-6">
                  {navLinks.map((link) => (
                    <button
                      key={link.href}
                      onClick={() => handleLinkClick(link.href)}
                      className={cn(
                        "text-left font-sans text-sm tracking-widest uppercase font-semibold py-2 border-l-2 pl-4",
                        activeSection === link.href 
                          ? "text-manx-cream border-manx-red" 
                          : "text-manx-cream/60 border-transparent hover:text-manx-cream hover:border-manx-brass"
                      )}
                    >
                      {link.label}
                    </button>
                  ))}
                </nav>
              </div>

              <div className="pt-6 border-t border-manx-cream/10">
                <button
                  onClick={() => {
                    setIsMobileMenuOpen(false);
                    onPlanClick();
                  }}
                  className="w-full text-center bg-manx-red hover:bg-manx-red/90 text-manx-cream py-3 font-sans text-xs tracking-widest uppercase font-bold border border-manx-brass/40 block"
                >
                  Plan Your Journey →
                </button>
                <div className="text-center mt-4">
                  <span className="text-[10px] text-manx-cream/40 uppercase font-semibold tracking-wider">
                    © 2026 Isle of Man Railways
                  </span>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
