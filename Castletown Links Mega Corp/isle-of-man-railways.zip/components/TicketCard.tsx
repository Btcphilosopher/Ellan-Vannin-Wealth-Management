'use client';

import * as React from 'react';
import { TicketType } from '@/data/railwayData';
import { Ticket, Check, Sparkles, X, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface TicketCardProps {
  ticket: TicketType;
}

export function TicketCard({ ticket }: TicketCardProps) {
  const [showPurchaseModal, setShowPurchaseModal] = React.useState(false);

  return (
    <>
      <div 
        className="bg-[#FCFAF6] border border-manx-brass/35 p-6 sm:p-8 flex flex-col justify-between h-full relative shadow-md hover:shadow-xl transition-all duration-300 group"
        id={`ticket-card-${ticket.id}`}
      >
        {/* Ticket Perforated Division Notch Details at Top/Bottom Sides */}
        <div className="absolute top-1/2 -left-3 w-6 h-12 bg-manx-cream border-r border-manx-brass/25 rounded-full transform -translate-y-1/2" />
        <div className="absolute top-1/2 -right-3 w-6 h-12 bg-manx-cream border-l border-manx-brass/25 rounded-full transform -translate-y-1/2" />

        <div>
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-dashed border-manx-brass/30 mb-5 pl-3">
            <div className="flex items-center space-x-2">
              <Ticket className="w-5 h-5 text-manx-red group-hover:rotate-12 transition-transform duration-500" />
              <span className="font-sans text-[9px] font-bold tracking-widest text-manx-brass uppercase">
                HERITAGE FARES
              </span>
            </div>
            <span className="font-sans text-[8px] font-semibold text-manx-charcoal/40 uppercase">
              Form 2026-A
            </span>
          </div>

          {/* Ticket Title */}
          <h3 className="font-serif text-2xl text-manx-green font-bold pl-3 mb-2">
            {ticket.name}
          </h3>

          {/* Short Description */}
          <p className="font-sans text-xs text-manx-charcoal/80 leading-relaxed font-light pl-3 mb-6 min-h-[36px]">
            {ticket.description}
          </p>

          {/* Benefit Items List */}
          <ul className="space-y-3.5 pl-3 mb-8">
            {ticket.benefits.map((benefit, index) => (
              <li key={index} className="flex items-start space-x-2.5 text-xs text-manx-charcoal">
                <Check className="w-3.5 h-3.5 text-manx-red mt-0.5 flex-shrink-0" />
                <span className="font-sans font-medium leading-tight">{benefit}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Fare Section with Placeholder and Action Button */}
        <div className="pt-6 border-t border-dashed border-manx-brass/30 pl-3">
          <div className="flex items-end justify-between mb-4">
            <div>
              <span className="block font-sans text-[9px] font-bold text-manx-brass tracking-wider uppercase mb-1">
                Standard Fare
              </span>
              <span className="font-serif text-3xl font-extrabold text-manx-green">
                {ticket.farePlaceholder}
              </span>
            </div>
            <div className="text-right">
              <span className="block font-sans text-[8px] text-manx-charcoal/40 uppercase font-bold">
                API Dynamic Link
              </span>
              <span className="text-[10px] text-manx-red font-bold uppercase tracking-wider">
                Pending Setup
              </span>
            </div>
          </div>

          <button
            onClick={() => setShowPurchaseModal(true)}
            className="w-full text-center bg-manx-green hover:bg-manx-red text-manx-cream font-sans text-xs tracking-widest uppercase font-bold py-3.5 border border-manx-brass/30 transition-all duration-300"
          >
            SELECT TICKET →
          </button>
        </div>
      </div>

      {/* Simulated Purchase / Reservation Drawer Modal */}
      <AnimatePresence>
        {showPurchaseModal && (
          <div className="fixed inset-0 bg-manx-charcoal/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-manx-cream border-2 border-manx-brass w-full max-w-md p-6 relative shadow-2xl"
            >
              <button
                onClick={() => setShowPurchaseModal(false)}
                className="absolute right-4 top-4 text-manx-green/60 hover:text-manx-green p-2"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="border-b border-manx-brass/25 pb-4 mb-6">
                <span className="font-sans text-[9px] font-extrabold tracking-widest bg-manx-red text-manx-cream px-2 py-0.5 uppercase">
                  Simulated Checkout Gateway
                </span>
                <h3 className="font-serif text-2xl text-manx-green mt-2 font-bold">
                  Purchase {ticket.name}
                </h3>
                <p className="font-sans text-xs text-manx-charcoal/70 mt-1">
                  API booking infrastructure is currently simulated.
                </p>
              </div>

              <div className="space-y-4">
                <div className="bg-white p-4 border border-manx-brass/15 rounded-none">
                  <div className="flex justify-between font-sans text-xs uppercase font-bold text-manx-green pb-2 border-b border-manx-brass/10 mb-2">
                    <span>Fare Subtotal:</span>
                    <span className="font-serif text-sm text-manx-red">{ticket.farePlaceholder}</span>
                  </div>
                  <p className="text-xs text-manx-charcoal/60 leading-relaxed font-light">
                    Real fare tariffs are currently pending synchronization with the Isle of Man Railways central ticketing database. No payments are processed.
                  </p>
                </div>

                <div className="text-xs font-sans text-manx-charcoal/70 border-l-2 border-manx-brass pl-3">
                  <p className="font-bold">Future API Integration Outline:</p>
                  <p className="font-light mt-0.5">
                    This front-end will bind to the secure central ticketing database once credentials are added to the platform secrets.
                  </p>
                </div>
              </div>

              <div className="mt-8 pt-4 border-t border-manx-brass/20 flex justify-end space-x-2">
                <button
                  onClick={() => setShowPurchaseModal(false)}
                  className="bg-transparent hover:bg-manx-green/5 text-manx-green border border-manx-brass px-6 py-2.5 font-sans text-xs tracking-widest uppercase font-bold"
                >
                  Cancel
                </button>
                <button
                  onClick={() => setShowPurchaseModal(false)}
                  className="bg-manx-green hover:bg-manx-green/90 text-manx-cream px-6 py-2.5 font-sans text-xs tracking-widest uppercase font-bold"
                >
                  Return to Site
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}
