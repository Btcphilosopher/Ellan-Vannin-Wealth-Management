'use client';

import { motion } from 'motion/react';
import { HERITAGE_TIMELINE } from '@/data/railwayData';
import { Landmark, Calendar, ArrowDown, History } from 'lucide-react';

export function HeritageTimeline() {
  return (
    <section className="py-24 bg-manx-cream relative" id="heritage">
      {/* Decorative Track Watermark inside Background */}
      <div className="absolute top-10 right-10 opacity-5 pointer-events-none text-manx-green max-w-sm">
        <History className="w-96 h-96" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Editorial Heading */}
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="font-sans text-[10px] tracking-[0.25em] text-manx-brass uppercase font-bold block mb-3">
            CHRONICLES & PRESERVATION
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-manx-green font-semibold">
            A Railway with a Story
          </h2>
          <div className="w-16 h-0.5 bg-manx-red mx-auto mt-4" />
        </div>

        {/* Timeline Grid Container */}
        <div className="max-w-4xl mx-auto relative pl-6 sm:pl-0">
          
          {/* Vertical Track Timeline Spine (desktop: centered, mobile: left-aligned) */}
          <div className="absolute top-4 bottom-4 left-6 sm:left-1/2 w-[3px] bg-manx-green/20 transform sm:-translate-x-1/2" />
          <div className="absolute top-4 bottom-4 left-[26px] sm:left-1/2 w-[1px] bg-manx-green/40 transform sm:-translate-x-1/2 translate-x-[2px] hidden sm:block" />
          
          {/* Railway Sleepers decorations along timeline spine */}
          <div className="absolute inset-0 pointer-events-none select-none hidden sm:block">
            <div className="absolute top-1/4 left-1/2 w-4 h-[2px] bg-manx-brass/30 transform -translate-x-1/2" />
            <div className="absolute top-2/4 left-1/2 w-4 h-[2px] bg-manx-brass/30 transform -translate-x-1/2" />
            <div className="absolute top-3/4 left-1/2 w-4 h-[2px] bg-manx-brass/30 transform -translate-x-1/2" />
          </div>

          <div className="space-y-12 sm:space-y-16">
            {HERITAGE_TIMELINE.map((milestone, index) => {
              const isEven = index % 2 === 0;
              return (
                <div 
                  key={milestone.year} 
                  className={`relative flex flex-col sm:flex-row items-start ${
                    isEven ? 'sm:flex-row-reverse' : ''
                  }`}
                >
                  {/* Spine Node Dot */}
                  <div className="absolute left-[-23px] sm:left-1/2 top-1 w-[15px] h-[15px] rounded-full border border-manx-brass bg-manx-red z-10 transform sm:-translate-x-1/2 flex items-center justify-center shadow-md">
                    <div className="w-1.5 h-1.5 rounded-full bg-manx-cream" />
                  </div>

                  {/* Left Column Spacer / Card Container (Desktop: 50% width) */}
                  <div className="w-full sm:w-1/2 pl-4 sm:pl-0 sm:px-12">
                    <motion.div
                      initial={{ opacity: 0, x: isEven ? 25 : -25 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true, margin: '-100px' }}
                      transition={{ duration: 0.6 }}
                      className="bg-white p-6 sm:p-8 border border-manx-brass/25 hover:border-manx-brass/40 shadow-sm hover:shadow-md transition-shadow duration-300 relative"
                    >
                      {/* Decorative Corner Label */}
                      <span className="absolute top-3 right-4 font-serif text-3xl font-extrabold text-manx-brass/30 tracking-wider">
                        {milestone.year}
                      </span>

                      {/* Year Indicator */}
                      <div className="flex items-center space-x-2 mb-3">
                        <span className="font-serif text-xl sm:text-2xl text-manx-red font-bold">
                          {milestone.year}
                        </span>
                        <div className="w-1.5 h-1.5 rounded-full bg-manx-green" />
                        <span className="font-sans text-[8px] font-bold tracking-widest text-manx-charcoal/40 uppercase">
                          Manx Archives
                        </span>
                      </div>

                      {/* Heading */}
                      <h3 className="font-serif text-lg sm:text-xl text-manx-green font-bold mb-2">
                        {milestone.title}
                      </h3>

                      {/* Description */}
                      <p className="font-sans text-xs sm:text-sm text-manx-charcoal/80 font-light leading-relaxed">
                        {milestone.description}
                      </p>
                    </motion.div>
                  </div>

                  {/* Right Column Spacer for balance on desktop */}
                  <div className="hidden sm:block sm:w-1/2" />

                </div>
              );
            })}
          </div>

        </div>

        {/* Vintage Footer Statement */}
        <div className="text-center mt-16 max-w-xl mx-auto bg-white/50 border border-manx-brass/20 p-6">
          <p className="font-serif italic text-sm text-manx-green font-semibold">
            &ldquo;A living connection to our ancestors, the railways are not mere transport lines; they are physical ribbons of Manx identity.&rdquo;
          </p>
          <span className="block font-sans text-[9px] tracking-wider text-manx-brass font-bold uppercase mt-2">
            Manx National Heritage Trust, 2026
          </span>
        </div>

      </div>
    </section>
  );
}
