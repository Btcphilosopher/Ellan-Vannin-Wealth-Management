'use client';

import { motion } from 'motion/react';
import { ArrowRight, Compass } from 'lucide-react';

interface HeroProps {
  onPlanClick: () => void;
  onExploreClick: () => void;
}

export function Hero({ onPlanClick, onExploreClick }: HeroProps) {
  return (
    <section className="relative h-[85vh] min-h-[550px] w-full overflow-hidden bg-manx-charcoal" id="hero">
      {/* Background Cinematic Image - Scenic steam train cutting through coastal hills */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1541417904950-b855846fe074?q=80&w=1920&auto=format&fit=crop"
          alt="Historic Steam Train traveling through the lush green cliffs of the Isle of Man with the sea in the distance"
          className="w-full h-full object-cover object-center transform scale-105 select-none pointer-events-none filter brightness-95"
          referrerPolicy="no-referrer"
        />
        {/* Subtle, beautiful dark vignette overlay matching our deep green and charcoal */}
        <div className="absolute inset-0 bg-gradient-to-t from-manx-charcoal via-manx-charcoal/40 to-transparent" />
        <div className="absolute inset-0 bg-manx-green/20 mix-blend-multiply" />
      </div>

      {/* Main Content Area */}
      <div className="relative z-10 max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex flex-col justify-center">
        <div className="max-w-3xl text-left">
          
          {/* Eyebrow Label */}
          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.1 }}
            className="flex items-center space-x-2.5 mb-4"
          >
            <div className="w-6 h-0.5 bg-manx-brass" />
            <span className="font-sans text-xs tracking-[0.3em] text-manx-cream uppercase font-bold">
              THE ISLE BY RAIL
            </span>
            <div className="w-1.5 h-1.5 rounded-full bg-manx-red" />
          </motion.div>

          {/* Large Editorial Serif Heading */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.2 }}
            className="font-serif text-5xl sm:text-6xl md:text-7xl text-manx-cream tracking-tight leading-[1.05] mb-6"
          >
            Discover the <br />
            <span className="italic font-normal text-manx-brass">Isle of Man</span>
          </motion.h1>

          {/* Supporting Campaign Text */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.3 }}
            className="font-sans text-base sm:text-lg md:text-xl text-manx-cream/90 font-light max-w-xl leading-relaxed mb-10"
          >
            Historic railways. Extraordinary landscapes. A journey worth taking.
          </motion.p>

          {/* CTA Action Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-4 sm:items-center"
          >
            <button
              onClick={onPlanClick}
              className="group flex items-center justify-center space-x-3 bg-manx-red hover:bg-manx-red/90 text-manx-cream px-8 py-4 rounded-none font-sans text-xs tracking-widest uppercase font-bold border border-manx-brass/40 shadow-xl transition-all duration-300 hover:scale-[1.02] active:scale-95"
            >
              <span>PLAN YOUR JOURNEY</span>
              <ArrowRight className="w-4 h-4 text-manx-brass transition-transform duration-300 group-hover:translate-x-1" />
            </button>

            <button
              onClick={onExploreClick}
              className="group flex items-center justify-center space-x-2 bg-transparent hover:bg-manx-cream/10 text-manx-cream px-8 py-4 rounded-none font-sans text-xs tracking-widest uppercase font-bold border border-manx-cream/40 transition-all duration-300 hover:border-manx-brass"
            >
              <Compass className="w-4 h-4 text-manx-brass" />
              <span>EXPLORE THE LINES</span>
            </button>
          </motion.div>

        </div>
      </div>

      {/* Retro Poster Bottom Border Detail */}
      <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-gradient-to-r from-manx-red via-manx-brass to-manx-green z-20" />
    </section>
  );
}
