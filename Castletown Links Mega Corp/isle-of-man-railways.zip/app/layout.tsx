import type {Metadata} from 'next';
import {Playfair_Display, Plus_Jakarta_Sans} from 'next/font/google';
import './globals.css'; // Global styles

const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-playfair',
  display: 'swap',
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ['latin'],
  variable: '--font-plus-jakarta',
  display: 'swap',
});

export const metadata: Metadata = {
  title: 'Isle of Man Railways — Steam • Electric • Island',
  description: 'Discover the Isle of Man by Railway. Historic steam, electric, and mountain railways traveling through extraordinary landscapes.',
  openGraph: {
    title: 'Isle of Man Railways — Steam • Electric • Island',
    description: 'Discover the Isle of Man by Railway. Historic steam, electric, and mountain railways traveling through extraordinary landscapes.',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Isle of Man Railways — Steam • Electric • Island',
    description: 'Discover the Isle of Man by Railway. Historic steam, electric, and mountain railways traveling through extraordinary landscapes.',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en" className={`${playfair.variable} ${plusJakarta.variable}`}>
      <body suppressHydrationWarning className="antialiased font-sans bg-manx-cream text-manx-charcoal min-h-screen flex flex-col">
        {children}
      </body>
    </html>
  );
}
