'use client';

import * as React from 'react';
import { motion } from 'motion/react';
import { Header } from '@/components/Header';
import { Hero } from '@/components/Hero';
import { JourneyPlanner } from '@/components/JourneyPlanner';
import { RailwayCard } from '@/components/RailwayCard';
import { Timetable } from '@/components/Timetable';
import { RailwayMap } from '@/components/RailwayMap';
import { StationCard } from '@/components/StationCard';
import { DestinationCard } from '@/components/DestinationCard';
import { TicketCard } from '@/components/TicketCard';
import { HeritageTimeline } from '@/components/HeritageTimeline';
import { ServiceStatus } from '@/components/ServiceStatus';
import { Footer } from '@/components/Footer';

import { 
  RAILWAY_LINES, 
  STATIONS, 
  DESTINATIONS, 
  TICKET_TYPES 
} from '@/data/railwayData';

import { ArrowRight, Compass, Landmark, Play, Heart, Star, Sparkles } from 'lucide-react';

export default function Home() {
  const [activeSection, setActiveSection] = React.useState('hero');

  // Handle smooth scroll navigation trigger
  const handleScrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const element = document.getElementById(sectionId);
    if (element) {
      const headerOffset = 80; // height of our sticky header
      const elementPosition = element.getBoundingClientRect().top;
      const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const handlePlanYourJourney = () => {
    handleScrollToSection('planner');
  };

  const handleExploreLines = () => {
    handleScrollToSection('lines');
  };

  return (
    <div className="flex flex-col min-h-screen bg-manx-cream font-sans selection:bg-manx-red selection:text-manx-cream">
      
      {/* 1. HEADER & NAVIGATION */}
      <Header 
        activeSection={activeSection}
        onSectionClick={handleScrollToSection}
        onPlanClick={handlePlanYourJourney}
      />

      {/* 2. SPECTACULAR HERO PROMO BANNER */}
      <Hero 
        onPlanClick={handlePlanYourJourney}
        onExploreClick={handleExploreLines}
      />

      {/* 3. INTERACTIVE OVERLAPPING JOURNEY PLANNER */}
      <JourneyPlanner />

      {/* 4. THE RAILWAYS SECTION (THREE EDITORIAL CARDS) */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" id="lines">
        <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-16 pb-6 border-b border-manx-brass/25">
          <div className="max-w-2xl mb-6 lg:mb-0">
            <span className="font-sans text-[10px] tracking-[0.25em] text-manx-brass uppercase font-bold block mb-3">
              THE RAILWAYS
            </span>
            <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-manx-green font-semibold leading-tight">
              Three railways. <br />
              <span className="italic font-normal text-manx-red">One extraordinary island.</span>
            </h2>
          </div>
          <p className="font-sans text-xs sm:text-sm text-manx-charcoal/70 max-w-md font-light leading-relaxed">
            The Isle of Man preserves three distinctive Victorian transit systems. Travelling across clifftops, coastal valleys, and towering peaks, they remain working engineering monuments to British ingenuity.
          </p>
        </div>

        {/* 3 Column Grid of Railway Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {RAILWAY_LINES.map((line) => (
            <RailwayCard 
              key={line.id} 
              line={line} 
              onExplore={(lineId) => {
                // Focus corresponding station map marker or scroll to timetable
                handleScrollToSection('timetable');
              }}
            />
          ))}
        </div>
      </section>

      {/* 5. EXPERIENTIAL FULL-BLEED LANDSCAPE SECTION */}
      <section className="relative py-32 bg-manx-charcoal text-manx-cream overflow-hidden">
        {/* Full-bleed rich landscape picture */}
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1493976040374-85c8e12f0c0e?q=80&w=1920&auto=format&fit=crop"
            alt="Scenic view overlooking coastal cliffs and the blue Irish Sea of the Isle of Man"
            className="w-full h-full object-cover select-none filter brightness-[0.35] contrast-[105%]"
            referrerPolicy="no-referrer"
          />
          {/* Subtle horizontal railways tracks divider line */}
          <div className="absolute bottom-12 left-0 right-0 h-1 bg-manx-brass/20" />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 text-center">
          <span className="font-sans text-[10px] tracking-[0.3em] text-manx-brass uppercase font-bold block mb-4">
            TAKE THE SCENIC ROUTE
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-manx-cream tracking-tight leading-[1.1] mb-6 font-light">
            Slow down. Look out of the window.
          </h2>
          <p className="font-sans text-sm sm:text-base md:text-lg text-manx-cream/80 max-w-2xl mx-auto font-light leading-relaxed mb-10">
            Cross valleys, climb hills and follow the coast. On the Isle of Man, the railway is part of the destination.
          </p>

          <button
            onClick={() => handleScrollToSection('stations')}
            className="group inline-flex items-center space-x-2.5 bg-manx-red hover:bg-manx-red/90 text-manx-cream px-8 py-3.5 rounded-none font-sans text-xs tracking-widest uppercase font-bold border border-manx-brass/40 shadow-xl transition-all duration-300 hover:scale-102"
          >
            <span>DISCOVER THE JOURNEY</span>
            <ArrowRight className="w-4 h-4 text-manx-brass group-hover:translate-x-1.5 transition-transform" />
          </button>
        </div>
      </section>

      {/* 6. TIMETABLE DATA COMPONENT */}
      <Timetable />

      {/* 7. CARTOGRAPHIC INTERACTIVE MAP SECTION */}
      <RailwayMap />

      {/* 8. ALONG THE LINE STATION POSTERS SECTION */}
      <section className="py-24 bg-manx-cream border-b border-manx-brass/20" id="stations-list">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-16 pb-6 border-b border-manx-brass/25">
            <div className="max-w-2xl">
              <span className="font-sans text-[10px] tracking-[0.25em] text-manx-brass uppercase font-bold block mb-3">
                COMMUNITIES & HERITAGE HALTS
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-manx-green font-semibold">
                Along the Line
              </h2>
            </div>
            <p className="font-sans text-xs sm:text-sm text-manx-charcoal/70 max-w-md font-light leading-relaxed mt-4 lg:mt-0">
              Each station along our network acts as a historic gateway to sandy bays, castle ruins, pine glens, and local Manx heritage spots.
            </p>
          </div>

          {/* Major stations poster layout grid (Douglas, Castletown, Port Erin, Laxey, Ramsey) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6">
            {STATIONS.filter(s => s.isMajor).map((station) => (
              <StationCard 
                key={station.id}
                station={station}
                onExplore={(stationId) => {
                  handleScrollToSection('timetable');
                }}
              />
            ))}
          </div>

        </div>
      </section>

      {/* 9. ATMOSPHERIC STEAM HIGHLIGHT */}
      <section className="py-24 bg-manx-green text-manx-cream relative overflow-hidden" id="steam-heritage">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            
            {/* Editorial Copy Block */}
            <div className="lg:col-span-5 max-w-md">
              <span className="font-sans text-[10px] tracking-[0.3em] text-manx-brass uppercase font-bold block mb-4">
                HERITAGE ENGINEERING
              </span>
              <h2 className="font-serif text-4xl sm:text-5xl text-manx-cream tracking-wide font-normal leading-tight mb-6">
                Steam belongs <br />
                <span className="italic font-light text-manx-brass">here.</span>
              </h2>
              <p className="font-sans text-xs sm:text-sm text-manx-cream/80 font-light leading-relaxed mb-8">
                The Isle of Man narrow-gauge steam engines have braved southern countrysides for over a century. No modern replacements, no compromises—this is living history, moving exactly as it did in 1874.
              </p>
              
              <div className="flex flex-wrap gap-4">
                <button
                  onClick={() => handleScrollToSection('lines')}
                  className="bg-manx-red hover:bg-manx-red/90 text-manx-cream px-6 py-3 font-sans text-xs tracking-widest uppercase font-bold border border-manx-brass/30 transition-all duration-300"
                >
                  STEAM RAILWAY →
                </button>
                <button
                  onClick={() => handleScrollToSection('heritage')}
                  className="bg-transparent hover:bg-white/10 text-manx-cream px-6 py-3 border border-manx-cream/30 font-sans text-xs tracking-widest uppercase font-bold transition-all"
                >
                  LOCOMOTIVES →
                </button>
              </div>
            </div>

            {/* Cinematic Steam Engine Picture Grid */}
            <div className="lg:col-span-7">
              <div className="relative aspect-[16/10] w-full overflow-hidden border border-manx-brass/40 shadow-2xl">
                <img
                  src="https://images.unsplash.com/photo-1519074069444-1ba4e6664104?q=80&w=1200&auto=format&fit=crop"
                  alt="Historic steam locomotive under warm natural sunlight, detailing steam venting and polished brass rivets"
                  className="w-full h-full object-cover filter contrast-[105%]"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-manx-green/60 to-transparent" />
                
                {/* Stamp overlay */}
                <div className="absolute bottom-4 right-4 bg-manx-cream text-manx-green border border-manx-brass px-3 py-1 text-[9px] font-sans font-bold tracking-widest uppercase">
                  Beyer Peacock Co. • Manchester
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 10. DRAMATIC HIGH-ALTITUDE SNAEFELL MOUNTAIN SECTION */}
      <section className="relative py-32 bg-manx-charcoal text-manx-cream overflow-hidden" id="snaefell-heritage">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?q=80&w=1920&auto=format&fit=crop"
            alt="Dramatic mountaintop landscape of Snaefell summit shrouded in mist and heather under morning skies"
            className="w-full h-full object-cover filter brightness-[0.35] select-none"
            referrerPolicy="no-referrer"
          />
        </div>

        <div className="relative z-10 max-w-3xl mx-auto px-4 text-center">
          <span className="font-sans text-[10px] tracking-[0.3em] text-manx-brass uppercase font-bold block mb-4">
            MOUNTAIN ASCENT
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl md:text-5xl lg:text-6xl text-manx-cream tracking-tight leading-none mb-6">
            Above the island
          </h2>
          <p className="font-sans text-xs sm:text-sm md:text-base text-manx-cream/80 font-light leading-relaxed max-w-xl mx-auto mb-10">
            Climb from Laxey towards the summit of Snaefell and see the Isle of Man from a different perspective. On clear days, look across the sea to witness England, Wales, Scotland, and Ireland merge at the horizon.
          </p>

          <button
            onClick={() => handleScrollToSection('timetable')}
            className="group bg-transparent hover:bg-manx-cream hover:text-manx-green text-manx-cream px-8 py-3.5 border border-manx-cream rounded-none font-sans text-xs tracking-widest uppercase font-bold transition-all duration-300"
          >
            <span>RIDE THE MOUNTAIN RAILWAY</span>
            <ArrowRight className="w-3.5 h-3.5 inline text-manx-brass group-hover:translate-x-1.5 transition-transform ml-2" />
          </button>
        </div>
      </section>

      {/* 11. MAKE A DAY OF IT - ISLAND DESTINATIONS */}
      <section className="py-24 bg-[#FAF7F2]" id="visit">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-16 pb-6 border-b border-manx-brass/25">
            <div className="max-w-2xl">
              <span className="font-sans text-[10px] tracking-[0.25em] text-manx-brass uppercase font-bold block mb-3">
                ISLAND EXPLORATION
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-manx-green font-semibold">
                Make a Day of It.
              </h2>
            </div>
            <p className="font-sans text-xs sm:text-sm text-manx-charcoal/70 max-w-md font-light leading-relaxed mt-4 lg:mt-0">
              Stop over at coastal harbors, walk among medieval strongholds, or hike the green northern forests. Our railway lines connect the island&apos;s best historic destinations.
            </p>
          </div>

          {/* 3 Column Grid of Destinations */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {DESTINATIONS.map((dest) => (
              <DestinationCard key={dest.id} destination={dest} />
            ))}
          </div>

        </div>
      </section>

      {/* 12. VINTAGE TICKETS & FARES SECTION */}
      <section className="py-24 bg-manx-cream border-t border-manx-brass/20" id="tickets">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="flex flex-col lg:flex-row lg:items-end justify-between mb-16 pb-6 border-b border-manx-brass/25">
            <div className="max-w-2xl">
              <span className="font-sans text-[10px] tracking-[0.25em] text-manx-brass uppercase font-bold block mb-3">
                TICKETING & PRIVILEGES
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl text-manx-green font-semibold">
                Tickets & Fares
              </h2>
            </div>
            <p className="font-sans text-xs sm:text-sm text-manx-charcoal/70 max-w-md font-light leading-relaxed mt-4 lg:mt-0">
              Simple single trips, or all-access rovers providing unlimited freedom on our networks. Tariffs are structured as templates awaiting API linkups.
            </p>
          </div>

          {/* Three Column Grid representing visual cardboard tickets */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            {TICKET_TYPES.map((ticket) => (
              <TicketCard key={ticket.id} ticket={ticket} />
            ))}
          </div>

          {/* Vintage Ticket Office Quote */}
          <div className="mt-16 text-center text-xs font-sans text-manx-charcoal/50 uppercase tracking-widest max-w-md mx-auto">
            <span>ALL CARDBOARD TICKETS PUNCHED AT DEPARTURE PLATFORMS. <br /> BUY ONLINE OR VISIT LOCAL TERMINAL BOOKING OFFICES.</span>
          </div>

        </div>
      </section>

      {/* 13. CHRONOLOGY TIMELINE */}
      <HeritageTimeline />

      {/* 14. ANNOUNCEMENTS, SERVICE ALERTS & NEWS LIST */}
      <ServiceStatus />

      {/* 15. BEAUTIFUL DEEP GREEN FOOTER */}
      <Footer onSectionClick={handleScrollToSection} />

    </div>
  );
}
