'use client';

import React from 'react';
import { AuditRecord, UserRole } from '@/lib/nestora/types';
import { AuditEngine } from '@/lib/nestora/audit';
import { ShieldCheck, Lock, FileText, UserCheck, Terminal, CheckCircle2 } from 'lucide-react';

interface Props {
  currentRole: UserRole;
  auditLogs: AuditRecord[];
}

export const AuditConsoleView: React.FC<Props> = ({ currentRole, auditLogs }) => {
  const allLogs = AuditEngine.getLogs().concat(auditLogs);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-600" />
            Append-Only Audit Ledger & Enterprise Security Console
          </h2>
          <p className="text-xs text-slate-500">
            Immutable log stream tracking who, what, when, where, why, and state diffs for every material action
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono font-bold px-3 py-1 bg-slate-900 text-emerald-400 rounded-lg flex items-center gap-1.5">
            <Lock className="w-3.5 h-3.5 text-emerald-400" />
            APPEND-ONLY IMMUTABLE
          </span>
        </div>
      </div>

      {/* RBAC Role Matrix Info */}
      <div className="bg-slate-900 p-4 rounded-xl text-white text-xs flex items-center justify-between">
        <div className="flex items-center gap-2">
          <UserCheck className="w-4 h-4 text-sky-400" />
          <span>Active Session Role: <strong className="text-sky-300 font-bold">{currentRole}</strong></span>
        </div>
        <div className="text-slate-400">
          Enforcing Least Privilege RBAC & ABAC Security Protocols
        </div>
      </div>

      {/* Audit Log Stream Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50/50 flex items-center justify-between">
          <h3 className="font-bold text-slate-900 text-xs uppercase tracking-wider flex items-center gap-2">
            <Terminal className="w-4 h-4 text-slate-700" />
            Audit Ledger Events Stream ({allLogs.length} Records)
          </h3>
          <span className="text-[10px] font-mono text-slate-500">
            SHA-256 Ledger Hash Verified
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-100 uppercase text-[10px] text-slate-500 font-bold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Audit ID</th>
                <th className="px-4 py-3">Timestamp (UTC)</th>
                <th className="px-4 py-3">Actor & Role</th>
                <th className="px-4 py-3">Action (What)</th>
                <th className="px-4 py-3">Module (Where)</th>
                <th className="px-4 py-3">Reason / Context (Why)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium font-mono text-[11px]">
              {allLogs.map((log) => (
                <tr key={log.audit_id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 font-bold text-slate-900">{log.audit_id}</td>
                  <td className="px-4 py-3 text-slate-500">{log.when}</td>
                  <td className="px-4 py-3">
                    <span className="font-bold text-slate-800">{log.who}</span>
                    <span className="text-[10px] block text-sky-600 font-sans font-semibold">{log.role}</span>
                  </td>
                  <td className="px-4 py-3 font-bold text-emerald-700">{log.what}</td>
                  <td className="px-4 py-3 text-slate-600">{log.where_module}</td>
                  <td className="px-4 py-3 text-slate-700 font-sans">{log.why_reason}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
