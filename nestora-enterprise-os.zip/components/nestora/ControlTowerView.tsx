'use client';

import React from 'react';
import { NestoraEnterpriseState } from '@/lib/nestora/store';
import { Truck, MapPin, AlertCircle, ShieldCheck, Clock, Navigation, Thermometer, Globe, ArrowRight } from 'lucide-react';

interface Props {
  state: NestoraEnterpriseState;
}

export const ControlTowerView: React.FC<Props> = ({ state }) => {
  const nodeLocations = [
    { name: 'Vevey Production Hub', city: 'Switzerland', type: 'FACTORY', status: 'GREEN', lat: 46.46, lng: 6.84 },
    { name: 'Avenches Nespresso Hub', city: 'Switzerland', type: 'FACTORY', status: 'GREEN', lat: 46.88, lng: 7.03 },
    { name: 'Toluca Campus', city: 'Mexico', type: 'FACTORY', status: 'AMBER', lat: 19.28, lng: -99.65 },
    { name: 'Kobe Plant', city: 'Japan', type: 'FACTORY', status: 'GREEN', lat: 34.69, lng: 135.19 },
    { name: 'Frankfurt Central DC', city: 'Germany', type: 'WAREHOUSE', status: 'GREEN', lat: 50.11, lng: 8.68 },
    { name: 'Alta Mogiana Coop', city: 'Brazil', type: 'SUPPLIER', status: 'GREEN', lat: -20.53, lng: -47.40 },
  ];

  return (
    <div className="space-y-6">
      {/* Control Tower Header KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-slate-500 text-xs font-semibold mb-1 flex items-center justify-between">
            <span>ACTIVE SHIPMENTS</span>
            <Truck className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{state.controlTower.total_active_shipments}</div>
          <div className="text-xs text-slate-500 mt-1">In Transit Globally</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-slate-500 text-xs font-semibold mb-1 flex items-center justify-between">
            <span>DELAYED SHIPMENTS</span>
            <AlertCircle className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-bold text-amber-600">{state.controlTower.delayed_shipments}</div>
          <div className="text-xs text-slate-500 mt-1">1.0% Delay Rate</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-slate-500 text-xs font-semibold mb-1 flex items-center justify-between">
            <span>ACTIVE DISRUPTIONS</span>
            <AlertCircle className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{state.controlTower.disruption_events_active}</div>
          <div className="text-xs text-slate-500 mt-1">Port & Weather Risk</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-slate-500 text-xs font-semibold mb-1 flex items-center justify-between">
            <span>INVENTORY DAYS</span>
            <Clock className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{state.controlTower.global_inventory_days} Days</div>
          <div className="text-xs text-emerald-600 mt-1 font-semibold">Optimized Buffer</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-slate-500 text-xs font-semibold mb-1 flex items-center justify-between">
            <span>OTIF SERVICE LEVEL</span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{state.controlTower.service_level_pct}%</div>
          <div className="text-xs text-emerald-600 mt-1 font-semibold">+0.6% vs Target</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-slate-500 text-xs font-semibold mb-1 flex items-center justify-between">
            <span>COLD CHAIN ALERTS</span>
            <Thermometer className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{state.controlTower.cold_chain_alerts}</div>
          <div className="text-xs text-slate-500 mt-1">Temp Within Limits</div>
        </div>
      </div>

      {/* Global Node Topology Canvas */}
      <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 shadow-xl text-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-bold text-base text-white flex items-center gap-2">
              <Globe className="w-5 h-5 text-sky-400" />
              Global Supply Network Topology & Logistics Map
            </h3>
            <p className="text-xs text-slate-400">
              Real-time node telemetry across Suppliers, Production Plants, Logistics Hubs, and Retailers
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-semibold">
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-emerald-400">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              98 Active Factories
            </span>
            <span className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-amber-400">
              <span className="w-2 h-2 rounded-full bg-amber-400"></span>
              4 Alert Status
            </span>
          </div>
        </div>

        {/* Synthetic Map Node Topology Visual */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
          {nodeLocations.map((node, i) => (
            <div
              key={i}
              className="p-4 rounded-xl bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all"
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-2 py-0.5 rounded bg-slate-800">
                  {node.type}
                </span>
                <span
                  className={`text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 ${
                    node.status === 'GREEN'
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                      : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                  }`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${node.status === 'GREEN' ? 'bg-emerald-400' : 'bg-amber-400'}`}></span>
                  {node.status}
                </span>
              </div>

              <div className="font-bold text-sm text-white">{node.name}</div>
              <div className="text-xs text-slate-400 mt-0.5 flex items-center gap-1">
                <MapPin className="w-3 h-3 text-slate-500" />
                {node.city} ({node.lat.toFixed(2)}, {node.lng.toFixed(2)})
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Active Shipments Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50/50 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-sm">Active In-Transit Shipments</h3>
            <p className="text-xs text-slate-500">Live vessel and truck container telemetry</p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 bg-sky-100 text-sky-800 rounded-full">
            {state.shipments.length} Active Express Routes
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-100/80 uppercase text-[10px] text-slate-500 font-bold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Tracking #</th>
                <th className="px-4 py-3">Origin Plant</th>
                <th className="px-4 py-3">Destination Hub</th>
                <th className="px-4 py-3">Departure / ETA</th>
                <th className="px-4 py-3">Temp Recorded</th>
                <th className="px-4 py-3">Status</th>
                <th className="px-4 py-3 text-right">Scope 3 CO2</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {state.shipments.map((s) => (
                <tr key={s.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="px-4 py-3 font-bold text-slate-900 flex items-center gap-2">
                    <Truck className="w-3.5 h-3.5 text-sky-600" />
                    {s.tracking_number}
                  </td>
                  <td className="px-4 py-3 text-slate-700">Vevey / Avenches</td>
                  <td className="px-4 py-3 text-slate-700">{s.destination_dc_id}</td>
                  <td className="px-4 py-3 text-slate-600">{s.departure_time} → {s.eta}</td>
                  <td className="px-4 py-3 font-semibold text-slate-800">
                    {s.temperature_c ? `${s.temperature_c}°C` : 'N/A (Dry)'}
                  </td>
                  <td className="px-4 py-3">
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800">
                      {s.status}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-right font-bold text-slate-900">{s.co2_kg} kg</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
