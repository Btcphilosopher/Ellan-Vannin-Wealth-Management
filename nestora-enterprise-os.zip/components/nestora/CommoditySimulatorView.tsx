'use client';

import React, { useState } from 'react';
import { CommodityEngine, ShockSimulationResult } from '@/lib/nestora/commodity';
import { ShoppingCart, TrendingUp, AlertTriangle, ArrowRight, ShieldCheck, DollarSign } from 'lucide-react';

export const CommoditySimulatorView: React.FC = () => {
  const [commodity, setCommodity] = useState<'COCOA' | 'COFFEE' | 'MILK' | 'GRAINS' | 'SUGAR'>('COCOA');
  const [priceChangePct, setPriceChangePct] = useState<number>(35);
  const [result, setResult] = useState<ShockSimulationResult>(
    CommodityEngine.simulateShock({ commodity: 'COCOA', priceChangePct: 35 })
  );

  const handleRunSimulation = () => {
    const sim = CommodityEngine.simulateShock({ commodity, priceChangePct });
    setResult(sim);
  };

  return (
    <div className="space-y-6">
      {/* Simulation Control Panel */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-amber-600" />
            Raw Material Market & Commodity Shock Simulator
          </h2>
          <p className="text-xs text-slate-500">
            Simulate spot price fluctuations and calculate cascade impact on recipe cost, SKU margins, factory COGS, and Group EBITDA
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-50 p-4 rounded-xl border border-slate-200">
          <div>
            <label className="text-xs font-bold text-slate-700 block mb-1">Select Commodity:</label>
            <select
              value={commodity}
              onChange={(e) => setCommodity(e.target.value as any)}
              className="w-full bg-white border border-slate-300 rounded-lg p-2 text-xs font-bold text-slate-900 focus:outline-none"
            >
              <option value="COCOA">Cocoa Beans & Butter</option>
              <option value="COFFEE">Green Coffee Beans (Arabica/Robusta)</option>
              <option value="MILK">Fresh & Powdered Milk</option>
              <option value="SUGAR">Refined Sugar</option>
              <option value="GRAINS">Wheat & Oats</option>
            </select>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs font-bold text-slate-700 mb-1">
              <span>Spot Price Shock (%):</span>
              <span className="text-amber-600 font-extrabold">{priceChangePct > 0 ? `+${priceChangePct}%` : `${priceChangePct}%`}</span>
            </div>
            <input
              type="range"
              min="-30"
              max="60"
              step="5"
              value={priceChangePct}
              onChange={(e) => setPriceChangePct(parseInt(e.target.value, 10))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-amber-600"
            />
          </div>

          <div className="flex items-end">
            <button
              onClick={handleRunSimulation}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition-all shadow-md flex items-center justify-center gap-2"
            >
              <TrendingUp className="w-4 h-4 text-amber-400" />
              Calculate Cascade Impact
            </button>
          </div>
        </div>
      </div>

      {/* Simulation Results Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 mb-1">SPOT PRICE DELTA</div>
          <div className="text-xl font-bold text-slate-900">
            {result.previousSpotPriceCHFPerTon} → {result.newSpotPriceCHFPerTon}
          </div>
          <div className="text-xs text-amber-600 font-semibold mt-1">
            {result.priceChangePct > 0 ? `+${result.priceChangePct}% Price Surge` : `${result.priceChangePct}% Decline`}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 mb-1">HEDGED FORWARD COVERAGE</div>
          <div className="text-xl font-bold text-emerald-700">{result.hedgedCoveragePct}% Hedged</div>
          <div className="text-xs text-slate-500 mt-1">40% Exposed to Spot Market</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 mb-1">ANNUAL UNHEDGED EXPOSURE</div>
          <div className="text-xl font-bold text-red-600">{result.unhedgedExposureCHF}</div>
          <div className="text-xs text-red-600 font-semibold mt-1">EBITDA Impact</div>
        </div>
      </div>

      {/* Cascade SKU Margin Impact Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden space-y-4 p-5">
        <h3 className="font-bold text-slate-900 text-base">Affected Category SKUs Margin Waterfall</h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-100 uppercase text-[10px] text-slate-500 font-bold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">SKU Name</th>
                <th className="px-4 py-3">Original Gross Margin</th>
                <th className="px-4 py-3">Shocked Gross Margin</th>
                <th className="px-4 py-3 text-right">Margin Delta (CHF)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {result.cascadeImpact.affectedSKUs.map((sku, i) => (
                <tr key={i} className="hover:bg-slate-50 transition-colors">
                  <td className="px-4 py-3 font-bold text-slate-900">{sku.skuName}</td>
                  <td className="px-4 py-3 text-slate-700">{sku.oldMarginPct}%</td>
                  <td className="px-4 py-3 font-bold text-amber-600">{sku.newMarginPct}%</td>
                  <td className="px-4 py-3 text-right font-bold text-red-600">{sku.grossMarginDeltaCHF} CHF</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Recommended Mitigation Actions */}
        <div className="pt-3 border-t border-slate-100 space-y-2">
          <span className="font-bold text-xs text-slate-900 block">AI Recommended Mitigation Actions:</span>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
            {result.recommendedActions.map((act, i) => (
              <div key={i} className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-slate-700 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600 flex-shrink-0" />
                <span>{act}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
