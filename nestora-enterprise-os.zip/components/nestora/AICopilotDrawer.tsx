'use client';

import React, { useState } from 'react';
import { Bot, Send, X, Terminal, Cpu, Sparkles, CheckCircle2 } from 'lucide-react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  id: string;
  sender: 'USER' | 'COPILOT';
  text: string;
  sourceDataVersion?: string;
  sqlQueryExecuted?: string;
  queryExecutionMs?: number;
}

export const AICopilotDrawer: React.FC<Props> = ({ isOpen, onClose }) => {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm-init',
      sender: 'COPILOT',
      text: 'Hello. I am Nestora AI Executive Copilot powered by Gemini 3.6. I operate over structured enterprise data across 102 factories, 1,240 SKUs, and 1,850 suppliers. Ask me anything about Nestora financials, supply chain disruptions, OEE downtime, or commodity exposure.',
      sourceDataVersion: 'v2026.09.12-LIVE-ENTERPRISE-DB',
    },
  ]);

  if (!isOpen) return null;

  const handleSend = async (userText: string) => {
    if (!userText.trim()) return;

    const userMsg: Message = {
      id: `u-${Date.now()}`,
      sender: 'USER',
      text: userText,
    };

    setMessages((prev) => [...prev, userMsg]);
    setQuery('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/copilot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: userText }),
      });

      const data = await res.json();

      const copilotMsg: Message = {
        id: `c-${Date.now()}`,
        sender: 'COPILOT',
        text: data.answer || 'Response processed.',
        sourceDataVersion: data.sourceDataVersion || 'v2026.09.12-ENTERPRISE-GRAPH',
        sqlQueryExecuted: data.sqlQueryExecuted,
        queryExecutionMs: data.queryExecutionMs,
      };

      setMessages((prev) => [...prev, copilotMsg]);
    } catch (err) {
      console.error('Copilot API error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-y-0 right-0 w-full sm:w-[480px] bg-slate-950 text-white z-50 shadow-2xl border-l border-slate-800 flex flex-col justify-between">
      {/* Drawer Header */}
      <div className="p-4 border-b border-slate-800 bg-slate-900 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-sky-600 text-white shadow-lg shadow-sky-600/30">
            <Cpu className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-bold text-sm text-white flex items-center gap-1.5">
              Nestora AI Executive Copilot
              <span className="text-[10px] bg-sky-500/20 text-sky-400 px-2 py-0.5 rounded border border-sky-500/30 font-mono">
                Gemini 3.6
              </span>
            </h3>
            <p className="text-[11px] text-slate-400">Operating over live canonical enterprise dataset</p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Quick Prompts */}
      <div className="p-3 bg-slate-900/60 border-b border-slate-800 text-xs overflow-x-auto flex gap-2">
        <button
          onClick={() => handleSend('Why did European coffee margin fall?')}
          className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 whitespace-nowrap text-[11px] border border-slate-700"
        >
          ☕ Why European coffee margin fall?
        </button>
        <button
          onClick={() => handleSend('Which factories have the highest downtime?')}
          className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 whitespace-nowrap text-[11px] border border-slate-700"
        >
          🏭 Highest factory downtime?
        </button>
        <button
          onClick={() => handleSend('What happens if cocoa prices rise 25%?')}
          className="px-2.5 py-1 rounded-full bg-slate-800 hover:bg-slate-700 text-slate-300 whitespace-nowrap text-[11px] border border-slate-700"
        >
          🍫 Cocoa price rise 25%?
        </button>
      </div>

      {/* Messages Stream */}
      <div className="flex-1 p-4 space-y-4 overflow-y-auto text-xs">
        {messages.map((m) => (
          <div
            key={m.id}
            className={`p-3.5 rounded-xl ${
              m.sender === 'USER'
                ? 'bg-sky-600/20 border border-sky-500/30 ml-8 text-sky-100'
                : 'bg-slate-900 border border-slate-800 mr-4 text-slate-200'
            }`}
          >
            <div className="font-bold text-[10px] uppercase text-slate-400 mb-1 flex items-center gap-1">
              {m.sender === 'COPILOT' ? (
                <>
                  <Sparkles className="w-3 h-3 text-sky-400" />
                  NESTORA AI ENGINE
                </>
              ) : (
                'EXECUTIVE USER'
              )}
            </div>

            <div className="whitespace-pre-line leading-relaxed">{m.text}</div>

            {m.sqlQueryExecuted && (
              <div className="mt-2.5 p-2 bg-slate-950 rounded border border-slate-800 font-mono text-[10px] text-amber-300">
                <div className="text-slate-500 font-sans text-[9px] uppercase">Executed SQL Query:</div>
                {m.sqlQueryExecuted}
              </div>
            )}

            {m.sourceDataVersion && (
              <div className="mt-2 pt-1 border-t border-slate-800/60 text-[9px] text-slate-500 flex justify-between">
                <span>Source: {m.sourceDataVersion}</span>
                {m.queryExecutionMs && <span>{m.queryExecutionMs}ms</span>}
              </div>
            )}
          </div>
        ))}

        {isLoading && (
          <div className="p-3.5 bg-slate-900 rounded-xl border border-slate-800 mr-4 text-slate-400 flex items-center gap-2 animate-pulse">
            <Bot className="w-4 h-4 text-sky-400 animate-spin" />
            Querying Nestora enterprise database graph...
          </div>
        )}
      </div>

      {/* Query Input */}
      <div className="p-3 border-t border-slate-800 bg-slate-900">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend(query);
          }}
          className="flex gap-2"
        >
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask Nestora AI Copilot..."
            className="flex-1 bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-sky-500"
          />
          <button
            type="submit"
            className="p-2 bg-sky-600 hover:bg-sky-500 text-white rounded-xl transition-colors"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
};
