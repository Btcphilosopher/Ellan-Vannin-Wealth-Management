'use client';

import React, { useState } from 'react';
import { TraceabilityEngine, TraceabilityNode, RecallAnalysisResult } from '@/lib/nestora/traceability';
import { AuditEngine } from '@/lib/nestora/audit';
import { UserRole } from '@/lib/nestora/types';
import { Search, GitCommit, AlertOctagon, ShieldCheck, Factory, Truck, ShoppingBag, ArrowDown, CheckCircle2 } from 'lucide-react';

interface Props {
  currentRole: UserRole;
  onAuditLogged: () => void;
}

export const TraceabilityView: React.FC<Props> = ({ currentRole, onAuditLogged }) => {
  const [lotNumber, setLotNumber] = useState<string>('LOT-COFFEE-2026-88');
  const [traceTree, setTraceTree] = useState<TraceabilityNode>(
    TraceabilityEngine.buildTraceabilityTree('LOT-COFFEE-2026-88')
  );
  const [recallResult, setRecallResult] = useState<RecallAnalysisResult | null>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const tree = TraceabilityEngine.buildTraceabilityTree(lotNumber);
    setTraceTree(tree);
    setRecallResult(null);
  };

  const handleExecuteRecall = () => {
    const analysis = TraceabilityEngine.runRecallAnalysis(lotNumber);
    setRecallResult(analysis);

    AuditEngine.logEvent({
      who: `${currentRole} Quality Lead`,
      role: currentRole,
      what: 'TARGETED_QUALITY_RECALL_EXECUTED',
      where_module: 'FOOD_SAFETY_TRACEABILITY_ENGINE',
      why_reason: `Triggered targeted recall isolation for contaminated lot #${lotNumber}`,
      before_state: 'Batches and Shipments Status: IN_TRANSIT/PASSED',
      after_state: `Quarantined 2 Factories, 2 Batches, 2 Shipments across ${analysis.affectedMarkets.join(', ')}. Est Cost: CHF ${analysis.estimatedRecallCostCHF}`,
    });

    onAuditLogged();
  };

  // Helper to recursively render node
  const renderNode = (node: TraceabilityNode, depth: number = 0) => {
    const isRecalled = node.status === 'RECALLED' || node.status === 'ON_HOLD';

    return (
      <div key={node.id} className="space-y-2">
        <div
          className={`p-3.5 rounded-xl border transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-3 ${
            isRecalled
              ? 'bg-red-50 border-red-300 shadow-sm'
              : 'bg-white border-slate-200 shadow-sm hover:border-slate-300'
          }`}
          style={{ marginLeft: `${depth * 24}px` }}
        >
          <div className="flex items-center gap-3">
            <span
              className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                isRecalled ? 'bg-red-600 text-white' : 'bg-slate-900 text-white'
              }`}
            >
              {node.type}
            </span>
            <div>
              <div className="font-bold text-xs text-slate-900">{node.name}</div>
              <div className="text-[11px] text-slate-500">
                Code: {node.code} | Location: {node.location}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 text-xs">
            {node.metadata.lot_number && (
              <span className="bg-slate-100 text-slate-700 px-2 py-0.5 rounded font-mono text-[10px]">
                Lot: {node.metadata.lot_number}
              </span>
            )}
            <span
              className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                node.status === 'RECALLED'
                  ? 'bg-red-200 text-red-900 animate-pulse'
                  : node.status === 'ON_HOLD'
                  ? 'bg-amber-100 text-amber-900'
                  : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {node.status}
            </span>
          </div>
        </div>

        {node.children && node.children.length > 0 && (
          <div className="space-y-2">
            {node.children.map((child) => renderNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header & Search Bar */}
      <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <GitCommit className="w-5 h-5 text-emerald-600" />
              End-to-End Food Safety & Graph Traceability Engine
            </h2>
            <p className="text-xs text-slate-500">
              Traverse complete supply topology: Supplier Lot → Raw Material → Factory Batch → Active Shipment → Customer Market
            </p>
          </div>

          <button
            onClick={handleExecuteRecall}
            className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-xl text-xs font-bold transition-all shadow-md flex items-center gap-1.5 shadow-red-600/20"
          >
            <AlertOctagon className="w-4 h-4" />
            Trigger Targeted Recall Analysis
          </button>
        </div>

        <form onSubmit={handleSearch} className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={lotNumber}
              onChange={(e) => setLotNumber(e.target.value)}
              placeholder="Enter Raw Ingredient Lot Number (e.g. LOT-COFFEE-2026-88)"
              className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
            />
          </div>
          <button
            type="submit"
            className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold transition-all"
          >
            Traverse Graph
          </button>
        </form>
      </div>

      {/* Recall Execution Result Alert */}
      {recallResult && (
        <div className="bg-red-950 border border-red-800 p-5 rounded-2xl text-white space-y-3 shadow-xl">
          <div className="flex items-center justify-between border-b border-red-800 pb-2">
            <div className="flex items-center gap-2 font-bold text-sm text-red-300">
              <AlertOctagon className="w-5 h-5 text-red-400 animate-pulse" />
              TARGETED FOOD SAFETY RECALL EXECUTED & AUDITED
            </div>
            <span className="text-xs font-mono text-red-200">
              Est Cost: CHF {recallResult.estimatedRecallCostCHF}
            </span>
          </div>

          <p className="text-xs text-red-200 leading-relaxed">{recallResult.actionSummary}</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs pt-1">
            <div className="bg-red-900/50 p-2.5 rounded-lg border border-red-800">
              <span className="font-bold text-red-300 block text-[10px] uppercase">Quarantined Factories</span>
              <ul className="list-disc list-inside mt-1 space-y-0.5 text-red-100">
                {recallResult.affectedFactories.map((f) => (
                  <li key={f.id}>{f.name} ({f.country})</li>
                ))}
              </ul>
            </div>

            <div className="bg-red-900/50 p-2.5 rounded-lg border border-red-800">
              <span className="font-bold text-red-300 block text-[10px] uppercase">Affected Batches</span>
              <ul className="list-disc list-inside mt-1 space-y-0.5 text-red-100">
                {recallResult.affectedBatches.map((b) => (
                  <li key={b.batchNumber}>{b.batchNumber} - {b.skuName}</li>
                ))}
              </ul>
            </div>

            <div className="bg-red-900/50 p-2.5 rounded-lg border border-red-800">
              <span className="font-bold text-red-300 block text-[10px] uppercase">Blocked Markets</span>
              <div className="mt-1 font-semibold text-red-100">
                {recallResult.affectedMarkets.join(', ')}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Traversed Graph Tree Display */}
      <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 space-y-4">
        <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
          <GitCommit className="w-4 h-4 text-emerald-600" />
          Traceability Lineage Traversal Tree for Lot #{lotNumber}
        </h3>

        <div className="space-y-2">
          {renderNode(traceTree)}
        </div>
      </div>
    </div>
  );
};
