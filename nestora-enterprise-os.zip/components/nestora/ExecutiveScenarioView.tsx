'use client';

import React, { useState } from 'react';
import { ExecutiveScenarioEngine, Scenario68Output } from '@/lib/nestora/scenarios';
import { AuditEngine } from '@/lib/nestora/audit';
import { UserRole, AIRecommendation } from '@/lib/nestora/types';
import { Zap, AlertOctagon, ArrowUpRight, CheckCircle2, ShieldCheck, Factory, Truck, ShoppingCart, DollarSign, Bot } from 'lucide-react';

interface Props {
  currentRole: UserRole;
  onAuditLogged: () => void;
}

export const ExecutiveScenarioView: React.FC<Props> = ({ currentRole, onAuditLogged }) => {
  const [scenarioData, setScenarioData] = useState<Scenario68Output>(
    ExecutiveScenarioEngine.runCoffeeSpikeScenario()
  );
  const [selectedStrategy, setSelectedStrategy] = useState<AIRecommendation | null>(null);
  const [executionMessage, setExecutionMessage] = useState<string | null>(null);

  const handleApproveStrategy = (strat: AIRecommendation) => {
    // Record Approval & Execution in Audit Engine
    AuditEngine.logEvent({
      who: `${currentRole} Executive Approver`,
      role: currentRole,
      what: 'EXECUTIVE_STRATEGY_EXECUTED',
      where_module: 'EXECUTIVE_SCENARIO_ENGINE_68',
      why_reason: `Approved & Executed ${strat.title}`,
      before_state: `Strategy status: ${strat.approval_status}`,
      after_state: `Strategy status: EXECUTED | Impact: ${strat.expected_impact_chf}`,
      approval_ref: strat.recommendation_id,
    });

    // Update local state
    const updatedStrats = scenarioData.executiveAIProposedStrategies.map((s) => {
      if (s.recommendation_id === strat.recommendation_id) {
        return { ...s, approval_status: 'EXECUTED' as const };
      }
      return s;
    });

    setScenarioData({
      ...scenarioData,
      executiveAIProposedStrategies: updatedStrats,
    });

    setSelectedStrategy({ ...strat, approval_status: 'EXECUTED' });
    setExecutionMessage(`Successfully executed ${strat.title}! Decision, approver, timestamp, and financial impact recorded to append-only audit ledger.`);
    onAuditLogged();
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-900 via-slate-900 to-slate-950 text-white p-6 rounded-2xl border border-amber-500/30 shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 opacity-10 flex items-center pr-10 pointer-events-none">
          <Zap className="w-64 h-64 text-amber-400" />
        </div>

        <div className="relative z-10 max-w-4xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 text-xs font-bold border border-amber-500/40 mb-3">
            <Zap className="w-3.5 h-3.5 animate-pulse text-amber-400" />
            LIVE DEMO SCENARIO 68: GLOBAL COFFEE DEMAND SPIKE (+12.4%)
          </div>

          <h2 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            Automated Supply Chain Cascade & Executive AI Decision Engine
          </h2>
          <p className="text-slate-300 text-sm mt-2 leading-relaxed">
            A sudden +12.4% European coffee demand surge threatens inventory stockout within 11 days. The Nestora Enterprise Engine calculates factory line capacity, procurement ingredient requirements, and working capital needs, presenting 3 Executive AI Response Strategies for immediate board decisioning.
          </p>
        </div>
      </div>

      {/* Real-time Cascade Impact Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-red-200 shadow-sm">
          <div className="flex items-center justify-between text-red-600 mb-1 text-xs font-bold">
            <span>INVENTORY DEPLETION RISK</span>
            <AlertOctagon className="w-4 h-4 text-red-600" />
          </div>
          <div className="text-2xl font-bold text-red-900">
            {scenarioData.impactAssessment.daysOfInventoryRemaining} Days Left
          </div>
          <div className="text-xs text-red-700 mt-1 font-medium">
            Projected Stockout: {scenarioData.impactAssessment.projectedStockoutDate}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-1 text-xs font-semibold">
            <span>UNMET REVENUE AT RISK</span>
            <DollarSign className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {scenarioData.impactAssessment.unmetRevenueRiskCHF}
          </div>
          <div className="text-xs text-slate-500 mt-1">
            +1.42M Weekly Unit Demand Surge
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-1 text-xs font-semibold">
            <span>FACTORY UTILIZATION SHIFT</span>
            <Factory className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {scenarioData.impactAssessment.factoryUtilizationBeforePct}% → {scenarioData.impactAssessment.factoryUtilizationAfterPct}%
          </div>
          <div className="text-xs text-indigo-600 font-semibold mt-1">
            Vevey Line 2 & 3 At Max Output
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between text-slate-500 mb-1 text-xs font-semibold">
            <span>SPOT INGREDIENT REQUIREMENT</span>
            <ShoppingCart className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl font-bold text-slate-900">
            {scenarioData.impactAssessment.requiredRawCoffeeBeansTons} Tons
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Spot Buy: {scenarioData.impactAssessment.procurementSpotBuyCostCHF}
          </div>
        </div>
      </div>

      {/* Execution Confirmation Message */}
      {executionMessage && (
        <div className="bg-emerald-50 border border-emerald-300 p-4 rounded-xl text-emerald-900 text-xs font-semibold flex items-center gap-3">
          <ShieldCheck className="w-6 h-6 text-emerald-600 flex-shrink-0" />
          <div>{executionMessage}</div>
        </div>
      )}

      {/* Executive AI Proposed Strategies */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <Bot className="w-5 h-5 text-amber-600" />
              Executive AI Agent Proposed Response Strategies
            </h3>
            <p className="text-xs text-slate-500">
              Generated by Gemini 3.6 Enterprise Reasoning Engine — Requires Explicit Human Board Authorization
            </p>
          </div>
          <span className="text-xs font-bold px-3 py-1 bg-amber-100 text-amber-900 rounded-full">
            3 Strategies Formulated
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          {scenarioData.executiveAIProposedStrategies.map((strat) => {
            const isExecuted = strat.approval_status === 'EXECUTED';

            return (
              <div
                key={strat.recommendation_id}
                className={`p-5 rounded-xl border flex flex-col justify-between transition-all ${
                  isExecuted
                    ? 'bg-emerald-50/50 border-emerald-300 ring-2 ring-emerald-500/20'
                    : 'bg-slate-50 border-slate-200 hover:border-slate-300 hover:shadow-md'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200">
                      {strat.agent_name}
                    </span>
                    <span className="text-xs font-bold text-emerald-600 bg-emerald-100 px-2 py-0.5 rounded-full">
                      {(strat.confidence * 100).toFixed(0)}% Confidence
                    </span>
                  </div>

                  <h4 className="font-bold text-slate-900 text-sm mb-2">{strat.title}</h4>
                  <p className="text-xs text-slate-600 leading-relaxed mb-3">{strat.reasoning_summary}</p>

                  <div className="p-2.5 bg-white rounded-lg border border-slate-200 text-xs text-slate-700 space-y-1 mb-4">
                    <div className="font-semibold text-slate-900">Proposed Action:</div>
                    <p className="text-slate-600 text-[11px]">{strat.proposed_action}</p>
                    <div className="pt-1 text-emerald-700 font-bold flex items-center gap-1 text-[11px]">
                      <ArrowUpRight className="w-3.5 h-3.5" />
                      Expected Impact: {strat.expected_impact_chf}
                    </div>
                  </div>
                </div>

                <div>
                  {isExecuted ? (
                    <div className="w-full py-2 bg-emerald-600 text-white rounded-lg text-xs font-bold flex items-center justify-center gap-1.5 shadow-sm">
                      <CheckCircle2 className="w-4 h-4" />
                      APPROVED & EXECUTED
                    </div>
                  ) : (
                    <button
                      onClick={() => handleApproveStrategy(strat)}
                      className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-lg text-xs font-bold transition-all shadow-md flex items-center justify-center gap-1.5"
                    >
                      <ShieldCheck className="w-4 h-4 text-emerald-400" />
                      AUTHORIZE & EXECUTE (as {currentRole})
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
