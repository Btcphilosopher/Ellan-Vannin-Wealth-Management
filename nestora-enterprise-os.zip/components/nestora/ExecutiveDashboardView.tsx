'use client';

import React from 'react';
import { NestoraEnterpriseState } from '@/lib/nestora/store';
import { TrendingUp, DollarSign, Factory, ShieldAlert, Award, Activity, BarChart3, PieChartIcon } from 'lucide-react';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, PieChart, Pie, Cell } from 'recharts';

interface Props {
  state: NestoraEnterpriseState;
}

export const ExecutiveDashboardView: React.FC<Props> = ({ state }) => {
  const categoryData = [
    { name: 'Coffee Systems', revenue: 20200, color: '#d97706' },
    { name: 'Petcare', revenue: 18200, color: '#0284c7' },
    { name: 'Nutrition', revenue: 15400, color: '#16a34a' },
    { name: 'Prepared Dishes', revenue: 11800, color: '#dc2626' },
    { name: 'Confectionery', revenue: 8200, color: '#9333ea' },
    { name: 'Water & Drinks', revenue: 6400, color: '#2563eb' },
  ];

  const zonePerformance = [
    { zone: 'Americas', organicGrowth: 4.2, grossMargin: 48.1, oee: 80.2 },
    { zone: 'Europe', organicGrowth: 2.9, grossMargin: 45.8, oee: 84.5 },
    { zone: 'Asia-Oceania-Africa', organicGrowth: 5.4, grossMargin: 44.2, oee: 82.1 },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner KPI Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1 text-xs font-semibold">
            <span>NET REVENUE</span>
            <DollarSign className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{state.groupFinancials.net_revenue_chf}</div>
          <div className="text-xs font-semibold text-emerald-600 mt-1 flex items-center gap-0.5">
            <TrendingUp className="w-3 h-3" /> +3.8% Organic Growth
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1 text-xs font-semibold">
            <span>GROSS MARGIN</span>
            <BarChart3 className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{state.groupFinancials.gross_margin_pct}%</div>
          <div className="text-xs text-slate-500 mt-1 font-medium">
            {state.groupFinancials.gross_margin_chf}
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1 text-xs font-semibold">
            <span>EBITDA</span>
            <Activity className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{state.groupFinancials.ebitda_chf}</div>
          <div className="text-xs font-semibold text-slate-600 mt-1">
            20.5% EBITDA Margin
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1 text-xs font-semibold">
            <span>FREE CASH FLOW</span>
            <TrendingUp className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{state.groupFinancials.free_cash_flow_chf}</div>
          <div className="text-xs text-emerald-600 mt-1 font-semibold">
            ROIC: {state.groupFinancials.roic_pct}%
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1 text-xs font-semibold">
            <span>GLOBAL FACTORY OEE</span>
            <Factory className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">82.4%</div>
          <div className="text-xs text-slate-500 mt-1">
            102 Production Plants
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm hover:border-slate-300 transition-all">
          <div className="flex items-center justify-between text-slate-500 mb-1 text-xs font-semibold">
            <span>SERVICE LEVEL</span>
            <Award className="w-4 h-4 text-violet-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{state.controlTower.service_level_pct}%</div>
          <div className="text-xs text-slate-500 mt-1">
            OTIF (On-Time In-Full)
          </div>
        </div>
      </div>

      {/* Analytics Main Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Revenue Breakdown Chart */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="font-bold text-slate-900 text-base">Global Category Revenue Distribution (CHF Millions)</h3>
              <p className="text-xs text-slate-500">Real-time consolidated sales by food & beverage category domain</p>
            </div>
            <div className="text-xs font-semibold px-2.5 py-1 rounded bg-slate-100 text-slate-700">
              FY 2026 Trailing
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={categoryData} margin={{ top: 10, right: 20, left: 0, bottom: 20 }}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#64748b' }} />
                <YAxis tick={{ fontSize: 11, fill: '#64748b' }} unit="M" />
                <Tooltip
                  formatter={(value: any) => [`CHF ${value} Million`, 'Net Revenue']}
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#fff', borderRadius: '8px', fontSize: '12px' }}
                />
                <Bar dataKey="revenue" radius={[6, 6, 0, 0]}>
                  {categoryData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Geographic Zone Performance Breakdown */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-base mb-1">Geographic Zone Performance</h3>
            <p className="text-xs text-slate-500 mb-4">Organic Growth vs Gross Margin by Zone</p>

            <div className="space-y-4">
              {zonePerformance.map((z, idx) => (
                <div key={idx} className="p-3 rounded-xl bg-slate-50 border border-slate-200">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="font-bold text-xs text-slate-900">{z.zone}</span>
                    <span className="text-xs font-bold text-emerald-600">+{z.organicGrowth}% Org Growth</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 text-xs text-slate-600">
                    <div>
                      <span className="text-slate-400">Gross Margin: </span>
                      <span className="font-semibold text-slate-800">{z.grossMargin}%</span>
                    </div>
                    <div>
                      <span className="text-slate-400">Factory OEE: </span>
                      <span className="font-semibold text-slate-800">{z.oee}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Group Treasury Base Currency:</span>
            <span className="font-bold text-slate-900">CHF (Swiss Franc)</span>
          </div>
        </div>
      </div>

      {/* Flagship Brands Table */}
      <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="p-4 border-b border-slate-200 bg-slate-50/50 flex items-center justify-between">
          <div>
            <h3 className="font-bold text-slate-900 text-sm">Billionaire Brand Portfolio</h3>
            <p className="text-xs text-slate-500">Billion-dollar brands operating in Nestora Global Portfolio</p>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 bg-amber-100 text-amber-800 rounded-full">
            {state.brands.length} Flagship Brands
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-700">
            <thead className="bg-slate-100/80 uppercase text-[10px] text-slate-500 font-bold border-b border-slate-200">
              <tr>
                <th className="px-4 py-3">Brand Name</th>
                <th className="px-4 py-3">Category Domain</th>
                <th className="px-4 py-3">Global Market Share</th>
                <th className="px-4 py-3">Brand Health Index</th>
                <th className="px-4 py-3 text-right">Annual Revenue (CHF)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium">
              {state.brands.map((b) => (
                <tr key={b.id} className="hover:bg-slate-50/80 transition-colors">
                  <td className="px-4 py-3 font-bold text-slate-900 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-500"></span>
                    {b.name}
                  </td>
                  <td className="px-4 py-3 text-slate-600">{b.category_domain}</td>
                  <td className="px-4 py-3 font-semibold">{b.global_market_share_pct}%</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-16 bg-slate-200 rounded-full h-1.5">
                        <div
                          className="bg-emerald-500 h-1.5 rounded-full"
                          style={{ width: `${b.health_score}%` }}
                        ></div>
                      </div>
                      <span className="font-bold text-slate-800">{b.health_score}/100</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-right font-bold text-slate-900">{b.annual_revenue_chf}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
