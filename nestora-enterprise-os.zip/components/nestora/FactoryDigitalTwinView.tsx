'use client';

import React, { useState } from 'react';
import { NestoraEnterpriseState } from '@/lib/nestora/store';
import { OEEEngine, OEECalculationResult } from '@/lib/nestora/oee';
import { Factory, Cpu, Gauge, AlertTriangle, ShieldCheck, Zap, Thermometer, Activity, Settings, RefreshCw } from 'lucide-react';

interface Props {
  state: NestoraEnterpriseState;
}

export const FactoryDigitalTwinView: React.FC<Props> = ({ state }) => {
  const [selectedFactoryId, setSelectedFactoryId] = useState<string>('FAC-VEVEY');
  const [plannedMins, setPlannedMins] = useState<number>(480);
  const [operatingMins, setOperatingMins] = useState<number>(432);
  const [targetSpeed, setTargetSpeed] = useState<number>(200);
  const [totalUnits, setTotalUnits] = useState<number>(82000);
  const [goodUnits, setGoodUnits] = useState<number>(80770);

  const activeFactory = state.factories.find((f) => f.id === selectedFactoryId) || state.factories[0];
  const oeeResult: OEECalculationResult = OEEEngine.calculateOEE(
    plannedMins,
    operatingMins,
    targetSpeed,
    totalUnits,
    goodUnits
  );

  return (
    <div className="space-y-6">
      {/* Factory Selector & Health Cards */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
        <div>
          <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Factory className="w-5 h-5 text-indigo-600" />
            Factory Operating System & Digital Twin
          </h2>
          <p className="text-xs text-slate-500">
            Real-time machine telemetry, OEE loss trees, line speed, and predictive maintenance
          </p>
        </div>

        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-slate-600">Active Plant:</label>
          <select
            value={selectedFactoryId}
            onChange={(e) => setSelectedFactoryId(e.target.value)}
            className="bg-slate-100 text-xs font-bold text-slate-800 rounded-lg p-2 border border-slate-200 focus:outline-none cursor-pointer"
          >
            {state.factories.map((f) => (
              <option key={f.id} value={f.id}>
                {f.name} ({f.country})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Selected Plant Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 mb-1 flex items-center justify-between">
            <span>ANNUAL CAPACITY</span>
            <Factory className="w-4 h-4 text-slate-400" />
          </div>
          <div className="text-xl font-bold text-slate-900">
            {activeFactory.annual_capacity_tons.toLocaleString()} Tons
          </div>
          <div className="text-xs text-slate-500 mt-1">
            Utilization: {activeFactory.current_utilization_pct}%
          </div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 mb-1 flex items-center justify-between">
            <span>PLANT OEE SCORE</span>
            <Gauge className="w-4 h-4 text-indigo-600" />
          </div>
          <div className="text-xl font-bold text-indigo-900">{activeFactory.oee_pct}%</div>
          <div className="text-xs text-emerald-600 font-semibold mt-1">Target: &gt;82.0%</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 mb-1 flex items-center justify-between">
            <span>WATER INTENSITY</span>
            <Zap className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{activeFactory.water_m3_per_ton} m³/ton</div>
          <div className="text-xs text-slate-500 mt-1">Target: &lt;1.50 m³</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 mb-1 flex items-center justify-between">
            <span>ENERGY CONSUMPTION</span>
            <Activity className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">{activeFactory.energy_kwh_per_ton} kWh/ton</div>
          <div className="text-xs text-emerald-600 font-semibold mt-1">100% Renewable Hydro</div>
        </div>
      </div>

      {/* Real-time OEE Engine & Loss Tree Panel */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-6">
        <div className="flex items-center justify-between border-b border-slate-100 pb-4">
          <div>
            <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
              <Gauge className="w-5 h-5 text-indigo-600" />
              Live Line OEE Loss Tree Engine
            </h3>
            <p className="text-xs text-slate-500">
              Formula: OEE = Availability ({oeeResult.availabilityPct}%) × Performance ({oeeResult.performancePct}%) × Quality ({oeeResult.qualityPct}%)
            </p>
          </div>
          <div className="text-right">
            <span className="text-2xl font-extrabold text-indigo-600">{oeeResult.oeePct}%</span>
            <div className="text-[10px] font-bold uppercase text-slate-400">Calculated OEE</div>
          </div>
        </div>

        {/* OEE Metric Gauges */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-xs text-slate-700">1. AVAILABILITY</span>
              <span className="font-bold text-xs text-indigo-600">{oeeResult.availabilityPct}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2 mb-2">
              <div
                className="bg-indigo-600 h-2 rounded-full"
                style={{ width: `${oeeResult.availabilityPct}%` }}
              ></div>
            </div>
            <div className="text-[11px] text-slate-500 flex justify-between">
              <span>Run: {operatingMins} mins</span>
              <span>Planned: {plannedMins} mins</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-xs text-slate-700">2. PERFORMANCE</span>
              <span className="font-bold text-xs text-sky-600">{oeeResult.performancePct}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2 mb-2">
              <div
                className="bg-sky-600 h-2 rounded-full"
                style={{ width: `${oeeResult.performancePct}%` }}
              ></div>
            </div>
            <div className="text-[11px] text-slate-500 flex justify-between">
              <span>Output: {totalUnits.toLocaleString()} units</span>
              <span>Target: {targetSpeed} u/min</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-50 border border-slate-200">
            <div className="flex items-center justify-between mb-2">
              <span className="font-bold text-xs text-slate-700">3. QUALITY</span>
              <span className="font-bold text-xs text-emerald-600">{oeeResult.qualityPct}%</span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2 mb-2">
              <div
                className="bg-emerald-600 h-2 rounded-full"
                style={{ width: `${oeeResult.qualityPct}%` }}
              ></div>
            </div>
            <div className="text-[11px] text-slate-500 flex justify-between">
              <span>Good: {goodUnits.toLocaleString()} units</span>
              <span>Scrap: {(totalUnits - goodUnits).toLocaleString()}</span>
            </div>
          </div>
        </div>

        {/* Structured Loss Tree Breakdown */}
        <div className="p-4 rounded-xl bg-slate-900 text-white space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <span className="font-bold text-xs text-amber-400">STRUCTURED OEE LOSS TREE BREAKDOWN</span>
            <span className="text-xs font-semibold text-slate-400">Financial Impact: CHF {oeeResult.lossTree.financialLossCHF}</span>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            <div>
              <span className="text-slate-400 block text-[10px]">UNPLANNED BREAKDOWNS</span>
              <span className="font-bold text-red-400">{oeeResult.lossTree.unplannedBreakdownMinutes} Mins</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">MINOR STOPPAGES</span>
              <span className="font-bold text-amber-400">{oeeResult.lossTree.minorStoppagesMinutes} Mins</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">SPEED LOSS EQUIVALENT</span>
              <span className="font-bold text-sky-400">{oeeResult.lossTree.speedLossMinutes} Mins</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px]">QUALITY REJECTS/SCRAP</span>
              <span className="font-bold text-emerald-400">{oeeResult.lossTree.qualityScrapUnits} Units</span>
            </div>
          </div>
        </div>
      </div>

      {/* Production Lines & Machine Telemetry Grid */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
          <Cpu className="w-5 h-5 text-indigo-600" />
          Active Production Lines & Sensor Telemetry
        </h3>

        <div className="space-y-4">
          {state.lines.map((line) => (
            <div key={line.id} className="p-4 rounded-xl bg-slate-50 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bold text-sm text-slate-900">{line.name}</div>
                  <div className="text-xs text-slate-500">
                    Line Code: {line.line_code} | Rated Speed: {line.capacity_units_per_hr.toLocaleString()} u/hr
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-xs font-bold text-indigo-600 bg-indigo-100 px-2.5 py-1 rounded-full">
                    OEE: {line.oee_pct}%
                  </span>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2">
                {line.machines.map((m) => (
                  <div key={m.machine_id} className="p-3 bg-white rounded-lg border border-slate-200 text-xs space-y-1">
                    <div className="flex items-center justify-between font-bold text-slate-800">
                      <span>{m.name}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] ${
                          m.status === 'RUNNING' ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {m.status}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2 text-slate-600 pt-1">
                      <div>Speed: {m.speed_units_per_min} u/m</div>
                      <div>Temp: {m.temperature_c}°C</div>
                      <div>Pressure: {m.pressure_bar} bar</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
