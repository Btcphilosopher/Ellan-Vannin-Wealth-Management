'use client';

import React from 'react';
import { UserRole, ZoneId } from '@/lib/nestora/types';
import { FX_RATES_TO_CHF } from '@/lib/nestora/decimal';
import { ShieldCheck, Cpu, Globe, UserCheck, RefreshCw, AlertTriangle, PlayCircle } from 'lucide-react';

interface HeaderBarProps {
  currentRole: UserRole;
  onRoleChange: (role: UserRole) => void;
  selectedZone: ZoneId;
  onZoneChange: (zone: ZoneId) => void;
  onTriggerScenario: () => void;
  isScenarioActive: boolean;
  onToggleCopilot: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({
  currentRole,
  onRoleChange,
  selectedZone,
  onZoneChange,
  onTriggerScenario,
  isScenarioActive,
  onToggleCopilot,
}) => {
  return (
    <header className="bg-slate-900 border-b border-slate-800 text-white px-4 py-3 sticky top-0 z-40 shadow-xl">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Logo & Platform Identifiers */}
        <div className="flex items-center gap-3">
          <div className="bg-amber-500 text-slate-950 p-2 rounded-xl font-bold tracking-wider text-lg flex items-center justify-center w-10 h-10 shadow-lg shadow-amber-500/20">
            N
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-lg tracking-tight text-white">NESTORA ENTERPRISE OS</h1>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                ONLINE v3.6
              </span>
            </div>
            <p className="text-xs text-slate-400">
              GLOBAL FOOD, NUTRITION, MANUFACTURING & CONSUMER OPERATING SYSTEM
            </p>
          </div>
        </div>

        {/* FX Ticker & Zone Switcher */}
        <div className="hidden xl:flex items-center gap-4 text-xs bg-slate-950/80 px-3 py-1.5 rounded-lg border border-slate-800 text-slate-300">
          <span className="font-semibold text-slate-400">FX Rates (vs CHF):</span>
          <span>EUR: {FX_RATES_TO_CHF.EUR.toFixed(4)}</span>
          <span className="text-slate-600">|</span>
          <span>USD: {FX_RATES_TO_CHF.USD.toFixed(4)}</span>
          <span className="text-slate-600">|</span>
          <span>GBP: {FX_RATES_TO_CHF.GBP.toFixed(4)}</span>
        </div>

        {/* Global Controls & Role Selector */}
        <div className="flex items-center flex-wrap gap-2">
          {/* Zone Selector */}
          <div className="flex items-center gap-1 bg-slate-800 rounded-lg p-1 border border-slate-700">
            <Globe className="w-3.5 h-3.5 text-amber-400 ml-1" />
            <select
              value={selectedZone}
              onChange={(e) => onZoneChange(e.target.value as ZoneId)}
              className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none pr-1 cursor-pointer"
            >
              <option value="ZONE_GLOBAL" className="bg-slate-900 text-white">Global Group (CHF)</option>
              <option value="ZONE_EUROPE" className="bg-slate-900 text-white">Zone Europe</option>
              <option value="ZONE_AMERICAS" className="bg-slate-900 text-white">Zone Americas</option>
              <option value="ZONE_AOA" className="bg-slate-900 text-white">Zone Asia-Oceania-Africa</option>
            </select>
          </div>

          {/* Role Switcher */}
          <div className="flex items-center gap-1 bg-slate-800 rounded-lg p-1 border border-slate-700">
            <UserCheck className="w-3.5 h-3.5 text-sky-400 ml-1" />
            <select
              value={currentRole}
              onChange={(e) => onRoleChange(e.target.value as UserRole)}
              className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none pr-1 cursor-pointer"
            >
              <option value="Executive" className="bg-slate-900 text-white">Executive Board</option>
              <option value="Finance" className="bg-slate-900 text-white">Finance & Treasury</option>
              <option value="FactoryManager" className="bg-slate-900 text-white">Factory Operations</option>
              <option value="QualityManager" className="bg-slate-900 text-white">Quality & Food Safety</option>
              <option value="SupplyChainManager" className="bg-slate-900 text-white">Supply Chain Tower</option>
              <option value="R&D" className="bg-slate-900 text-white">R&D & Innovation</option>
              <option value="Procurement" className="bg-slate-900 text-white">Procurement</option>
              <option value="Auditor" className="bg-slate-900 text-white">Auditor / Compliance</option>
            </select>
          </div>

          {/* Scenario Demo Trigger Button */}
          <button
            onClick={onTriggerScenario}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all shadow-md ${
              isScenarioActive
                ? 'bg-amber-500 text-slate-950 font-bold border border-amber-400 shadow-amber-500/20 animate-pulse'
                : 'bg-gradient-to-r from-amber-600 to-orange-600 text-white hover:brightness-110'
            }`}
          >
            <PlayCircle className="w-3.5 h-3.5" />
            {isScenarioActive ? 'Scenario 68 Active' : 'Run Scenario 68'}
          </button>

          {/* AI Copilot Drawer Toggle */}
          <button
            onClick={onToggleCopilot}
            className="px-3 py-1.5 rounded-lg text-xs font-semibold bg-sky-600 hover:bg-sky-500 text-white flex items-center gap-1.5 transition-all shadow-md shadow-sky-600/20"
          >
            <Cpu className="w-3.5 h-3.5" />
            AI Copilot
          </button>
        </div>
      </div>
    </header>
  );
};
