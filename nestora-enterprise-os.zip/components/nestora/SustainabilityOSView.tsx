'use client';

import React, { useState } from 'react';
import { NestoraEnterpriseState } from '@/lib/nestora/store';
import { Leaf, Droplets, Recycle, ShieldCheck, TrendingDown, Sun, Wind } from 'lucide-react';

interface Props {
  state: NestoraEnterpriseState;
}

export const SustainabilityOSView: React.FC<Props> = ({ state }) => {
  const [renewableEnergyPct, setRenewableEnergyPct] = useState<number>(85);
  const [recycledPackagingPct, setRecycledPackagingPct] = useState<number>(92);

  const baselineScope12 = 4.26; // Million tons
  const baselineScope3 = 91.2; // Million tons

  // Net zero simulation
  const abatedScope12 = baselineScope12 * (1 - (renewableEnergyPct - 50) / 100);
  const abatedScope3 = baselineScope3 * (1 - (recycledPackagingPct - 70) / 200);
  const totalAbated = Math.round((abatedScope12 + abatedScope3) * 10) / 10;

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 text-white p-6 rounded-2xl border border-emerald-500/30 shadow-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/40 mb-2">
              <Leaf className="w-3.5 h-3.5 text-emerald-400" />
              NET-ZERO ROADMAP 2050 & SUSTAINABILITY OS
            </div>
            <h2 className="text-2xl font-extrabold text-white">
              Scope 1, 2, 3 GHG Carbon & Environmental Ledger
            </h2>
            <p className="text-slate-300 text-xs mt-1">
              Tracking greenhouse gas emissions, water withdrawal intensity, virgin plastic reductions, and regenerative agriculture sourcing
            </p>
          </div>

          <div className="text-right bg-emerald-900/40 p-3 rounded-xl border border-emerald-800">
            <span className="text-2xl font-extrabold text-emerald-400">95.5M Tons</span>
            <div className="text-[10px] uppercase font-bold text-slate-300">Total Carbon Footprint</div>
          </div>
        </div>
      </div>

      {/* GHG Ledger Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 mb-1 flex justify-between">
            <span>SCOPE 1 GHG (DIRECT)</span>
            <Leaf className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">2.84M Tons</div>
          <div className="text-xs text-emerald-600 font-semibold mt-1">-4.2% YoY Abatement</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 mb-1 flex justify-between">
            <span>SCOPE 2 GHG (INDIRECT)</span>
            <Sun className="w-4 h-4 text-amber-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">1.42M Tons</div>
          <div className="text-xs text-emerald-600 font-semibold mt-1">85% Renewable Hydro/Solar</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 mb-1 flex justify-between">
            <span>SCOPE 3 (VALUE CHAIN)</span>
            <Wind className="w-4 h-4 text-sky-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">91.2M Tons</div>
          <div className="text-xs text-slate-500 mt-1">Dairy & Agriculture Supply</div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm">
          <div className="text-xs font-semibold text-slate-500 mb-1 flex justify-between">
            <span>RECYCLABLE PACKAGING</span>
            <Recycle className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-xl font-bold text-slate-900">91.4%</div>
          <div className="text-xs text-emerald-600 font-semibold mt-1">Target: 95% by 2027</div>
        </div>
      </div>

      {/* Interactive Net-Zero Scenario Simulator */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <h3 className="font-bold text-slate-900 text-base flex items-center gap-2">
          <TrendingDown className="w-5 h-5 text-emerald-600" />
          Net-Zero 2030 Abatement Scenario Engine
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-50 p-5 rounded-xl border border-slate-200">
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                <span>Renewable Electricity Sourcing Target:</span>
                <span className="text-emerald-600">{renewableEnergyPct}%</span>
              </div>
              <input
                type="range"
                min="50"
                max="100"
                value={renewableEnergyPct}
                onChange={(e) => setRenewableEnergyPct(parseInt(e.target.value, 10))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />
            </div>

            <div>
              <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                <span>Recyclable Packaging Transition Target:</span>
                <span className="text-emerald-600">{recycledPackagingPct}%</span>
              </div>
              <input
                type="range"
                min="70"
                max="100"
                value={recycledPackagingPct}
                onChange={(e) => setRecycledPackagingPct(parseInt(e.target.value, 10))}
                className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
              />
            </div>
          </div>

          <div className="bg-emerald-950 text-white p-4 rounded-xl border border-emerald-800 flex flex-col justify-between">
            <div>
              <span className="text-[10px] font-bold uppercase text-emerald-300">PROJECTED SCENARIO ABATEMENT</span>
              <div className="text-2xl font-extrabold text-emerald-400 mt-1">
                {totalAbated} Million Tons CO2e
              </div>
              <p className="text-xs text-slate-300 mt-1">
                Achieves 18.4% total carbon footprint reduction against 2018 baseline.
              </p>
            </div>

            <div className="pt-2 text-[11px] text-emerald-200 flex items-center gap-1">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              SBTi (Science Based Targets initiative) Verified Pathway
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
