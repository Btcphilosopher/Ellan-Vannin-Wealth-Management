'use client';

import React from 'react';
import { NestoraEnterpriseState } from '@/lib/nestora/store';
import { Lightbulb, Rocket, FlaskConical, Award, ShieldCheck, DollarSign, ArrowRight } from 'lucide-react';

interface Props {
  state: NestoraEnterpriseState;
}

export const InnovationPipelineView: React.FC<Props> = ({ state }) => {
  const stages = [
    'IDEA', 'CONCEPT', 'RESEARCH', 'FORMULATION', 'PROTOTYPE',
    'SENSORY_TEST', 'PILOT', 'FACTORY_SCALE_UP', 'MARKET_LAUNCH'
  ];

  return (
    <div className="space-y-6">
      {/* Header Summary */}
      <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm space-y-4">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-indigo-600" />
              R&D Engine & Stage-Gate Innovation Pipeline
            </h2>
            <p className="text-xs text-slate-500">
              Lifecycle Governance: IDEA → CONCEPT → RESEARCH → FORMULATION → PROTOTYPE → SENSORY → PILOT → SCALE → LAUNCH
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold px-3 py-1 bg-indigo-100 text-indigo-900 rounded-full">
              42 Active R&D Projects
            </span>
            <span className="text-xs font-bold px-3 py-1 bg-emerald-100 text-emerald-900 rounded-full">
              CHF 1.85B R&D Budget
            </span>
          </div>
        </div>

        {/* Stage Gate Board */}
        <div className="overflow-x-auto pb-2">
          <div className="flex items-center gap-2 min-w-max">
            {stages.map((stg, i) => (
              <div key={stg} className="flex items-center gap-2">
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-center text-xs font-bold text-slate-800 min-w-[110px]">
                  <div className="text-[10px] text-slate-400 font-semibold mb-0.5">GATE 0{i + 1}</div>
                  <div>{stg.replace(/_/g, ' ')}</div>
                </div>
                {i < stages.length - 1 && <ArrowRight className="w-3.5 h-3.5 text-slate-400 flex-shrink-0" />}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Flagship Innovation Projects Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {state.innovationProjects.map((p) => (
          <div key={p.id} className="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                  {p.category}
                </span>
                <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-indigo-100 text-indigo-800">
                  {p.stage}
                </span>
              </div>

              <h3 className="font-bold text-slate-900 text-sm mb-1">{p.name}</h3>
              <p className="text-xs text-slate-500 mb-3">Lead: {p.lead_scientist}</p>

              {/* Multidimensional Scores */}
              <div className="space-y-2 p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Commercial Viability:</span>
                  <span className="font-bold text-slate-900">{p.commercial_score}/100</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Technical Feasibility:</span>
                  <span className="font-bold text-slate-900">{p.technical_score}/100</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Consumer Preference:</span>
                  <span className="font-bold text-slate-900">{p.consumer_score}/100</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-slate-600">Sustainability Rating:</span>
                  <span className="font-bold text-emerald-600">{p.sustainability_score}/100</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex items-center justify-between text-xs font-bold">
              <span className="text-slate-500">Target Launch: {p.target_launch_year}</span>
              <span className="text-indigo-600">Budget: CHF {p.budget_chf}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
