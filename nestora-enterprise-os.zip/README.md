# NESTORA ENTERPRISE OS
## GLOBAL FOOD, NUTRITION, MANUFACTURING & CONSUMER OPERATING SYSTEM

Nestora Enterprise OS is a synthetic, production-grade enterprise operating system inspired by the global scale, manufacturing footprint, supply-chain topology, financial precision, and digital twin technology of Nestlé-scale food and beverage corporations.

---

## 🏛️ Enterprise Object Graph
```
GROUP
 └── ZONE (Americas, Europe, Asia-Oceania-Africa)
      └── MARKET / COUNTRY
           └── BUSINESS UNIT / CATEGORY (Coffee, Petcare, Nutrition, Confectionery...)
                └── BRAND (Nescafé, Nespresso, Purina, KitKat, Maggi)
                     └── PRODUCT & SKU
                          └── RECIPE & INGREDIENT SPECIFICATION
                               └── SUPPLIER & FARM ORIGIN
                                    └── FACTORY & PRODUCTION LINE
                                         └── BATCH & QUALITY RECORD
                                              └── SHIPMENT & DISTRIBUTION CENTER
                                                   └── RETAILER & CONSUMER
```

---

## 🚀 Key Enterprise Capabilities

1. **Executive Scenario 68 (Coffee Demand Spike +12%)**: Live real-time demand surge cascade calculating inventory depletion, factory capacity reallocations, raw material spot buys, working capital requirements, and 3 AI proposed strategies with executive human approval and audit logging.
2. **Financial Precision Engine**: Strict Decimal math (no floats) supporting CHF, EUR, USD, GBP, JPY, CNY, INR with exchange rate matrices and multi-currency P&L consolidation.
3. **End-to-End Traceability & Food Safety**: Direct graph traversal from Farm Lot -> Factory Batch -> Active Shipment -> Retailer. Includes 1-click targeted recall isolation.
4. **Commodity Market Shock Simulator**: Simulates spot price shocks (e.g. Cocoa +35%, Coffee +15%) calculating cascade impact down to SKU gross margins, factory conversion costs, and Group EBITDA.
5. **Manufacturing Digital Twin & OEE Engine**: Live OEE calculation (`Availability × Performance × Quality`) with loss trees, machine telemetry, and predictive maintenance.
6. **Enterprise AI Copilot**: Powered by Gemini API with structured database query execution logs and multi-agent roles (`SupplyChainAgent`, `FactoryAgent`, `ProcurementAgent`, `FinanceAgent`, `QualityAgent`, `RDAgent`, `MarketingAgent`, `SalesAgent`, `SustainabilityAgent`, `ExecutiveAgent`).
7. **Sustainability OS**: GHG Scope 1, 2, 3 Carbon Ledger, Water Withdrawal Ledger, Recyclable Packaging Plastic tracker, and Net-Zero scenario simulator.
8. **Append-Only Audit & RBAC Console**: Immutable log tracking every sensitive action with who, what, when, where, why, before/after states, and IP addresses.

---

## 🛠️ Technology Stack
- **Web Application & UI**: Next.js 15 App Router, TypeScript, React 19, Tailwind CSS v4, Lucide Icons, Recharts, Decimal.js, Motion.
- **Backend Architecture**: Python FastAPI Services (`nestora-enterprise-os/backend`), Rust Telemetry & Simulation Kernel (`nestora-enterprise-os/rust-core`), Kotlin Enterprise Desktop/Android UI (`nestora-enterprise-os/kotlin`).
- **AI Core**: Google GenAI SDK (`@google/genai`) with Gemini 3.5 Flash / Gemini 3.6 Enterprise reasoning models.
- **Specification**: OpenAPI 3.0 (`openapi/nestora.yaml`), PostgreSQL Schema (`nestora-enterprise-os/database/schemas/schema.sql`).

---

## 🏃 Running the Operating System
```bash
# 1. Launch Next.js Application
npm run dev

# 2. Access Health Endpoint
curl http://localhost:3000/api/health

# 3. Trigger Executive Scenario 68 via API
curl -X POST http://localhost:3000/api/scenarios/coffee-spike
```
