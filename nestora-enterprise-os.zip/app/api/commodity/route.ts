import { NextRequest, NextResponse } from 'next/server';
import { CommodityEngine } from '@/lib/nestora/commodity';

export async function POST(req: NextRequest) {
  const body = await req.json();
  const commodity = body.commodity || 'COCOA';
  const priceChangePct = typeof body.priceChangePct === 'number' ? body.priceChangePct : 35;

  const result = CommodityEngine.simulateShock({ commodity, priceChangePct });
  return NextResponse.json(result);
}
