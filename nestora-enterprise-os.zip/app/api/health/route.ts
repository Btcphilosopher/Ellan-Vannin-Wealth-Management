import { NextResponse } from 'next/server';

export async function GET() {
  return NextResponse.json({
    status: 'HEALTHY',
    system: 'NESTORA ENTERPRISE OS',
    version: '3.6.0-ENTERPRISE-PROD',
    timestamp: new Date().toISOString(),
    services: {
      financial_engine: 'ONLINE (Decimal.js)',
      traceability_graph: 'ONLINE',
      commodity_simulator: 'ONLINE',
      gemini_copilot: 'ONLINE',
      audit_engine: 'ONLINE (Append-Only)',
      oee_calculator: 'ONLINE',
    },
  });
}
