import { NextRequest, NextResponse } from 'next/server';
import { EnterpriseAIEngine } from '@/lib/nestora/ai';

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const result = await EnterpriseAIEngine.queryCopilot({
      userQuery: body.prompt || body.userQuery || 'Summarize Nestora Group operations',
      contextData: body.contextData,
    });
    return NextResponse.json(result);
  } catch (error: unknown) {
    const errMessage = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: errMessage }, { status: 500 });
  }
}
