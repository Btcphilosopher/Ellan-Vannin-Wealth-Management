import { NextResponse } from 'next/server';
import { ExecutiveScenarioEngine } from '@/lib/nestora/scenarios';
import { AuditEngine } from '@/lib/nestora/audit';

export async function POST() {
  const result = ExecutiveScenarioEngine.runCoffeeSpikeScenario();

  AuditEngine.logEvent({
    who: 'Executive Scenario Engine',
    role: 'Executive',
    what: 'SIMULATION_TRIGGERED',
    where_module: 'EXECUTIVE_COMMAND_CENTER',
    why_reason: 'Coffee Demand Spike (+12%) scenario executed',
  });

  return NextResponse.json(result);
}
