import { NextRequest, NextResponse } from 'next/server';
import { TraceabilityEngine } from '@/lib/nestora/traceability';

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const lot = searchParams.get('lot') || 'LOT-COFFEE-2026-88';
  const tree = TraceabilityEngine.buildTraceabilityTree(lot);
  return NextResponse.json(tree);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const lot = body.lotNumber || 'LOT-COFFEE-2026-88';
  const analysis = TraceabilityEngine.runRecallAnalysis(lot);
  return NextResponse.json(analysis);
}
