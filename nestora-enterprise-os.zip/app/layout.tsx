import type {Metadata} from 'next';
import './globals.css'; // Global styles

export const metadata: Metadata = {
  title: 'Nestora Enterprise OS',
  description: 'Global Food, Nutrition, Manufacturing & Consumer Enterprise Operating System',
  openGraph: {
    title: 'Nestora Enterprise OS',
    description: 'Global Food, Nutrition, Manufacturing & Consumer Enterprise Operating System',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Nestora Enterprise OS',
    description: 'Global Food, Nutrition, Manufacturing & Consumer Enterprise Operating System',
  },
};

export default function RootLayout({children}: {children: React.ReactNode}) {
  return (
    <html lang="en">
      <body suppressHydrationWarning>{children}</body>
    </html>
  );
}
