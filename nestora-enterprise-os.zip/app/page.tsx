'use client';

import React, { useState } from 'react';
import { initialEnterpriseStore, NestoraEnterpriseState } from '@/lib/nestora/store';
import { UserRole, ZoneId } from '@/lib/nestora/types';
import { HeaderBar } from '@/components/nestora/HeaderBar';
import { ExecutiveDashboardView } from '@/components/nestora/ExecutiveDashboardView';
import { ExecutiveScenarioView } from '@/components/nestora/ExecutiveScenarioView';
import { ControlTowerView } from '@/components/nestora/ControlTowerView';
import { FactoryDigitalTwinView } from '@/components/nestora/FactoryDigitalTwinView';
import { TraceabilityView } from '@/components/nestora/TraceabilityView';
import { CommoditySimulatorView } from '@/components/nestora/CommoditySimulatorView';
import { InnovationPipelineView } from '@/components/nestora/InnovationPipelineView';
import { SustainabilityOSView } from '@/components/nestora/SustainabilityOSView';
import { AuditConsoleView } from '@/components/nestora/AuditConsoleView';
import { AICopilotDrawer } from '@/components/nestora/AICopilotDrawer';
import {
  BarChart3,
  Zap,
  Globe,
  Factory,
  GitCommit,
  ShoppingCart,
  FlaskConical,
  Leaf,
  ShieldCheck,
  Building2
} from 'lucide-react';

type TabType =
  | 'EXECUTIVE'
  | 'SCENARIO_68'
  | 'CONTROL_TOWER'
  | 'FACTORY_TWIN'
  | 'TRACEABILITY'
  | 'COMMODITY'
  | 'INNOVATION'
  | 'SUSTAINABILITY'
  | 'AUDIT';

export default function Page() {
  const [store, setStore] = useState<NestoraEnterpriseState>(initialEnterpriseStore);
  const [activeTab, setActiveTab] = useState<TabType>('EXECUTIVE');
  const [isCopilotOpen, setIsCopilotOpen] = useState<boolean>(false);
  const [isScenarioActive, setIsScenarioActive] = useState<boolean>(false);

  const handleRoleChange = (role: UserRole) => {
    setStore((prev) => ({ ...prev, userRole: role }));
  };

  const handleZoneChange = (zone: ZoneId) => {
    setStore((prev) => ({ ...prev, selectedZone: zone }));
  };

  const handleTriggerScenario = () => {
    setActiveTab('SCENARIO_68');
    setIsScenarioActive(true);
  };

  const handleAuditLogged = () => {
    // Force re-render/store update if needed
    setStore((prev) => ({ ...prev }));
  };

  const tabs = [
    { id: 'EXECUTIVE', label: 'Executive Dashboard', icon: BarChart3 },
    { id: 'SCENARIO_68', label: 'Scenario 68 (Coffee Spike)', icon: Zap, badge: 'DEMO' },
    { id: 'CONTROL_TOWER', label: 'Supply Chain Tower', icon: Globe },
    { id: 'FACTORY_TWIN', label: 'Factory Digital Twin', icon: Factory },
    { id: 'TRACEABILITY', label: 'Food Safety & Traceability', icon: GitCommit },
    { id: 'COMMODITY', label: 'Commodity Simulator', icon: ShoppingCart },
    { id: 'INNOVATION', label: 'R&D Innovation Pipeline', icon: FlaskConical },
    { id: 'SUSTAINABILITY', label: 'Sustainability OS', icon: Leaf },
    { id: 'AUDIT', label: 'Audit & Security', icon: ShieldCheck },
  ];

  return (
    <div className="min-h-screen bg-slate-100 text-slate-900 font-sans flex flex-col">
      {/* Global Executive Header */}
      <HeaderBar
        currentRole={store.userRole}
        onRoleChange={handleRoleChange}
        selectedZone={store.selectedZone as ZoneId}
        onZoneChange={handleZoneChange}
        onTriggerScenario={handleTriggerScenario}
        isScenarioActive={isScenarioActive}
        onToggleCopilot={() => setIsCopilotOpen(!isCopilotOpen)}
      />

      {/* Main Tab Navigation Bar */}
      <div className="bg-slate-900 border-b border-slate-800 text-slate-300 px-4">
        <div className="max-w-7xl mx-auto flex items-center gap-1 overflow-x-auto scrollbar-none py-2 text-xs">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`px-3.5 py-2 rounded-xl font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
                  isActive
                    ? 'bg-slate-800 text-white shadow-sm border border-slate-700'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-amber-400' : 'text-slate-500'}`} />
                <span>{tab.label}</span>
                {tab.badge && (
                  <span className="text-[9px] font-extrabold bg-amber-500 text-slate-950 px-1.5 py-0.5 rounded-full">
                    {tab.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Operational Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
        {activeTab === 'EXECUTIVE' && <ExecutiveDashboardView state={store} />}
        {activeTab === 'SCENARIO_68' && (
          <ExecutiveScenarioView currentRole={store.userRole} onAuditLogged={handleAuditLogged} />
        )}
        {activeTab === 'CONTROL_TOWER' && <ControlTowerView state={store} />}
        {activeTab === 'FACTORY_TWIN' && <FactoryDigitalTwinView state={store} />}
        {activeTab === 'TRACEABILITY' && (
          <TraceabilityView currentRole={store.userRole} onAuditLogged={handleAuditLogged} />
        )}
        {activeTab === 'COMMODITY' && <CommoditySimulatorView />}
        {activeTab === 'INNOVATION' && <InnovationPipelineView state={store} />}
        {activeTab === 'SUSTAINABILITY' && <SustainabilityOSView state={store} />}
        {activeTab === 'AUDIT' && (
          <AuditConsoleView currentRole={store.userRole} auditLogs={store.auditLogs} />
        )}
      </main>

      {/* AI Copilot Drawer */}
      <AICopilotDrawer isOpen={isCopilotOpen} onClose={() => setIsCopilotOpen(false)} />

      {/* Footer Status Bar */}
      <footer className="bg-white border-t border-slate-200 py-3 px-4 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Building2 className="w-4 h-4 text-slate-400" />
            <span className="font-bold text-slate-800">NESTORA ENTERPRISE OS</span>
            <span>— Global Food, Nutrition, Manufacturing & Consumer Operating System</span>
          </div>
          <div className="flex items-center gap-4 text-[11px] font-medium">
            <span>Precision: Decimal.js (CHF Base)</span>
            <span>•</span>
            <span>Security: Append-Only Audit Stream</span>
            <span>•</span>
            <span className="text-emerald-600 font-bold">SHA-256 Verified</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
