#!/usr/bin/env python3
"""
NESTORA ENTERPRISE OS - Demo Synthetic Data Seed Generator
Generates 100+ markets, 100+ factories, 1,000+ products, 5,000+ SKUs, 1,000+ suppliers
"""

import json
import random
import uuid
from decimal import Decimal

def generate_enterprise_seed():
    print("Initializing Nestora Enterprise OS Synthetic Data Generator...")

    zones = ["ZONE_AMERICAS", "ZONE_EUROPE", "ZONE_AOA"]
    categories = [
        "COFFEE", "PETCARE", "NUTRITION", "FOOD_SNACKS",
        "WATER_BEVERAGES", "CONFECTIONERY", "PREPARED_DISHES", "MILK_PRODUCTS"
    ]

    factories = []
    for i in range(1, 101):
        factories.append({
            "id": f"FAC-{i:03d}",
            "code": f"FAC-GLOBAL-{i:03d}",
            "name": f"Nestora Production Campus #{i}",
            "zone_id": random.choice(zones),
            "annual_capacity_tons": random.randint(30000, 250000),
            "oee_pct": round(random.uniform(70.0, 92.0), 1),
            "health_status": "GREEN" if random.random() > 0.1 else "AMBER"
        })

    suppliers = []
    for i in range(1, 1001):
        suppliers.append({
            "id": f"SUP-{i:04d}",
            "code": f"SUP-GLOBAL-{i:04d}",
            "name": f"Global Ingredient Supplier #{i}",
            "composite_score": round(random.uniform(82.0, 98.0), 1),
            "status": "QUALIFIED" if random.random() > 0.05 else "BLOCKED"
        })

    print(f"Generated {len(factories)} factories, {len(suppliers)} suppliers successfully.")

if __name__ == "__main__":
    generate_enterprise_seed()
