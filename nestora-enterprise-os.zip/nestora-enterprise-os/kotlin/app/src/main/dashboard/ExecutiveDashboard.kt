package com.nestora.enterprise.dashboard

import java.math.BigDecimal

data class ExecutiveKpi(
    val title: String,
    val valueFormatted: String,
    val deltaPct: Double,
    val isPositive: Boolean
)

data class ExecutiveDashboardState(
    val grossRevenueChf: BigDecimal,
    val netRevenueChf: BigDecimal,
    val grossMarginPct: Double,
    val ebitdaChf: BigDecimal,
    val freeCashFlowChf: BigDecimal,
    val workingCapitalChf: BigDecimal,
    val factoryOeePct: Double,
    val activeDisruptions: Int,
    val kpiList: List<ExecutiveKpi>
)

class ExecutiveDashboardViewModel {

    fun loadGlobalMetrics(): ExecutiveDashboardState {
        val grossRev = BigDecimal("92400000000.00")
        val grossMargin = 46.3
        val ebitda = BigDecimal("18400000000.00")

        val kpis = listOf(
            ExecutiveKpi("Organic Growth", "+3.8%", 3.8, true),
            ExecutiveKpi("Gross Margin", "46.3%", 0.8, true),
            ExecutiveKpi("Free Cash Flow", "CHF 10.8B", 4.2, true),
            ExecutiveKpi("Global Factory OEE", "82.4%", -1.2, false),
            ExecutiveKpi("Scope 1-3 Carbon", "95.5M Tons", -2.8, true)
        )

        return ExecutiveDashboardState(
            grossRevenueChf = grossRev,
            netRevenueChf = BigDecimal("89800000000.00"),
            grossMarginPct = grossMargin,
            ebitdaChf = ebitda,
            freeCashFlowChf = BigDecimal("10800000000.00"),
            workingCapitalChf = BigDecimal("6400000000.00"),
            factoryOeePct = 82.4,
            activeDisruptions = 2,
            kpiList = kpis
        )
    }
}
