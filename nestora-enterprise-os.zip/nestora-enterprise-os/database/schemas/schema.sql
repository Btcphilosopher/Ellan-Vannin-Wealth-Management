-- NESTORA ENTERPRISE OS - PostgreSQL Enterprise Canonical Schema

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE organizations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(32) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    headquarters VARCHAR(255) NOT NULL,
    base_currency VARCHAR(3) NOT NULL DEFAULT 'CHF',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    version INT NOT NULL DEFAULT 1,
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE'
);

CREATE TABLE zones (
    id VARCHAR(64) PRIMARY KEY,
    organization_id UUID REFERENCES organizations(id),
    code VARCHAR(32) NOT NULL,
    name VARCHAR(255) NOT NULL,
    headquarters_city VARCHAR(255) NOT NULL,
    zone_president VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE markets (
    id VARCHAR(64) PRIMARY KEY,
    zone_id VARCHAR(64) REFERENCES zones(id),
    country_code VARCHAR(3) NOT NULL,
    name VARCHAR(255) NOT NULL,
    currency VARCHAR(3) NOT NULL,
    revenue_target_chf NUMERIC(28, 2) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
    id VARCHAR(64) PRIMARY KEY,
    domain VARCHAR(64) NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    global_lead VARCHAR(255)
);

CREATE TABLE brands (
    id VARCHAR(64) PRIMARY KEY,
    category_domain VARCHAR(64) NOT NULL,
    code VARCHAR(32) NOT NULL,
    name VARCHAR(255) NOT NULL,
    slogan TEXT,
    health_score INT CHECK (health_score BETWEEN 0 AND 100),
    annual_revenue_chf NUMERIC(28, 2) NOT NULL
);

CREATE TABLE skus (
    id VARCHAR(64) PRIMARY KEY,
    product_id VARCHAR(64) NOT NULL,
    gtin VARCHAR(14) UNIQUE NOT NULL,
    sku_code VARCHAR(64) NOT NULL,
    name VARCHAR(255) NOT NULL,
    pack_size VARCHAR(64) NOT NULL,
    unit_price_chf NUMERIC(28, 2) NOT NULL,
    cogs_per_unit_chf NUMERIC(28, 2) NOT NULL,
    shelf_life_days INT NOT NULL
);

CREATE TABLE factories (
    id VARCHAR(64) PRIMARY KEY,
    code VARCHAR(64) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    zone_id VARCHAR(64) REFERENCES zones(id),
    country VARCHAR(100) NOT NULL,
    latitude NUMERIC(9, 6),
    longitude NUMERIC(9, 6),
    annual_capacity_tons NUMERIC(12, 2) NOT NULL,
    oee_pct NUMERIC(5, 2) NOT NULL,
    health_status VARCHAR(16) NOT NULL DEFAULT 'GREEN'
);

CREATE TABLE batches (
    batch_number VARCHAR(64) PRIMARY KEY,
    factory_id VARCHAR(64) REFERENCES factories(id),
    sku_id VARCHAR(64) REFERENCES skus(id),
    quantity_units INT NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'PLANNED',
    start_time TIMESTAMP WITH TIME ZONE NOT NULL,
    end_time TIMESTAMP WITH TIME ZONE
);

CREATE TABLE audit_events (
    audit_id VARCHAR(64) PRIMARY KEY,
    who VARCHAR(255) NOT NULL,
    role VARCHAR(64) NOT NULL,
    what VARCHAR(255) NOT NULL,
    when_timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    where_module VARCHAR(128) NOT NULL,
    why_reason TEXT NOT NULL,
    before_state TEXT,
    after_state TEXT,
    ip_address VARCHAR(45) NOT NULL
);
