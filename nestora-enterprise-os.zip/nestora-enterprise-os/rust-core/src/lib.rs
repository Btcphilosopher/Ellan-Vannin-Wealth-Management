//! NESTORA ENTERPRISE OS - Rust High-Performance Telemetry & Simulation Kernel

use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct LineTelemetryEvent {
    pub factory_id: String,
    pub line_code: String,
    pub machine_id: String,
    pub speed_units_per_min: f64,
    pub temperature_c: f64,
    pub pressure_bar: f64,
    pub timestamp_epoch_ms: u64,
}

#[derive(Debug, Serialize, Deserialize)]
pub struct OEEResult {
    pub availability_pct: f64,
    pub performance_pct: f64,
    pub quality_pct: f64,
    pub oee_pct: f64,
}

pub fn calculate_oee_rust(
    planned_minutes: f64,
    operating_minutes: f64,
    target_units_per_min: f64,
    total_units: f64,
    good_units: f64,
) -> OEEResult {
    let availability = if planned_minutes > 0.0 {
        (operating_minutes / planned_minutes).min(1.0)
    } else {
        0.0
    };

    let max_units = operating_minutes * target_units_per_min;
    let performance = if max_units > 0.0 {
        (total_units / max_units).min(1.0)
    } else {
        0.0
    };

    let quality = if total_units > 0.0 {
        (good_units / total_units).min(1.0)
    } else {
        0.0
    };

    let oee = availability * performance * quality;

    OEEResult {
        availability_pct: (availability * 100.0 * 10.0).round() / 10.0,
        performance_pct: (performance * 100.0 * 10.0).round() / 10.0,
        quality_pct: (quality * 100.0 * 10.0).round() / 10.0,
        oee_pct: (oee * 100.0 * 10.0).round() / 10.0,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_oee_calculation() {
        let res = calculate_oee_rust(480.0, 420.0, 200.0, 80000.0, 78800.0);
        assert!((res.availability_pct - 87.5).abs() < 0.1);
        assert!((res.quality_pct - 98.5).abs() < 0.1);
    }
}
