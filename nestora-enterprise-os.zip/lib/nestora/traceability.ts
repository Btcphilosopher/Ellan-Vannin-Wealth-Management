import { QualityStatus } from './types';

export interface TraceabilityNode {
  id: string;
  name: string;
  type: 'SUPPLIER' | 'RAW_MATERIAL' | 'BATCH' | 'FACTORY' | 'SKU' | 'SHIPMENT' | 'CUSTOMER_MARKET';
  code: string;
  location: string;
  status: QualityStatus;
  metadata: {
    lot_number?: string;
    temperature_recorded_c?: number;
    allergen_declared?: string[];
    quantity_kg_or_units?: number;
    timestamp?: string;
  };
  children: TraceabilityNode[];
}

export interface RecallAnalysisResult {
  contaminatedLotNumber: string;
  ingredientName: string;
  supplierName: string;
  affectedFactories: { id: string; name: string; country: string }[];
  affectedBatches: { batchNumber: string; skuName: string; status: QualityStatus }[];
  affectedShipments: { trackingNumber: string; destinationMarket: string; eta: string }[];
  affectedMarkets: string[];
  estimatedRecallCostCHF: string;
  actionSummary: string;
}

export class TraceabilityEngine {
  /**
   * Builds the traceability graph for an ingredient lot
   */
  static buildTraceabilityTree(lotNumber: string): TraceabilityNode {
    // Synthetic deterministic graph based on lotNumber
    const isContaminated = lotNumber.toLowerCase().includes('contam') || lotNumber.endsWith('88') || lotNumber === 'LOT-COFFEE-2026-99';

    const rootSupplier: TraceabilityNode = {
      id: 'SUP-7819',
      name: 'Alta Mogiana Coffee Cooperative',
      type: 'SUPPLIER',
      code: 'SUP-BRAZIL-COFFEE-01',
      location: 'Minas Gerais, Brazil',
      status: isContaminated ? 'ON_HOLD' : 'PASSED',
      metadata: {
        lot_number: lotNumber,
        allergen_declared: [],
        quantity_kg_or_units: 25000,
        timestamp: '2026-08-14 08:30 UTC',
      },
      children: [
        {
          id: 'ING-RAW-COFFEE-ARABICA',
          name: 'Green Arabica Beans Single-Origin',
          type: 'RAW_MATERIAL',
          code: 'RM-COF-0192',
          location: 'Central Grain Silo 4',
          status: isContaminated ? 'ON_HOLD' : 'PASSED',
          metadata: {
            lot_number: lotNumber,
            quantity_kg_or_units: 25000,
            timestamp: '2026-08-16 11:00 UTC',
          },
          children: [
            {
              id: 'BATCH-2026-0912-A1',
              name: 'Nescafé Gold Special Blend Roast Batch #912',
              type: 'BATCH',
              code: 'BATCH-2026-0912-A1',
              location: 'Factory Vevey Line 2',
              status: isContaminated ? 'RECALLED' : 'PASSED',
              metadata: {
                lot_number: lotNumber,
                quantity_kg_or_units: 18500,
                timestamp: '2026-08-20 14:15 UTC',
              },
              children: [
                {
                  id: 'SKU-NESCAFE-GOLD-200G',
                  name: 'Nescafé Gold 200g Glass Jar',
                  type: 'SKU',
                  code: '7613032123456',
                  location: 'Vevey High-Bay Distribution Hub',
                  status: isContaminated ? 'RECALLED' : 'PASSED',
                  metadata: {
                    quantity_kg_or_units: 92500, // 92,500 units
                  },
                  children: [
                    {
                      id: 'SHIP-994812',
                      name: 'Shipment #994812 - Central Europe Logistics Hub',
                      type: 'SHIPMENT',
                      code: 'SHIP-994812',
                      location: 'A1 Highway Transit / Offenburg Hub',
                      status: isContaminated ? 'RECALLED' : 'PASSED',
                      metadata: {
                        temperature_recorded_c: 18.4,
                        timestamp: '2026-08-28 06:00 UTC',
                      },
                      children: [
                        {
                          id: 'MKT-GERMANY',
                          name: 'Germany Retail Channel (Rewe & Edeka)',
                          type: 'CUSTOMER_MARKET',
                          code: 'MKT-DE-RETAIL',
                          location: 'Frankfurt / Munich Hubs',
                          status: isContaminated ? 'RECALLED' : 'PASSED',
                          metadata: {
                            quantity_kg_or_units: 45000,
                          },
                          children: [],
                        },
                        {
                          id: 'MKT-FRANCE',
                          name: 'France Retail Channel (Carrefour)',
                          type: 'CUSTOMER_MARKET',
                          code: 'MKT-FR-RETAIL',
                          location: 'Paris Logistics Terminal',
                          status: isContaminated ? 'RECALLED' : 'PASSED',
                          metadata: {
                            quantity_kg_or_units: 47500,
                          },
                          children: [],
                        },
                      ],
                    },
                  ],
                },
              ],
            },
            {
              id: 'BATCH-2026-0914-B3',
              name: 'Nespresso Original Master Origin Brazil Batch #914',
              type: 'BATCH',
              code: 'BATCH-2026-0914-B3',
              location: 'Factory Avenches Line 4',
              status: isContaminated ? 'RECALLED' : 'PASSED',
              metadata: {
                lot_number: lotNumber,
                quantity_kg_or_units: 6500,
              },
              children: [
                {
                  id: 'SHIP-995100',
                  name: 'Shipment #995100 - UK Boutique Logistics',
                  type: 'SHIPMENT',
                  code: 'SHIP-995100',
                  location: 'Calais Ferry Terminal',
                  status: isContaminated ? 'RECALLED' : 'PASSED',
                  metadata: {
                    timestamp: '2026-09-02 09:30 UTC',
                  },
                  children: [
                    {
                      id: 'MKT-UK',
                      name: 'United Kingdom Boutiques & E-Commerce',
                      type: 'CUSTOMER_MARKET',
                      code: 'MKT-GB-RETAIL',
                      location: 'London & Manchester',
                      status: isContaminated ? 'RECALLED' : 'PASSED',
                      metadata: {
                        quantity_kg_or_units: 32000,
                      },
                      children: [],
                    },
                  ],
                },
              ],
            },
          ],
        },
      ],
    };

    return rootSupplier;
  }

  /**
   * Executes food safety recall analysis and isolation workflow
   */
  static runRecallAnalysis(contaminatedLotNumber: string): RecallAnalysisResult {
    return {
      contaminatedLotNumber,
      ingredientName: 'Green Arabica Beans Single-Origin (Lot ' + contaminatedLotNumber + ')',
      supplierName: 'Alta Mogiana Coffee Cooperative (Brazil)',
      affectedFactories: [
        { id: 'FAC-VEVEY', name: 'Vevey Factory', country: 'Switzerland' },
        { id: 'FAC-AVENCHES', name: 'Avenches Nespresso Centre', country: 'Switzerland' },
      ],
      affectedBatches: [
        { batchNumber: 'BATCH-2026-0912-A1', skuName: 'Nescafé Gold 200g Jar', status: 'RECALLED' },
        { batchNumber: 'BATCH-2026-0914-B3', skuName: 'Nespresso Brazil Master Origin', status: 'RECALLED' },
      ],
      affectedShipments: [
        { trackingNumber: 'SHIP-994812', destinationMarket: 'Germany & France Retail', eta: 'In Transit / Quarantined' },
        { trackingNumber: 'SHIP-995100', destinationMarket: 'UK Boutiques & E-Commerce', eta: 'Quarantined Port of Dover' },
      ],
      affectedMarkets: ['Germany', 'France', 'United Kingdom'],
      estimatedRecallCostCHF: '1,450,000.00',
      actionSummary: `Targeted quality hold initiated across 2 factories, 2 batches, and 2 active shipments. Automated notification issued to retail distributors in Germany, France, and UK. Blocked GTIN scanner registration at distribution center gates.`,
    };
  }
}
