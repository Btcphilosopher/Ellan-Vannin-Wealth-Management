import Decimal from 'decimal.js';
import { CurrencyCode } from './types';

// Configure Decimal precision for global financial standards
Decimal.set({ precision: 28, rounding: Decimal.ROUND_HALF_UP });

export interface FXRateTable {
  [fromCurrency: string]: { [toCurrency: string]: Decimal };
}

// Fixed synthetic exchange rate matrix anchored on CHF (Nestora Group Base Currency)
export const FX_RATES_TO_CHF: Record<CurrencyCode, Decimal> = {
  CHF: new Decimal('1.000000'),
  EUR: new Decimal('0.952380'), // 1 EUR = 0.95238 CHF
  USD: new Decimal('0.877190'), // 1 USD = 0.87719 CHF
  GBP: new Decimal('1.123590'), // 1 GBP = 1.12359 CHF
  JPY: new Decimal('0.005950'), // 1 JPY = 0.00595 CHF
  CNY: new Decimal('0.123450'), // 1 CNY = 0.12345 CHF
  INR: new Decimal('0.010480'), // 1 INR = 0.01048 CHF
};

export class FinancialEngine {
  /**
   * Convert financial value from source currency to target currency
   */
  static convert(
    amount: string | number | Decimal,
    from: CurrencyCode,
    to: CurrencyCode
  ): Decimal {
    const amtDecimal = new Decimal(amount.toString());
    if (from === to) return amtDecimal;

    const fromRateInCHF = FX_RATES_TO_CHF[from];
    const toRateInCHF = FX_RATES_TO_CHF[to];

    // Convert to CHF first, then to target currency
    const inCHF = amtDecimal.mul(fromRateInCHF);
    const converted = inCHF.div(toRateInCHF);
    return converted.toDecimalPlaces(2);
  }

  /**
   * Format decimal value into localized currency string with explicit ISO code
   */
  static format(
    amount: string | number | Decimal,
    currency: CurrencyCode = 'CHF'
  ): string {
    const dec = new Decimal(amount.toString());
    const formatted = dec.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return `${currency} ${formatted}`;
  }

  /**
   * Calculate Gross Margin Percentage: ((Revenue - COGS) / Revenue) * 100
   */
  static calculateGrossMarginPct(revenue: string | Decimal, cogs: string | Decimal): Decimal {
    const rev = new Decimal(revenue.toString());
    const cost = new Decimal(cogs.toString());
    if (rev.isZero()) return new Decimal('0.00');
    
    const margin = rev.sub(cost);
    return margin.div(rev).mul(100).toDecimalPlaces(2);
  }

  /**
   * Calculate SKU Cost Breakdown
   */
  static calculateSKUCost(
    materialCost: string | Decimal,
    conversionCost: string | Decimal,
    packagingCost: string | Decimal,
    wasteCost: string | Decimal,
    energyCost: string | Decimal,
    logisticsCost: string | Decimal
  ): {
    totalCOGS: Decimal;
    breakdownPercentages: Record<string, Decimal>;
  } {
    const mat = new Decimal(materialCost.toString());
    const conv = new Decimal(conversionCost.toString());
    const pack = new Decimal(packagingCost.toString());
    const waste = new Decimal(wasteCost.toString());
    const energy = new Decimal(energyCost.toString());
    const log = new Decimal(logisticsCost.toString());

    const totalCOGS = mat.add(conv).add(pack).add(waste).add(energy).add(log);

    if (totalCOGS.isZero()) {
      return {
        totalCOGS: new Decimal('0.00'),
        breakdownPercentages: {
          material: new Decimal('0'),
          conversion: new Decimal('0'),
          packaging: new Decimal('0'),
          waste: new Decimal('0'),
          energy: new Decimal('0'),
          logistics: new Decimal('0'),
        },
      };
    }

    return {
      totalCOGS,
      breakdownPercentages: {
        material: mat.div(totalCOGS).mul(100).toDecimalPlaces(1),
        conversion: conv.div(totalCOGS).mul(100).toDecimalPlaces(1),
        packaging: pack.div(totalCOGS).mul(100).toDecimalPlaces(1),
        waste: waste.div(totalCOGS).mul(100).toDecimalPlaces(1),
        energy: energy.div(totalCOGS).mul(100).toDecimalPlaces(1),
        logistics: log.div(totalCOGS).mul(100).toDecimalPlaces(1),
      },
    };
  }

  /**
   * Calculate Net Present Value (NPV) for Capital Allocation Projects
   */
  static calculateNPV(
    initialInvestment: string | Decimal,
    cashFlows: (string | Decimal)[],
    discountRatePct: number = 8.5
  ): Decimal {
    const init = new Decimal(initialInvestment.toString()).neg();
    const rate = new Decimal(discountRatePct).div(100);

    let npv = init;
    cashFlows.forEach((cf, idx) => {
      const year = idx + 1;
      const cfDec = new Decimal(cf.toString());
      const discountFactor = Decimal.add(1, rate).pow(year);
      npv = npv.add(cfDec.div(discountFactor));
    });

    return npv.toDecimalPlaces(2);
  }
}
