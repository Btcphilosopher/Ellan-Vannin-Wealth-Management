import { AuditRecord, UserRole } from './types';

export class AuditEngine {
  private static auditLogs: AuditRecord[] = [];

  static logEvent(params: {
    who: string;
    role: UserRole;
    what: string;
    where_module: string;
    why_reason: string;
    before_state?: string;
    after_state?: string;
    approval_ref?: string;
    ip_address?: string;
  }): AuditRecord {
    const record: AuditRecord = {
      audit_id: `AUD-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      who: params.who,
      role: params.role,
      what: params.what,
      when: new Date().toISOString(),
      where_module: params.where_module,
      why_reason: params.why_reason,
      before_state: params.before_state,
      after_state: params.after_state,
      approval_ref: params.approval_ref,
      ip_address: params.ip_address || '127.0.0.1 (Nestora-Kernel)',
    };

    // Append-only guarantee
    Object.freeze(record);
    this.auditLogs.unshift(record);
    return record;
  }

  static getLogs(): AuditRecord[] {
    return [...this.auditLogs];
  }

  /**
   * Simple RBAC check
   */
  static checkPermission(role: UserRole, action: string): boolean {
    const adminRoles: UserRole[] = ['Executive', 'Administrator'];
    if (adminRoles.includes(role)) return true;

    if (action.startsWith('FINANCE') && ['Finance', 'Auditor'].includes(role)) return true;
    if (action.startsWith('FACTORY') && ['FactoryManager', 'Operator', 'Engineer', 'QualityManager'].includes(role)) return true;
    if (action.startsWith('QUALITY') && ['QualityManager', 'Auditor', 'R&D'].includes(role)) return true;
    if (action.startsWith('PROCUREMENT') && ['Procurement', 'SupplyChainManager'].includes(role)) return true;

    return false;
  }
}
