import Decimal from 'decimal.js';
import { FinancialEngine } from './decimal';
import { AIRecommendation } from './types';

export interface Scenario68Output {
  scenarioId: string;
  triggerEvent: string;
  demandSpikePct: number;
  affectedMarkets: string[];
  impactAssessment: {
    weeklyDemandIncreaseUnits: number;
    daysOfInventoryRemaining: number;
    projectedStockoutDate: string;
    unmetRevenueRiskCHF: string;
    factoryUtilizationBeforePct: number;
    factoryUtilizationAfterPct: number;
    requiredRawCoffeeBeansTons: number;
    procurementSpotBuyCostCHF: string;
    additionalWorkingCapitalCHF: string;
  };
  executiveAIProposedStrategies: AIRecommendation[];
}

export class ExecutiveScenarioEngine {
  static runCoffeeSpikeScenario(): Scenario68Output {
    const demandSpikePct = 12; // +12% Demand Spike in Coffee Category

    const stratA: AIRecommendation = {
      recommendation_id: 'REC-STRAT-2026-001',
      agent_name: 'ExecutiveAgent',
      model_id: 'gemini-3.6-enterprise-flash',
      input_data_version: 'v2026.09.12-LIVE',
      title: 'Strategy A: Maximize Line 3 Capacity at Vevey Factory & Spot Purchase Arabica',
      reasoning_summary:
        'Reallocate 150 hours of downtime buffer at Vevey Line 3 and execute targeted spot procurement of 1,200 tons Arabica beans via Alta Mogiana Cooperative. Prevents 98% of stockout risk in Germany and France.',
      confidence: 0.94,
      expected_impact_chf: '+ CHF 14,200,000 Net Margin Preserved',
      risk_assessment: 'LOW',
      proposed_action:
        'Authorize CHF 4,500,000 spot procurement PO #88201 and approve overtime schedule for Vevey Factory Shift C.',
      human_owner: 'Laurent Freixe (Zone President Europe)',
      approval_status: 'PROPOSED',
      timestamp: new Date().toISOString(),
    };

    const stratB: AIRecommendation = {
      recommendation_id: 'REC-STRAT-2026-002',
      agent_name: 'SupplyChainAgent',
      model_id: 'gemini-3.6-enterprise-flash',
      input_data_version: 'v2026.09.12-LIVE',
      title: 'Strategy B: Inter-Zone Buffer Transfer from AMERICAS (Toluca Factory) Air-Freight',
      reasoning_summary:
        'Air-freight 450 tons of finished Nescafé Gold inventory from Toluca, Mexico hub to Frankfurt Distribution Center. Instant 5-day stock recovery but increases freight COGS by CHF 1.8M.',
      confidence: 0.88,
      expected_impact_chf: '+ CHF 8,900,000 Net Revenue Preserved',
      risk_assessment: 'MEDIUM',
      proposed_action:
        'Charter 3 Boeing 777F cargo flights from Mexico City to Frankfurt and adjust Scope 3 CO2 emissions budget (+140 tons CO2).',
      human_owner: 'Global Supply Chain Director',
      approval_status: 'PROPOSED',
      timestamp: new Date().toISOString(),
    };

    const stratC: AIRecommendation = {
      recommendation_id: 'REC-STRAT-2026-003',
      agent_name: 'MarketingAgent',
      model_id: 'gemini-3.6-enterprise-flash',
      input_data_version: 'v2026.09.12-LIVE',
      title: 'Strategy C: Tactical Promotion Suppression & Premium Price Adjustment (+3.5%)',
      reasoning_summary:
        'Temporarily pause planned Q4 trade promotions in retail channels to dampen artificial demand spike while increasing gross margin by 180 basis points.',
      confidence: 0.81,
      expected_impact_chf: '+ CHF 6,400,000 Margin Protection',
      risk_assessment: 'HIGH',
      proposed_action:
        'Issue trade policy notification to European retail key accounts and modify promo schedule in SAP/Nestora Sales module.',
      human_owner: 'Head of Global Commercial Operations',
      approval_status: 'PROPOSED',
      timestamp: new Date().toISOString(),
    };

    return {
      scenarioId: 'SCENARIO-COFFEE-SPIKE-12PCT',
      triggerEvent: 'Coffee Category Global Demand Surge (+12.4% YoY)',
      demandSpikePct,
      affectedMarkets: ['Germany', 'France', 'United Kingdom', 'Switzerland', 'Italy'],
      impactAssessment: {
        weeklyDemandIncreaseUnits: 1420000,
        daysOfInventoryRemaining: 11, // Standard safety stock is 25 days
        projectedStockoutDate: '2026-09-23',
        unmetRevenueRiskCHF: FinancialEngine.format(new Decimal('18500000.00'), 'CHF'),
        factoryUtilizationBeforePct: 84.5,
        factoryUtilizationAfterPct: 98.2,
        requiredRawCoffeeBeansTons: 1250,
        procurementSpotBuyCostCHF: FinancialEngine.format(new Decimal('4500000.00'), 'CHF'),
        additionalWorkingCapitalCHF: FinancialEngine.format(new Decimal('6200000.00'), 'CHF'),
      },
      executiveAIProposedStrategies: [stratA, stratB, stratC],
    };
  }
}
