import {
  Organization,
  Zone,
  Market,
  Category,
  Brand,
  Product,
  SKU,
  Supplier,
  Factory,
  ProductionLine,
  Batch,
  Shipment,
  InnovationProject,
  SustainabilityMetrics,
  FinancialMetrics,
  AuditRecord,
  UserRole,
  ControlTowerMetrics,
} from './types';
import { FinancialEngine } from './decimal';
import Decimal from 'decimal.js';

export interface NestoraEnterpriseState {
  organization: Organization;
  zones: Zone[];
  markets: Market[];
  categories: Category[];
  brands: Brand[];
  products: Product[];
  skus: SKU[];
  suppliers: Supplier[];
  factories: Factory[];
  lines: ProductionLine[];
  batches: Batch[];
  shipments: Shipment[];
  innovationProjects: InnovationProject[];
  sustainability: SustainabilityMetrics;
  groupFinancials: FinancialMetrics;
  controlTower: ControlTowerMetrics;
  auditLogs: AuditRecord[];
  activeScenarioId?: string;
  userRole: UserRole;
  selectedZone: string;
}

// Global deterministic seed data generator
function createInitialState(): NestoraEnterpriseState {
  const organization: Organization = {
    id: 'ORG-NESTORA-GLOBAL',
    code: 'NESTORA-GRP',
    name: 'Nestora Group S.A.',
    headquarters: 'Vevey, Vaud, Switzerland',
    base_currency: 'CHF',
    created_at: '2026-01-01T00:00:00Z',
    updated_at: new Date().toISOString(),
    version: 1,
    status: 'ACTIVE',
    owner: 'Group Executive Board',
    source_system: 'NESTORA-CORE',
  };

  const zones: Zone[] = [
    {
      id: 'ZONE_GLOBAL',
      organization_id: organization.id,
      code: 'ZONE_GLOBAL',
      name: 'Nestora Global Headquarters',
      headquarters_city: 'Vevey, Switzerland',
      zone_president: 'Laurent Freixe (CEO)',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: new Date().toISOString(),
      version: 1,
      status: 'ACTIVE',
      owner: 'CEO',
      source_system: 'NESTORA-CORE',
    },
    {
      id: 'ZONE_AMERICAS',
      organization_id: organization.id,
      code: 'ZONE_AMERICAS',
      name: 'Zone Americas (North & Latin America)',
      headquarters_city: 'Arlington, Virginia, USA',
      zone_president: 'Steve Presley',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: new Date().toISOString(),
      version: 1,
      status: 'ACTIVE',
      owner: 'Zone President AMERICAS',
      source_system: 'NESTORA-CORE',
    },
    {
      id: 'ZONE_EUROPE',
      organization_id: organization.id,
      code: 'ZONE_EUROPE',
      name: 'Zone Europe',
      headquarters_city: 'Vevey, Switzerland',
      zone_president: 'Marco Settembri',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: new Date().toISOString(),
      version: 1,
      status: 'ACTIVE',
      owner: 'Zone President EUROPE',
      source_system: 'NESTORA-CORE',
    },
    {
      id: 'ZONE_AOA',
      organization_id: organization.id,
      code: 'ZONE_AOA',
      name: 'Zone Asia, Oceania & Africa',
      headquarters_city: 'Singapore',
      zone_president: 'Remy Ejel',
      created_at: '2026-01-01T00:00:00Z',
      updated_at: new Date().toISOString(),
      version: 1,
      status: 'ACTIVE',
      owner: 'Zone President AOA',
      source_system: 'NESTORA-CORE',
    },
  ];

  const markets: Market[] = [
    { id: 'MKT-CH', zone_id: 'ZONE_EUROPE', country_code: 'CHE', name: 'Switzerland', currency: 'CHF', revenue_target_chf: '1450000000.00', id_code: 'MKT-CH', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' } as Market,
    { id: 'MKT-DE', zone_id: 'ZONE_EUROPE', country_code: 'DEU', name: 'Germany', currency: 'EUR', revenue_target_chf: '3800000000.00', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' } as Market,
    { id: 'MKT-US', zone_id: 'ZONE_AMERICAS', country_code: 'USA', name: 'United States', currency: 'USD', revenue_target_chf: '28400000000.00', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' } as Market,
    { id: 'MKT-BR', zone_id: 'ZONE_AMERICAS', country_code: 'BRA', name: 'Brazil', currency: 'USD', revenue_target_chf: '4200000000.00', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' } as Market,
    { id: 'MKT-CN', zone_id: 'ZONE_AOA', country_code: 'CHN', name: 'China', currency: 'CNY', revenue_target_chf: '6100000000.00', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' } as Market,
    { id: 'MKT-JP', zone_id: 'ZONE_AOA', country_code: 'JPN', name: 'Japan', currency: 'JPY', revenue_target_chf: '2900000000.00', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' } as Market,
  ];

  const categories: Category[] = [
    { id: 'CAT-COFFEE', domain: 'COFFEE', name: 'Coffee & Coffee Systems', description: 'Nescafé, Nespresso, Starbucks at Home', global_lead: 'David Rennie', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'CAT-PETCARE', domain: 'PETCARE', name: 'Petcare', description: 'Purina Pro Plan, Felix, Gourmet, ONE', global_lead: 'Bernard Meunier', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'CAT-NUTRITION', domain: 'NUTRITION', name: 'Nutrition & Health Science', description: 'Infant Nutrition, Medical Nutrition, Vitamins', global_lead: 'Anna Mohl', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'CAT-CONF', domain: 'CONFECTIONERY', name: 'Confectionery', description: 'KitKat, Cailler, Quality Street, Smarties', global_lead: 'Alexander von Maillot', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'CAT-WATER', domain: 'WATER_BEVERAGES', name: 'Water & Premium Beverages', description: 'Perrier, S.Pellegrino, Acqua Panna, Maison Perrier', global_lead: 'Muriel Lienau', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'CAT-PREP', domain: 'PREPARED_DISHES', name: 'Prepared Dishes & Cooking Aids', description: 'Maggi, Stouffer’s, Lean Cuisine', global_lead: 'Patrice Bula', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
  ];

  const brands: Brand[] = [
    { id: 'BR-NESCAFE', category_domain: 'COFFEE', code: 'NESCAFE', name: 'Nescafé', slogan: 'Good ideas start with a Nescafé', global_market_share_pct: 22.4, health_score: 94, annual_revenue_chf: '13800000000.00', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'BR-NESPRESSO', category_domain: 'COFFEE', code: 'NESPRESSO', name: 'Nespresso', slogan: 'What else?', global_market_share_pct: 18.1, health_score: 96, annual_revenue_chf: '6400000000.00', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'BR-PURINA', category_domain: 'PETCARE', code: 'PURINA', name: 'Purina', slogan: 'Your Pet, Our Passion', global_market_share_pct: 28.6, health_score: 98, annual_revenue_chf: '18200000000.00', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'BR-KITKAT', category_domain: 'CONFECTIONERY', code: 'KITKAT', name: 'KitKat', slogan: 'Have a break, have a KitKat', global_market_share_pct: 15.2, health_score: 92, annual_revenue_chf: '2200000000.00', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'BR-MAGGI', category_domain: 'PREPARED_DISHES', code: 'MAGGI', name: 'Maggi', slogan: '2-Minute Noodles & Seasonings', global_market_share_pct: 31.0, health_score: 91, annual_revenue_chf: '5800000000.00', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'BR-GERBER', category_domain: 'NUTRITION', code: 'GERBER', name: 'Gerber', slogan: 'Anything for Baby', global_market_share_pct: 24.5, health_score: 89, annual_revenue_chf: '3400000000.00', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
  ];

  const products: Product[] = [
    { id: 'PROD-NESCAFE-GOLD', brand_id: 'BR-NESCAFE', code: 'PROD-NGOLD', name: 'Nescafé Gold Pure Soluble Coffee', category: 'COFFEE', stage: 'MARKET_LAUNCH', target_launch_date: '2024-01-01', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'PROD-NESPRESSO-ARPEGGIO', brand_id: 'BR-NESPRESSO', code: 'PROD-NARP', name: 'Nespresso Original Ispirazione Firenze Arpeggio', category: 'COFFEE', stage: 'MARKET_LAUNCH', target_launch_date: '2023-05-10', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'PROD-PURINA-PROPLAN', brand_id: 'BR-PURINA', code: 'PROD-PPP', name: 'Purina Pro Plan Adult Shredded Blend Salmon & Rice', category: 'PETCARE', stage: 'MARKET_LAUNCH', target_launch_date: '2023-08-15', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'PROD-KITKAT-4F', brand_id: 'BR-KITKAT', code: 'PROD-KK4F', name: 'KitKat 4-Finger Milk Chocolate Bar 45g', category: 'CONFECTIONERY', stage: 'MARKET_LAUNCH', target_launch_date: '2022-03-01', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
  ];

  const skus: SKU[] = [
    { id: 'SKU-7613032123456', product_id: 'PROD-NESCAFE-GOLD', gtin: '7613032123456', sku_code: 'NGOLD-200G', name: 'Nescafé Gold 200g Glass Jar', pack_size: '200g', format: 'Glass Jar', unit_price_chf: '8.50', cogs_per_unit_chf: '3.91', shelf_life_days: 730, created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'SKU-7613032998877', product_id: 'PROD-NESPRESSO-ARPEGGIO', gtin: '7613032998877', sku_code: 'NARP-10S', name: 'Nespresso Arpeggio Capsules 10s Sleeve', pack_size: '50g (10x5g)', format: 'Aluminum Pod Sleeve', unit_price_chf: '4.80', cogs_per_unit_chf: '1.51', shelf_life_days: 365, created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'SKU-7613038112233', product_id: 'PROD-KITKAT-4F', gtin: '7613038112233', sku_code: 'KK4F-45G', name: 'KitKat 4-Finger Milk Chocolate 45g', pack_size: '45g', format: 'Flowwrap Paper Packaging', unit_price_chf: '1.20', cogs_per_unit_chf: '0.45', shelf_life_days: 365, created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
  ];

  const suppliers: Supplier[] = [
    { id: 'SUP-7819', code: 'SUP-BRAZIL-COFFEE-01', name: 'Alta Mogiana Coffee Cooperative', country: 'Brazil', commodities_supplied: ['Green Coffee Beans Arabica'], quality_score: 96, delivery_score: 94, capacity_score: 92, sustainability_score: 95, risk_score: 12, composite_score: 94.8, status: 'PREFERRED', created_at: '', updated_at: '', version: 1, source_system: 'NESTORA-PROC' } as Supplier,
    { id: 'SUP-8802', code: 'SUP-COTE-DIVOIRE-COCOA', name: 'Sassandra Sustainable Cocoa Union', country: 'Côte d’Ivoire', commodities_supplied: ['Raw Cocoa Beans', 'Cocoa Butter'], quality_score: 91, delivery_score: 88, capacity_score: 90, sustainability_score: 89, risk_score: 28, composite_score: 89.2, status: 'QUALIFIED', created_at: '', updated_at: '', version: 1, source_system: 'NESTORA-PROC' } as Supplier,
    { id: 'SUP-9012', code: 'SUP-GERMANY-PACKAGING', name: 'Amcor Flexibles Europe', country: 'Germany', commodities_supplied: ['Paper Packaging', 'Recyclable Foils'], quality_score: 98, delivery_score: 97, capacity_score: 95, sustainability_score: 94, risk_score: 8, composite_score: 96.2, status: 'PREFERRED', created_at: '', updated_at: '', version: 1, source_system: 'NESTORA-PROC' } as Supplier,
  ];

  const factories: Factory[] = [
    { id: 'FAC-VEVEY', code: 'FAC-CH-VEVEY', name: 'Vevey Excellence Factory & R&D Hub', zone_id: 'ZONE_EUROPE', country: 'Switzerland', lat: 46.4628, lng: 6.8419, category_capabilities: ['COFFEE', 'CONFECTIONERY'], annual_capacity_tons: 120000, current_utilization_pct: 84.5, oee_pct: 82.4, water_m3_per_ton: 1.42, energy_kwh_per_ton: 310, health_status: 'GREEN', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'FAC-AVENCHES', code: 'FAC-CH-AVENCHES', name: 'Avenches Nespresso Centre of Excellence', zone_id: 'ZONE_EUROPE', country: 'Switzerland', lat: 46.8804, lng: 7.0381, category_capabilities: ['COFFEE'], annual_capacity_tons: 85000, current_utilization_pct: 91.2, oee_pct: 86.8, water_m3_per_ton: 0.98, energy_kwh_per_ton: 280, health_status: 'GREEN', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'FAC-TOLUCA', code: 'FAC-MX-TOLUCA', name: 'Toluca Coffee & Dairy Production Campus', zone_id: 'ZONE_AMERICAS', country: 'Mexico', lat: 19.2826, lng: -99.6557, category_capabilities: ['COFFEE', 'MILK_PRODUCTS'], annual_capacity_tons: 195000, current_utilization_pct: 88.0, oee_pct: 74.2, water_m3_per_ton: 2.10, energy_kwh_per_ton: 420, health_status: 'AMBER', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'FAC-KOBE', code: 'FAC-JP-KOBE', name: 'Kobe Beverage & Confectionery Plant', zone_id: 'ZONE_AOA', country: 'Japan', lat: 34.6901, lng: 135.1955, category_capabilities: ['COFFEE', 'CONFECTIONERY'], annual_capacity_tons: 65000, current_utilization_pct: 79.0, oee_pct: 84.1, water_m3_per_ton: 1.15, energy_kwh_per_ton: 330, health_status: 'GREEN', created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
  ];

  const lines: ProductionLine[] = [
    {
      id: 'LINE-VEVEY-02', factory_id: 'FAC-VEVEY', line_code: 'VEVEY-L2', name: 'Nescafé Gold High-Speed Spray Drying & Agglomeration Line 2', capacity_units_per_hr: 12000, current_speed_pct: 96, availability_pct: 92.0, performance_pct: 94.5, quality_pct: 99.2, oee_pct: 86.2, active_sku_id: 'SKU-7613032123456',
      machines: [
        { machine_id: 'MAC-ROASTER-01', name: 'Probat Industrial Bean Roaster 5000', speed_units_per_min: 200, temperature_c: 210, pressure_bar: 3.2, vibration_mm_s: 0.8, status: 'RUNNING', last_maintenance: '2026-08-15', mtbf_hours: 1400, mttr_hours: 2.5 },
        { machine_id: 'MAC-FILLER-02', name: 'Bosch High-Speed Glass Jar Vacuum Filler', speed_units_per_min: 200, temperature_c: 22, pressure_bar: 1.0, vibration_mm_s: 0.4, status: 'RUNNING', last_maintenance: '2026-08-20', mtbf_hours: 2200, mttr_hours: 1.2 },
      ],
      created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: ''
    },
    {
      id: 'LINE-TOLUCA-02', factory_id: 'FAC-TOLUCA', line_code: 'TOLUCA-L2', name: 'Toluca Can & Jar Filling Line 2', capacity_units_per_hr: 9000, current_speed_pct: 80, availability_pct: 78.0, performance_pct: 82.0, quality_pct: 98.0, oee_pct: 62.6, active_sku_id: 'SKU-7613032123456',
      machines: [
        { machine_id: 'MAC-SEALER-02', name: 'Toluca High-Pressure Jar Sealer', speed_units_per_min: 150, temperature_c: 180, pressure_bar: 4.8, vibration_mm_s: 2.8, status: 'FAULT', last_maintenance: '2026-07-02', mtbf_hours: 450, mttr_hours: 6.0 },
      ],
      created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: ''
    },
  ];

  const batches: Batch[] = [
    { id: 'BATCH-2026-0912-A1', batch_number: 'BATCH-2026-0912-A1', factory_id: 'FAC-VEVEY', production_line_id: 'LINE-VEVEY-02', sku_id: 'SKU-7613032123456', recipe_id: 'REC-NGOLD-V2', quantity_units: 92500, status: 'RUNNING', start_time: '2026-09-12 04:00 UTC', ingredient_lots_used: [{ ingredient_id: 'ING-RAW-COFFEE-ARABICA', lot_number: 'LOT-COFFEE-2026-88', supplier_id: 'SUP-7819' }], created_at: '', updated_at: '', version: 1, owner: '', source_system: '' },
    { id: 'BATCH-2026-0910-B4', batch_number: 'BATCH-2026-0910-B4', factory_id: 'FAC-AVENCHES', production_line_id: 'LINE-AVENCHES-01', sku_id: 'SKU-7613032998877', recipe_id: 'REC-NARP-V1', quantity_units: 140000, status: 'PACKAGED', start_time: '2026-09-10 08:00 UTC', ingredient_lots_used: [{ ingredient_id: 'ING-RAW-COFFEE-ARABICA', lot_number: 'LOT-COFFEE-2026-77', supplier_id: 'SUP-7819' }], created_at: '', updated_at: '', version: 1, owner: '', source_system: '' },
  ];

  const shipments: Shipment[] = [
    { id: 'SHIP-994812', tracking_number: 'SHIP-994812', origin_factory_id: 'FAC-VEVEY', destination_dc_id: 'DC-FRANKFURT', destination_market_id: 'MKT-DE', skus: [{ sku_id: 'SKU-7613032123456', quantity: 45000, batch_number: 'BATCH-2026-0912-A1' }], departure_time: '2026-09-12 06:30 UTC', eta: '2026-09-13 14:00 UTC', temperature_c: 18.4, is_cold_chain: false, status: 'IN_TRANSIT', co2_kg: 840, created_at: '', updated_at: '', version: 1, owner: '', source_system: '' },
    { id: 'SHIP-995100', tracking_number: 'SHIP-995100', origin_factory_id: 'FAC-AVENCHES', destination_dc_id: 'DC-DOVER-UK', destination_market_id: 'MKT-GB', skus: [{ sku_id: 'SKU-7613032998877', quantity: 32000, batch_number: 'BATCH-2026-0910-B4' }], departure_time: '2026-09-11 22:00 UTC', eta: '2026-09-12 18:30 UTC', is_cold_chain: false, status: 'IN_TRANSIT', co2_kg: 610, created_at: '', updated_at: '', version: 1, owner: '', source_system: '' },
  ];

  const innovationProjects: InnovationProject[] = [
    { id: 'INV-2026-01', code: 'PROJ-NESPRESSO-OAT', name: 'Nespresso Barista Plant-Based Oat Pod Innovation', category: 'COFFEE', stage: 'PILOT', lead_scientist: 'Dr. Claire Laurent (Nestlé R&D Lausanne)', commercial_score: 92, technical_score: 88, consumer_score: 95, margin_score: 86, sustainability_score: 98, overall_score: 91.8, budget_chf: '14500000.00', target_launch_year: 2027, created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'INV-2026-02', code: 'PROJ-KITKAT-PAPER', name: 'KitKat 100% Recyclable Paper Monomaterial Barrier Wrap', category: 'CONFECTIONERY', stage: 'FACTORY_SCALE_UP', lead_scientist: 'Dr. Thomas Weber (Nestlé Packaging Institute)', commercial_score: 89, technical_score: 94, consumer_score: 91, margin_score: 82, sustainability_score: 99, overall_score: 91.0, budget_chf: '22000000.00', target_launch_year: 2026, created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
    { id: 'INV-2026-03', code: 'PROJ-PURINA-MICROBIOME', name: 'Purina Pro Plan Gut Microbiome Longevity Supplement', category: 'PETCARE', stage: 'SENSORY_TEST', lead_scientist: 'Dr. Sarah Jenkins (Purina PetCare St. Louis R&D)', commercial_score: 96, technical_score: 90, consumer_score: 94, margin_score: 92, sustainability_score: 88, overall_score: 92.0, budget_chf: '18000000.00', target_launch_year: 2027, created_at: '', updated_at: '', version: 1, status: 'ACTIVE', owner: '', source_system: '' },
  ];

  const sustainability: SustainabilityMetrics = {
    scope_1_ghg_tons: 2840000,
    scope_2_ghg_tons: 1420000,
    scope_3_ghg_tons: 91200000,
    total_carbon_footprint_tons: 95460000,
    water_withdrawn_m3: 112000000,
    water_recycled_pct: 42.8,
    recyclable_packaging_pct: 91.4,
    virgin_plastic_reduction_tons: 148000,
    regenerative_ag_sourcing_pct: 34.2,
  };

  const groupFinancials: FinancialMetrics = {
    gross_revenue_chf: FinancialEngine.format(new Decimal('92400000000.00'), 'CHF'),
    net_revenue_chf: FinancialEngine.format(new Decimal('89800000000.00'), 'CHF'),
    cogs_chf: FinancialEngine.format(new Decimal('48200000000.00'), 'CHF'),
    gross_margin_chf: FinancialEngine.format(new Decimal('41600000000.00'), 'CHF'),
    gross_margin_pct: 46.3,
    ebitda_chf: FinancialEngine.format(new Decimal('18400000000.00'), 'CHF'),
    ebit_chf: FinancialEngine.format(new Decimal('15600000000.00'), 'CHF'),
    free_cash_flow_chf: FinancialEngine.format(new Decimal('10800000000.00'), 'CHF'),
    working_capital_chf: FinancialEngine.format(new Decimal('6400000000.00'), 'CHF'),
    roic_pct: 14.8,
    capex_chf: FinancialEngine.format(new Decimal('4200000000.00'), 'CHF'),
    opex_chf: FinancialEngine.format(new Decimal('26000000000.00'), 'CHF'),
  };

  const controlTower: ControlTowerMetrics = {
    total_active_shipments: 1420,
    delayed_shipments: 14,
    disruption_events_active: 2,
    global_inventory_days: 22,
    service_level_pct: 97.4,
    cold_chain_alerts: 1,
  };

  const auditLogs: AuditRecord[] = [
    { audit_id: 'AUD-88001', who: 'Laurent Freixe', role: 'Executive', what: 'SYSTEM_BOOT', when: '2026-09-12 06:00:00 UTC', where_module: 'NESTORA-CORE-KERNEL', why_reason: 'Enterprise Operating System Initialized', ip_address: '10.240.0.12' },
    { audit_id: 'AUD-88002', who: 'Marco Settembri', role: 'Executive', what: 'SCENARIO_INSPECTION', when: '2026-09-12 06:12:00 UTC', where_module: 'EXECUTIVE_COMMAND_CENTER', why_reason: 'Inspected Zone Europe Coffee Margin Waterfall', ip_address: '10.240.4.88' },
  ];

  return {
    organization,
    zones,
    markets,
    categories,
    brands,
    products,
    skus,
    suppliers,
    factories,
    lines,
    batches,
    shipments,
    innovationProjects,
    sustainability,
    groupFinancials,
    controlTower,
    auditLogs,
    userRole: 'Executive',
    selectedZone: 'ZONE_GLOBAL',
  };
}

export const initialEnterpriseStore = createInitialState();
