/**
 * NESTORA ENTERPRISE OS - Canonical Data Model Definitions
 * Global Food, Nutrition, Manufacturing & Consumer Enterprise Operating System
 */

export type CurrencyCode = 'CHF' | 'EUR' | 'USD' | 'GBP' | 'JPY' | 'CNY' | 'INR';

export type ZoneId = 'ZONE_AMERICAS' | 'ZONE_EUROPE' | 'ZONE_AOA' | 'ZONE_GLOBAL';

export type CategoryDomain =
  | 'COFFEE'
  | 'PETCARE'
  | 'NUTRITION'
  | 'FOOD_SNACKS'
  | 'WATER_BEVERAGES'
  | 'CONFECTIONERY'
  | 'PREPARED_DISHES'
  | 'MILK_PRODUCTS'
  | 'ICE_CREAM'
  | 'POWDERED_BEVERAGES';

export type UserRole =
  | 'Executive'
  | 'Finance'
  | 'Procurement'
  | 'FactoryManager'
  | 'QualityManager'
  | 'SupplyChainManager'
  | 'R&D'
  | 'Marketing'
  | 'Sales'
  | 'DataScientist'
  | 'Engineer'
  | 'Operator'
  | 'Auditor'
  | 'Administrator';

export type ProductLifecycleStage =
  | 'IDEA'
  | 'CONCEPT'
  | 'RESEARCH'
  | 'FORMULATION'
  | 'PROTOTYPE'
  | 'SENSORY_TEST'
  | 'NUTRITION_VALIDATION'
  | 'SAFETY_VALIDATION'
  | 'PACKAGING'
  | 'REGULATORY_REVIEW'
  | 'PILOT'
  | 'FACTORY_SCALE_UP'
  | 'MARKET_LAUNCH'
  | 'POST_LAUNCH_REVIEW';

export type BatchStatus =
  | 'PLANNED'
  | 'RELEASED'
  | 'MATERIALS_READY'
  | 'RUNNING'
  | 'QUALITY_HOLD'
  | 'QUALITY_RELEASED'
  | 'PACKAGED'
  | 'COMPLETED';

export type QualityStatus = 'PENDING' | 'PASSED' | 'FAILED' | 'ON_HOLD' | 'RECALLED';

export type HealthStatus = 'GREEN' | 'AMBER' | 'RED';

export interface BaseEntity {
  id: string;
  created_at: string;
  updated_at: string;
  version: number;
  status: string;
  owner: string;
  source_system: string;
  audit_metadata?: Record<string, unknown>;
}

// 05. Global Organization
export interface Organization extends BaseEntity {
  code: string;
  name: string;
  headquarters: string;
  base_currency: CurrencyCode;
}

export interface Zone extends BaseEntity {
  organization_id: string;
  code: ZoneId;
  name: string;
  headquarters_city: string;
  zone_president: string;
}

export interface Market extends BaseEntity {
  zone_id: ZoneId;
  country_code: string;
  name: string;
  currency: CurrencyCode;
  revenue_target_chf: string; // Decimal string
}

export interface BusinessUnit extends BaseEntity {
  market_id: string;
  name: string;
  head_of_unit: string;
}

// 06. Categories & Brands
export interface Category extends BaseEntity {
  domain: CategoryDomain;
  name: string;
  description: string;
  global_lead: string;
}

export interface Brand extends BaseEntity {
  category_domain: CategoryDomain;
  code: string;
  name: string;
  slogan: string;
  global_market_share_pct: number;
  health_score: number;
  annual_revenue_chf: string; // Decimal string
}

// 08 & 09. Product, Recipe, Ingredients
export interface Product extends BaseEntity {
  brand_id: string;
  code: string;
  name: string;
  category: CategoryDomain;
  stage: ProductLifecycleStage;
  target_launch_date: string;
}

export interface SKU extends BaseEntity {
  product_id: string;
  gtin: string;
  sku_code: string;
  name: string;
  pack_size: string;
  format: string;
  unit_price_chf: string;
  cogs_per_unit_chf: string;
  min_temperature_c?: number;
  max_temperature_c?: number;
  shelf_life_days: number;
}

export interface Ingredient extends BaseEntity {
  code: string;
  name: string;
  type: 'RAW_MATERIAL' | 'PACKAGING' | 'ADDITIVE';
  unit_of_measure: string;
  allergens: string[];
  unit_cost_chf: string;
  origin_country: string;
}

export interface RecipeItem {
  ingredient_id: string;
  ingredient_name: string;
  quantity_kg: number;
  percentage: number;
  cost_per_kg_chf: string;
  allergens: string[];
}

export interface Recipe extends BaseEntity {
  sku_id: string;
  recipe_code: string;
  version_number: number;
  items: RecipeItem[];
  batch_size_kg: number;
  total_material_cost_chf: string;
  conversion_cost_chf: string;
  waste_cost_chf: string;
  energy_cost_chf: string;
  unit_cost_chf: string;
  is_immutable: boolean;
}

// 10. Nutrition
export interface NutritionProfile extends BaseEntity {
  sku_id: string;
  calories_kcal: number;
  protein_g: number;
  carbs_g: number;
  fat_g: number;
  saturated_fat_g: number;
  sugar_g: number;
  fiber_g: number;
  sodium_mg: number;
  nutri_score: 'A' | 'B' | 'C' | 'D' | 'E';
}

// 13 & 14. Procurement & Commodities
export interface Supplier extends BaseEntity {
  code: string;
  name: string;
  country: string;
  commodities_supplied: string[];
  quality_score: number; // 0-100
  delivery_score: number;
  capacity_score: number;
  sustainability_score: number;
  risk_score: number;
  composite_score: number;
  status: 'QUALIFIED' | 'PREFERRED' | 'UNDER_REVIEW' | 'BLOCKED';
}

export interface CommodityPrice extends BaseEntity {
  commodity: 'COFFEE' | 'COCOA' | 'MILK' | 'GRAINS' | 'SUGAR' | 'OIL' | 'PACKAGING_RESIN' | 'ENERGY';
  spot_price_chf_ton: string;
  contract_price_chf_ton: string;
  hedged_price_chf_ton: string;
  forecast_price_chf_ton: string;
  delta_30d_pct: number;
}

// 15 - 19. Factory, Lines, OEE & Digital Twin
export interface Factory extends BaseEntity {
  code: string;
  name: string;
  zone_id: ZoneId;
  country: string;
  lat: number;
  lng: number;
  category_capabilities: CategoryDomain[];
  annual_capacity_tons: number;
  current_utilization_pct: number;
  oee_pct: number;
  water_m3_per_ton: number;
  energy_kwh_per_ton: number;
  health_status: HealthStatus;
}

export interface MachineTelemetry {
  machine_id: string;
  name: string;
  speed_units_per_min: number;
  temperature_c: number;
  pressure_bar: number;
  vibration_mm_s: number;
  status: 'RUNNING' | 'IDLE' | 'MAINTENANCE' | 'FAULT';
  last_maintenance: string;
  mtbf_hours: number;
  mttr_hours: number;
}

export interface ProductionLine extends BaseEntity {
  factory_id: string;
  line_code: string;
  name: string;
  capacity_units_per_hr: number;
  current_speed_pct: number;
  availability_pct: number;
  performance_pct: number;
  quality_pct: number;
  oee_pct: number;
  active_sku_id?: string;
  machines: MachineTelemetry[];
}

export interface Batch extends BaseEntity {
  batch_number: string;
  factory_id: string;
  production_line_id: string;
  sku_id: string;
  recipe_id: string;
  quantity_units: number;
  status: BatchStatus;
  start_time: string;
  end_time?: string;
  ingredient_lots_used: { ingredient_id: string; lot_number: string; supplier_id: string }[];
}

// 20 & 21. Quality & Traceability
export interface QualityRecord extends BaseEntity {
  batch_number: string;
  test_type: 'MICROBIOLOGY' | 'CHEMICAL' | 'SENSORY' | 'PACKAGING_INTEGRITY' | 'ALLERGEN';
  parameter_tested: string;
  measured_value: string;
  specification_limit: string;
  result: 'PASS' | 'FAIL' | 'BORDERLINE';
  tested_by: string;
  timestamp: string;
}

export interface TraceabilityNode {
  id: string;
  label: string;
  type: 'SUPPLIER' | 'INGREDIENT_LOT' | 'FACTORY_BATCH' | 'WAREHOUSE' | 'SHIPMENT' | 'CUSTOMER_MARKET';
  details: string;
  status: QualityStatus;
  children?: string[];
}

// 22 - 26. Supply Chain & Control Tower
export interface Shipment extends BaseEntity {
  tracking_number: string;
  origin_factory_id: string;
  destination_dc_id: string;
  destination_market_id: string;
  skus: { sku_id: string; quantity: number; batch_number: string }[];
  departure_time: string;
  eta: string;
  temperature_c?: number;
  is_cold_chain: boolean;
  status: 'IN_TRANSIT' | 'DELIVERED' | 'DELAYED' | 'EXCEPTION';
  co2_kg: number;
}

export interface ControlTowerMetrics {
  total_active_shipments: number;
  delayed_shipments: number;
  disruption_events_active: number;
  global_inventory_days: number;
  service_level_pct: number;
  cold_chain_alerts: number;
}

// 32 - 34. Finance & P&L
export interface FinancialMetrics {
  gross_revenue_chf: string;
  net_revenue_chf: string;
  cogs_chf: string;
  gross_margin_chf: string;
  gross_margin_pct: number;
  ebitda_chf: string;
  ebit_chf: string;
  free_cash_flow_chf: string;
  working_capital_chf: string;
  roic_pct: number;
  capex_chf: string;
  opex_chf: string;
}

// 35 & 36. R&D & Innovation
export interface InnovationProject extends BaseEntity {
  code: string;
  name: string;
  category: CategoryDomain;
  stage: ProductLifecycleStage;
  lead_scientist: string;
  commercial_score: number; // 0-100
  technical_score: number;
  consumer_score: number;
  margin_score: number;
  sustainability_score: number;
  overall_score: number;
  budget_chf: string;
  target_launch_year: number;
}

// 37 & 38. Sustainability
export interface SustainabilityMetrics {
  scope_1_ghg_tons: number;
  scope_2_ghg_tons: number;
  scope_3_ghg_tons: number;
  total_carbon_footprint_tons: number;
  water_withdrawn_m3: number;
  water_recycled_pct: number;
  recyclable_packaging_pct: number;
  virgin_plastic_reduction_tons: number;
  regenerative_ag_sourcing_pct: number;
}

// 39 - 41. AI Enterprise Layer
export interface AIRecommendation {
  recommendation_id: string;
  agent_name: 'SupplyChainAgent' | 'FactoryAgent' | 'ProcurementAgent' | 'FinanceAgent' | 'QualityAgent' | 'RDAgent' | 'MarketingAgent' | 'SalesAgent' | 'SustainabilityAgent' | 'ExecutiveAgent';
  model_id: string;
  input_data_version: string;
  title: string;
  reasoning_summary: string;
  confidence: number; // 0-1
  expected_impact_chf: string;
  risk_assessment: 'LOW' | 'MEDIUM' | 'HIGH';
  proposed_action: string;
  human_owner: string;
  approval_status: 'PROPOSED' | 'UNDER_REVIEW' | 'APPROVED' | 'REJECTED' | 'EXECUTED';
  timestamp: string;
}

// 44. Audit Event
export interface AuditRecord {
  audit_id: string;
  who: string;
  role: UserRole;
  what: string;
  when: string;
  where_module: string;
  why_reason: string;
  before_state?: string;
  after_state?: string;
  approval_ref?: string;
  ip_address: string;
}
