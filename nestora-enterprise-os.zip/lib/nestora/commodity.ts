import Decimal from 'decimal.js';
import { FinancialEngine } from './decimal';

export interface CommodityShockParams {
  commodity: 'COCOA' | 'COFFEE' | 'MILK' | 'GRAINS' | 'SUGAR' | 'OIL' | 'PACKAGING_RESIN' | 'ENERGY';
  priceChangePct: number; // e.g. +35 or -10
}

export interface ShockSimulationResult {
  commodity: string;
  priceChangePct: number;
  previousSpotPriceCHFPerTon: string;
  newSpotPriceCHFPerTon: string;
  hedgedCoveragePct: number; // e.g. 65% hedged
  unhedgedExposureCHF: string;
  cascadeImpact: {
    avgRecipeCostIncreasePct: number;
    affectedCategory: string;
    affectedBrands: string[];
    affectedSKUs: { skuName: string; oldMarginPct: number; newMarginPct: number; grossMarginDeltaCHF: string }[];
    groupGrossMarginImpactCHF: string;
    groupNetEBITDAImpactCHF: string;
    groupEBITDAMarginDeltaBasisPoints: number;
  };
  recommendedActions: string[];
}

export class CommodityEngine {
  static simulateShock(params: CommodityShockParams): ShockSimulationResult {
    const changeFactor = new Decimal(1).add(new Decimal(params.priceChangePct).div(100));

    let basePrice = new Decimal('3800.00'); // CHF/ton baseline
    let categoryName = 'CONFECTIONERY';
    let brands = ['KitKat', 'Cailler', 'Smarties', 'Quality Street'];
    let skus = [
      { skuName: 'KitKat 4-Finger Milk Chocolate 45g', oldMarginPct: 42.5, cogsBase: '0.45', price: '1.20' },
      { skuName: 'Cailler L’Écorcé Dark Chocolate 100g', oldMarginPct: 58.0, cogsBase: '1.26', price: '3.00' },
      { skuName: 'Smarties Hexatube 38g', oldMarginPct: 39.0, cogsBase: '0.55', price: '0.90' },
    ];

    if (params.commodity === 'COFFEE') {
      basePrice = new Decimal('4200.00');
      categoryName = 'COFFEE';
      brands = ['Nescafé', 'Nespresso', 'Starbucks at Home', 'Blue Bottle'];
      skus = [
        { skuName: 'Nescafé Gold Instant 200g Glass Jar', oldMarginPct: 54.0, cogsBase: '3.91', price: '8.50' },
        { skuName: 'Nespresso Arpeggio Ispirazione Capsule 10s', oldMarginPct: 68.5, cogsBase: '1.51', price: '4.80' },
        { skuName: 'Starbucks House Blend Whole Bean 250g', oldMarginPct: 49.0, cogsBase: '4.59', price: '9.00' },
      ];
    } else if (params.commodity === 'MILK') {
      basePrice = new Decimal('650.00');
      categoryName = 'MILK_PRODUCTS';
      brands = ['Nido', 'Carnation', 'Milkmaid', 'Nestlé Everyday'];
      skus = [
        { skuName: 'Nido Fortified Powdered Milk 900g Can', oldMarginPct: 36.0, cogsBase: '8.96', price: '14.00' },
      ];
    }

    const newSpotPrice = basePrice.mul(changeFactor);
    const hedgedCoveragePct = 60; // 60% hedged via forward contracts
    const effectiveExposurePct = (100 - hedgedCoveragePct) / 100; // 40% exposed to spot

    const effectiveCostMultiplier = new Decimal(1).add(
      new Decimal(params.priceChangePct).div(100).mul(effectiveExposurePct)
    );

    const affectedSKUs = skus.map((sku) => {
      const cogsBaseDec = new Decimal(sku.cogsBase);
      const priceDec = new Decimal(sku.price);
      // Assume raw material is ~45% of total COGS
      const rawMatPortion = cogsBaseDec.mul(0.45);
      const otherCogsPortion = cogsBaseDec.mul(0.55);
      const newRawMatPortion = rawMatPortion.mul(effectiveCostMultiplier);
      const newCOGS = otherCogsPortion.add(newRawMatPortion);

      const oldGrossMarginCHF = priceDec.sub(cogsBaseDec);
      const newGrossMarginCHF = priceDec.sub(newCOGS);
      const newMarginPct = newGrossMarginCHF.div(priceDec).mul(100).toNumber();

      return {
        skuName: sku.skuName,
        oldMarginPct: sku.oldMarginPct,
        newMarginPct: Math.round(newMarginPct * 10) / 10,
        grossMarginDeltaCHF: newGrossMarginCHF.sub(oldGrossMarginCHF).toFixed(2),
      };
    });

    // Estimate Group Annual Impact
    const annualVolumeTons = new Decimal('180000'); // 180,000 tons annual cocoa or coffee consumption
    const annualUnhedgedTons = annualVolumeTons.mul(effectiveExposurePct);
    const priceDeltaPerTon = newSpotPrice.sub(basePrice);
    const totalImpactCHF = annualUnhedgedTons.mul(priceDeltaPerTon);

    return {
      commodity: params.commodity,
      priceChangePct: params.priceChangePct,
      previousSpotPriceCHFPerTon: FinancialEngine.format(basePrice, 'CHF'),
      newSpotPriceCHFPerTon: FinancialEngine.format(newSpotPrice, 'CHF'),
      hedgedCoveragePct,
      unhedgedExposureCHF: FinancialEngine.format(totalImpactCHF, 'CHF'),
      cascadeImpact: {
        avgRecipeCostIncreasePct: Math.round(params.priceChangePct * 0.45 * effectiveExposurePct * 10) / 10,
        affectedCategory: categoryName,
        affectedBrands: brands,
        affectedSKUs,
        groupGrossMarginImpactCHF: FinancialEngine.format(totalImpactCHF.neg(), 'CHF'),
        groupNetEBITDAImpactCHF: FinancialEngine.format(totalImpactCHF.mul(0.85).neg(), 'CHF'),
        groupEBITDAMarginDeltaBasisPoints: -Math.round((params.priceChangePct * 1.8)),
      },
      recommendedActions: [
        `Execute tactical price adjustment (+${Math.round(params.priceChangePct * 0.25)}%) in Western European retail markets`,
        `Extend forward commodity hedging window from 6 months to 12 months for ${params.commodity}`,
        `Initiate recipe cost optimization (RE-OPT 2026-B) with R&D formulation adjustments`,
        `Shift volume allocations to lower-cost conversion factories in Zone AOA`,
      ],
    };
  }
}
