import Decimal from 'decimal.js';

export interface OEECalculationResult {
  availabilityPct: number;
  performancePct: number;
  qualityPct: number;
  oeePct: number;
  lossTree: {
    plannedDowntimeMinutes: number;
    unplannedBreakdownMinutes: number;
    minorStoppagesMinutes: number;
    speedLossMinutes: number;
    qualityScrapUnits: number;
    financialLossCHF: string;
  };
}

export class OEEEngine {
  /**
   * Calculates OEE (Availability * Performance * Quality)
   */
  static calculateOEE(
    plannedMinutes: number,
    operatingMinutes: number,
    targetUnitsPerMinute: number,
    totalUnitsProduced: number,
    goodUnitsProduced: number,
    costPerScrapUnitCHF: number = 2.45
  ): OEECalculationResult {
    // 1. Availability = Operating Time / Planned Production Time
    const availabilityPct = plannedMinutes > 0
      ? Math.min(100, Math.max(0, (operatingMinutes / plannedMinutes) * 100))
      : 0;

    // 2. Performance = (Total Units / Operating Time) / Target Speed
    const maxPossibleUnits = operatingMinutes * targetUnitsPerMinute;
    const performancePct = maxPossibleUnits > 0
      ? Math.min(100, Math.max(0, (totalUnitsProduced / maxPossibleUnits) * 100))
      : 0;

    // 3. Quality = Good Units / Total Units
    const qualityPct = totalUnitsProduced > 0
      ? Math.min(100, Math.max(0, (goodUnitsProduced / totalUnitsProduced) * 100))
      : 0;

    // Overall OEE = A * P * Q
    const oeePct = (availabilityPct / 100) * (performancePct / 100) * (qualityPct / 100) * 100;

    // Loss Tree Calculation
    const unplannedBreakdownMinutes = Math.max(0, plannedMinutes - operatingMinutes);
    const speedLossMinutes = Math.max(0, ((maxPossibleUnits - totalUnitsProduced) / targetUnitsPerMinute));
    const scrapUnits = Math.max(0, totalUnitsProduced - goodUnitsProduced);
    const financialLoss = new Decimal(scrapUnits).mul(costPerScrapUnitCHF).add(new Decimal(unplannedBreakdownMinutes).mul(450)); // CHF 450/hr downtime

    return {
      availabilityPct: Math.round(availabilityPct * 10) / 10,
      performancePct: Math.round(performancePct * 10) / 10,
      qualityPct: Math.round(qualityPct * 10) / 10,
      oeePct: Math.round(oeePct * 10) / 10,
      lossTree: {
        plannedDowntimeMinutes: 30, // Scheduled cleaning/sanitation
        unplannedBreakdownMinutes: Math.round(unplannedBreakdownMinutes),
        minorStoppagesMinutes: Math.round(unplannedBreakdownMinutes * 0.4),
        speedLossMinutes: Math.round(speedLossMinutes),
        qualityScrapUnits: scrapUnits,
        financialLossCHF: financialLoss.toFixed(2),
      },
    };
  }
}
