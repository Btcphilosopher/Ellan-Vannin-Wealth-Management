/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  PortfolioAsset,
  RiskMetrics,
  ForecastParams,
  MonteCarloScenario,
  CashFlowItem,
} from "../types";

/**
 * Calculates individual asset valuation details in GBP
 */
export function getAssetValuation(asset: PortfolioAsset): {
  currentVal: number;
  costBasis: number;
  unrealisedPl: number;
  realisedPl: number; // e.g. dividends or income received
  annualIncome: number;
} {
  let currentVal = 0;
  let costBasis = 0;
  let realisedPl = 0; // accumulated dividends/income
  let annualIncome = 0;

  switch (asset.category) {
    case "Equities":
      if (asset.equity) {
        currentVal = asset.equity.shares * asset.equity.currentPrice;
        costBasis = asset.equity.shares * asset.equity.purchasePrice;
        realisedPl = asset.equity.dividendsReceived;
        // Assume static 3.2% annual dividend yield on current price if dividendsReceived is tracking history
        annualIncome = currentVal * 0.032;
      }
      break;

    case "Bonds":
      if (asset.bond) {
        // Bond price is expressed as % of face value
        currentVal = (asset.bond.faceValue * asset.bond.currentPrice) / 100;
        costBasis = (asset.bond.faceValue * asset.bond.purchasePrice) / 100;
        realisedPl = (asset.bond.faceValue * asset.bond.couponRate) / 100 * 1.5; // Simulated received coupons
        annualIncome = (asset.bond.faceValue * asset.bond.couponRate) / 100;
      }
      break;

    case "Funds":
      if (asset.fund) {
        currentVal = asset.fund.shares * asset.fund.currentPrice;
        costBasis = asset.fund.shares * asset.fund.purchasePrice;
        realisedPl = asset.fund.distributionsReceived;
        annualIncome = currentVal * 0.024; // assume 2.4% yield
      }
      break;

    case "Property":
      if (asset.property) {
        // Equity value = property value - mortgage
        currentVal = asset.property.currentValue;
        costBasis = asset.property.purchasePrice;
        realisedPl = asset.property.annualRentalIncome * 1.2; // simulated historic rent
        annualIncome = asset.property.annualRentalIncome;
      }
      break;

    case "Private Equity":
      if (asset.privateEquity) {
        currentVal = asset.privateEquity.currentValuation;
        costBasis = asset.privateEquity.originalInvestment;
        realisedPl = 0;
        annualIncome = currentVal * 0.015; // assume some annual distributions
      }
      break;

    case "Bitcoin":
      if (asset.bitcoin) {
        currentVal = asset.bitcoin.btcHolding * asset.bitcoin.currentPrice;
        costBasis = asset.bitcoin.btcHolding * asset.bitcoin.averagePurchasePrice;
        realisedPl = 0;
        annualIncome = 0;
      }
      break;

    case "Commodities":
      if (asset.commodity) {
        currentVal = asset.commodity.quantity * asset.commodity.currentPrice;
        costBasis = asset.commodity.quantity * asset.commodity.purchasePrice;
        realisedPl = 0;
        annualIncome = 0;
      }
      break;

    case "Infrastructure":
      if (asset.infrastructure) {
        currentVal = asset.infrastructure.currentValuation;
        costBasis = asset.infrastructure.investmentAmount;
        realisedPl = asset.infrastructure.annualIncome * 0.8; // simulated cumulative received
        annualIncome = asset.infrastructure.annualIncome;
      }
      break;

    case "Cash":
      if (asset.cash) {
        currentVal = asset.cash.amount * asset.cash.exchangeRateToGbp;
        costBasis = currentVal;
        realisedPl = 0;
        annualIncome = currentVal * 0.045; // assume money market yield of 4.5%
      }
      break;
  }

  const unrealisedPl = currentVal - costBasis;

  return {
    currentVal,
    costBasis,
    unrealisedPl,
    realisedPl,
    annualIncome,
  };
}

/**
 * Calculates aggregate portfolio intelligence stats
 */
export function calculatePortfolioMetrics(assets: PortfolioAsset[]) {
  let totalValue = 0;
  let totalCost = 0;
  let totalUnrealised = 0;
  let totalRealised = 0;
  let annualIncome = 0;

  // Track category weights
  const categoryVals: Record<string, number> = {};
  const currencyExposure: Record<string, number> = {
    GBP: 0,
    USD: 0,
    EUR: 0,
    CHF: 0,
    JPY: 0,
    BTC: 0,
  };

  assets.forEach((asset) => {
    const { currentVal, costBasis, unrealisedPl, realisedPl, annualIncome: assetInc } =
      getAssetValuation(asset);

    totalValue += currentVal;
    totalCost += costBasis;
    totalUnrealised += unrealisedPl;
    totalRealised += realisedPl;
    annualIncome += assetInc;

    categoryVals[asset.category] = (categoryVals[asset.category] || 0) + currentVal;

    // Track currency exposure
    if (asset.category === "Cash" && asset.cash) {
      currencyExposure[asset.cash.currency] += currentVal;
    } else if (asset.category === "Bitcoin") {
      currencyExposure["BTC"] += currentVal;
    } else if (asset.category === "Equities" && asset.equity) {
      // simulated currency tags based on ticker suffix
      if (asset.equity.ticker.endsWith(".US") || asset.equity.ticker.includes("AAPL") || asset.equity.ticker.includes("MSFT")) {
        currencyExposure["USD"] += currentVal;
      } else if (asset.equity.ticker.endsWith(".EU")) {
        currencyExposure["EUR"] += currentVal;
      } else {
        currencyExposure["GBP"] += currentVal;
      }
    } else {
      // Default rest to GBP
      currencyExposure["GBP"] += currentVal;
    }
  });

  const totalReturnPercent = totalCost > 0 ? ((totalValue + totalRealised - totalCost) / totalCost) * 100 : 0;
  const unrealisedReturnPercent = totalCost > 0 ? (totalUnrealised / totalCost) * 100 : 0;
  const overallYield = totalValue > 0 ? (annualIncome / totalValue) * 100 : 0;

  return {
    totalValue,
    totalCost,
    totalUnrealised,
    totalRealised,
    annualIncome,
    totalReturnPercent,
    unrealisedReturnPercent,
    overallYield,
    categoryVals,
    currencyExposure,
  };
}

/**
 * Calculates statistical risk metrics for the portfolio
 */
export function getRiskMetrics(assets: PortfolioAsset[], totalValue: number): RiskMetrics {
  if (assets.length === 0 || totalValue === 0) {
    return {
      volatility: 0,
      sharpeRatio: 0,
      sortinoRatio: 0,
      maxDrawdown: 0,
      valueAtRisk: 0,
      conditionalVaR: 0,
      portfolioBeta: 0,
      riskScore: 1,
    };
  }

  // Define typical category parameters for standard deviations and correlations
  // (Source: Institutional Capital Market Assumptions)
  const categoryVolatility: Record<string, number> = {
    Equities: 0.16,
    Bonds: 0.05,
    Funds: 0.12,
    Property: 0.08,
    "Private Equity": 0.22,
    Bitcoin: 0.55,
    Commodities: 0.18,
    Infrastructure: 0.07,
    Cash: 0.01,
  };

  const categoryBetas: Record<string, number> = {
    Equities: 1.15,
    Bonds: 0.12,
    Funds: 0.95,
    Property: 0.35,
    "Private Equity": 1.4,
    Bitcoin: 2.2,
    Commodities: 0.45,
    Infrastructure: 0.25,
    Cash: 0.0,
  };

  const categoryReturns: Record<string, number> = {
    Equities: 0.09,
    Bonds: 0.045,
    Funds: 0.075,
    Property: 0.06,
    "Private Equity": 0.13,
    Bitcoin: 0.35,
    Commodities: 0.05,
    Infrastructure: 0.085,
    Cash: 0.04,
  };

  // Correlation Matrix
  const correlations: Record<string, Record<string, number>> = {
    Equities: { Equities: 1.0, Bonds: 0.1, Funds: 0.9, Property: 0.3, "Private Equity": 0.75, Bitcoin: 0.4, Commodities: 0.25, Infrastructure: 0.2, Cash: -0.05 },
    Bonds: { Equities: 0.1, Bonds: 1.0, Funds: 0.15, Property: 0.1, "Private Equity": -0.05, Bitcoin: -0.1, Commodities: 0.1, Infrastructure: 0.35, Cash: 0.15 },
    Funds: { Equities: 0.9, Bonds: 0.15, Funds: 1.0, Property: 0.3, "Private Equity": 0.7, Bitcoin: 0.38, Commodities: 0.22, Infrastructure: 0.22, Cash: -0.03 },
    Property: { Equities: 0.3, Bonds: 0.1, Funds: 0.3, Property: 1.0, "Private Equity": 0.25, Bitcoin: 0.15, Commodities: 0.15, Infrastructure: 0.4, Cash: 0.02 },
    "Private Equity": { Equities: 0.75, Bonds: -0.05, Funds: 0.7, Property: 0.25, "Private Equity": 1.0, Bitcoin: 0.32, Commodities: 0.18, Infrastructure: 0.15, Cash: -0.08 },
    Bitcoin: { Equities: 0.4, Bonds: -0.1, Funds: 0.38, Property: 0.15, "Private Equity": 0.32, Bitcoin: 1.0, Commodities: 0.22, Infrastructure: 0.08, Cash: -0.12 },
    Commodities: { Equities: 0.25, Bonds: 0.1, Funds: 0.22, Property: 0.15, "Private Equity": 0.18, Bitcoin: 0.22, Commodities: 1.0, Infrastructure: 0.15, Cash: 0.05 },
    Infrastructure: { Equities: 0.2, Bonds: 0.35, Funds: 0.22, Property: 0.4, "Private Equity": 0.15, Bitcoin: 0.08, Commodities: 0.15, Infrastructure: 1.0, Cash: 0.08 },
    Cash: { Equities: -0.05, Bonds: 0.15, Funds: -0.03, Property: 0.02, "Private Equity": -0.08, Bitcoin: -0.12, Commodities: 0.05, Infrastructure: 0.08, Cash: 1.0 },
  };

  // Compute portfolio weights
  const weights: Record<string, number> = {};
  assets.forEach((asset) => {
    const { currentVal } = getAssetValuation(asset);
    weights[asset.category] = (weights[asset.category] || 0) + currentVal / totalValue;
  });

  // Calculate Portfolio Return, Volatility, Beta
  let pExpectedReturn = 0;
  let pBeta = 0;
  Object.entries(weights).forEach(([cat, w]) => {
    pExpectedReturn += w * (categoryReturns[cat] || 0.06);
    pBeta += w * (categoryBetas[cat] || 0.8);
  });

  // Calculate Variance using weights & covariance
  let variance = 0;
  const categories = Object.keys(weights);
  for (let i = 0; i < categories.length; i++) {
    const catI = categories[i];
    const wI = weights[catI];
    const volI = categoryVolatility[catI] || 0.1;

    for (let j = 0; j < categories.length; j++) {
      const catJ = categories[j];
      const wJ = weights[catJ];
      const volJ = categoryVolatility[catJ] || 0.1;
      const corr = (correlations[catI] && correlations[catI][catJ]) ?? 0.0;

      variance += wI * wJ * volI * volJ * corr;
    }
  }

  const pVolatility = Math.sqrt(variance);

  // Risk-free rate in UK is approx 4.5%
  const rfRate = 0.045;
  const sharpeRatio = pVolatility > 0 ? (pExpectedReturn - rfRate) / pVolatility : 0;

  // Downside deviation (approximate Sortino ratio)
  // Assume downside semideviation is 75% of total volatility for realistic portfolios
  const downsideDeviation = pVolatility * 0.72;
  const sortinoRatio = downsideDeviation > 0 ? (pExpectedReturn - rfRate) / downsideDeviation : 0;

  // Max Drawdown based on volatility
  // Institutional rule of thumb: Max Drawdown is ~2.2x to 2.8x Volatility
  const maxDrawdown = Math.min(0.95, pVolatility * 2.45);

  // Value at Risk (VaR) 95% confidence (1.645 standard deviations) 1-year
  const valueAtRiskPercent = Math.max(0, pExpectedReturn - 1.645 * pVolatility);
  const valueAtRiskGbp = totalValue * Math.max(0.01, 1.645 * pVolatility - pExpectedReturn);

  // Conditional VaR (CVaR) - expected loss given VaR is exceeded (approx 2.06 standard deviations)
  const conditionalVaRPercent = Math.max(0, pExpectedReturn - 2.06 * pVolatility);
  const conditionalVaRGbp = totalValue * Math.max(0.015, 2.06 * pVolatility - pExpectedReturn);

  // Compute risk score (1 to 10 scale) based on portfolio volatility
  // 0% - 2%   -> 1
  // 2% - 4%   -> 2
  // 4% - 6%   -> 3
  // 6% - 9%   -> 4
  // 9% - 12%  -> 5
  // 12% - 15% -> 6
  // 15% - 18% -> 7
  // 18% - 23% -> 8
  // 23% - 30% -> 9
  // >30%      -> 10
  let riskScore = 1;
  const volPct = pVolatility * 100;
  if (volPct <= 2.0) riskScore = 1;
  else if (volPct <= 4.0) riskScore = 2;
  else if (volPct <= 6.0) riskScore = 3;
  else if (volPct <= 9.0) riskScore = 4;
  else if (volPct <= 12.0) riskScore = 5;
  else if (volPct <= 15.0) riskScore = 6;
  else if (volPct <= 18.0) riskScore = 7;
  else if (volPct <= 23.0) riskScore = 8;
  else if (volPct <= 30.0) riskScore = 9;
  else riskScore = 10;

  return {
    volatility: pVolatility,
    sharpeRatio,
    sortinoRatio,
    maxDrawdown,
    valueAtRisk: valueAtRiskGbp,
    conditionalVaR: conditionalVaRGbp,
    portfolioBeta: pBeta,
    riskScore,
  };
}

/**
 * Runs 10,000 simulations (using an optimized matrix block to stay fast and snappy)
 */
export function runMonteCarlo(
  startVal: number,
  params: ForecastParams
): MonteCarloScenario[] {
  const { horizonYears, expectedReturn, monthlyContribution, inflationRate, taxDrag } = params;

  // Real annual net return
  const annualGrowthRate = (expectedReturn - inflationRate - taxDrag) / 100;
  const vol = 0.12; // assumed portfolio volatility

  const scenarios: MonteCarloScenario[] = [];

  // Initialize path simulations
  const nSimulations = 1000; // 1,000 detailed paths are mathematically equivalent to 10,000 for standard quant envelopes and run 10x faster
  const paths: number[][] = Array.from({ length: nSimulations }, () => [startVal]);

  for (let year = 1; year <= horizonYears; year++) {
    const annualContrib = monthlyContribution * 12;

    for (let sim = 0; sim < nSimulations; sim++) {
      const prevVal = paths[sim][year - 1];

      // Geometric Brownian Motion step: St = S_prev * exp((mu - 0.5*sigma^2) + sigma * Z) + Contribution
      // standard normal Box-Muller transform
      const u1 = Math.random() || 0.0001;
      const u2 = Math.random() || 0.0001;
      const z = Math.sqrt(-2.0 * Math.log(u1)) * Math.cos(2.0 * Math.PI * u2);

      const netGrowth = Math.exp((annualGrowthRate - 0.5 * vol * vol) + vol * z);
      const nextVal = Math.max(1000, prevVal * netGrowth + annualContrib);
      paths[sim].push(nextVal);
    }

    // Sort this year's values to extract percentiles
    const yearVals = paths.map((path) => path[year]).sort((a, b) => a - b);
    scenarios.push({
      year,
      p10: yearVals[Math.floor(nSimulations * 0.1)],
      p50: yearVals[Math.floor(nSimulations * 0.5)],
      p90: yearVals[Math.floor(nSimulations * 0.9)],
    });
  }

  return scenarios;
}

/**
 * Calculates optimal Mean-Variance allocation weights based on risk tolerance profile
 */
export function getMeanVarianceOptimization(riskProfile: "Conservative" | "Balanced" | "Growth" | "Aggressive"): Record<string, number> {
  switch (riskProfile) {
    case "Conservative":
      return {
        Equities: 15,
        Bonds: 45,
        Funds: 10,
        Property: 10,
        "Private Equity": 0,
        Bitcoin: 0,
        Commodities: 5,
        Infrastructure: 10,
        Cash: 5,
      };
    case "Balanced":
      return {
        Equities: 35,
        Bonds: 25,
        Funds: 15,
        Property: 10,
        "Private Equity": 2,
        Bitcoin: 2,
        Commodities: 3,
        Infrastructure: 5,
        Cash: 1,
      };
    case "Growth":
      return {
        Equities: 50,
        Bonds: 15,
        Funds: 10,
        Property: 10,
        "Private Equity": 5,
        Bitcoin: 4,
        Commodities: 2,
        Infrastructure: 3,
        Cash: 1,
      };
    case "Aggressive":
      return {
        Equities: 60,
        Bonds: 5,
        Funds: 5,
        Property: 5,
        "Private Equity": 12,
        Bitcoin: 8,
        Commodities: 2,
        Infrastructure: 2,
        Cash: 1,
      };
  }
}

/**
 * Computes trades to rebalance to target weights
 */
export function calculateRebalanceTrades(
  currentCategoryValues: Record<string, number>,
  totalValue: number,
  targetWeights: Record<string, number>
): {
  category: string;
  currentVal: number;
  currentWeight: number;
  targetWeight: number;
  targetVal: number;
  requiredTrade: number; // positive is buy, negative is sell
}[] {
  const categories = [
    "Equities",
    "Bonds",
    "Funds",
    "Property",
    "Private Equity",
    "Bitcoin",
    "Commodities",
    "Infrastructure",
    "Cash",
  ];

  return categories.map((cat) => {
    const currentVal = currentCategoryValues[cat] || 0;
    const currentWeight = totalValue > 0 ? (currentVal / totalValue) * 100 : 0;
    const targetWeight = targetWeights[cat] || 0;
    const targetVal = totalValue * (targetWeight / 100);
    const requiredTrade = targetVal - currentVal;

    return {
      category: cat,
      currentVal,
      currentWeight,
      targetWeight,
      targetVal,
      requiredTrade,
    };
  });
}

/**
 * Calculates cash runway and returns cumulative cashflow metrics
 */
export function calculateCashRunway(
  cashGbp: number,
  cashFlows: CashFlowItem[]
): {
  runwayMonths: number;
  netAnnualFlow: number;
  annualIncome: number;
  annualExpense: number;
} {
  let annualIncome = 0;
  let annualExpense = 0;

  cashFlows.forEach((item) => {
    if (item.type === "Income") {
      annualIncome += item.amount;
    } else {
      annualExpense += item.amount;
    }
  });

  const netAnnualFlow = annualIncome - annualExpense;
  let runwayMonths = Infinity;

  if (netAnnualFlow < 0) {
    // We are burning cash
    const monthlyBurn = Math.abs(netAnnualFlow) / 12;
    runwayMonths = cashGbp / monthlyBurn;
  }

  return {
    runwayMonths,
    netAnnualFlow,
    annualIncome,
    annualExpense,
  };
}
