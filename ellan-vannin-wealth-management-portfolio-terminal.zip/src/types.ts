/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AssetCategory =
  | "Equities"
  | "Bonds"
  | "Funds"
  | "Property"
  | "Private Equity"
  | "Bitcoin"
  | "Commodities"
  | "Infrastructure"
  | "Cash";

export interface EquityAsset {
  id: string;
  company: string;
  ticker: string;
  shares: number;
  purchasePrice: number; // in GBP
  currentPrice: number; // in GBP
  dividendsReceived: number; // cumulative dividends received in GBP
}

export interface BondAsset {
  id: string;
  issuer: string;
  ticker: string;
  faceValue: number;
  purchasePrice: number; // purchase price as % of face value (e.g. 98)
  currentPrice: number; // current price as % of face value (e.g. 101)
  maturityDate: string;
  couponRate: number; // annual percentage
  yieldToMaturity: number; // annual percentage
}

export interface FundAsset {
  id: string;
  name: string;
  ticker: string;
  fundType: "ETF" | "Mutual Fund" | "Index Fund";
  shares: number;
  purchasePrice: number;
  currentPrice: number;
  distributionsReceived: number;
}

export interface PropertyAsset {
  id: string;
  address: string;
  purchasePrice: number;
  currentValue: number;
  annualRentalIncome: number;
  mortgageOutstanding: number;
  mortgageRate: number; // percentage
}

export interface PrivateEquityAsset {
  id: string;
  company: string;
  investmentDate: string;
  originalInvestment: number;
  currentValuation: number;
  targetIrr: number; // percentage
  philanthropyContribution?: number; // Generational/FO feature
}

export interface BitcoinAsset {
  id: string;
  btcHolding: number;
  averagePurchasePrice: number; // in GBP
  currentPrice: number; // in GBP
  coldStorageLocation: string; // custody detail
}

export interface CommodityAsset {
  id: string;
  assetName: "Gold" | "Silver" | "Crude Oil" | "Agricultural Assets";
  quantity: number; // e.g., troy ounces, barrels
  purchasePrice: number; // average cost per unit
  currentPrice: number; // current price per unit
}

export interface InfrastructureAsset {
  id: string;
  projectName: string;
  projectType: "Rail" | "Port" | "Energy" | "Data Centre" | "Forestry";
  investmentAmount: number;
  expectedIrr: number; // percentage
  currentValuation: number;
  annualIncome: number;
  stage: "Planning" | "Construction" | "Operational";
}

export interface CashAsset {
  id: string;
  amount: number; // original foreign amount
  currency: "GBP" | "USD" | "EUR" | "CHF" | "JPY";
  exchangeRateToGbp: number; // multiplier to convert to GBP (e.g. 0.78 for USD to GBP)
}

// Discriminator Interface for the Portfolio
export interface PortfolioAsset {
  id: string;
  category: AssetCategory;
  equity?: EquityAsset;
  bond?: BondAsset;
  fund?: FundAsset;
  property?: PropertyAsset;
  privateEquity?: PrivateEquityAsset;
  bitcoin?: BitcoinAsset;
  commodity?: CommodityAsset;
  infrastructure?: InfrastructureAsset;
  cash?: CashAsset;
}

// Cash Flow Item
export interface CashFlowItem {
  id: string;
  type: "Income" | "Expense";
  category: string; // "Dividends", "Interest", "Rent", "Distributions", "Fees", "Taxes", "Withdrawals"
  amount: number; // annual value in GBP
  frequency: "Monthly" | "Quarterly" | "Annually";
}

// Generational Track (Family Office)
export interface GenerationalMember {
  id: string;
  name: string;
  relationship: string; // e.g., "Founder", "Spouse", "G2 Child", "G3 Grandchild"
  allocatedShare: number; // percentage of portfolio
  trustStructure: string; // trust holding vehicle details
  inheritanceTaxPlanned: boolean;
}

// Strategic Reserve (Sovereign Wealth Fund)
export interface StrategicReserve {
  id: string;
  assetName: string;
  type: "Permanent Capital" | "Natural Resource" | "Strategic Commodity Reserve" | "Foreign Exchange Reserve";
  amountGbp: number;
  purpose: string;
}

export type PortfolioMode = "Standard" | "Sovereign" | "Britain2040" | "FamilyOffice";

// Full Database Structure
export interface PortfolioDatabase {
  assets: PortfolioAsset[];
  cashFlows: CashFlowItem[];
  generationalMembers: GenerationalMember[];
  strategicReserves: StrategicReserve[];
  systemConfig: {
    selectedRole: "Client" | "Advisor" | "Administrator";
    selectedMode: PortfolioMode;
    currency: "GBP";
  };
}

// Risk Analysis Summary
export interface RiskMetrics {
  volatility: number; // standard deviation of returns
  sharpeRatio: number;
  sortinoRatio: number;
  maxDrawdown: number;
  valueAtRisk: number; // 95% 1-day VaR in GBP
  conditionalVaR: number; // 95% CVaR in GBP
  portfolioBeta: number; // beta vs MSCI World / S&P 500
  riskScore: number; // 1 to 10
}

// Future wealth forecast variables
export interface ForecastParams {
  horizonYears: number; // 5, 10, 20, 30
  expectedReturn: number; // annual %
  monthlyContribution: number; // GBP
  inflationRate: number; // annual %
  taxDrag: number; // annual %
}

// Monte Carlo scenario outcome
export interface MonteCarloScenario {
  year: number;
  p10: number; // 10th percentile (bear case)
  p50: number; // median (expected)
  p90: number; // 90th percentile (bull case)
}
