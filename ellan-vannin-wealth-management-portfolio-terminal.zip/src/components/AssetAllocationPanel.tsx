/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Compass, Globe, Coins, ShieldCheck, MapPin, Info } from "lucide-react";
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell } from "recharts";

interface AssetAllocationPanelProps {
  categoryVals: Record<string, number>;
  currencyExposure: Record<string, number>;
  totalValue: number;
}

export const AssetAllocationPanel: React.FC<AssetAllocationPanelProps> = ({
  categoryVals,
  currencyExposure,
  totalValue,
}) => {
  const [hoveredRegion, setHoveredRegion] = useState<string | null>(null);

  // Hardcoded premium geographic allocation weights based on traditional asset locations
  const geographicData = [
    { region: "United Kingdom", weight: 35, capital: totalValue * 0.35, color: "stroke-amber-400 fill-amber-500/10" },
    { region: "United States (USA)", weight: 30, capital: totalValue * 0.30, color: "stroke-sky-400 fill-sky-500/10" },
    { region: "Continental Europe", weight: 15, capital: totalValue * 0.15, color: "stroke-indigo-400 fill-indigo-500/10" },
    { region: "Asia / Emerging", weight: 12, capital: totalValue * 0.12, color: "stroke-emerald-400 fill-emerald-500/10" },
    { region: "Global Assets (FX/BTC)", weight: 8, capital: totalValue * 0.08, color: "stroke-teal-400 fill-teal-500/10" },
  ];

  // Recharts asset allocation array
  const assetClasses = Object.entries(categoryVals).map(([category, val]) => {
    const numVal = val as number;
    return {
      name: category,
      value: numVal,
      percentage: totalValue > 0 ? (numVal / totalValue) * 100 : 0,
    };
  }).sort((a, b) => b.value - a.value);

  // Recharts currency exposure array
  const currencies = Object.entries(currencyExposure).map(([currency, val]) => {
    const numVal = val as number;
    return {
      name: currency,
      value: numVal,
      percentage: totalValue > 0 ? (numVal / totalValue) * 100 : 0,
    };
  }).sort((a, b) => b.value - a.value);

  // Colors for the category list
  const CATEGORY_COLORS: Record<string, string> = {
    Equities: "bg-amber-400 border-amber-400",
    Bonds: "bg-amber-300 border-amber-300",
    Funds: "bg-sky-400 border-sky-400",
    Property: "bg-indigo-400 border-indigo-400",
    "Private Equity": "bg-emerald-400 border-emerald-400",
    Bitcoin: "bg-orange-400 border-orange-400",
    Commodities: "bg-yellow-400 border-yellow-400",
    Infrastructure: "bg-teal-400 border-teal-400",
    Cash: "bg-slate-400 border-slate-400",
  };

  return (
    <div className="space-y-6">
      {/* Category allocation grid & chart */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category breakdown table */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest mb-3 border-b border-slate-800 pb-3">
            <Compass className="w-4 h-4 text-amber-500" />
            <span>Portfolio Category Footprint</span>
          </div>

          <div className="space-y-4 font-mono">
            {assetClasses.map((ac) => (
              <div key={ac.name} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <div className="flex items-center gap-2">
                    <span className={`w-2.5 h-2.5 rounded-full ${CATEGORY_COLORS[ac.name] || "bg-slate-400"}`} />
                    <span className="text-white font-semibold">{ac.name}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-amber-100 font-bold block">£{ac.value.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                    <span className="text-slate-500 text-[10px] block">{ac.percentage.toFixed(1)}% weight</span>
                  </div>
                </div>
                {/* Custom CSS Bar */}
                <div className="w-full h-1.5 bg-slate-950 border border-slate-800 rounded-full overflow-hidden">
                  <div
                    className={`h-full rounded-full ${CATEGORY_COLORS[ac.name] || "bg-slate-400"}`}
                    style={{ width: `${ac.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recharts allocation horizontal bar representation */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl lg:col-span-2">
          <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest mb-4">
            <Globe className="w-4 h-4 text-amber-500" />
            <span>Valuation Asset Class Distribution</span>
          </div>

          <div className="h-64 w-full font-mono text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={assetClasses} layout="vertical" margin={{ left: 10, right: 10, top: 5, bottom: 5 }}>
                <XAxis type="number" stroke="#64748b" />
                <YAxis dataKey="name" type="category" stroke="#64748b" width={85} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#020617", borderColor: "#334155", color: "#f8fafc" }}
                  formatter={(value: any) => [`£${Number(value).toLocaleString()}`, "Valuation"]}
                />
                <Bar dataKey="value" fill="#f59e0b" radius={[0, 4, 4, 0]}>
                  {assetClasses.map((entry, index) => (
                    <Cell
                      key={`cell-${index}`}
                      fill={
                        entry.name === "Bitcoin"
                          ? "#f97316"
                          : entry.name === "Equities"
                          ? "#fbbf24"
                          : entry.name === "Bonds"
                          ? "#f59e0b"
                          : entry.name === "Infrastructure"
                          ? "#14b8a6"
                          : "#818cf8"
                      }
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Geographic Map and Currency exposures */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Custom designed high-fidelity Interactive SVG world map highlighting portfolio exposure */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest mb-2 border-b border-slate-800 pb-3">
            <Globe className="w-4 h-4 text-amber-500" />
            <span>Global Geographical Exposures</span>
          </div>

          {/* Interactive Custom SVG representing global continental divisions */}
          <div className="relative border border-slate-800 rounded-lg bg-slate-950 p-4 h-56 flex items-center justify-center overflow-hidden">
            <svg
              viewBox="0 0 1000 450"
              className="w-full h-full select-none"
              style={{ strokeWidth: 1.5, strokeLinecap: "round", strokeLinejoin: "round" }}
            >
              {/* Background dots representation for beautiful Bloomberg terminal world outline */}
              <g className="opacity-20 fill-slate-800">
                <circle cx="100" cy="150" r="1.5" /><circle cx="120" cy="160" r="1.5" /><circle cx="140" cy="170" r="1.5" />
                <circle cx="160" cy="150" r="1.5" /><circle cx="180" cy="140" r="1.5" /><circle cx="200" cy="180" r="1.5" />
                <circle cx="250" cy="200" r="1.5" /><circle cx="270" cy="210" r="1.5" /><circle cx="290" cy="230" r="1.5" />
                {/* Europe/UK dots */}
                <circle cx="450" cy="120" r="2" /><circle cx="470" cy="100" r="2" /><circle cx="480" cy="110" r="2" />
                <circle cx="500" cy="130" r="2" /><circle cx="520" cy="140" r="2" /><circle cx="540" cy="150" r="2" />
                {/* Asia/Emerging dots */}
                <circle cx="700" cy="150" r="1.5" /><circle cx="720" cy="160" r="1.5" /><circle cx="740" cy="170" r="1.5" />
                <circle cx="760" cy="180" r="1.5" /><circle cx="780" cy="190" r="1.5" /><circle cx="800" cy="200" r="1.5" />
                <circle cx="820" cy="220" r="1.5" /><circle cx="840" cy="230" r="1.5" /><circle cx="860" cy="240" r="1.5" />
              </g>

              {/* Geographic Regions drawn as beautiful high-tech box bubbles */}
              {/* USA Exposure Block */}
              <g
                className="cursor-pointer group"
                onMouseEnter={() => setHoveredRegion("United States")}
                onMouseLeave={() => setHoveredRegion(null)}
              >
                <rect x="150" y="80" width="160" height="90" rx="6" className={`transition-all duration-200 stroke-2 ${hoveredRegion === "United States" ? "fill-sky-500/25 stroke-sky-400" : "fill-slate-900/40 stroke-slate-800"}`} />
                <text x="230" y="120" textAnchor="middle" className="fill-sky-400 font-mono text-[11px] font-bold uppercase tracking-widest">United States</text>
                <text x="230" y="140" textAnchor="middle" className="fill-slate-300 font-mono text-xs font-bold">30% Exposure</text>
              </g>

              {/* UK Exposure Block (High-density centerpiece) */}
              <g
                className="cursor-pointer group"
                onMouseEnter={() => setHoveredRegion("United Kingdom")}
                onMouseLeave={() => setHoveredRegion(null)}
              >
                <rect x="420" y="40" width="170" height="90" rx="6" className={`transition-all duration-200 stroke-2 ${hoveredRegion === "United Kingdom" ? "fill-amber-500/25 stroke-amber-400" : "fill-slate-900/40 stroke-slate-800"}`} />
                <text x="505" y="80" textAnchor="middle" className="fill-amber-400 font-serif text-[11px] font-bold uppercase tracking-widest">United Kingdom</text>
                <text x="505" y="100" textAnchor="middle" className="fill-slate-300 font-mono text-xs font-bold">35% exposure</text>
              </g>

              {/* Continental Europe Block */}
              <g
                className="cursor-pointer group"
                onMouseEnter={() => setHoveredRegion("Continental Europe")}
                onMouseLeave={() => setHoveredRegion(null)}
              >
                <rect x="420" y="150" width="170" height="90" rx="6" className={`transition-all duration-200 stroke-2 ${hoveredRegion === "Continental Europe" ? "fill-indigo-500/25 stroke-indigo-400" : "fill-slate-900/40 stroke-slate-800"}`} />
                <text x="505" y="190" textAnchor="middle" className="fill-indigo-400 font-mono text-[11px] font-bold uppercase tracking-widest">Europe Union</text>
                <text x="505" y="210" textAnchor="middle" className="fill-slate-300 font-mono text-xs font-bold">15% exposure</text>
              </g>

              {/* Asia & Emerging Block */}
              <g
                className="cursor-pointer group"
                onMouseEnter={() => setHoveredRegion("Asia / Emerging")}
                onMouseLeave={() => setHoveredRegion(null)}
              >
                <rect x="700" y="110" width="170" height="90" rx="6" className={`transition-all duration-200 stroke-2 ${hoveredRegion === "Asia / Emerging" ? "fill-emerald-500/25 stroke-emerald-400" : "fill-slate-900/40 stroke-slate-800"}`} />
                <text x="785" y="150" textAnchor="middle" className="fill-emerald-400 font-mono text-[11px] font-bold uppercase tracking-widest">Asia / Emerging</text>
                <text x="785" y="170" textAnchor="middle" className="fill-slate-300 font-mono text-xs font-bold">12% exposure</text>
              </g>

              {/* Global assets Block */}
              <g
                className="cursor-pointer group"
                onMouseEnter={() => setHoveredRegion("Global Assets")}
                onMouseLeave={() => setHoveredRegion(null)}
              >
                <rect x="420" y="260" width="170" height="90" rx="6" className={`transition-all duration-200 stroke-2 ${hoveredRegion === "Global Assets" ? "fill-teal-500/25 stroke-teal-400" : "fill-slate-900/40 stroke-slate-800"}`} />
                <text x="505" y="300" textAnchor="middle" className="fill-teal-400 font-mono text-[11px] font-bold uppercase tracking-widest">Global Liquid</text>
                <text x="505" y="320" textAnchor="middle" className="fill-slate-300 font-mono text-xs font-bold">8% (BTC/Gold)</text>
              </g>
            </svg>

            {/* Hover tooltip overlay */}
            <div className="absolute bottom-2.5 left-2.5 bg-slate-950 px-2.5 py-1.5 border border-slate-800 rounded text-[11px] font-mono text-slate-400">
              {hoveredRegion ? (
                <span>
                  Active Selection: <strong className="text-amber-400">{hoveredRegion}</strong>
                </span>
              ) : (
                <span>Hover region cards to query geographic exposure metrics</span>
              )}
            </div>
          </div>
        </div>

        {/* Currency Exposure list */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest mb-3 border-b border-slate-800 pb-3">
            <Coins className="w-4 h-4 text-amber-500" />
            <span>Sovereign Currency Exposure Ledger</span>
          </div>

          <div className="space-y-4 font-mono">
            {currencies.map((curr) => (
              <div key={curr.name} className="flex items-center justify-between bg-slate-950 p-3 rounded-lg border border-slate-800/80 transition-all hover:border-amber-500/10">
                <div className="flex items-center gap-2.5">
                  <span className="w-8 h-8 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center font-bold text-xs text-amber-400">
                    {curr.name}
                  </span>
                  <div>
                    <span className="text-white text-xs font-bold font-serif">
                      {curr.name === "GBP" && "Pound Sterling"}
                      {curr.name === "USD" && "United States Dollar"}
                      {curr.name === "EUR" && "European Euro"}
                      {curr.name === "CHF" && "Swiss Franc"}
                      {curr.name === "JPY" && "Japanese Yen"}
                      {curr.name === "BTC" && "Bitcoin Core Reserve"}
                    </span>
                    <span className="text-[10px] text-slate-500 block uppercase">
                      {curr.name === "GBP" ? "Base Currency" : "Sovereign Peg / Asset Exposure"}
                    </span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-amber-100 font-bold block text-xs">
                    £{curr.value.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                  </span>
                  <span className="text-[10px] text-slate-400 block font-semibold bg-slate-900 px-1.5 py-0.5 rounded border border-slate-800">
                    {curr.percentage.toFixed(2)}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
