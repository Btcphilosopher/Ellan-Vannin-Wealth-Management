/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef } from "react";
import { Printer, FileText, Calendar, ShieldCheck, Landmark, Compass, Award } from "lucide-react";
import { PortfolioAsset, GenerationalMember, RiskMetrics } from "../types";
import { getAssetValuation } from "../utils/portfolio_engines";

interface ReportGeneratorPanelProps {
  assets: PortfolioAsset[];
  members: GenerationalMember[];
  riskMetrics: RiskMetrics;
  totalValue: number;
}

export const ReportGeneratorPanel: React.FC<ReportGeneratorPanelProps> = ({
  assets,
  members,
  riskMetrics,
  totalValue,
}) => {
  const printAreaRef = useRef<HTMLDivElement>(null);

  const handlePrint = () => {
    // Elegant print trigger. CSS @media print is perfect here!
    window.print();
  };

  const currentDateString = new Date().toLocaleDateString(undefined, {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <div className="space-y-6">
      {/* Control Panel bar */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="font-mono text-xs">
          <div className="flex items-center gap-2 text-amber-400 font-semibold uppercase tracking-wider mb-1">
            <FileText className="w-4 h-4 text-amber-500" />
            <span>Sovereign Report Engine</span>
          </div>
          <p className="text-slate-400">Generate high-fidelity, printable PDF/print briefs of portfolio performance, trust structures, and risk assessments.</p>
        </div>

        <button
          onClick={handlePrint}
          className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-mono font-bold text-xs px-4 py-2 rounded transition-all flex items-center gap-1.5 uppercase tracking-widest shadow-lg shrink-0 cursor-pointer"
        >
          <Printer className="w-4 h-4" />
          <span>Execute Print Job</span>
        </button>
      </div>

      {/* Printable Report Document (Aesthetic On-Screen Preview) */}
      <div
        id="printable-report-area"
        ref={printAreaRef}
        className="bg-slate-950 border border-slate-800 rounded-xl p-6 sm:p-10 text-white font-mono text-xs shadow-2xl relative overflow-hidden print:p-0 print:border-none print:bg-white print:text-slate-950"
      >
        {/* Cover Page Frame */}
        <div className="space-y-8 border-b border-slate-900 pb-10 print:border-slate-200">
          <div className="flex justify-between items-start">
            <div>
              <span className="text-[10px] text-amber-400 tracking-widest uppercase block font-bold print:text-amber-600">
                Ellan Vannin Wealth Management
              </span>
              <h1 className="text-xl sm:text-2xl font-bold font-serif text-white tracking-tight mt-1 print:text-slate-900">
                Global Portfolio Intelligence Platform
              </h1>
            </div>
            <div className="text-right shrink-0">
              <span className="text-[9px] text-slate-500 block uppercase font-bold">Document Code</span>
              <span className="text-[10px] text-white font-bold bg-slate-900 border border-slate-850 px-2 py-0.5 rounded print:text-slate-900 print:bg-slate-100">
                EV_GPIP_SECURE_95
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 border-t border-b border-slate-900 py-6 font-mono text-slate-400 print:border-slate-200 print:text-slate-700">
            <div className="space-y-1.5">
              <span className="text-[9px] text-slate-500 block uppercase font-bold">Prepared For</span>
              <strong className="text-white text-sm font-serif print:text-slate-900">The Callow Family Dynasty</strong>
              <span className="block text-[10px]">Isle of Man Registered Corporate Trust No. 44105</span>
            </div>
            <div className="space-y-1.5 text-left sm:text-right">
              <span className="text-[9px] text-slate-500 block uppercase font-bold">Reporting Date</span>
              <span className="text-white font-bold block print:text-slate-900">{currentDateString}</span>
              <span className="text-emerald-400 font-semibold text-[10px] block print:text-emerald-700">
                Security Classification: RESTRICTED PRINCIPAL ONLY
              </span>
            </div>
          </div>
        </div>

        {/* Section 1: Executive Summary */}
        <div className="space-y-4 py-8 border-b border-slate-900 print:border-slate-200 print:text-slate-950">
          <h2 className="text-sm font-serif text-amber-400 font-bold uppercase tracking-wider print:text-amber-700">
            I. Executive Valuation & Performance
          </h2>
          <p className="text-slate-300 leading-relaxed print:text-slate-700 text-justify">
            This portfolio tracking document provides a comprehensive audit of traditional, corporate, trust, and alternative holdings managed on behalf of Ellan Vannin Wealth clients. Current aggregate capitalization is audited at <strong className="text-white print:text-slate-900">£{totalValue.toLocaleString()}</strong>, showing resilient performance metrics and a balanced risk score of <strong className="text-white print:text-slate-900">{riskMetrics.riskScore}/10</strong>.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-3 font-mono text-center">
            <div className="bg-slate-900/40 p-3 rounded border border-slate-850 print:bg-slate-50 print:border-slate-200">
              <span className="text-[9px] text-slate-500 block uppercase">Total Valuation</span>
              <span className="text-sm font-bold text-white print:text-slate-900">£{totalValue.toLocaleString()}</span>
            </div>
            <div className="bg-slate-900/40 p-3 rounded border border-slate-850 print:bg-slate-50 print:border-slate-200">
              <span className="text-[9px] text-slate-500 block uppercase">Annual Volatility</span>
              <span className="text-sm font-bold text-amber-300 print:text-amber-700">{(riskMetrics.volatility * 100).toFixed(1)}%</span>
            </div>
            <div className="bg-slate-900/40 p-3 rounded border border-slate-850 print:bg-slate-50 print:border-slate-200">
              <span className="text-[9px] text-slate-500 block uppercase">Aggregate Beta</span>
              <span className="text-sm font-bold text-white print:text-slate-900">{riskMetrics.portfolioBeta.toFixed(2)}</span>
            </div>
            <div className="bg-slate-900/40 p-3 rounded border border-slate-850 print:bg-slate-50 print:border-slate-200">
              <span className="text-[9px] text-slate-500 block uppercase">95% Daily VaR</span>
              <span className="text-sm font-bold text-rose-400 print:text-rose-700">£{riskMetrics.valueAtRisk.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
            </div>
          </div>
        </div>

        {/* Section 2: Portfolio Inventory Table */}
        <div className="space-y-4 py-8 border-b border-slate-900 print:border-slate-200">
          <h2 className="text-sm font-serif text-amber-400 font-bold uppercase tracking-wider print:text-amber-700">
            II. Holdings & Position Roster
          </h2>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-[11px] font-mono print:text-slate-900">
              <thead>
                <tr className="border-b border-slate-800 text-slate-500 font-bold uppercase text-[9px] print:border-slate-300">
                  <th className="py-2">Position Name</th>
                  <th className="py-2">Asset category</th>
                  <th className="py-2 text-right">Cost Basis</th>
                  <th className="py-2 text-right">Market Valuation</th>
                  <th className="py-2 text-right">unrealised ROI</th>
                </tr>
              </thead>
              <tbody>
                {assets.map((asset) => {
                  const { currentVal, costBasis, unrealisedPl } = getAssetValuation(asset);
                  const roi = costBasis > 0 ? (unrealisedPl / costBasis) * 100 : 0;
                  
                  let title = "";
                  if (asset.equity) title = asset.equity.company;
                  else if (asset.bond) title = asset.bond.issuer;
                  else if (asset.fund) title = asset.fund.name;
                  else if (asset.property) title = asset.property.address;
                  else if (asset.privateEquity) title = asset.privateEquity.company;
                  else if (asset.bitcoin) title = "Sovereign Bitcoin Reserve";
                  else if (asset.commodity) title = `${asset.commodity.assetName} Spot`;
                  else if (asset.infrastructure) title = asset.infrastructure.projectName;
                  else if (asset.cash) title = `Cash Ledger (${asset.cash.currency})`;

                  return (
                    <tr key={asset.id} className="border-b border-slate-900/50 print:border-slate-150">
                      <td className="py-2 font-bold text-slate-300 font-serif print:text-slate-900">{title}</td>
                      <td className="py-2 text-slate-500 uppercase text-[9px]">{asset.category}</td>
                      <td className="py-2 text-right">£{costBasis.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                      <td className="py-2 text-right font-extrabold text-amber-100 print:text-slate-900">£{currentVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                      <td className={`py-2 text-right font-bold ${unrealisedPl >= 0 ? "text-emerald-400 print:text-emerald-700" : "text-rose-400 print:text-rose-700"}`}>
                        {unrealisedPl >= 0 ? "+" : ""}
                        {roi.toFixed(1)}%
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Section 3: Dynasty trust Allocations */}
        {members.length > 0 && (
          <div className="space-y-4 py-8 border-b border-slate-900 print:border-slate-200">
            <h2 className="text-sm font-serif text-amber-400 font-bold uppercase tracking-wider print:text-amber-700">
              III. Intergenerational Dynasty Beneficiaries
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 font-mono text-xs">
              {members.map((m) => (
                <div key={m.id} className="bg-slate-900/20 p-3 rounded border border-slate-850 print:border-slate-200 print:bg-slate-50">
                  <div className="flex justify-between items-center font-serif text-white font-bold print:text-slate-900">
                    <span>{m.name}</span>
                    <span className="text-amber-400 text-xs font-mono print:text-amber-700">{m.allocatedShare}% Target</span>
                  </div>
                  <div className="flex justify-between text-[10px] text-slate-500 mt-1">
                    <span>Structure: {m.trustStructure}</span>
                    <span className="text-emerald-400 font-bold print:text-emerald-700">
                      {m.inheritanceTaxPlanned ? "Trust Protected (IOM)" : "Review Needed"}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Section 4: Signature Signoffs */}
        <div className="pt-12 grid grid-cols-1 sm:grid-cols-2 gap-10 font-mono text-[10px] text-slate-500 print:text-slate-600">
          <div className="space-y-6">
            <p className="leading-relaxed">
              <strong>Prepared & Audited by:</strong>
              <br />
              Ellan Vannin Wealth Management Portfolio Desk
              <br />
              Athol Street, Douglas, Isle of Man
            </p>
            <div className="border-t border-slate-800 w-full pt-2 print:border-slate-400">
              <span>Authorized Portfolio Desk Signature</span>
              <span className="block text-[8px] text-slate-600">EV_GPIP_SIGN_OK_2026</span>
            </div>
          </div>

          <div className="space-y-6 text-left sm:text-right">
            <p className="leading-relaxed">
              <strong>Acknowledged by Principal Beneficiary:</strong>
              <br />
              Callow Dynasty Trusts Representative
              <br />
              Douglas, Isle of Man
            </p>
            <div className="border-t border-slate-800 w-full pt-2 print:border-slate-400 flex flex-col items-start sm:items-end">
              <span>Dynasty Representative Signature</span>
              <span className="block text-[8px] text-slate-600">CLIENT_ACK_PENDING</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
