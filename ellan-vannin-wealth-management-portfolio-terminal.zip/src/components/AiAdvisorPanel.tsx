/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Sparkles, Brain, RefreshCw, Send, ShieldAlert, Award } from "lucide-react";
import ReactMarkdown from "react-markdown";

interface AiAdvisorPanelProps {
  totalValue: number;
  riskScore: number;
}

const ADVISORY_SCENARIOS = [
  { id: "tax_mitigation", label: "Sovereign Tax Shield Options", prompt: "Evaluate offshore trust configurations in the Isle of Man for a £10m+ family office client. Analyze inheritance tax (IHT) mitigation advantages, capital gains tax deferrals, and corporate holding structures." },
  { id: "sov_allocation", label: "Sovereign Fund Rebalancing", prompt: "Recommend strategic reserve allocation changes to adjust for a rising interest rate climate. Contrast our current heavy liquid positions against sovereign infrastructure commitments." },
  { id: "britain_2040", label: "Britain 2040 Infrastructure", prompt: "Assess physical real asset opportunities inside the UK's high-speed rail, localized smart microgrids, and commercial data warehouses. Outline private capital partnership models." },
  { id: "alt_hedging", label: "Bitcoin & Alt-Asset Hedging", prompt: "Provide an institutional-grade risk assessment of holding 10% Bitcoin in a diversified family office treasury. Explain volatility dampening features, drawdowns, and cold storage custody protocols." },
];

export const AiAdvisorPanel: React.FC<AiAdvisorPanelProps> = ({
  totalValue,
  riskScore,
}) => {
  const [selectedPrompt, setSelectedPrompt] = useState(ADVISORY_SCENARIOS[0].prompt);
  const [customQuery, setCustomQuery] = useState("");
  const [briefing, setBriefing] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const fetchBriefing = async (queryText: string) => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch("/api/gemini/advisor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          portfolioState: {
            totalValue,
            riskMetrics: {
              riskScore,
              volatility: 0.115 // default or estimated
            }
          },
          promptType: queryText,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to communicate with Aladdin AI server. Check backend console logs.");
      }

      const data = await response.json();
      setBriefing(data.advice || "No recommendation generated.");
    } catch (err: any) {
      setError(err.message || "An unexpected advisor socket error occurred.");
    } finally {
      setLoading(false);
    }
  };

  const handleScenarioClick = (prompt: string) => {
    setSelectedPrompt(prompt);
    fetchBriefing(prompt);
  };

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customQuery) return;
    fetchBriefing(customQuery);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl space-y-5">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-500/10 border border-amber-500/30 text-amber-500 rounded-lg shadow-[0_0_15px_rgba(245,158,11,0.15)] animate-pulse">
            <Brain className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-white font-serif font-bold text-sm">Aladdin AI Portfolio Advisory Terminal</h3>
              <span className="text-[10px] bg-amber-500/10 border border-amber-500/20 text-amber-400 font-mono px-2 rounded font-bold uppercase tracking-widest">
                Gemini 2.5 Flash
              </span>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">Real-time macro investment modeling & tax architect</span>
          </div>
        </div>

        <div className="text-right font-mono text-[10px] text-slate-500 mt-2 sm:mt-0">
          Portfolio Value: <strong className="text-white">£{totalValue.toLocaleString()}</strong>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 font-mono text-xs">
        {/* Scenario selectors */}
        <div className="space-y-3">
          <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest block">Advisory Scenarios</span>
          <div className="space-y-2">
            {ADVISORY_SCENARIOS.map((sc) => (
              <button
                key={sc.id}
                onClick={() => handleScenarioClick(sc.prompt)}
                className={`w-full text-left p-3 rounded-lg border transition-all ${
                  selectedPrompt === sc.prompt
                    ? "bg-slate-950 border-amber-500/40 text-amber-300 shadow-md"
                    : "bg-slate-950/60 border-slate-850 text-slate-400 hover:text-slate-200"
                }`}
              >
                <div className="font-bold font-serif text-xs flex items-center gap-2">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  <span>{sc.label}</span>
                </div>
                <p className="text-[10px] text-slate-500 mt-1.5 leading-relaxed truncate">
                  {sc.prompt}
                </p>
              </button>
            ))}
          </div>

          {/* Custom Instruction Box */}
          <form onSubmit={handleCustomSubmit} className="pt-2 space-y-2">
            <span className="text-[10px] text-slate-500 font-bold uppercase tracking-widest block">Query custom briefing</span>
            <div className="flex gap-1.5 bg-slate-950 border border-slate-800 rounded p-1.5 focus-within:border-amber-500 transition-all">
              <input
                type="text"
                value={customQuery}
                onChange={(e) => setCustomQuery(e.target.value)}
                placeholder="Ask e.g. Evaluate sovereign gilt duration..."
                className="bg-transparent border-none outline-none text-xs text-white placeholder-slate-600 flex-1 px-1.5"
              />
              <button
                type="submit"
                disabled={loading || !customQuery}
                className="bg-amber-500 hover:bg-amber-600 text-slate-950 px-2 py-1.5 rounded font-bold transition-all shrink-0"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </div>
          </form>
        </div>

        {/* AI Output Terminal */}
        <div className="lg:col-span-2 flex flex-col h-[400px] bg-slate-950 border border-slate-850 rounded-lg overflow-hidden relative">
          <div className="bg-slate-950/90 border-b border-slate-900 px-4 py-2 flex items-center justify-between text-[10px] text-slate-400">
            <span className="uppercase font-bold text-amber-500 flex items-center gap-1">
              <Award className="w-3.5 h-3.5" />
              Strategic Advisory Output
            </span>
            <span className="font-bold">GPIP_ALADDIN_INTELLIGENCE</span>
          </div>

          {/* Main advice text */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {loading ? (
              <div className="flex flex-col items-center justify-center h-full space-y-3 text-slate-500">
                <RefreshCw className="w-8 h-8 animate-spin text-amber-500" />
                <span className="animate-pulse">Accessing Aladdin Sovereign Policy Databases...</span>
              </div>
            ) : error ? (
              <div className="flex items-start gap-2.5 p-3.5 bg-rose-500/10 border border-rose-500/20 text-rose-400 rounded-lg">
                <ShieldAlert className="w-5 h-5 shrink-0 mt-0.5" />
                <div>
                  <span className="font-bold block">Advisory Connection Error</span>
                  <p className="text-[11px] mt-1">{error}</p>
                </div>
              </div>
            ) : briefing ? (
              <div className="markdown-body text-slate-300 text-xs leading-relaxed font-mono space-y-4 selection:bg-amber-500/20">
                <ReactMarkdown>{briefing}</ReactMarkdown>
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center h-full text-center space-y-2 text-slate-500 p-6">
                <Brain className="w-12 h-12 text-slate-800" />
                <span className="font-bold text-white font-serif text-sm">Initiate Advisory Protocol</span>
                <p className="text-[11px] max-w-sm mt-1 leading-relaxed">
                  Select an advisory scenario on the left, or query custom tactical briefings to trigger real-time AI strategic reports on this portfolio.
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
