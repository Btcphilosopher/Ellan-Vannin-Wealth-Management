/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Users, Shield, Award, Heart, Plus, Trash2, HeartHandshake, Info } from "lucide-react";
import { GenerationalMember } from "../types";

interface FamilyOfficeViewProps {
  members: GenerationalMember[];
  role: "Client" | "Advisor" | "Administrator";
  onAddMember: (member: Omit<GenerationalMember, "id">) => void;
  onDeleteMember: (id: string) => void;
  totalPortfolioValue: number;
}

export const FamilyOfficeView: React.FC<FamilyOfficeViewProps> = ({
  members,
  role,
  onAddMember,
  onDeleteMember,
  totalPortfolioValue,
}) => {
  const [name, setName] = useState("");
  const [relationship, setRelationship] = useState("");
  const [allocatedShare, setAllocatedShare] = useState("");
  const [trustStructure, setTrustStructure] = useState("");
  const [inheritanceTaxPlanned, setInheritanceTaxPlanned] = useState(false);

  const totalAllocatedShares = members.reduce((sum, m) => sum + m.allocatedShare, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !allocatedShare || isNaN(Number(allocatedShare))) return;
    onAddMember({
      name,
      relationship,
      allocatedShare: Number(allocatedShare),
      trustStructure,
      inheritanceTaxPlanned,
    });
    setName("");
    setRelationship("");
    setAllocatedShare("");
    setTrustStructure("");
    setInheritanceTaxPlanned(false);
  };

  // Compute estate value per member
  const getEstateValue = (share: number) => {
    return totalPortfolioValue * (share / 100);
  };

  // Calculate potential UK Inheritance Tax savings (40% rate in UK, whereas IOM Trusts can avoid this!)
  const totalPotentialTaxSavings = totalPortfolioValue * 0.40;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl">
      <div className="flex flex-col lg:flex-row items-start justify-between gap-6 border-b border-slate-800 pb-5 mb-5 font-mono">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs uppercase tracking-widest mb-1">
            <Users className="w-4 h-4" />
            <span>Generational Capital Terminal</span>
          </div>
          <h2 className="text-xl font-bold text-white font-serif">Dynasty Wealth & Estate Architect</h2>
          <p className="text-slate-400 text-xs mt-1 max-w-xl font-mono leading-relaxed">
            Multi-generational beneficiary trust registries, philanthropy tracking, and offshore estate planning vectors for high-net-worth principal structures.
          </p>
        </div>
        <div className="flex gap-4">
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-500 block uppercase">Allocated Dynasty Equity</span>
            <span className="text-lg font-bold text-amber-300">
              {totalAllocatedShares}%
            </span>
          </div>
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-500 block uppercase">Dynasty Estate Vault</span>
            <span className="text-lg font-bold text-white">
              £{totalPortfolioValue.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Dynasty Roster & Trust Structures */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-mono text-amber-400 font-semibold uppercase tracking-wider">
              Beneficiary Dynasty & Trust Roster
            </h3>
            {totalAllocatedShares !== 100 && (
              <span className="text-[10px] font-mono text-amber-500 bg-amber-500/10 border border-amber-500/20 px-2 py-0.5 rounded">
                Allocation Sum: {totalAllocatedShares}% (Needs {100 - totalAllocatedShares}% unassigned)
              </span>
            )}
          </div>

          <div className="space-y-3">
            {members.map((m) => {
              const estateVal = getEstateValue(m.allocatedShare);
              return (
                <div
                  key={m.id}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-4 transition-all hover:border-amber-500/20"
                >
                  <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="text-white font-semibold font-serif text-sm">
                          {m.name}
                        </h4>
                        <span className="text-[10px] bg-slate-900 border border-slate-800 text-slate-400 px-2 rounded font-mono">
                          {m.relationship}
                        </span>
                        <span className="text-[10px] bg-amber-500/10 border border-amber-500/20 text-amber-300 px-2 py-0.5 rounded font-mono">
                          Share: {m.allocatedShare}%
                        </span>
                      </div>
                      <p className="text-slate-400 text-xs mt-2 font-mono">
                        Trust Vehicle: <strong className="text-slate-300">{m.trustStructure}</strong>
                      </p>
                    </div>

                    <div className="flex items-end sm:flex-col justify-between w-full sm:w-auto gap-4">
                      <div className="text-left sm:text-right font-mono">
                        <span className="text-slate-500 text-[10px] block uppercase">Est. Allocation</span>
                        <span className="text-amber-100 font-bold text-sm">
                          £{estateVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </span>
                      </div>
                      {role === "Administrator" && (
                        <button
                          onClick={() => onDeleteMember(m.id)}
                          className="text-slate-500 hover:text-rose-400 transition-colors"
                          title="Revoke dynasty allocation"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="mt-3 pt-3 border-t border-slate-900 flex items-center justify-between text-[11px] font-mono">
                    <span className="text-slate-500">Estate Inheritance Plan:</span>
                    <span
                      className={`font-semibold px-2 rounded-full ${
                        m.inheritanceTaxPlanned
                          ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20"
                          : "bg-amber-500/10 text-amber-400 border border-amber-500/20"
                      }`}
                    >
                      {m.inheritanceTaxPlanned ? "Trust Secured (IOM)" : "Review Required"}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Tax mitigation metrics */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 font-mono">
            <div className="bg-gradient-to-br from-amber-950/20 to-slate-950 border border-amber-500/10 rounded-lg p-4 flex items-start gap-3">
              <Shield className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-amber-300 font-bold text-xs uppercase">Sovereign Trust Shield</h4>
                <p className="text-slate-400 text-[11px] mt-1 leading-relaxed">
                  Capital gains & inheritance tax liability is minimized under Isle of Man Class 3 corporate trusts. Potential preservation is up to **£{totalPotentialTaxSavings.toLocaleString(undefined, { maximumFractionDigits: 0 })}** compared to onshore jurisdiction.
                </p>
              </div>
            </div>

            <div className="bg-gradient-to-br from-amber-950/10 to-slate-950 border border-slate-800 rounded-lg p-4 flex items-start gap-3">
              <HeartHandshake className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-emerald-400 font-bold text-xs uppercase">Generational Philanthropy</h4>
                <p className="text-slate-400 text-[11px] mt-1 leading-relaxed">
                  Your registered trusts have distributed **£80,000** annually to designated Manx community healthcare and global conservation charities.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Panel: Add dynasty beneficiary */}
        <div>
          {role === "Administrator" || role === "Advisor" ? (
            <form onSubmit={handleSubmit} className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-4">
              <h3 className="text-sm font-mono text-amber-400 font-semibold uppercase tracking-wider">
                Enroll Beneficiary
              </h3>

              <div className="space-y-1 font-mono">
                <label className="text-[10px] text-slate-500 block uppercase font-bold">Full Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Victoria Callow-Christian"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none"
                />
              </div>

              <div className="space-y-1 font-mono">
                <label className="text-[10px] text-slate-500 block uppercase font-bold">Generational Relation</label>
                <input
                  type="text"
                  required
                  value={relationship}
                  onChange={(e) => setRelationship(e.target.value)}
                  placeholder="e.g. G2 Daughter, G3 Grandchild"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none"
                />
              </div>

              <div className="space-y-1 font-mono">
                <label className="text-[10px] text-slate-500 block uppercase font-bold">Allocation Share (%)</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  required
                  value={allocatedShare}
                  onChange={(e) => setAllocatedShare(e.target.value)}
                  placeholder="e.g. 15"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none"
                />
              </div>

              <div className="space-y-1 font-mono">
                <label className="text-[10px] text-slate-500 block uppercase font-bold">Trust Structure Designation</label>
                <input
                  type="text"
                  required
                  value={trustStructure}
                  onChange={(e) => setTrustStructure(e.target.value)}
                  placeholder="e.g. The Callow Intervivos Trust"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none"
                />
              </div>

              <div className="flex items-center gap-2 pt-2 font-mono">
                <input
                  type="checkbox"
                  id="inheritanceTaxPlanned"
                  checked={inheritanceTaxPlanned}
                  onChange={(e) => setInheritanceTaxPlanned(e.target.checked)}
                  className="w-4 h-4 bg-slate-900 border border-slate-800 rounded checked:bg-amber-500 checked:border-amber-500 focus:ring-0"
                />
                <label htmlFor="inheritanceTaxPlanned" className="text-xs text-slate-400 font-bold uppercase cursor-pointer selection:bg-transparent">
                  Trust Asset Protection Secured
                </label>
              </div>

              <button
                type="submit"
                className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-mono font-bold text-xs py-2 rounded transition-all flex items-center justify-center gap-1.5 uppercase tracking-widest shadow-lg"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Inject Dynasty Beneficiary</span>
              </button>
            </form>
          ) : (
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-5 text-center space-y-4">
              <Info className="w-8 h-8 text-amber-500/40 mx-auto" />
              <div>
                <h4 className="text-white text-xs font-mono uppercase font-bold">Read-Only Trust Vault</h4>
                <p className="text-slate-500 text-[11px] font-mono mt-1 leading-relaxed">
                  You are logged in as a <strong>Client</strong>. Elevate role privileges to <strong>Advisor</strong> or <strong>Administrator</strong> in the header to modify trust records.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
