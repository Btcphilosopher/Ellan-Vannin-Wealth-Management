/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Landmark, ArrowRight, ShieldCheck, Plus, Trash2, HelpCircle } from "lucide-react";
import { StrategicReserve } from "../types";

interface SovereignFundViewProps {
  reserves: StrategicReserve[];
  role: "Client" | "Advisor" | "Administrator";
  onAddReserve: (reserve: Omit<StrategicReserve, "id">) => void;
  onDeleteReserve: (id: string) => void;
  totalPortfolioValue: number;
}

export const SovereignFundView: React.FC<SovereignFundViewProps> = ({
  reserves,
  role,
  onAddReserve,
  onDeleteReserve,
  totalPortfolioValue,
}) => {
  const [assetName, setAssetName] = useState("");
  const [type, setType] = useState<StrategicReserve["type"]>("Permanent Capital");
  const [amountGbp, setAmountGbp] = useState("");
  const [purpose, setPurpose] = useState("");

  const totalReservesValue = reserves.reduce((sum, res) => sum + res.amountGbp, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!assetName || !amountGbp || isNaN(Number(amountGbp))) return;
    onAddReserve({
      assetName,
      type,
      amountGbp: Number(amountGbp),
      purpose,
    });
    setAssetName("");
    setAmountGbp("");
    setPurpose("");
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl">
      <div className="flex flex-col lg:flex-row items-start justify-between gap-6 border-b border-slate-800 pb-5 mb-5">
        <div>
          <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest mb-1">
            <Landmark className="w-4 h-4" />
            <span>Sovereign Fund System Module</span>
          </div>
          <h2 className="text-xl font-bold text-white font-serif">Sovereign Strategic Reserve Registry</h2>
          <p className="text-slate-400 text-xs mt-1 max-w-xl font-mono">
            Tracks permanent strategic reserves, resource networks, and connectivity capital held by the Ellan Vannin Sovereign Investment Mandate for long-term fiscal support.
          </p>
        </div>
        <div className="flex gap-4 font-mono">
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-500 block uppercase">Strategic Reserves Base</span>
            <span className="text-lg font-bold text-amber-300">
              £{totalReservesValue.toLocaleString()}
            </span>
          </div>
          <div className="bg-slate-950 p-3 rounded border border-slate-800">
            <span className="text-[10px] text-slate-500 block uppercase">Total Capital Footprint</span>
            <span className="text-lg font-bold text-white">
              £{(totalPortfolioValue + totalReservesValue).toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Reserve List */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-sm font-mono text-amber-400 font-semibold uppercase tracking-wider mb-2">
            Active Strategic Reserve Holdings
          </h3>
          <div className="space-y-3">
            {reserves.map((res) => (
              <div
                key={res.id}
                className="bg-slate-950 border border-slate-800 rounded-lg p-4 transition-all hover:border-amber-500/20"
              >
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-white font-semibold font-serif text-sm">
                        {res.assetName}
                      </h4>
                      <span className="text-[10px] bg-slate-900 border border-slate-800 text-amber-300 px-2 py-0.5 rounded font-mono uppercase">
                        {res.type}
                      </span>
                    </div>
                    <p className="text-slate-400 text-xs mt-2 font-mono leading-relaxed">
                      {res.purpose}
                    </p>
                  </div>
                  <div className="flex flex-col items-end gap-2 text-right">
                    <span className="text-amber-100 font-mono font-bold text-sm">
                      £{res.amountGbp.toLocaleString()}
                    </span>
                    {role === "Administrator" && (
                      <button
                        onClick={() => onDeleteReserve(res.id)}
                        className="text-slate-500 hover:text-rose-400 transition-colors duration-150"
                        title="Liquidate strategic position"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Capital Allocation Logic Banner */}
          <div className="bg-gradient-to-r from-amber-950/20 to-slate-950 border border-amber-500/10 rounded-lg p-4 flex items-start gap-3 mt-4">
            <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div className="text-xs">
              <h4 className="text-amber-300 font-bold font-mono uppercase">Manx Permanent Capital Mandate</h4>
              <p className="text-slate-400 mt-1 font-mono leading-relaxed">
                Strategic Reserves are legally protected under Sovereign Acts. Releasing Permanent Capital requires standard Parliamentary joint assent or emergency liquidity triggers (e.g. currency peg stabilization).
              </p>
            </div>
          </div>
        </div>

        {/* Action Panel: Add strategic position */}
        <div>
          {role === "Administrator" || role === "Advisor" ? (
            <form onSubmit={handleSubmit} className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-4">
              <h3 className="text-sm font-mono text-amber-400 font-semibold uppercase tracking-wider">
                Provision Sovereign Capital
              </h3>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 font-mono block uppercase font-bold">Asset / Reserve Title</label>
                <input
                  type="text"
                  required
                  value={assetName}
                  onChange={(e) => setAssetName(e.target.value)}
                  placeholder="e.g. Douglas South Green Grid Link"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 font-mono block uppercase font-bold">Strategic Class</label>
                <select
                  value={type}
                  onChange={(e) => setType(e.target.value as any)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white focus:border-amber-500 outline-none font-mono"
                >
                  <option value="Permanent Capital">Permanent Capital Asset</option>
                  <option value="Natural Resource">Natural Resource Reserve</option>
                  <option value="Strategic Commodity Reserve">Strategic Commodity Reserve</option>
                  <option value="Foreign Exchange Reserve">FX Sovereign Liquidity Pool</option>
                </select>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 font-mono block uppercase font-bold">Assigned Capital (GBP)</label>
                <input
                  type="number"
                  required
                  value={amountGbp}
                  onChange={(e) => setAmountGbp(e.target.value)}
                  placeholder="e.g. 5000000"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none font-mono"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 font-mono block uppercase font-bold">Strategic Directives</label>
                <textarea
                  required
                  rows={3}
                  value={purpose}
                  onChange={(e) => setPurpose(e.target.value)}
                  placeholder="Summarize the geopolitical or sovereign stability purpose of this position..."
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none font-mono resize-none"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-mono font-bold text-xs py-2 rounded transition-all flex items-center justify-center gap-1.5 uppercase tracking-widest shadow-lg"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Inject Sovereign Reserve</span>
              </button>
            </form>
          ) : (
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-5 text-center space-y-4">
              <HelpCircle className="w-8 h-8 text-amber-500/40 mx-auto" />
              <div>
                <h4 className="text-white text-xs font-mono uppercase font-bold">Read-Only Sovereign Vault</h4>
                <p className="text-slate-500 text-[11px] font-mono mt-1 leading-relaxed">
                  You are logged in as a <strong>Client</strong>. Elevate role privileges to <strong>Advisor</strong> or <strong>Administrator</strong> in the header to authorize sovereign reserve deployment.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
