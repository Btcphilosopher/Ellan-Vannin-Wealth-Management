/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Landmark, Compass, Train, Wind, HardDrive, Trees, Anchor, Plus, Trash2, ShieldAlert } from "lucide-react";
import { InfrastructureAsset } from "../types";

interface InfrastructureModuleViewProps {
  infrastructureAssets: InfrastructureAsset[];
  role: "Client" | "Advisor" | "Administrator";
  onAddInfrastructure: (infra: Omit<InfrastructureAsset, "id">) => void;
  onDeleteInfrastructure: (id: string) => void;
}

export const InfrastructureModuleView: React.FC<InfrastructureModuleViewProps> = ({
  infrastructureAssets,
  role,
  onAddInfrastructure,
  onDeleteInfrastructure,
}) => {
  const [projectName, setProjectName] = useState("");
  const [projectType, setProjectType] = useState<InfrastructureAsset["projectType"]>("Energy");
  const [investmentAmount, setInvestmentAmount] = useState("");
  const [expectedIrr, setExpectedIrr] = useState("");
  const [currentValuation, setCurrentValuation] = useState("");
  const [annualIncome, setAnnualIncome] = useState("");
  const [stage, setStage] = useState<InfrastructureAsset["stage"]>("Operational");

  const totalInvestment = infrastructureAssets.reduce((sum, inf) => sum + inf.investmentAmount, 0);
  const totalValuation = infrastructureAssets.reduce((sum, inf) => sum + inf.currentValuation, 0);
  const totalAnnualIncome = infrastructureAssets.reduce((sum, inf) => sum + inf.annualIncome, 0);

  // Compute average IRR weighted by investment amount
  const weightedIrrSum = infrastructureAssets.reduce((sum, inf) => sum + inf.expectedIrr * inf.investmentAmount, 0);
  const averageIrr = totalInvestment > 0 ? weightedIrrSum / totalInvestment : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!projectName || !investmentAmount || !expectedIrr || !currentValuation || !annualIncome) return;
    onAddInfrastructure({
      projectName,
      projectType,
      investmentAmount: Number(investmentAmount),
      expectedIrr: Number(expectedIrr),
      currentValuation: Number(currentValuation),
      annualIncome: Number(annualIncome),
      stage,
    });
    setProjectName("");
    setInvestmentAmount("");
    setExpectedIrr("");
    setCurrentValuation("");
    setAnnualIncome("");
  };

  const getIcon = (type: InfrastructureAsset["projectType"]) => {
    switch (type) {
      case "Rail":
        return <Train className="w-4 h-4 text-sky-400" />;
      case "Port":
        return <Anchor className="w-4 h-4 text-emerald-400" />;
      case "Energy":
        return <Wind className="w-4 h-4 text-amber-400" />;
      case "Data Centre":
        return <HardDrive className="w-4 h-4 text-indigo-400" />;
      case "Forestry":
        return <Trees className="w-4 h-4 text-teal-400" />;
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl">
      <div className="flex flex-col lg:flex-row items-start justify-between gap-6 border-b border-slate-800 pb-5 mb-5 font-mono">
        <div>
          <div className="flex items-center gap-2 text-amber-400 text-xs uppercase tracking-widest mb-1">
            <Compass className="w-4 h-4 animate-spin-slow" />
            <span>Heavy Alternative Real Asset Module</span>
          </div>
          <h2 className="text-xl font-bold text-white font-serif">Infrastructure Real Estate Portfolio</h2>
          <p className="text-slate-400 text-xs mt-1 max-w-xl leading-relaxed">
            Direct equity investment registry in transport rail links, energy networks, data infrastructures, carbon sink forestry, and industrial connectivity nodes.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center">
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <span className="text-[9px] text-slate-500 block uppercase">Orig. Committed</span>
            <span className="text-xs font-bold text-slate-300">£{totalInvestment.toLocaleString()}</span>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <span className="text-[9px] text-slate-500 block uppercase">Current Value</span>
            <span className="text-xs font-bold text-white">£{totalValuation.toLocaleString()}</span>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <span className="text-[9px] text-slate-500 block uppercase">Annual Dividend</span>
            <span className="text-xs font-bold text-emerald-400">£{totalAnnualIncome.toLocaleString()}</span>
          </div>
          <div className="bg-slate-950 p-2.5 rounded border border-slate-800">
            <span className="text-[9px] text-slate-500 block uppercase">Weighted IRR</span>
            <span className="text-xs font-bold text-amber-300">{averageIrr.toFixed(2)}%</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Project table / list */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-sm font-mono text-amber-400 font-semibold uppercase tracking-wider">
            Direct Real Asset Positions
          </h3>

          <div className="space-y-3">
            {infrastructureAssets.map((inf) => (
              <div
                key={inf.id}
                className="bg-slate-950 border border-slate-800 rounded-lg p-4 transition-all hover:border-amber-500/20"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 font-mono">
                  <div>
                    <div className="flex items-center gap-2">
                      <div className="p-1.5 bg-slate-900 border border-slate-800 rounded">
                        {getIcon(inf.projectType)}
                      </div>
                      <h4 className="text-white font-semibold font-serif text-sm">
                        {inf.projectName}
                      </h4>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mt-3 text-[10px] text-slate-400">
                      <div>
                        <span className="text-slate-500 block text-[9px] uppercase">Committed</span>
                        <span className="font-bold">£{inf.investmentAmount.toLocaleString()}</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[9px] uppercase">Target IRR</span>
                        <span className="font-bold text-amber-300">{inf.expectedIrr}%</span>
                      </div>
                      <div>
                        <span className="text-slate-500 block text-[9px] uppercase">Annual Income</span>
                        <span className="font-bold text-emerald-400">£{inf.annualIncome.toLocaleString()}</span>
                      </div>
                    </div>
                  </div>

                  <div className="flex sm:flex-col items-center sm:items-end justify-between sm:text-right gap-2 border-t sm:border-t-0 border-slate-900 pt-3 sm:pt-0">
                    <div>
                      <span className="text-slate-500 text-[9px] block uppercase">Current Value</span>
                      <span className="text-sm font-extrabold text-amber-100">
                        £{inf.currentValuation.toLocaleString()}
                      </span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-[9px] bg-slate-900 border border-slate-800 text-slate-300 px-2 py-0.5 rounded uppercase">
                        {inf.stage}
                      </span>
                      {role === "Administrator" && (
                        <button
                          onClick={() => onDeleteInfrastructure(inf.id)}
                          className="text-slate-500 hover:text-rose-400 transition-all"
                          title="Liquidate physical real asset holding"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Panel: Commitment Form */}
        <div>
          {role === "Administrator" || role === "Advisor" ? (
            <form onSubmit={handleSubmit} className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-4">
              <h3 className="text-sm font-mono text-amber-400 font-semibold uppercase tracking-wider">
                Asset Commitment Setup
              </h3>

              <div className="space-y-1 font-mono">
                <label className="text-[10px] text-slate-500 block uppercase font-bold">Project / Asset Name</label>
                <input
                  type="text"
                  required
                  value={projectName}
                  onChange={(e) => setProjectName(e.target.value)}
                  placeholder="e.g. Douglas South Data Vault"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 block uppercase font-bold">Asset Type</label>
                  <select
                    value={projectType}
                    onChange={(e) => setProjectType(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white focus:border-amber-500 outline-none"
                  >
                    <option value="Rail">Rail Link</option>
                    <option value="Port">Marine Port</option>
                    <option value="Energy">Energy Network</option>
                    <option value="Data Centre">Data Centre</option>
                    <option value="Forestry">Forestry Sink</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 block uppercase font-bold">Project Stage</label>
                  <select
                    value={stage}
                    onChange={(e) => setStage(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white focus:border-amber-500 outline-none"
                  >
                    <option value="Planning">Planning Phase</option>
                    <option value="Construction">Under Construction</option>
                    <option value="Operational">Fully Operational</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 block uppercase font-bold">Committed Capital (£)</label>
                  <input
                    type="number"
                    required
                    value={investmentAmount}
                    onChange={(e) => setInvestmentAmount(e.target.value)}
                    placeholder="e.g. 1000000"
                    className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 block uppercase font-bold">Expected IRR (%)</label>
                  <input
                    type="number"
                    step="0.1"
                    required
                    value={expectedIrr}
                    onChange={(e) => setExpectedIrr(e.target.value)}
                    placeholder="e.g. 12.5"
                    className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 font-mono">
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 block uppercase font-bold">Current Valuation (£)</label>
                  <input
                    type="number"
                    required
                    value={currentValuation}
                    onChange={(e) => setCurrentValuation(e.target.value)}
                    placeholder="e.g. 1150000"
                    className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 block uppercase font-bold">Annual Dividends (£)</label>
                  <input
                    type="number"
                    required
                    value={annualIncome}
                    onChange={(e) => setAnnualIncome(e.target.value)}
                    placeholder="e.g. 75000"
                    className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-mono font-bold text-xs py-2 rounded transition-all flex items-center justify-center gap-1.5 uppercase tracking-widest shadow-lg"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Issue Asset Commitment</span>
              </button>
            </form>
          ) : (
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-5 text-center space-y-4">
              <ShieldAlert className="w-8 h-8 text-amber-500/40 mx-auto" />
              <div>
                <h4 className="text-white text-xs font-mono uppercase font-bold">Commitment Vault Locked</h4>
                <p className="text-slate-500 text-[11px] font-mono mt-1 leading-relaxed">
                  You are logged in as a <strong>Client</strong>. Elevate role privileges to <strong>Advisor</strong> or <strong>Administrator</strong> in the header to modify committed asset structures.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
