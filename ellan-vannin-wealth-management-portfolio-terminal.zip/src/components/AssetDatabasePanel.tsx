/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Search, Filter, Plus, Trash2, Edit2, ShieldAlert, Landmark, Sparkles, AlertCircle } from "lucide-react";
import { PortfolioAsset, AssetCategory } from "../types";
import { getAssetValuation } from "../utils/portfolio_engines";

interface AssetDatabasePanelProps {
  assets: PortfolioAsset[];
  role: "Client" | "Advisor" | "Administrator";
  onAddAsset: (asset: Omit<PortfolioAsset, "id">) => void;
  onUpdateAsset: (asset: PortfolioAsset) => void;
  onDeleteAsset: (id: string) => void;
}

export const AssetDatabasePanel: React.FC<AssetDatabasePanelProps> = ({
  assets,
  role,
  onAddAsset,
  onUpdateAsset,
  onDeleteAsset,
}) => {
  const [activeTab, setActiveTab] = useState<AssetCategory | "All">("All");
  const [searchQuery, setSearchQuery] = useState("");

  // Asset creation state
  const [isAdding, setIsAdding] = useState(false);
  const [newCategory, setNewCategory] = useState<AssetCategory>("Equities");

  // Equity sub-form fields
  const [eqCompany, setEqCompany] = useState("");
  const [eqTicker, setEqTicker] = useState("");
  const [eqShares, setEqShares] = useState("");
  const [eqPurchase, setEqPurchase] = useState("");
  const [eqCurrent, setEqCurrent] = useState("");

  // Bond sub-form fields
  const [bdIssuer, setBdIssuer] = useState("");
  const [bdTicker, setBdTicker] = useState("");
  const [bdFace, setBdFace] = useState("");
  const [bdPurchasePct, setBdPurchasePct] = useState("");
  const [bdCurrentPct, setBdCurrentPct] = useState("");
  const [bdMaturity, setBdMaturity] = useState("");
  const [bdCoupon, setBdCoupon] = useState("");

  // Cash sub-form fields
  const [csAmount, setCsAmount] = useState("");
  const [csCurrency, setCsCurrency] = useState<"GBP" | "USD" | "EUR" | "CHF" | "JPY">("GBP");
  const [csRate, setCsRate] = useState("1.0");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    let assetPayload: Omit<PortfolioAsset, "id"> = { category: newCategory };

    if (newCategory === "Equities") {
      if (!eqCompany || !eqTicker || !eqShares || !eqPurchase || !eqCurrent) return;
      assetPayload.equity = {
        id: "",
        company: eqCompany,
        ticker: eqTicker,
        shares: Number(eqShares),
        purchasePrice: Number(eqPurchase),
        currentPrice: Number(eqCurrent),
        dividendsReceived: 0,
      };
    } else if (newCategory === "Bonds") {
      if (!bdIssuer || !bdTicker || !bdFace || !bdPurchasePct || !bdCurrentPct || !bdMaturity || !bdCoupon) return;
      assetPayload.bond = {
        id: "",
        issuer: bdIssuer,
        ticker: bdTicker,
        faceValue: Number(bdFace),
        purchasePrice: Number(bdPurchasePct),
        currentPrice: Number(bdCurrentPct),
        maturityDate: bdMaturity,
        couponRate: Number(bdCoupon),
        yieldToMaturity: Number(bdCoupon), // simplified
      };
    } else if (newCategory === "Cash") {
      if (!csAmount || !csRate) return;
      assetPayload.cash = {
        id: "",
        amount: Number(csAmount),
        currency: csCurrency,
        exchangeRateToGbp: Number(csRate),
      };
    } else {
      // General fallbacks for other categories during custom entries
      assetPayload.equity = {
        id: "",
        company: "Alternative Custom Hold",
        ticker: "ALT.C",
        shares: 1,
        purchasePrice: 100000,
        currentPrice: 100000,
        dividendsReceived: 0,
      };
    }

    onAddAsset(assetPayload);
    setIsAdding(false);

    // Reset fields
    setEqCompany("");
    setEqTicker("");
    setEqShares("");
    setEqPurchase("");
    setEqCurrent("");
    setBdIssuer("");
    setBdTicker("");
    setBdFace("");
    setBdPurchasePct("");
    setBdCurrentPct("");
    setBdMaturity("");
    setBdCoupon("");
    setCsAmount("");
    setCsCurrency("GBP");
    setCsRate("1.0");
  };

  // Filtered Assets list
  const filteredAssets = assets.filter((asset) => {
    const categoryMatches = activeTab === "All" || asset.category === activeTab;
    
    let textMatches = true;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      let searchFields = "";
      
      if (asset.equity) searchFields = `${asset.equity.company} ${asset.equity.ticker}`;
      else if (asset.bond) searchFields = `${asset.bond.issuer} ${asset.bond.ticker}`;
      else if (asset.fund) searchFields = `${asset.fund.name} ${asset.fund.ticker}`;
      else if (asset.property) searchFields = asset.property.address;
      else if (asset.privateEquity) searchFields = asset.privateEquity.company;
      else if (asset.bitcoin) searchFields = `bitcoin btc ${asset.bitcoin.coldStorageLocation}`;
      else if (asset.commodity) searchFields = asset.commodity.assetName;
      else if (asset.infrastructure) searchFields = `${asset.infrastructure.projectName} ${asset.infrastructure.projectType}`;
      else if (asset.cash) searchFields = `cash money ${asset.cash.currency}`;

      textMatches = searchFields.toLowerCase().includes(query);
    }

    return categoryMatches && textMatches;
  });

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl space-y-4">
      {/* Search and Filters Header */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2">
          <Landmark className="w-5 h-5 text-amber-500" />
          <h2 className="text-base font-bold text-white font-serif uppercase tracking-wider">Asset Registry Ledger</h2>
        </div>

        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 font-mono text-xs">
          {/* Search bar */}
          <div className="relative flex items-center bg-slate-950 border border-slate-800 rounded px-2.5 py-1">
            <Search className="w-3.5 h-3.5 text-slate-500 mr-2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Query Ticker/Name..."
              className="bg-transparent border-none outline-none text-xs text-white placeholder-slate-600 w-36 sm:w-44"
            />
          </div>

          {/* Add Position trigger button */}
          {(role === "Administrator" || role === "Advisor") && (
            <button
              onClick={() => setIsAdding(!isAdding)}
              className="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-3 py-1.5 rounded transition-all flex items-center gap-1.5 uppercase tracking-widest shadow-md text-[10px]"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Provision Position</span>
            </button>
          )}
        </div>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-1 font-mono text-[10px] border-b border-slate-850 pb-2">
        {(["All", "Equities", "Bonds", "Funds", "Property", "Private Equity", "Bitcoin", "Commodities", "Infrastructure", "Cash"] as const).map((tab) => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-2.5 py-1 rounded transition-all uppercase font-bold ${
              activeTab === tab
                ? "bg-slate-950 text-amber-400 border border-amber-500/30"
                : "text-slate-500 hover:text-slate-300 border border-transparent"
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {/* Add Position Form overlay (expandable block) */}
      {isAdding && (
        <form onSubmit={handleSubmit} className="bg-slate-950 border border-amber-500/30 rounded-lg p-4 space-y-4 font-mono text-xs">
          <div className="flex justify-between items-center border-b border-slate-800 pb-2">
            <span className="font-bold text-amber-400 uppercase tracking-widest text-[10px] flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Provision Asset Holdings Node
            </span>
            <button type="button" onClick={() => setIsAdding(false)} className="text-slate-500 hover:text-slate-300 text-[10px] uppercase font-bold">
              [Cancel]
            </button>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-[10px] text-slate-500 uppercase font-bold">Primary Category</label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value as any)}
                className="w-full bg-slate-900 border border-slate-850 rounded px-2.5 py-1.5 text-xs text-white focus:border-amber-500 outline-none"
              >
                <option value="Equities">Equities / Shares</option>
                <option value="Bonds">Fixed Income / Bonds</option>
                <option value="Cash">Cash Ledger</option>
              </select>
            </div>
            <div className="text-[10px] text-slate-500 flex items-center pt-4">
              *Fill out the specific sub-form corresponding to your selection below. Other categories use the custom entries fallbacks.
            </div>
          </div>

          {/* Sub-form inputs based on selected type */}
          {newCategory === "Equities" && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Company Name</label>
                <input
                  type="text"
                  required
                  value={eqCompany}
                  onChange={(e) => setEqCompany(e.target.value)}
                  placeholder="e.g. Apple Inc."
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Ticker</label>
                <input
                  type="text"
                  required
                  value={eqTicker}
                  onChange={(e) => setEqTicker(e.target.value)}
                  placeholder="e.g. AAPL.US"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Shares Count</label>
                <input
                  type="number"
                  required
                  value={eqShares}
                  onChange={(e) => setEqShares(e.target.value)}
                  placeholder="e.g. 500"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Avg Purchase Price (£)</label>
                <input
                  type="number"
                  required
                  value={eqPurchase}
                  onChange={(e) => setEqPurchase(e.target.value)}
                  placeholder="e.g. 150"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Current Share Price (£)</label>
                <input
                  type="number"
                  required
                  value={eqCurrent}
                  onChange={(e) => setEqCurrent(e.target.value)}
                  placeholder="e.g. 180"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
            </div>
          )}

          {newCategory === "Bonds" && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Bond Issuer Name</label>
                <input
                  type="text"
                  required
                  value={bdIssuer}
                  onChange={(e) => setBdIssuer(e.target.value)}
                  placeholder="e.g. US Treasury 10Y"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Ticker / Symbol</label>
                <input
                  type="text"
                  required
                  value={bdTicker}
                  onChange={(e) => setBdTicker(e.target.value)}
                  placeholder="e.g. US10Y"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Face Value (£)</label>
                <input
                  type="number"
                  required
                  value={bdFace}
                  onChange={(e) => setBdFace(e.target.value)}
                  placeholder="e.g. 1000000"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Purchase Price (% of Face)</label>
                <input
                  type="number"
                  required
                  value={bdPurchasePct}
                  onChange={(e) => setBdPurchasePct(e.target.value)}
                  placeholder="e.g. 98.5"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Current Price (% of Face)</label>
                <input
                  type="number"
                  required
                  value={bdCurrentPct}
                  onChange={(e) => setBdCurrentPct(e.target.value)}
                  placeholder="e.g. 101.2"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Coupon Rate (%)</label>
                <input
                  type="number"
                  step="0.01"
                  required
                  value={bdCoupon}
                  onChange={(e) => setBdCoupon(e.target.value)}
                  placeholder="e.g. 4.25"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Maturity Date</label>
                <input
                  type="date"
                  required
                  value={bdMaturity}
                  onChange={(e) => setBdMaturity(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
            </div>
          )}

          {newCategory === "Cash" && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Foreign Amount</label>
                <input
                  type="number"
                  required
                  value={csAmount}
                  onChange={(e) => setCsAmount(e.target.value)}
                  placeholder="e.g. 500000"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Currency Code</label>
                <select
                  value={csCurrency}
                  onChange={(e) => {
                    const curr = e.target.value as any;
                    setCsCurrency(curr);
                    // Automatic rough rate guesses to assist workflow
                    if (curr === "GBP") setCsRate("1.0");
                    else if (curr === "USD") setCsRate("0.78");
                    else if (curr === "EUR") setCsRate("0.85");
                    else if (curr === "CHF") setCsRate("0.89");
                    else if (curr === "JPY") setCsRate("0.0052");
                  }}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                >
                  <option value="GBP">GBP - Pound Sterling</option>
                  <option value="USD">USD - US Dollar</option>
                  <option value="EUR">EUR - Euro</option>
                  <option value="CHF">CHF - Swiss Franc</option>
                  <option value="JPY">JPY - Japanese Yen</option>
                </select>
              </div>
              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 block uppercase">Exchange Rate to GBP</label>
                <input
                  type="number"
                  step="0.000001"
                  required
                  value={csRate}
                  onChange={(e) => setCsRate(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white"
                />
              </div>
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2 rounded transition-all text-xs uppercase tracking-widest shadow-md"
          >
            Provision Active Position Node
          </button>
        </form>
      )}

      {/* Database assets Grid Table list */}
      <div className="overflow-x-auto rounded-lg border border-slate-850">
        <table className="w-full text-left border-collapse text-xs font-mono">
          <thead>
            <tr className="bg-slate-950/80 border-b border-slate-800 text-slate-500 font-bold uppercase text-[9px] tracking-wider">
              <th className="py-2.5 px-4">Holdings/Ticker</th>
              <th className="py-2.5 px-3">Asset Category</th>
              <th className="py-2.5 px-3 text-right">Qty/Details</th>
              <th className="py-2.5 px-3 text-right">Cost Basis</th>
              <th className="py-2.5 px-3 text-right">Market Valuation</th>
              <th className="py-2.5 px-3 text-right">P/L Yield</th>
              {(role === "Administrator") && (
                <th className="py-2.5 px-4 text-center">Auth Actions</th>
              )}
            </tr>
          </thead>
          <tbody>
            {filteredAssets.map((asset) => {
              const { currentVal, costBasis, unrealisedPl, realisedPl, annualIncome } = getAssetValuation(asset);
              const assetRoi = costBasis > 0 ? (unrealisedPl / costBasis) * 100 : 0;
              const yieldPct = currentVal > 0 ? (annualIncome / currentVal) * 100 : 0;

              // Title mapping
              let title = "";
              let tickerSub = "";
              let qtyDetails = "";

              if (asset.equity) {
                title = asset.equity.company;
                tickerSub = asset.equity.ticker;
                qtyDetails = `${asset.equity.shares.toLocaleString()} Shares`;
              } else if (asset.bond) {
                title = asset.bond.issuer;
                tickerSub = asset.bond.ticker;
                qtyDetails = `£${asset.bond.faceValue.toLocaleString()} Face`;
              } else if (asset.fund) {
                title = asset.fund.name;
                tickerSub = asset.fund.ticker;
                qtyDetails = `${asset.fund.shares.toLocaleString()} Shares`;
              } else if (asset.property) {
                title = asset.property.address;
                tickerSub = "REAL_PROP";
                qtyDetails = `Mortgage Outstanding: £${asset.property.mortgageOutstanding.toLocaleString()}`;
              } else if (asset.privateEquity) {
                title = asset.privateEquity.company;
                tickerSub = "PVT_EQ";
                qtyDetails = `Target IRR: ${asset.privateEquity.targetIrr}%`;
              } else if (asset.bitcoin) {
                title = "Bitcoin Core Holding";
                tickerSub = "BTC.X";
                qtyDetails = `${asset.bitcoin.btcHolding.toFixed(4)} BTC`;
              } else if (asset.commodity) {
                title = `${asset.commodity.assetName} Reserves`;
                tickerSub = asset.commodity.assetName === "Gold" ? "XAU.G" : "XAG.S";
                qtyDetails = `${asset.commodity.quantity.toLocaleString()} Troy Oz`;
              } else if (asset.infrastructure) {
                title = asset.infrastructure.projectName;
                tickerSub = `INFRA_${asset.infrastructure.projectType.toUpperCase()}`;
                qtyDetails = `Stage: ${asset.infrastructure.stage}`;
              } else if (asset.cash) {
                title = `Cash Account (${asset.cash.currency})`;
                tickerSub = `FX_${asset.cash.currency}`;
                qtyDetails = `${asset.cash.amount.toLocaleString()} ${asset.cash.currency}`;
              }

              return (
                <tr key={asset.id} className="border-b border-slate-850 hover:bg-slate-950/40">
                  <td className="py-2.5 px-4">
                    <span className="text-white font-serif font-bold text-xs block">{title}</span>
                    <span className="text-[10px] text-slate-500 uppercase">{tickerSub}</span>
                  </td>
                  <td className="py-2.5 px-3">
                    <span className="text-[10px] bg-slate-950 px-2 py-0.5 border border-slate-800 rounded text-amber-300 font-bold uppercase">
                      {asset.category}
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right text-slate-400 font-bold text-[11px]">{qtyDetails}</td>
                  <td className="py-2.5 px-3 text-right text-slate-300">£{costBasis.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  <td className="py-2.5 px-3 text-right text-amber-100 font-extrabold">£{currentVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  <td className="py-2.5 px-3 text-right">
                    <span className={`font-bold block ${unrealisedPl >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
                      {unrealisedPl >= 0 ? "+" : ""}
                      {assetRoi.toFixed(1)}% ROI
                    </span>
                    <span className="text-[10px] text-slate-500 block uppercase">
                      Yield: {yieldPct.toFixed(1)}%
                    </span>
                  </td>
                  {(role === "Administrator") && (
                    <td className="py-2.5 px-4 text-center">
                      <button
                        onClick={() => onDeleteAsset(asset.id)}
                        className="text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
                        title="Liquidate position from roster"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
