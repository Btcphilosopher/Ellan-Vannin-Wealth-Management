/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Shield, Briefcase, Eye, Cpu, Landmark, Sparkles } from "lucide-react";

interface TerminalHeaderProps {
  totalValue: number;
  overallYield: number;
  volatility: number;
  sharpeRatio: number;
  riskScore: number;
  selectedRole: "Client" | "Advisor" | "Administrator";
  selectedMode: "Standard" | "Sovereign" | "Britain2040" | "FamilyOffice";
  onRoleChange: (role: "Client" | "Advisor" | "Administrator") => void;
  onModeChange: (mode: "Standard" | "Sovereign" | "Britain2040" | "FamilyOffice") => void;
}

export const TerminalHeader: React.FC<TerminalHeaderProps> = ({
  totalValue,
  overallYield,
  volatility,
  sharpeRatio,
  riskScore,
  selectedRole,
  selectedMode,
  onRoleChange,
  onModeChange,
}) => {
  return (
    <header className="bg-slate-950 border-b border-amber-500/30 text-white p-4 lg:px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-stretch justify-between gap-4">
        {/* Logo and Branding */}
        <div className="flex items-center gap-3">
          <div className="bg-gradient-to-br from-amber-600 to-amber-400 p-2.5 rounded-lg border border-amber-500/20 shadow-[0_0_15px_rgba(245,158,11,0.2)]">
            <Landmark className="w-6 h-6 text-slate-950" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-serif text-lg tracking-wider font-extrabold uppercase text-amber-400">
                Ellan Vannin
              </span>
              <span className="text-xs bg-amber-500/10 border border-amber-500/30 text-amber-300 px-2 py-0.5 rounded font-mono uppercase tracking-widest font-bold">
                GPIP Terminal
              </span>
            </div>
            <h1 className="text-slate-400 text-xs font-mono uppercase tracking-widest mt-0.5">
              Global Portfolio Intelligence Platform
            </h1>
          </div>
        </div>

        {/* Global Terminal Quick Statistics */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 lg:gap-4 flex-1 max-w-2xl bg-slate-900/50 p-2 rounded-lg border border-slate-800 font-mono">
          <div className="px-3 py-1">
            <span className="text-[10px] text-slate-500 block uppercase">Total Valuation</span>
            <span className="text-sm font-bold text-amber-100">
              £{totalValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </span>
          </div>
          <div className="px-3 py-1 border-l border-slate-800">
            <span className="text-[10px] text-slate-500 block uppercase">YTD Yield</span>
            <span className="text-sm font-bold text-emerald-400">
              +{overallYield.toFixed(2)}%
            </span>
          </div>
          <div className="px-3 py-1 border-l border-slate-800">
            <span className="text-[10px] text-slate-500 block uppercase">Volatility (StdDev)</span>
            <span className="text-sm font-bold text-amber-200">
              {(volatility * 100).toFixed(1)}%
            </span>
          </div>
          <div className="px-3 py-1 border-l border-slate-800">
            <span className="text-[10px] text-slate-500 block uppercase">Sharpe (Rf 4.5%)</span>
            <span className="text-sm font-bold text-amber-300">
              {sharpeRatio.toFixed(2)}
            </span>
          </div>
        </div>

        {/* Access Role & Mode Selector */}
        <div className="flex flex-col sm:flex-row md:flex-col lg:flex-row items-stretch sm:items-center justify-end gap-3 font-mono">
          {/* User Role */}
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 p-1 rounded">
            <span className="text-[10px] text-slate-500 px-1.5 uppercase font-bold">Role:</span>
            {(["Client", "Advisor", "Administrator"] as const).map((role) => (
              <button
                key={role}
                onClick={() => onRoleChange(role)}
                className={`px-2 py-1 text-xs rounded transition-all duration-150 ${
                  selectedRole === role
                    ? "bg-amber-500 text-slate-950 font-bold shadow-[0_0_8px_rgba(245,158,11,0.3)]"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {role}
              </button>
            ))}
          </div>

          {/* Platform Mode */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 p-1 rounded">
            <span className="text-[10px] text-slate-500 px-1.5 uppercase font-bold">Mode:</span>
            <select
              value={selectedMode}
              onChange={(e) => onModeChange(e.target.value as any)}
              className="bg-slate-950 text-amber-300 text-xs border border-amber-500/20 rounded px-2 py-1 cursor-pointer hover:border-amber-500/50 outline-none"
            >
              <option value="Standard">Standard Wealth</option>
              <option value="Sovereign">Sovereign Permanent Capital</option>
              <option value="Britain2040">Britain 2040 Strategic</option>
              <option value="FamilyOffice">Generational Family Office</option>
            </select>
          </div>
        </div>
      </div>

      {/* Mode Sub-Banner status banner */}
      <div className="max-w-7xl mx-auto mt-3 pt-2.5 border-t border-slate-900 flex flex-wrap items-center justify-between gap-2 text-xs font-mono text-slate-400">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
          <span>Isle of Man Custody Pegged</span>
          <span className="text-slate-600">|</span>
          <span className="text-amber-400/80 font-bold">
            {selectedMode === "Standard" && "Standard Wealth Management Console"}
            {selectedMode === "Sovereign" && "Sovereign Permanent Wealth Fund Terminal (SWF)"}
            {selectedMode === "Britain2040" && "Britain 2040 Thematic Green Energy & Strategic Reserve Tracker"}
            {selectedMode === "FamilyOffice" && "Generational Dynasty Office Hub (£10m+ Intergenerational Allocation)"}
          </span>
        </div>
        <div className="flex items-center gap-3">
          <span>Douglas Vault: <strong className="text-slate-300">Secure</strong></span>
          <span className="text-slate-600">|</span>
          <span>Jurisdiction: <strong className="text-amber-500">IOM (Class 3)</strong></span>
        </div>
      </div>
    </header>
  );
};
