/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Sliders, RefreshCw, AlertTriangle, ArrowRight, ShieldAlert, CheckCircle } from "lucide-react";
import { getMeanVarianceOptimization, calculateRebalanceTrades } from "../utils/portfolio_engines";

interface OptimizationRebalancePanelProps {
  categoryVals: Record<string, number>;
  totalValue: number;
}

export const OptimizationRebalancePanel: React.FC<OptimizationRebalancePanelProps> = ({
  categoryVals,
  totalValue,
}) => {
  const [riskProfile, setRiskProfile] = useState<"Conservative" | "Balanced" | "Growth" | "Aggressive">("Balanced");

  // Initial target weights as specified in prompt rebalancing section:
  // Equities: 50%, Bonds: 20%, Property: 15%, Bitcoin: 10%, Cash: 5%
  // Let's add standard entries for other categories to sum 100%
  const [targetEquities, setTargetEquities] = useState("50");
  const [targetBonds, setTargetBonds] = useState("20");
  const [targetProperty, setTargetProperty] = useState("15");
  const [targetBitcoin, setTargetBitcoin] = useState("10");
  const [targetCash, setTargetCash] = useState("5");

  const [appliedTargetWeights, setAppliedTargetWeights] = useState<Record<string, number>>({
    Equities: 50,
    Bonds: 20,
    Funds: 0,
    Property: 15,
    "Private Equity": 0,
    Bitcoin: 10,
    Commodities: 0,
    Infrastructure: 0,
    Cash: 5,
  });

  const [tradeMessage, setTradeMessage] = useState<string | null>(null);

  // Parse total active target sum
  const currentTargets = {
    Equities: Number(targetEquities) || 0,
    Bonds: Number(targetBonds) || 0,
    Property: Number(targetProperty) || 0,
    Bitcoin: Number(targetBitcoin) || 0,
    Cash: Number(targetCash) || 0,
    Funds: 0,
    "Private Equity": 0,
    Commodities: 0,
    Infrastructure: 0,
  };
  const sumTargets = Object.values(currentTargets).reduce((sum, v) => sum + v, 0);

  // Mean-variance model outcome
  const optimalModelWeights = getMeanVarianceOptimization(riskProfile);

  const handleApplyModelWeights = () => {
    setAppliedTargetWeights(optimalModelWeights);
    // Update individual sliders for visual feedback
    setTargetEquities((optimalModelWeights.Equities || 0).toString());
    setTargetBonds((optimalModelWeights.Bonds || 0).toString());
    setTargetProperty((optimalModelWeights.Property || 0).toString());
    setTargetBitcoin((optimalModelWeights.Bitcoin || 0).toString());
    setTargetCash((optimalModelWeights.Cash || 0).toString());

    setTradeMessage(`Synchronized targets to optimal ${riskProfile} frontier model.`);
  };

  const handleApplyCustomWeights = () => {
    if (sumTargets !== 100) return;
    setAppliedTargetWeights({
      Equities: currentTargets.Equities,
      Bonds: currentTargets.Bonds,
      Funds: 0,
      Property: currentTargets.Property,
      "Private Equity": 0,
      Bitcoin: currentTargets.Bitcoin,
      Commodities: 0,
      Infrastructure: 0,
      Cash: currentTargets.Cash,
    });
    setTradeMessage("Successfully generated rebalance matrix for custom target allocation.");
  };

  const trades = calculateRebalanceTrades(categoryVals, totalValue, appliedTargetWeights);

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Top Section: Mean Variance Optimization model */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center gap-2 text-amber-400 font-semibold uppercase tracking-wider border-b border-slate-800 pb-3">
            <Sliders className="w-4 h-4 text-amber-500" />
            <span>Mean-Variance Optimization</span>
          </div>

          <div className="space-y-1">
            <label className="text-[10px] text-slate-500 uppercase font-bold">Principal Risk Frontier</label>
            <div className="grid grid-cols-2 gap-1.5 pt-1">
              {(["Conservative", "Balanced", "Growth", "Aggressive"] as const).map((profile) => (
                <button
                  key={profile}
                  onClick={() => setRiskProfile(profile)}
                  className={`px-3 py-1.5 rounded transition-all font-bold ${
                    riskProfile === profile
                      ? "bg-amber-500 text-slate-950 shadow-[0_0_8px_rgba(245,158,11,0.25)]"
                      : "bg-slate-950 text-slate-400 border border-slate-850 hover:text-white"
                  }`}
                >
                  {profile}
                </button>
              ))}
            </div>
          </div>

          {/* Optimal Model weights preview */}
          <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 space-y-2">
            <span className="text-[9px] text-amber-500 font-bold block uppercase tracking-widest">Model Allocations</span>
            <div className="space-y-1.5 text-[10px]">
              {Object.entries(optimalModelWeights)
                .filter(([_, w]) => w > 0)
                .map(([cat, w]) => (
                  <div key={cat} className="flex justify-between items-center text-slate-300">
                    <span>{cat}</span>
                    <span className="font-bold text-amber-300">{w}%</span>
                  </div>
                ))}
            </div>
          </div>

          <button
            onClick={handleApplyModelWeights}
            className="w-full bg-slate-950 border border-amber-500/30 hover:border-amber-500/80 text-amber-400 py-2 rounded transition-all font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1.5"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>Apply Optimization model</span>
          </button>
        </div>

        {/* Custom Target Builder slider form */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center gap-2 text-amber-400 font-semibold uppercase tracking-wider border-b border-slate-800 pb-3">
            <Sliders className="w-4 h-4 text-amber-500" />
            <span>Target Portfolio Configuration Planner</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Custom Input Sliders */}
            <div className="space-y-3">
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Equities Target</span>
                  <span className="text-amber-300 font-bold">{targetEquities}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={targetEquities}
                  onChange={(e) => setTargetEquities(e.target.value)}
                  className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Bonds & Gilts Target</span>
                  <span className="text-amber-300 font-bold">{targetBonds}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={targetBonds}
                  onChange={(e) => setTargetBonds(e.target.value)}
                  className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Property Target</span>
                  <span className="text-amber-300 font-bold">{targetProperty}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={targetProperty}
                  onChange={(e) => setTargetProperty(e.target.value)}
                  className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>
            </div>

            <div className="space-y-3">
              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Bitcoin Reserve Target</span>
                  <span className="text-amber-300 font-bold">{targetBitcoin}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={targetBitcoin}
                  onChange={(e) => setTargetBitcoin(e.target.value)}
                  className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              <div className="space-y-1">
                <div className="flex justify-between items-center">
                  <span className="text-slate-400">Liquid Cash Target</span>
                  <span className="text-amber-300 font-bold">{targetCash}%</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={targetCash}
                  onChange={(e) => setTargetCash(e.target.value)}
                  className="w-full h-1 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-amber-500"
                />
              </div>

              {/* Status Alert */}
              <div className="flex items-center justify-between p-2 rounded bg-slate-950 border border-slate-800 text-[10px]">
                <span className="text-slate-500 uppercase font-bold">Sum Weights</span>
                <span className={`font-bold ${sumTargets === 100 ? "text-emerald-400" : "text-amber-500"}`}>
                  {sumTargets}% {sumTargets === 100 ? "(Valid)" : `(Must equal 100%)`}
                </span>
              </div>
            </div>
          </div>

          <button
            onClick={handleApplyCustomWeights}
            disabled={sumTargets !== 100}
            className={`w-full py-2 rounded transition-all font-bold uppercase tracking-wider text-[10px] text-center flex items-center justify-center gap-1.5 ${
              sumTargets === 100
                ? "bg-amber-500 text-slate-950 hover:bg-amber-600 cursor-pointer shadow-md"
                : "bg-slate-950 text-slate-600 border border-slate-900 cursor-not-allowed"
            }`}
          >
            <CheckCircle className="w-3.5 h-3.5" />
            <span>Generate Rebalance trade Matrix</span>
          </button>
        </div>
      </div>

      {/* Trades Matrix Results table */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div className="flex items-center gap-2 text-amber-400 font-semibold uppercase tracking-wider">
            <RefreshCw className="w-4 h-4 text-amber-500" />
            <span>Rebalancing Instruction & Trade Execution matrix</span>
          </div>
          {tradeMessage && (
            <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded font-bold uppercase">
              {tradeMessage}
            </span>
          )}
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-500 font-bold uppercase text-[10px]">
                <th className="py-2">Asset Category</th>
                <th className="py-2 text-right">Current Capital</th>
                <th className="py-2 text-right">Current Wt</th>
                <th className="py-2 text-right">Target Wt</th>
                <th className="py-2 text-right">Target Capital</th>
                <th className="py-2 text-right">Required Trade Exec.</th>
              </tr>
            </thead>
            <tbody>
              {trades.map((t) => (
                <tr key={t.category} className="border-b border-slate-850 hover:bg-slate-950/40 font-mono">
                  <td className="py-2.5 font-bold text-slate-300 font-serif">{t.category}</td>
                  <td className="py-2.5 text-right text-white">£{t.currentVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  <td className="py-2.5 text-right text-slate-400">{t.currentWeight.toFixed(1)}%</td>
                  <td className="py-2.5 text-right text-amber-400 font-bold">{t.targetWeight}%</td>
                  <td className="py-2.5 text-right text-slate-300">£{t.targetVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</td>
                  <td className="py-2.5 text-right font-extrabold">
                    {t.requiredTrade === 0 ? (
                      <span className="text-slate-500">—</span>
                    ) : t.requiredTrade > 0 ? (
                      <span className="text-emerald-400 font-bold">
                        BUY +£{t.requiredTrade.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </span>
                    ) : (
                      <span className="text-rose-400 font-bold">
                        SELL -£{Math.abs(t.requiredTrade).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Execution disclaimer */}
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-lg flex items-start gap-2.5 mt-4 text-[11px] text-slate-400 leading-relaxed">
          <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
          <div>
            <span className="font-bold text-amber-300 block uppercase text-[10px]">Aladdin Trade Router Assured</span>
            <span>
              Trade execution routed via Douglas OTC desks. Alternative assets (infrastructure & private property equity) may face secondary custody liquidation delay. Always seek principal confirmation before router lock.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
