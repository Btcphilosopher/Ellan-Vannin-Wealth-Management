/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Coins, HardDrive, Key, Landmark, ShieldCheck, ArrowUpRight, Percent, RefreshCw } from "lucide-react";
import { BitcoinAsset } from "../types";

interface BitcoinModuleViewProps {
  btcAsset: BitcoinAsset | undefined;
  totalPortfolioValue: number;
}

export const BitcoinModuleView: React.FC<BitcoinModuleViewProps> = ({
  btcAsset,
  totalPortfolioValue,
}) => {
  if (!btcAsset) {
    return (
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-center font-mono">
        <p className="text-slate-400 text-sm">No Bitcoin holdings registered in the portfolio database.</p>
      </div>
    );
  }

  const holdings = btcAsset.btcHolding;
  const costBasis = holdings * btcAsset.averagePurchasePrice;
  const currentVal = holdings * btcAsset.currentPrice;
  const unrealisedGains = currentVal - costBasis;
  const returnOnInvestment = costBasis > 0 ? (unrealisedGains / costBasis) * 100 : 0;
  const allocationPercent = totalPortfolioValue > 0 ? (currentVal / totalPortfolioValue) * 100 : 0;

  // Dedicated institutional crypto metrics (typically high volatility but high risk-adjusted alpha)
  const assetVolatility = 55.4; // 55.4% annual BTC volatility
  const maxDrawdown = -44.2; // simulated historic max drawdown during cycle

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between border-b border-slate-800 pb-4 mb-4">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-amber-500/10 border border-amber-500/30 text-amber-500 rounded-lg shadow-[0_0_15px_rgba(245,158,11,0.15)]">
            <Coins className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-white font-serif font-bold text-sm">Sovereign Bitcoin Reserve</h3>
              <span className="text-[10px] bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 font-mono px-2 py-0.5 rounded uppercase">
                Active Collateral
              </span>
            </div>
            <span className="text-[11px] text-slate-500 font-mono">Liquid Alt-Asset Treasury Ledger</span>
          </div>
        </div>

        <div className="text-right font-mono mt-2 sm:mt-0">
          <span className="text-[10px] text-slate-500 block uppercase">Spot Reference Price (GBP)</span>
          <span className="text-sm font-bold text-amber-300">
            £{btcAsset.currentPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </span>
        </div>
      </div>

      {/* Main Ledger grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono mb-5">
        <div className="bg-slate-950 p-3 rounded border border-slate-800">
          <span className="text-[10px] text-slate-500 block uppercase">Total Balance</span>
          <span className="text-sm font-extrabold text-white">{holdings.toFixed(4)} BTC</span>
        </div>
        <div className="bg-slate-950 p-3 rounded border border-slate-800">
          <span className="text-[10px] text-slate-500 block uppercase">Average Cost</span>
          <span className="text-sm font-extrabold text-slate-300">£{btcAsset.averagePurchasePrice.toLocaleString()}</span>
        </div>
        <div className="bg-slate-950 p-3 rounded border border-slate-800">
          <span className="text-[10px] text-slate-500 block uppercase">Valuation</span>
          <span className="text-sm font-extrabold text-amber-100">£{currentVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
        </div>
        <div className="bg-slate-950 p-3 rounded border border-slate-800">
          <span className="text-[10px] text-slate-500 block uppercase">Liquid Allocation</span>
          <span className="text-sm font-extrabold text-amber-400">{allocationPercent.toFixed(2)}%</span>
        </div>
      </div>

      {/* Risk Metrics Sub-grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
        {/* Performance Gains */}
        <div className="bg-slate-950/60 p-4 border border-slate-800 rounded-lg flex items-center justify-between font-mono">
          <div>
            <span className="text-[10px] text-slate-500 block uppercase">Unrealised Returns</span>
            <span className="text-sm font-extrabold text-emerald-400">
              +£{unrealisedGains.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </span>
          </div>
          <div className="flex items-center gap-0.5 text-emerald-400 text-xs font-bold bg-emerald-500/10 border border-emerald-500/20 px-2 py-1 rounded">
            <ArrowUpRight className="w-3.5 h-3.5" />
            <span>+{returnOnInvestment.toFixed(1)}%</span>
          </div>
        </div>

        {/* Volatility Index */}
        <div className="bg-slate-950/60 p-4 border border-slate-800 rounded-lg flex items-center justify-between font-mono">
          <div>
            <span className="text-[10px] text-slate-500 block uppercase">Asset Annual Volatility</span>
            <span className="text-sm font-extrabold text-amber-200">{assetVolatility}%</span>
          </div>
          <div className="text-[10px] text-slate-400 bg-amber-500/10 border border-amber-500/20 px-2 py-1 rounded">
            HIGH ALPHA
          </div>
        </div>

        {/* Drawdown Potential */}
        <div className="bg-slate-950/60 p-4 border border-slate-800 rounded-lg flex items-center justify-between font-mono">
          <div>
            <span className="text-[10px] text-slate-500 block uppercase">Cycle Drawdown Limit</span>
            <span className="text-sm font-extrabold text-rose-400">{maxDrawdown}%</span>
          </div>
          <div className="text-[10px] text-slate-400 bg-rose-500/10 border border-rose-500/20 px-2 py-1 rounded">
            STRESS TEST PASS
          </div>
        </div>
      </div>

      {/* Custody Registry Detail */}
      <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 font-mono">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <ShieldCheck className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-white text-xs font-bold uppercase">Institutional Cold Custody Registry</h4>
              <p className="text-slate-500 text-[11px] leading-relaxed mt-1">
                Security: <strong className="text-slate-300">{btcAsset.coldStorageLocation}</strong>
              </p>
              <p className="text-slate-500 text-[10px] mt-0.5">
                Physical air-gapped security, multi-sig authorization (3-of-5 key holders in Douglas & Zurich).
              </p>
            </div>
          </div>
          <div className="flex sm:flex-col items-center sm:items-end justify-between font-mono mt-3 sm:mt-0 text-right">
            <span className="text-[10px] text-slate-600 uppercase">Audit Status</span>
            <span className="text-emerald-400 font-bold text-xs bg-emerald-500/10 px-2 py-1 border border-emerald-500/20 rounded">
              VERIFIED LEDGER
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
