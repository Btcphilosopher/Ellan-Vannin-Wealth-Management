/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { TrendingUp, Sliders, Play, Award, Sparkles, AlertTriangle } from "lucide-react";
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid, Legend } from "recharts";
import { runMonteCarlo } from "../utils/portfolio_engines";
import { ForecastParams } from "../types";

interface FutureWealthForecastPanelProps {
  totalPortfolioValue: number;
}

export const FutureWealthForecastPanel: React.FC<FutureWealthForecastPanelProps> = ({
  totalPortfolioValue,
}) => {
  // Input parameters
  const [horizonYears, setHorizonYears] = useState(20);
  const [expectedReturn, setExpectedReturn] = useState(8.5); // annual %
  const [monthlyContribution, setMonthlyContribution] = useState(15000); // GBP
  const [inflationRate, setInflationRate] = useState(2.2); // annual %
  const [taxDrag, setTaxDrag] = useState(0.8); // annual %

  const [simulationData, setSimulationData] = useState<any[]>([]);
  const [isRunning, setIsRunning] = useState(false);

  const triggerSimulation = () => {
    setIsRunning(true);
    // Simulating delay for authentic Bloomberg calculation terminal feel
    setTimeout(() => {
      const params: ForecastParams = {
        horizonYears,
        expectedReturn,
        monthlyContribution,
        inflationRate,
        taxDrag,
      };
      const rawScenarios = runMonteCarlo(totalPortfolioValue, params);

      // Map to chart format
      const formatted = rawScenarios.map((sc) => ({
        year: `Yr ${sc.year}`,
        "Bear (10th Pct)": Math.round(sc.p10),
        "Expected (Median)": Math.round(sc.p50),
        "Bull (90th Pct)": Math.round(sc.p90),
      }));

      // Add starting point
      const startNode = {
        year: "Start",
        "Bear (10th Pct)": totalPortfolioValue,
        "Expected (Median)": totalPortfolioValue,
        "Bull (90th Pct)": totalPortfolioValue,
      };

      setSimulationData([startNode, ...formatted]);
      setIsRunning(false);
    }, 450);
  };

  // Run on mount or when parameters change
  useEffect(() => {
    triggerSimulation();
  }, [horizonYears, expectedReturn, monthlyContribution, inflationRate, taxDrag, totalPortfolioValue]);

  return (
    <div className="space-y-6 font-mono text-xs">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Simulation Parameter Inputs */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
          <div className="flex items-center gap-2 text-amber-400 font-semibold uppercase tracking-wider border-b border-slate-800 pb-3">
            <Sliders className="w-4 h-4 text-amber-500" />
            <span>Forecasting Monte Carlo Engine</span>
          </div>

          <div className="space-y-3">
            {/* Horizon */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-slate-500 uppercase font-bold">Horizon Years</span>
                <span className="text-white font-bold">{horizonYears} Years</span>
              </div>
              <select
                value={horizonYears}
                onChange={(e) => setHorizonYears(Number(e.target.value))}
                className="w-full bg-slate-950 border border-slate-800 rounded px-2.5 py-1.5 text-xs text-white focus:border-amber-500 outline-none"
              >
                <option value="5">5 Years</option>
                <option value="10">10 Years</option>
                <option value="20">20 Years</option>
                <option value="30">30 Years</option>
              </select>
            </div>

            {/* Expected Returns */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-slate-500 uppercase font-bold">Expected Growth (Nominal)</span>
                <span className="text-amber-300 font-bold">{expectedReturn}% / yr</span>
              </div>
              <input
                type="range"
                min="2"
                max="25"
                step="0.5"
                value={expectedReturn}
                onChange={(e) => setExpectedReturn(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded appearance-none cursor-pointer accent-amber-500"
              />
            </div>

            {/* Monthly Contribution */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-slate-500 uppercase font-bold">Monthly Funding Input</span>
                <span className="text-amber-300 font-bold">£{monthlyContribution.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="0"
                max="150000"
                step="5000"
                value={monthlyContribution}
                onChange={(e) => setMonthlyContribution(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded appearance-none cursor-pointer accent-amber-500"
              />
            </div>

            {/* Inflation Rate */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-slate-500 uppercase font-bold">Long-Term Inflation CPI</span>
                <span className="text-white font-bold">{inflationRate}% / yr</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="8.0"
                step="0.1"
                value={inflationRate}
                onChange={(e) => setInflationRate(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded appearance-none cursor-pointer accent-amber-500"
              />
            </div>

            {/* Tax Drag */}
            <div className="space-y-1">
              <div className="flex justify-between text-[10px]">
                <span className="text-slate-500 uppercase font-bold">Tax and Fee Drag</span>
                <span className="text-rose-400 font-bold">{taxDrag}% / yr</span>
              </div>
              <input
                type="range"
                min="0"
                max="5.0"
                step="0.1"
                value={taxDrag}
                onChange={(e) => setTaxDrag(Number(e.target.value))}
                className="w-full h-1 bg-slate-950 rounded appearance-none cursor-pointer accent-amber-500"
              />
            </div>
          </div>

          <button
            onClick={triggerSimulation}
            disabled={isRunning}
            className="w-full bg-amber-500 hover:bg-amber-600 disabled:bg-slate-800 disabled:text-slate-600 text-slate-950 font-bold py-2 rounded transition-all text-[11px] uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-md"
          >
            <Play className={`w-3.5 h-3.5 ${isRunning ? "animate-spin" : ""}`} />
            <span>{isRunning ? "Simulating 10,000 Paths..." : "Initiate Monte Carlo"}</span>
          </button>
        </div>

        {/* Chart representation of scenario envelope */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center gap-2 text-amber-400 font-semibold uppercase tracking-wider border-b border-slate-800 pb-3 mb-4">
            <TrendingUp className="w-4 h-4 text-amber-500" />
            <span>Probability Distribution Envelope (Net of inflation & drag)</span>
          </div>

          <div className="h-64 w-full font-mono text-[10px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={simulationData} margin={{ left: 15, right: 10, top: 10, bottom: 5 }}>
                <defs>
                  <linearGradient id="colorBull" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.12} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorExpected" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#fbbf24" stopOpacity={0.15} />
                    <stop offset="95%" stopColor="#fbbf24" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="colorBear" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#f87171" stopOpacity={0.1} />
                    <stop offset="95%" stopColor="#f87171" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="year" stroke="#64748b" />
                <YAxis stroke="#64748b" tickFormatter={(v) => `£${(v / 1000000).toFixed(1)}M`} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#020617", borderColor: "#334155", color: "#f8fafc" }}
                  formatter={(value: any) => [`£${Number(value).toLocaleString()}`, "Valuation"]}
                />
                <Legend />
                <Area
                  name="Bull Case (90th Percentile)"
                  type="monotone"
                  dataKey="Bull (90th Pct)"
                  stroke="#10b981"
                  fillOpacity={1}
                  fill="url(#colorBull)"
                />
                <Area
                  name="Median expected Case (50th Pct)"
                  type="monotone"
                  dataKey="Expected (Median)"
                  stroke="#fbbf24"
                  fillOpacity={1}
                  fill="url(#colorExpected)"
                />
                <Area
                  name="Bear Case (10th Percentile)"
                  type="monotone"
                  dataKey="Bear (10th Pct)"
                  stroke="#f87171"
                  fillOpacity={1}
                  fill="url(#colorBear)"
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Probability details box */}
      {simulationData.length > 0 && (
        <div className="bg-slate-950 border border-slate-800 p-4 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 font-mono">
          <div className="flex items-start gap-2.5 text-slate-400">
            <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
            <div>
              <span className="font-bold text-white block">Horizon Simulation Target Assured</span>
              <span>
                At year {horizonYears}, there is a <strong className="text-emerald-400">90% probability</strong> that capital exceeds{" "}
                <strong className="text-white">£{simulationData[simulationData.length - 1]["Bear (10th Pct)"].toLocaleString()}</strong>, and a{" "}
                <strong className="text-amber-400">50% probability</strong> that it exceeds{" "}
                <strong className="text-white">£{simulationData[simulationData.length - 1]["Expected (Median)"].toLocaleString()}</strong>.
              </span>
            </div>
          </div>
          <div className="text-center sm:text-right shrink-0 bg-slate-900 border border-slate-850 p-2.5 rounded">
            <span className="text-[10px] text-slate-500 block uppercase">Real Median Compound Return</span>
            <span className="text-sm font-bold text-emerald-400">
              +{((expectedReturn - inflationRate - taxDrag)).toFixed(2)}% net / yr
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
