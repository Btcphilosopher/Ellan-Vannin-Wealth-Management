/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { TrendingUp, TrendingDown, DollarSign, Plus, Trash2, ShieldAlert, Clock } from "lucide-react";
import { CashFlowItem } from "../types";
import { calculateCashRunway } from "../utils/portfolio_engines";

interface CashFlowTrackerPanelProps {
  cashFlows: CashFlowItem[];
  role: "Client" | "Advisor" | "Administrator";
  onAddCashFlow: (cf: Omit<CashFlowItem, "id">) => void;
  onDeleteCashFlow: (id: string) => void;
  liquidCashGbp: number;
}

export const CashFlowTrackerPanel: React.FC<CashFlowTrackerPanelProps> = ({
  cashFlows,
  role,
  onAddCashFlow,
  onDeleteCashFlow,
  liquidCashGbp,
}) => {
  const [type, setType] = useState<"Income" | "Expense">("Income");
  const [category, setCategory] = useState("");
  const [amount, setAmount] = useState("");
  const [frequency, setFrequency] = useState<"Monthly" | "Quarterly" | "Annually">("Annually");

  const { runwayMonths, netAnnualFlow, annualIncome, annualExpense } = calculateCashRunway(
    liquidCashGbp,
    cashFlows
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!category || !amount || isNaN(Number(amount))) return;
    
    // Convert to annual equivalent based on frequency
    let multiplier = 1;
    if (frequency === "Monthly") multiplier = 12;
    else if (frequency === "Quarterly") multiplier = 4;

    onAddCashFlow({
      type,
      category,
      amount: Number(amount) * multiplier,
      frequency,
    });

    setCategory("");
    setAmount("");
  };

  return (
    <div className="space-y-6 font-mono text-xs">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 font-mono text-center">
        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-md">
          <span className="text-[10px] text-slate-500 block uppercase font-bold">Total Annual Income</span>
          <span className="text-lg font-bold text-emerald-400">
            +£{annualIncome.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </span>
          <p className="text-[9px] text-slate-500 mt-1">Dividends, rent & distributions</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-md">
          <span className="text-[10px] text-slate-500 block uppercase font-bold">Total Annual Expenses</span>
          <span className="text-lg font-bold text-rose-400">
            -£{annualExpense.toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </span>
          <p className="text-[9px] text-slate-500 mt-1">Fees, tax drag & disbursements</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-md">
          <span className="text-[10px] text-slate-500 block uppercase font-bold">Net Annual Flow</span>
          <span className={`text-lg font-bold ${netAnnualFlow >= 0 ? "text-emerald-400" : "text-rose-400"}`}>
            {netAnnualFlow >= 0 ? "+" : "-"}£{Math.abs(netAnnualFlow).toLocaleString(undefined, { maximumFractionDigits: 0 })}
          </span>
          <p className="text-[9px] text-slate-500 mt-1">Aggregate annual net balance</p>
        </div>

        <div className="bg-slate-900 border border-slate-800 p-4 rounded-xl shadow-md">
          <span className="text-[10px] text-slate-500 block uppercase font-bold">Liquid Cash Runway</span>
          <span className="text-lg font-bold text-amber-300">
            {runwayMonths === Infinity ? "Infinite" : `${runwayMonths.toFixed(1)} Mos`}
          </span>
          <p className="text-[9px] text-slate-500 mt-1">Based on £{liquidCashGbp.toLocaleString(undefined, { maximumFractionDigits: 0 })} reserves</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Cashflow Ledger list */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl space-y-4">
          <h3 className="text-sm font-mono text-amber-400 font-semibold uppercase tracking-wider">
            Sovereign Cashflow & Yield Ledger
          </h3>

          <div className="space-y-3">
            {cashFlows.map((cf) => (
              <div
                key={cf.id}
                className="bg-slate-950 border border-slate-800 rounded-lg p-3.5 flex items-center justify-between transition-all hover:border-amber-500/10"
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded ${cf.type === "Income" ? "bg-emerald-500/10 text-emerald-400" : "bg-rose-500/10 text-rose-400"}`}>
                    {cf.type === "Income" ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  </div>
                  <div>
                    <h4 className="text-white font-serif font-bold text-xs">{cf.category}</h4>
                    <span className="text-[9px] text-slate-500 uppercase tracking-wider block mt-0.5">
                      Class: {cf.type} | Frequency: {cf.frequency}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-4">
                  <div className="text-right">
                    <span className={`font-bold block ${cf.type === "Income" ? "text-emerald-400" : "text-rose-400"}`}>
                      {cf.type === "Income" ? "+" : "-"}£{cf.amount.toLocaleString(undefined, { maximumFractionDigits: 0 })}/yr
                    </span>
                  </div>
                  {role === "Administrator" && (
                    <button
                      onClick={() => onDeleteCashFlow(cf.id)}
                      className="text-slate-500 hover:text-rose-400 transition-all cursor-pointer"
                      title="De-register cashflow entry"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Action Panel: Register cashflow */}
        <div>
          {role === "Administrator" || role === "Advisor" ? (
            <form onSubmit={handleSubmit} className="bg-slate-950 border border-slate-800 rounded-lg p-4 space-y-4">
              <h3 className="text-sm font-mono text-amber-400 font-semibold uppercase tracking-wider">
                Register Cashflow Node
              </h3>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 uppercase font-bold">Directional Type</label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setType("Income")}
                    className={`py-1 rounded font-bold ${type === "Income" ? "bg-emerald-500 text-slate-950" : "bg-slate-900 text-slate-400"}`}
                  >
                    Income (+)
                  </button>
                  <button
                    type="button"
                    onClick={() => setType("Expense")}
                    className={`py-1 rounded font-bold ${type === "Expense" ? "bg-rose-500 text-slate-950" : "bg-slate-900 text-slate-400"}`}
                  >
                    Expense (-)
                  </button>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[10px] text-slate-500 uppercase font-bold">Category Label</label>
                <input
                  type="text"
                  required
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  placeholder="e.g. Infrastructure Yield, Trust Fees"
                  className="w-full bg-slate-900 border border-slate-800 rounded px-3 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 uppercase font-bold">Receipt Freq.</label>
                  <select
                    value={frequency}
                    onChange={(e) => setFrequency(e.target.value as any)}
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white focus:border-amber-500 outline-none"
                  >
                    <option value="Monthly">Monthly</option>
                    <option value="Quarterly">Quarterly</option>
                    <option value="Annually">Annually</option>
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] text-slate-500 uppercase font-bold">Amount (£)</label>
                  <input
                    type="number"
                    required
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="e.g. 5000"
                    className="w-full bg-slate-900 border border-slate-800 rounded px-2 py-1.5 text-xs text-white placeholder-slate-600 focus:border-amber-500 outline-none"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-mono font-bold text-xs py-2 rounded transition-all flex items-center justify-center gap-1.5 uppercase tracking-widest shadow-lg"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Inject Cashflow node</span>
              </button>
            </form>
          ) : (
            <div className="bg-slate-950 border border-slate-800 rounded-lg p-5 text-center space-y-4">
              <Clock className="w-8 h-8 text-amber-500/40 mx-auto" />
              <div>
                <h4 className="text-white text-xs font-mono uppercase font-bold">Cashflow Registrar locked</h4>
                <p className="text-slate-500 text-[11px] font-mono mt-1 leading-relaxed">
                  You are logged in as a <strong>Client</strong>. Elevate role privileges to <strong>Advisor</strong> or <strong>Administrator</strong> in the header to modify recurring yield models.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
