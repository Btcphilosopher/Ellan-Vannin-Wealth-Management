/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Zap, Wind, HardDrive, Train, Trees, Anchor, Coins, ShieldAlert } from "lucide-react";
import { PortfolioAsset } from "../types";

interface Britain2040ViewProps {
  assets: PortfolioAsset[];
}

export const Britain2040View: React.FC<Britain2040ViewProps> = ({ assets }) => {
  // Filter the assets that are part of the Britain 2040 Thematic structure
  const WindAssets = assets.filter(
    (a) => a.category === "Infrastructure" && a.infrastructure?.projectType === "Energy" && a.infrastructure.projectName.includes("Wind")
  );
  const NuclearAssets = assets.filter(
    (a) => a.category === "Infrastructure" && a.infrastructure?.projectType === "Energy" && a.infrastructure.projectName.includes("Nuclear")
  );
  const PortForestryAssets = assets.filter(
    (a) => a.category === "Infrastructure" && (a.infrastructure?.projectType === "Forestry" || a.infrastructure?.projectName.includes("Port"))
  );
  const BtcAssets = assets.filter((a) => a.category === "Bitcoin");

  // Sum valuations
  const getVal = (assetList: PortfolioAsset[]) => {
    return assetList.reduce((sum, a) => {
      if (a.category === "Infrastructure" && a.infrastructure) {
        return sum + a.infrastructure.currentValuation;
      }
      if (a.category === "Bitcoin" && a.bitcoin) {
        return sum + a.bitcoin.btcHolding * a.bitcoin.currentPrice;
      }
      return sum;
    }, 0);
  };

  const windVal = getVal(WindAssets);
  const nuclearVal = getVal(NuclearAssets);
  const portForestryVal = getVal(PortForestryAssets);
  const btcVal = getVal(BtcAssets);

  // Add dummy themed holdings for display completeness if empty
  const dataCenterVal = 1850000; // Simulated active datacenter equity holding
  const railwayVal = 1200000; // Simulated train transport bond/equity exposure

  const totalThematicVal = windVal + nuclearVal + portForestryVal + btcVal + dataCenterVal + railwayVal;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl">
      <div className="border-b border-slate-800 pb-5 mb-5">
        <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest mb-1">
          <Zap className="w-4 h-4 text-amber-500 animate-pulse" />
          <span>Themed Flagship Investment Framework</span>
        </div>
        <h2 className="text-xl font-bold text-white font-serif">Britain 2040 Strategic Portfolio</h2>
        <p className="text-slate-400 text-xs mt-1 max-w-xl font-mono leading-relaxed">
          An institutional thematic allocation model mapping permanent capital to critical sovereign pillars: decarbonized energy grid, industrial computing, strategic connectivity, and digital sovereign reserve collateral.
        </p>
      </div>

      {/* Grid of 6 Theme Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* Pillar 1: Offshore Wind */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 relative overflow-hidden transition-all hover:border-amber-500/20">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-sky-500/10 border border-sky-500/20 text-sky-400 rounded">
              <Wind className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white font-serif text-sm font-semibold">Offshore Wind Grid</h3>
              <span className="text-[10px] text-slate-500 font-mono">Target: 35% Grid baseload</span>
            </div>
          </div>
          <p className="text-slate-400 text-xs mt-3 font-mono leading-relaxed">
            High-density offshore arrays supplying secure, zero-carbon electricity to Manx & UK interconnectors.
          </p>
          <div className="mt-4 pt-3 border-t border-slate-900 flex justify-between items-center text-xs font-mono">
            <span className="text-slate-500 uppercase">Exposure</span>
            <span className="text-amber-300 font-bold">£{windVal.toLocaleString()}</span>
          </div>
        </div>

        {/* Pillar 2: Nuclear SMR */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 relative overflow-hidden transition-all hover:border-amber-500/20">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 rounded">
              <Zap className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white font-serif text-sm font-semibold">Small Modular Nuclear (SMR)</h3>
              <span className="text-[10px] text-slate-500 font-mono">Target: 25% baseload stability</span>
            </div>
          </div>
          <p className="text-slate-400 text-xs mt-3 font-mono leading-relaxed">
            Investing in Westinghouse/Rolls-Royce SMR clusters for stable, continuous baseload capacity.
          </p>
          <div className="mt-4 pt-3 border-t border-slate-900 flex justify-between items-center text-xs font-mono">
            <span className="text-slate-500 uppercase">Exposure</span>
            <span className="text-amber-300 font-bold">£{nuclearVal.toLocaleString()}</span>
          </div>
        </div>

        {/* Pillar 3: Data Centres */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 relative overflow-hidden transition-all hover:border-amber-500/20">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 rounded">
              <HardDrive className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white font-serif text-sm font-semibold">Sovereign Data Infrastructure</h3>
              <span className="text-[10px] text-slate-500 font-mono">Target: Al-optimized computing</span>
            </div>
          </div>
          <p className="text-slate-400 text-xs mt-3 font-mono leading-relaxed">
            Data centres powered by dedicated on-site modular nuclear heat bypasses, providing localized secure computing.
          </p>
          <div className="mt-4 pt-3 border-t border-slate-900 flex justify-between items-center text-xs font-mono">
            <span className="text-slate-500 uppercase">Exposure</span>
            <span className="text-amber-300 font-bold">£{dataCenterVal.toLocaleString()}</span>
          </div>
        </div>

        {/* Pillar 4: Heavy Railways */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 relative overflow-hidden transition-all hover:border-amber-500/20">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/10 border border-amber-500/20 text-amber-400 rounded">
              <Train className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white font-serif text-sm font-semibold">Rail & Transit Networks</h3>
              <span className="text-[10px] text-slate-500 font-mono">Target: Carbon-neutral logistics</span>
            </div>
          </div>
          <p className="text-slate-400 text-xs mt-3 font-mono leading-relaxed">
            Critical regional freight corridors facilitating clean logistics under sovereign operation agreements.
          </p>
          <div className="mt-4 pt-3 border-t border-slate-900 flex justify-between items-center text-xs font-mono">
            <span className="text-slate-500 uppercase">Exposure</span>
            <span className="text-amber-300 font-bold">£{railwayVal.toLocaleString()}</span>
          </div>
        </div>

        {/* Pillar 5: Green Ports & Forestry */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 relative overflow-hidden transition-all hover:border-amber-500/20">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-teal-500/10 border border-teal-500/20 text-teal-400 rounded">
              <Trees className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white font-serif text-sm font-semibold">Ports & Carbon Sink Forestry</h3>
              <span className="text-[10px] text-slate-500 font-mono">Target: Carbon balancing</span>
            </div>
          </div>
          <p className="text-slate-400 text-xs mt-3 font-mono leading-relaxed">
            Logistical marine hubs paired with strategic forestry assets to secure carbon-offset certifications.
          </p>
          <div className="mt-4 pt-3 border-t border-slate-900 flex justify-between items-center text-xs font-mono">
            <span className="text-slate-500 uppercase">Exposure</span>
            <span className="text-amber-300 font-bold">£{portForestryVal.toLocaleString()}</span>
          </div>
        </div>

        {/* Pillar 6: Bitcoin Reserve */}
        <div className="bg-slate-950 border border-slate-800 rounded-lg p-4 relative overflow-hidden transition-all hover:border-amber-500/20">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-amber-500/15 border border-amber-500/30 text-amber-400 rounded">
              <Coins className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-white font-serif text-sm font-semibold">Digital Sovereign Reserve</h3>
              <span className="text-[10px] text-slate-500 font-mono">Target: Hard-capped collateral</span>
            </div>
          </div>
          <p className="text-slate-400 text-xs mt-3 font-mono leading-relaxed">
            Bitcoin strategic reserve held as decentralized digital gold, protecting against global sovereign fiat debasement.
          </p>
          <div className="mt-4 pt-3 border-t border-slate-900 flex justify-between items-center text-xs font-mono">
            <span className="text-slate-500 uppercase">Exposure</span>
            <span className="text-amber-300 font-bold">£{btcVal.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Thematic Summary Banner */}
      <div className="mt-5 p-4 bg-slate-950 border border-slate-800 rounded-lg flex flex-col sm:flex-row items-center justify-between gap-4 font-mono">
        <div>
          <span className="text-[10px] text-slate-500 block uppercase">Aggregate Thematic Portfolio Value</span>
          <span className="text-xl font-bold text-amber-400">
            £{totalThematicVal.toLocaleString()}
          </span>
        </div>
        <div className="text-xs text-right max-w-md">
          <span className="text-slate-400 block">
            This portfolio matches <strong className="text-white">Britain 2040 Standard Act II</strong>, ensuring heavy asset backing with stable, unlevered, sovereign CPI-linked yield profiles.
          </span>
        </div>
      </div>
    </div>
  );
};
