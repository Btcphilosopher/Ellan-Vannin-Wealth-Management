/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import {
  TrendingUp,
  ShieldAlert,
  Sliders,
  Compass,
  ArrowUpRight,
  TrendingDown,
  Info,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
} from "recharts";
import { RiskMetrics } from "../types";

interface PerformanceRiskPanelProps {
  riskMetrics: RiskMetrics;
  totalValue: number;
}

// 12-Month Historical Growth Path of Portfolio vs Benchmarks
// Starting base: £100 value 1 year ago
const HISTORICAL_CHART_DATA = [
  { month: "Aug 25", Portfolio: 100.0, SP500: 100.0, FTSE100: 100.0, MSCIWorld: 100.0, BTC: 100.0 },
  { month: "Sep 25", Portfolio: 101.5, SP500: 98.8, FTSE100: 100.4, MSCIWorld: 99.1, BTC: 104.5 },
  { month: "Oct 25", Portfolio: 102.8, SP500: 102.4, FTSE100: 99.2, MSCIWorld: 101.4, BTC: 112.1 },
  { month: "Nov 25", Portfolio: 104.2, SP500: 105.1, FTSE100: 101.8, MSCIWorld: 104.2, BTC: 108.4 },
  { month: "Dec 25", Portfolio: 106.1, SP500: 108.6, FTSE100: 103.5, MSCIWorld: 107.1, BTC: 122.3 },
  { month: "Jan 26", Portfolio: 105.4, SP500: 106.2, FTSE100: 101.1, MSCIWorld: 105.0, BTC: 114.0 },
  { month: "Feb 26", Portfolio: 107.8, SP500: 111.4, FTSE100: 102.3, MSCIWorld: 109.2, BTC: 131.5 },
  { month: "Mar 26", Portfolio: 109.5, SP500: 114.2, FTSE100: 104.0, MSCIWorld: 111.8, BTC: 145.2 },
  { month: "Apr 26", Portfolio: 108.1, SP500: 110.5, FTSE100: 102.1, MSCIWorld: 108.4, BTC: 132.8 },
  { month: "May 26", Portfolio: 110.4, SP500: 113.8, FTSE100: 104.5, MSCIWorld: 111.9, BTC: 148.1 },
  { month: "Jun 26", Portfolio: 111.9, SP500: 116.5, FTSE100: 103.8, MSCIWorld: 113.6, BTC: 154.5 },
  { month: "Jul 26", Portfolio: 112.8, SP500: 118.2, FTSE100: 105.2, MSCIWorld: 115.4, BTC: 161.2 },
];

export const PerformanceRiskPanel: React.FC<PerformanceRiskPanelProps> = ({
  riskMetrics,
  totalValue,
}) => {
  const [selectedBenchmark, setSelectedBenchmark] = useState<"SP500" | "FTSE100" | "MSCIWorld" | "BTC">("MSCIWorld");

  // Traditional Category Correlation Matrix
  const CATEGORIES = ["Equities", "Bonds", "Funds", "Property", "Bitcoin", "Infrastructure", "Cash"];
  const CORRELATION_MATRIX: Record<string, Record<string, number>> = {
    Equities: { Equities: 1.0, Bonds: 0.1, Funds: 0.9, Property: 0.3, Bitcoin: 0.4, Infrastructure: 0.2, Cash: -0.05 },
    Bonds: { Equities: 0.1, Bonds: 1.0, Funds: 0.15, Property: 0.1, Bitcoin: -0.1, Infrastructure: 0.35, Cash: 0.15 },
    Funds: { Equities: 0.9, Bonds: 0.15, Funds: 1.0, Property: 0.3, Bitcoin: 0.38, Infrastructure: 0.22, Cash: -0.03 },
    Property: { Equities: 0.3, Bonds: 0.1, Funds: 0.3, Property: 1.0, Bitcoin: 0.15, Infrastructure: 0.4, Cash: 0.02 },
    Bitcoin: { Equities: 0.4, Bonds: -0.1, Funds: 0.38, Property: 0.15, Bitcoin: 1.0, Infrastructure: 0.08, Cash: -0.12 },
    Infrastructure: { Equities: 0.2, Bonds: 0.35, Funds: 0.22, Property: 0.4, Bitcoin: 0.08, Infrastructure: 1.0, Cash: 0.08 },
    Cash: { Equities: -0.05, Bonds: 0.15, Funds: -0.03, Property: 0.02, Bitcoin: -0.12, Infrastructure: 0.08, Cash: 1.0 },
  };

  // Compute color based on correlation strength
  const getHeatmapColor = (val: number) => {
    if (val === 1.0) return "bg-amber-500 text-slate-950 font-bold";
    if (val > 0.6) return "bg-amber-600/30 text-amber-200";
    if (val > 0.2) return "bg-amber-700/15 text-amber-300/80";
    if (val > -0.01) return "bg-slate-900 text-slate-400";
    return "bg-rose-950/20 text-rose-300";
  };

  return (
    <div className="space-y-6">
      {/* Risk Metrics Highlight Panel */}
      <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
        <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest mb-4">
          <ShieldAlert className="w-4 h-4 text-amber-500" />
          <span>Institutional Portfolio Stress Testing & Volatility Indices</span>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-mono">
          <div className="bg-slate-950 p-4 border border-slate-800 rounded-lg">
            <span className="text-[10px] text-slate-500 block uppercase">Annual Volatility</span>
            <span className="text-xl font-extrabold text-amber-200">
              {(riskMetrics.volatility * 100).toFixed(1)}%
            </span>
            <p className="text-[9px] text-slate-500 mt-1 leading-tight">Aggregate basket standard deviation</p>
          </div>

          <div className="bg-slate-950 p-4 border border-slate-800 rounded-lg">
            <span className="text-[10px] text-slate-500 block uppercase">Sortino Ratio</span>
            <span className="text-xl font-extrabold text-amber-300">
              {riskMetrics.sortinoRatio.toFixed(2)}
            </span>
            <p className="text-[9px] text-slate-500 mt-1 leading-tight">Downside deviation-adjusted alpha</p>
          </div>

          <div className="bg-slate-950 p-4 border border-slate-800 rounded-lg">
            <span className="text-[10px] text-slate-500 block uppercase">95% 1-Day VaR</span>
            <span className="text-xl font-extrabold text-rose-400">
              £{riskMetrics.valueAtRisk.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </span>
            <p className="text-[9px] text-slate-500 mt-1 leading-tight">Max loss in 95% of market days</p>
          </div>

          <div className="bg-slate-950 p-4 border border-slate-800 rounded-lg">
            <span className="text-[10px] text-slate-500 block uppercase">95% 1-Day CVaR</span>
            <span className="text-xl font-extrabold text-rose-500">
              £{riskMetrics.conditionalVaR.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </span>
            <p className="text-[9px] text-slate-500 mt-1 leading-tight">Estimated loss when VaR is exceeded</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4 font-mono text-xs">
          <div className="bg-slate-950/40 px-4 py-2 border border-slate-800/80 rounded flex items-center justify-between">
            <span className="text-slate-500">Aggregate Beta (vs MSCI World)</span>
            <strong className="text-white">{riskMetrics.portfolioBeta.toFixed(2)}</strong>
          </div>
          <div className="bg-slate-950/40 px-4 py-2 border border-slate-800/80 rounded flex items-center justify-between">
            <span className="text-slate-500">Maximum Drawdown Potential</span>
            <strong className="text-rose-400">{(riskMetrics.maxDrawdown * -100).toFixed(1)}%</strong>
          </div>
          <div className="bg-slate-950/40 px-4 py-2 border border-slate-800/80 rounded flex items-center justify-between">
            <span className="text-slate-500">Risk Score Profile</span>
            <span className="bg-amber-500 text-slate-950 font-bold px-2 py-0.5 rounded text-[11px]">
              {riskMetrics.riskScore} / 10
            </span>
          </div>
        </div>
      </div>

      {/* Interactive Line Chart comparison vs Benchmarks */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4 mb-4">
            <div>
              <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest mb-1">
                <TrendingUp className="w-4 h-4" />
                <span>Growth Index Comparative Track (1Y)</span>
              </div>
              <h3 className="text-base font-bold text-white font-serif">Portfolio vs Institutional Benchmarks</h3>
            </div>

            {/* Benchmark Selector */}
            <div className="flex items-center gap-1 bg-slate-950 border border-slate-800 p-1 rounded font-mono">
              <span className="text-[10px] text-slate-500 px-1.5 uppercase font-bold">VS:</span>
              {(["MSCIWorld", "SP500", "FTSE100", "BTC"] as const).map((bm) => (
                <button
                  key={bm}
                  onClick={() => setSelectedBenchmark(bm)}
                  className={`px-2 py-1 text-[10px] rounded transition-all duration-150 uppercase ${
                    selectedBenchmark === bm
                      ? "bg-amber-500 text-slate-950 font-bold shadow-md"
                      : "text-slate-400 hover:text-white"
                  }`}
                >
                  {bm === "SP500" ? "S&P 500" : bm === "FTSE100" ? "FTSE 100" : bm === "MSCIWorld" ? "MSCI World" : "Bitcoin"}
                </button>
              ))}
            </div>
          </div>

          <div className="h-72 w-full font-mono text-xs">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={HISTORICAL_CHART_DATA} margin={{ left: -15, right: 10, top: 10, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="month" stroke="#64748b" />
                <YAxis stroke="#64748b" domain={["auto", "auto"]} />
                <Tooltip
                  contentStyle={{ backgroundColor: "#020617", borderColor: "#334155", color: "#f8fafc" }}
                  labelStyle={{ fontWeight: "bold", color: "#f59e0b" }}
                />
                <Legend />
                <Line
                  name="GPIP Portfolio"
                  type="monotone"
                  dataKey="Portfolio"
                  stroke="#f59e0b"
                  strokeWidth={3}
                  dot={{ r: 4 }}
                  activeDot={{ r: 6 }}
                />
                <Line
                  name={
                    selectedBenchmark === "SP500"
                      ? "S&P 500 Index"
                      : selectedBenchmark === "FTSE100"
                      ? "FTSE 100 Index"
                      : selectedBenchmark === "MSCIWorld"
                      ? "MSCI World"
                      : "Bitcoin Core Spot"
                  }
                  type="monotone"
                  dataKey={selectedBenchmark}
                  stroke="#64748b"
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                  dot={{ r: 2 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
          <p className="text-[11px] text-slate-500 font-mono mt-3 text-center">
            *Base Index 100 on August 2025. Aggregate data models dividends re-invested (total return indices).
          </p>
        </div>

        {/* Category Correlation Heatmap */}
        <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl">
          <div className="flex items-center gap-2 text-amber-400 font-mono text-xs uppercase tracking-widest mb-1 border-b border-slate-800 pb-3">
            <Sliders className="w-4 h-4 text-amber-500" />
            <span>Category Correlation Matrix</span>
          </div>

          <div className="overflow-x-auto mt-3 font-mono text-[9px] selection:bg-transparent">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr>
                  <th className="py-1 px-1.5 text-slate-500 font-bold uppercase border-b border-slate-800">Class</th>
                  {CATEGORIES.map((cat) => (
                    <th
                      key={cat}
                      className="py-1 px-1 text-slate-500 font-bold uppercase border-b border-slate-800 text-center"
                      title={cat}
                    >
                      {cat.slice(0, 3)}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {CATEGORIES.map((rowCat) => (
                  <tr key={rowCat} className="hover:bg-slate-950/40">
                    <td className="py-1.5 px-1.5 text-slate-300 font-semibold border-b border-slate-800/50">
                      {rowCat}
                    </td>
                    {CATEGORIES.map((colCat) => {
                      const corr = CORRELATION_MATRIX[rowCat][colCat];
                      return (
                        <td
                          key={colCat}
                          className={`py-1.5 px-1 border-b border-slate-800/50 text-center rounded-sm transition-colors ${getHeatmapColor(
                            corr
                          )}`}
                          title={`Correlation between ${rowCat} and ${colCat}: ${corr}`}
                        >
                          {corr.toFixed(2)}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="bg-slate-950 p-3 border border-slate-800 rounded-lg mt-4 flex items-start gap-2 text-[10px] text-slate-400 font-mono leading-relaxed">
            <Info className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
            <span>
              <strong>Volatility Hedge Note</strong>: A portfolio holding Bitcoin alongside Infrastructure exhibits low correlation indices, optimizing the overall portfolio Sharpe ratio and mitigating tail-risk events.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};
