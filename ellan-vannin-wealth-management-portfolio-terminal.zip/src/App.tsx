/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import {
  TrendingUp,
  ShieldAlert,
  Sliders,
  Compass,
  Coins,
  FileText,
  Brain,
  Landmark,
  Layers,
  ArrowUpRight,
  Info,
  Users,
  Briefcase,
  ExternalLink,
  ChevronRight,
  Printer,
} from "lucide-react";

// Types
import {
  PortfolioDatabase,
  PortfolioAsset,
  CashFlowItem,
  GenerationalMember,
  StrategicReserve,
  PortfolioMode,
} from "./types";

// Financial Engines
import {
  calculatePortfolioMetrics,
  getRiskMetrics,
} from "./utils/portfolio_engines";

// Component Views
import { TerminalHeader } from "./components/TerminalHeader";
import { SovereignFundView } from "./components/SovereignFundView";
import { Britain2040View } from "./components/Britain2040View";
import { FamilyOfficeView } from "./components/FamilyOfficeView";
import { BitcoinModuleView } from "./components/BitcoinModuleView";
import { InfrastructureModuleView } from "./components/InfrastructureModuleView";
import { PerformanceRiskPanel } from "./components/PerformanceRiskPanel";
import { AssetAllocationPanel } from "./components/AssetAllocationPanel";
import { OptimizationRebalancePanel } from "./components/OptimizationRebalancePanel";
import { CashFlowTrackerPanel } from "./components/CashFlowTrackerPanel";
import { FutureWealthForecastPanel } from "./components/FutureWealthForecastPanel";
import { AssetDatabasePanel } from "./components/AssetDatabasePanel";
import { AiAdvisorPanel } from "./components/AiAdvisorPanel";
import { ReportGeneratorPanel } from "./components/ReportGeneratorPanel";

type ActiveTab =
  | "Overview"
  | "RiskPerformance"
  | "Allocation"
  | "Rebalance"
  | "CashFlows"
  | "Forecast"
  | "Bitcoin"
  | "Infrastructure"
  | "Registry"
  | "AiAdvisor"
  | "ExecutiveReport";

export default function App() {
  const [db, setDb] = useState<PortfolioDatabase | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [activeTab, setActiveTab] = useState<ActiveTab>("Overview");

  // Fetch full portfolio state on load
  const loadPortfolio = async () => {
    try {
      const res = await fetch("/api/portfolio");
      if (!res.ok) throw new Error("Failed to sync portfolio database.");
      const data = await res.json();
      setDb(data);
    } catch (err: any) {
      setError(err.message || "An unexpected network socket error occurred.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadPortfolio();
  }, []);

  // Update System Mode or Role
  const handleModeRoleChange = async (mode: PortfolioMode, role: "Client" | "Advisor" | "Administrator") => {
    if (!db) return;
    try {
      const res = await fetch("/api/portfolio/mode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode, role }),
      });
      if (res.ok) {
        setDb({
          ...db,
          systemConfig: {
            ...db.systemConfig,
            selectedMode: mode,
            selectedRole: role,
          },
        });
      }
    } catch (err) {
      console.error("Error setting terminal mode:", err);
    }
  };

  // Asset additions & deletions
  const handleAddAsset = async (asset: Omit<PortfolioAsset, "id">) => {
    try {
      const res = await fetch("/api/portfolio/asset/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(asset),
      });
      if (res.ok) loadPortfolio();
    } catch (err) {
      console.error("Error adding position:", err);
    }
  };

  const handleAddInfraAsset = async (infra: Omit<any, "id">) => {
    const portfolioAsset: Omit<PortfolioAsset, "id"> = {
      category: "Infrastructure",
      infrastructure: {
        id: `infra-${Date.now()}`,
        projectName: infra.projectName,
        projectType: infra.projectType,
        investmentAmount: infra.investmentAmount,
        expectedIrr: infra.expectedIrr,
        currentValuation: infra.currentValuation,
        annualIncome: infra.annualIncome,
        stage: infra.stage,
      },
    };
    await handleAddAsset(portfolioAsset);
  };

  const handleDeleteAsset = async (id: string) => {
    try {
      const res = await fetch("/api/portfolio/asset/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (res.ok) loadPortfolio();
    } catch (err) {
      console.error("Error deleting position:", err);
    }
  };

  // Cashflow additions & deletions
  const handleAddCashFlow = async (item: Omit<CashFlowItem, "id">) => {
    try {
      const res = await fetch("/api/portfolio/cashflow/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(item),
      });
      if (res.ok) loadPortfolio();
    } catch (err) {
      console.error("Error adding cashflow:", err);
    }
  };

  const handleDeleteCashFlow = async (id: string) => {
    try {
      const res = await fetch("/api/portfolio/cashflow/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (res.ok) loadPortfolio();
    } catch (err) {
      console.error("Error deleting cashflow:", err);
    }
  };

  // Beneficiary additions & deletions
  const handleAddMember = async (member: Omit<GenerationalMember, "id">) => {
    try {
      const res = await fetch("/api/portfolio/member/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(member),
      });
      if (res.ok) loadPortfolio();
    } catch (err) {
      console.error("Error adding member:", err);
    }
  };

  const handleDeleteMember = async (id: string) => {
    try {
      const res = await fetch("/api/portfolio/member/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (res.ok) loadPortfolio();
    } catch (err) {
      console.error("Error deleting member:", err);
    }
  };

  // Sovereign Reserve additions & deletions
  const handleAddReserve = async (reserve: Omit<StrategicReserve, "id">) => {
    try {
      const res = await fetch("/api/portfolio/reserve/add", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(reserve),
      });
      if (res.ok) loadPortfolio();
    } catch (err) {
      console.error("Error adding reserve:", err);
    }
  };

  const handleDeleteReserve = async (id: string) => {
    try {
      const res = await fetch("/api/portfolio/reserve/delete", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id }),
      });
      if (res.ok) loadPortfolio();
    } catch (err) {
      console.error("Error deleting reserve:", err);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center space-y-4">
        <div className="w-12 h-12 rounded-full border-4 border-amber-500 border-t-transparent animate-spin" />
        <span className="text-amber-400 font-mono text-xs uppercase tracking-widest animate-pulse">
          Synchronizing Ellan Vannin Databases...
        </span>
      </div>
    );
  }

  if (error || !db) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 text-center font-mono text-xs">
        <div className="bg-rose-500/10 border border-rose-500/20 rounded-lg p-6 max-w-md space-y-3">
          <ShieldAlert className="w-10 h-10 text-rose-500 mx-auto animate-bounce" />
          <h3 className="text-white text-sm font-bold uppercase">Sovereign Data Bridge Offline</h3>
          <p className="text-slate-400 leading-relaxed">
            {error || "An unexpected error disrupted our connection to the Express backend."}
          </p>
          <button
            onClick={() => window.location.reload()}
            className="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2 rounded transition-all uppercase tracking-widest text-[10px]"
          >
            Reconnect Terminal
          </button>
        </div>
      </div>
    );
  }

  const { assets, cashFlows, generationalMembers, strategicReserves, systemConfig } = db;

  // Perform core financial math
  const metrics = calculatePortfolioMetrics(assets);
  const totalPortfolioValue = metrics.totalValue;
  const categoryVals = metrics.categoryVals;
  const currencyExposure = metrics.currencyExposure;

  const riskMetrics = getRiskMetrics(assets, totalPortfolioValue);

  // Retrieve Bitcoin holding row safely
  const btcAsset = assets.find((a) => a.category === "Bitcoin")?.bitcoin;

  // Retrieve Infrastructure list mapped to parent asset ID for seamless delete orchestration
  const infraAssets = assets
    .filter((a) => a.category === "Infrastructure" && a.infrastructure)
    .map((a) => ({
      ...a.infrastructure!,
      id: a.id,
    }));

  // Extract liquid cash GBP reserves for cash runway computations
  const cashAssetRow = assets.find((a) => a.category === "Cash" && a.cash);
  const liquidCashGbp = cashAssetRow?.cash ? cashAssetRow.cash.amount * cashAssetRow.cash.exchangeRateToGbp : 500000;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-amber-500/20 selection:text-white">
      {/* Premium Header Widget */}
      <TerminalHeader
        selectedMode={systemConfig.selectedMode}
        selectedRole={systemConfig.selectedRole}
        onModeChange={(mode) => handleModeRoleChange(mode, systemConfig.selectedRole)}
        onRoleChange={(role) => handleModeRoleChange(systemConfig.selectedMode, role)}
        totalValue={totalPortfolioValue}
        overallYield={metrics.overallYield}
        volatility={riskMetrics.volatility}
        sharpeRatio={riskMetrics.sharpeRatio}
        riskScore={riskMetrics.riskScore}
      />

      <div className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 flex flex-col lg:flex-row gap-6">
        {/* Navigation Sidebar Drawer */}
        <aside className="w-full lg:w-64 shrink-0 font-mono text-[11px] uppercase tracking-wider space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl space-y-2">
            <span className="text-[9px] text-slate-500 block uppercase font-bold tracking-widest pl-2 mb-1">
              Primary Nav Vectors
            </span>

            <nav className="space-y-1">
              {(
                [
                  { id: "Overview", label: "Dashboard Overview", icon: <Layers className="w-3.5 h-3.5" /> },
                  { id: "RiskPerformance", label: "Risk & Performance", icon: <ShieldAlert className="w-3.5 h-3.5" /> },
                  { id: "Allocation", label: "Allocation Map", icon: <Compass className="w-3.5 h-3.5" /> },
                  { id: "Rebalance", label: "Optimization Hub", icon: <Sliders className="w-3.5 h-3.5" /> },
                  { id: "CashFlows", label: "Cash Flow Ledger", icon: <Coins className="w-3.5 h-3.5" /> },
                  { id: "Forecast", label: "Monte Carlo projection", icon: <TrendingUp className="w-3.5 h-3.5" /> },
                ] as const
              ).map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg font-bold transition-all text-left ${
                    activeTab === item.id
                      ? "bg-slate-950 text-amber-400 border border-amber-500/20 shadow-md"
                      : "text-slate-400 hover:text-white hover:bg-slate-950/40"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {item.icon}
                    <span>{item.label}</span>
                  </div>
                  <ChevronRight className={`w-3 h-3 ${activeTab === item.id ? "opacity-100" : "opacity-0"}`} />
                </button>
              ))}
            </nav>

            <span className="text-[9px] text-slate-500 block uppercase font-bold tracking-widest pl-2 mt-4 mb-1">
              Alternative Desks
            </span>

            <nav className="space-y-1">
              {(
                [
                  { id: "Bitcoin", label: "Sovereign Bitcoin Reserve", icon: <Coins className="w-3.5 h-3.5 text-orange-400" /> },
                  { id: "Infrastructure", label: "Direct Real Assets", icon: <Compass className="w-3.5 h-3.5 text-teal-400" /> },
                ] as const
              ).map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg font-bold transition-all text-left ${
                    activeTab === item.id
                      ? "bg-slate-950 text-amber-400 border border-amber-500/20 shadow-md"
                      : "text-slate-400 hover:text-white hover:bg-slate-950/40"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {item.icon}
                    <span>{item.label}</span>
                  </div>
                  <ChevronRight className={`w-3 h-3 ${activeTab === item.id ? "opacity-100" : "opacity-0"}`} />
                </button>
              ))}
            </nav>

            <span className="text-[9px] text-slate-500 block uppercase font-bold tracking-widest pl-2 mt-4 mb-1">
              Governance & Intelligence
            </span>

            <nav className="space-y-1">
              {(
                [
                  { id: "Registry", label: "Holdings Database", icon: <Briefcase className="w-3.5 h-3.5" /> },
                  { id: "AiAdvisor", label: "Aladdin AI Advisor", icon: <Brain className="w-3.5 h-3.5 text-purple-400" /> },
                  { id: "ExecutiveReport", label: "Executive Report Print", icon: <FileText className="w-3.5 h-3.5" /> },
                ] as const
              ).map((item) => (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-lg font-bold transition-all text-left ${
                    activeTab === item.id
                      ? "bg-slate-950 text-amber-400 border border-amber-500/20 shadow-md"
                      : "text-slate-400 hover:text-white hover:bg-slate-950/40"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {item.icon}
                    <span>{item.label}</span>
                  </div>
                  <ChevronRight className={`w-3 h-3 ${activeTab === item.id ? "opacity-100" : "opacity-0"}`} />
                </button>
              ))}
            </nav>
          </div>

          {/* Quick Stats side panel */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 shadow-xl text-[10px] space-y-3">
            <span className="text-slate-500 block font-bold">Terminal Health Status</span>
            <div className="space-y-1.5">
              <div className="flex justify-between">
                <span className="text-slate-400">Database Bridge:</span>
                <span className="text-emerald-400 font-bold">ONLINE</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Total Positions:</span>
                <span className="text-white font-bold">{assets.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Isle of Man Jurisdiction:</span>
                <span className="text-amber-400 font-bold">SECURED</span>
              </div>
            </div>
          </div>
        </aside>

        {/* Primary Main Content View Panel */}
        <main className="flex-1 min-w-0">
          {activeTab === "Overview" && (
            <div className="space-y-6">
              {/* Context-aware Specialist View displayed prominently based on Selected Mode */}
              {systemConfig.selectedMode === "Sovereign" && (
                <SovereignFundView
                  reserves={strategicReserves}
                  role={systemConfig.selectedRole}
                  onAddReserve={handleAddReserve}
                  onDeleteReserve={handleDeleteReserve}
                  totalPortfolioValue={totalPortfolioValue}
                />
              )}

              {systemConfig.selectedMode === "Britain2040" && (
                <Britain2040View
                  assets={assets}
                />
              )}

              {systemConfig.selectedMode === "FamilyOffice" && (
                <FamilyOfficeView
                  members={generationalMembers}
                  role={systemConfig.selectedRole}
                  onAddMember={handleAddMember}
                  onDeleteMember={handleDeleteMember}
                  totalPortfolioValue={totalPortfolioValue}
                />
              )}

              {/* General standard landing dashboard if no specific specialist mode selected */}
              {systemConfig.selectedMode === "Standard" && (
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl font-mono text-xs">
                  <div className="border-b border-slate-800 pb-4 mb-4">
                    <div className="flex items-center gap-2 text-amber-400 uppercase tracking-widest text-[10px] font-bold">
                      <Layers className="w-4 h-4" />
                      <span>Platform Executive Suite</span>
                    </div>
                    <h2 className="text-lg font-serif font-bold text-white mt-1">Global Wealth Terminal Overview</h2>
                    <p className="text-slate-400 text-[11px] mt-1 leading-relaxed">
                      Toggle specific sovereign policy or family dynasty themes in the top header selector to boot specialist reserve, rail link, or corporate inheritance trusts modules instantly.
                    </p>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
                    <div className="bg-slate-950 p-4 border border-slate-850 rounded-lg">
                      <span className="text-[10px] text-slate-500 block uppercase">Liquid Portfolio Cap</span>
                      <span className="text-lg font-extrabold text-white">£{totalPortfolioValue.toLocaleString()}</span>
                      <p className="text-[9px] text-slate-500 mt-1">Baskets valuation net of liabilities</p>
                    </div>

                    <div className="bg-slate-950 p-4 border border-slate-850 rounded-lg">
                      <span className="text-[10px] text-slate-500 block uppercase">Annual Volatility</span>
                      <span className="text-lg font-extrabold text-amber-200">{(riskMetrics.volatility * 100).toFixed(1)}%</span>
                      <p className="text-[9px] text-slate-500 mt-1">Aggregate daily pricing standard dev</p>
                    </div>

                    <div className="bg-slate-950 p-4 border border-slate-850 rounded-lg">
                      <span className="text-[10px] text-slate-500 block uppercase">Aladdin Risk Score</span>
                      <span className="text-lg font-extrabold text-amber-300">{riskMetrics.riskScore}/10</span>
                      <p className="text-[9px] text-slate-500 mt-1">Defensive profile status check</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Main dashboard list widgets: mini charts or categories */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Micro Category list */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl font-mono text-xs space-y-3">
                  <span className="text-[10px] text-amber-400 uppercase tracking-widest font-bold">Category Distribution</span>
                  <div className="space-y-2.5">
                    {Object.entries(categoryVals as Record<string, number>)
                      .sort((a, b) => b[1] - a[1])
                      .map(([cat, val]) => (
                        <div key={cat} className="flex justify-between items-center bg-slate-950 p-2 border border-slate-850 rounded">
                          <span className="font-bold text-slate-300 font-serif">{cat}</span>
                          <span className="text-white font-semibold">£{val.toLocaleString(undefined, { maximumFractionDigits: 0 })}</span>
                        </div>
                      ))}
                  </div>
                </div>

                {/* Micro active positions lists */}
                <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-xl font-mono text-xs space-y-3">
                  <span className="text-[10px] text-amber-400 uppercase tracking-widest font-bold">Recent Positions Core Ledger</span>
                  <div className="space-y-2">
                    {assets.slice(0, 5).map((a) => {
                      let label = "";
                      if (a.equity) label = `${a.equity.company} (${a.equity.ticker})`;
                      else if (a.bond) label = a.bond.issuer;
                      else if (a.fund) label = a.fund.name;
                      else if (a.property) label = a.property.address;
                      else if (a.privateEquity) label = a.privateEquity.company;
                      else if (a.bitcoin) label = "Sovereign Bitcoin Reserve";
                      else if (a.commodity) label = `${a.commodity.assetName} Spot`;
                      else if (a.infrastructure) label = a.infrastructure.projectName;
                      else if (a.cash) label = `Cash (${a.cash.currency})`;

                      return (
                        <div key={a.id} className="flex justify-between items-center text-[11px] hover:text-white transition-colors border-b border-slate-850 pb-2">
                          <span className="text-slate-400 truncate max-w-[200px]">{label}</span>
                          <span className="bg-slate-950 border border-slate-850 text-slate-400 px-2 py-0.5 rounded text-[10px] uppercase">{a.category}</span>
                        </div>
                      );
                    })}
                  </div>
                  <button
                    onClick={() => setActiveTab("Registry")}
                    className="w-full text-center text-amber-400 text-[10px] uppercase font-bold pt-1 hover:text-amber-500 transition-colors"
                  >
                    View All {assets.length} Positions inside Database Registry
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === "RiskPerformance" && (
            <PerformanceRiskPanel riskMetrics={riskMetrics} totalValue={totalPortfolioValue} />
          )}

          {activeTab === "Allocation" && (
            <AssetAllocationPanel
              categoryVals={categoryVals}
              currencyExposure={currencyExposure}
              totalValue={totalPortfolioValue}
            />
          )}

          {activeTab === "Rebalance" && (
            <OptimizationRebalancePanel categoryVals={categoryVals} totalValue={totalPortfolioValue} />
          )}

          {activeTab === "CashFlows" && (
            <CashFlowTrackerPanel
              cashFlows={cashFlows}
              role={systemConfig.selectedRole}
              onAddCashFlow={handleAddCashFlow}
              onDeleteCashFlow={handleDeleteCashFlow}
              liquidCashGbp={liquidCashGbp}
            />
          )}

          {activeTab === "Forecast" && <FutureWealthForecastPanel totalPortfolioValue={totalPortfolioValue} />}

          {activeTab === "Bitcoin" && (
            <BitcoinModuleView btcAsset={btcAsset} totalPortfolioValue={totalPortfolioValue} />
          )}

          {activeTab === "Infrastructure" && (
            <InfrastructureModuleView
              infrastructureAssets={infraAssets}
              role={systemConfig.selectedRole}
              onAddInfrastructure={handleAddInfraAsset}
              onDeleteInfrastructure={handleDeleteAsset}
            />
          )}

          {activeTab === "Registry" && (
            <AssetDatabasePanel
              assets={assets}
              role={systemConfig.selectedRole}
              onAddAsset={handleAddAsset}
              onUpdateAsset={(updated) => console.log("Update requested:", updated)}
              onDeleteAsset={handleDeleteAsset}
            />
          )}

          {activeTab === "AiAdvisor" && <AiAdvisorPanel totalValue={totalPortfolioValue} riskScore={riskMetrics.riskScore} />}

          {activeTab === "ExecutiveReport" && (
            <ReportGeneratorPanel
              assets={assets}
              members={generationalMembers}
              riskMetrics={riskMetrics}
              totalValue={totalPortfolioValue}
            />
          )}
        </main>
      </div>
    </div>
  );
}
