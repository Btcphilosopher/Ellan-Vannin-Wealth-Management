/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import { PortfolioDatabase, PortfolioAsset, CashFlowItem, GenerationalMember, StrategicReserve } from "./src/types";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

const DB_PATH = path.join(process.cwd(), "db_portfolio.json");

// Default Institutional Seed Data (£25,450,000)
const DEFAULT_DATABASE: PortfolioDatabase = {
  assets: [
    // --- Equities (40% Target -> ~£10.18m) ---
    {
      id: "eq-1",
      category: "Equities",
      equity: {
        id: "eq-1",
        company: "AstraZeneca PLC",
        ticker: "AZN.LN",
        shares: 32000,
        purchasePrice: 105.5,
        currentPrice: 114.2,
        dividendsReceived: 185000,
      },
    },
    {
      id: "eq-2",
      category: "Equities",
      equity: {
        id: "eq-2",
        company: "Apple Inc.",
        ticker: "AAPL.US",
        shares: 20000,
        purchasePrice: 145.2,
        currentPrice: 182.5,
        dividendsReceived: 92000,
      },
    },
    {
      id: "eq-3",
      category: "Equities",
      equity: {
        id: "eq-3",
        company: "Shell PLC",
        ticker: "SHEL.LN",
        shares: 110000,
        purchasePrice: 22.4,
        currentPrice: 28.6,
        dividendsReceived: 340000,
      },
    },
    {
      id: "eq-4",
      category: "Equities",
      equity: {
        id: "eq-4",
        company: "Taiwan Semiconductor Manufacturing Co.",
        ticker: "TSM.US",
        shares: 18000,
        purchasePrice: 88.0,
        currentPrice: 142.3,
        dividendsReceived: 45000,
      },
    },

    // --- Fixed Income & Bonds (20% Target -> ~£5.09m) ---
    {
      id: "bond-1",
      category: "Bonds",
      bond: {
        id: "bond-1",
        issuer: "UK Sovereign Gilt 4.25% 2035",
        ticker: "TG35.LN",
        faceValue: 3000000,
        purchasePrice: 97.4,
        currentPrice: 99.8,
        maturityDate: "2035-09-07",
        couponRate: 4.25,
        yieldToMaturity: 4.27,
      },
    },
    {
      id: "bond-2",
      category: "Bonds",
      bond: {
        id: "bond-2",
        issuer: "US Treasury Note 10Y",
        ticker: "US10Y",
        faceValue: 2000000,
        purchasePrice: 98.2,
        currentPrice: 101.5,
        maturityDate: "2034-05-15",
        couponRate: 4.125,
        yieldToMaturity: 3.98,
      },
    },

    // --- Funds & ETFs (10% -> ~£2.55m) ---
    {
      id: "fund-1",
      category: "Funds",
      fund: {
        id: "fund-1",
        name: "iShares Core MSCI World ETF GBP",
        ticker: "SWDA.LN",
        fundType: "ETF",
        shares: 28000,
        purchasePrice: 65.5,
        currentPrice: 82.3,
        distributionsReceived: 62000,
      },
    },
    {
      id: "fund-2",
      category: "Funds",
      fund: {
        id: "fund-2",
        name: "Vanguard S&P 500 UCITS ETF",
        ticker: "VUSA.LN",
        fundType: "ETF",
        shares: 3200,
        purchasePrice: 620.0,
        currentPrice: 742.0,
        distributionsReceived: 18500,
      },
    },

    // --- Property (15% Target -> ~£3.82m) ---
    {
      id: "prop-1",
      category: "Property",
      property: {
        id: "prop-1",
        address: "Athol Street Office Chambers, Douglas, Isle of Man",
        purchasePrice: 2200000,
        currentValue: 2550000,
        annualRentalIncome: 145000,
        mortgageOutstanding: 850000,
        mortgageRate: 4.85,
      },
    },
    {
      id: "prop-2",
      category: "Property",
      property: {
        id: "prop-2",
        address: "Belgravia Commercial Space, London",
        purchasePrice: 1100000,
        currentValue: 1267500,
        annualRentalIncome: 62000,
        mortgageOutstanding: 0,
        mortgageRate: 0,
      },
    },

    // --- Private Equity (Generational - FO) ---
    {
      id: "pe-1",
      category: "Private Equity",
      privateEquity: {
        id: "pe-1",
        company: "Manx Bio-Tech Partners Ltd",
        investmentDate: "2023-03-12",
        originalInvestment: 400000,
        currentValuation: 650000,
        targetIrr: 18.5,
        philanthropyContribution: 50000,
      },
    },

    // --- Bitcoin Dedicated Module (10% Target -> ~£2.55m) ---
    {
      id: "btc-1",
      category: "Bitcoin",
      bitcoin: {
        id: "btc-1",
        btcHolding: 45.32,
        averagePurchasePrice: 32500,
        currentPrice: 56150, // in GBP, approximately £2.545m total
        coldStorageLocation: "Isle of Man Freeport Vault - Deep Multi-Sig",
      },
    },

    // --- Commodities (Gold reserves) ---
    {
      id: "comm-1",
      category: "Commodities",
      commodity: {
        id: "comm-1",
        assetName: "Gold",
        quantity: 250, // troy ounces
        purchasePrice: 1550,
        currentPrice: 2045, // ~£511k
      },
    },

    // --- Infrastructure Assets Module (Tailored for sovereign capital / Britain 2040) ---
    {
      id: "infra-1",
      category: "Infrastructure",
      infrastructure: {
        id: "infra-1",
        projectName: "Ellan Vannin Offshore Wind Array Phase I",
        projectType: "Energy",
        investmentAmount: 1200000,
        expectedIrr: 11.2,
        currentValuation: 1450000,
        annualIncome: 95000,
        stage: "Operational",
      },
    },
    {
      id: "infra-2",
      category: "Infrastructure",
      infrastructure: {
        id: "infra-2",
        projectName: "Britain 2040 Nuclear SMR Development (Sizewell)",
        projectType: "Energy",
        investmentAmount: 800000,
        expectedIrr: 14.5,
        currentValuation: 800000,
        annualIncome: 0,
        stage: "Planning",
      },
    },
    {
      id: "infra-3",
      category: "Infrastructure",
      infrastructure: {
        id: "infra-3",
        projectName: "Heysham Green Port & Forestry Carbon Sink",
        projectType: "Forestry",
        investmentAmount: 450000,
        expectedIrr: 8.8,
        currentValuation: 495000,
        annualIncome: 18000,
        stage: "Operational",
      },
    },

    // --- Cash & FX Module (5% Target -> ~£1.27m) ---
    {
      id: "cash-1",
      category: "Cash",
      cash: {
        id: "cash-1",
        amount: 850000,
        currency: "GBP",
        exchangeRateToGbp: 1.0,
      },
    },
    {
      id: "cash-2",
      category: "Cash",
      cash: {
        id: "cash-2",
        amount: 420000,
        currency: "USD",
        exchangeRateToGbp: 0.78, // ~£327.6k
      },
    },
    {
      id: "cash-3",
      category: "Cash",
      cash: {
        id: "cash-3",
        amount: 110000,
        currency: "EUR",
        exchangeRateToGbp: 0.85, // ~£93.5k
      },
    },
  ],
  cashFlows: [
    { id: "cf-1", type: "Income", category: "Dividends", amount: 662000, frequency: "Quarterly" },
    { id: "cf-2", type: "Income", category: "Rent", amount: 207000, frequency: "Monthly" },
    { id: "cf-3", type: "Income", category: "Infrastructure Yield", amount: 113000, frequency: "Annually" },
    { id: "cf-4", type: "Expense", category: "Wealth Advisory Fees", amount: 125000, frequency: "Annually" },
    { id: "cf-5", type: "Expense", category: "Trust Administration & Tax Drag", amount: 180000, frequency: "Annually" },
    { id: "cf-6", type: "Expense", category: "Philanthropic Disbursements", amount: 80000, frequency: "Annually" },
  ],
  generationalMembers: [
    { id: "gen-1", name: "Sir Archibald Callow", relationship: "Founder", allocatedShare: 45, trustStructure: "The Callow Permanent Dynasty Trust (IOM)", inheritanceTaxPlanned: true },
    { id: "gen-2", name: "Lady Eleanor Callow", relationship: "Spouse", allocatedShare: 25, trustStructure: "Athol Marital Trust", inheritanceTaxPlanned: true },
    { id: "gen-3", name: "Victoria Callow-Christian", relationship: "G2 Daughter (MD)", allocatedShare: 20, trustStructure: "Victoria G2 Discretionary settlement", inheritanceTaxPlanned: true },
    { id: "gen-4", name: "Archie Christian", relationship: "G3 Grandson (Scholar)", allocatedShare: 10, trustStructure: "Grandchild Education trust", inheritanceTaxPlanned: false },
  ],
  strategicReserves: [
    { id: "res-1", assetName: "Manx Sovereign Liquidity Pool", type: "Foreign Exchange Reserve", amountGbp: 15000000, purpose: "Currency Peg Stabilization & Immediate Deficit Runway Buffer" },
    { id: "res-2", assetName: "Sovereign Strategic Agri-forestry Reserve", type: "Natural Resource", amountGbp: 8500000, purpose: "Long-term carbon balancing and forestry strategic timber assets" },
    { id: "res-3", assetName: "Ramsey Harbour Green Port Anchor", type: "Permanent Capital", amountGbp: 12000000, purpose: "Permanent critical connectivity infrastructure of national significance" },
  ],
  systemConfig: {
    selectedRole: "Advisor",
    selectedMode: "Standard",
    currency: "GBP",
  },
};

// Database read/write helpers
function readDatabase(): PortfolioDatabase {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify(DEFAULT_DATABASE, null, 2));
    return DEFAULT_DATABASE;
  }
  try {
    const data = fs.readFileSync(DB_PATH, "utf8");
    return JSON.parse(data);
  } catch (error) {
    console.error("Failed to read database, falling back to default:", error);
    return DEFAULT_DATABASE;
  }
}

function writeDatabase(db: PortfolioDatabase) {
  try {
    fs.writeFileSync(DB_PATH, JSON.stringify(db, null, 2));
  } catch (error) {
    console.error("Failed to write database:", error);
  }
}

// --- PORTFOLIO API ENDPOINTS ---

app.get("/api/portfolio", (req, res) => {
  const db = readDatabase();
  res.json(db);
});

app.post("/api/portfolio/mode", (req, res) => {
  const { mode, role } = req.body;
  const db = readDatabase();
  if (mode) db.systemConfig.selectedMode = mode;
  if (role) db.systemConfig.selectedRole = role;
  writeDatabase(db);
  res.json({ success: true, config: db.systemConfig });
});

app.post("/api/portfolio/asset/add", (req, res) => {
  const asset: PortfolioAsset = req.body;
  if (!asset.id) asset.id = `asset-${Date.now()}`;
  const db = readDatabase();
  db.assets.push(asset);
  writeDatabase(db);
  res.json({ success: true, asset });
});

app.post("/api/portfolio/asset/update", (req, res) => {
  const updatedAsset: PortfolioAsset = req.body;
  const db = readDatabase();
  const index = db.assets.findIndex((a) => a.id === updatedAsset.id);
  if (index !== -1) {
    db.assets[index] = updatedAsset;
    writeDatabase(db);
    res.json({ success: true, asset: updatedAsset });
  } else {
    res.status(404).json({ error: "Asset not found" });
  }
});

app.post("/api/portfolio/asset/delete", (req, res) => {
  const { id } = req.body;
  const db = readDatabase();
  db.assets = db.assets.filter((a) => a.id !== id);
  writeDatabase(db);
  res.json({ success: true });
});

// Cashflow API
app.post("/api/portfolio/cashflow/add", (req, res) => {
  const item: CashFlowItem = req.body;
  if (!item.id) item.id = `cf-${Date.now()}`;
  const db = readDatabase();
  db.cashFlows.push(item);
  writeDatabase(db);
  res.json({ success: true, item });
});

app.post("/api/portfolio/cashflow/delete", (req, res) => {
  const { id } = req.body;
  const db = readDatabase();
  db.cashFlows = db.cashFlows.filter((cf) => cf.id !== id);
  writeDatabase(db);
  res.json({ success: true });
});

// Family Office Member API
app.post("/api/portfolio/member/add", (req, res) => {
  const member: GenerationalMember = req.body;
  if (!member.id) member.id = `gen-${Date.now()}`;
  const db = readDatabase();
  db.generationalMembers.push(member);
  writeDatabase(db);
  res.json({ success: true, member });
});

app.post("/api/portfolio/member/delete", (req, res) => {
  const { id } = req.body;
  const db = readDatabase();
  db.generationalMembers = db.generationalMembers.filter((m) => m.id !== id);
  writeDatabase(db);
  res.json({ success: true });
});

// Sovereign Reserve API
app.post("/api/portfolio/reserve/add", (req, res) => {
  const reserve: StrategicReserve = req.body;
  if (!reserve.id) reserve.id = `res-${Date.now()}`;
  const db = readDatabase();
  db.strategicReserves.push(reserve);
  writeDatabase(db);
  res.json({ success: true, reserve });
});

app.post("/api/portfolio/reserve/delete", (req, res) => {
  const { id } = req.body;
  const db = readDatabase();
  db.strategicReserves = db.strategicReserves.filter((r) => r.id !== id);
  writeDatabase(db);
  res.json({ success: true });
});


// --- GEMINI AI INTEGRATION ENDPOINT ---

app.post("/api/gemini/advisor", async (req, res) => {
  const { portfolioState, promptType } = req.body;
  
  if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === "MY_GEMINI_API_KEY") {
    // If key is missing or is the placeholder, return a beautiful simulated professional guidance block
    return res.json({
      advice: `### 🏛️ Ellan Vannin Wealth Management Executive Briefing
*(Simulation Mode — Configure your real GEMINI_API_KEY in Settings > Secrets for customized dynamic live AI briefings)*

Dear Principal,

Based on your current portfolio valuation of **£${(portfolioState?.totalValue || 25450000).toLocaleString(undefined, { maximumFractionDigits: 0 })}** and recorded risk-score of **${portfolioState?.riskMetrics?.riskScore || "5"}/10**, we have compiled the following institutional-grade directives:

#### 1. Strategic Asset Allocation Review
Your portfolio currently exhibits an equity bias with a **${portfolioState?.equityWeight?.toFixed(1) || "40"}%** allocation. While this supports long-term wealth compounding, current market volatility suggests a mild rebalancing towards high-yielding infrastructure assets. 
* **Equities Action**: Realize minor gains in late-stage tech indices (S&P 500) and shift **£500,000** into sovereign-backed clean energy projects under the **Britain 2040** theme.
* **Fixed Income Action**: Your coupon yield of **${portfolioState?.bondYield?.toFixed(2) || "4.21"}%** is highly secure, anchored by UK gilts. Retain these to act as a liquid defensive volatility dampener.

#### 2. Alternative & Bitcoin Reserve Guidance
Your Bitcoin allocation sits at **${portfolioState?.btcWeight?.toFixed(1) || "10"}%** of the liquid asset base. In line with the *Manx Permanent Capital Strategy*, Bitcoin serves as a digital gold sovereign reserve.
* **Custody**: Ensure holdings remain in the Douglas multi-sig vault.
* **Risk Envelope**: Volatility is currently high (**${(portfolioState?.riskMetrics?.volatility * 100)?.toFixed(1) || "11.5"}%** aggregate). Maintain a hard stop-rebalance trigger if the BTC allocation drifts beyond **15%** of total liquid capital.

#### 3. Sovereign Fund & Britain 2040 Commentary
Under the Sovereign/Britain 2040 thematic lenses, your wind power and small-modular nuclear (SMR) pipeline positions are exemplary:
* High-density offshore wind is yielding a solid **${portfolioState?.infraYield?.toFixed(2) || "7.9"}%** unlevered cash-on-cash return.
* SMR development remains in planning. It is critical to stagger capital drawdowns over the next 36 months to manage the classic J-curve investment dip.

#### 4. Generational & Family Office Directives
With multiple trusts active, Victoria Callow-Christian's MD transition is securely funded. Ensure that Archie Christian's upcoming educational trust draws distributions from the cash reserves (yielding **4.5%**) rather than liquidating high-performing equity assets to minimize capital gains tax realization.

*Ellan Vannin Investment Committee*
*Douglas, Isle of Man*`
    });
  }

  try {
    const ai = new GoogleGenAI({
      apiKey: process.env.GEMINI_API_KEY,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    const portfolioValueStr = portfolioState?.totalValue ? `£${portfolioState.totalValue.toLocaleString()}` : "£25.45M";
    const riskScore = portfolioState?.riskMetrics?.riskScore || 5;
    const volatilityStr = portfolioState?.riskMetrics?.volatility ? `${(portfolioState.riskMetrics.volatility * 100).toFixed(1)}%` : "11.5%";
    const assetsList = JSON.stringify(portfolioState?.assets || []);

    const systemInstruction = `You are the lead institutional investment advisor, chief risk officer, and family office managing director for Ellan Vannin Wealth Management based in Douglas, Isle of Man. 
Your tone is highly professional, sober, sophisticated, and deeply informed, similar to reports from BlackRock Aladdin, Goldman Sachs, or Norges Bank.
Generate a structured wealth briefing for the portfolio principal. Always format output in clean, readable markdown without any greeting placeholder. Always include specific asset allocations, currency risk warnings, sovereign infrastructure themes (such as railways, SMR nuclear, offshore wind, carbon sink forestry), Bitcoin digital reserve custody advice, and trust-generational tax-saving strategies.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.6-flash",
      contents: `Draft an executive brief for a portfolio valued at ${portfolioValueStr} with a Risk Score of ${riskScore}/10 and aggregate Volatility of ${volatilityStr}. 
Specific prompt context requested: ${promptType || "General strategic allocation and risk overview"}. 
Current holdings details: ${assetsList}`,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    res.json({ advice: response.text });
  } catch (error: any) {
    console.error("Gemini API error:", error);
    res.status(500).json({ error: "Failed to consult Gemini advisor: " + error?.message });
  }
});


// --- VITE MIDDLEWARE / STATIC SERVING ---

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Ellan Vannin Portfolio Platform running on port ${PORT}`);
  });
}

startServer();
