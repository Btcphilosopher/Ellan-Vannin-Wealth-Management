/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HydrogenAsset, FinancialMetrics, ScenarioParameters, CapitalAllocationWeights } from '../types';

// Constants for finance modelling
const DEFAULT_DEBT_RATIO = 0.45; // 45% debt financing
const DEFAULT_DEBT_INTEREST = 0.055; // 5.5% cost of debt
const DEFAULT_MAINTENANCE_RATE = 0.015; // 1.5% of capital invested annually for maintenance

/**
 * Solves for IRR using the Secant/Bisection method
 */
export function calculateIRR(initialInvestment: number, cashFlows: number[]): number {
  const maxIterations = 200;
  const tolerance = 0.00001;

  // Function to calculate NPV at rate 'r'
  const npvAtRate = (r: number): number => {
    let sum = -initialInvestment;
    for (let t = 0; t < cashFlows.length; t++) {
      sum += cashFlows[t] / Math.pow(1 + r, t + 1);
    }
    return sum;
  };

  // Find bounds
  let low = -0.99;
  let high = 2.0;
  let npvLow = npvAtRate(low);
  let npvHigh = npvAtRate(high);

  if (npvLow * npvHigh > 0) {
    // If both have the same sign, we adjust bounds
    if (npvLow < 0) {
      // IRR is extremely negative, cap at low
      return -0.95;
    } else {
      // IRR is extremely high
      low = 0.0;
      high = 5.0;
      npvLow = npvAtRate(low);
      npvHigh = npvAtRate(high);
      if (npvLow * npvHigh > 0) return 0.45; // sensible fallback
    }
  }

  // Bisection method
  let mid = 0.0;
  for (let i = 0; i < maxIterations; i++) {
    mid = (low + high) / 2;
    const npvMid = npvAtRate(mid);

    if (Math.abs(npvMid) < tolerance) {
      return mid;
    }

    if (npvLow * npvMid < 0) {
      high = mid;
      npvHigh = npvMid;
    } else {
      low = mid;
      npvLow = npvMid;
    }
  }

  return mid;
}

/**
 * Calculates project-level financial metrics under given scenario modifiers
 */
export function modelAssetFinance(
  asset: HydrogenAsset,
  discountRate: number = 0.07,
  scenarios: ScenarioParameters = {
    electricityPriceMod: 1.0,
    hydrogenDemandMod: 1.0,
    capexMod: 1.0,
    opexMod: 1.0,
    financingCostMod: 0.0,
    inflationMod: 0.05,
    carbonPricingMod: 1.0,
    discountRate: 7.0
  }
): FinancialMetrics {
  const years = asset.expectedLifeYears;
  const initialCapital = asset.capitalInvestedM * scenarios.capexMod;
  
  // Debt structure
  const debtRatio = DEFAULT_DEBT_RATIO;
  const debtCapital = initialCapital * debtRatio;
  const equityInvestment = initialCapital * (1 - debtRatio);
  const costOfDebt = DEFAULT_DEBT_INTEREST + scenarios.financingCostMod / 100;
  
  // Amortized annual debt service (equal payments over asset life)
  const annualDebtService = debtCapital > 0 
    ? (debtCapital * costOfDebt * Math.pow(1 + costOfDebt, years)) / (Math.pow(1 + costOfDebt, years) - 1)
    : 0;

  const freeCashFlows: number[] = [];
  const discountedCashFlows: number[] = [];
  let cumulativeDCF = 0;
  let presentValueFutureCashFlows = 0;

  // Project 25 years or expected life
  for (let t = 1; t <= years; t++) {
    const inflationMultiplier = Math.pow(1 + scenarios.inflationMod / 100, t);
    
    // Revenue modeled with hydrogen demand, market modifiers, and ownership share
    // Green hydrogen production benefits more from hydrogen demand multipliers, pipelines from volume, blending from carbon pricing
    let revMod = scenarios.hydrogenDemandMod;
    if (asset.assetType === 'Green Hydrogen Production') {
      revMod = scenarios.hydrogenDemandMod * (2.0 - scenarios.electricityPriceMod * 0.4); // production impacted by power input cost
    } else if (asset.assetType === 'Industrial Blending Plant') {
      revMod = scenarios.hydrogenDemandMod * scenarios.carbonPricingMod;
    }
    
    const annualRevenue = asset.annualRevenueM * revMod * (asset.ownershipPercentage / 100) * inflationMultiplier;
    
    // Opex modeled with general opex modification
    let opexMod = scenarios.opexMod;
    if (asset.assetType === 'Green Hydrogen Production') {
      opexMod = scenarios.opexMod * (scenarios.electricityPriceMod * 0.6 + 0.4); // high power dependency
    }
    const annualOpex = asset.operatingCostM * opexMod * (asset.ownershipPercentage / 100) * inflationMultiplier;
    
    // Maintenance escalates slightly with age
    const maintenanceCost = (initialCapital * DEFAULT_MAINTENANCE_RATE) * (1 + 0.01 * t) * (asset.ownershipPercentage / 100) * inflationMultiplier;
    
    // Debt service is fixed nominal, but real value decreases with inflation
    const actualDebtService = annualDebtService;

    // Free Cash Flow = Revenue - Opex - Maintenance - Debt Service
    const fcf = annualRevenue - annualOpex - maintenanceCost - actualDebtService;
    freeCashFlows.push(fcf);

    // Discounted Cash Flow
    const dcf = fcf / Math.pow(1 + discountRate, t);
    discountedCashFlows.push(dcf);
    presentValueFutureCashFlows += dcf;
  }

  // NPV = PV of future cash flows - Initial Equity Investment
  const npv = presentValueFutureCashFlows - equityInvestment;
  
  // IRR on equity investment
  const irr = calculateIRR(equityInvestment, freeCashFlows);

  // Payback Period (Equity)
  let paybackPeriod = years;
  let cumEquityCF = -equityInvestment;
  for (let t = 0; t < years; t++) {
    cumEquityCF += freeCashFlows[t];
    if (cumEquityCF >= 0) {
      // Interpolate for exact fraction of year
      const lastOwed = cumEquityCF - freeCashFlows[t];
      const fraction = Math.abs(lastOwed) / freeCashFlows[t];
      paybackPeriod = t + fraction;
      break;
    }
  }

  // Profitability Index (PV of Future Cash Flows / Equity)
  const profitabilityIndex = presentValueFutureCashFlows / (equityInvestment || 1);

  // Return on Invested Capital (average of annual FCF / total invested equity)
  const totalFCF = freeCashFlows.reduce((sum, fcf) => sum + fcf, 0);
  const averageFCF = totalFCF / years;
  const roic = (averageFCF / equityInvestment) * 100;

  return {
    npv,
    irr,
    paybackPeriod,
    profitabilityIndex,
    roic,
    freeCashFlows,
    discountedCashFlows
  };
}

/**
 * Module 4 — Scoring Engine
 */
export function scoreProject(
  asset: HydrogenAsset,
  finance: FinancialMetrics,
  weights: CapitalAllocationWeights
): { score: number; details: Record<string, number> } {
  // Score 1-10 for each criteria
  
  // 1. IRR Score (capped at 25% IRR -> 10, <= 4% -> 1)
  const irrPct = finance.irr * 100;
  const irrScore = Math.max(1, Math.min(10, 1 + (irrPct - 4) * (9 / 21)));

  // 2. Cash Flow score (cumulative nominal FCF over expected life, relative to investment size)
  const totalFCF = finance.freeCashFlows.reduce((sum, fcf) => sum + fcf, 0);
  const cfRatio = totalFCF / asset.capitalInvestedM;
  const cashFlowScore = Math.max(1, Math.min(10, Math.round(1 + cfRatio * 2.5)));

  // 3. Capital Efficiency (Profitability Index)
  // PI = 1.0 -> score 1, PI >= 2.0 -> score 10
  const capitalEfficiencyScore = Math.max(1, Math.min(10, 1 + (finance.profitabilityIndex - 1.0) * 9));

  // 4. Construction Risk (Higher status -> lower risk -> higher score)
  const riskScores: Record<string, number> = {
    'Operational': 10,
    'Under Construction': 7,
    'Detailed Design': 5,
    'Pre-feasibility': 3
  };
  const constructionRiskScore = riskScores[asset.constructionStatus] || 5;

  // 5. Tech Maturity
  const techScores: Record<string, number> = {
    'Green Hydrogen Production': 8,
    'Hydrogen Storage Facility': 7,
    'Pipeline Distribution Network': 9,
    'Industrial Blending Plant': 8,
    'Heavy Transport Refuelling Station': 8
  };
  const techScore = techScores[asset.assetType] || 8;

  // 6. Diversification contribution (simulate standard diversification helper)
  const divScore = asset.ownershipPercentage < 100 ? 9 : 6; // Co-investments get higher diversification score

  // 7. Regional strategy (high strategic zones like Teesside, Scotland, Wales get high scores)
  const regionScores: Record<string, number> = {
    'Scotland': 9,
    'North East': 10,
    'Wales': 9,
    'Yorkshire & Humber': 8,
    'North West': 8,
    'South West': 7,
    'South East': 7,
    'East Midlands': 6
  };
  const regionalScore = regionScores[asset.region] || 7;

  // 8. ESG score (Lower carbon intensity -> higher score)
  // CI = 0.1 -> score 10, CI >= 0.8 -> score 1
  const esgScore = Math.max(1, Math.min(10, 10 - (asset.carbonIntensity - 0.1) * (9 / 0.7)));

  // Compute weighted average
  const totalWeight = Object.values(weights).reduce((sum, w) => sum + w, 0);
  const weightedSum =
    irrScore * weights.irrWeight +
    cashFlowScore * weights.cashFlowWeight +
    capitalEfficiencyScore * weights.capitalEfficiencyWeight +
    constructionRiskScore * weights.technologyMaturityWeight + // map construction risk
    techScore * weights.technologyMaturityWeight +
    divScore * weights.diversificationWeight +
    regionalScore * weights.regionalStrategyWeight +
    esgScore * weights.esgWeight;

  const finalScore = Number((weightedSum / (totalWeight || 1)).toFixed(2));

  return {
    score: finalScore,
    details: {
      irr: Number(irrScore.toFixed(1)),
      cashFlow: Number(cashFlowScore.toFixed(1)),
      capitalEfficiency: Number(capitalEfficiencyScore.toFixed(1)),
      constructionRisk: Number(constructionRiskScore.toFixed(1)),
      technologyMaturity: Number(techScore.toFixed(1)),
      diversification: Number(divScore.toFixed(1)),
      regionalStrategy: Number(regionalScore.toFixed(1)),
      esg: Number(esgScore.toFixed(1))
    }
  };
}

/**
 * Module 5 — Portfolio Optimizer
 * Simulates Mean-Variance Efficient Frontier and recommends optimal allocations
 */
export function generateEfficientFrontier(
  assets: HydrogenAsset[],
  discountRate: number,
  constraints: {
    maxRegionalWeight: number; // e.g. 0.40 for max 40% in one region
    maxAssetTypeWeight: number; // e.g. 0.50
    targetIRR: number; // e.g. 8%
  }
) {
  // Map risk rating to a standard deviation proxy
  const riskToStdev = (rating: string): number => {
    switch (rating) {
      case 'Low': return 0.05;
      case 'Medium-Low': return 0.08;
      case 'Medium': return 0.12;
      case 'Medium-High': return 0.16;
      case 'High': return 0.22;
      default: return 0.12;
    }
  };

  const assetReturns = assets.map(a => {
    const fin = modelAssetFinance(a, discountRate);
    return {
      id: a.id,
      name: a.name,
      irr: fin.irr,
      risk: riskToStdev(a.riskRating),
      capital: a.capitalInvestedM,
      region: a.region,
      type: a.assetType
    };
  });

  // Calculate correlation proxy (similar regions/types have mild correlation)
  const getCorrelation = (i: number, j: number): number => {
    if (i === j) return 1.0;
    let corr = 0.15; // low base correlation
    if (assetReturns[i].region === assetReturns[j].region) corr += 0.25;
    if (assetReturns[i].type === assetReturns[j].type) corr += 0.20;
    return corr;
  };

  // Generate 15 points along the efficient frontier
  const frontierPoints: { returnPct: number; riskPct: number; weights: Record<string, number> }[] = [];

  // Minimum standard deviation portfolio and Maximum return portfolio
  const numAssets = assets.length;

  // Let's create frontier configurations by varying risk tolerance
  for (let step = 0; step < 15; step++) {
    // Risk tolerance from 0 (minimize variance) to 1 (maximize return)
    const lambda = step / 14; 

    // Heuristic solver for optimization weights (complying with weights summing to 100%)
    let rawWeights = assetReturns.map((asset, idx) => {
      // Score based on (lambda * Return) - ((1 - lambda) * Risk)
      const objectiveScore = lambda * asset.irr - (1 - lambda) * asset.risk * 1.5;
      return Math.max(0.01, objectiveScore + 0.5); // shift to keep positive
    });

    // Enforce constraints (regional caps, asset type caps)
    // Run an iterative scaling projection
    for (let iter = 0; iter < 10; iter++) {
      // Normalize first
      const total = rawWeights.reduce((s, w) => s + w, 0);
      rawWeights = rawWeights.map(w => w / (total || 1));

      // Region check & limit
      const regionWeights: Record<string, number> = {};
      assetReturns.forEach((a, i) => {
        regionWeights[a.region] = (regionWeights[a.region] || 0) + rawWeights[i];
      });

      assetReturns.forEach((a, i) => {
        if (regionWeights[a.region] > constraints.maxRegionalWeight) {
          // clip the weight
          const excess = regionWeights[a.region] - constraints.maxRegionalWeight;
          rawWeights[i] = rawWeights[i] - excess * (rawWeights[i] / regionWeights[a.region]);
        }
      });

      // Asset Type check & limit
      const typeWeights: Record<string, number> = {};
      assetReturns.forEach((a, i) => {
        typeWeights[a.type] = (typeWeights[a.type] || 0) + rawWeights[i];
      });

      assetReturns.forEach((a, i) => {
        if (typeWeights[a.type] > constraints.maxAssetTypeWeight) {
          const excess = typeWeights[a.type] - constraints.maxAssetTypeWeight;
          rawWeights[i] = rawWeights[i] - excess * (rawWeights[i] / typeWeights[a.type]);
        }
      });
    }

    // Final Normalize
    const finalTotal = rawWeights.reduce((s, w) => s + w, 0);
    const weightsMap: Record<string, number> = {};
    assetReturns.forEach((asset, i) => {
      weightsMap[asset.id] = Number(((rawWeights[i] / (finalTotal || 1)) * 100).toFixed(1));
    });

    // Calculate Portfolio Return and Risk
    let portfolioReturn = 0;
    let portfolioVar = 0;

    assetReturns.forEach((asset, i) => {
      const wi = weightsMap[asset.id] / 100;
      portfolioReturn += wi * asset.irr;
      
      assetReturns.forEach((other, j) => {
        const wj = weightsMap[other.id] / 100;
        portfolioVar += wi * wj * asset.risk * other.risk * getCorrelation(i, j);
      });
    });

    const portfolioRisk = Math.sqrt(portfolioVar);

    frontierPoints.push({
      returnPct: Number((portfolioReturn * 100).toFixed(2)),
      riskPct: Number((portfolioRisk * 100).toFixed(2)),
      weights: weightsMap
    });
  }

  // Find the point on the frontier that is closest to constraints.targetIRR (or maximizes Sharpe ratio)
  let bestIndex = 0;
  let minDiff = Infinity;
  frontierPoints.forEach((pt, i) => {
    const diff = Math.abs(pt.returnPct - constraints.targetIRR);
    if (diff < minDiff) {
      minDiff = diff;
      bestIndex = i;
    }
  });

  return {
    frontier: frontierPoints,
    recommended: frontierPoints[bestIndex] || frontierPoints[7]
  };
}
