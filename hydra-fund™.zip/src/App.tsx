/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { INITIAL_ASSETS } from './data/sampleAssets';
import { HydrogenAsset, AuditLogEntry } from './types';
import { 
  Building2, 
  Database as DatabaseIcon, 
  DollarSign, 
  Scale, 
  MapPin, 
  SlidersHorizontal, 
  ShieldAlert, 
  FileText, 
  LayoutDashboard, 
  Settings2,
  TrendingUp,
  Cpu
} from 'lucide-react';

// Import newly created module views
import ExecutiveDashboard from './components/ExecutiveDashboard';
import AssetRegister from './components/AssetRegister';
import FinanceEngineView from './components/FinanceEngineView';
import CapitalAllocationView from './components/CapitalAllocationView';
import PortfolioOptimizerView from './components/PortfolioOptimizerView';
import ScenarioAnalysisView from './components/ScenarioAnalysisView';
import RegionalInvestmentAtlas from './components/RegionalInvestmentAtlas';
import RiskDashboardView from './components/RiskDashboardView';
import ReportingSuiteView from './components/ReportingSuiteView';
import DataManagementView from './components/DataManagementView';

export default function App() {
  const [assets, setAssets] = useState<HydrogenAsset[]>(INITIAL_ASSETS);
  const [discountRate, setDiscountRate] = useState<number>(0.065); // Default 6.5% WACC
  const [activeTab, setActiveTab] = useState<string>('dashboard');

  // Dynamic audit logs state for Module 12 persistence tracking
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([
    {
      timestamp: new Date().toLocaleTimeString(),
      action: 'SYSTEM_BOOT',
      user: 'Tom',
      details: 'HYDRA FUND™ sovereign portfolio ledger successfully mounted. Integrity keys verified.'
    },
    {
      timestamp: new Date().toLocaleTimeString(),
      action: 'SEED_PORTFOLIO',
      user: 'Tom',
      details: 'Populated 10 production-grade national UK hydrogen hubs into active RAM buffer.'
    }
  ]);

  const addAuditLog = (action: string, details: string) => {
    const newEntry: AuditLogEntry = {
      timestamp: new Date().toLocaleTimeString(),
      action,
      user: 'Tom',
      details
    };
    setAuditLogs(prev => [newEntry, ...prev]);
  };

  // Asset register write handles
  const handleAddAsset = (newAsset: HydrogenAsset) => {
    setAssets(prev => [...prev, newAsset]);
    addAuditLog('ASSET_CREATE', `Successfully registered new project: ${newAsset.name} (${newAsset.id}) with £${newAsset.capitalInvestedM}M allocated.`);
  };

  const handleUpdateAsset = (updatedAsset: HydrogenAsset) => {
    setAssets(prev => prev.map(a => a.id === updatedAsset.id ? updatedAsset : a));
    addAuditLog('ASSET_UPDATE', `Modified physical specifications on project: ${updatedAsset.name} (${updatedAsset.id}).`);
  };

  const handleDeleteAsset = (id: string) => {
    const deleted = assets.find(a => a.id === id);
    setAssets(prev => prev.filter(a => a.id !== id));
    if (deleted) {
      addAuditLog('ASSET_DELETE', `Divested and purged record for project: ${deleted.name} (${deleted.id}).`);
    }
  };

  // Bulk import assets from CSV
  const handleBulkImport = (imported: HydrogenAsset[]) => {
    setAssets(imported);
    addAuditLog('BULK_IMPORT', `Replaced portfolio holdings with ${imported.length} bulk imported entries.`);
  };

  const handleClearLogs = () => {
    setAuditLogs([
      {
        timestamp: new Date().toLocaleTimeString(),
        action: 'LOGS_CLEARED',
        user: 'Tom',
        details: 'Audit logs cache flushed by Administrator command.'
      }
    ]);
  };

  // Navigation structure
  const tabs = [
    { id: 'dashboard', label: 'Executive Dashboard', icon: LayoutDashboard },
    { id: 'register', label: 'Asset Registry', icon: DatabaseIcon },
    { id: 'finance', label: 'Project Finance', icon: DollarSign },
    { id: 'allocation', label: 'Capital Allocation', icon: Scale },
    { id: 'optimizer', label: 'Portfolio Optimiser', icon: TrendingUp },
    { id: 'scenario', label: 'Scenario Simulator', icon: SlidersHorizontal },
    { id: 'atlas', label: 'Regional Atlas', icon: MapPin },
    { id: 'risk', label: 'Risk Monitor', icon: ShieldAlert },
    { id: 'reporting', label: 'Reporting Suite', icon: FileText },
    { id: 'dataroom', label: 'Data Room', icon: Settings2 },
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-teal-500 selection:text-slate-950" id="hydra-app">
      {/* Sovereign Brand Top Header Bar */}
      <header className="bg-slate-950 text-slate-100 border-b border-slate-800 px-6 py-4 flex flex-col sm:flex-row sm:items-center justify-between" id="app-header">
        <div className="flex items-center space-x-3">
          <div className="bg-teal-500/10 p-2 rounded border border-teal-500/20">
            <Cpu className="w-5 h-5 text-teal-400" />
          </div>
          <div>
            <div className="flex items-center space-x-1.5">
              <h1 className="text-xl font-serif tracking-tight leading-none text-teal-400 font-bold uppercase">HYDRA FUND™</h1>
              <span className="bg-teal-500/10 text-teal-400 text-[9px] font-bold px-2 py-0.5 rounded border border-teal-500/20 uppercase tracking-wider">Sovereign Asset Suite</span>
            </div>
            <p className="text-[10px] text-slate-500 uppercase tracking-[0.2em] font-semibold mt-1">British Hydrogen National Sovereign Fund • Client: Ellan Vannin Wealth Management</p>
          </div>
        </div>
        
        {/* Quick status HUD */}
        <div className="mt-3 sm:mt-0 flex items-center space-x-4 text-xs text-slate-400 font-mono bg-slate-900/50 px-3.5 py-1.5 rounded border border-slate-800/60" id="hud-status">
          <div className="flex items-center space-x-1.5">
            <span className="w-2 h-2 rounded-full bg-teal-500 animate-pulse"></span>
            <span>Ledger: Encrypted</span>
          </div>
          <div className="border-l border-slate-800 h-3"></div>
          <div>
            <span>Active Hurdle: {(discountRate * 100).toFixed(1)}% WACC</span>
          </div>
        </div>
      </header>

      {/* Grid container of tabs and layout */}
      <div className="flex-1 flex flex-col md:flex-row" id="app-workspace">
        {/* Navigation panel */}
        <aside className="w-full md:w-64 bg-slate-950 border-r border-slate-800 flex flex-col justify-between py-6 px-4" id="app-sidebar">
          <div className="space-y-6">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500 px-3 block">Navigation Module</span>
            <nav className="space-y-1" id="app-navigation">
              {tabs.map(tab => {
                const Icon = tab.icon;
                const isActive = activeTab === tab.id;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`w-full text-left text-xs font-semibold px-3 py-2.5 flex items-center space-x-3 transition-colors ${
                      isActive 
                        ? 'bg-teal-500/10 text-teal-300 border-l-2 border-teal-500 font-medium' 
                        : 'text-slate-400 hover:bg-slate-900 hover:text-slate-200'
                    }`}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0 text-slate-500 group-hover:text-slate-300" />
                    <span>{tab.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>

          <div className="mt-8 border-t border-slate-800 pt-4 px-3 text-[10px] text-slate-500 leading-relaxed" id="sidebar-footer">
            <p className="text-[10px] text-slate-500 uppercase tracking-widest mb-1">Principal Client</p>
            <p className="font-serif italic text-slate-300 mb-2">Ellan Vannin Wealth Management</p>
            <p>System: R-v4.3.2 Production • Sovereign guidelines apply.</p>
          </div>
        </aside>

        {/* Dynamic Views Viewport */}
        <main className="flex-1 p-6 md:p-8 max-w-7xl mx-auto w-full overflow-y-auto" id="app-viewport">
          {activeTab === 'dashboard' && (
            <ExecutiveDashboard 
              assets={assets} 
              discountRate={discountRate} 
            />
          )}

          {activeTab === 'register' && (
            <AssetRegister 
              assets={assets}
              onAddAsset={handleAddAsset}
              onUpdateAsset={handleUpdateAsset}
              onDeleteAsset={handleDeleteAsset}
            />
          )}

          {activeTab === 'finance' && (
            <FinanceEngineView 
              assets={assets}
              discountRate={discountRate}
              onDiscountRateChange={(r) => {
                setDiscountRate(r);
                addAuditLog('WACC_MODIFY', `Adjusted Sovereign target WACC discount hurdle rate to ${(r * 100).toFixed(1)}%.`);
              }}
            />
          )}

          {activeTab === 'allocation' && (
            <CapitalAllocationView 
              assets={assets}
              discountRate={discountRate}
            />
          )}

          {activeTab === 'optimizer' && (
            <PortfolioOptimizerView 
              assets={assets}
              discountRate={discountRate}
            />
          )}

          {activeTab === 'scenario' && (
            <ScenarioAnalysisView 
              assets={assets}
              discountRate={discountRate}
            />
          )}

          {activeTab === 'atlas' && (
            <RegionalInvestmentAtlas 
              assets={assets}
              discountRate={discountRate}
            />
          )}

          {activeTab === 'risk' && (
            <RiskDashboardView 
              assets={assets}
              discountRate={discountRate}
            />
          )}

          {activeTab === 'reporting' && (
            <ReportingSuiteView 
              assets={assets}
              discountRate={discountRate}
            />
          )}

          {activeTab === 'dataroom' && (
            <DataManagementView 
              auditLogs={auditLogs}
              onClearLogs={handleClearLogs}
            />
          )}
        </main>
      </div>
    </div>
  );
}
