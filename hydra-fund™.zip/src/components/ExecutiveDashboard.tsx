/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { HydrogenAsset, FinancialMetrics } from '../types';
import { modelAssetFinance } from '../utils/financeEngine';
import { TrendingUp, Award, Layers, ShieldCheck, Activity, DollarSign, Percent, AlertCircle } from 'lucide-react';

interface ExecutiveDashboardProps {
  assets: HydrogenAsset[];
  discountRate: number;
}

export default function ExecutiveDashboard({ assets, discountRate }: ExecutiveDashboardProps) {
  // Compute aggregated portfolio metrics
  const portfolioStats = useMemo(() => {
    let totalInvested = 0;
    let totalEquityInvested = 0;
    let totalAnnualRevenue = 0;
    let totalAnnualOpex = 0;
    let totalNPV = 0;
    let weightedIRRNumerator = 0;
    let weightedLifeNumerator = 0;
    let underConstructionCount = 0;
    let operationalCount = 0;
    let totalCapacity = 0;
    let weightedCarbonNumerator = 0;

    assets.forEach(asset => {
      const finance = modelAssetFinance(asset, discountRate);
      
      // Ownership contribution
      const share = asset.ownershipPercentage / 100;
      totalInvested += asset.capitalInvestedM;
      totalEquityInvested += asset.capitalInvestedM * share * 0.55; // 55% equity portion
      totalAnnualRevenue += asset.annualRevenueM * share;
      totalAnnualOpex += asset.operatingCostM * share;
      totalCapacity += asset.capacityMW * share;
      
      totalNPV += finance.npv;
      weightedIRRNumerator += finance.irr * asset.capitalInvestedM;
      weightedLifeNumerator += asset.expectedLifeYears * asset.capitalInvestedM;
      weightedCarbonNumerator += asset.carbonIntensity * asset.capacityMW;

      if (asset.constructionStatus === 'Operational') {
        operationalCount++;
      } else {
        underConstructionCount++;
      }
    });

    const averageIRR = totalInvested > 0 ? (weightedIRRNumerator / totalInvested) : 0;
    const averageLife = totalInvested > 0 ? (weightedLifeNumerator / totalInvested) : 0;
    const averageCarbon = totalCapacity > 0 ? (weightedCarbonNumerator / totalCapacity) : 0.3;

    // Portfolio NAV = Total Equity Invested + Portfolio NPV
    const portfolioNAV = totalEquityInvested + totalNPV;
    const fundSize = 1000.0; // £1B sovereign fund allocation
    const capitalAvailable = fundSize - totalInvested;
    const debtRatio = 45.0; // 45% debt ratio

    return {
      aum: totalInvested,
      nav: portfolioNAV,
      annualCashFlow: totalAnnualRevenue - totalAnnualOpex - (totalInvested * 0.015), // net of maintenance
      irr: averageIRR * 100,
      npv: totalNPV,
      averageLife,
      debtRatio,
      capitalAvailable,
      constructionCount: underConstructionCount,
      operationalCount,
      capacity: totalCapacity,
      averageCarbon
    };
  }, [assets, discountRate]);

  // Asset type distribution
  const typeDistribution = useMemo(() => {
    const counts: Record<string, number> = {};
    assets.forEach(a => {
      counts[a.assetType] = (counts[a.assetType] || 0) + a.capitalInvestedM;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [assets]);

  // Total capacity and share calculations
  const totalCap = typeDistribution.reduce((acc, curr) => acc + curr.value, 0);

  return (
    <div className="space-y-8" id="dashboard-container">
      {/* Overview Intro */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-5" id="dashboard-header">
        <div>
          <h2 className="text-3xl font-serif text-slate-100 tracking-tight">Executive Dashboard</h2>
          <p className="text-sm text-slate-400 mt-1">Sovereign hydrogen infrastructure allocation summary and portfolio performance metrics.</p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center space-x-3 bg-slate-900 border border-slate-800 px-4 py-2 text-xs font-mono text-slate-400" id="current-funding-round">
          <Activity className="w-4 h-4 text-teal-400 animate-pulse" />
          <span>Active Allocation Window: <strong className="text-slate-100 font-medium">Q3 2026</strong></span>
        </div>
      </div>

      {/* Institutional KPI Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5" id="kpi-grid">
        {/* Metric 1 */}
        <div className="bg-slate-900/50 border border-slate-800 p-5 shadow-sm hover:border-slate-700/50 transition-all" id="kpi-aum">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Assets Under Management</span>
            <DollarSign className="w-4 h-4 text-slate-500" />
          </div>
          <div className="mt-2.5 flex items-baseline">
            <span className="text-3xl font-serif text-slate-100">£{portfolioStats.aum.toFixed(1)}M</span>
            <span className="text-[9px] uppercase font-mono text-slate-500 ml-2">allocated</span>
          </div>
          <div className="mt-4 text-xs text-slate-400 flex items-center justify-between">
            <span>Sovereign Fund Cap:</span>
            <span className="font-mono text-slate-300">£1,000.0M</span>
          </div>
          <div className="mt-2 w-full bg-slate-950 h-1">
            <div className="bg-teal-500 h-full" style={{ width: `${(portfolioStats.aum / 1000) * 100}%` }}></div>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-slate-900/50 border border-slate-800 p-5 shadow-sm hover:border-slate-700/50 transition-all" id="kpi-nav">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Net Asset Value (NAV)</span>
            <TrendingUp className="w-4 h-4 text-teal-400" />
          </div>
          <div className="mt-2.5 flex items-baseline">
            <span className="text-3xl font-serif text-teal-400">£{portfolioStats.nav.toFixed(1)}M</span>
            <span className="text-[9px] uppercase font-mono text-teal-400/80 ml-2">equity + premium</span>
          </div>
          <div className="mt-4 text-xs text-slate-400 flex items-center justify-between">
            <span>Net Portfolio Value Add:</span>
            <span className="font-mono text-slate-300">£{portfolioStats.npv.toFixed(1)}M</span>
          </div>
          <div className="mt-2 w-full bg-slate-950 h-1">
            <div className="bg-teal-500 h-full" style={{ width: `${Math.min(100, (portfolioStats.nav / portfolioStats.aum) * 100)}%` }}></div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-slate-900/50 border border-slate-800 p-5 shadow-sm hover:border-slate-700/50 transition-all" id="kpi-cash-flow">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Projected Portfolio IRR</span>
            <Percent className="w-4 h-4 text-slate-500" />
          </div>
          <div className="mt-2.5 flex items-baseline">
            <span className="text-3xl font-serif text-slate-100">{portfolioStats.irr.toFixed(2)}%</span>
            <span className="text-[9px] uppercase font-mono text-slate-500 ml-2">weighted avg</span>
          </div>
          <div className="mt-4 text-xs text-slate-400 flex items-center justify-between">
            <span>Target Sovereign Hurdle:</span>
            <span className="font-mono text-slate-300">7.00%</span>
          </div>
          <div className="mt-2 w-full bg-slate-950 h-1">
            <div className="bg-amber-500 h-full" style={{ width: `${Math.min(100, (portfolioStats.irr / 12) * 100)}%` }}></div>
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-slate-900/50 border border-slate-800 p-5 shadow-sm hover:border-slate-700/50 transition-all" id="kpi-npv">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[10px] uppercase tracking-widest font-bold text-slate-400">Net Portfolio Cash Flow</span>
            <Layers className="w-4 h-4 text-slate-500" />
          </div>
          <div className="mt-2.5 flex items-baseline">
            <span className="text-3xl font-serif text-slate-100">£{portfolioStats.annualCashFlow.toFixed(1)}M</span>
            <span className="text-[9px] uppercase font-mono text-slate-500 ml-2">p.a. net yield</span>
          </div>
          <div className="mt-4 text-xs text-slate-400 flex items-center justify-between">
            <span>Operational Assets:</span>
            <span className="font-mono text-slate-300">{portfolioStats.operationalCount} / {assets.length}</span>
          </div>
          <div className="mt-2 w-full bg-slate-950 h-1">
            <div className="bg-sky-500 h-full" style={{ width: `${(portfolioStats.operationalCount / assets.length) * 100}%` }}></div>
          </div>
        </div>
      </div>

      {/* Sub-KPI Details Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 bg-slate-900/20 border border-slate-800 p-4 text-center" id="secondary-metrics">
        <div id="sub-cap-available">
          <p className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Capital Available</p>
          <p className="text-xl font-serif text-slate-100 mt-1">£{portfolioStats.capitalAvailable.toFixed(1)}M</p>
        </div>
        <div className="border-l border-slate-800" id="sub-avg-life">
          <p className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Average Asset Life</p>
          <p className="text-xl font-serif text-slate-100 mt-1">{portfolioStats.averageLife.toFixed(1)} yrs</p>
        </div>
        <div className="border-l border-slate-800" id="sub-debt-ratio">
          <p className="text-[10px] uppercase tracking-widest font-bold text-slate-500">LTC Debt Ratio</p>
          <p className="text-xl font-serif text-slate-100 mt-1">{portfolioStats.debtRatio.toFixed(1)}%</p>
        </div>
        <div className="border-l border-slate-800" id="sub-capacity">
          <p className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Net Capacity (MW)</p>
          <p className="text-xl font-serif text-slate-100 mt-1">{portfolioStats.capacity.toFixed(1)} MW</p>
        </div>
        <div className="border-l border-slate-800 hidden md:block" id="sub-carbon">
          <p className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Avg Carbon Intensity</p>
          <p className="text-xl font-serif text-teal-400 mt-1">{portfolioStats.averageCarbon.toFixed(2)} kg</p>
        </div>
        <div className="border-l border-slate-800 hidden lg:block" id="sub-stage">
          <p className="text-[10px] uppercase tracking-widest font-bold text-slate-500">Under Construction</p>
          <p className="text-xl font-serif text-slate-100 mt-1">{portfolioStats.constructionCount} projects</p>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="dashboard-charts-grid">
        {/* Asset Allocation Chart (Left) */}
        <div className="bg-slate-900/40 border border-slate-800 p-5 lg:col-span-5" id="allocation-pie-card">
          <h3 className="text-xs uppercase tracking-widest text-slate-400 font-bold mb-4 flex items-center justify-between">
            <span>Portfolio Capital Allocation</span>
            <span className="text-[10px] font-mono font-normal text-slate-500 lowercase">by asset type</span>
          </h3>

          <div className="flex flex-col items-center justify-center py-4" id="allocation-pie-visualization">
            {/* Visual Donut representation in pure SVG */}
            <svg className="w-48 h-48 transform -rotate-90" viewBox="0 0 100 100">
              {typeDistribution.reduce<{ cumulativePercent: number; elements: React.ReactNode[] }>((acc, curr, index) => {
                const percent = (curr.value / totalCap) * 100;
                const dashArray = `${percent} ${100 - percent}`;
                const dashOffset = 100 - acc.cumulativePercent;
                
                // Colors representing the modern editorial slate and teal tones
                const colors = [
                  'stroke-teal-500',
                  'stroke-sky-500',
                  'stroke-indigo-500',
                  'stroke-amber-500',
                  'stroke-slate-500'
                ];
                const color = colors[index % colors.length];

                acc.elements.push(
                  <circle
                    key={index}
                    cx="50"
                    cy="50"
                    r="40"
                    fill="transparent"
                    className={`${color} stroke-[11] hover:stroke-[13] transition-all cursor-pointer`}
                    strokeDasharray={dashArray}
                    strokeDashoffset={dashOffset}
                  />
                );

                acc.cumulativePercent += percent;
                return acc;
              }, { cumulativePercent: 0, elements: [] }).elements}
              <circle cx="50" cy="50" r="28" fill="#0f172a" />
            </svg>

            {/* Absolute center metric */}
            <div className="text-center mt-4">
              <span className="text-[10px] uppercase tracking-wider text-slate-500">Total Asset Value</span>
              <p className="text-xl font-serif text-slate-100 mt-0.5">£{portfolioStats.aum.toFixed(1)}M</p>
            </div>
          </div>

          {/* Allocation Legend */}
          <div className="mt-5 space-y-2 text-xs" id="allocation-pie-legend">
            {typeDistribution.map((item, index) => {
              const colors = [
                'bg-teal-500',
                'bg-sky-500',
                'bg-indigo-500',
                'bg-amber-500',
                'bg-slate-500'
              ];
              const pct = ((item.value / totalCap) * 100).toFixed(1);
              return (
                <div key={item.name} className="flex items-center justify-between border-b border-slate-800/40 pb-1.5 last:border-0 last:pb-0">
                  <div className="flex items-center space-x-2 truncate">
                    <span className={`w-2 h-2 ${colors[index % colors.length]} flex-shrink-0`}></span>
                    <span className="truncate text-slate-300 font-medium">{item.name}</span>
                  </div>
                  <div className="flex items-center space-x-3 text-slate-400 font-mono text-right flex-shrink-0">
                    <span>£{item.value.toFixed(1)}M</span>
                    <span className="text-slate-500">({pct}%)</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Expected Cash Flow Forecast Preview (Right) */}
        <div className="bg-slate-900/40 border border-slate-800 p-5 lg:col-span-7 flex flex-col justify-between" id="cashflow-forecast-card">
          <div id="forecast-header">
            <h3 className="text-xs uppercase tracking-widest text-slate-400 font-bold mb-2 flex items-center justify-between">
              <span>Expected Annual Cash Generation Profile</span>
              <span className="text-[10px] font-mono font-normal text-slate-500">10-Year Horizon (£ Millions)</span>
            </h3>
            <p className="text-xs text-slate-400 mb-4">Consolidated net cash flows from operational assets, after subtracting opex, debt service, and statutory maintenance.</p>
          </div>

          <div className="h-56 flex items-end justify-between px-2 pt-6 relative" id="forecast-bar-chart">
            {/* Guide Gridlines */}
            <div className="absolute inset-0 flex flex-col justify-between pointer-events-none pb-8 pt-4">
              <div className="border-b border-dashed border-slate-800/60 w-full text-[9px] font-mono text-slate-500 text-right pr-1">£60M</div>
              <div className="border-b border-dashed border-slate-800/60 w-full text-[9px] font-mono text-slate-500 text-right pr-1">£40M</div>
              <div className="border-b border-dashed border-slate-800/60 w-full text-[9px] font-mono text-slate-500 text-right pr-1">£20M</div>
              <div className="border-b border-dashed border-slate-800/60 w-full text-[9px] font-mono text-slate-500 text-right pr-1">£0M</div>
            </div>

            {/* Hardcoded 10 year projection based on asset lifecycle, ramp-up and inflation */}
            {[
              { year: 'Year 1', val: portfolioStats.annualCashFlow * 0.8 }, // some under construction
              { year: 'Year 2', val: portfolioStats.annualCashFlow * 0.9 },
              { year: 'Year 3', val: portfolioStats.annualCashFlow * 1.05 }, // more operational
              { year: 'Year 4', val: portfolioStats.annualCashFlow * 1.15 },
              { year: 'Year 5', val: portfolioStats.annualCashFlow * 1.25 },
              { year: 'Year 6', val: portfolioStats.annualCashFlow * 1.30 },
              { year: 'Year 7', val: portfolioStats.annualCashFlow * 1.35 },
              { year: 'Year 8', val: portfolioStats.annualCashFlow * 1.40 },
              { year: 'Year 9', val: portfolioStats.annualCashFlow * 1.45 },
              { year: 'Year 10', val: portfolioStats.annualCashFlow * 1.50 }
            ].map((d, idx) => {
              // Map heights based on £60M max
              const heightPct = Math.min(95, (d.val / 60) * 100);
              return (
                <div key={idx} className="flex flex-col items-center flex-1 group z-10 mx-1">
                  {/* Tooltip */}
                  <div className="opacity-0 group-hover:opacity-100 transition-all absolute -top-1 bg-slate-950 text-slate-100 border border-slate-800 text-[10px] font-mono py-1 px-1.5 rounded-sm shadow pointer-events-none mb-1">
                    £{d.val.toFixed(1)}M
                  </div>
                  <div 
                    className="w-full bg-teal-500/20 group-hover:bg-teal-500 transition-all"
                    style={{ height: `${heightPct}%` }}
                  ></div>
                  <span className="text-[9px] uppercase tracking-widest font-mono text-slate-500 mt-2.5 text-center truncate w-full">{d.year.replace('Year ', 'Y')}</span>
                </div>
              );
            })}
          </div>

          <div className="mt-5 border-t border-slate-800 pt-4 flex items-center justify-between text-xs text-slate-400" id="forecast-footer-stats">
            <span className="flex items-center">
              <ShieldCheck className="w-4 h-4 text-teal-400 mr-1.5" />
              Sovereign guarantees covering 65% of forecasted volumes.
            </span>
            <span className="font-mono font-semibold text-slate-200 text-right">
              Cumulative 10yr: £{(portfolioStats.annualCashFlow * 12.1).toFixed(1)}M
            </span>
          </div>
        </div>
      </div>

      {/* Flagship Notice or Alert banner */}
      <div className="bg-slate-900/30 border border-slate-800 p-5 flex flex-col md:flex-row items-start md:items-center justify-between gap-4" id="sovereign-alignment-banner">
        <div className="flex items-start space-x-3.5">
          <div className="bg-teal-500/10 text-teal-400 p-2.5 mt-0.5 flex-shrink-0 border border-teal-500/20">
            <Award className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-semibold text-slate-100 font-serif">National Sovereign Hydrogen Strategy Alignment</h4>
            <p className="text-xs text-slate-400 mt-0.5">The portfolio is structurally structured to reduce UK carbon emissions by approximately <strong className="text-slate-200 font-medium">450k tonnes CO2e annually</strong> while anchoring local industrial workforces.</p>
          </div>
        </div>
        <div className="flex-shrink-0 text-xs font-semibold text-slate-300 bg-slate-950 border border-slate-800 px-3 py-1.5 shadow-sm">
          Net-Zero Direct Contribution: <span className="text-teal-400">A+ rated</span>
        </div>
      </div>
    </div>
  );
}
