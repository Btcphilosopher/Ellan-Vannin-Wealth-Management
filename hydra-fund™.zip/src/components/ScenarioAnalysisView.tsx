/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { HydrogenAsset, ScenarioParameters } from '../types';
import { modelAssetFinance } from '../utils/financeEngine';
import { Sliders, RefreshCw, AlertTriangle, TrendingUp, Compass } from 'lucide-react';

interface ScenarioAnalysisViewProps {
  assets: HydrogenAsset[];
  discountRate: number;
}

export default function ScenarioAnalysisView({ assets, discountRate }: ScenarioAnalysisViewProps) {
  // Scenario variables state
  const [scenarioName, setScenarioName] = useState<string>('Baseline');
  const [params, setParams] = useState<ScenarioParameters>({
    electricityPriceMod: 1.0,
    hydrogenDemandMod: 1.0,
    capexMod: 1.0,
    opexMod: 1.0,
    financingCostMod: 0.0,
    inflationMod: 2.0, // 2% baseline
    carbonPricingMod: 1.0,
    discountRate: discountRate * 100
  });

  // Load a quick macroeconomic scenario preset
  const applyPreset = (preset: string) => {
    setScenarioName(preset);
    switch (preset) {
      case 'Baseline':
        setParams({
          electricityPriceMod: 1.0,
          hydrogenDemandMod: 1.0,
          capexMod: 1.0,
          opexMod: 1.0,
          financingCostMod: 0.0,
          inflationMod: 2.0,
          carbonPricingMod: 1.0,
          discountRate: discountRate * 100
        });
        break;
      case 'Power Crisis / High Inflation':
        setParams({
          electricityPriceMod: 1.45, // +45% power cost
          hydrogenDemandMod: 0.85,  // depressed demand
          capexMod: 1.15,          // higher capex escalation
          opexMod: 1.20,          // opex shock
          financingCostMod: 2.5,  // +250bps interest rates
          inflationMod: 6.5,      // 6.5% inflation
          carbonPricingMod: 0.80,  // weaker carbon pricing support
          discountRate: (discountRate + 0.02) * 100 // higher hurdle
        });
        break;
      case 'Green Hydrogen Surge':
        setParams({
          electricityPriceMod: 0.75, // cheap power inputs
          hydrogenDemandMod: 1.35,  // high demand
          capexMod: 0.90,          // streamlined capex
          opexMod: 0.95,          // efficient opex
          financingCostMod: -1.0, // subsidized sovereign financing (-100bps)
          inflationMod: 2.5,      // moderate inflation
          carbonPricingMod: 1.50,  // high carbon prices boosting blending economics
          discountRate: (discountRate - 0.01) * 100 // lower hurdle
        });
        break;
      case 'Capex Crunch / Rate Hikes':
        setParams({
          electricityPriceMod: 1.0,
          hydrogenDemandMod: 1.0,
          capexMod: 1.25,          // +25% supply chain overruns
          opexMod: 1.0,
          financingCostMod: 4.0,  // severe rate shock (+400bps)
          inflationMod: 4.0,
          carbonPricingMod: 1.0,
          discountRate: (discountRate + 0.035) * 100
        });
        break;
    }
  };

  // Perform calculations for Baseline vs Scenario
  const comparisonData = useMemo(() => {
    let baseNPV = 0;
    let baseIRRNumerator = 0;
    let baseCashFlow = 0;
    let baseAUM = 0;

    let scenNPV = 0;
    let scenIRRNumerator = 0;
    let scenCashFlow = 0;
    let scenAUM = 0;

    const assetsComparison = assets.map(asset => {
      const share = asset.ownershipPercentage / 100;
      
      // Baseline financials
      const baseFin = modelAssetFinance(asset, discountRate);
      baseNPV += baseFin.npv;
      baseIRRNumerator += baseFin.irr * asset.capitalInvestedM;
      baseCashFlow += baseFin.freeCashFlows[0] || 0; // proxy Year 1 flow
      baseAUM += asset.capitalInvestedM;

      // Scenario financials
      const scenDiscountRate = params.discountRate / 100;
      const scenFin = modelAssetFinance(asset, scenDiscountRate, params);
      scenNPV += scenFin.npv;
      scenIRRNumerator += scenFin.irr * (asset.capitalInvestedM * params.capexMod);
      scenCashFlow += scenFin.freeCashFlows[0] || 0;
      scenAUM += asset.capitalInvestedM * params.capexMod;

      return {
        id: asset.id,
        name: asset.name,
        baseNPV: baseFin.npv,
        scenNPV: scenFin.npv,
        baseIRR: baseFin.irr * 100,
        scenIRR: scenFin.irr * 100
      };
    });

    const totalBaseCapital = assets.reduce((s, a) => s + a.capitalInvestedM, 0);
    const totalScenCapital = assets.reduce((s, a) => s + a.capitalInvestedM * params.capexMod, 0);

    return {
      baseline: {
        aum: baseAUM,
        npv: baseNPV,
        irr: totalBaseCapital > 0 ? (baseIRRNumerator / totalBaseCapital) * 100 : 0,
        cashFlow: baseCashFlow
      },
      scenario: {
        aum: scenAUM,
        npv: scenNPV,
        irr: totalScenCapital > 0 ? (scenIRRNumerator / totalScenCapital) * 100 : 0,
        cashFlow: scenCashFlow
      },
      assets: assetsComparison
    };
  }, [assets, discountRate, params]);

  return (
    <div className="space-y-6" id="scenarios-container">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-5" id="scenarios-header">
        <div>
          <h2 className="text-3xl font-serif text-slate-100 tracking-tight">Macro Scenario Simulator</h2>
          <p className="text-sm text-slate-400 mt-1">Side-by-side sensitivity forecasting, inflation modelling, and energy commodity stress testing.</p>
        </div>

        {/* Quick Scenario Preset Select */}
        <div className="mt-4 md:mt-0 flex items-center space-x-2" id="scenarios-presets">
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Presets:</span>
          {['Baseline', 'Power Crisis / High Inflation', 'Green Hydrogen Surge', 'Capex Crunch / Rate Hikes'].map(p => (
            <button 
              key={p}
              onClick={() => applyPreset(p)}
              className={`text-[10px] font-semibold px-2.5 py-1.5 rounded border transition-all cursor-pointer ${scenarioName === p ? 'bg-slate-950 text-teal-400 border-teal-500/30' : 'bg-slate-900/50 text-slate-300 border-slate-800/60 hover:bg-slate-900'}`}
            >
              {p.split(' / ')[0]}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="scenarios-views-grid">
        {/* Dynamic Modifiers Sidebar (Left) */}
        <div className="lg:col-span-4 bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm space-y-4" id="modifiers-card">
          <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 flex items-center justify-between">
            <span className="flex items-center">
              <Sliders className="w-4 h-4 text-teal-400 mr-2" />
              Scenario Modifiers
            </span>
            <button 
              onClick={() => applyPreset('Baseline')}
              className="text-[10px] text-slate-500 hover:text-teal-400 flex items-center space-x-1 cursor-pointer transition-colors"
              title="Reset all factors to neutral"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset</span>
            </button>
          </h3>

          <div className="space-y-4 text-xs" id="modifiers-sliders-list">
            {/* Input 1 */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Electricity Prices</span>
                <span className="font-mono font-bold text-teal-400">
                  {params.electricityPriceMod === 1.0 ? 'Neutral' : `${params.electricityPriceMod > 1.0 ? '+' : ''}${Math.round((params.electricityPriceMod - 1.0) * 100)}%`}
                </span>
              </div>
              <input 
                type="range" min="0.5" max="2.0" step="0.05"
                value={params.electricityPriceMod}
                onChange={(e) => setParams(prev => ({ ...prev, electricityPriceMod: Number(e.target.value) }))}
                className="w-full accent-teal-500 cursor-pointer"
              />
            </div>

            {/* Input 2 */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Hydrogen Contract Demand</span>
                <span className="font-mono font-bold text-teal-400">
                  {params.hydrogenDemandMod === 1.0 ? 'Neutral' : `${params.hydrogenDemandMod > 1.0 ? '+' : ''}${Math.round((params.hydrogenDemandMod - 1.0) * 100)}%`}
                </span>
              </div>
              <input 
                type="range" min="0.5" max="1.5" step="0.05"
                value={params.hydrogenDemandMod}
                onChange={(e) => setParams(prev => ({ ...prev, hydrogenDemandMod: Number(e.target.value) }))}
                className="w-full accent-teal-500 cursor-pointer"
              />
            </div>

            {/* Input 3 */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Capex Overruns</span>
                <span className="font-mono font-bold text-teal-400">
                  {params.capexMod === 1.0 ? 'Neutral' : `${params.capexMod > 1.0 ? '+' : ''}${Math.round((params.capexMod - 1.0) * 100)}%`}
                </span>
              </div>
              <input 
                type="range" min="0.7" max="1.3" step="0.05"
                value={params.capexMod}
                onChange={(e) => setParams(prev => ({ ...prev, capexMod: Number(e.target.value) }))}
                className="w-full accent-teal-500 cursor-pointer"
              />
            </div>

            {/* Input 4 */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Opex Escalation</span>
                <span className="font-mono font-bold text-teal-400">
                  {params.opexMod === 1.0 ? 'Neutral' : `${params.opexMod > 1.0 ? '+' : ''}${Math.round((params.opexMod - 1.0) * 100)}%`}
                </span>
              </div>
              <input 
                type="range" min="0.7" max="1.3" step="0.05"
                value={params.opexMod}
                onChange={(e) => setParams(prev => ({ ...prev, opexMod: Number(e.target.value) }))}
                className="w-full accent-teal-500 cursor-pointer"
              />
            </div>

            {/* Input 5 */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Sovereign Financing Premium</span>
                <span className="font-mono font-bold text-teal-400">
                  {params.financingCostMod === 0 ? 'Neutral' : `${params.financingCostMod > 0 ? '+' : ''}${params.financingCostMod.toFixed(2)}%`}
                </span>
              </div>
              <input 
                type="range" min="-2.0" max="5.0" step="0.5"
                value={params.financingCostMod}
                onChange={(e) => setParams(prev => ({ ...prev, financingCostMod: Number(e.target.value) }))}
                className="w-full accent-teal-500 cursor-pointer"
              />
            </div>

            {/* Input 6 */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Annual Core Inflation</span>
                <span className="font-mono font-bold text-teal-400">{params.inflationMod.toFixed(1)}%</span>
              </div>
              <input 
                type="range" min="0.0" max="10.0" step="0.5"
                value={params.inflationMod}
                onChange={(e) => setParams(prev => ({ ...prev, inflationMod: Number(e.target.value) }))}
                className="w-full accent-teal-500 cursor-pointer"
              />
            </div>

            {/* Input 7 */}
            <div>
              <div className="flex justify-between text-slate-400 mb-1">
                <span>Carbon Pricing Support</span>
                <span className="font-mono font-bold text-teal-400">
                  {params.carbonPricingMod === 1.0 ? 'Neutral' : `${params.carbonPricingMod > 1.0 ? '+' : ''}${Math.round((params.carbonPricingMod - 1.0) * 100)}%`}
                </span>
              </div>
              <input 
                type="range" min="0.5" max="2.0" step="0.1"
                value={params.carbonPricingMod}
                onChange={(e) => setParams(prev => ({ ...prev, carbonPricingMod: Number(e.target.value) }))}
                className="w-full accent-teal-500 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Side-by-Side Comparison Panels & Resiliance Chart (Right) */}
        <div className="lg:col-span-8 space-y-6" id="scenarios-main-views">
          {/* Side by Side Portfolio Metrics Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5" id="side-by-side-cards">
            {/* Baseline Card */}
            <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm" id="scenario-baseline-card">
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Baseline Portfolio State</span>
              <div className="mt-3 space-y-3.5 text-xs">
                <div className="flex justify-between border-b border-slate-850/60 pb-2">
                  <span className="text-slate-400 font-medium">Assets Under Management:</span>
                  <span className="font-mono font-bold text-slate-100">£{comparisonData.baseline.aum.toFixed(1)}M</span>
                </div>
                <div className="flex justify-between border-b border-slate-850/60 pb-2">
                  <span className="text-slate-400 font-medium">Portfolio NPV Surplus:</span>
                  <span className="font-mono font-bold text-teal-400">£{comparisonData.baseline.npv.toFixed(1)}M</span>
                </div>
                <div className="flex justify-between border-b border-slate-850/60 pb-2">
                  <span className="text-slate-400 font-medium">Weighted Portfolio IRR:</span>
                  <span className="font-mono font-bold text-slate-100">{comparisonData.baseline.irr.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-medium">Annual Free Cash Flow:</span>
                  <span className="font-mono font-bold text-slate-100">£{comparisonData.baseline.cashFlow.toFixed(1)}M / yr</span>
                </div>
              </div>
            </div>

            {/* Stressed / Scenario Card */}
            <div className="bg-slate-950 text-slate-100 rounded border border-teal-500/20 p-5 shadow-lg relative overflow-hidden" id="scenario-stressed-card">
              <span className="text-[10px] font-bold uppercase tracking-widest text-teal-400">Active Scenario State</span>
              <div className="mt-3 space-y-3.5 text-xs">
                <div className="flex justify-between border-b border-slate-850/60 pb-2">
                  <span className="text-slate-400 font-medium">Adjusted AUM Capital:</span>
                  <span className="font-mono font-bold text-slate-100">£{comparisonData.scenario.aum.toFixed(1)}M</span>
                </div>
                <div className="flex justify-between border-b border-slate-850/60 pb-2">
                  <span className="text-slate-400 font-medium">Adjusted NPV Surplus:</span>
                  <span className={`font-mono font-bold ${comparisonData.scenario.npv >= comparisonData.baseline.npv ? 'text-teal-400' : 'text-rose-400'}`}>
                    £{comparisonData.scenario.npv.toFixed(1)}M
                  </span>
                </div>
                <div className="flex justify-between border-b border-slate-850/60 pb-2">
                  <span className="text-slate-400 font-medium">Adjusted Portfolio IRR:</span>
                  <span className="font-mono font-bold text-slate-100">{comparisonData.scenario.irr.toFixed(2)}%</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-medium">Adjusted FCF:</span>
                  <span className="font-mono font-bold text-slate-100">£{comparisonData.scenario.cashFlow.toFixed(1)}M / yr</span>
                </div>
              </div>

              {/* Status flag overlay */}
              {comparisonData.scenario.npv < 0 && (
                <div className="absolute top-2 right-2 bg-rose-500/10 text-rose-400 p-1 rounded border border-rose-500/20" title="Negative portfolio NPV under active stress parameters. Portfolio value destroyed.">
                  <AlertTriangle className="w-3.5 h-3.5" />
                </div>
              )}
            </div>
          </div>

          {/* NPV Delta Sensitivity chart per Asset */}
          <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm" id="resilience-chart-card">
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 mb-4 flex items-center justify-between">
              <span>Project-level NPV Sensitivity (Resilience Monitor)</span>
              <span className="text-[10px] text-slate-500 font-normal">Comparing project NPV under Baseline vs Active Scenario</span>
            </h3>

            <div className="space-y-4" id="resilience-list">
              {comparisonData.assets.map(asset => {
                const baseWidth = Math.max(5, Math.min(100, (asset.baseNPV / 50) * 100));
                const scenWidth = Math.max(5, Math.min(100, (asset.scenNPV / 50) * 100));

                return (
                  <div key={asset.id} className="space-y-1.5 border-b border-slate-850/50 pb-3 last:border-0 last:pb-0">
                    <div className="flex items-center justify-between text-[11px]">
                      <span className="font-semibold text-slate-200 font-serif">{asset.name}</span>
                      <div className="font-mono space-x-3 text-slate-400">
                        <span>Base: £{asset.baseNPV.toFixed(1)}M</span>
                        <span className={asset.scenNPV >= asset.baseNPV ? 'text-teal-400 font-bold' : 'text-rose-400 font-bold'}>
                          Scen: £{asset.scenNPV.toFixed(1)}M
                        </span>
                      </div>
                    </div>

                    {/* Side-by-side micro bars representing the delta */}
                    <div className="space-y-1">
                      {/* Baseline Bar */}
                      <div className="h-2 w-full bg-slate-950 rounded overflow-hidden">
                        <div className="bg-slate-700 h-full" style={{ width: `${baseWidth}%` }}></div>
                      </div>
                      {/* Scenario Bar */}
                      <div className="h-2 w-full bg-slate-950 rounded overflow-hidden">
                        <div className={`h-full ${asset.scenNPV >= asset.baseNPV ? 'bg-teal-500/80' : 'bg-rose-400/80'}`} style={{ width: `${scenWidth}%` }}></div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
