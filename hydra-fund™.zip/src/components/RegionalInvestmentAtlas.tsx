/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { HydrogenAsset, AssetType, ConstructionStatus } from '../types';
import { ASSET_LOCATIONS, REGION_COORDINATES } from '../data/sampleAssets';
import { Map, Pin, Layers, Compass, DollarSign, Activity, Eye, SlidersHorizontal } from 'lucide-react';
import { modelAssetFinance } from '../utils/financeEngine';

interface RegionalInvestmentAtlasProps {
  assets: HydrogenAsset[];
  discountRate: number;
}

export default function RegionalInvestmentAtlas({ assets, discountRate }: RegionalInvestmentAtlasProps) {
  // Map Filters
  const [assetTypeFilter, setAssetTypeFilter] = useState<string>('All');
  const [stageFilter, setStageFilter] = useState<string>('All');
  const [minIRR, setMinIRR] = useState<number>(0);
  const [minCapital, setMinCapital] = useState<number>(0);

  // Selected Pin details overlay
  const [selectedAssetId, setSelectedAssetId] = useState<string | null>(assets[0]?.id || null);

  const activeAsset = useMemo(() => {
    return assets.find(a => a.id === selectedAssetId) || null;
  }, [assets, selectedAssetId]);

  const activeAssetFinance = useMemo(() => {
    if (!activeAsset) return null;
    return modelAssetFinance(activeAsset, discountRate);
  }, [activeAsset, discountRate]);

  // Apply filters to mapped assets
  const filteredAssets = useMemo(() => {
    return assets.filter(asset => {
      const finance = modelAssetFinance(asset, discountRate);
      const matchesType = assetTypeFilter === 'All' || asset.assetType === assetTypeFilter;
      const matchesStage = stageFilter === 'All' || asset.constructionStatus === stageFilter;
      const matchesIRR = (finance.irr * 100) >= minIRR;
      const matchesCap = asset.capitalInvestedM >= minCapital;
      return matchesType && matchesStage && matchesIRR && matchesCap;
    });
  }, [assets, assetTypeFilter, stageFilter, minIRR, minCapital, discountRate]);

  // Aggregate stats per region for heatmap overlays
  const regionalStats = useMemo(() => {
    const stats: Record<string, { count: number; capital: number; mw: number }> = {};
    assets.forEach(asset => {
      const share = asset.ownershipPercentage / 100;
      if (!stats[asset.region]) {
        stats[asset.region] = { count: 0, capital: 0, mw: 0 };
      }
      stats[asset.region].count++;
      stats[asset.region].capital += asset.capitalInvestedM;
      stats[asset.region].mw += asset.capacityMW * share;
    });
    return stats;
  }, [assets]);

  return (
    <div className="space-y-6" id="atlas-container">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-5" id="atlas-header">
        <div>
          <h2 className="text-3xl font-serif text-slate-100 tracking-tight">Regional Investment Atlas</h2>
          <p className="text-sm text-slate-400 mt-1">Spatial allocation maps, strategic energy cluster overlays, and regional capital heatmaps.</p>
        </div>
      </div>

      {/* Main Two Column layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="atlas-grid">
        {/* Interactive UK Map Column (Left) */}
        <div className="lg:col-span-7 bg-slate-950 border border-slate-800 rounded p-5 shadow-2xl relative flex flex-col justify-between overflow-hidden" id="map-visualizer-card">
          <div className="flex items-center justify-between text-slate-400 z-10" id="map-legend-banner">
            <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 flex items-center">
              <Compass className="w-4 h-4 mr-1.5 text-teal-400 animate-spin" style={{ animationDuration: '20s' }} />
              UK Spatial Hydrogen Hubs
            </span>
            <div className="flex items-center space-x-2 text-[9px] font-mono">
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-emerald-400 mr-1 animate-pulse"></span> Operational</span>
              <span className="flex items-center"><span className="w-2 h-2 rounded-full bg-amber-400 mr-1"></span> Const / Design</span>
            </div>
          </div>

          {/* Interactive SVG Great Britain Coastline Map */}
          <div className="flex-1 min-h-[480px] flex items-center justify-center relative mt-4" id="gb-map-canvas">
            {/* Highly stylized Great Britain & Ireland SVG map outline */}
            <svg viewBox="0 0 100 100" className="w-full h-full max-h-[480px] select-none text-slate-800">
              {/* Scotland */}
              <path d="M40 5 L48 5 L43 12 L49 18 L46 25 L35 24 L39 12 Z" className="fill-slate-900/40 hover:fill-slate-900/60 stroke-slate-800/30 stroke-1 transition-colors" />
              {/* Highlands / Islands */}
              <path d="M30 10 L35 5 L37 12 L33 18 Z" className="fill-slate-900/30 hover:fill-slate-900/50 stroke-slate-800/30 stroke-1 transition-colors" />
              {/* Northern Ireland */}
              <path d="M20 40 L28 42 L25 51 L18 48 Z" className="fill-slate-900/20 hover:fill-slate-900/45 stroke-slate-800/30 stroke-1 transition-colors" />
              {/* England & Wales main landmass */}
              <path d="M45 25 L49 18 L51 28 L57 32 L55 45 L50 49 L58 55 L58 68 L69 78 L65 88 L58 88 L52 82 L44 80 L39 76 L44 70 L48 55 L45 42 L42 28 Z" className="fill-slate-900/40 hover:fill-slate-900/60 stroke-slate-800/30 stroke-1 transition-colors" />
              {/* Cornwall tail */}
              <path d="M39 76 L35 84 L28 92 L34 94 L38 90 Z" className="fill-slate-900/40 hover:fill-slate-900/60 stroke-slate-800/30 stroke-1 transition-colors" />

              {/* Regional text heatmaps coordinates */}
              {Object.entries(REGION_COORDINATES).map(([name, coords]) => {
                const regStats = regionalStats[name] || { count: 0, capital: 0 };
                if (regStats.count === 0) return null;
                return (
                  <g key={name} className="opacity-40 hover:opacity-100 transition-all cursor-pointer">
                    <rect x={coords.x - 7} y={coords.y - 4} width="14" height="6" rx="0.5" className="fill-slate-900 stroke-slate-800 stroke-[0.5]" />
                    <text x={coords.x} y={coords.y} className="fill-slate-400 font-mono text-[2.2px] text-center" textAnchor="middle">
                      {name.split(' ')[0]}: £{regStats.capital.toFixed(0)}M
                    </text>
                  </g>
                );
              })}

              {/* Mapped filtered Asset pin markers */}
              {filteredAssets.map(asset => {
                const loc = ASSET_LOCATIONS[asset.id];
                if (!loc) return null;

                const isOperational = asset.constructionStatus === 'Operational';
                const isSelected = asset.id === selectedAssetId;

                return (
                  <g 
                    key={asset.id} 
                    transform={`translate(${loc.x}, ${loc.y})`}
                    onClick={() => setSelectedAssetId(asset.id)}
                    className="cursor-pointer group z-20"
                  >
                    {/* Ring aura */}
                    <circle 
                      cx="0" cy="0" r={isSelected ? "3" : "2"} 
                      className={`${isOperational ? 'fill-teal-400/30 stroke-teal-400' : 'fill-amber-400/30 stroke-amber-400'} stroke-[0.3] animate-pulse`} 
                    />
                    {/* Center Core dot */}
                    <circle 
                      cx="0" cy="0" r={isSelected ? "1.5" : "1"} 
                      className={`${isOperational ? 'fill-teal-400' : 'fill-amber-400'}`} 
                    />
                    
                    {/* Hover tooltip label */}
                    <text 
                      x="0" y="-3.5" 
                      className="fill-slate-200 text-[1.8px] font-sans font-semibold text-center pointer-events-none opacity-0 group-hover:opacity-100 transition-all" 
                      textAnchor="middle"
                    >
                      {asset.name}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>

          <div className="text-[10px] font-mono text-slate-500 border-t border-slate-800/80 pt-4 z-10" id="map-footer">
            Displaying <strong className="text-teal-400">{filteredAssets.length}</strong> qualified hydrogen hubs on GB network grid. Click any node to review detailed financials.
          </div>
        </div>

        {/* Filters and Asset Details Panel Column (Right) */}
        <div className="lg:col-span-5 space-y-6" id="atlas-sidebar">
          {/* Spatial Filters Box */}
          <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm space-y-4" id="spatial-filters-card">
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 flex items-center">
              <SlidersHorizontal className="w-4 h-4 text-teal-400 mr-2" />
              Atlas Search Filters
            </h3>

            <div className="grid grid-cols-2 gap-4 text-xs text-slate-300" id="spatial-filters-grid">
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Asset Category</label>
                <select 
                  value={assetTypeFilter}
                  onChange={(e) => setAssetTypeFilter(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-mono focus:border-teal-400 focus:outline-none"
                >
                  <option value="All">All Types</option>
                  <option value="Green Hydrogen Production">Green Production</option>
                  <option value="Hydrogen Storage Facility">Storage</option>
                  <option value="Pipeline Distribution Network">Pipeline Network</option>
                  <option value="Industrial Blending Plant">Industrial Blending</option>
                  <option value="Heavy Transport Refuelling Station">Refuelling</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Project Stage</label>
                <select 
                  value={stageFilter}
                  onChange={(e) => setStageFilter(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-mono focus:border-teal-400 focus:outline-none"
                >
                  <option value="All">All Stages</option>
                  <option value="Operational">Operational</option>
                  <option value="Under Construction">Under Construction</option>
                  <option value="Detailed Design">Detailed Design</option>
                  <option value="Pre-feasibility">Pre-feasibility</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Min Expected IRR (%)</label>
                <input 
                  type="number" min="0" max="20"
                  value={minIRR}
                  onChange={(e) => setMinIRR(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-mono focus:border-teal-400 focus:outline-none"
                  placeholder="e.g. 5"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Min Capital (£M)</label>
                <input 
                  type="number" min="0" max="150"
                  value={minCapital}
                  onChange={(e) => setMinCapital(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2 text-slate-100 font-mono focus:border-teal-400 focus:outline-none"
                  placeholder="e.g. 20"
                />
              </div>
            </div>
          </div>

          {/* Active selected Node Details Card overlay */}
          {activeAsset && activeAssetFinance ? (
            <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm space-y-4" id="atlas-asset-details-card">
              <div className="border-b border-slate-800 pb-3">
                <span className="text-[10px] font-mono font-bold text-slate-500 uppercase">{activeAsset.id} • {activeAsset.region} Region</span>
                <h4 className="text-base font-serif font-bold text-slate-100 mt-1">{activeAsset.name}</h4>
                <p className="text-xs text-slate-400 mt-0.5">{activeAsset.location}</p>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs" id="details-sub-grid">
                <div>
                  <span className="text-slate-500 font-medium">Asset Type:</span>
                  <p className="font-semibold text-slate-200 mt-0.5 truncate">{activeAsset.assetType}</p>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Stage Status:</span>
                  <p className="font-semibold text-slate-200 mt-0.5">{activeAsset.constructionStatus}</p>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Capital Invested:</span>
                  <p className="font-bold text-slate-100 mt-0.5">£{activeAsset.capitalInvestedM.toFixed(1)}M</p>
                </div>
                <div>
                  <span className="text-slate-500 font-medium">Sovereign Share:</span>
                  <p className="font-semibold text-slate-200 mt-0.5">{activeAsset.ownershipPercentage}% ownership</p>
                </div>
              </div>

              <div className="bg-slate-950 border border-slate-800 rounded-none p-3.5 space-y-2.5 text-xs text-slate-400" id="details-finance-summary">
                <div className="flex justify-between font-mono">
                  <span>Discounted NPV Surplus:</span>
                  <span className={`font-bold ${activeAssetFinance.npv >= 0 ? 'text-teal-400' : 'text-rose-400'}`}>£{activeAssetFinance.npv.toFixed(2)}M</span>
                </div>
                <div className="flex justify-between font-mono">
                  <span>Project IRR on Equity:</span>
                  <span className="font-bold text-slate-200">{(activeAssetFinance.irr * 100).toFixed(2)}%</span>
                </div>
                <div className="flex justify-between font-mono">
                  <span>Carbon intensity:</span>
                  <span className="font-semibold text-emerald-400">{activeAsset.carbonIntensity.toFixed(2)} kg CO2/kg</span>
                </div>
              </div>

              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Responsible Investment Governance Notes</span>
                <p className="text-xs text-slate-400 italic mt-1 leading-relaxed border-l border-teal-500/50 pl-2.5">{activeAsset.responsibleInvestmentNotes}</p>
              </div>
            </div>
          ) : (
            <div className="bg-slate-900/40 border border-slate-800 rounded p-8 shadow-sm text-center text-slate-500">
              <Eye className="w-8 h-8 text-slate-600 mx-auto mb-2" />
              <span>Select any spatial node on the map to review cluster evaluations.</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
