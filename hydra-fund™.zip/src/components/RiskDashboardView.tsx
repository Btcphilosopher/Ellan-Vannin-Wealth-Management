/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useMemo } from 'react';
import { HydrogenAsset } from '../types';
import { modelAssetFinance } from '../utils/financeEngine';
import { ShieldAlert, BarChart3, AlertTriangle, TrendingDown, Layers, HelpCircle } from 'lucide-react';

interface RiskDashboardViewProps {
  assets: HydrogenAsset[];
  discountRate: number;
}

export default function RiskDashboardView({ assets, discountRate }: RiskDashboardViewProps) {
  // Compute risk parameters
  const riskStats = useMemo(() => {
    let totalInvested = 0;
    const regionCapitalMap: Record<string, number> = {};
    const typeCapitalMap: Record<string, number> = {};
    
    // Sensitivities
    let interestRateShockNPV = 0; // +2% rate increase impact on NPV
    let baseNPV = 0;
    
    assets.forEach(asset => {
      totalInvested += asset.capitalInvestedM;
      regionCapitalMap[asset.region] = (regionCapitalMap[asset.region] || 0) + asset.capitalInvestedM;
      typeCapitalMap[asset.assetType] = (typeCapitalMap[asset.assetType] || 0) + asset.capitalInvestedM;
      
      const baseFin = modelAssetFinance(asset, discountRate);
      baseNPV += baseFin.npv;

      // Rate shock NPV (+200bps)
      const shockFin = modelAssetFinance(asset, discountRate, {
        electricityPriceMod: 1.0,
        hydrogenDemandMod: 1.0,
        capexMod: 1.0,
        opexMod: 1.0,
        financingCostMod: 2.0, // +2% financing cost
        inflationMod: 2.0,
        carbonPricingMod: 1.0,
        discountRate: discountRate * 100
      });
      interestRateShockNPV += shockFin.npv;
    });

    // Calculate maximum concentrations
    const maxRegion = Object.entries(regionCapitalMap).reduce((max, [name, val]) => val > max.val ? { name, val } : max, { name: 'None', val: 0 });
    const maxType = Object.entries(typeCapitalMap).reduce((max, [name, val]) => val > max.val ? { name, val } : max, { name: 'None', val: 0 });

    const regionConcentrationPct = totalInvested > 0 ? (maxRegion.val / totalInvested) * 100 : 0;
    const typeConcentrationPct = totalInvested > 0 ? (maxType.val / totalInvested) * 100 : 0;

    // Herfindahl-Hirschman Index (HHI) for diversification
    // HHI < 1500 -> Highly diversified, HHI > 2500 -> Highly concentrated
    let hhiSum = 0;
    Object.values(regionCapitalMap).forEach(v => {
      const share = (v / totalInvested) * 100;
      hhiSum += share * share;
    });

    const diversificationRating = hhiSum < 1800 ? 'Optimal (Diversified)' :
                                  hhiSum < 3000 ? 'Moderate Concentration' : 'High Concentration Risk';

    return {
      totalInvested,
      maxRegionName: maxRegion.name,
      regionConcentrationPct,
      maxTypeName: maxType.name,
      typeConcentrationPct,
      hhi: hhiSum,
      diversificationRating,
      interestRateShockDelta: baseNPV - interestRateShockNPV
    };
  }, [assets, discountRate]);

  return (
    <div className="space-y-6" id="risk-container">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-5" id="risk-header">
        <div>
          <h2 className="text-3xl font-serif text-slate-100 tracking-tight">Risk & Concentration Monitor</h2>
          <p className="text-sm text-slate-400 mt-1">Sovereign portfolio stress analytics, rate shock sensitivities, and concentration ratios.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-5" id="risk-metrics-row">
        {/* Metric 1 */}
        <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm" id="risk-div-card">
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Regional Diversification</span>
          <p className="text-xl font-bold text-slate-100 mt-2">{riskStats.diversificationRating}</p>
          <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
            <span>Herfindahl Index (HHI):</span>
            <span className="font-mono font-bold text-teal-400">{riskStats.hhi.toFixed(0)}</span>
          </div>
          <div className="mt-2 w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
            <div className={`h-full rounded-full ${riskStats.hhi < 1800 ? 'bg-teal-500/80' : 'bg-amber-500/80'}`} style={{ width: `${Math.min(100, (riskStats.hhi / 4000) * 100)}%` }}></div>
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm" id="risk-con-region-card">
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Max Region Concentration</span>
          <p className="text-xl font-bold text-slate-100 mt-2">{riskStats.regionConcentrationPct.toFixed(1)}%</p>
          <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
            <span>Primary Region:</span>
            <span className="font-semibold text-slate-200 truncate max-w-[120px]">{riskStats.maxRegionName}</span>
          </div>
          <div className="mt-2 w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
            <div className={`h-full rounded-full ${riskStats.regionConcentrationPct <= 35 ? 'bg-teal-500/80' : 'bg-rose-500/80'}`} style={{ width: `${riskStats.regionConcentrationPct}%` }}></div>
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm" id="risk-con-type-card">
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Max Asset Type Weight</span>
          <p className="text-xl font-bold text-slate-100 mt-2">{riskStats.typeConcentrationPct.toFixed(1)}%</p>
          <div className="mt-4 flex items-center justify-between text-xs text-slate-400">
            <span>Primary Type:</span>
            <span className="font-semibold text-slate-200 truncate max-w-[120px]">{riskStats.maxTypeName}</span>
          </div>
          <div className="mt-2 w-full bg-slate-950 h-1.5 rounded-full overflow-hidden">
            <div className={`h-full rounded-full ${riskStats.typeConcentrationPct <= 45 ? 'bg-teal-500/80' : 'bg-rose-500/80'}`} style={{ width: `${riskStats.typeConcentrationPct}%` }}></div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="risk-details-grid">
        {/* Left Column - Sensitivities */}
        <div className="lg:col-span-6 bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm space-y-4" id="sensitivity-card">
          <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 flex items-center">
            <ShieldAlert className="w-4 h-4 text-teal-400 mr-2" />
            Macroeconomic Sensitivity & Stress Audits
          </h3>
          <p className="text-xs text-slate-400">Evaluating potential capital impairment under specific credit and market swings.</p>

          <div className="space-y-4 text-xs" id="sensitivity-audits-list">
            {/* Asset-level risk list */}
            <div className="border border-slate-800 rounded p-3.5 space-y-3 bg-slate-950">
              <div className="flex items-center justify-between text-[11px] font-bold text-slate-200 border-b border-slate-800 pb-1.5 uppercase tracking-wider">
                <span>Impairment Vector</span>
                <span>Portfolio Impact</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Interest-Rate Shock (+200bps):</span>
                <span className="font-mono font-bold text-rose-400">-£{riskStats.interestRateShockDelta.toFixed(1)}M NPV reduction</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Electricity Price Surge (+40% inputs):</span>
                <span className="font-mono font-bold text-rose-400">-12.5% Average Production cash flow yield</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Contract Volatility (-20% hydrogen demand):</span>
                <span className="font-mono font-bold text-rose-400">-£4.8M Yearly portfolio liquidity drop</span>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Audit Gating Risk Summary */}
        <div className="lg:col-span-6 bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm space-y-4" id="risk-mitigation-card">
          <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 flex items-center">
            <BarChart3 className="w-4 h-4 text-teal-400 mr-2" />
            Strategic Risk Gating Guidelines
          </h3>
          <p className="text-xs text-slate-400">Investment committee regulatory mandates strictly monitored to avoid asset strandedness.</p>

          <div className="space-y-3 text-xs text-slate-300" id="mitigations-list">
            <div className="flex items-start space-x-2 border-b border-slate-850 pb-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
              <span><strong>Regional Limit:</strong> No single UK region may host more than <strong>35% of total allocated capital</strong> to insulate against local grid constraints. (Current status: <strong className={riskStats.regionConcentrationPct <= 35 ? 'text-teal-400' : 'text-rose-400'}>{riskStats.regionConcentrationPct.toFixed(1)}%</strong>).</span>
            </div>
            <div className="flex items-start space-x-2 border-b border-slate-850 pb-2.5">
              <AlertTriangle className="w-4 h-4 text-amber-500 mt-0.5 flex-shrink-0" />
              <span><strong>Asset Type Limit:</strong> Capital allocated to blending plants or refuelling networks cannot exceed <strong>45% weight</strong> due to higher technical obsolescence risk. (Current status: <strong className={riskStats.typeConcentrationPct <= 45 ? 'text-teal-400' : 'text-rose-400'}>{riskStats.typeConcentrationPct.toFixed(1)}%</strong>).</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
