/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { HydrogenAsset } from '../types';
import { FileText, ShieldAlert, Sparkles, Printer, FileSpreadsheet, Loader2, BookOpen } from 'lucide-react';

interface ReportingSuiteViewProps {
  assets: HydrogenAsset[];
  discountRate: number;
}

export default function ReportingSuiteView({ assets, discountRate }: ReportingSuiteViewProps) {
  const [selectedReportType, setSelectedReportType] = useState<string>('Executive Sovereign Memo');
  const [aiReport, setAiReport] = useState<string>('');
  const [isLoadingAi, setIsLoadingAi] = useState<boolean>(false);

  // Generate standard printable template contents locally
  const reportSummary = React.useMemo(() => {
    const totalCapital = assets.reduce((s, a) => s + a.capitalInvestedM, 0);
    const averageLife = assets.reduce((s, a) => s + a.expectedLifeYears, 0) / (assets.length || 1);
    
    return {
      totalCapital,
      averageLife,
      date: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
      auditor: 'Ellan Vannin Sovereign Governance Committee'
    };
  }, [assets]);

  // Request the server-side Gemini endpoint to generate a custom Sovereign Memo
  const generateAIReport = async () => {
    setIsLoadingAi(true);
    setAiReport('');
    try {
      const response = await fetch('/api/gemini/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          assets: assets.map(a => ({
            name: a.name,
            type: a.assetType,
            capital: a.capitalInvestedM,
            status: a.constructionStatus,
            region: a.region,
            irr: a.operatingCostM // simplified summary metadata passed safely
          })),
          discountRate
        })
      });
      const data = await response.json();
      if (data.report) {
        setAiReport(data.report);
      } else {
        setAiReport("Unable to generate sovereign advisory at this time. Please confirm API key availability in the Secrets dashboard.");
      }
    } catch (e) {
      setAiReport("Server connection timed out. Please check that the backend dev server is fully initialized.");
    } finally {
      setIsLoadingAi(false);
    }
  };

  // Simple HTML export / Local print
  const handlePrint = () => {
    window.print();
  };

  // Export to Excel / CSV simulation
  const exportCSVReport = () => {
    const headers = ['Metric', 'Valuation / Target', 'Sovereign Rating'];
    const rows = [
      ['Total Fund Size Target', '£1,000.00 Million GBP', 'Approved limit'],
      ['Active Capital Allocated', `£${reportSummary.totalCapital.toFixed(1)} Million GBP`, 'Active deployment'],
      ['Target Sovereign WACC', `${(discountRate * 100).toFixed(1)}% discount rate`, 'Approved target'],
      ['Weighted Portfolio Life', `${reportSummary.averageLife.toFixed(1)} Years expected`, 'Resilient buffer']
    ];
    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `Sovereign_Evaluation_Report_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6" id="reporting-suite-container">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-5" id="reporting-header">
        <div>
          <h2 className="text-3xl font-serif text-slate-100 tracking-tight">Reporting Suite</h2>
          <p className="text-sm text-slate-400 mt-1">Audit generation, executive investment memos, and real-time AI analyst reviews.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="reporting-views-grid">
        {/* Report Templates Selection (Left) */}
        <div className="lg:col-span-4 bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm space-y-4" id="report-selector-card">
          <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200">Audit Templates</h3>
          <p className="text-xs text-slate-400">Select standard reporting frameworks compiled directly from the active cash flow database ledger.</p>

          <div className="space-y-2.5" id="templates-selector-list">
            {[
              'Executive Sovereign Memo',
              'Valuation & Yield Audit',
              'Sovereign Risk Sensitivity Analysis',
              'Net-Zero ESG Strategy Report'
            ].map(type => (
              <button
                key={type}
                onClick={() => { setSelectedReportType(type); setAiReport(''); }}
                className={`w-full text-left text-xs font-semibold p-3 rounded border transition-all flex items-center space-x-2.5 ${selectedReportType === type ? 'bg-slate-950 text-teal-400 border-slate-800' : 'bg-slate-900/50 text-slate-300 border-slate-800/60 hover:bg-slate-900'}`}
              >
                <FileText className="w-4 h-4 flex-shrink-0" />
                <span>{type}</span>
              </button>
            ))}
          </div>

          {/* AI Advisor Button section */}
          <div className="border-t border-slate-800 pt-4" id="ai-advisor-activator">
            <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-2">Sovereign AI Copilot</h4>
            <button
              onClick={generateAIReport}
              disabled={isLoadingAi}
              className="w-full bg-teal-500 hover:bg-teal-600 text-slate-950 font-bold text-xs py-2.5 px-4 rounded-sm shadow-md transition-all flex items-center justify-center space-x-2 disabled:opacity-50 cursor-pointer"
              id="btn-trigger-ai"
            >
              {isLoadingAi ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Drafting Memo...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-slate-900" />
                  <span>Sovereign AI Memo Writer</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Dynamic Report Panel View (Right) */}
        <div className="lg:col-span-8 space-y-6" id="report-document-container">
          <div className="bg-slate-900/40 border border-slate-800 rounded overflow-hidden shadow-sm" id="document-card">
            {/* Document Controls Bar */}
            <div className="bg-slate-900/80 border-b border-slate-800 px-6 py-4 flex items-center justify-between" id="document-header-bar">
              <span className="text-xs font-bold uppercase tracking-widest text-slate-200">{selectedReportType}</span>
              <div className="flex items-center space-x-2" id="document-actions">
                <button 
                  onClick={exportCSVReport}
                  className="p-1.5 text-slate-400 hover:text-teal-400 hover:bg-slate-950 rounded cursor-pointer transition-colors" 
                  title="Export Metrics Sheet"
                >
                  <FileSpreadsheet className="w-4 h-4" />
                </button>
                <button 
                  onClick={handlePrint}
                  className="p-1.5 text-slate-400 hover:text-teal-400 hover:bg-slate-950 rounded cursor-pointer transition-colors" 
                  title="Print Portfolio Memo"
                >
                  <Printer className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Document Content */}
            <div className="p-8 prose prose-invert max-w-none text-slate-300 font-serif leading-relaxed" id="document-body">
              {aiReport ? (
                // AI generated report rendered with gorgeous institutional parchment styling
                <div className="bg-slate-950 border border-slate-800 p-6 rounded-none text-xs leading-relaxed space-y-4 shadow-inner" id="parchment-ai-document">
                  <div className="flex items-center space-x-2 text-teal-400 font-sans font-bold border-b border-slate-800 pb-2 mb-2">
                    <Sparkles className="w-4 h-4" />
                    <span>Gemini Sovereign Advisor Memo Drafted Q3 2026</span>
                  </div>
                  <div className="whitespace-pre-line text-slate-300 font-sans leading-relaxed text-xs">
                    {aiReport}
                  </div>
                </div>
              ) : (
                // Standard default template compiled locally
                <div className="space-y-6 text-xs text-slate-300 font-sans" id="parchment-local-document">
                  <div className="text-center space-y-1.5 border-b border-slate-800 pb-6">
                    <h2 className="text-xl font-serif font-bold text-slate-100 uppercase tracking-tight">HYDRA FUND™</h2>
                    <p className="text-[10px] font-mono uppercase tracking-widest text-slate-500">British Hydrogen National Sovereign Fund</p>
                    <p className="text-[10px] font-mono text-slate-400">Date: {reportSummary.date} • Auditor: Tom (tom@ahyx.org)</p>
                  </div>

                  <div className="space-y-4 text-slate-300">
                    <p className="leading-relaxed"><strong>Executive Summary:</strong> The Sovereign Investment Committee for Ellan Vannin Wealth Management has completed its Q3 2026 valuation audit of the HYDRA FUND™ hydrogen infrastructure portfolio. Active allocated capital sits at <strong>£{reportSummary.totalCapital.toFixed(1)}M</strong> representing a diversified basket of {assets.length} production nodes, transport corridors, salt caverns, and blending plants across the United Kingdom.</p>
                    
                    <h3 className="font-serif text-slate-100 font-bold border-b border-slate-800 pb-1 mt-6">Sovereign Financial Summary</h3>
                    <ul className="list-disc list-inside space-y-1 bg-slate-950 border border-slate-800 p-3 rounded-none text-slate-300 font-mono">
                      <li>Consolidated Active Portfolio AUM: £{reportSummary.totalCapital.toFixed(2)}M</li>
                      <li>Estimated Portfolio Lifespan: {reportSummary.averageLife.toFixed(1)} Years</li>
                      <li>Approved Discount Rate (WACC): {(discountRate * 100).toFixed(1)}% per annum</li>
                    </ul>

                    <h3 className="font-serif text-slate-100 font-bold border-b border-slate-800 pb-1 mt-6">Committee Recommendations</h3>
                    <p className="leading-relaxed">The active portfolio exhibits strong performance with robust alignment to net-zero regulatory frameworks. To unlock optimal yield, the committee advises rebalancing capital into storage and marine corridors to lower the correlation of input electricity price shocks.</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
