/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { HydrogenAsset, CapitalAllocationWeights } from '../types';
import { modelAssetFinance, scoreProject } from '../utils/financeEngine';
import { Scale, SlidersHorizontal, Award, Info, HelpCircle } from 'lucide-react';

interface CapitalAllocationViewProps {
  assets: HydrogenAsset[];
  discountRate: number;
}

export default function CapitalAllocationView({ assets, discountRate }: CapitalAllocationViewProps) {
  // Configurable weights for criteria
  const [weights, setWeights] = useState<CapitalAllocationWeights>({
    irrWeight: 30,
    cashFlowWeight: 15,
    capitalEfficiencyWeight: 15,
    riskWeight: 10,
    technologyMaturityWeight: 10,
    diversificationWeight: 5,
    regionalStrategyWeight: 5,
    esgWeight: 20
  });

  // Calculate scores and sort by rank
  const scoredAssets = useMemo(() => {
    return assets.map(asset => {
      const finance = modelAssetFinance(asset, discountRate);
      const scoreData = scoreProject(asset, finance, weights);
      return {
        asset,
        finance,
        score: scoreData.score,
        details: scoreData.details
      };
    }).sort((a, b) => b.score - a.score);
  }, [assets, discountRate, weights]);

  // Handle a weight slider change
  const handleWeightChange = (key: keyof CapitalAllocationWeights, val: number) => {
    setWeights(prev => ({
      ...prev,
      [key]: val
    }));
  };

  // Quick reset to balanced weighting
  const resetWeights = (preset: 'balanced' | 'aggressive' | 'esg' | 'conservative') => {
    switch (preset) {
      case 'balanced':
        setWeights({
          irrWeight: 20,
          cashFlowWeight: 15,
          capitalEfficiencyWeight: 15,
          riskWeight: 15,
          technologyMaturityWeight: 10,
          diversificationWeight: 10,
          regionalStrategyWeight: 5,
          esgWeight: 10
        });
        break;
      case 'aggressive':
        setWeights({
          irrWeight: 45,
          cashFlowWeight: 20,
          capitalEfficiencyWeight: 20,
          riskWeight: 5,
          technologyMaturityWeight: 5,
          diversificationWeight: 5,
          regionalStrategyWeight: 0,
          esgWeight: 0
        });
        break;
      case 'esg':
        setWeights({
          irrWeight: 10,
          cashFlowWeight: 10,
          capitalEfficiencyWeight: 10,
          riskWeight: 10,
          technologyMaturityWeight: 10,
          diversificationWeight: 10,
          regionalStrategyWeight: 10,
          esgWeight: 50
        });
        break;
      case 'conservative':
        setWeights({
          irrWeight: 15,
          cashFlowWeight: 15,
          capitalEfficiencyWeight: 15,
          riskWeight: 35,
          technologyMaturityWeight: 10,
          diversificationWeight: 5,
          regionalStrategyWeight: 5,
          esgWeight: 5
        });
        break;
    }
  };

  return (
    <div className="space-y-6" id="capital-allocation-container">
      {/* Module Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-5" id="allocation-header">
        <div>
          <h2 className="text-3xl font-serif text-slate-100 tracking-tight">Capital Allocation Engine</h2>
          <p className="text-sm text-slate-400 mt-1">Sovereign scorecards, multi-criteria asset ranking, and strategic gating criteria.</p>
        </div>
        
        {/* Preset quick weights buttons */}
        <div className="mt-4 md:mt-0 flex items-center space-x-2" id="presets-container">
          <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Score Presets:</span>
          <button 
            onClick={() => resetWeights('balanced')}
            className="bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 font-semibold text-[10px] px-2.5 py-1.5 rounded shadow-xs"
          >
            Balanced
          </button>
          <button 
            onClick={() => resetWeights('aggressive')}
            className="bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 font-semibold text-[10px] px-2.5 py-1.5 rounded shadow-xs"
          >
            IRR-Focused
          </button>
          <button 
            onClick={() => resetWeights('esg')}
            className="bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 font-semibold text-[10px] px-2.5 py-1.5 rounded shadow-xs"
          >
            ESG-Focused
          </button>
          <button 
            onClick={() => resetWeights('conservative')}
            className="bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 font-semibold text-[10px] px-2.5 py-1.5 rounded shadow-xs"
          >
            Risk-Averse
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="allocation-grid">
        {/* Sliders Configuration Sidebar (Left) */}
        <div className="lg:col-span-4 bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm space-y-5" id="sliders-card">
          <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 flex items-center">
            <SlidersHorizontal className="w-4 h-4 text-teal-400 mr-2" />
            Strategic Allocation Weights
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">Modify relative scoring parameters to adjust how the Investment Committee prioritises carbon reduction vs financial return.</p>

          <div className="space-y-4" id="sliders-list">
            {/* Slide 1 */}
            <div>
              <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                <span className="font-semibold">Financial Return (Expected IRR)</span>
                <span className="font-mono font-bold text-teal-400 bg-slate-950 border border-slate-800 px-1.5 py-0.5 rounded">{weights.irrWeight}%</span>
              </div>
              <input 
                type="range" min="0" max="100" step="5"
                value={weights.irrWeight}
                onChange={(e) => handleWeightChange('irrWeight', Number(e.target.value))}
                className="w-full accent-teal-400"
              />
            </div>

            {/* Slide 2 */}
            <div>
              <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                <span className="font-semibold">Cash Flow Volume Forecast</span>
                <span className="font-mono font-bold text-teal-400 bg-slate-950 border border-slate-800 px-1.5 py-0.5 rounded">{weights.cashFlowWeight}%</span>
              </div>
              <input 
                type="range" min="0" max="100" step="5"
                value={weights.cashFlowWeight}
                onChange={(e) => handleWeightChange('cashFlowWeight', Number(e.target.value))}
                className="w-full accent-teal-400"
              />
            </div>

            {/* Slide 3 */}
            <div>
              <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                <span className="font-semibold">Capital Efficiency (PI Index)</span>
                <span className="font-mono font-bold text-teal-400 bg-slate-950 border border-slate-800 px-1.5 py-0.5 rounded">{weights.capitalEfficiencyWeight}%</span>
              </div>
              <input 
                type="range" min="0" max="100" step="5"
                value={weights.capitalEfficiencyWeight}
                onChange={(e) => handleWeightChange('capitalEfficiencyWeight', Number(e.target.value))}
                className="w-full accent-teal-400"
              />
            </div>

            {/* Slide 4 */}
            <div>
              <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                <span className="font-semibold">Risk Mitigation (Construction/Sovereign)</span>
                <span className="font-mono font-bold text-teal-400 bg-slate-950 border border-slate-800 px-1.5 py-0.5 rounded">{weights.riskWeight}%</span>
              </div>
              <input 
                type="range" min="0" max="100" step="5"
                value={weights.riskWeight}
                onChange={(e) => handleWeightChange('riskWeight', Number(e.target.value))}
                className="w-full accent-teal-400"
              />
            </div>

            {/* Slide 5 */}
            <div>
              <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                <span className="font-semibold">Responsible ESG & Low Carbon Impact</span>
                <span className="font-mono font-bold text-teal-400 bg-slate-950 border border-slate-800 px-1.5 py-0.5 rounded">{weights.esgWeight}%</span>
              </div>
              <input 
                type="range" min="0" max="100" step="5"
                value={weights.esgWeight}
                onChange={(e) => handleWeightChange('esgWeight', Number(e.target.value))}
                className="w-full accent-teal-400"
              />
            </div>

            {/* Slide 6 */}
            <div>
              <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                <span className="font-semibold">Technology Maturity Rating</span>
                <span className="font-mono font-bold text-teal-400 bg-slate-950 border border-slate-800 px-1.5 py-0.5 rounded">{weights.technologyMaturityWeight}%</span>
              </div>
              <input 
                type="range" min="0" max="100" step="5"
                value={weights.technologyMaturityWeight}
                onChange={(e) => handleWeightChange('technologyMaturityWeight', Number(e.target.value))}
                className="w-full accent-teal-400"
              />
            </div>
          </div>
        </div>

        {/* Scoring Grid & Ranking (Right) */}
        <div className="lg:col-span-8 space-y-6" id="allocations-table-wrapper">
          <div className="bg-slate-900/20 border border-slate-800 overflow-hidden shadow-sm" id="scores-table-card">
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs text-slate-300" id="allocation-scoring-table">
                <thead>
                  <tr className="bg-slate-900/60 border-b border-slate-800 text-[10px] uppercase font-bold tracking-widest text-slate-400">
                    <th className="py-3.5 px-4 text-center">Rank</th>
                    <th className="py-3.5 px-4">Project</th>
                    <th className="py-3.5 px-4">Asset Type</th>
                    <th className="py-3.5 px-4 text-center">Score (Max 10)</th>
                    <th className="py-3.5 px-4 text-center">Strategic Grade</th>
                    <th className="py-3.5 px-4">Score Component Breakdown</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {scoredAssets.map((item, index) => {
                    const rank = index + 1;
                    
                    // Award colors for top 3
                    const rankColors: Record<number, string> = {
                      1: 'bg-amber-500/10 text-amber-300 border-amber-500/20 font-bold',
                      2: 'bg-slate-800 text-slate-300 border-slate-700 font-bold',
                      3: 'bg-orange-500/10 text-orange-300 border-orange-500/20 font-bold'
                    };

                    const scoreGrade = item.score >= 8.5 ? 'Strong Gated Buy' :
                                       item.score >= 7.0 ? 'Qualified Buy' :
                                       item.score >= 5.0 ? 'Hold / Monitor' : 'Strategic Reject';

                    const gradeColors: Record<string, string> = {
                      'Strong Gated Buy': 'bg-emerald-500/10 text-emerald-300 border-emerald-500/20',
                      'Qualified Buy': 'bg-sky-500/10 text-sky-300 border-sky-500/20',
                      'Hold / Monitor': 'bg-amber-500/10 text-amber-300 border-amber-500/20',
                      'Strategic Reject': 'bg-rose-500/10 text-rose-300 border-rose-500/20'
                    };

                    return (
                      <tr key={item.asset.id} className="hover:bg-slate-900/40 transition-colors">
                        <td className="py-3.5 px-4 text-center">
                          <span className={`inline-flex items-center justify-center w-6 h-6 rounded-full text-xs border ${rankColors[rank] || 'bg-slate-950 text-slate-400 border-slate-800 font-medium'}`}>
                            {rank}
                          </span>
                        </td>
                        <td className="py-3.5 px-4">
                          <span className="font-semibold text-slate-100 block">{item.asset.name}</span>
                          <span className="text-[10px] text-slate-400 font-mono mt-0.5">{item.asset.id} • {item.asset.region}</span>
                        </td>
                        <td className="py-3.5 px-4 max-w-[140px] truncate text-slate-400">{item.asset.assetType}</td>
                        <td className="py-3.5 px-4 text-center">
                          <span className="font-mono font-bold text-slate-100 text-sm">{item.score.toFixed(2)}</span>
                        </td>
                        <td className="py-3.5 px-4 text-center">
                          <span className={`inline-flex px-2 py-0.5 text-[9px] font-bold border ${gradeColors[scoreGrade]}`}>
                            {scoreGrade}
                          </span>
                        </td>
                        <td className="py-3.5 px-4">
                          {/* Mini visual segment breakdown of the 10 components */}
                          <div className="flex h-2 w-32 rounded-full overflow-hidden bg-slate-950" title={`IRR: ${item.details.irr}, ESG: ${item.details.esg}, Risk: ${item.details.constructionRisk}`}>
                            <div className="bg-teal-500" style={{ width: `${item.details.irr * 10}%` }}></div>
                            <div className="bg-emerald-400" style={{ width: `${item.details.esg * 10}%` }}></div>
                            <div className="bg-amber-500" style={{ width: `${item.details.constructionRisk * 10}%` }}></div>
                            <div className="bg-indigo-400" style={{ width: `${item.details.technologyMaturity * 10}%` }}></div>
                          </div>
                          <span className="text-[9px] text-slate-500 font-mono mt-1 block">IRR/ESG/Risk/Tech</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div className="bg-slate-900/50 border-t border-slate-800 p-4 text-[10px] text-slate-400 flex items-start gap-2.5" id="allocation-policy-note">
              <Info className="w-4 h-4 text-teal-400 flex-shrink-0 mt-0.5" />
              <span>
                <strong>Gating Logic:</strong> Sovereign guidelines state projects must achieve a Strategic Score of <strong>&gt;7.00</strong> to qualify for direct capital injection from the British Hydrogen National Fund. Lower scoring projects can undergo alternative co-investment structures.
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
