/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { HydrogenAsset } from '../types';
import { modelAssetFinance } from '../utils/financeEngine';
import { Sliders, DollarSign, Percent, Calendar, ShieldCheck, Scale, BarChart2 } from 'lucide-react';

interface FinanceEngineViewProps {
  assets: HydrogenAsset[];
  discountRate: number;
  onDiscountRateChange: (rate: number) => void;
}

export default function FinanceEngineView({ assets, discountRate, onDiscountRateChange }: FinanceEngineViewProps) {
  const [selectedAssetId, setSelectedAssetId] = useState<string>(assets[0]?.id || '');

  // Retrieve current active asset
  const activeAsset = useMemo(() => {
    return assets.find(a => a.id === selectedAssetId) || assets[0];
  }, [assets, selectedAssetId]);

  // Model active asset financials
  const financials = useMemo(() => {
    if (!activeAsset) return null;
    return modelAssetFinance(activeAsset, discountRate);
  }, [activeAsset, discountRate]);

  // Create detailed 25-year projection table
  const annualSchedule = useMemo(() => {
    if (!activeAsset || !financials) return [];
    
    const schedule = [];
    let cumulative = -activeAsset.capitalInvestedM * (1 - 0.45); // initial equity investment

    for (let t = 1; t <= activeAsset.expectedLifeYears; t++) {
      // Re-run year-by-year cash flow details
      const inflationMultiplier = Math.pow(1 + 0.02, t); // default base 2% inflation
      const annualRevenue = activeAsset.annualRevenueM * (activeAsset.ownershipPercentage / 100) * inflationMultiplier;
      const annualOpex = activeAsset.operatingCostM * (activeAsset.ownershipPercentage / 100) * inflationMultiplier;
      const maintenanceCost = (activeAsset.capitalInvestedM * 0.015) * (1 + 0.01 * t) * (activeAsset.ownershipPercentage / 100) * inflationMultiplier;
      
      const debtCapital = activeAsset.capitalInvestedM * 0.45;
      const costOfDebt = 0.055;
      const annualDebtService = debtCapital > 0 
        ? (debtCapital * costOfDebt * Math.pow(1 + costOfDebt, activeAsset.expectedLifeYears)) / (Math.pow(1 + costOfDebt, activeAsset.expectedLifeYears) - 1)
        : 0;

      const fcf = annualRevenue - annualOpex - maintenanceCost - annualDebtService;
      const discountFactor = 1 / Math.pow(1 + discountRate, t);
      const dcf = fcf * discountFactor;
      cumulative += fcf;

      schedule.push({
        year: t,
        revenue: annualRevenue,
        opex: annualOpex,
        maintenance: maintenanceCost,
        debtService: annualDebtService,
        fcf,
        discountFactor,
        dcf,
        cumulative
      });
    }

    return schedule;
  }, [activeAsset, financials, discountRate]);

  return (
    <div className="space-y-6" id="finance-engine-container">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-5" id="finance-header">
        <div>
          <h2 className="text-3xl font-serif text-slate-100 tracking-tight">Project Finance Engine</h2>
          <p className="text-sm text-slate-400 mt-1">Granular DCF financial modeler, NPV calculator, and project cash flow scheduler.</p>
        </div>
        
        {/* Project Selector dropdown */}
        <div className="mt-4 md:mt-0 flex flex-col sm:flex-row sm:items-center gap-3">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold uppercase tracking-widest text-slate-500">Project:</span>
            <select 
              value={selectedAssetId}
              onChange={(e) => setSelectedAssetId(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded text-xs font-semibold px-3 py-2 focus:outline-none focus:ring-1 focus:ring-teal-500 text-slate-100 shadow-sm font-mono"
              id="asset-selector-dropdown"
            >
              {assets.map(a => (
                <option key={a.id} value={a.id}>{a.id} - {a.name}</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {activeAsset && financials ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="finance-views-grid">
          {/* Controls & Metrics Sidebar */}
          <div className="lg:col-span-4 space-y-6" id="finance-sidebar">
            {/* Configurable Discount Rate Assumptions Card */}
            <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm" id="discount-rate-config-card">
              <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 mb-4 flex items-center">
                <Sliders className="w-4 h-4 text-teal-400 mr-2" />
                Financial Assumptions
              </h3>
              
              <div className="space-y-4" id="discount-rate-slider-group">
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-300 mb-1.5">
                    <span>Target Sovereign Discount Rate (WACC)</span>
                    <span className="font-mono font-bold text-teal-400 text-sm bg-slate-950 px-2 py-0.5 rounded border border-slate-800">{(discountRate * 100).toFixed(1)}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="2" 
                    max="15" 
                    step="0.5"
                    value={discountRate * 100}
                    onChange={(e) => onDiscountRateChange(Number(e.target.value) / 100)}
                    className="w-full accent-teal-400"
                  />
                  <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono mt-1">
                    <span>2.0% (Risk Free)</span>
                    <span>15.0% (Speculative)</span>
                  </div>
                </div>

                <div className="border-t border-slate-800 pt-4 space-y-2.5 text-xs text-slate-400">
                  <div className="flex items-center justify-between">
                    <span>Leverage Debt Financing:</span>
                    <span className="font-mono text-slate-300">45% debt ratio</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Subsidized Debt Cost:</span>
                    <span className="font-mono text-slate-300">5.5% (fixed nominee)</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Annual Maintenance:</span>
                    <span className="font-mono text-slate-300">1.5% of cap invested</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Structured Financial Evaluation Badges */}
            <div className="bg-slate-950 border border-slate-800 rounded-none p-5 shadow-lg space-y-4" id="project-financial-metrics-card">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Net Present Value (NPV)</span>
                <p className={`text-3xl font-serif font-bold mt-1 ${financials.npv >= 0 ? 'text-teal-400' : 'text-rose-400'}`}>
                  £{financials.npv.toFixed(2)}M
                </p>
                <p className="text-[10px] text-slate-500 mt-1">NPV represents cumulative present value of equity flows minus upfront equity cash. (Hurdle: &gt; 0)</p>
              </div>

              <div className="border-t border-slate-800 pt-4">
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Internal Rate of Return (IRR)</span>
                <p className="text-2xl font-bold mt-1 text-slate-100">
                  {(financials.irr * 100).toFixed(2)}%
                </p>
                <p className="text-[10px] text-slate-500 mt-1">Sovereign IRR on equity allocation. Target hurdle is {(discountRate*100).toFixed(1)}%.</p>
              </div>

              <div className="border-t border-slate-800 pt-4 grid grid-cols-2 gap-4 text-left">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Equity Payback</span>
                  <p className="text-lg font-bold text-slate-100 mt-0.5">
                    {financials.paybackPeriod.toFixed(1)} Yrs
                  </p>
                </div>
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Profitability Index</span>
                  <p className="text-lg font-bold text-slate-100 mt-0.5">
                    {financials.profitabilityIndex.toFixed(2)}x
                  </p>
                </div>
              </div>

              <div className="border-t border-slate-800 pt-4 text-xs">
                <div className="flex items-center justify-between text-slate-500">
                  <span>Avg Return on Invested Capital:</span>
                  <span className="font-mono font-bold text-slate-300">{financials.roic.toFixed(1)}%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Granular Schedule & Graph Tab panel (Right) */}
          <div className="lg:col-span-8 space-y-6" id="finance-main-views">
            {/* Interactive Waterfall Visualization */}
            <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm" id="waterfall-card">
              <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 mb-4 flex items-center">
                <BarChart2 className="w-4 h-4 text-teal-400 mr-2" />
                Project Cumulative Cash Flow Timeline (Payback Visualisation)
              </h3>
              
              <div className="h-44 flex items-end justify-between px-2 pt-6 relative" id="cumulative-cashflow-graph">
                {/* Horizontal reference line representing zero point break even */}
                <div className="absolute inset-x-0 bottom-1/3 border-b border-rose-900/60 h-0 w-full pointer-events-none text-[8px] font-mono text-rose-400 text-left pl-1">Equity Invested: -£{(activeAsset.capitalInvestedM * 0.55).toFixed(1)}M (Zero Point)</div>
                <div className="absolute inset-0 flex flex-col justify-between pointer-events-none pb-6 pt-2">
                  <div className="border-b border-dashed border-slate-800/40 w-full text-[8px] font-mono text-slate-500 text-right pr-1">Break Even</div>
                </div>

                {annualSchedule.filter(y => y.year % 2 === 0 || y.year === 1 || y.year === activeAsset.expectedLifeYears).map((d, idx) => {
                  // Normalize height mapping between negative equity investment and max return
                  const maxVal = annualSchedule[annualSchedule.length - 1]?.cumulative || 100;
                  const minVal = -activeAsset.capitalInvestedM * 0.55;
                  const spread = maxVal - minVal;
                  
                  // Position relative to height of graph container
                  const heightPct = ((d.cumulative - minVal) / spread) * 100;
                  
                  return (
                    <div key={idx} className="flex flex-col items-center flex-1 group z-10 mx-1">
                      <div className="opacity-0 group-hover:opacity-100 transition-all absolute -top-1 bg-slate-950 border border-slate-800 text-slate-100 text-[9px] font-mono py-1 px-1.5 rounded-none shadow pointer-events-none mb-1">
                        £{d.cumulative.toFixed(1)}M
                      </div>
                      <div 
                        className={`w-full ${d.cumulative >= 0 ? 'bg-teal-500/80' : 'bg-slate-700/80'} group-hover:bg-teal-400 transition-all rounded-t-xs`}
                        style={{ height: `${heightPct}%` }}
                      ></div>
                      <span className="text-[9px] font-mono text-slate-500 mt-2.5">Yr {d.year}</span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Granite 25-Year Ledger Spreadsheet Grid */}
            <div className="bg-slate-900/20 border border-slate-800 overflow-hidden shadow-sm" id="ledger-table-card">
              <div className="bg-slate-900/80 border-b border-slate-800 px-5 py-3.5 flex items-center justify-between">
                <span className="text-xs font-bold uppercase tracking-widest text-slate-200">DCF Ledgers & Projections</span>
                <span className="text-[10px] font-mono text-slate-400">Asset Life: {activeAsset.expectedLifeYears} Years</span>
              </div>
              <div className="overflow-x-auto max-h-72" id="ledger-scroll-box">
                <table className="w-full text-left border-collapse text-[11px]" id="dcf-ledger-table">
                  <thead>
                    <tr className="bg-slate-900/90 border-b border-slate-800 font-bold text-slate-400 uppercase select-none sticky top-0 z-10 tracking-wider">
                      <th className="py-2.5 px-3 bg-slate-900">Year</th>
                      <th className="py-2.5 px-3 bg-slate-900 text-right">Revenue</th>
                      <th className="py-2.5 px-3 bg-slate-900 text-right">Opex</th>
                      <th className="py-2.5 px-3 bg-slate-900 text-right">Maintenance</th>
                      <th className="py-2.5 px-3 bg-slate-900 text-right">Debt Service</th>
                      <th className="py-2.5 px-3 bg-slate-900 text-right font-semibold text-slate-200">Free Cash Flow</th>
                      <th className="py-2.5 px-3 bg-slate-900 text-right">Discount Factor</th>
                      <th className="py-2.5 px-3 bg-slate-900 text-right font-semibold text-teal-400">Discounted CF</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-slate-300 font-mono">
                    {annualSchedule.map(row => (
                      <tr key={row.year} className="hover:bg-slate-900/40 transition-colors">
                        <td className="py-2 px-3 font-semibold text-slate-100">Yr {row.year}</td>
                        <td className="py-2 px-3 text-right text-slate-400">£{row.revenue.toFixed(2)}M</td>
                        <td className="py-2 px-3 text-right text-slate-400">-£{row.opex.toFixed(2)}M</td>
                        <td className="py-2 px-3 text-right text-slate-400">-£{row.maintenance.toFixed(2)}M</td>
                        <td className="py-2 px-3 text-right text-slate-400">-£{row.debtService.toFixed(2)}M</td>
                        <td className="py-2 px-3 text-right font-bold text-slate-100 bg-slate-950">£{row.fcf.toFixed(2)}M</td>
                        <td className="py-2 px-3 text-right text-slate-500">{row.discountFactor.toFixed(4)}</td>
                        <td className="py-2 px-3 text-right font-bold text-teal-400 bg-teal-500/5">£{row.dcf.toFixed(2)}M</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              
              <div className="bg-slate-900/80 border-t border-slate-800 px-5 py-3 text-[10px] text-slate-400 flex items-center justify-between" id="ledger-summary-bar">
                <span className="flex items-center">
                  <ShieldCheck className="w-3.5 h-3.5 text-teal-400 mr-1" />
                  Calculations comply with standard UK sovereign green finance accounting guidelines.
                </span>
                <span className="font-semibold text-teal-400">Sum DCF: £{financials.freeCashFlows.reduce((sum, fcf, i) => sum + fcf / Math.pow(1 + discountRate, i + 1), 0).toFixed(2)}M</span>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="py-20 text-center text-slate-400">Loading portfolio holdings...</div>
      )}
    </div>
  );
}
