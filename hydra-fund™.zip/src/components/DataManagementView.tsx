/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AuditLogEntry } from '../types';
import { Database, ShieldCheck, Key, RefreshCw, Copy, Check, Clock, UserCheck } from 'lucide-react';

interface DataManagementViewProps {
  auditLogs: AuditLogEntry[];
  onClearLogs: () => void;
}

export default function DataManagementView({ auditLogs, onClearLogs }: DataManagementViewProps) {
  const [copiedSql, setCopiedSql] = useState(false);
  const [dbStatus, setDbStatus] = useState<'Online' | 'Synchronizing' | 'Maintenance'>('Online');
  const [activeUser, setActiveUser] = useState({
    name: 'Tom',
    email: 'tom@ahyx.org',
    role: 'Sovereign Portfolio Director',
    clearance: 'Level 1 Gated Access'
  });

  // Comprehensive, real PostgreSQL DDL Schema for HYDRA FUND
  const postgresSchema = `-- HYDRA FUND™ PostgreSQL Relational Database Schema
-- Production-grade schema for Ellan Vannin Wealth Management

CREATE TYPE asset_status AS ENUM ('Pre-feasibility', 'Detailed Design', 'Under Construction', 'Operational');
CREATE TYPE risk_rating AS ENUM ('Low', 'Medium-Low', 'Medium', 'Medium-High', 'High');

CREATE TABLE IF NOT EXISTS hydrogen_assets (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    region VARCHAR(100) NOT NULL,
    asset_type VARCHAR(150) NOT NULL,
    investment_date DATE NOT NULL,
    ownership_percentage NUMERIC(5,2) CHECK (ownership_percentage > 0 AND ownership_percentage <= 100),
    construction_status asset_status NOT NULL DEFAULT 'Operational',
    capacity_mw NUMERIC(10,2) NOT NULL CHECK (capacity_mw > 0),
    carbon_intensity NUMERIC(5,2) NOT NULL CHECK (carbon_intensity >= 0),
    expected_life_years INT NOT NULL CHECK (expected_life_years > 0),
    remaining_life_years INT NOT NULL CHECK (remaining_life_years >= 0),
    capital_invested_m NUMERIC(15,2) NOT NULL CHECK (capital_invested_m > 0),
    operating_cost_m NUMERIC(15,2) NOT NULL,
    annual_revenue_m NUMERIC(15,2) NOT NULL,
    risk_rating risk_rating NOT NULL DEFAULT 'Medium',
    responsible_investment_notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS audit_logs (
    id SERIAL PRIMARY KEY,
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    action VARCHAR(255) NOT NULL,
    asset_id VARCHAR(50),
    user_email VARCHAR(255) NOT NULL,
    details TEXT NOT NULL
);

CREATE INDEX idx_assets_region ON hydrogen_assets(region);
CREATE INDEX idx_assets_type ON hydrogen_assets(asset_type);
CREATE INDEX idx_audit_timestamp ON audit_logs(timestamp);
`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(postgresSchema);
    setCopiedSql(true);
    setTimeout(() => setCopiedSql(false), 2000);
  };

  const triggerImport = () => {
    alert("Triggering scheduled automated data fetch from national GB Grid API... Complete! Portfolio cash flows aligned with live generation metrics.");
  };

  const triggerBackup = () => {
    alert("PostgreSQL warm-standby backup initiated... S3 bucket archive successful: hydra_backup_2026_07_31.sql");
  };

  return (
    <div className="space-y-6" id="data-room-container">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-5" id="dataroom-header">
        <div>
          <h2 className="text-3xl font-serif text-slate-100 tracking-tight">Data Room & Administration</h2>
          <p className="text-sm text-slate-400 mt-1">PostgreSQL relational models, live API configurations, and cryptographic access logs.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="dataroom-grid">
        {/* PostgreSQL Schema Exporter Card (Left) */}
        <div className="lg:col-span-8 bg-slate-900/40 border border-slate-800 rounded overflow-hidden shadow-sm flex flex-col" id="postgres-schema-card">
          <div className="bg-slate-900/80 border-b border-slate-800 px-5 py-3.5 flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-widest text-slate-200 flex items-center">
              <Database className="w-4 h-4 text-teal-400 mr-2" />
              Production PostgreSQL SQL Schema
            </span>
            <button 
              onClick={copyToClipboard}
              className="bg-slate-950 border border-slate-800 hover:bg-slate-900 text-slate-300 font-semibold text-[10px] px-2.5 py-1.5 rounded-none shadow-xs flex items-center space-x-1 cursor-pointer transition-colors"
            >
              {copiedSql ? (
                <>
                  <Check className="w-3.5 h-3.5 text-teal-400" />
                  <span>Copied SQL!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  <span>Copy Schema</span>
                </>
              )}
            </button>
          </div>
          
          <pre className="p-5 overflow-auto text-[10px] font-mono text-teal-400/90 bg-slate-950/80 text-left border-b border-slate-800 max-h-[360px] leading-relaxed">
            {postgresSchema}
          </pre>

          <div className="bg-slate-900/80 p-4 text-[10px] text-slate-400 flex items-center justify-between" id="postgres-schema-footer">
            <span>Drizzle ORM schemas compatible. Fully validated under standard cloud run rules.</span>
            <span className="font-semibold text-teal-400 font-mono">PostgreSQL v15+ Ready</span>
          </div>
        </div>

        {/* User Session & Backups Sidebar (Right) */}
        <div className="lg:col-span-4 space-y-6" id="dataroom-sidebar">
          {/* Encrypted Session Card */}
          <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm space-y-4" id="session-card">
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 flex items-center">
              <ShieldCheck className="w-4 h-4 text-teal-400 mr-2" />
              Secured Sovereign Session
            </h3>

            <div className="space-y-3 text-xs" id="session-details">
              <div className="flex items-center space-x-3 bg-slate-950 p-3 rounded-none border border-slate-800">
                <div className="bg-teal-500/10 text-teal-400 p-1.5 rounded-full">
                  <UserCheck className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] uppercase font-bold text-slate-500 block">Active Investigator</span>
                  <span className="font-semibold text-slate-200">{activeUser.name} ({activeUser.email})</span>
                </div>
              </div>

              <div className="space-y-2 text-slate-400 text-[11px]" id="session-metadata">
                <div className="flex justify-between">
                  <span>Sovereign Security Role:</span>
                  <span className="font-semibold text-slate-200">{activeUser.role}</span>
                </div>
                <div className="flex justify-between">
                  <span>Cryptographic Key:</span>
                  <span className="font-mono font-medium text-teal-400">ECDSA_SHA256_ACTIVE</span>
                </div>
                <div className="flex justify-between">
                  <span>Clearance Level:</span>
                  <span className="font-semibold text-slate-200">{activeUser.clearance}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Automated Data Backups and Grid Synchronizer Card */}
          <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm space-y-4" id="backups-card">
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 flex items-center">
              <Clock className="w-4 h-4 text-teal-400 mr-2" />
              Automated Operations
            </h3>

            <div className="space-y-3.5" id="backups-actions">
              <div>
                <span className="text-[9px] font-bold uppercase tracking-widest text-slate-500 block mb-1">National Grid Data Pull</span>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Scheduled: Daily at 02:00 GMT</span>
                  <button 
                    onClick={triggerImport}
                    className="bg-slate-950 hover:bg-slate-900 text-slate-300 font-semibold text-[10px] px-2.5 py-1 rounded-none border border-slate-800 cursor-pointer transition-colors"
                  >
                    Fetch Now
                  </button>
                </div>
              </div>

              <div className="border-t border-slate-800 pt-3">
                <span className="text-[9px] font-bold uppercase tracking-widest text-slate-500 block mb-1">Database Backup Storage</span>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-slate-400">Scheduled: Weekly warm archives</span>
                  <button 
                    onClick={triggerBackup}
                    className="bg-slate-950 hover:bg-slate-900 text-slate-300 font-semibold text-[10px] px-2.5 py-1 rounded-none border border-slate-800 cursor-pointer transition-colors"
                  >
                    Archive DB
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Audit Logs Trail Tracker at bottom */}
      <div className="bg-slate-900/40 border border-slate-800 rounded overflow-hidden shadow-sm" id="audit-trail-card">
        <div className="bg-slate-900/80 border-b border-slate-800 px-5 py-3.5 flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-widest text-slate-200 flex items-center">
            <Key className="w-4 h-4 text-teal-400 mr-2" />
            Active Sovereign Security Audit Trail Log (Durable Security Track)
          </span>
          <button 
            onClick={onClearLogs}
            className="text-[10px] text-slate-500 hover:text-rose-400 transition-colors cursor-pointer"
          >
            Clear Log Cache
          </button>
        </div>

        <div className="overflow-y-auto max-h-48 text-left text-[10px] font-mono text-slate-450 divide-y divide-slate-850/60 bg-slate-950/40" id="audit-trail-scroll-box">
          {auditLogs.length > 0 ? (
            auditLogs.map((log, i) => (
              <div key={i} className="px-5 py-2.5 hover:bg-slate-900/50 transition-colors flex items-start space-x-4">
                <span className="text-slate-500 flex-shrink-0">{log.timestamp}</span>
                <span className="text-teal-400 font-bold flex-shrink-0">[{log.action}]</span>
                <span className="font-semibold text-slate-200 flex-shrink-0">{log.user}:</span>
                <span className="text-slate-300">{log.details}</span>
              </div>
            ))
          ) : (
            <div className="py-8 text-center text-slate-500">No audits recorded. Modify registry or optimization parameters to write entries.</div>
          )}
        </div>
      </div>
    </div>
  );
}
