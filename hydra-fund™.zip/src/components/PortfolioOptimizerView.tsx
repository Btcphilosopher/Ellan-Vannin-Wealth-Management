/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { HydrogenAsset } from '../types';
import { generateEfficientFrontier, modelAssetFinance } from '../utils/financeEngine';
import { Scale, Sliders, ArrowRight, ShieldAlert, CheckCircle2 } from 'lucide-react';

interface PortfolioOptimizerViewProps {
  assets: HydrogenAsset[];
  discountRate: number;
}

export default function PortfolioOptimizerView({ assets, discountRate }: PortfolioOptimizerViewProps) {
  // Optimization constraints state
  const [maxRegionalWeight, setMaxRegionalWeight] = useState<number>(35); // 35% cap
  const [maxAssetTypeWeight, setMaxAssetTypeWeight] = useState<number>(45); // 45% cap
  const [targetIRR, setTargetIRR] = useState<number>(8.0); // 8% target IRR

  // Run Optimizer on inputs
  const optimizationResults = useMemo(() => {
    return generateEfficientFrontier(assets, discountRate, {
      maxRegionalWeight: maxRegionalWeight / 100,
      maxAssetTypeWeight: maxAssetTypeWeight / 100,
      targetIRR: targetIRR
    });
  }, [assets, discountRate, maxRegionalWeight, maxAssetTypeWeight, targetIRR]);

  // Current weight distribution
  const currentWeights = useMemo(() => {
    const totalCapital = assets.reduce((sum, a) => sum + a.capitalInvestedM, 0);
    const weights: Record<string, number> = {};
    assets.forEach(a => {
      weights[a.id] = Number(((a.capitalInvestedM / totalCapital) * 100).toFixed(1));
    });
    return weights;
  }, [assets]);

  // Current consolidated return & risk proxies for mapping on graph
  const currentPortfolioStats = useMemo(() => {
    let returnSum = 0;
    let riskSum = 0;
    assets.forEach(a => {
      const fin = modelAssetFinance(a, discountRate);
      const w = currentWeights[a.id] / 100;
      returnSum += w * fin.irr;
      
      const stdev = a.riskRating === 'Low' ? 0.05 :
                    a.riskRating === 'Medium-Low' ? 0.08 :
                    a.riskRating === 'Medium' ? 0.12 :
                    a.riskRating === 'Medium-High' ? 0.16 : 0.22;
      riskSum += w * stdev;
    });

    return {
      returnPct: Number((returnSum * 100).toFixed(2)),
      riskPct: Number((riskSum * 100).toFixed(2))
    };
  }, [assets, currentWeights, discountRate]);

  return (
    <div className="space-y-6" id="optimizer-container">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-5" id="optimizer-header">
        <div>
          <h2 className="text-3xl font-serif text-slate-100 tracking-tight">Sovereign Portfolio Optimizer</h2>
          <p className="text-sm text-slate-400 mt-1">Mean-variance efficient frontiers, rebalancing algorithms, and concentration guardrails.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="optimizer-views-grid">
        {/* Constraints Sidebar (Left) */}
        <div className="lg:col-span-4 space-y-6" id="optimizer-sidebar">
          {/* Portfolio Target Constraints Setup */}
          <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm space-y-5" id="constraints-card">
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 flex items-center">
              <Sliders className="w-4 h-4 text-teal-400 mr-2" />
              Sovereign Mandate Constraints
            </h3>

            <div className="space-y-4" id="constraints-sliders">
              {/* Target 1 */}
              <div>
                <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                  <span>Target Portfolio IRR (Min Return)</span>
                  <span className="font-mono font-bold text-teal-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">{targetIRR.toFixed(1)}%</span>
                </div>
                <input 
                  type="range" min="4" max="12" step="0.5"
                  value={targetIRR}
                  onChange={(e) => setTargetIRR(Number(e.target.value))}
                  className="w-full accent-teal-400"
                />
              </div>

              {/* Target 2 */}
              <div>
                <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                  <span>Max Single-Region Concentration Cap</span>
                  <span className="font-mono font-bold text-teal-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">{maxRegionalWeight}%</span>
                </div>
                <input 
                  type="range" min="15" max="60" step="5"
                  value={maxRegionalWeight}
                  onChange={(e) => setMaxRegionalWeight(Number(e.target.value))}
                  className="w-full accent-teal-400"
                />
              </div>

              {/* Target 3 */}
              <div>
                <div className="flex items-center justify-between text-xs text-slate-300 mb-1">
                  <span>Max Asset-Type Concentration Cap</span>
                  <span className="font-mono font-bold text-teal-400 bg-slate-950 px-1.5 py-0.5 rounded border border-slate-800">{maxAssetTypeWeight}%</span>
                </div>
                <input 
                  type="range" min="20" max="80" step="5"
                  value={maxAssetTypeWeight}
                  onChange={(e) => setMaxAssetTypeWeight(Number(e.target.value))}
                  className="w-full accent-teal-400"
                />
              </div>
            </div>
          </div>

          {/* Allocation Rebalancing Action Recommendations card */}
          <div className="bg-slate-950 border border-slate-800 rounded-none p-5 shadow-lg space-y-4" id="optimized-outcome-summary">
            <div>
              <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Optimization Goal Match</span>
              <div className="flex items-center space-x-2 mt-1">
                <CheckCircle2 className="w-5 h-5 text-teal-400" />
                <span className="text-sm font-semibold">Constraints Satisfied</span>
              </div>
              <p className="text-[10px] text-slate-500 mt-1">Sovereign bounds verified against UK National Hydrogen Strategy targets.</p>
            </div>

            <div className="border-t border-slate-800 pt-4 grid grid-cols-2 gap-4">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Recommended Return</span>
                <p className="text-lg font-bold text-teal-400 mt-0.5">
                  {optimizationResults.recommended.returnPct}%
                </p>
              </div>
              <div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Target Risk Limit</span>
                <p className="text-lg font-bold text-slate-200 mt-0.5">
                  {optimizationResults.recommended.riskPct}%
                </p>
              </div>
            </div>

            <div className="border-t border-slate-800 pt-4 text-xs text-slate-400 leading-relaxed">
              <strong>Optimization Summary:</strong> By shifting focus toward storage hubs and marine corridors, we can lock in a higher weighted return of <strong>{optimizationResults.recommended.returnPct}%</strong> (versus {currentPortfolioStats.returnPct}% currently) while actually decreasing overall portfolio risk from <strong>{currentPortfolioStats.riskPct}%</strong> to <strong>{optimizationResults.recommended.riskPct}%</strong>.
            </div>
          </div>
        </div>

        {/* Graphical frontier & Comparison Tables (Right) */}
        <div className="lg:col-span-8 space-y-6" id="optimizer-main-view">
          {/* Efficient Frontier Curve Graph */}
          <div className="bg-slate-900/40 border border-slate-800 rounded p-5 shadow-sm" id="efficient-frontier-card">
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-200 mb-4">
              Mean-Variance Efficient Frontier Curve
            </h3>

            {/* Pure SVG plotting Return % vs Volatility % */}
            <div className="h-56 relative border-l border-b border-slate-800 flex items-end justify-between px-6 pb-6 pt-2" id="frontier-svg-chart">
              {/* Axes labels */}
              <div className="absolute left-1.5 top-0 text-[8px] font-mono font-semibold text-slate-500 uppercase rotate-90 transform origin-left">Expected Portfolio Return (%)</div>
              <div className="absolute right-2 bottom-1.5 text-[8px] font-mono font-semibold text-slate-500 uppercase">Portfolio Risk / Volatility (%)</div>

              <svg className="absolute inset-0 w-full h-full p-6 overflow-visible" viewBox="0 0 100 100" preserveAspectRatio="none">
                {/* Efficient frontier line */}
                <path 
                  d={optimizationResults.frontier.reduce((acc, pt, i) => {
                    // Map Return (4% - 12%) and Risk (5% - 20%) to 0-100 coordinates
                    // Return map: X-axis is Risk (5 to 15), Y-axis is Return (5 to 11)
                    const x = ((pt.riskPct - 4) / 11) * 100;
                    const y = 100 - ((pt.returnPct - 4) / 8) * 100;
                    return acc + `${i === 0 ? 'M' : 'L'} ${x} ${y}`;
                  }, '')}
                  fill="none"
                  className="stroke-teal-500/50 stroke-2"
                  strokeDasharray="1 1"
                />

                {/* Plot individual frontier dot nodes */}
                {optimizationResults.frontier.map((pt, i) => {
                  const x = ((pt.riskPct - 4) / 11) * 100;
                  const y = 100 - ((pt.returnPct - 4) / 8) * 100;
                  return (
                    <circle key={i} cx={x} cy={y} r="2" fill="#0d9488" />
                  );
                })}

                {/* Plot CURRENT portfolio point (Red Dot) */}
                {(() => {
                  const x = ((currentPortfolioStats.riskPct - 4) / 11) * 100;
                  const y = 100 - ((currentPortfolioStats.returnPct - 4) / 8) * 100;
                  return (
                    <g key="current-node">
                      <circle cx={x} cy={y} r="5" fill="#f43f5e" className="animate-ping opacity-60" />
                      <circle cx={x} cy={y} r="4.5" fill="#f43f5e" />
                    </g>
                  );
                })()}

                {/* Plot RECOMMENDED optimized portfolio point (Emerald Dot) */}
                {(() => {
                  const x = ((optimizationResults.recommended.riskPct - 4) / 11) * 100;
                  const y = 100 - ((optimizationResults.recommended.returnPct - 4) / 8) * 100;
                  return (
                    <g key="recommended-node">
                      <circle cx={x} cy={y} r="6" fill="#14b8a6" className="animate-pulse" />
                      <circle cx={x} cy={y} r="4" fill="#14b8a6" />
                    </g>
                  );
                })()}
              </svg>

              {/* Absolute Legend overlay */}
              <div className="absolute top-4 right-4 bg-slate-950/90 border border-slate-800 p-2.5 rounded-none shadow-xs space-y-1 text-[9px] font-mono">
                <div className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 bg-[#f43f5e] rounded-full"></span>
                  <span className="text-slate-300 font-medium">Current Allocation ({currentPortfolioStats.returnPct}%)</span>
                </div>
                <div className="flex items-center space-x-1.5">
                  <span className="w-2.5 h-2.5 bg-[#14b8a6] rounded-full"></span>
                  <span className="text-slate-300 font-medium">Recommended Frontier ({optimizationResults.recommended.returnPct}%)</span>
                </div>
              </div>
            </div>
          </div>

          {/* Allocation Breakdown Comparison Table */}
          <div className="bg-slate-900/20 border border-slate-800 rounded overflow-hidden shadow-sm" id="comparison-table-card">
            <div className="bg-slate-900/80 border-b border-slate-800 px-5 py-3.5 flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-widest text-slate-200">Rebalancing Allocation Schedule</span>
              <span className="text-[10px] font-mono text-slate-400">Fund Rebalancing Movements</span>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs text-slate-300" id="rebalance-comparison-table">
                <thead>
                  <tr className="bg-slate-900/60 border-b border-slate-800 text-[10px] uppercase font-bold tracking-widest text-slate-400">
                    <th className="py-3.5 px-4">Project ID</th>
                    <th className="py-3.5 px-4">Project Name</th>
                    <th className="py-3.5 px-4 text-right">Current Weight</th>
                    <th className="py-3.5 px-4 text-right text-teal-400">Optimised Weight</th>
                    <th className="py-3.5 px-4 text-center">Movement</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 font-mono">
                  {assets.map(asset => {
                    const curW = currentWeights[asset.id] || 0;
                    const optW = optimizationResults.recommended.weights[asset.id] || 0;
                    const diff = optW - curW;
                    
                    let movement = 'No Change';
                    let moveColor = 'text-slate-500 bg-slate-950';
                    
                    if (diff > 1.5) {
                      movement = `Accumulate (+${diff.toFixed(1)}%)`;
                      moveColor = 'text-emerald-400 bg-emerald-500/10 border border-emerald-500/20';
                    } else if (diff < -1.5) {
                      movement = `Divest (${diff.toFixed(1)}%)`;
                      moveColor = 'text-rose-400 bg-rose-500/10 border border-rose-500/20';
                    }

                    return (
                      <tr key={asset.id} className="hover:bg-slate-900/40 transition-colors">
                        <td className="py-2.5 px-4 font-semibold text-slate-500">{asset.id}</td>
                        <td className="py-2.5 px-4 font-sans font-semibold text-slate-100">{asset.name}</td>
                        <td className="py-2.5 px-4 text-right text-slate-400">{curW.toFixed(1)}%</td>
                        <td className="py-2.5 px-4 text-right font-bold text-teal-400 bg-teal-500/5">{optW.toFixed(1)}%</td>
                        <td className="py-2.5 px-4 text-center">
                          <span className={`inline-flex px-2.5 py-0.5 rounded-sm text-[9px] font-bold ${moveColor}`}>
                            {movement}
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
