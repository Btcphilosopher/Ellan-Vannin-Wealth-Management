/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { HydrogenAsset, AssetType, ConstructionStatus, RiskRating } from '../types';
import { Plus, Search, FileDown, Upload, Edit3, Trash2, SlidersHorizontal, Check, X, Info } from 'lucide-react';

interface AssetRegisterProps {
  assets: HydrogenAsset[];
  onAddAsset: (asset: HydrogenAsset) => void;
  onUpdateAsset: (asset: HydrogenAsset) => void;
  onDeleteAsset: (id: string) => void;
}

export default function AssetRegister({ assets, onAddAsset, onUpdateAsset, onDeleteAsset }: AssetRegisterProps) {
  // Filtering & Sorting State
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('All');
  const [filterStatus, setFilterStatus] = useState<string>('All');
  const [sortBy, setSortBy] = useState<keyof HydrogenAsset>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');

  // Form Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<HydrogenAsset | null>(null);

  // Form Fields
  const [formName, setFormName] = useState('');
  const [formLocation, setFormLocation] = useState('');
  const [formRegion, setFormRegion] = useState('Scotland');
  const [formAssetType, setFormAssetType] = useState<AssetType>('Green Hydrogen Production');
  const [formInvestmentDate, setFormInvestmentDate] = useState('');
  const [formOwnership, setFormOwnership] = useState(100);
  const [formStatus, setFormStatus] = useState<ConstructionStatus>('Operational');
  const [formCapacity, setFormCapacity] = useState(10);
  const [formCarbon, setFormCarbon] = useState(0.2);
  const [formExpectedLife, setFormExpectedLife] = useState(25);
  const [formRemainingLife, setFormRemainingLife] = useState(25);
  const [formCapital, setFormCapital] = useState(20);
  const [formOpex, setFormOpex] = useState(1.5);
  const [formRevenue, setFormRevenue] = useState(5.0);
  const [formRisk, setFormRisk] = useState<RiskRating>('Medium');
  const [formNotes, setFormNotes] = useState('');

  // Handle opening form for adding
  const openAddModal = () => {
    setEditingAsset(null);
    setFormName('');
    setFormLocation('');
    setFormRegion('Scotland');
    setFormAssetType('Green Hydrogen Production');
    setFormInvestmentDate(new Date().toISOString().split('T')[0]);
    setFormOwnership(100);
    setFormStatus('Operational');
    setFormCapacity(15);
    setFormCarbon(0.25);
    setFormExpectedLife(25);
    setFormRemainingLife(25);
    setFormCapital(30.0);
    setFormOpex(1.8);
    setFormRevenue(6.2);
    setFormRisk('Medium');
    setFormNotes('');
    setIsModalOpen(true);
  };

  // Handle opening form for editing
  const openEditModal = (asset: HydrogenAsset) => {
    setEditingAsset(asset);
    setFormName(asset.name);
    setFormLocation(asset.location);
    setFormRegion(asset.region);
    setFormAssetType(asset.assetType);
    setFormInvestmentDate(asset.investmentDate);
    setFormOwnership(asset.ownershipPercentage);
    setFormStatus(asset.constructionStatus);
    setFormCapacity(asset.capacityMW);
    setFormCarbon(asset.carbonIntensity);
    setFormExpectedLife(asset.expectedLifeYears);
    setFormRemainingLife(asset.remainingLifeYears);
    setFormCapital(asset.capitalInvestedM);
    setFormOpex(asset.operatingCostM);
    setFormRevenue(asset.annualRevenueM);
    setFormRisk(asset.riskRating);
    setFormNotes(asset.responsibleInvestmentNotes);
    setIsModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    const assetData: HydrogenAsset = {
      id: editingAsset ? editingAsset.id : `HYD-${Math.floor(100 + Math.random() * 900)}`,
      name: formName || 'Unnamed Asset',
      location: formLocation || 'UK Regional Facility',
      region: formRegion,
      assetType: formAssetType,
      investmentDate: formInvestmentDate,
      ownershipPercentage: Number(formOwnership),
      constructionStatus: formStatus,
      capacityMW: Number(formCapacity),
      carbonIntensity: Number(formCarbon),
      expectedLifeYears: Number(formExpectedLife),
      remainingLifeYears: Number(formRemainingLife),
      capitalInvestedM: Number(formCapital),
      operatingCostM: Number(formOpex),
      annualRevenueM: Number(formRevenue),
      riskRating: formRisk,
      responsibleInvestmentNotes: formNotes || 'Standard project governance active.'
    };

    if (editingAsset) {
      onUpdateAsset(assetData);
    } else {
      onAddAsset(assetData);
    }
    setIsModalOpen(false);
  };

  // Sorting helper
  const handleSort = (field: keyof HydrogenAsset) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('asc');
    }
  };

  // Export CSV Functionality
  const exportToCSV = () => {
    const headers = [
      'ID', 'Project Name', 'Location', 'Region', 'Asset Type', 'Investment Date',
      'Ownership %', 'Construction Status', 'Capacity MW', 'Carbon Intensity (kg CO2e)',
      'Expected Life', 'Remaining Life', 'Capital Invested (£M)', 'Operating Cost (£M)',
      'Annual Revenue (£M)', 'Risk Rating', 'ESG/Responsible Notes'
    ];

    const rows = assets.map(a => [
      a.id,
      `"${a.name.replace(/"/g, '""')}"`,
      `"${a.location.replace(/"/g, '""')}"`,
      a.region,
      a.assetType,
      a.investmentDate,
      a.ownershipPercentage,
      a.constructionStatus,
      a.capacityMW,
      a.carbonIntensity,
      a.expectedLifeYears,
      a.remainingLifeYears,
      a.capitalInvestedM,
      a.operatingCostM,
      a.annualRevenueM,
      a.riskRating,
      `"${a.responsibleInvestmentNotes.replace(/"/g, '""')}"`
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(','), ...rows.map(e => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `HYDRA_FUND_Registry_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // CSV Import Simulation Handler
  const handleCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (!text) return;

      const lines = text.split('\n');
      if (lines.length <= 1) return;

      // Parse some rows simply (avoid heavy parsing libraries to ensure zero dependency failure)
      for (let i = 1; i < lines.length; i++) {
        const line = lines[i].trim();
        if (!line) continue;

        // Splitting by comma, accounting for possible quotes around notes or names
        // Simple regex splitter
        const parts = line.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
        if (parts.length >= 15) {
          const clean = (s: string) => (s || '').replace(/^"|"$/g, '').trim();
          
          const importedAsset: HydrogenAsset = {
            id: `HYD-${Math.floor(100 + Math.random() * 900)}`,
            name: clean(parts[1]) || 'Imported Asset',
            location: clean(parts[2]) || 'UK Location',
            region: clean(parts[3]) || 'Scotland',
            assetType: (clean(parts[4]) as AssetType) || 'Green Hydrogen Production',
            investmentDate: clean(parts[5]) || '2026-01-01',
            ownershipPercentage: Number(clean(parts[6])) || 100,
            constructionStatus: (clean(parts[7]) as ConstructionStatus) || 'Operational',
            capacityMW: Number(clean(parts[8])) || 10,
            carbonIntensity: Number(clean(parts[9])) || 0.25,
            expectedLifeYears: Number(clean(parts[10])) || 25,
            remainingLifeYears: Number(clean(parts[11])) || 25,
            capitalInvestedM: Number(clean(parts[12])) || 20.0,
            operatingCostM: Number(clean(parts[13])) || 1.5,
            annualRevenueM: Number(clean(parts[14])) || 5.0,
            riskRating: (clean(parts[15]) as RiskRating) || 'Medium',
            responsibleInvestmentNotes: clean(parts[16]) || 'Imported project entry.'
          };
          onAddAsset(importedAsset);
        }
      }
      alert("CSV import parsed successfully! New records added to cache.");
    };
    reader.readAsText(file);
  };

  // Filtered Assets list
  const filteredAssets = useMemo(() => {
    return assets
      .filter(asset => {
        const matchesSearch = asset.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                              asset.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
                              asset.id.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesType = filterType === 'All' || asset.assetType === filterType;
        const matchesStatus = filterStatus === 'All' || asset.constructionStatus === filterStatus;
        return matchesSearch && matchesType && matchesStatus;
      })
      .sort((a, b) => {
        let valA = a[sortBy];
        let valB = b[sortBy];

        if (typeof valA === 'string' && typeof valB === 'string') {
          return sortOrder === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
        } else {
          const numA = valA as number;
          const numB = valB as number;
          return sortOrder === 'asc' ? numA - numB : numB - numA;
        }
      });
  }, [assets, searchTerm, filterType, filterStatus, sortBy, sortOrder]);

  return (
    <div className="space-y-6" id="asset-register-container">
      {/* Module Title and Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-5" id="asset-header">
        <div>
          <h2 className="text-3xl font-serif text-slate-100 tracking-tight">Hydrogen Asset Register</h2>
          <p className="text-sm text-slate-400 mt-1">Sovereign registry database holding structured metadata for all hydrogen holdings.</p>
        </div>
        <div className="mt-4 md:mt-0 flex items-center space-x-3" id="asset-action-buttons">
          <label className="flex items-center space-x-2 bg-slate-900 border border-slate-800 hover:bg-slate-800 cursor-pointer text-slate-300 font-semibold text-xs px-3.5 py-2 rounded shadow-sm transition-all" id="btn-import-csv">
            <Upload className="w-3.5 h-3.5 text-teal-400" />
            <span>Import CSV</span>
            <input type="file" accept=".csv" onChange={handleCSVUpload} className="hidden" />
          </label>
          <button 
            onClick={exportToCSV}
            className="flex items-center space-x-2 bg-slate-900 border border-slate-800 hover:bg-slate-800 text-slate-300 font-semibold text-xs px-3.5 py-2 rounded shadow-sm transition-all"
            id="btn-export-csv"
          >
            <FileDown className="w-3.5 h-3.5 text-teal-400" />
            <span>Export Registry</span>
          </button>
          <button 
            onClick={openAddModal}
            className="flex items-center space-x-2 bg-teal-600 hover:bg-teal-500 text-white font-semibold text-xs px-4 py-2 rounded shadow-sm transition-all"
            id="btn-add-asset"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Asset</span>
          </button>
        </div>
      </div>

      {/* Grid Filtering Tool Bar */}
      <div className="bg-slate-900/40 border border-slate-800 rounded p-4 flex flex-col md:flex-row items-center gap-4 shadow-sm" id="registry-toolbar">
        <div className="relative flex-1 w-full" id="search-input-wrapper">
          <Search className="absolute left-3.5 top-2.5 text-slate-500 w-4 h-4" />
          <input 
            type="text" 
            placeholder="Search assets by name, code or location..." 
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded pl-10 pr-4 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-teal-500 text-slate-100 placeholder-slate-500"
            id="search-input-field"
          />
        </div>

        <div className="flex flex-wrap items-center gap-4 w-full md:w-auto" id="filters-wrapper">
          {/* Asset Type Filter */}
          <div className="flex items-center space-x-2" id="filter-type-box">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Type:</span>
            <select 
              value={filterType} 
              onChange={(e) => setFilterType(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded text-xs px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-teal-500 text-slate-300 font-medium"
            >
              <option value="All">All Types</option>
              <option value="Green Hydrogen Production">Green Production</option>
              <option value="Hydrogen Storage Facility">Storage</option>
              <option value="Pipeline Distribution Network">Pipeline Network</option>
              <option value="Industrial Blending Plant">Industrial Blending</option>
              <option value="Heavy Transport Refuelling Station">Refuelling</option>
            </select>
          </div>

          {/* Construction Status Filter */}
          <div className="flex items-center space-x-2" id="filter-status-box">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Stage:</span>
            <select 
              value={filterStatus} 
              onChange={(e) => setFilterStatus(e.target.value)}
              className="bg-slate-950 border border-slate-800 rounded text-xs px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-teal-500 text-slate-300 font-medium"
            >
              <option value="All">All Stages</option>
              <option value="Operational">Operational</option>
              <option value="Under Construction">Under Construction</option>
              <option value="Detailed Design">Detailed Design</option>
              <option value="Pre-feasibility">Pre-feasibility</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Table Grid Container */}
      <div className="bg-slate-900/20 border border-slate-800 overflow-hidden shadow-sm" id="registry-table-card">
        <div className="overflow-x-auto" id="table-scroll-container">
          <table className="w-full text-left border-collapse" id="asset-registry-table">
            <thead>
              <tr className="bg-slate-900/60 border-b border-slate-800 text-[10px] uppercase font-bold tracking-widest text-slate-400 select-none">
                <th className="py-3 px-4 cursor-pointer hover:bg-slate-800/40" onClick={() => handleSort('id')}>ID</th>
                <th className="py-3 px-4 cursor-pointer hover:bg-slate-800/40" onClick={() => handleSort('name')}>Project Name</th>
                <th className="py-3 px-4 cursor-pointer hover:bg-slate-800/40" onClick={() => handleSort('assetType')}>Type</th>
                <th className="py-3 px-4 cursor-pointer hover:bg-slate-800/40" onClick={() => handleSort('region')}>Region</th>
                <th className="py-3 px-4 cursor-pointer hover:bg-slate-800/40 text-right" onClick={() => handleSort('capitalInvestedM')}>Capital Invested</th>
                <th className="py-3 px-4 cursor-pointer hover:bg-slate-800/40 text-right" onClick={() => handleSort('ownershipPercentage')}>Ownership</th>
                <th className="py-3 px-4 cursor-pointer hover:bg-slate-800/40" onClick={() => handleSort('constructionStatus')}>Stage</th>
                <th className="py-3 px-4 cursor-pointer hover:bg-slate-800/40" onClick={() => handleSort('riskRating')}>Risk</th>
                <th className="py-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300" id="table-body">
              {filteredAssets.length > 0 ? (
                filteredAssets.map((asset) => {
                  // Style modifiers for badges
                  const riskColors: Record<string, string> = {
                    'Low': 'bg-teal-500/10 text-teal-300 border-teal-500/20',
                    'Medium-Low': 'bg-teal-500/10 text-teal-400 border-teal-500/20',
                    'Medium': 'bg-amber-500/10 text-amber-300 border-amber-500/20',
                    'Medium-High': 'bg-amber-50/70 text-amber-400 border-amber-500/20',
                    'High': 'bg-rose-500/10 text-rose-300 border-rose-500/20'
                  };

                  const stageColors: Record<string, string> = {
                    'Operational': 'bg-teal-500/10 text-teal-300 border-teal-500/20',
                    'Under Construction': 'bg-amber-500/10 text-amber-300 border-amber-500/20',
                    'Detailed Design': 'bg-slate-800 text-slate-300 border-slate-700',
                    'Pre-feasibility': 'bg-indigo-500/10 text-indigo-300 border-indigo-500/20'
                  };

                  return (
                    <tr key={asset.id} className="hover:bg-slate-900/40 transition-colors">
                      <td className="py-3 px-4 font-mono font-medium text-slate-500">{asset.id}</td>
                      <td className="py-3 px-4">
                        <span className="font-semibold text-slate-100 block">{asset.name}</span>
                        <span className="text-[10px] text-slate-400 block mt-0.5">{asset.location}</span>
                      </td>
                      <td className="py-3 px-4 max-w-[150px] truncate text-slate-400">{asset.assetType}</td>
                      <td className="py-3 px-4 text-slate-400">{asset.region}</td>
                      <td className="py-3 px-4 text-right font-mono font-medium text-slate-100">£{asset.capitalInvestedM.toFixed(1)}M</td>
                      <td className="py-3 px-4 text-right font-mono text-slate-400">{asset.ownershipPercentage}%</td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex px-2 py-0.5 text-[10px] font-medium rounded-full border ${stageColors[asset.constructionStatus] || 'bg-slate-800'}`}>
                          {asset.constructionStatus}
                        </span>
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex px-2 py-0.5 text-[10px] font-medium rounded-full border ${riskColors[asset.riskRating] || 'bg-slate-800'}`}>
                          {asset.riskRating}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <div className="flex items-center justify-center space-x-2">
                          <button 
                            onClick={() => openEditModal(asset)}
                            className="p-1 text-slate-500 hover:text-teal-400 hover:bg-slate-800 rounded transition-all"
                            title="Edit Asset Properties"
                          >
                            <Edit3 className="w-3.5 h-3.5" />
                          </button>
                          <button 
                            onClick={() => {
                              if (confirm(`Confirm deletion of ${asset.name}?`)) {
                                onDeleteAsset(asset.id);
                              }
                            }}
                            className="p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-950/40 rounded transition-all"
                            title="Delete Asset Entry"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500">
                    <Info className="w-8 h-8 text-slate-600 mx-auto mb-2" />
                    No assets matched the active search filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        
        {/* Table Footer Stats */}
        <div className="bg-slate-900/50 border-t border-slate-800 p-3.5 flex items-center justify-between text-xs text-slate-400" id="table-summary-bar">
          <span>Displaying <strong className="text-slate-200">{filteredAssets.length}</strong> of {assets.length} institutional assets.</span>
          <span className="font-mono">Total Capital in selection: £{filteredAssets.reduce((s, a) => s + a.capitalInvestedM, 0).toFixed(1)}M</span>
        </div>
      </div>

      {/* Edit / Add Asset Slide-over or Modal Popup */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-xs p-4" id="asset-form-modal">
          <div className="bg-slate-900 border border-slate-800 w-full max-w-2xl max-h-[90vh] flex flex-col shadow-2xl rounded-none">
            {/* Modal Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
              <h2 className="font-serif text-lg font-bold text-slate-100">
                {editingAsset ? `Edit Asset Entry: ${editingAsset.id}` : 'Create New Infrastructure Asset'}
              </h2>
              <button 
                onClick={() => setIsModalOpen(false)}
                className="p-1 text-slate-500 hover:text-slate-200 hover:bg-slate-800 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Modal Form Scroll Area */}
            <form onSubmit={handleSave} className="flex-1 overflow-y-auto p-6 space-y-4 text-xs text-slate-300">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Field 1 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Project Name</label>
                  <input 
                    type="text" 
                    required
                    value={formName}
                    onChange={(e) => setFormName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                    placeholder="e.g. Grangemouth Electrolyser Node"
                  />
                </div>

                {/* Field 2 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Asset Location</label>
                  <input 
                    type="text" 
                    required
                    value={formLocation}
                    onChange={(e) => setFormLocation(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                    placeholder="e.g. Grangemouth, Scotland"
                  />
                </div>

                {/* Field 3 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Asset Type</label>
                  <select 
                    value={formAssetType}
                    onChange={(e) => setFormAssetType(e.target.value as AssetType)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    <option value="Green Hydrogen Production">Green Hydrogen Production</option>
                    <option value="Hydrogen Storage Facility">Hydrogen Storage Facility</option>
                    <option value="Pipeline Distribution Network">Pipeline Distribution Network</option>
                    <option value="Industrial Blending Plant">Industrial Blending Plant</option>
                    <option value="Heavy Transport Refuelling Station">Heavy Transport Refuelling Station</option>
                  </select>
                </div>

                {/* Field 4 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Strategic Region</label>
                  <select 
                    value={formRegion}
                    onChange={(e) => setFormRegion(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    <option value="Scotland">Scotland</option>
                    <option value="North East">North East</option>
                    <option value="North West">North West</option>
                    <option value="Yorkshire & Humber">Yorkshire & Humber</option>
                    <option value="Wales">Wales</option>
                    <option value="East Midlands">East Midlands</option>
                    <option value="West Midlands">West Midlands</option>
                    <option value="East of England">East of England</option>
                    <option value="London">London</option>
                    <option value="South East">South East</option>
                    <option value="South West">South West</option>
                    <option value="Northern Ireland">Northern Ireland</option>
                  </select>
                </div>

                {/* Financial 1 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Capital Invested (£ Millions)</label>
                  <input 
                    type="number" 
                    step="0.1" 
                    required
                    value={formCapital}
                    onChange={(e) => setFormCapital(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                {/* Financial 2 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Annual Operating Cost (£M/yr)</label>
                  <input 
                    type="number" 
                    step="0.1" 
                    required
                    value={formOpex}
                    onChange={(e) => setFormOpex(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                {/* Financial 3 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Annual Projected Revenue (£M/yr)</label>
                  <input 
                    type="number" 
                    step="0.1" 
                    required
                    value={formRevenue}
                    onChange={(e) => setFormRevenue(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                {/* Financial 4 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Ownership Percentage (%)</label>
                  <input 
                    type="number" 
                    min="1" 
                    max="100" 
                    required
                    value={formOwnership}
                    onChange={(e) => setFormOwnership(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                {/* Technical 1 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Capacity Equivalent (MW)</label>
                  <input 
                    type="number" 
                    required
                    value={formCapacity}
                    onChange={(e) => setFormCapacity(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                {/* Technical 2 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Carbon Intensity (kg CO2e / kg H2)</label>
                  <input 
                    type="number" 
                    step="0.01" 
                    required
                    value={formCarbon}
                    onChange={(e) => setFormCarbon(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                {/* Lifespan 1 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Asset Expected Lifespan (Years)</label>
                  <input 
                    type="number" 
                    required
                    value={formExpectedLife}
                    onChange={(e) => setFormExpectedLife(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                {/* Lifespan 2 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Remaining Operational Life (Years)</label>
                  <input 
                    type="number" 
                    required
                    value={formRemainingLife}
                    onChange={(e) => setFormRemainingLife(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  />
                </div>

                {/* Qualitative 1 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Construction / Operating Stage</label>
                  <select 
                    value={formStatus}
                    onChange={(e) => setFormStatus(e.target.value as ConstructionStatus)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    <option value="Pre-feasibility">Pre-feasibility</option>
                    <option value="Detailed Design">Detailed Design</option>
                    <option value="Under Construction">Under Construction</option>
                    <option value="Operational">Operational</option>
                  </select>
                </div>

                {/* Qualitative 2 */}
                <div>
                  <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Sovereign Risk Rating</label>
                  <select 
                    value={formRisk}
                    onChange={(e) => setFormRisk(e.target.value as RiskRating)}
                    className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium-Low">Medium-Low</option>
                    <option value="Medium">Medium</option>
                    <option value="Medium-High">Medium-High</option>
                    <option value="High">High</option>
                  </select>
                </div>
              </div>

              {/* RI Notes */}
              <div>
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Responsible Investment (RI) / ESG Governance Notes</label>
                <textarea 
                  rows={3}
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-800 rounded p-2.5 text-slate-100 focus:outline-none focus:ring-1 focus:ring-teal-500"
                  placeholder="Record strategic environmental benefits, community offsets, circular recycling guidelines..."
                ></textarea>
              </div>

              {/* Modal Actions */}
              <div className="flex items-center justify-end space-x-3 pt-4 border-t border-slate-800">
                <button 
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="bg-slate-950 border border-slate-800 hover:bg-slate-800 text-slate-300 font-semibold px-4 py-2 rounded-sm"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="bg-teal-600 hover:bg-teal-500 text-white font-semibold px-4 py-2 rounded-sm"
                >
                  Save Asset Properties
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
