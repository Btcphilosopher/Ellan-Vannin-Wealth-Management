/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { HydrogenAsset } from '../types';

export const INITIAL_ASSETS: HydrogenAsset[] = [
  {
    id: 'HYD-001',
    name: 'Orkney Clean H2 Hub',
    location: 'Orkney Islands, Scotland',
    region: 'Scotland',
    assetType: 'Green Hydrogen Production',
    investmentDate: '2023-04-12',
    ownershipPercentage: 100,
    constructionStatus: 'Operational',
    capacityMW: 15,
    carbonIntensity: 0.15, // kg CO2e / kg H2 (Very low - wind powered)
    expectedLifeYears: 25,
    remainingLifeYears: 22,
    capitalInvestedM: 45.0,
    operatingCostM: 2.2,
    annualRevenueM: 7.8,
    riskRating: 'Medium-Low',
    responsibleInvestmentNotes: 'Wind-powered electrolysers. Direct grid curtailment reduction. Highly aligned with Highlands & Islands net-zero strategy.'
  },
  {
    id: 'HYD-002',
    name: 'Teesside Salt Cavern Storage',
    location: 'Teesside, North East England',
    region: 'North East',
    assetType: 'Hydrogen Storage Facility',
    investmentDate: '2024-02-18',
    ownershipPercentage: 65,
    constructionStatus: 'Under Construction',
    capacityMW: 60,
    carbonIntensity: 0.45, // Salt caverns have small operational footprint
    expectedLifeYears: 40,
    remainingLifeYears: 38,
    capitalInvestedM: 110.0,
    operatingCostM: 4.8,
    annualRevenueM: 18.5,
    riskRating: 'Medium',
    responsibleInvestmentNotes: 'Reutilising deep geologically stable salt structures. Strategic national resilience buffer. Some localized construction disturbance.'
  },
  {
    id: 'HYD-003',
    name: 'Cromarty Firth Distillery H2',
    location: 'Invergordon, Scotland',
    region: 'Scotland',
    assetType: 'Green Hydrogen Production',
    investmentDate: '2023-11-05',
    ownershipPercentage: 80,
    constructionStatus: 'Operational',
    capacityMW: 20,
    carbonIntensity: 0.18,
    expectedLifeYears: 25,
    remainingLifeYears: 23,
    capitalInvestedM: 52.0,
    operatingCostM: 2.6,
    annualRevenueM: 9.1,
    riskRating: 'Low',
    responsibleInvestmentNotes: 'Replacing heavy fuel oil usage in local whisky distilleries. High local community buy-in. circular water recycling system implemented.'
  },
  {
    id: 'HYD-004',
    name: 'Humber Industrial Blend & Feed',
    location: 'Humber Estuary, Yorkshire',
    region: 'Yorkshire & Humber',
    assetType: 'Industrial Blending Plant',
    investmentDate: '2024-08-30',
    ownershipPercentage: 40,
    constructionStatus: 'Detailed Design',
    capacityMW: 150,
    carbonIntensity: 0.72, // Blends hydrogen into natural gas grid, partially gas powered
    expectedLifeYears: 30,
    remainingLifeYears: 29,
    capitalInvestedM: 85.0,
    operatingCostM: 3.5,
    annualRevenueM: 14.2,
    riskRating: 'Medium-High',
    responsibleInvestmentNotes: 'Blending up to 20% H2 into the existing gas network. Technical regulatory approvals pending. Vital transition asset for heavy industry.'
  },
  {
    id: 'HYD-005',
    name: 'Port Talbot Net-Zero Steel Feed',
    location: 'Port Talbot, South Wales',
    region: 'Wales',
    assetType: 'Green Hydrogen Production',
    investmentDate: '2025-01-15',
    ownershipPercentage: 50,
    constructionStatus: 'Pre-feasibility',
    capacityMW: 100,
    carbonIntensity: 0.22,
    expectedLifeYears: 30,
    remainingLifeYears: 30,
    capitalInvestedM: 140.0,
    operatingCostM: 6.8,
    annualRevenueM: 26.0,
    riskRating: 'High',
    responsibleInvestmentNotes: 'Mega-scale production for steel decarbonisation. Heavy reliance on grid scale renewable expansion. Critical UK industrial preservation asset.'
  },
  {
    id: 'HYD-006',
    name: 'Milford Haven Shipping Refueller',
    location: 'Milford Haven, Wales',
    region: 'Wales',
    assetType: 'Heavy Transport Refuelling Station',
    investmentDate: '2023-08-22',
    ownershipPercentage: 100,
    constructionStatus: 'Operational',
    capacityMW: 8,
    carbonIntensity: 0.25,
    expectedLifeYears: 20,
    remainingLifeYears: 17,
    capitalInvestedM: 18.5,
    operatingCostM: 1.1,
    annualRevenueM: 3.9,
    riskRating: 'Medium-Low',
    responsibleInvestmentNotes: 'Refuelling maritime vessels and heavy cargo vehicles. Direct reduction in coastal sulphur and particulate emissions. Zero safety incidents.'
  },
  {
    id: 'HYD-007',
    name: 'Mersey H2 Pipeline Corridor',
    location: 'Mersey Basin, North West England',
    region: 'North West',
    assetType: 'Pipeline Distribution Network',
    investmentDate: '2024-05-14',
    ownershipPercentage: 75,
    constructionStatus: 'Under Construction',
    capacityMW: 80,
    carbonIntensity: 0.35,
    expectedLifeYears: 50,
    remainingLifeYears: 48,
    capitalInvestedM: 95.0,
    operatingCostM: 3.1,
    annualRevenueM: 15.8,
    riskRating: 'Medium',
    responsibleInvestmentNotes: 'Connecting green producers with chemical plants in Cheshire. Low pressure distribution lines minimizing safety risks. Detailed environmental impact audit completed.'
  },
  {
    id: 'HYD-008',
    name: 'Solent Marine Bunkering Station',
    location: 'Southampton, South East England',
    region: 'South East',
    assetType: 'Heavy Transport Refuelling Station',
    investmentDate: '2024-11-10',
    ownershipPercentage: 70,
    constructionStatus: 'Detailed Design',
    capacityMW: 12,
    carbonIntensity: 0.28,
    expectedLifeYears: 20,
    remainingLifeYears: 19,
    capitalInvestedM: 24.0,
    operatingCostM: 1.4,
    annualRevenueM: 4.8,
    riskRating: 'Medium-High',
    responsibleInvestmentNotes: 'Hydrogen bunkering for Solent ferries. Strict coastal marine protection guidelines followed. High alignment with Freeport zero-emission targets.'
  },
  {
    id: 'HYD-009',
    name: 'East Midlands Grid-Blending Node',
    location: 'Derbyshire, East Midlands',
    region: 'East Midlands',
    assetType: 'Industrial Blending Plant',
    investmentDate: '2025-03-01',
    ownershipPercentage: 35,
    constructionStatus: 'Pre-feasibility',
    capacityMW: 50,
    carbonIntensity: 0.65,
    expectedLifeYears: 30,
    remainingLifeYears: 30,
    capitalInvestedM: 38.0,
    operatingCostM: 1.8,
    annualRevenueM: 5.9,
    riskRating: 'Medium-High',
    responsibleInvestmentNotes: 'Decarbonising local glass and ceramics manufacturing. Challenging electrical grid connection queue. Excellent long-term volume commitments.'
  },
  {
    id: 'HYD-010',
    name: 'Cornwall Wind-to-H2 Pilot',
    location: 'Redruth, South West England',
    region: 'South West',
    assetType: 'Green Hydrogen Production',
    investmentDate: '2022-09-18',
    ownershipPercentage: 100,
    constructionStatus: 'Operational',
    capacityMW: 6,
    carbonIntensity: 0.12, // Super low powered by off-grid wind
    expectedLifeYears: 20,
    remainingLifeYears: 16,
    capitalInvestedM: 14.5,
    operatingCostM: 0.8,
    annualRevenueM: 2.5,
    riskRating: 'Low',
    responsibleInvestmentNotes: 'Powered by a dedicated local wind turbine. Direct local utility-vehicle supply. Strong community cooperative engagement.'
  }
];

// Map coordinates for the UK Atlas
export const REGION_COORDINATES: Record<string, { x: number; y: number; lat: number; lng: number }> = {
  'Scotland': { x: 42, y: 25, lat: 57.5, lng: -4.0 },
  'North East': { x: 55, y: 51, lat: 55.0, lng: -1.8 },
  'North West': { x: 49, y: 59, lat: 54.2, lng: -2.8 },
  'Yorkshire & Humber': { x: 58, y: 65, lat: 53.8, lng: -1.0 },
  'Wales': { x: 42, y: 79, lat: 52.3, lng: -3.8 },
  'East Midlands': { x: 58, y: 73, lat: 52.9, lng: -1.0 },
  'West Midlands': { x: 52, y: 76, lat: 52.5, lng: -2.0 },
  'East of England': { x: 67, y: 79, lat: 52.4, lng: 0.5 },
  'London': { x: 64, y: 85, lat: 51.5, lng: -0.1 },
  'South East': { x: 59, y: 88, lat: 51.1, lng: -0.5 },
  'South West': { x: 38, y: 91, lat: 50.7, lng: -3.5 },
  'Northern Ireland': { x: 25, y: 50, lat: 54.6, lng: -6.5 }
};

export const ASSET_LOCATIONS: Record<string, { x: number; y: number }> = {
  'HYD-001': { x: 44, y: 12 }, // Orkney
  'HYD-002': { x: 55, y: 54 }, // Teesside
  'HYD-003': { x: 41, y: 24 }, // Cromarty Firth
  'HYD-004': { x: 59, y: 62 }, // Humber
  'HYD-005': { x: 43, y: 82 }, // Port Talbot
  'HYD-006': { x: 37, y: 81 }, // Milford Haven
  'HYD-007': { x: 48, y: 64 }, // Mersey
  'HYD-008': { x: 56, y: 87 }, // Solent
  'HYD-009': { x: 54, y: 72 }, // East Midlands
  'HYD-010': { x: 33, y: 92 }  // Cornwall
};
