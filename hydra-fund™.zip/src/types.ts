/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AssetType = 'Green Hydrogen Production' | 'Hydrogen Storage Facility' | 'Pipeline Distribution Network' | 'Industrial Blending Plant' | 'Heavy Transport Refuelling Station';

export type ConstructionStatus = 'Pre-feasibility' | 'Detailed Design' | 'Under Construction' | 'Operational';

export type RiskRating = 'Low' | 'Medium-Low' | 'Medium' | 'Medium-High' | 'High';

export interface HydrogenAsset {
  id: string;
  name: string;
  location: string;
  region: string;
  assetType: AssetType;
  investmentDate: string;
  ownershipPercentage: number; // e.g. 85 for 85%
  constructionStatus: ConstructionStatus;
  capacityMW: number;
  carbonIntensity: number; // kg CO2e / kg H2
  expectedLifeYears: number;
  remainingLifeYears: number;
  capitalInvestedM: number; // Million GBP
  operatingCostM: number; // Million GBP per year
  annualRevenueM: number; // Million GBP per year
  riskRating: RiskRating;
  responsibleInvestmentNotes: string;
}

export interface FinancialMetrics {
  npv: number;
  irr: number;
  paybackPeriod: number;
  profitabilityIndex: number;
  roic: number;
  freeCashFlows: number[];
  discountedCashFlows: number[];
}

export interface ScenarioParameters {
  electricityPriceMod: number; // relative change, e.g. 1.0 (no change), 1.2 (+20%)
  hydrogenDemandMod: number;
  capexMod: number;
  opexMod: number;
  financingCostMod: number; // e.g. +1.0% interest rate
  inflationMod: number; // e.g. percentage interest
  carbonPricingMod: number; // e.g. change in £/tonne
  discountRate: number; // percentage
}

export interface CapitalAllocationWeights {
  irrWeight: number;
  cashFlowWeight: number;
  capitalEfficiencyWeight: number;
  riskWeight: number;
  technologyMaturityWeight: number;
  diversificationWeight: number;
  regionalStrategyWeight: number;
  esgWeight: number;
}

export interface AuditLogEntry {
  timestamp: string;
  action: string;
  assetId?: string;
  assetName?: string;
  user: string;
  details: string;
}
