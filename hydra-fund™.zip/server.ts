/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route first: Gemini Sovereign AI Advisor Memo Generator
  app.post('/api/gemini/analyze', async (req, res) => {
    try {
      const { assets, discountRate } = req.body;
      
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
        return res.json({ 
          report: "GEMINI_API_KEY environment variable is not defined or is using the default placeholder.\n\nTo enable genuine, real-time AI Sovereign Analysis:\n1. Click the 'Settings' gear icon in the top right of your AI Studio workspace.\n2. Open 'Secrets' or 'API Keys'.\n3. Provide a valid Gemini API key for the secret 'GEMINI_API_KEY'.\n\nUntil configured, you can download local printable summaries and PostgreSQL relational schemas using the buttons above." 
        });
      }

      // Initialize Gemini using named parameters (complying with skill instructions)
      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      const assetSummary = assets.map((a: any) => `- Name: ${a.name}, Category: ${a.type}, Invested Capital: £${a.capital}M, Region: ${a.region}, Phase: ${a.status}`).join('\n');
      
      const prompt = `You are a world-class senior quantitative sovereign wealth portfolio director auditing a diversified hydrogen infrastructure fund called HYDRA FUND™ for Ellan Vannin Wealth Management.
The current portfolio hurdle rate (WACC discount rate) is ${(discountRate * 100).toFixed(1)}%.

Here is the active portfolio asset registry:
${assetSummary}

Write an institutional-grade, formal, elite-level Sovereign Investment Advisory Memo outlining:
1. Executive Portfolio Health Review: Analyze consolidated assets under management, evaluate regional geographic concentration risks (especially Scotland, Teesside, and Wales), and cross-examine performance against the ${(discountRate * 100).toFixed(1)}% sovereign hurdle.
2. Asset Strategic Categorization: Categorize active holdings into low-risk base utility infrastructure (e.g. pipeline and cavern storage networks) versus high-beta merchant nodes (such as production electrolysers and refuelling depots).
3. Transition, Carbon & ESG Footprint Audit: Examine the carbon intensity index metrics and overall alignment with the UK Net-Zero 2050 legal framework.
4. Capital Rebalancing Directives: Recommend specific capital movements to optimize overall portfolio efficiency, insulate against input electricity price shocks, and prevent long-term stranded asset risk.

Speak with high-finance gravity, objective analytical precision, and authoritative composure. Avoid promotional hype, exclamation marks, or empty adjectives. Format with beautiful numbered headings, clean spacing, and scannable paragraph layouts.`;

      const response = await ai.models.generateContent({
        model: 'gemini-3.6-flash',
        contents: prompt,
      });

      res.json({ report: response.text });
    } catch (error: any) {
      console.error("Gemini sovereign analyzer failed:", error);
      res.json({ report: `The Gemini Sovereign Advisory Engine encountered an operational interrupt: ${error.message}` });
    }
  });

  // Health endpoint
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', time: new Date().toISOString() });
  });

  // Vite development integration or static file serving
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`HYDRA FUND™ server running on http://localhost:${PORT}`);
  });
}

startServer();
