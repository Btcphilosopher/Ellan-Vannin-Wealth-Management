package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.CasaLibreViewModel
import com.example.ui.Screen
import com.example.ui.screens.*
import com.example.ui.theme.CasaLibreTheme

class MainActivity : ComponentActivity() {
    private val viewModel: CasaLibreViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CasaLibreTheme {
                MainContent(viewModel)
            }
        }
    }
}

enum class PlatformMode {
    GUEST, HOST, OPERATIONS
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainContent(viewModel: CasaLibreViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsState()
    
    // Core Platform Role/Mode (Guest, Host, Operations Back-office)
    var activeMode by remember { mutableStateOf(PlatformMode.GUEST) }

    // Guest bottom nav active tab
    var activeGuestTab by remember { mutableStateOf(0) } // 0: Explorer, 1: Favoritos, 2: Viajes, 3: Perfil

    // Intercept system back button to control our custom ViewModel navigation stack
    BackHandler(enabled = currentScreen != Screen.GuestHome) {
        viewModel.navigateBack()
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            // Elegant Editorial header to switch roles instantly for demonstration
            Surface(
                tonalElevation = 4.dp,
                shadowElevation = 2.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Casa Libre",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 18.sp,
                            color = MaterialTheme.colorScheme.primary,
                            letterSpacing = (-0.5).sp
                        )

                        // Role Selector Chips
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // Guest
                            InputChip(
                                selected = activeMode == PlatformMode.GUEST,
                                onClick = {
                                    activeMode = PlatformMode.GUEST
                                    viewModel.navigateTo(Screen.GuestHome)
                                },
                                label = { Text("Viajero", fontSize = 11.sp) },
                                colors = InputChipDefaults.inputChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
                                )
                            )

                            // Host
                            InputChip(
                                selected = activeMode == PlatformMode.GUEST.let { activeMode == PlatformMode.HOST },
                                onClick = {
                                    activeMode = PlatformMode.HOST
                                    viewModel.navigateTo(Screen.HostDashboard)
                                },
                                label = { Text("Anfitrión", fontSize = 11.sp) },
                                colors = InputChipDefaults.inputChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.secondary.copy(alpha = 0.15f)
                                )
                            )

                            // Admin / Operations
                            InputChip(
                                selected = activeMode == PlatformMode.OPERATIONS,
                                onClick = {
                                    activeMode = PlatformMode.OPERATIONS
                                    viewModel.navigateTo(Screen.OperationsDashboard)
                                },
                                label = { Text("Operaciones", fontSize = 11.sp) },
                                colors = InputChipDefaults.inputChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)
                                )
                            )
                        }
                    }
                }
            }
        },
        bottomBar = {
            // Render traveler bottom navigation ONLY when in GUEST travel mode
            if (activeMode == PlatformMode.GUEST) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp
                ) {
                    NavigationBarItem(
                        selected = activeGuestTab == 0 && (currentScreen is Screen.GuestHome || currentScreen is Screen.GuestSearch || currentScreen is Screen.GuestPropertyDetail),
                        onClick = {
                            activeGuestTab = 0
                            viewModel.navigateTo(Screen.GuestHome)
                        },
                        icon = { Icon(Icons.Default.Search, contentDescription = "Explorar") },
                        label = { Text("Explorar", fontSize = 11.sp) }
                    )
                    NavigationBarItem(
                        selected = activeGuestTab == 1 && currentScreen is Screen.GuestFavorites,
                        onClick = {
                            activeGuestTab = 1
                            viewModel.navigateTo(Screen.GuestFavorites)
                        },
                        icon = { Icon(Icons.Default.FavoriteBorder, contentDescription = "Favoritos") },
                        label = { Text("Favoritos", fontSize = 11.sp) }
                    )
                    NavigationBarItem(
                        selected = activeGuestTab == 2 && currentScreen is Screen.GuestTrips,
                        onClick = {
                            activeGuestTab = 2
                            viewModel.navigateTo(Screen.GuestTrips)
                        },
                        icon = { Icon(Icons.Default.Luggage, contentDescription = "Viajes") },
                        label = { Text("Mis Viajes", fontSize = 11.sp) }
                    )
                    NavigationBarItem(
                        selected = activeGuestTab == 3 && currentScreen is Screen.GuestAccount,
                        onClick = {
                            activeGuestTab = 3
                            viewModel.navigateTo(Screen.GuestAccount)
                        },
                        icon = { Icon(Icons.Default.PersonOutline, contentDescription = "Perfil") },
                        label = { Text("Perfil", fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            AnimatedContent(
                targetState = currentScreen,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                },
                label = "ScreenTransition"
            ) { screen ->
                when (screen) {
                    // --- GUEST MARKETPLACE ---
                    is Screen.GuestHome -> GuestHomeScreen(
                        viewModel = viewModel,
                        onNavigateToProperty = { id -> viewModel.navigateTo(Screen.GuestPropertyDetail(id)) }
                    )
                    is Screen.GuestSearch -> GuestSearchScreen(
                        viewModel = viewModel,
                        onNavigateToProperty = { id -> viewModel.navigateTo(Screen.GuestPropertyDetail(id)) }
                    )
                    is Screen.GuestPropertyDetail -> GuestPropertyDetailScreen(
                        propertyId = screen.propertyId,
                        viewModel = viewModel,
                        onNavigateToChat = { id -> viewModel.navigateTo(Screen.GuestChat(id)) }
                    )
                    is Screen.GuestTrips -> GuestTripsScreen(
                        viewModel = viewModel
                    )
                    is Screen.GuestChat -> GuestChatScreen(
                        propertyId = screen.propertyId,
                        viewModel = viewModel
                    )
                    is Screen.GuestFavorites -> GuestFavoritesScreen(
                        viewModel = viewModel,
                        onNavigateToProperty = { id -> viewModel.navigateTo(Screen.GuestPropertyDetail(id)) }
                    )
                    is Screen.GuestAccount -> GuestAccountScreen(
                        viewModel = viewModel
                    )

                    // --- HOST PROFESSIONAL PORTAL ---
                    is Screen.HostDashboard -> HostDashboardScreen(
                        viewModel = viewModel,
                        onNavigateToProperty = { id -> viewModel.navigateTo(Screen.GuestPropertyDetail(id)) }
                    )
                    is Screen.HostProperties -> HostDashboardScreen(
                        viewModel = viewModel,
                        onNavigateToProperty = { id -> viewModel.navigateTo(Screen.GuestPropertyDetail(id)) }
                    )
                    is Screen.HostPropertyDetail -> GuestPropertyDetailScreen(
                        propertyId = screen.propertyId,
                        viewModel = viewModel,
                        onNavigateToChat = { id -> viewModel.navigateTo(Screen.GuestChat(id)) }
                    )

                    // --- OPERATIONS ADMIN ---
                    is Screen.OperationsDashboard -> OperationsDashboardScreen(
                        viewModel = viewModel
                    )
                }
            }
        }
    }
}

// --- Traveler Favorites Screen ---
@Composable
fun GuestFavoritesScreen(
    viewModel: CasaLibreViewModel,
    onNavigateToProperty: (String) -> Unit
) {
    val favorites by viewModel.favorites.collectAsState()
    val properties by viewModel.allProperties.collectAsState()

    val favProps = remember(favorites, properties) {
        properties.filter { p -> favorites.any { f -> f.propertyId == p.id } }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        SectionHeader(
            title = "Mis Favoritos",
            subtitle = "Alojamientos guardados para tus próximos destinos"
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (favProps.isEmpty()) {
            Box(modifier = Modifier.weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Default.FavoriteBorder, "Favs", modifier = Modifier.size(64.dp), tint = Color.LightGray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("No tienes alojamientos guardados.", fontWeight = FontWeight.Bold)
                    Text("Guarda alojamientos con encanto tocando el corazón.", fontSize = 12.sp, color = Color.Gray)
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(favProps) { property ->
                    PropertyListItemCard(
                        property = property,
                        onClick = { onNavigateToProperty(property.id) }
                    )
                }
            }
        }
    }
}

// --- Traveler Account Profile Screen ---
@Composable
fun GuestAccountScreen(
    viewModel: CasaLibreViewModel
) {
    val user by viewModel.currentUser.collectAsState()

    var bioInput by remember { mutableStateOf("") }
    var showDniSuccess by remember { mutableStateOf(false) }

    LaunchedEffect(user) {
        user?.let { bioInput = it.bio }
    }

    if (user == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            SectionHeader(
                title = "Mi Cuenta",
                subtitle = "Perfil de viajero verificado de Casa Libre"
            )
        }

        // Profile Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    ProfileAvatar(imageUrl = user!!.photoUrl, name = user!!.name, size = 80)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(user!!.name, fontWeight = FontWeight.Black, fontSize = 18.sp)
                    Text(user!!.email, fontSize = 13.sp, color = Color.Gray)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Miembro de la comunidad desde: ${user!!.memberSince}", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }

        // Verification & Compliance ID upload simulation
        item {
            Text("Verificación de Identidad", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.secondary)
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (showDniSuccess || user!!.idDocument.isNotEmpty()) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)
                )
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (showDniSuccess || user!!.idDocument.isNotEmpty()) Icons.Default.Verified else Icons.Default.ErrorOutline,
                        contentDescription = "Estado",
                        tint = if (showDniSuccess || user!!.idDocument.isNotEmpty()) Color(0xFF2E7D32) else Color(0xFFC62828),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (showDniSuccess || user!!.idDocument.isNotEmpty()) "Identidad Validada" else "Identidad no verificada",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (showDniSuccess || user!!.idDocument.isNotEmpty()) Color(0xFF2E7D32) else Color(0xFFC62828)
                        )
                        Text(
                            text = if (showDniSuccess || user!!.idDocument.isNotEmpty()) "Documento DNI_48593021X.pdf verificado." else "Es obligatorio subir tu DNI para formalizar alquileres turísticos en España.",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }
                    if (!showDniSuccess && user!!.idDocument.isEmpty()) {
                        Button(
                            onClick = { showDniSuccess = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("Subir DNI", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Bio Section
        item {
            Text("Biografía del viajero", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.secondary)
        }

        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = bioInput,
                    onValueChange = { bioInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 4,
                    textStyle = TextStyle(fontSize = 13.sp)
                )
                Button(
                    onClick = {
                        val updated = user!!.copy(bio = bioInput)
                        viewModel.insertUser(updated)
                    },
                    modifier = Modifier.align(Alignment.End),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Text("Actualizar perfil")
                }
            }
        }
    }
}
