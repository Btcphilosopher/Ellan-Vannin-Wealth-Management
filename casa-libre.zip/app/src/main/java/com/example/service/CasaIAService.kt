package com.example.service

import android.util.Log
import com.example.data.SearchParams
import com.example.model.Property
import com.example.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object CasaIAService {
    private const val TAG = "CasaIAService"
    private const val MODEL_NAME = "gemini-3.5-flash"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Parses a natural language search query in Spanish into structured SearchParams.
     */
    suspend fun parseNaturalLanguageQuery(query: String): SearchParams = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w(TAG, "Gemini API key not found or placeholder. Using local fallback parser.")
            return@withContext parseWithLocalFallback(query)
        }

        val prompt = """
            Eres el motor de inteligencia artificial de "Casa Libre", una plataforma premium de alquileres turísticos en España.
            Tu tarea es analizar la siguiente consulta de búsqueda del usuario en español y extraer los parámetros de búsqueda estructurados correspondientes en formato JSON.
            
            Consulta del usuario: "$query"
            
            Debes responder ÚNICAMENTE con un objeto JSON válido con los siguientes campos opcionales:
            - destination (string): Nombre de la ciudad, provincia o región turística en España.
            - guests (int): Número de huéspedes (por defecto 1).
            - minPriceEur (double): Presupuesto mínimo en euros.
            - maxPriceEur (double): Presupuesto máximo en euros.
            - category (string): Categoría de alojamiento. Debe ser una de estas: "Playa", "Montaña", "Ciudad", "Pueblos", "Islas", "Naturaleza", "Trabajo", "Familias", "Escapadas", "Larga estancia".
            - minBedrooms (int): Número mínimo de dormitorios.
            - minBathrooms (int): Número mínimo de baños.
            - minBeds (int): Número mínimo de camas.
            - hasWifi (boolean): Si requiere wifi.
            - hasPool (boolean): Si requiere piscina.
            - hasAirConditioning (boolean): Si requiere aire acondicionado.
            - hasHeating (boolean): Si requiere calefacción.
            - hasKitchen (boolean): Si requiere cocina.
            - hasWashingMachine (boolean): Si requiere lavadora.
            - hasDishwasher (boolean): Si requiere lavavajillas.
            - hasParking (boolean): Si requiere aparcamiento.
            - hasPetsAllowed (boolean): Si acepta mascotas.
            - hasWorkstation (boolean): Si requiere zona o espacio para trabajar.
            - hasSeaViews (boolean): Si requiere vistas al mar.

            REGLAS IMPORTANTES:
            - NO inventes datos que no se mencionen o deduzcan lógicamente de la consulta.
            - Traduce frases temporales como "una semana" a 1 huésped o deduce las fechas si se mencionan meses ("septiembre", etc.).
            - Devuelve ÚNICAMENTE el JSON limpio. Sin markdown, sin explicaciones, sin triple comilla trasera.
        """.trimIndent()

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent?key=$apiKey"
            val jsonBody = JSONObject().apply {
                put("contents", org.json.JSONArray().put(
                    JSONObject().apply {
                        put("parts", org.json.JSONArray().put(
                            JSONObject().apply {
                                put("text", prompt)
                            }
                        ))
                    }
                ))
                put("generationConfig", JSONObject().apply {
                    put("responseMimeType", "application/json")
                    put("temperature", 0.1)
                })
            }

            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    Log.e(TAG, "Gemini call failed with code ${response.code}. Falling back.")
                    return@withContext parseWithLocalFallback(query)
                }

                val responseBody = response.body?.string() ?: return@withContext parseWithLocalFallback(query)
                val responseJson = JSONObject(responseBody)
                val candidates = responseJson.getJSONArray("candidates")
                val parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                val rawText = parts.getJSONObject(0).getString("text").trim()

                Log.d(TAG, "Raw response from Gemini: $rawText")
                return@withContext parseJsonToSearchParams(rawText)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during Gemini parsing: ${e.message}. Using fallback.", e)
            return@withContext parseWithLocalFallback(query)
        }
    }

    /**
     * Local rule-based parser that extracts keys and terms from Spanish queries as a safety fallback.
     */
    private fun parseWithLocalFallback(query: String): SearchParams {
        val q = query.lowercase()
        var destination = ""
        var guests = 1
        var category = ""
        var hasWifi = false
        var hasPool = false
        var hasAir = false
        var hasHeating = false
        var hasKitchen = false
        var hasWashing = false
        var hasDishwasher = false
        var hasParking = false
        var hasPets = false
        var hasWork = false
        var hasSea = false
        var minBedrooms = 0

        // Parse guests count
        if (q.contains("dos") || q.contains("2 personas") || q.contains("para 2") || q.contains("pareja")) guests = 2
        else if (q.contains("tres") || q.contains("3 personas") || q.contains("para 3")) guests = 3
        else if (q.contains("cuatro") || q.contains("4 personas") || q.contains("para 4")) guests = 4
        else if (q.contains("cinco") || q.contains("5 personas") || q.contains("para 5")) guests = 5
        else if (q.contains("seis") || q.contains("6 personas") || q.contains("para 6") || q.contains("grupo")) guests = 6

        // Parse destinations
        if (q.contains("valencia")) destination = "Valencia"
        else if (q.contains("madrid")) destination = "Madrid"
        else if (q.contains("mallorca") || q.contains("deia") || q.contains("deià")) destination = "Deià"
        else if (q.contains("begur") || q.contains("girona") || q.contains("costa brava")) destination = "Begur"
        else if (q.contains("granada") || q.contains("albaicin")) destination = "Granada"
        else if (q.contains("gredos") || q.contains("avila") || q.contains("ávila")) destination = "Hoyos del Espino"
        else if (q.contains("sevilla")) destination = "Sevilla"

        // Parse amenities
        if (q.contains("piscina") || q.contains("alberca")) hasPool = true
        if (q.contains("wifi") || q.contains("internet") || q.contains("conexión")) hasWifi = true
        if (q.contains("aire") || q.contains("climatizado") || q.contains("calor")) hasAir = true
        if (q.contains("calefacción") || q.contains("chimenea") || q.contains("frio")) hasHeating = true
        if (q.contains("cocina") || q.contains("cocinar")) hasKitchen = true
        if (q.contains("lavadora")) hasWashing = true
        if (q.contains("lavavajillas")) hasDishwasher = true
        if (q.contains("parking") || q.contains("aparcamiento") || q.contains("garaje")) hasParking = true
        if (q.contains("mascota") || q.contains("perro") || q.contains("gato") || q.contains("animales")) hasPets = true
        if (q.contains("trabajar") || q.contains("trabajo") || q.contains("escritorio") || q.contains("oficina")) hasWork = true
        if (q.contains("mar") || q.contains("playa") || q.contains("vistas al mar") || q.contains("costa")) {
            hasSea = true
            category = "Playa"
        }

        // Parse categories
        if (q.contains("montaña") || q.contains("sierra") || q.contains("cabaña")) category = "Montaña"
        if (q.contains("pueblo") || q.contains("rural")) category = "Pueblos"
        if (q.contains("ciudad") || q.contains("loft") || q.contains("estudio")) category = "Ciudad"

        // Parse rooms
        if (q.contains("dormitorios") || q.contains("habitaciones")) {
            if (q.contains("dos") || q.contains("2")) minBedrooms = 2
            if (q.contains("tres") || q.contains("3")) minBedrooms = 3
        }

        return SearchParams(
            destination = destination,
            guests = guests,
            category = category,
            hasWifi = hasWifi,
            hasPool = hasPool,
            hasAirConditioning = hasAir,
            hasHeating = hasHeating,
            hasKitchen = hasKitchen,
            hasWashingMachine = hasWashing,
            hasDishwasher = hasDishwasher,
            hasParking = hasParking,
            hasPetsAllowed = hasPets,
            hasWorkstation = hasWork,
            hasSeaViews = hasSea,
            minBedrooms = minBedrooms
        )
    }

    private fun parseJsonToSearchParams(jsonStr: String): SearchParams {
        return try {
            val json = JSONObject(jsonStr)
            SearchParams(
                destination = json.optString("destination", ""),
                guests = json.optInt("guests", 1),
                minPriceEur = json.optDouble("minPriceEur", 0.0),
                maxPriceEur = json.optDouble("maxPriceEur", 1000.0),
                category = json.optString("category", ""),
                minBedrooms = json.optInt("minBedrooms", 0),
                minBathrooms = json.optInt("minBathrooms", 0),
                minBeds = json.optInt("minBeds", 0),
                hasWifi = json.optBoolean("hasWifi", false),
                hasPool = json.optBoolean("hasPool", false),
                hasAirConditioning = json.optBoolean("hasAirConditioning", false),
                hasHeating = json.optBoolean("hasHeating", false),
                hasKitchen = json.optBoolean("hasKitchen", false),
                hasWashingMachine = json.optBoolean("hasWashingMachine", false),
                hasDishwasher = json.optBoolean("hasDishwasher", false),
                hasParking = json.optBoolean("hasParking", false),
                hasPetsAllowed = json.optBoolean("hasPetsAllowed", false),
                hasWorkstation = json.optBoolean("hasWorkstation", false),
                hasSeaViews = json.optBoolean("hasSeaViews", false)
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing JSON SearchParams: ${e.message}")
            SearchParams()
        }
    }

    /**
     * Audits a host's property listing details to detect gaps and suggest improvements.
     */
    suspend fun auditPropertyDescription(property: Property): List<String> = withContext(Dispatchers.IO) {
        val apiKey = try { BuildConfig.GEMINI_API_KEY } catch (e: Exception) { "" }
        if (apiKey.isEmpty() || apiKey == "MY_GEMINI_API_KEY") {
            Log.w(TAG, "Gemini API key not found. Using local fallback audit.")
            return@withContext auditWithLocalFallback(property)
        }

        val prompt = """
            Eres el inspector de calidad y cumplimiento de anuncios en "Casa Libre". 
            Analiza el anuncio de propiedad de este anfitrión y propón sugerencias profesionales de redacción de interiorismo y normas en español para maximizar reservas.
            
            Título del anuncio: "${property.title}"
            Ubicación: ${property.city}, ${property.region}
            Descripción actual: "${property.description}"
            Servicios declarados:
            - Wifi: ${property.hasWifi}
            - Piscina: ${property.hasPool}
            - Climatización: ${property.hasAirConditioning}
            - Calefacción: ${property.hasHeating}
            - Cocina: ${property.hasKitchen}
            - Admite mascotas: ${property.hasPetsAllowed}
            - Zona de trabajo: ${property.hasWorkstation}

            Escribe de 2 a 4 recomendaciones breves y profesionales en español, cada una de una línea, que ayuden a mejorar la descripción.
            Devuélvelas como una lista separada por saltos de línea sin números ni guiones iniciales.
        """.trimIndent()

        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent?key=$apiKey"
            val jsonBody = JSONObject().apply {
                put("contents", org.json.JSONArray().put(
                    JSONObject().apply {
                        put("parts", org.json.JSONArray().put(
                            JSONObject().apply {
                                put("text", prompt)
                            }
                        ))
                    }
                ))
            }

            val request = Request.Builder()
                .url(url)
                .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext auditWithLocalFallback(property)
                
                val responseBody = response.body?.string() ?: return@withContext auditWithLocalFallback(property)
                val responseJson = JSONObject(responseBody)
                val candidates = responseJson.getJSONArray("candidates")
                val parts = candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                val text = parts.getJSONObject(0).getString("text").trim()
                
                return@withContext text.lines().map { it.trim().removePrefix("-").removePrefix("*").trim() }.filter { it.isNotEmpty() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in description audit", e)
            return@withContext auditWithLocalFallback(property)
        }
    }

    private fun auditWithLocalFallback(property: Property): List<String> {
        val suggestions = mutableListOf<String>()
        if (property.description.length < 100) {
            suggestions.add("La descripción es muy corta. Detalla la arquitectura, el vecindario y la luz natural de las estancias.")
        }
        if (property.hasWifi && !property.description.contains("wifi", ignoreCase = true) && !property.description.contains("fibra", ignoreCase = true)) {
            suggestions.add("Mencionas que tienes Wifi, pero no especificas si es fibra o apto para teletrabajo en la descripción.")
        }
        if (property.hasPetsAllowed && !property.description.contains("mascota", ignoreCase = true)) {
            suggestions.add("Permites mascotas, ¡un gran atractivo en España! Añade una mención acogedora indicando que son bienvenidas.")
        }
        if (property.registrationNumber.isEmpty()) {
            suggestions.add("Falta introducir el Número de Licencia Turística oficial. Es obligatorio para poder ser publicado en esta comunidad autónoma.")
        } else {
            suggestions.add("¡Estupendo! Licencia turística ${property.registrationNumber} visible. Transmite confianza legal a tus huéspedes.")
        }
        return suggestions
    }
}
