package com.example.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.Update
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import java.util.UUID

// --- Room Converters ---
class CasaLibreConverters {
    @TypeConverter
    fun fromUserRole(value: UserRole): String = value.name
    @TypeConverter
    fun toUserRole(value: String): UserRole = UserRole.valueOf(value)

    @TypeConverter
    fun fromPropertyStatus(value: PropertyStatus): String = value.name
    @TypeConverter
    fun toPropertyStatus(value: String): PropertyStatus = PropertyStatus.valueOf(value)

    @TypeConverter
    fun fromBookingStatus(value: BookingStatus): String = value.name
    @TypeConverter
    fun toBookingStatus(value: String): BookingStatus = BookingStatus.valueOf(value)

    @TypeConverter
    fun fromComplianceStatus(value: ComplianceStatus): String = value.name
    @TypeConverter
    fun toComplianceStatus(value: String): ComplianceStatus = ComplianceStatus.valueOf(value)

    @TypeConverter
    fun fromPaymentStatus(value: PaymentStatus?): String? = value?.name
    @TypeConverter
    fun toPaymentStatus(value: String?): PaymentStatus? = value?.let { PaymentStatus.valueOf(it) }
}

// --- DAOs ---

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :id")
    suspend fun getUserById(id: String): User?

    @Query("SELECT * FROM users WHERE role = :role")
    suspend fun getUsersByRole(role: String): List<User>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: User)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsers(users: List<User>)
}

@Dao
interface PropertyDao {
    @Query("SELECT * FROM properties")
    fun getAllPropertiesFlow(): Flow<List<Property>>

    @Query("SELECT * FROM properties")
    suspend fun getAllProperties(): List<Property>

    @Query("SELECT * FROM properties WHERE id = :id")
    suspend fun getPropertyById(id: String): Property?

    @Query("SELECT * FROM properties WHERE hostId = :hostId")
    fun getPropertiesByHostFlow(hostId: String): Flow<List<Property>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProperty(property: Property)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProperties(properties: List<Property>)

    @Update
    suspend fun updateProperty(property: Property)

    @Delete
    suspend fun deleteProperty(property: Property)
}

@Dao
interface BookingDao {
    @Query("SELECT * FROM bookings ORDER BY timestamp DESC")
    fun getAllBookingsFlow(): Flow<List<Booking>>

    @Query("SELECT * FROM bookings WHERE guestId = :guestId ORDER BY timestamp DESC")
    fun getBookingsForGuestFlow(guestId: String): Flow<List<Booking>>

    @Query("SELECT * FROM bookings WHERE hostId = :hostId ORDER BY timestamp DESC")
    fun getBookingsForHostFlow(hostId: String): Flow<List<Booking>>

    @Query("SELECT * FROM bookings WHERE id = :id")
    suspend fun getBookingById(id: String): Booking?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooking(booking: Booking)

    @Update
    suspend fun updateBooking(booking: Booking)
}

@Dao
interface MessageDao {
    @Query("SELECT * FROM messages WHERE propertyId = :propertyId AND guestId = :guestId ORDER BY timestamp ASC")
    fun getChatMessagesFlow(propertyId: String, guestId: String): Flow<List<Message>>

    @Query("SELECT * FROM messages ORDER BY timestamp DESC")
    fun getAllMessagesFlow(): Flow<List<Message>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: Message)
}

@Dao
interface ReviewDao {
    @Query("SELECT * FROM reviews WHERE propertyId = :propertyId")
    fun getReviewsForPropertyFlow(propertyId: String): Flow<List<Review>>

    @Query("SELECT * FROM reviews WHERE propertyId = :propertyId")
    suspend fun getReviewsForProperty(propertyId: String): List<Review>

    @Query("SELECT * FROM reviews WHERE propertyId = :propertyId")
    fun getReviewsForPropertySync(propertyId: String): List<Review>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReview(review: Review)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReviews(reviews: List<Review>)
}

@Dao
interface FavouriteDao {
    @Query("SELECT * FROM favourites WHERE userId = :userId")
    fun getFavouritesForUserFlow(userId: String): Flow<List<Favourite>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavourite(favourite: Favourite)

    @Query("DELETE FROM favourites WHERE userId = :userId AND propertyId = :propertyId")
    suspend fun deleteFavourite(userId: String, propertyId: String)
}

@Dao
interface IncidentDao {
    @Query("SELECT * FROM incidents ORDER BY timestamp DESC")
    fun getAllIncidentsFlow(): Flow<List<Incident>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIncident(incident: Incident)

    @Update
    suspend fun updateIncident(incident: Incident)
}

@Dao
interface ComplianceAuditDao {
    @Query("SELECT * FROM compliance_audits ORDER BY timestamp DESC")
    fun getAllAuditsFlow(): Flow<List<ComplianceAudit>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAudit(audit: ComplianceAudit)
}

// --- Room Database ---

@Database(
    entities = [
        User::class,
        Property::class,
        Booking::class,
        Message::class,
        Review::class,
        Favourite::class,
        Incident::class,
        ComplianceAudit::class
    ],
    version = 1,
    exportSchema = false
)
@androidx.room.TypeConverters(CasaLibreConverters::class)
abstract class CasaLibreDatabase : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun propertyDao(): PropertyDao
    abstract fun bookingDao(): BookingDao
    abstract fun messageDao(): MessageDao
    abstract fun reviewDao(): ReviewDao
    abstract fun favouriteDao(): FavouriteDao
    abstract fun incidentDao(): IncidentDao
    abstract fun complianceAuditDao(): ComplianceAuditDao

    companion object {
        @Volatile
        private var INSTANCE: CasaLibreDatabase? = null

        fun getDatabase(context: Context): CasaLibreDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    CasaLibreDatabase::class.java,
                    "casa_libre_db"
                )
                .addCallback(DatabaseCallback(context))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val context: Context
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            // Seed the database in a background thread
            CoroutineScope(Dispatchers.IO).launch {
                val database = getDatabase(context)
                seedDatabase(database)
            }
        }
    }
}

// --- Seeding Data Helper ---
suspend fun seedDatabase(db: CasaLibreDatabase) {
    // 1. Seed Users (Guest, Hosts, and Admins/Compliance officers)
    val hostId1 = "host_manuel_deia"
    val hostId2 = "host_sofia_valencia"
    val hostId3 = "host_alvaro_madrid"
    val hostId4 = "host_elena_costabrava"
    val guestId = "usuario_demo_huesped"
    val complianceOfficerId = "oficial_carlos"

    val users = listOf(
        User(
            id = guestId,
            name = "Tomás Soler",
            email = "tom@ahyx.org",
            photoUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
            role = UserRole.GUEST,
            bio = "Viajero y arquitecto de interiores barcelonés. Me encanta descubrir alojamientos singulares que capturen la esencia local de cada rincón de España.",
            ratingAsGuest = 4.9f,
            memberSince = "Febrero 2025",
            idDocument = "DNI_48593021X_VERIFIED.pdf"
        ),
        User(
            id = hostId1,
            name = "Manuel Deià",
            email = "manuel@casadeia.es",
            photoUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80",
            role = UserRole.HOST,
            bio = "Nativo de la Sierra de Tramuntana, artesano de la piedra seca y apasionado de la arquitectura mallorquina tradicional.",
            ratingAsHost = 4.95f,
            memberSince = "Enero 2023"
        ),
        User(
            id = hostId2,
            name = "Sofía Valls",
            email = "sofia.valencia@casalibre.es",
            photoUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80",
            role = UserRole.HOST,
            bio = "Productora cultural y apasionada de la huerta valenciana. Comparto apartamentos modernos con encanto cerca del mar.",
            ratingAsHost = 4.88f,
            memberSince = "Mayo 2024"
        ),
        User(
            id = hostId3,
            name = "Álvaro Ruiz",
            email = "alvaro.madrid@casalibre.es",
            photoUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80",
            role = UserRole.HOST,
            bio = "Diseñador madrileño. Ofrezco estancias de trabajo remoto y escapadas en la sierra con un cuidado interiorismo escandinavo-español.",
            ratingAsHost = 4.75f,
            memberSince = "Septiembre 2023"
        ),
        User(
            id = hostId4,
            name = "Elena Giralt",
            email = "elena.costabrava@casalibre.es",
            photoUrl = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=150&q=80",
            role = UserRole.HOST,
            bio = "Amante de la mar y los caminos de ronda. Ofrezco alojamientos restaurados respetando el entorno marinero de Begur.",
            ratingAsHost = 4.92f,
            memberSince = "Julio 2024"
        ),
        User(
            id = complianceOfficerId,
            name = "Oficial Carlos Gómez",
            email = "carlos.compliance@casalibre.es",
            photoUrl = "",
            role = UserRole.COMPLIANCE,
            bio = "Responsable de Verificación y Cumplimiento Normativo Turístico Estatal y Autonómico."
        )
    )
    db.userDao().insertUsers(users)

    // 2. Seed Properties (With real licensing details & Spanish regional differences)
    val properties = listOf(
        Property(
            id = "prop_deia_mallorca",
            title = "Casa de Piedra Mallorquina en Deià",
            description = "Enclavada en el corazón de Deià, esta joya arquitectónica de piedra seca ofrece vistas panorámicas impresionantes a la Sierra de Tramuntana y al mar Mediterráneo. Cuidadosamente restaurada combinando vigas de pino de Oregón, suelos de barro cocido y comodidades modernas. Cuenta con una terraza espectacular protegida por olivos centenarios.",
            category = "Pueblos",
            city = "Deià",
            province = "Mallorca",
            region = "Islas Baleares",
            maxGuests = 4,
            bedrooms = 2,
            beds = 2,
            bathrooms = 1,
            pricePerNight = 24500, // 245,00 €
            priceWeekend = 27500,  // 275,00 €
            cleaningFee = 6000,    // 60,00 €
            taxesAmount = 2450,    // 10% IVA simplificado + Tasa Turística Ecotasa de Baleares
            status = PropertyStatus.PUBLICADO,
            hasWifi = true,
            hasPool = false,
            hasAirConditioning = false,
            hasHeating = true,
            hasKitchen = true,
            hasWashingMachine = true,
            hasDishwasher = true,
            hasParking = true,
            hasPetsAllowed = false,
            hasWorkstation = true,
            hasSeaViews = true,
            registrationNumber = "ETV/85493-DEIA",
            catastroReference = "9823401DD6892S0001JJ",
            complianceStatus = ComplianceStatus.CUMPLE,
            complianceNotes = "Licencia vacacional (ETV) verificada formalmente con el registro oficial de la Conselleria de Turisme de las Islas Baleares.",
            hostId = hostId1,
            mainImageUrl = "https://images.unsplash.com/photo-1513584684374-8bab748fbf90?auto=format&fit=crop&w=600&q=80",
            latitude = 39.7479,
            longitude = 2.6414
        ),
        Property(
            id = "prop_valencia_playa",
            title = "Ático Mediterráneo Frente al Mar",
            description = "Elegante ático en primera línea de playa en Valencia, con una inmensa terraza privada orientada al este para disfrutar de amaneceres únicos. Decorado en tonos arena, lino blanco y maderas flotantes. Dispone de un amplio espacio luminoso de salón-cocina totalmente equipado y acceso directo al paseo marítimo.",
            category = "Playa",
            city = "Valencia",
            province = "Valencia",
            region = "Comunidad Valenciana",
            maxGuests = 4,
            bedrooms = 2,
            beds = 3,
            bathrooms = 2,
            pricePerNight = 16000, // 160,00 €
            priceWeekend = 18500,
            cleaningFee = 5000,
            taxesAmount = 1600,
            status = PropertyStatus.PUBLICADO,
            hasWifi = true,
            hasPool = true,
            hasAirConditioning = true,
            hasHeating = true,
            hasKitchen = true,
            hasWashingMachine = true,
            hasDishwasher = true,
            hasParking = true,
            hasPetsAllowed = true,
            hasWorkstation = true,
            hasSeaViews = true,
            registrationNumber = "VT-49302-V",
            catastroReference = "4510309YJ2741N0002KK",
            complianceStatus = ComplianceStatus.CUMPLE,
            complianceNotes = "Licencia VT registrada válidamente en el Registro de Turismo de la Generalitat Valenciana.",
            hostId = hostId2,
            mainImageUrl = "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=600&q=80",
            latitude = 39.4699,
            longitude = -0.3763
        ),
        Property(
            id = "prop_madrid_chueca",
            title = "Estudio de Diseño Industrial en Chueca",
            description = "Espectacular loft urbano en el dinámico barrio madrileño de Chueca. Conserva las paredes originales de ladrillo visto madrileño del siglo XIX y grandes ventanales de madera balconados. Rediseñado con un estilo industrial refinado, con una moderna zona de trabajo de alta velocidad y cafetera premium de especialidad.",
            category = "Ciudad",
            city = "Madrid",
            province = "Madrid",
            region = "Comunidad de Madrid",
            maxGuests = 2,
            bedrooms = 1,
            beds = 1,
            bathrooms = 1,
            pricePerNight = 11000, // 110,00 €
            priceWeekend = 13000,
            cleaningFee = 4000,
            taxesAmount = 1100,
            status = PropertyStatus.PUBLICADO,
            hasWifi = true,
            hasPool = false,
            hasAirConditioning = true,
            hasHeating = true,
            hasKitchen = true,
            hasWashingMachine = true,
            hasDishwasher = false,
            hasParking = false,
            hasPetsAllowed = false,
            hasWorkstation = true,
            hasSeaViews = false,
            registrationNumber = "VFT/MAD/49321",
            catastroReference = "1203948TT4029S0001AA",
            complianceStatus = ComplianceStatus.CUMPLE,
            complianceNotes = "Declaración responsable tramitada ante el Ayuntamiento de Madrid.",
            hostId = hostId3,
            mainImageUrl = "https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=600&q=80",
            latitude = 40.4225,
            longitude = -3.6980
        ),
        Property(
            id = "prop_costa_brava_begur",
            title = "Refugio de Pescadores en Calas de Begur",
            description = "Antigua cabaña de pescadores de 1910, exquisitamente restaurada y rodeada de pinos y rocas a escasos metros del agua en Begur, Costa Brava. Acceso directo a una cala escondida por el sendero 'Camí de Ronda'. Un espacio idílico y silencioso, diseñado para desconectar por completo de la prisa y escuchar el oleaje.",
            category = "Naturaleza",
            city = "Begur",
            province = "Girona",
            region = "Cataluña",
            maxGuests = 3,
            bedrooms = 1,
            beds = 2,
            bathrooms = 1,
            pricePerNight = 19500, // 195,00 €
            priceWeekend = 22000,
            cleaningFee = 4500,
            taxesAmount = 1950,
            status = PropertyStatus.PUBLICADO,
            hasWifi = true,
            hasPool = false,
            hasAirConditioning = false,
            hasHeating = true,
            hasKitchen = true,
            hasWashingMachine = true,
            hasDishwasher = true,
            hasParking = true,
            hasPetsAllowed = false,
            hasWorkstation = false,
            hasSeaViews = true,
            registrationNumber = "HUTG-049281",
            catastroReference = "7392104DG8391S0001LL",
            complianceStatus = ComplianceStatus.CUMPLE,
            complianceNotes = "Licencia de Vivienda de Uso Turístico (HUTG) homologada por la Generalitat de Catalunya.",
            hostId = hostId4,
            mainImageUrl = "https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?auto=format&fit=crop&w=600&q=80",
            latitude = 41.9536,
            longitude = 3.2046
        ),
        Property(
            id = "prop_granada_albaicin",
            title = "Carmen Histórico con Vistas a la Alhambra",
            description = "Descubre la magia andaluza alojándote en un carmen tradicional restaurado en el barrio medieval del Albaicín, en Granada. Un patio de ensueño con alberca privada, plantas aromáticas de jazmín y naranjos, y unas vistas frontales e ininterrumpidas a los palacios de la Alhambra que te quitarán el aliento.",
            category = "Pueblos",
            city = "Granada",
            province = "Granada",
            region = "Andalucía",
            maxGuests = 6,
            bedrooms = 3,
            beds = 4,
            bathrooms = 2,
            pricePerNight = 22000, // 220,00 €
            priceWeekend = 25000,
            cleaningFee = 7000,
            taxesAmount = 2200,
            status = PropertyStatus.PUBLICADO,
            hasWifi = true,
            hasPool = true,
            hasAirConditioning = true,
            hasHeating = true,
            hasKitchen = true,
            hasWashingMachine = true,
            hasDishwasher = true,
            hasParking = false,
            hasPetsAllowed = false,
            hasWorkstation = true,
            hasSeaViews = false,
            registrationNumber = "VFT/GR/09328",
            catastroReference = "2394012HH8302S0001ZZ",
            complianceStatus = ComplianceStatus.CUMPLE,
            complianceNotes = "Código VFT de la Junta de Andalucía verificado y activo.",
            hostId = hostId2,
            mainImageUrl = "https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=600&q=80",
            latitude = 37.1773,
            longitude = -3.5986
        ),
        Property(
            id = "prop_gredos_cabana",
            title = "Cabaña de Madera y Cristal en Sierra de Gredos",
            description = "Una cabaña sostenible de arquitectura contemporánea, integrada respetuosamente entre robles y pinos de la Sierra de Gredos. Con un gran ventanal de doble altura que difumina el límite entre el interior y la naturaleza, chimenea de leña nórdica y tina de baño de piedra natural tallada.",
            category = "Montaña",
            city = "Hoyos del Espino",
            province = "Ávila",
            region = "Castilla y León",
            maxGuests = 2,
            bedrooms = 1,
            beds = 1,
            bathrooms = 1,
            pricePerNight = 13500, // 135,00 €
            priceWeekend = 15500,
            cleaningFee = 3500,
            taxesAmount = 1350,
            status = PropertyStatus.PUBLICADO,
            hasWifi = true,
            hasPool = false,
            hasAirConditioning = false,
            hasHeating = true,
            hasKitchen = true,
            hasWashingMachine = false,
            hasDishwasher = false,
            hasParking = true,
            hasPetsAllowed = true,
            hasWorkstation = true,
            hasSeaViews = false,
            registrationNumber = "CRA-AV-4930",
            catastroReference = "1123405AV9230S0001XX",
            complianceStatus = ComplianceStatus.REVISION_NECESARIA,
            complianceNotes = "Se requiere confirmación de la declaración responsable autonómica por cambio en el seguro de responsabilidad civil.",
            hostId = hostId3,
            mainImageUrl = "https://images.unsplash.com/photo-1449034446853-66c86144b0ad?auto=format&fit=crop&w=600&q=80",
            latitude = 40.3548,
            longitude = -5.1742
        ),
        Property(
            id = "prop_sevilla_terraza",
            title = "Estancia Premium junto a la Giralda",
            description = "Espectacular piso señorial sevillano, ubicado en el centro monumental. Conserva los techos altos artesonados y suelos hidráulicos originales combinados con mobiliario de firma contemporáneo. Posee acceso a azotea comunitaria con tumbonas orientada a la Giralda.",
            category = "Ciudad",
            city = "Sevilla",
            province = "Sevilla",
            region = "Andalucía",
            maxGuests = 4,
            bedrooms = 2,
            beds = 2,
            bathrooms = 1,
            pricePerNight = 14500,
            priceWeekend = 16500,
            cleaningFee = 5000,
            taxesAmount = 1450,
            status = PropertyStatus.EN_REVISION,
            hasWifi = true,
            hasPool = false,
            hasAirConditioning = true,
            hasHeating = true,
            hasKitchen = true,
            hasWashingMachine = true,
            hasDishwasher = true,
            hasParking = false,
            hasPetsAllowed = false,
            hasWorkstation = true,
            registrationNumber = "", // Falta licencia!
            catastroReference = "5430219AA8392X0001YY",
            complianceStatus = ComplianceStatus.NO_APTO,
            complianceNotes = "No apto para publicación pública: Carece del número de registro turístico (licencia autonómica) obligatorio en la provincia de Sevilla.",
            hostId = hostId2,
            mainImageUrl = "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?auto=format&fit=crop&w=600&q=80",
            latitude = 37.3891,
            longitude = -5.9845
        )
    )
    db.propertyDao().insertProperties(properties)

    // 3. Seed Reviews
    val reviews = listOf(
        Review(
            id = "rev_1",
            propertyId = "prop_deia_mallorca",
            authorName = "Alejandro M.",
            authorPhotoUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=100&q=80",
            comment = "Absolutamente celestial. Deià es un rincón de ensueño y esta casa conserva todo el espíritu auténtico de la isla. Despertarse con el sonido de la Tramuntana y ver la mar al fondo de la terraza no tiene precio.",
            ratingCleanliness = 5,
            ratingCommunication = 5,
            ratingPrecision = 5,
            ratingLocation = 5,
            ratingCheckIn = 5,
            ratingValue = 5
        ),
        Review(
            id = "rev_2",
            propertyId = "prop_deia_mallorca",
            authorName = "Mireia C.",
            authorPhotoUrl = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=100&q=80",
            comment = "La casa está perfectamente restaurada. Los detalles decorativos en madera y barro son preciosos. El anfitrión Manuel es encantador y nos recomendó las mejores calas recónditas de Mallorca.",
            ratingCleanliness = 5,
            ratingCommunication = 4,
            ratingPrecision = 5,
            ratingLocation = 5,
            ratingCheckIn = 5,
            ratingValue = 4
        ),
        Review(
            id = "rev_3",
            propertyId = "prop_valencia_playa",
            authorName = "Harlan F.",
            authorPhotoUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=100&q=80",
            comment = "Vistas espectaculares a la playa valenciana. Es un lujo levantarse y estar directamente en el paseo marítimo. Muy cómodo para trabajar a distancia con el wifi rápido.",
            ratingCleanliness = 4,
            ratingCommunication = 5,
            ratingPrecision = 5,
            ratingLocation = 5,
            ratingCheckIn = 5,
            ratingValue = 5
        ),
        Review(
            id = "rev_4",
            propertyId = "prop_madrid_chueca",
            authorName = "Lucía P.",
            authorPhotoUrl = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=100&q=80",
            comment = "El estudio tiene un estilazo industrial que me encantó. Ubicación excelente en pleno Chueca, muy cerca de todo. Perfecto para parejas.",
            ratingCleanliness = 5,
            ratingCommunication = 5,
            ratingPrecision = 4,
            ratingLocation = 5,
            ratingCheckIn = 5,
            ratingValue = 5
        )
    )
    db.reviewDao().insertReviews(reviews)

    // 4. Seed default messages & conversations
    val messages = listOf(
        Message(
            propertyId = "prop_deia_mallorca",
            guestId = guestId,
            hostId = hostId1,
            senderId = hostId1,
            text = "¡Hola Tomás! Qué alegría que reserves nuestra pequeña casa de piedra. Ya está todo preparado para tu llegada. Te paso las indicaciones de recogida de llaves autónoma por código.",
            timestamp = System.currentTimeMillis() - 86400000 * 2, // Hace 2 días
            isAutoGenerated = false
        ),
        Message(
            propertyId = "prop_deia_mallorca",
            guestId = guestId,
            hostId = hostId1,
            senderId = guestId,
            text = "Muchas gracias Manuel, es ideal. Volamos mañana por la tarde. ¿Alguna recomendación para cenar cerca?",
            timestamp = System.currentTimeMillis() - 86400000, // Hace 1 día
            isAutoGenerated = false
        ),
        Message(
            propertyId = "prop_deia_mallorca",
            guestId = guestId,
            hostId = hostId1,
            senderId = hostId1,
            text = "Te recomiendo sin duda Es Racó d'es Teix en el propio pueblo, comida local exquisita con unas vistas maravillosas.",
            timestamp = System.currentTimeMillis() - 3600000 * 12, // Hace 12 horas
            isAutoGenerated = false
        )
    )
    for (msg in messages) {
        db.messageDao().insertMessage(msg)
    }

    // 5. Seed default simulated Booking to make the demo active out of the box!
    val defaultBooking = Booking(
        id = "booking_demo_activa",
        propertyId = "prop_deia_mallorca",
        guestId = guestId,
        guestName = "Tomás Soler",
        guestPhoto = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80",
        hostId = hostId1,
        startDate = "2026-10-10",
        endDate = "2026-10-17",
        guestsCount = 2,
        nightsCount = 7,
        pricePerNight = 24500,
        baseAmount = 24500 * 7,
        cleaningFee = 6000,
        taxesAmount = 2450 * 7,
        totalAmount = (24500 * 7) + 6000 + (2450 * 7),
        status = BookingStatus.CONFIRMADA,
        paymentStatus = PaymentStatus.CAPTURA,
        checkInCode = "9483#",
        checkInInstructions = "La caja de llaves se encuentra en el lateral derecho del portal de entrada. El código es 9483#. Empuja la tapa hacia abajo."
    )
    db.bookingDao().insertBooking(defaultBooking)

    // 6. Seed default Incident
    val defaultIncident = Incident(
        id = "incidente_demo",
        bookingId = "booking_demo_activa",
        propertyId = "prop_deia_mallorca",
        title = "Goteo menor grifo cocina",
        description = "El huésped reportó que el grifo de la cocina tiene un leve goteo constante al cerrarse del todo. Requiere ajuste.",
        reporterRole = UserRole.GUEST,
        isResolved = false,
        resolutionNotes = ""
    )
    db.incidentDao().insertIncident(defaultIncident)

    // 7. Seed default Compliance audit log
    val defaultAudit = ComplianceAudit(
        id = "audit_demo_1",
        propertyId = "prop_deia_mallorca",
        actionType = "APROBACION",
        officerName = "Oficial Carlos Gómez",
        oldStatus = ComplianceStatus.PENDIENTE,
        newStatus = ComplianceStatus.CUMPLE,
        remarks = "Documentación vacacional aportada correcta. Coincide plenamente con el Catastro."
    )
    db.complianceAuditDao().insertAudit(defaultAudit)
}
