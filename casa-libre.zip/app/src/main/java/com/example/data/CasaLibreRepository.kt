package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import java.util.UUID

data class SearchParams(
    val destination: String = "",
    val startDate: String = "",
    val endDate: String = "",
    val guests: Int = 1,
    val minPriceEur: Double = 0.0,
    val maxPriceEur: Double = 1000.0,
    val category: String = "", // e.g. "Playa", "Montaña"
    val minBedrooms: Int = 0,
    val minBathrooms: Int = 0,
    val minBeds: Int = 0,
    val hasWifi: Boolean = false,
    val hasPool: Boolean = false,
    val hasAirConditioning: Boolean = false,
    val hasHeating: Boolean = false,
    val hasKitchen: Boolean = false,
    val hasWashingMachine: Boolean = false,
    val hasDishwasher: Boolean = false,
    val hasParking: Boolean = false,
    val hasPetsAllowed: Boolean = false,
    val hasWorkstation: Boolean = false,
    val hasSeaViews: Boolean = false,
    val sortBy: String = "Recomendados" // Recomendados, PrecioMásBajo, PrecioMásAlto, MejorValorada
)

class CasaLibreRepository(private val db: CasaLibreDatabase) {

    // --- Users ---
    suspend fun getUser(id: String): User? = db.userDao().getUserById(id)
    suspend fun insertUser(user: User) = db.userDao().insertUser(user)

    // --- Properties ---
    val allPropertiesFlow: Flow<List<Property>> = db.propertyDao().getAllPropertiesFlow()
    
    suspend fun getAllProperties(): List<Property> = db.propertyDao().getAllProperties()
    suspend fun getPropertyById(id: String): Property? = db.propertyDao().getPropertyById(id)
    fun getPropertiesByHost(hostId: String): Flow<List<Property>> = db.propertyDao().getPropertiesByHostFlow(hostId)
    
    suspend fun insertProperty(property: Property) = db.propertyDao().insertProperty(property)
    suspend fun updateProperty(property: Property) = db.propertyDao().updateProperty(property)
    suspend fun deleteProperty(property: Property) = db.propertyDao().deleteProperty(property)

    // --- Search Engine (deterministic filtering over Room properties) ---
    suspend fun searchProperties(params: SearchParams): List<Property> {
        val all = db.propertyDao().getAllProperties()
        
        return all.filter { p ->
            // Only search published listings
            if (p.status != PropertyStatus.PUBLICADO) return@filter false
            
            // 1. Destination filter
            if (params.destination.isNotEmpty()) {
                val matchesDest = p.city.contains(params.destination, ignoreCase = true) ||
                        p.province.contains(params.destination, ignoreCase = true) ||
                        p.region.contains(params.destination, ignoreCase = true)
                if (!matchesDest) return@filter false
            }
            
            // 2. Guests filter
            if (p.maxGuests < params.guests) return@filter false
            
            // 3. Category filter
            if (params.category.isNotEmpty() && params.category != "Todos") {
                if (!p.category.equals(params.category, ignoreCase = true)) return@filter false
            }
            
            // 4. Price range filter
            val priceEur = p.pricePerNightEur
            if (priceEur < params.minPriceEur || priceEur > params.maxPriceEur) return@filter false
            
            // 5. Rooms/Beds/Bathrooms filter
            if (p.bedrooms < params.minBedrooms) return@filter false
            if (p.bathrooms < params.minBathrooms) return@filter false
            if (p.beds < params.minBeds) return@filter false
            
            // 6. Amenities
            if (params.hasWifi && !p.hasWifi) return@filter false
            if (params.hasPool && !p.hasPool) return@filter false
            if (params.hasAirConditioning && !p.hasAirConditioning) return@filter false
            if (params.hasHeating && !p.hasHeating) return@filter false
            if (params.hasKitchen && !p.hasKitchen) return@filter false
            if (params.hasWashingMachine && !p.hasWashingMachine) return@filter false
            if (params.hasDishwasher && !p.hasDishwasher) return@filter false
            if (params.hasParking && !p.hasParking) return@filter false
            if (params.hasPetsAllowed && !p.hasPetsAllowed) return@filter false
            if (params.hasWorkstation && !p.hasWorkstation) return@filter false
            if (params.hasSeaViews && !p.hasSeaViews) return@filter false
            
            true
        }.let { filtered ->
            // Sort
            when (params.sortBy) {
                "PrecioMásBajo" -> filtered.sortedBy { it.pricePerNight }
                "PrecioMásAlto" -> filtered.sortedByDescending { it.pricePerNight }
                "MejorValorada" -> filtered.sortedByDescending { p -> 
                    // Dynamic calculation for ranking
                    val reviews = db.reviewDao().getReviewsForProperty(p.id)
                    if (reviews.isEmpty()) 4.0f else reviews.map { it.ratingGlobal }.average().toFloat()
                }
                else -> filtered // Recomendados
            }
        }
    }

    // --- Bookings ---
    val allBookingsFlow: Flow<List<Booking>> = db.bookingDao().getAllBookingsFlow()
    fun getBookingsForGuest(guestId: String): Flow<List<Booking>> = db.bookingDao().getBookingsForGuestFlow(guestId)
    fun getBookingsForHost(hostId: String): Flow<List<Booking>> = db.bookingDao().getBookingsForHostFlow(hostId)
    suspend fun getBookingById(id: String): Booking? = db.bookingDao().getBookingById(id)
    
    suspend fun createBooking(booking: Booking) {
        db.bookingDao().insertBooking(booking)
        // Auto-generate booking message
        val welcomeMsg = Message(
            propertyId = booking.propertyId,
            guestId = booking.guestId,
            hostId = booking.hostId,
            senderId = booking.hostId,
            text = "¡Tu reserva de ${booking.nightsCount} noches ha sido confirmada! El estado actual de la reserva es: ${booking.status.name}. El check-in está disponible a partir de las 15:00 del día de entrada. Tu código digital de acceso es: ${booking.checkInCode}.",
            isAutoGenerated = true
        )
        db.messageDao().insertMessage(welcomeMsg)
    }
    
    suspend fun updateBooking(booking: Booking) = db.bookingDao().updateBooking(booking)

    // --- Pricing Engine ---
    fun calculatePrice(property: Property, nights: Int, isWeekendIncluded: Boolean): Map<String, Int> {
        val ratePerNight = if (isWeekendIncluded && property.priceWeekend > 0) {
            property.priceWeekend
        } else {
            property.pricePerNight
        }
        val baseAmount = ratePerNight * nights
        val cleaningFee = property.cleaningFee
        val taxesAmount = (baseAmount * 10) / 100 // 10% IVA simplificado turística
        
        // Descuentos semanales (>= 7 noches: 10% descuento)
        val discountAmount = if (nights >= 7) {
            (baseAmount * 10) / 100
        } else {
            0
        }
        val totalAmount = baseAmount + cleaningFee + taxesAmount - discountAmount
        
        return mapOf(
            "baseAmount" to baseAmount,
            "cleaningFee" to cleaningFee,
            "taxesAmount" to taxesAmount,
            "discountAmount" to discountAmount,
            "totalAmount" to totalAmount,
            "pricePerNight" to ratePerNight
        )
    }

    // --- Messages / Chat ---
    fun getChatMessages(propertyId: String, guestId: String): Flow<List<Message>> =
        db.messageDao().getChatMessagesFlow(propertyId, guestId)
        
    val allMessagesFlow: Flow<List<Message>> = db.messageDao().getAllMessagesFlow()

    suspend fun sendMessage(message: Message) {
        db.messageDao().insertMessage(message)
        
        // Simular respuesta automática del anfitrión para enriquecer la experiencia de demostración
        if (message.senderId == message.guestId && !message.isAutoGenerated) {
            val autoReplyText = when {
                message.text.contains("llaves", ignoreCase = true) || message.text.contains("entrar", ignoreCase = true) -> {
                    "Hola. Para la entrada dispones de un teclado numérico junto a la puerta principal. Tu código digital está disponible en la sección 'Mis Viajes' de tu cuenta Casa Libre."
                }
                message.text.contains("wifi", ignoreCase = true) || message.text.contains("internet", ignoreCase = true) -> {
                    "Hola. El wifi es de alta velocidad por fibra. Los datos de la red y clave los encontrarás anotados en una placa de madera sobre el mueble del recibidor."
                }
                message.text.contains("mascotas", ignoreCase = true) -> {
                    "¡Hola! Estaremos encantados de recibir a tu compañero peludo, siempre que se respeten las normas básicas del alojamiento y el sofá se proteja con las mantas."
                }
                message.text.contains("parking", ignoreCase = true) || message.text.contains("aparcar", ignoreCase = true) -> {
                    "Hola. Hay espacio disponible para aparcar frente al alojamiento en la calle de forma gratuita y segura."
                }
                else -> {
                    "¡Hola! Gracias por tu mensaje. Me pondré en contacto contigo lo antes posible para atender tu solicitud detalladamente."
                }
            }
            // Insert simulated host reply after a small logical delay (simulado en el hilo)
            val hostReply = Message(
                propertyId = message.propertyId,
                guestId = message.guestId,
                hostId = message.hostId,
                senderId = message.hostId,
                text = autoReplyText,
                timestamp = System.currentTimeMillis() + 1000,
                isAutoGenerated = true
            )
            db.messageDao().insertMessage(hostReply)
        }
    }

    // --- Reviews ---
    fun getReviewsForProperty(propertyId: String): Flow<List<Review>> =
        db.reviewDao().getReviewsForPropertyFlow(propertyId)
        
    suspend fun createReview(review: Review) = db.reviewDao().insertReview(review)

    // --- Favourites ---
    fun getFavouritesForUser(userId: String): Flow<List<Favourite>> =
        db.favouriteDao().getFavouritesForUserFlow(userId)

    suspend fun addFavourite(userId: String, propertyId: String, listName: String = "Favoritos") {
        db.favouriteDao().insertFavourite(Favourite(userId = userId, propertyId = propertyId, listName = listName))
    }

    suspend fun removeFavourite(userId: String, propertyId: String) {
        db.favouriteDao().deleteFavourite(userId, propertyId)
    }

    // --- Incidents ---
    val allIncidentsFlow: Flow<List<Incident>> = db.incidentDao().getAllIncidentsFlow()
    suspend fun createIncident(incident: Incident) = db.incidentDao().insertIncident(incident)
    suspend fun updateIncident(incident: Incident) = db.incidentDao().updateIncident(incident)

    // --- Compliance Audits ---
    val allComplianceAuditsFlow: Flow<List<ComplianceAudit>> = db.complianceAuditDao().getAllAuditsFlow()
    suspend fun createComplianceAudit(audit: ComplianceAudit) {
        db.complianceAuditDao().insertAudit(audit)
        // Also update actual property compliance status
        val property = db.propertyDao().getPropertyById(audit.propertyId)
        if (property != null) {
            val updated = property.copy(
                complianceStatus = audit.newStatus,
                complianceNotes = audit.remarks
            )
            db.propertyDao().updateProperty(updated)
        }
    }
}
