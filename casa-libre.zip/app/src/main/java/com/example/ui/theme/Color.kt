package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val TerracottaPrimary = Color(0xFFC05C3E)     // Warm terracotta clay
val OceanSecondary = Color(0xFF1B3B5A)        // Deep Mediterranean ocean blue
val OliveGreenTertiary = Color(0xFF5A7D60)    // Soft olive green
val SandBackground = Color(0xFFFAF7F2)        // Soft warm white background
val StoneSurface = Color(0xFFF3EDE4)          // Soft warm stone card surface
val EarthText = Color(0xFF2C2421)             // Very dark warm brown/black for text

// Dark Theme Palette
val TerracottaPrimaryDark = Color(0xFFE07E60)
val OceanSecondaryDark = Color(0xFF537A9F)
val OliveGreenTertiaryDark = Color(0xFF86A88B)
val CharcoalBackground = Color(0xFF1A1715)    // Rich charcoal-earth dark background
val EarthSurfaceDark = Color(0xFF292421)      // Deep warm brown-grey surface
val WarmTextDark = Color(0xFFF3EDE4)          // Light stone/sand for dark text
