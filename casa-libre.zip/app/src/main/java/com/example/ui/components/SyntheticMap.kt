package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Property
import kotlin.math.sqrt

data class MapMarker(
    val id: String,
    val name: String,
    val region: String,
    // Coordenadas normalizadas de 0 a 1 para posicionar en el lienzo
    val normX: Float,
    val normY: Float,
    val priceEur: Double
)

@Composable
fun InteractiveSyntheticMap(
    properties: List<Property>,
    selectedProperty: Property?,
    onPropertySelected: (Property) -> Unit,
    modifier: Modifier = Modifier
) {
    val mapMarkers = remember(properties) {
        properties.map { p ->
            // Mapeamos geográficamente coordenadas de España a un plano normalizado (0.0 a 1.0)
            // España aprox: latitud 36 a 44, longitud -9 a 4
            val x = ((p.longitude + 9.0) / 13.0).toFloat().coerceIn(0.1f, 0.9f)
            val y = (1.0f - ((p.latitude - 36.0) / 8.0).toFloat()).coerceIn(0.1f, 0.9f)
            MapMarker(p.id, p.title, p.city, x, y, p.pricePerNightEur)
        }
    }

    // Animation for pulse effect on selected marker
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseRadius by infiniteTransition.animateFloat(
        initialValue = 8f,
        targetValue = 22f,
        animationSpec = infiniteRepeatable(
            animationSpec = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "radius"
    )
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(
            animationSpec = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "alpha"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFE8F1F5), shape = RoundedCornerShape(16.dp)) // Suave azul océano pastel
    ) {
        // Map elements overlay
        Column(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(8.dp))
                .padding(12.dp)
        ) {
            Text(
                "Mapa Sintético de España",
                style = MaterialTheme.typography.titleSmall,
                color = Color(0xFF1B3B5A),
                fontWeight = FontWeight.Bold
            )
            Text(
                "Zonas de estancias reguladas de Casa Libre",
                style = MaterialTheme.typography.bodySmall,
                color = Color.Gray
            )
        }

        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(mapMarkers) {
                    detectTapGestures { offset ->
                        // Detect click on markers
                        val canvasWidth = size.width
                        val canvasHeight = size.height
                        
                        var closestMarker: MapMarker? = null
                        var closestDist = Float.MAX_VALUE
                        
                        for (marker in mapMarkers) {
                            val mx = marker.normX * canvasWidth
                            val my = marker.normY * canvasHeight
                            val dist = sqrt((offset.x - mx) * (offset.x - mx) + (offset.y - my) * (offset.y - my))
                            if (dist < 36f && dist < closestDist) { // 36px threshold
                                closestDist = dist
                                closestMarker = marker
                            }
                        }
                        
                        closestMarker?.let { clicked ->
                            val prop = properties.find { it.id == clicked.id }
                            if (prop != null) {
                                onPropertySelected(prop)
                            }
                        }
                    }
                }
        ) {
            val w = size.width
            val h = size.height

            // 1. Dibujar la península ibérica esquemática (España y Portugal)
            // Usamos líneas curvas que simulen el litoral español
            val landColor = Color(0xFFFAF2E7) // Arena cálido
            val strokeColor = Color(0xFFDED2C1)

            val pathPeninsula = androidx.compose.ui.graphics.Path().apply {
                // Galicia / Cantábrico
                moveTo(w * 0.15f, h * 0.15f)
                lineTo(w * 0.50f, h * 0.15f)
                // Pirineo / Frontera Francia
                lineTo(w * 0.75f, h * 0.22f)
                // Costa Catalana
                quadraticTo(w * 0.85f, h * 0.35f, w * 0.82f, h * 0.45f)
                // Comunidad Valenciana / Baleares
                quadraticTo(w * 0.75f, h * 0.55f, w * 0.70f, h * 0.65f)
                // Cabo de Gata / Almería
                quadraticTo(w * 0.58f, h * 0.85f, w * 0.48f, h * 0.88f)
                // Estrecho / Cádiz
                lineTo(w * 0.35f, h * 0.88f)
                // Portugal / Costa Oeste
                lineTo(w * 0.10f, h * 0.80f)
                lineTo(w * 0.10f, h * 0.45f)
                // Esquina Galicia
                lineTo(w * 0.10f, h * 0.22f)
                close()
            }

            drawPath(pathPeninsula, color = landColor)
            drawPath(pathPeninsula, color = strokeColor, style = Stroke(width = 3f))

            // 2. Dibujar Baleares (Mallorca, Ibiza, Menorca)
            drawCircle(Color(0xFFFAF2E7), radius = 18f, center = Offset(w * 0.88f, h * 0.55f))
            drawCircle(Color(0xFFDED2C1), radius = 18f, center = Offset(w * 0.88f, h * 0.55f), style = Stroke(width = 2f))
            
            drawCircle(Color(0xFFFAF2E7), radius = 10f, center = Offset(w * 0.82f, h * 0.58f))
            drawCircle(Color(0xFFDED2C1), radius = 10f, center = Offset(w * 0.82f, h * 0.58f), style = Stroke(width = 2f))

            // 3. Dibujar Islas Canarias (esquemático abajo izquierda)
            drawRect(Color(0xFFD6E2E8), topLeft = Offset(w * 0.05f, h * 0.80f), size = androidx.compose.ui.geometry.Size(w * 0.25f, h * 0.15f))
            drawRect(Color(0xFFB1C6D0), topLeft = Offset(w * 0.05f, h * 0.80f), size = androidx.compose.ui.geometry.Size(w * 0.25f, h * 0.15f), style = Stroke(width = 1f))
            drawCircle(Color(0xFFFAF2E7), radius = 12f, center = Offset(w * 0.12f, h * 0.88f))
            drawCircle(Color(0xFFFAF2E7), radius = 14f, center = Offset(w * 0.20f, h * 0.87f))

            // 4. Dibujar marcadores
            for (marker in mapMarkers) {
                val mx = marker.normX * w
                val my = marker.normY * h
                val isSelected = selectedProperty?.id == marker.id

                if (isSelected) {
                    // Círculo de pulso animado
                    drawCircle(
                        color = Color(0xFFC05C3E),
                        radius = pulseRadius,
                        center = Offset(mx, my),
                        alpha = pulseAlpha
                    )
                    // Círculo central activo
                    drawCircle(
                        color = Color(0xFFC05C3E),
                        radius = 10f,
                        center = Offset(mx, my)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 4f,
                        center = Offset(mx, my)
                    )
                } else {
                    // Círculo por defecto (azul o terracota secundario)
                    drawCircle(
                        color = Color(0xFF1B3B5A),
                        radius = 8f,
                        center = Offset(mx, my)
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 3f,
                        center = Offset(mx, my)
                    )
                }
            }
        }

        // Selected Property Card overlay
        if (selectedProperty != null) {
            Card(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 8.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.LocationOn,
                        contentDescription = "Ubicación",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            selectedProperty.title,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            "${selectedProperty.city}, ${selectedProperty.province}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            "${selectedProperty.pricePerNightEur.toInt()} €",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            "noche",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color.Gray
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onPropertySelected(selectedProperty) },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier.height(36.dp)
                    ) {
                        Text("Ver", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}
