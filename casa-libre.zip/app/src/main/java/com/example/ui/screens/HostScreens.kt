package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.CasaLibreViewModel
import com.example.ui.Screen
import com.example.ui.components.SectionHeader

@Composable
fun HostDashboardScreen(
    viewModel: CasaLibreViewModel,
    onNavigateToProperty: (String) -> Unit
) {
    val properties by viewModel.allProperties.collectAsState()
    val bookings by viewModel.hostBookings.collectAsState()
    val hostId = "host_manuel_deia"
    val myProperties = properties.filter { it.hostId == hostId }

    var selectedTab by remember { mutableStateOf(0) } // 0: Panel, 1: Alojamientos, 2: Calendario y Precios

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            SectionHeader(
                title = "Panel Profesional de Anfitrión",
                subtitle = "Gestiona tus propiedades con cumplimiento legal en España"
            )
        }

        TabRow(selectedTabIndex = selectedTab) {
            Tab(selected = selectedTab == 0, onClick = { selectedTab = 0 }, text = { Text("Resumen") })
            Tab(selected = selectedTab == 1, onClick = { selectedTab = 1 }, text = { Text("Mis Alojamientos") })
            Tab(selected = selectedTab == 2, onClick = { selectedTab = 2 }, text = { Text("Calendario y Tarifas") })
        }

        when (selectedTab) {
            0 -> HostOverviewTab(myProperties, bookings)
            1 -> HostPropertiesTab(myProperties, viewModel, onNavigateToProperty)
            2 -> HostCalendarTab(myProperties)
        }
    }
}

@Composable
fun HostOverviewTab(
    properties: List<Property>,
    bookings: List<Booking>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Today Summary
        item {
            Text("Resumen de Hoy", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), gap = 12.dp) {
                // Total Earnings Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Ingresos Totales", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("1.775 €", fontSize = 20.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                        Text("Simulados de reservas", fontSize = 9.sp, color = Color.Gray)
                    }
                }

                // Active bookings Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Reservas Activas", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${bookings.size} estancias", fontSize = 20.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.secondary)
                        Text("1 en curso hoy", fontSize = 9.sp, color = Color.Gray)
                    }
                }
            }
        }

        // Performance KPIs Section
        item {
            Text("Métricas de Rendimiento", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(0.5.dp, Color.LightGray)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Ocupación media mensual", fontSize = 12.sp, color = Color.Gray)
                        Text("84 %", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Divider(color = Color.LightGray.copy(alpha = 0.3f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Tarifa media por noche (ADR)", fontSize = 12.sp, color = Color.Gray)
                        Text("210 €", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    Divider(color = Color.LightGray.copy(alpha = 0.3f))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Estancia media habitual", fontSize = 12.sp, color = Color.Gray)
                        Text("6,2 noches", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // Regulatory Compliance Alert summary
        item {
            Text("Centro de Cumplimiento", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
        }

        item {
            val nonCompliant = properties.filter { it.complianceStatus != ComplianceStatus.CUMPLE }
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = if (nonCompliant.isEmpty()) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)
                )
            ) {
                Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (nonCompliant.isEmpty()) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = "Estado",
                        tint = if (nonCompliant.isEmpty()) Color(0xFF2E7D32) else Color(0xFFE65100),
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            text = if (nonCompliant.isEmpty()) "🟢 Tus alojamientos cumplen legalmente" else "🟠 Tienes ${nonCompliant.size} anuncios pendientes de licencia",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = if (nonCompliant.isEmpty()) Color(0xFF2E7D32) else Color(0xFFE65100)
                        )
                        Text(
                            text = if (nonCompliant.isEmpty()) "Todas tus licencias turísticas y catastros han sido validados." else "Completa la referencia catastral y la declaración responsable autonómica.",
                            fontSize = 11.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }
        }
    }
}

// --- List & Property Creator tab ---
@Composable
fun HostPropertiesTab(
    myProperties: List<Property>,
    viewModel: CasaLibreViewModel,
    onNavigateToProperty: (String) -> Unit
) {
    var showAddDialog by remember { mutableStateOf(false) }

    var newTitle by remember { mutableStateOf("") }
    var newDesc by remember { mutableStateOf("") }
    var newCity by remember { mutableStateOf("") }
    var newProvince by remember { mutableStateOf("") }
    var newRegion by remember { mutableStateOf("") }
    var newPrice by remember { mutableStateOf("") }
    var newCleaning by remember { mutableStateOf("") }
    var newCategory by remember { mutableStateOf("Playa") }
    var newLicence by remember { mutableStateOf("") }
    var newCatastro by remember { mutableStateOf("") }

    val categories = listOf("Playa", "Montaña", "Ciudad", "Pueblos", "Islas", "Naturaleza", "Trabajo")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    "Tus anuncios de alquiler",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
                Button(
                    onClick = { showAddDialog = true },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Add, "Añadir")
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Añadir Alojamiento")
                }
            }
        }

        if (myProperties.isEmpty()) {
            item {
                Box(modifier = Modifier.fillParentMaxHeight(0.6f), contentAlignment = Alignment.Center) {
                    Text("No tienes ningún alojamiento registrado. ¡Añade tu primera propiedad!", color = Color.Gray, textAlign = TextAlign.Center)
                }
            }
        } else {
            items(myProperties) { property ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(property.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            
                            // Status badge
                            Box(
                                modifier = Modifier
                                    .background(
                                        when (property.status) {
                                            PropertyStatus.PUBLICADO -> Color(0xFFE8F5E9)
                                            PropertyStatus.EN_REVISION -> Color(0xFFFFF3E0)
                                            PropertyStatus.BORRADOR -> Color(0xFFECEFF1)
                                            else -> Color(0xFFFFEBEE)
                                        },
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    property.status.name,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (property.status) {
                                        PropertyStatus.PUBLICADO -> Color(0xFF2E7D32)
                                        PropertyStatus.EN_REVISION -> Color(0xFFE65100)
                                        else -> Color.DarkGray
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text("${property.city}, ${property.province} · ${property.pricePerNightEur.toInt()} €/noche", fontSize = 12.sp, color = Color.Gray)
                        
                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = Color.LightGray.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(12.dp))

                        // Spanish Compliance status inside the specific card
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(
                                            when (property.complianceStatus) {
                                                ComplianceStatus.CUMPLE -> Color(0xFF4CAF50)
                                                ComplianceStatus.REVISION_NECESARIA -> Color(0xFFFF9800)
                                                ComplianceStatus.NO_APTO -> Color(0xFFF44336)
                                                ComplianceStatus.PENDIENTE -> Color(0xFF9E9E9E)
                                            }
                                        )
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Estado Licencia: ${property.complianceStatus.name}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                            
                            Row(gap = 8.dp) {
                                OutlinedButton(
                                    onClick = { onNavigateToProperty(property.id) },
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("Ver ficha", fontSize = 11.sp)
                                }
                                if (property.status == PropertyStatus.BORRADOR) {
                                    Button(
                                        onClick = { viewModel.updatePropertyStatus(property, PropertyStatus.PUBLICADO) },
                                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Text("Publicar", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add listing dialog
    if (showAddDialog) {
        AlertDialog(
            onDismissRequest = { showAddDialog = false },
            title = { Text("Registrar Nuevo Alojamiento", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.heightIn(max = 400.dp)) {
                    item {
                        OutlinedTextField(
                            value = newTitle,
                            onValueChange = { newTitle = it },
                            label = { Text("Título (Ejem: Casa rústica de piedra)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = newDesc,
                            onValueChange = { newDesc = it },
                            label = { Text("Descripción editorial") },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3
                        )
                    }
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), gap = 8.dp) {
                            OutlinedTextField(
                                value = newCity,
                                onValueChange = { newCity = it },
                                label = { Text("Municipio") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = newProvince,
                                onValueChange = { newProvince = it },
                                label = { Text("Provincia") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    item {
                        OutlinedTextField(
                            value = newRegion,
                            onValueChange = { newRegion = it },
                            label = { Text("Comunidad Autónoma") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        Row(modifier = Modifier.fillMaxWidth(), gap = 8.dp) {
                            OutlinedTextField(
                                value = newPrice,
                                onValueChange = { newPrice = it },
                                label = { Text("Precio por noche (€)") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = newCleaning,
                                onValueChange = { newCleaning = it },
                                label = { Text("Limpieza (€)") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    item {
                        // Category selection Dropdown simulate
                        Text("Categoría:", fontSize = 11.sp, color = Color.Gray)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            for (cat in categories.take(4)) {
                                FilterChip(
                                    selected = newCategory == cat,
                                    onClick = { newCategory = cat },
                                    label = { Text(cat, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                    
                    // Critical Spanish legal registration fields
                    item {
                        Divider()
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Cumplimiento Normativo Estatal (Obligatorio en España)", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                    }
                    item {
                        OutlinedTextField(
                            value = newLicence,
                            onValueChange = { newLicence = it },
                            label = { Text("Número de Registro Turístico (Licencia)") },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Ejem: ETV/49302 o HUTG-39201") }
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = newCatastro,
                            onValueChange = { newCatastro = it },
                            label = { Text("Referencia Catastral (20 dígitos)") },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Ejem: 9823401DD6892S0001JJ") }
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val price = newPrice.toDoubleOrNull() ?: 100.0
                        val cleaning = newCleaning.toDoubleOrNull() ?: 30.0
                        viewModel.createHostProperty(
                            title = newTitle,
                            description = newDesc,
                            category = newCategory,
                            city = newCity,
                            province = newProvince,
                            region = newRegion,
                            priceEur = price,
                            cleaningEur = cleaning,
                            guests = 4,
                            rooms = 2,
                            beds = 2,
                            baths = 1,
                            license = newLicence,
                            catastro = newCatastro
                        )
                        showAddDialog = false
                    }
                ) {
                    Text("Registrar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

// --- Custom Interactive Monthly Calendar Tab ---
@Composable
fun HostCalendarTab(
    properties: List<Property>
) {
    var selectedProperty by remember { mutableStateOf(properties.firstOrNull()) }
    var selectedDay by remember { mutableStateOf<Int?>(null) }
    var isDayBlocked by remember { mutableStateOf(false) }
    var customPrice by remember { mutableStateOf("") }
    
    // Represent a calendar month grid (October 2026)
    val daysInMonth = 31
    val startOffset = 3 // Wednesday start for Oct 2026 (approx 3 offsets)

    val blockedDays = remember { mutableStateListOf(4, 5, 12, 13) } // Pre-seeded blocked days
    val customPriceDays = remember { mutableStateMapOf<Int, Int>() }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Agenda de Disponibilidad",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        item {
            // Calendar Grid container
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Octubre 2026", fontWeight = FontWeight.Black, fontSize = 16.sp, color = MaterialTheme.colorScheme.primary, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
                    Spacer(modifier = Modifier.height(12.dp))

                    // Days of week
                    Row(modifier = Modifier.fillMaxWidth()) {
                        val dows = listOf("Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom")
                        for (dow in dows) {
                            Text(dow, modifier = Modifier.weight(1f), textAlign = TextAlign.Center, fontWeight = FontWeight.Bold, fontSize = 11.sp, color = Color.Gray)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Calendar Grid Items
                    val totalSlots = startOffset + daysInMonth
                    val rows = (totalSlots + 6) / 7

                    for (r in 0 until rows) {
                        Row(modifier = Modifier.fillMaxWidth()) {
                            for (c in 0..6) {
                                val index = r * 7 + c
                                val dayNum = index - startOffset + 1
                                if (dayNum in 1..daysInMonth) {
                                    val isBlocked = blockedDays.contains(dayNum)
                                    val hasCustomPrice = customPriceDays.containsKey(dayNum)
                                    val isCurrentSelected = selectedDay == dayNum

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                            .padding(2.dp)
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(
                                                when {
                                                    isCurrentSelected -> MaterialTheme.colorScheme.primary
                                                    isBlocked -> Color.Red.copy(alpha = 0.15f)
                                                    hasCustomPrice -> MaterialTheme.colorScheme.tertiary.copy(alpha = 0.15f)
                                                    else -> Color(0xFFF9F7F4)
                                                }
                                            )
                                            .border(
                                                width = if (isCurrentSelected) 2.dp else 0.5.dp,
                                                color = if (isCurrentSelected) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.5f),
                                                shape = RoundedCornerShape(4.dp)
                                            )
                                            .clickable {
                                                selectedDay = dayNum
                                                isDayBlocked = blockedDays.contains(dayNum)
                                                customPrice = customPriceDays[dayNum]?.toString() ?: ""
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text(
                                                text = dayNum.toString(),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = if (isCurrentSelected) Color.White else if (isBlocked) Color.Red else Color.Black
                                            )
                                            val priceShow = if (hasCustomPrice) customPriceDays[dayNum] else 245
                                            Text(
                                                text = "${priceShow}€",
                                                fontSize = 8.sp,
                                                color = if (isCurrentSelected) Color.White.copy(alpha = 0.8f) else Color.Gray
                                            )
                                        }
                                    }
                                } else {
                                    Spacer(modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }
            }
        }

        // Date Controls overlay inside calendar
        if (selectedDay != null) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "Configurar Día: $selectedDay de Octubre 2026",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // Switch to Block Dates
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Bloquear reservas este día:", fontSize = 13.sp)
                            Switch(
                                checked = isDayBlocked,
                                onCheckedChange = { checked ->
                                    isDayBlocked = checked
                                    if (checked) {
                                        if (!blockedDays.contains(selectedDay!!)) blockedDays.add(selectedDay!!)
                                    } else {
                                        blockedDays.remove(selectedDay!!)
                                    }
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Custom Price override input
                        OutlinedTextField(
                            value = customPrice,
                            onValueChange = { customPrice = it },
                            label = { Text("Precio especial para este día (€)") },
                            modifier = Modifier.fillMaxWidth(),
                            trailingIcon = {
                                IconButton(
                                    onClick = {
                                        val p = customPrice.toIntOrNull()
                                        if (p != null) {
                                            customPriceDays[selectedDay!!] = p
                                        } else {
                                            customPriceDays.remove(selectedDay!!)
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.Save, "Guardar")
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}
