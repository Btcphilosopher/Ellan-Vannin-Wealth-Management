package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = TerracottaPrimaryDark,
    secondary = OceanSecondaryDark,
    tertiary = OliveGreenTertiaryDark,
    background = CharcoalBackground,
    surface = EarthSurfaceDark,
    onPrimary = CharcoalBackground,
    onSecondary = WarmTextDark,
    onTertiary = CharcoalBackground,
    onBackground = WarmTextDark,
    onSurface = WarmTextDark
)

private val LightColorScheme = lightColorScheme(
    primary = TerracottaPrimary,
    secondary = OceanSecondary,
    tertiary = OliveGreenTertiary,
    background = SandBackground,
    surface = StoneSurface,
    onPrimary = SandBackground,
    onSecondary = SandBackground,
    onTertiary = SandBackground,
    onBackground = EarthText,
    onSurface = EarthText
)

@Composable
fun CasaLibreTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Keep dynamicColor false to preserve the high-end custom editorial brand colors
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    CasaLibreTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
