package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.CasaLibreViewModel
import com.example.ui.components.SectionHeader

@Composable
fun OperationsDashboardScreen(
    viewModel: CasaLibreViewModel
) {
    val properties by viewModel.allProperties.collectAsState()
    val bookings by viewModel.allBookings.collectAsState()
    val incidents by viewModel.allIncidents.collectAsState()
    val audits by viewModel.complianceAudits.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: Métricas, 1: Cola Legal, 2: Incidencias

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            SectionHeader(
                title = "Casa Libre Operaciones",
                subtitle = "Consola de control, disputas y cumplimiento legal estatal"
            )
        }

        TabRow(selectedTabIndex = activeTab) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text("Métricas") })
            Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text("Cola Legal") })
            Tab(selected = activeTab == 2, onClick = { activeTab = 2 }, text = { Text("Disputas") })
        }

        when (activeTab) {
            0 -> OperationsMetricsTab(properties, bookings, audits)
            1 -> OperationsComplianceQueueTab(properties, viewModel)
            2 -> OperationsIncidentsTab(incidents, viewModel)
        }
    }
}

@Composable
fun OperationsMetricsTab(
    properties: List<Property>,
    bookings: List<Booking>,
    audits: List<ComplianceAudit>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Text("Estadísticas del Marketplace", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
        }

        item {
            Row(modifier = Modifier.fillMaxWidth(), gap = 12.dp) {
                // Total listings Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(0.5.dp, Color.LightGray)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Alojamientos Activos", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(properties.filter { it.status == PropertyStatus.PUBLICADO }.size.toString(), fontSize = 22.sp, fontWeight = FontWeight.Black)
                        Text("${properties.size} en total", fontSize = 10.sp, color = Color.Gray)
                    }
                }

                // Commission earnings Card
                Card(
                    modifier = Modifier.weight(1f),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(0.5.dp, Color.LightGray)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Comisión Casa Libre", fontSize = 11.sp, color = Color.Gray)
                        Spacer(modifier = Modifier.height(4.dp))
                        val volume = bookings.sumOf { it.totalAmountEur }
                        val commission = volume * 0.15 // 15% platform commission
                        Text("${commission.toInt()} €", fontSize = 22.sp, fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.primary)
                        Text("15 % tarifa plataforma", fontSize = 10.sp, color = Color.Gray)
                    }
                }
            }
        }

        // Financial summary
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Finanzas de Plataforma", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Divider()
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Volumen Bruto (GMV)", fontSize = 12.sp, color = Color.Gray)
                        Text("${bookings.sumOf { it.totalAmountEur }.toInt()} €", fontWeight = FontWeight.Bold)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Impuestos y tasas liquidadas", fontSize = 12.sp, color = Color.Gray)
                        Text("${bookings.sumOf { it.taxesAmountEur }.toInt()} €", fontWeight = FontWeight.Bold, color = Color.Gray)
                    }
                }
            }
        }

        // Risk log / Audit trail list
        item {
            Text("Historial de Verificaciones de Licencia", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
        }

        if (audits.isEmpty()) {
            item {
                Text("No hay auditorías registradas todavía.", fontSize = 13.sp, color = Color.Gray)
            }
        } else {
            items(audits) { audit ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(0.5.dp, Color.LightGray)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(audit.actionType, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = if (audit.actionType == "APROBACION") Color(0xFF2E7D32) else Color(0xFFC62828))
                            Text(audit.officerName, fontSize = 10.sp, color = Color.Gray)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(audit.remarks, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Propiedad ID: ${audit.propertyId}", fontSize = 9.sp, color = Color.Gray)
                    }
                }
            }
        }
    }
}

// --- Compliance Queue verification (where admins approve/reject registrations) ---
@Composable
fun OperationsComplianceQueueTab(
    properties: List<Property>,
    viewModel: CasaLibreViewModel
) {
    val pendingProps = properties.filter { it.complianceStatus == ComplianceStatus.PENDIENTE || it.status == PropertyStatus.EN_REVISION }
    
    var showDialogForProperty by remember { mutableStateOf<Property?>(null) }
    var officerFeedback by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "Cola de Validación Turística (${pendingProps.size} pendientes)",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        if (pendingProps.isEmpty()) {
            item {
                Box(modifier = Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                    Text("🟢 ¡Excelente! No hay alojamientos pendientes de revisión legal en España.", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                }
            }
        } else {
            items(pendingProps) { property ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(property.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Jurisdicción: ${property.city} (${property.region})", fontSize = 12.sp, color = Color.Gray)
                        
                        Spacer(modifier = Modifier.height(8.dp))
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFAF7F2))) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Nº Licencia: ${property.registrationNumber.ifEmpty { "[FALTA LICENCIA]" }}", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (property.registrationNumber.isEmpty()) Color.Red else Color.Black)
                                Text("Ref. Catastral: ${property.catastroReference.ifEmpty { "[FALTA REFERENCIA CATASTRAL]" }}", fontSize = 11.sp, color = if (property.catastroReference.isEmpty()) Color.Red else Color.Black)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider()
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, gap = 8.dp) {
                            OutlinedButton(
                                onClick = {
                                    showDialogForProperty = property
                                    officerFeedback = "Rechazado: La documentación catastral aportada no coincide con los metros cuadrados del catastro público."
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red),
                                modifier = Modifier.height(34.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
                            ) {
                                Text("Rechazar", fontSize = 11.sp)
                            }

                            Button(
                                onClick = {
                                    showDialogForProperty = property
                                    officerFeedback = "Aprobado: Verificación de licencia estatal y catastral completada correctamente."
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50)),
                                modifier = Modifier.height(34.dp),
                                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp)
                            ) {
                                Text("Validar Licencia", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showDialogForProperty != null) {
        val prop = showDialogForProperty!!
        AlertDialog(
            onDismissRequest = { showDialogForProperty = null },
            title = { Text("Registrar resolución de verificación", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Alojamiento: ${prop.title}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = officerFeedback,
                        onValueChange = { officerFeedback = it },
                        label = { Text("Comentarios y justificación formal") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val isApproval = officerFeedback.contains("Aprobado") || officerFeedback.contains("completada")
                        if (isApproval) {
                            viewModel.approveCompliance(prop.id, "Inspector Carlos Gómez", officerFeedback)
                            // Also update property status to PUBLICADO
                            viewModel.updatePropertyStatus(prop, PropertyStatus.PUBLICADO)
                        } else {
                            viewModel.rejectCompliance(prop.id, "Inspector Carlos Gómez", officerFeedback)
                            // Keep property as PAUSADO or SUSPENDIDO
                            viewModel.updatePropertyStatus(prop, PropertyStatus.SUSPENDIDO)
                        }
                        showDialogForProperty = null
                    }
                ) {
                    Text("Confirmar Firma de Auditoría")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDialogForProperty = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

// --- Dispute Incident Manager tab ---
@Composable
fun OperationsIncidentsTab(
    incidents: List<Incident>,
    viewModel: CasaLibreViewModel
) {
    var showResolveDialogForIncident by remember { mutableStateOf<Incident?>(null) }
    var resolutionNotesInput by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "Centro de Disputas e Incidencias",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        if (incidents.isEmpty()) {
            item {
                Text("No hay incidencias activas en el sistema.", fontSize = 13.sp, color = Color.Gray)
            }
        } else {
            items(incidents) { incident ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(incident.title, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (incident.isResolved) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
                                        shape = RoundedCornerShape(4.dp)
                                    )
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = if (incident.isResolved) "RESUELTA" else "ACTIVA",
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (incident.isResolved) Color(0xFF2E7D32) else Color(0xFFC62828)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(incident.description, fontSize = 12.sp, color = Color.DarkGray)
                        
                        if (incident.isResolved) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFF1F8E9))) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Resolución: ${incident.resolutionNotes}", fontSize = 11.sp, color = Color(0xFF33691E))
                                }
                            }
                        } else {
                            Spacer(modifier = Modifier.height(12.dp))
                            Divider()
                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    showResolveDialogForIncident = incident
                                    resolutionNotesInput = "Mediación completada: Se coordina envío de técnico y se realiza reembolso simulado del 10% por molestias."
                                },
                                modifier = Modifier.align(Alignment.End),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                            ) {
                                Text("Resolver y Mediar", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showResolveDialogForIncident != null) {
        val inc = showResolveDialogForIncident!!
        AlertDialog(
            onDismissRequest = { showResolveDialogForIncident = null },
            title = { Text("Registrar resolución de mediación", fontWeight = FontWeight.Bold, fontSize = 15.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Incidencia: ${inc.title}", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    OutlinedTextField(
                        value = resolutionNotesInput,
                        onValueChange = { resolutionNotesInput = it },
                        label = { Text("Instrucciones y resolución") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resolveIncident(inc, resolutionNotesInput)
                        showResolveDialogForIncident = null
                    }
                ) {
                    Text("Guardar Resolución")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResolveDialogForIncident = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}
