package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.SearchParams
import com.example.model.*
import com.example.ui.CasaLibreViewModel
import com.example.ui.Screen
import com.example.ui.components.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuestHomeScreen(
    viewModel: CasaLibreViewModel,
    onNavigateToProperty: (String) -> Unit
) {
    val allProperties by viewModel.allProperties.collectAsState()
    val isSearchingAI by viewModel.casaIAIsLoading.collectAsState()
    
    var searchDestination by remember { mutableStateOf("") }
    var searchGuests by remember { mutableStateOf("1") }
    
    var aiQueryInput by remember { mutableStateOf("") }
    var useAISearch by remember { mutableStateOf(false) }

    val categories = listOf("Todos", "Playa", "Montaña", "Ciudad", "Pueblos", "Islas", "Naturaleza", "Trabajo", "Familias")
    var selectedCategory by remember { mutableStateOf("Todos") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        // Platform title / subtitle
        item {
            Column(modifier = Modifier.padding(top = 16.dp)) {
                Text(
                    text = "CASA LIBRE",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "ALQUILA. DESCUBRE. QUÉDATE.",
                    style = MaterialTheme.typography.titleSmall,
                    color = MaterialTheme.colorScheme.secondary,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                )
            }
        }

        // Editorial AppHero
        item {
            AppHero(
                title = "Encuentra una casa que encaje contigo.",
                subtitle = "Plataforma de alquileres de corta y media estancia regulados legalmente en España. Vivir local, con confianza."
            )
        }

        // Search engine container card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Header Search Toggle
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (useAISearch) "CASA IA: Búsqueda Inteligente" else "¿Dónde quieres ir?",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            fontSize = 16.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI Search Toggle",
                                tint = if (useAISearch) MaterialTheme.colorScheme.primary else Color.Gray,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                "Modo IA",
                                fontSize = 12.sp,
                                color = if (useAISearch) MaterialTheme.colorScheme.primary else Color.Gray,
                                fontWeight = FontWeight.SemiBold
                            )
                            Switch(
                                checked = useAISearch,
                                onCheckedChange = { useAISearch = it },
                                modifier = Modifier.scale(0.7f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    if (useAISearch) {
                        // Casa IA Search view
                        OutlinedTextField(
                            value = aiQueryInput,
                            onValueChange = { aiQueryInput = it },
                            placeholder = { Text("Ejem: Quiero un loft para dos personas en Madrid con buena wifi y aire acondicionado...") },
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = MaterialTheme.colorScheme.primary,
                                unfocusedBorderColor = Color.LightGray
                            ),
                            textStyle = TextStyle(fontSize = 14.sp),
                            shape = RoundedCornerShape(8.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                if (aiQueryInput.isNotBlank()) {
                                    viewModel.processCasaIASearch(aiQueryInput)
                                }
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            enabled = !isSearchingAI
                        ) {
                            if (isSearchingAI) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Procesando consulta...")
                            } else {
                                Icon(Icons.Default.AutoAwesome, contentDescription = "Buscar con IA")
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Buscar con Casa IA")
                            }
                        }
                    } else {
                        // Structured Traditional Search
                        Row(modifier = Modifier.fillMaxWidth(), gap = 8.dp) {
                            OutlinedTextField(
                                value = searchDestination,
                                onValueChange = { searchDestination = it },
                                label = { Text("Destino (Madrid, Valencia, etc.)") },
                                modifier = Modifier.weight(1.5f),
                                leadingIcon = { Icon(Icons.Default.Search, "Destino") },
                                textStyle = TextStyle(fontSize = 13.sp),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MaterialTheme.colorScheme.primary)
                            )
                            OutlinedTextField(
                                value = searchGuests,
                                onValueChange = { searchGuests = it },
                                label = { Text("Huéspedes") },
                                modifier = Modifier.weight(0.8f),
                                textStyle = TextStyle(fontSize = 13.sp),
                                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MaterialTheme.colorScheme.primary)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = {
                                val guestsInt = searchGuests.toIntOrNull() ?: 1
                                viewModel.updateSearchParams(
                                    SearchParams(
                                        destination = searchDestination,
                                        guests = guestsInt,
                                        category = if (selectedCategory == "Todos") "" else selectedCategory
                                    )
                                )
                                viewModel.navigateTo(Screen.GuestSearch)
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Buscar Alojamientos")
                        }
                    }
                }
            }
        }

        // Horizontal Category Row
        item {
            Column {
                Text(
                    "Categorías",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(categories) { category ->
                        val isSelected = selectedCategory == category
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                selectedCategory = category
                                viewModel.updateSearchParams(
                                    viewModel.searchParams.value.copy(
                                        category = if (category == "Todos") "" else category
                                    )
                                )
                            },
                            label = { Text(category) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                selectedLabelColor = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                }
            }
        }

        // Destinos populares (synthetic data list)
        item {
            Text(
                "Destinos destacados",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary
            )
        }

        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                val destinations = listOf(
                    "Mallorca" to "Calma y mar mediterráneo",
                    "Valencia" to "Áticos luminosos y playa",
                    "Madrid" to "Lofts de diseño urbano",
                    "Costa Brava" to "Calas salvajes y pinos",
                    "Granada" to "Cármenes con vistas históricas",
                    "Sierra de Gredos" to "Naturaleza y desconexión"
                )
                items(destinations) { (dest, desc) ->
                    Card(
                        modifier = Modifier
                            .width(160.dp)
                            .clickable {
                                viewModel.updateSearchParams(SearchParams(destination = dest))
                                viewModel.navigateTo(Screen.GuestSearch)
                            },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(0.5.dp, Color.LightGray)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(80.dp)
                                    .background(
                                        MaterialTheme.colorScheme.primary.copy(alpha = 0.05f),
                                        RoundedCornerShape(8.dp)
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.LocationOn, contentDescription = dest, tint = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(dest, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text(desc, fontSize = 11.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            }
        }

        // Recommended Houses list
        item {
            Text(
                "Nuestros alojamientos recomendados",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.secondary,
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        val filteredProps = allProperties.filter { it.status == PropertyStatus.PUBLICADO && (selectedCategory == "Todos" || it.category == selectedCategory) }
        if (filteredProps.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No hay alojamientos disponibles en esta categoría en este momento.", color = Color.Gray, textAlign = TextAlign.Center)
                }
            }
        } else {
            items(filteredProps) { property ->
                PropertyListItemCard(
                    property = property,
                    onClick = { onNavigateToProperty(property.id) }
                )
            }
        }
    }
}

@Composable
fun PropertyListItemCard(
    property: Property,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(0.5.dp, Color.LightGray.copy(alpha = 0.6f))
    ) {
        Column {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            ) {
                if (property.mainImageUrl.isNotEmpty()) {
                    AsyncImage(
                        model = property.mainImageUrl,
                        contentDescription = property.title,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    CustomImagePlaceholder(property.category, modifier = Modifier.fillMaxSize())
                }

                // Compliance Tag (Spain regulation indicator)
                Box(
                    modifier = Modifier
                        .padding(12.dp)
                        .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .align(Alignment.TopEnd)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(if (property.complianceStatus == ComplianceStatus.CUMPLE) Color(0xFF4CAF50) else Color(0xFFFF9800))
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (property.complianceStatus == ComplianceStatus.CUMPLE) "Lincencia 🟢" else "Revisión 🟠",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }
            }

            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = property.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "${property.city}, ${property.province}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.Gray
                        )
                    }
                    RatingStars(rating = 4.9f) // Synthetic default
                }

                Spacer(modifier = Modifier.height(8.dp))
                
                Text(
                    text = "${property.maxGuests} huéspedes · ${property.bedrooms} dormitorios · ${property.beds} camas · ${property.bathrooms} baño",
                    fontSize = 12.sp,
                    color = Color.Gray
                )

                Spacer(modifier = Modifier.height(12.dp))
                Divider(color = Color.LightGray.copy(alpha = 0.5f))
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Column {
                        Text(
                            text = "${property.pricePerNightEur.toInt()} €",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(text = "por noche + limpieza", fontSize = 10.sp, color = Color.Gray)
                    }
                    Button(
                        onClick = onClick,
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 6.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Text("Ver ficha", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// --- Search and Map Results Page ---
@Composable
fun GuestSearchScreen(
    viewModel: CasaLibreViewModel,
    onNavigateToProperty: (String) -> Unit
) {
    val searchResults by viewModel.searchResults.collectAsState()
    val showMap by viewModel.showMapView.collectAsState()
    val params by viewModel.searchParams.collectAsState()
    val isSearching by viewModel.isSearching.collectAsState()

    var selectedMapProperty by remember { mutableStateOf<Property?>(null) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Search header bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Atrás")
            }
            Spacer(modifier = Modifier.width(8.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (params.destination.isNotEmpty()) params.destination else "España",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = "Búsqueda activa: ${params.guests} huéspedes" + if (params.category.isNotEmpty()) " · ${params.category}" else "",
                    fontSize = 11.sp,
                    color = Color.Gray
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            
            // Map Toggle Button
            Button(
                onClick = { viewModel.toggleMapView() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (showMap) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                modifier = Modifier.height(36.dp)
            ) {
                Icon(
                    imageVector = if (showMap) Icons.Default.List else Icons.Default.Map,
                    contentDescription = "Ver Mapa",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(if (showMap) "Lista" else "Mapa", fontSize = 12.sp)
            }
        }

        Divider()

        if (isSearching) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        } else if (searchResults.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                    Icon(Icons.Default.SearchOff, "Sin resultados", modifier = Modifier.size(64.dp), tint = Color.LightGray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("No hemos encontrado alojamientos que cumplan tus filtros.", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Intenta buscando destinos populares como Valencia, Madrid o Mallorca con menos filtros de servicios.", color = Color.Gray, textAlign = TextAlign.Center, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = { viewModel.executeSearch(SearchParams()) }) {
                        Text("Ver todos los alojamientos")
                    }
                }
            }
        } else {
            if (showMap) {
                // Map + selection sidebar experience
                Box(modifier = Modifier.fillMaxSize()) {
                    InteractiveSyntheticMap(
                        properties = searchResults,
                        selectedProperty = selectedMapProperty,
                        onPropertySelected = { prop ->
                            if (selectedMapProperty?.id == prop.id) {
                                // Double click to open property page
                                onNavigateToProperty(prop.id)
                            } else {
                                selectedMapProperty = prop
                            }
                        }
                    )
                }
            } else {
                // Classic search results listing
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp),
                    contentPadding = PaddingValues(vertical = 16.dp)
                ) {
                    item {
                        Text(
                            text = "${searchResults.size} alojamientos regulados disponibles",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.secondary,
                            fontSize = 14.sp
                        )
                    }

                    items(searchResults) { property ->
                        PropertyListItemCard(
                            property = property,
                            onClick = { onNavigateToProperty(property.id) }
                        )
                    }
                }
            }
        }
    }
}

// --- Property Detail View ---
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GuestPropertyDetailScreen(
    propertyId: String,
    viewModel: CasaLibreViewModel,
    onNavigateToChat: (String) -> Unit
) {
    val properties by viewModel.allProperties.collectAsState()
    val property = remember(properties, propertyId) { properties.find { it.id == propertyId } }
    
    if (property == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Alojamiento no disponible.")
        }
        return
    }

    var checkoutNights by remember { mutableStateOf(7) }
    var checkoutGuests by remember { mutableStateOf(2) }
    var dateStart by remember { mutableStateOf("2026-10-10") }
    var dateEnd by remember { mutableStateOf("2026-10-17") }

    val pricing = remember(property, checkoutNights) {
        viewModel.calculatePricingBreakdown(property, checkoutNights, false)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Ficha de Alojamiento", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                navigationIcon = {
                    IconButton(onClick = { viewModel.navigateBack() }) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Atrás")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleFavorite(property.id) }) {
                        Icon(
                            imageVector = Icons.Default.FavoriteBorder, // Always toggle favorites outline/filled
                            contentDescription = "Guardar",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(bottom = 32.dp)
        ) {
            // Photo Gallery banner
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .clip(RoundedCornerShape(12.dp))
                ) {
                    if (property.mainImageUrl.isNotEmpty()) {
                        AsyncImage(
                            model = property.mainImageUrl,
                            contentDescription = property.title,
                            modifier = Modifier.fillMaxSize(),
                            contentScale = ContentScale.Crop
                        )
                    } else {
                        CustomImagePlaceholder(property.category, modifier = Modifier.fillMaxSize())
                    }
                }
            }

            // Title section
            item {
                Column {
                    Text(
                        text = property.title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.secondary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocationOn, "Ubicación", tint = Color.Gray, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            "${property.city}, ${property.province} · ${property.region}",
                            fontSize = 13.sp,
                            color = Color.Gray
                        )
                    }
                }
            }

            // Host Bio Row
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f))
                ) {
                    Row(modifier = Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        ProfileAvatar(imageUrl = "", name = "Manuel Anfitrión", size = 48)
                        Spacer(modifier = Modifier.width(16.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Anfitrión verificado Casa Libre", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("Antigüedad: 2 años · Valoración: ★★★★☆ 4,9", fontSize = 11.sp, color = Color.Gray)
                        }
                        IconButton(onClick = { onNavigateToChat(property.id) }) {
                            Icon(Icons.Default.ChatBubble, "Contactar", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }

            // Description / El alojamiento
            item {
                Column {
                    Text("El alojamiento", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = property.description,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                        lineHeight = 20.sp
                    )
                }
            }

            // Services (Amenities)
            item {
                Column {
                    Text("Servicios disponibles", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    val serviceList = mutableListOf<Pair<String, Boolean>>().apply {
                        add("Wifi de alta velocidad" to property.hasWifi)
                        add("Piscina" to property.hasPool)
                        add("Aire acondicionado" to property.hasAirConditioning)
                        add("Calefacción" to property.hasHeating)
                        add("Cocina completa" to property.hasKitchen)
                        add("Lavadora" to property.hasWashingMachine)
                        add("Lavavajillas" to property.hasDishwasher)
                        add("Aparcamiento gratuito" to property.hasParking)
                        add("Admite mascotas" to property.hasPetsAllowed)
                        add("Espacio de trabajo remoto" to property.hasWorkstation)
                    }.filter { it.second }

                    if (serviceList.isEmpty()) {
                        Text("Servicios estándar incluidos.", fontSize = 13.sp, color = Color.Gray)
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            for ((serv, _) in serviceList) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.CheckCircle, "Disponible", tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(serv, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }

            // Rules
            item {
                Column {
                    Text("Normas de la casa", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.SmokeFree, "No fumar", tint = Color.Red, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Alojamiento libre de humo (prohibido fumar)", fontSize = 12.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VolumeMute, "Horario silencio", tint = Color.Blue, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Respetar horas de descanso de vecinos: 22:00h - 08:00h", fontSize = 12.sp)
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Pets, "Mascotas", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (property.hasPetsAllowed) "Mascotas admitidas con responsabilidad" else "No se admiten mascotas", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }

            // Compliance status (Spanish tourism licence)
            item {
                Column {
                    Text("Cumplimiento normativo y licencias", fontWeight = FontWeight.Bold, fontSize = 16.sp, color = MaterialTheme.colorScheme.secondary)
                    Spacer(modifier = Modifier.height(8.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.VerifiedUser, "Seguro", tint = Color(0xFF4CAF50), modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Licencia Turística Oficial:", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (property.registrationNumber.isNotEmpty()) property.registrationNumber else "Registro turístico autonómico en trámite",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                "Referencia catastral: ${property.catastroReference.ifEmpty { "Pendiente verificación" }}",
                                fontSize = 11.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }
            }

            // Interactive date duration calculator & pricing breakdown
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.5.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Calcular e iniciar reserva",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(modifier = Modifier.fillMaxWidth(), gap = 8.dp) {
                            OutlinedTextField(
                                value = dateStart,
                                onValueChange = { dateStart = it },
                                label = { Text("Llegada") },
                                modifier = Modifier.weight(1f),
                                textStyle = TextStyle(fontSize = 12.sp)
                            )
                            OutlinedTextField(
                                value = dateEnd,
                                onValueChange = { dateEnd = it },
                                label = { Text("Salida") },
                                modifier = Modifier.weight(1f),
                                textStyle = TextStyle(fontSize = 12.sp)
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Guests and Nights slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Noches de estancia:", fontSize = 13.sp, fontWeight = FontWeight.Medium)
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                IconButton(onClick = { if (checkoutNights > 1) checkoutNights-- }, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.RemoveCircleOutline, "-")
                                }
                                Text("$checkoutNights noches", modifier = Modifier.padding(horizontal = 8.dp), fontWeight = FontWeight.Bold)
                                IconButton(onClick = { checkoutNights++ }, modifier = Modifier.size(28.dp)) {
                                    Icon(Icons.Default.AddCircleOutline, "+")
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider()
                        Spacer(modifier = Modifier.height(12.dp))

                        // Price breakdown table
                        val basePriceEur = (pricing["pricePerNight"] ?: 0) / 100.0
                        val baseAmountEur = (pricing["baseAmount"] ?: 0) / 100.0
                        val cleaningEur = (pricing["cleaningFee"] ?: 0) / 100.0
                        val taxesEur = (pricing["taxesAmount"] ?: 0) / 100.0
                        val discountEur = (pricing["discountAmount"] ?: 0) / 100.0
                        val totalAmountEur = (pricing["totalAmount"] ?: 0) / 100.0

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${basePriceEur.toInt()} € x $checkoutNights noches", fontSize = 13.sp, color = Color.Gray)
                            Text("${baseAmountEur.toInt()} €", fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Gastos de limpieza (único)", fontSize = 13.sp, color = Color.Gray)
                            Text("${cleaningEur.toInt()} €", fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("IVA español (10% simplificado)", fontSize = 13.sp, color = Color.Gray)
                            Text("${taxesEur.toInt()} €", fontSize = 13.sp)
                        }

                        if (discountEur > 0) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Descuento larga estancia (10%)", fontSize = 13.sp, color = MaterialTheme.colorScheme.tertiary)
                                Text("-${discountEur.toInt()} €", fontSize = 13.sp, color = MaterialTheme.colorScheme.tertiary)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Precio Total:", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text(
                                "${totalAmountEur.toInt()} €",
                                fontWeight = FontWeight.Black,
                                fontSize = 20.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                viewModel.makeSimulatedBooking(
                                    property = property,
                                    startDate = dateStart,
                                    endDate = dateEnd,
                                    guestsCount = checkoutGuests,
                                    nights = checkoutNights,
                                    isWeekend = false
                                )
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Payment, "Pago")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Reservar y simular pago seguro")
                        }
                        Text(
                            "Sistema simulado de cobros · Nunca almacenes datos bancarios reales",
                            fontSize = 9.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.fillMaxWidth().padding(top = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

// --- Trips List and Check-In Screen ---
@Composable
fun GuestTripsScreen(
    viewModel: CasaLibreViewModel
) {
    val bookings by viewModel.guestBookings.collectAsState()
    val properties by viewModel.allProperties.collectAsState()

    var activeTab by remember { mutableStateOf(0) } // 0: Activas, 1: Historial

    Column(modifier = Modifier.fillMaxSize()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            SectionHeader(
                title = "Mis Estancias",
                subtitle = "Gestiona tus escapadas y códigos de entrada segura"
            )
        }

        TabRow(selectedTabIndex = activeTab) {
            Tab(selected = activeTab == 0, onClick = { activeTab = 0 }, text = { Text("Próximas estancias") })
            Tab(selected = activeTab == 1, onClick = { activeTab = 1 }, text = { Text("Anteriores") })
        }

        if (bookings.isEmpty()) {
            Box(modifier = Modifier.fillWeight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
                    Icon(Icons.Default.Luggage, "Luggage", modifier = Modifier.size(64.dp), tint = Color.LightGray)
                    Spacer(modifier = Modifier.height(16.dp))
                    Text("¿Aún no has reservado tu próximo viaje?", fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Descubre alojamientos únicos en toda la costa, montaña e interior de España.", color = Color.Gray, textAlign = TextAlign.Center, fontSize = 12.sp)
                }
            }
        } else {
            val filteredBookings = if (activeTab == 0) {
                bookings.filter { it.status != BookingStatus.CANCELADA && it.status != BookingStatus.FINALIZADA }
            } else {
                bookings.filter { it.status == BookingStatus.CANCELADA || it.status == BookingStatus.FINALIZADA }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                items(filteredBookings) { booking ->
                    val prop = properties.find { it.id == booking.propertyId }
                    if (prop != null) {
                        TripBookingCard(
                            booking = booking,
                            property = prop,
                            viewModel = viewModel
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun TripBookingCard(
    booking: Booking,
    property: Property,
    viewModel: CasaLibreViewModel
) {
    var expandedCheckIn by remember { mutableStateOf(false) }
    var reviewComment by remember { mutableStateOf("") }
    var cleanlinessRating by remember { mutableStateOf(5) }
    var communicationRating by remember { mutableStateOf(5) }
    var locationRating by remember { mutableStateOf(5) }
    var showReviewDialog by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column {
                    Text(
                        text = property.title,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = "${property.city} · ${booking.startDate} al ${booking.endDate}",
                        fontSize = 12.sp,
                        color = Color.Gray
                    )
                }
                
                // Badge for state machine status
                Box(
                    modifier = Modifier
                        .background(
                            when (booking.status) {
                                BookingStatus.CONFIRMADA, BookingStatus.PAGADA -> Color(0xFFE8F5E9)
                                BookingStatus.PENDIENTE -> Color(0xFFFFF3E0)
                                BookingStatus.CANCELADA -> Color(0xFFFFEBEE)
                                else -> Color(0xFFF5F5F5)
                            },
                            shape = RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = booking.status.name,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = when (booking.status) {
                            BookingStatus.CONFIRMADA, BookingStatus.PAGADA -> Color(0xFF2E7D32)
                            BookingStatus.PENDIENTE -> Color(0xFFE65100)
                            BookingStatus.CANCELADA -> Color(0xFFC62828)
                            else -> Color.DarkGray
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            Divider(color = Color.LightGray.copy(alpha = 0.4f))
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("Total abonado:", fontSize = 11.sp, color = Color.Gray)
                    Text("${booking.totalAmountEur.toInt()} €", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Código Acceso:", fontSize = 11.sp, color = Color.Gray)
                    Text(if (booking.status == BookingStatus.CONFIRMADA) booking.checkInCode else "Pendiente confirmar", fontWeight = FontWeight.Black, color = MaterialTheme.colorScheme.secondary)
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Row(modifier = Modifier.fillMaxWidth(), gap = 8.dp) {
                if (booking.status == BookingStatus.PENDIENTE) {
                    Button(
                        onClick = { viewModel.simulatePaymentConfirm(booking) },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Confirmar Pago", fontSize = 12.sp)
                    }
                } else if (booking.status == BookingStatus.CONFIRMADA) {
                    Button(
                        onClick = { expandedCheckIn = !expandedCheckIn },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                    ) {
                        Text(if (expandedCheckIn) "Ocultar Check-In" else "Instrucciones entrada", fontSize = 12.sp)
                    }
                }

                if (booking.status != BookingStatus.CANCELADA && booking.status != BookingStatus.FINALIZADA) {
                    OutlinedButton(
                        onClick = { viewModel.cancelBooking(booking) },
                        modifier = Modifier.weight(0.8f),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.Red)
                    ) {
                        Text("Cancelar", fontSize = 12.sp)
                    }
                } else if (booking.status == BookingStatus.FINALIZADA || booking.status == BookingStatus.CONFIRMADA) {
                    // Review button for guests to write feedback
                    Button(
                        onClick = { showReviewDialog = true },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary)
                    ) {
                        Text("Valorar Estancia", fontSize = 12.sp)
                    }
                }
            }

            // Expanded Check-In instructions with key code
            if (expandedCheckIn) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF9F7F4)),
                    border = BorderStroke(1.dp, Color(0xFFEDE8E2)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Guía de Entrada Autónoma", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(booking.checkInInstructions, fontSize = 12.sp, lineHeight = 16.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Tu código de teclado digital:", fontSize = 11.sp, color = Color.Gray)
                        Text(
                            text = booking.checkInCode,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            letterSpacing = 2.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }

    // Write review dialog
    if (showReviewDialog) {
        AlertDialog(
            onDismissRequest = { showReviewDialog = false },
            title = { Text("Valorar estancia en ${property.city}", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Comparte tu opinión real con otros miembros de Casa Libre. Tu valoración es muy importante.", fontSize = 12.sp, color = Color.Gray)
                    
                    OutlinedTextField(
                        value = reviewComment,
                        onValueChange = { reviewComment = it },
                        placeholder = { Text("Escribe tu comentario aquí...") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 4
                    )

                    // Ratings columns
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Limpieza: $cleanlinessRating/5", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Slider(value = cleanlinessRating.toFloat(), onValueChange = { cleanlinessRating = it.toInt() }, valueRange = 1f..5f, steps = 3)
                        
                        Text("Comunicación: $communicationRating/5", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Slider(value = communicationRating.toFloat(), onValueChange = { communicationRating = it.toInt() }, valueRange = 1f..5f, steps = 3)

                        Text("Ubicación: $locationRating/5", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Slider(value = locationRating.toFloat(), onValueChange = { locationRating = it.toInt() }, valueRange = 1f..5f, steps = 3)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.submitReview(
                            propertyId = property.id,
                            comment = reviewComment,
                            cleanliness = cleanlinessRating,
                            communication = communicationRating,
                            precision = 5,
                            location = locationRating,
                            checkIn = 5,
                            value = 5
                        )
                        showReviewDialog = false
                    }
                ) {
                    Text("Enviar Reseña")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReviewDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

// --- Live Chat Message Screen ---
@Composable
fun GuestChatScreen(
    propertyId: String,
    viewModel: CasaLibreViewModel
) {
    val messages by viewModel.activeChatMessages.collectAsState()
    val properties by viewModel.allProperties.collectAsState()
    val property = remember(properties, propertyId) { properties.find { it.id == propertyId } }

    var textInput by remember { mutableStateOf(TextFieldValue("")) }

    LaunchedEffect(propertyId) {
        viewModel.loadChatMessages(propertyId, "usuario_demo_huesped")
    }

    if (property == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Conversación no válida.")
        }
        return
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // Chat Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { viewModel.navigateBack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Atrás")
            }
            Spacer(modifier = Modifier.width(8.dp))
            ProfileAvatar(imageUrl = "", name = "Manuel Anfitrión", size = 40)
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(property.title, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("Anfitrión: Deià, Mallorca", fontSize = 11.sp, color = Color.Gray)
            }
        }

        Divider()

        // Message bubbles list
        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            items(messages) { msg ->
                val isMe = msg.senderId == "usuario_demo_huesped"
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isMe) Arrangement.End else Arrangement.Start
                ) {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (isMe) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                        ),
                        border = if (isMe) null else BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                        shape = RoundedCornerShape(
                            topStart = 12.dp,
                            topEnd = 12.dp,
                            bottomStart = if (isMe) 12.dp else 0.dp,
                            bottomEnd = if (isMe) 0.dp else 12.dp
                        ),
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Text(
                                text = msg.text,
                                fontSize = 13.sp,
                                color = if (isMe) Color.White else MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            }
        }

        // Input bar
        Divider()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                placeholder = { Text("Pregunta algo al anfitrión (llaves, wifi, etc.)...", fontSize = 12.sp) },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = MaterialTheme.colorScheme.primary)
            )
            Spacer(modifier = Modifier.width(8.dp))
            IconButton(
                onClick = {
                    if (textInput.text.isNotBlank()) {
                        viewModel.sendChatMessage(propertyId, property.hostId, textInput.text)
                        textInput = TextFieldValue("")
                    }
                },
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.primary, shape = CircleShape)
                    .size(40.dp)
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, "Enviar", tint = Color.White)
            }
        }
    }
}
