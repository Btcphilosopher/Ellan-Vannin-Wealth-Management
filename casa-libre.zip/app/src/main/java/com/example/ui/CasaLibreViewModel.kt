package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import com.example.model.*
import com.example.service.CasaIAService
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

sealed class Screen {
    object GuestHome : Screen()
    object GuestSearch : Screen()
    data class GuestPropertyDetail(val propertyId: String) : Screen()
    object GuestTrips : Screen()
    data class GuestChat(val propertyId: String) : Screen()
    object GuestFavorites : Screen()
    object GuestAccount : Screen()
    
    object HostDashboard : Screen()
    object HostProperties : Screen()
    data class HostPropertyDetail(val propertyId: String) : Screen()
    
    object OperationsDashboard : Screen()
}

class CasaLibreViewModel(application: Application) : AndroidViewModel(application) {

    private val db = CasaLibreDatabase.getDatabase(application)
    private val repository = CasaLibreRepository(db)

    // Current Screen
    private val _currentScreen = MutableStateFlow<Screen>(Screen.GuestHome)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    // Screen navigation stack
    private val screenStack = mutableListOf<Screen>(Screen.GuestHome)

    fun navigateTo(screen: Screen) {
        screenStack.add(screen)
        _currentScreen.value = screen
    }

    fun navigateBack() {
        if (screenStack.size > 1) {
            screenStack.removeAt(screenStack.size - 1)
            _currentScreen.value = screenStack.last()
        } else {
            _currentScreen.value = Screen.GuestHome
        }
    }

    // Active User (Pre-seeded with guestId "usuario_demo_huesped")
    val currentUserId = "usuario_demo_huesped"
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    // Properties state
    val allProperties: StateFlow<List<Property>> = repository.allPropertiesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Filtered/searched properties for guests
    private val _searchParams = MutableStateFlow(SearchParams())
    val searchParams: StateFlow<SearchParams> = _searchParams.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Property>>(emptyList())
    val searchResults: StateFlow<List<Property>> = _searchResults.asStateFlow()

    private val _isSearching = MutableStateFlow(false)
    val isSearching: StateFlow<Boolean> = _isSearching.asStateFlow()

    // Map vs List view on search screen
    private val _showMapView = MutableStateFlow(false)
    val showMapView: StateFlow<Boolean> = _showMapView.asStateFlow()

    // Bookings flows
    val guestBookings: StateFlow<List<Booking>> = repository.getBookingsForGuest(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val hostBookings: StateFlow<List<Booking>> = repository.getBookingsForHost("host_manuel_deia") // Manual Host demo
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allBookings: StateFlow<List<Booking>> = repository.allBookingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Chat states
    private val _activeChatMessages = MutableStateFlow<List<Message>>(emptyList())
    val activeChatMessages: StateFlow<List<Message>> = _activeChatMessages.asStateFlow()

    val allMessages: StateFlow<List<Message>> = repository.allMessagesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Favorites
    val favorites: StateFlow<List<Favourite>> = repository.getFavouritesForUser(currentUserId)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Incidents
    val allIncidents: StateFlow<List<Incident>> = repository.allIncidentsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Compliance Audits
    val complianceAudits: StateFlow<List<ComplianceAudit>> = repository.allComplianceAuditsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Casa IA state
    private val _casaIAPrompt = MutableStateFlow("")
    val casaIAPrompt: StateFlow<String> = _casaIAPrompt.asStateFlow()

    private val _casaIAIsLoading = MutableStateFlow(false)
    val casaIAIsLoading: StateFlow<Boolean> = _casaIAIsLoading.asStateFlow()

    private val _activeAuditSuggestions = MutableStateFlow<List<String>>(emptyList())
    val activeAuditSuggestions: StateFlow<List<String>> = _activeAuditSuggestions.asStateFlow()

    init {
        // Load default user profile
        viewModelScope.launch {
            _currentUser.value = repository.getUser(currentUserId)
            // Initial search seed
            executeSearch(SearchParams())
        }
    }

    // --- Search methods ---
    fun updateSearchParams(params: SearchParams) {
        _searchParams.value = params
        executeSearch(params)
    }

    fun executeSearch(params: SearchParams) {
        viewModelScope.launch {
            _isSearching.value = true
            val results = repository.searchProperties(params)
            _searchResults.value = results
            _isSearching.value = false
        }
    }

    fun toggleMapView() {
        _showMapView.value = !_showMapView.value
    }

    // --- Casa IA Natural Language Search ---
    fun processCasaIASearch(prompt: String) {
        viewModelScope.launch {
            _casaIAPrompt.value = prompt
            _casaIAIsLoading.value = true
            val parsedParams = CasaIAService.parseNaturalLanguageQuery(prompt)
            _searchParams.value = parsedParams
            executeSearch(parsedParams)
            _casaIAIsLoading.value = false
            navigateTo(Screen.GuestSearch)
        }
    }

    // --- Host Property Audit ---
    fun runPropertyAudit(property: Property) {
        viewModelScope.launch {
            val suggestions = CasaIAService.auditPropertyDescription(property)
            _activeAuditSuggestions.value = suggestions
        }
    }

    fun clearAuditSuggestions() {
        _activeAuditSuggestions.value = emptyList()
    }

    // --- Bookings management ---
    fun makeSimulatedBooking(
        property: Property,
        startDate: String,
        endDate: String,
        guestsCount: Int,
        nights: Int,
        isWeekend: Boolean
    ) {
        viewModelScope.launch {
            val breakdown = repository.calculatePrice(property, nights, isWeekend)
            val booking = Booking(
                id = "booking_${UUID.randomUUID().toString().take(6)}",
                propertyId = property.id,
                guestId = currentUserId,
                guestName = _currentUser.value?.name ?: "Tomás Soler",
                guestPhoto = _currentUser.value?.photoUrl ?: "",
                hostId = property.hostId,
                startDate = startDate,
                endDate = endDate,
                guestsCount = guestsCount,
                nightsCount = nights,
                pricePerNight = breakdown["pricePerNight"] ?: property.pricePerNight,
                baseAmount = breakdown["baseAmount"] ?: 0,
                cleaningFee = breakdown["cleaningFee"] ?: 0,
                taxesAmount = breakdown["taxesAmount"] ?: 0,
                discountAmount = breakdown["discountAmount"] ?: 0,
                totalAmount = breakdown["totalAmount"] ?: 0,
                status = BookingStatus.PENDIENTE,
                paymentStatus = PaymentStatus.AUTORIZACION,
                checkInCode = "${(1000..9999).random()}#",
                checkInInstructions = "La entrada se realiza de forma autónoma con clave. Introduce el código en el teclado del picaporte electrónico."
            )
            repository.createBooking(booking)
            navigateTo(Screen.GuestTrips)
        }
    }

    fun cancelBooking(booking: Booking) {
        viewModelScope.launch {
            val updated = booking.copy(
                status = BookingStatus.CANCELADA,
                paymentStatus = PaymentStatus.CANCELACION
            )
            repository.updateBooking(updated)
        }
    }

    fun simulatePaymentConfirm(booking: Booking) {
        viewModelScope.launch {
            val updated = booking.copy(
                status = BookingStatus.CONFIRMADA,
                paymentStatus = PaymentStatus.CAPTURA
            )
            repository.updateBooking(updated)
        }
    }

    // --- Review Creation ---
    fun submitReview(
        propertyId: String,
        comment: String,
        cleanliness: Int,
        communication: Int,
        precision: Int,
        location: Int,
        checkIn: Int,
        value: Int
    ) {
        viewModelScope.launch {
            val review = Review(
                propertyId = propertyId,
                authorName = _currentUser.value?.name ?: "Usuario Demo",
                authorPhotoUrl = _currentUser.value?.photoUrl ?: "",
                comment = comment,
                ratingCleanliness = cleanliness,
                ratingCommunication = communication,
                ratingPrecision = precision,
                ratingLocation = location,
                ratingCheckIn = checkIn,
                ratingValue = value,
                isFromGuest = true
            )
            repository.createReview(review)
        }
    }

    // --- Message handling ---
    fun loadChatMessages(propertyId: String, guestId: String) {
        viewModelScope.launch {
            repository.getChatMessages(propertyId, guestId).collect { msgs ->
                _activeChatMessages.value = msgs
            }
        }
    }

    fun sendChatMessage(propertyId: String, hostId: String, text: String) {
        viewModelScope.launch {
            val msg = Message(
                propertyId = propertyId,
                guestId = currentUserId,
                hostId = hostId,
                senderId = currentUserId,
                text = text
            )
            repository.sendMessage(msg)
        }
    }

    // --- Favorites ---
    fun toggleFavorite(propertyId: String) {
        viewModelScope.launch {
            val list = favorites.value
            val existing = list.find { it.propertyId == propertyId }
            if (existing != null) {
                repository.removeFavourite(currentUserId, propertyId)
            } else {
                repository.addFavourite(currentUserId, propertyId)
            }
        }
    }

    // --- Host Property Administration ---
    fun createHostProperty(
        title: String,
        description: String,
        category: String,
        city: String,
        province: String,
        region: String,
        priceEur: Double,
        cleaningEur: Double,
        guests: Int,
        rooms: Int,
        beds: Int,
        baths: Int,
        license: String,
        catastro: String
    ) {
        viewModelScope.launch {
            val isCompliant = license.isNotEmpty() && catastro.isNotEmpty()
            val property = Property(
                id = "prop_${UUID.randomUUID().toString().take(6)}",
                title = title,
                description = description,
                category = category,
                city = city,
                province = province,
                region = region,
                maxGuests = guests,
                bedrooms = rooms,
                beds = beds,
                bathrooms = baths,
                pricePerNight = (priceEur * 100).toInt(),
                priceWeekend = ((priceEur * 1.15) * 100).toInt(),
                cleaningFee = (cleaningEur * 100).toInt(),
                taxesAmount = ((priceEur * 0.10) * 100).toInt(),
                status = PropertyStatus.EN_REVISION,
                registrationNumber = license,
                catastroReference = catastro,
                complianceStatus = if (isCompliant) ComplianceStatus.PENDIENTE else ComplianceStatus.NO_APTO,
                complianceNotes = if (isCompliant) "Esperando revisión de la documentación autonómica por Casa Libre Operaciones." else "Faltan documentos requeridos de licencia turística para su jurisdicción.",
                hostId = "host_manuel_deia", // Demo as Manuel
                mainImageUrl = "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=600&q=80"
            )
            repository.insertProperty(property)
            navigateTo(Screen.HostProperties)
        }
    }

    fun updatePropertyStatus(property: Property, status: PropertyStatus) {
        viewModelScope.launch {
            val updated = property.copy(status = status)
            repository.updateProperty(updated)
        }
    }

    // --- Compliance Verification Operations ---
    fun approveCompliance(propertyId: String, officerName: String, notes: String) {
        viewModelScope.launch {
            val audit = ComplianceAudit(
                propertyId = propertyId,
                actionType = "APROBACION",
                officerName = officerName,
                oldStatus = ComplianceStatus.PENDIENTE,
                newStatus = ComplianceStatus.CUMPLE,
                remarks = notes
            )
            repository.createComplianceAudit(audit)
        }
    }

    fun rejectCompliance(propertyId: String, officerName: String, notes: String) {
        viewModelScope.launch {
            val audit = ComplianceAudit(
                propertyId = propertyId,
                actionType = "RECHAZO",
                officerName = officerName,
                oldStatus = ComplianceStatus.PENDIENTE,
                newStatus = ComplianceStatus.NO_APTO,
                remarks = notes
            )
            repository.createComplianceAudit(audit)
        }
    }

    fun fileIncident(bookingId: String, propertyId: String, title: String, desc: String, reporter: UserRole) {
        viewModelScope.launch {
            val incident = Incident(
                bookingId = bookingId,
                propertyId = propertyId,
                title = title,
                description = desc,
                reporterRole = reporter,
                isResolved = false
            )
            repository.createIncident(incident)
        }
    }

    fun resolveIncident(incident: Incident, notes: String) {
        viewModelScope.launch {
            val updated = incident.copy(
                isResolved = true,
                resolutionNotes = notes
            )
            repository.updateIncident(updated)
        }
    }

    fun calculatePricingBreakdown(property: Property, nights: Int, isWeekend: Boolean): Map<String, Int> {
        return repository.calculatePrice(property, nights, isWeekend)
    }
}
