/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { 
  Mine, FleetVehicle, ProcessingPlant, Stockpile, 
  GeologicalBlock, WaterBalance, WeatherCondition, Incident 
} from "../types";
import { 
  MapPin, ShieldAlert, Truck, Flame, Droplets, Zap, 
  RotateCw, LayoutGrid, Info, Eye, Activity, Hammer, CheckSquare 
} from "lucide-react";

interface DigitalTwinProps {
  mines: Mine[];
  fleet: FleetVehicle[];
  plants: ProcessingPlant[];
  stockpiles: Stockpile[];
  geology: Record<string, GeologicalBlock[]>;
  water: Record<string, WaterBalance>;
  weather: WeatherCondition;
  incidents: Incident[];
  onResolveIncident: (id: string) => void;
  selectedMineId: string | null;
  onSelectMine: (id: string | null) => void;
}

export const DigitalTwin: React.FC<DigitalTwinProps> = ({
  mines,
  fleet,
  plants,
  stockpiles,
  geology,
  water,
  weather,
  incidents,
  onResolveIncident,
  selectedMineId,
  onSelectMine
}) => {
  const [selectedBlock, setSelectedBlock] = useState<GeologicalBlock | null>(null);
  const [blockFilter, setBlockFilter] = useState<"All" | "High Grade" | "Low Grade">("All");

  const currentMine = mines.find((m) => m.id === selectedMineId);
  const activeMineIncidents = incidents.filter(
    (inc) => inc.status === "Active" && (inc.mineId === selectedMineId || inc.mineId === "all")
  );

  const mineFleet = fleet.filter((v) => v.mineId === selectedMineId);
  const minePlants = plants.filter((p) => p.mineId === selectedMineId);
  const mineStockpiles = stockpiles.filter((s) => s.mineId === selectedMineId);
  const mineWater = selectedMineId ? water[selectedMineId] : null;
  const mineBlocks = selectedMineId ? geology[selectedMineId] || [] : [];

  const filteredBlocks = mineBlocks.filter((b) => {
    if (blockFilter === "High Grade") return b.grade >= (currentMine?.headGrade || 1.0);
    if (blockFilter === "Low Grade") return b.grade < (currentMine?.headGrade || 1.0);
    return true;
  });

  return (
    <div id="digital-twin-container" className="border border-white/10 rounded-lg bg-[#0A0C10] p-5 overflow-hidden">
      {/* Control Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-white/10 pb-4 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <Activity className="w-4 h-4 text-[#F27D26]" />
            <h2 className="text-sm font-bold tracking-widest text-white uppercase">
              {selectedMineId ? `${currentMine?.name} Digital Twin` : "United States Mining Portfolio Map"}
            </h2>
          </div>
          <p className="text-[10px] text-white/50 mt-1 font-mono">
            {selectedMineId 
              ? `Real-time physical asset twin, geology matrix and haul telemetry (${currentMine?.state})` 
              : "Geographic view of asset distribution across regional resource corridors"}
          </p>
        </div>
        <div className="flex gap-2">
          {selectedMineId && (
            <button
              id="back-to-portfolio-btn"
              onClick={() => {
                onSelectMine(null);
                setSelectedBlock(null);
              }}
              className="px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 text-[10px] rounded transition-all flex items-center gap-1 font-mono uppercase"
            >
              ← USA Portfolio Map
            </button>
          )}
          <div className="flex items-center gap-1.5 bg-[#050608] border border-white/10 px-2.5 py-1 rounded">
            <span className="h-1.5 w-1.5 rounded-full bg-[#00FF41] animate-pulse" />
            <span className="text-[9px] font-mono text-[#00FF41] uppercase font-bold tracking-wider">Live SCADA Sync</span>
          </div>
        </div>
      </div>

      {/* --- USA MAP VIEW (No Mine Selected) --- */}
      {!selectedMineId && (
        <div className="relative h-[420px] bg-[#050608] rounded-lg border border-white/10 flex items-center justify-center">
          {/* Custom Stylized US Outline Grid */}
          <svg className="absolute inset-0 w-full h-full opacity-15" viewBox="0 0 800 450">
            <rect width="800" height="450" fill="none" />
            {/* Grid grid lines */}
            <path d="M 0,50 L 800,50 M 0,100 L 800,100 M 0,150 L 800,150 M 0,200 L 800,200 M 0,250 L 800,250 M 0,300 L 800,300 M 0,350 L 800,350 M 0,400 L 800,400" stroke="rgba(255,255,255,0.08)" strokeWidth="0.5" />
            <path d="M 100,0 L 100,450 M 200,0 L 200,450 M 300,0 L 300,450 M 400,0 L 400,450 M 500,0 L 500,450 M 600,0 L 600,450 M 700,0 L 700,450" stroke="rgba(255,255,255,0.08)" strokeWidth="0.5" />
            {/* US Boundary Approximations */}
            <path d="M 150,150 L 250,80 L 450,80 L 600,100 L 750,140 L 780,240 L 700,320 L 550,340 L 450,420 L 380,410 L 300,350 L 120,320 L 80,220 Z" fill="none" stroke="rgba(255,255,255,0.15)" strokeWidth="1.5" strokeDasharray="4 4" />
          </svg>

          {/* Mine Pins overlaid on USA Geography */}
          <div className="relative w-full h-full max-w-4xl">
            {/* Morenci Mine (AZ) */}
            <button 
              id="pin-morenci"
              onClick={() => onSelectMine("mine-01")}
              className="absolute left-[30%] top-[65%] group flex flex-col items-center cursor-pointer focus:outline-none"
            >
              <MapPin className="w-5 h-5 text-[#F27D26] hover:scale-125 transition-transform" />
              <span className="bg-[#0A0C10] border border-white/10 text-[9px] text-white/80 px-1.5 py-0.5 rounded mt-1 font-mono uppercase whitespace-nowrap">
                Morenci (Cu)
              </span>
            </button>

            {/* Carlin Trend (NV) */}
            <button 
              id="pin-carlin"
              onClick={() => onSelectMine("mine-02")}
              className="absolute left-[20%] top-[40%] group flex flex-col items-center cursor-pointer focus:outline-none"
            >
              <MapPin className="w-5 h-5 text-yellow-500 hover:scale-125 transition-transform animate-pulse" />
              <span className="bg-[#0A0C10] border border-white/10 text-[9px] text-white/80 px-1.5 py-0.5 rounded mt-1 font-mono uppercase whitespace-nowrap">
                Carlin Trend (Au)
              </span>
            </button>

            {/* Iron Mountain (MN) */}
            <button 
              id="pin-iron-mountain"
              onClick={() => onSelectMine("mine-03")}
              className="absolute left-[54%] top-[25%] group flex flex-col items-center cursor-pointer focus:outline-none"
            >
              <MapPin className="w-5 h-5 text-red-500 hover:scale-125 transition-transform" />
              <span className="bg-[#0A0C10] border border-white/10 text-[9px] text-white/80 px-1.5 py-0.5 rounded mt-1 font-mono uppercase whitespace-nowrap">
                Iron Mountain (Fe)
              </span>
            </button>

            {/* Cumberland (PA) */}
            <button 
              id="pin-cumberland"
              onClick={() => onSelectMine("mine-04")}
              className="absolute left-[78%] top-[38%] group flex flex-col items-center cursor-pointer focus:outline-none"
            >
              <MapPin className="w-5 h-5 text-white/40 hover:scale-125 transition-transform" />
              <span className="bg-[#0A0C10] border border-white/10 text-[9px] text-white/80 px-1.5 py-0.5 rounded mt-1 font-mono uppercase whitespace-nowrap">
                Cumberland (Coal)
              </span>
            </button>

            {/* Sweetwater (WY) */}
            <button 
              id="pin-sweetwater"
              onClick={() => onSelectMine("mine-05")}
              className="absolute left-[32%] top-[42%] group flex flex-col items-center cursor-pointer focus:outline-none"
            >
              <MapPin className="w-5 h-5 text-indigo-400 hover:scale-125 transition-transform" />
              <span className="bg-[#0A0C10] border border-white/10 text-[9px] text-white/80 px-1.5 py-0.5 rounded mt-1 font-mono uppercase whitespace-nowrap">
                Sweetwater (Li)
              </span>
            </button>

            {/* Mountain Pass (CA) */}
            <button 
              id="pin-mountain-pass"
              onClick={() => onSelectMine("mine-06")}
              className="absolute left-[16%] top-[56%] group flex flex-col items-center cursor-pointer focus:outline-none"
            >
              <MapPin className="w-5 h-5 text-[#00FF41] hover:scale-125 transition-transform" />
              <span className="bg-[#0A0C10] border border-white/10 text-[9px] text-white/80 px-1.5 py-0.5 rounded mt-1 font-mono uppercase whitespace-nowrap">
                Mountain Pass (RE)
              </span>
            </button>

            {/* Global Map Info Banner */}
            <div className="absolute bottom-4 left-4 right-4 bg-[#050608]/90 border border-white/10 p-3 rounded flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Info className="w-4 h-4 text-[#F27D26] shrink-0" />
                <span className="text-[10px] text-white/60 font-mono">
                  Select any active mining site icon on the map to zoom into its active operational layout, 3D geology block matrix, and telemetry streams.
                </span>
              </div>
              <div className="hidden md:flex gap-4 text-right">
                <div>
                  <div className="text-[9px] text-white/30 uppercase">Mines Simulated</div>
                  <div className="text-xs text-white/80 font-mono font-bold">6 Operations</div>
                </div>
                <div>
                  <div className="text-[9px] text-white/30 uppercase">Commodity Coverage</div>
                  <div className="text-xs text-white/80 font-mono font-bold">6 Strategic Base/Metals</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- DETAILED MINE SITE VIEW (Mine Selected) --- */}
      {selectedMineId && currentMine && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          
          {/* Active Stress Alarm Banner */}
          {activeMineIncidents.length > 0 && (
            <div className="col-span-12 bg-red-950/20 border border-red-500/30 p-3.5 rounded flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 animate-pulse">
              <div className="flex items-center gap-2.5">
                <ShieldAlert className="w-5 h-5 text-red-500" />
                <div>
                  <span className="text-[10px] uppercase font-mono tracking-wider font-bold text-red-400">
                    CRITICAL WARNING: ACTIVE INCIDENT REPORTED
                  </span>
                  <p className="text-[11px] text-red-300 mt-0.5 font-mono">
                    {activeMineIncidents[0].title} - {activeMineIncidents[0].location}
                  </p>
                </div>
              </div>
              <button
                id={`resolve-${activeMineIncidents[0].id}`}
                onClick={() => onResolveIncident(activeMineIncidents[0].id)}
                className="px-3 py-1 bg-red-600 hover:bg-red-500 text-white text-[10px] font-mono font-bold rounded uppercase transition"
              >
                Execute Remote Override
              </button>
            </div>
          )}

          {/* Interactive Layout Column (Geology Block Explorer & Live Schematic) */}
          <div className="col-span-12 lg:col-span-8 flex flex-col gap-5">
            
            {/* Grid 3D Block Model Section */}
            <div className="border border-white/10 bg-white/5 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-3">
                <div className="flex items-center gap-1.5">
                  <LayoutGrid className="w-4 h-4 text-[#F27D26]" />
                  <span className="text-[10px] font-bold uppercase tracking-widest text-white/80 font-mono">
                    Geological Block Model (3D Matrix)
                  </span>
                </div>
                <div className="flex items-center gap-1.5">
                  <span className="text-[9px] text-white/40 uppercase font-mono">Filter Grade:</span>
                  <select 
                    id="geology-block-grade-filter"
                    value={blockFilter}
                    onChange={(e) => setBlockFilter(e.target.value as any)}
                    className="bg-[#050608] border border-white/10 text-[9px] text-white/80 rounded px-1.5 py-0.5 font-mono focus:outline-none"
                  >
                    <option value="All">All Grades</option>
                    <option value="High Grade">≥ Head Grade</option>
                    <option value="Low Grade">&lt; Head Grade</option>
                  </select>
                </div>
              </div>

              {/* Grid representation */}
              <div className="grid grid-cols-4 sm:grid-cols-8 md:grid-cols-16 gap-1.5 bg-[#050608] p-3 rounded border border-white/10 max-h-[180px] overflow-y-auto">
                {filteredBlocks.map((blk) => {
                  const isHG = blk.grade >= currentMine.headGrade;
                  return (
                    <button
                      key={blk.id}
                      id={`block-${blk.id}`}
                      onClick={() => setSelectedBlock(blk)}
                      className={`h-9 border flex flex-col justify-between p-1 rounded text-left transition-all ${
                        selectedBlock?.id === blk.id 
                          ? "ring-1 ring-[#F27D26] border-[#F27D26] bg-[#F27D26]/10 text-white" 
                          : isHG 
                            ? "bg-[#00FF41]/5 border-[#00FF41]/20 hover:bg-[#00FF41]/10 text-[#00FF41]"
                            : "bg-[#F27D26]/5 border-[#F27D26]/15 hover:bg-[#F27D26]/10 text-[#F27D26]/80"
                      }`}
                    >
                      <span className="text-[7px] font-mono opacity-50 text-white uppercase">
                        Z{blk.coordinates.z}
                      </span>
                      <span className="text-[9px] font-bold font-mono text-center block w-full truncate">
                        {blk.grade}
                      </span>
                    </button>
                  );
                })}
              </div>
              <div className="flex justify-between items-center mt-2.5 text-[9px] text-white/40 font-mono">
                <span>Total Matched Blocks: {filteredBlocks.length} / {mineBlocks.length}</span>
                <span className="flex items-center gap-2">
                  <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 bg-[#00FF41] rounded-full"/> HG Ore</span>
                  <span className="flex items-center gap-1"><span className="h-1.5 w-1.5 bg-[#F27D26] rounded-full"/> LG Ore</span>
                </span>
              </div>
            </div>

            {/* Live Operational Layout schematic (Map representation) */}
            <div className="border border-white/10 bg-white/5 p-4 rounded-lg relative">
              <span className="text-[10px] font-bold text-white/80 uppercase tracking-widest font-mono mb-2.5 block">
                Live Shovel & Crusher Telemetry Map
              </span>

              <div className="h-[220px] bg-[#050608] border border-white/10 rounded relative overflow-hidden flex items-center justify-center">
                {/* Visual grid lines */}
                <div className="absolute inset-0 bg-[radial-gradient(rgba(255,255,255,0.05)_1px,transparent_1px)] [background-size:16px_16px] opacity-40" />

                {/* Draw Schematic elements */}
                {/* Pit Face / Loading Zone */}
                <div className="absolute left-6 top-1/2 -translate-y-1/2 border border-white/10 bg-[#0A0C10] p-2.5 rounded text-center w-28">
                  <Hammer className="w-4 h-4 mx-auto text-[#F27D26] mb-1" />
                  <span className="text-[9px] font-bold uppercase text-white font-mono">Pit Excavation</span>
                  <div className="text-[8px] text-white/40 font-mono mt-0.5">Bench 04A (Z3)</div>
                </div>

                {/* Dispatch corridor (Road) */}
                <div className="absolute left-[30%] right-[30%] top-1/2 h-8 border-y border-dashed border-white/10 bg-white/5 flex items-center justify-around overflow-hidden">
                  <div className="text-[8px] font-mono text-white/30 uppercase tracking-widest animate-pulse">Haul corridor (2.4 km)</div>
                </div>

                {/* Processing Crusher Bin */}
                <div className="absolute right-6 top-1/2 -translate-y-1/2 border border-white/10 bg-[#0A0C10] p-2.5 rounded text-center w-28">
                  <RotateCw className="w-4 h-4 mx-auto text-[#00FF41] mb-1 animate-spin" style={{ animationDuration: '6s' }} />
                  <span className="text-[9px] font-bold uppercase text-white font-mono">Crusher Bin</span>
                  <div className="text-[8px] text-white/40 font-mono mt-0.5">
                    Feed: {minePlants[0]?.feedRate || 4100} t/h
                  </div>
                </div>

                {/* Animated Vehicles flowing across path */}
                {mineFleet.map((v, idx) => {
                  // Calculate synthetic path coordinate mapping based on indices to avoid clashing
                  const pathProgress = (v.fuelLevel * 4) % 100; // Mock progression
                  const isGoingToCrusher = v.status === "Hauling" || v.status === "Dumping";
                  const leftOffset = isGoingToCrusher 
                    ? `calc(35% + ${pathProgress * 0.3}%)`
                    : `calc(65% - ${pathProgress * 0.3}%)`;
                  const topOffset = `calc(35% + ${idx * 6}px)`;

                  return (
                    <div
                      key={v.id}
                      id={`vehicle-${v.id}`}
                      className="absolute p-1 bg-[#0A0C10] border border-white/15 rounded shadow-lg flex items-center gap-1 z-10 transition-all duration-1000"
                      style={{ left: leftOffset, top: topOffset }}
                    >
                      <Truck className={`w-3.5 h-3.5 ${v.isElectric ? "text-[#00FF41]" : "text-[#F27D26]"}`} />
                      <div className="flex flex-col">
                        <span className="text-[7px] font-mono text-white/80">{v.id.split('-').pop()}</span>
                        <span className="text-[6px] font-mono text-white/40 leading-none">{v.payload}t</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

          </div>

          {/* Sidebar Inspections Column (Geological Inspector & Mine site Metrics) */}
          <div className="col-span-12 lg:col-span-4 flex flex-col gap-5">
            
            {/* Geology Block Inspector Card */}
            <div className="border border-white/10 bg-white/5 p-4 rounded-lg">
              <span className="text-[10px] font-bold text-white/80 uppercase tracking-widest mb-2.5 block flex items-center gap-1.5 font-mono">
                <Eye className="w-4 h-4 text-[#F27D26]" /> Block Property Inspector
              </span>

              {selectedBlock ? (
                <div id="block-inspector-panel" className="bg-[#050608] p-3.5 rounded border border-white/10 font-mono text-[11px] flex flex-col gap-2 text-white/80">
                  <div className="flex justify-between border-b border-white/5 pb-1.5 mb-1">
                    <span className="text-white/40 text-[9px] uppercase">Block Reference</span>
                    <span className="text-[#F27D26] font-bold">{selectedBlock.id.split('-').pop()?.toUpperCase()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Position Matrix:</span>
                    <span>X: {selectedBlock.coordinates.x} | Y: {selectedBlock.coordinates.y} | Z: {selectedBlock.coordinates.z}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Lithology / Rock:</span>
                    <span className="text-white/95">{selectedBlock.lithology}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Resource Classification:</span>
                    <span className="text-white/95">{selectedBlock.confidence}</span>
                  </div>
                  <div className="flex justify-between border-t border-white/5 pt-1.5">
                    <span className="text-white/40">Ore Grade:</span>
                    <span className="text-[#00FF41] font-bold">{selectedBlock.grade} % / gt</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Bore Density:</span>
                    <span>{selectedBlock.density} t/m³</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Contaminants (S/Si):</span>
                    <span>{selectedBlock.contaminants.sulfur}% S / {selectedBlock.contaminants.silica}% Si</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-white/40">Mill Extraction Recovery:</span>
                    <span>{selectedBlock.recovery}%</span>
                  </div>
                  <div className="flex justify-between border-t border-white/5 pt-1.5 font-bold">
                    <span className="text-white/40">Expected Block Value:</span>
                    <span className={selectedBlock.economicValue >= 0 ? "text-[#00FF41]" : "text-red-400"}>
                      ${(selectedBlock.economicValue / 1000).toFixed(1)}k USD
                    </span>
                  </div>
                </div>
              ) : (
                <div className="bg-[#050608] p-6 rounded border border-white/10 text-center text-[10px] font-mono text-white/30">
                  Click on any geological block unit on the matrix to analyze its lithology composition, ore density, and expected NPV margins.
                </div>
              )}
            </div>

            {/* Utility Stats (Water balance / Solar / Plants) */}
            <div className="border border-white/10 bg-white/5 p-4 rounded-lg flex flex-col gap-3">
              <span className="text-[10px] font-bold text-white/80 uppercase tracking-widest font-mono">
                Industrial Site Utilities
              </span>

              {/* Water Balance block */}
              {mineWater && (
                <div className="bg-[#050608] p-3 rounded border border-white/10 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Droplets className="w-4 h-4 text-[#F27D26]" />
                    <div>
                      <div className="text-[9px] text-white/40 uppercase font-mono">Water Reservoir</div>
                      <div className="text-xs text-white/90 font-mono font-bold">
                        {mineWater.reservoirLevel}% Capacity
                      </div>
                    </div>
                  </div>
                  <div className="text-right text-[9px] font-mono text-white/30">
                    <div>Recycle: 85%</div>
                    <div>Risk: {mineWater.floodRisk}</div>
                  </div>
                </div>
              )}

              {/* Energy stats */}
              <div className="bg-[#050608] p-3 rounded border border-white/10 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-500" />
                  <div>
                    <div className="text-[9px] text-white/40 uppercase font-mono">Demand / Power Source</div>
                    <div className="text-xs text-white/90 font-mono font-bold">
                      {currentMine.energyDemand} MW Peak
                    </div>
                  </div>
                </div>
                <div className="text-right text-[9px] font-mono text-white/30">
                  <div>Scope 1: {currentMine.carbonEmissions} t</div>
                  <div>Solar Grid offset: Active</div>
                </div>
              </div>

              {/* Stockpile block */}
              {mineStockpiles.length > 0 && (
                <div className="bg-[#050608] p-3 rounded border border-white/10">
                  <div className="text-[9px] text-white/40 uppercase font-mono mb-1.5">ROM Stockpiles Inventory</div>
                  {mineStockpiles.map((stock) => (
                    <div key={stock.id} className="flex justify-between items-center text-xs font-mono border-t border-white/5 py-1.5 first:border-0 first:pt-0">
                      <span className="text-white/75 truncate max-w-[150px]">{stock.name}</span>
                      <span className="text-white font-bold">{stock.tonnage.toLocaleString()} t</span>
                    </div>
                  ))}
                </div>
              )}

            </div>

          </div>

        </div>
      )}
    </div>
  );
};
