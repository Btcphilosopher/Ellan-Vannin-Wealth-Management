/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from "react";
import { 
  SimulationState, Mine, FleetVehicle, ProcessingPlant, 
  Stockpile, LogisticsRoute, EnergyGridState, WaterBalance, 
  WeatherCondition, Incident, Recommendation, GeologicalBlock 
} from "./types";
import { MetricCard } from "./components/MetricCard";
import { DigitalTwin } from "./components/DigitalTwin";
import { ExecutiveMode } from "./components/ExecutiveMode";
import { GeologyMode } from "./components/GeologyMode";
import { EngineeringMode } from "./components/EngineeringMode";
import { LogisticsMode } from "./components/LogisticsMode";
import { EconomicsMode } from "./components/EconomicsMode";
import { WhatShouldWeDo } from "./components/WhatShouldWeDo";
import { 
  Activity, ShieldAlert, Cpu, Droplets, Zap, 
  RefreshCw, TrendingUp, Compass, Award, Calendar, Layers 
} from "lucide-react";

export default function App() {
  const [simState, setSimState] = useState<SimulationState | null>(null);
  const [geologyModels, setGeologyModels] = useState<Record<string, GeologicalBlock[]>>({});
  const [selectedMineId, setSelectedMineId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"twin" | "executive" | "geology" | "engineering" | "logistics" | "economics">("twin");
  
  const [isAiLoading, setIsAiLoading] = useState(false);
  const [aiError, setAiError] = useState<string | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Recent Event Bus Logs
  const [eventLogs, setEventLogs] = useState<Array<{ id: string; time: string; event: string; type: "info" | "warn" | "success" | "alert" }>>([
    { id: "ev-1", time: new Date().toLocaleTimeString(), event: "AME authoritative data platform synced.", type: "info" },
    { id: "ev-2", time: new Date().toLocaleTimeString(), event: "Autonomous haul corridor geofencing locks verified.", type: "success" }
  ]);

  // Fetch complete portfolio and telemetry state
  const fetchState = async (silent = false) => {
    if (!silent) setIsRefreshing(true);
    try {
      const response = await fetch("/api/simulation/state");
      const data = await response.json();
      setSimState(data.simState);
      setGeologyModels(data.geologyModels);
    } catch (err) {
      console.error("Failed to connect to simulation server:", err);
    } finally {
      if (!silent) setIsRefreshing(false);
    }
  };

  useEffect(() => {
    // Initial fetch
    fetchState();

    // Fast-polling telemetry sync every 3 seconds to update trucks and energy prices
    const pollInterval = setInterval(() => {
      fetchState(true);
    }, 3000);

    return () => clearInterval(pollInterval);
  }, []);

  // Set the global optimization strategy
  const handleSetOptimizationMode = async (mode: "MAX PROFIT" | "MIN CARBON" | "BALANCED") => {
    try {
      const res = await fetch("/api/simulation/set-optimisation-mode", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ mode })
      });
      const data = await res.json();
      if (data.success) {
        fetchState();
        // Log the optimization event
        setEventLogs((prev) => [
          {
            id: `ev-${Date.now()}`,
            time: new Date().toLocaleTimeString(),
            event: `Corporate optimization target re-routed to: ${mode}`,
            type: "success"
          },
          ...prev
        ]);
      }
    } catch (err) {
      console.error("Failed to set optimization mode:", err);
    }
  };

  // Trigger simulated failures (Blizzards, power price shocks, etc.)
  const handleTriggerScenario = async (scenario: string) => {
    try {
      const res = await fetch("/api/simulation/trigger-failure", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scenario })
      });
      const data = await res.json();
      if (data.success) {
        fetchState();
        setEventLogs((prev) => [
          {
            id: `ev-${Date.now()}`,
            time: new Date().toLocaleTimeString(),
            event: `Macro scenario trigger event injected: ${scenario}`,
            type: scenario === "BASE CASE" ? "success" : "alert"
          },
          ...prev
        ]);
      }
    } catch (err) {
      console.error("Failed to trigger scenario:", err);
    }
  };

  // Resolve active incidents from control room
  const handleResolveIncident = async (id: string) => {
    try {
      const res = await fetch("/api/simulation/resolve-incident", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id })
      });
      const data = await res.json();
      if (data.success) {
        fetchState();
        setEventLogs((prev) => [
          {
            id: `ev-${Date.now()}`,
            time: new Date().toLocaleTimeString(),
            event: `Incident ${id} successfully overridden and resolved by operator override.`,
            type: "success"
          },
          ...prev
        ]);
      }
    } catch (err) {
      console.error("Failed to resolve incident:", err);
    }
  };

  // Query Gemini API Recommendation Endpoint
  const handleFetchNewRecommendation = async () => {
    setIsAiLoading(true);
    setAiError(null);
    try {
      const res = await fetch("/api/gemini/recommendation", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      const data = await res.json();
      if (res.ok && data.recommendations) {
        // Force sync state to update local list
        fetchState();
        setEventLogs((prev) => [
          {
            id: `ev-${Date.now()}`,
            time: new Date().toLocaleTimeString(),
            event: "New Gemini recommendation generated successfully.",
            type: "success"
          },
          ...prev
        ]);
      } else {
        setAiError(data.error || "Failed to compile recommendations from Gemini.");
      }
    } catch (err: any) {
      setAiError(err.message || "Failed to reach Gemini optimization server.");
    } finally {
      setIsAiLoading(false);
    }
  };

  if (!simState) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-100 font-mono">
        <Activity className="w-8 h-8 text-cyan-400 animate-spin mb-3" />
        <p className="text-xs uppercase tracking-widest text-slate-400 animate-pulse">
          Connecting to American Mining Engine Core...
        </p>
      </div>
    );
  }

  // Aggregate Key Portfolio Metrics
  const activeMinesCount = simState.mines.filter(m => m.status === "Operational").length;
  const totalProduction = simState.mines.reduce((acc, curr) => acc + curr.productionRate, 0);
  const totalEbitda = simState.mines.reduce((acc, curr) => acc + curr.ebitda, 0);
  const totalWater = simState.mines.reduce((acc, curr) => acc + curr.waterConsumption, 0);
  const totalPower = simState.mines.reduce((acc, curr) => acc + curr.energyDemand, 0);
  const activeIncidentsCount = simState.incidents.filter(inc => inc.status === "Active").length;

  return (
    <div className="min-h-screen bg-[#050608] text-[#E0E2E5] flex flex-col font-sans selection:bg-[#F27D26]/30 selection:text-white">
      
      {/* --- SCADA COMMAND NAVIGATION HEADER --- */}
      <header className="border-b border-white/10 bg-[#0A0C10] p-4 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          
          {/* Logo & Corporate Identity */}
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-[#F27D26] flex items-center justify-center font-black text-black text-xl italic shrink-0 rounded">
              AME
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono tracking-widest text-white/50 uppercase font-semibold">NORTHSTAR MINING CORP</span>
                <span className="bg-[#14171D] text-[#F27D26] text-[8px] font-mono border border-white/10 px-1.5 py-0.5 rounded uppercase">
                  v4.2.0
                </span>
              </div>
              <h1 className="text-sm font-bold tracking-widest text-white uppercase mt-0.5">
                American Mining Engine
              </h1>
            </div>
          </div>

          {/* Quick Stats Ticker */}
          <div className="hidden lg:flex items-center gap-6 font-mono text-[10px] text-white/50">
            <div>
              <div className="uppercase text-white/40">Active Mines</div>
              <div className="text-xs font-light text-white mt-0.5">{activeMinesCount} / 6 ONLINE</div>
            </div>
            <div>
              <div className="uppercase text-white/40">Power pricing</div>
              <div className="text-xs font-light text-[#00FF41] mt-0.5">${simState.energy.electricityPrice}/MWh</div>
            </div>
            <div>
              <div className="uppercase text-white/40">Sim State</div>
              <div className="text-xs font-light text-white mt-0.5 uppercase">{simState.market.scenarioName}</div>
            </div>
          </div>

          {/* Refresh Control */}
          <div className="flex items-center gap-3 self-stretch md:self-auto justify-between">
            <div className="text-[10px] font-mono text-white/40 hidden sm:block">
              LAST UPDATE: {new Date(simState.timestamp).toLocaleTimeString()}
            </div>
            <button
              id="global-refresh-btn"
              onClick={() => fetchState()}
              disabled={isRefreshing}
              className="px-3 py-1.5 bg-white/5 hover:bg-white/10 border border-white/10 text-white/80 rounded font-mono text-[10px] flex items-center gap-1.5 transition-all focus:outline-none uppercase tracking-widest"
            >
              <RefreshCw className={`w-3 h-3 ${isRefreshing ? "animate-spin text-[#F27D26]" : ""}`} />
              SYNC SCADA
            </button>
          </div>

        </div>
      </header>

      {/* --- SCADA MAIN WORKSPACE --- */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 flex flex-col gap-6">
        
        {/* --- PORTFOLIO WIDE CORE KPI METRICS --- */}
        <section id="portfolio-kpis" className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          <MetricCard
            id="kpi-production"
            title="Total Production"
            value={`${(totalProduction / 1000).toFixed(1)} kt/day`}
            subtext="Consolidated haul yield"
            icon={Activity}
            color="cyan"
          />
          <MetricCard
            id="kpi-ebitda"
            title="Revenue EBITDA"
            value={`$${(totalEbitda / 1000000).toFixed(1)}M/mo`}
            subtext="Risk-adjusted expected margin"
            icon={TrendingUp}
            color="emerald"
          />
          <MetricCard
            id="kpi-energy"
            title="Energy Grid Load"
            value={`${(totalPower / 1000).toFixed(2)} GW`}
            subtext={`Avg LMP: $${simState.energy.electricityPrice}/MWh`}
            icon={Zap}
            color="amber"
          />
          <MetricCard
            id="kpi-water"
            title="Freshwater Draw"
            value={`${totalWater.toFixed(1)} ML/day`}
            subtext="Reservoir recycling active"
            icon={Droplets}
            color="indigo"
          />
          <MetricCard
            id="kpi-incidents"
            title="Active Stress Alarms"
            value={`${activeIncidentsCount} Alerts`}
            subtext="Emergency PLC interlocks OK"
            icon={ShieldAlert}
            color={activeIncidentsCount > 0 ? "rose" : "emerald"}
          />
          <MetricCard
            id="kpi-co2"
            title="Scope Carbon"
            value={`${(simState.totalEmissionsThisYear / 1000).toFixed(1)} kt/yr`}
            subtext={`Goal: ${simState.optimizationMode}`}
            icon={Compass}
            color="yellow"
          />
        </section>

        {/* --- GEOGRAPHIC SELECTOR & SCADA MODE TABS --- */}
        <section className="flex flex-col md:flex-row justify-between items-stretch md:items-center gap-3 bg-[#0A0C10] p-2.5 rounded-lg border border-white/10">
          
          {/* Mine site selector pills */}
          <div className="flex flex-wrap gap-1.5">
            <button
              id="mine-selector-all"
              onClick={() => setSelectedMineId(null)}
              className={`px-3 py-1.5 rounded font-mono text-xs uppercase tracking-tight transition-all focus:outline-none ${
                selectedMineId === null 
                  ? "bg-[#F27D26]/10 text-[#F27D26] border border-[#F27D26]/30 font-bold" 
                  : "bg-white/5 text-white/50 border border-white/5 hover:text-white hover:bg-white/10"
              }`}
            >
              ★ Corporate Portfolio
            </button>
            {simState.mines.map((m) => (
              <button
                key={m.id}
                id={`mine-selector-${m.id}`}
                onClick={() => setSelectedMineId(m.id)}
                className={`px-3 py-1.5 rounded font-mono text-xs uppercase tracking-tight transition-all focus:outline-none ${
                  selectedMineId === m.id 
                    ? "bg-[#F27D26]/10 text-[#F27D26] border border-[#F27D26]/30 font-bold" 
                    : "bg-white/5 text-white/50 border border-white/5 hover:text-white hover:bg-white/10"
                }`}
              >
                {m.name.split(" ")[0]}
              </button>
            ))}
          </div>

          {/* Operational Modes Tab trigger */}
          <div className="flex gap-1 bg-[#050608] p-1 rounded-lg border border-white/10 overflow-x-auto">
            {[
              { id: "twin", label: "Digital Twin Map" },
              { id: "executive", label: "Executive Mode" },
              { id: "geology", label: "Geology" },
              { id: "engineering", label: "Engineering" },
              { id: "logistics", label: "Logistics" },
              { id: "economics", label: "Economics" }
            ].map((tab) => (
              <button
                key={tab.id}
                id={`tab-btn-${tab.id}`}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-3 py-1.5 rounded text-xs font-semibold uppercase tracking-tight whitespace-nowrap transition-all focus:outline-none ${
                  activeTab === tab.id 
                    ? "bg-[#14171D] text-white border border-white/5" 
                    : "text-white/40 hover:text-white/80"
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

        </section>

        {/* --- MAIN OPERATIONAL PANEL --- */}
        <section id="operational-workspace" className="min-h-[460px]">
          {activeTab === "twin" && (
            <DigitalTwin
              mines={simState.mines}
              fleet={simState.fleet}
              plants={simState.processingPlants}
              stockpiles={simState.stockpiles}
              geology={geologyModels}
              water={simState.water}
              weather={simState.weather}
              incidents={simState.incidents}
              onResolveIncident={handleResolveIncident}
              selectedMineId={selectedMineId}
              onSelectMine={setSelectedMineId}
            />
          )}

          {activeTab === "executive" && (
            <ExecutiveMode
              mines={simState.mines}
              optimizationMode={simState.optimizationMode}
              onChangeMode={handleSetOptimizationMode}
            />
          )}

          {activeTab === "geology" && (
            <GeologyMode
              mines={simState.mines}
              selectedMineId={selectedMineId}
              geology={geologyModels}
            />
          )}

          {activeTab === "engineering" && (
            <EngineeringMode
              fleet={simState.fleet}
              plants={simState.processingPlants}
              selectedMineId={selectedMineId}
            />
          )}

          {activeTab === "logistics" && (
            <LogisticsMode
              logistics={simState.logistics}
              mines={simState.mines}
            />
          )}

          {activeTab === "economics" && (
            <EconomicsMode
              market={simState.market}
              mines={simState.mines}
              onTriggerScenario={handleTriggerScenario}
            />
          )}
        </section>

        {/* --- CENTRAL RECOMMENDATION ENGINE PANEL --- */}
        <section id="recom-engine">
          <WhatShouldWeDo
            recommendations={simState.recommendations}
            onFetchNewRecommendation={handleFetchNewRecommendation}
            isLoading={isAiLoading}
            error={aiError}
          />
        </section>

        {/* --- BOTTOM SCADA TELEMETRY LOGGER & ALARM FEED --- */}
        <section id="event-feed" className="border border-white/10 bg-[#0A0C10] p-4 rounded-lg flex flex-col gap-2.5">
          <div className="flex justify-between items-center border-b border-white/10 pb-2">
            <span className="text-[10px] uppercase tracking-widest text-white/40 font-bold font-mono">
              AME System Event Logs & Alarm Feed
            </span>
            <span className="text-[9px] text-white/30 font-mono">Channel: live-telemetry-bus</span>
          </div>

          <div className="flex flex-col gap-1.5 max-h-[110px] overflow-y-auto pr-1">
            {eventLogs.map((log) => (
              <div key={log.id} className="flex gap-4 items-start text-[11px] font-mono py-1 border-b border-white/5 last:border-0">
                <span className="text-white/30 shrink-0 select-none">[{log.time}]</span>
                <span className={`h-1.5 w-1.5 rounded-full mt-1.5 shrink-0 ${
                  log.type === "success" ? "bg-[#00FF41]" :
                  log.type === "alert" ? "bg-[#F27D26] animate-pulse" :
                  log.type === "warn" ? "bg-amber-500" : "bg-blue-400"
                }`} />
                <span className="text-white/70 leading-relaxed flex-1">{log.event}</span>
              </div>
            ))}
          </div>
        </section>

      </main>

      {/* --- COMMAND FOOTER --- */}
      <footer className="border-t border-white/10 bg-[#050608] p-4 text-center text-[10px] font-mono text-white/30 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between gap-4">
          <span>NORTHSTAR MINING CORPORATION © 2026. All rights reserved.</span>
          <span>Security Classification: Strictly Confidential - Internal Operations Only</span>
        </div>
      </footer>

    </div>
  );
}
