/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Scale,
  ShieldAlert,
  Search,
  CheckCircle,
  HelpCircle,
  Clock,
  SlidersHorizontal,
  FileCheck2,
  AlertCircle
} from 'lucide-react';
import { CountryConformityRecord } from '../../types/energy';
import { EnergyComputationalEngine } from '../../services/energyEngine';

interface ProductionConformityViewProps {
  records: CountryConformityRecord[];
  onUpdateRecord?: (updatedRecord: CountryConformityRecord) => void;
}

export const ProductionConformityView: React.FC<ProductionConformityViewProps> = ({
  records,
  onUpdateRecord
}) => {
  const [selectedCountryId, setSelectedCountryId] = useState<string>(records[0]?.countryId || 'sau');
  const [filterGroup, setFilterGroup] = useState<'ALL' | 'DoC_OPEC' | 'DoC_NonOPEC'>('ALL');

  const filteredRecords = records.filter((r) => {
    if (filterGroup === 'ALL') return true;
    return r.group === filterGroup;
  });

  const selectedRecord = records.find((r) => r.countryId === selectedCountryId) || records[0];

  const totalTarget = filteredRecords.reduce((sum, r) => sum + r.targetMbd, 0);
  const totalActual = filteredRecords.reduce((sum, r) => sum + r.consensusActualMbd, 0);
  const totalDifference = Number((totalActual - totalTarget).toFixed(2));
  const overallConformity = Number(((totalActual / totalTarget) * 100).toFixed(1));
  const totalOutstandingComp = filteredRecords.reduce((sum, r) => sum + r.outstandingCompensationMbd, 0);

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-3">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
            PRODUCTION-COORDINATION // JMMC AUDIT PLATFORM
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            Production Conformity & Secondary Source Reconciliation
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            Secondary source monitoring mandates: Official filings audited against Argus, Platts, EIA, Satellite SAR & AIS tanker meter flows.
          </p>
        </div>

        {/* Group Filter segmented controls */}
        <div className="flex items-center gap-1 p-1 bg-[#121926] border border-[#233149] rounded">
          <button
            onClick={() => setFilterGroup('ALL')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
              filterGroup === 'ALL' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-[#f8fafc]'
            }`}
          >
            All Participating ({records.length})
          </button>
          <button
            onClick={() => setFilterGroup('DoC_OPEC')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
              filterGroup === 'DoC_OPEC' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-[#f8fafc]'
            }`}
          >
            OPEC Members
          </button>
          <button
            onClick={() => setFilterGroup('DoC_NonOPEC')}
            className={`px-3 py-1 text-xs font-mono rounded transition-colors ${
              filterGroup === 'DoC_NonOPEC' ? 'bg-[#2563eb] text-white font-semibold' : 'text-[#94a3b8] hover:text-[#f8fafc]'
            }`}
          >
            Non-OPEC Partners
          </button>
        </div>
      </div>

      {/* Aggregate Scorecards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div className="p-3.5 bg-[#111722] border border-[#1e293b] rounded">
          <span className="text-[10px] text-[#94a3b8] block font-mono uppercase">GROUP TARGET</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-xl font-bold font-mono text-[#f8fafc]">{totalTarget.toFixed(2)}</span>
            <span className="text-xs text-[#64748b]">mb/d</span>
          </div>
        </div>

        <div className="p-3.5 bg-[#111722] border border-[#1e293b] rounded">
          <span className="text-[10px] text-[#94a3b8] block font-mono uppercase">RECONCILED ACTUAL</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-xl font-bold font-mono text-[#f59e0b]">{totalActual.toFixed(2)}</span>
            <span className="text-xs text-[#64748b]">mb/d</span>
          </div>
        </div>

        <div className="p-3.5 bg-[#111722] border border-[#1e293b] rounded">
          <span className="text-[10px] text-[#94a3b8] block font-mono uppercase">NET DEVIATION</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className={`text-xl font-bold font-mono ${totalDifference > 0 ? 'text-[#f87171]' : 'text-[#22c55e]'}`}>
              {totalDifference > 0 ? `+${totalDifference.toFixed(2)}` : totalDifference.toFixed(2)}
            </span>
            <span className="text-xs text-[#64748b]">mb/d</span>
          </div>
        </div>

        <div className="p-3.5 bg-[#111722] border border-[#1e293b] rounded">
          <span className="text-[10px] text-[#94a3b8] block font-mono uppercase">OVERALL CONFORMITY</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-xl font-bold font-mono text-[#22c55e]">{overallConformity}%</span>
            <span className="text-xs text-[#94a3b8] font-mono">JMMC Avg</span>
          </div>
        </div>

        <div className="p-3.5 bg-[#111722] border border-[#1e293b] rounded">
          <span className="text-[10px] text-[#94a3b8] block font-mono uppercase">COMPENSATION DUE</span>
          <div className="flex items-baseline gap-1 mt-1">
            <span className="text-xl font-bold font-mono text-[#eab308]">{totalOutstandingComp.toFixed(2)}</span>
            <span className="text-xs text-[#64748b]">mb/d</span>
          </div>
        </div>
      </div>

      {/* Main Table + Detail Drawer Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Table: 7 Cols */}
        <div className="lg:col-span-7 bg-[#111722] border border-[#1e293b] rounded-lg overflow-hidden">
          <div className="p-3 bg-[#0e1420] border-b border-[#1e293b] flex items-center justify-between">
            <span className="text-xs font-semibold text-[#e2e8f0] font-mono">
              PARTICIPATING PRODUCER CONFORMITY MATRIX (MONTHLY MONITORING)
            </span>
            <span className="text-[11px] text-[#94a3b8]">Select a country to inspect secondary sources</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#121926] text-[#94a3b8] font-mono uppercase text-[10px] border-b border-[#1e293b]">
                  <th className="py-2.5 px-3">Country</th>
                  <th className="py-2.5 px-2 text-right">Baseline</th>
                  <th className="py-2.5 px-2 text-right">Target</th>
                  <th className="py-2.5 px-2 text-right">Actual</th>
                  <th className="py-2.5 px-2 text-right">Diff</th>
                  <th className="py-2.5 px-2 text-right">Conformity</th>
                  <th className="py-2.5 px-2 text-right">Comp. Due</th>
                  <th className="py-2.5 px-3 text-right">DQS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#182232] font-mono">
                {filteredRecords.map((r) => {
                  const isSelected = r.countryId === selectedCountryId;
                  return (
                    <tr
                      key={r.countryId}
                      onClick={() => setSelectedCountryId(r.countryId)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-[#1e2d42] border-l-2 border-[#38bdf8]' : 'hover:bg-[#162130]'
                      }`}
                    >
                      <td className="py-2 px-3 font-sans font-medium text-[#f1f5f9]">
                        {r.countryName}
                      </td>
                      <td className="py-2 px-2 text-right text-[#94a3b8]">{r.referenceBaselineMbd.toFixed(2)}</td>
                      <td className="py-2 px-2 text-right text-[#cbd5e1]">{r.targetMbd.toFixed(2)}</td>
                      <td className="py-2 px-2 text-right font-semibold text-[#f8fafc]">
                        {r.consensusActualMbd.toFixed(2)}
                      </td>
                      <td className="py-2 px-2 text-right">
                        <span
                          className={`px-1 rounded text-[11px] ${
                            r.differenceMbd > 0.02
                              ? 'bg-[#3b1212] text-[#f87171]'
                              : r.differenceMbd < -0.02
                              ? 'bg-[#052e16] text-[#4ade80]'
                              : 'text-[#94a3b8]'
                          }`}
                        >
                          {r.differenceMbd > 0 ? `+${r.differenceMbd.toFixed(2)}` : r.differenceMbd.toFixed(2)}
                        </span>
                      </td>
                      <td className="py-2 px-2 text-right">
                        <span
                          className={`font-semibold ${
                            r.conformityPercent >= 95
                              ? 'text-[#22c55e]'
                              : r.conformityPercent >= 70
                              ? 'text-[#eab308]'
                              : 'text-[#ef4444]'
                          }`}
                        >
                          {r.conformityPercent}%
                        </span>
                      </td>
                      <td className="py-2 px-2 text-right text-[#eab308]">
                        {r.outstandingCompensationMbd > 0 ? `${r.outstandingCompensationMbd.toFixed(2)}` : '—'}
                      </td>
                      <td className="py-2 px-3 text-right">
                        <span className="text-[10px] text-[#38bdf8] bg-[#0c243b] px-1.5 py-0.5 rounded">
                          {r.dataQualityScore}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Panel: Secondary Source Reconciliation Breakdown */}
        <div className="lg:col-span-5 bg-[#111722] border border-[#1e293b] rounded-lg p-5 space-y-5">
          <div className="pb-3 border-b border-[#1c2433] flex items-center justify-between">
            <div>
              <span className="text-[10px] text-[#d4af37] font-mono uppercase tracking-wider">
                SECONDARY SOURCE RECONCILIATION ENGINE
              </span>
              <h3 className="text-lg font-bold text-[#f8fafc] font-sans">
                {selectedRecord.countryName}
              </h3>
            </div>
            <div className="text-right">
              <span className="text-[10px] text-[#94a3b8] block">DATA QUALITY SCORE</span>
              <span className="text-base font-bold font-mono text-[#22c55e]">
                {selectedRecord.dataQualityScore} / 100
              </span>
            </div>
          </div>

          {/* Quick Metrics */}
          <div className="grid grid-cols-3 gap-2 text-xs font-mono">
            <div className="p-2.5 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block">OFFICIAL SUBMISSION</span>
              <span className="text-sm font-bold text-[#f8fafc]">
                {selectedRecord.officialSubmissionMbd.toFixed(2)} mb/d
              </span>
            </div>
            <div className="p-2.5 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block">CONSENSUS ACTUAL</span>
              <span className="text-sm font-bold text-[#38bdf8]">
                {selectedRecord.consensusActualMbd.toFixed(2)} mb/d
              </span>
            </div>
            <div className="p-2.5 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block">TARGET</span>
              <span className="text-sm font-bold text-[#cbd5e1]">
                {selectedRecord.targetMbd.toFixed(2)} mb/d
              </span>
            </div>
          </div>

          {/* Individual Secondary Feeds Audit */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-semibold text-[#94a3b8] uppercase font-mono tracking-wider">
              Independent Approved Estimator Feeds
            </h4>
            <div className="space-y-2">
              {selectedRecord.secondaryEstimates.map((est, idx) => (
                <div
                  key={idx}
                  className="p-3 bg-[#141d2a] border border-[#233149] rounded flex flex-col gap-1 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[#e2e8f0] font-sans">{est.sourceName}</span>
                    <span className="font-mono font-bold text-[#38bdf8]">{est.productionMbd.toFixed(2)} mb/d</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-[#94a3b8] font-mono">
                    <span>Method: {est.methodology}</span>
                    <span>Confidence: {est.confidence}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Compensation Schedule Details */}
          {selectedRecord.outstandingCompensationMbd > 0 && (
            <div className="p-3.5 bg-[#2a1710] border border-[#f59e0b]/40 rounded-lg text-xs space-y-2">
              <div className="flex items-center gap-2 text-[#fbbf24] font-semibold">
                <AlertCircle className="w-4 h-4" />
                <span>Formal Outstanding Compensation Plan</span>
              </div>
              <p className="text-[#fef3c7] leading-relaxed">
                Total overproduced volume accumulated: <strong className="font-mono">+{selectedRecord.overproductionMbd} mb/d</strong>.
                Required compensation balance remaining: <strong className="font-mono">{selectedRecord.outstandingCompensationMbd} mb/d</strong>.
                Allocated for daily volumetric deduction through month-end.
              </p>
            </div>
          )}

          {/* Methodology footnote */}
          <div className="text-[11px] text-[#64748b] font-mono pt-2 border-t border-[#1c2433]">
            Rule: "Never silently average incompatible datasets." Consensus is computed via outlier-trimmed median across approved secondary sources and satellite radar tank roof metrics.
          </div>
        </div>
      </div>
    </div>
  );
};
