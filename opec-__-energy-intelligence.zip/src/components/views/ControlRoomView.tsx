/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Globe2,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Scale,
  ShieldCheck,
  Ship,
  Database,
  Layers,
  ArrowRight
} from 'lucide-react';
import { EnergyCountry, CountryConformityRecord, GlobalBalanceBreakdown } from '../../types/energy';

interface ControlRoomProps {
  countries: EnergyCountry[];
  conformityRecords: CountryConformityRecord[];
  currentBalance: GlobalBalanceBreakdown;
  onSelectCountry: (country: EnergyCountry) => void;
  onNavigateTab: (tabId: string) => void;
}

export const ControlRoomView: React.FC<ControlRoomProps> = ({
  countries,
  conformityRecords,
  currentBalance,
  onSelectCountry,
  onNavigateTab
}) => {
  const overproducers = conformityRecords.filter((r) => r.isOverproducing);
  const topSpareHolders = [...countries]
    .filter((c) => c.spareCapacityMbd > 0.1)
    .sort((a, b) => b.spareCapacityMbd - a.spareCapacityMbd);

  const docParticipating = countries.filter(
    (c) => c.participationStatus === 'DoC_OPEC' || c.participationStatus === 'DoC_NonOPEC'
  );

  return (
    <div className="space-y-6">
      {/* Title & Institutional Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
              EXECUTIVE SECRETARIAT OS // REAL-TIME DIGITAL TWIN
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            Global Oil Market Control Room
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            OBSERVATION VINTAGE: 2026-Q3 • HARMONISED DATASET: MOMR-ASB-DOC • VIENNA HEADQUARTERS
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigateTab('POLICY_LAB')}
            className="px-3.5 py-1.5 bg-[#172554] hover:bg-[#1e3a8a] text-[#bfdbfe] border border-[#2563eb]/40 rounded text-xs font-medium transition-colors flex items-center gap-1.5"
          >
            <Layers className="w-3.5 h-3.5" />
            Launch Policy Lab
          </button>
          <button
            onClick={() => onNavigateTab('AI_SECRETARIAT')}
            className="px-3.5 py-1.5 bg-[#2a2410] hover:bg-[#3d3314] text-[#fef08a] border border-[#d4af37]/40 rounded text-xs font-medium transition-colors flex items-center gap-1.5"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-[#d4af37]" />
            Secretariat Intelligence AI
          </button>
        </div>
      </div>

      {/* Primary Global Supply/Demand Balance Waterfall Block */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-4 pb-3 border-b border-[#1c2433] gap-2">
          <div className="flex items-center gap-2">
            <Scale className="w-4 h-4 text-[#38bdf8]" />
            <h2 className="text-sm font-semibold tracking-wider text-[#e2e8f0] uppercase">
              Global Supply / Demand Physical Balance (Q3-2026)
            </h2>
          </div>
          <span className="text-xs font-mono text-[#94a3b8]">
            Formulation: Balance = Total Supply ({currentBalance.totalWorldSupplyMbd} mb/d) - World Demand ({currentBalance.worldDemandMbd} mb/d)
          </span>
        </div>

        {/* Visual Balance Bar */}
        <div className="space-y-4">
          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#94a3b8]">WORLD LIQUIDS DEMAND</span>
              <span className="font-semibold text-[#f8fafc]">{currentBalance.worldDemandMbd} mb/d</span>
            </div>
            <div className="w-full bg-[#1a2332] h-4 rounded-sm overflow-hidden flex">
              <div
                style={{ width: '100%' }}
                className="bg-gradient-to-r from-[#0284c7] to-[#38bdf8] h-full flex items-center justify-end px-2 text-[10px] font-mono text-white font-bold"
              >
                100% Demand
              </div>
            </div>
          </div>

          <div className="space-y-1.5">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-[#94a3b8]">
                WORLD LIQUIDS SUPPLY (Non-DoC {currentBalance.nonDocLiquidsSupplyMbd} + DoC NGLs {currentBalance.docNglAndNonConvMbd} + DoC Crude {currentBalance.actualDocCrudeMbd})
              </span>
              <span className="font-semibold text-[#f8fafc]">{currentBalance.totalWorldSupplyMbd} mb/d</span>
            </div>
            <div className="w-full bg-[#1a2332] h-4 rounded-sm overflow-hidden flex">
              <div
                style={{ width: `${(currentBalance.nonDocLiquidsSupplyMbd / currentBalance.totalWorldSupplyMbd) * 100}%` }}
                className="bg-[#475569] h-full flex items-center justify-center text-[9px] font-mono text-[#cbd5e1] border-r border-[#111722]"
                title="Non-DoC Liquids"
              >
                Non-DoC 55.6
              </div>
              <div
                style={{ width: `${(currentBalance.docNglAndNonConvMbd / currentBalance.totalWorldSupplyMbd) * 100}%` }}
                className="bg-[#0f766e] h-full flex items-center justify-center text-[9px] font-mono text-[#ccfbf1] border-r border-[#111722]"
                title="DoC NGLs & Non-Conventional"
              >
                DoC NGL 8.4
              </div>
              <div
                style={{ width: `${(currentBalance.actualDocCrudeMbd / currentBalance.totalWorldSupplyMbd) * 100}%` }}
                className="bg-[#d97706] h-full flex items-center justify-center text-[9px] font-mono text-white font-bold"
                title="Participating DoC Crude"
              >
                DoC Crude 42.8
              </div>
            </div>
          </div>

          {/* Institutional Balance Equation Card */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 pt-3">
            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block font-mono">WORLD DEMAND</span>
              <span className="text-lg font-bold font-mono text-[#f8fafc]">{currentBalance.worldDemandMbd}</span>
              <span className="text-[10px] text-[#64748b] ml-1">mb/d</span>
            </div>

            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block font-mono">CALL ON PARTICIPATING CRUDE</span>
              <span className="text-lg font-bold font-mono text-[#38bdf8]">{currentBalance.callOnDocCrudeMbd}</span>
              <span className="text-[10px] text-[#64748b] ml-1">mb/d</span>
              <p className="text-[9px] text-[#64748b] mt-0.5">Demand - NonDoC - NGLs</p>
            </div>

            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block font-mono">ACTUAL PARTICIPATING OUTPUT</span>
              <span className="text-lg font-bold font-mono text-[#f59e0b]">{currentBalance.actualDocCrudeMbd}</span>
              <span className="text-[10px] text-[#64748b] ml-1">mb/d</span>
              <p className="text-[9px] text-[#64748b] mt-0.5">Reconciled Secondary Sources</p>
            </div>

            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block font-mono">NET GLOBAL BALANCE</span>
              <div className="flex items-baseline gap-1">
                <span className={`text-lg font-bold font-mono ${currentBalance.netBalanceMbd >= 0 ? 'text-[#38bdf8]' : 'text-[#f87171]'}`}>
                  {currentBalance.netBalanceMbd > 0 ? `+${currentBalance.netBalanceMbd}` : currentBalance.netBalanceMbd}
                </span>
                <span className="text-[10px] text-[#64748b]">mb/d</span>
              </div>
              <p className="text-[9px] text-[#94a3b8] mt-0.5">
                {currentBalance.netBalanceMbd >= 0 ? 'Commercial inventory accumulation pace' : 'Commercial inventory depletion pace'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Coordination & Monitoring Status + Secondary Source Reconciled Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Overproducers & Compensation Watch */}
        <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-[#1c2433]">
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-[#f59e0b]" />
                <h3 className="text-xs font-semibold tracking-wider text-[#e2e8f0] uppercase">
                  JMMC Compensation & Deviation Watch
                </h3>
              </div>
              <button
                onClick={() => onNavigateTab('PRODUCTION_CONFORMITY')}
                className="text-[11px] text-[#38bdf8] hover:underline flex items-center gap-0.5"
              >
                Full Matrix <ArrowRight className="w-3 h-3" />
              </button>
            </div>

            <div className="space-y-2.5">
              {overproducers.map((op) => (
                <div
                  key={op.countryId}
                  className="p-2.5 bg-[#17202e] border border-[#253347] rounded flex items-center justify-between"
                >
                  <div>
                    <div className="flex items-center gap-1.5">
                      <span className="font-semibold text-xs text-[#f1f5f9]">{op.countryName}</span>
                      <span className="text-[10px] font-mono text-[#f87171] bg-[#450a0a] px-1 py-0.2 rounded">
                        +{op.overproductionMbd} mb/d
                      </span>
                    </div>
                    <span className="text-[10px] text-[#94a3b8] font-mono">
                      Target: {op.targetMbd} mb/d | Actual: {op.consensusActualMbd} mb/d
                    </span>
                  </div>

                  <div className="text-right">
                    <span className="text-[10px] text-[#94a3b8] block">Compensation Due</span>
                    <span className="text-xs font-mono font-semibold text-[#f59e0b]">
                      {op.outstandingCompensationMbd} mb/d
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1c2433] text-[11px] text-[#94a3b8]">
            <p>
              Under JMMC Decision 84/3, compensation volumes are scheduled across Q4-2026 to bring cumulative deviation to zero.
            </p>
          </div>
        </div>

        {/* Global Spare Capacity Concentration */}
        <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-[#1c2433]">
              <div className="flex items-center gap-2">
                <Database className="w-4 h-4 text-[#d4af37]" />
                <h3 className="text-xs font-semibold tracking-wider text-[#e2e8f0] uppercase">
                  Sustainable Spare Capacity
                </h3>
              </div>
              <span className="text-[11px] font-mono text-[#d4af37] font-semibold">
                Total: 4.87 mb/d
              </span>
            </div>

            <div className="space-y-2">
              {topSpareHolders.slice(0, 4).map((c) => (
                <div
                  key={c.id}
                  onClick={() => onSelectCountry(c)}
                  className="p-2 bg-[#17202e] hover:bg-[#1f2c3f] border border-[#253347] rounded flex items-center justify-between cursor-pointer transition-colors"
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">{c.flagEmoji}</span>
                    <div>
                      <span className="text-xs font-medium text-[#f1f5f9]">{c.name}</span>
                      <span className="text-[10px] text-[#64748b] block font-mono">
                        Sustainable: {c.sustainableCapacityMbd} mb/d
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-xs font-mono font-bold text-[#d4af37]">
                      {c.spareCapacityMbd.toFixed(2)} mb/d
                    </span>
                    <span className="text-[9px] text-[#64748b] block">Operable ≤30d</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-[#1c2433] text-[11px] text-[#64748b] font-mono">
            Note: Spare capacity excludes offline planned maintenance and damaged field infrastructure.
          </div>
        </div>

        {/* Secondary Source Provenance Audit */}
        <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-4 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-2.5 mb-3 border-b border-[#1c2433]">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-[#22c55e]" />
                <h3 className="text-xs font-semibold tracking-wider text-[#e2e8f0] uppercase">
                  Data Quality & Source Engine
                </h3>
              </div>
              <span className="text-[10px] font-mono text-[#22c55e] bg-[#052e16] px-1.5 py-0.5 rounded border border-[#22c55e]/30">
                SCORE: 94 / 100
              </span>
            </div>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-1 border-b border-[#1c2433]">
                <span className="text-[#94a3b8]">Approved Secondary Sources</span>
                <span className="font-mono text-[#e2e8f0]">6 Agencies</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1c2433]">
                <span className="text-[#94a3b8]">Satellite Synthetic Aperture Radar</span>
                <span className="font-mono text-[#38bdf8]">Live GaUGING Active</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1c2433]">
                <span className="text-[#94a3b8]">Tanker AIS Discharge Reconciliation</span>
                <span className="font-mono text-[#e2e8f0]">98.2% Corroborated</span>
              </div>
              <div className="flex justify-between py-1 border-b border-[#1c2433]">
                <span className="text-[#94a3b8]">Average Secondary Spread</span>
                <span className="font-mono text-[#e2e8f0]">±0.06 mb/d</span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-[#94a3b8]">Latest Revision Cycle</span>
                <span className="font-mono text-[#94a3b8]">2026-10-04 06:00 UTC</span>
              </div>
            </div>
          </div>

          <button
            onClick={() => onNavigateTab('QUANT_DEVELOPER')}
            className="w-full mt-4 py-1.5 bg-[#16202f] hover:bg-[#1e2a3c] text-[#38bdf8] text-xs font-mono rounded border border-[#24354c] transition-colors"
          >
            Inspect Audit Trails & Registry →
          </button>
        </div>
      </div>

      {/* Sovereign Country Master Table (Quick analytical scan) */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg overflow-hidden">
        <div className="px-5 py-3 border-b border-[#1e293b] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-[#d4af37]" />
            <h3 className="text-xs font-semibold tracking-wider text-[#e2e8f0] uppercase">
              Participating Producers Scorecard (Declaration of Cooperation)
            </h3>
          </div>
          <span className="text-xs text-[#94a3b8] font-mono">
            Click any country row for field-level digital twin and infrastructure
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#0e1420] text-[#94a3b8] font-mono uppercase text-[10px] border-b border-[#1e293b]">
                <th className="py-2.5 px-4 font-semibold">Country</th>
                <th className="py-2.5 px-3 font-semibold">Status</th>
                <th className="py-2.5 px-3 font-semibold text-right">Reference Baseline</th>
                <th className="py-2.5 px-3 font-semibold text-right">Required Target</th>
                <th className="py-2.5 px-3 font-semibold text-right">Actual Crude</th>
                <th className="py-2.5 px-3 font-semibold text-right">Deviation</th>
                <th className="py-2.5 px-3 font-semibold text-right">Sustainable Cap.</th>
                <th className="py-2.5 px-3 font-semibold text-right">Spare Cap.</th>
                <th className="py-2.5 px-4 font-semibold text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#182232] font-mono">
              {docParticipating.map((c) => {
                const conf = conformityRecords.find((r) => r.countryId === c.id);
                const dev = conf ? conf.differenceMbd : 0;
                return (
                  <tr
                    key={c.id}
                    onClick={() => onSelectCountry(c)}
                    className="hover:bg-[#162130] cursor-pointer transition-colors"
                  >
                    <td className="py-2 px-4 flex items-center gap-2 font-sans font-medium text-[#f1f5f9]">
                      <span>{c.flagEmoji}</span>
                      <span>{c.name}</span>
                    </td>
                    <td className="py-2 px-3 text-[#94a3b8] text-[11px]">
                      {c.membershipStatus}
                    </td>
                    <td className="py-2 px-3 text-right text-[#cbd5e1]">{c.referenceBaselineMbd.toFixed(2)}</td>
                    <td className="py-2 px-3 text-right text-[#cbd5e1]">{c.targetMbd.toFixed(2)}</td>
                    <td className="py-2 px-3 text-right font-semibold text-[#f8fafc]">
                      {c.crudeProductionMbd.toFixed(2)}
                    </td>
                    <td className="py-2 px-3 text-right">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[11px] ${
                          dev > 0.02
                            ? 'bg-[#3b1212] text-[#f87171]'
                            : dev < -0.02
                            ? 'bg-[#052e16] text-[#4ade80]'
                            : 'text-[#94a3b8]'
                        }`}
                      >
                        {dev > 0 ? `+${dev.toFixed(2)}` : dev.toFixed(2)}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-right text-[#cbd5e1]">{c.sustainableCapacityMbd.toFixed(2)}</td>
                    <td className="py-2 px-3 text-right font-semibold text-[#d4af37]">
                      {c.spareCapacityMbd.toFixed(2)}
                    </td>
                    <td className="py-2 px-4 text-right">
                      <span className="text-[11px] text-[#38bdf8] font-sans hover:underline">
                        Profile →
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
