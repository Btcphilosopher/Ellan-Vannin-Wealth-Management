/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Code2,
  Terminal,
  Cpu,
  Database,
  Play,
  FileCode,
  ShieldCheck,
  CheckCircle,
  Copy
} from 'lucide-react';
import { AuditTrailEntry } from '../../types/energy';

interface QuantPlatformProps {
  auditLogs: AuditTrailEntry[];
}

export const QuantPlatformView: React.FC<QuantPlatformProps> = ({ auditLogs }) => {
  const [activeLang, setActiveLang] = useState<'R' | 'PYTHON' | 'RUST' | 'API' | 'AUDIT'>('R');
  const [executionOutput, setExecutionOutput] = useState<string | null>(null);
  const [isExecuting, setIsExecuting] = useState<boolean>(false);

  const rCodeSnippet = `# energyR Institutional Research Suite
library(energyR)
library(vars)

# Ingest and Reconcile Current World Oil Balance
current_bal <- energyR::oil_balance(vintage = "2026-Q3")
print(current_bal)

# Estimate Econometric SVAR on Monthly Supply Shocks vs Brent Spot
svar_model <- energyR::oil_svar(
  endogenous = c("doc_crude", "world_demand", "oecd_stocks", "brent_price"),
  lags = 4,
  identification = "cholesky"
)

# Compute 12-Month Impulse Response Function
irf_results <- energyR::oil_irf(svar_model, impulse = "doc_crude", response = "brent_price", n.ahead = 12)
plot(irf_results, main = "Brent Spot Response to -1.0 mb/d DoC Supply Shock")`;

  const pythonSnippet = `from energy_intelligence import EnergyClient
import polars as pl

# Connect to Vienna Secretariat Gateway
energy = EnergyClient(gateway="https://secretariat.energy.org/api/v1")

# Fetch Reconciled Secondary Source Conformity Matrix
conformity_df = energy.conformity(period="2026-Q3")
print(conformity_df.filter(pl.col("is_overproducing") == True))

# Run Monte Carlo Policy Simulation for 500k Unwind
sim_output = energy.scenario(
  production_delta_mbd=0.50,
  demand_shock_percent=0.0,
  monte_carlo_draws=100000
)
print('Projected Brent Spot: $' + str(round(sim_output.p50_brent, 2)) + '/bbl (CI: $' + str(round(sim_output.p10_brent, 2)) + ' - $' + str(round(sim_output.p90_brent, 2)) + ')')`;

  const rustSnippet = `// energy-core: Sovereign High-Throughput Engine (Rust 2024 Edition)
use energy_core::production::{CountryMaster, ConformityEngine};
use energy_core::balance::WorldOilBalance;
use rayon::prelude::*;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let dataset = WorldOilBalance::load_vintage("2026-Q3")?;
    
    // Parallel Monte Carlo simulation of 1,000,000 production scenarios
    let results: Vec<_> = (0..1_000_000).into_par_iter().map(|seed| {
        dataset.simulate_equilibrium(seed)
    }).collect();
    
    println!("Computed 1,000,000 scenario paths in 14.2ms across 32 Rayon threads.");
    Ok(())
}`;

  const handleRunScript = () => {
    setIsExecuting(true);
    setExecutionOutput(null);
    setTimeout(() => {
      setIsExecuting(false);
      if (activeLang === 'R') {
        setExecutionOutput(`> energyR::oil_balance(vintage = "2026-Q3")
           Period WorldDemand NonDoCLiquids DoCNGLs CallOnDoC ActualDoC NetBalance
1 2026-Q3 (Curr)       106.40          55.60     8.38     42.42     42.82      +0.40

> SVAR Estimation converged in 6 iterations. Log-likelihood: -148.32
Impulse Response (doc_crude -> brent_price):
  Q0: +$0.00/bbl  |  Q+1: +$7.82/bbl  |  Q+2: +$6.94/bbl  |  Q+4: +$4.10/bbl
Stationarity Verified: Augmented Dickey-Fuller p < 0.001 (Cointegrated)`);
      } else if (activeLang === 'PYTHON') {
        setExecutionOutput(`shape: (3, 6)
┌────────────┬───────────┬────────┬──────────┬─────────────┬─────────────────┐
│ country    ┆ target_mb ┆ actual ┆ diff_mbd ┆ conformity% ┆ comp_due_mbd    │
│ ---        ┆ ---       ┆ ---    ┆ ---      ┆ ---         ┆ ---             │
│ Iraq       ┆ 4.00      ┆ 4.18   ┆ +0.18    ┆ 58.1%       ┆ 0.18            │
│ Russia     ┆ 8.98      ┆ 9.06   ┆ +0.08    ┆ 90.6%       ┆ 0.08            │
│ Kazakhstan ┆ 1.47      ┆ 1.56   ┆ +0.09    ┆ 43.8%       ┆ 0.09            │
└────────────┴───────────┴────────┴──────────┴─────────────┴─────────────────┘
Projected Brent Spot: $67.80/bbl (CI: $63.20 - $72.40)`);
      } else if (activeLang === 'RUST') {
        setExecutionOutput(`Finished release [optimized + lto] target(s) in 0.08s
Running \`target/release/energy-core\`
[INFO  energy_core::balance] Loaded vintage 2026-Q3 (18,420 field twins active)
[INFO  energy_core::simulation] Rayon threadpool initialized with 32 workers
Computed 1,000,000 scenario paths in 14.2ms across 32 Rayon threads.
Memory footprint: 4.8 MB resident. Invariant checks passed: 100.00%`);
      }
    }, 600);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-3">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
            RESEARCH PLATFORM // QUANT & PROGRAMMATIC ACCESS
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            energyR Econometric Suite, Python SDK & Rust Engine
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            Direct programmatic interfaces for sovereign energy econometricians and quantitative researchers.
          </p>
        </div>

        <button
          onClick={handleRunScript}
          disabled={isExecuting || activeLang === 'API' || activeLang === 'AUDIT'}
          className="px-3.5 py-1.5 bg-[#2563eb] hover:bg-[#1d4ed8] disabled:opacity-50 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors"
        >
          <Play className="w-3.5 h-3.5" />
          <span>{isExecuting ? 'Running Model...' : 'Execute Script'}</span>
        </button>
      </div>

      {/* Language / Interface Selector */}
      <div className="flex border-b border-[#233149] gap-4 text-xs font-mono">
        <button
          onClick={() => { setActiveLang('R'); setExecutionOutput(null); }}
          className={`pb-2.5 font-semibold transition-colors border-b-2 ${
            activeLang === 'R' ? 'border-[#38bdf8] text-[#38bdf8]' : 'border-transparent text-[#94a3b8] hover:text-[#cbd5e1]'
          }`}
        >
          energyR (R Econometrics)
        </button>
        <button
          onClick={() => { setActiveLang('PYTHON'); setExecutionOutput(null); }}
          className={`pb-2.5 font-semibold transition-colors border-b-2 ${
            activeLang === 'PYTHON' ? 'border-[#38bdf8] text-[#38bdf8]' : 'border-transparent text-[#94a3b8] hover:text-[#cbd5e1]'
          }`}
        >
          energy_intelligence (Python SDK)
        </button>
        <button
          onClick={() => { setActiveLang('RUST'); setExecutionOutput(null); }}
          className={`pb-2.5 font-semibold transition-colors border-b-2 ${
            activeLang === 'RUST' ? 'border-[#38bdf8] text-[#38bdf8]' : 'border-transparent text-[#94a3b8] hover:text-[#cbd5e1]'
          }`}
        >
          energy-core (Rust Engine)
        </button>
        <button
          onClick={() => { setActiveLang('API'); setExecutionOutput(null); }}
          className={`pb-2.5 font-semibold transition-colors border-b-2 ${
            activeLang === 'API' ? 'border-[#38bdf8] text-[#38bdf8]' : 'border-transparent text-[#94a3b8] hover:text-[#cbd5e1]'
          }`}
        >
          REST API v1 Explorer
        </button>
        <button
          onClick={() => { setActiveLang('AUDIT'); setExecutionOutput(null); }}
          className={`pb-2.5 font-semibold transition-colors border-b-2 ${
            activeLang === 'AUDIT' ? 'border-[#38bdf8] text-[#38bdf8]' : 'border-transparent text-[#94a3b8] hover:text-[#cbd5e1]'
          }`}
        >
          Audit Logs & Provenance
        </button>
      </div>

      {/* Code Editor Box */}
      {(activeLang === 'R' || activeLang === 'PYTHON' || activeLang === 'RUST') && (
        <div className="space-y-4">
          <div className="bg-[#090d14] border border-[#1e293b] rounded-lg overflow-hidden font-mono text-xs">
            <div className="bg-[#121926] px-4 py-2 border-b border-[#1e293b] flex justify-between items-center text-[#94a3b8]">
              <span>
                {activeLang === 'R' ? 'analysis_svar.R' : activeLang === 'PYTHON' ? 'client_script.py' : 'src/main.rs'}
              </span>
              <span className="text-[10px] text-[#64748b]">ReadOnly Institutional Script</span>
            </div>
            <pre className="p-4 text-[#e2e8f0] overflow-x-auto leading-relaxed">
              {activeLang === 'R' ? rCodeSnippet : activeLang === 'PYTHON' ? pythonSnippet : rustSnippet}
            </pre>
          </div>

          {/* Execution Console Output */}
          {executionOutput && (
            <div className="bg-[#0a0f18] border border-[#22c55e]/40 rounded-lg p-4 font-mono text-xs space-y-2">
              <div className="flex items-center gap-2 text-[#22c55e] text-[11px] font-semibold">
                <CheckCircle className="w-3.5 h-3.5" />
                <span>EXECUTION COMPLETED SUCCESSFULLY (EXIT CODE 0)</span>
              </div>
              <pre className="text-[#a7f3d0] whitespace-pre-wrap leading-relaxed">
                {executionOutput}
              </pre>
            </div>
          )}
        </div>
      )}

      {/* API Explorer */}
      {activeLang === 'API' && (
        <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-5 space-y-4">
          <div className="pb-3 border-b border-[#1c2433]">
            <h3 className="text-xs font-semibold text-[#f8fafc] font-mono uppercase tracking-wider">
              Secretariat REST API v1 Catalog
            </h3>
            <p className="text-xs text-[#94a3b8] mt-1">
              Standard JSON endpoints with HTTP status codes and ISO 8601 timestamps.
            </p>
          </div>

          <div className="space-y-2 font-mono text-xs">
            {[
              { method: 'GET', endpoint: '/api/v1/countries', desc: 'Returns all 200+ sovereign country master records with reserves and capacity.' },
              { method: 'GET', endpoint: '/api/v1/conformity', desc: 'Reconciled secondary source estimates and JMMC conformity percentages.' },
              { method: 'GET', endpoint: '/api/v1/balance', desc: 'Quarterly supply/demand balance series and call on DoC crude.' },
              { method: 'GET', endpoint: '/api/v1/inventories', desc: 'OECD commercial, strategic and floating stock metrics vs 5Y average.' },
              { method: 'GET', endpoint: '/api/v1/on-water', desc: 'AIS satellite crude cargo tracking with vessel classes and destinations.' },
              { method: 'POST', endpoint: '/api/v1/scenarios/simulate', desc: 'Runs policy simulation of volumetric quota shifts and demand shocks.' },
              { method: 'POST', endpoint: '/api/ai/ask', desc: 'Executes verified Gemini AI query with strict dataset citations.' }
            ].map((ep, idx) => (
              <div key={idx} className="p-3 bg-[#131b28] border border-[#233149] rounded flex flex-col md:flex-row md:items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${ep.method === 'GET' ? 'bg-[#0369a1] text-white' : 'bg-[#0f766e] text-white'}`}>
                    {ep.method}
                  </span>
                  <span className="text-[#38bdf8] font-bold">{ep.endpoint}</span>
                </div>
                <span className="text-[#cbd5e1] font-sans text-xs">{ep.desc}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Audit Logs */}
      {activeLang === 'AUDIT' && (
        <div className="bg-[#111722] border border-[#1e293b] rounded-lg overflow-hidden">
          <div className="p-4 bg-[#0e1420] border-b border-[#1e293b] flex items-center justify-between">
            <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
              Secretariat Immutable Data Ingestion & Action Audit Trail
            </h3>
            <span className="text-[11px] text-[#64748b] font-mono">
              Every published number is reproducible
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs font-mono">
              <thead>
                <tr className="bg-[#121926] text-[#94a3b8] uppercase text-[10px] border-b border-[#1e293b]">
                  <th className="py-2.5 px-4">Timestamp (UTC)</th>
                  <th className="py-2.5 px-3">Role</th>
                  <th className="py-2.5 px-3">Operator</th>
                  <th className="py-2.5 px-3">Action</th>
                  <th className="py-2.5 px-3">Dataset</th>
                  <th className="py-2.5 px-4">Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#182232]">
                {auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-[#162130]">
                    <td className="py-2.5 px-4 text-[#94a3b8]">{log.timestamp}</td>
                    <td className="py-2.5 px-3 text-[#38bdf8]">{log.userRole}</td>
                    <td className="py-2.5 px-3 font-sans text-[#f1f5f9]">{log.userName}</td>
                    <td className="py-2.5 px-3 font-semibold text-[#f8fafc]">{log.action}</td>
                    <td className="py-2.5 px-3 text-[#d4af37]">{log.dataset}</td>
                    <td className="py-2.5 px-4 font-sans text-[#cbd5e1]">{log.details}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
