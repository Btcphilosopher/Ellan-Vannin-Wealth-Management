/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Database,
  Ship,
  Navigation,
  Compass,
  Anchor,
  TrendingDown,
  Layers,
  ArrowRight
} from 'lucide-react';
import {
  InventoryMetrics,
  OilOnWaterCargo,
  TankerMarketMetrics,
  TradeFlowRoute
} from '../../types/energy';

interface InventoriesShippingProps {
  inventories: InventoryMetrics[];
  cargoes: OilOnWaterCargo[];
  tankers: TankerMarketMetrics[];
  tradeFlows: TradeFlowRoute[];
}

export const InventoriesShippingView: React.FC<InventoriesShippingProps> = ({
  inventories,
  cargoes,
  tankers,
  tradeFlows
}) => {
  const oecdTotal = inventories[0];
  const totalOnWaterMb = cargoes.reduce((sum, c) => sum + c.volumeMillionBbl, 0);

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-3">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
            INVENTORY & SHIPPING // GLOBAL STOCK COVER & SEABORNE FLOWS
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            Global Inventories, Tanker Fleet & Oil On Water
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            Forward days of supply relative to 5-year benchmark and satellite AIS telemetry of crude in transit.
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="bg-[#111722] px-3 py-1.5 border border-[#1e293b] rounded">
            <span className="text-[#94a3b8]">TRACKED ON WATER:</span>{' '}
            <strong className="text-[#38bdf8]">{totalOnWaterMb.toFixed(2)} million bbl</strong>
          </div>
          <div className="bg-[#111722] px-3 py-1.5 border border-[#1e293b] rounded">
            <span className="text-[#94a3b8]">OECD FORWARD COVER:</span>{' '}
            <strong className="text-[#f87171]">{oecdTotal.daysOfForwardCover} days ({oecdTotal.daysDeviation}d vs 5Y)</strong>
          </div>
        </div>
      </div>

      {/* Global Inventories & Forward Cover Matrix */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg overflow-hidden">
        <div className="p-4 bg-[#0e1420] border-b border-[#1e293b] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-[#d4af37]" />
            <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
              OECD Commercial, Strategic & Floating Stocks Balance
            </h3>
          </div>
          <span className="text-[11px] text-[#64748b] font-mono">
            Comparison vs 5-Year Historical Average
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#121926] text-[#94a3b8] font-mono uppercase text-[10px] border-b border-[#1e293b]">
                <th className="py-2.5 px-4">Inventory Category</th>
                <th className="py-2.5 px-3 text-right">Current Level (Mb)</th>
                <th className="py-2.5 px-3 text-right">5-Year Avg (Mb)</th>
                <th className="py-2.5 px-3 text-right">Deviation vs 5Y</th>
                <th className="py-2.5 px-3 text-right">Forward Cover (Days)</th>
                <th className="py-2.5 px-3 text-right">Days vs 5Y Avg</th>
                <th className="py-2.5 px-3 text-right">5Y Percentile</th>
                <th className="py-2.5 px-4 text-right">Weekly Delta</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#182232] font-mono">
              {inventories.map((inv, idx) => (
                <tr key={idx} className="hover:bg-[#162130] transition-colors">
                  <td className="py-2.5 px-4 text-[#f1f5f9] font-sans font-medium">{inv.category}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-[#f8fafc]">{inv.currentVolumeMb}</td>
                  <td className="py-2.5 px-3 text-right text-[#94a3b8]">{inv.fiveYearAverageMb}</td>
                  <td className="py-2.5 px-3 text-right">
                    <span
                      className={`px-1 rounded ${
                        inv.deviationMb < 0 ? 'text-[#f87171] bg-[#3b1212]' : 'text-[#38bdf8] bg-[#0c2a38]'
                      }`}
                    >
                      {inv.deviationMb > 0 ? `+${inv.deviationMb}` : inv.deviationMb} Mb
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right font-bold text-[#cbd5e1]">{inv.daysOfForwardCover}</td>
                  <td className="py-2.5 px-3 text-right text-[#f87171]">
                    {inv.daysDeviation > 0 ? `+${inv.daysDeviation}` : inv.daysDeviation} days
                  </td>
                  <td className="py-2.5 px-3 text-right text-[#94a3b8]">{inv.percentile5Year}th</td>
                  <td className="py-2.5 px-4 text-right">
                    <span className={inv.weeklyChangeMb > 0 ? 'text-[#38bdf8]' : 'text-[#f87171]'}>
                      {inv.weeklyChangeMb > 0 ? `+${inv.weeklyChangeMb}` : inv.weeklyChangeMb} Mb
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Grid: Live Oil On Water Cargoes + Freight / Tanker Rates */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Oil on Water Cargoes (7 cols) */}
        <div className="lg:col-span-7 bg-[#111722] border border-[#1e293b] rounded-lg overflow-hidden">
          <div className="p-3.5 bg-[#0e1420] border-b border-[#1e293b] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Ship className="w-4 h-4 text-[#38bdf8]" />
              <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
                Live Oil On Water Cargoes (AIS Satellite Track)
              </h3>
            </div>
            <span className="text-[11px] text-[#94a3b8] font-mono">Real-time voyage status</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#121926] text-[#94a3b8] font-mono uppercase text-[10px] border-b border-[#1e293b]">
                  <th className="py-2 px-3">Vessel</th>
                  <th className="py-2 px-2">Class</th>
                  <th className="py-2 px-2">Origin → Destination</th>
                  <th className="py-2 px-2 text-right">Vol (Mb)</th>
                  <th className="py-2 px-2">Grade</th>
                  <th className="py-2 px-2">Current Location</th>
                  <th className="py-2 px-3 text-right">ETA</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#182232] font-mono text-[11px]">
                {cargoes.map((c, idx) => (
                  <tr key={idx} className="hover:bg-[#162130] transition-colors">
                    <td className="py-2.5 px-3 font-semibold text-[#f1f5f9] font-sans">{c.tankerName}</td>
                    <td className="py-2.5 px-2 text-[#94a3b8]">{c.vesselClass}</td>
                    <td className="py-2.5 px-2 text-[#cbd5e1] font-sans">
                      {c.originCountry} → {c.destinationCountry}
                    </td>
                    <td className="py-2.5 px-2 text-right font-bold text-[#38bdf8]">{c.volumeMillionBbl}</td>
                    <td className="py-2.5 px-2 text-[#94a3b8]">{c.crudeGrade}</td>
                    <td className="py-2.5 px-2 text-[#cbd5e1]">{c.currentLocation}</td>
                    <td className="py-2.5 px-3 text-right text-[#94a3b8]">{c.etaDate}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right: Tanker Market Rates & Trade Routes (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-4">
            <div className="pb-2.5 mb-3 border-b border-[#1c2433] flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Compass className="w-4 h-4 text-[#d4af37]" />
                <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
                  Tanker Freight & TCE Earnings
                </h3>
              </div>
              <span className="text-[11px] text-[#64748b] font-mono">Worldscale Benchmarks</span>
            </div>

            <div className="space-y-2.5">
              {tankers.map((t, idx) => (
                <div key={idx} className="p-2.5 bg-[#141d2a] border border-[#233149] rounded text-xs space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-[#f1f5f9] font-sans">{t.route}</span>
                    <span className="font-mono font-bold text-[#38bdf8]">WS {t.freightWorldscale}</span>
                  </div>
                  <div className="flex justify-between text-[11px] text-[#94a3b8] font-mono">
                    <span>TCE: ${t.timeCharterEquivalentUsdPerDay.toLocaleString()}/day</span>
                    <span>Fleet Util: {t.fleetUtilizationPercent}%</span>
                    <span>Ton-Miles: {t.tonMilesBillion}B</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Key Global Oil Trade Corridors */}
          <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-4">
            <div className="pb-2 mb-2.5 border-b border-[#1c2433] flex items-center justify-between">
              <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
                Strategic Chokepoints & Trade Flows
              </h3>
              <span className="text-[11px] text-[#64748b] font-mono">Volume (mb/d)</span>
            </div>

            <div className="space-y-2 text-xs">
              {tradeFlows.slice(0, 4).map((f, idx) => (
                <div key={idx} className="p-2 bg-[#131b28] border border-[#233149] rounded flex justify-between items-center">
                  <div>
                    <span className="font-semibold text-[#f1f5f9] font-sans block">
                      {f.sourceRegion} → {f.targetRegion}
                    </span>
                    <span className="text-[10px] text-[#94a3b8] font-mono">
                      Via: {f.keyChokepoint}
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="font-mono font-bold text-[#f59e0b]">{f.volumeMbd} mb/d</span>
                    <span className="text-[10px] text-[#64748b] block font-mono">${f.freightCostPerBbl}/bbl</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
