/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Users,
  ShieldCheck,
  FileText,
  FileSignature,
  CheckCircle,
  Copy,
  Layers,
  ArrowRight
} from 'lucide-react';
import { CountryConformityRecord, EnergyCountry } from '../../types/energy';
import { SecretariatAiEngine } from '../../services/geminiAi';

interface MinisterialJmmcProps {
  countries: EnergyCountry[];
  conformityRecords: CountryConformityRecord[];
}

export const MinisterialJmmcView: React.FC<MinisterialJmmcProps> = ({ countries, conformityRecords }) => {
  const [selectedScenarioTab, setSelectedScenarioTab] = useState<'SCENARIO_A' | 'SCENARIO_B' | 'SCENARIO_C'>('SCENARIO_A');
  const [communiqueDraft, setCommuniqueDraft] = useState<string>('');
  const [isDrafting, setIsDrafting] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);

  const docMembers = countries.filter(c => c.participationStatus === 'DoC_OPEC' || c.participationStatus === 'DoC_NonOPEC');

  const handleGenerateCommunique = async () => {
    setIsDrafting(true);
    try {
      const draft = await SecretariatAiEngine.draftInstitutionalReport('MINISTERIAL_COMMUNIQUE');
      setCommuniqueDraft(draft);
    } catch (e) {
      console.error(e);
    } finally {
      setIsDrafting(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(communiqueDraft);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-3">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
            MINISTERIAL CONFERENCE // DECISION SUPPORT ENVIRONMENT
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            Ministerial Conference & JMMC Monitoring Workspace
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            Sovereign coordination room: Comparative policy scenario appraisal, delegation voting positions, and formal communiqué drafting.
          </p>
        </div>

        <button
          onClick={handleGenerateCommunique}
          disabled={isDrafting}
          className="px-3.5 py-1.5 bg-[#d4af37] hover:bg-[#b89528] text-[#090d14] font-semibold rounded text-xs transition-colors flex items-center gap-1.5"
        >
          <FileSignature className="w-3.5 h-3.5" />
          {isDrafting ? 'Drafting Communiqué...' : 'Draft Ministerial Communiqué'}
        </button>
      </div>

      {/* Comparative Scenario Options Grid (Scenario A vs Scenario B vs Scenario C) */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#1c2433]">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-[#38bdf8]" />
            <h2 className="text-xs font-semibold tracking-wider text-[#e2e8f0] uppercase font-mono">
              MINISTERIAL POLICY OPTIONS FOR MINISTERIAL CONFERENCE (Q4-2026 / 2027)
            </h2>
          </div>
          <span className="text-[11px] text-[#94a3b8] font-mono">Direct comparative evaluation</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {/* Option A */}
          <div
            onClick={() => setSelectedScenarioTab('SCENARIO_A')}
            className={`p-4 rounded-lg border cursor-pointer transition-all ${
              selectedScenarioTab === 'SCENARIO_A'
                ? 'bg-[#162338] border-[#38bdf8] shadow-md'
                : 'bg-[#131b28] border-[#233149] hover:border-[#334460]'
            }`}
          >
            <div className="flex justify-between items-center text-xs mb-2">
              <span className="font-bold text-[#f8fafc] font-sans">OPTION A: ROLL-OVER BASELINE</span>
              <span className="text-[10px] font-mono bg-[#0c2438] text-[#38bdf8] px-1.5 py-0.5 rounded">STATUS QUO</span>
            </div>
            <p className="text-xs text-[#cbd5e1] leading-relaxed mb-3">
              Maintain existing voluntary cuts through 2027. Strictly enforce overproduction compensation plans from Iraq, Kazakhstan, and Russia.
            </p>
            <div className="space-y-1 text-[11px] font-mono text-[#94a3b8] border-t border-[#1e293b] pt-2">
              <div className="flex justify-between">
                <span>Implied Balance:</span>
                <span className="text-[#38bdf8] font-bold">+0.40 mb/d</span>
              </div>
              <div className="flex justify-between">
                <span>Indicative Brent:</span>
                <span className="text-[#f8fafc] font-bold">$74.20/bbl</span>
              </div>
              <div className="flex justify-between">
                <span>Member Support:</span>
                <span className="text-[#22c55e] font-semibold">Broad Consensus</span>
              </div>
            </div>
          </div>

          {/* Option B */}
          <div
            onClick={() => setSelectedScenarioTab('SCENARIO_B')}
            className={`p-4 rounded-lg border cursor-pointer transition-all ${
              selectedScenarioTab === 'SCENARIO_B'
                ? 'bg-[#162338] border-[#38bdf8] shadow-md'
                : 'bg-[#131b28] border-[#233149] hover:border-[#334460]'
            }`}
          >
            <div className="flex justify-between items-center text-xs mb-2">
              <span className="font-bold text-[#f8fafc] font-sans">OPTION B: PHASED UNWIND (+250K)</span>
              <span className="text-[10px] font-mono bg-[#1c2e1f] text-[#4ade80] px-1.5 py-0.5 rounded">SUPPLY EXPANSION</span>
            </div>
            <p className="text-xs text-[#cbd5e1] leading-relaxed mb-3">
              Gradually restore 250 kb/d to market over 6 months. Test demand elasticity and absorb seasonal winter refinery call.
            </p>
            <div className="space-y-1 text-[11px] font-mono text-[#94a3b8] border-t border-[#1e293b] pt-2">
              <div className="flex justify-between">
                <span>Implied Balance:</span>
                <span className="text-[#38bdf8] font-bold">+0.65 mb/d</span>
              </div>
              <div className="flex justify-between">
                <span>Indicative Brent:</span>
                <span className="text-[#f8fafc] font-bold">$71.50/bbl</span>
              </div>
              <div className="flex justify-between">
                <span>Member Support:</span>
                <span className="text-[#eab308] font-semibold">Conditional on Asia demand</span>
              </div>
            </div>
          </div>

          {/* Option C */}
          <div
            onClick={() => setSelectedScenarioTab('SCENARIO_C')}
            className={`p-4 rounded-lg border cursor-pointer transition-all ${
              selectedScenarioTab === 'SCENARIO_C'
                ? 'bg-[#162338] border-[#38bdf8] shadow-md'
                : 'bg-[#131b28] border-[#233149] hover:border-[#334460]'
            }`}
          >
            <div className="flex justify-between items-center text-xs mb-2">
              <span className="font-bold text-[#f8fafc] font-sans">OPTION C: TARGET RESTRAINT (-500K)</span>
              <span className="text-[10px] font-mono bg-[#3b1212] text-[#f87171] px-1.5 py-0.5 rounded">DEFICIT TARGET</span>
            </div>
            <p className="text-xs text-[#cbd5e1] leading-relaxed mb-3">
              Deepen cuts by 500 kb/d if non-DoC liquids over-perform, targeting a slight physical deficit to accelerate OECD stock draws.
            </p>
            <div className="space-y-1 text-[11px] font-mono text-[#94a3b8] border-t border-[#1e293b] pt-2">
              <div className="flex justify-between">
                <span>Implied Balance:</span>
                <span className="text-[#f87171] font-bold">-0.10 mb/d</span>
              </div>
              <div className="flex justify-between">
                <span>Indicative Brent:</span>
                <span className="text-[#22c55e] font-bold">$82.40/bbl</span>
              </div>
              <div className="flex justify-between">
                <span>Member Support:</span>
                <span className="text-[#94a3b8] font-semibold">Contingency reserve</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Generated Communiqué Draft Box if triggered */}
      {communiqueDraft && (
        <div className="bg-[#111722] border border-[#d4af37]/40 rounded-lg p-5 space-y-3">
          <div className="flex items-center justify-between pb-3 border-b border-[#1c2433]">
            <div className="flex items-center gap-2">
              <FileSignature className="w-4 h-4 text-[#d4af37]" />
              <h3 className="text-xs font-semibold text-[#f8fafc] font-mono uppercase tracking-wider">
                DRAFT MINISTERIAL CONFERENCE COMMUNIQUÉ // FOR DELEGATION APPROVAL
              </h3>
            </div>
            <button
              onClick={handleCopy}
              className="text-xs text-[#38bdf8] hover:underline flex items-center gap-1 font-mono"
            >
              <Copy className="w-3.5 h-3.5" />
              {copied ? 'Copied to Clipboard' : 'Copy Text'}
            </button>
          </div>

          <pre className="p-4 bg-[#090d14] border border-[#1b2536] rounded font-mono text-xs text-[#cbd5e1] whitespace-pre-wrap leading-relaxed max-h-72 overflow-y-auto">
            {communiqueDraft}
          </pre>
        </div>
      )}

      {/* Country Positions & Delegation Scorecard */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg overflow-hidden">
        <div className="p-4 bg-[#0e1420] border-b border-[#1e293b] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-[#38bdf8]" />
            <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
              Participating Sovereign Delegation Stances & JMMC Conformity Audit
            </h3>
          </div>
          <span className="text-[11px] text-[#64748b] font-mono">
            Quorum: 100% of participating sovereign producers present
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#121926] text-[#94a3b8] font-mono uppercase text-[10px] border-b border-[#1e293b]">
                <th className="py-2.5 px-4">Delegation</th>
                <th className="py-2.5 px-3">Status</th>
                <th className="py-2.5 px-3 text-right">Production (mb/d)</th>
                <th className="py-2.5 px-3 text-right">Target</th>
                <th className="py-2.5 px-3 text-right">Conformity</th>
                <th className="py-2.5 px-3 text-right">Compensation Plan</th>
                <th className="py-2.5 px-4">Preferred Decision Stance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#182232] font-mono">
              {docMembers.map((c) => {
                const conf = conformityRecords.find(r => r.countryId === c.id);
                return (
                  <tr key={c.id} className="hover:bg-[#162130] transition-colors">
                    <td className="py-2.5 px-4 font-sans font-medium text-[#f1f5f9] flex items-center gap-2">
                      <span>{c.flagEmoji}</span>
                      <span>{c.name}</span>
                    </td>
                    <td className="py-2.5 px-3 text-[#94a3b8] text-[11px]">{c.membershipStatus}</td>
                    <td className="py-2.5 px-3 text-right text-[#f8fafc] font-semibold">{c.crudeProductionMbd.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right text-[#cbd5e1]">{c.targetMbd.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right">
                      <span className={conf && conf.conformityPercent >= 95 ? 'text-[#22c55e]' : 'text-[#eab308]'}>
                        {conf ? `${conf.conformityPercent}%` : '100%'}
                      </span>
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#eab308]">
                      {conf && conf.outstandingCompensationMbd > 0 ? `${conf.outstandingCompensationMbd.toFixed(2)} mb/d` : 'None due'}
                    </td>
                    <td className="py-2.5 px-4 font-sans text-[#cbd5e1]">
                      {c.id === 'sau' || c.id === 'kwt'
                        ? 'Supports Option A (Market stability and quota compliance priority)'
                        : c.id === 'uae'
                        ? 'Supports Option A with flexible baseline adjustments for added sustainable capacity'
                        : c.id === 'irq' || c.id === 'kaz'
                        ? 'Committed to scheduled compensation deductions in Q4'
                        : 'Aligns with group consensus'}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
