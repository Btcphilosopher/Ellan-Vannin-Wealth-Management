/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Scale,
  Calendar,
  Layers,
  ArrowRight,
  TrendingDown,
  TrendingUp,
  BarChart3
} from 'lucide-react';
import { GlobalBalanceBreakdown } from '../../types/energy';

interface WorldBalanceViewProps {
  balanceSeries: GlobalBalanceBreakdown[];
}

export const WorldBalanceView: React.FC<WorldBalanceViewProps> = ({ balanceSeries }) => {
  const latest = balanceSeries[balanceSeries.length - 2]; // 2026-Q3 Current

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-3">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
            SUPPLY/DEMAND ENGINE // WORLD-OIL-BALANCE & CALL-ON CORE
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            World Supply / Demand Balance & Call on Participating Crude
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            MOMR Standard Methodology Chapter 13: World Demand vs Non-DoC Liquids vs DoC NGLs yields Call on DoC Crude.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono bg-[#111722] px-3 py-1.5 border border-[#1e293b] rounded">
          <Calendar className="w-3.5 h-3.5 text-[#38bdf8]" />
          <span className="text-[#94a3b8]">REPORTING HORIZON:</span>
          <span className="text-[#f8fafc] font-semibold">{latest.period}</span>
        </div>
      </div>

      {/* Primary Call-on-Oil Calculation Block */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-5">
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-[#1c2433]">
          <Layers className="w-4 h-4 text-[#38bdf8]" />
          <h2 className="text-sm font-semibold tracking-wider text-[#e2e8f0] uppercase">
            The Institutional "Call on Participating Crude" Equation
          </h2>
        </div>

        {/* Step-by-step institutional calculation cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3 items-center">
          {/* Step 1: Demand */}
          <div className="p-3.5 bg-[#141d2a] border border-[#233149] rounded-lg">
            <span className="text-[10px] text-[#94a3b8] block font-mono">STEP 1: TOTAL DEMAND</span>
            <span className="text-xl font-bold font-mono text-[#f8fafc]">{latest.worldDemandMbd}</span>
            <span className="text-xs text-[#64748b] ml-1">mb/d</span>
            <p className="text-[10px] text-[#94a3b8] mt-1">Global liquid consumption</p>
          </div>

          <div className="hidden md:flex justify-center text-[#64748b] font-mono text-xl font-bold">
            −
          </div>

          {/* Step 2: Non-DoC Supply */}
          <div className="p-3.5 bg-[#141d2a] border border-[#233149] rounded-lg">
            <span className="text-[10px] text-[#94a3b8] block font-mono">STEP 2: NON-DOC SUPPLY</span>
            <span className="text-xl font-bold font-mono text-[#cbd5e1]">{latest.nonDocLiquidsSupplyMbd}</span>
            <span className="text-xs text-[#64748b] ml-1">mb/d</span>
            <p className="text-[10px] text-[#94a3b8] mt-1">US shale, Brazil, Guyana, etc.</p>
          </div>

          <div className="hidden md:flex justify-center text-[#64748b] font-mono text-xl font-bold">
            −
          </div>

          {/* Step 3: DoC NGLs */}
          <div className="p-3.5 bg-[#141d2a] border border-[#233149] rounded-lg">
            <span className="text-[10px] text-[#94a3b8] block font-mono">STEP 3: DOC NGLS</span>
            <span className="text-xl font-bold font-mono text-[#0ea5e9]">{latest.docNglAndNonConvMbd}</span>
            <span className="text-xs text-[#64748b] ml-1">mb/d</span>
            <p className="text-[10px] text-[#94a3b8] mt-1">Exempt from crude quotas</p>
          </div>
        </div>

        {/* Equals Call on Participating Crude */}
        <div className="mt-4 pt-4 border-t border-[#1c2433] grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 bg-[#0c2438] border border-[#0284c7]/40 rounded-lg">
            <span className="text-[10px] text-[#7dd3fc] block font-mono uppercase tracking-wider">
              = REQUIRED "CALL ON DOC CRUDE"
            </span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-2xl font-bold font-mono text-[#38bdf8]">{latest.callOnDocCrudeMbd}</span>
              <span className="text-xs text-[#7dd3fc]">mb/d</span>
            </div>
            <p className="text-[11px] text-[#bae6fd] mt-1">
              The volume of participating crude required to satisfy demand without drawing or building inventories.
            </p>
          </div>

          <div className="p-4 bg-[#251e12] border border-[#d97706]/40 rounded-lg">
            <span className="text-[10px] text-[#fde68a] block font-mono uppercase tracking-wider">
              ACTUAL RECONCILED DOC PRODUCTION
            </span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className="text-2xl font-bold font-mono text-[#f59e0b]">{latest.actualDocCrudeMbd}</span>
              <span className="text-xs text-[#fde68a]">mb/d</span>
            </div>
            <p className="text-[11px] text-[#fef3c7] mt-1">
              Secondary source consensus production from participating countries.
            </p>
          </div>

          <div className="p-4 bg-[#111722] border border-[#233149] rounded-lg">
            <span className="text-[10px] text-[#94a3b8] block font-mono uppercase tracking-wider">
              IMPLIED PHYSICAL SURPLUS / DEFICIT
            </span>
            <div className="flex items-baseline gap-1 mt-1">
              <span className={`text-2xl font-bold font-mono ${latest.netBalanceMbd >= 0 ? 'text-[#38bdf8]' : 'text-[#f87171]'}`}>
                {latest.netBalanceMbd > 0 ? `+${latest.netBalanceMbd}` : latest.netBalanceMbd}
              </span>
              <span className="text-xs text-[#64748b]">mb/d</span>
            </div>
            <p className="text-[11px] text-[#94a3b8] mt-1">
              Actual Crude ({latest.actualDocCrudeMbd}) − Call ({latest.callOnDocCrudeMbd}) = Global Balance (+{latest.netBalanceMbd} mb/d).
            </p>
          </div>
        </div>
      </div>

      {/* Dense Institutional Supply/Demand Balance Quarterly Series Table */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg overflow-hidden">
        <div className="p-4 bg-[#0e1420] border-b border-[#1e293b] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4 text-[#d4af37]" />
            <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
              MOMR Chapter 13: World Oil Balance Historical & Forecast Series (mb/d)
            </h3>
          </div>
          <span className="text-[11px] text-[#64748b] font-mono">
            Unit: million barrels / day (mb/d)
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#121926] text-[#94a3b8] font-mono uppercase text-[10px] border-b border-[#1e293b]">
                <th className="py-2.5 px-4">Period</th>
                <th className="py-2.5 px-3 text-right">World Demand (a)</th>
                <th className="py-2.5 px-3 text-right">Non-DoC Liquids (b)</th>
                <th className="py-2.5 px-3 text-right">DoC NGLs (c)</th>
                <th className="py-2.5 px-3 text-right text-[#38bdf8]">Call on DoC (a-b-c)</th>
                <th className="py-2.5 px-3 text-right text-[#f59e0b]">Actual DoC Crude</th>
                <th className="py-2.5 px-3 text-right">Total World Supply</th>
                <th className="py-2.5 px-4 text-right font-bold">Balance</th>
                <th className="py-2.5 px-4 text-right">Stock Impact</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#182232] font-mono">
              {balanceSeries.map((s, idx) => {
                const isCurrent = s.period.includes('Current');
                return (
                  <tr
                    key={idx}
                    className={`transition-colors ${
                      isCurrent ? 'bg-[#182638] font-semibold' : 'hover:bg-[#162130]'
                    }`}
                  >
                    <td className="py-2.5 px-4 text-[#f1f5f9] font-sans">
                      {s.period}
                    </td>
                    <td className="py-2.5 px-3 text-right text-[#cbd5e1]">{s.worldDemandMbd.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right text-[#94a3b8]">{s.nonDocLiquidsSupplyMbd.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right text-[#94a3b8]">{s.docNglAndNonConvMbd.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right text-[#38bdf8] font-bold">{s.callOnDocCrudeMbd.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right text-[#f59e0b] font-bold">{s.actualDocCrudeMbd.toFixed(2)}</td>
                    <td className="py-2.5 px-3 text-right text-[#cbd5e1]">{s.totalWorldSupplyMbd.toFixed(2)}</td>
                    <td className="py-2.5 px-4 text-right">
                      <span
                        className={`px-1.5 py-0.5 rounded text-[11px] ${
                          s.netBalanceMbd > 0
                            ? 'bg-[#0c2a38] text-[#38bdf8]'
                            : s.netBalanceMbd < 0
                            ? 'bg-[#3b1212] text-[#f87171]'
                            : 'text-[#94a3b8]'
                        }`}
                      >
                        {s.netBalanceMbd > 0 ? `+${s.netBalanceMbd.toFixed(2)}` : s.netBalanceMbd.toFixed(2)}
                      </span>
                    </td>
                    <td className="py-2.5 px-4 text-right text-[11px] text-[#94a3b8]">
                      {s.oecdStockChangeMbd > 0 ? `+${s.oecdStockChangeMbd.toFixed(2)}` : s.oecdStockChangeMbd.toFixed(2)} mb/d build
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
