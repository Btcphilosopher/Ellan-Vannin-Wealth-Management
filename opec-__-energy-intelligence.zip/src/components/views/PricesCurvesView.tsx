/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  DollarSign,
  TrendingUp,
  Activity,
  Layers,
  BarChart,
  Sliders,
  ShieldCheck
} from 'lucide-react';
import {
  CrudeBenchmarkPrice,
  ForwardCurvePoint,
  VolatilityOptionMetrics
} from '../../types/energy';

interface PricesCurvesProps {
  benchmarks: CrudeBenchmarkPrice[];
  forwardCurve: ForwardCurvePoint[];
  volatility: VolatilityOptionMetrics;
}

export const PricesCurvesView: React.FC<PricesCurvesProps> = ({
  benchmarks,
  forwardCurve,
  volatility
}) => {
  const frontMonthPrice = forwardCurve[0]?.priceUsd || 74.20;
  const backMonthPrice = forwardCurve[forwardCurve.length - 1]?.priceUsd || 66.80;
  const totalCurveSlope = Number((backMonthPrice - frontMonthPrice).toFixed(2));
  const isBackwardation = totalCurveSlope < 0;

  // SVG Chart points calculation
  const minPrice = 64;
  const maxPrice = 78;
  const chartWidth = 580;
  const chartHeight = 160;

  const points = forwardCurve.map((pt, idx) => {
    const x = (idx / (forwardCurve.length - 1)) * (chartWidth - 40) + 20;
    const y = chartHeight - ((pt.priceUsd - minPrice) / (maxPrice - minPrice)) * (chartHeight - 40) - 20;
    return { x, y, ...pt };
  });

  const pathD = points.reduce((acc, p, idx) => {
    return idx === 0 ? `M ${p.x} ${p.y}` : `${acc} L ${p.x} ${p.y}`;
  }, '');

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-3">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
            RESEARCH ENGINE // ENERGY-QUANT & TERM STRUCTURE
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            Crude Benchmarks, 60-Month Forward Curve & Options Volatility
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            Forward term structure slope, roll yield economics, quality differentials, and 25-delta options volatility skew.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-mono bg-[#111722] px-3 py-1.5 border border-[#1e293b] rounded">
          <Activity className="w-3.5 h-3.5 text-[#22c55e]" />
          <span className="text-[#94a3b8]">CURVE STRUCTURE:</span>
          <span className="text-[#38bdf8] font-bold">
            {isBackwardation ? 'BACKWARDATION (INVENTORY TIGHTNESS)' : 'CONTANGO (STORAGE INCENTIVE)'}
          </span>
        </div>
      </div>

      {/* Benchmarks Grid */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        {benchmarks.map((b) => (
          <div key={b.benchmark} className="p-3.5 bg-[#111722] border border-[#1e293b] rounded-lg">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-[#f8fafc] font-sans">{b.benchmark}</span>
              <span className="text-[10px] text-[#94a3b8] font-mono">{b.apiGravity}° / {b.sulphurPercent}% S</span>
            </div>
            <div className="flex items-baseline gap-1 mt-1.5">
              <span className="text-xl font-bold font-mono text-[#f8fafc]">${b.spotPriceUsd.toFixed(2)}</span>
              <span className="text-xs text-[#64748b]">/bbl</span>
            </div>
            <div className="flex justify-between items-center text-[11px] font-mono mt-1 text-[#94a3b8]">
              <span>Diff vs Brent:</span>
              <span className={b.differentialVsBrent >= 0 ? 'text-[#38bdf8]' : 'text-[#cbd5e1]'}>
                {b.differentialVsBrent > 0 ? `+${b.differentialVsBrent.toFixed(2)}` : b.differentialVsBrent.toFixed(2)}
              </span>
            </div>
          </div>
        ))}
      </div>

      {/* Main Term Structure Section: Forward Curve Chart + Table */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Forward Curve Graphic (7 cols) */}
        <div className="lg:col-span-7 bg-[#111722] border border-[#1e293b] rounded-lg p-5 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center pb-3 mb-3 border-b border-[#1c2433]">
              <div className="flex items-center gap-2">
                <TrendingUp className="w-4 h-4 text-[#38bdf8]" />
                <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
                  ICE Brent Futures 60-Month Forward Curve Structure
                </h3>
              </div>
              <span className="text-xs font-mono text-[#38bdf8]">
                Slope: {totalCurveSlope}$/bbl (M1 to M60)
              </span>
            </div>

            {/* SVG Curve Plot */}
            <div className="w-full bg-[#0d131e] p-3 rounded border border-[#1b2536] my-2">
              <svg viewBox={`0 0 ${chartWidth} ${chartHeight}`} className="w-full h-44 overflow-visible">
                {/* Horizontal grid lines */}
                {[66, 70, 74].map((gridPrice) => {
                  const y = chartHeight - ((gridPrice - minPrice) / (maxPrice - minPrice)) * (chartHeight - 40) - 20;
                  return (
                    <g key={gridPrice}>
                      <line x1="20" y1={y} x2={chartWidth - 20} y2={y} stroke="#1e293b" strokeDasharray="3 3" />
                      <text x="5" y={y + 3} fill="#64748b" fontSize="9" fontFamily="monospace">
                        ${gridPrice}
                      </text>
                    </g>
                  );
                })}

                {/* Line path */}
                <path d={pathD} fill="none" stroke="#38bdf8" strokeWidth="2.5" strokeLinecap="round" />

                {/* Data Points */}
                {points.map((p, idx) => (
                  <g key={idx}>
                    <circle cx={p.x} cy={p.y} r="4" fill="#0369a1" stroke="#38bdf8" strokeWidth="2" />
                    <text x={p.x} y={p.y - 8} fill="#f1f5f9" fontSize="10" fontFamily="monospace" textAnchor="middle">
                      ${p.priceUsd.toFixed(2)}
                    </text>
                    <text x={p.x} y={chartHeight - 4} fill="#94a3b8" fontSize="9" fontFamily="monospace" textAnchor="middle">
                      {p.tenor}
                    </text>
                  </g>
                ))}
              </svg>
            </div>
          </div>

          <div className="mt-3 text-xs text-[#94a3b8] font-mono flex justify-between border-t border-[#1c2433] pt-2.5">
            <span>Annualized Roll Yield (Front 3M): <strong className="text-[#22c55e]">+5.2% p.a.</strong></span>
            <span>Prompts Spread (M1-M2): <strong className="text-[#38bdf8]">+$0.35/bbl</strong></span>
          </div>
        </div>

        {/* Options Greeks & Volatility Engine (5 cols) */}
        <div className="lg:col-span-5 bg-[#111722] border border-[#1e293b] rounded-lg p-5 space-y-4">
          <div className="pb-3 border-b border-[#1c2433] flex justify-between items-center">
            <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
              Options Volatility Surface & Greeks (30D ATM)
            </h3>
            <span className="text-[11px] text-[#64748b] font-mono">Black-76 Commodity Model</span>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs font-mono">
            <div className="p-2.5 bg-[#141d2a] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block">REALIZED VOL (30D)</span>
              <span className="text-base font-bold text-[#f8fafc]">{volatility.realizedVol30d}%</span>
            </div>
            <div className="p-2.5 bg-[#141d2a] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block">IMPLIED VOL (30D)</span>
              <span className="text-base font-bold text-[#38bdf8]">{volatility.impliedVol30d}%</span>
            </div>
            <div className="p-2.5 bg-[#141d2a] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block">25-DELTA SKEW (PUT - CALL)</span>
              <span className="text-base font-bold text-[#f87171]">{volatility.callPutSkew25d}%</span>
            </div>
            <div className="p-2.5 bg-[#141d2a] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block">ATM STRADDLE COST</span>
              <span className="text-base font-bold text-[#f59e0b]">${volatility.atmStraddlePriceUsd}/bbl</span>
            </div>
          </div>

          <div className="space-y-2 pt-2 border-t border-[#1c2433] text-xs font-mono">
            <h4 className="text-[11px] text-[#94a3b8] uppercase font-semibold">Risk Sensitivities (Greeks)</h4>
            <div className="flex justify-between py-1 border-b border-[#182333]">
              <span className="text-[#94a3b8]">Delta (Δ Call 50):</span>
              <span className="text-[#e2e8f0] font-semibold">{volatility.deltaCall50}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#182333]">
              <span className="text-[#94a3b8]">Gamma (Γ):</span>
              <span className="text-[#e2e8f0] font-semibold">{volatility.gammaCall50}</span>
            </div>
            <div className="flex justify-between py-1 border-b border-[#182333]">
              <span className="text-[#94a3b8]">Vega (ν per 1% IV):</span>
              <span className="text-[#e2e8f0] font-semibold">${volatility.vegaCall50}/bbl</span>
            </div>
            <div className="flex justify-between py-1">
              <span className="text-[#94a3b8]">Theta (θ daily time decay):</span>
              <span className="text-[#f87171] font-semibold">${volatility.thetaCall50}/bbl/day</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
