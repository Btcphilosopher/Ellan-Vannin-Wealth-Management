/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ShieldCheck,
  Send,
  Sparkles,
  BookOpen,
  CheckCircle2,
  FileCheck,
  AlertTriangle,
  FileText,
  Copy,
  RefreshCw
} from 'lucide-react';
import { SecretariatAiEngine, AiQueryResult } from '../../services/geminiAi';

export const AiSecretariatView: React.FC = () => {
  const [queryInput, setQueryInput] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [activeResult, setActiveResult] = useState<AiQueryResult | null>(null);
  const [approvedForPublication, setApprovedForPublication] = useState<boolean>(false);

  const suggestedQuestions = [
    'Why has the global balance tightened?',
    'Which countries are above target?',
    'What is driving demand growth?',
    'How much spare capacity exists?',
    'What has changed since last month?',
    'Show inventories vs five-year average.',
    'What happens if production falls 1 mb/d?',
    'Summarise this month’s oil market.'
  ];

  const handleRunQuery = async (queryToRun: string) => {
    if (!queryToRun.trim()) return;
    setLoading(true);
    setApprovedForPublication(false);
    try {
      const res = await SecretariatAiEngine.answerInstitutionalQuery(queryToRun);
      setActiveResult(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
              AI ENGINE // ENERGY INTELLIGENCE AI
            </span>
            <span className="text-[10px] bg-[#0c2a38] text-[#38bdf8] px-2 py-0.5 rounded font-mono border border-[#0284c7]/40">
              STRICT GROUNDING & AUDITED PROVENANCE
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            Institutional Research Assistant & Sovereign Report Drafter
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            Grounds strictly in approved secondary sources, official submissions, and MOMR balance tables. Human approval required before publication.
          </p>
        </div>
      </div>

      {/* Suggested Questions Grid */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-4">
        <span className="text-[10px] text-[#94a3b8] font-mono uppercase tracking-wider block mb-2">
          CURATED SECRETARIAT QUERIES (INSTANT RECONCILIATION)
        </span>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
          {suggestedQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => {
                setQueryInput(q);
                handleRunQuery(q);
              }}
              className="p-2.5 bg-[#141d2a] hover:bg-[#1a2636] border border-[#233149] rounded text-left text-xs text-[#cbd5e1] font-sans transition-colors"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Input box */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-3 flex gap-2">
        <input
          type="text"
          value={queryInput}
          onChange={(e) => setQueryInput(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && handleRunQuery(queryInput)}
          placeholder="Ask an analytical question regarding production, conformity, spare capacity, or supply/demand balance..."
          className="flex-1 bg-[#090d14] border border-[#233149] rounded px-3 py-2 text-xs text-[#f8fafc] placeholder-[#64748b] focus:outline-none focus:border-[#38bdf8]"
        />
        <button
          onClick={() => handleRunQuery(queryInput)}
          disabled={loading || !queryInput.trim()}
          className="px-4 py-2 bg-[#2563eb] hover:bg-[#1d4ed8] disabled:opacity-50 text-white rounded text-xs font-semibold flex items-center gap-1.5 transition-colors"
        >
          {loading ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
          <span>Execute Query</span>
        </button>
      </div>

      {/* Query Result Pane */}
      {activeResult && (
        <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-6 space-y-6">
          {/* Header & Approval status */}
          <div className="flex flex-col md:flex-row md:items-center justify-between pb-3 border-b border-[#1c2433] gap-3">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#22c55e]" />
              <div>
                <h3 className="text-sm font-bold text-[#f8fafc] uppercase tracking-wider font-mono">
                  Sovereign Analytical Synthesis
                </h3>
                <span className="text-[11px] text-[#94a3b8] font-mono">
                  Model: {activeResult.isAiGenerated ? 'Gemini 2.5 Flash Verified' : 'Deterministic Sovereign Engine'}
                </span>
              </div>
            </div>

            {/* Human approval workflow */}
            <div className="flex items-center gap-3">
              {approvedForPublication ? (
                <span className="flex items-center gap-1 text-xs text-[#22c55e] font-mono bg-[#052e16] px-2.5 py-1 rounded border border-[#22c55e]/30">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  APPROVED FOR MINISTERIAL PUBLICATION
                </span>
              ) : (
                <button
                  onClick={() => setApprovedForPublication(true)}
                  className="px-3 py-1 bg-[#15803d] hover:bg-[#16a34a] text-white text-xs font-medium rounded transition-colors flex items-center gap-1.5"
                >
                  <FileCheck className="w-3.5 h-3.5" />
                  Grant Human Clearance & Sign
                </button>
              )}
            </div>
          </div>

          {/* Core Response Body */}
          <div className="p-4 bg-[#0d131f] border border-[#1c2536] rounded font-sans text-xs text-[#e2e8f0] leading-relaxed whitespace-pre-wrap">
            {activeResult.answer}
          </div>

          {/* Explicit Data Provenance & Citations Grid */}
          <div className="space-y-3 pt-3 border-t border-[#1c2433]">
            <span className="text-[10px] text-[#d4af37] font-mono uppercase tracking-wider block font-semibold">
              FORMAL CITATIONS & AUDITED PROVENANCE (NO SYNTHETIC DRIFT)
            </span>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {activeResult.sourceCitations.map((cit, idx) => (
                <div key={idx} className="p-3 bg-[#131b28] border border-[#233149] rounded text-xs space-y-1">
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-[#f8fafc]">{cit.source}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-[#0c2438] text-[#38bdf8]">
                      {cit.status}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#94a3b8] font-mono">Dataset: {cit.dataset}</div>
                  <div className="flex justify-between text-[10px] text-[#64748b] font-mono">
                    <span>Obs. Date: {cit.observationDate}</span>
                    <span>Confidence: {cit.confidence}%</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Assumptions */}
          <div className="text-[11px] text-[#94a3b8] space-y-1">
            <span className="text-[#cbd5e1] font-semibold block font-mono">Explicit Assumptions:</span>
            <ul className="list-disc list-inside space-y-0.5">
              {activeResult.assumptions.map((asm, idx) => (
                <li key={idx}>{asm}</li>
              ))}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
};
