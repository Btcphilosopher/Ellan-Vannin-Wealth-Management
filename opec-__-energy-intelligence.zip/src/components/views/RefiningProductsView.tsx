/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Flame,
  Gauge,
  Factory,
  ArrowRight,
  TrendingUp,
  Droplet,
  Layers
} from 'lucide-react';
import { RefineryMetrics } from '../../types/energy';

interface RefiningProductsProps {
  refineries: RefineryMetrics[];
}

export const RefiningProductsView: React.FC<RefiningProductsProps> = ({ refineries }) => {
  const totalCapacity = refineries.reduce((sum, r) => sum + r.nameplateCapacityMbd, 0);
  const totalThroughput = refineries.reduce((sum, r) => sum + r.throughputMbd, 0);
  const avgUtilization = Number(((totalThroughput / totalCapacity) * 100).toFixed(1));

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-3">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
            DOWNSTREAM ENGINE // GLOBAL REFINING TWIN & PRODUCT CRACKS
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            Refinery Utilization, Turnarounds & Product Crack Spreads
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            Downstream conversion economics: Throughput / Capacity runs, seasonal turnarounds, and product margin cracks ($/bbl over Brent).
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="bg-[#111722] px-3 py-1.5 border border-[#1e293b] rounded">
            <span className="text-[#94a3b8]">GLOBAL RUNS:</span>{' '}
            <strong className="text-[#f8fafc]">{totalThroughput.toFixed(2)} / {totalCapacity.toFixed(2)} mb/d</strong>
          </div>
          <div className="bg-[#111722] px-3 py-1.5 border border-[#1e293b] rounded">
            <span className="text-[#94a3b8]">AVG UTILIZATION:</span>{' '}
            <strong className="text-[#22c55e]">{avgUtilization}%</strong>
          </div>
        </div>
      </div>

      {/* Institutional Downstream Flow Bridge Card */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-5">
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-[#1c2433]">
          <Layers className="w-4 h-4 text-[#38bdf8]" />
          <h2 className="text-xs font-semibold tracking-wider text-[#e2e8f0] uppercase font-mono">
            REFINERY PRODUCT VALUE CHAIN (CRUDE → REFINERY RUN → PRODUCT MARGIN)
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          <div className="p-3 bg-[#131b28] border border-[#233149] rounded text-center">
            <span className="text-[10px] text-[#94a3b8] font-mono block">INPUT FEEDSTOCK</span>
            <span className="text-sm font-bold text-[#f8fafc] font-sans mt-1 block">Dated Brent / Dubai / WTI</span>
            <span className="text-xs font-mono text-[#38bdf8]">$74.20/bbl</span>
          </div>

          <div className="text-center font-mono text-[#94a3b8] text-xs">
            <span>→ Atmospheric & Vacuum Distillation →</span>
          </div>

          <div className="p-3 bg-[#131b28] border border-[#233149] rounded text-center">
            <span className="text-[10px] text-[#94a3b8] font-mono block">REFINERY RUNS</span>
            <span className="text-sm font-bold text-[#22c55e] font-sans mt-1 block">Throughput: {totalThroughput.toFixed(1)} mb/d</span>
            <span className="text-xs font-mono text-[#cbd5e1]">{avgUtilization}% Capacity Run</span>
          </div>

          <div className="p-3 bg-[#131b28] border border-[#233149] rounded text-center">
            <span className="text-[10px] text-[#94a3b8] font-mono block">TOP PERFORMING CRACK</span>
            <span className="text-sm font-bold text-[#f59e0b] font-sans mt-1 block">USGC Diesel Crack</span>
            <span className="text-xs font-mono text-[#22c55e]">+$26.80/bbl margin</span>
          </div>
        </div>
      </div>

      {/* Regional Refining Metrics Table */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg overflow-hidden">
        <div className="p-4 bg-[#0e1420] border-b border-[#1e293b] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Factory className="w-4 h-4 text-[#d4af37]" />
            <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
              Regional Refining Capacity, Turnarounds & Product Cracks ($/bbl)
            </h3>
          </div>
          <span className="text-[11px] text-[#64748b] font-mono">
            Crack Spread: Product Cargo Spot minus Crude Input Benchmark
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#121926] text-[#94a3b8] font-mono uppercase text-[10px] border-b border-[#1e293b]">
                <th className="py-2.5 px-4">Refining Center</th>
                <th className="py-2.5 px-3 text-right">Capacity (mb/d)</th>
                <th className="py-2.5 px-3 text-right">Throughput</th>
                <th className="py-2.5 px-3 text-right">Utilization</th>
                <th className="py-2.5 px-3 text-right">Turnaround Offline</th>
                <th className="py-2.5 px-3 text-right text-[#38bdf8]">Gasoline Crack</th>
                <th className="py-2.5 px-3 text-right text-[#f59e0b]">Diesel Crack</th>
                <th className="py-2.5 px-3 text-right text-[#38bdf8]">Jet Fuel Crack</th>
                <th className="py-2.5 px-4 text-right">Naphtha Crack</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#182232] font-mono">
              {refineries.map((r, idx) => (
                <tr key={idx} className="hover:bg-[#162130] transition-colors">
                  <td className="py-2.5 px-4 text-[#f1f5f9] font-sans font-medium">{r.region}</td>
                  <td className="py-2.5 px-3 text-right text-[#cbd5e1]">{r.nameplateCapacityMbd.toFixed(2)}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-[#f8fafc]">{r.throughputMbd.toFixed(2)}</td>
                  <td className="py-2.5 px-3 text-right font-semibold text-[#22c55e]">{r.utilizationPercent}%</td>
                  <td className="py-2.5 px-3 text-right text-[#ef4444]">{r.turnaroundOfflineMbd.toFixed(2)} mb/d</td>
                  <td className="py-2.5 px-3 text-right text-[#38bdf8] font-semibold">+${r.gasolineCrackUsd.toFixed(2)}</td>
                  <td className="py-2.5 px-3 text-right text-[#f59e0b] font-bold">+${r.dieselCrackUsd.toFixed(2)}</td>
                  <td className="py-2.5 px-3 text-right text-[#38bdf8] font-semibold">+${r.jetFuelCrackUsd.toFixed(2)}</td>
                  <td className="py-2.5 px-4 text-right text-[#94a3b8]">${r.naphthaCrackUsd.toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
