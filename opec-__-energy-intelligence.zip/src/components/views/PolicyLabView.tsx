/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Sliders,
  AlertTriangle,
  Play,
  RotateCcw,
  Layers,
  Scale,
  TrendingUp,
  TrendingDown,
  Info
} from 'lucide-react';
import { GlobalBalanceBreakdown, ScenarioDefinition } from '../../types/energy';
import { EnergyComputationalEngine } from '../../services/energyEngine';

interface PolicyLabProps {
  currentBalance: GlobalBalanceBreakdown;
  currentBrentPrice: number;
  presetScenarios: ScenarioDefinition[];
}

export const PolicyLabView: React.FC<PolicyLabProps> = ({
  currentBalance,
  currentBrentPrice,
  presetScenarios
}) => {
  const [productionAdjustmentMbd, setProductionAdjustmentMbd] = useState<number>(0.0);
  const [demandAdjustmentPercent, setDemandAdjustmentPercent] = useState<number>(0.0);
  const [selectedPresetId, setSelectedPresetId] = useState<string>('scen-base');

  // Compute instantaneous simulation
  const sim = EnergyComputationalEngine.simulateScenario(
    currentBalance,
    currentBrentPrice,
    productionAdjustmentMbd,
    demandAdjustmentPercent
  );

  const irfData = EnergyComputationalEngine.computeImpulseResponse(
    productionAdjustmentMbd !== 0 ? productionAdjustmentMbd : -1.0
  );

  const handleApplyPreset = (scenario: ScenarioDefinition) => {
    setSelectedPresetId(scenario.id);
    setProductionAdjustmentMbd(scenario.productionAdjustmentMbd);
    setDemandAdjustmentPercent(scenario.demandAdjustmentPercent);
  };

  const handleReset = () => {
    setProductionAdjustmentMbd(0);
    setDemandAdjustmentPercent(0);
    setSelectedPresetId('scen-base');
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-3">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
              SCENARIO ENGINE // PRODUCTION POLICY LAB
            </span>
            <span className="text-[10px] bg-[#3b1818] text-[#fca5a5] px-2 py-0.5 rounded font-mono border border-[#ef4444]/30">
              SCENARIO — NOT FORECAST
            </span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            Production Policy Lab & Geopolitical Stress Simulator
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            Interactive analytical sandbox: Model volumetric quota unwinds, supply disruptions, and macroeconomic demand shocks.
          </p>
        </div>

        <button
          onClick={handleReset}
          className="px-3 py-1.5 bg-[#17202e] hover:bg-[#1f2c3f] text-[#cbd5e1] border border-[#233149] rounded text-xs font-mono flex items-center gap-1.5 transition-colors"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset Baseline
        </button>
      </div>

      {/* Preset Scenarios Selector Bar */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-4">
        <span className="text-[10px] text-[#94a3b8] font-mono uppercase tracking-wider block mb-2">
          APPROVED INSTITUTIONAL PRESET SCENARIOS
        </span>
        <div className="grid grid-cols-2 md:grid-cols-6 gap-2">
          {presetScenarios.map((scen) => (
            <button
              key={scen.id}
              onClick={() => handleApplyPreset(scen)}
              className={`p-2 rounded text-left border text-xs font-mono transition-all ${
                selectedPresetId === scen.id
                  ? 'bg-[#1e3a8a]/40 border-[#38bdf8] text-[#f8fafc]'
                  : 'bg-[#131b28] border-[#233149] text-[#94a3b8] hover:text-[#cbd5e1]'
              }`}
            >
              <span className="font-semibold block truncate font-sans text-xs">{scen.title}</span>
              <span className="text-[10px] text-[#64748b] block mt-0.5">
                {scen.productionAdjustmentMbd > 0
                  ? `+${scen.productionAdjustmentMbd} mb/d`
                  : scen.productionAdjustmentMbd < 0
                  ? `${scen.productionAdjustmentMbd} mb/d`
                  : 'Baseline Q'}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Controls & Projected Impact Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Interactive Sliders (5 cols) */}
        <div className="lg:col-span-5 bg-[#111722] border border-[#1e293b] rounded-lg p-5 space-y-6">
          <div className="pb-3 border-b border-[#1c2433] flex items-center gap-2">
            <Sliders className="w-4 h-4 text-[#38bdf8]" />
            <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
              Policy Adjustment Controls
            </h3>
          </div>

          {/* Quick Production Quota Buttons */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-[#94a3b8] block">
              DoC Production Adjustment (mb/d):
            </label>
            <div className="grid grid-cols-3 gap-1.5 font-mono text-xs">
              {[-1.0, -0.5, -0.25, 0.0, 0.25, 0.5, 1.0].slice(0, 6).map((adj) => (
                <button
                  key={adj}
                  onClick={() => {
                    setProductionAdjustmentMbd(adj);
                    setSelectedPresetId('custom');
                  }}
                  className={`py-1.5 px-2 rounded border text-center transition-colors ${
                    productionAdjustmentMbd === adj
                      ? 'bg-[#0284c7] text-white border-[#38bdf8] font-bold'
                      : 'bg-[#141d2a] border-[#233149] text-[#cbd5e1] hover:bg-[#1a2636]'
                  }`}
                >
                  {adj > 0 ? `+${adj * 1000}k` : adj < 0 ? `${adj * 1000}k` : '0'}
                </button>
              ))}
            </div>

            {/* Slider */}
            <div className="pt-2">
              <input
                type="range"
                min="-3.0"
                max="2.0"
                step="0.05"
                value={productionAdjustmentMbd}
                onChange={(e) => {
                  setProductionAdjustmentMbd(parseFloat(e.target.value));
                  setSelectedPresetId('custom');
                }}
                className="w-full accent-[#38bdf8] cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-[#64748b] font-mono mt-1">
                <span>-3.0 mb/d (Severe Shock)</span>
                <span className="text-[#38bdf8] font-bold">
                  {productionAdjustmentMbd > 0 ? `+${productionAdjustmentMbd} mb/d` : `${productionAdjustmentMbd} mb/d`}
                </span>
                <span>+2.0 mb/d (Full Unwind)</span>
              </div>
            </div>
          </div>

          {/* Demand Adjustment Slider */}
          <div className="space-y-2 pt-4 border-t border-[#1c2433]">
            <div className="flex justify-between items-center text-xs">
              <label className="font-semibold text-[#94a3b8]">Global Demand Shift (%):</label>
              <span className="font-mono text-[#f8fafc] font-bold">
                {demandAdjustmentPercent > 0 ? `+${demandAdjustmentPercent}%` : `${demandAdjustmentPercent}%`}
              </span>
            </div>
            <input
              type="range"
              min="-5.0"
              max="3.0"
              step="0.1"
              value={demandAdjustmentPercent}
              onChange={(e) => {
                setDemandAdjustmentPercent(parseFloat(e.target.value));
                setSelectedPresetId('custom');
              }}
              className="w-full accent-[#f59e0b] cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-[#64748b] font-mono">
              <span>-5.0% (Severe Recession)</span>
              <span>Baseline 0%</span>
              <span>+3.0% (High Growth)</span>
            </div>
          </div>

          {/* Institutional note */}
          <div className="p-3 bg-[#131b28] border border-[#233149] rounded text-[11px] text-[#94a3b8] space-y-1">
            <div className="flex items-center gap-1.5 text-[#d4af37] font-semibold">
              <Info className="w-3.5 h-3.5" />
              <span>Computational Model Assumptions:</span>
            </div>
            <p className="leading-relaxed">
              Price impact uses short-run empirical crude elasticity ($\approx -0.06$). Inventories reflect cumulative quarterly imbalance.
            </p>
          </div>
        </div>

        {/* Right: Simulated Physical & Financial Impact (7 cols) */}
        <div className="lg:col-span-7 bg-[#111722] border border-[#1e293b] rounded-lg p-5 space-y-5">
          <div className="pb-3 border-b border-[#1c2433] flex justify-between items-center">
            <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
              Simulated Market Equilibrium & Sensitivities
            </h3>
            <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#131b28] text-[#38bdf8] border border-[#233149]">
              Structure: {sim.forwardCurveTilt}
            </span>
          </div>

          {/* Key Simulation KPI Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] font-mono block">PROJECTED BALANCE</span>
              <span className={`text-xl font-bold font-mono ${sim.simulatedBalanceMbd >= 0 ? 'text-[#38bdf8]' : 'text-[#f87171]'}`}>
                {sim.simulatedBalanceMbd > 0 ? `+${sim.simulatedBalanceMbd}` : sim.simulatedBalanceMbd}
              </span>
              <span className="text-[10px] text-[#64748b] ml-1">mb/d</span>
              <span className="text-[10px] text-[#94a3b8] block font-mono mt-0.5">
                (Δ {sim.balanceDeltaMbd > 0 ? `+${sim.balanceDeltaMbd}` : sim.balanceDeltaMbd})
              </span>
            </div>

            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] font-mono block">PROJECTED BRENT</span>
              <span className="text-xl font-bold font-mono text-[#f8fafc]">${sim.simulatedBrentUsd}</span>
              <span className="text-[10px] text-[#64748b] ml-1">/bbl</span>
              <span className={`text-[10px] font-mono block mt-0.5 ${sim.priceDeltaUsd >= 0 ? 'text-[#22c55e]' : 'text-[#f87171]'}`}>
                (Δ {sim.priceDeltaUsd >= 0 ? `+${sim.priceDeltaUsd}` : sim.priceDeltaUsd}$/bbl)
              </span>
            </div>

            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] font-mono block">STOCK BUILD / DRAW</span>
              <span className="text-xl font-bold font-mono text-[#cbd5e1]">{sim.impliedStockChangeMbd}</span>
              <span className="text-[10px] text-[#64748b] ml-1">mb/d</span>
              <span className="text-[10px] text-[#64748b] block font-mono mt-0.5">Commercial pace</span>
            </div>

            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] font-mono block">TOTAL LIQUIDS SUPPLY</span>
              <span className="text-xl font-bold font-mono text-[#cbd5e1]">{sim.simulatedSupplyMbd}</span>
              <span className="text-[10px] text-[#64748b] ml-1">mb/d</span>
            </div>
          </div>

          {/* Secretariat Analytical Verdict */}
          <div className="p-3.5 bg-[#141d2a] border border-[#233149] rounded-lg space-y-1.5">
            <span className="text-[10px] text-[#d4af37] font-mono uppercase font-semibold">
              SECRETARIAT SIMULATION SYNTHESIS:
            </span>
            <p className="text-xs text-[#e2e8f0] leading-relaxed">
              {sim.marketVerdict} Under these modeled parameters, the global oil balance shifts by{' '}
              <strong className="font-mono">{sim.balanceDeltaMbd > 0 ? `+${sim.balanceDeltaMbd}` : sim.balanceDeltaMbd} mb/d</strong>,
              triggering an indicative price response of <strong className="font-mono">{sim.priceDeltaUsd > 0 ? `+${sim.priceDeltaUsd}` : sim.priceDeltaUsd}$/bbl</strong> on front-month Dated Brent.
            </p>
          </div>

          {/* Econometric VAR Impulse Response Function Table */}
          <div className="space-y-2 pt-2 border-t border-[#1c2433]">
            <span className="text-[10px] text-[#94a3b8] font-mono uppercase tracking-wider block">
              ECONOMETRIC VAR IMPULSE RESPONSE TRAJECTORY (12 QUARTERS DYNAMICS)
            </span>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs font-mono">
                <thead>
                  <tr className="bg-[#121926] text-[#64748b] text-[10px] uppercase">
                    <th className="py-1.5 px-2">Horizon</th>
                    <th className="py-1.5 px-2 text-right">Supply Resp.</th>
                    <th className="py-1.5 px-2 text-right">Price Resp. ($/bbl)</th>
                    <th className="py-1.5 px-2 text-right">Cumulative Stocks (Mb)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#182333]">
                  {irfData.slice(0, 5).map((d, idx) => (
                    <tr key={idx}>
                      <td className="py-1.5 px-2 text-[#cbd5e1] font-sans">{d.quarter}</td>
                      <td className="py-1.5 px-2 text-right text-[#94a3b8]">{d.supplyResponseMbd} mb/d</td>
                      <td className="py-1.5 px-2 text-right text-[#38bdf8] font-semibold">{d.priceResponseUsd > 0 ? `+${d.priceResponseUsd}` : d.priceResponseUsd}$</td>
                      <td className="py-1.5 px-2 text-right text-[#cbd5e1]">{d.inventoryResponseMb} Mb</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
