/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  FileText,
  BookOpen,
  Printer,
  Download,
  Calendar,
  CheckCircle,
  Building2,
  Layers,
  ChevronRight
} from 'lucide-react';
import { EnergyCountry, GlobalBalanceBreakdown } from '../../types/energy';

interface ReportGeneratorProps {
  countries: EnergyCountry[];
  currentBalance: GlobalBalanceBreakdown;
}

export const ReportGeneratorView: React.FC<ReportGeneratorProps> = ({ countries, currentBalance }) => {
  const [activeReportTab, setActiveReportTab] = useState<'MOMR' | 'ASB' | 'WOO'>('MOMR');
  const [activeMomrChapter, setActiveMomrChapter] = useState<number>(1);

  const momrChapters = [
    { id: 1, title: 'Oil Market Highlights', lead: 'Overview of prompt crude differentials, global liquid balance and macroeconomic environment.' },
    { id: 2, title: 'World Economy', lead: 'Global GDP growth sustained at 2.9% in 2026; Asian emerging markets maintain strong industrial output.' },
    { id: 3, title: 'World Oil Demand', lead: 'Global liquid consumption reaches 106.4 mb/d (+1.85 mb/d YoY), anchored by non-OECD Asia transport.' },
    { id: 4, title: 'World Oil Supply', lead: 'Non-participating liquids expand by 1.25 mb/d YoY to average 55.6 mb/d, spearheaded by US shale and Guyana.' },
    { id: 5, title: 'Declaration of Cooperation Production', lead: 'Participating crude production reconciled at 42.82 mb/d, reflecting 94.2% overall conformity.' },
    { id: 6, title: 'Product Markets & Refining', lead: 'Global refinery runs average 83.4% with distillate cracks commanding healthy premiums.' },
    { id: 7, title: 'Tanker Market', lead: 'Dirty VLCC rates on Middle East-to-East routes average WS 64.5 with steady ton-mile expansion.' },
    { id: 8, title: 'Oil Trade & Chokepoint Flows', lead: 'Crude seaborne shipments via Hormuz and Malacca sustain 43 mb/d aggregate throughput.' },
    { id: 9, title: 'Commercial & Strategic Inventories', lead: 'OECD commercial stocks stand at 2,792 Mb, trailing the five-year average by 123 Mb (59.8 days of cover).' },
    { id: 10, title: 'Balance of Supply and Demand', lead: 'Call on participating crude calculated at 42.42 mb/d, indicating a modest seasonal surplus of +0.40 mb/d.' }
  ];

  const wooScenarios = [
    { name: 'Reference Case', demand2030: 108.5, demand2040: 111.2, demand2050: 112.5, desc: 'Steady population and GDP expansion with realistic petrochemical and aviation demand.' },
    { name: 'High Economic Growth', demand2030: 111.0, demand2040: 116.5, demand2050: 119.0, desc: 'Faster industrialisation in Global South outpaces electric fleet transition speed.' },
    { name: 'Accelerated Transition', demand2030: 104.2, demand2040: 96.0, demand2050: 84.5, desc: 'Aggressive EV subsidies, hydrogen adoption in heavy industry, and strict efficiency standards.' }
  ];

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-3">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
            SECRETARIAT PUBLICATIONS // OFFICIAL DIGITAL TWINS
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            Institutional Research & Statistical Publications
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            Digital publications compliant with official Vienna Secretariat format: MOMR, Annual Statistical Bulletin (ASB), and World Oil Outlook (WOO 2050).
          </p>
        </div>

        {/* Action controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="px-3 py-1.5 bg-[#17202e] hover:bg-[#1f2c3f] text-[#cbd5e1] border border-[#233149] rounded text-xs font-mono flex items-center gap-1.5 transition-colors"
          >
            <Printer className="w-3.5 h-3.5" />
            Print / PDF Export
          </button>
        </div>
      </div>

      {/* Publication Tabs */}
      <div className="flex border-b border-[#233149] gap-4">
        <button
          onClick={() => setActiveReportTab('MOMR')}
          className={`pb-3 text-sm font-semibold flex items-center gap-2 border-b-2 transition-colors ${
            activeReportTab === 'MOMR'
              ? 'border-[#d4af37] text-[#d4af37]'
              : 'border-transparent text-[#94a3b8] hover:text-[#cbd5e1]'
          }`}
        >
          <BookOpen className="w-4 h-4" />
          Monthly Oil Market Report (MOMR)
        </button>
        <button
          onClick={() => setActiveReportTab('ASB')}
          className={`pb-3 text-sm font-semibold flex items-center gap-2 border-b-2 transition-colors ${
            activeReportTab === 'ASB'
              ? 'border-[#d4af37] text-[#d4af37]'
              : 'border-transparent text-[#94a3b8] hover:text-[#cbd5e1]'
          }`}
        >
          <Building2 className="w-4 h-4" />
          Annual Statistical Bulletin (ASB)
        </button>
        <button
          onClick={() => setActiveReportTab('WOO')}
          className={`pb-3 text-sm font-semibold flex items-center gap-2 border-b-2 transition-colors ${
            activeReportTab === 'WOO'
              ? 'border-[#d4af37] text-[#d4af37]'
              : 'border-transparent text-[#94a3b8] hover:text-[#cbd5e1]'
          }`}
        >
          <Layers className="w-4 h-4" />
          World Oil Outlook 2050 (WOO)
        </button>
      </div>

      {/* MOMR View */}
      {activeReportTab === 'MOMR' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Chapter sidebar (4 cols) */}
          <div className="lg:col-span-4 bg-[#111722] border border-[#1e293b] rounded-lg p-3 space-y-1">
            <span className="text-[10px] text-[#94a3b8] font-mono uppercase tracking-wider block px-2 py-1">
              MOMR OFFICIAL CHAPTER CONTENTS
            </span>
            {momrChapters.map((ch) => (
              <button
                key={ch.id}
                onClick={() => setActiveMomrChapter(ch.id)}
                className={`w-full p-2.5 rounded text-left text-xs transition-colors flex items-center justify-between ${
                  activeMomrChapter === ch.id
                    ? 'bg-[#182638] text-[#38bdf8] font-semibold border border-[#38bdf8]/30'
                    : 'text-[#cbd5e1] hover:bg-[#151f2d]'
                }`}
              >
                <span>Chapter {ch.id}: {ch.title}</span>
                <ChevronRight className="w-3.5 h-3.5 text-[#64748b]" />
              </button>
            ))}
          </div>

          {/* Chapter reading pane (8 cols) */}
          <div className="lg:col-span-8 bg-[#111722] border border-[#1e293b] rounded-lg p-6 space-y-5">
            <div className="pb-4 border-b border-[#1c2433]">
              <span className="text-xs font-mono text-[#d4af37] uppercase tracking-wider">
                MONTHLY OIL MARKET REPORT // DIGITAL TWIN • CHAPTER {activeMomrChapter}
              </span>
              <h2 className="text-xl font-bold text-[#f8fafc] font-sans mt-1">
                {momrChapters[activeMomrChapter - 1].title}
              </h2>
              <p className="text-sm text-[#cbd5e1] mt-2 leading-relaxed">
                {momrChapters[activeMomrChapter - 1].lead}
              </p>
            </div>

            {/* Chapter Statistical Highlight Table */}
            <div className="space-y-3">
              <span className="text-xs font-mono text-[#94a3b8] uppercase">
                Audited Chapter Summary Metrics (mb/d):
              </span>
              <div className="p-4 bg-[#131b28] border border-[#233149] rounded-lg grid grid-cols-3 gap-4 text-xs font-mono">
                <div>
                  <span className="text-[10px] text-[#94a3b8] block">CURRENT VINTAGE</span>
                  <span className="text-base font-bold text-[#f8fafc]">{currentBalance.period}</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#94a3b8] block">WORLD BALANCE</span>
                  <span className="text-base font-bold text-[#38bdf8]">
                    {currentBalance.netBalanceMbd > 0 ? `+${currentBalance.netBalanceMbd}` : currentBalance.netBalanceMbd} mb/d
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-[#94a3b8] block">CALL ON DOC</span>
                  <span className="text-base font-bold text-[#f59e0b]">{currentBalance.callOnDocCrudeMbd} mb/d</span>
                </div>
              </div>
            </div>

            {/* Institutional Footnote */}
            <div className="p-3 bg-[#0d131f] border border-[#1c2536] rounded text-[11px] text-[#64748b] font-mono leading-relaxed">
              Source: Secretariat Research & Data Divisions. Data validated under ISO-8000 statistical standards. Production figures reflect consensus of official submissions and approved secondary agencies.
            </div>
          </div>
        </div>
      )}

      {/* ASB View */}
      {activeReportTab === 'ASB' && (
        <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-5 space-y-4">
          <div className="pb-3 border-b border-[#1c2433] flex justify-between items-center">
            <div>
              <span className="text-xs font-mono text-[#d4af37] uppercase tracking-wider">
                ANNUAL STATISTICAL BULLETIN (ASB) // PROVEN OIL RESERVES & HISTORICAL METRICS
              </span>
              <h2 className="text-lg font-bold text-[#f8fafc] font-sans mt-0.5">
                World Oil Reserves & Production Historical Tables
              </h2>
            </div>
            <span className="text-xs text-[#94a3b8] font-mono">200+ Country Aggregations</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse text-xs">
              <thead>
                <tr className="bg-[#121926] text-[#94a3b8] font-mono uppercase text-[10px] border-b border-[#1e293b]">
                  <th className="py-2.5 px-4">Country</th>
                  <th className="py-2.5 px-3 text-right">Proven Reserves (Billion bbl)</th>
                  <th className="py-2.5 px-3 text-right">Crude Output (mb/d)</th>
                  <th className="py-2.5 px-3 text-right">Refining Capacity (mb/d)</th>
                  <th className="py-2.5 px-3 text-right">Domestic Use (mb/d)</th>
                  <th className="py-2.5 px-4 text-right">Net Exports (mb/d)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#182232] font-mono">
                {countries.map((c) => (
                  <tr key={c.id} className="hover:bg-[#162130]">
                    <td className="py-2 px-4 font-sans font-medium text-[#f1f5f9] flex items-center gap-2">
                      <span>{c.flagEmoji}</span>
                      <span>{c.name}</span>
                    </td>
                    <td className="py-2 px-3 text-right font-bold text-[#d4af37]">
                      {c.provenReservesBillionBbl.toFixed(1)}
                    </td>
                    <td className="py-2 px-3 text-right text-[#f8fafc]">{c.crudeProductionMbd.toFixed(2)}</td>
                    <td className="py-2 px-3 text-right text-[#cbd5e1]">{c.refiningCapacityMbd.toFixed(2)}</td>
                    <td className="py-2 px-3 text-right text-[#94a3b8]">{c.oilConsumptionMbd.toFixed(2)}</td>
                    <td className="py-2 px-4 text-right font-semibold text-[#38bdf8]">
                      {c.netExportsMbd > 0 ? `+${c.netExportsMbd.toFixed(2)}` : c.netExportsMbd.toFixed(2)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* WOO View */}
      {activeReportTab === 'WOO' && (
        <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-5 space-y-5">
          <div className="pb-3 border-b border-[#1c2433]">
            <span className="text-xs font-mono text-[#d4af37] uppercase tracking-wider">
              WORLD OIL OUTLOOK 2050 (WOO) // LONG-TERM ENERGY SCENARIOS
            </span>
            <h2 className="text-lg font-bold text-[#f8fafc] font-sans mt-0.5">
              Long-Term Global Liquids Trajectory to 2050
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {wooScenarios.map((scen, idx) => (
              <div key={idx} className="p-4 bg-[#131b28] border border-[#233149] rounded-lg space-y-3">
                <span className="font-bold text-sm text-[#f8fafc] block font-sans">{scen.name}</span>
                <p className="text-xs text-[#94a3b8] leading-relaxed">{scen.desc}</p>
                <div className="space-y-1.5 pt-2 border-t border-[#1e293b] text-xs font-mono">
                  <div className="flex justify-between">
                    <span className="text-[#94a3b8]">2030 Horizon:</span>
                    <strong className="text-[#38bdf8]">{scen.demand2030} mb/d</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#94a3b8]">2040 Horizon:</span>
                    <strong className="text-[#f8fafc]">{scen.demand2040} mb/d</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-[#94a3b8]">2050 Horizon:</span>
                    <strong className="text-[#d4af37]">{scen.demand2050} mb/d</strong>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
