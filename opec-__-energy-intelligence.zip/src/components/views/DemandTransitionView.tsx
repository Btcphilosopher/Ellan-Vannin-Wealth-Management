/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  Globe2,
  Zap,
  TrendingUp,
  TrendingDown,
  FileEdit,
  Car,
  Plane,
  FlaskConical,
  Factory
} from 'lucide-react';
import { DemandRegionBreakdown, DemandRevisionItem } from '../../types/energy';

interface DemandTransitionViewProps {
  regions: DemandRegionBreakdown[];
  revisions: DemandRevisionItem[];
}

export const DemandTransitionView: React.FC<DemandTransitionViewProps> = ({ regions, revisions }) => {
  const totalWorldDemand = regions.reduce((sum, r) => sum + r.demandMbd, 0);
  const totalEvImpact = regions.reduce((sum, r) => sum + r.evPenetrationImpactMbd, 0);

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="flex flex-col md:flex-row md:items-center justify-between pb-4 border-b border-[#1e293b] gap-3">
        <div>
          <span className="text-xs uppercase tracking-widest text-[#d4af37] font-semibold">
            RESEARCH ENGINE // WORLD-OIL-DEMAND & TRANSITION DYNAMICS
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-[#f8fafc] font-sans mt-0.5">
            Regional Demand Breakdown & Energy Transition Displacements
          </h1>
          <p className="text-xs text-[#94a3b8] mt-1 font-mono">
            Sectoral modeling by region (Transport, Petrochemicals, Aviation, Industry) and audited monthly forecast revisions.
          </p>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono">
          <div className="bg-[#111722] px-3 py-1.5 border border-[#1e293b] rounded">
            <span className="text-[#94a3b8]">TOTAL DEMAND:</span>{' '}
            <strong className="text-[#f8fafc]">{totalWorldDemand.toFixed(2)} mb/d</strong>
          </div>
          <div className="bg-[#111722] px-3 py-1.5 border border-[#1e293b] rounded">
            <span className="text-[#94a3b8]">EV DISPLACEMENT:</span>{' '}
            <strong className="text-[#38bdf8]">{totalEvImpact.toFixed(2)} mb/d</strong>
          </div>
        </div>
      </div>

      {/* Demand Revision Engine Box */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg p-5">
        <div className="flex items-center justify-between pb-3 mb-4 border-b border-[#1c2433]">
          <div className="flex items-center gap-2">
            <FileEdit className="w-4 h-4 text-[#d4af37]" />
            <h2 className="text-xs font-semibold tracking-wider text-[#e2e8f0] uppercase font-mono">
              DEMAND REVISION ENGINE // AUDITED MONTHLY FORECAST ADJUSTMENTS
            </h2>
          </div>
          <span className="text-[11px] text-[#94a3b8] font-mono">Mandatory explanation log</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {revisions.map((rev, idx) => (
            <div key={idx} className="p-3 bg-[#131b28] border border-[#233149] rounded-lg space-y-2">
              <div className="flex justify-between items-start">
                <span className="text-xs font-bold text-[#f1f5f9] font-sans">{rev.horizon}</span>
                <span
                  className={`text-xs font-mono font-bold px-1.5 py-0.5 rounded ${
                    rev.revisionMbd > 0 ? 'bg-[#0c2a38] text-[#38bdf8]' : 'bg-[#3b1212] text-[#f87171]'
                  }`}
                >
                  {rev.revisionMbd > 0 ? `+${rev.revisionMbd.toFixed(2)}` : rev.revisionMbd.toFixed(2)} mb/d
                </span>
              </div>
              <div className="flex items-center gap-3 text-[11px] text-[#94a3b8] font-mono">
                <span>Prev: {rev.previousForecastMbd.toFixed(2)} mb/d</span>
                <span>→</span>
                <span className="text-[#e2e8f0] font-semibold">Curr: {rev.currentForecastMbd.toFixed(2)} mb/d</span>
              </div>
              <p className="text-xs text-[#cbd5e1] leading-relaxed">{rev.reason}</p>
              <div className="pt-2 border-t border-[#1c2433] text-[10px] text-[#64748b] font-mono flex justify-between">
                <span>{rev.source}</span>
                <span>{rev.date}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Regional Demand Table with Sectoral Breakdown */}
      <div className="bg-[#111722] border border-[#1e293b] rounded-lg overflow-hidden">
        <div className="p-4 bg-[#0e1420] border-b border-[#1e293b] flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Globe2 className="w-4 h-4 text-[#38bdf8]" />
            <h3 className="text-xs font-semibold text-[#e2e8f0] font-mono uppercase tracking-wider">
              Regional Demand Structure & Sectoral Shares (2026-Q3)
            </h3>
          </div>
          <span className="text-[11px] text-[#64748b] font-mono">
            Unit: mb/d and percentage share
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-[#121926] text-[#94a3b8] font-mono uppercase text-[10px] border-b border-[#1e293b]">
                <th className="py-2.5 px-4">Region</th>
                <th className="py-2.5 px-3 text-right">Demand (mb/d)</th>
                <th className="py-2.5 px-3 text-right">YoY Growth</th>
                <th className="py-2.5 px-3 text-right">Road Transport</th>
                <th className="py-2.5 px-3 text-right">Petrochemicals</th>
                <th className="py-2.5 px-3 text-right">Aviation</th>
                <th className="py-2.5 px-3 text-right">Industry / Power</th>
                <th className="py-2.5 px-4 text-right">EV Displacement</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#182232] font-mono">
              {regions.map((r, idx) => (
                <tr key={idx} className="hover:bg-[#162130] transition-colors">
                  <td className="py-2.5 px-4 text-[#f1f5f9] font-sans font-medium">{r.region}</td>
                  <td className="py-2.5 px-3 text-right font-bold text-[#f8fafc]">{r.demandMbd.toFixed(2)}</td>
                  <td className="py-2.5 px-3 text-right">
                    <span
                      className={`${
                        r.yoyGrowthMbd > 0 ? 'text-[#38bdf8]' : 'text-[#f87171]'
                      }`}
                    >
                      {r.yoyGrowthMbd > 0 ? `+${r.yoyGrowthMbd.toFixed(2)}` : r.yoyGrowthMbd.toFixed(2)} ({r.yoyPercent > 0 ? `+${r.yoyPercent.toFixed(1)}%` : `${r.yoyPercent.toFixed(1)}%`})
                    </span>
                  </td>
                  <td className="py-2.5 px-3 text-right text-[#cbd5e1]">{r.roadTransportShare}%</td>
                  <td className="py-2.5 px-3 text-right text-[#38bdf8] font-semibold">{r.petrochemicalShare}%</td>
                  <td className="py-2.5 px-3 text-right text-[#cbd5e1]">{r.aviationShare}%</td>
                  <td className="py-2.5 px-3 text-right text-[#94a3b8]">{r.industryPowerShare}%</td>
                  <td className="py-2.5 px-4 text-right text-[#38bdf8]">
                    {r.evPenetrationImpactMbd < 0 ? `${r.evPenetrationImpactMbd.toFixed(2)} mb/d` : '—'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
