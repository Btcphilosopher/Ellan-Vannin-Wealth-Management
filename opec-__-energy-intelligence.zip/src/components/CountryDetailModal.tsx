/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  X,
  Globe2,
  Database,
  Flame,
  Layers,
  Activity,
  DollarSign,
  Droplets,
  Ship
} from 'lucide-react';
import { EnergyCountry, OilProducerField, CountryConformityRecord } from '../types/energy';

interface CountryDetailModalProps {
  country: EnergyCountry | null;
  fields: OilProducerField[];
  conformityRecord?: CountryConformityRecord;
  onClose: () => void;
}

export const CountryDetailModal: React.FC<CountryDetailModalProps> = ({
  country,
  fields,
  conformityRecord,
  onClose
}) => {
  if (!country) return null;

  const countryFields = fields.filter((f) => f.countryId === country.id);

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#111722] border border-[#233149] rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto text-[#e2e8f0] shadow-2xl flex flex-col">
        {/* Modal Header */}
        <div className="p-5 border-b border-[#1c2433] bg-[#0c121c] flex items-center justify-between sticky top-0 z-10">
          <div className="flex items-center gap-3">
            <span className="text-3xl">{country.flagEmoji}</span>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl font-bold font-sans text-[#f8fafc]">{country.name}</h2>
                <span className="text-xs font-mono px-2 py-0.5 rounded bg-[#162338] text-[#38bdf8] border border-[#2563eb]/40">
                  {country.isoCode} • {country.membershipStatus}
                </span>
              </div>
              <span className="text-xs text-[#94a3b8] font-mono">
                Region: {country.region} ({country.subregion}) • GDP: ${country.gdpBillionUsd}B • Pop: {country.populationMillions}M
              </span>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 hover:bg-[#1f2c3f] rounded text-[#94a3b8] hover:text-[#f8fafc] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 space-y-6">
          {/* Key Upstream Statistics */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block">CURRENT CRUDE OUTPUT</span>
              <span className="text-lg font-bold text-[#f8fafc]">{country.crudeProductionMbd.toFixed(2)}</span>
              <span className="text-[10px] text-[#64748b] ml-1">mb/d</span>
            </div>
            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block">SUSTAINABLE CAPACITY</span>
              <span className="text-lg font-bold text-[#38bdf8]">{country.sustainableCapacityMbd.toFixed(2)}</span>
              <span className="text-[10px] text-[#64748b] ml-1">mb/d</span>
            </div>
            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block">SPARE CAPACITY (≤30D)</span>
              <span className="text-lg font-bold text-[#d4af37]">{country.spareCapacityMbd.toFixed(2)}</span>
              <span className="text-[10px] text-[#64748b] ml-1">mb/d</span>
            </div>
            <div className="p-3 bg-[#131b28] border border-[#233149] rounded">
              <span className="text-[10px] text-[#94a3b8] block">PROVEN RESERVES</span>
              <span className="text-lg font-bold text-[#22c55e]">{country.provenReservesBillionBbl.toFixed(1)}</span>
              <span className="text-[10px] text-[#64748b] ml-1">Billion bbl</span>
            </div>
          </div>

          {/* Coordination Baseline vs Conformity */}
          {conformityRecord && (
            <div className="p-4 bg-[#141d2a] border border-[#233149] rounded-lg space-y-3">
              <span className="text-xs font-mono uppercase tracking-wider text-[#d4af37] font-semibold block">
                PRODUCTION COORDINATION & SECONDARY SOURCES AUDIT
              </span>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs font-mono">
                <div>
                  <span className="text-[10px] text-[#94a3b8] block">Reference Baseline:</span>
                  <span className="font-bold text-[#cbd5e1]">{conformityRecord.referenceBaselineMbd.toFixed(2)} mb/d</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#94a3b8] block">Agreed Target:</span>
                  <span className="font-bold text-[#cbd5e1]">{conformityRecord.targetMbd.toFixed(2)} mb/d</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#94a3b8] block">Consensus Actual:</span>
                  <span className="font-bold text-[#f8fafc]">{conformityRecord.consensusActualMbd.toFixed(2)} mb/d</span>
                </div>
                <div>
                  <span className="text-[10px] text-[#94a3b8] block">Conformity Rate:</span>
                  <span className={`font-bold ${conformityRecord.conformityPercent >= 95 ? 'text-[#22c55e]' : 'text-[#f59e0b]'}`}>
                    {conformityRecord.conformityPercent}%
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* Field-level Digital Twins */}
          <div className="space-y-3">
            <span className="text-xs font-mono uppercase tracking-wider text-[#94a3b8] font-semibold block">
              FIELD-LEVEL DIGITAL TWINS & PRODUCTION ASSETS ({countryFields.length} Tracked)
            </span>

            {countryFields.length === 0 ? (
              <div className="p-4 bg-[#131b28] border border-[#233149] rounded text-xs text-[#94a3b8] text-center">
                Aggregate national monitoring active. Detailed geological well telemetry logged in secondary repository.
              </div>
            ) : (
              <div className="space-y-3">
                {countryFields.map((f) => (
                  <div key={f.id} className="p-4 bg-[#131b28] border border-[#233149] rounded-lg space-y-2">
                    <div className="flex justify-between items-center text-xs">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-[#f8fafc] font-sans">{f.fieldName}</span>
                        <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-[#0c2438] text-[#38bdf8]">
                          {f.status}
                        </span>
                      </div>
                      <span className="font-mono text-[#cbd5e1]">
                        Operator: <strong className="text-[#f8fafc]">{f.operator}</strong>
                      </span>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-xs font-mono pt-2 border-t border-[#1c2433] text-[#94a3b8]">
                      <div>
                        <span>Output / Cap: </span>
                        <strong className="text-[#f8fafc]">{f.currentProductionMbd} / {f.sustainableCapacityMbd} mb/d</strong>
                      </div>
                      <div>
                        <span>Crude Grade: </span>
                        <strong className="text-[#38bdf8]">{f.crudeGrade} ({f.apiGravity}°)</strong>
                      </div>
                      <div>
                        <span>Lifting Cost: </span>
                        <strong className="text-[#22c55e]">${f.liftingCostUsd.toFixed(2)}/bbl</strong>
                      </div>
                      <div>
                        <span>Terminal: </span>
                        <strong className="text-[#cbd5e1]">{f.exportTerminal}</strong>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Downstream & Economic Balance */}
          <div className="p-4 bg-[#131b28] border border-[#233149] rounded-lg grid grid-cols-3 gap-3 text-xs font-mono">
            <div>
              <span className="text-[10px] text-[#94a3b8] block">DOMESTIC CONSUMPTION</span>
              <span className="text-sm font-bold text-[#f8fafc]">{country.oilConsumptionMbd.toFixed(2)} mb/d</span>
            </div>
            <div>
              <span className="text-[10px] text-[#94a3b8] block">REFINING CAPACITY</span>
              <span className="text-sm font-bold text-[#f8fafc]">{country.refiningCapacityMbd.toFixed(2)} mb/d</span>
            </div>
            <div>
              <span className="text-[10px] text-[#94a3b8] block">NET EXPORTS</span>
              <span className="text-sm font-bold text-[#38bdf8]">
                {country.netExportsMbd > 0 ? `+${country.netExportsMbd.toFixed(2)}` : country.netExportsMbd.toFixed(2)} mb/d
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
