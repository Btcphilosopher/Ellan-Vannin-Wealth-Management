/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  ShieldAlert,
  Clock,
  CheckCircle2,
  Lock,
  Globe2,
  FileSpreadsheet,
  ChevronDown
} from 'lucide-react';
import { UserRole, SecurityClassification } from '../types/energy';

interface HeaderStripProps {
  userRole: UserRole;
  setUserRole: (role: UserRole) => void;
  classification: SecurityClassification;
  setClassification: (c: SecurityClassification) => void;
  activeVintage: string;
  setActiveVintage: (v: string) => void;
  vintages: string[];
  metrics: {
    worldDemand: number;
    worldSupply: number;
    balance: number;
    brent: number;
    wti: number;
    dubai: number;
    spareCapacity: number;
    daysCover: number;
    groupConformity: number;
  };
}

export const HeaderStrip: React.FC<HeaderStripProps> = ({
  userRole,
  setUserRole,
  classification,
  setClassification,
  activeVintage,
  setActiveVintage,
  vintages,
  metrics
}) => {
  return (
    <header className="border-b border-[#233149] bg-[#090d14] text-[#e2e8f0]">
      {/* Top diplomatic institution bar */}
      <div className="px-4 py-2 border-b border-[#1a2538] flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#d4af37]" />
            <span className="font-semibold tracking-wider text-[#d4af37]">OPEC // ENERGY INTELLIGENCE</span>
          </div>
          <span className="text-[#64748b]">|</span>
          <span className="text-[#94a3b8] font-mono tracking-tight">OPEC-MARKET-CORE • VIENNA SECRETARIAT OS</span>
          <span className="text-[#64748b]">|</span>
          <span className="text-[#38bdf8] flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5 text-[#22c55e]" />
            <span className="text-[#94a3b8]">INVARIANTS:</span>
            <span className="text-[#22c55e] font-mono">VALIDATED</span>
          </span>
        </div>

        {/* Security & Access Controls */}
        <div className="flex items-center gap-4">
          {/* Classification */}
          <div className="flex items-center gap-1.5 bg-[#121926] px-2.5 py-1 rounded border border-[#233149]">
            <Lock className="w-3 h-3 text-[#d4af37]" />
            <span className="text-[#94a3b8] text-[11px]">CLASSIFICATION:</span>
            <select
              value={classification}
              onChange={(e) => setClassification(e.target.value as SecurityClassification)}
              aria-label="Security Classification"
              className="bg-transparent text-[#e2e8f0] font-mono text-xs focus:outline-none cursor-pointer"
            >
              <option value="INTERNAL" className="bg-[#121926]">INTERNAL</option>
              <option value="RESTRICTED" className="bg-[#121926]">RESTRICTED</option>
              <option value="CONFIDENTIAL" className="bg-[#121926]">CONFIDENTIAL</option>
              <option value="PUBLIC" className="bg-[#121926]">PUBLIC</option>
            </select>
          </div>

          {/* User Role */}
          <div className="flex items-center gap-1.5 bg-[#121926] px-2.5 py-1 rounded border border-[#233149]">
            <span className="text-[#94a3b8] text-[11px]">ROLE:</span>
            <select
              value={userRole}
              onChange={(e) => setUserRole(e.target.value as UserRole)}
              aria-label="User Clearance Role"
              className="bg-transparent text-[#e2e8f0] font-mono text-xs focus:outline-none cursor-pointer"
            >
              <option value="SECRETARY_GENERAL" className="bg-[#121926]">SECRETARY_GENERAL</option>
              <option value="MINISTERIAL" className="bg-[#121926]">MINISTERIAL DELEGATE</option>
              <option value="DIRECTOR" className="bg-[#121926]">RESEARCH DIRECTOR</option>
              <option value="SENIOR_ANALYST" className="bg-[#121926]">SENIOR ANALYST</option>
              <option value="ECONOMIST" className="bg-[#121926]">CHIEF ECONOMIST</option>
              <option value="READ_ONLY" className="bg-[#121926]">READ_ONLY</option>
            </select>
          </div>

          {/* Vintage Selection (Contemporaneous vs Revised) */}
          <div className="flex items-center gap-1.5 bg-[#121926] px-2.5 py-1 rounded border border-[#233149]">
            <Clock className="w-3 h-3 text-[#38bdf8]" />
            <span className="text-[#94a3b8] text-[11px]">VINTAGE:</span>
            <select
              value={activeVintage}
              onChange={(e) => setActiveVintage(e.target.value)}
              aria-label="Data Vintage Selection"
              className="bg-transparent text-[#38bdf8] font-mono text-xs focus:outline-none cursor-pointer"
            >
              {vintages.map((v) => (
                <option key={v} value={v} className="bg-[#121926] text-[#e2e8f0]">
                  {v}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Sovereign Market Ticker Strip (Always Visible Dense Telemetry) */}
      <div className="px-4 py-2.5 bg-[#0e1420] flex flex-wrap items-center justify-between gap-y-2 border-b border-[#1b263b] text-xs">
        <div className="flex items-center gap-6 overflow-x-auto py-0.5">
          {/* World Demand */}
          <div className="flex flex-col">
            <span className="text-[10px] tracking-wider text-[#94a3b8] font-medium uppercase">WORLD DEMAND</span>
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-sm font-semibold text-[#f8fafc]">{metrics.worldDemand}</span>
              <span className="text-[10px] text-[#64748b]">mb/d</span>
            </div>
          </div>

          <div className="w-[1px] h-6 bg-[#233149]" />

          {/* World Supply */}
          <div className="flex flex-col">
            <span className="text-[10px] tracking-wider text-[#94a3b8] font-medium uppercase">WORLD SUPPLY</span>
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-sm font-semibold text-[#f8fafc]">{metrics.worldSupply}</span>
              <span className="text-[10px] text-[#64748b]">mb/d</span>
            </div>
          </div>

          <div className="w-[1px] h-6 bg-[#233149]" />

          {/* Global Net Balance */}
          <div className="flex flex-col">
            <span className="text-[10px] tracking-wider text-[#94a3b8] font-medium uppercase">WORLD BALANCE</span>
            <div className="flex items-baseline gap-1.5">
              <span className={`font-mono text-sm font-semibold ${metrics.balance >= 0 ? 'text-[#38bdf8]' : 'text-[#f87171]'}`}>
                {metrics.balance > 0 ? `+${metrics.balance}` : metrics.balance}
              </span>
              <span className="text-[10px] text-[#64748b]">mb/d</span>
              <span className={`text-[10px] font-mono px-1 rounded ${metrics.balance >= 0 ? 'bg-[#0c2a38] text-[#38bdf8]' : 'bg-[#3b1212] text-[#f87171]'}`}>
                {metrics.balance >= 0 ? 'SURPLUS' : 'DEFICIT'}
              </span>
            </div>
          </div>

          <div className="w-[1px] h-6 bg-[#233149]" />

          {/* Brent Spot */}
          <div className="flex flex-col">
            <span className="text-[10px] tracking-wider text-[#94a3b8] font-medium uppercase">ICE BRENT</span>
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-sm font-semibold text-[#f8fafc]">${metrics.brent.toFixed(2)}</span>
              <span className="text-[10px] text-[#64748b]">/bbl</span>
            </div>
          </div>

          <div className="w-[1px] h-6 bg-[#233149]" />

          {/* WTI Spot */}
          <div className="flex flex-col">
            <span className="text-[10px] tracking-wider text-[#94a3b8] font-medium uppercase">NYMEX WTI</span>
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-sm font-semibold text-[#cbd5e1]">${metrics.wti.toFixed(2)}</span>
              <span className="text-[10px] text-[#64748b]">/bbl</span>
            </div>
          </div>

          <div className="w-[1px] h-6 bg-[#233149]" />

          {/* Dubai Spot */}
          <div className="flex flex-col">
            <span className="text-[10px] tracking-wider text-[#94a3b8] font-medium uppercase">PLATTS DUBAI</span>
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-sm font-semibold text-[#cbd5e1]">${metrics.dubai.toFixed(2)}</span>
              <span className="text-[10px] text-[#64748b]">/bbl</span>
            </div>
          </div>

          <div className="w-[1px] h-6 bg-[#233149]" />

          {/* Spare Capacity */}
          <div className="flex flex-col">
            <span className="text-[10px] tracking-wider text-[#94a3b8] font-medium uppercase">SPARE CAPACITY</span>
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-sm font-semibold text-[#d4af37]">{metrics.spareCapacity.toFixed(2)}</span>
              <span className="text-[10px] text-[#64748b]">mb/d</span>
            </div>
          </div>

          <div className="w-[1px] h-6 bg-[#233149]" />

          {/* OECD Stock Cover */}
          <div className="flex flex-col">
            <span className="text-[10px] tracking-wider text-[#94a3b8] font-medium uppercase">OECD STOCK COVER</span>
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-sm font-semibold text-[#cbd5e1]">{metrics.daysCover}</span>
              <span className="text-[10px] text-[#64748b]">days</span>
              <span className="text-[10px] text-[#f87171] font-mono">(-2.6d vs 5Y)</span>
            </div>
          </div>

          <div className="w-[1px] h-6 bg-[#233149]" />

          {/* Group Conformity */}
          <div className="flex flex-col">
            <span className="text-[10px] tracking-wider text-[#94a3b8] font-medium uppercase">DOC CONFORMITY</span>
            <div className="flex items-baseline gap-1.5">
              <span className="font-mono text-sm font-semibold text-[#22c55e]">{metrics.groupConformity}%</span>
              <span className="text-[10px] text-[#94a3b8] font-mono">JMMC RECONCILED</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
