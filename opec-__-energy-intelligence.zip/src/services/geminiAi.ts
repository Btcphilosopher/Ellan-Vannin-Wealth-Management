/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI } from '@google/genai';
import { INITIAL_COUNTRIES, INITIAL_CONFORMITY_RECORDS, INITIAL_BALANCE_SERIES, INVENTORY_STATUS, CRUDE_BENCHMARKS } from '../data/energyDataset';

export interface AiQueryResult {
  answer: string;
  sourceCitations: Array<{
    source: string;
    dataset: string;
    observationDate: string;
    confidence: number;
    status: string;
  }>;
  methodologyNotes: string;
  assumptions: string[];
  isAiGenerated: boolean;
}

export class SecretariatAiEngine {
  private static aiClient: GoogleGenAI | null = null;

  private static getClient(): GoogleGenAI | null {
    if (this.aiClient) return this.aiClient;
    const apiKey = (typeof process !== 'undefined' && process.env?.GEMINI_API_KEY) ||
      (typeof import.meta !== 'undefined' && (import.meta as any).env?.VITE_GEMINI_API_KEY);
    if (apiKey) {
      this.aiClient = new GoogleGenAI({ apiKey });
      return this.aiClient;
    }
    return null;
  }

  public static async answerInstitutionalQuery(query: string): Promise<AiQueryResult> {
    const currentBalance = INITIAL_BALANCE_SERIES[INITIAL_BALANCE_SERIES.length - 2]; // 2026-Q3
    const overproducers = INITIAL_CONFORMITY_RECORDS.filter(c => c.isOverproducing);
    const totalSpare = INITIAL_COUNTRIES.reduce((sum, c) => sum + c.spareCapacityMbd, 0);

    const contextSnippet = `
INSTITUTIONAL DATABASE SNAPSHOT (OBSERVATION PERIOD: 2026-Q3):
- World Demand: ${currentBalance.worldDemandMbd} mb/d
- World Supply: ${currentBalance.totalWorldSupplyMbd} mb/d
- Non-DoC Liquids Supply: ${currentBalance.nonDocLiquidsSupplyMbd} mb/d
- DoC NGLs & Non-Conventional: ${currentBalance.docNglAndNonConvMbd} mb/d
- Call on DoC Crude: ${currentBalance.callOnDocCrudeMbd} mb/d
- Actual DoC Crude: ${currentBalance.actualDocCrudeMbd} mb/d
- Global Balance: +${currentBalance.netBalanceMbd} mb/d
- Global Commercial OECD Stocks: ${INVENTORY_STATUS[0].currentVolumeMb} mb (${INVENTORY_STATUS[0].daysOfForwardCover} days cover, ${INVENTORY_STATUS[0].daysDeviation} days vs 5-yr avg)
- Global Spare Capacity (Sustainable - Actual): ${totalSpare.toFixed(2)} mb/d (Concentrated in Saudi Arabia 3.02 mb/d, UAE 1.28 mb/d, Kuwait 0.49 mb/d)
- Crude Benchmarks: Brent $${CRUDE_BENCHMARKS[0].spotPriceUsd}/bbl, WTI $${CRUDE_BENCHMARKS[1].spotPriceUsd}/bbl, Dubai $${CRUDE_BENCHMARKS[2].spotPriceUsd}/bbl
- Overproducing Participating Countries: ${overproducers.map(o => `${o.countryName} (+${o.overproductionMbd} mb/d, outstanding compensation ${o.outstandingCompensationMbd} mb/d)`).join(', ')}
    `;

    try {
      const client = this.getClient();
      if (client) {
        const response = await client.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: `You are the chief computational analyst of ENERGY SECRETARIAT OS (OPEC // ENERGY INTELLIGENCE).
Answer the following query using ONLY the verified institutional database snapshot and formal energy economics principles.
Tone: Vienna diplomatic institution, central-bank statistical rigor, concise, objective. No conversational fluff or marketing buzzwords.
Query: "${query}"

Context:
${contextSnippet}

Structure your answer with:
1. Executive Assessment
2. Numerical Empirical Breakdown
3. Secretariat Policy Implications
4. Explicit Provenance and Footnotes`
        });

        if (response.text) {
          return {
            answer: response.text,
            sourceCitations: [
              {
                source: 'Secretariat Data & Research Division',
                dataset: 'MOMR Monthly Oil Market Twin (Q3-2026)',
                observationDate: '2026-10-01',
                confidence: 96,
                status: 'OFFICIAL'
              },
              {
                source: 'Approved Secondary Sources Consensus',
                dataset: 'Argus / S&P Platts / EIA Reconciled Feed',
                observationDate: '2026-10-04',
                confidence: 92,
                status: 'SECONDARY'
              }
            ],
            methodologyNotes: 'Direct volumetric reconciliation across 6 approved secondary sources and official national data dispatches.',
            assumptions: [
              'Voluntary production adjustments remain active in Q4 2026',
              'Non-participating US tight oil decline conforms to EIA DPR vintage',
              'Refinery turnaround schedules proceed without unplanned outages'
            ],
            isAiGenerated: true
          };
        }
      }
    } catch (e) {
      console.warn('Secretariat AI API fallback to institutional deterministic model:', e);
    }

    // Deterministic Sovereign fallback response
    return this.generateDeterministicInstitutionalResponse(query, currentBalance, overproducers, totalSpare);
  }

  private static generateDeterministicInstitutionalResponse(
    query: string,
    balance: any,
    overproducers: any[],
    spare: number
  ): AiQueryResult {
    const qLower = query.toLowerCase();

    if (qLower.includes('spare capacity') || qLower.includes('capacity')) {
      return {
        answer: `EXECUTIVE ASSESSMENT:
Total sustainable spare capacity among participating producers stands at ${spare.toFixed(2)} mb/d as of 2026-Q3. 
The capacity is heavily concentrated in low-cost Gulf producers: Saudi Arabia maintains ${INITIAL_COUNTRIES[0].spareCapacityMbd} mb/d of immediately operable spare capacity, the United Arab Emirates holds ${INITIAL_COUNTRIES[3].spareCapacityMbd} mb/d, and Kuwait retains ${INITIAL_COUNTRIES[4].spareCapacityMbd} mb/d.

NON-PARTICIPATING BUFFERS:
Spare capacity outside participating sovereign producers remains functionally negligible (<0.45 mb/d globally), largely confined to deepwater Brazil and offshore Norway under routine debottlenecking.`,
        sourceCitations: [
          { source: 'MaximumSustainableCapacityEngine', dataset: 'Field-level geological audit', observationDate: '2026-10-01', confidence: 97, status: 'OFFICIAL' }
        ],
        methodologyNotes: 'Sustainable capacity defined strictly as production achievable within 30 days and maintainable for at least 90 consecutive days without reservoir damage.',
        assumptions: ['Ras Tanura and Ruwais export terminals maintain full operational availability'],
        isAiGenerated: false
      };
    }

    if (qLower.includes('overproducing') || qLower.includes('conformity') || qLower.includes('compensation')) {
      return {
        answer: `EXECUTIVE ASSESSMENT:
Overall conformity of participating producers stands at 94.2% for the current monitoring cycle. 
However, secondary source reconciliation identifies two primary overproducers:
1. Iraq: Actual output estimated at 4.18 mb/d vs agreed target of 4.00 mb/d (+0.18 mb/d deviation). Cumulative compensation outstanding stands at 0.18 mb/d.
2. Russian Federation: Actual output estimated at 9.06 mb/d vs agreed target of 8.98 mb/d (+0.08 mb/d deviation). Cumulative compensation outstanding stands at 0.08 mb/d.
3. Kazakhstan: Actual output estimated at 1.56 mb/d vs target of 1.47 mb/d (+0.09 mb/d deviation).

COMPENSATION SCHEDULE:
Under the JMMC coordination mechanism, the identified overproducers have submitted compensation plans scheduling daily volumetric deductions through Q4-2026 to offset past deviations.`,
        sourceCitations: [
          { source: 'ProductionReconciliationEngine', dataset: 'JMMC Conformity & Secondary Source Audit', observationDate: '2026-10-04', confidence: 94, status: 'OFFICIAL' }
        ],
        methodologyNotes: 'Secondary source assessment utilizes trimmed median across Argus, Platts, EIA, and satellite SAR tank gauging.',
        assumptions: ['Official pipeline and tanker meter tallies subject to end-of-quarter revision'],
        isAiGenerated: false
      };
    }

    // Default global balance synthesis
    return {
      answer: `EXECUTIVE ASSESSMENT:
The global oil market is operating in a modest supply surplus of +${balance.netBalanceMbd} mb/d for 2026-Q3.
- Total World Demand: ${balance.worldDemandMbd} mb/d (supported by transportation in Non-OECD Asia and petrochemical feedstock additions in China).
- Total World Supply: ${balance.totalWorldSupplyMbd} mb/d.
- Non-DoC Liquids Supply: ${balance.nonDocLiquidsSupplyMbd} mb/d (led by the US Permian Basin, Brazilian pre-salt, and Guyana Stabroek Block).
- Participating NGLs & Non-conventional: ${balance.docNglAndNonConvMbd} mb/d.
- Implied Call on Participating Crude: ${balance.callOnDocCrudeMbd} mb/d vs actual production of ${balance.actualDocCrudeMbd} mb/d.

INVENTORY IMPACT:
OECD commercial inventories stand at 2,792 million barrels (59.8 days of forward cover), resting 2.6 days below the 5-year seasonal norm. This ongoing deficit has anchored prompt Brent spreads in mild backwardation despite the modest current-quarter headline surplus.`,
      sourceCitations: [
        { source: 'WORLD-OIL-BALANCE Engine', dataset: 'MOMR Core Balance Chapter 13', observationDate: '2026-10-01', confidence: 95, status: 'OFFICIAL' },
        { source: 'GLOBAL OIL INVENTORIES', dataset: 'OECD Commercial Stock Monitor', observationDate: '2026-09-30', confidence: 98, status: 'OBSERVED' }
      ],
      methodologyNotes: 'Global balance calculated strictly as World Supply minus World Demand. Floating storage and transit oil tracked via satellite AIS radar.',
      assumptions: [
        'No major geopolitical shipping interruptions along the Bab-el-Mandeb or Strait of Hormuz corridors',
        'Global GDP growth averages 2.9% annualized across 2026-2027'
      ],
      isAiGenerated: false
    };
  }

  public static async draftInstitutionalReport(reportType: 'MOMR_SUMMARY' | 'MINISTERIAL_COMMUNIQUE' | 'JMMC_REVIEW'): Promise<string> {
    const dateStr = new Date().toISOString().split('T')[0];
    if (reportType === 'MINISTERIAL_COMMUNIQUE') {
      return `ORGANISATION OF PETROLEUM EXPORTING COUNTRIES & PARTICIPATING NON-OPEC COUNTRIES
DECLARATION OF COOPERATION // MINISTERIAL CONFERENCE COMMUNIQUÉ
Vienna, Austria — ${dateStr}

1. The Ministerial Conference reviewed market developments, noting that global oil demand is projected to average 106.4 mb/d in 2026, supported by steady expansion in non-OECD emerging economies, offset by continuing efficiency gains in OECD economies.

2. The Conference reaffirmed the continued commitment of participating countries in the Declaration of Cooperation (DoC) to maintain market stability and long-term security of energy supply.

3. The Conference noted the report of the Joint Ministerial Monitoring Committee (JMMC) regarding conformity levels for the preceding period, which recorded overall group conformity of 94.2%.

4. The Conference welcomed the reaffirmed pledges by the Republic of Iraq, the Russian Federation, and the Republic of Kazakhstan to fully conform with required production levels and fulfill their respective compensation schedules for overproduced volumes before the conclusion of Q4.

5. Participating countries reconfirmed their decision to maintain the current reference production baselines, with voluntary adjustments monitored closely on a monthly basis by the JMMC.

6. The next Ordinary Meeting of the Ministerial Conference is scheduled to convene in Vienna.`;
    }

    if (reportType === 'JMMC_REVIEW') {
      return `JOINT MINISTERIAL MONITORING COMMITTEE (JMMC)
MONTHLY REPORT ON CONFORMITY AND PRODUCTION COORDINATION
Secretariat Digital Twin — Audit Date: ${dateStr}

SECTION I: CONFORMITY ASSESSMENT
- Group Production Ceiling Target: 42.42 mb/d
- Reconciled Actual Participating Crude: 42.82 mb/d
- Aggregate Group Conformity: 94.2%
- Secondary Source Consensus Spread: 0.18 mb/d across approved reporting agencies

SECTION II: COMPENSATION MONITORING
- Iraq: Required compensation remaining: 0.18 mb/d. Monthly plan: 60 kb/d per month through December.
- Kazakhstan: Required compensation remaining: 0.09 mb/d. Scheduled across Tengiz maintenance window.
- Russian Federation: Net deviation 0.08 mb/d; compensation barrels allocated against seaborne export schedules.

SECTION III: MARKET OUTLOOK & RECOMMENDATIONS
The JMMC advises the Ministerial Conference to maintain disciplined coordination in light of anticipated seasonal refining turnarounds in Q4 and non-DoC liquids growth of 1.4 mb/d YoY.`;
    }

    return `MONTHLY OIL MARKET REPORT (MOMR) — EXECUTIVE SUMMARY
Secretariat Research Division — ${dateStr}

• CRUDE OIL PRICE MOVEMENTS:
The OPEC Reference Basket (ORB) averaged $74.20/bbl, supported by steady physical differentials and tight product inventories. Brent and WTI futures exhibited steady backwardation with prompt calendar spreads averaging +$0.35/bbl.

• WORLD ECONOMY:
World economic growth is forecast at 2.9% for 2026, with emerging markets in Asia leading industrial energy consumption. Inflation trends in OECD economies continue to moderate.

• WORLD OIL DEMAND:
Global oil demand growth for 2026 is forecast at 1.85 mb/d YoY, reaching an average of 106.4 mb/d. Non-OECD regions account for 1.70 mb/d of the expansion.

• WORLD OIL SUPPLY:
Non-participating liquids supply is projected to expand by 1.25 mb/d YoY to average 55.6 mb/d, propelled by the US, Brazil, Guyana, and Canada.

• BALANCE OF SUPPLY AND DEMAND:
The call on participating crude for 2026 stands at 42.42 mb/d. With current production at 42.82 mb/d, the implied global balance registers a modest seasonal surplus of +0.40 mb/d.`;
  }
}
