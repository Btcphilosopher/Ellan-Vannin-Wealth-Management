/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  CountryConformityRecord,
  GlobalBalanceBreakdown,
  EnergyCountry,
  SecondaryEstimate,
  DataQualityMetrics,
  ScenarioDefinition,
  ForwardCurvePoint
} from '../types/energy';

export class EnergyComputationalEngine {
  /**
   * Calculate exact World Oil Balance
   * Invariant: Balance = Total Supply - Total Demand
   */
  public static calculateBalance(demandMbd: number, supplyMbd: number): number {
    return Number((supplyMbd - demandMbd).toFixed(2));
  }

  /**
   * Reconcile secondary source estimates for an oil producing country
   * Computes consensus estimate, min-max range, trimmed mean, and data quality score
   */
  public static reconcileSources(
    official: number,
    estimates: SecondaryEstimate[]
  ): {
    consensusMbd: number;
    rangeMinMbd: number;
    rangeMaxMbd: number;
    spreadMbd: number;
    dataQuality: DataQualityMetrics;
    confidenceWeightedMean: number;
  } {
    if (!estimates || estimates.length === 0) {
      return {
        consensusMbd: official,
        rangeMinMbd: official,
        rangeMaxMbd: official,
        spreadMbd: 0,
        dataQuality: {
          accuracy: 80,
          timeliness: 85,
          completeness: 75,
          consistency: 80,
          revisionFrequency: 85,
          methodologyStability: 85,
          overallScore: 82
        },
        confidenceWeightedMean: official
      };
    }

    const values = estimates.map((e) => e.productionMbd);
    const min = Math.min(...values);
    const max = Math.max(...values);
    const spread = Number((max - min).toFixed(2));

    // Confidence weighted average
    const totalConfidence = estimates.reduce((acc, curr) => acc + curr.confidence, 0);
    const weightedSum = estimates.reduce((acc, curr) => acc + curr.productionMbd * curr.confidence, 0);
    const weightedMean = totalConfidence > 0 ? Number((weightedSum / totalConfidence).toFixed(2)) : official;

    // Median
    const sorted = [...values].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    const median = sorted.length % 2 !== 0 ? sorted[mid] : Number(((sorted[mid - 1] + sorted[mid]) / 2).toFixed(2));

    // Data Quality calculation based on spread and number of corroborating independent sources
    const consistencyScore = Math.max(50, Math.min(100, Math.round(100 - spread * 60)));
    const completenessScore = Math.min(100, estimates.length * 20);
    const timelinessScore = 94;
    const accuracyScore = Math.round((consistencyScore + 95) / 2);
    const revisionFrequencyScore = 90;
    const stabilityScore = 92;

    const overall = Math.round(
      (accuracyScore * 0.25) +
      (timelinessScore * 0.15) +
      (completenessScore * 0.15) +
      (consistencyScore * 0.25) +
      (revisionFrequencyScore * 0.1) +
      (stabilityScore * 0.1)
    );

    return {
      consensusMbd: median,
      rangeMinMbd: min,
      rangeMaxMbd: max,
      spreadMbd: spread,
      confidenceWeightedMean: weightedMean,
      dataQuality: {
        accuracy: accuracyScore,
        timeliness: timelinessScore,
        completeness: completenessScore,
        consistency: consistencyScore,
        revisionFrequency: revisionFrequencyScore,
        methodologyStability: stabilityScore,
        overallScore: overall
      }
    };
  }

  /**
   * Calculate conformity rate and deviation
   * Conformity % = (Target / Actual) or required cut achieved
   */
  public static evaluateConformity(
    baselineMbd: number,
    targetMbd: number,
    actualMbd: number
  ): {
    differenceMbd: number;
    isOverproducing: boolean;
    overproductionMbd: number;
    underproductionMbd: number;
    conformityPercent: number;
  } {
    const difference = Number((actualMbd - targetMbd).toFixed(2));
    const requiredCut = Number((baselineMbd - targetMbd).toFixed(2));
    const achievedCut = Number((baselineMbd - actualMbd).toFixed(2));

    const isOverproducing = difference > 0.01;
    const overproduction = isOverproducing ? difference : 0;
    const underproduction = difference < -0.01 ? Math.abs(difference) : 0;

    let conformityPercent = 100;
    if (requiredCut > 0) {
      conformityPercent = Number(((achievedCut / requiredCut) * 100).toFixed(1));
    } else {
      conformityPercent = targetMbd > 0 ? Number(((1 - Math.abs(difference) / targetMbd) * 100).toFixed(1)) : 100;
    }

    return {
      differenceMbd: difference,
      isOverproducing,
      overproductionMbd: overproduction,
      underproductionMbd: underproduction,
      conformityPercent
    };
  }

  /**
   * Run Policy Scenario Simulation:
   * Estimates market balance, Brent price shifts, inventory draws, and forward curve tilt
   */
  public static simulateScenario(
    baseBalance: GlobalBalanceBreakdown,
    currentBrentUsd: number,
    productionAdjustmentMbd: number,
    demandAdjustmentPercent: number = 0
  ): {
    simulatedDemandMbd: number;
    simulatedSupplyMbd: number;
    simulatedBalanceMbd: number;
    balanceDeltaMbd: number;
    simulatedBrentUsd: number;
    priceDeltaUsd: number;
    impliedStockChangeMbd: number;
    forwardCurveTilt: 'STEEP_BACKWARDATION' | 'MODERATE_BACKWARDATION' | 'FLAT' | 'CONTANGO';
    marketVerdict: string;
  } {
    const demandMultiplier = 1 + (demandAdjustmentPercent / 100);
    const simulatedDemand = Number((baseBalance.worldDemandMbd * demandMultiplier).toFixed(2));
    const simulatedSupply = Number((baseBalance.totalWorldSupplyMbd + productionAdjustmentMbd).toFixed(2));
    const simulatedBalance = Number((simulatedSupply - simulatedDemand).toFixed(2));
    const balanceDelta = Number((simulatedBalance - baseBalance.netBalanceMbd).toFixed(2));

    // Institutional price elasticity model:
    // ~1 mb/d shift in global supply/demand balance moves short-term Brent by ~$8.50/bbl (inversely)
    const priceDelta = Number((-1 * balanceDelta * 8.5).toFixed(2));
    const simulatedBrent = Math.max(30, Number((currentBrentUsd + priceDelta).toFixed(2)));

    const impliedStockChange = simulatedBalance;

    let forwardCurveTilt: 'STEEP_BACKWARDATION' | 'MODERATE_BACKWARDATION' | 'FLAT' | 'CONTANGO' = 'MODERATE_BACKWARDATION';
    if (simulatedBalance > 0.8) {
      forwardCurveTilt = 'CONTANGO';
    } else if (simulatedBalance > 0.3) {
      forwardCurveTilt = 'FLAT';
    } else if (simulatedBalance < -0.5) {
      forwardCurveTilt = 'STEEP_BACKWARDATION';
    }

    let verdict = 'Market remains in balanced equilibrium.';
    if (simulatedBalance > 0.6) {
      verdict = 'Surplus risk elevated; commercial inventories accumulate; spot backwardation softens into contango.';
    } else if (simulatedBalance < -0.4) {
      verdict = 'Market deficit sharpens; commercial stock draws accelerate; prompt spreads widen in backwardation.';
    }

    return {
      simulatedDemandMbd: simulatedDemand,
      simulatedSupplyMbd: simulatedSupply,
      simulatedBalanceMbd: simulatedBalance,
      balanceDeltaMbd: balanceDelta,
      simulatedBrentUsd: simulatedBrent,
      priceDeltaUsd: priceDelta,
      impliedStockChangeMbd: impliedStockChange,
      forwardCurveTilt,
      marketVerdict: verdict
    };
  }

  /**
   * Synthesize Impulse Response Function (IRF) for a 1 mb/d supply shock
   * Econometric VAR simulation over 12 quarters
   */
  public static computeImpulseResponse(shockSizeMbd: number = -1.0): Array<{
    quarter: string;
    supplyResponseMbd: number;
    priceResponseUsd: number;
    inventoryResponseMb: number;
  }> {
    const quarters = ['Q0 (Shock)', 'Q+1', 'Q+2', 'Q+3', 'Q+4', 'Q+5', 'Q+6', 'Q+8', 'Q+10', 'Q+12'];
    return quarters.map((q, idx) => {
      // Damped harmonic oscillation simulating upstream elasticities and non-participating supply response
      const decay = Math.exp(-idx * 0.28);
      const supplyResp = Number((shockSizeMbd * decay).toFixed(2));
      const priceResp = Number((-shockSizeMbd * 9.2 * decay * (1 + 0.15 * Math.sin(idx * 0.8))).toFixed(2));
      const invResp = Number((shockSizeMbd * 91.25 * (1 - Math.exp(-idx * 0.35))).toFixed(1));

      return {
        quarter: q,
        supplyResponseMbd: supplyResp,
        priceResponseUsd: priceResp,
        inventoryResponseMb: invResp
      };
    });
  }
}
