/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  ShieldAlert,
  Globe2,
  Scale,
  TrendingUp,
  Database,
  Factory,
  Sliders,
  Users,
  BookOpen,
  Sparkles,
  Code2,
  Ship,
  Layers,
  ChevronRight
} from 'lucide-react';
import {
  INITIAL_COUNTRIES,
  INITIAL_CONFORMITY_RECORDS,
  INITIAL_PRODUCER_FIELDS,
  INITIAL_BALANCE_SERIES,
  DEMAND_REGIONS,
  DEMAND_REVISIONS,
  INVENTORY_STATUS,
  OIL_ON_WATER_CARGOES,
  TANKER_MARKET_DATA,
  TRADE_FLOWS,
  REFINERY_REGIONS,
  CRUDE_BENCHMARKS,
  FORWARD_CURVE_DATA,
  VOLATILITY_METRICS,
  PRESET_SCENARIOS,
  HISTORICAL_REPLAY_SNAPSHOTS,
  INITIAL_AUDIT_LOGS
} from './data/energyDataset';
import { UserRole, SecurityClassification, EnergyCountry } from './types/energy';
import { HeaderStrip } from './components/HeaderStrip';
import { ControlRoomView } from './components/views/ControlRoomView';
import { ProductionConformityView } from './components/views/ProductionConformityView';
import { WorldBalanceView } from './components/views/WorldBalanceView';
import { DemandTransitionView } from './components/views/DemandTransitionView';
import { InventoriesShippingView } from './components/views/InventoriesShippingView';
import { RefiningProductsView } from './components/views/RefiningProductsView';
import { PricesCurvesView } from './components/views/PricesCurvesView';
import { PolicyLabView } from './components/views/PolicyLabView';
import { MinisterialJmmcView } from './components/views/MinisterialJmmcView';
import { ReportGeneratorView } from './components/views/ReportGeneratorView';
import { AiSecretariatView } from './components/views/AiSecretariatView';
import { QuantPlatformView } from './components/views/QuantPlatformView';
import { CountryDetailModal } from './components/CountryDetailModal';

type NavTabId =
  | 'CONTROL_ROOM'
  | 'PRODUCTION_CONFORMITY'
  | 'WORLD_BALANCE'
  | 'DEMAND_TRANSITION'
  | 'INVENTORIES_SHIPPING'
  | 'REFINING_PRODUCTS'
  | 'PRICES_CURVES'
  | 'POLICY_LAB'
  | 'MINISTERIAL_JMMC'
  | 'REPORT_GENERATOR'
  | 'AI_SECRETARIAT'
  | 'QUANT_DEVELOPER';

export default function App() {
  const [activeTab, setActiveTab] = useState<NavTabId>('CONTROL_ROOM');
  const [userRole, setUserRole] = useState<UserRole>('SENIOR_ANALYST');
  const [classification, setClassification] = useState<SecurityClassification>('RESTRICTED');
  const [activeVintage, setActiveVintage] = useState<string>('2026-10-01 (Current Vintage)');
  const [selectedCountry, setSelectedCountry] = useState<EnergyCountry | null>(null);

  // Core reactive dataset
  const [countries] = useState(INITIAL_COUNTRIES);
  const [conformityRecords, setConformityRecords] = useState(INITIAL_CONFORMITY_RECORDS);
  const [balanceSeries] = useState(INITIAL_BALANCE_SERIES);
  const [demandRegions] = useState(DEMAND_REGIONS);
  const [demandRevisions] = useState(DEMAND_REVISIONS);
  const [inventories] = useState(INVENTORY_STATUS);
  const [cargoes] = useState(OIL_ON_WATER_CARGOES);
  const [tankers] = useState(TANKER_MARKET_DATA);
  const [tradeFlows] = useState(TRADE_FLOWS);
  const [refineries] = useState(REFINERY_REGIONS);
  const [benchmarks] = useState(CRUDE_BENCHMARKS);
  const [forwardCurve] = useState(FORWARD_CURVE_DATA);
  const [volatility] = useState(VOLATILITY_METRICS);
  const [presetScenarios] = useState(PRESET_SCENARIOS);
  const [auditLogs] = useState(INITIAL_AUDIT_LOGS);

  const vintages = HISTORICAL_REPLAY_SNAPSHOTS.map((s) => s.vintageDate);

  // Compute live ticker metrics
  const currentBalance = balanceSeries[balanceSeries.length - 2]; // 2026-Q3
  const totalSpare = countries.reduce((sum, c) => sum + c.spareCapacityMbd, 0);
  const totalTarget = conformityRecords.reduce((sum, r) => sum + r.targetMbd, 0);
  const totalActual = conformityRecords.reduce((sum, r) => sum + r.consensusActualMbd, 0);
  const groupConformity = Number(((totalActual / totalTarget) * 100).toFixed(1));

  const navItems: Array<{ id: NavTabId; label: string; icon: React.ComponentType<{ className?: string }> }> = [
    { id: 'CONTROL_ROOM', label: 'Control Room', icon: Globe2 },
    { id: 'PRODUCTION_CONFORMITY', label: 'Production & Conformity', icon: Scale },
    { id: 'WORLD_BALANCE', label: 'World Oil Balance', icon: Layers },
    { id: 'DEMAND_TRANSITION', label: 'Demand & Transition', icon: TrendingUp },
    { id: 'INVENTORIES_SHIPPING', label: 'Inventories & Fleet', icon: Ship },
    { id: 'REFINING_PRODUCTS', label: 'Refining & Cracks', icon: Factory },
    { id: 'PRICES_CURVES', label: 'Prices & Term Structure', icon: TrendingUp },
    { id: 'POLICY_LAB', label: 'Scenario Policy Lab', icon: Sliders },
    { id: 'MINISTERIAL_JMMC', label: 'Ministerial & JMMC', icon: Users },
    { id: 'REPORT_GENERATOR', label: 'Reports Digital Twin', icon: BookOpen },
    { id: 'AI_SECRETARIAT', label: 'Intelligence AI', icon: Sparkles },
    { id: 'QUANT_DEVELOPER', label: 'Quant Suite (R/Py/Rust)', icon: Code2 }
  ];

  return (
    <div className="min-h-screen bg-[#0b0f17] text-[#e2e8f0] flex flex-col font-sans selection:bg-[#2563eb] selection:text-white">
      {/* Top Diplomatic & Sovereign Ticker Strip */}
      <HeaderStrip
        userRole={userRole}
        setUserRole={setUserRole}
        classification={classification}
        setClassification={setClassification}
        activeVintage={activeVintage}
        setActiveVintage={setActiveVintage}
        vintages={vintages}
        metrics={{
          worldDemand: currentBalance.worldDemandMbd,
          worldSupply: currentBalance.totalWorldSupplyMbd,
          balance: currentBalance.netBalanceMbd,
          brent: benchmarks[0].spotPriceUsd,
          wti: benchmarks[1].spotPriceUsd,
          dubai: benchmarks[2].spotPriceUsd,
          spareCapacity: totalSpare,
          daysCover: inventories[0].daysOfForwardCover,
          groupConformity: groupConformity
        }}
      />

      {/* Main Institutional Navigation Tabs */}
      <nav className="border-b border-[#1e293b] bg-[#0c121d] px-4 overflow-x-auto">
        <div className="flex items-center space-x-1 min-w-max py-1.5">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex items-center gap-2 px-3 py-1.5 rounded text-xs transition-colors font-medium ${
                  isActive
                    ? 'bg-[#1e2d44] text-[#f8fafc] border border-[#38bdf8]/40 shadow-xs'
                    : 'text-[#94a3b8] hover:text-[#f8fafc] hover:bg-[#141d2c]'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-[#38bdf8]' : 'text-[#64748b]'}`} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </nav>

      {/* Main View Area */}
      <main className="flex-1 p-4 md:p-6 max-w-[1720px] w-full mx-auto">
        {activeTab === 'CONTROL_ROOM' && (
          <ControlRoomView
            countries={countries}
            conformityRecords={conformityRecords}
            currentBalance={currentBalance}
            onSelectCountry={(c) => setSelectedCountry(c)}
            onNavigateTab={(tab) => setActiveTab(tab as NavTabId)}
          />
        )}

        {activeTab === 'PRODUCTION_CONFORMITY' && (
          <ProductionConformityView
            records={conformityRecords}
            onUpdateRecord={(rec) => {
              setConformityRecords((prev) =>
                prev.map((r) => (r.countryId === rec.countryId ? rec : r))
              );
            }}
          />
        )}

        {activeTab === 'WORLD_BALANCE' && (
          <WorldBalanceView balanceSeries={balanceSeries} />
        )}

        {activeTab === 'DEMAND_TRANSITION' && (
          <DemandTransitionView regions={demandRegions} revisions={demandRevisions} />
        )}

        {activeTab === 'INVENTORIES_SHIPPING' && (
          <InventoriesShippingView
            inventories={inventories}
            cargoes={cargoes}
            tankers={tankers}
            tradeFlows={tradeFlows}
          />
        )}

        {activeTab === 'REFINING_PRODUCTS' && (
          <RefiningProductsView refineries={refineries} />
        )}

        {activeTab === 'PRICES_CURVES' && (
          <PricesCurvesView
            benchmarks={benchmarks}
            forwardCurve={forwardCurve}
            volatility={volatility}
          />
        )}

        {activeTab === 'POLICY_LAB' && (
          <PolicyLabView
            currentBalance={currentBalance}
            currentBrentPrice={benchmarks[0].spotPriceUsd}
            presetScenarios={presetScenarios}
          />
        )}

        {activeTab === 'MINISTERIAL_JMMC' && (
          <MinisterialJmmcView countries={countries} conformityRecords={conformityRecords} />
        )}

        {activeTab === 'REPORT_GENERATOR' && (
          <ReportGeneratorView countries={countries} currentBalance={currentBalance} />
        )}

        {activeTab === 'AI_SECRETARIAT' && (
          <AiSecretariatView />
        )}

        {activeTab === 'QUANT_DEVELOPER' && (
          <QuantPlatformView auditLogs={auditLogs} />
        )}
      </main>

      {/* Country Detail Modal */}
      {selectedCountry && (
        <CountryDetailModal
          country={selectedCountry}
          fields={INITIAL_PRODUCER_FIELDS}
          conformityRecord={conformityRecords.find((r) => r.countryId === selectedCountry.id)}
          onClose={() => setSelectedCountry(null)}
        />
      )}

      {/* Institutional Footer */}
      <footer className="border-t border-[#1e293b] bg-[#090d14] px-6 py-3 text-[11px] text-[#64748b] font-mono flex flex-col md:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full bg-[#22c55e]" />
          <span>OPEC-MARKET-CORE v4.8.2 (VIENNA PRODUCTION RELEASE)</span>
          <span>•</span>
          <span>STOCHASTIC ENGINE: CONVERGED</span>
          <span>•</span>
          <span>INVARIANTS: AUDITED</span>
        </div>
        <div>
          <span>ENERGY SECRETARIAT DIGITAL TWIN • ALL DATA CLASSIFIED UNDER DIPLOMATIC PROTOCOL</span>
        </div>
      </footer>
    </div>
  );
}
