/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type MembershipStatus =
  | 'MEMBER'
  | 'PARTICIPATING'
  | 'NON-MEMBER'
  | 'OBSERVER'
  | 'NON-PARTICIPATING';

export type SecurityClassification =
  | 'PUBLIC'
  | 'INTERNAL'
  | 'RESTRICTED'
  | 'CONFIDENTIAL';

export type DataStatus =
  | 'OBSERVED'
  | 'OFFICIAL'
  | 'SECONDARY'
  | 'ESTIMATED'
  | 'MODELLED'
  | 'FORECAST'
  | 'SCENARIO'
  | 'SYNTHETIC';

export type UserRole =
  | 'SECRETARY_GENERAL'
  | 'MINISTERIAL'
  | 'DIRECTOR'
  | 'SENIOR_ANALYST'
  | 'ANALYST'
  | 'DATA_ENGINEER'
  | 'ECONOMIST'
  | 'RESEARCHER'
  | 'COMMUNICATIONS'
  | 'READ_ONLY';

export interface DataProvenance {
  source: string;
  dataset: string;
  observationDate: string;
  publicationDate: string;
  revisionDate: string;
  method: string;
  unit: string;
  confidence: number; // 0 - 100
  license: string;
  status: DataStatus;
}

export interface EnergyCountry {
  id: string;
  isoCode: string;
  name: string;
  region: string;
  subregion: string;
  membershipStatus: MembershipStatus;
  participationStatus: 'DoC_OPEC' | 'DoC_NonOPEC' | 'Non_DoC' | 'Observer';
  currency: string;
  populationMillions: number;
  gdpBillionUsd: number;
  crudeProductionMbd: number;
  nglProductionMbd: number;
  totalLiquidsMbd: number;
  oilConsumptionMbd: number;
  netExportsMbd: number;
  refiningCapacityMbd: number;
  provenReservesBillionBbl: number;
  sustainableCapacityMbd: number;
  spareCapacityMbd: number;
  referenceBaselineMbd: number;
  targetMbd: number;
  outstandingCompensationMbd: number;
  flagEmoji: string;
}

export interface OilProducerField {
  id: string;
  countryId: string;
  countryName: string;
  fieldName: string;
  basin: string;
  operator: string;
  crudeGrade: string;
  apiGravity: number;
  sulphurPercent: number;
  sustainableCapacityMbd: number;
  currentProductionMbd: number;
  declineRateAnnual: number;
  liftingCostUsd: number;
  capexUsd: number;
  opexUsd: number;
  waterCutPercent: number;
  reservoirPressurePsi: number;
  exportTerminal: string;
  status: 'PRODUCING' | 'MAINTENANCE' | 'EXPANSION' | 'SHUTDOWN' | 'RESTART';
}

export interface SecondaryEstimate {
  sourceName: string; // e.g. "Official Government", "Argus Media", "S&P Platts", "EIA", "IEA", "Satellite / Radar", "Tanker Tracker"
  productionMbd: number;
  confidence: number; // 0-100
  methodology: string;
  reportedDate: string;
}

export interface CountryConformityRecord {
  countryId: string;
  countryName: string;
  group: 'DoC_OPEC' | 'DoC_NonOPEC';
  referenceBaselineMbd: number;
  agreedCutMbd: number;
  targetMbd: number;
  secondaryEstimates: SecondaryEstimate[];
  officialSubmissionMbd: number;
  consensusActualMbd: number;
  differenceMbd: number; // consensus - target
  conformityPercent: number; // (actual / target) or required cut achieved
  isOverproducing: boolean;
  overproductionMbd: number;
  underproductionMbd: number;
  cumulativeDeviationMbd: number;
  compensationDueMbd: number;
  compensatedMbd: number;
  outstandingCompensationMbd: number;
  dataQualityScore: number; // 0 - 100
}

export interface DataQualityMetrics {
  accuracy: number;
  timeliness: number;
  completeness: number;
  consistency: number;
  revisionFrequency: number;
  methodologyStability: number;
  overallScore: number;
}

export interface GlobalBalanceBreakdown {
  period: string; // e.g. "2026-Q3"
  worldDemandMbd: number;
  nonDocLiquidsSupplyMbd: number;
  docNglAndNonConvMbd: number;
  callOnDocCrudeMbd: number;
  actualDocCrudeMbd: number;
  totalWorldSupplyMbd: number;
  netBalanceMbd: number; // totalWorldSupply - worldDemand
  oecdStockChangeMbd: number;
  floatingStorageChangeMbd: number;
}

export interface DemandRegionBreakdown {
  region: string;
  demandMbd: number;
  yoyGrowthMbd: number;
  yoyPercent: number;
  roadTransportShare: number;
  aviationShare: number;
  petrochemicalShare: number;
  industryPowerShare: number;
  otherShare: number;
  evPenetrationImpactMbd: number;
}

export interface DemandRevisionItem {
  horizon: string;
  previousForecastMbd: number;
  currentForecastMbd: number;
  revisionMbd: number;
  reason: string;
  source: string;
  date: string;
}

export interface InventoryMetrics {
  category: string;
  currentVolumeMb: number;
  fiveYearAverageMb: number;
  deviationMb: number;
  daysOfForwardCover: number;
  fiveYearAvgDaysCover: number;
  daysDeviation: number;
  percentile5Year: number;
  weeklyChangeMb: number;
}

export interface OilOnWaterCargo {
  tankerName: string;
  vesselClass: 'VLCC' | 'Suezmax' | 'Aframax' | 'Panamax' | 'Product Tanker';
  originCountry: string;
  originPort: string;
  destinationCountry: string;
  destinationPort: string;
  crudeGrade: string;
  volumeMillionBbl: number;
  departureDate: string;
  etaDate: string;
  currentLocation: string;
  status: 'LADEN_TRANSIT' | 'CONGESTED_WAIT' | 'DISCHARGING' | 'BALLAST_RETURN';
}

export interface TankerMarketMetrics {
  vesselClass: 'VLCC' | 'Suezmax' | 'Aframax' | 'Clean LR2';
  route: string;
  freightWorldscale: number;
  timeCharterEquivalentUsdPerDay: number;
  fleetUtilizationPercent: number;
  tonMilesBillion: number;
  portCongestionIndex: number;
}

export interface TradeFlowRoute {
  sourceRegion: string;
  targetRegion: string;
  volumeMbd: number;
  dominantCrudeGrade: string;
  keyChokepoint: string;
  freightCostPerBbl: number;
}

export interface RefineryMetrics {
  region: string;
  nameplateCapacityMbd: number;
  throughputMbd: number;
  utilizationPercent: number;
  turnaroundOfflineMbd: number;
  gasolineCrackUsd: number;
  dieselCrackUsd: number;
  jetFuelCrackUsd: number;
  fuelOilCrackUsd: number;
  naphthaCrackUsd: number;
}

export interface CrudeBenchmarkPrice {
  benchmark: 'Brent' | 'WTI' | 'Dubai' | 'Oman' | 'Murban';
  spotPriceUsd: number;
  change1dUsd: number;
  change1dPercent: number;
  apiGravity: number;
  sulphurPercent: number;
  differentialVsBrent: number;
}

export interface ForwardCurvePoint {
  tenor: string;
  monthsOut: number;
  priceUsd: number;
  spreadVsFrontMonth: number;
  annualizedRollYieldPercent: number;
}

export interface VolatilityOptionMetrics {
  realizedVol30d: number;
  impliedVol30d: number;
  callPutSkew25d: number;
  atmStraddlePriceUsd: number;
  deltaCall50: number;
  gammaCall50: number;
  vegaCall50: number;
  thetaCall50: number;
}

export interface ScenarioDefinition {
  id: string;
  title: string;
  category: 'PRODUCTION_POLICY' | 'GEOPOLITICAL_DISRUPTION' | 'DEMAND_SHOCK' | 'ENERGY_TRANSITION';
  author: string;
  dateCreated: string;
  productionAdjustmentMbd: number;
  demandAdjustmentPercent: number;
  supplyShockDurationMonths: number;
  targetCountryId?: string;
  projectedWorldBalanceMbd: number;
  projectedBrentPriceUsd: number;
  projectedStockChangeMbd: number;
  status: 'DRAFT' | 'REVIEW' | 'APPROVED' | 'ARCHIVED';
  rationale: string;
}

export interface MarketReplaySnapshot {
  vintageDate: string; // The date as known then
  observationDate: string; // The actual month being reported
  worldDemandMbd: number;
  docProductionMbd: number;
  nonDocSupplyMbd: number;
  netBalanceMbd: number;
  brentPriceUsd: number;
  oecdStocksMb: number;
  laterRevisionMbd: number;
  revisionExplanation: string;
}

export interface AuditTrailEntry {
  id: string;
  timestamp: string;
  userRole: UserRole;
  userName: string;
  action: string;
  dataset: string;
  classification: SecurityClassification;
  details: string;
}
