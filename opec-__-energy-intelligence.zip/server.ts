/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import {
  INITIAL_COUNTRIES,
  INITIAL_CONFORMITY_RECORDS,
  INITIAL_PRODUCER_FIELDS,
  INITIAL_BALANCE_SERIES,
  DEMAND_REGIONS,
  DEMAND_REVISIONS,
  INVENTORY_STATUS,
  OIL_ON_WATER_CARGOES,
  TANKER_MARKET_DATA,
  TRADE_FLOWS,
  REFINERY_REGIONS,
  CRUDE_BENCHMARKS,
  FORWARD_CURVE_DATA,
  VOLATILITY_METRICS,
  PRESET_SCENARIOS,
  HISTORICAL_REPLAY_SNAPSHOTS,
  INITIAL_AUDIT_LOGS
} from './src/data/energyDataset.ts';
import { EnergyComputationalEngine } from './src/services/energyEngine.ts';
import { SecretariatAiEngine } from './src/services/geminiAi.ts';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

  app.use(express.json());

  // === OPEC // ENERGY INTELLIGENCE REST API (v1) ===

  app.get('/api/v1/countries', (_req, res) => {
    res.json({ status: 'OK', count: INITIAL_COUNTRIES.length, data: INITIAL_COUNTRIES });
  });

  app.get('/api/v1/members', (_req, res) => {
    const members = INITIAL_COUNTRIES.filter(c => c.membershipStatus === 'MEMBER' || c.membershipStatus === 'PARTICIPATING');
    res.json({ status: 'OK', count: members.length, data: members });
  });

  app.get('/api/v1/production', (_req, res) => {
    const totalCrude = INITIAL_COUNTRIES.reduce((sum, c) => sum + c.crudeProductionMbd, 0);
    const totalLiquids = INITIAL_COUNTRIES.reduce((sum, c) => sum + c.totalLiquidsMbd, 0);
    res.json({
      status: 'OK',
      unit: 'mb/d',
      totalCrudeMbd: Number(totalCrude.toFixed(2)),
      totalLiquidsMbd: Number(totalLiquids.toFixed(2)),
      countries: INITIAL_COUNTRIES.map(c => ({
        id: c.id,
        name: c.name,
        crudeMbd: c.crudeProductionMbd,
        nglMbd: c.nglProductionMbd,
        totalMbd: c.totalLiquidsMbd
      }))
    });
  });

  app.get('/api/v1/conformity', (_req, res) => {
    const totalTarget = INITIAL_CONFORMITY_RECORDS.reduce((s, r) => s + r.targetMbd, 0);
    const totalActual = INITIAL_CONFORMITY_RECORDS.reduce((s, r) => s + r.consensusActualMbd, 0);
    const groupConformity = Number(((totalActual / totalTarget) * 100).toFixed(1));
    res.json({
      status: 'OK',
      groupTargetMbd: Number(totalTarget.toFixed(2)),
      groupActualMbd: Number(totalActual.toFixed(2)),
      groupDeviationMbd: Number((totalActual - totalTarget).toFixed(2)),
      groupConformityPercent: groupConformity,
      records: INITIAL_CONFORMITY_RECORDS
    });
  });

  app.get('/api/v1/compensation', (_req, res) => {
    const overproducers = INITIAL_CONFORMITY_RECORDS.filter(c => c.outstandingCompensationMbd > 0);
    res.json({
      status: 'OK',
      totalOutstandingMbd: Number(overproducers.reduce((s, c) => s + c.outstandingCompensationMbd, 0).toFixed(2)),
      schedules: overproducers.map(o => ({
        country: o.countryName,
        overproductionMbd: o.overproductionMbd,
        compensationDueMbd: o.compensationDueMbd,
        compensatedMbd: o.compensatedMbd,
        outstandingCompensationMbd: o.outstandingCompensationMbd
      }))
    });
  });

  app.get('/api/v1/capacity', (_req, res) => {
    const totalSustainable = INITIAL_COUNTRIES.reduce((s, c) => s + c.sustainableCapacityMbd, 0);
    const totalActual = INITIAL_COUNTRIES.reduce((s, c) => s + c.crudeProductionMbd, 0);
    res.json({
      status: 'OK',
      unit: 'mb/d',
      sustainableCapacityMbd: Number(totalSustainable.toFixed(2)),
      currentProductionMbd: Number(totalActual.toFixed(2)),
      spareCapacityMbd: Number((totalSustainable - totalActual).toFixed(2))
    });
  });

  app.get('/api/v1/spare-capacity', (_req, res) => {
    const ranking = INITIAL_COUNTRIES
      .filter(c => c.spareCapacityMbd > 0.05)
      .sort((a, b) => b.spareCapacityMbd - a.spareCapacityMbd);
    res.json({
      status: 'OK',
      ranking: ranking.map(c => ({
        country: c.name,
        sustainableMbd: c.sustainableCapacityMbd,
        actualMbd: c.crudeProductionMbd,
        spareMbd: c.spareCapacityMbd
      }))
    });
  });

  app.get('/api/v1/balance', (_req, res) => {
    res.json({
      status: 'OK',
      current: INITIAL_BALANCE_SERIES[INITIAL_BALANCE_SERIES.length - 2],
      series: INITIAL_BALANCE_SERIES
    });
  });

  app.get('/api/v1/call-on', (_req, res) => {
    const latest = INITIAL_BALANCE_SERIES[INITIAL_BALANCE_SERIES.length - 2];
    res.json({
      status: 'OK',
      period: latest.period,
      worldDemandMbd: latest.worldDemandMbd,
      nonDocLiquidsMbd: latest.nonDocLiquidsSupplyMbd,
      docNglsMbd: latest.docNglAndNonConvMbd,
      callOnDocCrudeMbd: latest.callOnDocCrudeMbd,
      actualDocCrudeMbd: latest.actualDocCrudeMbd,
      differenceMbd: Number((latest.actualDocCrudeMbd - latest.callOnDocCrudeMbd).toFixed(2))
    });
  });

  app.get('/api/v1/demand', (_req, res) => {
    res.json({
      status: 'OK',
      regions: DEMAND_REGIONS,
      revisions: DEMAND_REVISIONS
    });
  });

  app.get('/api/v1/inventories', (_req, res) => {
    res.json({ status: 'OK', inventory: INVENTORY_STATUS });
  });

  app.get('/api/v1/on-water', (_req, res) => {
    const totalOnWaterMb = OIL_ON_WATER_CARGOES.reduce((s, c) => s + c.volumeMillionBbl, 0);
    res.json({ status: 'OK', totalTrackedMillionBbl: Number(totalOnWaterMb.toFixed(2)), cargoes: OIL_ON_WATER_CARGOES });
  });

  app.get('/api/v1/tankers', (_req, res) => {
    res.json({ status: 'OK', freightMetrics: TANKER_MARKET_DATA });
  });

  app.get('/api/v1/trade', (_req, res) => {
    res.json({ status: 'OK', tradeFlows: TRADE_FLOWS });
  });

  app.get('/api/v1/refining', (_req, res) => {
    res.json({ status: 'OK', refineries: REFINERY_REGIONS });
  });

  app.get('/api/v1/prices', (_req, res) => {
    res.json({ status: 'OK', benchmarks: CRUDE_BENCHMARKS });
  });

  app.get('/api/v1/forward-curves', (_req, res) => {
    res.json({ status: 'OK', curve: FORWARD_CURVE_DATA, structure: 'BACKWARDATION' });
  });

  app.get('/api/v1/volatility', (_req, res) => {
    res.json({ status: 'OK', volatility: VOLATILITY_METRICS });
  });

  app.get('/api/v1/scenarios', (_req, res) => {
    res.json({ status: 'OK', scenarios: PRESET_SCENARIOS });
  });

  app.post('/api/v1/scenarios/simulate', (req, res) => {
    const { productionAdjustmentMbd = 0, demandAdjustmentPercent = 0 } = req.body;
    const currentBalance = INITIAL_BALANCE_SERIES[INITIAL_BALANCE_SERIES.length - 2];
    const brentPrice = CRUDE_BENCHMARKS[0].spotPriceUsd;
    const sim = EnergyComputationalEngine.simulateScenario(currentBalance, brentPrice, productionAdjustmentMbd, demandAdjustmentPercent);
    res.json({ status: 'OK', simulation: sim });
  });

  app.get('/api/v1/replay', (_req, res) => {
    res.json({ status: 'OK', snapshots: HISTORICAL_REPLAY_SNAPSHOTS });
  });

  app.get('/api/v1/audit-trail', (_req, res) => {
    res.json({ status: 'OK', logs: INITIAL_AUDIT_LOGS });
  });

  // AI Secretariat API
  app.post('/api/ai/ask', async (req, res) => {
    const { query } = req.body;
    if (!query) {
      return res.status(400).json({ error: 'Query is required' });
    }
    const result = await SecretariatAiEngine.answerInstitutionalQuery(query);
    res.json({ status: 'OK', result });
  });

  app.post('/api/ai/draft-report', async (req, res) => {
    const { reportType = 'MOMR_SUMMARY' } = req.body;
    const draft = await SecretariatAiEngine.draftInstitutionalReport(reportType);
    res.json({ status: 'OK', reportType, draft });
  });

  // Mount Vite middleware in development
  const isProduction = process.env.NODE_ENV === 'production';
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa'
    });
    app.use(vite.middlewares);
  } else {
    // Serve production static files if dist exists
    app.use(express.static('dist'));
    app.get('*', (_req, res) => {
      res.sendFile('dist/index.html', { root: '.' });
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ENERGY SECRETARIAT OS running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
