package com.example.data.remote

import com.example.BuildConfig
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object GeminiService {
    private const val MODEL_NAME = "gemini-3.5-flash"
    private const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models/$MODEL_NAME:generateContent"

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    suspend fun generateAssistResponse(
        userPrompt: String,
        shipmentContext: String
    ): String = withContext(Dispatchers.IO) {
        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            return@withContext getSmartLocalFallback(userPrompt, shipmentContext)
        }

        try {
            val systemInstruction = """
                You are FedEx Assist, an expert multilingual AI logistics assistant for FedEx global customers.
                Be polite, efficient, clear, and brand-accurate.
                Use the provided context of active shipments when applicable.
                Always clarify that all tracking, customs, and shipping information shown in this app is synthetic/simulated prototype data.
            """.trimIndent()

            val fullPrompt = "$systemInstruction\n\nActive Shipments Context:\n$shipmentContext\n\nUser Question:\n$userPrompt"

            val jsonBody = JSONObject().apply {
                val contents = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val parts = JSONArray().apply {
                            put(JSONObject().put("text", fullPrompt))
                        }
                        put("parts", parts)
                    }
                    put(contentObj)
                }
                put("contents", contents)
            }

            val requestBody = jsonBody.toString().toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url("$BASE_URL?key=$apiKey")
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseString = response.body?.string() ?: ""

            if (response.isSuccessful && responseString.isNotBlank()) {
                val responseJson = JSONObject(responseString)
                val candidates = responseJson.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        val text = parts.getJSONObject(0).optString("text")
                        if (text.isNotBlank()) return@withContext text
                    }
                }
            }
            getSmartLocalFallback(userPrompt, shipmentContext)
        } catch (e: Exception) {
            getSmartLocalFallback(userPrompt, shipmentContext)
        }
    }

    private fun getSmartLocalFallback(userPrompt: String, shipmentContext: String): String {
        val lower = userPrompt.lowercase()
        return when {
            lower.contains("where is my package") || lower.contains("track") -> {
                "📦 **Package Tracking Status:**\n\n" +
                "• **7812394821** (FedEx Express): Out for delivery today in New York (ETA 14:00–16:00).\n" +
                "• **9823410928** (International Priority): In transit from London Hub to JFK International Airport.\n" +
                "• **3491204859** (Return Label): Drop-off scan registered at FedEx Office London.\n\n" +
                "*(Note: All tracking data is synthetic prototype simulation).* "
            }
            lower.contains("arrive") || lower.contains("when") -> {
                "⏱️ **Estimated Delivery Schedule:**\n\n" +
                "• Package **7812394821**: Arriving **Today between 14:00–16:00**.\n" +
                "• Package **9823410928**: Estimated arrival tomorrow at 10:30 AM.\n\n" +
                "You can use Delivery Manager to request a safe-place drop-off or hold at a FedEx location."
            }
            lower.contains("cost") || lower.contains("rate") || lower.contains("germany") || lower.contains("price") -> {
                "✈️ **Estimated FedEx Express Shipping to Germany (5 kg):**\n\n" +
                "• **FedEx International Priority**: $118.50 (Est. 1-2 Business Days)\n" +
                "• **FedEx International Economy**: $74.20 (Est. 3-5 Business Days)\n" +
                "• **FedEx First Overseas**: $165.00 (Est. Next Day 9:00 AM)\n\n" +
                "Prices include fuel surcharge & customs documentation assistance."
            }
            lower.contains("location") || lower.contains("office") || lower.contains("nearest") || lower.contains("drop") -> {
                "📍 **Nearest FedEx Locations:**\n\n" +
                "1. **FedEx Office Print & Ship Center** — 0.8 km (Open until 20:00)\n" +
                "   *Address: 452 Fifth Avenue, New York, NY*\n" +
                "2. **FedEx Self-Service Locker 24/7** — 1.2 km (Open 24 Hours)\n" +
                "   *Address: 120 Broadway Station, New York, NY*"
            }
            lower.contains("customs") || lower.contains("documents") || lower.contains("duties") || lower.contains("delay") -> {
                "🛃 **International Customs Clearance Guidance:**\n\n" +
                "For international shipments (e.g. UK to US):\n" +
                "• **Required Documents:** Commercial Invoice (3 copies), Certificate of Origin, HS Code classification.\n" +
                "• **Estimated Duties & Taxes:** $38.40 (Paid via FedEx Billing).\n" +
                "• **Status:** Documentation submitted, clearance in progress at JFK Clearance Hub."
            }
            else -> {
                "Hello! I am **FedEx Assist**, your global logistics AI assistant.\n\n" +
                "I can help you with:\n" +
                "• Tracking shipments & checking delivery times\n" +
                "• Calculating FedEx Express rates worldwide\n" +
                "• Managing customs documents & clearance\n" +
                "• Finding FedEx Office locations & 24/7 lockers\n" +
                "• Scheduling pickups or creating return labels"
            }
        }
    }
}
