package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ShipmentStatus(val label: String) {
    LABEL_CREATED("Label created"),
    PICKED_UP("Picked up"),
    FEDEX_FACILITY("FedEx facility"),
    INTL_TRANSIT("International transit"),
    OUT_FOR_DELIVERY("Out for delivery"),
    DELIVERED("Delivered"),
    DELAYED("Delayed / Exception")
}

data class ScanEvent(
    val timestamp: String,
    val status: ShipmentStatus,
    val location: String,
    val description: String,
    val isCompleted: Boolean = true
)

data class CustomsInfo(
    val status: String,
    val requiredDocs: List<String>,
    val estimatedDutiesUsd: Double,
    val clearanceProgressPercent: Float,
    val notes: String
)

data class DeliveryOptions(
    val dateOption: String? = null,
    val holdAtLocation: String? = null,
    val deliverToNeighbor: String? = null,
    val safePlaceInstructions: String? = null,
    val pickupLockerId: String? = null
)

data class ReturnInfo(
    val originalTrackingNumber: String,
    val returnTrackingNumber: String,
    val returnMethod: String,
    val qrCodePayload: String,
    val statusText: String
)

@Entity(tableName = "shipments")
data class Shipment(
    @PrimaryKey val trackingNumber: String,
    val title: String,
    val senderName: String,
    val senderCityCountry: String,
    val recipientName: String,
    val recipientCityCountry: String,
    val carrierService: String, // e.g. "FedEx Express", "FedEx International Priority"
    val status: ShipmentStatus,
    val etaText: String,
    val etaTimeWindow: String,
    val weightKg: Double,
    val packageSize: String,
    val originLat: Float,
    val originLng: Float,
    val destLat: Float,
    val destLng: Float,
    val currentLat: Float,
    val currentLng: Float,
    val driverName: String? = null,
    val timelineJson: String, // Serialized ScanEvent list
    val customsInfoJson: String? = null, // Serialized CustomsInfo
    val deliveryOptionsJson: String? = null, // Serialized DeliveryOptions
    val returnInfoJson: String? = null, // Serialized ReturnInfo
    val isBusiness: Boolean = false,
    val isSaved: Boolean = true,
    val lastUpdated: Long = System.currentTimeMillis()
)

@Entity(tableName = "fedex_locations")
data class FedExLocation(
    @PrimaryKey val id: String,
    val name: String,
    val locationType: String, // "FedEx Office", "Pickup Location", "Drop-off Location", "Locker"
    val address: String,
    val distanceKm: Double,
    val openHours: String,
    val servicesJson: String, // Serialized List<String>
    val lat: Float,
    val lng: Float
)

@Entity(tableName = "documents")
data class FedExDocument(
    @PrimaryKey val id: String,
    val trackingNumber: String,
    val title: String,
    val docType: String, // "Shipping Label", "Customs Form", "Commercial Invoice", "Receipt", "Delivery Confirmation"
    val dateText: String,
    val summaryText: String,
    val pdfUrl: String? = null
)

@Entity(tableName = "notifications")
data class AppNotification(
    @PrimaryKey val id: String,
    val trackingNumber: String?,
    val title: String,
    val message: String,
    val timeAgo: String,
    val notificationType: String, // "OUT_FOR_DELIVERY", "DELAY", "DELIVERED", "CUSTOMS", "BUSINESS"
    val isRead: Boolean = false
)

data class ShippingRateOption(
    val serviceName: String,
    val speedCategory: String, // "Priority", "Express", "Standard", "Economy"
    val deliveryDaysText: String,
    val estArrivalDate: String,
    val priceUsd: Double,
    val badge: String? = null
)

data class LanguageOption(
    val code: String,
    val displayName: String,
    val nativeName: String,
    val flagEmoji: String
)

data class ChatMessage(
    val id: String,
    val sender: String, // "USER" or "ASSISTANT"
    val text: String,
    val timestamp: String = "Just now",
    val suggestedActions: List<String> = emptyList()
)
