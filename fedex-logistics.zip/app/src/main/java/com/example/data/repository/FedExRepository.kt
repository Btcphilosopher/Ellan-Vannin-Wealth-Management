package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.model.*
import com.squareup.moshi.Moshi
import com.squareup.moshi.Types
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

class FedExRepository(context: Context) {
    private val db = AppDatabase.getDatabase(context)
    private val shipmentDao = db.shipmentDao()
    private val locationDao = db.locationDao()
    private val documentDao = db.documentDao()
    private val notificationDao = db.notificationDao()

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()

    val allShipments: Flow<List<Shipment>> = shipmentDao.getAllShipments()
    val allLocations: Flow<List<FedExLocation>> = locationDao.getAllLocations()
    val allDocuments: Flow<List<FedExDocument>> = documentDao.getAllDocuments()
    val allNotifications: Flow<List<AppNotification>> = notificationDao.getAllNotifications()

    fun getShipmentsByMode(isBusiness: Boolean): Flow<List<Shipment>> {
        return shipmentDao.getShipmentsByMode(isBusiness)
    }

    fun observeShipment(trackingNumber: String): Flow<Shipment?> {
        return shipmentDao.observeShipmentByTrackingNumber(trackingNumber)
    }

    suspend fun getShipment(trackingNumber: String): Shipment? {
        return shipmentDao.getShipmentByTrackingNumber(trackingNumber)
    }

    suspend fun seedDatabaseIfEmpty() = withContext(Dispatchers.IO) {
        val existing = shipmentDao.getAllShipments().first()
        if (existing.isNotEmpty()) return@withContext

        // Seed Sample Shipments
        val sampleShipments = listOf(
            createShipmentObj(
                trackingNumber = "7812394821",
                title = "High-Priority Electronics Component",
                senderName = "Tech Global Ltd",
                senderCityCountry = "London, UK",
                recipientName = "John Doe",
                recipientCityCountry = "New York, USA",
                carrierService = "FedEx Express",
                status = ShipmentStatus.OUT_FOR_DELIVERY,
                etaText = "Arriving Today",
                etaTimeWindow = "14:00 – 16:00",
                weightKg = 4.8,
                packageSize = "Medium Box",
                originLat = 51.5074f,
                originLng = -0.1278f,
                destLat = 40.7128f,
                destLng = -74.0060f,
                currentLat = 40.7300f,
                currentLng = -73.9900f,
                driverName = "Michael Vance (FedEx Express Courier #402)",
                isBusiness = false,
                timelineEvents = listOf(
                    ScanEvent("08:15 AM", ShipmentStatus.OUT_FOR_DELIVERY, "New York Station, NY", "On FedEx vehicle for delivery - Courier Michael V.", true),
                    ScanEvent("05:40 AM", ShipmentStatus.FEDEX_FACILITY, "New York Sorting Facility, NY", "Arrived at local distribution hub", true),
                    ScanEvent("01:20 AM", ShipmentStatus.INTL_TRANSIT, "JFK International Airport, NY", "In transit - Customs cleared", true),
                    ScanEvent("Yesterday 22:10", ShipmentStatus.INTL_TRANSIT, "Heathrow International Hub, UK", "Departed FedEx origin facility", true),
                    ScanEvent("Yesterday 15:30", ShipmentStatus.PICKED_UP, "London Central, UK", "Picked up by FedEx Express courier", true),
                    ScanEvent("Yesterday 10:00", ShipmentStatus.LABEL_CREATED, "London, UK", "Shipment information sent to FedEx", true)
                ),
                customsInfo = CustomsInfo(
                    status = "Cleared by US Customs",
                    requiredDocs = listOf("Commercial Invoice", "Declaration Form"),
                    estimatedDutiesUsd = 38.40,
                    clearanceProgressPercent = 1.0f,
                    notes = "Duties & Taxes prepaid by sender."
                ),
                deliveryOptions = DeliveryOptions(
                    dateOption = "Today, 14:00 - 16:00",
                    holdAtLocation = "FedEx Office - 452 Fifth Ave, NY",
                    deliverToNeighbor = "Apt 4B - Sarah Jenkins",
                    safePlaceInstructions = "Front porch behind planter box",
                    pickupLockerId = "LOCKER-NY-42"
                )
            ),

            createShipmentObj(
                trackingNumber = "9823410928",
                title = "Medical Supplies & Diagnostics Kit",
                senderName = "PharmaCare Europe",
                senderCityCountry = "Frankfurt, Germany",
                recipientName = "Biomedical Research Inc.",
                recipientCityCountry = "Boston, MA, USA",
                carrierService = "FedEx International Priority",
                status = ShipmentStatus.INTL_TRANSIT,
                etaText = "Tomorrow",
                etaTimeWindow = "10:30 AM",
                weightKg = 12.5,
                packageSize = "Large Freight Box",
                originLat = 50.1109f,
                originLng = 8.6821f,
                destLat = 42.3601f,
                destLng = -71.0589f,
                currentLat = 50.0333f,
                currentLng = 8.5705f,
                driverName = null,
                isBusiness = true,
                timelineEvents = listOf(
                    ScanEvent("03:10 AM", ShipmentStatus.INTL_TRANSIT, "Frankfurt Air Hub (EDDF)", "In transit via FedEx Cargo Flight FX-018", true),
                    ScanEvent("Yesterday 21:00", ShipmentStatus.FEDEX_FACILITY, "Frankfurt Sorting Facility", "Processed at FedEx location", true),
                    ScanEvent("Yesterday 14:00", ShipmentStatus.PICKED_UP, "Frankfurt Industrial Park", "Picked up by FedEx Express", true),
                    ScanEvent("Yesterday 09:15", ShipmentStatus.LABEL_CREATED, "Frankfurt, Germany", "Label created", true)
                ),
                customsInfo = CustomsInfo(
                    status = "Documentation Required",
                    requiredDocs = listOf("Biomedical Import Permit", "Commercial Invoice (3 copies)", "FDA Form 2877"),
                    estimatedDutiesUsd = 142.50,
                    clearanceProgressPercent = 0.65f,
                    notes = "Pending FDA electronic document review at port of entry."
                )
            ),

            createShipmentObj(
                trackingNumber = "3491204859",
                title = "Apparel Sample Return Package",
                senderName = "Emma Watson",
                senderCityCountry = "London, UK",
                recipientName = "Fashion Logistics Hub",
                recipientCityCountry = "Milan, Italy",
                carrierService = "FedEx Standard Return",
                status = ShipmentStatus.LABEL_CREATED,
                etaText = "Estimated 3 Days",
                etaTimeWindow = "By End of Day",
                weightKg = 2.1,
                packageSize = "FedEx Pak",
                originLat = 51.5074f,
                originLng = -0.1278f,
                destLat = 45.4642f,
                destLng = 9.1900f,
                currentLat = 51.5074f,
                currentLng = -0.1278f,
                driverName = null,
                isBusiness = false,
                timelineEvents = listOf(
                    ScanEvent("09:00 AM", ShipmentStatus.LABEL_CREATED, "London, UK", "Return shipping label generated", true)
                ),
                returnInfo = ReturnInfo(
                    originalTrackingNumber = "7812394821",
                    returnTrackingNumber = "3491204859",
                    returnMethod = "FedEx Office Drop-off",
                    qrCodePayload = "FEDEX-RETURN-3491204859",
                    statusText = "Ready for Drop-off at any FedEx Location"
                )
            ),

            createShipmentObj(
                trackingNumber = "4510293847",
                title = "Precision Robotics Motor Assemblies",
                senderName = "Nippon Automation Co.",
                senderCityCountry = "Tokyo, Japan",
                recipientName = "Automotive West Coast",
                recipientCityCountry = "Los Angeles, CA, USA",
                carrierService = "FedEx International First",
                status = ShipmentStatus.DELIVERED,
                etaText = "Delivered",
                etaTimeWindow = "Delivered at 10:15 AM",
                weightKg = 28.0,
                packageSize = "Pallet / Heavy Duty Box",
                originLat = 35.6762f,
                originLng = 139.6503f,
                destLat = 34.0522f,
                destLng = -118.2437f,
                currentLat = 34.0522f,
                currentLng = -118.2437f,
                driverName = "Carlos R. (FedEx Courier)",
                isBusiness = true,
                timelineEvents = listOf(
                    ScanEvent("10:15 AM", ShipmentStatus.DELIVERED, "Los Angeles, CA", "Delivered - Signed by J. MILLER at Receiving Dock", true),
                    ScanEvent("07:30 AM", ShipmentStatus.OUT_FOR_DELIVERY, "Los Angeles West Facility", "On vehicle for delivery", true),
                    ScanEvent("02:15 AM", ShipmentStatus.FEDEX_FACILITY, "LAX Express Terminal", "Sorted at destination facility", true),
                    ScanEvent("2 Days Ago", ShipmentStatus.INTL_TRANSIT, "Narita Cargo Hub, Japan", "In flight FX-088", true),
                    ScanEvent("3 Days Ago", ShipmentStatus.PICKED_UP, "Tokyo Technology Park", "Picked up", true)
                )
            )
        )

        shipmentDao.insertShipments(sampleShipments)

        // Seed Sample Locations
        val sampleLocations = listOf(
            FedExLocation(
                id = "LOC-101",
                name = "FedEx Office Print & Ship Center",
                locationType = "FedEx Office",
                address = "452 Fifth Avenue, New York, NY 10018",
                distanceKm = 0.8,
                openHours = "Mon–Fri: 07:30–21:00 | Sat: 09:00–18:00",
                servicesJson = serializeList(listOf("Packing Services", "Passport Photos", "Hold at Location", "Express Shipping", "Direct Print")),
                lat = 40.7510f,
                lng = -73.9820f
            ),
            FedExLocation(
                id = "LOC-102",
                name = "FedEx Self-Service Locker 24/7",
                locationType = "Locker",
                address = "120 Broadway Station, New York, NY 10005",
                distanceKm = 1.4,
                openHours = "Open 24 Hours / 7 Days",
                servicesJson = serializeList(listOf("Contactless Pickup", "Return Drop-off", "24/7 Access")),
                lat = 40.7080f,
                lng = -74.0110f
            ),
            FedExLocation(
                id = "LOC-103",
                name = "Walgreens (FedEx Drop-off)",
                locationType = "Drop-off Location",
                address = "148 E 86th St, New York, NY 10028",
                distanceKm = 2.1,
                openHours = "Daily: 08:00–22:00",
                servicesJson = serializeList(listOf("Pre-labeled Drop-off", "Package Hold")),
                lat = 40.7790f,
                lng = -73.9550f
            ),
            FedExLocation(
                id = "LOC-104",
                name = "FedEx World Service Center",
                locationType = "Pickup Location",
                address = "Heathrow Hub Cargo Center, London TW6 3UA, UK",
                distanceKm = 4.5,
                openHours = "Mon–Fri: 06:00–22:00",
                servicesJson = serializeList(listOf("International Clearance", "Dangerous Goods", "Heavy Freight", "Customs Brokerage")),
                lat = 51.4700f,
                lng = -0.4543f
            )
        )
        locationDao.insertLocations(sampleLocations)

        // Seed Documents
        val sampleDocuments = listOf(
            FedExDocument(
                id = "DOC-1001",
                trackingNumber = "7812394821",
                title = "Official Air Waybill / Shipping Label",
                docType = "Shipping Label",
                dateText = "Aug 12, 2026",
                summaryText = "FedEx Express 2-Day Air Waybill #7812394821 (Origin: London, Dest: NY)"
            ),
            FedExDocument(
                id = "DOC-1002",
                trackingNumber = "7812394821",
                title = "Commercial Invoice & Customs Declaration",
                docType = "Commercial Invoice",
                dateText = "Aug 12, 2026",
                summaryText = "Declared Value $450.00 USD - HS Code 8542.31 Electronics"
            ),
            FedExDocument(
                id = "DOC-1003",
                trackingNumber = "9823410928",
                title = "FDA Clearance & Import Certificate",
                docType = "Customs Form",
                dateText = "Aug 11, 2026",
                summaryText = "Biomedical device entry authorization #FDA-2026-98210"
            ),
            FedExDocument(
                id = "DOC-1004",
                trackingNumber = "4510293847",
                title = "Proof of Delivery & Electronic Signature",
                docType = "Delivery Confirmation",
                dateText = "Aug 10, 2026",
                summaryText = "Signed by J. MILLER at Los Angeles Dock B at 10:15 AM"
            )
        )
        documentDao.insertDocuments(sampleDocuments)

        // Seed Notifications
        val sampleNotifications = listOf(
            AppNotification(
                id = "NOTIF-1",
                trackingNumber = "7812394821",
                title = "📦 OUT FOR DELIVERY",
                message = "Your FedEx Express package is arriving today between 14:00–16:00. Driver Michael Vance is on the way.",
                timeAgo = "30m ago",
                notificationType = "OUT_FOR_DELIVERY"
            ),
            AppNotification(
                id = "NOTIF-2",
                trackingNumber = "9823410928",
                title = "⚠️ CUSTOMS UPDATE",
                message = "Biomedical import documentation required for shipment 9823410928 from Frankfurt.",
                timeAgo = "2h ago",
                notificationType = "CUSTOMS"
            ),
            AppNotification(
                id = "NOTIF-3",
                trackingNumber = "4510293847",
                title = "✓ DELIVERED",
                message = "Shipment 4510293847 delivered to Los Angeles Dock B at 10:15 AM.",
                timeAgo = "Yesterday",
                notificationType = "DELIVERED"
            )
        )
        notificationDao.insertNotifications(sampleNotifications)
    }

    suspend fun createNewShipment(
        senderCity: String,
        recipientCity: String,
        packageSize: String,
        weightKg: Double,
        serviceType: String,
        priceUsd: Double,
        isBusiness: Boolean
    ): Shipment = withContext(Dispatchers.IO) {
        val trackingNum = "7" + (100000000..999999999).random()
        val createdShipment = createShipmentObj(
            trackingNumber = trackingNum,
            title = "Package: $packageSize ($weightKg kg)",
            senderName = "Sender ($senderCity)",
            senderCityCountry = senderCity,
            recipientName = "Recipient ($recipientCity)",
            recipientCityCountry = recipientCity,
            carrierService = serviceType,
            status = ShipmentStatus.LABEL_CREATED,
            etaText = "Est. 2-3 Days",
            etaTimeWindow = "09:00 - 18:00",
            weightKg = weightKg,
            packageSize = packageSize,
            originLat = 51.5074f,
            originLng = -0.1278f,
            destLat = 40.7128f,
            destLng = -74.0060f,
            currentLat = 51.5074f,
            currentLng = -0.1278f,
            isBusiness = isBusiness,
            timelineEvents = listOf(
                ScanEvent("Just now", ShipmentStatus.LABEL_CREATED, senderCity, "Shipment created & air waybill generated", true)
            )
        )
        shipmentDao.insertShipment(createdShipment)

        // Add corresponding shipping label document
        documentDao.insertDocument(
            FedExDocument(
                id = "DOC-${System.currentTimeMillis()}",
                trackingNumber = trackingNum,
                title = "FedEx Air Waybill - $serviceType",
                docType = "Shipping Label",
                dateText = "Today",
                summaryText = "Generated shipping label for $senderCity to $recipientCity ($priceUsd USD)"
            )
        )

        createdShipment
    }

    suspend fun updateDeliveryInstructions(
        trackingNumber: String,
        dateOption: String?,
        holdLocation: String?,
        safePlace: String?,
        neighbor: String?
    ) = withContext(Dispatchers.IO) {
        val current = shipmentDao.getShipmentByTrackingNumber(trackingNumber) ?: return@withContext
        val currentOpts = deserializeDeliveryOptions(current.deliveryOptionsJson) ?: DeliveryOptions()
        val updatedOpts = currentOpts.copy(
            dateOption = dateOption ?: currentOpts.dateOption,
            holdAtLocation = holdLocation ?: currentOpts.holdAtLocation,
            safePlaceInstructions = safePlace ?: currentOpts.safePlaceInstructions,
            deliverToNeighbor = neighbor ?: currentOpts.deliverToNeighbor
        )
        val updatedShipment = current.copy(
            deliveryOptionsJson = serializeDeliveryOptions(updatedOpts),
            lastUpdated = System.currentTimeMillis()
        )
        shipmentDao.updateShipment(updatedShipment)

        notificationDao.insertNotification(
            AppNotification(
                id = "NOTIF-${System.currentTimeMillis()}",
                trackingNumber = trackingNumber,
                title = "📝 DELIVERY PREFERENCES UPDATED",
                message = "Your instructions for package $trackingNumber have been saved and sent to driver.",
                timeAgo = "Just now",
                notificationType = "OUT_FOR_DELIVERY"
            )
        )
    }

    suspend fun createReturnLabel(
        originalTrackingNumber: String,
        returnMethod: String
    ): Shipment = withContext(Dispatchers.IO) {
        val returnTracking = "3" + (100000000..999999999).random()
        val returnInfo = ReturnInfo(
            originalTrackingNumber = originalTrackingNumber,
            returnTrackingNumber = returnTracking,
            returnMethod = returnMethod,
            qrCodePayload = "FEDEX-RETURN-$returnTracking",
            statusText = "Return label created - Ready for $returnMethod"
        )

        val returnShipment = createShipmentObj(
            trackingNumber = returnTracking,
            title = "Return for #$originalTrackingNumber",
            senderName = "Customer Return",
            senderCityCountry = "Customer Address",
            recipientName = "FedEx Return Center",
            recipientCityCountry = "Logistics Return Hub",
            carrierService = "FedEx Ground Return",
            status = ShipmentStatus.LABEL_CREATED,
            etaText = "Estimated 3 Days",
            etaTimeWindow = "By End of Day",
            weightKg = 3.0,
            packageSize = "Return Box",
            originLat = 40.7128f,
            originLng = -74.0060f,
            destLat = 41.8781f,
            destLng = -87.6298f,
            currentLat = 40.7128f,
            currentLng = -74.0060f,
            timelineEvents = listOf(
                ScanEvent("Just now", ShipmentStatus.LABEL_CREATED, "Customer Origin", "Return label created", true)
            ),
            returnInfo = returnInfo
        )

        shipmentDao.insertShipment(returnShipment)
        returnShipment
    }

    suspend fun markNotificationRead(id: String) = withContext(Dispatchers.IO) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllNotificationsRead() = withContext(Dispatchers.IO) {
        notificationDao.markAllAsRead()
    }

    // JSON Helper Serialization
    private fun createShipmentObj(
        trackingNumber: String,
        title: String,
        senderName: String,
        senderCityCountry: String,
        recipientName: String,
        recipientCityCountry: String,
        carrierService: String,
        status: ShipmentStatus,
        etaText: String,
        etaTimeWindow: String,
        weightKg: Double,
        packageSize: String,
        originLat: Float,
        originLng: Float,
        destLat: Float,
        destLng: Float,
        currentLat: Float,
        currentLng: Float,
        driverName: String? = null,
        isBusiness: Boolean = false,
        timelineEvents: List<ScanEvent>,
        customsInfo: CustomsInfo? = null,
        deliveryOptions: DeliveryOptions? = null,
        returnInfo: ReturnInfo? = null
    ): Shipment {
        return Shipment(
            trackingNumber = trackingNumber,
            title = title,
            senderName = senderName,
            senderCityCountry = senderCityCountry,
            recipientName = recipientName,
            recipientCityCountry = recipientCityCountry,
            carrierService = carrierService,
            status = status,
            etaText = etaText,
            etaTimeWindow = etaTimeWindow,
            weightKg = weightKg,
            packageSize = packageSize,
            originLat = originLat,
            originLng = originLng,
            destLat = destLat,
            destLng = destLng,
            currentLat = currentLat,
            currentLng = currentLng,
            driverName = driverName,
            timelineJson = serializeEvents(timelineEvents),
            customsInfoJson = customsInfo?.let { serializeCustoms(it) },
            deliveryOptionsJson = deliveryOptions?.let { serializeDeliveryOptions(it) },
            returnInfoJson = returnInfo?.let { serializeReturnInfo(it) },
            isBusiness = isBusiness,
            isSaved = true
        )
    }

    fun deserializeEvents(json: String): List<ScanEvent> {
        return try {
            val type = Types.newParameterizedType(List::class.java, ScanEvent::class.java)
            moshi.adapter<List<ScanEvent>>(type).fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun serializeEvents(events: List<ScanEvent>): String {
        val type = Types.newParameterizedType(List::class.java, ScanEvent::class.java)
        return moshi.adapter<List<ScanEvent>>(type).toJson(events)
    }

    fun deserializeCustoms(json: String?): CustomsInfo? {
        if (json.isNull_or_blank()) return null
        return try {
            moshi.adapter(CustomsInfo::class.java).fromJson(json)
        } catch (e: Exception) {
            null
        }
    }

    private fun serializeCustoms(customsInfo: CustomsInfo): String {
        return moshi.adapter(CustomsInfo::class.java).toJson(customsInfo)
    }

    fun deserializeDeliveryOptions(json: String?): DeliveryOptions? {
        if (json.isNull_or_blank()) return null
        return try {
            moshi.adapter(DeliveryOptions::class.java).fromJson(json)
        } catch (e: Exception) {
            null
        }
    }

    private fun serializeDeliveryOptions(options: DeliveryOptions): String {
        return moshi.adapter(DeliveryOptions::class.java).toJson(options)
    }

    fun deserializeReturnInfo(json: String?): ReturnInfo? {
        if (json.isNull_or_blank()) return null
        return try {
            moshi.adapter(ReturnInfo::class.java).fromJson(json)
        } catch (e: Exception) {
            null
        }
    }

    private fun serializeReturnInfo(info: ReturnInfo): String {
        return moshi.adapter(ReturnInfo::class.java).toJson(info)
    }

    private fun serializeList(list: List<String>): String {
        val type = Types.newParameterizedType(List::class.java, String::class.java)
        return moshi.adapter<List<String>>(type).toJson(list)
    }

    fun deserializeList(json: String): List<String> {
        return try {
            val type = Types.newParameterizedType(List::class.java, String::class.java)
            moshi.adapter<List<String>>(type).fromJson(json) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun String?.isNull_or_blank(): Boolean = this == null || this.isBlank()
}
