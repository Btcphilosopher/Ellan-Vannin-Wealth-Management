package com.example.data.local

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ShipmentDao {
    @Query("SELECT * FROM shipments ORDER BY lastUpdated DESC")
    fun getAllShipments(): Flow<List<Shipment>>

    @Query("SELECT * FROM shipments WHERE isBusiness = :isBusiness ORDER BY lastUpdated DESC")
    fun getShipmentsByMode(isBusiness: Boolean): Flow<List<Shipment>>

    @Query("SELECT * FROM shipments WHERE trackingNumber = :trackingNumber")
    suspend fun getShipmentByTrackingNumber(trackingNumber: String): Shipment?

    @Query("SELECT * FROM shipments WHERE trackingNumber = :trackingNumber")
    fun observeShipmentByTrackingNumber(trackingNumber: String): Flow<Shipment?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShipment(shipment: Shipment)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShipments(shipments: List<Shipment>)

    @Update
    suspend fun updateShipment(shipment: Shipment)

    @Query("DELETE FROM shipments WHERE trackingNumber = :trackingNumber")
    suspend fun deleteShipment(trackingNumber: String)
}

@Dao
interface LocationDao {
    @Query("SELECT * FROM fedex_locations ORDER BY distanceKm ASC")
    fun getAllLocations(): Flow<List<FedExLocation>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLocations(locations: List<FedExLocation>)
}

@Dao
interface DocumentDao {
    @Query("SELECT * FROM documents ORDER BY id DESC")
    fun getAllDocuments(): Flow<List<FedExDocument>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocuments(documents: List<FedExDocument>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDocument(document: FedExDocument)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications ORDER BY id DESC")
    fun getAllNotifications(): Flow<List<AppNotification>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotifications(notifications: List<AppNotification>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotification)

    @Query("UPDATE notifications SET isRead = 1 WHERE id = :id")
    suspend fun markAsRead(id: String)

    @Query("UPDATE notifications SET isRead = 1")
    suspend fun markAllAsRead()
}
