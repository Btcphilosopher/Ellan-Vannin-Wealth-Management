package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ScanEvent
import com.example.data.model.Shipment
import com.example.data.model.ShipmentStatus
import com.example.ui.theme.*

@Composable
fun TopHeaderBar(
    isBusinessMode: Boolean,
    onToggleBusinessMode: (Boolean) -> Unit,
    unreadNotifCount: Int,
    onOpenNotifs: () -> Unit,
    onOpenAccount: () -> Unit
) {
    Surface(
        color = FedExPurple,
        contentColor = Color.White,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // FedEx Logo Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onOpenAccount() }
            ) {
                Surface(
                    color = Color.White,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.padding(end = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Fed",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp,
                            color = FedExPurple
                        )
                        Text(
                            text = "Ex",
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp,
                            color = FedExOrange
                        )
                    }
                }

                Column {
                    Text(
                        text = if (isBusinessMode) "BUSINESS LOGISTICS" else "GLOBAL EXPRESS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FedExOrangeLight,
                        letterSpacing = 1.sp
                    )
                }
            }

            // Mode Switcher & Notifications
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Business / Personal Pill Switch
                Surface(
                    color = FedExPurpleDark,
                    shape = RoundedCornerShape(20.dp),
                    modifier = Modifier
                        .clickable { onToggleBusinessMode(!isBusinessMode) }
                        .testTag("mode_toggle_button")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isBusinessMode) Icons.Default.BusinessCenter else Icons.Default.Person,
                            contentDescription = "Mode Switch",
                            tint = FedExOrange,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isBusinessMode) "Business" else "Personal",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // Notification Bell with Badge
                IconButton(
                    onClick = onOpenNotifs,
                    modifier = Modifier.testTag("notification_bell_button")
                ) {
                    BadgedBox(
                        badge = {
                            if (unreadNotifCount > 0) {
                                Badge(containerColor = FedExOrange) {
                                    Text("$unreadNotifCount", color = Color.White)
                                }
                            }
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Outlined.Notifications,
                            contentDescription = "Notifications",
                            tint = Color.White
                        )
                    }
                }

                IconButton(
                    onClick = onOpenAccount,
                    modifier = Modifier.testTag("account_profile_button")
                ) {
                    Icon(
                        imageVector = Icons.Outlined.AccountCircle,
                        contentDescription = "Account Settings",
                        tint = Color.White
                    )
                }
            }
        }
    }
}

@Composable
fun ShipmentStatusChip(status: ShipmentStatus) {
    val (bgColor, textColor, icon) = when (status) {
        ShipmentStatus.DELIVERED -> Triple(FedExGreenContainer, FedExGreen, Icons.Default.CheckCircle)
        ShipmentStatus.OUT_FOR_DELIVERY -> Triple(FedExOrangeContainer, FedExOrangeDark, Icons.Default.LocalShipping)
        ShipmentStatus.INTL_TRANSIT -> Triple(FedExPurpleContainer, FedExPurple, Icons.Default.FlightTakeoff)
        ShipmentStatus.FEDEX_FACILITY -> Triple(FedExPurpleContainer, FedExPurple, Icons.Default.Domain)
        ShipmentStatus.PICKED_UP -> Triple(FedExOrangeContainer, FedExOrangeDark, Icons.Default.Inventory2)
        ShipmentStatus.LABEL_CREATED -> Triple(Color(0xFFE8EAED), Color(0xFF3C4043), Icons.Default.QrCode)
        ShipmentStatus.DELAYED -> Triple(FedExRedContainer, FedExRed, Icons.Default.Warning)
    }

    Surface(
        color = bgColor,
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = status.label,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = textColor
            )
        }
    }
}

@Composable
fun TrackingTimelineView(
    events: List<ScanEvent>,
    currentStatus: ShipmentStatus
) {
    val allStatuses = listOf(
        ShipmentStatus.LABEL_CREATED,
        ShipmentStatus.PICKED_UP,
        ShipmentStatus.FEDEX_FACILITY,
        ShipmentStatus.INTL_TRANSIT,
        ShipmentStatus.OUT_FOR_DELIVERY,
        ShipmentStatus.DELIVERED
    )

    val currentIndex = allStatuses.indexOf(currentStatus).let { if (it == -1) 3 else it }

    Column(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(
            text = "SHIPMENT TIMELINE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        allStatuses.forEachIndexed { index, status ->
            val isCompleted = index <= currentIndex
            val isCurrent = index == currentIndex

            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                // Line + Indicator Node Column
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(36.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(if (isCurrent) 22.dp else 16.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isCurrent -> FedExOrange
                                    isCompleted -> FedExPurple
                                    else -> Color(0xFFE0E0E0)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCompleted) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }

                    if (index < allStatuses.size - 1) {
                        Box(
                            modifier = Modifier
                                .width(3.dp)
                                .height(38.dp)
                                .background(
                                    if (index < currentIndex) FedExPurple else Color(0xFFE0E0E0)
                                )
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Event text info
                val event = events.find { it.status == status }
                Column(modifier = Modifier.weight(1f).padding(bottom = 8.dp)) {
                    Text(
                        text = status.label,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 14.sp,
                        color = if (isCompleted) MaterialTheme.colorScheme.onSurface else Color.Gray
                    )

                    if (event != null) {
                        Text(
                            text = "${event.timestamp} • ${event.location}",
                            fontSize = 12.sp,
                            color = FedExPurple
                        )
                        if (event.description.isNotBlank()) {
                            Text(
                                text = event.description,
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                        }
                    } else if (isCurrent) {
                        Text(
                            text = "In progress",
                            fontSize = 12.sp,
                            color = FedExOrange,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RouteMapCanvas(
    originCity: String,
    destCity: String,
    status: ShipmentStatus,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAnim by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = NeutralDark),
        modifier = modifier
            .fillMaxWidth()
            .height(180.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Draw custom simulated route graphics
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                val p1 = Offset(width * 0.18f, height * 0.65f)
                val p2 = Offset(width * 0.82f, height * 0.35f)
                val controlPoint = Offset(width * 0.5f, height * 0.10f)

                // Draw background grid lines for tactical logistics map feel
                for (i in 1..4) {
                    val y = height * (i / 5f)
                    drawLine(
                        color = Color.White.copy(alpha = 0.08f),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1f
                    )
                }
                for (i in 1..6) {
                    val x = width * (i / 7f)
                    drawLine(
                        color = Color.White.copy(alpha = 0.08f),
                        start = Offset(x, 0f),
                        end = Offset(x, height),
                        strokeWidth = 1f
                    )
                }

                // Curved Flight/Route Line
                val path = Path().apply {
                    moveTo(p1.x, p1.y)
                    quadraticTo(controlPoint.x, controlPoint.y, p2.x, p2.y)
                }

                drawPath(
                    path = path,
                    color = Color.White.copy(alpha = 0.3f),
                    style = Stroke(width = 4f)
                )

                drawPath(
                    path = path,
                    color = FedExOrange,
                    style = Stroke(width = 4f)
                )

                // Origin Node
                drawCircle(color = Color.White, radius = 10f, center = p1)
                drawCircle(color = FedExPurpleLight, radius = 6f, center = p1)

                // Destination Node
                drawCircle(color = Color.White, radius = 10f, center = p2)
                drawCircle(color = FedExOrange, radius = 6f, center = p2)

                // Simulated active package node position
                val currentProgress = when (status) {
                    ShipmentStatus.LABEL_CREATED -> 0.05f
                    ShipmentStatus.PICKED_UP -> 0.25f
                    ShipmentStatus.FEDEX_FACILITY -> 0.45f
                    ShipmentStatus.INTL_TRANSIT -> 0.65f
                    ShipmentStatus.OUT_FOR_DELIVERY -> 0.88f
                    ShipmentStatus.DELIVERED -> 1.0f
                    ShipmentStatus.DELAYED -> 0.60f
                }

                val curX = (1 - currentProgress) * (1 - currentProgress) * p1.x +
                        2 * (1 - currentProgress) * currentProgress * controlPoint.x +
                        currentProgress * currentProgress * p2.x
                val curY = (1 - currentProgress) * (1 - currentProgress) * p1.y +
                        2 * (1 - currentProgress) * currentProgress * controlPoint.y +
                        currentProgress * currentProgress * p2.y

                val activePos = Offset(curX, curY)

                // Pulsing glow
                drawCircle(
                    color = FedExOrange.copy(alpha = 0.4f * pulseAnim),
                    radius = 24f,
                    center = activePos
                )
                drawCircle(color = Color.White, radius = 14f, center = activePos)
                drawCircle(color = FedExOrange, radius = 10f, center = activePos)
            }

            // Overlay City Labels
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .align(Alignment.BottomCenter)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.8f))
                        )
                    )
                    .padding(12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("ORIGIN", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text(originCity, fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FlightTakeoff,
                        contentDescription = null,
                        tint = FedExOrange,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = status.label,
                        fontSize = 11.sp,
                        color = FedExOrange,
                        fontWeight = FontWeight.Bold
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("DESTINATION", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                    Text(destCity, fontSize = 13.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
