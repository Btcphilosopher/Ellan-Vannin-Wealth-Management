package com.example.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun BusinessAnalyticsScreen(
    onBack: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Header
        Surface(
            color = FedExPurple,
            contentColor = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("business_analytics_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("BUSINESS LOGISTICS ANALYTICS", fontSize = 11.sp, color = FedExOrangeLight, fontWeight = FontWeight.Bold)
                    Text("Enterprise Performance & Spend", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // PROMPT EXAMPLE BUSINESS METRICS BANNER
            Text(
                text = "OVERVIEW KPI DASHBOARD",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard("Shipments Today", "248", "+12% vs avg", FedExPurple, Modifier.weight(1f))
                MetricCard("In Transit", "1,204", "On schedule", FedExOrangeDark, Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricCard("Delivered", "4,820", "99.4% SLA", FedExGreen, Modifier.weight(1f))
                MetricCard("Monthly Spend", "$42,840", "Budget: $50k", Color(0xFF1A73E8), Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(24.dp))

            // SHIPMENT VOLUME CHART CARD
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "MONTHLY SHIPMENT VOLUME",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "4,820 Total Deliveries (Past 6 Months)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Custom Bar Chart Canvas
                    val months = listOf("Mar", "Apr", "May", "Jun", "Jul", "Aug")
                    val values = listOf(3200f, 3800f, 4100f, 3900f, 4500f, 4820f)
                    val maxVal = 5000f

                    Canvas(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                    ) {
                        val width = size.width
                        val height = size.height
                        val barWidth = width / (values.size * 2f)

                        values.forEachIndexed { i, valPx ->
                            val barHeight = (valPx / maxVal) * (height - 30f)
                            val x = (i * 2 + 0.5f) * barWidth

                            drawRoundRect(
                                color = if (i == values.size - 1) FedExOrange else FedExPurple,
                                topLeft = Offset(x, height - barHeight - 20f),
                                size = Size(barWidth, barHeight),
                                cornerRadius = CornerRadius(6f, 6f)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        months.forEach { m ->
                            Text(m, fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // DESTINATION BREAKDOWN & SLA PERFORMANCE
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "TOP INTERNATIONAL DESTINATIONS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    DestinationRow("🇺🇸 United States (NY / LA)", "2,140 shipments", "44.4%")
                    DestinationRow("🇬🇧 United Kingdom (London)", "1,280 shipments", "26.5%")
                    DestinationRow("🇩🇪 Germany (Frankfurt)", "840 shipments", "17.4%")
                    DestinationRow("🇯🇵 Japan (Tokyo)", "560 shipments", "11.6%")
                }
            }
        }
    }
}

@Composable
private fun MetricCard(
    title: String,
    value: String,
    subtext: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(4.dp))
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = accentColor)
            Text(subtext, fontSize = 11.sp, color = FedExGreen, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun DestinationRow(country: String, volume: String, percent: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(country, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text(volume, fontSize = 12.sp, color = Color.Gray)
        }

        Surface(
            color = FedExPurpleContainer,
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                percent,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = FedExPurpleDark,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }
    }
}
