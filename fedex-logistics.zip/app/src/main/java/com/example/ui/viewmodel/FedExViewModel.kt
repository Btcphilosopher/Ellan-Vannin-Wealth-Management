package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.*
import com.example.data.remote.GeminiService
import com.example.data.repository.FedExRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppNavTab {
    HOME,
    TRACKING,
    SHIP,
    MAP,
    MORE
}

enum class SubScreen {
    NONE,
    ASSISTANT,
    DELIVERY_MANAGER,
    CUSTOMS,
    LOCATIONS,
    RETURNS,
    ANALYTICS,
    DOCUMENTS,
    NOTIFICATIONS,
    ACCOUNT
}

class FedExViewModel(application: Application) : AndroidViewModel(application) {
    val repository = FedExRepository(application)

    // Mode: Personal vs Business
    private val _isBusinessMode = MutableStateFlow(false)
    val isBusinessMode: StateFlow<Boolean> = _isBusinessMode.asStateFlow()

    // Navigation
    private val _currentTab = MutableStateFlow(AppNavTab.HOME)
    val currentTab: StateFlow<AppNavTab> = _currentTab.asStateFlow()

    private val _currentSubScreen = MutableStateFlow(SubScreen.NONE)
    val currentSubScreen: StateFlow<SubScreen> = _currentSubScreen.asStateFlow()

    // Active Selected Shipment
    private val _selectedTrackingNumber = MutableStateFlow("7812394821")
    val selectedTrackingNumber: StateFlow<String> = _selectedTrackingNumber.asStateFlow()

    val selectedShipment: StateFlow<Shipment?> = _selectedTrackingNumber.flatMapLatest { trackingNum ->
        repository.observeShipment(trackingNum)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Shipments List
    val shipments: StateFlow<List<Shipment>> = _isBusinessMode.flatMapLatest { isBusiness ->
        repository.getShipmentsByMode(isBusiness)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allShipments: StateFlow<List<Shipment>> = repository.allShipments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val locations: StateFlow<List<FedExLocation>> = repository.allLocations
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val documents: StateFlow<List<FedExDocument>> = repository.allDocuments
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<AppNotification>> = repository.allNotifications
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Language Selector
    private val _currentLanguage = MutableStateFlow(
        LanguageOption("en", "English", "English", "🇺🇸")
    )
    val currentLanguage: StateFlow<LanguageOption> = _currentLanguage.asStateFlow()

    val availableLanguages = listOf(
        LanguageOption("en", "English", "English", "🇺🇸"),
        LanguageOption("es", "Spanish", "Español", "🇪🇸"),
        LanguageOption("fr", "French", "Français", "🇫🇷"),
        LanguageOption("de", "German", "Deutsch", "🇩🇪"),
        LanguageOption("it", "Italian", "Italiano", "🇮🇹"),
        LanguageOption("pt", "Portuguese", "Português", "🇵🇹"),
        LanguageOption("nl", "Dutch", "Nederlands", "🇳🇱"),
        LanguageOption("ja", "Japanese", "日本語", "🇯🇵"),
        LanguageOption("ko", "Korean", "한국어", "🇰🇷"),
        LanguageOption("zh", "Chinese", "中文", "🇨🇳")
    )

    // FedEx Assist AI Chat Messages
    private val _chatMessages = MutableStateFlow(
        listOf(
            ChatMessage(
                id = "m1",
                sender = "ASSISTANT",
                text = "Hello! I am **FedEx Assist**, your global logistics AI assistant.\nHow can I help with your shipments, delivery options, or shipping quotes today?",
                timestamp = "Just now",
                suggestedActions = listOf("Where is my package?", "When will it arrive?", "Rate to Germany", "Find nearest FedEx Office")
            )
        )
    )
    val chatMessages: StateFlow<List<ChatMessage>> = _chatMessages.asStateFlow()

    private val _isAssistantLoading = MutableStateFlow(false)
    val isAssistantLoading: StateFlow<Boolean> = _isAssistantLoading.asStateFlow()

    // Shipping Quote State
    private val _shipFrom = MutableStateFlow("London, UK")
    val shipFrom: StateFlow<String> = _shipFrom.asStateFlow()

    private val _shipTo = MutableStateFlow("New York, USA")
    val shipTo: StateFlow<String> = _shipTo.asStateFlow()

    private val _packageWeight = MutableStateFlow(5.0)
    val packageWeight: StateFlow<Double> = _packageWeight.asStateFlow()

    private val _packageType = MutableStateFlow("Medium Box")
    val packageType: StateFlow<String> = _packageType.asStateFlow()

    private val _quoteOptions = MutableStateFlow<List<ShippingRateOption>>(emptyList())
    val quoteOptions: StateFlow<List<ShippingRateOption>> = _quoteOptions.asStateFlow()

    init {
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
            calculateShippingQuotes()
        }
    }

    fun setBusinessMode(enabled: Boolean) {
        _isBusinessMode.value = enabled
    }

    fun setNavTab(tab: AppNavTab) {
        _currentTab.value = tab
        _currentSubScreen.value = SubScreen.NONE
    }

    fun openSubScreen(subScreen: SubScreen) {
        _currentSubScreen.value = subScreen
    }

    fun selectTrackingNumber(trackingNum: String) {
        _selectedTrackingNumber.value = trackingNum
    }

    fun setLanguage(lang: LanguageOption) {
        _currentLanguage.value = lang
    }

    fun updateShipFrom(from: String) {
        _shipFrom.value = from
        calculateShippingQuotes()
    }

    fun updateShipTo(to: String) {
        _shipTo.value = to
        calculateShippingQuotes()
    }

    fun updatePackageWeight(weight: Double) {
        _packageWeight.value = weight
        calculateShippingQuotes()
    }

    fun updatePackageType(type: String) {
        _packageType.value = type
        calculateShippingQuotes()
    }

    private fun calculateShippingQuotes() {
        val w = _packageWeight.value
        val basePrice = 25.0 + (w * 8.5)

        _quoteOptions.value = listOf(
            ShippingRateOption(
                serviceName = "FedEx International First®",
                speedCategory = "First Priority",
                deliveryDaysText = "1 Business Day",
                estArrivalDate = "Tomorrow by 09:00 AM",
                priceUsd = String.format("%.2f", basePrice * 2.2).toDouble(),
                badge = "Fastest"
            ),
            ShippingRateOption(
                serviceName = "FedEx International Priority®",
                speedCategory = "Priority Express",
                deliveryDaysText = "1-2 Business Days",
                estArrivalDate = "Tomorrow by 12:00 PM",
                priceUsd = String.format("%.2f", basePrice * 1.6).toDouble(),
                badge = "Most Popular"
            ),
            ShippingRateOption(
                serviceName = "FedEx International Economy®",
                speedCategory = "Economy",
                deliveryDaysText = "3-5 Business Days",
                estArrivalDate = "In 3 Business Days",
                priceUsd = String.format("%.2f", basePrice).toDouble(),
                badge = "Best Value"
            )
        )
    }

    fun sendAssistMessage(userPrompt: String) {
        if (userPrompt.isBlank()) return

        val userMsg = ChatMessage(
            id = "msg-${System.currentTimeMillis()}",
            sender = "USER",
            text = userPrompt,
            timestamp = "Just now"
        )
        _chatMessages.update { it + userMsg }
        _isAssistantLoading.value = true

        viewModelScope.launch {
            val allList = repository.allShipments.first()
            val contextSummary = allList.joinToString("\n") {
                "Tracking: ${it.trackingNumber}, Title: ${it.title}, Status: ${it.status.label}, Service: ${it.carrierService}, ETA: ${it.etaText}"
            }

            val assistantReply = GeminiService.generateAssistResponse(userPrompt, contextSummary)

            val replyMsg = ChatMessage(
                id = "msg-${System.currentTimeMillis() + 1}",
                sender = "ASSISTANT",
                text = assistantReply,
                timestamp = "Just now"
            )
            _chatMessages.update { it + replyMsg }
            _isAssistantLoading.value = false
        }
    }

    fun createShipmentFromQuote(selectedRate: ShippingRateOption) {
        viewModelScope.launch {
            val created = repository.createNewShipment(
                senderCity = _shipFrom.value,
                recipientCity = _shipTo.value,
                packageSize = _packageType.value,
                weightKg = _packageWeight.value,
                serviceType = selectedRate.serviceName,
                priceUsd = selectedRate.priceUsd,
                isBusiness = _isBusinessMode.value
            )
            _selectedTrackingNumber.value = created.trackingNumber
            _currentTab.value = AppNavTab.TRACKING
        }
    }

    fun saveDeliveryOptions(
        trackingNumber: String,
        dateOption: String?,
        holdLocation: String?,
        safePlace: String?,
        neighbor: String?
    ) {
        viewModelScope.launch {
            repository.updateDeliveryInstructions(
                trackingNumber = trackingNumber,
                dateOption = dateOption,
                holdLocation = holdLocation,
                safePlace = safePlace,
                neighbor = neighbor
            )
        }
    }

    fun createReturn(originalTrackingNumber: String, returnMethod: String) {
        viewModelScope.launch {
            val returnShipment = repository.createReturnLabel(originalTrackingNumber, returnMethod)
            _selectedTrackingNumber.value = returnShipment.trackingNumber
            _currentTab.value = AppNavTab.TRACKING
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationRead(id)
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }
}
