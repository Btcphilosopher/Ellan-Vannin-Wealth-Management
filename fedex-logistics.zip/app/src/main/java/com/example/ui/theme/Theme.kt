package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LightColorScheme = lightColorScheme(
    primary = FedExPurple,
    onPrimary = Color.White,
    primaryContainer = FedExPurpleContainer,
    onPrimaryContainer = FedExPurpleDark,
    secondary = FedExOrange,
    onSecondary = Color.White,
    secondaryContainer = FedExOrangeContainer,
    onSecondaryContainer = FedExOrangeDark,
    tertiary = FedExGreen,
    onTertiary = Color.White,
    tertiaryContainer = FedExGreenContainer,
    background = BackgroundLight,
    onBackground = NeutralDark,
    surface = SurfaceLight,
    onSurface = NeutralDark,
    error = FedExRed,
    errorContainer = FedExRedContainer
)

private val DarkColorScheme = darkColorScheme(
    primary = FedExPurpleLight,
    onPrimary = Color.White,
    primaryContainer = FedExPurpleDark,
    onPrimaryContainer = FedExPurpleContainer,
    secondary = FedExOrangeLight,
    onSecondary = Color.Black,
    secondaryContainer = FedExOrangeDark,
    onSecondaryContainer = FedExOrangeContainer,
    tertiary = FedExGreen,
    onTertiary = Color.White,
    background = BackgroundDark,
    onBackground = Color.White,
    surface = SurfaceDark,
    onSurface = Color.White,
    error = FedExRed
)

@Composable
fun FedExTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
