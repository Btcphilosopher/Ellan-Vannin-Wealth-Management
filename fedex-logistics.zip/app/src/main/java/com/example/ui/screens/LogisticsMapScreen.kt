package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FedExLocation
import com.example.data.model.Shipment
import com.example.data.model.ShipmentStatus
import com.example.ui.components.ShipmentStatusChip
import com.example.ui.theme.*

@Composable
fun LogisticsMapScreen(
    shipments: List<Shipment>,
    locations: List<FedExLocation>,
    selectedTrackingNumber: String,
    onSelectShipment: (String) -> Unit,
    onNavigateTracking: () -> Unit
) {
    val activeShipment = shipments.find { it.trackingNumber == selectedTrackingNumber } ?: shipments.firstOrNull()

    var activeMapFilter by remember { mutableStateOf("ALL") } // ALL, PACKAGES, HUBS, LOCKERS

    // Radar pulse animation
    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val radarRadius by infiniteTransition.animateFloat(
        initialValue = 10f,
        targetValue = 60f,
        animationSpec = infiniteRepeatable(tween(2000, easing = LinearEasing), RepeatMode.Restart),
        label = "radius"
    )
    val radarAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0.0f,
        animationSpec = infiniteRepeatable(tween(2000, easing = LinearEasing), RepeatMode.Restart),
        label = "alpha"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(NeutralDark)
    ) {
        // MAP HEADER & FILTER CHIPS
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Text(
                text = "LIVE GLOBAL LOGISTICS MAP",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = FedExOrangeLight,
                letterSpacing = 1.5.sp
            )
            Text(
                text = "Real-time Simulated Air & Ground Fleet Telemetry",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Filter Pills
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("ALL" to "All Active", "PACKAGES" to "📦 Packages", "HUBS" to "✈️ Air Hubs", "LOCKERS" to "📍 Lockers").forEach { (key, label) ->
                    val isSel = activeMapFilter == key
                    Surface(
                        color = if (isSel) FedExOrange else Color(0xFF2A243D),
                        shape = RoundedCornerShape(20.dp),
                        modifier = Modifier.clickable { activeMapFilter = key }
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // INTERACTIVE MAP CANVAS CONTAINER
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF130F21))
                .border(1.dp, Color(0xFF2E2747), RoundedCornerShape(20.dp))
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val width = size.width
                val height = size.height

                // Draw Grid & Lat/Lng lines
                for (i in 1..8) {
                    val y = height * (i / 9f)
                    drawLine(
                        color = Color(0xFF221A38),
                        start = Offset(0f, y),
                        end = Offset(width, y),
                        strokeWidth = 1f
                    )
                }
                for (i in 1..10) {
                    val x = width * (i / 11f)
                    drawLine(
                        color = Color(0xFF221A38),
                        start = Offset(x, 0f),
                        end = Offset(x, height),
                        strokeWidth = 1f
                    )
                }

                // Draw Simulated Hub Nodes (Airports / Facilities)
                if (activeMapFilter == "ALL" || activeMapFilter == "HUBS") {
                    val hubs = listOf(
                        Offset(width * 0.25f, height * 0.35f) to "LHR (Heathrow)",
                        Offset(width * 0.70f, height * 0.40f) to "JFK (New York)",
                        Offset(width * 0.45f, height * 0.25f) to "FRA (Frankfurt)",
                        Offset(width * 0.85f, height * 0.75f) to "LAX (Los Angeles)"
                    )

                    hubs.forEach { (pos, label) ->
                        drawCircle(color = FedExPurpleLight.copy(alpha = 0.3f), radius = 18f, center = pos)
                        drawCircle(color = Color.White, radius = 6f, center = pos)
                    }
                }

                // Draw Global Flight & Delivery Routes
                shipments.forEachIndexed { index, ship ->
                    val factor = (index + 1) / (shipments.size + 1.0f)
                    val p1 = Offset(width * (0.15f + factor * 0.15f), height * (0.3f + factor * 0.4f))
                    val p2 = Offset(width * (0.65f + factor * 0.2f), height * (0.2f + factor * 0.5f))
                    val ctrl = Offset(width * 0.5f, height * (0.1f + factor * 0.1f))

                    val routePath = Path().apply {
                        moveTo(p1.x, p1.y)
                        quadraticTo(ctrl.x, ctrl.y, p2.x, p2.y)
                    }

                    val isSelected = ship.trackingNumber == activeShipment?.trackingNumber

                    drawPath(
                        path = routePath,
                        color = if (isSelected) FedExOrange else Color.Gray.copy(alpha = 0.3f),
                        style = Stroke(width = if (isSelected) 6f else 2f)
                    )

                    // Current position
                    val progress = when (ship.status) {
                        ShipmentStatus.LABEL_CREATED -> 0.1f
                        ShipmentStatus.PICKED_UP -> 0.3f
                        ShipmentStatus.FEDEX_FACILITY -> 0.5f
                        ShipmentStatus.INTL_TRANSIT -> 0.7f
                        ShipmentStatus.OUT_FOR_DELIVERY -> 0.9f
                        ShipmentStatus.DELIVERED -> 1.0f
                        ShipmentStatus.DELAYED -> 0.6f
                    }

                    val curX = (1 - progress) * (1 - progress) * p1.x + 2 * (1 - progress) * progress * ctrl.x + progress * progress * p2.x
                    val curY = (1 - progress) * (1 - progress) * p1.y + 2 * (1 - progress) * progress * ctrl.y + progress * progress * p2.y
                    val curPos = Offset(curX, curY)

                    if (isSelected) {
                        drawCircle(
                            color = FedExOrange.copy(alpha = radarAlpha),
                            radius = radarRadius,
                            center = curPos
                        )
                        drawCircle(color = Color.White, radius = 14f, center = curPos)
                        drawCircle(color = FedExOrange, radius = 10f, center = curPos)
                    } else {
                        drawCircle(color = Color.White, radius = 8f, center = curPos)
                        drawCircle(color = FedExPurple, radius = 5f, center = curPos)
                    }
                }
            }

            // Radar Telemetry Overlay Banner
            Surface(
                color = Color.Black.copy(alpha = 0.7f),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(FedExGreen)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("GLOBAL GPS SATELLITE LOCK", fontSize = 10.sp, color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // SELECTED PACKAGE TELEMETRY BOTTOM DRAWER
        if (activeShipment != null) {
            Card(
                shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "FOLLOWING SHIPMENT JOURNEY",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = activeShipment.carrierService,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = FedExPurple
                            )
                            Text(
                                text = activeShipment.trackingNumber,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }

                        ShipmentStatusChip(activeShipment.status)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "${activeShipment.senderCityCountry} → ${activeShipment.recipientCityCountry}",
                        fontSize = 13.sp,
                        color = Color.Gray
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onNavigateTracking,
                            colors = ButtonDefaults.buttonColors(containerColor = FedExPurple),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("view_details_map_button")
                        ) {
                            Text("VIEW TIMELINE DETAILS", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
