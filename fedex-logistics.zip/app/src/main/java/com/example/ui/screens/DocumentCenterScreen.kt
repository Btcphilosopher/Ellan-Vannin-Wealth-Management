package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FedExDocument
import com.example.ui.theme.*

@Composable
fun DocumentCenterScreen(
    documents: List<FedExDocument>,
    onBack: () -> Unit
) {
    var selectedFilter by remember { mutableStateOf("ALL") }
    var selectedDocForPreview by remember { mutableStateOf<FedExDocument?>(null) }

    val filteredDocs = remember(selectedFilter, documents) {
        if (selectedFilter == "ALL") documents
        else documents.filter { it.docType.contains(selectedFilter, ignoreCase = true) }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Header
        Surface(
            color = FedExPurple,
            contentColor = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("documents_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("SECURE DOCUMENT CENTER", fontSize = 11.sp, color = FedExOrangeLight, fontWeight = FontWeight.Bold)
                    Text("Air Waybills, Invoices & Clearances", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        // Filter Chips
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("ALL" to "All Docs", "Label" to "Waybills", "Customs" to "Customs", "Invoice" to "Invoices").forEach { (filter, label) ->
                val isSel = selectedFilter == filter
                FilterChip(
                    selected = isSel,
                    onClick = { selectedFilter = filter },
                    label = { Text(label, fontSize = 12.sp) },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = FedExPurple,
                        selectedLabelColor = Color.White
                    )
                )
            }
        }

        // Document Cards List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(filteredDocs) { doc ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp)
                        .clickable { selectedDocForPreview = doc }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = FedExPurpleContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = when (doc.docType) {
                                        "Shipping Label" -> Icons.Default.QrCode
                                        "Customs Form" -> Icons.Default.Public
                                        "Commercial Invoice" -> Icons.Default.ReceiptLong
                                        else -> Icons.Default.Description
                                    },
                                    contentDescription = null,
                                    tint = FedExPurple
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(doc.title, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                            Text(doc.summaryText, fontSize = 12.sp, color = Color.Gray)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Tracking #${doc.trackingNumber} • ${doc.dateText}", fontSize = 11.sp, color = FedExPurple, fontWeight = FontWeight.Bold)
                        }

                        IconButton(onClick = { selectedDocForPreview = doc }) {
                            Icon(Icons.Default.FileDownload, contentDescription = "Download PDF", tint = FedExOrange)
                        }
                    }
                }
            }
        }
    }

    if (selectedDocForPreview != null) {
        val doc = selectedDocForPreview!!
        AlertDialog(
            onDismissRequest = { selectedDocForPreview = null },
            icon = { Icon(Icons.Default.PictureAsPdf, contentDescription = null, tint = FedExPurple, modifier = Modifier.size(36.dp)) },
            title = { Text(doc.title) },
            text = {
                Column {
                    Text("Synthetic Document Preview:")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Type: ${doc.docType}", fontWeight = FontWeight.Bold)
                    Text("Air Waybill: #${doc.trackingNumber}")
                    Text("Issued Date: ${doc.dateText}")
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        color = Color(0xFFF0F1F5),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(120.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text("📄 [PDF DIGITAL SIGNATURE VERIFIED]", fontSize = 12.sp, color = Color.DarkGray, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { selectedDocForPreview = null },
                    colors = ButtonDefaults.buttonColors(containerColor = FedExPurple)
                ) {
                    Text("Close Preview")
                }
            }
        )
    }
}
