package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ShippingRateOption
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShipScreen(
    shipFrom: String,
    shipTo: String,
    packageWeight: Double,
    packageType: String,
    quoteOptions: List<ShippingRateOption>,
    onUpdateShipFrom: (String) -> Unit,
    onUpdateShipTo: (String) -> Unit,
    onUpdateWeight: (Double) -> Unit,
    onUpdateType: (String) -> Unit,
    onCreateShipmentFromQuote: (ShippingRateOption) -> Unit
) {
    var includeInsurance by remember { mutableStateOf(true) }
    var declaredValueText by remember { mutableStateOf("500") }
    var selectedServiceOption by remember { mutableStateOf<ShippingRateOption?>(null) }
    var showSuccessDialog by remember { mutableStateOf(false) }

    val packageTypes = listOf("Envelope", "Small Box", "Medium Box", "Large Box", "FedEx Pak", "Custom Freight")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        contentPadding = PaddingValues(bottom = 24.dp)
    ) {
        item {
            Text(
                text = "SHIP A PACKAGE",
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Text(
                text = "Calculate rates, select speed & print simulated air waybills.",
                fontSize = 13.sp,
                color = Color.Gray
            )

            Spacer(modifier = Modifier.height(16.dp))
        }

        // FROM & TO ADDRESS CARDS
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ORIGIN & DESTINATION",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = shipFrom,
                        onValueChange = onUpdateShipFrom,
                        label = { Text("FROM (Origin City / Country)") },
                        leadingIcon = { Icon(Icons.Default.FlightTakeoff, contentDescription = null, tint = FedExPurple) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ship_from_input")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = shipTo,
                        onValueChange = onUpdateShipTo,
                        label = { Text("TO (Destination City / Country)") },
                        leadingIcon = { Icon(Icons.Default.FlightLand, contentDescription = null, tint = FedExOrange) },
                        singleLine = true,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("ship_to_input")
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))
        }

        // PACKAGE SIZE & WEIGHT CARD
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "PACKAGE SPECIFICATIONS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Package Type", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        packageTypes.take(3).forEach { type ->
                            val isSel = type == packageType
                            Surface(
                                color = if (isSel) FedExPurple else Color(0xFFF0F1F5),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onUpdateType(type) }
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = type,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSel) Color.White else Color.Black
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Package Weight: ${String.format("%.1f", packageWeight)} kg", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text("${String.format("%.1f", packageWeight * 2.20462)} lbs", fontSize = 12.sp, color = Color.Gray)
                    }

                    Slider(
                        value = packageWeight.toFloat(),
                        onValueChange = { onUpdateWeight(it.toDouble()) },
                        valueRange = 0.5f..30.0f,
                        steps = 59,
                        colors = SliderDefaults.colors(
                            thumbColor = FedExOrange,
                            activeTrackColor = FedExPurple
                        ),
                        modifier = Modifier.testTag("weight_slider")
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Declared Value & Insurance
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Declared Value Protection", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text("FedEx Priority Insurance ($5.00)", fontSize = 11.sp, color = Color.Gray)
                        }

                        Switch(
                            checked = includeInsurance,
                            onCheckedChange = { includeInsurance = it },
                            colors = SwitchDefaults.colors(checkedThumbColor = FedExOrange)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "AVAILABLE FEDEX EXPRESS RATES",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )
        }

        // RATES OPTIONS LIST
        items(quoteOptions) { option ->
            val finalPrice = option.priceUsd + (if (includeInsurance) 5.0 else 0.0)

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp)
                    .clickable { selectedServiceOption = option }
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            if (option.badge != null) {
                                Surface(
                                    color = FedExOrangeContainer,
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = option.badge.uppercase(),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = FedExOrangeDark,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                            }

                            Text(
                                text = option.serviceName,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = FedExPurple
                            )
                        }

                        Text(
                            text = "$${String.format("%.2f", finalPrice)}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Speed, contentDescription = null, tint = FedExOrange, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = option.deliveryDaysText,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Text(
                            text = option.estArrivalDate,
                            fontSize = 12.sp,
                            color = FedExGreen,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = {
                            selectedServiceOption = option
                            onCreateShipmentFromQuote(option)
                            showSuccessDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FedExPurple),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("CREATE SHIPMENT & PRINT LABEL", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showSuccessDialog && selectedServiceOption != null) {
        AlertDialog(
            onDismissRequest = { showSuccessDialog = false },
            icon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = FedExGreen) },
            title = { Text("Shipment Created Successfully!") },
            text = {
                Column {
                    Text("Your synthetic FedEx Air Waybill label has been generated and saved to Document Center.")
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Service: ${selectedServiceOption?.serviceName}", fontWeight = FontWeight.Bold)
                    Text("Route: $shipFrom → $shipTo")
                    Text("Package: $packageType (${String.format("%.1f", packageWeight)} kg)")
                }
            },
            confirmButton = {
                Button(
                    onClick = { showSuccessDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = FedExPurple)
                ) {
                    Text("View Tracking Timeline")
                }
            }
        )
    }
}
