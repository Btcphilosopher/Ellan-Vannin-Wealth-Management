package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val FedExPurple = Color(0xFF4D148C)
val FedExPurpleDark = Color(0xFF330C60)
val FedExPurpleLight = Color(0xFF7522CF)
val FedExPurpleContainer = Color(0xFFF1E6FF)

val FedExOrange = Color(0xFFFF6600)
val FedExOrangeDark = Color(0xFFCC5200)
val FedExOrangeLight = Color(0xFFFF8533)
val FedExOrangeContainer = Color(0xFFFFF0E6)

val FedExGreen = Color(0xFF008A00)
val FedExGreenContainer = Color(0xFFE6F4EA)

val FedExRed = Color(0xFFD93025)
val FedExRedContainer = Color(0xFFFCE8E6)

val FedExBlue = Color(0xFF1A73E8)

val NeutralDark = Color(0xFF161224)
val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF5F6FA)
val SurfaceDark = Color(0xFF221D33)
val BackgroundDark = Color(0xFF120E1E)
