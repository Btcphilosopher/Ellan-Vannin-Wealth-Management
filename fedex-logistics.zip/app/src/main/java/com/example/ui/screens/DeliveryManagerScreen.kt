package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Shipment
import com.example.ui.theme.*

@Composable
fun DeliveryManagerScreen(
    shipment: Shipment?,
    onSaveInstructions: (trackingNumber: String, date: String?, hold: String?, safe: String?, neighbor: String?) -> Unit,
    onBack: () -> Unit
) {
    val scrollState = rememberScrollState()

    var selectedDateOption by remember { mutableStateOf("Today, 14:00 - 16:00") }
    var selectedHoldLocation by remember { mutableStateOf("None (Deliver to address)") }
    var safePlaceInstructions by remember { mutableStateOf("Front porch behind planter box") }
    var neighborNameAddress by remember { mutableStateOf("Apt 4B - Sarah Jenkins") }
    var showSuccessToast by remember { mutableStateOf(false) }

    val dateOptions = listOf("Today, 14:00 - 16:00", "Tomorrow, 09:00 - 12:00", "Friday, 14:00 - 18:00")
    val holdLocations = listOf("None (Deliver to address)", "FedEx Office - 452 Fifth Ave, NY", "FedEx Locker 24/7 - 120 Broadway")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Header
        Surface(
            color = FedExPurple,
            contentColor = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("delivery_manager_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("DELIVERY MANAGER", fontSize = 11.sp, color = FedExOrangeLight, fontWeight = FontWeight.Bold)
                    Text("Manage Arrival & Driver Instructions", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        if (shipment != null) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(16.dp)
            ) {
                // Driver Approaching Hero Card
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("YOUR DELIVERY", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                Text(shipment.carrierService, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = FedExPurple)
                                Text("Tracking: #${shipment.trackingNumber}", fontSize = 13.sp, color = Color.Gray)
                            }

                            Surface(color = FedExOrangeContainer, shape = RoundedCornerShape(12.dp)) {
                                Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.DirectionsCar, contentDescription = null, tint = FedExOrangeDark, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Driver Approaching", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = FedExOrangeDark)
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Text(
                            text = "Arriving today: ${shipment.etaTimeWindow}",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = "Destination: ${shipment.recipientName}, ${shipment.recipientCityCountry}",
                            fontSize = 13.sp,
                            color = Color.Gray
                        )
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Text(
                    text = "SIMULATED DELIVERY OPTIONS",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                // Option 1: Change Delivery Date
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Event, contentDescription = null, tint = FedExPurple)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Change Delivery Date / Window", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        dateOptions.forEach { opt ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                RadioButton(
                                    selected = selectedDateOption == opt,
                                    onClick = { selectedDateOption = opt },
                                    colors = RadioButtonDefaults.colors(selectedColor = FedExOrange)
                                )
                                Text(opt, fontSize = 13.sp)
                            }
                        }
                    }
                }

                // Option 2: Hold at FedEx Location
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Storefront, contentDescription = null, tint = FedExPurple)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Hold at FedEx Location / Locker", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        holdLocations.forEach { loc ->
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                RadioButton(
                                    selected = selectedHoldLocation == loc,
                                    onClick = { selectedHoldLocation = loc },
                                    colors = RadioButtonDefaults.colors(selectedColor = FedExOrange)
                                )
                                Text(loc, fontSize = 13.sp)
                            }
                        }
                    }
                }

                // Option 3: Safe Place Instructions
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Security, contentDescription = null, tint = FedExPurple)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Safe-Place Drop Instructions", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = safePlaceInstructions,
                            onValueChange = { safePlaceInstructions = it },
                            label = { Text("Driver note (e.g. Back porch, behind gate)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Option 4: Deliver to Neighbor
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.People, contentDescription = null, tint = FedExPurple)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Deliver to Neighbor", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = neighborNameAddress,
                            onValueChange = { neighborNameAddress = it },
                            label = { Text("Neighbor Apt / Name") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = {
                        onSaveInstructions(
                            shipment.trackingNumber,
                            selectedDateOption,
                            selectedHoldLocation,
                            safePlaceInstructions,
                            neighborNameAddress
                        )
                        showSuccessToast = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FedExOrange),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("save_delivery_options_button")
                ) {
                    Text("SAVE SIMULATED DELIVERY OPTIONS", fontWeight = FontWeight.Bold)
                }

                if (showSuccessToast) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(color = FedExGreenContainer, shape = RoundedCornerShape(8.dp)) {
                        Text(
                            text = "✓ Driver instructions sent to courier vehicle terminal!",
                            color = FedExGreen,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(12.dp)
                        )
                    }
                }
            }
        }
    }
}
