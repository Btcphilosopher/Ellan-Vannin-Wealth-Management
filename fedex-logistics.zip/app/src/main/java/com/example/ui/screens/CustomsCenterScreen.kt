package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Shipment
import com.example.ui.theme.*

@Composable
fun CustomsCenterScreen(
    shipment: Shipment?,
    onViewDocuments: () -> Unit,
    onBack: () -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Header
        Surface(
            color = FedExPurple,
            contentColor = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("customs_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("CUSTOMS & INTERNATIONAL CLEARANCE", fontSize = 11.sp, color = FedExOrangeLight, fontWeight = FontWeight.Bold)
                    Text("Global Import/Export Hub", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // PROMPT EXAMPLE CARD
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "CUSTOMS CLEARANCE STATUS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "${shipment?.senderCityCountry ?: "London, UK"} → ${shipment?.recipientCityCountry ?: "New York, USA"}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Status", fontSize = 12.sp, color = Color.Gray)
                            Text(
                                text = "Documentation required",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = FedExOrangeDark
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("Estimated duties", fontSize = 12.sp, color = Color.Gray)
                            Text(
                                text = "$38.40",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = FedExPurple
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Progress Bar
                    Text("Clearance Progress: 65%", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { 0.65f },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp),
                        color = FedExOrange,
                        trackColor = FedExOrangeContainer
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onViewDocuments,
                        colors = ButtonDefaults.buttonColors(containerColor = FedExPurple),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Description, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("VIEW DOCUMENTS", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = "REQUIRED CUSTOMS DOCUMENTS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            val requiredDocs = listOf(
                "Commercial Invoice (3 copies signed)" to "Verified ✓",
                "US CBP Form 7501 Entry Summary" to "Pending Upload ⚠️",
                "Certificate of Origin (EUR.1)" to "Verified ✓",
                "Harmonized Tariff Schedule (HS 8542.31)" to "Classified ✓"
            )

            requiredDocs.forEach { (doc, status) ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(doc, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            Text("Synthetic customs form preview", fontSize = 11.sp, color = Color.Gray)
                        }

                        Surface(
                            color = if (status.contains("✓")) FedExGreenContainer else FedExOrangeContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                status,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (status.contains("✓")) FedExGreen else FedExOrangeDark,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
