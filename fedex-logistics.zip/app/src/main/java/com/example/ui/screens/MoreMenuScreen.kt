package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*
import com.example.ui.viewmodel.SubScreen

@Composable
fun MoreMenuScreen(
    onOpenSubScreen: (SubScreen) -> Unit,
    isBusinessMode: Boolean,
    onToggleBusinessMode: (Boolean) -> Unit
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        Text(
            text = "FEDEX LOGISTICS HUB",
            fontSize = 22.sp,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Text(
            text = "All FedEx services, tools, and international features in one view.",
            fontSize = 13.sp,
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(20.dp))

        // AI ASSIST BANNER CARD
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = FedExPurple),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpenSubScreen(SubScreen.ASSISTANT) }
                .testTag("more_ai_assist_card")
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = FedExOrange, modifier = Modifier.size(28.dp))
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("FedEx Assist AI", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Multilingual AI logistics assistant", fontSize = 12.sp, color = FedExOrangeLight)
                }
                Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "LOGISTICS & SHIPMENT SERVICES",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        MenuItem(
            icon = Icons.Default.Analytics,
            title = "Business Analytics Dashboard",
            subtitle = "Enterprise KPIs, volume charts & monthly spend",
            onClick = { onOpenSubScreen(SubScreen.ANALYTICS) }
        )

        MenuItem(
            icon = Icons.Default.EditRoad,
            title = "Delivery Manager Options",
            subtitle = "Change date, hold at location, safe place, neighbor drop",
            onClick = { onOpenSubScreen(SubScreen.DELIVERY_MANAGER) }
        )

        MenuItem(
            icon = Icons.Default.Public,
            title = "Customs & Clearance Center",
            subtitle = "Status, duties & taxes estimate ($38.40), CBP clearance",
            onClick = { onOpenSubScreen(SubScreen.CUSTOMS) }
        )

        MenuItem(
            icon = Icons.Default.Place,
            title = "FedEx Location Finder",
            subtitle = "Find Offices, 24/7 Lockers, drop-off points with hours",
            onClick = { onOpenSubScreen(SubScreen.LOCATIONS) }
        )

        MenuItem(
            icon = Icons.Default.AssignmentReturn,
            title = "Returns Center",
            subtitle = "Generate return QR codes & air waybills",
            onClick = { onOpenSubScreen(SubScreen.RETURNS) }
        )

        MenuItem(
            icon = Icons.Default.Description,
            title = "Secure Document Center",
            subtitle = "Air Waybills, Customs Forms, Commercial Invoices",
            onClick = { onOpenSubScreen(SubScreen.DOCUMENTS) }
        )

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "ACCOUNT & PREFERENCES",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            letterSpacing = 1.sp,
            modifier = Modifier.padding(bottom = 8.dp)
        )

        MenuItem(
            icon = Icons.Default.Notifications,
            title = "Delivery Alerts & Notifications",
            subtitle = "View active shipment alerts and SLA updates",
            onClick = { onOpenSubScreen(SubScreen.NOTIFICATIONS) }
        )

        MenuItem(
            icon = Icons.Default.Language,
            title = "Language & Account Settings",
            subtitle = "10 Localisations, profile & business mode switch",
            onClick = { onOpenSubScreen(SubScreen.ACCOUNT) }
        )

        Spacer(modifier = Modifier.height(30.dp))
    }
}

@Composable
private fun MenuItem(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                color = FedExPurpleContainer,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.size(40.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = null, tint = FedExPurple, modifier = Modifier.size(20.dp))
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, fontSize = 11.sp, color = Color.Gray)
            }

            Icon(Icons.Default.ArrowForwardIos, contentDescription = null, tint = Color.LightGray, modifier = Modifier.size(14.dp))
        }
    }
}
