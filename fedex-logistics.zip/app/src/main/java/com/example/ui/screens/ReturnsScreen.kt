package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Shipment
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReturnsScreen(
    shipments: List<Shipment>,
    onCreateReturn: (originalTrackingNumber: String, returnMethod: String) -> Unit,
    onBack: () -> Unit
) {
    val scrollState = rememberScrollState()

    var selectedTrackingNum by remember { mutableStateOf(shipments.firstOrNull()?.trackingNumber ?: "7812394821") }
    var returnMethod by remember { mutableStateOf("FedEx Location Drop-off") }
    var showQrDialog by remember { mutableStateOf(false) }

    val returnMethods = listOf("FedEx Location Drop-off", "Schedule Courier Pickup", "FedEx 24/7 Locker Drop")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Header
        Surface(
            color = FedExPurple,
            contentColor = Color.White,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier.testTag("returns_back_button")
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text("FEDEX RETURNS PORTAL", fontSize = 11.sp, color = FedExOrangeLight, fontWeight = FontWeight.Bold)
                    Text("Instant Return Label & QR Code", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(16.dp)
        ) {
            // PROMPT FORM CARD
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "RETURN A PACKAGE",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Select Original Shipment Tracking", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Spacer(modifier = Modifier.height(6.dp))

                    OutlinedTextField(
                        value = selectedTrackingNum,
                        onValueChange = { selectedTrackingNum = it },
                        label = { Text("FedEx tracking number") },
                        leadingIcon = { Icon(Icons.Default.ConfirmationNumber, contentDescription = null, tint = FedExPurple) },
                        modifier = Modifier.fillMaxWidth().testTag("return_tracking_input")
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Text("Return Method", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                    Spacer(modifier = Modifier.height(6.dp))

                    returnMethods.forEach { method ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            RadioButton(
                                selected = returnMethod == method,
                                onClick = { returnMethod = method },
                                colors = RadioButtonDefaults.colors(selectedColor = FedExOrange)
                            )
                            Text(method, fontSize = 14.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = {
                            onCreateReturn(selectedTrackingNum, returnMethod)
                            showQrDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FedExPurple),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("create_return_button")
                    ) {
                        Text("CREATE RETURN & GENERATE QR CODE", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    if (showQrDialog) {
        AlertDialog(
            onDismissRequest = { showQrDialog = false },
            icon = { Icon(Icons.Default.QrCode2, contentDescription = null, tint = FedExPurple, modifier = Modifier.size(36.dp)) },
            title = { Text("Simulated Return QR Code") },
            text = {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Show this QR code at any FedEx Office or drop-off location:")
                    Spacer(modifier = Modifier.height(12.dp))

                    Box(
                        modifier = Modifier
                            .size(160.dp)
                            .background(Color.White, RoundedCornerShape(12.dp))
                            .border(2.dp, FedExPurple, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.QrCode2, contentDescription = null, tint = FedExPurple, modifier = Modifier.size(100.dp))
                            Text("FEDEX-RETURN", fontSize = 10.sp, fontWeight = FontWeight.Bold, color = FedExPurple)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Return Air Waybill generated and added to tracking list.", fontSize = 12.sp, color = FedExGreen, fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                Button(
                    onClick = { showQrDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = FedExPurple)
                ) {
                    Text("Track Return Shipment")
                }
            }
        )
    }
}
