package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Shipment
import com.example.data.model.ShipmentStatus
import com.example.ui.components.RouteMapCanvas
import com.example.ui.components.ShipmentStatusChip
import com.example.ui.components.TrackingTimelineView
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TrackingScreen(
    shipments: List<Shipment>,
    selectedShipment: Shipment?,
    selectedTrackingNumber: String,
    onSelectShipment: (String) -> Unit,
    onOpenSubScreen: (com.example.ui.viewmodel.SubScreen) -> Unit,
    repository: com.example.data.repository.FedExRepository
) {
    var searchQuery by remember { mutableStateOf("") }
    var showScanSimulatedDialog by remember { mutableStateOf(false) }

    val filteredShipments = remember(searchQuery, shipments) {
        if (searchQuery.isBlank()) shipments
        else shipments.filter {
            it.trackingNumber.contains(searchQuery, ignoreCase = true) ||
                    it.title.contains(searchQuery, ignoreCase = true) ||
                    it.senderCityCountry.contains(searchQuery, ignoreCase = true) ||
                    it.recipientCityCountry.contains(searchQuery, ignoreCase = true)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // TOP SEARCH & SCAN BAR
        Surface(
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 2.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        placeholder = { Text("Enter or paste tracking number...", fontSize = 14.sp) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = FedExPurple)
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear")
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("tracking_search_input")
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Scan Barcode Button
                    FilledIconButton(
                        onClick = { showScanSimulatedDialog = true },
                        colors = IconButtonDefaults.filledIconButtonColors(containerColor = FedExOrange),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .size(52.dp)
                            .testTag("scan_barcode_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.QrCodeScanner,
                            contentDescription = "Scan Barcode",
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // MULTI-PACKAGE TRACKING SELECTOR PIPELINE
                Text(
                    text = "SAVED SHIPMENTS (${shipments.size})",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray,
                    letterSpacing = 1.sp
                )

                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(top = 8.dp)
                ) {
                    items(filteredShipments) { item ->
                        val isSelected = item.trackingNumber == selectedTrackingNumber
                        FilterChip(
                            selected = isSelected,
                            onClick = { onSelectShipment(item.trackingNumber) },
                            label = {
                                Text(
                                    text = "#${item.trackingNumber.takeLast(6)} • ${item.status.label}",
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 12.sp
                                )
                            },
                            leadingIcon = {
                                Icon(
                                    imageVector = if (item.status == ShipmentStatus.DELIVERED) Icons.Default.CheckCircle else Icons.Default.Inventory2,
                                    contentDescription = null,
                                    tint = if (isSelected) Color.White else FedExPurple,
                                    modifier = Modifier.size(16.dp)
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = FedExPurple,
                                selectedLabelColor = Color.White
                            ),
                            shape = RoundedCornerShape(20.dp)
                        )
                    }
                }
            }
        }

        // DETAILED TRACKING DISPLAY AREA
        if (selectedShipment != null) {
            val scanEvents = remember(selectedShipment) {
                repository.deserializeEvents(selectedShipment.timelineJson)
            }
            val customsInfo = remember(selectedShipment) {
                repository.deserializeCustoms(selectedShipment.customsInfoJson)
            }
            val deliveryOptions = remember(selectedShipment) {
                repository.deserializeDeliveryOptions(selectedShipment.deliveryOptionsJson)
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(vertical = 16.dp)
            ) {
                // SHIPMENT STATUS HERO CARD
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = selectedShipment.carrierService,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = FedExPurple
                                    )
                                    Text(
                                        text = selectedShipment.trackingNumber,
                                        fontSize = 20.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }

                                ShipmentStatusChip(selectedShipment.status)
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = selectedShipment.title,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Text(
                                text = "${selectedShipment.senderName} (${selectedShipment.senderCityCountry}) → ${selectedShipment.recipientName} (${selectedShipment.recipientCityCountry})",
                                fontSize = 13.sp,
                                color = Color.Gray
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // ETA Banner
                            Surface(
                                color = FedExPurpleContainer,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            text = "ESTIMATED DELIVERY",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = FedExPurple
                                        )
                                        Text(
                                            text = selectedShipment.etaText,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = FedExPurpleDark
                                        )
                                        Text(
                                            text = selectedShipment.etaTimeWindow,
                                            fontSize = 12.sp,
                                            color = FedExPurple
                                        )
                                    }

                                    if (selectedShipment.driverName != null) {
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text(
                                                text = "COURIER",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = FedExOrangeDark
                                            )
                                            Text(
                                                text = selectedShipment.driverName.split("(").first(),
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = FedExOrangeDark
                                            )
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Quick Action Bar for this shipment
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                OutlinedButton(
                                    onClick = { onOpenSubScreen(com.example.ui.viewmodel.SubScreen.DELIVERY_MANAGER) },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = FedExPurple),
                                    modifier = Modifier.weight(1f).testTag("delivery_options_button")
                                ) {
                                    Icon(Icons.Default.EditRoad, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Options", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }

                                if (customsInfo != null) {
                                    OutlinedButton(
                                        onClick = { onOpenSubScreen(com.example.ui.viewmodel.SubScreen.CUSTOMS) },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = FedExPurple),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Public, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Customs", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }

                                OutlinedButton(
                                    onClick = { onOpenSubScreen(com.example.ui.viewmodel.SubScreen.DOCUMENTS) },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.outlinedButtonColors(contentColor = FedExPurple),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.ReceiptLong, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Docs", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }

                // LIVE MAP CANVAS
                item {
                    Text(
                        text = "LIVE GEOGRAPHIC PROGRESS",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )

                    RouteMapCanvas(
                        originCity = selectedShipment.senderCityCountry.split(",").first(),
                        destCity = selectedShipment.recipientCityCountry.split(",").first(),
                        status = selectedShipment.status
                    )
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }

                // TIMELINE STEPS
                item {
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            TrackingTimelineView(
                                events = scanEvents,
                                currentStatus = selectedShipment.status
                            )
                        }
                    }
                }

                item { Spacer(modifier = Modifier.height(16.dp)) }

                // PACKAGE SPECIFICATIONS CARD
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "SHIPMENT DETAILS",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                letterSpacing = 1.sp
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text("Weight", fontSize = 12.sp, color = Color.Gray)
                                    Text("${selectedShipment.weightKg} kg", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                Column {
                                    Text("Package Size", fontSize = 12.sp, color = Color.Gray)
                                    Text(selectedShipment.packageSize, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                }

                                Column {
                                    Text("Service", fontSize = 12.sp, color = Color.Gray)
                                    Text(selectedShipment.carrierService, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = FedExPurple)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("No shipment found for search query.", color = Color.Gray)
            }
        }
    }

    // SIMULATED BARCODE SCANNER DIALOG
    if (showScanSimulatedDialog) {
        AlertDialog(
            onDismissRequest = { showScanSimulatedDialog = false },
            icon = { Icon(Icons.Default.QrCodeScanner, contentDescription = null, tint = FedExOrange) },
            title = { Text("Simulated Barcode Scanner") },
            text = {
                Column {
                    Text("Align FedEx barcode or air waybill within camera frame:")
                    Spacer(modifier = Modifier.height(12.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .background(NeutralDark, RoundedCornerShape(12.dp))
                            .border(2.dp, FedExOrange, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("📷 [CAMERA PREVIEW SIMULATION]", color = Color.White, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showScanSimulatedDialog = false
                        searchQuery = "7812394821"
                        onSelectShipment("7812394821")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FedExPurple)
                ) {
                    Text("Scan Sample #7812394821")
                }
            },
            dismissButton = {
                TextButton(onClick = { showScanSimulatedDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}
