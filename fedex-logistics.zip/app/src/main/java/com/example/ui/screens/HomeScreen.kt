package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Shipment
import com.example.data.model.ShipmentStatus
import com.example.ui.components.RouteMapCanvas
import com.example.ui.components.ShipmentStatusChip
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    shipments: List<Shipment>,
    selectedTrackingNumber: String,
    onSelectShipment: (String) -> Unit,
    onNavigateTab: (com.example.ui.viewmodel.AppNavTab) -> Unit,
    onOpenSubScreen: (com.example.ui.viewmodel.SubScreen) -> Unit,
    isBusinessMode: Boolean
) {
    val scrollState = rememberScrollState()

    // Find primary hero shipment (e.g. Out for delivery or first active)
    val primaryShipment = shipments.find { it.status == ShipmentStatus.OUT_FOR_DELIVERY }
        ?: shipments.firstOrNull()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(scrollState)
            .padding(16.dp)
    ) {
        // Greeting Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "Good morning",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = if (isBusinessMode) "Global Freight & Logistics Dashboard" else "Every shipment. Every destination. One FedEx.",
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }

            Surface(
                color = FedExOrangeContainer,
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(FedExOrange)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LIVE",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FedExOrangeDark
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Quick Action Buttons Row: [TRACK] [SHIP] [RETURNS] [ASSIST]
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { onNavigateTab(com.example.ui.viewmodel.AppNavTab.TRACKING) },
                colors = ButtonDefaults.buttonColors(containerColor = FedExPurple),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("track_button")
            ) {
                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("TRACK", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            Button(
                onClick = { onNavigateTab(com.example.ui.viewmodel.AppNavTab.SHIP) },
                colors = ButtonDefaults.buttonColors(containerColor = FedExOrange),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("ship_button")
            ) {
                Icon(Icons.Default.LocalShipping, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("SHIP", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }

            Button(
                onClick = { onOpenSubScreen(com.example.ui.viewmodel.SubScreen.RETURNS) },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF202124)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .height(48.dp)
                    .testTag("returns_button")
            ) {
                Icon(Icons.Default.AssignmentReturn, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("RETURNS", fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // HERO SHIPMENT CARD
        if (primaryShipment != null) {
            Text(
                text = "YOUR SHIPMENTS",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(bottom = 8.dp)
            )

            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        onSelectShipment(primaryShipment.trackingNumber)
                        onNavigateTab(com.example.ui.viewmodel.AppNavTab.TRACKING)
                    }
                    .testTag("hero_shipment_card")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("📦", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = primaryShipment.carrierService,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FedExPurple
                                )
                                Text(
                                    text = primaryShipment.trackingNumber,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        ShipmentStatusChip(primaryShipment.status)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = primaryShipment.title,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )

                    Text(
                        text = "${primaryShipment.senderCityCountry} → ${primaryShipment.recipientCityCountry}",
                        fontSize = 13.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(top = 2.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Route Map Canvas Preview
                    RouteMapCanvas(
                        originCity = primaryShipment.senderCityCountry.split(",").first(),
                        destCity = primaryShipment.recipientCityCountry.split(",").first(),
                        status = primaryShipment.status
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(FedExPurpleContainer, RoundedCornerShape(12.dp))
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Schedule,
                                contentDescription = null,
                                tint = FedExPurple,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = primaryShipment.etaText,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = FedExPurpleDark
                                )
                                Text(
                                    text = primaryShipment.etaTimeWindow,
                                    fontSize = 11.sp,
                                    color = FedExPurple
                                )
                            }
                        }

                        OutlinedButton(
                            onClick = {
                                onSelectShipment(primaryShipment.trackingNumber)
                                onOpenSubScreen(com.example.ui.viewmodel.SubScreen.DELIVERY_MANAGER)
                            },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = FedExPurple),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(36.dp)
                        ) {
                            Text("OPTIONS", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // OTHER ACTIVE SHIPMENTS HORIZONTAL SCROLL
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ACTIVE PACKAGE PIPELINE",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                letterSpacing = 1.sp
            )

            TextButton(onClick = { onNavigateTab(com.example.ui.viewmodel.AppNavTab.TRACKING) }) {
                Text("See All (${shipments.size})", fontSize = 12.sp, color = FedExPurple, fontWeight = FontWeight.Bold)
            }
        }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            items(shipments) { item ->
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .width(260.dp)
                        .clickable {
                            onSelectShipment(item.trackingNumber)
                            onNavigateTab(com.example.ui.viewmodel.AppNavTab.TRACKING)
                        }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            ShipmentStatusChip(item.status)
                            Text(
                                text = "#${item.trackingNumber.takeLast(6)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = item.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )

                        Text(
                            text = "${item.senderCityCountry} → ${item.recipientCityCountry}",
                            fontSize = 12.sp,
                            color = Color.Gray,
                            maxLines = 1
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Event,
                                contentDescription = null,
                                tint = FedExOrange,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "${item.etaText} (${item.etaTimeWindow})",
                                fontSize = 11.sp,
                                color = FedExOrangeDark,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // FEDEX ASSIST QUICK AI CARD
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = FedExPurple),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpenSubScreen(com.example.ui.viewmodel.SubScreen.ASSISTANT) }
                .testTag("ai_assist_banner_card")
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = FedExOrange,
                    shape = CircleShape,
                    modifier = Modifier.size(44.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = Color.White
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "FEDEX ASSIST AI",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = FedExOrangeLight,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Ask anything about tracking, customs, or rates",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Icon(
                    imageVector = Icons.Default.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // QUICK LOGISTICS UTILITIES GRID
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onOpenSubScreen(com.example.ui.viewmodel.SubScreen.LOCATIONS) }
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Icon(Icons.Default.Place, contentDescription = null, tint = FedExPurple)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Locations", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Offices & Lockers", fontSize = 11.sp, color = Color.Gray)
                }
            }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onOpenSubScreen(com.example.ui.viewmodel.SubScreen.CUSTOMS) }
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Icon(Icons.Default.Public, contentDescription = null, tint = FedExPurple)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Customs Hub", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Duties & Clearance", fontSize = 11.sp, color = Color.Gray)
                }
            }

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .weight(1f)
                    .clickable { onOpenSubScreen(com.example.ui.viewmodel.SubScreen.DOCUMENTS) }
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Icon(Icons.Default.Description, contentDescription = null, tint = FedExPurple)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Documents", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Invoices & Waybills", fontSize = 11.sp, color = Color.Gray)
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
