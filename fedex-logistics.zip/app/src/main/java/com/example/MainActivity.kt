package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.TopHeaderBar
import com.example.ui.screens.*
import com.example.ui.theme.FedExOrange
import com.example.ui.theme.FedExPurple
import com.example.ui.theme.FedExTheme
import com.example.ui.viewmodel.AppNavTab
import com.example.ui.viewmodel.FedExViewModel
import com.example.ui.viewmodel.SubScreen

class MainActivity : ComponentActivity() {
    private val viewModel: FedExViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            FedExTheme {
                val isBusinessMode by viewModel.isBusinessMode.collectAsState()
                val currentTab by viewModel.currentTab.collectAsState()
                val currentSubScreen by viewModel.currentSubScreen.collectAsState()
                val selectedTrackingNumber by viewModel.selectedTrackingNumber.collectAsState()
                val selectedShipment by viewModel.selectedShipment.collectAsState()
                val shipments by viewModel.shipments.collectAsState()
                val locations by viewModel.locations.collectAsState()
                val documents by viewModel.documents.collectAsState()
                val notifications by viewModel.notifications.collectAsState()
                val chatMessages by viewModel.chatMessages.collectAsState()
                val isAssistantLoading by viewModel.isAssistantLoading.collectAsState()
                val currentLanguage by viewModel.currentLanguage.collectAsState()
                val availableLanguages = viewModel.availableLanguages

                val shipFrom by viewModel.shipFrom.collectAsState()
                val shipTo by viewModel.shipTo.collectAsState()
                val packageWeight by viewModel.packageWeight.collectAsState()
                val packageType by viewModel.packageType.collectAsState()
                val quoteOptions by viewModel.quoteOptions.collectAsState()

                val unreadNotifs = notifications.count { !it.isRead }

                Scaffold(
                    topBar = {
                        if (currentSubScreen == SubScreen.NONE) {
                            TopHeaderBar(
                                isBusinessMode = isBusinessMode,
                                onToggleBusinessMode = { viewModel.setBusinessMode(it) },
                                unreadNotifCount = unreadNotifs,
                                onOpenNotifs = { viewModel.openSubScreen(SubScreen.NOTIFICATIONS) },
                                onOpenAccount = { viewModel.openSubScreen(SubScreen.ACCOUNT) }
                            )
                        }
                    },
                    bottomBar = {
                        if (currentSubScreen == SubScreen.NONE) {
                            NavigationBar(
                                containerColor = MaterialTheme.colorScheme.surface,
                                contentColor = FedExPurple,
                                modifier = Modifier.height(72.dp)
                            ) {
                                NavigationBarItem(
                                    selected = currentTab == AppNavTab.HOME,
                                    onClick = { viewModel.setNavTab(AppNavTab.HOME) },
                                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                    label = { Text("Home", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = FedExPurple,
                                        selectedTextColor = FedExPurple,
                                        indicatorColor = FedExPurple.copy(alpha = 0.15f)
                                    ),
                                    modifier = Modifier.testTag("nav_tab_home")
                                )

                                NavigationBarItem(
                                    selected = currentTab == AppNavTab.TRACKING,
                                    onClick = { viewModel.setNavTab(AppNavTab.TRACKING) },
                                    icon = { Icon(Icons.Default.Search, contentDescription = "Tracking") },
                                    label = { Text("Tracking", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = FedExPurple,
                                        selectedTextColor = FedExPurple,
                                        indicatorColor = FedExPurple.copy(alpha = 0.15f)
                                    ),
                                    modifier = Modifier.testTag("nav_tab_tracking")
                                )

                                NavigationBarItem(
                                    selected = currentTab == AppNavTab.SHIP,
                                    onClick = { viewModel.setNavTab(AppNavTab.SHIP) },
                                    icon = { Icon(Icons.Default.LocalShipping, contentDescription = "Ship") },
                                    label = { Text("Ship", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = FedExOrange,
                                        selectedTextColor = FedExOrange,
                                        indicatorColor = FedExOrange.copy(alpha = 0.15f)
                                    ),
                                    modifier = Modifier.testTag("nav_tab_ship")
                                )

                                NavigationBarItem(
                                    selected = currentTab == AppNavTab.MAP,
                                    onClick = { viewModel.setNavTab(AppNavTab.MAP) },
                                    icon = { Icon(Icons.Default.Map, contentDescription = "Live Map") },
                                    label = { Text("Map", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = FedExPurple,
                                        selectedTextColor = FedExPurple,
                                        indicatorColor = FedExPurple.copy(alpha = 0.15f)
                                    ),
                                    modifier = Modifier.testTag("nav_tab_map")
                                )

                                NavigationBarItem(
                                    selected = currentTab == AppNavTab.MORE,
                                    onClick = { viewModel.setNavTab(AppNavTab.MORE) },
                                    icon = { Icon(Icons.Default.GridView, contentDescription = "More") },
                                    label = { Text("More", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = FedExPurple,
                                        selectedTextColor = FedExPurple,
                                        indicatorColor = FedExPurple.copy(alpha = 0.15f)
                                    ),
                                    modifier = Modifier.testTag("nav_tab_more")
                                )
                            }
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        if (currentSubScreen != SubScreen.NONE) {
                            when (currentSubScreen) {
                                SubScreen.ASSISTANT -> FedExAssistScreen(
                                    messages = chatMessages,
                                    isLoading = isAssistantLoading,
                                    onSendMessage = { viewModel.sendAssistMessage(it) },
                                    onBack = { viewModel.openSubScreen(SubScreen.NONE) }
                                )

                                SubScreen.DELIVERY_MANAGER -> DeliveryManagerScreen(
                                    shipment = selectedShipment ?: shipments.firstOrNull(),
                                    onSaveInstructions = { trackingNum, dateOpt, holdLoc, safe, neighbor ->
                                        viewModel.saveDeliveryOptions(trackingNum, dateOpt, holdLoc, safe, neighbor)
                                    },
                                    onBack = { viewModel.openSubScreen(SubScreen.NONE) }
                                )

                                SubScreen.CUSTOMS -> CustomsCenterScreen(
                                    shipment = selectedShipment ?: shipments.firstOrNull(),
                                    onViewDocuments = { viewModel.openSubScreen(SubScreen.DOCUMENTS) },
                                    onBack = { viewModel.openSubScreen(SubScreen.NONE) }
                                )

                                SubScreen.LOCATIONS -> LocationFinderScreen(
                                    locations = locations,
                                    repository = viewModel.repository,
                                    onBack = { viewModel.openSubScreen(SubScreen.NONE) }
                                )

                                SubScreen.RETURNS -> ReturnsScreen(
                                    shipments = shipments,
                                    onCreateReturn = { origTracking, method ->
                                        viewModel.createReturn(origTracking, method)
                                    },
                                    onBack = { viewModel.openSubScreen(SubScreen.NONE) }
                                )

                                SubScreen.ANALYTICS -> BusinessAnalyticsScreen(
                                    onBack = { viewModel.openSubScreen(SubScreen.NONE) }
                                )

                                SubScreen.DOCUMENTS -> DocumentCenterScreen(
                                    documents = documents,
                                    onBack = { viewModel.openSubScreen(SubScreen.NONE) }
                                )

                                SubScreen.NOTIFICATIONS -> NotificationsScreen(
                                    notifications = notifications,
                                    onMarkRead = { viewModel.markNotificationRead(it) },
                                    onMarkAllRead = { viewModel.markAllNotificationsRead() },
                                    onBack = { viewModel.openSubScreen(SubScreen.NONE) }
                                )

                                SubScreen.ACCOUNT -> AccountSettingsScreen(
                                    currentLanguage = currentLanguage,
                                    availableLanguages = availableLanguages,
                                    onSelectLanguage = { viewModel.setLanguage(it) },
                                    isBusinessMode = isBusinessMode,
                                    onToggleBusinessMode = { viewModel.setBusinessMode(it) },
                                    onBack = { viewModel.openSubScreen(SubScreen.NONE) }
                                )

                                SubScreen.NONE -> {}
                            }
                        } else {
                            when (currentTab) {
                                AppNavTab.HOME -> HomeScreen(
                                    shipments = shipments,
                                    selectedTrackingNumber = selectedTrackingNumber,
                                    onSelectShipment = { viewModel.selectTrackingNumber(it) },
                                    onNavigateTab = { viewModel.setNavTab(it) },
                                    onOpenSubScreen = { viewModel.openSubScreen(it) },
                                    isBusinessMode = isBusinessMode
                                )

                                AppNavTab.TRACKING -> TrackingScreen(
                                    shipments = shipments,
                                    selectedShipment = selectedShipment,
                                    selectedTrackingNumber = selectedTrackingNumber,
                                    onSelectShipment = { viewModel.selectTrackingNumber(it) },
                                    onOpenSubScreen = { viewModel.openSubScreen(it) },
                                    repository = viewModel.repository
                                )

                                AppNavTab.SHIP -> ShipScreen(
                                    shipFrom = shipFrom,
                                    shipTo = shipTo,
                                    packageWeight = packageWeight,
                                    packageType = packageType,
                                    quoteOptions = quoteOptions,
                                    onUpdateShipFrom = { viewModel.updateShipFrom(it) },
                                    onUpdateShipTo = { viewModel.updateShipTo(it) },
                                    onUpdateWeight = { viewModel.updatePackageWeight(it) },
                                    onUpdateType = { viewModel.updatePackageType(it) },
                                    onCreateShipmentFromQuote = { viewModel.createShipmentFromQuote(it) }
                                )

                                AppNavTab.MAP -> LogisticsMapScreen(
                                    shipments = shipments,
                                    locations = locations,
                                    selectedTrackingNumber = selectedTrackingNumber,
                                    onSelectShipment = { viewModel.selectTrackingNumber(it) },
                                    onNavigateTracking = { viewModel.setNavTab(AppNavTab.TRACKING) }
                                )

                                AppNavTab.MORE -> MoreMenuScreen(
                                    onOpenSubScreen = { viewModel.openSubScreen(it) },
                                    isBusinessMode = isBusinessMode,
                                    onToggleBusinessMode = { viewModel.setBusinessMode(it) }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
