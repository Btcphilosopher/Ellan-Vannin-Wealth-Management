# BTC-OS: Matching Engine & Double-Entry Ledger Invariants

## Matching Engine Specification
- **Order Book Structure**: `CentralLimitOrderBook` maintaining separate bid and ask ladders.
- **Priority Rules**: Price-Time Priority (`Price` -> `Timestamp` -> `Sequence Number`).
  - Bids: Highest price first, then earliest timestamp, then lowest sequence ID.
  - Asks: Lowest price first, then earliest timestamp, then lowest sequence ID.
- **Supported Order Types**:
  - `MARKET`: Aggressive taker sweep across resting depth; unfulfilled balance cancelled immediately.
  - `LIMIT`: Places onto book if resting; crosses opposing book at maker price.
  - `POST_ONLY`: Rejects with zero fills if incoming price would cross resting book as taker.
  - `IOC` (Immediate or Cancel): Matches available opposing liquidity immediately, cancels unexecuted portion.
  - `FOK` (Fill or Kill): Requires 100% immediate fill across opposing depth; otherwise rejects with 0 fills.
  - `STOP` / `STOP_LIMIT`: Triggers upon market price crossing threshold.

## Circuit Breakers & Kill Switch
- **Collar Band**: Rejects limit orders priced outside ±25% of reference index.
- **Emergency Kill Switch**: Operator-controlled instant halt preventing order admission while retaining auditable state.

## Double-Entry Ledger Invariant
- **Rule**: Every trade settlement and deposit movement generates balanced journal postings.
- **Invariant**:
  $$\sum \text{Debits} \equiv \sum \text{Credits}$$
- **Zero-Drift Verification**: Automated reconciliation verifies that both Bitcoin satoshis and fiat minor units remain in exact balance after every execution.
- **Asset Segregation**: Strict separation between `CLIENT_ASSET_SEGREGATED`, `PLATFORM_OPERATIONAL`, `TREASURY_RESERVE`, and `FEE_REVENUE`.
