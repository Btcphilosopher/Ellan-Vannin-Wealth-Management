package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.btcos.ui.MarketViewModel
import com.example.btcos.ui.TerminalTab
import com.example.btcos.ui.components.MarketTopBar
import com.example.btcos.ui.screens.AiAnalystScreen
import com.example.btcos.ui.screens.DigitalTwinScreen
import com.example.btcos.ui.screens.LedgerSettlementScreen
import com.example.btcos.ui.screens.LiquidityScreen
import com.example.btcos.ui.screens.RiskSurveillanceScreen
import com.example.btcos.ui.screens.TerminalScreen
import com.example.ui.theme.BgGraphiteDark
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                BtcOsApp()
            }
        }
    }
}

@Composable
fun BtcOsApp(
    viewModel: MarketViewModel = viewModel()
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(BgGraphiteDark),
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .windowInsetsPadding(WindowInsets.statusBars)
                .navigationBarsPadding()
                .background(BgGraphiteDark)
        ) {
            // Market Top Bar with ticker, regulatory sandbox status & navigation tabs
            MarketTopBar(
                selectedInstrument = state.selectedInstrument,
                lastPriceCents = state.lastTradedPriceCents,
                priceChangePct = state.priceChange24hPct,
                volume24hBtc = state.volume24hBtc,
                spreadBps = state.orderBookSnapshot?.spreadBps,
                activeTab = state.currentTab,
                isKillSwitchEngaged = state.isKillSwitchEngaged,
                onInstrumentSelected = { viewModel.selectInstrument(it) },
                onTabSelected = { viewModel.selectTab(it) }
            )

            // Dynamic screen according to selected institutional tab
            Box(modifier = Modifier.weight(1f)) {
                when (state.currentTab) {
                    TerminalTab.TERMINAL -> {
                        TerminalScreen(state = state, viewModel = viewModel)
                    }
                    TerminalTab.LIQUIDITY_SOR -> {
                        LiquidityScreen(state = state, viewModel = viewModel)
                    }
                    TerminalTab.LEDGER_SETTLE -> {
                        LedgerSettlementScreen(state = state, viewModel = viewModel)
                    }
                    TerminalTab.RISK_SURVEILLANCE -> {
                        RiskSurveillanceScreen(state = state, viewModel = viewModel)
                    }
                    TerminalTab.DIGITAL_TWIN -> {
                        DigitalTwinScreen(state = state, viewModel = viewModel)
                    }
                    TerminalTab.AI_ANALYST -> {
                        AiAnalystScreen(state = state, viewModel = viewModel)
                    }
                }
            }
        }
    }
}
