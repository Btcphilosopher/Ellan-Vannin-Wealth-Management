package com.example.btcos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btcos.core.BitcoinAmount
import com.example.btcos.core.FiatAmount
import com.example.btcos.liquidity.RoutingStrategy
import com.example.btcos.market.MarketMaster
import com.example.btcos.ui.MarketUiState
import com.example.btcos.ui.MarketViewModel
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgGraphiteDark
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.BtcGold
import com.example.ui.theme.InstitutionalBlue
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMutedGraphite
import com.example.ui.theme.TextPaperWhite
import java.util.Locale

@Composable
fun LiquidityScreen(
    state: MarketUiState,
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Multi-Venue Liquidity Comparison Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text(
                text = "CONSOLIDATED VENUE LIQUIDITY POOL",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite
            )
            Spacer(modifier = Modifier.height(6.dp))

            // Venue list
            MarketMaster.VENUES.forEach { venue ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.4f)) {
                        Text(
                            text = venue.name,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace,
                            color = TextPaperWhite
                        )
                        Text(
                            text = "${venue.jurisdiction.label} • ${venue.liquidityProfile}",
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextDim
                        )
                    }
                    Text(
                        text = "${venue.latencyMs}ms",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = InstitutionalBlue,
                        modifier = Modifier.weight(0.6f)
                    )
                    Text(
                        text = "${venue.feeBpsTaker} bps",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextMutedGraphite,
                        modifier = Modifier.weight(0.6f)
                    )
                    Box(
                        modifier = Modifier
                            .background(TerminalGreen.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "ACTIVE",
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = TerminalGreen
                        )
                    }
                }
            }
        }

        // Smart Order Routing (SOR) Algorithm Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "SMART ORDER ROUTER (SOR) SLICING",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextMutedGraphite
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "ALGORITHMIC",
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    color = InstitutionalBlue
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Strategy Selector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                listOf(
                    RoutingStrategy.MULTI_VENUE,
                    RoutingStrategy.SINGLE_VENUE,
                    RoutingStrategy.VWAP,
                    RoutingStrategy.LIQUIDITY_SEEKING
                ).forEach { strat ->
                    val isSel = state.sorPlan?.strategy == strat
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isSel) InstitutionalBlue else BgGraphiteDark, RoundedCornerShape(2.dp))
                            .clickable { viewModel.computeSorRoute(strat) }
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = strat.name.take(6),
                            fontSize = 9.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            fontFamily = FontFamily.Monospace,
                            color = if (isSel) BgGraphiteDark else TextMutedGraphite
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            state.sorPlan?.let { plan ->
                // Metrics summary
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BgGraphiteDark, RoundedCornerShape(3.dp))
                        .padding(6.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "EST. FILL PRICE", fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                        Text(text = FiatAmount(plan.estimatedFillPriceCents).formatted(), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "EST. SLIPPAGE", fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                        Text(text = String.format(Locale.US, "%.2f bps", plan.estimatedSlippageBps), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGreen)
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "TOTAL EST. FEES", fontSize = 8.5.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                        Text(text = FiatAmount(plan.estimatedTotalFeesCents).formatted(), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = BtcGold)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(text = "ALLOCATION SLICES BY VENUE:", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                Spacer(modifier = Modifier.height(4.dp))

                plan.slices.forEach { slice ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = slice.venueName,
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextPaperWhite,
                            modifier = Modifier.weight(1.2f)
                        )
                        Text(
                            text = "${BitcoinAmount(slice.allocatedSats).toBtcString(2)} (${String.format(Locale.US, "%.1f", slice.weightPercent)}%)",
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = BtcGold,
                            textAlign = TextAlign.End,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = FiatAmount(slice.estimatedFeeCents).formatted(),
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextMutedGraphite,
                            textAlign = TextAlign.End,
                            modifier = Modifier.weight(0.8f)
                        )
                    }
                }
            }
        }

        // Cross-Venue Arbitrage & Theoretical Basis Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text(
                text = "CROSS-VENUE ARBITRAGE & THEORETICAL BASIS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite
            )
            Spacer(modifier = Modifier.height(6.dp))

            if (state.arbitrageOpportunities.isEmpty()) {
                Text(
                    text = "No non-negative spread arbitrage currently executable after taker fee deduction.",
                    fontSize = 9.5.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextDim
                )
            } else {
                state.arbitrageOpportunities.take(3).forEach { arb ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.5f)) {
                            Text(
                                text = "BUY ${arb.venueBuyName} → SELL ${arb.venueSellName}",
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.SemiBold,
                                fontFamily = FontFamily.Monospace,
                                color = TextPaperWhite
                            )
                            Text(
                                text = "Gross: ${String.format(Locale.US, "+%.1f", arb.grossSpreadBps)} bps | Fees: ${String.format(Locale.US, "%.1f", arb.totalEstimatedFeeBps)} bps",
                                fontSize = 8.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextDim
                            )
                        }
                        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(0.8f)) {
                            val netColor = if (arb.isExecutable) TerminalGreen else TerminalRed
                            Text(
                                text = String.format(Locale.US, "NET: %+.1f bps", arb.netSpreadBps),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = netColor
                            )
                            Text(
                                text = if (arb.isExecutable) "EXECUTABLE" else "SUB-SPREAD",
                                fontSize = 7.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (arb.isExecutable) TerminalGreen else TextDim
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // BTC/CNH Theoretical Model Section
            state.btcCnhPricing?.let { cnh ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BgGraphiteDark, RoundedCornerShape(3.dp))
                        .padding(6.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "BTC/CNH THEORETICAL FX MODEL",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = InstitutionalBlue
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "USD/CNH: ${cnh.usdCnhRate}",
                                fontSize = 8.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextMutedGraphite
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Theoretical: ¥${String.format(Locale.US, "%,.2f", cnh.theoreticalBtcCnhCents / 100.0)}",
                                fontSize = 9.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextPaperWhite,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = "Basis: ${String.format(Locale.US, "+%.1f bps", cnh.basisDeviationBps)}",
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = BtcGold,
                                textAlign = TextAlign.End,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
