package com.example.btcos.risk

import com.example.btcos.core.BitcoinAmount
import com.example.btcos.core.FiatAmount
import java.util.UUID

enum class AlertSeverity { INFO, WARNING, CRITICAL }
enum class AlertStatus { OPEN, INVESTIGATING, DISMISSED }

data class SurveillanceAlert(
    val alertId: String,
    val timestamp: Long,
    val market: String,
    val accountId: String,
    val signal: String,
    val severity: AlertSeverity,
    val evidence: String,
    val status: AlertStatus = AlertStatus.OPEN
)

data class StressScenarioResult(
    val name: String,
    val description: String,
    val btcPriceShiftPct: Double,
    val liquidityReductionPct: Double,
    val simulatedPriceCents: Long,
    val portfolioLossCents: Long,
    val portfolioLossBtcAmount: BitcoinAmount,
    val marginImpactDescription: String,
    val riskRating: String
)

data class MarketRiskMetrics(
    val btcSpotPriceCents: Long,
    val portfolioBtcSats: Long,
    val portfolioUsdCents: Long,
    val totalPortfolioValueCents: Long,
    val var95DailyCents: Long,
    val var99DailyCents: Long,
    val expectedShortfall99Cents: Long, // CVaR
    val realisedVolatilityAnnualizedPct: Double,
    val amihudIlliquidityMeasure: Double,
    val maxDrawdownPct: Double,
    val betaToGlobalCrypto: Double
)

class RiskSurveillanceEngine {
    private val alerts = ArrayList<SurveillanceAlert>()
    private val lock = Any()

    init {
        // Initial regulatory surveillance audit records
        alerts.add(
            SurveillanceAlert(
                alertId = "ALT-SURV-101",
                timestamp = System.currentTimeMillis() - 15 * 60 * 1000,
                market = "BTC/USD",
                accountId = "CLIENT_002",
                signal = "POTENTIAL_SPOOFING",
                severity = AlertSeverity.WARNING,
                evidence = "Large limit buy (25.0 BTC) cancelled 420ms after placement near best bid without fill.",
                status = AlertStatus.INVESTIGATING
            )
        )
        alerts.add(
            SurveillanceAlert(
                alertId = "ALT-SURV-102",
                timestamp = System.currentTimeMillis() - 48 * 60 * 1000,
                market = "BTC/USDT",
                accountId = "MM_ALPHA",
                signal = "HIGH_CANCEL_RATIO",
                severity = AlertSeverity.INFO,
                evidence = "Order cancellation to execution ratio reached 94.2% across 5-minute rolling window.",
                status = AlertStatus.OPEN
            )
        )
    }

    fun getAlerts(): List<SurveillanceAlert> = synchronized(lock) { ArrayList(alerts) }

    fun addAlert(alert: SurveillanceAlert) {
        synchronized(lock) {
            alerts.add(0, alert)
        }
    }

    fun updateAlertStatus(alertId: String, newStatus: AlertStatus) {
        synchronized(lock) {
            val idx = alerts.indexOfFirst { it.alertId == alertId }
            if (idx >= 0) {
                alerts[idx] = alerts[idx].copy(status = newStatus)
            }
        }
    }

    /**
     * Calculates institutional market risk metrics.
     */
    fun calculateMetrics(
        spotPriceCents: Long,
        totalBtcSats: Long,
        cashCents: Long
    ): MarketRiskMetrics {
        val btcValCents = Math.round((spotPriceCents.toDouble() * totalBtcSats) / BitcoinAmount.SATS_PER_BTC)
        val totalValueCents = btcValCents + cashCents

        // Historical 30d annualized volatility ~ 52.4%
        val dailyVol = 0.524 / Math.sqrt(365.0) // ~ 2.74% daily std dev
        val var95 = Math.round(btcValCents * (1.645 * dailyVol))
        val var99 = Math.round(btcValCents * (2.326 * dailyVol))
        val cvar99 = Math.round(btcValCents * (2.665 * dailyVol))

        return MarketRiskMetrics(
            btcSpotPriceCents = spotPriceCents,
            portfolioBtcSats = totalBtcSats,
            portfolioUsdCents = cashCents,
            totalPortfolioValueCents = totalValueCents,
            var95DailyCents = var95,
            var99DailyCents = var99,
            expectedShortfall99Cents = cvar99,
            realisedVolatilityAnnualizedPct = 52.4,
            amihudIlliquidityMeasure = 0.00000412,
            maxDrawdownPct = 14.8,
            betaToGlobalCrypto = 1.04
        )
    }

    /**
     * Executes stress test scenarios across market shock regimes.
     */
    fun runStressScenarios(spotPriceCents: Long, portfolioBtcSats: Long): List<StressScenarioResult> {
        val btcDouble = portfolioBtcSats.toDouble() / BitcoinAmount.SATS_PER_BTC

        return listOf(
            StressScenarioResult(
                name = "Market Shock: BTC -10%",
                description = "Standard institutional 1-day tail risk event with moderate liquidity compression.",
                btcPriceShiftPct = -10.0,
                liquidityReductionPct = -25.0,
                simulatedPriceCents = (spotPriceCents * 0.90).toLong(),
                portfolioLossCents = Math.round(spotPriceCents * 0.10 * btcDouble),
                portfolioLossBtcAmount = BitcoinAmount(0L),
                marginImpactDescription = "Collateral coverage remains sufficient (>280%). No margin calls.",
                riskRating = "LOW RISK"
            ),
            StressScenarioResult(
                name = "Severe Shock: BTC -20%",
                description = "Acute sell-off driven by macro liquidity contraction; spread expands 4x.",
                btcPriceShiftPct = -20.0,
                liquidityReductionPct = -50.0,
                simulatedPriceCents = (spotPriceCents * 0.80).toLong(),
                portfolioLossCents = Math.round(spotPriceCents * 0.20 * btcDouble),
                portfolioLossBtcAmount = BitcoinAmount(0L),
                marginImpactDescription = "Tier-2 market maker limits reached. Passive spreads widen to 32 bps.",
                riskRating = "MODERATE RISK"
            ),
            StressScenarioResult(
                name = "Extreme Volatility: BTC -30%",
                description = "Flash cascading liquidations across external derivative venues spilling into spot.",
                btcPriceShiftPct = -30.0,
                liquidityReductionPct = -70.0,
                simulatedPriceCents = (spotPriceCents * 0.70).toLong(),
                portfolioLossCents = Math.round(spotPriceCents * 0.30 * btcDouble),
                portfolioLossBtcAmount = BitcoinAmount(0L),
                marginImpactDescription = "Level 1 Circuit Breaker triggered. 15-minute trading pause recommended.",
                riskRating = "HIGH RISK"
            ),
            StressScenarioResult(
                name = "Systemic Crisis: BTC -50%",
                description = "Severe tail-risk capitulation event; liquidity evaporated, multi-venue dislocations.",
                btcPriceShiftPct = -50.0,
                liquidityReductionPct = -85.0,
                simulatedPriceCents = (spotPriceCents * 0.50).toLong(),
                portfolioLossCents = Math.round(spotPriceCents * 0.50 * btcDouble),
                portfolioLossBtcAmount = BitcoinAmount(0L),
                marginImpactDescription = "Level 2 Circuit Breaker invoked. Physical settlement halts initiated.",
                riskRating = "CRITICAL RISK"
            ),
            StressScenarioResult(
                name = "Stablecoin Depeg Shock (-5%)",
                description = "USDT/USDC basis drops to 0.95. Spot USD/BTC premium diverges +420 bps.",
                btcPriceShiftPct = -5.0,
                liquidityReductionPct = -40.0,
                simulatedPriceCents = (spotPriceCents * 0.95).toLong(),
                portfolioLossCents = Math.round(spotPriceCents * 0.05 * btcDouble),
                portfolioLossBtcAmount = BitcoinAmount(0L),
                marginImpactDescription = "Stablecoin settlement pairs temporarily routed to fiat USD rail.",
                riskRating = "SYSTEMIC ALERT"
            ),
            StressScenarioResult(
                name = "Major Venue Outage (Venue A Offline)",
                description = "Primary London liquidity hub disconnects. Flow shifts to Internal & New York venues.",
                btcPriceShiftPct = -1.5,
                liquidityReductionPct = -35.0,
                simulatedPriceCents = (spotPriceCents * 0.985).toLong(),
                portfolioLossCents = Math.round(spotPriceCents * 0.015 * btcDouble),
                portfolioLossBtcAmount = BitcoinAmount(0L),
                marginImpactDescription = "SOR auto-failover activated. Single-venue execution latency increases 4ms.",
                riskRating = "OPERATIONAL ALERT"
            )
        )
    }

    /**
     * Surveillance check on order cancellation to detect potential spoofing.
     */
    fun checkSpoofing(orderQuantitySats: Long, orderLifeMs: Long, cancelledNearBest: Boolean): SurveillanceAlert? {
        if (orderQuantitySats > 1_000_000_000L && orderLifeMs < 1000 && cancelledNearBest) {
            val alert = SurveillanceAlert(
                alertId = "ALT-SURV-" + UUID.randomUUID().toString().take(6).uppercase(),
                timestamp = System.currentTimeMillis(),
                market = "BTC/USD",
                accountId = "CLIENT_SUSPECT",
                signal = "RAPID_CANCELLATION_SPOOFING",
                severity = AlertSeverity.CRITICAL,
                evidence = "Order size ${orderQuantitySats / BitcoinAmount.SATS_PER_BTC} BTC cancelled within ${orderLifeMs}ms while near top of book.",
                status = AlertStatus.OPEN
            )
            addAlert(alert)
            return alert
        }
        return null
    }
}
