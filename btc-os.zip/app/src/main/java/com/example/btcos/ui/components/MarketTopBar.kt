package com.example.btcos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btcos.core.FiatAmount
import com.example.btcos.market.Instrument
import com.example.btcos.market.MarketMaster
import com.example.btcos.ui.TerminalTab
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgGraphiteDark
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.BtcGold
import com.example.ui.theme.InstitutionalBlue
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMutedGraphite
import com.example.ui.theme.TextPaperWhite
import java.util.Locale

@Composable
fun MarketTopBar(
    selectedInstrument: Instrument,
    lastPriceCents: Long,
    priceChangePct: Double,
    volume24hBtc: Double,
    spreadBps: Double?,
    activeTab: TerminalTab,
    isKillSwitchEngaged: Boolean,
    onInstrumentSelected: (Instrument) -> Unit,
    onTabSelected: (TerminalTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(BgGraphiteDark)
    ) {
        // Regulatory & Sandbox Mode Notice Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Color(0xFF131D28))
                .padding(horizontal = 12.dp, vertical = 3.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .clip(CircleShape)
                        .background(if (isKillSwitchEngaged) TerminalRed else TerminalGreen)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "UK FCA SANDBOX COMPLIANT • REQ REGULATED ACTIVITIES SEGREGATION • STRICT SIMULATION MODE",
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    color = TextMutedGraphite
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = if (isKillSwitchEngaged) "HALTED" else "LIVE MATCHING",
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = if (isKillSwitchEngaged) TerminalRed else TerminalGreen
                )
            }
        }

        // Header Title & Primary Spot Ticker
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "BTC-OS",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        color = BtcGold
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(BorderSteel, RoundedCornerShape(2.dp))
                            .padding(horizontal = 4.dp, vertical = 1.dp)
                    ) {
                        Text(
                            text = "v3.6 CORE",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            color = InstitutionalBlue
                        )
                    }
                }
                Text(
                    text = "Institutional Spot Market OS",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextDim
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            // Spot Price display
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = FiatAmount(lastPriceCents, selectedInstrument.quoteAsset).formatted(),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    color = TextPaperWhite
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val sign = if (priceChangePct >= 0) "+" else ""
                    val chgColor = if (priceChangePct >= 0) TerminalGreen else TerminalRed
                    Text(
                        text = "$sign${String.format(Locale.US, "%.2f", priceChangePct)}%",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = chgColor
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "24h Vol: ${String.format(Locale.US, "%.1f", volume24hBtc)} BTC",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextDim
                    )
                }
            }
        }

        // Horizontal Instrument Switcher Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            MarketMaster.INSTRUMENTS.forEach { inst ->
                val isSel = inst.id == selectedInstrument.id
                Box(
                    modifier = Modifier
                        .background(
                            if (isSel) BtcGold else BgCardElevated,
                            RoundedCornerShape(3.dp)
                        )
                        .clickable { onInstrumentSelected(inst) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                        .testTag("instrument_tab_${inst.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = inst.id,
                        fontSize = 10.sp,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Medium,
                        fontFamily = FontFamily.Monospace,
                        color = if (isSel) BgGraphiteDark else TextPaperWhite
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // High-density Navigation Tab Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            TerminalTab.values().forEach { tab ->
                val isSelected = tab == activeTab
                Box(
                    modifier = Modifier
                        .background(
                            if (isSelected) InstitutionalBlue else BgCardElevated,
                            RoundedCornerShape(3.dp)
                        )
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                        .testTag("nav_tab_${tab.name}"),
                    contentAlignment = Alignment.Center
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = tab.title,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            fontFamily = FontFamily.Monospace,
                            color = if (isSelected) BgGraphiteDark else TextPaperWhite
                        )
                        if (tab.badge != null) {
                            Spacer(modifier = Modifier.width(4.dp))
                            Box(
                                modifier = Modifier
                                    .background(
                                        if (isSelected) BgGraphiteDark else BorderSteel,
                                        RoundedCornerShape(2.dp)
                                    )
                                    .padding(horizontal = 3.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = tab.badge,
                                    fontSize = 7.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = if (isSelected) InstitutionalBlue else TextMutedGraphite
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
    }
}
