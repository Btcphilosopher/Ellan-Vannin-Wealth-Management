package com.example.btcos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btcos.core.FiatAmount
import com.example.btcos.risk.AlertSeverity
import com.example.btcos.risk.AlertStatus
import com.example.btcos.ui.MarketUiState
import com.example.btcos.ui.MarketViewModel
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgGraphiteDark
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.BtcGold
import com.example.ui.theme.InstitutionalBlue
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMutedGraphite
import com.example.ui.theme.TextPaperWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RiskSurveillanceScreen(
    state: MarketUiState,
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier
) {
    val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Market Risk & VaR Metrics Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "QUANTITATIVE MARKET RISK DASHBOARD",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextMutedGraphite
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "PARAMETRIC + HISTORICAL",
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    color = InstitutionalBlue
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            state.riskMetrics?.let { rm ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BgGraphiteDark, RoundedCornerShape(3.dp))
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(text = "1-DAY 95% VaR", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                        Text(text = FiatAmount(rm.var95DailyCents).formatted(), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = AmberWarning)
                    }
                    Column {
                        Text(text = "1-DAY 99% VaR", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                        Text(text = FiatAmount(rm.var99DailyCents).formatted(), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalRed)
                    }
                    Column {
                        Text(text = "EXPECTED SHORTFALL (CVaR)", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                        Text(text = FiatAmount(rm.expectedShortfall99Cents).formatted(), fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalRed)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Row(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "30d Realised Vol: ${rm.realisedVolatilityAnnualizedPct}% | Amihud Illiquidity: ${String.format(Locale.US, "%.7f", rm.amihudIlliquidityMeasure)} | Beta: ${rm.betaToGlobalCrypto}",
                        fontSize = 8.5.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextMutedGraphite
                    )
                }
            }
        }

        // Stress Testing Scenarios Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text(
                text = "MACROECONOMIC & LIQUIDITY STRESS TESTS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite
            )
            Spacer(modifier = Modifier.height(6.dp))

            state.stressResults.forEach { s ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .background(BgGraphiteDark, RoundedCornerShape(3.dp))
                        .padding(6.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = s.name,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TextPaperWhite,
                                modifier = Modifier.weight(1.5f)
                            )
                            val ratingColor = when {
                                s.riskRating.contains("CRITICAL") -> TerminalRed
                                s.riskRating.contains("HIGH") -> TerminalRed
                                s.riskRating.contains("MODERATE") -> AmberWarning
                                else -> InstitutionalBlue
                            }
                            Text(
                                text = s.riskRating,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = ratingColor
                            )
                        }

                        Spacer(modifier = Modifier.height(2.dp))

                        Text(
                            text = s.description,
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextDim
                        )

                        Spacer(modifier = Modifier.height(3.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "Simulated Spot: ${FiatAmount(s.simulatedPriceCents).formatted()}",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextMutedGraphite,
                                modifier = Modifier.weight(1.2f)
                            )
                            Text(
                                text = "Estimated Loss: -${FiatAmount(s.portfolioLossCents).formatted()}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalRed,
                                textAlign = TextAlign.End,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        // Market Surveillance & Integrity Monitor Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MARKET INTEGRITY & SURVEILLANCE ALERTS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextMutedGraphite
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "${state.surveillanceAlerts.size} AUDIT EVENTS",
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    color = AmberWarning
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            state.surveillanceAlerts.forEach { alert ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .background(BgGraphiteDark, RoundedCornerShape(3.dp))
                        .padding(6.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            val sevColor = when (alert.severity) {
                                AlertSeverity.CRITICAL -> TerminalRed
                                AlertSeverity.WARNING -> AmberWarning
                                AlertSeverity.INFO -> InstitutionalBlue
                            }
                            Box(
                                modifier = Modifier
                                    .background(sevColor.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = alert.severity.name,
                                    fontSize = 7.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = sevColor
                                )
                            }

                            Spacer(modifier = Modifier.width(6.dp))

                            Text(
                                text = "${alert.signal} (${alert.alertId})",
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TextPaperWhite
                            )

                            Spacer(modifier = Modifier.weight(1f))

                            Text(
                                text = timeFormat.format(Date(alert.timestamp)),
                                fontSize = 8.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextDim
                            )
                        }

                        Spacer(modifier = Modifier.height(3.dp))

                        Text(
                            text = alert.evidence,
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextMutedGraphite
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "STATUS: ${alert.status.name}",
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                color = TextDim
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            if (alert.status != AlertStatus.DISMISSED) {
                                Box(
                                    modifier = Modifier
                                        .background(BorderSteel, RoundedCornerShape(2.dp))
                                        .clickable { viewModel.updateSurveillanceAlertStatus(alert.alertId, AlertStatus.DISMISSED) }
                                        .padding(horizontal = 4.dp, vertical = 2.dp)
                                ) {
                                    Text(text = "DISMISS", fontSize = 7.5.sp, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
