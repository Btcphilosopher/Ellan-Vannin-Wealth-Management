package com.example.btcos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btcos.ui.MarketUiState
import com.example.btcos.ui.MarketViewModel
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgGraphiteDark
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.BtcGold
import com.example.ui.theme.InstitutionalBlue
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMutedGraphite
import com.example.ui.theme.TextPaperWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AiAnalystScreen(
    state: MarketUiState,
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier
) {
    val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // AI Header & Methodology Notice
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "INSTITUTIONAL AI MARKET ANALYST",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextMutedGraphite
                )
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .background(InstitutionalBlue.copy(alpha = 0.2f), RoundedCornerShape(2.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "100% PROVABLE PROVENANCE",
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = InstitutionalBlue
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = "Zero-hallucination institutional intelligence. Every explanation is strictly grounded in order book microstructure, matching engine execution logs, and double-entry balances.",
                fontSize = 8.5.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim
            )
        }

        // Quick Analysis Query Chips
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text(
                text = "SELECT ANALYTICAL INQUIRY:",
                fontSize = 9.5.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextDim
            )
            Spacer(modifier = Modifier.height(6.dp))

            val queries = listOf(
                "What is happening in BTC liquidity?",
                "Why did the spread widen?",
                "Which venues have the deepest books?",
                "What are the largest market risks right now?"
            )

            queries.forEach { q ->
                val isSelected = state.currentAiReport?.query == q
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp)
                        .background(if (isSelected) InstitutionalBlue else BgGraphiteDark, RoundedCornerShape(3.dp))
                        .clickable { viewModel.askAiQuery(q) }
                        .padding(horizontal = 8.dp, vertical = 6.dp)
                        .testTag("ai_query_chip"),
                    contentAlignment = Alignment.CenterStart
                ) {
                    Text(
                        text = "› $q",
                        fontSize = 10.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontFamily = FontFamily.Monospace,
                        color = if (isSelected) BgGraphiteDark else TextPaperWhite
                    )
                }
            }
        }

        // AI Generated Analytical Report Card
        state.currentAiReport?.let { report ->
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BgCardElevated, RoundedCornerShape(4.dp))
                    .padding(8.dp)
            ) {
                Text(
                    text = "EXECUTIVE SUMMARY",
                    fontSize = 9.5.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = InstitutionalBlue
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = report.executiveSummary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Medium,
                    fontFamily = FontFamily.Monospace,
                    color = TextPaperWhite,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = "DETAILED MICROSTRUCTURE FINDINGS",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextMutedGraphite
                )
                Spacer(modifier = Modifier.height(4.dp))
                report.detailedFindings.forEach { finding ->
                    Text(
                        text = "• $finding",
                        fontSize = 9.5.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextPaperWhite,
                        modifier = Modifier.padding(vertical = 1.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BgGraphiteDark, RoundedCornerShape(3.dp))
                        .padding(6.dp)
                ) {
                    Column {
                        Text(
                            text = "MARKET IMPLICATION & EXECUTION ADVICE",
                            fontSize = 8.5.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = BtcGold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = report.marketImplication,
                            fontSize = 9.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextPaperWhite
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Provenance Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0F1722), RoundedCornerShape(3.dp))
                        .border(1.dp, BorderSteel, RoundedCornerShape(3.dp))
                        .padding(6.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "ANALYTICAL PROVENANCE & METHODOLOGY AUDIT",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalGreen
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "CONFIDENCE: ${report.provenance.confidencePercent}%",
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Data Sources: ${report.provenance.dataSources.joinToString(", ")}",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextMutedGraphite
                        )
                        Text(
                            text = "Methodology: ${report.provenance.methodology}",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextMutedGraphite
                        )
                        Text(
                            text = "Model: ${report.provenance.analyticalModel} | Generated: ${timeFormat.format(Date(report.provenance.timestamp))}",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextDim
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Formula: ${report.provenance.calculationFormula}",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            color = InstitutionalBlue
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
