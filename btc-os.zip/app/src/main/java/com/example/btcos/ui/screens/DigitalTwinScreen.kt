package com.example.btcos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btcos.ui.MarketUiState
import com.example.btcos.ui.MarketViewModel
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgGraphiteDark
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.BtcGold
import com.example.ui.theme.InstitutionalBlue
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMutedGraphite
import com.example.ui.theme.TextPaperWhite
import java.util.Locale

@Composable
fun DigitalTwinScreen(
    state: MarketUiState,
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Digital Twin Overview Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "BITCOIN MARKET DIGITAL TWIN",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextMutedGraphite
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "SYNTHETIC COGNITIVE ENVIRONMENT",
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    color = BtcGold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Simulating dynamic interactions between 1,000 synthetic institutional accounts, 20 liquidity providers, 6 global venues, custody MPC vaults, and the Bitcoin network abstraction layer.",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextPaperWhite
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Active Shock Event Indicator
            state.activeShockEvent?.let { shock ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(TerminalRed.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                        .padding(6.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "ACTIVE SHOCK: ${shock.name}",
                                fontSize = 9.5.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = TerminalRed
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            Text(
                                text = "${shock.priceImpactPct}% IMPACT",
                                fontSize = 8.5.sp,
                                fontFamily = FontFamily.Monospace,
                                color = AmberWarning
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = shock.description,
                            fontSize = 8.5.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextMutedGraphite
                        )
                    }
                }
            }
        }

        // Market Shock Injection Panel
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text(
                text = "INJECT TAIL-RISK MARKET SHOCKS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite
            )
            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { viewModel.injectDigitalTwinShock("FLASH_DROP_15") },
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .testTag("shock_flash_drop"),
                    colors = ButtonDefaults.buttonColors(containerColor = TerminalRed),
                    shape = RoundedCornerShape(3.dp)
                ) {
                    Text(text = "FLASH DROP -15%", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                }

                Button(
                    onClick = { viewModel.injectDigitalTwinShock("VENUE_DISCONNECT") },
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .testTag("shock_venue_disconnect"),
                    colors = ButtonDefaults.buttonColors(containerColor = AmberWarning),
                    shape = RoundedCornerShape(3.dp)
                ) {
                    Text(text = "VENUE A OUTAGE", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = BgGraphiteDark)
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { viewModel.injectDigitalTwinShock("MEMPOOL_CONGESTION") },
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .testTag("shock_mempool_spike"),
                    colors = ButtonDefaults.buttonColors(containerColor = BorderSteel),
                    shape = RoundedCornerShape(3.dp)
                ) {
                    Text(text = "MEMPOOL SPIKE", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                }

                Button(
                    onClick = { viewModel.injectDigitalTwinShock("STABLECOIN_DEPEG") },
                    modifier = Modifier
                        .weight(1f)
                        .height(36.dp)
                        .testTag("shock_stablecoin_depeg"),
                    colors = ButtonDefaults.buttonColors(containerColor = BorderSteel),
                    shape = RoundedCornerShape(3.dp)
                ) {
                    Text(text = "USDT DEPEG (-3%)", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                }
            }
        }

        // Performance Benchmark Suite Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "MATCHING ENGINE BENCHMARK SUITE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextMutedGraphite
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "100K+ TARGET",
                    fontSize = 8.5.sp,
                    fontFamily = FontFamily.Monospace,
                    color = InstitutionalBlue
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Button(
                onClick = { viewModel.runPerformanceBenchmark() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .testTag("run_benchmark_button"),
                colors = ButtonDefaults.buttonColors(containerColor = InstitutionalBlue),
                shape = RoundedCornerShape(3.dp)
            ) {
                Text(
                    text = "EXECUTE 1,000-ORDER MATCHING BENCHMARK",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = BgGraphiteDark
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            state.latestBenchmarkResult?.let { bench ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BgGraphiteDark, RoundedCornerShape(3.dp))
                        .padding(6.dp)
                ) {
                    Column {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(text = "ORDERS SUBMITTED", fontSize = 7.5.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                                Text(text = "${bench.totalOrdersSubmitted}", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                            }
                            Column {
                                Text(text = "TRADES GENERATED", fontSize = 7.5.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                                Text(text = "${bench.totalTradesExecuted}", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                            }
                            Column {
                                Text(text = "THROUGHPUT", fontSize = 7.5.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                                Text(text = "${String.format(Locale.US, "%,.0f", bench.ordersPerSecond)} ord/s", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TerminalGreen)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text(text = "LATENCY p50", fontSize = 7.5.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                                Text(text = "${bench.latencyP50Micros} µs", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = InstitutionalBlue)
                            }
                            Column {
                                Text(text = "LATENCY p95", fontSize = 7.5.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                                Text(text = "${bench.latencyP95Micros} µs", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = InstitutionalBlue)
                            }
                            Column {
                                Text(text = "LATENCY p99", fontSize = 7.5.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                                Text(text = "${bench.latencyP99Micros} µs", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = AmberWarning)
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(modifier = Modifier.fillMaxWidth()) {
                            Text(
                                text = "DETERMINISM: ${if (bench.isDeterministic) "VERIFIED" else "FAILED"} | LEDGER BALANCE: ${if (bench.ledgerReconciled) "ZERO-DRIFT" else "MISMATCH"}",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = if (bench.isDeterministic && bench.ledgerReconciled) TerminalGreen else TerminalRed
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
