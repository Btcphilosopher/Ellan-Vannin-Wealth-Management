package com.example.btcos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btcos.core.BitcoinAmount
import com.example.btcos.core.FiatAmount
import com.example.btcos.orderbook.OrderSide
import com.example.btcos.orderbook.OrderType
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgGraphiteDark
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.BtcGold
import com.example.ui.theme.InstitutionalBlue
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMutedGraphite
import com.example.ui.theme.TextPaperWhite

@Composable
fun OrderEntryPad(
    side: OrderSide,
    orderType: OrderType,
    priceText: String,
    quantitySats: Long,
    feedbackText: String?,
    isKillSwitchEngaged: Boolean,
    onSideChanged: (OrderSide) -> Unit,
    onOrderTypeChanged: (OrderType) -> Unit,
    onPriceChanged: (String) -> Unit,
    onQuantityChanged: (Long) -> Unit,
    onSubmitOrder: () -> Unit,
    onToggleKillSwitch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .background(BgCardElevated, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ORDER ENTRY PAD",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite
            )
            Spacer(modifier = Modifier.weight(1f))
            // Emergency Kill switch
            Box(
                modifier = Modifier
                    .background(
                        if (isKillSwitchEngaged) TerminalRed else BorderSteel,
                        RoundedCornerShape(3.dp)
                    )
                    .clickable { onToggleKillSwitch() }
                    .padding(horizontal = 6.dp, vertical = 2.dp)
                    .testTag("kill_switch_button")
            ) {
                Text(
                    text = if (isKillSwitchEngaged) "KILL SWITCH: ACTIVE" else "STOP MARKET",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextPaperWhite
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Side toggle (BUY / SELL)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp)
                    .background(
                        if (side == OrderSide.BUY) TerminalGreen else BgGraphiteDark,
                        RoundedCornerShape(3.dp)
                    )
                    .clickable { onSideChanged(OrderSide.BUY) }
                    .testTag("buy_side_tab"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "BUY BTC",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (side == OrderSide.BUY) BgGraphiteDark else TerminalGreen
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .height(34.dp)
                    .background(
                        if (side == OrderSide.SELL) TerminalRed else BgGraphiteDark,
                        RoundedCornerShape(3.dp)
                    )
                    .clickable { onSideChanged(OrderSide.SELL) }
                    .testTag("sell_side_tab"),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "SELL BTC",
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    color = if (side == OrderSide.SELL) TextPaperWhite else TerminalRed
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Order Type selector row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            listOf(OrderType.LIMIT, OrderType.MARKET, OrderType.POST_ONLY, OrderType.IOC, OrderType.FOK).forEach { type ->
                val isSelected = orderType == type
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(
                            if (isSelected) InstitutionalBlue else BgGraphiteDark,
                            RoundedCornerShape(2.dp)
                        )
                        .clickable { onOrderTypeChanged(type) }
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when (type) {
                            OrderType.POST_ONLY -> "POST"
                            else -> type.name
                        },
                        fontSize = 9.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        fontFamily = FontFamily.Monospace,
                        color = if (isSelected) BgGraphiteDark else TextMutedGraphite
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Price Input
        if (orderType != OrderType.MARKET) {
            Text(
                text = "LIMIT PRICE ($)",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim
            )
            Spacer(modifier = Modifier.height(2.dp))
            OutlinedTextField(
                value = priceText,
                onValueChange = onPriceChanged,
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("price_input"),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = InstitutionalBlue,
                    unfocusedBorderColor = BorderSteel,
                    focusedTextColor = TextPaperWhite,
                    unfocusedTextColor = TextPaperWhite,
                    focusedContainerColor = BgGraphiteDark,
                    unfocusedContainerColor = BgGraphiteDark
                )
            )
            Spacer(modifier = Modifier.height(6.dp))
        }

        // Quantity Presets & Display
        val btcVal = quantitySats.toDouble() / BitcoinAmount.SATS_PER_BTC
        Text(
            text = "ORDER SIZE: $btcVal BTC (${BitcoinAmount(quantitySats).toSatsFormatted()})",
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            color = TextDim
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            listOf(
                Pair("0.1 BTC", 10_000_000L),
                Pair("0.5 BTC", 50_000_000L),
                Pair("1.0 BTC", 100_000_000L),
                Pair("5.0 BTC", 500_000_000L)
            ).forEach { (lbl, sats) ->
                val isSel = quantitySats == sats
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .background(if (isSel) BtcGold else BgGraphiteDark, RoundedCornerShape(2.dp))
                        .clickable { onQuantityChanged(sats) }
                        .padding(vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = lbl,
                        fontSize = 9.sp,
                        fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                        fontFamily = FontFamily.Monospace,
                        color = if (isSel) BgGraphiteDark else TextPaperWhite
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Total Estimate
        val pNum = priceText.toDoubleOrNull() ?: 104250.0
        val estTotal = pNum * btcVal
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "EST. NOTIONAL:",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = String.format("%,.2f USD", estTotal),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextPaperWhite
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Feedback / Warning message
        if (feedbackText != null) {
            Text(
                text = feedbackText,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = if (feedbackText.startsWith("REJECT")) TerminalRed else InstitutionalBlue,
                modifier = Modifier.padding(bottom = 6.dp)
            )
        }

        // Submit Button
        Button(
            onClick = onSubmitOrder,
            modifier = Modifier
                .fillMaxWidth()
                .height(40.dp)
                .testTag("submit_order_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (side == OrderSide.BUY) TerminalGreen else TerminalRed
            ),
            shape = RoundedCornerShape(3.dp),
            enabled = !isKillSwitchEngaged
        ) {
            Text(
                text = if (isKillSwitchEngaged) "MARKET HALTED" else "SUBMIT ${side.name} ORDER",
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                color = if (side == OrderSide.BUY) BgGraphiteDark else TextPaperWhite
            )
        }
    }
}
