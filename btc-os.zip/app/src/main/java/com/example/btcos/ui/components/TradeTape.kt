package com.example.btcos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btcos.core.BitcoinAmount
import com.example.btcos.orderbook.Trade
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMutedGraphite
import com.example.ui.theme.TextPaperWhite
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun TradeTape(
    trades: List<Trade>,
    modifier: Modifier = Modifier
) {
    val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    Column(
        modifier = modifier
            .background(BgCardElevated, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "TRADE TAPE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "${trades.size} TRADES",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Table header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 2.dp)
        ) {
            Text(
                text = "TIME",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim,
                modifier = Modifier.weight(0.9f)
            )
            Text(
                text = "PRICE",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim,
                modifier = Modifier.weight(1.2f)
            )
            Text(
                text = "SIZE (BTC)",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "VENUE",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.9f)
            )
        }

        if (trades.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Awaiting executions...",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextDim
                )
            }
        } else {
            trades.take(15).forEach { trade ->
                val timeStr = timeFormat.format(Date(trade.timestamp))
                val isBuy = trade.isTakerBuyer
                val color = if (isBuy) TerminalGreen else TerminalRed

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 1.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = timeStr,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextDim,
                        modifier = Modifier.weight(0.9f)
                    )
                    Text(
                        text = String.format(Locale.US, "%,.2f", trade.priceCents / 100.0),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Medium,
                        fontFamily = FontFamily.Monospace,
                        color = color,
                        modifier = Modifier.weight(1.2f)
                    )
                    Text(
                        text = String.format(Locale.US, "%.4f", trade.quantitySats.toDouble() / BitcoinAmount.SATS_PER_BTC),
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextPaperWhite,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = trade.venueId.takeLast(4),
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextMutedGraphite,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(0.9f)
                    )
                }
            }
        }
    }
}
