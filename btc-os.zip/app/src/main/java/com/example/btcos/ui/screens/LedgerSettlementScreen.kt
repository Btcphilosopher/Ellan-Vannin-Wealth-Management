package com.example.btcos.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btcos.core.BitcoinAmount
import com.example.btcos.core.FiatAmount
import com.example.btcos.ledger.EntryDirection
import com.example.btcos.ui.MarketUiState
import com.example.btcos.ui.MarketViewModel
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BgGraphiteDark
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.BtcGold
import com.example.ui.theme.InstitutionalBlue
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMutedGraphite
import com.example.ui.theme.TextPaperWhite

@Composable
fun LedgerSettlementScreen(
    state: MarketUiState,
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Continuous Ledger Invariant Verification Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(if (state.ledgerInvariantValid) TerminalGreen.copy(alpha = 0.15f) else TerminalRed.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
                .border(1.dp, if (state.ledgerInvariantValid) TerminalGreen else TerminalRed, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "DOUBLE-ENTRY LEDGER INVARIANT: VERIFIED",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (state.ledgerInvariantValid) TerminalGreen else TerminalRed
                    )
                    Text(
                        text = "Total Debits ≡ Total Credits across 100% of journal postings. Zero balance drift.",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextMutedGraphite
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                Box(
                    modifier = Modifier
                        .background(TerminalGreen, RoundedCornerShape(2.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "0 DRIFT",
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = BgGraphiteDark
                    )
                }
            }
        }

        // 5-Way Continuous Reconciliation Matrix Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text(
                text = "5-WAY INSTITUTIONAL RECONCILIATION MATRIX",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite
            )
            Spacer(modifier = Modifier.height(6.dp))

            state.reconciliationMatrix?.let { rec ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(BgGraphiteDark, RoundedCornerShape(3.dp))
                        .padding(6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "TRADING SYS", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                        Text(text = "${BitcoinAmount(rec.tradingBalanceSats).toBtcString(2)}", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                    }
                    Text(text = "≡", fontSize = 12.sp, color = TerminalGreen)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "LEDGER", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                        Text(text = "${BitcoinAmount(rec.ledgerBalanceSats).toBtcString(2)}", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                    }
                    Text(text = "≡", fontSize = 12.sp, color = TerminalGreen)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "CUSTODY VAULT", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                        Text(text = "${BitcoinAmount(rec.custodyVaultSats).toBtcString(2)}", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                    }
                    Text(text = "≡", fontSize = 12.sp, color = TerminalGreen)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(text = "ON-CHAIN UTXO", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = TextDim)
                        Text(text = "${BitcoinAmount(rec.blockchainUtxoSats).toBtcString(2)}", fontSize = 9.5.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                    }
                }
            }
        }

        // Segregated Account Balances Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text(
                text = "SEGREGATED CLIENT & PLATFORM ACCOUNTS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite
            )
            Spacer(modifier = Modifier.height(6.dp))

            state.accounts.forEach { acc ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.4f)) {
                        Text(
                            text = acc.name,
                            fontSize = 9.5.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace,
                            color = TextPaperWhite
                        )
                        Text(
                            text = "${acc.category.name} • ${acc.accountId}",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            color = TextDim
                        )
                    }
                    Text(
                        text = if (acc.currency == "BTC") acc.btcAmount.toBtcString(4) else acc.fiatAmount.formatted(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = if (acc.currency == "BTC") BtcGold else InstitutionalBlue,
                        textAlign = TextAlign.End,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // Bitcoin Network Abstraction & UTXO Settlement Card
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "BITCOIN NETWORK & UTXO SETTLEMENT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextMutedGraphite
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = "BLOCK 892,140+",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = BtcGold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Action buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Button(
                    onClick = { viewModel.mineBitcoinBlock() },
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .testTag("mine_block_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = InstitutionalBlue),
                    shape = RoundedCornerShape(3.dp)
                ) {
                    Text(text = "MINE BLOCK", fontSize = 10.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = BgGraphiteDark)
                }

                Button(
                    onClick = { viewModel.simulateReorg() },
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                        .testTag("simulate_reorg_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = BorderSteel),
                    shape = RoundedCornerShape(3.dp)
                ) {
                    Text(text = "SIMULATE 1-BLOCK REORG", fontSize = 9.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, color = TextPaperWhite)
                }
            }
        }

        // Double-Entry Journal Entries
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(BgCardElevated, RoundedCornerShape(4.dp))
                .padding(8.dp)
        ) {
            Text(
                text = "DOUBLE-ENTRY JOURNAL AUDIT LOG",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite
            )
            Spacer(modifier = Modifier.height(6.dp))

            if (state.journal.isEmpty()) {
                Text(
                    text = "No recent journal entries.",
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace,
                    color = TextDim
                )
            } else {
                state.journal.take(6).forEach { j ->
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                            .background(BgGraphiteDark, RoundedCornerShape(2.dp))
                            .padding(5.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = j.entryId,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    color = InstitutionalBlue
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = j.description,
                                    fontSize = 8.5.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = TextPaperWhite
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            j.postings.forEach { p ->
                                val dirColor = if (p.direction == EntryDirection.DEBIT) TerminalGreen else TerminalRed
                                val amtStr = if (p.amountSats > 0) BitcoinAmount(p.amountSats).toBtcString(4) else FiatAmount(p.amountCents).formatted()
                                Text(
                                    text = "  ${p.direction.name}: ${p.accountId.takeLast(14)} → $amtStr",
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = dirColor
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}
