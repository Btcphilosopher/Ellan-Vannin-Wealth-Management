package com.example.btcos.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btcos.core.FiatAmount
import com.example.btcos.ui.Candle
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.InstitutionalBlue
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMutedGraphite
import com.example.ui.theme.TextPaperWhite

@Composable
fun TerminalPriceChart(
    candles: List<Candle>,
    modifier: Modifier = Modifier
) {
    if (candles.isEmpty()) return

    val minPrice = candles.minOf { it.lowCents }
    val maxPrice = candles.maxOf { it.highCents }
    val priceRange = (maxPrice - minPrice).coerceAtLeast(100L)
    val maxVol = candles.maxOf { it.volumeSats }.coerceAtLeast(1L)

    Column(
        modifier = modifier
            .background(BgCardElevated, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        // Chart header with high, low, VWAP
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "1M CANDLESTICK • VWAP OVERLAY",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "H: ${FiatAmount(maxPrice).formatted()}",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = TerminalGreen
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "L: ${FiatAmount(minPrice).formatted()}",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = TerminalRed
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val chartHeight = h * 0.75f
                val volHeight = h * 0.22f
                val volTop = h - volHeight

                // Draw horizontal grid lines
                val gridLines = 4
                for (i in 0..gridLines) {
                    val y = (chartHeight / gridLines) * i
                    drawLine(
                        color = BorderSteel.copy(alpha = 0.5f),
                        start = Offset(0f, y),
                        end = Offset(w, y),
                        strokeWidth = 1f
                    )
                }

                val candleCount = candles.size
                val candleWidth = (w / candleCount) * 0.70f
                val step = w / candleCount

                val vwapPath = Path()
                var cumulativePriceVol = 0.0
                var cumulativeVol = 0.0

                candles.forEachIndexed { idx, c ->
                    val xCenter = (idx * step) + (step / 2f)
                    val isBull = c.closeCents >= c.openCents
                    val candleColor = if (isBull) TerminalGreen else TerminalRed

                    // Normalise Y coordinates
                    val highY = chartHeight - ((c.highCents - minPrice).toFloat() / priceRange * chartHeight)
                    val lowY = chartHeight - ((c.lowCents - minPrice).toFloat() / priceRange * chartHeight)
                    val openY = chartHeight - ((c.openCents - minPrice).toFloat() / priceRange * chartHeight)
                    val closeY = chartHeight - ((c.closeCents - minPrice).toFloat() / priceRange * chartHeight)

                    // Draw High/Low wick
                    drawLine(
                        color = candleColor,
                        start = Offset(xCenter, highY),
                        end = Offset(xCenter, lowY),
                        strokeWidth = 1.5f
                    )

                    // Draw Candle body
                    val bodyTop = Math.min(openY, closeY)
                    val bodyHeight = Math.max(Math.abs(closeY - openY), 2f)
                    drawRect(
                        color = candleColor,
                        topLeft = Offset(xCenter - (candleWidth / 2f), bodyTop),
                        size = Size(candleWidth, bodyHeight)
                    )

                    // Draw Volume bar
                    val vBarHeight = (c.volumeSats.toFloat() / maxVol) * volHeight
                    drawRect(
                        color = candleColor.copy(alpha = 0.35f),
                        topLeft = Offset(xCenter - (candleWidth / 2f), h - vBarHeight),
                        size = Size(candleWidth, vBarHeight)
                    )

                    // VWAP calculation
                    val typicalPrice = (c.highCents + c.lowCents + c.closeCents) / 3.0
                    cumulativePriceVol += typicalPrice * c.volumeSats
                    cumulativeVol += c.volumeSats
                    val currentVwap = if (cumulativeVol > 0) cumulativePriceVol / cumulativeVol else typicalPrice
                    val vwapY = chartHeight - ((currentVwap - minPrice).toFloat() / priceRange * chartHeight)

                    if (idx == 0) {
                        vwapPath.moveTo(xCenter, vwapY)
                    } else {
                        vwapPath.lineTo(xCenter, vwapY)
                    }
                }

                // Draw VWAP line
                drawPath(
                    path = vwapPath,
                    color = InstitutionalBlue,
                    style = Stroke(width = 1.8f)
                )
            }
        }
    }
}
