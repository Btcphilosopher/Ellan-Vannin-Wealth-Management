package com.example.btcos.orderbook

import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentSkipListMap

/**
 * Institutional Central Limit Order Book (CLOB).
 * Price-Time priority matching structure.
 */
class CentralLimitOrderBook(
    val instrumentId: String,
    val venueId: String = "VENUE_INTERNAL"
) {
    // Bid Comparator: Price DESC, then Timestamp ASC, then Seq ASC
    private val bidComparator = Comparator<Order> { o1, o2 ->
        val priceComp = o2.priceCents.compareTo(o1.priceCents)
        if (priceComp != 0) priceComp
        else {
            val timeComp = o1.timestamp.compareTo(o2.timestamp)
            if (timeComp != 0) timeComp else o1.sequenceNumber.compareTo(o2.sequenceNumber)
        }
    }

    // Ask Comparator: Price ASC, then Timestamp ASC, then Seq ASC
    private val askComparator = Comparator<Order> { o1, o2 ->
        val priceComp = o1.priceCents.compareTo(o2.priceCents)
        if (priceComp != 0) priceComp
        else {
            val timeComp = o1.timestamp.compareTo(o2.timestamp)
            if (timeComp != 0) timeComp else o1.sequenceNumber.compareTo(o2.sequenceNumber)
        }
    }

    private val bids = ArrayList<Order>()
    private val asks = ArrayList<Order>()
    private val orderIndex = HashMap<String, Order>()
    private val lock = Any()

    fun addOrder(order: Order) {
        synchronized(lock) {
            orderIndex[order.orderId] = order
            if (order.side == OrderSide.BUY) {
                bids.add(order)
                bids.sortWith(bidComparator)
            } else {
                asks.add(order)
                asks.sortWith(askComparator)
            }
        }
    }

    fun removeOrder(orderId: String): Order? {
        synchronized(lock) {
            val existing = orderIndex.remove(orderId) ?: return null
            if (existing.side == OrderSide.BUY) {
                bids.removeAll { it.orderId == orderId }
            } else {
                asks.removeAll { it.orderId == orderId }
            }
            return existing
        }
    }

    fun updateOrder(order: Order) {
        synchronized(lock) {
            if (order.remainingQuantitySats <= 0L) {
                removeOrder(order.orderId)
            } else {
                orderIndex[order.orderId] = order
                if (order.side == OrderSide.BUY) {
                    val idx = bids.indexOfFirst { it.orderId == order.orderId }
                    if (idx >= 0) bids[idx] = order else bids.add(order)
                    bids.sortWith(bidComparator)
                } else {
                    val idx = asks.indexOfFirst { it.orderId == order.orderId }
                    if (idx >= 0) asks[idx] = order else asks.add(order)
                    asks.sortWith(askComparator)
                }
            }
        }
    }

    fun getOrder(orderId: String): Order? = synchronized(lock) { orderIndex[orderId] }

    fun getBestBid(): Order? = synchronized(lock) { bids.firstOrNull() }
    fun getBestAsk(): Order? = synchronized(lock) { asks.firstOrNull() }

    fun getBidsSnapshot(): List<Order> = synchronized(lock) { ArrayList(bids) }
    fun getAsksSnapshot(): List<Order> = synchronized(lock) { ArrayList(asks) }

    fun generateSnapshot(levels: Int = 10, sequenceNumber: Long = 0L): OrderBookSnapshot {
        synchronized(lock) {
            val aggregatedBids = aggregateLevels(bids, levels)
            val aggregatedAsks = aggregateLevels(asks, levels)

            val bestBid = aggregatedBids.firstOrNull()?.priceCents
            val bestAsk = aggregatedAsks.firstOrNull()?.priceCents

            val mid = if (bestBid != null && bestAsk != null) (bestBid + bestAsk) / 2 else bestBid ?: bestAsk
            val spread = if (bestBid != null && bestAsk != null) bestAsk - bestBid else null
            val spreadBps = if (spread != null && mid != null && mid > 0) {
                (spread.toDouble() / mid.toDouble()) * 10_000.0
            } else null

            val totalBidSats = aggregatedBids.sumOf { it.quantitySats }
            val totalAskSats = aggregatedAsks.sumOf { it.quantitySats }
            val totalVol = totalBidSats + totalAskSats
            val obi = if (totalVol > 0) {
                (totalBidSats - totalAskSats).toDouble() / totalVol.toDouble()
            } else 0.0

            return OrderBookSnapshot(
                instrumentId = instrumentId,
                venueId = venueId,
                timestamp = System.currentTimeMillis(),
                sequenceNumber = sequenceNumber,
                bids = aggregatedBids,
                asks = aggregatedAsks,
                bestBidCents = bestBid,
                bestAskCents = bestAsk,
                midPriceCents = mid,
                spreadCents = spread,
                spreadBps = spreadBps,
                orderBookImbalance = obi
            )
        }
    }

    private fun aggregateLevels(orders: List<Order>, maxLevels: Int): List<BookLevel> {
        val levelMap = LinkedHashMap<Long, Pair<Long, Int>>() // Price -> (Quantity, Count)
        for (order in orders) {
            val current = levelMap.getOrDefault(order.priceCents, Pair(0L, 0))
            levelMap[order.priceCents] = Pair(current.first + order.remainingQuantitySats, current.second + 1)
        }

        var runningCumSats = 0L
        val topLevels = levelMap.entries.take(maxLevels)
        val totalSatsInView = topLevels.sumOf { it.value.first }

        return topLevels.map { (price, stats) ->
            runningCumSats += stats.first
            val depthPct = if (totalSatsInView > 0) stats.first.toDouble() / totalSatsInView.toDouble() else 0.0
            BookLevel(
                priceCents = price,
                quantitySats = stats.first,
                orderCount = stats.second,
                cumulativeSats = runningCumSats,
                depthPercent = depthPct
            )
        }
    }

    fun clear() {
        synchronized(lock) {
            bids.clear()
            asks.clear()
            orderIndex.clear()
        }
    }
}
