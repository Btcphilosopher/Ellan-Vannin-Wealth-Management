package com.example.btcos.market

import com.example.btcos.core.BitcoinAmount
import com.example.btcos.core.FiatAmount
import com.example.btcos.core.Jurisdiction

enum class TradingStatus {
    PRE_OPEN,
    OPEN,
    HALTED,
    POST_ONLY,
    CLOSED,
    MAINTENANCE
}

data class Instrument(
    val id: String,
    val baseAsset: String = "BTC",
    val quoteAsset: String,
    val tickSizeCents: Long = 100L, // $1.00 tick size
    val lotSizeSats: Long = 10_000L, // 0.0001 BTC minimum lot
    val minOrderSats: Long = 10_000L,
    val maxOrderSats: Long = 10_000_000_000L, // 100 BTC max single order
    val status: TradingStatus = TradingStatus.OPEN,
    val settlementAsset: String = "BTC",
    val jurisdiction: Jurisdiction = Jurisdiction.UK_FCA
)

data class Venue(
    val id: String,
    val name: String,
    val jurisdiction: Jurisdiction,
    val status: TradingStatus = TradingStatus.OPEN,
    val feeBpsMaker: Double = 2.0, // 2 bps maker fee
    val feeBpsTaker: Double = 5.0, // 5 bps taker fee
    val latencyMs: Long = 4L,
    val liquidityProfile: String = "Institutional Tier-1",
    val custodyModel: String = "Segregated MPC / Cold Vault"
)

object MarketMaster {
    val VENUES = listOf(
        Venue("VENUE_INTERNAL", "Internal Market (BTC-OS)", Jurisdiction.UK_FCA, feeBpsMaker = 1.0, feeBpsTaker = 3.5, latencyMs = 1),
        Venue("VENUE_LSE_LND", "Venue A (London Institutional)", Jurisdiction.UK_FCA, feeBpsMaker = 2.0, feeBpsTaker = 5.0, latencyMs = 4),
        Venue("VENUE_TYO_ECN", "Venue B (Tokyo ECN)", Jurisdiction.JP_JFSA, feeBpsMaker = 2.5, feeBpsTaker = 6.0, latencyMs = 12),
        Venue("VENUE_NYC_PTS", "Venue C (New York PTS)", Jurisdiction.US_SEC_CFTC, feeBpsMaker = 2.0, feeBpsTaker = 4.5, latencyMs = 8),
        Venue("VENUE_FRA_BSE", "Venue D (Frankfurt Digital)", Jurisdiction.EU_MICA, feeBpsMaker = 1.8, feeBpsTaker = 4.8, latencyMs = 6),
        Venue("VENUE_SYNTH", "Synthetic Market Maker", Jurisdiction.GLOBAL_SIMULATION, feeBpsMaker = 0.0, feeBpsTaker = 2.0, latencyMs = 2)
    )

    val INSTRUMENTS = listOf(
        Instrument("BTC/USD", "BTC", "USD", tickSizeCents = 100L, lotSizeSats = 10_000L, jurisdiction = Jurisdiction.UK_FCA),
        Instrument("BTC/EUR", "BTC", "EUR", tickSizeCents = 100L, lotSizeSats = 10_000L, jurisdiction = Jurisdiction.EU_MICA),
        Instrument("BTC/GBP", "BTC", "GBP", tickSizeCents = 100L, lotSizeSats = 10_000L, jurisdiction = Jurisdiction.UK_FCA),
        Instrument("BTC/JPY", "BTC", "JPY", tickSizeCents = 1000L, lotSizeSats = 10_000L, jurisdiction = Jurisdiction.JP_JFSA),
        Instrument("BTC/CNH", "BTC", "CNH", tickSizeCents = 100L, lotSizeSats = 10_000L, jurisdiction = Jurisdiction.GLOBAL_SIMULATION),
        Instrument("BTC/USDT", "BTC", "USDT", tickSizeCents = 100L, lotSizeSats = 10_000L, jurisdiction = Jurisdiction.GLOBAL_SIMULATION),
        Instrument("BTC/USDC", "BTC", "USDC", tickSizeCents = 100L, lotSizeSats = 10_000L, jurisdiction = Jurisdiction.GLOBAL_SIMULATION)
    )

    fun findInstrument(id: String): Instrument =
        INSTRUMENTS.find { it.id == id } ?: INSTRUMENTS.first()

    fun findVenue(id: String): Venue =
        VENUES.find { it.id == id } ?: VENUES.first()
}
