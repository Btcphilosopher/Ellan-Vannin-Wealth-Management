package com.example.btcos.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.btcos.core.FiatAmount
import com.example.btcos.orderbook.BookLevel
import com.example.btcos.orderbook.OrderBookSnapshot
import com.example.ui.theme.BgCardElevated
import com.example.ui.theme.BorderSteel
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.InstitutionalBlue
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TerminalGreenBg
import com.example.ui.theme.TerminalRed
import com.example.ui.theme.TerminalRedBg
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMutedGraphite
import com.example.ui.theme.TextPaperWhite
import java.util.Locale

@Composable
fun OrderBookLadder(
    snapshot: OrderBookSnapshot?,
    modifier: Modifier = Modifier
) {
    if (snapshot == null) return

    Column(
        modifier = modifier
            .background(BgCardElevated, RoundedCornerShape(4.dp))
            .padding(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "L2 ORDER BOOK",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite
            )
            Spacer(modifier = Modifier.weight(1f))
            Text(
                text = "SEQ #${snapshot.sequenceNumber}",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Table header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 2.dp)
        ) {
            Text(
                text = "PRICE (${snapshot.instrumentId.substringAfter('/')})",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim,
                modifier = Modifier.weight(1.2f)
            )
            Text(
                text = "SIZE (BTC)",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = "CUMULATIVE",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = TextDim,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(1f)
            )
        }

        val topAsks = snapshot.asks.take(5).reversed() // Display top 5 asks descending towards mid
        val topBids = snapshot.bids.take(5)

        val maxCumulative = Math.max(
            topAsks.maxOfOrNull { it.cumulativeBtc } ?: 1.0,
            topBids.maxOfOrNull { it.cumulativeBtc } ?: 1.0
        ).coerceAtLeast(0.1)

        // Asks list (Red)
        topAsks.forEach { ask ->
            OrderBookRow(
                level = ask,
                isBid = false,
                maxCumulative = maxCumulative
            )
        }

        // Mid Price & Spread Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .background(BorderSteel, RoundedCornerShape(2.dp))
                .padding(horizontal = 6.dp, vertical = 3.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val midStr = snapshot.midPriceCents?.let { FiatAmount(it).formatted() } ?: "---"
                Text(
                    text = "MID $midStr",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = TextPaperWhite
                )
                Spacer(modifier = Modifier.weight(1f))
                val spreadStr = snapshot.spreadCents?.let { FiatAmount(it).formatted() } ?: "0"
                val bpsStr = snapshot.spreadBps?.let { String.format(Locale.US, "%.1f bps", it) } ?: "0 bps"
                Text(
                    text = "Spread: $spreadStr ($bpsStr)",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = InstitutionalBlue
                )
            }
        }

        // Bids list (Green)
        topBids.forEach { bid ->
            OrderBookRow(
                level = bid,
                isBid = true,
                maxCumulative = maxCumulative
            )
        }
    }
}

@Composable
private fun OrderBookRow(
    level: BookLevel,
    isBid: Boolean,
    maxCumulative: Double
) {
    val fraction = (level.cumulativeBtc / maxCumulative).coerceIn(0.0, 1.0).toFloat()
    val barColor = if (isBid) TerminalGreenBg else TerminalRedBg
    val textColor = if (isBid) TerminalGreen else TerminalRed

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(20.dp)
            .padding(vertical = 1.dp)
    ) {
        // Depth background bar
        Box(
            modifier = Modifier
                .fillMaxHeight()
                .fillMaxWidth(fraction)
                .align(Alignment.CenterEnd)
                .background(barColor)
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = String.format(Locale.US, "%,.2f", level.priceCents / 100.0),
                fontSize = 10.sp,
                fontWeight = FontWeight.Medium,
                fontFamily = FontFamily.Monospace,
                color = textColor,
                modifier = Modifier.weight(1.2f)
            )
            Text(
                text = String.format(Locale.US, "%.4f", level.btcQuantity),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = TextPaperWhite,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(1f)
            )
            Text(
                text = String.format(Locale.US, "%.4f", level.cumulativeBtc),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = TextMutedGraphite,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(1f)
            )
        }
    }
}
