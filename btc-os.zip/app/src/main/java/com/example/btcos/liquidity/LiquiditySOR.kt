package com.example.btcos.liquidity

import com.example.btcos.core.BitcoinAmount
import com.example.btcos.core.FiatAmount
import com.example.btcos.market.MarketMaster
import com.example.btcos.orderbook.BookLevel
import com.example.btcos.orderbook.OrderSide

enum class RoutingStrategy(val label: String, val description: String) {
    MULTI_VENUE("Multi-Venue SOR", "Optimal depth allocation minimizing market impact and fees"),
    SINGLE_VENUE("Single Venue Primary", "Direct routing to internal institutional matching engine"),
    VWAP("VWAP Execution", "Volume-Weighted Average Price algorithmic slicing"),
    TWAP("TWAP Execution", "Time-Weighted Average Price uniform interval schedule"),
    LIQUIDITY_SEEKING("Liquidity Seeking", "Aggressive sweeps targeting dark/resting liquidity"),
    PASSIVE("Passive Pegged", "Post-only maker orders capturing spread rebates")
}

data class VenueQuote(
    val venueId: String,
    val venueName: String,
    val bidPriceCents: Long,
    val bidQtySats: Long,
    val askPriceCents: Long,
    val askQtySats: Long,
    val spreadBps: Double,
    val latencyMs: Long,
    val feeBpsTaker: Double,
    val isOnline: Boolean = true
)

data class RouteSlice(
    val venueId: String,
    val venueName: String,
    val allocatedSats: Long,
    val targetPriceCents: Long,
    val estimatedFeeCents: Long,
    val weightPercent: Double
)

data class SorExecutionPlan(
    val strategy: RoutingStrategy,
    val side: OrderSide,
    val totalSats: Long,
    val arrivalPriceCents: Long,
    val estimatedFillPriceCents: Long,
    val slices: List<RouteSlice>,
    val estimatedSlippageBps: Double,
    val estimatedTotalFeesCents: Long
)

data class TcaAnalysis(
    val parentOrderId: String,
    val arrivalPriceCents: Long,
    val executionPriceCents: Long,
    val implementationShortfallBps: Double,
    val spreadCostBps: Double,
    val marketImpactBps: Double,
    val feeCostBps: Double,
    val totalCostCents: Long
)

data class ArbitrageOpportunity(
    val venueBuyId: String,
    val venueBuyName: String,
    val buyPriceCents: Long,
    val venueSellId: String,
    val venueSellName: String,
    val sellPriceCents: Long,
    val grossSpreadCents: Long,
    val grossSpreadBps: Double,
    val totalEstimatedFeeBps: Double,
    val netSpreadBps: Double,
    val maxAvailableSats: Long,
    val isExecutable: Boolean
)

data class BtcCnhPricing(
    val btcUsdPriceCents: Long,
    val usdCnhRate: Double,
    val theoreticalBtcCnhCents: Long,
    val observedBtcCnhCents: Long,
    val basisDeviationBps: Double
)

class LiquidityAggregator {
    // Current quotes across venues
    val quotes = mutableMapOf<String, VenueQuote>()

    init {
        refreshQuotes(baseMidCents = 104_250_00L)
    }

    fun refreshQuotes(baseMidCents: Long) {
        val spreads = mapOf(
            "VENUE_INTERNAL" to Pair(-10_00L, 10_00L), // $104,240 / $104,260 (20 spread)
            "VENUE_LSE_LND" to Pair(-15_00L, 15_00L),
            "VENUE_TYO_ECN" to Pair(-25_00L, 22_00L),
            "VENUE_NYC_PTS" to Pair(-12_00L, 14_00L),
            "VENUE_FRA_BSE" to Pair(-18_00L, 20_00L),
            "VENUE_SYNTH" to Pair(-30_00L, 30_00L)
        )

        for (v in MarketMaster.VENUES) {
            val offset = spreads[v.id] ?: Pair(-20_00L, 20_00L)
            val bid = baseMidCents + offset.first
            val ask = baseMidCents + offset.second
            val spread = ask - bid
            val spreadBps = (spread.toDouble() / baseMidCents.toDouble()) * 10_000.0

            quotes[v.id] = VenueQuote(
                venueId = v.id,
                venueName = v.name,
                bidPriceCents = bid,
                bidQtySats = (250_000_000L..800_000_000L).random(), // 2.5 - 8.0 BTC
                askPriceCents = ask,
                askQtySats = (200_000_000L..750_000_000L).random(),
                spreadBps = spreadBps,
                latencyMs = v.latencyMs,
                feeBpsTaker = v.feeBpsTaker,
                isOnline = v.status == com.example.btcos.market.TradingStatus.OPEN
            )
        }
    }

    /**
     * Smart Order Routing (SOR) algorithm.
     * Computes optimal venue allocation minimizing slippage and fees.
     */
    fun computeSorPlan(
        side: OrderSide,
        totalSats: Long,
        strategy: RoutingStrategy,
        currentMidCents: Long
    ): SorExecutionPlan {
        val availableVenues = quotes.values.filter { it.isOnline }
        if (availableVenues.isEmpty()) {
            return SorExecutionPlan(strategy, side, totalSats, currentMidCents, currentMidCents, emptyList(), 0.0, 0L)
        }

        if (strategy == RoutingStrategy.SINGLE_VENUE) {
            val internal = quotes["VENUE_INTERNAL"] ?: availableVenues.first()
            val fillPrice = if (side == OrderSide.BUY) internal.askPriceCents else internal.bidPriceCents
            val feeCents = Math.round((fillPrice.toDouble() * totalSats / BitcoinAmount.SATS_PER_BTC) * (internal.feeBpsTaker / 10_000.0))
            return SorExecutionPlan(
                strategy = strategy,
                side = side,
                totalSats = totalSats,
                arrivalPriceCents = currentMidCents,
                estimatedFillPriceCents = fillPrice,
                slices = listOf(RouteSlice(internal.venueId, internal.venueName, totalSats, fillPrice, feeCents, 100.0)),
                estimatedSlippageBps = Math.abs(fillPrice - currentMidCents).toDouble() / currentMidCents.toDouble() * 10_000.0,
                estimatedTotalFeesCents = feeCents
            )
        }

        // Multi-venue liquidity-weighted routing
        val sortedVenues = if (side == OrderSide.BUY) {
            availableVenues.sortedWith(compareBy({ it.askPriceCents }, { it.feeBpsTaker }))
        } else {
            availableVenues.sortedWith(compareByDescending<VenueQuote> { it.bidPriceCents }.thenBy { it.feeBpsTaker })
        }

        var remainingSats = totalSats
        val slices = mutableListOf<RouteSlice>()
        var weightedSumPrice = 0.0
        var totalFeesCents = 0L

        for (vq in sortedVenues) {
            if (remainingSats <= 0L) break
            val venueCap = if (side == OrderSide.BUY) vq.askQtySats else vq.bidQtySats
            val allocSats = Math.min(remainingSats, (venueCap * 0.75).toLong().coerceAtLeast(10_000_000L))
            val targetPrice = if (side == OrderSide.BUY) vq.askPriceCents else vq.bidPriceCents
            val sliceQuoteVal = (targetPrice.toDouble() * allocSats) / BitcoinAmount.SATS_PER_BTC
            val feeCents = Math.round(sliceQuoteVal * (vq.feeBpsTaker / 10_000.0))

            slices.add(
                RouteSlice(
                    venueId = vq.venueId,
                    venueName = vq.venueName,
                    allocatedSats = allocSats,
                    targetPriceCents = targetPrice,
                    estimatedFeeCents = feeCents,
                    weightPercent = (allocSats.toDouble() / totalSats.toDouble()) * 100.0
                )
            )

            weightedSumPrice += targetPrice * (allocSats.toDouble() / totalSats.toDouble())
            totalFeesCents += feeCents
            remainingSats -= allocSats
        }

        // If any remaining, allocate to first venue
        if (remainingSats > 0 && slices.isNotEmpty()) {
            val first = slices[0]
            val extraQuote = (first.targetPriceCents.toDouble() * remainingSats) / BitcoinAmount.SATS_PER_BTC
            val extraFee = Math.round(extraQuote * 0.0004)
            slices[0] = first.copy(
                allocatedSats = first.allocatedSats + remainingSats,
                estimatedFeeCents = first.estimatedFeeCents + extraFee,
                weightPercent = ((first.allocatedSats + remainingSats).toDouble() / totalSats.toDouble()) * 100.0
            )
            weightedSumPrice += first.targetPriceCents * (remainingSats.toDouble() / totalSats.toDouble())
            totalFeesCents += extraFee
        }

        val estimatedAvgPrice = Math.round(weightedSumPrice)
        val slippageBps = (Math.abs(estimatedAvgPrice - currentMidCents).toDouble() / currentMidCents.toDouble()) * 10_000.0

        return SorExecutionPlan(
            strategy = strategy,
            side = side,
            totalSats = totalSats,
            arrivalPriceCents = currentMidCents,
            estimatedFillPriceCents = estimatedAvgPrice,
            slices = slices,
            estimatedSlippageBps = slippageBps,
            estimatedTotalFeesCents = totalFeesCents
        )
    }

    /**
     * Cross-Venue Arbitrage Scanner
     */
    fun findArbitrageOpportunities(): List<ArbitrageOpportunity> {
        val list = mutableListOf<ArbitrageOpportunity>()
        val vList = quotes.values.filter { it.isOnline }.toList()

        for (i in vList.indices) {
            for (j in vList.indices) {
                if (i == j) continue
                val buyVenue = vList[i]
                val sellVenue = vList[j]

                // Can we buy at buyVenue.askPriceCents and sell at sellVenue.bidPriceCents?
                if (sellVenue.bidPriceCents > buyVenue.askPriceCents) {
                    val grossDiffCents = sellVenue.bidPriceCents - buyVenue.askPriceCents
                    val grossBps = (grossDiffCents.toDouble() / buyVenue.askPriceCents.toDouble()) * 10_000.0
                    val totalFeeBps = buyVenue.feeBpsTaker + sellVenue.feeBpsTaker
                    val netBps = grossBps - totalFeeBps
                    val maxQty = Math.min(buyVenue.askQtySats, sellVenue.bidQtySats)

                    list.add(
                        ArbitrageOpportunity(
                            venueBuyId = buyVenue.venueId,
                            venueBuyName = buyVenue.venueName,
                            buyPriceCents = buyVenue.askPriceCents,
                            venueSellId = sellVenue.venueId,
                            venueSellName = sellVenue.venueName,
                            sellPriceCents = sellVenue.bidPriceCents,
                            grossSpreadCents = grossDiffCents,
                            grossSpreadBps = grossBps,
                            totalEstimatedFeeBps = totalFeeBps,
                            netSpreadBps = netBps,
                            maxAvailableSats = maxQty,
                            isExecutable = netBps > 0.5
                        )
                    )
                }
            }
        }
        return list.sortedByDescending { it.netSpreadBps }
    }

    /**
     * BTC/CNH Theoretical vs Observed Model
     */
    fun computeBtcCnhPricing(btcUsdPriceCents: Long): BtcCnhPricing {
        val usdCnhRate = 7.2415 // USD/CNH FX spot
        val theoreticalCnhCents = Math.round(btcUsdPriceCents * usdCnhRate)
        // Add realistic offshore market basis (+18 bps offshore premium)
        val observedCnhCents = theoreticalCnhCents + 13_500_00L
        val basisBps = ((observedCnhCents - theoreticalCnhCents).toDouble() / theoreticalCnhCents.toDouble()) * 10_000.0
        return BtcCnhPricing(
            btcUsdPriceCents = btcUsdPriceCents,
            usdCnhRate = usdCnhRate,
            theoreticalBtcCnhCents = theoreticalCnhCents,
            observedBtcCnhCents = observedCnhCents,
            basisDeviationBps = basisBps
        )
    }
}
