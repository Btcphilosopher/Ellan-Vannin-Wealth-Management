package com.example.btcos.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.btcos.ui.MarketUiState
import com.example.btcos.ui.MarketViewModel
import com.example.btcos.ui.components.OrderBookLadder
import com.example.btcos.ui.components.OrderEntryPad
import com.example.btcos.ui.components.TerminalPriceChart
import com.example.btcos.ui.components.TradeTape

@Composable
fun TerminalScreen(
    state: MarketUiState,
    viewModel: MarketViewModel,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Price Chart with Candlesticks, Volume, VWAP
        TerminalPriceChart(
            candles = state.candles,
            modifier = Modifier.fillMaxWidth()
        )

        // Order Book & Trade Tape row / columns
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OrderBookLadder(
                snapshot = state.orderBookSnapshot,
                modifier = Modifier.weight(1.1f)
            )
            TradeTape(
                trades = state.recentTrades,
                modifier = Modifier.weight(1f)
            )
        }

        // Order Entry Pad
        OrderEntryPad(
            side = state.inputSide,
            orderType = state.inputOrderType,
            priceText = state.inputPriceText,
            quantitySats = state.inputQuantitySats,
            feedbackText = state.lastOrderFeedback,
            isKillSwitchEngaged = state.isKillSwitchEngaged,
            onSideChanged = { viewModel.setOrderSide(it) },
            onOrderTypeChanged = { viewModel.setOrderType(it) },
            onPriceChanged = { viewModel.updatePriceText(it) },
            onQuantityChanged = { viewModel.updateQuantitySats(it) },
            onSubmitOrder = { viewModel.submitOrder() },
            onToggleKillSwitch = { viewModel.toggleKillSwitch() },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(16.dp))
    }
}
