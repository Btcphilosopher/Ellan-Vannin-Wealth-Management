package com.example.btcos.orderbook

import com.example.btcos.core.BitcoinAmount
import com.example.btcos.core.FiatAmount
import java.util.concurrent.atomic.AtomicLong

enum class OrderSide { BUY, SELL }

enum class OrderType {
    MARKET,
    LIMIT,
    POST_ONLY,
    IOC,        // Immediate or Cancel
    FOK,        // Fill or Kill
    STOP,
    STOP_LIMIT
}

enum class TimeInForce { GTC, IOC, FOK, DAY }

enum class OrderStatus {
    NEW,
    ACCEPTED,
    PARTIALLY_FILLED,
    FILLED,
    CANCEL_PENDING,
    CANCELLED,
    REJECTED,
    EXPIRED
}

data class Order(
    val orderId: String,
    val clientOrderId: String,
    val accountId: String,
    val venueId: String,
    val instrumentId: String,
    val side: OrderSide,
    val orderType: OrderType,
    val priceCents: Long, // 0 for market orders
    val quantitySats: Long,
    val remainingQuantitySats: Long,
    val timeInForce: TimeInForce = TimeInForce.GTC,
    val status: OrderStatus = OrderStatus.NEW,
    val timestamp: Long = System.currentTimeMillis(),
    val sequenceNumber: Long = 0L,
    val stopPriceCents: Long = 0L
) {
    val isFilled: Boolean get() = remainingQuantitySats == 0L
    val filledQuantitySats: Long get() = quantitySats - remainingQuantitySats
    val btcAmount: BitcoinAmount get() = BitcoinAmount(quantitySats)
    val remainingBtc: BitcoinAmount get() = BitcoinAmount(remainingQuantitySats)
    val fiatPrice: FiatAmount get() = FiatAmount(priceCents)
}

data class Trade(
    val tradeId: String,
    val buyOrderId: String,
    val sellOrderId: String,
    val venueId: String,
    val instrumentId: String,
    val priceCents: Long,
    val quantitySats: Long,
    val quoteValueCents: Long,
    val timestamp: Long,
    val makerOrderId: String,
    val takerOrderId: String,
    val makerFeeCents: Long,
    val takerFeeCents: Long,
    val sequenceNumber: Long,
    val isTakerBuyer: Boolean
) {
    val btcAmount: BitcoinAmount get() = BitcoinAmount(quantitySats)
    val fiatPrice: FiatAmount get() = FiatAmount(priceCents)
    val quoteValue: FiatAmount get() = FiatAmount(quoteValueCents)
}

data class BookLevel(
    val priceCents: Long,
    val quantitySats: Long,
    val orderCount: Int,
    val cumulativeSats: Long = 0L,
    val depthPercent: Double = 0.0
) {
    val btcQuantity: Double get() = quantitySats.toDouble() / BitcoinAmount.SATS_PER_BTC
    val cumulativeBtc: Double get() = cumulativeSats.toDouble() / BitcoinAmount.SATS_PER_BTC
    val fiatPrice: FiatAmount get() = FiatAmount(priceCents)
}

data class OrderBookSnapshot(
    val instrumentId: String,
    val venueId: String,
    val timestamp: Long,
    val sequenceNumber: Long,
    val bids: List<BookLevel>,
    val asks: List<BookLevel>,
    val bestBidCents: Long?,
    val bestAskCents: Long?,
    val midPriceCents: Long?,
    val spreadCents: Long?,
    val spreadBps: Double?,
    val orderBookImbalance: Double // (Q_bid - Q_ask)/(Q_bid + Q_ask) [-1.0, 1.0]
)
