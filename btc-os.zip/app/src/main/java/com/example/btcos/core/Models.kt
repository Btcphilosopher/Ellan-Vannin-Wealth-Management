package com.example.btcos.core

import java.text.DecimalFormat
import java.text.NumberFormat
import java.util.Locale

/**
 * Fundamental Bitcoin precision unit.
 * Authoritative accounting ALWAYS uses integer satoshis.
 * 1 BTC = 100,000,000 satoshis.
 */
@JvmInline
value class BitcoinAmount(val satoshis: Long) : Comparable<BitcoinAmount> {
    operator fun plus(other: BitcoinAmount): BitcoinAmount = BitcoinAmount(this.satoshis + other.satoshis)
    operator fun minus(other: BitcoinAmount): BitcoinAmount = BitcoinAmount(this.satoshis - other.satoshis)
    operator fun times(scalar: Long): BitcoinAmount = BitcoinAmount(this.satoshis * scalar)
    operator fun div(scalar: Long): BitcoinAmount = BitcoinAmount(this.satoshis / scalar)

    override fun compareTo(other: BitcoinAmount): Int = this.satoshis.compareTo(other.satoshis)

    fun toBtcDouble(): Double = satoshis.toDouble() / SATS_PER_BTC

    fun toBtcString(decimals: Int = 4): String {
        val btc = satoshis.toDouble() / SATS_PER_BTC
        return String.format(Locale.US, "%.${decimals}f BTC", btc)
    }

    fun toSatsFormatted(): String {
        return NumberFormat.getNumberInstance(Locale.US).format(satoshis) + " sats"
    }

    companion object {
        const val SATS_PER_BTC: Long = 100_000_000L
        val ZERO = BitcoinAmount(0L)

        fun fromBtc(btc: Double): BitcoinAmount {
            val sats = Math.round(btc * SATS_PER_BTC)
            return BitcoinAmount(sats)
        }
    }
}

/**
 * Fiat currency amount in minor currency units (cents / pence / yen units)
 * to maintain integer precision throughout accounting and ledger.
 */
data class FiatAmount(
    val cents: Long,
    val currency: String = "USD"
) : Comparable<FiatAmount> {
    operator fun plus(other: FiatAmount): FiatAmount {
        require(this.currency == other.currency) { "Currency mismatch: ${this.currency} vs ${other.currency}" }
        return FiatAmount(this.cents + other.cents, currency)
    }

    operator fun minus(other: FiatAmount): FiatAmount {
        require(this.currency == other.currency) { "Currency mismatch: ${this.currency} vs ${other.currency}" }
        return FiatAmount(this.cents - other.cents, currency)
    }

    override fun compareTo(other: FiatAmount): Int {
        require(this.currency == other.currency) { "Currency mismatch" }
        return this.cents.compareTo(other.cents)
    }

    fun toDecimal(): Double = cents.toDouble() / 100.0

    fun formatted(): String {
        val symbol = when (currency) {
            "USD" -> "$"
            "EUR" -> "€"
            "GBP" -> "£"
            "JPY" -> "¥"
            "CNH" -> "¥"
            "USDT" -> "₮"
            "USDC" -> "$"
            else -> "$currency "
        }
        val dec = cents.toDouble() / 100.0
        val df = DecimalFormat("#,##0.00")
        return "$symbol${df.format(dec)}"
    }

    companion object {
        fun fromDecimal(amount: Double, currency: String = "USD"): FiatAmount {
            val cents = Math.round(amount * 100.0)
            return FiatAmount(cents, currency)
        }
    }
}

enum class Jurisdiction(val label: String, val regulatoryBody: String) {
    UK_FCA("United Kingdom", "Financial Conduct Authority (FCA - CP24/25)"),
    US_SEC_CFTC("United States", "SEC / CFTC"),
    EU_MICA("European Union", "ESMA / MiCA"),
    JP_JFSA("Japan", "Japan FSA"),
    GLOBAL_SIMULATION("Global Sandbox", "BTC-OS Simulation Sandbox")
}

enum class RegulatedActivity(val title: String, val description: String) {
    TRADING_PLATFORM("Operating a Trading Platform", "Multilateral matching engine & order books"),
    DEALING("Dealing in Cryptoassets", "Principal execution & market making"),
    ARRANGING("Arranging Deals", "Smart Order Routing & multilateral introduction"),
    SAFEGUARDING("Safeguarding & Administration", "Custodial key management & asset segregation"),
    EXECUTION("Order Execution", "Client order execution against venues"),
    SETTLEMENT("Clearing & Settlement", "Bilateral & multilateral on-chain delivery vs payment"),
    MARKET_DATA("Market Intelligence & Benchmarks", "Reference pricing & microstructure indices")
}
