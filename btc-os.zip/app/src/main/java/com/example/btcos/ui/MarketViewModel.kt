package com.example.btcos.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.btcos.bitcoin.BitcoinSettlementEngine
import com.example.btcos.bitcoin.ReconciliationMatrix
import com.example.btcos.core.BitcoinAmount
import com.example.btcos.core.FiatAmount
import com.example.btcos.digitaltwin.BenchmarkResult
import com.example.btcos.digitaltwin.DigitalTwinEngine
import com.example.btcos.digitaltwin.DigitalTwinShockEvent
import com.example.btcos.ledger.DoubleEntryLedger
import com.example.btcos.liquidity.ArbitrageOpportunity
import com.example.btcos.liquidity.BtcCnhPricing
import com.example.btcos.liquidity.LiquidityAggregator
import com.example.btcos.liquidity.RoutingStrategy
import com.example.btcos.liquidity.SorExecutionPlan
import com.example.btcos.market.Instrument
import com.example.btcos.market.MarketMaster
import com.example.btcos.orderbook.BookLevel
import com.example.btcos.orderbook.CentralLimitOrderBook
import com.example.btcos.orderbook.MatchResult
import com.example.btcos.orderbook.MatchingEngine
import com.example.btcos.orderbook.Order
import com.example.btcos.orderbook.OrderBookSnapshot
import com.example.btcos.orderbook.OrderSide
import com.example.btcos.orderbook.OrderStatus
import com.example.btcos.orderbook.OrderType
import com.example.btcos.orderbook.TimeInForce
import com.example.btcos.orderbook.Trade
import com.example.btcos.quant.AiAnalystReport
import com.example.btcos.quant.BtcIndexObservation
import com.example.btcos.quant.BtcPriceDiscovery
import com.example.btcos.quant.InstitutionalAiAnalyst
import com.example.btcos.risk.AlertStatus
import com.example.btcos.risk.MarketRiskMetrics
import com.example.btcos.risk.RiskSurveillanceEngine
import com.example.btcos.risk.StressScenarioResult
import com.example.btcos.risk.SurveillanceAlert
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class TerminalTab(val title: String, val badge: String? = null) {
    TERMINAL("Terminal", "L2"),
    LIQUIDITY_SOR("Liquidity / SOR", "Multi"),
    LEDGER_SETTLE("Ledger & Settle", "Zero-Drift"),
    RISK_SURVEILLANCE("Risk & Surveillance", "Audit"),
    DIGITAL_TWIN("Digital Twin", "Sim"),
    AI_ANALYST("AI Analyst", "Proven")
}

data class Candle(
    val timestamp: Long,
    val openCents: Long,
    val highCents: Long,
    val lowCents: Long,
    val closeCents: Long,
    val volumeSats: Long
)

data class MarketUiState(
    val currentTab: TerminalTab = TerminalTab.TERMINAL,
    val selectedInstrument: Instrument = MarketMaster.INSTRUMENTS.first(),
    val referenceIndex: BtcIndexObservation? = null,
    val orderBookSnapshot: OrderBookSnapshot? = null,
    val recentTrades: List<Trade> = emptyList(),
    val candles: List<Candle> = emptyList(),
    val lastTradedPriceCents: Long = 104_250_00L,
    val priceChange24hPct: Double = 2.45,
    val volume24hBtc: Double = 1420.8,
    // Order entry inputs
    val inputSide: OrderSide = OrderSide.BUY,
    val inputOrderType: OrderType = OrderType.LIMIT,
    val inputPriceText: String = "104250",
    val inputQuantitySats: Long = 50_000_000L, // 0.5 BTC default
    val inputAccount: String = "CLIENT_001",
    val lastOrderFeedback: String? = null,
    // Ledger & Settle
    val accounts: List<com.example.btcos.ledger.LedgerAccount> = emptyList(),
    val journal: List<com.example.btcos.ledger.JournalEntry> = emptyList(),
    val ledgerInvariantValid: Boolean = true,
    val reconciliationMatrix: ReconciliationMatrix? = null,
    // Multi-Venue
    val sorPlan: SorExecutionPlan? = null,
    val arbitrageOpportunities: List<ArbitrageOpportunity> = emptyList(),
    val btcCnhPricing: BtcCnhPricing? = null,
    // Risk & Surveillance
    val riskMetrics: MarketRiskMetrics? = null,
    val stressResults: List<StressScenarioResult> = emptyList(),
    val surveillanceAlerts: List<SurveillanceAlert> = emptyList(),
    val isKillSwitchEngaged: Boolean = false,
    // Digital Twin
    val latestBenchmarkResult: BenchmarkResult? = null,
    val activeShockEvent: DigitalTwinShockEvent? = null,
    // AI Analyst
    val currentAiReport: AiAnalystReport? = null,
    val isAiAnalyzing: Boolean = false
)

class MarketViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(MarketUiState())
    val uiState: StateFlow<MarketUiState> = _uiState.asStateFlow()

    private val ledger = DoubleEntryLedger()
    private val settlementEngine = BitcoinSettlementEngine()
    private val liquidityAggregator = LiquidityAggregator()
    private val riskEngine = RiskSurveillanceEngine()
    private val aiAnalyst = InstitutionalAiAnalyst()

    // Matching engines map per instrument
    private val matchingEngines = mutableMapOf<String, MatchingEngine>()
    private lateinit var digitalTwin: DigitalTwinEngine

    init {
        initializeEngines()
        refreshAllState()
    }

    private fun initializeEngines() {
        for (inst in MarketMaster.INSTRUMENTS) {
            val engine = MatchingEngine(inst)
            matchingEngines[inst.id] = engine
        }
        val defaultEngine = matchingEngines[MarketMaster.INSTRUMENTS.first().id]!!
        digitalTwin = DigitalTwinEngine(defaultEngine, ledger)
        digitalTwin.seedInstitutionalBook(anchorPriceCents = 104_250_00L)

        // Seed initial candles
        val initCandles = generateHistoricalCandles(104_250_00L)
        _uiState.value = _uiState.value.copy(candles = initCandles)
    }

    fun selectTab(tab: TerminalTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab)
        if (tab == TerminalTab.AI_ANALYST && _uiState.value.currentAiReport == null) {
            askAiQuery("What is happening in BTC liquidity?")
        }
    }

    fun selectInstrument(instrument: Instrument) {
        val engine = matchingEngines[instrument.id] ?: return
        if (engine.book.getBestBid() == null && engine.book.getBestAsk() == null) {
            digitalTwin = DigitalTwinEngine(engine, ledger)
            digitalTwin.seedInstitutionalBook(anchorPriceCents = engine.lastTradedPriceCents)
        }
        _uiState.value = _uiState.value.copy(
            selectedInstrument = instrument,
            lastTradedPriceCents = engine.lastTradedPriceCents,
            inputPriceText = (engine.lastTradedPriceCents / 100).toString()
        )
        refreshAllState()
    }

    fun setOrderSide(side: OrderSide) {
        _uiState.value = _uiState.value.copy(inputSide = side)
    }

    fun setOrderType(type: OrderType) {
        _uiState.value = _uiState.value.copy(inputOrderType = type)
    }

    fun updatePriceText(text: String) {
        _uiState.value = _uiState.value.copy(inputPriceText = text)
    }

    fun updateQuantitySats(sats: Long) {
        _uiState.value = _uiState.value.copy(inputQuantitySats = sats.coerceAtLeast(10_000L))
    }

    fun submitOrder() {
        val state = _uiState.value
        val engine = matchingEngines[state.selectedInstrument.id] ?: return

        val priceCents = if (state.inputOrderType == OrderType.MARKET) 0L else {
            val p = state.inputPriceText.toDoubleOrNull() ?: return
            Math.round(p * 100)
        }

        val order = Order(
            orderId = "ORD-" + UUID.randomUUID().toString().take(8).uppercase(),
            clientOrderId = "CLT-" + UUID.randomUUID().toString().take(6).uppercase(),
            accountId = state.inputAccount,
            venueId = "VENUE_INTERNAL",
            instrumentId = state.selectedInstrument.id,
            side = state.inputSide,
            orderType = state.inputOrderType,
            priceCents = priceCents,
            quantitySats = state.inputQuantitySats,
            remainingQuantitySats = state.inputQuantitySats,
            timeInForce = TimeInForce.GTC
        )

        val result = engine.processOrder(order)

        // Process generated trades into double-entry ledger
        val currentTrades = _uiState.value.recentTrades.toMutableList()
        for (trade in result.trades) {
            currentTrades.add(0, trade)
            ledger.recordTradeSettlement(
                tradeId = trade.tradeId,
                buyerBtcAccId = "ACC_CLIENT_A_BTC",
                buyerFiatAccId = "ACC_CLIENT_A_USD",
                sellerBtcAccId = "ACC_CLIENT_B_BTC",
                sellerFiatAccId = "ACC_CLIENT_B_USD",
                quantitySats = trade.quantitySats,
                quoteValueCents = trade.quoteValueCents,
                takerFeeCents = trade.takerFeeCents,
                makerFeeCents = trade.makerFeeCents
            )
            appendTradeToCandle(trade)
        }

        val feedback = if (result.rejectionReason != null) {
            "REJECTED: ${result.rejectionReason}"
        } else if (result.trades.isNotEmpty()) {
            "EXECUTED: ${result.trades.size} fill(s) at ${FiatAmount(result.trades.first().priceCents).formatted()}"
        } else {
            "RESTING ON BOOK: Limit order accepted (#${result.submittedOrder.sequenceNumber})"
        }

        _uiState.value = _uiState.value.copy(
            recentTrades = currentTrades.take(50),
            lastOrderFeedback = feedback,
            lastTradedPriceCents = engine.lastTradedPriceCents
        )
        refreshAllState()
    }

    fun toggleKillSwitch() {
        val state = _uiState.value
        val engine = matchingEngines[state.selectedInstrument.id] ?: return
        val newStatus = !engine.isKillSwitchActive
        engine.isKillSwitchActive = newStatus

        _uiState.value = _uiState.value.copy(
            isKillSwitchEngaged = newStatus,
            lastOrderFeedback = if (newStatus) "KILL SWITCH ENGAGED: Market matching halted" else "KILL SWITCH RELEASED: Normal matching restored"
        )
    }

    fun computeSorRoute(strategy: RoutingStrategy) {
        val state = _uiState.value
        val plan = liquidityAggregator.computeSorPlan(
            side = state.inputSide,
            totalSats = state.inputQuantitySats,
            strategy = strategy,
            currentMidCents = state.lastTradedPriceCents
        )
        _uiState.value = _uiState.value.copy(sorPlan = plan)
    }

    fun mineBitcoinBlock() {
        settlementEngine.mineSyntheticBlock()
        refreshAllState()
    }

    fun simulateReorg() {
        val msg = settlementEngine.simulateChainReorg()
        _uiState.value = _uiState.value.copy(lastOrderFeedback = msg)
        refreshAllState()
    }

    fun injectDigitalTwinShock(shockType: String) {
        val event = digitalTwin.injectShock(shockType)
        liquidityAggregator.refreshQuotes(matchingEngine().lastTradedPriceCents)
        _uiState.value = _uiState.value.copy(
            activeShockEvent = event,
            lastTradedPriceCents = matchingEngine().lastTradedPriceCents
        )
        refreshAllState()
    }

    fun runPerformanceBenchmark() {
        viewModelScope.launch {
            val bench = digitalTwin.runPerformanceBenchmark(1000)
            _uiState.value = _uiState.value.copy(
                latestBenchmarkResult = bench,
                lastOrderFeedback = "Benchmark completed: ${String.format("%.1f", bench.ordersPerSecond)} orders/sec | p50 ${bench.latencyP50Micros}µs"
            )
            refreshAllState()
        }
    }

    fun askAiQuery(query: String) {
        val state = _uiState.value
        val snapshot = state.orderBookSnapshot ?: return
        val report = when {
            query.contains("spread", ignoreCase = true) -> aiAnalyst.analyzeSpreadWidening(snapshot)
            query.contains("deep", ignoreCase = true) -> aiAnalyst.analyzeDeepestVenues(liquidityAggregator.quotes.values.toList())
            query.contains("risk", ignoreCase = true) -> state.riskMetrics?.let { aiAnalyst.analyzeMarketRisks(it) } ?: aiAnalyst.analyzeLiquidity(snapshot, state.recentTrades)
            else -> aiAnalyst.analyzeLiquidity(snapshot, state.recentTrades)
        }
        _uiState.value = _uiState.value.copy(currentAiReport = report)
    }

    fun updateSurveillanceAlertStatus(alertId: String, status: AlertStatus) {
        riskEngine.updateAlertStatus(alertId, status)
        _uiState.value = _uiState.value.copy(surveillanceAlerts = riskEngine.getAlerts())
    }

    private fun matchingEngine(): MatchingEngine =
        matchingEngines[_uiState.value.selectedInstrument.id] ?: matchingEngines.values.first()

    private fun refreshAllState() {
        val engine = matchingEngine()
        val snapshot = engine.book.generateSnapshot(levels = 10, sequenceNumber = engine.getNextSequence())
        val mid = snapshot.midPriceCents ?: engine.lastTradedPriceCents

        liquidityAggregator.refreshQuotes(mid)
        val quotesMap = liquidityAggregator.quotes.mapValues { it.value.bidPriceCents }
        val volumesMap = liquidityAggregator.quotes.mapValues { it.value.bidQtySats }
        val refIndex = BtcPriceDiscovery.computeReferenceIndex(quotesMap, volumesMap)

        val totalBtc = ledger.getAllAccounts().filter { it.currency == "BTC" }.sumOf { it.balanceSats }
        val totalUsd = ledger.getAllAccounts().filter { it.currency == "USD" }.sumOf { it.balanceCents }

        val metrics = riskEngine.calculateMetrics(mid, totalBtc, totalUsd)
        val stresses = riskEngine.runStressScenarios(mid, totalBtc)
        val reconc = settlementEngine.perform5WayReconciliation(totalBtc)
        val arbs = liquidityAggregator.findArbitrageOpportunities()
        val cnh = liquidityAggregator.computeBtcCnhPricing(mid)

        _uiState.value = _uiState.value.copy(
            orderBookSnapshot = snapshot,
            referenceIndex = refIndex,
            accounts = ledger.getAllAccounts(),
            journal = ledger.getJournal().take(20),
            ledgerInvariantValid = ledger.verifyInvariant(),
            reconciliationMatrix = reconc,
            riskMetrics = metrics,
            stressResults = stresses,
            surveillanceAlerts = riskEngine.getAlerts(),
            arbitrageOpportunities = arbs,
            btcCnhPricing = cnh,
            sorPlan = _uiState.value.sorPlan ?: liquidityAggregator.computeSorPlan(OrderSide.BUY, 50_000_000L, RoutingStrategy.MULTI_VENUE, mid)
        )
    }

    private fun appendTradeToCandle(trade: Trade) {
        val candles = _uiState.value.candles.toMutableList()
        if (candles.isEmpty()) return
        val last = candles.last()
        val updated = last.copy(
            highCents = Math.max(last.highCents, trade.priceCents),
            lowCents = Math.min(last.lowCents, trade.priceCents),
            closeCents = trade.priceCents,
            volumeSats = last.volumeSats + trade.quantitySats
        )
        candles[candles.lastIndex] = updated
        _uiState.value = _uiState.value.copy(candles = candles)
    }

    private fun generateHistoricalCandles(currentMid: Long): List<Candle> {
        val list = mutableListOf<Candle>()
        var price = currentMid - 400_00L
        val now = System.currentTimeMillis()

        for (i in 20 downTo 1) {
            val delta = ((-150_00L..180_00L).random())
            val open = price
            val close = price + delta
            val high = Math.max(open, close) + (10_00L..80_00L).random()
            val low = Math.min(open, close) - (10_00L..80_00L).random()
            val vol = (100_000_000L..900_000_000L).random()

            list.add(Candle(now - (i * 300_000L), open, high, low, close, vol))
            price = close
        }
        return list
    }
}
