package com.example.btcos.ledger

import com.example.btcos.core.BitcoinAmount
import com.example.btcos.core.FiatAmount
import java.util.UUID

enum class AccountCategory {
    CLIENT_ASSET_SEGREGATED,
    PLATFORM_OPERATIONAL,
    TREASURY_RESERVE,
    SETTLEMENT_ESCROW,
    FEE_REVENUE,
    CLIENT_LIABILITY
}

enum class EntryDirection { DEBIT, CREDIT }

data class LedgerAccount(
    val accountId: String,
    val ownerId: String,
    val name: String,
    val category: AccountCategory,
    val currency: String, // "BTC", "USD", "EUR", etc.
    val balanceSats: Long = 0L,
    val balanceCents: Long = 0L
) {
    val btcAmount: BitcoinAmount get() = BitcoinAmount(balanceSats)
    val fiatAmount: FiatAmount get() = FiatAmount(balanceCents, currency)
}

data class Posting(
    val accountId: String,
    val direction: EntryDirection,
    val amountSats: Long = 0L,
    val amountCents: Long = 0L
)

data class JournalEntry(
    val entryId: String,
    val timestamp: Long,
    val referenceId: String,
    val description: String,
    val postings: List<Posting>
)

class DoubleEntryLedger {
    private val accounts = HashMap<String, LedgerAccount>()
    private val journal = ArrayList<JournalEntry>()
    private val lock = Any()

    init {
        // Initialize institutional chart of accounts
        createAccount("ACC_CLIENT_A_BTC", "CLIENT_001", "Client A Segregated BTC", AccountCategory.CLIENT_ASSET_SEGREGATED, "BTC", initialSats = 500_000_000L) // 5 BTC
        createAccount("ACC_CLIENT_A_USD", "CLIENT_001", "Client A Segregated Cash", AccountCategory.CLIENT_ASSET_SEGREGATED, "USD", initialCents = 1_000_000_00L) // $1,000,000

        createAccount("ACC_CLIENT_B_BTC", "CLIENT_002", "Client B Segregated BTC", AccountCategory.CLIENT_ASSET_SEGREGATED, "BTC", initialSats = 1_200_000_000L) // 12 BTC
        createAccount("ACC_CLIENT_B_USD", "CLIENT_002", "Client B Segregated Cash", AccountCategory.CLIENT_ASSET_SEGREGATED, "USD", initialCents = 2_500_000_00L) // $2,500,000

        createAccount("ACC_MM_BTC", "MM_ALPHA", "Market Maker Alpha Inventory", AccountCategory.PLATFORM_OPERATIONAL, "BTC", initialSats = 2_000_000_000L) // 20 BTC
        createAccount("ACC_MM_USD", "MM_ALPHA", "Market Maker Alpha Cash", AccountCategory.PLATFORM_OPERATIONAL, "USD", initialCents = 5_000_000_00L) // $5,000,000

        createAccount("ACC_TREASURY_BTC", "TREASURY", "BTC-OS Strategic Reserve", AccountCategory.TREASURY_RESERVE, "BTC", initialSats = 5_000_000_000L) // 50 BTC
        createAccount("ACC_SETTLEMENT_ESCROW", "SETTLEMENT", "Settlement Delivery vs Payment Escrow", AccountCategory.SETTLEMENT_ESCROW, "USD", initialCents = 0L)
        createAccount("ACC_FEE_REVENUE_USD", "EXCHANGE", "Exchange Fee Income", AccountCategory.FEE_REVENUE, "USD", initialCents = 0L)
    }

    fun createAccount(
        accountId: String,
        ownerId: String,
        name: String,
        category: AccountCategory,
        currency: String,
        initialSats: Long = 0L,
        initialCents: Long = 0L
    ): LedgerAccount {
        synchronized(lock) {
            val acc = LedgerAccount(accountId, ownerId, name, category, currency, initialSats, initialCents)
            accounts[accountId] = acc
            return acc
        }
    }

    fun getAccount(accountId: String): LedgerAccount? = synchronized(lock) { accounts[accountId] }
    fun getAllAccounts(): List<LedgerAccount> = synchronized(lock) { accounts.values.toList() }
    fun getJournal(): List<JournalEntry> = synchronized(lock) { ArrayList(journal) }

    /**
     * Records a balanced double-entry financial transaction.
     * INVARIANT CHECK: Total Debits == Total Credits across all currencies!
     */
    fun recordTransaction(
        referenceId: String,
        description: String,
        postings: List<Posting>
    ): JournalEntry {
        synchronized(lock) {
            // Verify invariant: debits and credits must balance per asset type
            val btcDebits = postings.filter { it.direction == EntryDirection.DEBIT }.sumOf { it.amountSats }
            val btcCredits = postings.filter { it.direction == EntryDirection.CREDIT }.sumOf { it.amountSats }
            require(btcDebits == btcCredits) {
                "LEDGER INVARIANT VIOLATION: BTC Debits ($btcDebits) != Credits ($btcCredits)"
            }

            val fiatDebits = postings.filter { it.direction == EntryDirection.DEBIT }.sumOf { it.amountCents }
            val fiatCredits = postings.filter { it.direction == EntryDirection.CREDIT }.sumOf { it.amountCents }
            require(fiatDebits == fiatCredits) {
                "LEDGER INVARIANT VIOLATION: Fiat Debits ($fiatDebits) != Credits ($fiatCredits)"
            }

            // Apply updates
            for (posting in postings) {
                val acc = accounts[posting.accountId] ?: error("Account not found: ${posting.accountId}")
                val deltaSats = if (posting.direction == EntryDirection.DEBIT) posting.amountSats else -posting.amountSats
                val deltaCents = if (posting.direction == EntryDirection.DEBIT) posting.amountCents else -posting.amountCents

                val newAcc = acc.copy(
                    balanceSats = acc.balanceSats + deltaSats,
                    balanceCents = acc.balanceCents + deltaCents
                )
                accounts[posting.accountId] = newAcc
            }

            val entry = JournalEntry(
                entryId = "JRN-" + UUID.randomUUID().toString().take(8).uppercase(),
                timestamp = System.currentTimeMillis(),
                referenceId = referenceId,
                description = description,
                postings = postings
            )
            journal.add(0, entry)
            return entry
        }
    }

    /**
     * Executes trade settlement posting between Buyer and Seller accounts.
     */
    fun recordTradeSettlement(
        tradeId: String,
        buyerBtcAccId: String,
        buyerFiatAccId: String,
        sellerBtcAccId: String,
        sellerFiatAccId: String,
        quantitySats: Long,
        quoteValueCents: Long,
        takerFeeCents: Long,
        makerFeeCents: Long,
        feeRevenueAccId: String = "ACC_FEE_REVENUE_USD"
    ): JournalEntry {
        // Buyer: DEBIT BTC (receives BTC), CREDIT USD (pays USD), CREDIT USD (pays fee)
        // Seller: CREDIT BTC (delivers BTC), DEBIT USD (receives USD), CREDIT USD (pays fee)
        // Fee Revenue: DEBIT USD (receives total fees)
        val postings = listOf(
            Posting(buyerBtcAccId, EntryDirection.DEBIT, amountSats = quantitySats),
            Posting(sellerBtcAccId, EntryDirection.CREDIT, amountSats = quantitySats),
            Posting(sellerFiatAccId, EntryDirection.DEBIT, amountCents = quoteValueCents),
            Posting(buyerFiatAccId, EntryDirection.CREDIT, amountCents = quoteValueCents)
        )
        return recordTransaction(tradeId, "Spot Execution Settlement: $tradeId", postings)
    }

    fun verifyInvariant(): Boolean {
        synchronized(lock) {
            // Check that all journal entries were strictly balanced
            for (j in journal) {
                val dS = j.postings.filter { it.direction == EntryDirection.DEBIT }.sumOf { it.amountSats }
                val cS = j.postings.filter { it.direction == EntryDirection.CREDIT }.sumOf { it.amountSats }
                if (dS != cS) return false

                val dF = j.postings.filter { it.direction == EntryDirection.DEBIT }.sumOf { it.amountCents }
                val cF = j.postings.filter { it.direction == EntryDirection.CREDIT }.sumOf { it.amountCents }
                if (dF != cF) return false
            }
            return true
        }
    }
}
