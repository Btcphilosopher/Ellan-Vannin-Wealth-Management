package com.example.btcos.orderbook

import com.example.btcos.market.Instrument
import com.example.btcos.market.TradingStatus
import java.util.UUID
import java.util.concurrent.atomic.AtomicLong

data class MatchResult(
    val submittedOrder: Order,
    val trades: List<Trade>,
    val filledOrders: List<Order>,
    val restingOrder: Order?,
    val rejectionReason: String? = null
)

class MatchingEngine(
    val instrument: Instrument,
    val venueId: String = "VENUE_INTERNAL",
    val feeBpsMaker: Double = 1.0,
    val feeBpsTaker: Double = 3.5
) {
    val book = CentralLimitOrderBook(instrument.id, venueId)
    private val sequenceCounter = AtomicLong(1L)
    private val lock = Any()

    var marketStatus: TradingStatus = TradingStatus.OPEN
    var isKillSwitchActive: Boolean = false
    var lastTradedPriceCents: Long = 104_250_00L // $104,250.00 initial anchor
    var referencePriceCents: Long = 104_250_00L

    // Performance tracking
    var totalOrdersProcessed: Long = 0L
    var totalTradesGenerated: Long = 0L
    var lastProcessingLatencyMicros: Long = 0L

    fun getNextSequence(): Long = sequenceCounter.getAndIncrement()

    fun processOrder(inputOrder: Order): MatchResult {
        val startNano = System.nanoTime()
        synchronized(lock) {
            totalOrdersProcessed++

            // 1. Circuit breaker / Kill switch / Market status checks
            if (isKillSwitchActive) {
                return reject(inputOrder, "Emergency Kill Switch is ACTIVE: Market halted")
            }
            if (marketStatus == TradingStatus.HALTED || marketStatus == TradingStatus.CLOSED) {
                return reject(inputOrder, "Market is currently $marketStatus")
            }

            // 2. Order validation
            if (inputOrder.quantitySats < instrument.minOrderSats) {
                return reject(inputOrder, "Quantity ${inputOrder.quantitySats} sats below min lot ${instrument.minOrderSats}")
            }
            if (inputOrder.quantitySats > instrument.maxOrderSats) {
                return reject(inputOrder, "Quantity exceeds max order limit ${instrument.maxOrderSats}")
            }
            if (inputOrder.orderType != OrderType.MARKET && inputOrder.priceCents <= 0L) {
                return reject(inputOrder, "Limit orders must have positive price")
            }

            // Price Collar / Circuit breaker check (±20% from reference price)
            if (inputOrder.orderType != OrderType.MARKET && referencePriceCents > 0) {
                val maxAllowed = (referencePriceCents * 1.25).toLong()
                val minAllowed = (referencePriceCents * 0.75).toLong()
                if (inputOrder.priceCents > maxAllowed || inputOrder.priceCents < minAllowed) {
                    return reject(inputOrder, "Price outside regulatory circuit breaker band (±25% collar)")
                }
            }

            val seq = getNextSequence()
            var currentOrder = inputOrder.copy(
                status = OrderStatus.ACCEPTED,
                sequenceNumber = seq,
                remainingQuantitySats = inputOrder.quantitySats
            )

            // 3. Special handling for FOK (Fill or Kill)
            if (currentOrder.orderType == OrderType.FOK) {
                val canFill = canFillCompletely(currentOrder)
                if (!canFill) {
                    return reject(currentOrder, "FOK condition not met: Insufficient immediate liquidity")
                }
            }

            // 4. Special handling for POST_ONLY
            if (currentOrder.orderType == OrderType.POST_ONLY) {
                if (wouldCrossBook(currentOrder)) {
                    return reject(currentOrder, "POST_ONLY order would execute immediately as taker")
                }
                // Directly place on book
                book.addOrder(currentOrder)
                recordLatency(startNano)
                return MatchResult(currentOrder, emptyList(), emptyList(), currentOrder)
            }

            // 5. Matching execution
            val trades = mutableListOf<Trade>()
            val filledOrders = mutableListOf<Order>()
            var remainingSats = currentOrder.remainingQuantitySats

            val opposingList = if (currentOrder.side == OrderSide.BUY) book.getAsksSnapshot() else book.getBidsSnapshot()

            for (makerOrder in opposingList) {
                if (remainingSats <= 0L) break

                // Check price match
                val isPriceCrossed = when (currentOrder.side) {
                    OrderSide.BUY -> currentOrder.orderType == OrderType.MARKET || currentOrder.priceCents >= makerOrder.priceCents
                    OrderSide.SELL -> currentOrder.orderType == OrderType.MARKET || currentOrder.priceCents <= makerOrder.priceCents
                }

                if (!isPriceCrossed) break // No further orders can match

                val matchPriceCents = makerOrder.priceCents // Maker's price rules
                val matchQtySats = Math.min(remainingSats, makerOrder.remainingQuantitySats)
                val quoteValueCents = Math.round((matchPriceCents.toDouble() * matchQtySats) / com.example.btcos.core.BitcoinAmount.SATS_PER_BTC)

                // Calculate fees
                val makerFeeCents = Math.round(quoteValueCents * (feeBpsMaker / 10_000.0))
                val takerFeeCents = Math.round(quoteValueCents * (feeBpsTaker / 10_000.0))

                val tradeSeq = getNextSequence()
                val trade = Trade(
                    tradeId = "TRD-" + UUID.randomUUID().toString().take(8).uppercase(),
                    buyOrderId = if (currentOrder.side == OrderSide.BUY) currentOrder.orderId else makerOrder.orderId,
                    sellOrderId = if (currentOrder.side == OrderSide.SELL) currentOrder.orderId else makerOrder.orderId,
                    venueId = venueId,
                    instrumentId = instrument.id,
                    priceCents = matchPriceCents,
                    quantitySats = matchQtySats,
                    quoteValueCents = quoteValueCents,
                    timestamp = System.currentTimeMillis(),
                    makerOrderId = makerOrder.orderId,
                    takerOrderId = currentOrder.orderId,
                    makerFeeCents = makerFeeCents,
                    takerFeeCents = takerFeeCents,
                    sequenceNumber = tradeSeq,
                    isTakerBuyer = currentOrder.side == OrderSide.BUY
                )
                trades.add(trade)
                totalTradesGenerated++
                lastTradedPriceCents = matchPriceCents

                // Update maker order
                val updatedMakerRemaining = makerOrder.remainingQuantitySats - matchQtySats
                val updatedMaker = makerOrder.copy(
                    remainingQuantitySats = updatedMakerRemaining,
                    status = if (updatedMakerRemaining == 0L) OrderStatus.FILLED else OrderStatus.PARTIALLY_FILLED
                )
                book.updateOrder(updatedMaker)
                if (updatedMaker.status == OrderStatus.FILLED) {
                    filledOrders.add(updatedMaker)
                }

                remainingSats -= matchQtySats
            }

            // 6. Update taker order
            currentOrder = currentOrder.copy(
                remainingQuantitySats = remainingSats,
                status = when {
                    remainingSats == 0L -> OrderStatus.FILLED
                    remainingSats < currentOrder.quantitySats -> OrderStatus.PARTIALLY_FILLED
                    else -> OrderStatus.ACCEPTED
                }
            )

            var resting: Order? = null
            // Check IOC / MARKET residual
            if (currentOrder.orderType == OrderType.IOC || currentOrder.orderType == OrderType.MARKET) {
                if (currentOrder.remainingQuantitySats > 0L) {
                    currentOrder = currentOrder.copy(status = OrderStatus.CANCELLED)
                }
            } else if (currentOrder.remainingQuantitySats > 0L) {
                // Limit order rests on book
                book.addOrder(currentOrder)
                resting = currentOrder
            }

            recordLatency(startNano)
            return MatchResult(currentOrder, trades, filledOrders, resting)
        }
    }

    fun cancelOrder(orderId: String): Order? {
        synchronized(lock) {
            val removed = book.removeOrder(orderId) ?: return null
            return removed.copy(status = OrderStatus.CANCELLED)
        }
    }

    private fun wouldCrossBook(order: Order): Boolean {
        return if (order.side == OrderSide.BUY) {
            val bestAsk = book.getBestAsk() ?: return false
            order.priceCents >= bestAsk.priceCents
        } else {
            val bestBid = book.getBestBid() ?: return false
            order.priceCents <= bestBid.priceCents
        }
    }

    private fun canFillCompletely(order: Order): Boolean {
        val opposing = if (order.side == OrderSide.BUY) book.getAsksSnapshot() else book.getBidsSnapshot()
        var cumSats = 0L
        for (resting in opposing) {
            val crosses = when (order.side) {
                OrderSide.BUY -> order.orderType == OrderType.MARKET || order.priceCents >= resting.priceCents
                OrderSide.SELL -> order.orderType == OrderType.MARKET || order.priceCents <= resting.priceCents
            }
            if (crosses) {
                cumSats += resting.remainingQuantitySats
                if (cumSats >= order.quantitySats) return true
            } else break
        }
        return false
    }

    private fun reject(order: Order, reason: String): MatchResult {
        val rejectedOrder = order.copy(status = OrderStatus.REJECTED)
        return MatchResult(
            submittedOrder = rejectedOrder,
            trades = emptyList(),
            filledOrders = emptyList(),
            restingOrder = null,
            rejectionReason = reason
        )
    }

    private fun recordLatency(startNano: Long) {
        lastProcessingLatencyMicros = (System.nanoTime() - startNano) / 1000
    }
}
