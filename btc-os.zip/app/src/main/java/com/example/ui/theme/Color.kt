package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// London Institutional Trading Desk Palette
// Paper White, Graphite, Deep Navy, Steel, Cool Blue, Dark Green, Muted Amber, Minimal Bitcoin Gold
val BgGraphiteDark = Color(0xFF0B1017)
val BgSurfaceNavy = Color(0xFF131A24)
val BgCardElevated = Color(0xFF1A2332)
val BorderSteel = Color(0xFF263345)
val BorderSubtle = Color(0xFF1E293B)

val TextPaperWhite = Color(0xFFF1F5F9)
val TextMutedGraphite = Color(0xFF94A3B8)
val TextDim = Color(0xFF64748B)

val TerminalGreen = Color(0xFF10B981)
val TerminalGreenBg = Color(0x1A10B981)
val TerminalRed = Color(0xFFEF4444)
val TerminalRedBg = Color(0x1AEF4444)

val BtcGold = Color(0xFFF7931A)
val BtcGoldDim = Color(0x26F7931A)
val InstitutionalBlue = Color(0xFF38BDF8)
val AmberWarning = Color(0xFFF59E0B)
val PurpleAccent = Color(0xFF818CF8)
