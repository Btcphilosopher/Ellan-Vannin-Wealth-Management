package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val InstitutionalColorScheme = darkColorScheme(
    primary = BtcGold,
    onPrimary = BgGraphiteDark,
    primaryContainer = BgCardElevated,
    onPrimaryContainer = TextPaperWhite,
    secondary = InstitutionalBlue,
    onSecondary = BgGraphiteDark,
    secondaryContainer = BorderSteel,
    onSecondaryContainer = TextPaperWhite,
    tertiary = TerminalGreen,
    onTertiary = BgGraphiteDark,
    background = BgGraphiteDark,
    onBackground = TextPaperWhite,
    surface = BgSurfaceNavy,
    onSurface = TextPaperWhite,
    surfaceVariant = BgCardElevated,
    onSurfaceVariant = TextMutedGraphite,
    outline = BorderSteel,
    outlineVariant = BorderSubtle,
    error = TerminalRed,
    onError = TextPaperWhite
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = InstitutionalColorScheme,
        typography = Typography,
        content = content
    )
}
