package com.example

import com.example.btcos.bitcoin.BitcoinSettlementEngine
import com.example.btcos.core.BitcoinAmount
import com.example.btcos.core.FiatAmount
import com.example.btcos.ledger.DoubleEntryLedger
import com.example.btcos.market.MarketMaster
import com.example.btcos.orderbook.MatchingEngine
import com.example.btcos.orderbook.Order
import com.example.btcos.orderbook.OrderSide
import com.example.btcos.orderbook.OrderStatus
import com.example.btcos.orderbook.OrderType
import com.example.btcos.orderbook.TimeInForce
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun testSatoshiIntegerPrecision() {
    // 1 BTC = 100,000,000 satoshis, verify integer math without float precision drift
    val btc1 = BitcoinAmount.fromBtc(1.0)
    val btc2 = BitcoinAmount.fromBtc(0.5)
    val sum = btc1 + btc2
    assertEquals(150_000_000L, sum.satoshis)
    assertEquals("1.5000 BTC", sum.toBtcString(4))
  }

  @Test
  fun testMatchingEngineFullAndPartialFill() {
    val instrument = MarketMaster.findInstrument("BTC/USD")
    val engine = MatchingEngine(instrument)

    // Resting limit sell order: 1.0 BTC at $104,200.00
    val sellOrder = Order(
      orderId = "TEST-SELL-1",
      clientOrderId = "CLT-S1",
      accountId = "SELLER_01",
      venueId = "VENUE_INTERNAL",
      instrumentId = instrument.id,
      side = OrderSide.SELL,
      orderType = OrderType.LIMIT,
      priceCents = 104_200_00L,
      quantitySats = 100_000_000L,
      remainingQuantitySats = 100_000_000L,
      timeInForce = TimeInForce.GTC
    )
    val sellResult = engine.processOrder(sellOrder)
    assertEquals(OrderStatus.ACCEPTED, sellResult.submittedOrder.status)
    assertEquals(1, engine.book.getAsksSnapshot().size)

    // Incoming aggressive limit buy order for 0.4 BTC at $104,250.00 (crosses book)
    val buyOrder = Order(
      orderId = "TEST-BUY-1",
      clientOrderId = "CLT-B1",
      accountId = "BUYER_01",
      venueId = "VENUE_INTERNAL",
      instrumentId = instrument.id,
      side = OrderSide.BUY,
      orderType = OrderType.LIMIT,
      priceCents = 104_250_00L,
      quantitySats = 40_000_000L,
      remainingQuantitySats = 40_000_000L,
      timeInForce = TimeInForce.GTC
    )
    val buyResult = engine.processOrder(buyOrder)
    assertEquals(OrderStatus.FILLED, buyResult.submittedOrder.status)
    assertEquals(1, buyResult.trades.size)

    val trade = buyResult.trades.first()
    assertEquals(104_200_00L, trade.priceCents) // Maker price executed
    assertEquals(40_000_000L, trade.quantitySats)

    // Verify resting sell order has 0.6 BTC remaining
    val remainingAsk = engine.book.getAsksSnapshot().first()
    assertEquals(60_000_000L, remainingAsk.remainingQuantitySats)
    assertEquals(OrderStatus.PARTIALLY_FILLED, remainingAsk.status)
  }

  @Test
  fun testDoubleEntryLedgerInvariant() {
    val ledger = DoubleEntryLedger()
    assertTrue(ledger.verifyInvariant())

    // Settle a synthetic trade: 0.5 BTC at $100,000 = $50,000
    val entry = ledger.recordTradeSettlement(
      tradeId = "TRD-UNIT-01",
      buyerBtcAccId = "ACC_CLIENT_A_BTC",
      buyerFiatAccId = "ACC_CLIENT_A_USD",
      sellerBtcAccId = "ACC_CLIENT_B_BTC",
      sellerFiatAccId = "ACC_CLIENT_B_USD",
      quantitySats = 50_000_000L,
      quoteValueCents = 50_000_00L,
      takerFeeCents = 17_50L,
      makerFeeCents = 5_00L
    )

    assertNotNull(entry)
    // Continuous reconciliation invariant must hold 100%
    assertTrue("Total Debits must strictly equal Total Credits", ledger.verifyInvariant())
  }

  @Test
  fun testBitcoinNetworkSettlementReconciliation() {
    val settlement = BitcoinSettlementEngine()
    val initialHeight = settlement.currentBlockHeight
    val newBlock = settlement.mineSyntheticBlock()
    assertEquals(initialHeight + 1, newBlock.height)

    val matrix = settlement.perform5WayReconciliation(ledgerTotalSats = 8_700_000_000L)
    assertTrue("5-way reconciliation must show zero drift", matrix.isReconciled)
    assertEquals(0L, matrix.varianceSats)
  }
}
