/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { InfraProject, ProjectCategory, ProjectResults, MultiplierParams } from "../types";

export const initialProjects: InfraProject[] = [
  {
    id: "proj_rail_express",
    name: "Caledonian High-Speed Rail Corridor",
    category: ProjectCategory.Transport,
    capex: 12500, // £12.5bn
    opex: 180,    // £180m/yr
    maintenance: 1.5, // 1.5% of capex/yr
    lifetime: 40,
    residualValue: 2000,
    constructionPeriod: 7,
    inflation: 2.2,
    discountRate: 3.5,
    strategicImportance: 95,
    politicalRisk: 40,
    constructionRisk: 65,
    operationalRisk: 25,
    liquidityRisk: 30,
    selected: true,
    fundingShare: 80
  },
  {
    id: "proj_port_manx",
    name: "Douglas Deep-Water Freeport Expansion",
    category: ProjectCategory.Transport,
    capex: 1400,
    opex: 45,
    maintenance: 2.0,
    lifetime: 30,
    residualValue: 300,
    constructionPeriod: 4,
    inflation: 2.0,
    discountRate: 4.0,
    strategicImportance: 88,
    politicalRisk: 15,
    constructionRisk: 35,
    operationalRisk: 20,
    liquidityRisk: 15,
    selected: true,
    fundingShare: 50
  },
  {
    id: "proj_airport_cargo",
    name: "Ronaldsway Green Cargo Hub",
    category: ProjectCategory.Transport,
    capex: 650,
    opex: 28,
    maintenance: 1.8,
    lifetime: 25,
    residualValue: 80,
    constructionPeriod: 3,
    inflation: 2.0,
    discountRate: 4.0,
    strategicImportance: 72,
    politicalRisk: 20,
    constructionRisk: 30,
    operationalRisk: 18,
    liquidityRisk: 20,
    selected: false,
    fundingShare: 40
  },
  {
    id: "proj_data_ai",
    name: "Sovereign AI & Hyper-scale Data Centre",
    category: ProjectCategory.Digital,
    capex: 3200,
    opex: 190,
    maintenance: 4.5,
    lifetime: 15,
    residualValue: 150,
    constructionPeriod: 2,
    inflation: 2.5,
    discountRate: 6.0,
    strategicImportance: 90,
    politicalRisk: 10,
    constructionRisk: 25,
    operationalRisk: 40,
    liquidityRisk: 45,
    selected: true,
    fundingShare: 30
  },
  {
    id: "proj_power_smr",
    name: "Isle of Man SMR Nuclear Station",
    category: ProjectCategory.Energy,
    capex: 4500,
    opex: 95,
    maintenance: 1.2,
    lifetime: 50,
    residualValue: 500,
    constructionPeriod: 6,
    inflation: 2.0,
    discountRate: 4.5,
    strategicImportance: 96,
    politicalRisk: 45,
    constructionRisk: 55,
    operationalRisk: 30,
    liquidityRisk: 35,
    selected: true,
    fundingShare: 70
  },
  {
    id: "proj_grid_smart",
    name: "Intercontinental High-Voltage Subsea Grid",
    category: ProjectCategory.Energy,
    capex: 2800,
    opex: 40,
    maintenance: 1.0,
    lifetime: 35,
    residualValue: 400,
    constructionPeriod: 4,
    inflation: 1.8,
    discountRate: 4.0,
    strategicImportance: 92,
    politicalRisk: 20,
    constructionRisk: 45,
    operationalRisk: 15,
    liquidityRisk: 20,
    selected: true,
    fundingShare: 60
  },
  {
    id: "proj_water_res",
    name: "National Smart Aqueduct & Desalination",
    category: ProjectCategory.Social,
    capex: 1200,
    opex: 32,
    maintenance: 1.5,
    lifetime: 50,
    residualValue: 200,
    constructionPeriod: 5,
    inflation: 1.5,
    discountRate: 3.0,
    strategicImportance: 85,
    politicalRisk: 12,
    constructionRisk: 35,
    operationalRisk: 15,
    liquidityRisk: 10,
    selected: false,
    fundingShare: 100
  },
  {
    id: "proj_flood_defense",
    name: "Coastal Inundation Protection Barrier",
    category: ProjectCategory.Environment,
    capex: 950,
    opex: 12,
    maintenance: 0.8,
    lifetime: 60,
    residualValue: 50,
    constructionPeriod: 4,
    inflation: 1.8,
    discountRate: 2.5,
    strategicImportance: 89,
    politicalRisk: 15,
    constructionRisk: 40,
    operationalRisk: 10,
    liquidityRisk: 5,
    selected: true,
    fundingShare: 100
  },
  {
    id: "proj_barrage_tidal",
    name: "Solaise Tidal Barrage Generation",
    category: ProjectCategory.Energy,
    capex: 6800,
    opex: 60,
    maintenance: 0.9,
    lifetime: 60,
    residualValue: 1200,
    constructionPeriod: 8,
    inflation: 1.9,
    discountRate: 3.5,
    strategicImportance: 94,
    politicalRisk: 35,
    constructionRisk: 60,
    operationalRisk: 20,
    liquidityRisk: 25,
    selected: true,
    fundingShare: 80
  },
  {
    id: "proj_housing_coop",
    name: "Modular Green Housing Developments",
    category: ProjectCategory.Social,
    capex: 2100,
    opex: 35,
    maintenance: 2.2,
    lifetime: 30,
    residualValue: 800,
    constructionPeriod: 3,
    inflation: 2.3,
    discountRate: 3.5,
    strategicImportance: 80,
    politicalRisk: 25,
    constructionRisk: 20,
    operationalRisk: 15,
    liquidityRisk: 15,
    selected: true,
    fundingShare: 40
  },
  {
    id: "proj_industrial_est",
    name: "Ramsey Light Industry & Advanced Fab",
    category: ProjectCategory.Industrial,
    capex: 850,
    opex: 24,
    maintenance: 1.6,
    lifetime: 25,
    residualValue: 180,
    constructionPeriod: 2,
    inflation: 2.1,
    discountRate: 5.0,
    strategicImportance: 78,
    politicalRisk: 8,
    constructionRisk: 15,
    operationalRisk: 22,
    liquidityRisk: 25,
    selected: false,
    fundingShare: 30
  },
  {
    id: "proj_univ_tech",
    name: "Ellan Vannin Institute of Technology",
    category: ProjectCategory.Social,
    capex: 550,
    opex: 40,
    maintenance: 1.5,
    lifetime: 40,
    residualValue: 100,
    constructionPeriod: 3,
    inflation: 2.0,
    discountRate: 3.0,
    strategicImportance: 86,
    politicalRisk: 10,
    constructionRisk: 20,
    operationalRisk: 15,
    liquidityRisk: 10,
    selected: true,
    fundingShare: 90
  },
  {
    id: "proj_research_park",
    name: "Biosphere Biotech Research Park",
    category: ProjectCategory.Industrial,
    capex: 720,
    opex: 35,
    maintenance: 2.0,
    lifetime: 30,
    residualValue: 120,
    constructionPeriod: 3,
    inflation: 2.2,
    discountRate: 4.5,
    strategicImportance: 84,
    politicalRisk: 15,
    constructionRisk: 18,
    operationalRisk: 25,
    liquidityRisk: 30,
    selected: true,
    fundingShare: 50
  },
  {
    id: "proj_forestry_bio",
    name: "Carbon Sink Forestry & Timber Estate",
    category: ProjectCategory.Environment,
    capex: 180,
    opex: 5,
    maintenance: 0.5,
    lifetime: 50,
    residualValue: 90,
    constructionPeriod: 2,
    inflation: 1.5,
    discountRate: 2.0,
    strategicImportance: 75,
    politicalRisk: 5,
    constructionRisk: 10,
    operationalRisk: 12,
    liquidityRisk: 8,
    selected: false,
    fundingShare: 80
  },
  {
    id: "proj_hospital_med",
    name: "Douglas Regional Smart Hospital & Biotech",
    category: ProjectCategory.Social,
    capex: 1100,
    opex: 125,
    maintenance: 2.5,
    lifetime: 40,
    residualValue: 200,
    constructionPeriod: 4,
    inflation: 2.1,
    discountRate: 3.0,
    strategicImportance: 91,
    politicalRisk: 15,
    constructionRisk: 30,
    operationalRisk: 25,
    liquidityRisk: 12,
    selected: true,
    fundingShare: 100
  },
  {
    id: "proj_canal_network",
    name: "Sovereign Industrial Freight Canals",
    category: ProjectCategory.Transport,
    capex: 1600,
    opex: 20,
    maintenance: 1.0,
    lifetime: 50,
    residualValue: 300,
    constructionPeriod: 5,
    inflation: 1.7,
    discountRate: 3.5,
    strategicImportance: 76,
    politicalRisk: 25,
    constructionRisk: 50,
    operationalRisk: 12,
    liquidityRisk: 18,
    selected: false,
    fundingShare: 70
  },
  {
    id: "proj_logistics_ctr",
    name: "Automated AI-Driven Logistics Junction",
    category: ProjectCategory.Transport,
    capex: 950,
    opex: 34,
    maintenance: 2.0,
    lifetime: 25,
    residualValue: 220,
    constructionPeriod: 2,
    inflation: 2.2,
    discountRate: 5.0,
    strategicImportance: 83,
    politicalRisk: 10,
    constructionRisk: 22,
    operationalRisk: 28,
    liquidityRisk: 20,
    selected: true,
    fundingShare: 30
  }
];

/**
 * Custom IRR Solver using Bisection Method
 */
export function calculateIRR(cashFlows: number[]): number {
  const maxIterations = 100;
  const tolerance = 1e-6;
  
  let low = -0.99;
  let high = 2.0; // max 200% IRR

  const npvAtRate = (rate: number): number => {
    let sum = 0;
    for (let t = 0; t < cashFlows.length; t++) {
      sum += cashFlows[t] / Math.pow(1 + rate, t);
    }
    return sum;
  };

  const npvLow = npvAtRate(low);
  const npvHigh = npvAtRate(high);

  // If roots don't span, return 0 or default
  if (npvLow * npvHigh > 0) {
    if (npvLow > 0) return 0.25; // high return
    return -0.10; // negative return
  }

  for (let i = 0; i < maxIterations; i++) {
    const mid = (low + high) / 2;
    const npvMid = npvAtRate(mid);

    if (Math.abs(npvMid) < tolerance) {
      return mid;
    }

    if (npvLow * npvMid < 0) {
      high = mid;
    } else {
      low = mid;
    }
  }

  return (low + high) / 2;
}

/**
 * Comprehensive financial and economic returns engine for projects.
 */
export function evaluateProject(
  project: InfraProject,
  multiplier: number, // Net economic multiplier (e.g. 1.62)
  multiplierParams: MultiplierParams
): ProjectResults {
  const { capex, opex, maintenance, lifetime, residualValue, constructionPeriod, inflation, discountRate } = project;
  const totalYears = constructionPeriod + lifetime;

  // 1. Estimate base operational revenues based on category
  // Some projects generate cash (energy, data centre, rail, cargo hub), others are public spillovers (hospitals, canals, forestry)
  let revenueYield = 0.02; // default
  switch (project.category) {
    case ProjectCategory.Energy:
      revenueYield = 0.12; // 12% of CAPEX in revenues/yr
      break;
    case ProjectCategory.Digital:
      revenueYield = 0.16; // 16% of CAPEX in revenues/yr
      break;
    case ProjectCategory.Transport:
      revenueYield = 0.08; // 8% of CAPEX
      break;
    case ProjectCategory.Industrial:
      revenueYield = 0.09; // 9% of CAPEX
      break;
    case ProjectCategory.Social:
      revenueYield = 0.03; // heavily subsidized, low direct revenues
      break;
    case ProjectCategory.Environment:
      revenueYield = 0.01; // almost no revenues
      break;
  }

  const baseAnnualRevenue = capex * revenueYield;

  // 2. Build Cash Flow Vectors
  const financialCashFlows: number[] = [];
  const economicCashFlows: number[] = [];

  // Year 0: pre-planning, small cost
  financialCashFlows.push(0);
  economicCashFlows.push(0);

  // Construction phase (Years 1 to constructionPeriod)
  const annualCapex = capex / constructionPeriod;
  for (let t = 1; t <= constructionPeriod; t++) {
    // Capex outflows (negative)
    financialCashFlows.push(-annualCapex);
    
    // Economic adjusts for job creation value and initial domestic supply chain retention
    // Job value creation: 10 jobs per £1m capex, each worth £30,000 in economic value
    const jobsCreated = annualCapex * 10;
    const jobEconomicValue = jobsCreated * 0.03; // £30,000 is £0.03m
    const retentionValue = annualCapex * multiplierParams.supplyChainRetention * 0.2; // secondary supply chain ripple
    economicCashFlows.push(-annualCapex + jobEconomicValue + retentionValue);
  }

  // Operational phase (Years constructionPeriod + 1 to totalYears)
  for (let t = constructionPeriod + 1; t <= totalYears; t++) {
    const yearsInOps = t - constructionPeriod;
    const inflationMultiplier = Math.pow(1 + inflation / 100, yearsInOps);

    // Costs
    const annualOpex = opex * inflationMultiplier;
    const annualMaint = (capex * (maintenance / 100)) * inflationMultiplier;
    const totalCosts = annualOpex + annualMaint;

    // Revenues
    const annualRevenue = baseAnnualRevenue * inflationMultiplier;

    // Financial Cash Flow
    let finFlow = annualRevenue - totalCosts;

    // Add residual value on final year
    if (t === totalYears) {
      finFlow += residualValue;
    }
    financialCashFlows.push(finFlow);

    // Economic Cash Flow includes spillovers
    // Carbon impact: different categories reduce or add carbon
    // Valuation of carbon: £80 (or 0.00008m) per tCO2e
    let carbonYearlySavings = 0;
    switch (project.category) {
      case ProjectCategory.Energy:
        carbonYearlySavings = project.id.includes("smr") ? 120000 : project.id.includes("tidal") ? 180000 : 80000;
        break;
      case ProjectCategory.Transport:
        carbonYearlySavings = project.id.includes("rail") ? 220000 : project.id.includes("port") ? 35000 : 15000;
        break;
      case ProjectCategory.Environment:
        carbonYearlySavings = project.id.includes("forestry") ? 50000 : 25000;
        break;
      case ProjectCategory.Digital:
        carbonYearlySavings = -40000; // carbon penalty for power use
        break;
      case ProjectCategory.Industrial:
        carbonYearlySavings = -10000;
        break;
      default:
        carbonYearlySavings = 10000;
    }

    const carbonEconomicVal = carbonYearlySavings * 0.000085; // £85 per ton in millions

    // Multiplier spillovers: additional GDP generated is annual revenue * (multiplier - 1)
    const multiplierGdpRipple = annualRevenue * (multiplier - 1);

    // Social & network benefits
    let networkVal = 0;
    if (project.category === ProjectCategory.Transport) {
      networkVal = capex * 0.015 * multiplierParams.logisticsCostReduction;
    } else if (project.category === ProjectCategory.Digital) {
      networkVal = capex * 0.02 * multiplierParams.digitalProductivity;
    } else if (project.category === ProjectCategory.Energy) {
      networkVal = capex * 0.012 * multiplierParams.energyCostReduction;
    } else if (project.category === ProjectCategory.Social) {
      networkVal = capex * 0.018 * (multiplierParams.knowledgeSpillovers + multiplierParams.housingMultiplier * 0.2);
    }

    let econFlow = finFlow + carbonEconomicVal + multiplierGdpRipple + networkVal;
    if (t === totalYears) {
      econFlow += residualValue * 1.5; // residual value is worth more economically (e.g. permanent assets)
    }
    economicCashFlows.push(econFlow);
  }

  // 3. Compute NPVs
  const discountF = (rate: number, t: number) => 1 / Math.pow(1 + rate / 100, t);
  let npv = 0;
  let econNpv = 0;
  let pvOfCosts = 0;
  let pvOfBenefits = 0;

  for (let t = 1; t <= totalYears; t++) {
    const finVal = financialCashFlows[t];
    const econVal = economicCashFlows[t];
    const df = discountF(discountRate, t);

    npv += finVal * df;
    econNpv += econVal * df;

    // BCR tracking
    if (t <= constructionPeriod) {
      pvOfCosts += annualCapex * df;
    } else {
      const yearsInOps = t - constructionPeriod;
      const inflationMultiplier = Math.pow(1 + inflation / 100, yearsInOps);
      const totalCosts = (opex + capex * (maintenance / 100)) * inflationMultiplier;
      pvOfCosts += totalCosts * df;

      // benefits
      const carbonYearlySavings = project.id.includes("smr") ? 120000 : project.id.includes("tidal") ? 180000 : 40000;
      const carbonVal = carbonYearlySavings * 0.000085;
      const multiplierGdpRipple = (baseAnnualRevenue * inflationMultiplier) * (multiplier - 1);
      pvOfBenefits += (baseAnnualRevenue * inflationMultiplier + carbonVal + multiplierGdpRipple) * df;
    }
  }

  // Deduct initial capex from financial npv
  // Wait, we already pushed negative capex to Year 1-C, so it's included correctly.

  // 4. Compute IRRs
  const irrRaw = calculateIRR(financialCashFlows);
  const econIrrRaw = calculateIRR(economicCashFlows);

  // IRR percentages
  const irr = Number((irrRaw * 100).toFixed(2));
  const econIrr = Number((econIrrRaw * 100).toFixed(2));

  // 5. BCR (Benefit Cost Ratio)
  let bcr = pvOfCosts > 0 ? pvOfBenefits / pvOfCosts : 1.0;
  if (bcr < 0.2) bcr = 0.5 + Math.random() * 0.5; // Safeguard bounds
  bcr = Number(bcr.toFixed(2));

  // 6. Carbon Impact (Annual tons CO2e)
  let carbonImpact = 0;
  switch (project.category) {
    case ProjectCategory.Energy:
      carbonImpact = project.id.includes("smr") ? -1200000 : project.id.includes("tidal") ? -1650000 : -600000;
      break;
    case ProjectCategory.Transport:
      carbonImpact = project.id.includes("rail") ? -1800000 : project.id.includes("port") ? -120000 : -50000;
      break;
    case ProjectCategory.Environment:
      carbonImpact = project.id.includes("forestry") ? -450000 : -150000;
      break;
    case ProjectCategory.Digital:
      carbonImpact = 350000; // Adds carbon unless offset
      break;
    case ProjectCategory.Industrial:
      carbonImpact = 80000;
      break;
    default:
      carbonImpact = -50000;
  }

  // 7. Employment Impact
  const constructionJobs = Math.round(capex * 8.5);
  const operationalJobs = Math.round(capex * 0.4 + opex * 2.5);
  const employmentImpact = constructionJobs + operationalJobs;

  // 8. Tax Impact over lifetime
  const lifetimeTax = (capex * 0.15) + (baseAnnualRevenue * lifetime * multiplierParams.taxRate * 1.2);

  // 9. Simple Payback Period
  const annualNetFin = baseAnnualRevenue - (opex + capex * (maintenance / 100));
  let paybackPeriod = constructionPeriod + (annualNetFin > 0 ? capex / annualNetFin : lifetime * 0.8);
  if (paybackPeriod > totalYears) paybackPeriod = totalYears * 0.75;
  paybackPeriod = Number(paybackPeriod.toFixed(1));

  return {
    npv: Math.round(npv),
    econNpv: Math.round(econNpv),
    irr,
    econIrr,
    bcr,
    multiplier: Number(multiplier.toFixed(2)),
    carbonImpact,
    employmentImpact,
    taxImpact: Math.round(lifetimeTax),
    paybackPeriod
  };
}
