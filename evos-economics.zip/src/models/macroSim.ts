/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { EconomicSchool, InfraProject, MultiplierParams, MacroSimResults } from "../types";
import { evaluateProject } from "./projectModel";
import { calculateMultiplier } from "./multiplierEngine";

/**
 * Runs a multi-decade year-by-year simulation of the national economy based on selected projects.
 */
export function runMacroSimulation(
  selectedProjects: InfraProject[],
  school: EconomicSchool,
  multiplierParams: MultiplierParams,
  years: number = 30
): MacroSimResults[] {
  // 1. Set Initial Baseline (UK Scale scaled slightly)
  let gdp = 2400.0; // £ billions
  let inflation = 2.0; // %
  let population = 67.5; // million
  let employment = 33.2; // million
  let govDebt = 2450.0; // £ billions
  let infraStock = 1200.0; // £ billions (initial infrastructure value)
  let productivityGrowth = 1.2; // % base productivity growth rate
  let privateInvestment = 420.0; // £ billions
  let exports = 820.0; // £ billions
  let energyDemand = 320.0; // TWh
  let constructionOutput = 180.0; // £ billions
  let industrialProduction = 380.0; // £ billions

  const results: MacroSimResults[] = [];

  // Pre-calculate project evaluations to get their multipliers and impacts
  const evaluated = selectedProjects.map(proj => {
    // get custom multiplier for this specific school
    const multResults = calculateMultiplier(school, multiplierParams, proj.capex);
    const results = evaluateProject(proj, multResults.gdpMultiplier, multiplierParams);
    return {
      proj,
      results,
      multResults
    };
  });

  // Year 0 Baseline
  results.push({
    year: 0,
    gdp,
    inflation,
    population,
    employment,
    taxReceipts: gdp * multiplierParams.taxRate,
    govDebt,
    debtToGdp: (govDebt / gdp) * 100,
    infraDepreciation: infraStock * 0.025, // 2.5% depreciation
    infraStock,
    productivityGrowth,
    privateInvestment,
    exports,
    energyDemand,
    constructionOutput,
    industrialProduction
  });

  // 2. Year-by-Year Simulation Loop
  for (let y = 1; y <= years; y++) {
    // Natural baseline growths
    const basePopGrowth = 0.003; // +0.3% per year
    population = population * (1 + basePopGrowth);

    // Sum active construction capex and operational benefits in year y
    let activeCapexTotal = 0; // in £ billions
    let activeOpexTotal = 0; // in £ billions
    let activeRevenueTotal = 0; // in £ billions
    let carbonSavingsTotal = 0; // tCO2e
    let directJobsTotal = 0;
    let connectivitySpillover = 0;
    let energyBoost = 0;
    let logisticsEfficiency = 0;
    let exportSovereignBoost = 0;

    evaluated.forEach(({ proj, results, multResults }) => {
      // Construction Phase
      if (y <= proj.constructionPeriod) {
        const annualCapexM = proj.capex / proj.constructionPeriod;
        activeCapexTotal += annualCapexM / 1000.0; // convert to £ billions
        directJobsTotal += (annualCapexM * 8.5); // construction jobs
      } 
      // Operational Phase
      else if (y <= proj.constructionPeriod + proj.lifetime) {
        // OPEX + Maintenance
        const yearsInOps = y - proj.constructionPeriod;
        const operationalInflation = Math.pow(1 + proj.inflation / 100, yearsInOps);
        const annualOpexM = (proj.opex + proj.capex * (proj.maintenance / 100)) * operationalInflation;
        activeOpexTotal += annualOpexM / 1000.0;

        // Revenues
        // Estimated based on category
        let revenueYield = 0.05;
        if (proj.category === "Energy") revenueYield = 0.12;
        else if (proj.category === "Digital") revenueYield = 0.16;
        else if (proj.category === "Transport") revenueYield = 0.08;
        
        activeRevenueTotal += (proj.capex * revenueYield * operationalInflation) / 1000.0;
        carbonSavingsTotal += results.carbonImpact;
        directJobsTotal += (proj.capex * 0.4 + proj.opex * 2.5);

        // Network spillovers
        if (proj.category === "Digital") connectivitySpillover += 0.03 * multiplierParams.digitalProductivity;
        if (proj.category === "Energy") energyBoost += 0.04 * (1 - multiplierParams.energyCostReduction);
        if (proj.category === "Transport") logisticsEfficiency += 0.03 * multiplierParams.logisticsCostReduction;
        if (proj.id.includes("port") || proj.id.includes("airport") || proj.id.includes("logistics")) {
          exportSovereignBoost += 0.05 * multiplierParams.exportGrowth;
        }
      }
    });

    // Compute Multiplier Stimulus in Year y
    // Under Keynesian, direct public capex expands GDP strongly in current year.
    // Under Austrian/Classical, high capex drives crowding-out and higher debt interest.
    let capMultiplier = calculateMultiplier(school, multiplierParams, activeCapexTotal * 1000).gdpMultiplier;
    
    // Keynesian stimulus
    const demandStimulusGdp = activeCapexTotal * capMultiplier;

    // Infrastructure stock depreciation and additions
    const baseDeprRate = 0.025; // 2.5% default depreciation
    // Projects active maintenance offsets depreciation
    const maintOffset = Math.min(0.015, activeOpexTotal * 0.05); 
    const netDeprRate = Math.max(0.01, baseDeprRate - maintOffset);
    const infraDepreciation = infraStock * netDeprRate;

    infraStock = infraStock - infraDepreciation + activeCapexTotal;

    // Productivity growth matches infrastructural stock ratios (glowing network effects)
    const stockRatio = infraStock / 1200.0; // Relative to start
    const networkSpilloverProductivity = (connectivitySpillover + logisticsEfficiency + energyBoost) * 0.8;
    
    // Adjust productivity growth by school
    let schoolProductivityMult = 1.0;
    if (school === EconomicSchool.SupplySide || school === EconomicSchool.InfrastructureEconomics) {
      schoolProductivityMult = 1.35;
    } else if (school === EconomicSchool.Austrian) {
      schoolProductivityMult = 0.85; // Malinvestment frictional losses
    }

    productivityGrowth = Math.max(0.2, (1.1 + (stockRatio - 1) * 0.35 + networkSpilloverProductivity) * schoolProductivityMult);

    // Private Investment Crowded-In / Out
    const crowdingMultiplier = multiplierParams.crowdingIn - multiplierParams.crowdingOut;
    let pInvGrowth = 0.015; // baseline private investment growth
    if (activeCapexTotal > 0) {
      pInvGrowth += (activeCapexTotal * crowdingMultiplier * 0.05);
    }
    // High government debt dampens private investment under Classical/Austrian
    if (school === EconomicSchool.Classical || school === EconomicSchool.Austrian) {
      const debtRatio = govDebt / gdp;
      if (debtRatio > 1.1) {
        pInvGrowth -= (debtRatio - 1.1) * 0.08;
      }
    }
    privateInvestment = Math.max(100.0, privateInvestment * (1 + pInvGrowth));

    // GDP Growth Transition
    // Real GDP growth is driven by productivity growth, labor growth, and demand shocks
    const laborGrowthRate = 0.002 + (activeCapexTotal > 0 ? 0.001 : 0);
    const supplySideGdpGrowth = (productivityGrowth / 100.0) + laborGrowthRate;

    let previousGdp = gdp;
    // Current year real GDP before stimulus shock
    gdp = gdp * (1 + supplySideGdpGrowth) + demandStimulusGdp * 0.3; 

    // Inflation Model
    // Driven by money speed, debt growth, and cost-reductions from energy/logistics
    let inflationPressure = (gdp - previousGdp) / previousGdp * 15.0 - (energyBoost + logisticsEfficiency) * 8.0;
    if (school === EconomicSchool.Austrian || school === EconomicSchool.PostKeynesian) {
      // Austrian links high government debt and spending to credit inflation
      const debtIncreaseRatio = (govDebt / previousGdp) * 0.015;
      inflationPressure += debtIncreaseRatio * 1.5;
    }
    inflation = Math.max(-0.5, Math.min(12.0, 1.8 + inflationPressure));

    // Employment
    // Elastic with GDP growth and public project creation
    const empElasticity = 0.45;
    const gdpGrowthRate = (gdp - previousGdp) / previousGdp;
    const baselineEmpChange = employment * gdpGrowthRate * empElasticity;
    const directEmpChangeMil = directJobsTotal / 1000000.0; // Convert to millions
    employment = Math.min(population * 0.82, employment + baselineEmpChange + directEmpChangeMil * 0.4);

    // Tax Receipts
    const nominalGdp = gdp * Math.pow(1 + inflation / 100, y);
    // widening tax base from digital and structural efficiency
    const dynamicTaxRate = multiplierParams.taxRate + (connectivitySpillover * 0.02);
    const taxReceipts = gdp * dynamicTaxRate;

    // Government Debt Accumulation
    // public funding share is funded by state borrowing (or SWF deployment)
    const publicInvestmentCapex = activeCapexTotal * 0.7; // assuming 70% public funded on average
    const govInterestRate = 0.035 + (inflation > 4.0 ? (inflation - 4.0) * 0.3 : 0);
    const debtInterestCost = govDebt * govInterestRate;
    const otherPublicSpending = gdp * 0.32; // education, welfare, health baseline

    govDebt = govDebt + debtInterestCost + publicInvestmentCapex + otherPublicSpending - taxReceipts;
    if (govDebt < 100) govDebt = 100; // lower bound

    // Secondary sectoral outputs
    exports = exports * (1 + 0.012 + exportSovereignBoost * 0.5) + (activeRevenueTotal * 0.1);
    energyDemand = Math.max(50.0, energyDemand * (1 + gdpGrowthRate * 0.6) - (energyBoost * 12.0));
    constructionOutput = 150.0 + (activeCapexTotal * 1.2) + (gdp * 0.015);
    industrialProduction = industrialProduction * (1 + gdpGrowthRate * 0.8 + logisticsEfficiency * 0.4);

    results.push({
      year: y,
      gdp: Number(gdp.toFixed(2)),
      inflation: Number(inflation.toFixed(2)),
      population: Number(population.toFixed(2)),
      employment: Number(employment.toFixed(2)),
      taxReceipts: Number(taxReceipts.toFixed(2)),
      govDebt: Number(govDebt.toFixed(2)),
      debtToGdp: Number(((govDebt / gdp) * 100).toFixed(1)),
      infraDepreciation: Number(infraDepreciation.toFixed(2)),
      infraStock: Number(infraStock.toFixed(2)),
      productivityGrowth: Number(productivityGrowth.toFixed(2)),
      privateInvestment: Number(privateInvestment.toFixed(2)),
      exports: Number(exports.toFixed(2)),
      energyDemand: Number(energyDemand.toFixed(2)),
      constructionOutput: Number(constructionOutput.toFixed(2)),
      industrialProduction: Number(industrialProduction.toFixed(2))
    });
  }

  return results;
}
