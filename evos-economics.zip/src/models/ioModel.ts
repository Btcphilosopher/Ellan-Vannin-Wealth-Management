/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { IndustryIo } from "../types";

export const initialIndustries: IndustryIo[] = [
  {
    id: "ind_construction",
    name: "Construction Services",
    directEffect: 1.0,
    indirectEffect: 0.62,
    inducedEffect: 0.45,
    supplyChainEffect: 0.38,
    steelInput: 0.18,
    concreteInput: 0.22,
    energyInput: 0.08,
    softwareInput: 0.05,
    engineeringInput: 0.15
  },
  {
    id: "ind_steel",
    name: "Metallurgy & Steel Alloys",
    directEffect: 0.85,
    indirectEffect: 0.78,
    inducedEffect: 0.32,
    supplyChainEffect: 0.55,
    steelInput: 0.10,
    concreteInput: 0.02,
    energyInput: 0.30,
    softwareInput: 0.04,
    engineeringInput: 0.12
  },
  {
    id: "ind_concrete",
    name: "Cement, Aggregates & Concrete",
    directEffect: 0.90,
    indirectEffect: 0.58,
    inducedEffect: 0.28,
    supplyChainEffect: 0.42,
    steelInput: 0.02,
    concreteInput: 0.08,
    energyInput: 0.28,
    softwareInput: 0.02,
    engineeringInput: 0.06
  },
  {
    id: "ind_engineering",
    name: "Heavy Precision Engineering",
    directEffect: 0.95,
    indirectEffect: 0.70,
    inducedEffect: 0.48,
    supplyChainEffect: 0.46,
    steelInput: 0.25,
    concreteInput: 0.03,
    energyInput: 0.12,
    softwareInput: 0.12,
    engineeringInput: 0.08
  },
  {
    id: "ind_agriculture",
    name: "Agriculture, Forestry & Fisheries",
    directEffect: 0.45,
    indirectEffect: 0.32,
    inducedEffect: 0.40,
    supplyChainEffect: 0.20,
    steelInput: 0.01,
    concreteInput: 0.01,
    energyInput: 0.15,
    softwareInput: 0.03,
    engineeringInput: 0.05
  },
  {
    id: "ind_energy",
    name: "Electricity, SMR & Grid Power",
    directEffect: 0.70,
    indirectEffect: 0.82,
    inducedEffect: 0.25,
    supplyChainEffect: 0.65,
    steelInput: 0.05,
    concreteInput: 0.03,
    energyInput: 0.05,
    softwareInput: 0.08,
    engineeringInput: 0.14
  },
  {
    id: "ind_software",
    name: "Software & Sovereign AI Systems",
    directEffect: 0.55,
    indirectEffect: 0.40,
    inducedEffect: 0.65,
    supplyChainEffect: 0.30,
    steelInput: 0.00,
    concreteInput: 0.00,
    energyInput: 0.18,
    softwareInput: 0.10,
    engineeringInput: 0.08
  },
  {
    id: "ind_transport",
    name: "Logistics, Rail & Freight Transport",
    directEffect: 0.75,
    indirectEffect: 0.65,
    inducedEffect: 0.50,
    supplyChainEffect: 0.35,
    steelInput: 0.08,
    concreteInput: 0.04,
    energyInput: 0.22,
    softwareInput: 0.07,
    engineeringInput: 0.10
  },
  {
    id: "ind_manufacturing",
    name: "Advanced Electronics & Assembly",
    directEffect: 0.80,
    indirectEffect: 0.72,
    inducedEffect: 0.42,
    supplyChainEffect: 0.48,
    steelInput: 0.12,
    concreteInput: 0.01,
    energyInput: 0.16,
    softwareInput: 0.14,
    engineeringInput: 0.18
  },
  {
    id: "ind_healthcare",
    name: "Clinical Healthcare & MedTech",
    directEffect: 0.40,
    indirectEffect: 0.28,
    inducedEffect: 0.58,
    supplyChainEffect: 0.18,
    steelInput: 0.00,
    concreteInput: 0.00,
    energyInput: 0.06,
    softwareInput: 0.12,
    engineeringInput: 0.04
  },
  {
    id: "ind_education",
    name: "Higher Education & Research",
    directEffect: 0.35,
    indirectEffect: 0.24,
    inducedEffect: 0.60,
    supplyChainEffect: 0.15,
    steelInput: 0.00,
    concreteInput: 0.00,
    energyInput: 0.05,
    softwareInput: 0.08,
    engineeringInput: 0.02
  },
  {
    id: "ind_finance",
    name: "Sovereign Banking & Treasury",
    directEffect: 0.50,
    indirectEffect: 0.45,
    inducedEffect: 0.55,
    supplyChainEffect: 0.32,
    steelInput: 0.00,
    concreteInput: 0.00,
    energyInput: 0.04,
    softwareInput: 0.15,
    engineeringInput: 0.01
  },
  {
    id: "ind_tourism",
    name: "Maritime Tourism & Hospitality",
    directEffect: 0.42,
    indirectEffect: 0.30,
    inducedEffect: 0.52,
    supplyChainEffect: 0.18,
    steelInput: 0.01,
    concreteInput: 0.01,
    energyInput: 0.10,
    softwareInput: 0.04,
    engineeringInput: 0.02
  },
  {
    id: "ind_retail",
    name: "High Street & Digital Retail",
    directEffect: 0.38,
    indirectEffect: 0.25,
    inducedEffect: 0.58,
    supplyChainEffect: 0.16,
    steelInput: 0.00,
    concreteInput: 0.00,
    energyInput: 0.08,
    softwareInput: 0.06,
    engineeringInput: 0.01
  }
];

export interface SectorRipple {
  sector: string;
  direct: number;
  indirect: number;
  induced: number;
  supplyChain: number;
  total: number;
}

/**
 * Computes Leontief multipliers dynamically based on project categories.
 * shockMap maps sector IDs to initial shock amounts in £ millions.
 */
export function calculateLeontiefRipples(
  shockMap: Record<string, number>
): SectorRipple[] {
  // Convert initial industries to matrix representations
  const sectorCount = initialIndustries.length;
  const sectorIds = initialIndustries.map(ind => ind.id);

  // Initialize Final Demand vector Y
  const Y = new Array(sectorCount).fill(0);
  for (let i = 0; i < sectorCount; i++) {
    const sId = sectorIds[i];
    Y[i] = shockMap[sId] || 0;
  }

  // Build direct requirement matrix A
  // A[i][j] represents input from industry i required per unit of output of industry j
  const A = Array.from({ length: sectorCount }, () => new Array(sectorCount).fill(0.02)); // baseline inter-industry interaction

  // Enrich matrix A using specific inputs defined in initialIndustries
  for (let j = 0; j < sectorCount; j++) {
    const ind = initialIndustries[j];
    
    // Map specific input rows
    const steelRow = sectorIds.indexOf("ind_steel");
    const concreteRow = sectorIds.indexOf("ind_concrete");
    const energyRow = sectorIds.indexOf("ind_energy");
    const softwareRow = sectorIds.indexOf("ind_software");
    const engRow = sectorIds.indexOf("ind_engineering");

    if (steelRow !== -1) A[steelRow][j] = ind.steelInput;
    if (concreteRow !== -1) A[concreteRow][j] = ind.concreteInput;
    if (energyRow !== -1) A[energyRow][j] = ind.energyInput;
    if (softwareRow !== -1) A[softwareRow][j] = ind.softwareInput;
    if (engRow !== -1) A[engRow][j] = ind.engineeringInput;
  }

  // Solve Leontief series: output X = (I - A)^-1 * Y
  // We approximate using Neumann series expansion: X = Y + A*Y + A^2*Y + A^3*Y + A^4*Y...
  // This nicely matches the economic concepts of direct, indirect, induced, and supply chain.

  // Direct effect: The initial shock Y
  const directOutput = [...Y];

  // Indirect effect: A * Y (suppliers buying inputs)
  const indirectOutput = new Array(sectorCount).fill(0);
  for (let i = 0; i < sectorCount; i++) {
    for (let j = 0; j < sectorCount; j++) {
      indirectOutput[i] += A[i][j] * Y[j];
    }
  }

  // Supply-chain effects: A^2 * Y + A^3 * Y (deep loops)
  const supplyChainOutput = new Array(sectorCount).fill(0);
  let currentShock = [...indirectOutput];
  for (let step = 0; step < 3; step++) {
    const nextShock = new Array(sectorCount).fill(0);
    for (let i = 0; i < sectorCount; i++) {
      for (let j = 0; j < sectorCount; j++) {
        nextShock[i] += A[i][j] * currentShock[j];
      }
    }
    for (let i = 0; i < sectorCount; i++) {
      supplyChainOutput[i] += nextShock[i];
    }
    currentShock = [...nextShock];
  }

  // Induced effect: Consumer spend triggered by wages
  // Modeled as a fraction of total direct/indirect outputs, weighted by industry-specific labor shares
  const inducedOutput = new Array(sectorCount).fill(0);
  for (let i = 0; i < sectorCount; i++) {
    const ind = initialIndustries[i];
    const inducedMultiplier = ind.inducedEffect * 0.35; // scaled down to maintain conservation of money
    for (let j = 0; j < sectorCount; j++) {
      inducedOutput[i] += (directOutput[j] + indirectOutput[j] + supplyChainOutput[j]) * inducedMultiplier * A[i][j] * 0.4;
    }
    // High induced effects on retail, healthcare, agriculture, tourism
    if (["ind_retail", "ind_tourism", "ind_agriculture", "ind_healthcare"].includes(ind.id)) {
      const sumShock = Y.reduce((a, b) => a + b, 0);
      inducedOutput[i] += sumShock * ind.inducedEffect * 0.12;
    }
  }

  // Package results
  const results: SectorRipple[] = [];
  for (let i = 0; i < sectorCount; i++) {
    const ind = initialIndustries[i];
    const dir = directOutput[i];
    const indr = indirectOutput[i];
    const sc = supplyChainOutput[i];
    const indc = inducedOutput[i];
    const total = dir + indr + sc + indc;

    results.push({
      sector: ind.name,
      direct: Number(dir.toFixed(2)),
      indirect: Number(indr.toFixed(2)),
      induced: Number(indc.toFixed(2)),
      supplyChain: Number(sc.toFixed(2)),
      total: Number(total.toFixed(2))
    });
  }

  return results;
}
