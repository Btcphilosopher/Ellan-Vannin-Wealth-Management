/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { CountyMetrics } from "../types";

export const initialCounties: CountyMetrics[] = [
  {
    id: "reg_iom",
    name: "Isle of Man (Ellan Vannin)",
    gdp: 5.4, // £bn
    population: 85, // thousands
    employment: 44, // thousands
    avgWage: 43200, // £/yr
    productivity: 41.5, // £/hr
    electricityCost: 26.5, // p/kWh
    infraQuality: 68,
    connectivity: 55,
    investmentRequired: 1800, // £m
    historicInvestment: 420,
    privateSectorActivity: 74,
    expectedIrr: 14.2,
    expectedGdpGrowth: 3.4,
    coordinates: [45, 45] // Center-West
  },
  {
    id: "reg_london",
    name: "Greater London Authority",
    gdp: 503.2,
    population: 8960,
    employment: 5200,
    avgWage: 58500,
    productivity: 64.8,
    electricityCost: 18.2,
    infraQuality: 92,
    connectivity: 96,
    investmentRequired: 35000,
    historicInvestment: 18500,
    privateSectorActivity: 95,
    expectedIrr: 8.5,
    expectedGdpGrowth: 1.8,
    coordinates: [70, 78] // Southeast
  },
  {
    id: "reg_scotland",
    name: "Caledonia & Highlands (Scotland)",
    gdp: 182.5,
    population: 5460,
    employment: 2650,
    avgWage: 34200,
    productivity: 38.2,
    electricityCost: 19.8,
    infraQuality: 74,
    connectivity: 65,
    investmentRequired: 14500,
    historicInvestment: 5200,
    privateSectorActivity: 68,
    expectedIrr: 11.8,
    expectedGdpGrowth: 2.5,
    coordinates: [45, 15] // North
  },
  {
    id: "reg_northwest",
    name: "North West England & Mersey",
    gdp: 215.8,
    population: 7340,
    employment: 3520,
    avgWage: 31800,
    productivity: 35.5,
    electricityCost: 21.0,
    infraQuality: 76,
    connectivity: 82,
    investmentRequired: 11200,
    historicInvestment: 4100,
    privateSectorActivity: 72,
    expectedIrr: 12.5,
    expectedGdpGrowth: 2.8,
    coordinates: [48, 52] // Mid-North
  },
  {
    id: "reg_nireland",
    name: "Northern Ireland",
    gdp: 48.2,
    population: 1890,
    employment: 860,
    avgWage: 29500,
    productivity: 31.2,
    electricityCost: 24.5,
    infraQuality: 62,
    connectivity: 58,
    investmentRequired: 5800,
    historicInvestment: 1200,
    privateSectorActivity: 55,
    expectedIrr: 13.0,
    expectedGdpGrowth: 2.1,
    coordinates: [25, 42] // Far West
  },
  {
    id: "reg_wales",
    name: "Wales & Severn Basin",
    gdp: 79.5,
    population: 3150,
    employment: 1420,
    avgWage: 29800,
    productivity: 30.8,
    electricityCost: 22.4,
    infraQuality: 68,
    connectivity: 64,
    investmentRequired: 8400,
    historicInvestment: 1900,
    privateSectorActivity: 61,
    expectedIrr: 13.5,
    expectedGdpGrowth: 2.2,
    coordinates: [38, 70] // Southwest-Mid
  },
  {
    id: "reg_midlands",
    name: "West Midlands & Industrial Core",
    gdp: 154.2,
    population: 5930,
    employment: 2780,
    avgWage: 32400,
    productivity: 34.8,
    electricityCost: 19.5,
    infraQuality: 80,
    connectivity: 85,
    investmentRequired: 9800,
    historicInvestment: 3500,
    privateSectorActivity: 78,
    expectedIrr: 10.2,
    expectedGdpGrowth: 2.4,
    coordinates: [54, 66] // Center
  },
  {
    id: "reg_yorkshire",
    name: "Yorkshire & Humber Basin",
    gdp: 132.8,
    population: 5430,
    employment: 2510,
    avgWage: 30500,
    productivity: 32.6,
    electricityCost: 20.2,
    infraQuality: 72,
    connectivity: 75,
    investmentRequired: 8900,
    historicInvestment: 2600,
    privateSectorActivity: 66,
    expectedIrr: 11.5,
    expectedGdpGrowth: 2.3,
    coordinates: [58, 54] // Mid-East
  },
  {
    id: "reg_southwest",
    name: "South West & Western Peninsula",
    gdp: 142.1,
    population: 5650,
    employment: 2680,
    avgWage: 31200,
    productivity: 33.5,
    electricityCost: 21.8,
    infraQuality: 70,
    connectivity: 68,
    investmentRequired: 10500,
    historicInvestment: 2800,
    privateSectorActivity: 70,
    expectedIrr: 12.0,
    expectedGdpGrowth: 2.6,
    coordinates: [30, 84] // Southwest tip
  },
  {
    id: "reg_east",
    name: "East of England & Tech Fens",
    gdp: 172.5,
    population: 6240,
    employment: 3020,
    avgWage: 36500,
    productivity: 40.2,
    electricityCost: 18.5,
    infraQuality: 82,
    connectivity: 80,
    investmentRequired: 7800,
    historicInvestment: 3900,
    privateSectorActivity: 84,
    expectedIrr: 10.8,
    expectedGdpGrowth: 2.9,
    coordinates: [72, 68] // East
  }
];

export enum HeatmapMode {
  InvestmentOpportunity = "Investment Opportunity",
  Productivity = "Labor Productivity",
  TaxGeneration = "Tax Generation Potentials",
  EconomicOutput = "Sovereign GDP Size",
  InfrastructureGaps = "Infrastructure Deficits"
}

/**
 * Normalizes a metric for a county across the dataset into a 0-1 range
 * to represent heatmap intensity.
 */
export function getMetricIntensity(
  county: CountyMetrics,
  mode: HeatmapMode,
  allCounties: CountyMetrics[]
): number {
  let val = 0;
  
  switch (mode) {
    case HeatmapMode.InvestmentOpportunity:
      // High expected IRR + High required investment relative to historic investment
      val = county.expectedIrr * (county.investmentRequired / (county.historicInvestment || 1));
      break;
    case HeatmapMode.Productivity:
      val = county.productivity;
      break;
    case HeatmapMode.TaxGeneration:
      // Approximated by GDP * taxRate potential (higher wages & private sector activity)
      val = county.gdp * (county.privateSectorActivity / 100);
      break;
    case HeatmapMode.EconomicOutput:
      val = county.gdp;
      break;
    case HeatmapMode.InfrastructureGaps:
      // High investment required, low infraQuality index
      val = county.investmentRequired * (100 - county.infraQuality);
      break;
  }

  const values = allCounties.map(c => {
    switch (mode) {
      case HeatmapMode.InvestmentOpportunity:
        return c.expectedIrr * (c.investmentRequired / (c.historicInvestment || 1));
      case HeatmapMode.Productivity:
        return c.productivity;
      case HeatmapMode.TaxGeneration:
        return c.gdp * (c.privateSectorActivity / 100);
      case HeatmapMode.EconomicOutput:
        return c.gdp;
      case HeatmapMode.InfrastructureGaps:
        return c.investmentRequired * (100 - c.infraQuality);
    }
  });

  const min = Math.min(...values);
  const max = Math.max(...values);
  const range = max - min || 1;

  // logarithmic scaling for GDP to avoid London completely drowning out others
  if (mode === HeatmapMode.EconomicOutput || mode === HeatmapMode.TaxGeneration) {
    const logMin = Math.log(min + 1);
    const logMax = Math.log(max + 1);
    const logVal = Math.log(val + 1);
    return (logVal - logMin) / (logMax - logMin || 1);
  }

  return (val - min) / range;
}
