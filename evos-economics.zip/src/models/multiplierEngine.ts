/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { EconomicSchool, MultiplierParams } from "../types";

// Default multiplier parameters
export const defaultMultiplierParams: MultiplierParams = {
  mpc: 0.65,
  mps: 0.15,
  taxRate: 0.28,
  importLeakage: 0.22,
  supplyChainRetention: 0.75,
  regionalLeakage: 0.30,
  investmentVelocity: 0.70,
  labourParticipation: 0.78,
  capitalProductivity: 0.35,
  infraEfficiency: 0.82,
  constructionProductivity: 0.68,
  crowdingIn: 1.25,
  crowdingOut: 0.15,
  housingMultiplier: 1.40,
  innovationSpillovers: 0.45,
  agglomerationEffects: 0.50,
  knowledgeSpillovers: 0.40,
  exportGrowth: 0.32,
  energyCostReduction: 0.40,
  logisticsCostReduction: 0.45,
  digitalProductivity: 0.55
};

export interface MultiplierBreakdown {
  gdpMultiplier: number;
  privateCrowdedIn: number;
  netRegionalMultiplier: number;
  longTermProductivityGains: number;
  totalGdpImpact: number; // For a standardized £100m investment
  jobsCreatedPer100m: number;
  householdIncomeIncrease: number;
  corporateProfitsIncrease: number;
  govRevenueIncrease: number;
  debtSustainabilityIndex: number; // scale of 0-100 (high is better)
}

/**
 * Calculates the infrastructure multiplier based on the economic framework and input parameters.
 */
export function calculateMultiplier(
  school: EconomicSchool,
  params: MultiplierParams,
  investmentAmount: number // in £ millions
): MultiplierBreakdown {
  // 1. Core Demand-Side (Keynesian) Multiplier
  // Standard formula: 1 / (1 - MPC * (1 - taxRate) + ImportLeakage)
  const baseKeynesian = 1 / (1 - params.mpc * (1 - params.taxRate) + params.importLeakage);
  
  // 2. Supply-Side Spillover Multiplier
  const supplySideSpillovers = 
    params.capitalProductivity * params.infraEfficiency * (
      params.innovationSpillovers + 
      params.agglomerationEffects + 
      params.knowledgeSpillovers +
      params.digitalProductivity
    );

  // Adjust factors based on chosen Economic School
  let demandMultiplier = baseKeynesian;
  let supplySpillovers = supplySideSpillovers;
  let crowdingInFactor = params.crowdingIn;
  let crowdingOutFactor = params.crowdingOut;
  let efficiencyLoss = 1 - params.infraEfficiency;

  switch (school) {
    case EconomicSchool.Classical:
      // Classical theory rejects consumption multipliers; focus purely on supply capacity, labor, and capital
      demandMultiplier = 0.5 + (params.capitalProductivity * 0.4); 
      supplySpillovers = supplySideSpillovers * 1.5;
      crowdingInFactor = params.crowdingIn * 0.5;
      crowdingOutFactor = params.crowdingOut * 2.0; // High crowding out (competitve credit)
      break;

    case EconomicSchool.Keynesian:
      // Pure Keynesian: Focus on MPC, consumption loop, high crowding in, minimal crowding out
      demandMultiplier = baseKeynesian * 1.2;
      supplySpillovers = supplySideSpillovers * 0.7;
      crowdingInFactor = params.crowdingIn * 1.3;
      crowdingOutFactor = params.crowdingOut * 0.3;
      break;

    case EconomicSchool.NeoKeynesian:
      // Neo-Keynesian: Balance demand & supply. Sticky prices mean demand matters short term, capacity matters long term
      demandMultiplier = baseKeynesian * 1.0;
      supplySpillovers = supplySideSpillovers * 1.1;
      crowdingInFactor = params.crowdingIn * 1.1;
      crowdingOutFactor = params.crowdingOut * 0.8;
      break;

    case EconomicSchool.PostKeynesian:
      // Post-Keynesian: Focus on endogeneous money, strong demand loops, highly responsive corporate profits and wages
      demandMultiplier = baseKeynesian * 1.4;
      supplySpillovers = supplySideSpillovers * 0.8;
      crowdingInFactor = params.crowdingIn * 1.6;
      crowdingOutFactor = params.crowdingOut * 0.1;
      break;

    case EconomicSchool.Austrian:
      // Austrian theory: Public spending misallocates credit ("malinvestment"). Multiplier is heavily discounted.
      // High inflation risk.
      demandMultiplier = 0.3; 
      supplySpillovers = supplySideSpillovers * 0.9; // Spillovers still exist but are private-led
      crowdingInFactor = params.crowdingIn * 0.2;
      crowdingOutFactor = params.crowdingOut * 2.5; // Massive crowding out of private enterprise
      break;

    case EconomicSchool.SupplySide:
      // Supply-Side: Focus on incentives, productivity, cost reductions, tax base widening
      demandMultiplier = 0.6;
      supplySpillovers = supplySideSpillovers * 1.8;
      crowdingInFactor = params.crowdingIn * 0.9;
      crowdingOutFactor = params.crowdingOut * 1.2;
      break;

    case EconomicSchool.InfrastructureEconomics:
      // Infrastructure Economics: Emphasizes network effects, logistics, and digital cost-reductions
      demandMultiplier = baseKeynesian * 0.9;
      supplySpillovers = (
        supplySideSpillovers + 
        params.logisticsCostReduction * 0.8 + 
        params.energyCostReduction * 0.8
      ) * 1.3;
      crowdingInFactor = params.crowdingIn * 1.4;
      crowdingOutFactor = params.crowdingOut * 0.5;
      break;

    case EconomicSchool.DevelopmentEconomics:
      // Development Economics: Structural transformations, labor mobilization, supply-chain localization
      demandMultiplier = baseKeynesian * 1.1;
      supplySpillovers = (
        supplySideSpillovers + 
        params.labourParticipation * 0.6
      ) * 1.4;
      crowdingInFactor = params.crowdingIn * 1.5;
      crowdingOutFactor = params.crowdingOut * 0.4;
      break;
  }

  // Calculate Net Multiplier
  // Gdp Multiplier combines demand response with supply-side spillovers, adjusted for crowding-in/out
  const grossMultiplier = demandMultiplier + supplySpillovers + (crowdingInFactor * 0.4);
  const netMultiplier = Math.max(0.2, grossMultiplier - (crowdingOutFactor * 0.5) - (efficiencyLoss * 0.3));

  // Spillover multiplier specific to local region
  const netRegionalMultiplier = netMultiplier * (1 - params.regionalLeakage);

  // Private Investment Crowded-In (£m)
  const privateCrowdedIn = investmentAmount * Math.max(0, crowdingInFactor - crowdingOutFactor);

  // Long-Term Productivity gains index (0-100)
  const longTermProductivityGains = (supplySpillovers * 40) + (params.digitalProductivity * 20);

  // Total GDP impact (£ millions)
  const totalGdpImpact = investmentAmount * netMultiplier;

  // Secondary metrics
  const jobsCreatedPer100m = Math.round(
    1450 * params.constructionProductivity * (1 + params.labourParticipation) * (netMultiplier / 1.5)
  );

  const householdIncomeIncrease = totalGdpImpact * params.mpc * 0.6;
  const corporateProfitsIncrease = totalGdpImpact * (1 - params.mpc) * 0.45;
  const govRevenueIncrease = totalGdpImpact * params.taxRate + (corporateProfitsIncrease * 0.19);
  
  // Debt sustainability calculation
  // Sustainable if GDP generated far exceeds the cost, creating tax revenues that amortize the debt
  const selfFinancingRatio = govRevenueIncrease / investmentAmount;
  const debtSustainabilityIndex = Math.min(100, Math.round(selfFinancingRatio * 75 + (longTermProductivityGains * 0.25)));

  return {
    gdpMultiplier: Number(netMultiplier.toFixed(3)),
    privateCrowdedIn: Number(privateCrowdedIn.toFixed(2)),
    netRegionalMultiplier: Number(netRegionalMultiplier.toFixed(3)),
    longTermProductivityGains: Number(longTermProductivityGains.toFixed(1)),
    totalGdpImpact: Number(totalGdpImpact.toFixed(2)),
    jobsCreatedPer100m,
    householdIncomeIncrease: Number(householdIncomeIncrease.toFixed(2)),
    corporateProfitsIncrease: Number(corporateProfitsIncrease.toFixed(2)),
    govRevenueIncrease: Number(govRevenueIncrease.toFixed(2)),
    debtSustainabilityIndex
  };
}
