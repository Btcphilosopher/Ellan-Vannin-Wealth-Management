/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { EconomicSchool, InfraProject, MultiplierParams, MonteCarloSummary, Scenario } from "../types";
import { calculateMultiplier } from "./multiplierEngine";
import { evaluateProject } from "./projectModel";

export const preDefinedScenarios: Scenario[] = [
  {
    name: "Central Baseline Case",
    description: "Standard economic assumptions with average domestic growth, low volatility, and normal supply-chain retention.",
    mpcModifier: 1.0,
    crowdingInModifier: 1.0,
    capexModifier: 1.0,
    inflationModifier: 0.0,
    leakageModifier: 1.0
  },
  {
    name: "Sovereign Growth (Best Case)",
    description: "High domestic supply chain retention, robust consumption multipliers, high private investment crowding-in, and 10% capex savings.",
    mpcModifier: 1.15,
    crowdingInModifier: 1.35,
    capexModifier: 0.90,
    inflationModifier: -0.5,
    leakageModifier: 0.70 // less leakage
  },
  {
    name: "Systemic Supply-Chain Crisis (Worst Case)",
    description: "Severe cost overruns (+30% CAPEX), structural material shortages, severe import leakage, high local inflation, and private sector crowding-out.",
    mpcModifier: 0.75,
    crowdingInModifier: 0.50,
    capexModifier: 1.30,
    inflationModifier: 2.5,
    leakageModifier: 1.40 // more leakage
  },
  {
    name: "Decarbonised Green Leap",
    description: "Surging carbon credits valuation (£150/ton), massive green energy spillovers, high innovation, and strong sovereign multiplier effects.",
    mpcModifier: 1.05,
    crowdingInModifier: 1.20,
    capexModifier: 1.05,
    inflationModifier: 0.2,
    leakageModifier: 0.90
  },
  {
    name: "Austere Stagflation Stress",
    description: "High interest rates, low consumer spending (low MPC), severe crowding-out, rising construction inflation, and depressed infrastructure productivity.",
    mpcModifier: 0.80,
    crowdingInModifier: 0.40,
    capexModifier: 1.15,
    inflationModifier: 3.5,
    leakageModifier: 1.20
  }
];

/**
 * Box-Muller transform to generate normally distributed random numbers.
 */
function randomNormal(mean: number, stdDev: number): number {
  let u = 0, v = 0;
  while (u === 0) u = Math.random(); // Converting [0,1) to (0,1)
  while (v === 0) v = Math.random();
  const num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return num * stdDev + mean;
}

/**
 * Performs a stochastic Monte Carlo simulation across the portfolio.
 */
export function runMonteCarlo(
  selectedProjects: InfraProject[],
  school: EconomicSchool,
  baselineParams: MultiplierParams,
  iterations: number = 250
): MonteCarloSummary {
  const gdpOutputs: number[] = [];
  const irrOutputs: number[] = [];

  const totalCapex = selectedProjects.reduce((sum, p) => sum + (p.selected ? p.capex : 0), 0);

  for (let iter = 0; iter < iterations; iter++) {
    // 1. Shock Multiplier Parameters
    const mpcShock = Math.max(0.3, Math.min(0.95, randomNormal(baselineParams.mpc, 0.06)));
    const leakageShock = Math.max(0.05, Math.min(0.6, randomNormal(baselineParams.importLeakage, 0.05)));
    const crowdInShock = Math.max(0.2, Math.min(2.5, randomNormal(baselineParams.crowdingIn, 0.15)));
    const crowdOutShock = Math.max(0.0, Math.min(1.0, randomNormal(baselineParams.crowdingOut, 0.08)));

    const shockedParams: MultiplierParams = {
      ...baselineParams,
      mpc: mpcShock,
      importLeakage: leakageShock,
      crowdingIn: crowdInShock,
      crowdingOut: crowdOutShock
    };

    // Calculate multiplier for this run
    const testMultiplier = calculateMultiplier(school, shockedParams, totalCapex || 100).gdpMultiplier;

    // 2. Shock Projects individually
    let runTotalGdpImpact = 0;
    const runEconomicIrrs: number[] = [];

    selectedProjects.forEach(proj => {
      if (!proj.selected) return;

      // Shock capex: usually projects have right-skewed cost overruns (log-normal feel)
      const capexMultiplier = Math.exp(randomNormal(0.08, 0.12)); // bias towards overruns (>1.0)
      const shockedProject: InfraProject = {
        ...proj,
        capex: proj.capex * capexMultiplier,
        discountRate: Math.max(1.0, randomNormal(proj.discountRate, 0.5)) // discount rate shock
      };

      const results = evaluateProject(shockedProject, testMultiplier, shockedParams);
      runTotalGdpImpact += results.econNpv * (testMultiplier);
      runEconomicIrrs.push(results.econIrr);
    });

    const avgIrr = runEconomicIrrs.length > 0 
      ? runEconomicIrrs.reduce((a, b) => a + b, 0) / runEconomicIrrs.length
      : 0;

    gdpOutputs.push(runTotalGdpImpact || 0);
    irrOutputs.push(avgIrr || 0);
  }

  // 3. Compile statistics
  gdpOutputs.sort((a, b) => a - b);
  irrOutputs.sort((a, b) => a - b);

  const meanGdp = gdpOutputs.reduce((a, b) => a + b, 0) / iterations;
  const medianGdp = gdpOutputs[Math.floor(iterations / 2)];
  const p10Gdp = gdpOutputs[Math.floor(iterations * 0.1)];
  const p90Gdp = gdpOutputs[Math.floor(iterations * 0.9)];

  const variance = gdpOutputs.reduce((sum, val) => sum + Math.pow(val - meanGdp, 2), 0) / iterations;
  const stdDev = Math.sqrt(variance);

  // Build histogram frequency data for GDP and IRR distributions (30 buckets)
  const bucketsCount = 20;
  
  // GDP Dist
  const minGdp = gdpOutputs[0];
  const maxGdp = gdpOutputs[iterations - 1];
  const gdpStep = (maxGdp - minGdp) / bucketsCount || 100;
  const gdpDist: { gdp: number; density: number }[] = [];

  for (let b = 0; b < bucketsCount; b++) {
    const bucketStart = minGdp + b * gdpStep;
    const bucketEnd = bucketStart + gdpStep;
    const midPoint = (bucketStart + bucketEnd) / 2;
    const count = gdpOutputs.filter(v => v >= bucketStart && v < bucketEnd).length;
    gdpDist.push({
      gdp: Math.round(midPoint),
      density: Number((count / iterations * 100).toFixed(1))
    });
  }

  // IRR Dist
  const minIrr = irrOutputs[0];
  const maxIrr = irrOutputs[iterations - 1];
  const irrStep = (maxIrr - minIrr) / bucketsCount || 1;
  const irrDist: { irr: number; density: number }[] = [];

  for (let b = 0; b < bucketsCount; b++) {
    const bucketStart = minIrr + b * irrStep;
    const bucketEnd = bucketStart + irrStep;
    const midPoint = (bucketStart + bucketEnd) / 2;
    const count = irrOutputs.filter(v => v >= bucketStart && v < bucketEnd).length;
    irrDist.push({
      irr: Number(midPoint.toFixed(1)),
      density: Number((count / iterations * 100).toFixed(1))
    });
  }

  return {
    meanGdp: Math.round(meanGdp),
    medianGdp: Math.round(medianGdp),
    p10Gdp: Math.round(p10Gdp),
    p90Gdp: Math.round(p90Gdp),
    stdDev: Math.round(stdDev),
    irrDist,
    gdpDist
  };
}
