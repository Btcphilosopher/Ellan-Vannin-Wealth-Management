/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { InfraProject, ProjectResults } from "../types";

export interface OptimiserWeights {
  financialIrr: number; // weight 0-100
  economicIrr: number;
  npv: number;
  gdpGenerated: number;
  employment: number;
  taxRevenue: number;
  carbonReduction: number;
  strategicImportance: number;
  riskAversion: number; // higher means penalize risks more
}

export interface OptimizedProjectRow {
  id: string;
  name: string;
  category: string;
  capex: number;
  financialIrr: number;
  economicIrr: number;
  financialNpv: number;
  economicNpv: number;
  gdpGenerated: number;
  employment: number;
  taxRevenue: number;
  carbonReduction: number;
  paybackPeriod: number;
  returnPerPound: number; // economic npv / capex
  strategicScore: number; // strategic rating out of 100
  riskIndex: number;      // composite risk rating (0-100)
  rank: number;
}

export const defaultOptimiserWeights: OptimiserWeights = {
  financialIrr: 20,
  economicIrr: 25,
  npv: 15,
  gdpGenerated: 20,
  employment: 10,
  taxRevenue: 15,
  carbonReduction: 15,
  strategicImportance: 25,
  riskAversion: 30
};

/**
 * Normalizes values to 0-1 scale. Higher is better.
 */
function normalize(val: number, min: number, max: number, invert: boolean = false): number {
  if (max === min) return 0.5;
  const normalized = (val - min) / (max - min);
  return invert ? 1.0 - normalized : normalized;
}

/**
 * Core portfolio multi-attribute optimization ranking engine.
 */
export function optimizePortfolio(
  projects: InfraProject[],
  evaluations: Record<string, ProjectResults>,
  weights: OptimiserWeights
): OptimizedProjectRow[] {
  if (projects.length === 0) return [];

  // Extract raw lists for min-max normalization
  const capexes = projects.map(p => p.capex);
  const irrs = projects.map(p => evaluations[p.id]?.irr || 0);
  const econIrrs = projects.map(p => evaluations[p.id]?.econIrr || 0);
  const npvs = projects.map(p => evaluations[p.id]?.npv || 0);
  const econNpvs = projects.map(p => evaluations[p.id]?.econNpv || 0);
  const gdps = projects.map(p => (evaluations[p.id]?.npv || 0) * (evaluations[p.id]?.multiplier || 1.2));
  const employments = projects.map(p => evaluations[p.id]?.employmentImpact || 0);
  const taxes = projects.map(p => evaluations[p.id]?.taxImpact || 0);
  const carbons = projects.map(p => evaluations[p.id]?.carbonImpact || 0); // negative is good
  const strategics = projects.map(p => p.strategicImportance);

  // Min-max ranges
  const minCapex = Math.min(...capexes), maxCapex = Math.max(...capexes);
  const minIrr = Math.min(...irrs), maxIrr = Math.max(...irrs);
  const minEconIrr = Math.min(...econIrrs), maxEconIrr = Math.max(...econIrrs);
  const minNpv = Math.min(...npvs), maxNpv = Math.max(...npvs);
  const minEconNpv = Math.min(...econNpvs), maxEconNpv = Math.max(...econNpvs);
  const minGdp = Math.min(...gdps), maxGdp = Math.max(...gdps);
  const minEmp = Math.min(...employments), maxEmp = Math.max(...employments);
  const minTax = Math.min(...taxes), maxTax = Math.max(...taxes);
  const minCarbon = Math.min(...carbons), maxCarbon = Math.max(...carbons); // carbon reduction is negative
  const minStrat = Math.min(...strategics), maxStrat = Math.max(...strategics);

  const rows: OptimizedProjectRow[] = projects.map(p => {
    const evalResult = evaluations[p.id] || {
      npv: 0, econNpv: 0, irr: 0, econIrr: 0, bcr: 1.0, multiplier: 1.0,
      carbonImpact: 0, employmentImpact: 0, taxImpact: 0, paybackPeriod: 20
    };

    const returnPerPound = Number((evalResult.econNpv / p.capex).toFixed(2));

    // Calculate composite risk rating (0-100)
    // Average of structural risks
    const riskIndex = (p.politicalRisk * 0.15) + (p.constructionRisk * 0.35) + 
                      (p.operationalRisk * 0.30) + (p.liquidityRisk * 0.20);

    // Normalize metrics
    const nIrr = normalize(evalResult.irr, minIrr, maxIrr);
    const nEconIrr = normalize(evalResult.econIrr, minEconIrr, maxEconIrr);
    const nNpv = normalize(evalResult.npv, minNpv, maxNpv);
    const nGdp = normalize(evalResult.npv * evalResult.multiplier, minGdp, maxGdp);
    const nEmp = normalize(evalResult.employmentImpact, minEmp, maxEmp);
    const nTax = normalize(evalResult.taxImpact, minTax, maxTax);
    
    // Carbon impact: net carbon reduction is highly negative. So we invert normalization so that high reduction (very negative carbon) gets a high score.
    const nCarbon = normalize(evalResult.carbonImpact, minCarbon, maxCarbon, true);
    
    const nStrat = normalize(p.strategicImportance, minStrat, maxStrat);
    const nRisk = normalize(riskIndex, 0, 100, true); // higher is better (which means lower raw risk rating)

    // Weighted sum
    const totalWeight = weights.financialIrr + weights.economicIrr + weights.npv + 
                        weights.gdpGenerated + weights.employment + weights.taxRevenue + 
                        weights.carbonReduction + weights.strategicImportance + weights.riskAversion;

    const weightedScore = (
      nIrr * weights.financialIrr +
      nEconIrr * weights.economicIrr +
      nNpv * weights.npv +
      nGdp * weights.gdpGenerated +
      nEmp * weights.employment +
      nTax * weights.taxRevenue +
      nCarbon * weights.carbonReduction +
      nStrat * weights.strategicImportance +
      nRisk * weights.riskAversion
    ) / (totalWeight || 1) * 100;

    return {
      id: p.id,
      name: p.name,
      category: p.category,
      capex: p.capex,
      financialIrr: evalResult.irr,
      economicIrr: evalResult.econIrr,
      financialNpv: evalResult.npv,
      economicNpv: evalResult.econNpv,
      gdpGenerated: Math.round(evalResult.npv * evalResult.multiplier),
      employment: evalResult.employmentImpact,
      taxRevenue: evalResult.taxImpact,
      carbonReduction: evalResult.carbonImpact,
      paybackPeriod: evalResult.paybackPeriod,
      returnPerPound,
      strategicScore: Number(weightedScore.toFixed(1)),
      riskIndex: Number(riskIndex.toFixed(1)),
      rank: 0
    };
  });

  // Sort by strategicScore descending and assign ranks
  rows.sort((a, b) => b.strategicScore - a.strategicScore);
  rows.forEach((row, idx) => {
    row.rank = idx + 1;
  });

  return rows;
}
