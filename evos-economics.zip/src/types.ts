/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export enum EconomicSchool {
  Classical = "Classical",
  Keynesian = "Keynesian",
  NeoKeynesian = "Neo-Keynesian",
  PostKeynesian = "Post-Keynesian",
  Austrian = "Austrian",
  SupplySide = "Supply-side",
  InfrastructureEconomics = "Infrastructure Economics",
  DevelopmentEconomics = "Development Economics"
}

export enum ProjectCategory {
  Transport = "Transport",
  Energy = "Energy",
  Digital = "Digital",
  Social = "Social Infrastructure",
  Environment = "Environmental",
  Industrial = "Industrial & Research"
}

export interface InfraProject {
  id: string;
  name: string;
  category: ProjectCategory;
  capex: number; // £ millions
  opex: number;  // £ millions/year
  maintenance: number; // % of capex/year
  lifetime: number; // years
  residualValue: number; // £ millions
  constructionPeriod: number; // years
  inflation: number; // %
  discountRate: number; // %
  
  // Risk metrics (out of 100)
  strategicImportance: number;
  politicalRisk: number;
  constructionRisk: number;
  operationalRisk: number;
  liquidityRisk: number;

  // Selected status (for portfolio construction)
  selected: boolean;
  fundingShare: number; // % funded by public capital
}

export interface ProjectResults {
  npv: number;       // Financial NPV (£m)
  econNpv: number;   // Economic NPV (including externalities, £m)
  irr: number;       // Financial IRR (%)
  econIrr: number;   // Economic IRR (%)
  bcr: number;       // Benefit-Cost Ratio
  multiplier: number; // GDP Multiplier
  carbonImpact: number; // Net tCO2e reduced/yr
  employmentImpact: number; // Jobs created during construction + operational
  taxImpact: number;  // £m tax generated over lifetime
  paybackPeriod: number; // years
}

export interface MultiplierParams {
  mpc: number; // Marginal Propensity to Consume (0-1)
  mps: number; // Marginal Propensity to Save (0-1)
  taxRate: number; // Average Tax Rate (0-1)
  importLeakage: number; // Import Leakage (0-1)
  supplyChainRetention: number; // Domestic Supply Chain Retention (0-1)
  regionalLeakage: number; // Regional Spending Leakage (0-1)
  investmentVelocity: number; // Investment Velocity (0-1)
  labourParticipation: number; // Labour Participation (0-1)
  capitalProductivity: number; // Capital Productivity (0-1)
  infraEfficiency: number; // Infrastructure Efficiency (0-1)
  constructionProductivity: number; // Construction Productivity (0-1)
  crowdingIn: number; // Private Investment Crowding-In factor (0-2)
  crowdingOut: number; // Crowding-Out factor (0-1)
  housingMultiplier: number; // Housing Multiplier
  innovationSpillovers: number; // Innovation Spillovers (0-1)
  agglomerationEffects: number; // Agglomeration Effects (0-1)
  knowledgeSpillovers: number; // Knowledge Spillovers (0-1)
  exportGrowth: number; // Export Growth factor (0-1)
  energyCostReduction: number; // Energy Cost Reduction factor (0-1)
  logisticsCostReduction: number; // Logistics Cost Reduction factor (0-1)
  digitalProductivity: number; // Digital Productivity (0-1)
}

export interface CountyMetrics {
  id: string;
  name: string;
  gdp: number; // £ billions
  population: number; // thousands
  employment: number; // thousands
  avgWage: number; // £/year
  productivity: number; // £/hour worked
  electricityCost: number; // p/kWh
  infraQuality: number; // index (1-100)
  connectivity: number; // index (1-100)
  investmentRequired: number; // £ millions
  historicInvestment: number; // £ millions (last decade)
  privateSectorActivity: number; // index (1-100)
  expectedIrr: number; // %
  expectedGdpGrowth: number; // % per year
  coordinates: [number, number]; // custom layout position (X, Y) 0-100 for SVG map
}

export interface MacroSimResults {
  year: number;
  gdp: number;
  inflation: number;
  population: number;
  employment: number;
  taxReceipts: number;
  govDebt: number;
  debtToGdp: number;
  infraDepreciation: number;
  infraStock: number;
  productivityGrowth: number;
  privateInvestment: number;
  exports: number;
  energyDemand: number;
  constructionOutput: number;
  industrialProduction: number;
}

export interface IndustryIo {
  id: string;
  name: string;
  directEffect: number; // Direct multiplier per £1 spent
  indirectEffect: number;
  inducedEffect: number;
  supplyChainEffect: number;
  steelInput: number; // concrete/steel/etc inter-industry shares
  concreteInput: number;
  energyInput: number;
  softwareInput: number;
  engineeringInput: number;
}

export interface MonteCarloSummary {
  meanGdp: number;
  medianGdp: number;
  p10Gdp: number; // 10th percentile (Worst case)
  p90Gdp: number; // 90th percentile (Best case)
  stdDev: number;
  irrDist: { irr: number; density: number }[];
  gdpDist: { gdp: number; density: number }[];
}

export interface Scenario {
  name: string;
  description: string;
  mpcModifier: number;
  crowdingInModifier: number;
  capexModifier: number;
  inflationModifier: number;
  leakageModifier: number;
}
