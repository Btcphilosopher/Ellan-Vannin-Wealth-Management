/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from "react";
import { EconomicSchool, InfraProject, CountyMetrics, MultiplierParams, ProjectResults } from "./types";
import { calculateMultiplier, defaultMultiplierParams } from "./models/multiplierEngine";
import { initialProjects, evaluateProject } from "./models/projectModel";
import { initialCounties } from "./models/regionalModel";
import { runMacroSimulation } from "./models/macroSim";

import Sidebar from "./components/Sidebar";
import DashboardView from "./components/DashboardView";
import MultiplierView from "./components/MultiplierView";
import ProjectsView from "./components/ProjectsView";
import RegionalView from "./components/RegionalView";
import SimulationView from "./components/SimulationView";
import InputOutputView from "./components/InputOutputView";
import OptimiserView from "./components/OptimiserView";
import SensitivityView from "./components/SensitivityView";
import StatisticalView from "./components/StatisticalView";

export default function App() {
  const [activeTab, setActiveTab] = useState<string>("dashboard");
  const [selectedSchool, setSelectedSchool] = useState<EconomicSchool>(EconomicSchool.InfrastructureEconomics);
  const [selectedYear, setSelectedYear] = useState<number>(30); // 30 Years default horizon
  const [projects, setProjects] = useState<InfraProject[]>(initialProjects);
  const [counties, setCounties] = useState<CountyMetrics[]>(initialCounties);
  const [multiplierParams, setMultiplierParams] = useState<MultiplierParams>(defaultMultiplierParams);

  // 1. Dynamic multiplier calculation based on selected school and current params
  const currentMultiplier = useMemo(() => {
    return calculateMultiplier(selectedSchool, multiplierParams, 100);
  }, [selectedSchool, multiplierParams]);

  // 2. Project evaluations compiled dynamically based on active multiplier & re-costing metrics
  const evaluations = useMemo(() => {
    const evals: Record<string, ProjectResults> = {};
    projects.forEach(p => {
      evals[p.id] = evaluateProject(p, currentMultiplier.gdpMultiplier, multiplierParams);
    });
    return evals;
  }, [projects, currentMultiplier.gdpMultiplier, multiplierParams]);

  // 3. Dynamic macroeconomic simulation over specified horizon
  const simulationData = useMemo(() => {
    return runMacroSimulation(projects, selectedSchool, multiplierParams, selectedYear);
  }, [projects, selectedSchool, multiplierParams, selectedYear]);

  const toggleProject = (id: string) => {
    setProjects(prev => prev.map(p => p.id === id ? { ...p, selected: !p.selected } : p));
  };

  return (
    <div className="min-h-screen bg-[#0A0B0D] text-[#E0E0E0] flex flex-col md:flex-row antialiased select-none font-mono">
      {/* Sidebar Control Panel */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        selectedSchool={selectedSchool}
        setSelectedSchool={setSelectedSchool}
        selectedYear={selectedYear}
        setSelectedYear={setSelectedYear}
      />

      {/* Main Terminal View Container */}
      <main className="flex-1 p-6 md:p-8 overflow-y-auto space-y-6 h-screen">
        {/* Top Sovereign bar */}
        <div className="flex justify-between items-center bg-[#0F1115] border border-[#1E2024] rounded-xl px-5 py-3 shadow-lg shadow-black/20">
          <div className="flex items-center space-x-3">
            <span className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse"></span>
            <span className="text-[10px] text-[#00D1FF] font-bold tracking-widest uppercase">
              ELLAN VANNIN SOVEREIGN SYSTEMS // CORE ONLINE
            </span>
          </div>
          <div className="text-right text-[10px] text-gray-500">
            SECURE LINK // NODE ID: EVOS-SEC-92A
          </div>
        </div>

        {/* View Routing */}
        <div className="animate-fade-in duration-200">
          {activeTab === "dashboard" && (
            <DashboardView
              selectedSchool={selectedSchool}
              selectedYear={selectedYear}
              projects={projects}
              evaluations={evaluations}
              simulationData={simulationData}
              toggleProject={toggleProject}
            />
          )}

          {activeTab === "multiplier" && (
            <MultiplierView
              selectedSchool={selectedSchool}
              setSelectedSchool={setSelectedSchool}
              multiplierParams={multiplierParams}
              setMultiplierParams={setMultiplierParams}
            />
          )}

          {activeTab === "projects" && (
            <ProjectsView
              projects={projects}
              setProjects={setProjects}
              evaluations={evaluations}
              activeMultiplier={currentMultiplier.gdpMultiplier}
              multiplierParams={multiplierParams}
            />
          )}

          {activeTab === "regional" && (
            <RegionalView
              counties={counties}
              setCounties={setCounties}
            />
          )}

          {activeTab === "simulation" && (
            <SimulationView
              simulationData={simulationData}
            />
          )}

          {activeTab === "io" && (
            <InputOutputView />
          )}

          {activeTab === "optimiser" && (
            <OptimiserView
              projects={projects}
              toggleProject={toggleProject}
              evaluations={evaluations}
            />
          )}

          {activeTab === "sensitivity" && (
            <SensitivityView
              selectedSchool={selectedSchool}
              projects={projects}
              multiplierParams={multiplierParams}
              setMultiplierParams={setMultiplierParams}
            />
          )}

          {activeTab === "statistical" && (
            <StatisticalView
              simulationData={simulationData}
              counties={counties}
            />
          )}
        </div>
      </main>
    </div>
  );
}
