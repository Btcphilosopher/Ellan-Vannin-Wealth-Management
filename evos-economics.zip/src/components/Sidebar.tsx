/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  TrendingUp, 
  Layers, 
  MapPin, 
  LineChart, 
  GitMerge, 
  Sliders, 
  ShieldAlert, 
  Terminal, 
  HelpCircle,
  Briefcase,
  Compass
} from "lucide-react";
import { EconomicSchool } from "../types";

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  selectedSchool: EconomicSchool;
  setSelectedSchool: (school: EconomicSchool) => void;
  selectedYear: number;
  setSelectedYear: (y: number) => void;
}

export default function Sidebar({
  activeTab,
  setActiveTab,
  selectedSchool,
  setSelectedSchool,
  selectedYear,
  setSelectedYear
}: SidebarProps) {
  const navItems = [
    { id: "dashboard", label: "CEO Bloomberg Dashboard", icon: Briefcase },
    { id: "multiplier", label: "Infrastructure Multipliers", icon: Sliders },
    { id: "projects", label: "National Project Register", icon: Layers },
    { id: "regional", label: "Regional Economics Map", icon: MapPin },
    { id: "simulation", label: "Decadal Macro Simulation", icon: LineChart },
    { id: "io", label: "Leontief Input-Output", icon: GitMerge },
    { id: "optimiser", label: "Portfolio Optimiser", icon: TrendingUp },
    { id: "sensitivity", label: "Sensitivity & Monte Carlo", icon: ShieldAlert },
    { id: "statistical", label: "Econometric Estimations", icon: Terminal },
    { id: "docs", label: "SWF Architecture Docs", icon: HelpCircle }
  ];

  const schools = Object.values(EconomicSchool);

  return (
    <aside id="evos_sidebar" className="w-80 bg-[#0F1115] border-r border-[#1E2024] flex flex-col h-screen shrink-0 text-slate-300">
      {/* Brand Header */}
      <div className="p-6 border-b border-[#1E2024] bg-[#0F1115]">
        <div className="text-[#00D1FF] font-black text-xl tracking-tighter">
          EVOS<span className="text-white ml-1">ECONOMICS</span>
        </div>
        <div className="text-[10px] text-gray-500 uppercase tracking-widest mt-1 font-mono">
          Sovereign Terminal v4.2
        </div>
      </div>

      {/* Navigation List */}
      <nav className="flex-1 overflow-y-auto p-4 space-y-1">
        <div className="text-[10px] font-bold text-gray-500 tracking-wider uppercase px-3 mb-2 font-mono">
          Analytical Modules
        </div>
        {navItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              id={`nav_btn_${item.id}`}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded text-xs font-medium transition-all duration-150 text-left ${
                isActive 
                  ? "bg-[#1E2024] border-l-2 border-[#00D1FF] text-white" 
                  : "hover:bg-[#16181D] text-gray-400 hover:text-white transition-all"
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? "text-[#00D1FF]" : "text-slate-500"}`} />
              <span className="truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Global Control Terminal */}
      <div className="p-4 border-t border-[#1E2024] bg-[#0A0B0D] space-y-4">
        <div className="space-y-2">
          <div className="flex items-center space-x-1.5">
            <Compass className="w-3.5 h-3.5 text-[#00D1FF]" />
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider font-mono">
              Theoretical School
            </label>
          </div>
          <select
            id="school_selector"
            value={selectedSchool}
            onChange={(e) => setSelectedSchool(e.target.value as EconomicSchool)}
            className="w-full bg-[#1E2024] border border-[#2E3138] rounded px-2.5 py-2 text-xs font-mono text-[#00D1FF] focus:outline-none focus:border-[#00D1FF] focus:ring-1 focus:ring-[#00D1FF]/25"
          >
            {schools.map(school => (
              <option key={school} value={school}>{school}</option>
            ))}
          </select>
          <div className="text-[10px] text-gray-500 leading-relaxed italic font-mono pt-1">
            * Adjusts multipliers, inflation weights, and crowding-out factors dynamically.
          </div>
        </div>

        <div className="space-y-2 pt-2 border-t border-[#1E2024]">
          <div className="flex justify-between text-[10px] font-bold uppercase tracking-wider font-mono">
            <span className="text-gray-500">Decadal Horizon</span>
            <span className="text-[#00D1FF]">{selectedYear} Years</span>
          </div>
          <input
            type="range"
            min="5"
            max="50"
            step="5"
            value={selectedYear}
            onChange={(e) => setSelectedYear(Number(e.target.value))}
            className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
          />
          <div className="flex justify-between text-[8px] text-gray-600 font-mono">
            <span>5Y</span>
            <span>20Y</span>
            <span>30Y</span>
            <span>50Y</span>
          </div>
        </div>

        {/* SWF Terminal Node Status */}
        <div className="pt-2 border-t border-[#1E2024] flex justify-between items-center text-[10px] font-mono">
          <span className="text-gray-600">Terminal:</span>
          <span className="flex items-center text-green-500">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse mr-1.5"></span>
            Node EV-01 Active
          </span>
        </div>
      </div>
    </aside>
  );
}
