/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Layers, Search, Filter, HelpCircle, Check, X, Settings2, ShieldCheck, Flame, Compass } from "lucide-react";
import { InfraProject, ProjectCategory, ProjectResults, MultiplierParams } from "../types";
import { evaluateProject } from "../models/projectModel";

interface ProjectsViewProps {
  projects: InfraProject[];
  setProjects: React.Dispatch<React.SetStateAction<InfraProject[]>>;
  evaluations: Record<string, ProjectResults>;
  activeMultiplier: number;
  multiplierParams: MultiplierParams;
}

export default function ProjectsView({
  projects,
  setProjects,
  evaluations,
  activeMultiplier,
  multiplierParams
}: ProjectsViewProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [editingProject, setEditingProject] = useState<InfraProject | null>(null);

  // Filter Categories
  const categories = ["All", ...Object.values(ProjectCategory)];

  const filteredProjects = projects.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "All" || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const toggleSelect = (id: string) => {
    setProjects(prev => prev.map(p => p.id === id ? { ...p, selected: !p.selected } : p));
  };

  // Handle detailed project updates
  const handleSaveProjectEdits = (updated: InfraProject) => {
    setProjects(prev => prev.map(p => p.id === updated.id ? updated : p));
    setEditingProject(null);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-[#1E2024] pb-4 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center space-x-2">
            <Layers className="w-5 h-5 text-[#00D1FF]" />
            <span>NATIONAL INFRASTRUCTURE REGISTER</span>
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Audit, re-cost, and schedule national capital development assets.
          </p>
        </div>
      </div>

      {/* Search & Filter Controls */}
      <div className="flex flex-col md:flex-row gap-4 bg-[#0F1115] border border-[#1E2024] p-4 rounded-xl">
        <div className="relative flex-1">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          <input
            type="text"
            placeholder="Search projects by database registries..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-[#0A0B0D] border border-[#1E2024] rounded pl-10 pr-4 py-2 text-xs font-mono text-slate-300 focus:outline-none focus:border-[#00D1FF]"
          />
        </div>
        <div className="flex items-center space-x-2 shrink-0">
          <Filter className="w-4 h-4 text-slate-500" />
          <div className="flex flex-wrap gap-1">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 text-[10px] font-mono rounded font-bold uppercase tracking-wider transition-colors ${
                  selectedCategory === cat 
                    ? "bg-[#00D1FF] text-[#0A0B0D]" 
                    : "bg-[#0A0B0D] border border-[#1E2024] text-slate-400 hover:text-slate-200"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredProjects.map(proj => {
          const evalRes = evaluations[proj.id];
          return (
            <div 
              key={proj.id} 
              className={`bg-[#0F1115] border transition-all duration-200 rounded-xl flex flex-col justify-between shadow-xl shadow-black/20 overflow-hidden relative ${
                proj.selected 
                  ? "border-[#00D1FF]/80 shadow-[#00D1FF]/5" 
                  : "border-[#1E2024]/80 hover:border-[#1E2024]/80 hover:shadow-[#00D1FF]/5"
              }`}
            >
              {/* Card Header */}
              <div className="p-5 space-y-2 border-b border-[#1E2024]/60 bg-[#0A0B0D]/20">
                <div className="flex justify-between items-start">
                  <span className="text-[9px] font-bold font-mono tracking-wider uppercase text-slate-500 bg-[#0A0B0D] border border-[#1E2024] px-2 py-0.5 rounded">
                    {proj.category}
                  </span>
                  
                  <div className="flex items-center space-x-1">
                    <button
                      onClick={() => setEditingProject(proj)}
                      className="p-1 rounded bg-[#1E2024] hover:bg-[#1E2024]/80 text-slate-400 hover:text-slate-200 transition-colors"
                      title="Adjust project metrics"
                    >
                      <Settings2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => toggleSelect(proj.id)}
                      className={`p-1 rounded border transition-colors ${
                        proj.selected 
                          ? "bg-[#00D1FF] border-[#00D1FF] text-[#0A0B0D] font-bold" 
                          : "border-[#1E2024] hover:border-[#1E2024]/80 text-slate-500 hover:text-slate-300"
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <h3 className="font-bold text-sm text-slate-200 font-mono tracking-tight line-clamp-1 h-5">{proj.name}</h3>
                <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                  <span>CAPEX: <strong className="text-slate-300">£{proj.capex}m</strong></span>
                  <span>Op Lifetime: <strong className="text-slate-300">{proj.lifetime}Y</strong></span>
                </div>
              </div>

              {/* Evaluation Metrics Block */}
              {evalRes ? (
                <div className="p-5 space-y-4 flex-1">
                  <div className="grid grid-cols-2 gap-3 text-xs font-mono">
                    <div className="bg-[#0A0B0D]/40 p-2 rounded border border-[#1E2024]/40">
                      <span className="text-[9px] text-slate-500 uppercase block">Financial IRR</span>
                      <span className="text-sm font-bold text-[#00D1FF]">{evalRes.irr}%</span>
                    </div>
                    <div className="bg-[#0A0B0D]/40 p-2 rounded border border-[#1E2024]/40">
                      <span className="text-[9px] text-slate-500 uppercase block">Economic IRR</span>
                      <span className="text-sm font-bold text-emerald-400">{evalRes.econIrr}%</span>
                    </div>
                    <div className="bg-[#0A0B0D]/40 p-2 rounded border border-[#1E2024]/40 col-span-2">
                      <div className="flex justify-between items-center">
                        <span className="text-[9px] text-slate-500 uppercase block">Econ NPV / BCR</span>
                        <span className="text-[10px] text-slate-400 font-bold">BCR: {evalRes.bcr}x</span>
                      </div>
                      <span className="text-sm font-bold text-slate-200">£{evalRes.econNpv}m</span>
                    </div>
                  </div>

                  {/* Horizontal visual Gantt-bar */}
                  <div className="space-y-1 font-mono text-[9px] text-slate-500">
                    <div className="flex justify-between">
                      <span>Const: {proj.constructionPeriod}Y</span>
                      <span>Operations: {proj.lifetime}Y</span>
                    </div>
                    <div className="w-full bg-[#0A0B0D] border border-[#1E2024] rounded h-2 overflow-hidden flex">
                      <div 
                        className="bg-rose-500/80 h-full" 
                        style={{ width: `${(proj.constructionPeriod / (proj.constructionPeriod + proj.lifetime)) * 100}%` }}
                        title="Construction Period"
                      ></div>
                      <div 
                        className="bg-emerald-500/80 h-full" 
                        style={{ width: `${(proj.lifetime / (proj.constructionPeriod + proj.lifetime)) * 100}%` }}
                        title="Operational Lifetime"
                      ></div>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="p-5 text-center text-xs text-slate-500 font-mono italic">
                  Run model to evaluate
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Editing Details Drawer/Modal */}
      {editingProject && (
        <div className="fixed inset-0 bg-[#0A0B0D]/80 flex items-center justify-center p-4 z-50 animate-fade-in font-mono">
          <div className="bg-[#0F1115] border border-[#1E2024]/60 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl relative">
            
            {/* Modal Header */}
            <div className="p-5 border-b border-[#1E2024] bg-[#0A0B0D] flex justify-between items-center">
              <div>
                <h3 className="text-sm font-bold text-[#00D1FF] tracking-wider uppercase">Sovereign Financial Re-Costing</h3>
                <span className="text-xs text-slate-400">{editingProject.name}</span>
              </div>
              <button 
                onClick={() => setEditingProject(null)}
                className="p-1 rounded hover:bg-[#1E2024] text-slate-500 hover:text-slate-300 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Inputs Body */}
            <div className="p-6 space-y-6 max-h-[500px] overflow-y-auto">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                {/* CAPEX */}
                <div className="space-y-1.5">
                  <label className="text-slate-400 block">CAPEX (Public funding capital, £m):</label>
                  <input
                    type="number"
                    value={editingProject.capex}
                    onChange={(e) => setEditingProject({ ...editingProject, capex: Math.max(1, Number(e.target.value)) })}
                    className="w-full bg-[#0A0B0D] border border-[#1E2024] rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-[#00D1FF]"
                  />
                </div>
                {/* OPEX */}
                <div className="space-y-1.5">
                  <label className="text-slate-400 block">Operating Costs (OPEX, £m/year):</label>
                  <input
                    type="number"
                    value={editingProject.opex}
                    onChange={(e) => setEditingProject({ ...editingProject, opex: Math.max(0, Number(e.target.value)) })}
                    className="w-full bg-[#0A0B0D] border border-[#1E2024] rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-[#00D1FF]"
                  />
                </div>
                {/* Maintenance */}
                <div className="space-y-1.5">
                  <label className="text-slate-400 block">Yearly Maintenance (% of capex/year):</label>
                  <input
                    type="number" step="0.1"
                    value={editingProject.maintenance}
                    onChange={(e) => setEditingProject({ ...editingProject, maintenance: Math.max(0, Number(e.target.value)) })}
                    className="w-full bg-[#0A0B0D] border border-[#1E2024] rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-[#00D1FF]"
                  />
                </div>
                {/* Lifetime */}
                <div className="space-y-1.5">
                  <label className="text-slate-400 block">Project Lifetime (years):</label>
                  <input
                    type="number"
                    value={editingProject.lifetime}
                    onChange={(e) => setEditingProject({ ...editingProject, lifetime: Math.max(1, Number(e.target.value)) })}
                    className="w-full bg-[#0A0B0D] border border-[#1E2024] rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-[#00D1FF]"
                  />
                </div>
                {/* Construction Period */}
                <div className="space-y-1.5">
                  <label className="text-slate-400 block">Construction Period (years):</label>
                  <input
                    type="number"
                    value={editingProject.constructionPeriod}
                    onChange={(e) => setEditingProject({ ...editingProject, constructionPeriod: Math.max(1, Number(e.target.value)) })}
                    className="w-full bg-[#0A0B0D] border border-[#1E2024] rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-[#00D1FF]"
                  />
                </div>
                {/* Discount Rate */}
                <div className="space-y-1.5">
                  <label className="text-slate-400 block">Social Discount Rate (%):</label>
                  <input
                    type="number" step="0.1"
                    value={editingProject.discountRate}
                    onChange={(e) => setEditingProject({ ...editingProject, discountRate: Math.max(0.5, Number(e.target.value)) })}
                    className="w-full bg-[#0A0B0D] border border-[#1E2024] rounded px-3 py-2 text-slate-200 focus:outline-none focus:border-[#00D1FF]"
                  />
                </div>
              </div>

              {/* Instant Evaluation HUD inside Modal */}
              <div className="border-t border-[#1E2024] pt-4">
                <h4 className="text-xs font-bold text-slate-400 mb-3 uppercase tracking-wider">Projected Impact Analysis (Instant Solver)</h4>
                {(() => {
                  const tempEval = evaluateProject(editingProject, activeMultiplier, multiplierParams);
                  return (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                      <div>
                        <span className="text-[10px] text-slate-500 block">Financial IRR:</span>
                        <span className="font-bold text-[#00D1FF] text-sm">{tempEval.irr}%</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">Economic IRR:</span>
                        <span className="font-bold text-emerald-400 text-sm">{tempEval.econIrr}%</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">Benefit-Cost (BCR):</span>
                        <span className="font-bold text-slate-200 text-sm">{tempEval.bcr}x</span>
                      </div>
                      <div>
                        <span className="text-[10px] text-slate-500 block">Payback Period:</span>
                        <span className="font-bold text-slate-300 text-sm">{tempEval.paybackPeriod} Years</span>
                      </div>
                    </div>
                  );
                })()}
              </div>
            </div>

            {/* Modal Actions Footer */}
            <div className="p-5 border-t border-[#1E2024] bg-[#0A0B0D] flex justify-end space-x-3">
              <button
                onClick={() => setEditingProject(null)}
                className="bg-[#0F1115] border border-[#1E2024] text-slate-400 hover:text-white px-4 py-2 rounded text-xs transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={() => handleSaveProjectEdits(editingProject)}
                className="bg-[#00D1FF] hover:bg-[#00D1FF]/90 text-[#0A0B0D] px-4 py-2 rounded text-xs font-bold transition-colors"
              >
                Commit Re-Costing
              </button>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
