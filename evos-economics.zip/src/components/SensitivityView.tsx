/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { ShieldAlert, Compass, Play, Sparkles, TrendingUp, HelpCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, AreaChart, Area } from "recharts";
import { EconomicSchool, InfraProject, MultiplierParams, MonteCarloSummary, Scenario } from "../types";
import { preDefinedScenarios, runMonteCarlo } from "../models/sensitivityModel";

interface SensitivityViewProps {
  selectedSchool: EconomicSchool;
  projects: InfraProject[];
  multiplierParams: MultiplierParams;
  setMultiplierParams: React.Dispatch<React.SetStateAction<MultiplierParams>>;
}

export default function SensitivityView({
  selectedSchool,
  projects,
  multiplierParams,
  setMultiplierParams
}: SensitivityViewProps) {
  const [selectedScenarioIndex, setSelectedScenarioIndex] = useState<number>(0);
  const [mcSummary, setMcSummary] = useState<MonteCarloSummary | null>(null);
  const [simulating, setSimulating] = useState(false);

  const activeProjects = projects.filter(p => p.selected);

  const handleApplyScenario = (index: number) => {
    setSelectedScenarioIndex(index);
    const scen = preDefinedScenarios[index];

    // Modify multiplierParams dynamically based on modifiers
    setMultiplierParams(prev => ({
      ...prev,
      mpc: Math.max(0.2, Math.min(0.95, prev.mpc * scen.mpcModifier)),
      importLeakage: Math.max(0.05, Math.min(0.60, prev.importLeakage * scen.leakageModifier)),
      crowdingIn: Math.max(0.1, Math.min(2.5, prev.crowdingIn * scen.crowdingInModifier)),
      // Adjust other parameters based on scenario
    }));
  };

  const handleRunSimulation = () => {
    if (activeProjects.length === 0) return;
    setSimulating(true);

    // Simulate small latency to match high performance calculation
    setTimeout(() => {
      const summary = runMonteCarlo(projects, selectedSchool, multiplierParams, 250);
      setMcSummary(summary);
      setSimulating(false);
    }, 500);
  };

  // Generate initial simulation summary on mount if not exist
  if (!mcSummary && activeProjects.length > 0 && !simulating) {
    const summary = runMonteCarlo(projects, selectedSchool, multiplierParams, 250);
    setMcSummary(summary);
  }

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-[#1E2024] pb-4">
        <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center space-x-2">
          <ShieldAlert className="w-5 h-5 text-[#00D1FF]" />
          <span>STOCHASTIC MONTE CARLO & STRESS TESTING</span>
        </h2>
        <p className="text-xs text-slate-500 font-mono">
          Model capital cost-overruns and shock multiplier variances via probability distributions.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Scenarios Panel (5 cols) */}
        <div className="lg:col-span-5 bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <span className="text-[10px] font-bold text-slate-500 tracking-wider uppercase font-mono block mb-2 flex items-center">
              <Compass className="w-4 h-4 text-[#00D1FF] mr-1.5" /> Macro Scenario Stress Tests
            </span>

            <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
              {preDefinedScenarios.map((scen, idx) => {
                const isActive = idx === selectedScenarioIndex;
                return (
                  <button
                    key={scen.name}
                    onClick={() => handleApplyScenario(idx)}
                    className={`w-full text-left p-3 rounded-lg border font-mono transition-all duration-150 ${
                      isActive 
                        ? "bg-[#0A0B0D] border-[#00D1FF] shadow-inner" 
                        : "bg-[#0A0B0D]/40 border-[#1E2024] hover:border-[#1E2024]/80 hover:bg-[#0A0B0D]/60"
                    }`}
                  >
                    <span className={`text-[11px] font-bold block ${isActive ? "text-[#00D1FF]" : "text-slate-300"}`}>
                      {scen.name}
                    </span>
                    <p className="text-[10px] text-slate-500 mt-1 leading-relaxed">
                      {scen.description}
                    </p>
                    {isActive && (
                      <div className="mt-2.5 pt-2 border-t border-[#0A0B0D] grid grid-cols-3 gap-2 text-[8px] text-[#00D1FF] font-bold uppercase">
                        <span>MPC: x{scen.mpcModifier}</span>
                        <span>Capex: x{scen.capexModifier}</span>
                        <span>Risk: x{scen.crowdingInModifier}</span>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          <div className="pt-4 border-t border-[#1E2024]/60">
            <button
              onClick={handleRunSimulation}
              disabled={activeProjects.length === 0 || simulating}
              className={`w-full py-3 rounded-lg text-xs font-bold font-mono tracking-wider uppercase flex items-center justify-center space-x-2 transition-colors ${
                activeProjects.length === 0 
                  ? "bg-[#1E2024] text-slate-600 cursor-not-allowed" 
                  : simulating 
                    ? "bg-[#00D1FF]/20 text-[#00D1FF] cursor-wait" 
                    : "bg-[#00D1FF] hover:bg-[#00B0D7] text-[#0A0B0D]"
              }`}
            >
              <Play className="w-4 h-4" />
              <span>{simulating ? "Executing 250 Trials..." : "Run Monte Carlo Simulation"}</span>
            </button>
            {activeProjects.length === 0 && (
              <span className="text-[9px] text-slate-500 font-mono block text-center mt-2 italic">
                * Select at least one project from the pipeline to run simulations.
              </span>
            )}
          </div>
        </div>

        {/* Monte Carlo Output HUD (7 cols) */}
        <div className="lg:col-span-7 bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20 space-y-6">
          <div className="flex justify-between items-start border-b border-[#1E2024] pb-3">
            <div>
              <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200">
                Simulation Results HUD (80% Confidence Interval)
              </h3>
              <p className="text-xs text-slate-500 font-mono">Statistical ranges compiled across 250 stochastic runs.</p>
            </div>
            <Sparkles className="w-5 h-5 text-[#00D1FF] animate-pulse shrink-0" />
          </div>

          {mcSummary && activeProjects.length > 0 ? (
            <div className="space-y-6">
              {/* Quantile KPIs */}
              <div className="grid grid-cols-3 gap-4 font-mono text-xs">
                {/* P10 (Worst case) */}
                <div className="bg-[#0A0B0D] p-3 rounded-lg border border-[#1E2024]">
                  <span className="text-[9px] text-slate-500 block uppercase">P10 (Worst Case)</span>
                  <span className="text-sm font-bold text-rose-500">£{mcSummary.p10Gdp.toLocaleString()}m</span>
                  <p className="text-[8px] text-slate-500 mt-1">10% chance of being below this level.</p>
                </div>
                {/* P50 (Median) */}
                <div className="bg-[#0A0B0D] p-3 rounded-lg border border-[#1E2024]">
                  <span className="text-[9px] text-slate-500 block uppercase">P50 (Median Case)</span>
                  <span className="text-sm font-bold text-[#00D1FF]">£{mcSummary.medianGdp.toLocaleString()}m</span>
                  <p className="text-[8px] text-slate-500 mt-1">50% chance of being above/below.</p>
                </div>
                {/* P90 (Best case) */}
                <div className="bg-[#0A0B0D] p-3 rounded-lg border border-[#1E2024]">
                  <span className="text-[9px] text-slate-500 block uppercase">P90 (Best Case)</span>
                  <span className="text-sm font-bold text-emerald-400">£{mcSummary.p90Gdp.toLocaleString()}m</span>
                  <p className="text-[8px] text-slate-500 mt-1">10% chance of exceeding this level.</p>
                </div>
              </div>

              {/* Statistics block */}
              <div className="flex justify-between text-xs font-mono text-slate-400 bg-[#0A0B0D]/40 p-3 rounded border border-[#1E2024]">
                <span>Mean GDP Impact: <strong className="text-slate-200">£{mcSummary.meanGdp.toLocaleString()}m</strong></span>
                <span>Standard Deviation ($\sigma$): <strong className="text-slate-200">£{mcSummary.stdDev.toLocaleString()}m</strong></span>
              </div>

              {/* Probability Density Plot */}
              <div>
                <h4 className="text-xs font-bold text-slate-300 font-mono uppercase tracking-wider mb-3">GDP Generated Probability Density Histogram</h4>
                <div className="h-44">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={mcSummary.gdpDist} margin={{ top: 10, right: 10, left: -30, bottom: 0 }}>
                      <CartesianGrid stroke="#1E2024" strokeDasharray="3 3" vertical={false} />
                      <XAxis dataKey="gdp" stroke="#475569" fontSize={9} />
                      <YAxis stroke="#475569" fontSize={9} label={{ value: 'Probability Density (%)', angle: -90, position: 'insideLeft', offset: 10, fill: '#475569', fontSize: 8, fontFamily: 'monospace' }} />
                      <Tooltip 
                        contentStyle={{ backgroundColor: "#0A0B0D", border: "1px solid #1E2024", borderRadius: "8px", fontFamily: "monospace" }}
                        labelStyle={{ color: "#94a3b8" }}
                      />
                      <Bar name="Probability Density" dataKey="density" fill="#00D1FF" radius={[2, 2, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-72 flex flex-col items-center justify-center text-xs text-slate-500 font-mono italic space-y-2">
              <HelpCircle className="w-8 h-8 text-slate-700 animate-pulse" />
              <span>Stochastic simulation pending. Click Run button.</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
