/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Sliders, Sparkles, AlertTriangle, ShieldCheck } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { EconomicSchool, MultiplierParams } from "../types";
import { calculateMultiplier } from "../models/multiplierEngine";

interface MultiplierViewProps {
  selectedSchool: EconomicSchool;
  setSelectedSchool: (school: EconomicSchool) => void;
  multiplierParams: MultiplierParams;
  setMultiplierParams: React.Dispatch<React.SetStateAction<MultiplierParams>>;
}

export default function MultiplierView({
  selectedSchool,
  setSelectedSchool,
  multiplierParams,
  setMultiplierParams
}: MultiplierViewProps) {
  const [activeGroup, setActiveGroup] = useState<"leakage" | "supply" | "spillover">("leakage");

  const schools = Object.values(EconomicSchool);
  const testInvestment = 100; // £100m standardize base

  // Run multiplier calculations for ALL schools to compare
  const schoolComparisons = schools.map(sch => {
    const results = calculateMultiplier(sch, multiplierParams, testInvestment);
    return {
      name: sch,
      multiplier: results.gdpMultiplier,
      isCurrent: sch === selectedSchool
    };
  });

  // Calculate current active school results
  const currentResults = calculateMultiplier(selectedSchool, multiplierParams, testInvestment);

  const updateParam = (key: keyof MultiplierParams, value: number) => {
    setMultiplierParams(prev => {
      const next = { ...prev, [key]: Number(value.toFixed(3)) };
      
      // Auto balance MPC and MPS if necessary (MPC + MPS <= 1.0)
      if (key === "mpc") {
        next.mps = Number(Math.max(0, 1 - value - next.taxRate).toFixed(3));
      } else if (key === "mps") {
        next.mpc = Number(Math.max(0, 1 - value - next.taxRate).toFixed(3));
      } else if (key === "taxRate") {
        next.mpc = Number(Math.max(0, 1 - value - next.mps).toFixed(3));
      }
      return next;
    });
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-[#1E2024] pb-4">
        <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center space-x-2">
          <Sliders className="w-5 h-5 text-[#00D1FF]" />
          <span>EVOS MULTIPLIER CORE MODEL</span>
        </h2>
        <p className="text-xs text-slate-500 font-mono">
          Interactive multi-school sovereign infrastructure output elasticity engine.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Hand side: Parameter Sliders (5 cols) */}
        <div className="lg:col-span-5 bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20 space-y-4">
          <div className="flex border-b border-[#1E2024] pb-2">
            <button
              onClick={() => setActiveGroup("leakage")}
              className={`flex-1 text-center py-1 text-[10px] font-mono font-bold tracking-widest uppercase transition-colors border-b ${
                activeGroup === "leakage" ? "border-[#00D1FF] text-[#00D1FF]" : "border-transparent text-slate-500 hover:text-slate-300"
              }`}
            >
              Consumption & Leakage
            </button>
            <button
              onClick={() => setActiveGroup("supply")}
              className={`flex-1 text-center py-1 text-[10px] font-mono font-bold tracking-widest uppercase transition-colors border-b ${
                activeGroup === "supply" ? "border-[#00D1FF] text-[#00D1FF]" : "border-transparent text-slate-500 hover:text-slate-300"
              }`}
            >
              Supply & Labor
            </button>
            <button
              onClick={() => setActiveGroup("spillover")}
              className={`flex-1 text-center py-1 text-[10px] font-mono font-bold tracking-widest uppercase transition-colors border-b ${
                activeGroup === "spillover" ? "border-[#00D1FF] text-[#00D1FF]" : "border-transparent text-slate-500 hover:text-slate-300"
              }`}
            >
              Spillovers & Cost-Cuts
            </button>
          </div>

          <div className="space-y-4 max-h-[460px] overflow-y-auto pr-2">
            {activeGroup === "leakage" && (
              <>
                {/* MPC */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Marginal Propensity to Consume (MPC):</span>
                    <span className="text-[#00D1FF] font-bold">{multiplierParams.mpc.toFixed(2)}</span>
                  </div>
                  <input
                    type="range" min="0.10" max="0.90" step="0.01"
                    value={multiplierParams.mpc}
                    onChange={(e) => updateParam("mpc", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* MPS */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Marginal Propensity to Save (MPS):</span>
                    <span className="text-[#00D1FF] font-bold">{multiplierParams.mps.toFixed(2)}</span>
                  </div>
                  <input
                    type="range" min="0.05" max="0.50" step="0.01"
                    value={multiplierParams.mps}
                    onChange={(e) => updateParam("mps", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Tax Rate */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Average National Tax Rate:</span>
                    <span className="text-[#00D1FF] font-bold">{(multiplierParams.taxRate * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range" min="0.10" max="0.50" step="0.01"
                    value={multiplierParams.taxRate}
                    onChange={(e) => updateParam("taxRate", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Import Leakage */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Import Leakage (Overseas sourcing):</span>
                    <span className="text-[#00D1FF] font-bold">{(multiplierParams.importLeakage * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range" min="0.05" max="0.60" step="0.01"
                    value={multiplierParams.importLeakage}
                    onChange={(e) => updateParam("importLeakage", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Regional Leakage */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Regional Leakage (Capital flights):</span>
                    <span className="text-[#00D1FF] font-bold">{(multiplierParams.regionalLeakage * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range" min="0.10" max="0.60" step="0.01"
                    value={multiplierParams.regionalLeakage}
                    onChange={(e) => updateParam("regionalLeakage", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Supply Chain Retention */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Domestic Supply Chain Retention:</span>
                    <span className="text-[#00D1FF] font-bold">{(multiplierParams.supplyChainRetention * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range" min="0.40" max="0.95" step="0.01"
                    value={multiplierParams.supplyChainRetention}
                    onChange={(e) => updateParam("supplyChainRetention", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>
              </>
            )}

            {activeGroup === "supply" && (
              <>
                {/* Capital Productivity */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Elasticity of Capital (Productivity):</span>
                    <span className="text-[#00D1FF] font-bold">{multiplierParams.capitalProductivity.toFixed(2)}</span>
                  </div>
                  <input
                    type="range" min="0.10" max="0.60" step="0.01"
                    value={multiplierParams.capitalProductivity}
                    onChange={(e) => updateParam("capitalProductivity", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Labour Participation */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Labour Mobilisation Coefficient:</span>
                    <span className="text-[#00D1FF] font-bold">{multiplierParams.labourParticipation.toFixed(2)}</span>
                  </div>
                  <input
                    type="range" min="0.50" max="0.95" step="0.01"
                    value={multiplierParams.labourParticipation}
                    onChange={(e) => updateParam("labourParticipation", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Infra Efficiency */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Institutional Allocation Efficiency:</span>
                    <span className="text-[#00D1FF] font-bold">{(multiplierParams.infraEfficiency * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range" min="0.40" max="0.99" step="0.01"
                    value={multiplierParams.infraEfficiency}
                    onChange={(e) => updateParam("infraEfficiency", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Construction Productivity */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Construction Labor Efficiency:</span>
                    <span className="text-[#00D1FF] font-bold">{multiplierParams.constructionProductivity.toFixed(2)}</span>
                  </div>
                  <input
                    type="range" min="0.30" max="0.95" step="0.01"
                    value={multiplierParams.constructionProductivity}
                    onChange={(e) => updateParam("constructionProductivity", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Private Investment Crowding-In */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Private Investment Crowding-In:</span>
                    <span className="text-[#00D1FF] font-bold">{multiplierParams.crowdingIn.toFixed(2)}x</span>
                  </div>
                  <input
                    type="range" min="0.20" max="2.00" step="0.05"
                    value={multiplierParams.crowdingIn}
                    onChange={(e) => updateParam("crowdingIn", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Crowding-Out */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Credit Crowding-Out Factor:</span>
                    <span className="text-[#00D1FF] font-bold">{multiplierParams.crowdingOut.toFixed(2)}x</span>
                  </div>
                  <input
                    type="range" min="0.00" max="1.00" step="0.02"
                    value={multiplierParams.crowdingOut}
                    onChange={(e) => updateParam("crowdingOut", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>
              </>
            )}

            {activeGroup === "spillover" && (
              <>
                {/* Innovation Spillovers */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Innovation & R&D Spillovers:</span>
                    <span className="text-[#00D1FF] font-bold">{multiplierParams.innovationSpillovers.toFixed(2)}</span>
                  </div>
                  <input
                    type="range" min="0.10" max="0.90" step="0.02"
                    value={multiplierParams.innovationSpillovers}
                    onChange={(e) => updateParam("innovationSpillovers", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Agglomeration Effects */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Regional Agglomeration Elasticity:</span>
                    <span className="text-[#00D1FF] font-bold">{multiplierParams.agglomerationEffects.toFixed(2)}</span>
                  </div>
                  <input
                    type="range" min="0.10" max="0.90" step="0.02"
                    value={multiplierParams.agglomerationEffects}
                    onChange={(e) => updateParam("agglomerationEffects", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Energy Cost Reduction */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Industry Energy Cost Reductions:</span>
                    <span className="text-[#00D1FF] font-bold">{(multiplierParams.energyCostReduction * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range" min="0.00" max="0.80" step="0.02"
                    value={multiplierParams.energyCostReduction}
                    onChange={(e) => updateParam("energyCostReduction", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Logistics Cost Reduction */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Logistics & Freight Friction Cuts:</span>
                    <span className="text-[#00D1FF] font-bold">{(multiplierParams.logisticsCostReduction * 100).toFixed(0)}%</span>
                  </div>
                  <input
                    type="range" min="0.00" max="0.80" step="0.02"
                    value={multiplierParams.logisticsCostReduction}
                    onChange={(e) => updateParam("logisticsCostReduction", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>

                {/* Digital Productivity */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-mono">
                    <span className="text-slate-400">Digital / Sovereign AI Connectivity:</span>
                    <span className="text-[#00D1FF] font-bold">{multiplierParams.digitalProductivity.toFixed(2)}</span>
                  </div>
                  <input
                    type="range" min="0.10" max="0.95" step="0.02"
                    value={multiplierParams.digitalProductivity}
                    onChange={(e) => updateParam("digitalProductivity", parseFloat(e.target.value))}
                    className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
                  />
                </div>
              </>
            )}
          </div>
        </div>

        {/* Right Hand side: HUD Stats & School Comparison Chart (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Main School HUD */}
          <div className="bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200">
                  {selectedSchool} Elasticity Core
                </h3>
                <p className="text-xs text-slate-500 font-mono">Active multiplier estimations for a standard £100m spend</p>
              </div>
              <div className="text-right">
                <span className="text-slate-500 text-[10px] font-mono block uppercase">GDP Multiplier</span>
                <span className="text-3xl font-extrabold font-mono text-[#00D1FF]">
                  {currentResults.gdpMultiplier.toFixed(3)}x
                </span>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t border-[#1E2024] font-mono text-xs">
              {/* Regional Multiplier */}
              <div>
                <span className="text-slate-500 text-[10px] block">Regional Mult:</span>
                <span className="font-bold text-slate-300">{currentResults.netRegionalMultiplier.toFixed(3)}x</span>
              </div>
              {/* Private Crowded-In */}
              <div>
                <span className="text-slate-500 text-[10px] block">Crowded-In capital:</span>
                <span className="font-bold text-slate-300">£{currentResults.privateCrowdedIn.toFixed(1)}m</span>
              </div>
              {/* Total GDP Impact */}
              <div>
                <span className="text-slate-500 text-[10px] block">Net Output Gain:</span>
                <span className="font-bold text-emerald-400">£{currentResults.totalGdpImpact.toFixed(1)}m</span>
              </div>
              {/* Jobs per £100m */}
              <div>
                <span className="text-slate-500 text-[10px] block">Employment Yield:</span>
                <span className="font-bold text-slate-300">{currentResults.jobsCreatedPer100m.toLocaleString()} FTE</span>
              </div>
            </div>

            {/* Sustainability Panel */}
            <div className="mt-4 bg-[#0A0B0D]/60 rounded border border-[#1E2024]/80 p-3.5 flex justify-between items-center text-xs font-mono">
              <div className="space-y-1 pr-4">
                <span className="text-slate-400 font-bold flex items-center">
                  <ShieldCheck className="w-4 h-4 text-emerald-500 mr-1.5" /> Debt Sustainability Index (DSI)
                </span>
                <p className="text-[10px] text-slate-500 leading-relaxed">
                  Measures whether future sovereign fiscal returns from GDP growth cover the debt debt-servicing limits.
                </p>
              </div>
              <div className="text-center shrink-0">
                <span className="text-[9px] text-slate-500 uppercase block">Sustainability</span>
                <span className={`text-xl font-extrabold font-mono ${
                  currentResults.debtSustainabilityIndex >= 70 ? "text-emerald-500" : currentResults.debtSustainabilityIndex >= 45 ? "text-amber-500" : "text-rose-500"
                }`}>
                  {currentResults.debtSustainabilityIndex}/100
                </span>
              </div>
            </div>
          </div>

          {/* School Comparison Chart */}
          <div className="bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20">
            <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200 mb-4">
              Multiplier Variations across Economic Schools
            </h3>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={schoolComparisons} margin={{ top: 10, right: 10, left: -20, bottom: 5 }}>
                  <XAxis dataKey="name" stroke="#475569" fontSize={9} fontStyle="italic" />
                  <YAxis stroke="#475569" fontSize={10} />
                  <Tooltip 
                    contentStyle={{ backgroundColor: "#0A0B0D", border: "1px solid #1E2024", borderRadius: "8px", fontFamily: "monospace" }}
                    labelStyle={{ color: "#94a3b8" }}
                  />
                  <Bar dataKey="multiplier" radius={[4, 4, 0, 0]}>
                    {schoolComparisons.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.isCurrent ? "#00D1FF" : "#1E2024"} 
                        stroke={entry.isCurrent ? "#00D1FF" : "transparent"}
                        className="cursor-pointer transition-opacity hover:opacity-80"
                        onClick={() => setSelectedSchool(entry.name as EconomicSchool)}
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
            <div className="text-[10px] text-slate-500 font-mono italic text-center mt-2">
              * Click on any bar to dynamically re-bind the primary model to that school of economic theory.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
