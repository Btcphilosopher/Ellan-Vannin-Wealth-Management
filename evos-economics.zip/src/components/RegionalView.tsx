/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { MapPin, Globe, Compass, Star, TrendingUp, Info } from "lucide-react";
import { CountyMetrics } from "../types";
import { getMetricIntensity, HeatmapMode as HeatmapModeEnum } from "../models/regionalModel";

interface RegionalViewProps {
  counties: CountyMetrics[];
  setCounties: React.Dispatch<React.SetStateAction<CountyMetrics[]>>;
}

export default function RegionalView({
  counties,
  setCounties
}: RegionalViewProps) {
  const [selectedCountyId, setSelectedCountyId] = useState<string>("reg_iom");
  const [heatmapMode, setHeatmapMode] = useState<HeatmapModeEnum>(HeatmapModeEnum.InvestmentOpportunity);

  const activeCounty = counties.find(c => c.id === selectedCountyId) || counties[0];

  // Helper to resolve heat map hex colors
  const getHeatColor = (intensity: number) => {
    // scale from cold dark slate/navy to glowing cyan (#00D1FF)
    // Intensity is 0 to 1
    const r = Math.round(15 + intensity * (0 - 15));
    const g = Math.round(23 + intensity * (209 - 23));
    const b = Math.round(42 + intensity * (255 - 42));
    return `rgb(${r}, ${g}, ${b})`;
  };

  // Pre-defined connectivity lines (network grids)
  const connections = [
    { from: "reg_iom", to: "reg_scotland", label: "Caledonian High-Speed Rail" },
    { from: "reg_iom", to: "reg_northwest", label: "Ferry Cargo Link" },
    { from: "reg_iom", to: "reg_nireland", label: "Douglas-Belfast Power Cable" },
    { from: "reg_iom", to: "reg_wales", label: "Irish Sea Smart Grid" },
    { from: "reg_northwest", to: "reg_london", label: "National Spine Core" },
    { from: "reg_london", to: "reg_east", label: "Sovereign AI Fiber" },
    { from: "reg_midlands", to: "reg_yorkshire", label: "Freight Canal Core" },
    { from: "reg_wales", to: "reg_southwest", label: "Severn Tidal Ingress" }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="border-b border-[#1E2024] pb-4">
        <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center space-x-2">
          <Globe className="w-5 h-5 text-[#00D1FF]" />
          <span>SOVEREIGN REGIONAL SPATIAL ECONOMICS</span>
        </h2>
        <p className="text-xs text-slate-500 font-mono">
          Interactive Isle of Man & UK geospatial infrastructure heatmaps.
        </p>
      </div>

      {/* Heatmap selectors */}
      <div className="flex flex-wrap gap-1.5 bg-[#0F1115] border border-[#1E2024] p-2 rounded-xl">
        {Object.values(HeatmapModeEnum).map(mode => (
          <button
            key={mode}
            onClick={() => setHeatmapMode(mode)}
            className={`px-3 py-1.5 text-[10px] font-mono rounded font-bold uppercase tracking-wider transition-colors ${
              heatmapMode === mode
                ? "bg-[#00D1FF] text-[#0A0B0D] shadow-md shadow-[#00D1FF]/10"
                : "bg-[#0A0B0D] border border-[#1E2024]/80 text-slate-400 hover:text-slate-200"
            }`}
          >
            {mode}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* SVG Interactive Map (7 cols) */}
        <div className="lg:col-span-7 bg-[#0F1115] border border-[#1E2024] rounded-xl p-4 flex flex-col items-center justify-center min-h-[460px] relative shadow-2xl overflow-hidden">
          {/* Legend */}
          <div className="absolute top-4 left-4 font-mono text-[9px] bg-[#0A0B0D] border border-[#1E2024] p-2.5 rounded space-y-1.5 z-10">
            <span className="text-slate-400 font-bold uppercase tracking-wider block mb-1">Heat Intensity</span>
            <div className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-[#0F172A] border border-[#1E2024]"></span>
              <span className="text-slate-500">Minimal Deficit / Core Baseline</span>
            </div>
            <div className="flex items-center space-x-1.5">
              <span className="w-2 h-2 rounded-full bg-[#00D1FF]"></span>
              <span className="text-slate-400">Peak Capacity / Max Opportunity</span>
            </div>
          </div>

          <div className="absolute top-4 right-4 font-mono text-[9px] text-slate-500 flex items-center space-x-1.5">
            <Compass className="w-3.5 h-3.5 text-slate-400 animate-spin" style={{ animationDuration: '20s' }} />
            <span>Isle of Man Strategic Node</span>
          </div>

          {/* Core Map Drawing */}
          <svg className="w-full max-w-lg aspect-[4/5] bg-[#0A0B0D]/20 rounded-xl border border-slate-900 shadow-inner" viewBox="0 0 100 100">
            {/* Grid background matching military radar layout */}
            <pattern id="radarGrid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#1e293b" strokeWidth="0.05" />
            </pattern>
            <rect width="100%" height="100%" fill="url(#radarGrid)" />

            {/* Concentric tactical circles */}
            <circle cx="50" cy="50" r="15" fill="none" stroke="#1e293b" strokeWidth="0.1" strokeDasharray="1 3" />
            <circle cx="50" cy="50" r="30" fill="none" stroke="#1e293b" strokeWidth="0.1" strokeDasharray="1 3" />

            {/* Draw transport and electrical grid connections */}
            {connections.map((conn, idx) => {
              const fromC = counties.find(c => c.id === conn.from);
              const toC = counties.find(c => c.id === conn.to);
              if (!fromC || !toC) return null;
              return (
                <g key={idx}>
                  <line
                    x1={fromC.coordinates[0]}
                    y1={fromC.coordinates[1]}
                    x2={toC.coordinates[0]}
                    y2={toC.coordinates[1]}
                    stroke="#1e293b"
                    strokeWidth="0.45"
                  />
                  <line
                    x1={fromC.coordinates[0]}
                    y1={fromC.coordinates[1]}
                    x2={toC.coordinates[0]}
                    y2={toC.coordinates[1]}
                    stroke="#00D1FF"
                    strokeWidth="0.2"
                    strokeDasharray="2 6"
                    className="animate-[dash_10s_linear_infinite]"
                  />
                </g>
              );
            })}

            {/* Draw regional nodes */}
            {counties.map(county => {
              const intensity = getMetricIntensity(county, heatmapMode, counties);
              const nodeColor = getHeatColor(intensity);
              const isSelected = county.id === selectedCountyId;
              const isIOM = county.id === "reg_iom";

              return (
                <g 
                  key={county.id} 
                  className="cursor-pointer" 
                  onClick={() => setSelectedCountyId(county.id)}
                >
                  {/* Selection glow ring */}
                  {isSelected && (
                    <circle
                      cx={county.coordinates[0]}
                      cy={county.coordinates[1]}
                      r={isIOM ? "5" : "3.5"}
                      fill="none"
                      stroke="#00D1FF"
                      strokeWidth="0.4"
                      className="animate-ping"
                      style={{ transformOrigin: `${county.coordinates[0]}px ${county.coordinates[1]}px` }}
                    />
                  )}

                  {/* Node outer border circle */}
                  <circle
                    cx={county.coordinates[0]}
                    cy={county.coordinates[1]}
                    r={isIOM ? "3.2" : "2.4"}
                    fill={nodeColor}
                    stroke={isSelected ? "#00D1FF" : "#1E2024"}
                    strokeWidth="0.5"
                    className="hover:stroke-slate-100 transition-colors"
                  />

                  {/* Special Isle of Man central star marker */}
                  {isIOM && (
                    <circle
                      cx={county.coordinates[0]}
                      cy={county.coordinates[1]}
                      r="0.8"
                      fill="#000"
                    />
                  )}

                  {/* Label background for legibility */}
                  <rect
                    x={county.coordinates[0] + (isIOM ? 4 : 3)}
                    y={county.coordinates[1] - 2}
                    width={county.name.length * 1.0}
                    height="4"
                    fill="#0A0B0D"
                    opacity="0.7"
                    rx="1"
                  />

                  {/* Text labels */}
                  <text
                    x={county.coordinates[0] + (isIOM ? 4.5 : 3.5)}
                    y={county.coordinates[1] + 1}
                    fill={isSelected ? "#00D1FF" : "#94a3b8"}
                    fontSize="2"
                    fontFamily="monospace"
                    fontWeight={isSelected ? "bold" : "normal"}
                  >
                    {isIOM ? "Ellan Vannin (HQ)" : county.name.split(" ")[0]}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Selected County HUD card (5 cols) */}
        <div className="lg:col-span-5 bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex justify-between items-start border-b border-[#1E2024] pb-3">
              <div>
                <h3 className="text-base font-bold font-mono text-slate-100 flex items-center">
                  <MapPin className="w-4 h-4 text-[#00D1FF] mr-1.5 shrink-0" /> {activeCounty.name}
                </h3>
                <span className="text-[10px] text-slate-500 font-mono">Registry ID: {activeCounty.id}</span>
              </div>
              <span className="bg-[#00D1FF]/10 border border-[#00D1FF]/30 text-[#00D1FF] font-bold px-2 py-0.5 rounded text-[10px] font-mono">
                {activeCounty.id === "reg_iom" ? "SWF HQ Node" : "Standard Zone"}
              </span>
            </div>

            {/* Demographics & Production */}
            <div className="grid grid-cols-2 gap-4 font-mono text-[11px] border-b border-[#1E2024]/60 pb-3">
              <div>
                <span className="text-slate-500 block">Regional GDP Size:</span>
                <strong className="text-slate-300 text-sm">£{activeCounty.gdp.toFixed(1)}bn</strong>
              </div>
              <div>
                <span className="text-slate-500 block">Core Population:</span>
                <strong className="text-slate-300 text-sm">{activeCounty.population.toLocaleString()}k</strong>
              </div>
              <div>
                <span className="text-slate-500 block">Wages (Avg/Yr):</span>
                <strong className="text-slate-300 text-sm">£{activeCounty.avgWage.toLocaleString()}</strong>
              </div>
              <div>
                <span className="text-slate-500 block">Electricity Price:</span>
                <strong className="text-slate-300 text-sm">{activeCounty.electricityCost.toFixed(1)} p/kWh</strong>
              </div>
            </div>

            {/* Regional Performance Metrics */}
            <div className="space-y-3 font-mono text-xs">
              <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">Local Multipliers & Gaps</span>
              
              {/* Productivity progress */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">Labor Productivity:</span>
                  <span className="text-slate-200">£{activeCounty.productivity.toFixed(1)}/hr</span>
                </div>
                <div className="w-full bg-[#0A0B0D] rounded h-1.5 overflow-hidden">
                  <div className="bg-[#00D1FF] h-full" style={{ width: `${(activeCounty.productivity / 70) * 100}%` }}></div>
                </div>
              </div>

              {/* Infra Quality progress */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">Infrastructure Quality Index:</span>
                  <span className="text-slate-200">{activeCounty.infraQuality}/100</span>
                </div>
                <div className="w-full bg-[#0A0B0D] rounded h-1.5 overflow-hidden">
                  <div className="bg-[#00D1FF] h-full" style={{ width: `${activeCounty.infraQuality}%` }}></div>
                </div>
              </div>

              {/* Connectivity progress */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px]">
                  <span className="text-slate-400">Transport Connectivity Index:</span>
                  <span className="text-slate-200">{activeCounty.connectivity}/100</span>
                </div>
                <div className="w-full bg-[#0A0B0D] rounded h-1.5 overflow-hidden">
                  <div className="bg-[#00D1FF] h-full" style={{ width: `${activeCounty.connectivity}%` }}></div>
                </div>
              </div>
            </div>
          </div>

          {/* Expected returns info bottom */}
          <div className="bg-[#0A0B0D] p-3 rounded-xl border border-[#1E2024]/80 mt-4 flex justify-between items-center text-xs font-mono">
            <div className="flex items-center space-x-2">
              <Star className="w-4 h-4 text-[#00D1FF] animate-pulse" />
              <div>
                <span className="text-slate-500 text-[10px] block">Expected Regional IRR</span>
                <span className="text-slate-200 font-bold">{activeCounty.expectedIrr}%</span>
              </div>
            </div>
            <div className="text-right">
              <span className="text-slate-500 text-[10px] block flex items-center justify-end">
                <TrendingUp className="w-3.5 h-3.5 mr-1 text-emerald-500" /> Projected GDP Growth
              </span>
              <span className="text-emerald-400 font-bold">{activeCounty.expectedGdpGrowth}% / Yr</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
