/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { 
  TrendingUp, 
  Activity, 
  Briefcase, 
  Clock, 
  Coins, 
  Sparkles,
  AlertTriangle,
  Info
} from "lucide-react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Cell, 
  Pie, 
  AreaChart, 
  Area 
} from "recharts";
import { EconomicSchool, InfraProject, ProjectCategory, ProjectResults } from "../types";

interface DashboardViewProps {
  selectedSchool: EconomicSchool;
  projects: InfraProject[];
  evaluations: Record<string, ProjectResults>;
  toggleProject: (id: string) => void;
  selectedYear: number;
  simulationData: any[];
}

export default function DashboardView({
  selectedSchool,
  projects,
  evaluations,
  toggleProject,
  selectedYear,
  simulationData
}: DashboardViewProps) {
  // Aggregate stats
  const activeProjects = projects.filter(p => p.selected);
  const totalCapex = activeProjects.reduce((sum, p) => sum + p.capex, 0); // millions
  const totalFundLimit = 35000; // £35bn sovereign allocation
  const remainingCash = Math.max(0, totalFundLimit - totalCapex);

  const totalNpv = activeProjects.reduce((sum, p) => sum + (evaluations[p.id]?.npv || 0), 0);
  const totalEconNpv = activeProjects.reduce((sum, p) => sum + (evaluations[p.id]?.econNpv || 0), 0);
  const totalJobs = activeProjects.reduce((sum, p) => sum + (evaluations[p.id]?.employmentImpact || 0), 0);
  const netCarbon = activeProjects.reduce((sum, p) => sum + (evaluations[p.id]?.carbonImpact || 0), 0); // tons co2 reduced

  // Weighted average economic multiplier
  const totalMultiplierSum = activeProjects.reduce((sum, p) => sum + (evaluations[p.id]?.multiplier || 0) * p.capex, 0);
  const avgMultiplier = totalCapex > 0 ? totalMultiplierSum / totalCapex : 1.25;

  // Average risk indicators
  const avgStrategic = activeProjects.reduce((sum, p) => sum + p.strategicImportance, 0) / (activeProjects.length || 1);
  const avgPolitical = activeProjects.reduce((sum, p) => sum + p.politicalRisk, 0) / (activeProjects.length || 1);
  const avgConstruction = activeProjects.reduce((sum, p) => sum + p.constructionRisk, 0) / (activeProjects.length || 1);
  const avgOperational = activeProjects.reduce((sum, p) => sum + p.operationalRisk, 0) / (activeProjects.length || 1);
  const avgLiquidity = activeProjects.reduce((sum, p) => sum + p.liquidityRisk, 0) / (activeProjects.length || 1);

  // Allocation data for Pie chart
  const categoryCapex = Object.values(ProjectCategory).map(cat => {
    const amt = activeProjects.filter(p => p.category === cat).reduce((sum, p) => sum + p.capex, 0);
    return { name: cat, value: amt };
  }).filter(item => item.value > 0);

  const COLORS = ["#f59e0b", "#10b981", "#3b82f6", "#ec4899", "#8b5cf6", "#14b8a6"];

  // GDP trajectory for line chart
  const gdpChartData = simulationData.map(d => ({
    year: `Yr ${d.year}`,
    gdp: d.gdp,
    debt: d.govDebt
  }));

  // Helper for traffic-light system
  const getTrafficLight = (score: number, invert: boolean = false) => {
    // Standard: low is green, high is red
    // Invert: high is green, low is red (for strategic importance)
    if (invert) {
      if (score >= 85) return "text-emerald-500 bg-emerald-500/10 border-emerald-500/30";
      if (score >= 60) return "text-amber-500 bg-amber-500/10 border-amber-500/30";
      return "text-rose-500 bg-rose-500/10 border-rose-500/30";
    } else {
      if (score < 25) return "text-emerald-500 bg-emerald-500/10 border-emerald-500/30";
      if (score < 55) return "text-amber-500 bg-amber-500/10 border-amber-500/30";
      return "text-rose-500 bg-rose-500/10 border-rose-500/30";
    }
  };

  return (
    <div className="space-y-6">
      {/* Upper Terminal Section */}
      <div className="flex justify-between items-center border-b border-[#1E2024] pb-4">
        <div>
          <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center space-x-2">
            <Activity className="w-5 h-5 text-[#00D1FF]" />
            <span>EVOS ECO-CORE TERMINAL</span>
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Active Framework: <span className="text-[#00D1FF] font-semibold">{selectedSchool}</span> • Model Horizon: <span className="text-[#00D1FF] font-semibold">{selectedYear}Y</span>
          </p>
        </div>
        
        <div className="bg-[#0F1115] border border-[#1E2024] px-4 py-1.5 rounded flex items-center space-x-3 text-xs font-mono">
          <span className="text-slate-500">Live National GDP:</span>
          <span className="text-emerald-500 font-bold tracking-widest animate-pulse">
            £{(simulationData[simulationData.length - 1]?.gdp || 2400).toFixed(2)}bn
          </span>
          <span className="text-slate-700">|</span>
          <span className="text-slate-500">Growth:</span>
          <span className="text-emerald-500 font-bold">
            +{(simulationData[1]?.productivityGrowth || 1.25).toFixed(2)}%
          </span>
        </div>
      </div>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Deployed Capital */}
        <div id="kpi_deployed" className="bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 relative overflow-hidden shadow-lg shadow-black/30">
          <div className="flex justify-between items-start mb-4">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-widest font-mono">Capital Deployment</span>
            <Coins className="w-5 h-5 text-[#00D1FF]" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100">
            £{(totalCapex / 1000).toFixed(2)}bn
          </div>
          <p className="text-xs text-slate-500 mt-2 font-mono">
            Deployed from <span className="text-slate-300">£{(totalFundLimit / 1000).toFixed(1)}bn</span> allocation
          </p>
          <div className="w-full bg-[#1E2024] h-1 mt-4 rounded overflow-hidden">
            <div 
              className="bg-[#00D1FF] h-full transition-all duration-500" 
              style={{ width: `${(totalCapex / totalFundLimit) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* SWF Cash Reserve */}
        <div id="kpi_cash" className="bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 relative overflow-hidden shadow-lg shadow-black/30">
          <div className="flex justify-between items-start mb-4">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-widest font-mono">Cash Reserve Position</span>
            <Briefcase className="w-5 h-5 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100">
            £{(remainingCash / 1000).toFixed(2)}bn
          </div>
          <p className="text-xs text-slate-500 mt-2 font-mono">
            Unallocated liquidity on hand
          </p>
          <div className="w-full bg-[#1E2024] h-1 mt-4 rounded overflow-hidden">
            <div 
              className="bg-emerald-500 h-full transition-all duration-500" 
              style={{ width: `${(remainingCash / totalFundLimit) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* National Economic NPV */}
        <div id="kpi_multiplier" className="bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 relative overflow-hidden shadow-lg shadow-black/30">
          <div className="flex justify-between items-start mb-4">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-widest font-mono">Portfolio Economic NPV</span>
            <TrendingUp className="w-5 h-5 text-blue-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100">
            £{(totalEconNpv / 1000).toFixed(2)}bn
          </div>
          <p className="text-xs text-slate-500 mt-2 font-mono">
            Financial NPV: <span className="text-slate-300">£{(totalNpv / 1000).toFixed(2)}bn</span>
          </p>
          <div className="text-[10px] text-blue-400 mt-2 font-mono flex items-center">
            <Sparkles className="w-3 h-3 mr-1" /> Weighted Mult: {avgMultiplier.toFixed(2)}x
          </div>
        </div>

        {/* Employment and Carbon Spillovers */}
        <div id="kpi_jobs" className="bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 relative overflow-hidden shadow-lg shadow-black/30">
          <div className="flex justify-between items-start mb-4">
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-widest font-mono">Jobs & Carbon Impact</span>
            <Clock className="w-5 h-5 text-purple-500" />
          </div>
          <div className="text-2xl font-bold font-mono text-slate-100">
            {totalJobs.toLocaleString()}
          </div>
          <p className="text-xs text-slate-500 mt-2 font-mono">
            Full-time equivalent roles created
          </p>
          <div className="text-[10px] mt-2 font-mono flex items-center text-emerald-400">
            Net CO2: {(netCarbon / 1000000).toFixed(2)}m tons/yr reduction
          </div>
        </div>
      </div>

      {/* Main Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Economic Growth Projection Chart */}
        <div className="lg:col-span-2 bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20">
          <div className="flex justify-between items-center mb-6">
            <div className="space-y-1">
              <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200">Decadal GDP & Debt Simulation</h3>
              <p className="text-xs text-slate-500 font-mono">Long-term debt sustainability paths (£ billions)</p>
            </div>
          </div>
          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={gdpChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorGdp" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.2}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                  <linearGradient id="colorDebt" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#ef4444" stopOpacity={0.15}/>
                    <stop offset="95%" stopColor="#ef4444" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="year" stroke="#475569" fontSize={10} fontStyle="italic" />
                <YAxis stroke="#475569" fontSize={10} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#0A0B0D", border: "1px solid #1E2024", borderRadius: "8px", fontFamily: "monospace" }}
                  labelStyle={{ color: "#94a3b8" }}
                />
                <Area type="monotone" name="National GDP" dataKey="gdp" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorGdp)" />
                <Area type="monotone" name="Sovereign Debt" dataKey="govDebt" stroke="#ef4444" strokeWidth={1.5} strokeDasharray="3 3" fillOpacity={1} fill="url(#colorDebt)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Capital Allocation & Risk Metrics */}
        <div className="bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20 space-y-6">
          <div>
            <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200 mb-4">Portfolio Allocation</h3>
            {categoryCapex.length > 0 ? (
              <div className="flex items-center justify-between h-36">
                <div className="w-1/2 h-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={categoryCapex}
                        cx="50%"
                        cy="50%"
                        innerRadius={30}
                        outerRadius={50}
                        paddingAngle={4}
                        dataKey="value"
                      >
                        {categoryCapex.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Pie>
                    </PieChart>
                  </ResponsiveContainer>
                </div>
                <div className="w-1/2 space-y-1.5 font-mono text-[10px] pl-2 max-h-full overflow-y-auto">
                  {categoryCapex.map((item, index) => (
                    <div key={item.name} className="flex items-center justify-between text-slate-400">
                      <span className="flex items-center">
                        <span className="w-2 h-2 rounded-full mr-2 shrink-0" style={{ backgroundColor: COLORS[index % COLORS.length] }}></span>
                        <span className="truncate max-w-[100px]">{item.name}</span>
                      </span>
                      <span className="text-slate-200 font-bold">£{(item.value / 1000).toFixed(1)}b</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="h-36 flex items-center justify-center text-xs text-slate-500 font-mono italic">
                No active projects in portfolio
              </div>
            )}
          </div>

          <div className="border-t border-[#1E2024] pt-4">
            <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200 mb-3 flex items-center justify-between">
              <span>Risk Aggregation</span>
              <AlertTriangle className="w-4 h-4 text-rose-500" />
            </h3>
            <div className="space-y-2 font-mono text-[11px]">
              {/* Strategic Importance */}
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Strategic Importance:</span>
                <span className={`px-2 py-0.5 rounded text-[10px] border font-bold ${getTrafficLight(avgStrategic, true)}`}>
                  {Math.round(avgStrategic || 0)}%
                </span>
              </div>
              {/* Political Risk */}
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Political Volatility:</span>
                <span className={`px-2 py-0.5 rounded text-[10px] border font-bold ${getTrafficLight(avgPolitical)}`}>
                  {Math.round(avgPolitical || 0)}%
                </span>
              </div>
              {/* Construction Risk */}
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Construction Overruns:</span>
                <span className={`px-2 py-0.5 rounded text-[10px] border font-bold ${getTrafficLight(avgConstruction)}`}>
                  {Math.round(avgConstruction || 0)}%
                </span>
              </div>
              {/* Operational Risk */}
              <div className="flex items-center justify-between">
                <span className="text-slate-400">Operational Friction:</span>
                <span className={`px-2 py-0.5 rounded text-[10px] border font-bold ${getTrafficLight(avgOperational)}`}>
                  {Math.round(avgOperational || 0)}%
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Project Status Matrix (Pipeline) */}
      <div className="bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20">
        <div className="flex items-center space-x-2 mb-4">
          <Info className="w-4 h-4 text-[#00D1FF]" />
          <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200">Active Capital Allocation Matrix</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1E2024] text-slate-500 bg-[#0A0B0D]/40">
                <th className="py-2.5 px-3">State</th>
                <th className="py-2.5 px-3">Project Registry Name</th>
                <th className="py-2.5 px-3">Category</th>
                <th className="py-2.5 px-3 text-right">CAPEX (£m)</th>
                <th className="py-2.5 px-3 text-right">Financial IRR (%)</th>
                <th className="py-2.5 px-3 text-right">Economic IRR (%)</th>
                <th className="py-2.5 px-3 text-right">Econ NPV (£m)</th>
                <th className="py-2.5 px-3 text-right">Jobs Created</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E2024]">
              {projects.map(proj => {
                const evalRes = evaluations[proj.id];
                return (
                  <tr 
                    key={proj.id} 
                    className={`hover:bg-[#1E2024]/30 transition-colors ${proj.selected ? "" : "opacity-40"}`}
                  >
                    <td className="py-2 px-3">
                      <button
                        onClick={() => toggleProject(proj.id)}
                        className={`w-10 h-5 rounded-full p-0.5 transition-colors duration-200 focus:outline-none ${
                          proj.selected ? "bg-[#00D1FF]" : "bg-[#1E2024]"
                        }`}
                      >
                        <div className={`bg-[#0A0B0D] w-4 h-4 rounded-full shadow-md transform duration-200 ${
                          proj.selected ? "translate-x-5" : ""
                        }`}></div>
                      </button>
                    </td>
                    <td className="py-2 px-3 font-semibold text-slate-300">{proj.name}</td>
                    <td className="py-2 px-3 text-[10px] text-slate-400">
                      <span className="bg-[#1E2024] border border-[#2E3138] px-2 py-0.5 rounded">
                        {proj.category}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-right text-slate-300">£{proj.capex}</td>
                    <td className="py-2 px-3 text-right text-[#00D1FF] font-bold">{evalRes ? `${evalRes.irr}%` : "-"}</td>
                    <td className="py-2 px-3 text-right text-emerald-400 font-bold">{evalRes ? `${evalRes.econIrr}%` : "-"}</td>
                    <td className="py-2 px-3 text-right text-slate-300">£{evalRes ? evalRes.econNpv : "-"}</td>
                    <td className="py-2 px-3 text-right text-slate-400">{evalRes ? evalRes.employmentImpact.toLocaleString() : "-"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
