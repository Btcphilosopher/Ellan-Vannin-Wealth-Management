/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { TrendingUp, Sliders, Sparkles, Check, X, ShieldAlert } from "lucide-react";
import { ScatterChart, Scatter, XAxis, YAxis, ZAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { InfraProject, ProjectResults } from "../types";
import { optimizePortfolio, defaultOptimiserWeights, OptimiserWeights } from "../models/portfolioOptimiser";

interface OptimiserViewProps {
  projects: InfraProject[];
  toggleProject: (id: string) => void;
  evaluations: Record<string, ProjectResults>;
}

export default function OptimiserView({
  projects,
  toggleProject,
  evaluations
}: OptimiserViewProps) {
  const [weights, setWeights] = useState<OptimiserWeights>(defaultOptimiserWeights);

  const optimizedRows = optimizePortfolio(projects, evaluations, weights);

  const handleWeightChange = (key: keyof OptimiserWeights, val: number) => {
    setWeights(prev => ({
      ...prev,
      [key]: val
    }));
  };

  // Format data for Scatter Bubble Chart
  const bubbleData = optimizedRows.map(row => ({
    name: row.name,
    score: row.strategicScore, // X-axis (0-100)
    risk: row.riskIndex,       // Y-axis (0-100)
    capex: row.capex,          // Bubble size (Z-axis)
    selected: projects.find(p => p.id === row.id)?.selected || false,
    id: row.id
  }));

  const getRiskColor = (risk: number) => {
    if (risk < 25) return "#10b981"; // green
    if (risk < 55) return "#f59e0b"; // yellow
    return "#ef4444"; // red
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-[#1E2024] pb-4">
        <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center space-x-2">
          <TrendingUp className="w-5 h-5 text-[#00D1FF]" />
          <span>SOVEREIGN INFRASTRUCTURE PORTFOLIO OPTIMISER</span>
        </h2>
        <p className="text-xs text-slate-500 font-mono">
          Multi-attribute weighted project ranking using capital-return and risk parameters.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Sliders panel (4 cols) */}
        <div className="lg:col-span-4 bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20 space-y-4">
          <span className="text-[10px] font-bold text-slate-500 tracking-wider uppercase font-mono block mb-2 flex items-center">
            <Sliders className="w-4 h-4 text-[#00D1FF] mr-1.5" /> Core Scoring Weights
          </span>

          <div className="space-y-3.5 max-h-[460px] overflow-y-auto pr-1">
            {/* Financial IRR */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-slate-400">Financial IRR:</span>
                <span className="text-[#00D1FF] font-bold">{weights.financialIrr}</span>
              </div>
              <input
                type="range" min="0" max="100" step="5"
                value={weights.financialIrr}
                onChange={(e) => handleWeightChange("financialIrr", Number(e.target.value))}
                className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
              />
            </div>

            {/* Economic IRR */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-slate-400">Economic IRR:</span>
                <span className="text-[#00D1FF] font-bold">{weights.economicIrr}</span>
              </div>
              <input
                type="range" min="0" max="100" step="5"
                value={weights.economicIrr}
                onChange={(e) => handleWeightChange("economicIrr", Number(e.target.value))}
                className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
              />
            </div>

            {/* NPV */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-slate-400">Net Present Value (NPV):</span>
                <span className="text-[#00D1FF] font-bold">{weights.npv}</span>
              </div>
              <input
                type="range" min="0" max="100" step="5"
                value={weights.npv}
                onChange={(e) => handleWeightChange("npv", Number(e.target.value))}
                className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
              />
            </div>

            {/* GDP Generated */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-slate-400">Total GDP Stimulated:</span>
                <span className="text-[#00D1FF] font-bold">{weights.gdpGenerated}</span>
              </div>
              <input
                type="range" min="0" max="100" step="5"
                value={weights.gdpGenerated}
                onChange={(e) => handleWeightChange("gdpGenerated", Number(e.target.value))}
                className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
              />
            </div>

            {/* Employment */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-slate-400">Employment Yield:</span>
                <span className="text-[#00D1FF] font-bold">{weights.employment}</span>
              </div>
              <input
                type="range" min="0" max="100" step="5"
                value={weights.employment}
                onChange={(e) => handleWeightChange("employment", Number(e.target.value))}
                className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
              />
            </div>

            {/* Tax Revenue */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-slate-400">Fiscal Tax Base Widening:</span>
                <span className="text-[#00D1FF] font-bold">{weights.taxRevenue}</span>
              </div>
              <input
                type="range" min="0" max="100" step="5"
                value={weights.taxRevenue}
                onChange={(e) => handleWeightChange("taxRevenue", Number(e.target.value))}
                className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
              />
            </div>

            {/* Carbon Reduction */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-slate-400">Carbon Abatement (CO2):</span>
                <span className="text-[#00D1FF] font-bold">{weights.carbonReduction}</span>
              </div>
              <input
                type="range" min="0" max="100" step="5"
                value={weights.carbonReduction}
                onChange={(e) => handleWeightChange("carbonReduction", Number(e.target.value))}
                className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
              />
            </div>

            {/* Strategic Importance */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-slate-400">Strategic Sovereign Priority:</span>
                <span className="text-[#00D1FF] font-bold">{weights.strategicImportance}</span>
              </div>
              <input
                type="range" min="0" max="100" step="5"
                value={weights.strategicImportance}
                onChange={(e) => handleWeightChange("strategicImportance", Number(e.target.value))}
                className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
              />
            </div>

            {/* Risk Aversion */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono">
                <span className="text-slate-400 font-bold text-rose-400 flex items-center">
                  <ShieldAlert className="w-3.5 h-3.5 mr-1" /> Risk Aversion Penalty:
                </span>
                <span className="text-rose-400 font-bold">{weights.riskAversion}</span>
              </div>
              <input
                type="range" min="0" max="100" step="5"
                value={weights.riskAversion}
                onChange={(e) => handleWeightChange("riskAversion", Number(e.target.value))}
                className="w-full accent-rose-500 bg-[#1E2024] rounded h-1 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Bubble plot and ranked table (8 cols) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Executive Scatter Bubble Chart */}
          <div className="bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20">
            <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200 mb-4 flex items-center">
              <Sparkles className="w-4 h-4 text-[#00D1FF]" /> Risk-Return Strategic Mapping Cluster
            </h3>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <ScatterChart margin={{ top: 10, right: 10, bottom: 5, left: -20 }}>
                  <XAxis type="number" dataKey="score" name="Sovereign Strategic Score" stroke="#475569" fontSize={9} domain={[0, 100]} label={{ value: 'Sovereign Strategic Score', position: 'insideBottom', offset: -5, fill: '#475569', fontSize: 9, fontFamily: 'monospace' }} />
                  <YAxis type="number" dataKey="risk" name="Composite Risk Index" stroke="#475569" fontSize={9} domain={[0, 100]} label={{ value: 'Composite Risk Index', angle: -90, position: 'insideLeft', fill: '#475569', fontSize: 9, fontFamily: 'monospace' }} />
                  <ZAxis type="number" dataKey="capex" range={[50, 400]} />
                  <Tooltip 
                    cursor={{ strokeDasharray: '3 3' }} 
                    contentStyle={{ backgroundColor: "#0A0B0D", border: "1px solid #1E2024", borderRadius: "8px", fontFamily: "monospace" }}
                  />
                  <Scatter name="Infrastructure Asset Registry" data={bubbleData}>
                    {bubbleData.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.selected ? "#00D1FF" : "#334155"} 
                        stroke={entry.selected ? "#00B0D7" : "#1E2024"}
                        strokeWidth={entry.selected ? 1.5 : 1}
                        className="cursor-pointer transition-opacity hover:opacity-80"
                        onClick={() => toggleProject(entry.id)}
                      />
                    ))}
                  </Scatter>
                </ScatterChart>
              </ResponsiveContainer>
            </div>
            <div className="text-[10px] text-slate-500 font-mono italic text-center">
              * Bubble size corresponds to project CAPEX. Cyan: Selected. Slate: Deselected. Click bubbles to toggle inclusion.
            </div>
          </div>

          {/* Leaderboard Table */}
          <div className="bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20">
            <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200 mb-4">Optimiser Ranked Leaderboard</h3>
            <div className="overflow-x-auto max-h-64">
              <table className="w-full text-left border-collapse text-xs font-mono">
                <thead>
                  <tr className="border-b border-[#1E2024] text-slate-500 bg-[#0A0B0D]/40">
                    <th className="py-2 px-3">Rank</th>
                    <th className="py-2 px-3">Project Asset Name</th>
                    <th className="py-2 px-3 text-right">Strategic Score</th>
                    <th className="py-2 px-3 text-right">Composite Risk</th>
                    <th className="py-2 px-3 text-right">Return/£ (Econ NPV/CAPEX)</th>
                    <th className="py-2 px-3 text-right">Payback</th>
                    <th className="py-2 px-3 text-right">State</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#1E2024]">
                  {optimizedRows.map(row => {
                    const isSelected = projects.find(p => p.id === row.id)?.selected || false;
                    return (
                      <tr key={row.id} className={`hover:bg-slate-800/30 transition-colors ${isSelected ? "" : "opacity-50"}`}>
                      <td className="py-2 px-3 font-bold text-[#00D1FF]">#{row.rank}</td>
                      <td className="py-2 px-3 font-semibold text-slate-300">{row.name}</td>
                      <td className="py-2 px-3 text-right font-extrabold text-[#00D1FF]">{row.strategicScore}/100</td>
                      <td className="py-2 px-3 text-right">
                        <span className="font-bold" style={{ color: getRiskColor(row.riskIndex) }}>
                          {row.riskIndex}%
                        </span>
                      </td>
                      <td className="py-2 px-3 text-right text-slate-300">£{row.returnPerPound}</td>
                      <td className="py-2 px-3 text-right text-slate-400">{row.paybackPeriod}Y</td>
                      <td className="py-2 px-3 text-right">
                        <button
                          onClick={() => toggleProject(row.id)}
                          className={`px-2 py-0.5 rounded text-[9px] font-bold uppercase border transition-colors ${
                            projects.find(p => p.id === row.id)?.selected
                              ? "bg-[#00D1FF]/10 border border-[#00D1FF]/30 text-[#00D1FF]"
                              : "bg-[#0A0B0D] border border-[#1E2024] text-slate-500"
                          }`}
                        >
                          {projects.find(p => p.id === row.id)?.selected ? "Selected" : "Deselected"}
                        </button>
                      </td>
                    </tr>
                  );
                })}
                </tbody>
              </table>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
