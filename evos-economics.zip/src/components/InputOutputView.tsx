/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { GitMerge, Sparkles, Sliders, Info, Zap } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from "recharts";
import { IndustryIo, ProjectCategory } from "../types";
import { calculateLeontiefRipples, initialIndustries } from "../models/ioModel";

export default function InputOutputView() {
  const [shockCategory, setShockCategory] = useState<ProjectCategory>(ProjectCategory.Transport);
  const [shockAmount, setShockAmount] = useState<number>(1000); // £1,000m default

  // Build the final demand shock vector based on selected category
  // Different categories spend on different primary industries:
  // - Transport: Construction (50%), Steel (20%), Engineering (20%), Transport (10%)
  // - Energy: Engineering (40%), Construction (30%), Concrete (15%), Energy (15%)
  // - Digital: Software (55%), Construction (25%), Energy (20%)
  // - Social: Construction (60%), Healthcare/Education/Housing (40%)
  // - Environmental: Construction (40%), Engineering (30%), Concrete (20%), Forestry (10%)
  // - Industrial: Manufacturing (40%), Software (20%), Engineering (20%), Construction (20%)
  const getShockMap = (): Record<string, number> => {
    const shockMap: Record<string, number> = {};
    
    switch (shockCategory) {
      case ProjectCategory.Transport:
        shockMap["ind_construction"] = shockAmount * 0.50;
        shockMap["ind_steel"] = shockAmount * 0.20;
        shockMap["ind_engineering"] = shockAmount * 0.20;
        shockMap["ind_transport"] = shockAmount * 0.10;
        break;
      case ProjectCategory.Energy:
        shockMap["ind_engineering"] = shockAmount * 0.40;
        shockMap["ind_construction"] = shockAmount * 0.30;
        shockMap["ind_concrete"] = shockAmount * 0.15;
        shockMap["ind_energy"] = shockAmount * 0.15;
        break;
      case ProjectCategory.Digital:
        shockMap["ind_software"] = shockAmount * 0.55;
        shockMap["ind_construction"] = shockAmount * 0.25;
        shockMap["ind_energy"] = shockAmount * 0.20;
        break;
      case ProjectCategory.Social:
        shockMap["ind_construction"] = shockAmount * 0.60;
        shockMap["ind_education"] = shockAmount * 0.20;
        shockMap["ind_healthcare"] = shockAmount * 0.20;
        break;
      case ProjectCategory.Environment:
        shockMap["ind_construction"] = shockAmount * 0.40;
        shockMap["ind_engineering"] = shockAmount * 0.30;
        shockMap["ind_concrete"] = shockAmount * 0.20;
        shockMap["ind_agriculture"] = shockAmount * 0.10;
        break;
      case ProjectCategory.Industrial:
        shockMap["ind_manufacturing"] = shockAmount * 0.40;
        shockMap["ind_software"] = shockAmount * 0.20;
        shockMap["ind_engineering"] = shockAmount * 0.20;
        shockMap["ind_construction"] = shockAmount * 0.20;
        break;
    }

    return shockMap;
  };

  const shockMap = getShockMap();
  const ripples = calculateLeontiefRipples(shockMap);

  // Sorting results to show industries with the largest impact first
  const sortedRipples = [...ripples].sort((a, b) => b.total - a.total);

  const totalInduced = ripples.reduce((s, r) => s + r.induced, 0);
  const totalIndirect = ripples.reduce((s, r) => s + r.indirect, 0);
  const totalSupplyChain = ripples.reduce((s, r) => s + r.supplyChain, 0);
  const totalGdpImpact = ripples.reduce((s, r) => s + r.total, 0);

  const netLeontiefMultiplier = totalGdpImpact / shockAmount || 1.0;

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-[#1E2024] pb-4">
        <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center space-x-2">
          <GitMerge className="w-5 h-5 text-[#00D1FF]" />
          <span>LEONTIEF INPUT-OUTPUT INTER-INDUSTRY FLOWS</span>
        </h2>
        <p className="text-xs text-slate-500 font-mono">
          Simulate final demand shocks propagating through inter-industry production networks.
        </p>
      </div>

      {/* Input controller */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 bg-[#0F1115] border border-[#1E2024] p-5 rounded-xl">
        {/* Shock Category selection */}
        <div className="space-y-1.5">
          <label className="text-xs font-mono text-slate-400 block uppercase font-bold tracking-wider">Infrastructure Segment</label>
          <select
            value={shockCategory}
            onChange={(e) => setShockCategory(e.target.value as ProjectCategory)}
            className="w-full bg-[#0A0B0D] border border-[#1E2024] rounded px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-[#00D1FF]"
          >
            {Object.values(ProjectCategory).map(cat => (
              <option key={cat} value={cat}>{cat}</option>
            ))}
          </select>
        </div>

        {/* Shock Amount slider */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
            <span>Direct Capital Injection</span>
            <span className="text-[#00D1FF]">£{shockAmount.toLocaleString()}m</span>
          </div>
          <input
            type="range"
            min="100"
            max="10000"
            step="100"
            value={shockAmount}
            onChange={(e) => setShockAmount(Number(e.target.value))}
            className="w-full accent-[#00D1FF] bg-[#1E2024] rounded h-1 cursor-pointer"
          />
          <div className="flex justify-between text-[8px] text-slate-600 font-mono">
            <span>£100m</span>
            <span>£5,000m</span>
            <span>£10,000m</span>
          </div>
        </div>

        {/* Summary Output HUD */}
        <div className="bg-[#0A0B0D]/60 rounded border border-[#1E2024]/80 p-3 flex justify-between items-center text-xs font-mono">
          <div className="space-y-0.5">
            <span className="text-slate-500 text-[10px] uppercase block">Derived IO Multiplier</span>
            <strong className="text-[#00D1FF] text-lg">{netLeontiefMultiplier.toFixed(3)}x</strong>
          </div>
          <div className="text-right">
            <span className="text-slate-500 text-[10px] uppercase block">Total Output Ripple</span>
            <strong className="text-emerald-400 text-lg">£{Math.round(totalGdpImpact).toLocaleString()}m</strong>
          </div>
        </div>
      </div>

      {/* Main stacked bar visualization */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Graph (8 cols) */}
        <div className="lg:col-span-8 bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20 space-y-4">
          <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200">Decomposed Economic Spillover Wave</h3>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={sortedRipples}
                layout="vertical"
                margin={{ top: 10, right: 10, left: 30, bottom: 5 }}
              >
                <XAxis type="number" stroke="#475569" fontSize={9} label={{ value: 'GDP Output Stimulated (£ millions)', position: 'insideBottom', offset: -5, fill: '#475569', fontSize: 9, fontFamily: 'monospace' }} />
                <YAxis dataKey="sector" type="category" stroke="#475569" fontSize={9} width={100} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#0A0B0D", border: "1px solid #1E2024", borderRadius: "8px", fontFamily: "monospace" }}
                  labelStyle={{ color: "#94a3b8" }}
                />
                <Legend wrapperStyle={{ fontSize: '9px', fontFamily: 'monospace' }} />
                <Bar name="Direct Initial Shock" dataKey="direct" stackId="a" fill="#00D1FF" />
                <Bar name="Indirect Supplies" dataKey="indirect" stackId="a" fill="#3b82f6" />
                <Bar name="Supply-Chain Loops" dataKey="supplyChain" stackId="a" fill="#8b5cf6" />
                <Bar name="Induced Wages Spending" dataKey="induced" stackId="a" fill="#10b981" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Detailed transaction summaries (4 cols) */}
        <div className="lg:col-span-4 bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20 flex flex-col justify-between">
          <div className="space-y-4">
            <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200">Propagation breakdown</h3>
            <div className="space-y-3 font-mono text-xs">
              <div className="flex justify-between items-center pb-2 border-b border-[#1E2024]">
                <span className="text-slate-500">Initial Direct Investment:</span>
                <span className="text-[#00D1FF] font-bold">£{shockAmount.toLocaleString()}m</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-[#1E2024]">
                <span className="text-slate-500">Indirect Purchases (Suppliers):</span>
                <span className="text-blue-400 font-bold">+£{Math.round(totalIndirect).toLocaleString()}m</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-[#1E2024]">
                <span className="text-slate-500">Supply-Chain Multiplier loops:</span>
                <span className="text-purple-400 font-bold">+£{Math.round(totalSupplyChain).toLocaleString()}m</span>
              </div>
              <div className="flex justify-between items-center pb-2 border-b border-[#1E2024]">
                <span className="text-slate-500">Induced Consumption (Wages):</span>
                <span className="text-emerald-400 font-bold">+£{Math.round(totalInduced).toLocaleString()}m</span>
              </div>
              <div className="flex justify-between items-center pt-2 font-extrabold text-sm border-t-2 border-dashed border-[#1E2024]">
                <span className="text-slate-300">Total Output expansion:</span>
                <span className="text-emerald-400">£{Math.round(totalGdpImpact).toLocaleString()}m</span>
              </div>
            </div>
          </div>

          <div className="bg-[#0A0B0D] p-3.5 rounded-lg border border-[#1E2024]/80 text-[10px] font-mono text-slate-500 leading-relaxed mt-4 flex items-start space-x-2">
            <Info className="w-4 h-4 text-[#00D1FF] shrink-0 mt-0.5" />
            <span>
              * Based on the <strong>Leontief Inverse Matrix $(I - A)^{-1}$</strong> calculated via standard Neumann Power series expansions. Direct shocks stimulate supplier inputs which cascade indefinitely into wages and consumption.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
