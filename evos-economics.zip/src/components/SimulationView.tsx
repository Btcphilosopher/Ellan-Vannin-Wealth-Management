/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { LineChart as ChartIcon, Eye, Download, Info, Zap, Sparkles } from "lucide-react";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  CartesianGrid, 
  AreaChart, 
  Area 
} from "recharts";
import { MacroSimResults } from "../types";

interface SimulationViewProps {
  simulationData: MacroSimResults[];
}

type PlotVariable = "gdp" | "govDebt" | "debtToGdp" | "infraStock" | "productivityGrowth" | "exports" | "energyDemand" | "constructionOutput" | "industrialProduction";

export default function SimulationView({
  simulationData
}: SimulationViewProps) {
  const [activePlotVar, setActivePlotVar] = useState<PlotVariable>("gdp");

  // Plot details helper
  const varMeta: Record<PlotVariable, { label: string; stroke: string; fill: string; unit: string; desc: string }> = {
    gdp: { label: "National GDP", stroke: "#10b981", fill: "rgba(16, 185, 129, 0.1)", unit: "£bn", desc: "Real Gross Domestic Product driven by consumption, investment, and exports." },
    govDebt: { label: "Sovereign Debt", stroke: "#ef4444", fill: "rgba(239, 68, 68, 0.1)", unit: "£bn", desc: "Accumulated national borrowing, updated for interest payments and tax revenues." },
    debtToGdp: { label: "Debt-to-GDP Ratio", stroke: "#8b5cf6", fill: "rgba(139, 92, 246, 0.1)", unit: "%", desc: "Debt burden ratio relative to GDP. Below 60% indicates strong sustainability." },
    infraStock: { label: "Infrastructure Capital Stock", stroke: "#3b82f6", fill: "rgba(59, 130, 246, 0.1)", unit: "£bn", desc: "Accumulated net public assets, depreciated over time and boosted by CAPEX." },
    productivityGrowth: { label: "Annual Productivity Growth", stroke: "#f59e0b", fill: "rgba(245, 158, 11, 0.1)", unit: "%/yr", desc: "Underlying structural efficiency gains driven by digital/transport networks." },
    exports: { label: "Sovereign Exports", stroke: "#ec4899", fill: "rgba(236, 72, 153, 0.1)", unit: "£bn", desc: "Total international exports stimulated by upgraded ports and logistics." },
    energyDemand: { label: "Energy Power Demands", stroke: "#14b8a6", fill: "rgba(20, 184, 166, 0.1)", unit: "TWh", desc: "Total national electrical power demand, mitigated by grid-efficiency boosts." },
    constructionOutput: { label: "Construction Industry Output", stroke: "#8b5cf6", fill: "rgba(139, 92, 246, 0.1)", unit: "£bn", desc: "Gross size of construction and aggregate materials sector in GDP." },
    industrialProduction: { label: "Advanced Industrial Production", stroke: "#6366f1", fill: "rgba(99, 102, 241, 0.1)", unit: "£bn", desc: "Output of heavy manufacturing, steel, concrete, and assembly plants." }
  };

  const activeMeta = varMeta[activePlotVar];

  // Client-side CSV Download function
  const downloadCsv = () => {
    const headers = ["Year", "GDP (£bn)", "Inflation (%)", "Population (m)", "Employment (m)", "Tax Receipts (£bn)", "Gov Debt (£bn)", "Debt-to-GDP (%)", "Productivity Growth (%)", "Exports (£bn)", "Energy Demand (TWh)", "Construction (£bn)", "Industrial Production (£bn)"];
    
    const rows = simulationData.map(d => [
      d.year, d.gdp, d.inflation, d.population, d.employment, d.taxReceipts, d.govDebt, d.debtToGdp, d.productivityGrowth, d.exports, d.energyDemand, d.constructionOutput, d.industrialProduction
    ]);

    const csvContent = "data:text/csv;charset=utf-8," 
      + [headers.join(","), ...rows.map(e => e.join(","))].join("\n");
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `evos_macroeconomic_simulation_${simulationData.length - 1}y.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div className="border-b border-[#1E2024] pb-4 flex justify-between items-center">
        <div>
          <h2 className="text-xl font-bold font-mono tracking-tight text-slate-100 flex items-center space-x-2">
            <ChartIcon className="w-5 h-5 text-[#00D1FF]" />
            <span>DYNAMIC MACROECONOMIC FORECASTS</span>
          </h2>
          <p className="text-xs text-slate-500 font-mono">
            Decadal state-space transition equations mapping capital depletion.
          </p>
        </div>
        <button
          onClick={downloadCsv}
          className="bg-[#0F1115] border border-[#1E2024] text-slate-300 hover:text-[#00D1FF] hover:border-[#00D1FF]/50 px-3 py-1.5 rounded text-xs font-mono flex items-center space-x-1.5 transition-colors"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export CSV Dataset</span>
        </button>
      </div>

      {/* Main Plot Panel (Grid) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Variable Selection Hud (3 cols) */}
        <div className="lg:col-span-3 bg-[#0F1115] border border-[#1E2024] rounded-xl p-4 space-y-2 max-h-[420px] overflow-y-auto">
          <span className="text-[10px] font-bold text-slate-500 tracking-wider uppercase font-mono block mb-2">Select Plot Variable</span>
          {Object.entries(varMeta).map(([key, meta]) => {
            const isSelected = key === activePlotVar;
            const latestVal = simulationData[simulationData.length - 1]?.[key as keyof MacroSimResults] || 0;
            return (
              <button
                key={key}
                onClick={() => setActivePlotVar(key as PlotVariable)}
                className={`w-full text-left p-2 rounded border font-mono transition-all flex justify-between items-center ${
                  isSelected 
                    ? "bg-[#0A0B0D] border-[#00D1FF] text-[#00D1FF]" 
                    : "bg-[#0A0B0D]/40 border-transparent text-slate-400 hover:text-slate-200"
                }`}
              >
                <div className="space-y-0.5">
                  <span className="text-[10px] uppercase block tracking-wide">{meta.label}</span>
                  <span className="text-[9px] text-slate-500 block leading-tight">{meta.unit} indicator</span>
                </div>
                <span className="text-xs font-bold text-right">
                  {latestVal.toLocaleString()}
                </span>
              </button>
            );
          })}
        </div>

        {/* Dynamic Chart Display (9 cols) */}
        <div className="lg:col-span-9 bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20 space-y-4">
          <div className="flex justify-between items-start border-b border-[#1E2024]/60 pb-3">
            <div>
              <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-[#00D1FF] flex items-center">
                <Eye className="w-4 h-4 mr-1.5" /> {activeMeta.label} Curve
              </h3>
              <p className="text-[11px] text-slate-500 font-mono mt-1 leading-relaxed">{activeMeta.desc}</p>
            </div>
            <div className="text-right shrink-0">
              <span className="text-[9px] text-slate-500 font-mono uppercase block">Terminal Val</span>
              <span className="text-lg font-extrabold font-mono text-slate-200">
                {(simulationData[simulationData.length - 1]?.[activePlotVar as keyof MacroSimResults] || 0).toLocaleString()} {activeMeta.unit}
              </span>
            </div>
          </div>

          <div className="h-72">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={simulationData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorPlot" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={activeMeta.stroke} stopOpacity={0.15}/>
                    <stop offset="95%" stopColor={activeMeta.stroke} stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid stroke="#1E2024" strokeDasharray="3 3" vertical={false} />
                <XAxis dataKey="year" stroke="#475569" fontSize={10} label={{ value: 'Simulation Year', position: 'insideBottom', offset: -10, fill: '#475569', fontSize: 10, fontFamily: 'monospace' }} />
                <YAxis stroke="#475569" fontSize={10} />
                <Tooltip 
                  contentStyle={{ backgroundColor: "#0A0B0D", border: "1px solid #1E2024", borderRadius: "8px", fontFamily: "monospace" }}
                  labelStyle={{ color: "#94a3b8" }}
                />
                <Area type="monotone" name={activeMeta.label} dataKey={activePlotVar} stroke={activeMeta.stroke} strokeWidth={2.5} fillOpacity={1} fill="url(#colorPlot)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Structured Year-By-Year Spreadsheet Table */}
      <div className="bg-[#0F1115] border border-[#1E2024] rounded-xl p-5 shadow-xl shadow-black/20">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Info className="w-4 h-4 text-[#00D1FF]" />
            <h3 className="text-sm font-bold font-mono tracking-wider uppercase text-slate-200">Year-by-Year Sovereign Balance Sheets</h3>
          </div>
          <span className="text-[10px] text-slate-500 font-mono italic">* Values represent real adjusted deflated units</span>
        </div>
        
        <div className="overflow-x-auto max-h-72 border border-[#1E2024] rounded">
          <table className="w-full text-left border-collapse text-xs font-mono">
            <thead>
              <tr className="border-b border-[#1E2024] text-slate-500 bg-[#0A0B0D] sticky top-0 z-10">
                <th className="py-2.5 px-3 bg-[#0A0B0D]">Year</th>
                <th className="py-2.5 px-3 text-right bg-[#0A0B0D]">GDP (£b)</th>
                <th className="py-2.5 px-3 text-right bg-[#0A0B0D]">Inflation (%)</th>
                <th className="py-2.5 px-3 text-right bg-[#0A0B0D]">Tax Receipts (£b)</th>
                <th className="py-2.5 px-3 text-right bg-[#0A0B0D]">Debt (£b)</th>
                <th className="py-2.5 px-3 text-right bg-[#0A0B0D]">Debt/GDP (%)</th>
                <th className="py-2.5 px-3 text-right bg-[#0A0B0D]">Capital Stock (£b)</th>
                <th className="py-2.5 px-3 text-right bg-[#0A0B0D]">Productivity Growth (%)</th>
                <th className="py-2.5 px-3 text-right bg-[#0A0B0D]">Exports (£b)</th>
                <th className="py-2.5 px-3 text-right bg-[#0A0B0D]">Energy Dem (TWh)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#1E2024]/60 bg-[#0A0B0D]/60">
              {simulationData.map(d => (
                <tr key={d.year} className="hover:bg-[#1E2024]/40 transition-colors">
                  <td className="py-2 px-3 font-semibold text-[#00D1FF]">{d.year === 0 ? "Baseline" : `Yr ${d.year}`}</td>
                  <td className="py-2 px-3 text-right text-slate-300">£{d.gdp.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right text-rose-500">{d.inflation}%</td>
                  <td className="py-2 px-3 text-right text-slate-300">£{d.taxReceipts.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right text-slate-300">£{d.govDebt.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right font-bold text-slate-300">{d.debtToGdp}%</td>
                  <td className="py-2 px-3 text-right text-slate-300">£{d.infraStock.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right text-emerald-400 font-bold">+{d.productivityGrowth}%</td>
                  <td className="py-2 px-3 text-right text-slate-300">£{d.exports.toLocaleString()}</td>
                  <td className="py-2 px-3 text-right text-slate-400">{d.energyDemand} TWh</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
