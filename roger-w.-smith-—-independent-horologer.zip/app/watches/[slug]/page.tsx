'use client';

import React, { useState, use } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Triskelion } from '@/components/Triskelion';
import { EnquiryModal } from '@/components/EnquiryModal';
import { WATCHES, Watch } from '@/lib/data/watches';
import { ShieldCheck, Check, ArrowLeft, Clock, Sparkles } from 'lucide-react';

interface WatchDetailPageProps {
  params: Promise<{ slug: string }>;
}

export default function WatchDetailPage({ params }: WatchDetailPageProps) {
  const resolvedParams = use(params);
  const watch = WATCHES.find((w) => w.slug === resolvedParams.slug);

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [enquiryOpen, setEnquiryOpen] = useState(false);

  if (!watch) {
    notFound();
  }

  const images = watch.galleryImages.length > 0 ? watch.galleryImages : [watch.heroImage];

  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col">
      <Header onOpenEnquiry={() => setEnquiryOpen(true)} />

      <main className="flex-1">
        {/* Back Link Breadcrumb */}
        <div className="border-b border-[#c4a265]/15 bg-[#061510]">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16 py-4 flex items-center justify-between text-xs tracking-[0.2em] uppercase text-[#8fa397]">
            <Link 
              href="/collection" 
              className="inline-flex items-center space-x-2 text-[#c4a265] hover:text-white transition-colors"
            >
              <ArrowLeft size={14} />
              <span>RETURN TO COLLECTION</span>
            </Link>
            <span className="hidden sm:inline text-white/40">
              {watch.series}
            </span>
          </div>
        </div>

        {/* Watch Showcase Grid */}
        <section className="py-12 lg:py-20 border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
              
              {/* Left Column: Gallery */}
              <div className="lg:col-span-7 space-y-4">
                <div className="relative aspect-square w-full bg-[#061510] border border-[#c4a265]/30 overflow-hidden shadow-2xl">
                  <Image
                    src={images[activeImageIndex] || watch.heroImage}
                    alt={`${watch.name} detail view`}
                    fill
                    priority
                    sizes="(max-width: 1024px) 100vw, 55vw"
                    className="object-cover object-center transition-all duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute bottom-4 right-4 bg-[#061510]/85 px-3 py-1 border border-[#c4a265]/30 text-[10px] tracking-[0.2em] uppercase text-[#dfc590]">
                    PLATE {activeImageIndex + 1} OF {images.length}
                  </div>
                </div>

                {/* Thumbnails */}
                {images.length > 1 && (
                  <div className="flex gap-4">
                    {images.map((img, idx) => (
                      <button
                        key={img}
                        type="button"
                        onClick={() => setActiveImageIndex(idx)}
                        className={`relative w-24 h-24 bg-[#061510] border overflow-hidden transition-all ${
                          activeImageIndex === idx ? 'border-[#c4a265] ring-1 ring-[#c4a265]' : 'border-white/10 opacity-70 hover:opacity-100'
                        }`}
                      >
                        <Image
                          src={img}
                          alt={`${watch.name} thumbnail ${idx + 1}`}
                          fill
                          className="object-cover"
                          referrerPolicy="no-referrer"
                        />
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Right Column: Timepiece Dossier & Acquisition Action */}
              <div className="lg:col-span-5 space-y-8 flex flex-col justify-between">
                <div className="space-y-4">
                  <div className="flex items-center space-x-2 text-[10px] tracking-[0.28em] uppercase text-[#c4a265]">
                    <Triskelion size={16} color="#c4a265" />
                    <span>{watch.series}</span>
                  </div>

                  <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl tracking-[0.14em] uppercase text-[#f4f1ea] font-normal">
                    {watch.name}
                  </h1>

                  <p className="text-xs sm:text-sm tracking-[0.2em] uppercase text-[#dfc590] font-light">
                    {watch.tagline}
                  </p>

                  <div className="w-12 h-[1px] bg-[#c4a265]/70" />

                  <p className="text-sm text-[#cbd6cf] font-light leading-relaxed">
                    {watch.longDescription}
                  </p>

                  <div className="bg-[#061510] border border-[#c4a265]/20 p-5 space-y-3">
                    <div className="text-[10px] tracking-[0.24em] uppercase text-[#c4a265] font-semibold border-b border-white/10 pb-2">
                      ATELIER ALLOCATION STATUS
                    </div>
                    <p className="text-xs text-[#a0b3a7] leading-relaxed">
                      Timepieces are individually allocated via private dialogue. Workshop production output is strictly calibrated to guarantee uncompromising hand-finishing.
                    </p>
                    <div className="pt-2">
                      <button
                        type="button"
                        onClick={() => setEnquiryOpen(true)}
                        className="w-full py-3.5 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-[0.22em] uppercase hover:bg-[#dfc590] transition-colors shadow-lg"
                      >
                        REQUEST ALLOCATION FOR {watch.name.toUpperCase()} →
                      </button>
                    </div>
                  </div>
                </div>

                {/* Quick Highlights */}
                <div className="border-t border-white/10 pt-6 space-y-3 text-xs">
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-[#8fa397]">Standard Case</span>
                    <span className="text-white font-medium">{watch.caseMaterial.split('(')[0]}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-[#8fa397]">Dimensions</span>
                    <span className="text-white font-mono">{watch.caseDiameter}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-[#8fa397]">Movement</span>
                    <span className="text-white font-mono">{watch.movementCalibre}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-[#8fa397]">Frequency</span>
                    <span className="text-white font-mono">{watch.vibrationsPerHour}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-white/5">
                    <span className="text-[#8fa397]">Production Status</span>
                    <span className="text-[#c4a265]">Bespoke Order Only</span>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* Verified Technical Specifications Table */}
        <section className="py-20 bg-[#071712]">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16 space-y-10">
            <div className="max-w-xl space-y-2">
              <span className="text-[10px] tracking-[0.28em] uppercase text-[#c4a265] font-medium">
                HOROLOGICAL ARCHIVE
              </span>
              <h2 className="font-serif text-2xl sm:text-3xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                VERIFIED SPECIFICATIONS
              </h2>
              <p className="text-xs text-[#8fa397]">
                Every technical specification is certified by the Isle of Man atelier.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {watch.specifications.map((spec, i) => (
                <div
                  key={`${spec.label}-${i}`}
                  className="bg-[#091b15] border border-[#c4a265]/20 p-5 space-y-2 hover:border-[#c4a265]/50 transition-colors"
                >
                  <div className="flex justify-between items-center">
                    <span className="text-[9px] tracking-[0.24em] uppercase text-[#c4a265]">
                      {spec.category}
                    </span>
                    {spec.verified && (
                      <span className="flex items-center space-x-1 text-[9px] text-[#8fa397]">
                        <ShieldCheck size={12} className="text-[#c4a265]" />
                        <span>VERIFIED</span>
                      </span>
                    )}
                  </div>
                  <div className="text-xs uppercase tracking-wider text-[#a7baa0]">
                    {spec.label}
                  </div>
                  <div className="text-sm text-[#f4f1ea] font-light leading-snug">
                    {spec.value}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />

      <EnquiryModal
        isOpen={enquiryOpen}
        onClose={() => setEnquiryOpen(false)}
        defaultWatchSlug={watch.slug}
        defaultWatchName={watch.name}
      />
    </div>
  );
}
