'use client';

import React, { use } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { notFound } from 'next/navigation';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { ARTICLES } from '@/lib/data/articles';
import { ArrowLeft, Clock, Calendar, User } from 'lucide-react';

interface ArticlePageProps {
  params: Promise<{ slug: string }>;
}

export default function ArticleDetailPage({ params }: ArticlePageProps) {
  const resolvedParams = use(params);
  const article = ARTICLES.find((a) => a.slug === resolvedParams.slug);

  if (!article) {
    notFound();
  }

  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Breadcrumb */}
        <div className="bg-[#061510] border-b border-[#c4a265]/15">
          <div className="max-w-[960px] mx-auto px-6 py-4">
            <Link
              href="/journal"
              className="inline-flex items-center space-x-2 text-xs tracking-[0.2em] uppercase text-[#c4a265] hover:text-white transition-colors"
            >
              <ArrowLeft size={14} />
              <span>RETURN TO JOURNAL</span>
            </Link>
          </div>
        </div>

        {/* Article Header */}
        <article className="py-16 lg:py-24 max-w-[960px] mx-auto px-6 space-y-12">
          <div className="space-y-6 text-center">
            <div className="flex items-center justify-center space-x-3 text-[10px] tracking-[0.26em] uppercase text-[#c4a265]">
              <span>{article.category}</span>
              <span>·</span>
              <span>{article.publishDate}</span>
              <span>·</span>
              <span>{article.readingTime}</span>
            </div>

            <h1 className="font-serif text-3xl sm:text-5xl lg:text-5xl text-white font-normal leading-tight">
              {article.title}
            </h1>

            <p className="text-base sm:text-lg text-[#cbd6cf] italic font-serif max-w-2xl mx-auto leading-relaxed">
              &ldquo;{article.summary}&rdquo;
            </p>

            <div className="pt-2 text-xs text-[#8fa397] tracking-wider uppercase">
              By {article.author}
            </div>
          </div>

          {/* Hero Image */}
          <div className="relative aspect-[16/9] w-full overflow-hidden border border-[#c4a265]/20 shadow-2xl">
            <Image
              src={article.heroImage}
              alt={article.title}
              fill
              priority
              className="object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Body Content */}
          <div className="prose prose-invert max-w-none space-y-6 text-sm sm:text-base text-[#d0ded5] leading-relaxed font-light">
            {article.body.split('\n\n').map((paragraph, idx) => (
              <p key={idx} className="leading-relaxed">
                {paragraph}
              </p>
            ))}
          </div>

          {/* Footer of Article */}
          <div className="pt-12 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-[#8fa397]">
            <p>© Roger W. Smith Ltd. Published in the Isle of Man.</p>
            <Link
              href="/contact"
              className="text-[#c4a265] hover:text-white uppercase tracking-wider font-medium"
            >
              Enquire on Commissions →
            </Link>
          </div>
        </article>
      </main>

      <Footer />
    </div>
  );
}
