'use client';

import React from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { ARTICLES } from '@/lib/data/articles';
import { ArrowRight, BookOpen, Clock } from 'lucide-react';

export default function JournalIndexPage() {
  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative py-16 lg:py-24 bg-gradient-to-b from-[#091b15] to-[#071812] border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="max-w-2xl space-y-4">
              <span className="text-[11px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                HOROLOGICAL ESSAYS & DISPATCHES
              </span>
              <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl tracking-[0.14em] uppercase text-[#f4f1ea] font-normal">
                THE JOURNAL
              </h1>
              <p className="text-sm sm:text-base text-[#cbd6cf] font-light leading-relaxed">
                Essays on traditional British watchmaking, technical breakthroughs in co-axial mechanics, and reflections from the workshop bench in Ramsey, Isle of Man.
              </p>
            </div>
          </div>
        </section>

        {/* Articles List */}
        <section className="py-16 lg:py-24">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16 space-y-16">
            
            {/* Featured Lead Article */}
            {ARTICLES[0] && (
              <div className="bg-[#0b241c] border border-[#c4a265]/20 overflow-hidden grid grid-cols-1 lg:grid-cols-12 gap-0 group">
                <div className="lg:col-span-7 relative aspect-[16/10] lg:aspect-auto overflow-hidden">
                  <Image
                    src={ARTICLES[0].heroImage}
                    alt={ARTICLES[0].title}
                    fill
                    sizes="(max-width: 1024px) 100vw, 60vw"
                    className="object-cover group-hover:scale-105 transition-transform duration-700 ease-out"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#061510]/80 via-transparent to-transparent lg:hidden" />
                </div>

                <div className="lg:col-span-5 p-8 sm:p-12 flex flex-col justify-between space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center space-x-3 text-[10px] tracking-[0.22em] uppercase text-[#c4a265]">
                      <span>{ARTICLES[0].category}</span>
                      <span>·</span>
                      <span>{ARTICLES[0].publishDate}</span>
                      <span>·</span>
                      <span>{ARTICLES[0].readingTime}</span>
                    </div>

                    <h2 className="font-serif text-2xl sm:text-3xl text-white font-normal leading-snug">
                      <Link href={`/journal/${ARTICLES[0].slug}`} className="hover:text-[#c4a265] transition-colors">
                        {ARTICLES[0].title}
                      </Link>
                    </h2>

                    <p className="text-xs sm:text-sm text-[#cbd6cf] leading-relaxed font-light">
                      {ARTICLES[0].summary}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-white/10 flex justify-between items-center text-xs">
                    <span className="text-[#8fa397]">By {ARTICLES[0].author}</span>
                    <Link
                      href={`/journal/${ARTICLES[0].slug}`}
                      className="inline-flex items-center space-x-1 text-[#c4a265] hover:text-white uppercase tracking-wider font-medium"
                    >
                      <span>READ ESSAY</span>
                      <ArrowRight size={14} />
                    </Link>
                  </div>
                </div>
              </div>
            )}

            {/* Remaining Articles */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
              {ARTICLES.slice(1).map((article) => (
                <article
                  key={article.id}
                  className="bg-[#0b221a] border border-[#c4a265]/20 flex flex-col justify-between group overflow-hidden"
                >
                  <div className="relative aspect-[16/9] w-full overflow-hidden bg-[#061510]">
                    <Image
                      src={article.heroImage}
                      alt={article.title}
                      fill
                      sizes="(max-width: 768px) 100vw, 50vw"
                      className="object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <div className="p-8 flex-1 flex flex-col justify-between space-y-6">
                    <div className="space-y-3">
                      <div className="flex items-center space-x-2 text-[10px] tracking-[0.22em] uppercase text-[#c4a265]">
                        <span>{article.category}</span>
                        <span>·</span>
                        <span>{article.publishDate}</span>
                      </div>

                      <h3 className="font-serif text-xl sm:text-2xl text-white font-normal">
                        <Link href={`/journal/${article.slug}`} className="hover:text-[#c4a265] transition-colors">
                          {article.title}
                        </Link>
                      </h3>

                      <p className="text-xs text-[#a0b3a7] leading-relaxed font-light line-clamp-3">
                        {article.summary}
                      </p>
                    </div>

                    <div className="pt-4 border-t border-white/5 flex justify-between items-center text-xs">
                      <span className="text-[#7e9488]">{article.readingTime}</span>
                      <Link
                        href={`/journal/${article.slug}`}
                        className="inline-flex items-center space-x-1 text-[#c4a265] hover:text-white uppercase tracking-wider font-medium text-[11px]"
                      >
                        <span>READ ESSAY</span>
                        <ArrowRight size={13} />
                      </Link>
                    </div>
                  </div>
                </article>
              ))}
            </div>

          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
