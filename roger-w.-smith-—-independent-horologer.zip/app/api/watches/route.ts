import { NextRequest, NextResponse } from 'next/server';
import { WATCHES, Watch } from '@/lib/data/watches';

// In-memory editable store for watches in the CMS
let editableWatches: Watch[] = [...WATCHES];

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const slug = searchParams.get('slug');

  if (slug) {
    const watch = editableWatches.find((w) => w.slug === slug);
    if (!watch) {
      return NextResponse.json({ error: 'Watch not found' }, { status: 404 });
    }
    return NextResponse.json({ watch });
  }

  return NextResponse.json({
    watches: editableWatches.sort((a, b) => a.sortOrder - b.sortOrder),
  });
}

export async function PUT(req: NextRequest) {
  try {
    const updatedWatch: Watch = await req.json();

    const index = editableWatches.findIndex((w) => w.id === updatedWatch.id);
    if (index === -1) {
      return NextResponse.json({ error: 'Watch record not found' }, { status: 404 });
    }

    editableWatches[index] = {
      ...editableWatches[index],
      ...updatedWatch,
    };

    return NextResponse.json({
      success: true,
      watch: editableWatches[index],
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update watch' }, { status: 500 });
  }
}
