import { NextRequest, NextResponse } from 'next/server';
import { enquiryStore } from '@/lib/data/enquiries';

// In-memory rate limiting map: IP -> timestamp[]
const rateLimitMap = new Map<string, number[]>();

function checkRateLimit(ip: string): boolean {
  const now = Date.now();
  const windowMs = 60 * 1000; // 1 minute
  const maxRequests = 5;

  const timestamps = rateLimitMap.get(ip) || [];
  const validTimestamps = timestamps.filter((t) => now - t < windowMs);

  if (validTimestamps.length >= maxRequests) {
    return false;
  }

  validTimestamps.push(now);
  rateLimitMap.set(ip, validTimestamps);
  return true;
}

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get('status');

    let results = enquiryStore.getAll();
    if (status) {
      results = results.filter((e) => e.status.toLowerCase() === status.toLowerCase());
    }

    return NextResponse.json({
      success: true,
      count: results.length,
      enquiries: results,
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to retrieve enquiries' },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get('x-forwarded-for') || '127.0.0.1';
    if (!checkRateLimit(ip)) {
      return NextResponse.json(
        { success: false, error: 'Too many requests. Please wait a moment before sending another enquiry.' },
        { status: 429 }
      );
    }

    const body = await req.json();
    const { clientName, email, phone, country, message, watchSlug, watchName, type, preferredContact } = body;

    // Strict Server-side Validation
    if (!clientName || typeof clientName !== 'string' || clientName.trim().length < 2) {
      return NextResponse.json(
        { success: false, error: 'Please provide a valid client name (at least 2 characters).' },
        { status: 400 }
      );
    }

    if (!email || typeof email !== 'string' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return NextResponse.json(
        { success: false, error: 'Please provide a valid email address for correspondence.' },
        { status: 400 }
      );
    }

    if (!country || typeof country !== 'string') {
      return NextResponse.json(
        { success: false, error: 'Please specify your country or jurisdiction.' },
        { status: 400 }
      );
    }

    // Sanitization
    const sanitizedName = clientName.trim().slice(0, 100);
    const sanitizedEmail = email.trim().toLowerCase().slice(0, 100);
    const sanitizedPhone = (phone || '').toString().trim().slice(0, 40);
    const sanitizedCountry = country.trim().slice(0, 60);
    const sanitizedMessage = (message || '').toString().trim().slice(0, 2000);
    const sanitizedWatchName = (watchName || 'General Atelier Enquiry').toString().slice(0, 120);

    const newEnquiry = enquiryStore.create({
      clientName: sanitizedName,
      email: sanitizedEmail,
      phone: sanitizedPhone,
      country: sanitizedCountry,
      message: sanitizedMessage,
      watchSlug: watchSlug || undefined,
      watchName: sanitizedWatchName,
      type: type || 'watch_allocation',
      preferredContact: preferredContact || 'email',
    });

    // Production Email Dispatch Simulation (logging to console without failing the client)
    console.log(
      `[ATELIER NOTIFICATION DISPATCHED] Reference: ${newEnquiry.reference} | Client: ${sanitizedName} <${sanitizedEmail}> | Timepiece: ${sanitizedWatchName}`
    );

    return NextResponse.json({
      success: true,
      message: 'Enquiry successfully registered in the Isle of Man allocation registry.',
      enquiry: {
        id: newEnquiry.id,
        reference: newEnquiry.reference,
        clientName: newEnquiry.clientName,
        email: newEnquiry.email,
        status: newEnquiry.status,
        createdAt: newEnquiry.createdAt,
      },
    });
  } catch (error) {
    console.error('Error creating enquiry:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error while recording enquiry.' },
      { status: 500 }
    );
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const body = await req.json();
    const { id, status, adminNotes } = body;

    if (!id || !status) {
      return NextResponse.json(
        { success: false, error: 'Enquiry ID and status are required.' },
        { status: 400 }
      );
    }

    const updated = enquiryStore.updateStatus(id, status, adminNotes);
    if (!updated) {
      return NextResponse.json(
        { success: false, error: 'Enquiry not found.' },
        { status: 404 }
      );
    }

    return NextResponse.json({
      success: true,
      enquiry: updated,
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to update enquiry status.' },
      { status: 500 }
    );
  }
}
