import { NextRequest, NextResponse } from 'next/server';
import { ARTICLES, Article } from '@/lib/data/articles';

let editableArticles: Article[] = [...ARTICLES];

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const slug = searchParams.get('slug');

  if (slug) {
    const article = editableArticles.find((a) => a.slug === slug);
    if (!article) {
      return NextResponse.json({ error: 'Article not found' }, { status: 404 });
    }
    return NextResponse.json({ article });
  }

  return NextResponse.json({
    articles: editableArticles,
  });
}

export async function POST(req: NextRequest) {
  try {
    const newArticleData = await req.json();

    if (!newArticleData.title || !newArticleData.body) {
      return NextResponse.json({ error: 'Title and content are required' }, { status: 400 });
    }

    const slug = newArticleData.title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-|-$/g, '');

    const newArticle: Article = {
      id: `art-${Date.now()}`,
      slug,
      title: newArticleData.title,
      summary: newArticleData.summary || '',
      body: newArticleData.body,
      author: newArticleData.author || 'Roger W. Smith Atelier',
      publishDate: new Date().toLocaleDateString('en-GB', { day: 'numeric', month: 'long', year: 'numeric' }),
      readingTime: `${Math.max(3, Math.ceil(newArticleData.body.length / 800))} min read`,
      category: newArticleData.category || 'Craftsmanship',
      heroImage: newArticleData.heroImage || '/images/rws_watchmaker_workshop.jpg',
      published: newArticleData.published ?? true,
    };

    editableArticles.unshift(newArticle);

    return NextResponse.json({
      success: true,
      article: newArticle,
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create article' }, { status: 500 });
  }
}
