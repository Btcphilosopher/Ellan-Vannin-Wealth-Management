'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Triskelion } from '@/components/Triskelion';
import { EnquiryModal } from '@/components/EnquiryModal';
import { Check, Shield, Sparkles, Compass } from 'lucide-react';

const CRAFTS_LIST = [
  'Movement Conceiving & Mechanical Calculating',
  'Bridge & Mainplate Milling from Solid Nickel-Silver & Brass',
  'English Frosted Gilt Surface Finishing (Traditional Acid Dip)',
  'Mirror-Polished Steelwork & Black Polishing (Poli Noir)',
  'Straight-Line Engine Turning (Guilloché Dials)',
  'Circular Rose Engine Turning (Brocot & Barleycorn Patterns)',
  'Hand-Cutting & Inking Silver Dial Chapter Rings',
  'Sculpting Steel Hands by File & Eye',
  'Thermal Flame-Bluing of Hands & Screws',
  'Turning Arbors, Pinions & Pivots on Watchmaker Lathe',
  'Cutting Wheels & Teeth Profile Optimization',
  'Jewel Setting & Hand-Polished Chatons',
  'Fabricating Co-Axial Escape Wheels & Raised Impulses',
  'Shaping & Polishing Synthetic Ruby Pallet Jewels',
  'Crafting Quadra-Cushion Variable Inertia Balance Wheels',
  'Hand-Shaping Balance Poising & Collet Fitting',
  'Case Fabrication: Shaping, Piercing & Soldering Precious Metals',
  'Hand-Carving & London/Isle of Man Assay Hallmarking',
  'Exhibition Sapphire Glass Bezel Seating',
  'Crown & Winding Stem Micro-Fabrication',
  'Click Spring & Ratchet Wheel Metallurgy',
  'Mainspring Barrel Arbors & Hooking',
  'Dial Foot Soldering & Eccentric Alignment',
  'Subsidiary Seconds Gear Train Depthing',
  'Friction Adjustment & Train Truing',
  'Poising & Calibrating in Six Orthogonal Positions',
  'Bespoke Alligator Strap Fitting & Hand-Made Gold Buckles',
  'Final Isochronism & Long-Term Workshop Rate Testing'
];

export default function CraftPage() {
  const [enquiryOpen, setEnquiryOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col">
      <Header onOpenEnquiry={() => setEnquiryOpen(true)} />

      <main className="flex-1">
        {/* Page Hero */}
        <section className="relative py-20 lg:py-28 bg-gradient-to-b from-[#091b15] via-[#081a14] to-[#071812] border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="max-w-3xl space-y-4">
              <div className="flex items-center space-x-3">
                <Triskelion size={20} color="#c4a265" />
                <span className="text-[11px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                  THE DANIELS METHOD
                </span>
              </div>
              <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl tracking-[0.14em] uppercase text-[#f4f1ea] font-normal leading-tight">
                THE CRAFT OF BRITISH HOROLOGY
              </h1>
              <p className="text-base sm:text-lg text-[#cbd6cf] font-light leading-relaxed max-w-2xl">
                At the Roger W. Smith atelier on the Isle of Man, thirty-two of the thirty-four crafts required to build an entire watch from raw metals are performed beneath a single roof.
              </p>
            </div>
          </div>
        </section>

        {/* Story Section 1: The Principle of Singularity */}
        <section className="py-20 border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              <div className="lg:col-span-6 relative aspect-[4/3] overflow-hidden border border-[#c4a265]/20 shadow-2xl">
                <Image
                  src="/images/rws_watchmaker_workshop.jpg"
                  alt="Precision hand finishing at Roger W. Smith atelier"
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="lg:col-span-6 space-y-6 lg:pl-6">
                <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                  A RADICAL ALTERNATIVE TO MASS INDUSTRY
                </span>
                <h2 className="font-serif text-2xl sm:text-3xl lg:text-4xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                  ONE WATCHMAKER.<br />ONE VISION.
                </h2>
                <div className="w-12 h-[1px] bg-[#c4a265]/70" />
                <p className="text-sm sm:text-base text-[#a7baa0] leading-relaxed font-light">
                  Modern watchmaking has become an assembly industry of anonymous suppliers. By contrast, the Daniels Method demands that the watchmaker retains complete dominion over every wheel, pinion, bridge, hand and screw.
                </p>
                <p className="text-sm sm:text-base text-[#a7baa0] leading-relaxed font-light">
                  This total mastery produces an individuality and harmony that industrial manufacturing can never replicate. When you hold a Roger W. Smith watch, you hold an object imbued with the thoughts, pulse and hours of the human being who shaped it.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* The 32 Crafts Pillar Grid */}
        <section className="py-20 bg-[#071712] border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16 space-y-12">
            <div className="text-center max-w-2xl mx-auto space-y-3">
              <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                ATELIER MASTERY
              </span>
              <h2 className="font-serif text-2xl sm:text-4xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                THE THIRTY-TWO CRAFTS
              </h2>
              <p className="text-xs sm:text-sm text-[#8fa397] leading-relaxed">
                Only the balance spring and sapphire crystals are sourced externally. Every other element is shaped, tuned and finished in Ramsey.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {CRAFTS_LIST.map((craft, idx) => (
                <div 
                  key={craft}
                  className="bg-[#0a1e17] border border-[#c4a265]/20 p-4 flex items-start space-x-3 transition-colors hover:border-[#c4a265]/60"
                >
                  <span className="font-mono text-xs text-[#c4a265] font-semibold tracking-wider">
                    {String(idx + 1).padStart(2, '0')}.
                  </span>
                  <p className="text-xs text-[#dbe5df] font-light leading-snug">
                    {craft}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Escapement & Hand Guilloché Engine Turning */}
        <section className="py-20 border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              
              <div className="space-y-6">
                <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                  ENGINE-TURNING HERITAGE
                </span>
                <h2 className="font-serif text-2xl sm:text-4xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                  ANTIQUE ROSE & STRAIGHT-LINE ENGINES
                </h2>
                <div className="w-12 h-[1px] bg-[#c4a265]/70" />
                <p className="text-sm sm:text-base text-[#a7baa0] leading-relaxed font-light">
                  A Roger W. Smith dial is never stamped or chemically etched. It is engine-turned by hand using antique rose and straight-line machines dating back to the Victorian era.
                </p>
                <p className="text-sm sm:text-base text-[#a7baa0] leading-relaxed font-light">
                  The watchmaker rotates the dial blank with one hand while feeding the cutting tool with microscopic sensitivity with the other. A single miscalculation destroys dozens of hours of work, yet when executed properly, it catches ambient light with an optical depth that machines cannot match.
                </p>
              </div>

              <div className="relative aspect-square sm:aspect-[4/3] overflow-hidden border border-[#c4a265]/20 shadow-2xl">
                <Image
                  src="/images/rws_watch_the_manx.jpg"
                  alt="Multi-tiered silver engine turned guilloché dial"
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

            </div>
          </div>
        </section>

        {/* Workshop Call to Action */}
        <section className="py-20 bg-[#061510] text-center">
          <div className="max-w-2xl mx-auto px-6 space-y-6">
            <Triskelion size={30} color="#c4a265" />
            <h2 className="font-serif text-2xl sm:text-3xl tracking-[0.18em] uppercase text-[#f4f1ea]">
              EXPERIENCE THE WORKSHOP
            </h2>
            <p className="text-xs sm:text-sm text-[#8fa397] leading-relaxed">
              We invite prospective collectors to enquire about our allocation schedule and discuss commission details directly with our atelier.
            </p>
            <div className="pt-2 flex justify-center gap-4">
              <button
                type="button"
                onClick={() => setEnquiryOpen(true)}
                className="px-8 py-3.5 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#dfc590] transition-colors"
              >
                REQUEST ATELIER DIALOGUE →
              </button>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      <EnquiryModal
        isOpen={enquiryOpen}
        onClose={() => setEnquiryOpen(false)}
      />
    </div>
  );
}
