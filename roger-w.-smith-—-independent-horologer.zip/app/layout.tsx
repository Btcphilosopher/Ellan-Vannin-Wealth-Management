import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Roger W. Smith — Independent Horologer | Isle of Man',
  description: 'Fine mechanical watches, handcrafted on the Isle of Man by Roger W. Smith OBE. Traditional British watchmaking, precision engineering and horological craftsmanship.',
  keywords: [
    'Roger W Smith',
    'Roger Smith watchmaker',
    'Isle of Man',
    'Independent Horologer',
    'George Daniels',
    'Co-Axial Escapement',
    'British Watchmaking',
    'Series 1',
    'Series 2',
    'The Heron',
    'The Manx',
    'The Tynwald',
    'Handmade watches'
  ],
  authors: [{ name: 'Roger W. Smith OBE' }],
  openGraph: {
    title: 'Roger W. Smith — Independent Horologer',
    description: 'Fine mechanical watches, handcrafted on the Isle of Man.',
    url: 'https://www.rwsmithwatches.com',
    siteName: 'Roger W. Smith',
    images: [
      {
        url: '/images/rws_hero_watch_green.jpg',
        width: 1200,
        height: 800,
        alt: 'Roger W. Smith Bespoke Chronometer'
      }
    ],
    locale: 'en_GB',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Roger W. Smith — Independent Horologer',
    description: 'Fine mechanical watches, handcrafted on the Isle of Man.',
    images: ['/images/rws_hero_watch_green.jpg'],
  },
  icons: {
    icon: '/favicon.ico',
  }
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
      </head>
      <body className="min-h-screen bg-[#091b15] text-[#f4f1ea] antialiased selection:bg-[#c4a265] selection:text-[#091b15]" suppressHydrationWarning>
        {children}
      </body>
    </html>
  );
}
