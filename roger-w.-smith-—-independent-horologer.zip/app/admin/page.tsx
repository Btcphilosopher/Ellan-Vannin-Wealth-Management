'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { Triskelion } from '@/components/Triskelion';
import { Enquiry } from '@/lib/data/enquiries';
import { Watch, WATCHES } from '@/lib/data/watches';
import { Article, ARTICLES } from '@/lib/data/articles';
import { 
  Lock, 
  Unlock, 
  Clock, 
  FileText, 
  Watch as WatchIcon, 
  CheckCircle, 
  AlertCircle, 
  Save, 
  Plus, 
  Search, 
  ChevronRight,
  ShieldCheck,
  LogOut
} from 'lucide-react';

export default function AdminPage() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [passcode, setPasscode] = useState('');
  const [authError, setAuthError] = useState('');
  
  const [activeTab, setActiveTab] = useState<'enquiries' | 'watches' | 'journal'>('enquiries');

  // Enquiries state
  const [enquiries, setEnquiries] = useState<Enquiry[]>([]);
  const [selectedEnquiry, setSelectedEnquiry] = useState<Enquiry | null>(null);
  const [enquiryStatusFilter, setEnquiryStatusFilter] = useState<string>('all');
  const [savingEnquiry, setSavingEnquiry] = useState(false);
  const [enquirySuccessMsg, setEnquirySuccessMsg] = useState('');

  // Watches state
  const [watches, setWatches] = useState<Watch[]>([]);
  const [selectedWatch, setSelectedWatch] = useState<Watch | null>(null);
  const [savingWatch, setSavingWatch] = useState(false);
  const [watchSuccessMsg, setWatchSuccessMsg] = useState('');

  // Journal state
  const [articles, setArticles] = useState<Article[]>([]);
  const [newTitle, setNewTitle] = useState('');
  const [newSummary, setNewSummary] = useState('');
  const [newBody, setNewBody] = useState('');
  const [newCategory, setNewCategory] = useState<'Craftsmanship' | 'Horology' | 'Heritage' | 'Workshop Log'>('Workshop Log');
  const [savingArticle, setSavingArticle] = useState(false);
  const [articleSuccessMsg, setArticleSuccessMsg] = useState('');

  // Fetch enquiries
  const loadEnquiries = async () => {
    try {
      const res = await fetch('/api/enquiries');
      const data = await res.json();
      if (data.enquiries) {
        setEnquiries(data.enquiries);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Fetch watches
  const loadWatches = async () => {
    try {
      const res = await fetch('/api/watches');
      const data = await res.json();
      if (data.watches) {
        setWatches(data.watches);
      }
    } catch (e) {
      console.error(e);
    }
  };

  // Fetch articles
  const loadArticles = async () => {
    try {
      const res = await fetch('/api/journal');
      const data = await res.json();
      if (data.articles) {
        setArticles(data.articles);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    let ignore = false;
    async function initData() {
      if (!isAuthenticated) return;
      try {
        const [enqRes, watchRes, artRes] = await Promise.all([
          fetch('/api/enquiries').then((r) => r.json()),
          fetch('/api/watches').then((r) => r.json()),
          fetch('/api/journal').then((r) => r.json()),
        ]);
        if (!ignore) {
          if (enqRes.enquiries) {
            setEnquiries(enqRes.enquiries);
            setSelectedEnquiry(enqRes.enquiries[0] || null);
          }
          if (watchRes.watches) {
            setWatches(watchRes.watches);
            setSelectedWatch(watchRes.watches[0] || null);
          }
          if (artRes.articles) {
            setArticles(artRes.articles);
          }
        }
      } catch (err) {
        console.error(err);
      }
    }
    initData();
    return () => {
      ignore = true;
    };
  }, [isAuthenticated]);

  const handleLogin = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    // Authorized credentials check (allow standard atelier master pass or quick demo login)
    if (passcode === 'daniels1974' || passcode === 'rws' || passcode === 'admin' || passcode === '') {
      setIsAuthenticated(true);
      setAuthError('');
    } else {
      setAuthError('Incorrect atelier key. (Hint: use "daniels1974" or click Quick Access)');
    }
  };

  const handleUpdateEnquiryStatus = async (status: Enquiry['status'], notes?: string) => {
    if (!selectedEnquiry) return;
    setSavingEnquiry(true);
    setEnquirySuccessMsg('');

    try {
      const res = await fetch('/api/enquiries', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          id: selectedEnquiry.id,
          status,
          adminNotes: notes ?? selectedEnquiry.adminNotes,
        }),
      });

      const data = await res.json();
      if (data.success) {
        setEnquirySuccessMsg('Dossier updated successfully in registry.');
        await loadEnquiries();
        setSelectedEnquiry(data.enquiry);
        setTimeout(() => setEnquirySuccessMsg(''), 3000);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSavingEnquiry(false);
    }
  };

  const handleSaveWatch = async () => {
    if (!selectedWatch) return;
    setSavingWatch(true);
    setWatchSuccessMsg('');

    try {
      const res = await fetch('/api/watches', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(selectedWatch),
      });

      const data = await res.json();
      if (data.success) {
        setWatchSuccessMsg('Watch specifications updated in public catalogue.');
        await loadWatches();
        setTimeout(() => setWatchSuccessMsg(''), 3000);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSavingWatch(false);
    }
  };

  const handleCreateArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newBody.trim()) return;

    setSavingArticle(true);
    setArticleSuccessMsg('');

    try {
      const res = await fetch('/api/journal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle,
          summary: newSummary,
          body: newBody,
          category: newCategory,
          author: 'Roger W. Smith Atelier',
        }),
      });

      const data = await res.json();
      if (data.success) {
        setArticleSuccessMsg('New journal article published successfully.');
        setNewTitle('');
        setNewSummary('');
        setNewBody('');
        await loadArticles();
        setTimeout(() => setArticleSuccessMsg(''), 3000);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSavingArticle(false);
    }
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-[#061510] flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-[#091b15] border border-[#c4a265]/40 p-8 shadow-2xl text-[#f4f1ea] space-y-6">
          <div className="text-center space-y-2">
            <div className="flex justify-center mb-2">
              <Triskelion size={30} color="#c4a265" />
            </div>
            <span className="text-[10px] tracking-[0.3em] uppercase text-[#c4a265] font-medium">
              RAMSEY ATELIER PORTAL
            </span>
            <h1 className="font-serif text-2xl uppercase tracking-[0.16em]">
              Staff & Editorial Access
            </h1>
            <p className="text-xs text-[#8fa397]">
              Confidential administration of client allocations, catalogue specifications and workshop journal.
            </p>
          </div>

          {authError && (
            <div className="p-3 bg-red-950/40 border border-red-500/40 text-red-200 text-xs flex items-center space-x-2">
              <AlertCircle size={16} className="text-red-400 shrink-0" />
              <span>{authError}</span>
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                ATELIER SECURITY PASSKEY
              </label>
              <input
                type="password"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="Enter passkey (e.g. daniels1974)"
                className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none"
              />
            </div>

            <button
              type="submit"
              className="w-full py-3 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#dfc590] transition-colors"
            >
              AUTHENTICATE TO ATELIER LEDGER
            </button>
          </form>

          <div className="pt-2 border-t border-white/10 text-center">
            <button
              type="button"
              onClick={() => { setPasscode('daniels1974'); setIsAuthenticated(true); }}
              className="text-[11px] text-[#8fa397] hover:text-[#c4a265] tracking-wider uppercase underline underline-offset-4"
            >
              Demo Staff One-Click Access →
            </button>
          </div>

          <div className="text-center pt-2">
            <Link href="/" className="text-xs text-[#8fa397] hover:text-white">
              ← Return to Public Website
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const filteredEnquiries = enquiries.filter((e) => {
    if (enquiryStatusFilter === 'all') return true;
    return e.status === enquiryStatusFilter;
  });

  return (
    <div className="min-h-screen bg-[#061510] text-[#f4f1ea] flex flex-col">
      {/* Top Admin Header */}
      <header className="bg-[#091b15] border-b border-[#c4a265]/25 px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Link href="/" className="font-serif text-2xl tracking-[0.2em] text-[#dfc590]">
            RWS
          </Link>
          <div className="h-4 w-[1px] bg-white/20" />
          <span className="text-xs tracking-[0.2em] uppercase text-[#c4a265] font-medium hidden sm:inline">
            ATELIER CMS & ALLOCATION REGISTRY
          </span>
        </div>

        <div className="flex items-center space-x-4">
          <Link
            href="/"
            className="text-xs tracking-wider text-[#8fa397] hover:text-white uppercase transition-colors"
          >
            Preview Site ↗
          </Link>
          <button
            onClick={() => setIsAuthenticated(false)}
            className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#0e261e] border border-white/10 text-xs text-[#8fa397] hover:text-red-400 hover:border-red-400/40 transition-colors uppercase tracking-wider"
          >
            <LogOut size={13} />
            <span>Lock</span>
          </button>
        </div>
      </header>

      {/* Nav Tabs */}
      <div className="bg-[#0a1e17] border-b border-[#c4a265]/15 px-6 flex space-x-6 text-xs tracking-[0.2em] uppercase font-medium">
        <button
          onClick={() => setActiveTab('enquiries')}
          className={`py-4 border-b-2 transition-colors flex items-center space-x-2 ${
            activeTab === 'enquiries' ? 'border-[#c4a265] text-[#c4a265]' : 'border-transparent text-[#8fa397] hover:text-white'
          }`}
        >
          <Clock size={14} />
          <span>ALLOCATIONS & ENQUIRIES ({enquiries.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('watches')}
          className={`py-4 border-b-2 transition-colors flex items-center space-x-2 ${
            activeTab === 'watches' ? 'border-[#c4a265] text-[#c4a265]' : 'border-transparent text-[#8fa397] hover:text-white'
          }`}
        >
          <WatchIcon size={14} />
          <span>TIMEPIECE CATALOGUE ({watches.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('journal')}
          className={`py-4 border-b-2 transition-colors flex items-center space-x-2 ${
            activeTab === 'journal' ? 'border-[#c4a265] text-[#c4a265]' : 'border-transparent text-[#8fa397] hover:text-white'
          }`}
        >
          <FileText size={14} />
          <span>JOURNAL ARTICLES ({articles.length})</span>
        </button>
      </div>

      {/* Tab 1: Allocations & Enquiries */}
      {activeTab === 'enquiries' && (
        <div className="flex-1 p-6 max-w-[1440px] mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* List Left */}
          <div className="lg:col-span-5 bg-[#091b15] border border-[#c4a265]/20 flex flex-col h-[750px]">
            <div className="p-4 border-b border-[#c4a265]/15 flex items-center justify-between">
              <span className="text-xs uppercase tracking-wider text-[#c4a265] font-semibold">
                Client Dossiers
              </span>
              <select
                value={enquiryStatusFilter}
                onChange={(e) => setEnquiryStatusFilter(e.target.value)}
                className="bg-[#061510] border border-white/10 text-xs px-2 py-1 text-[#f4f1ea] outline-none"
              >
                <option value="all">All Statuses</option>
                <option value="Pending Review">Pending Review</option>
                <option value="In Discussion">In Discussion</option>
                <option value="Allocated">Allocated</option>
                <option value="Waitlist">Waitlist</option>
                <option value="Declined">Declined</option>
              </select>
            </div>

            <div className="flex-1 overflow-y-auto divide-y divide-white/5">
              {filteredEnquiries.map((enq) => {
                const isSelected = selectedEnquiry?.id === enq.id;
                return (
                  <div
                    key={enq.id}
                    onClick={() => setSelectedEnquiry(enq)}
                    className={`p-4 cursor-pointer transition-colors ${
                      isSelected ? 'bg-[#0f2e22] border-l-2 border-[#c4a265]' : 'hover:bg-white/5'
                    }`}
                  >
                    <div className="flex justify-between items-start mb-1">
                      <span className="font-mono text-xs text-[#dfc590] font-semibold">
                        {enq.reference}
                      </span>
                      <span className={`text-[9px] px-2 py-0.5 uppercase tracking-wider ${
                        enq.status === 'Allocated' ? 'bg-emerald-950 text-emerald-300 border border-emerald-500/30' :
                        enq.status === 'In Discussion' ? 'bg-amber-950 text-amber-300 border border-amber-500/30' :
                        'bg-zinc-800 text-zinc-300'
                      }`}>
                        {enq.status}
                      </span>
                    </div>
                    <h4 className="text-sm font-medium text-white">{enq.clientName}</h4>
                    <p className="text-xs text-[#8fa397] truncate mt-0.5">
                      {enq.watchName || 'General Enquiry'}
                    </p>
                    <div className="flex justify-between text-[10px] text-[#708479] mt-2">
                      <span>{enq.country}</span>
                      <span>{new Date(enq.createdAt).toLocaleDateString()}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Details Right */}
          <div className="lg:col-span-7 bg-[#091b15] border border-[#c4a265]/20 p-6 flex flex-col justify-between h-[750px] overflow-y-auto">
            {selectedEnquiry ? (
              <div className="space-y-6">
                <div className="flex justify-between items-start border-b border-white/10 pb-4">
                  <div>
                    <span className="text-[10px] tracking-[0.24em] uppercase text-[#c4a265]">
                      DOSSIER DETAILS
                    </span>
                    <h2 className="font-serif text-2xl text-white mt-1">
                      {selectedEnquiry.clientName}
                    </h2>
                    <span className="font-mono text-xs text-[#dfc590]">
                      {selectedEnquiry.reference}
                    </span>
                  </div>
                  
                  <div className="text-right">
                    <span className="text-xs text-[#8fa397] block">Current Status</span>
                    <select
                      value={selectedEnquiry.status}
                      onChange={(e) => handleUpdateEnquiryStatus(e.target.value as any)}
                      className="mt-1 bg-[#061510] border border-[#c4a265]/40 text-xs px-3 py-1.5 text-[#f4f1ea] outline-none"
                    >
                      <option value="Pending Review">Pending Review</option>
                      <option value="In Discussion">In Discussion</option>
                      <option value="Allocated">Allocated</option>
                      <option value="Waitlist">Waitlist</option>
                      <option value="Completed">Completed</option>
                      <option value="Declined">Declined</option>
                    </select>
                  </div>
                </div>

                {enquirySuccessMsg && (
                  <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center space-x-2">
                    <CheckCircle size={15} />
                    <span>{enquirySuccessMsg}</span>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4 text-xs bg-[#061510] p-4 border border-white/5">
                  <div>
                    <span className="text-[#8fa397] block">Email</span>
                    <span className="text-white font-medium">{selectedEnquiry.email}</span>
                  </div>
                  <div>
                    <span className="text-[#8fa397] block">Telephone</span>
                    <span className="text-white font-medium">{selectedEnquiry.phone || 'Not provided'}</span>
                  </div>
                  <div>
                    <span className="text-[#8fa397] block">Country</span>
                    <span className="text-white font-medium">{selectedEnquiry.country}</span>
                  </div>
                  <div>
                    <span className="text-[#8fa397] block">Preferred Contact</span>
                    <span className="text-[#dfc590] uppercase">{selectedEnquiry.preferredContact}</span>
                  </div>
                </div>

                <div>
                  <h4 className="text-xs tracking-wider uppercase text-[#c4a265] mb-2 font-medium">
                    Requested Timepiece / Subject
                  </h4>
                  <div className="bg-[#0b241c] p-3 text-sm text-white font-light border border-white/5">
                    {selectedEnquiry.watchName || 'General Enquiry'}
                  </div>
                </div>

                <div>
                  <h4 className="text-xs tracking-wider uppercase text-[#c4a265] mb-2 font-medium">
                    Client&apos;s Inbound Note
                  </h4>
                  <div className="bg-[#061510] p-4 text-xs text-[#cbd6cf] leading-relaxed border border-white/5 whitespace-pre-wrap">
                    {selectedEnquiry.message || 'No additional note provided.'}
                  </div>
                </div>

                <div>
                  <h4 className="text-xs tracking-wider uppercase text-[#c4a265] mb-2 font-medium">
                    Ramsey Atelier Confidential Notes
                  </h4>
                  <textarea
                    rows={4}
                    value={selectedEnquiry.adminNotes || ''}
                    onChange={(e) => setSelectedEnquiry({ ...selectedEnquiry, adminNotes: e.target.value })}
                    placeholder="Record notes on collector background, meeting dates, deposit status, or specific custom dial requests..."
                    className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] p-3 text-xs text-[#f4f1ea] outline-none resize-none"
                  />
                  <div className="flex justify-end mt-2">
                    <button
                      type="button"
                      disabled={savingEnquiry}
                      onClick={() => handleUpdateEnquiryStatus(selectedEnquiry.status, selectedEnquiry.adminNotes)}
                      className="px-5 py-2 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-wider uppercase hover:bg-[#dfc590] transition-colors"
                    >
                      {savingEnquiry ? 'Saving...' : 'Save Atelier Notes'}
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-full text-xs text-[#8fa397]">
                Select an enquiry to review dossier
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Watches Catalogue */}
      {activeTab === 'watches' && (
        <div className="flex-1 p-6 max-w-[1440px] mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-4 bg-[#091b15] border border-[#c4a265]/20 p-4 space-y-3 h-[750px] overflow-y-auto">
            <h3 className="text-xs uppercase tracking-wider text-[#c4a265] font-semibold border-b border-white/10 pb-2">
              Timepiece Models
            </h3>
            {watches.map((w) => (
              <div
                key={w.id}
                onClick={() => setSelectedWatch(w)}
                className={`p-3 cursor-pointer transition-colors border ${
                  selectedWatch?.id === w.id ? 'border-[#c4a265] bg-[#0f2e22]' : 'border-white/5 hover:bg-white/5'
                }`}
              >
                <div className="text-sm font-medium text-white">{w.name}</div>
                <div className="text-[10px] text-[#c4a265] uppercase">{w.series}</div>
                <div className="text-xs text-[#8fa397] truncate mt-1">{w.tagline}</div>
              </div>
            ))}
          </div>

          <div className="lg:col-span-8 bg-[#091b15] border border-[#c4a265]/20 p-6 h-[750px] overflow-y-auto space-y-6">
            {selectedWatch ? (
              <div className="space-y-4">
                <div className="flex justify-between items-center border-b border-white/10 pb-3">
                  <div>
                    <span className="text-[10px] tracking-[0.24em] uppercase text-[#c4a265]">
                      EDITING TIMEPIECE
                    </span>
                    <h2 className="font-serif text-2xl text-white">{selectedWatch.name}</h2>
                  </div>
                  <button
                    onClick={handleSaveWatch}
                    disabled={savingWatch}
                    className="px-6 py-2.5 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-wider uppercase hover:bg-[#dfc590] transition-colors"
                  >
                    {savingWatch ? 'Saving...' : 'Save Changes'}
                  </button>
                </div>

                {watchSuccessMsg && (
                  <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center space-x-2">
                    <CheckCircle size={15} />
                    <span>{watchSuccessMsg}</span>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-[#c4a265] mb-1">
                      Public Name
                    </label>
                    <input
                      type="text"
                      value={selectedWatch.name}
                      onChange={(e) => setSelectedWatch({ ...selectedWatch, name: e.target.value })}
                      className="w-full bg-[#061510] border border-white/10 p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-[#c4a265] mb-1">
                      Series Line
                    </label>
                    <input
                      type="text"
                      value={selectedWatch.series}
                      onChange={(e) => setSelectedWatch({ ...selectedWatch, series: e.target.value })}
                      className="w-full bg-[#061510] border border-white/10 p-2.5 text-xs text-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-[#c4a265] mb-1">
                    Tagline
                  </label>
                  <input
                    type="text"
                    value={selectedWatch.tagline}
                    onChange={(e) => setSelectedWatch({ ...selectedWatch, tagline: e.target.value })}
                    className="w-full bg-[#061510] border border-white/10 p-2.5 text-xs text-white"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase tracking-wider text-[#c4a265] mb-1">
                    Editorial Long Description
                  </label>
                  <textarea
                    rows={4}
                    value={selectedWatch.longDescription}
                    onChange={(e) => setSelectedWatch({ ...selectedWatch, longDescription: e.target.value })}
                    className="w-full bg-[#061510] border border-white/10 p-2.5 text-xs text-white resize-none"
                  />
                </div>

                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-[#c4a265] mb-1">
                      Case Diameter
                    </label>
                    <input
                      type="text"
                      value={selectedWatch.caseDiameter}
                      onChange={(e) => setSelectedWatch({ ...selectedWatch, caseDiameter: e.target.value })}
                      className="w-full bg-[#061510] border border-white/10 p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-[#c4a265] mb-1">
                      Power Reserve
                    </label>
                    <input
                      type="text"
                      value={selectedWatch.powerReserve}
                      onChange={(e) => setSelectedWatch({ ...selectedWatch, powerReserve: e.target.value })}
                      className="w-full bg-[#061510] border border-white/10 p-2.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase tracking-wider text-[#c4a265] mb-1">
                      Frequency
                    </label>
                    <input
                      type="text"
                      value={selectedWatch.vibrationsPerHour}
                      onChange={(e) => setSelectedWatch({ ...selectedWatch, vibrationsPerHour: e.target.value })}
                      className="w-full bg-[#061510] border border-white/10 p-2.5 text-xs text-white"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-xs text-[#8fa397]">Select a watch to edit</div>
            )}
          </div>
        </div>
      )}

      {/* Tab 3: Journal Articles */}
      {activeTab === 'journal' && (
        <div className="flex-1 p-6 max-w-[1440px] mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 bg-[#091b15] border border-[#c4a265]/20 p-6 space-y-4 h-[750px] overflow-y-auto">
            <h3 className="text-xs uppercase tracking-wider text-[#c4a265] font-semibold border-b border-white/10 pb-2">
              Published Journal Entries
            </h3>
            {articles.map((art) => (
              <div key={art.id} className="p-4 bg-[#061510] border border-white/5 space-y-1">
                <span className="text-[9px] tracking-wider uppercase text-[#c4a265]">
                  {art.category} · {art.publishDate}
                </span>
                <h4 className="text-sm font-medium text-white">{art.title}</h4>
                <p className="text-xs text-[#8fa397] line-clamp-2">{art.summary}</p>
              </div>
            ))}
          </div>

          <div className="lg:col-span-7 bg-[#091b15] border border-[#c4a265]/20 p-6 h-[750px] overflow-y-auto space-y-6">
            <h3 className="font-serif text-2xl text-white border-b border-white/10 pb-3">
              Publish New Workshop Journal Entry
            </h3>

            {articleSuccessMsg && (
              <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 text-emerald-300 text-xs flex items-center space-x-2">
                <CheckCircle size={15} />
                <span>{articleSuccessMsg}</span>
              </div>
            )}

            <form onSubmit={handleCreateArticle} className="space-y-4">
              <div>
                <label className="block text-[10px] uppercase tracking-wider text-[#c4a265] mb-1">
                  Article Title *
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={(e) => setNewTitle(e.target.value)}
                  placeholder="e.g. Engine-Turning the 2027 Series 2 Guilloché Dials"
                  className="w-full bg-[#061510] border border-white/10 p-2.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-wider text-[#c4a265] mb-1">
                  Category
                </label>
                <select
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as any)}
                  className="w-full bg-[#061510] border border-white/10 p-2.5 text-xs text-white"
                >
                  <option value="Craftsmanship">Craftsmanship</option>
                  <option value="Horology">Horology</option>
                  <option value="Heritage">Heritage</option>
                  <option value="Workshop Log">Workshop Log</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-wider text-[#c4a265] mb-1">
                  Executive Summary
                </label>
                <input
                  type="text"
                  value={newSummary}
                  onChange={(e) => setNewSummary(e.target.value)}
                  placeholder="Brief synopsis of the entry"
                  className="w-full bg-[#061510] border border-white/10 p-2.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-wider text-[#c4a265] mb-1">
                  Full Journal Text *
                </label>
                <textarea
                  rows={8}
                  required
                  value={newBody}
                  onChange={(e) => setNewBody(e.target.value)}
                  placeholder="Detailed horological narrative and workshop reflections..."
                  className="w-full bg-[#061510] border border-white/10 p-2.5 text-xs text-white resize-none"
                />
              </div>

              <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={savingArticle}
                  className="px-8 py-3 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-wider uppercase hover:bg-[#dfc590] transition-colors"
                >
                  {savingArticle ? 'Publishing...' : 'Publish to Workshop Journal'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
