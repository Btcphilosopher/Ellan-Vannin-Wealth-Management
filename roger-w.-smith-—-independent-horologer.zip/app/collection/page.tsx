'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Triskelion } from '@/components/Triskelion';
import { EnquiryModal } from '@/components/EnquiryModal';
import { WATCHES, Watch } from '@/lib/data/watches';

export default function CollectionPage() {
  const [activeFilter, setActiveFilter] = useState<'all' | 'series1' | 'series2' | 'series5'>('all');
  const [enquiryOpen, setEnquiryOpen] = useState(false);
  const [selectedWatch, setSelectedWatch] = useState<Watch | null>(null);

  const filteredWatches = WATCHES.filter((watch) => {
    if (activeFilter === 'series1') return watch.slug === 'the-heron';
    if (activeFilter === 'series2') return watch.slug === 'the-manx';
    if (activeFilter === 'series5') return watch.slug === 'the-tynwald';
    return true;
  });

  const handleEnquire = (watch: Watch) => {
    setSelectedWatch(watch);
    setEnquiryOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col">
      <Header onOpenEnquiry={() => { setSelectedWatch(null); setEnquiryOpen(true); }} />

      <main className="flex-1">
        {/* Collection Hero */}
        <section className="relative py-16 lg:py-24 bg-gradient-to-b from-[#091b15] to-[#071812] border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="max-w-2xl space-y-4">
              <span className="text-[11px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                THE CATALOGUE OF TIMEPIECES
              </span>
              <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl tracking-[0.14em] uppercase text-[#f4f1ea] font-normal">
                THE COLLECTION
              </h1>
              <p className="text-sm sm:text-base text-[#a7baa0] font-light leading-relaxed">
                Handcrafted on the Isle of Man in strictly limited annual editions. Each timepiece is powered by Roger W. Smith’s proprietary single-wheel co-axial escapement and finished according to the historic Daniels Method.
              </p>
            </div>

            {/* Filter Tabs */}
            <div className="mt-10 flex flex-wrap gap-2 pt-4 border-t border-white/10">
              <button
                type="button"
                onClick={() => setActiveFilter('all')}
                className={`px-4 py-2 text-xs tracking-[0.2em] uppercase transition-colors ${
                  activeFilter === 'all'
                    ? 'bg-[#c4a265] text-[#091b15] font-semibold'
                    : 'bg-[#0b241c] text-[#a7baa0] hover:text-white border border-[#c4a265]/20'
                }`}
              >
                ALL TIMEPIECES ({WATCHES.length})
              </button>
              <button
                type="button"
                onClick={() => setActiveFilter('series1')}
                className={`px-4 py-2 text-xs tracking-[0.2em] uppercase transition-colors ${
                  activeFilter === 'series1'
                    ? 'bg-[#c4a265] text-[#091b15] font-semibold'
                    : 'bg-[#0b241c] text-[#a7baa0] hover:text-white border border-[#c4a265]/20'
                }`}
              >
                SERIES 1 (THE HERON)
              </button>
              <button
                type="button"
                onClick={() => setActiveFilter('series2')}
                className={`px-4 py-2 text-xs tracking-[0.2em] uppercase transition-colors ${
                  activeFilter === 'series2'
                    ? 'bg-[#c4a265] text-[#091b15] font-semibold'
                    : 'bg-[#0b241c] text-[#a7baa0] hover:text-white border border-[#c4a265]/20'
                }`}
              >
                SERIES 2 (THE MANX)
              </button>
              <button
                type="button"
                onClick={() => setActiveFilter('series5')}
                className={`px-4 py-2 text-xs tracking-[0.2em] uppercase transition-colors ${
                  activeFilter === 'series5'
                    ? 'bg-[#c4a265] text-[#091b15] font-semibold'
                    : 'bg-[#0b241c] text-[#a7baa0] hover:text-white border border-[#c4a265]/20'
                }`}
              >
                SERIES 5 (THE TYNWALD)
              </button>
            </div>
          </div>
        </section>

        {/* Watches Grid */}
        <section className="py-16 lg:py-24">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-10">
              {filteredWatches.map((watch) => (
                <div 
                  key={watch.id}
                  className="bg-[#0b221a] border border-[#c4a265]/20 flex flex-col justify-between overflow-hidden group hover:border-[#c4a265]/60 transition-all duration-300 shadow-xl"
                >
                  {/* Image Container */}
                  <div className="relative aspect-square w-full bg-[#061510] overflow-hidden border-b border-[#c4a265]/15">
                    <Image
                      src={watch.heroImage}
                      alt={watch.name}
                      fill
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                      className="object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-4 left-4">
                      <span className="text-[9px] tracking-[0.22em] uppercase bg-[#061510]/85 text-[#c4a265] px-2.5 py-1 border border-[#c4a265]/30">
                        {watch.series}
                      </span>
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between space-y-6">
                    <div className="space-y-2">
                      <h2 className="font-serif text-2xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                        {watch.name}
                      </h2>
                      <p className="text-xs text-[#c4a265] tracking-[0.18em] uppercase font-light">
                        {watch.tagline}
                      </p>
                      <p className="text-xs text-[#a0b3a7] leading-relaxed font-light pt-2 line-clamp-3">
                        {watch.description}
                      </p>
                    </div>

                    {/* Quick Specs */}
                    <div className="space-y-2 pt-3 border-t border-white/5 text-[11px]">
                      <div className="flex justify-between">
                        <span className="text-[#7e9488]">Case Diameter</span>
                        <span className="text-[#f4f1ea] font-mono">{watch.caseDiameter.split(' ')[0]}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#7e9488]">Escapement</span>
                        <span className="text-[#dfc590]">Co-Axial</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-[#7e9488]">Calibre</span>
                        <span className="text-[#f4f1ea] font-mono">{watch.movementCalibre.split('—')[0]}</span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="grid grid-cols-2 gap-3 pt-2">
                      <Link
                        href={`/watches/${watch.slug}`}
                        className="text-center py-2.5 border border-[#c4a265]/50 text-[#f4f1ea] text-[10px] tracking-[0.2em] uppercase hover:bg-[#c4a265] hover:text-[#091b15] transition-colors"
                      >
                        VIEW DOSSIER
                      </Link>
                      <button
                        type="button"
                        onClick={() => handleEnquire(watch)}
                        className="py-2.5 bg-[#c4a265] text-[#091b15] text-[10px] tracking-[0.2em] uppercase font-semibold hover:bg-[#dfc590] transition-colors"
                      >
                        ENQUIRE
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Bespoke Commission Banner */}
        <section className="py-16 bg-[#061510] border-t border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16 flex flex-col md:flex-row items-center justify-between gap-8">
            <div className="space-y-2">
              <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                BESPOKE HOROLOGY
              </span>
              <h3 className="font-serif text-2xl sm:text-3xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                COMMISSIONING A UNIQUE TIMEPIECE
              </h3>
              <p className="text-xs text-[#8fa397] max-w-xl">
                For collectors seeking personalized dial guilloché motifs, bespoke casing or unique complications, Roger W. Smith accepts a limited number of bespoke commissions.
              </p>
            </div>
            <Link
              href="/bespoke"
              className="px-8 py-3.5 bg-transparent border border-[#c4a265] text-[#dfc590] text-xs tracking-[0.24em] uppercase hover:bg-[#c4a265] hover:text-[#091b15] transition-colors whitespace-nowrap"
            >
              BESPOKE CONSULTATION →
            </Link>
          </div>
        </section>
      </main>

      <Footer />

      <EnquiryModal
        isOpen={enquiryOpen}
        onClose={() => setEnquiryOpen(false)}
        defaultWatchSlug={selectedWatch?.slug}
        defaultWatchName={selectedWatch?.name}
      />
    </div>
  );
}
