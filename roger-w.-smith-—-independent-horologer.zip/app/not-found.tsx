import React from 'react';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Triskelion } from '@/components/Triskelion';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col">
      <Header />

      <main className="flex-1 flex items-center justify-center py-24 px-6 text-center">
        <div className="max-w-md space-y-6">
          <div className="flex justify-center">
            <Triskelion size={36} color="#c4a265" />
          </div>
          <span className="text-[10px] tracking-[0.3em] uppercase text-[#c4a265] font-medium">
            404 · TIMEPIECE UNLOCATED
          </span>
          <h1 className="font-serif text-3xl sm:text-4xl text-white font-normal uppercase">
            PAGE NOT FOUND
          </h1>
          <p className="text-xs sm:text-sm text-[#8fa397] leading-relaxed">
            The horological dossier or page you are seeking does not exist or has been relocated within the atelier archives.
          </p>
          <div className="pt-2">
            <Link
              href="/"
              className="inline-block px-8 py-3.5 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#dfc590] transition-colors"
            >
              RETURN TO ATELIER HOME →
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
