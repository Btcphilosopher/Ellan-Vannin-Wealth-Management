import React from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col">
      <Header />

      <main className="flex-1 py-16 lg:py-24">
        <div className="max-w-[840px] mx-auto px-6 space-y-8">
          <div className="space-y-2 border-b border-[#c4a265]/20 pb-6">
            <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
              LEGAL NOTICE
            </span>
            <h1 className="font-serif text-3xl sm:text-4xl text-white font-normal uppercase tracking-wider">
              TERMS & CONDITIONS
            </h1>
            <p className="text-xs text-[#8fa397]">
              Roger W. Smith Ltd. · Ramsey, Isle of Man
            </p>
          </div>

          <div className="space-y-6 text-sm text-[#cbd6cf] font-light leading-relaxed">
            <section className="space-y-2">
              <h2 className="text-base text-white font-medium uppercase tracking-wider text-[#c4a265]">
                1. Nature of the Website
              </h2>
              <p>
                This website is an informational and editorial portfolio presenting the horological craftsmanship of Roger W. Smith OBE. Transmission of an enquiry form does not constitute a binding purchase contract or an immediate guarantee of timepiece allocation.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-base text-white font-medium uppercase tracking-wider text-[#c4a265]">
                2. Allocation & Commission Agreements
              </h2>
              <p>
                All timepiece allocations, bespoke orders, and waiting-list registrations are formalized through separate bilateral legal contracts executed directly between Roger W. Smith Ltd. and the patron following personal consultation.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-base text-white font-medium uppercase tracking-wider text-[#c4a265]">
                3. Intellectual Property
              </h2>
              <p>
                All horological mechanisms, movement calibre designs, rose-engine dial motifs, photography, text, and registered trademarks—including the signature hands, single-wheel co-axial escapement modifications, and brand monogram—remain the exclusive intellectual property of Roger W. Smith Ltd.
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
