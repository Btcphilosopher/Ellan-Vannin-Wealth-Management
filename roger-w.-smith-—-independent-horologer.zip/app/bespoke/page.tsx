'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Triskelion } from '@/components/Triskelion';
import { EnquiryModal } from '@/components/EnquiryModal';
import { ShieldCheck, Calendar, Compass, Feather } from 'lucide-react';

export default function BespokePage() {
  const [enquiryOpen, setEnquiryOpen] = useState(false);

  const STEPS = [
    {
      num: '01',
      title: 'Private Consultation',
      description: 'An intimate dialogue directly with Roger W. Smith OBE or senior horologists to establish your aesthetic desires, case ergonomics, and intended complications.'
    },
    {
      num: '02',
      title: 'Dial & Movement Architecture',
      description: 'Hand-rendering of bespoke dial patterns on our 19th-century rose engines. Options include bespoke chapter lettering, family crests, and unique frosting tones.'
    },
    {
      num: '03',
      title: 'Hand Fabrication in Ramsey',
      description: 'Between 1,500 and 2,500 hours of manual craftsmanship where every component is sawn, turned, filed, hardened and polished by individual craftsmen.'
    },
    {
      num: '04',
      title: 'Atelier Presentation',
      description: 'Personal presentation on the Isle of Man, where the finished timepiece is handed over along with its bespoke hand-bound archival provenance book.'
    }
  ];

  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col">
      <Header onOpenEnquiry={() => setEnquiryOpen(true)} />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative py-20 lg:py-28 bg-gradient-to-b from-[#091b15] to-[#071812] border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="max-w-3xl space-y-4">
              <div className="flex items-center space-x-3">
                <Triskelion size={20} color="#c4a265" />
                <span className="text-[11px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                  INDIVIDUAL HOROLOGICAL PATRONAGE
                </span>
              </div>
              <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl tracking-[0.14em] uppercase text-[#f4f1ea] font-normal leading-tight">
                BESPOKE COMMISSIONS
              </h1>
              <p className="text-base sm:text-lg text-[#cbd6cf] font-light leading-relaxed">
                A Roger W. Smith bespoke commission is not an adaptation of an industrial catalog; it is an intimate collaboration between collector and master watchmaker.
              </p>
            </div>
          </div>
        </section>

        {/* Narrative Split */}
        <section className="py-20 border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
              
              <div className="space-y-6">
                <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                  THE SPIRIT OF BESPOKE
                </span>
                <h2 className="font-serif text-2xl sm:text-4xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                  CREATING TIMELESS INDIVIDUALITY
                </h2>
                <div className="w-12 h-[1px] bg-[#c4a265]/70" />
                <p className="text-sm sm:text-base text-[#a7baa0] leading-relaxed font-light">
                  Because every dial is cut individually with rose engines and every hand sculptured by eye, our atelier can adapt geometry, guilloché wave pitches, and hand-painted miniature details to the patron’s singular vision.
                </p>
                <p className="text-sm sm:text-base text-[#a7baa0] leading-relaxed font-light">
                  Past commissions have encompassed platinum single-piece wristwatches with custom calendar mechanisms, dials in British Racing Green and Imperial Midnight Blue, and movement plates engraved with celestial constellations or personal historic emblems.
                </p>
                <div className="pt-2">
                  <button
                    type="button"
                    onClick={() => setEnquiryOpen(true)}
                    className="px-8 py-3.5 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-[0.22em] uppercase hover:bg-[#dfc590] transition-colors"
                  >
                    INITIATE BESPOKE INQUIRY →
                  </button>
                </div>
              </div>

              <div className="relative aspect-[4/3] border border-[#c4a265]/20 overflow-hidden shadow-2xl">
                <Image
                  src="/images/rws_watch_the_tynwald.jpg"
                  alt="Bespoke watch in midnight blue"
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

            </div>
          </div>
        </section>

        {/* 4 Steps of the Client Journey */}
        <section className="py-20 bg-[#071712]">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16 space-y-12">
            <div className="text-center max-w-xl mx-auto space-y-3">
              <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                THE PATRON&apos;S JOURNEY
              </span>
              <h2 className="font-serif text-2xl sm:text-4xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                FROM CONCEPTION TO CREATION
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {STEPS.map((step) => (
                <div
                  key={step.num}
                  className="bg-[#091b15] border border-[#c4a265]/20 p-6 space-y-4 hover:border-[#c4a265]/60 transition-colors"
                >
                  <span className="font-mono text-2xl text-[#c4a265] font-light">
                    {step.num}
                  </span>
                  <h3 className="font-serif text-lg tracking-[0.12em] uppercase text-[#f4f1ea]">
                    {step.title}
                  </h3>
                  <p className="text-xs text-[#a0b3a7] leading-relaxed font-light">
                    {step.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />

      <EnquiryModal
        isOpen={enquiryOpen}
        onClose={() => setEnquiryOpen(false)}
        defaultWatchName="Bespoke Commission Dialogue"
      />
    </div>
  );
}
