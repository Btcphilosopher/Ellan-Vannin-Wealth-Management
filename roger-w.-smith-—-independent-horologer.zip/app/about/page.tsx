'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Triskelion } from '@/components/Triskelion';
import { EnquiryModal } from '@/components/EnquiryModal';
import { Award, Compass, History, BookOpen } from 'lucide-react';

export default function AboutPage() {
  const [enquiryOpen, setEnquiryOpen] = useState(false);

  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col">
      <Header onOpenEnquiry={() => setEnquiryOpen(true)} />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative py-20 lg:py-28 bg-gradient-to-b from-[#091b15] via-[#081a14] to-[#071812] border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="max-w-3xl space-y-4">
              <div className="flex items-center space-x-3">
                <Triskelion size={20} color="#c4a265" />
                <span className="text-[11px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                  BIOGRAPHY & HOROLOGICAL PHILOSOPHY
                </span>
              </div>
              <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl tracking-[0.14em] uppercase text-[#f4f1ea] font-normal leading-tight">
                ROGER W. SMITH OBE
              </h1>
              <p className="text-base sm:text-lg text-[#cbd6cf] font-light leading-relaxed">
                The sole protégé of Dr. George Daniels CBE and the leading exponent of independent British handcrafted watchmaking.
              </p>
            </div>
          </div>
        </section>

        {/* The 7-Year Trial Section */}
        <section className="py-20 border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
              
              <div className="lg:col-span-6 space-y-6">
                <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                  THE FORMATIVE YEARS
                </span>
                <h2 className="font-serif text-2xl sm:text-4xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                  THE TRIAL OF THE SECOND WATCH
                </h2>
                <div className="w-12 h-[1px] bg-[#c4a265]/70" />
                <p className="text-sm sm:text-base text-[#a7baa0] leading-relaxed font-light">
                  Born in Bolton, Roger discovered his passion at the Manchester School of Horology. A guest lecture by Dr. George Daniels—displaying his legendary Space Traveller pocket watch—ignited an obsession: to learn how to make an entire watch by hand.
                </p>
                <p className="text-sm sm:text-base text-[#a7baa0] leading-relaxed font-light">
                  At 22, Roger presented his first handmade pocket watch to Daniels. George inspected it, acknowledged the effort, but told him bluntly: &ldquo;It looks handmade. A watch should look as though it simply created itself.&rdquo;
                </p>
                <p className="text-sm sm:text-base text-[#a7baa0] leading-relaxed font-light">
                  Rather than giving up, Roger spent five and a half years in a spare bedroom remaking every single component, teaching himself thirty-four crafts. When he brought his second pocket watch to the Isle of Man, Daniels smiled and declared: &ldquo;You are now a watchmaker.&rdquo;
                </p>
              </div>

              <div className="lg:col-span-6 relative aspect-[4/3] border border-[#c4a265]/20 overflow-hidden shadow-2xl">
                <Image
                  src="/images/rws_watchmaker_workshop.jpg"
                  alt="Roger W. Smith workshop craftsmanship"
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

            </div>
          </div>
        </section>

        {/* The Isle of Man Atelier Section */}
        <section className="py-20 bg-[#071712] border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
              
              <div className="lg:col-span-6 relative aspect-[4/3] border border-[#c4a265]/20 overflow-hidden shadow-2xl order-2 lg:order-1">
                <Image
                  src="/images/rws_isle_of_man_cliffs.jpg"
                  alt="Isle of Man coastline cliffs"
                  fill
                  className="object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>

              <div className="lg:col-span-6 space-y-6 order-1 lg:order-2">
                <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                  THE SANCTUARY OF RAMSEY
                </span>
                <h2 className="font-serif text-2xl sm:text-4xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                  HOROLOGY IN SOLITUDE
                </h2>
                <div className="w-12 h-[1px] bg-[#c4a265]/70" />
                <p className="text-sm sm:text-base text-[#a7baa0] leading-relaxed font-light">
                  In 1998, Roger moved permanently to the Isle of Man to work beside George Daniels on the Millennium series of fifty wristwatches. In 2001, Roger established his own studio outside Ramsey.
                </p>
                <p className="text-sm sm:text-base text-[#a7baa0] leading-relaxed font-light">
                  Here, overlooking the Irish Sea, the studio maintains an output of approximately 10 to 12 watches per year. Free from industrial pressures, every watch is afforded hundreds of hours of manual finishing and testing.
                </p>
              </div>

            </div>
          </div>
        </section>

        {/* Honors and Accolades */}
        <section className="py-20">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="text-center max-w-xl mx-auto space-y-3 mb-12">
              <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                RECOGNITION
              </span>
              <h2 className="font-serif text-2xl sm:text-4xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                HONORS & APPOINTMENTS
              </h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-[#0b241c] border border-[#c4a265]/20 p-6 space-y-3">
                <span className="text-xs tracking-[0.2em] uppercase text-[#c4a265] font-semibold">
                  OBE APPOINTMENT (2018)
                </span>
                <h3 className="font-serif text-lg text-white">Officer of the Order of the British Empire</h3>
                <p className="text-xs text-[#8fa397] leading-relaxed font-light">
                  Awarded in Her Majesty Queen Elizabeth II&apos;s New Year Honours for services to British watchmaking.
                </p>
              </div>

              <div className="bg-[#0b241c] border border-[#c4a265]/20 p-6 space-y-3">
                <span className="text-xs tracking-[0.2em] uppercase text-[#c4a265] font-semibold">
                  THE GREAT BRITAIN WATCH
                </span>
                <h3 className="font-serif text-lg text-white">Commissioned by the Prime Minister&apos;s Office</h3>
                <p className="text-xs text-[#8fa397] leading-relaxed font-light">
                  A unique timepiece created to showcase British engineering and innovation to head-of-state summits worldwide.
                </p>
              </div>

              <div className="bg-[#0b241c] border border-[#c4a265]/20 p-6 space-y-3">
                <span className="text-xs tracking-[0.2em] uppercase text-[#c4a265] font-semibold">
                  AHCI MEMBER & BARRETT MEDAL
                </span>
                <h3 className="font-serif text-lg text-white">Académie Horlogère des Créateurs Indépendants</h3>
                <p className="text-xs text-[#8fa397] leading-relaxed font-light">
                  Honoured with the British Horological Institute&apos;s Barrett Silver Medal for horological contributions.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />

      <EnquiryModal
        isOpen={enquiryOpen}
        onClose={() => setEnquiryOpen(false)}
      />
    </div>
  );
}
