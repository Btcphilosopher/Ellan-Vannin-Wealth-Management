'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Triskelion } from '@/components/Triskelion';
import { EnquiryModal } from '@/components/EnquiryModal';
import { ArrowRight } from 'lucide-react';

export default function HomePage() {
  const [enquiryOpen, setEnquiryOpen] = useState(false);
  const [selectedWatch, setSelectedWatch] = useState<{ slug: string; name: string } | null>(null);

  const handleOpenWatchEnquiry = (slug: string, name: string) => {
    setSelectedWatch({ slug, name });
    setEnquiryOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col selection:bg-[#c4a265] selection:text-[#091b15]">
      {/* Authoritative Navigation Header */}
      <Header onOpenEnquiry={() => { setSelectedWatch(null); setEnquiryOpen(true); }} />

      <main className="flex-1">
        {/* HERO SECTION - Split Layout matching authoritative screenshot */}
        <section className="relative overflow-hidden bg-gradient-to-b from-[#091b15] via-[#081a14] to-[#071812] border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16 py-12 lg:py-24">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center min-h-[580px] lg:min-h-[660px]">
              
              {/* Left Column: Brand Statement & CTA */}
              <div className="lg:col-span-5 flex flex-col justify-center space-y-6 lg:space-y-8 z-10 lg:pr-6">
                <div>
                  <h1 className="font-serif text-3xl sm:text-5xl lg:text-[54px] tracking-[0.16em] uppercase text-[#f4f1ea] font-normal leading-[1.15]">
                    ROGER W SMITH
                  </h1>
                  <p className="mt-3 text-xs sm:text-sm tracking-[0.32em] uppercase text-[#c4a265] font-light">
                    INDEPENDENT HOROLOGER
                  </p>
                </div>

                {/* Subtle Hairline Gold Divider Rule */}
                <div className="w-12 h-[1px] bg-[#c4a265]/70" />

                {/* Italic Editorial Prose */}
                <div className="space-y-2">
                  <p className="font-serif italic text-xl sm:text-2xl lg:text-[28px] leading-relaxed text-[#ede8df] font-light">
                    Fine mechanical watches,<br />
                    handcrafted on the Isle of Man.
                  </p>
                </div>

                {/* Primary CTA Button */}
                <div className="pt-2">
                  <Link
                    href="/collection"
                    className="inline-flex items-center space-x-3 px-6 py-3.5 border border-[#c4a265]/80 text-[#dfc590] hover:text-[#091b15] hover:bg-[#c4a265] transition-all duration-300 text-[11px] sm:text-xs tracking-[0.24em] uppercase font-medium group"
                  >
                    <span>EXPLORE THE COLLECTION</span>
                    <span className="transform group-hover:translate-x-1 transition-transform duration-200">
                      →
                    </span>
                  </Link>
                </div>
              </div>

              {/* Right Column: Hero Macro Watch Image on Leather Box */}
              <div className="lg:col-span-7 relative flex items-center justify-center lg:justify-end">
                <div className="relative w-full aspect-[4/3] sm:aspect-[16/11] lg:aspect-[4/3] max-w-[700px] overflow-hidden rounded-sm shadow-2xl border border-[#c4a265]/20 group">
                  <Image
                    src="/images/rws_hero_watch_green.jpg"
                    alt="Roger W. Smith handcrafted chronometer with British racing green guilloché dial"
                    fill
                    priority
                    sizes="(max-width: 1024px) 100vw, 58vw"
                    className="object-cover object-center group-hover:scale-[1.02] transition-transform duration-700 ease-out"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#091b15]/60 via-transparent to-transparent pointer-events-none" />
                </div>
              </div>

            </div>
          </div>
        </section>

        {/* TRIPTYCH FEATURE SECTION - 3 Columns matching authoritative screenshot */}
        <section className="w-full bg-[#071812] border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto">
            <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-[#c4a265]/15">
              
              {/* Column 1: The Isle of Man Landscape with Overlay Card */}
              <div className="relative min-h-[460px] lg:min-h-[540px] flex flex-col justify-end p-8 sm:p-10 overflow-hidden group">
                <Image
                  src="/images/rws_isle_of_man_cliffs.jpg"
                  alt="Rugged green cliffs and coastline of the Isle of Man with Milner's Tower"
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#061510] via-[#061510]/60 to-transparent" />
                
                {/* Overlay Text Content */}
                <div className="relative z-10 space-y-3">
                  <h3 className="text-xs sm:text-[13px] tracking-[0.28em] uppercase text-[#dfc590] font-medium">
                    THE ISLE OF MAN
                  </h3>
                  <p className="text-xs sm:text-[13px] leading-relaxed text-[#c6d3cb] font-light max-w-sm">
                    A place of rugged beauty, independent spirit and a long tradition of craftsmanship. It is here, on this remarkable island, that Roger W Smith creates his timepieces.
                  </p>
                  <div className="pt-1">
                    <Link
                      href="/about"
                      className="inline-flex items-center space-x-2 text-[11px] tracking-[0.22em] uppercase text-[#f4f1ea] hover:text-[#c4a265] transition-colors group/link"
                    >
                      <span className="border-b border-[#c4a265]/40 pb-0.5">DISCOVER MORE</span>
                      <span className="group-hover/link:translate-x-1 transition-transform">→</span>
                    </Link>
                  </div>
                </div>
              </div>

              {/* Column 2: Tradition Meets Precision (Editorial Centerpiece) */}
              <div className="bg-[#0b241c] p-8 sm:p-12 lg:p-14 flex flex-col justify-center items-center text-center space-y-6">
                <div className="pt-2">
                  <Triskelion size={34} color="#c4a265" className="hover:scale-110 transition-transform duration-300" />
                </div>

                <div className="space-y-1">
                  <h2 className="font-serif text-2xl sm:text-3xl tracking-[0.2em] uppercase text-[#f4f1ea] font-normal leading-tight">
                    TRADITION<br />MEETS PRECISION
                  </h2>
                </div>

                {/* Hairline Divider */}
                <div className="w-10 h-[1px] bg-[#c4a265]/60" />

                <p className="text-xs sm:text-[13px] leading-relaxed text-[#cbd6cf] font-light max-w-sm mx-auto">
                  Each Roger W Smith watch is conceived, designed and built by hand, combining traditional British watchmaking techniques with a relentless pursuit of precision, reliability and beauty.
                </p>

                <div className="pt-2">
                  <Link
                    href="/craft"
                    className="inline-flex items-center space-x-2 text-[11px] tracking-[0.24em] uppercase text-[#dfc590] hover:text-white transition-colors group"
                  >
                    <span className="border-b border-[#c4a265] pb-0.5">THE CRAFT</span>
                    <span className="group-hover:translate-x-1 transition-transform">→</span>
                  </Link>
                </div>
              </div>

              {/* Column 3: The Workshop Macro Craftsmanship Photography */}
              <div className="relative min-h-[460px] lg:min-h-[540px] overflow-hidden group">
                <Image
                  src="/images/rws_watchmaker_workshop.jpg"
                  alt="Watchmaker assembling delicate mechanical escapement with tweezers at workbench"
                  fill
                  sizes="(max-width: 768px) 100vw, 33vw"
                  className="object-cover object-center group-hover:scale-105 transition-transform duration-700 ease-out"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#061510]/50 via-transparent to-transparent" />
              </div>

            </div>
          </div>
        </section>

        {/* THE COLLECTION SECTION - Split layout matching authoritative screenshot */}
        <section className="w-full bg-[#091b15] py-16 lg:py-24 border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
              
              {/* Left Editorial Text Column */}
              <div className="lg:col-span-3 space-y-5">
                <h2 className="font-serif text-2xl sm:text-3xl tracking-[0.2em] uppercase text-[#f4f1ea] font-normal">
                  THE COLLECTION
                </h2>
                <p className="text-xs sm:text-[13px] leading-relaxed text-[#a1b5aa] font-light">
                  A small collection of timepieces, made in limited numbers, for those who value independence, tradition and lasting value.
                </p>
                <div className="pt-2">
                  <Link
                    href="/collection"
                    className="inline-flex items-center space-x-2 text-[11px] tracking-[0.22em] uppercase text-[#dfc590] hover:text-white transition-colors group"
                  >
                    <span className="border-b border-[#c4a265] pb-0.5">VIEW COLLECTION</span>
                    <span className="group-hover:translate-x-1 transition-transform">→</span>
                  </Link>
                </div>
              </div>

              {/* Right Watch Cards Grid (3 Watches) */}
              <div className="lg:col-span-9">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 lg:gap-8">
                  
                  {/* Card 1: THE HERON */}
                  <div className="group flex flex-col items-center">
                    <Link 
                      href="/watches/the-heron"
                      className="relative w-full aspect-square bg-[#061711] border border-[#c4a265]/20 overflow-hidden shadow-lg transition-all duration-500 group-hover:border-[#c4a265]/70"
                    >
                      <Image
                        src="/images/rws_watch_the_heron.jpg"
                        alt="The Heron timepiece with British racing green guilloché dial"
                        fill
                        sizes="(max-width: 640px) 100vw, (max-width: 1024px) 33vw, 25vw"
                        className="object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
                    </Link>
                    <div className="mt-4 text-center">
                      <Link 
                        href="/watches/the-heron"
                        className="text-xs tracking-[0.26em] uppercase text-[#f4f1ea] hover:text-[#c4a265] transition-colors font-medium"
                      >
                        THE HERON
                      </Link>
                      <p className="text-[10px] tracking-[0.18em] text-[#8fa397] uppercase mt-1">
                        Series 1 Edition
                      </p>
                    </div>
                  </div>

                  {/* Card 2: THE MANX */}
                  <div className="group flex flex-col items-center">
                    <Link 
                      href="/watches/the-manx"
                      className="relative w-full aspect-square bg-[#061711] border border-[#c4a265]/20 overflow-hidden shadow-lg transition-all duration-500 group-hover:border-[#c4a265]/70"
                    >
                      <Image
                        src="/images/rws_watch_the_manx.jpg"
                        alt="The Manx timepiece with silver hand-guilloché dial"
                        fill
                        sizes="(max-width: 640px) 100vw, (max-width: 1024px) 33vw, 25vw"
                        className="object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
                    </Link>
                    <div className="mt-4 text-center">
                      <Link 
                        href="/watches/the-manx"
                        className="text-xs tracking-[0.26em] uppercase text-[#f4f1ea] hover:text-[#c4a265] transition-colors font-medium"
                      >
                        THE MANX
                      </Link>
                      <p className="text-[10px] tracking-[0.18em] text-[#8fa397] uppercase mt-1">
                        Series 2 Classic
                      </p>
                    </div>
                  </div>

                  {/* Card 3: THE TYNWALD */}
                  <div className="group flex flex-col items-center">
                    <Link 
                      href="/watches/the-tynwald"
                      className="relative w-full aspect-square bg-[#061711] border border-[#c4a265]/20 overflow-hidden shadow-lg transition-all duration-500 group-hover:border-[#c4a265]/70"
                    >
                      <Image
                        src="/images/rws_watch_the_tynwald.jpg"
                        alt="The Tynwald timepiece with midnight blue dial"
                        fill
                        sizes="(max-width: 640px) 100vw, (max-width: 1024px) 33vw, 25vw"
                        className="object-cover object-center group-hover:scale-105 transition-transform duration-500 ease-out"
                        referrerPolicy="no-referrer"
                      />
                      <div className="absolute inset-0 bg-black/10 group-hover:bg-transparent transition-colors" />
                    </Link>
                    <div className="mt-4 text-center">
                      <Link 
                        href="/watches/the-tynwald"
                        className="text-xs tracking-[0.26em] uppercase text-[#f4f1ea] hover:text-[#c4a265] transition-colors font-medium"
                      >
                        THE TYNWALD
                      </Link>
                      <p className="text-[10px] tracking-[0.18em] text-[#8fa397] uppercase mt-1">
                        Series 5 Sovereign
                      </p>
                    </div>
                  </div>

                </div>
              </div>

            </div>
          </div>
        </section>

        {/* RESTRAINED EDITORIAL PHILOSOPHY CALLOUT */}
        <section className="w-full bg-[#061510] py-20 border-b border-[#c4a265]/15">
          <div className="max-w-[960px] mx-auto px-6 text-center space-y-6">
            <span className="text-[10px] tracking-[0.3em] uppercase text-[#c4a265] font-medium">
              THE DANIELS METHOD
            </span>
            <blockquote className="font-serif italic text-xl sm:text-2xl lg:text-3xl text-[#ede8df] leading-relaxed font-light">
              &ldquo;To be a watchmaker, one must be capable of designing, calculating, and making every single component of a watch by hand.&rdquo;
            </blockquote>
            <p className="text-xs tracking-[0.24em] uppercase text-[#8fa397]">
              — Dr. George Daniels CBE & Roger W. Smith OBE
            </p>
            <div className="pt-4 flex flex-wrap justify-center gap-4 text-xs">
              <button
                type="button"
                onClick={() => { setSelectedWatch(null); setEnquiryOpen(true); }}
                className="px-6 py-3 bg-[#c4a265] text-[#091b15] tracking-[0.2em] uppercase font-semibold hover:bg-[#dfc590] transition-colors"
              >
                REQUEST PRIVATE ALLOCATION DIALOGUE
              </button>
              <Link
                href="/craft"
                className="px-6 py-3 border border-[#c4a265]/40 text-[#dfc590] tracking-[0.2em] uppercase font-medium hover:border-[#c4a265] hover:text-white transition-colors"
              >
                DISCOVER THE 32 CRAFTS
              </Link>
            </div>
          </div>
        </section>
      </main>

      {/* Authoritative Footer matching screenshot */}
      <Footer />

      {/* Interactive Allocation / Confidential Enquiry Modal */}
      <EnquiryModal
        isOpen={enquiryOpen}
        onClose={() => setEnquiryOpen(false)}
        defaultWatchSlug={selectedWatch?.slug}
        defaultWatchName={selectedWatch?.name}
      />
    </div>
  );
}
