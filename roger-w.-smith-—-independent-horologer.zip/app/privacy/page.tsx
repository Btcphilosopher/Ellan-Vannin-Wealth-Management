import React from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col">
      <Header />

      <main className="flex-1 py-16 lg:py-24">
        <div className="max-w-[840px] mx-auto px-6 space-y-8">
          <div className="space-y-2 border-b border-[#c4a265]/20 pb-6">
            <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
              LEGAL NOTICE
            </span>
            <h1 className="font-serif text-3xl sm:text-4xl text-white font-normal uppercase tracking-wider">
              PRIVACY POLICY
            </h1>
            <p className="text-xs text-[#8fa397]">
              Last updated: October 2026 · Registered in the Isle of Man
            </p>
          </div>

          <div className="space-y-6 text-sm text-[#cbd6cf] font-light leading-relaxed">
            <section className="space-y-2">
              <h2 className="text-base text-white font-medium uppercase tracking-wider text-[#c4a265]">
                1. Data Controller & Principle of Discretion
              </h2>
              <p>
                Roger W. Smith Ltd. (&ldquo;we&rdquo;, &ldquo;our&rdquo;, &ldquo;the atelier&rdquo;) operates with the utmost discretion. We do not sell, rent, license, or exchange client information with commercial brokers or advertising networks.
              </p>
              <p>
                Our data practices comply strictly with the Isle of Man Data Protection Act 2018 and the UK General Data Protection Regulation (UK GDPR).
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-base text-white font-medium uppercase tracking-wider text-[#c4a265]">
                2. Information Collected During Allocation
              </h2>
              <p>
                When you initiate an allocation enquiry or commission dialogue, we collect your name, contact telephone, email address, country of residence, and horological preferences. This information is retained solely to review production capacity, coordinate private atelier consultations, and maintain the historical provenance registry of our timepieces.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-base text-white font-medium uppercase tracking-wider text-[#c4a265]">
                3. Cookies & Tracking Technologies
              </h2>
              <p>
                This website does not employ third-party advertising cookies, cross-site trackers, or behavioral profiling tools. Essential technical session cookies may be used solely to manage navigation and protect our administrative interfaces.
              </p>
            </section>

            <section className="space-y-2">
              <h2 className="text-base text-white font-medium uppercase tracking-wider text-[#c4a265]">
                4. Your Rights
              </h2>
              <p>
                You maintain the right under Manx and UK law to request access to your personal dossier, rectify any inaccuracies, or request the deletion of your enquiry data by contacting us at enquiries@rwsmithwatches.com.
              </p>
            </section>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
