'use client';

import React, { useState } from 'react';
import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { Triskelion } from '@/components/Triskelion';
import { Mail, Phone, MapPin, CheckCircle2, ShieldCheck, AlertCircle } from 'lucide-react';

export default function ContactPage() {
  const [clientName, setClientName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('United Kingdom');
  const [category, setCategory] = useState<'watch_allocation' | 'bespoke_commission' | 'atelier_visit' | 'general'>('watch_allocation');
  const [watchName, setWatchName] = useState('The Heron (Series 1)');
  const [preferredContact, setPreferredContact] = useState<'email' | 'phone' | 'atelier_visit'>('email');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [receipt, setReceipt] = useState<{ reference: string; clientName: string; email: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      const res = await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName,
          email,
          phone,
          country,
          type: category,
          watchName: category === 'watch_allocation' ? watchName : undefined,
          preferredContact,
          message,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to submit enquiry.');
      }

      setReceipt({
        reference: data.enquiry.reference,
        clientName: data.enquiry.clientName,
        email: data.enquiry.email,
      });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'An error occurred while transmitting your enquiry.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#091b15] text-[#f4f1ea] flex flex-col">
      <Header />

      <main className="flex-1">
        {/* Hero */}
        <section className="relative py-16 lg:py-24 bg-gradient-to-b from-[#091b15] to-[#071812] border-b border-[#c4a265]/15">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="max-w-2xl space-y-4">
              <span className="text-[11px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                ISLE OF MAN WORKSHOP
              </span>
              <h1 className="font-serif text-3xl sm:text-5xl lg:text-6xl tracking-[0.14em] uppercase text-[#f4f1ea] font-normal">
                CONTACT & ENQUIRIES
              </h1>
              <p className="text-sm sm:text-base text-[#cbd6cf] font-light leading-relaxed">
                We welcome confidential enquiries from collectors, horologists and patrons worldwide. All acquisition and workshop discussions are conducted with strict discretion.
              </p>
            </div>
          </div>
        </section>

        {/* Content Section */}
        <section className="py-16 lg:py-24">
          <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16">
              
              {/* Atelier Details Left */}
              <div className="lg:col-span-5 space-y-8">
                <div className="space-y-3">
                  <span className="text-[10px] tracking-[0.28em] uppercase text-[#c4a265] font-medium">
                    ATELIER INFORMATION
                  </span>
                  <h2 className="font-serif text-2xl sm:text-3xl tracking-[0.16em] uppercase text-[#f4f1ea]">
                    ROGER W. SMITH LTD.
                  </h2>
                </div>

                <div className="space-y-6 text-sm text-[#cbd6cf]">
                  <div className="flex items-start space-x-4">
                    <MapPin size={20} className="text-[#c4a265] shrink-0 mt-1" />
                    <div>
                      <h4 className="text-xs uppercase tracking-wider text-[#c4a265] mb-1">Workshop Location</h4>
                      <p className="font-light">The Workshop, PO Box 67</p>
                      <p className="font-light">Ramsey, Isle of Man, IM99 4LE</p>
                      <p className="font-light">British Isles</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <Mail size={20} className="text-[#c4a265] shrink-0 mt-1" />
                    <div>
                      <h4 className="text-xs uppercase tracking-wider text-[#c4a265] mb-1">Direct Correspondence</h4>
                      <p className="font-mono text-xs text-[#f4f1ea]">enquiries@rwsmithwatches.com</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <Phone size={20} className="text-[#c4a265] shrink-0 mt-1" />
                    <div>
                      <h4 className="text-xs uppercase tracking-wider text-[#c4a265] mb-1">Telephone Registry</h4>
                      <p className="font-mono text-xs text-[#f4f1ea]">+44 (0) 1624 897949</p>
                      <p className="text-xs text-[#8fa397]">Monday – Friday, 09:00 – 17:00 GMT</p>
                    </div>
                  </div>
                </div>

                <div className="bg-[#0b241c] border border-[#c4a265]/20 p-6 space-y-3">
                  <div className="flex items-center space-x-2 text-xs text-[#c4a265] font-semibold tracking-wider uppercase">
                    <ShieldCheck size={16} />
                    <span>PRIVATE VISITOR POLICY</span>
                  </div>
                  <p className="text-xs text-[#8fa397] leading-relaxed">
                    To preserve the quiet concentration required for watchmaking, our workshop in Ramsey accepts visitors by confirmed appointment only.
                  </p>
                </div>
              </div>

              {/* Form Right */}
              <div className="lg:col-span-7 bg-[#0b221a] border border-[#c4a265]/25 p-8 sm:p-10 shadow-2xl">
                {receipt ? (
                  <div className="text-center py-10 space-y-6">
                    <div className="w-16 h-16 rounded-full bg-[#0d261e] border border-[#c4a265] flex items-center justify-center text-[#c4a265] mx-auto">
                      <CheckCircle2 size={36} />
                    </div>

                    <div className="space-y-2">
                      <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                        OFFICIAL RECORD CREATED
                      </span>
                      <h2 className="font-serif text-3xl text-white">
                        Thank You, {receipt.clientName}
                      </h2>
                    </div>

                    <div className="bg-[#061510] border border-[#c4a265]/30 p-5 max-w-md mx-auto text-left space-y-2">
                      <div className="flex justify-between text-xs">
                        <span className="text-[#8fa397]">Dossier Reference</span>
                        <span className="font-mono text-[#dfc590] font-semibold">{receipt.reference}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-[#8fa397]">Dispatch Notice</span>
                        <span className="text-white/90">{receipt.email}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-[#8fa397]">Status</span>
                        <span className="text-[#c4a265]">Registered in Atelier Ledger</span>
                      </div>
                    </div>

                    <p className="text-xs text-[#8fa397] max-w-md mx-auto">
                      A member of the Roger W. Smith team on the Isle of Man will review your dossier and be in touch promptly.
                    </p>

                    <button
                      type="button"
                      onClick={() => {
                        setReceipt(null);
                        setClientName('');
                        setEmail('');
                        setMessage('');
                      }}
                      className="px-8 py-3 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#dfc590] transition-colors"
                    >
                      SUBMIT ANOTHER ENQUIRY
                    </button>
                  </div>
                ) : (
                  <div>
                    <div className="space-y-2 mb-8">
                      <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                        ATELIER DOSSIER
                      </span>
                      <h3 className="font-serif text-2xl sm:text-3xl text-white">
                        Request Allocation or Consultation
                      </h3>
                      <p className="text-xs text-[#8fa397]">
                        Please complete the fields below to initiate dialogue.
                      </p>
                    </div>

                    {error && (
                      <div className="mb-6 p-3 bg-red-950/40 border border-red-500/40 text-red-200 text-xs flex items-center space-x-2">
                        <AlertCircle size={16} className="shrink-0 text-red-400" />
                        <span>{error}</span>
                      </div>
                    )}

                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                            FULL NAME *
                          </label>
                          <input
                            type="text"
                            required
                            value={clientName}
                            onChange={(e) => setClientName(e.target.value)}
                            placeholder="Full Name / Title"
                            className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none transition-colors"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                            EMAIL ADDRESS *
                          </label>
                          <input
                            type="email"
                            required
                            value={email}
                            onChange={(e) => setEmail(e.target.value)}
                            placeholder="client@address.com"
                            className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none transition-colors"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                            TELEPHONE NUMBER
                          </label>
                          <input
                            type="tel"
                            value={phone}
                            onChange={(e) => setPhone(e.target.value)}
                            placeholder="+44 20 7000 0000"
                            className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none transition-colors"
                          />
                        </div>

                        <div>
                          <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                            COUNTRY OF RESIDENCE *
                          </label>
                          <input
                            type="text"
                            required
                            value={country}
                            onChange={(e) => setCountry(e.target.value)}
                            placeholder="United Kingdom"
                            className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none transition-colors"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                            ENQUIRY NATURE
                          </label>
                          <select
                            value={category}
                            onChange={(e) => setCategory(e.target.value as any)}
                            className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none transition-colors"
                          >
                            <option value="watch_allocation">Timepiece Allocation</option>
                            <option value="bespoke_commission">Bespoke Commission</option>
                            <option value="atelier_visit">Private Atelier Visit</option>
                            <option value="general">General Horological Query</option>
                          </select>
                        </div>

                        {category === 'watch_allocation' ? (
                          <div>
                            <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                              TIMEPIECE MODEL
                            </label>
                            <select
                              value={watchName}
                              onChange={(e) => setWatchName(e.target.value)}
                              className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none transition-colors"
                            >
                              <option value="The Heron (Series 1)">The Heron (Series 1 Special Edition)</option>
                              <option value="The Manx (Series 2)">The Manx (Series 2 Classic)</option>
                              <option value="The Tynwald (Series 5)">The Tynwald (Series 5 Sovereign)</option>
                              <option value="Series 4 Triple Calendar">Series 4 Triple Calendar</option>
                            </select>
                          </div>
                        ) : (
                          <div>
                            <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                              PREFERRED CORRESPONDENCE
                            </label>
                            <select
                              value={preferredContact}
                              onChange={(e) => setPreferredContact(e.target.value as any)}
                              className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none transition-colors"
                            >
                              <option value="email">Discreet Email</option>
                              <option value="phone">Telephone</option>
                              <option value="atelier_visit">In-Person Atelier Visit</option>
                            </select>
                          </div>
                        )}
                      </div>

                      <div>
                        <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                          MESSAGE
                        </label>
                        <textarea
                          rows={4}
                          value={message}
                          onChange={(e) => setMessage(e.target.value)}
                          placeholder="Please articulate any specific aspects of interest..."
                          className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none transition-colors resize-none"
                        />
                      </div>

                      <div className="pt-2 flex justify-end">
                        <button
                          type="submit"
                          disabled={submitting}
                          className="px-8 py-3.5 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#dfc590] disabled:opacity-50 transition-colors"
                        >
                          {submitting ? 'TRANSMITTING...' : 'REGISTER ENQUIRY →'}
                        </button>
                      </div>
                    </form>
                  </div>
                )}
              </div>

            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
