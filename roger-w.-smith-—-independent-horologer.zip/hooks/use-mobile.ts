import * as React from "react"

const MOBILE_BREAKPOINT = 768

export function useIsMobile() {
  const [isMobile, setIsMobile] = React.useState<boolean>(false)

  React.useEffect(() => {
    const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
    const update = (e: MediaQueryListEvent | MediaQueryList) => {
      setIsMobile(e.matches)
    }
    update(mql)
    const listener = (e: MediaQueryListEvent) => update(e)
    mql.addEventListener("change", listener)
    return () => mql.removeEventListener("change", listener)
  }, [])

  return isMobile
}
