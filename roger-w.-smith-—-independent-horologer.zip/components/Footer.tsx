import React from 'react';
import Link from 'next/link';
import { Triskelion } from './Triskelion';
import { Instagram, Lock } from 'lucide-react';

export function Footer() {
  return (
    <footer className="w-full bg-[#061510] border-t border-[#c4a265]/20 text-[#8fa397]">
      <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16 py-12 lg:py-16">
        
        {/* Main Footer Row */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-8 text-center md:text-left">
          
          {/* Left Brand Mark */}
          <div className="space-y-1">
            <p className="font-serif text-lg tracking-[0.2em] uppercase text-[#f4f1ea] font-normal">
              ROGER W SMITH
            </p>
            <p className="text-[10px] tracking-[0.28em] text-[#8fa397] uppercase font-light">
              INDEPENDENT HOROLOGER
            </p>
          </div>

          {/* Center Isle of Man Emblem */}
          <div className="flex flex-col items-center">
            <Triskelion size={26} color="#c4a265" className="hover:scale-110 transition-transform" />
            <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium mt-1.5">
              ISLE OF MAN
            </span>
          </div>

          {/* Right Navigation & Legal */}
          <div className="flex flex-col sm:flex-row items-center gap-6 text-[10px] sm:text-[11px] tracking-[0.24em] uppercase">
            <div className="flex items-center space-x-4">
              <Link href="/contact" className="hover:text-[#f4f1ea] transition-colors">
                CONTACT
              </Link>
              <span className="text-white/20">|</span>
              <Link href="/privacy" className="hover:text-[#f4f1ea] transition-colors">
                PRIVACY
              </Link>
              <span className="text-white/20">|</span>
              <Link href="/terms" className="hover:text-[#f4f1ea] transition-colors">
                TERMS
              </Link>
            </div>

            {/* Social & Admin Access */}
            <div className="flex items-center space-x-4 pl-0 sm:pl-4 sm:border-l sm:border-white/10">
              <a 
                href="https://www.instagram.com/rogerwsmithwatches/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="text-[#c4a265] hover:text-white transition-colors"
                aria-label="Roger W. Smith Instagram"
              >
                <Instagram size={16} />
              </a>
              <Link 
                href="/admin" 
                className="flex items-center space-x-1 text-[#8fa397] hover:text-[#c4a265] transition-colors"
                title="Atelier CMS & Allocation Portal"
              >
                <Lock size={12} />
                <span className="text-[9px] tracking-[0.2em]">PORTAL</span>
              </Link>
            </div>
          </div>
        </div>

        {/* Sub-footer note */}
        <div className="mt-10 pt-6 border-t border-white/5 flex flex-col sm:flex-row justify-between items-center text-[10px] tracking-[0.16em] text-[#708479]">
          <p>© {new Date().getFullYear()} Roger W. Smith Ltd. All rights reserved. Handcrafted in Ramsey, Isle of Man.</p>
          <p className="mt-2 sm:mt-0">Member of the Académie Horlogère des Créateurs Indépendants (AHCI)</p>
        </div>

      </div>
    </footer>
  );
}
