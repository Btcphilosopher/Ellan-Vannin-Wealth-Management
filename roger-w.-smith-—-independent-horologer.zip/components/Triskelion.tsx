import React from 'react';

interface TriskelionProps {
  className?: string;
  size?: number;
  color?: string;
}

/**
 * Isle of Man Triskelion (Three Legs of Man) Emblem
 * Symbol of ancient Manx independence and horological craftsmanship.
 */
export function Triskelion({ className = '', size = 28, color = '#c4a265' }: TriskelionProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={`inline-block ${className}`}
      aria-label="Isle of Man Triskelion"
    >
      {/* Central boss / hub */}
      <circle cx="50" cy="50" r="4.5" fill={color} />
      
      {/* Leg 1 - pointing upwards / clockwise */}
      <g stroke={color} strokeWidth="2.75" strokeLinecap="round" strokeLinejoin="round" fill="none">
        {/* Thigh extending from center */}
        <path d="M50 46 C 48 38, 45 30, 48 22 C 50 17, 56 16, 61 17 C 65 18, 68 22, 69 25" />
        {/* Armor plate detail & spur */}
        <path d="M48 22 L 40 24" strokeWidth="2" />
        <path d="M61 17 L 66 12" strokeWidth="2" />
        {/* Lower leg bending */}
        <path d="M61 17 C 67 25, 68 33, 62 40" strokeWidth="2.5" />
        {/* Pointed armored foot/toe */}
        <path d="M69 25 L 75 24 L 71 28 Z" fill={color} />
      </g>

      {/* Leg 2 - pointing bottom right / clockwise (rotated 120deg) */}
      <g
        stroke={color}
        strokeWidth="2.75"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        transform="rotate(120 50 50)"
      >
        <path d="M50 46 C 48 38, 45 30, 48 22 C 50 17, 56 16, 61 17 C 65 18, 68 22, 69 25" />
        <path d="M48 22 L 40 24" strokeWidth="2" />
        <path d="M61 17 L 66 12" strokeWidth="2" />
        <path d="M61 17 C 67 25, 68 33, 62 40" strokeWidth="2.5" />
        <path d="M69 25 L 75 24 L 71 28 Z" fill={color} />
      </g>

      {/* Leg 3 - pointing bottom left / clockwise (rotated 240deg) */}
      <g
        stroke={color}
        strokeWidth="2.75"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        transform="rotate(240 50 50)"
      >
        <path d="M50 46 C 48 38, 45 30, 48 22 C 50 17, 56 16, 61 17 C 65 18, 68 22, 69 25" />
        <path d="M48 22 L 40 24" strokeWidth="2" />
        <path d="M61 17 L 66 12" strokeWidth="2" />
        <path d="M61 17 C 67 25, 68 33, 62 40" strokeWidth="2.5" />
        <path d="M69 25 L 75 24 L 71 28 Z" fill={color} />
      </g>
    </svg>
  );
}
