'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Triskelion } from './Triskelion';
import { Menu, X } from 'lucide-react';

interface HeaderProps {
  onOpenEnquiry?: () => void;
}

export function Header({ onOpenEnquiry }: HeaderProps) {
  const pathname = usePathname();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks = [
    { label: 'HOME', href: '/' },
    { label: 'THE CRAFT', href: '/craft' },
    { label: 'COLLECTION', href: '/collection' },
    { label: 'BESPOKE', href: '/bespoke' },
    { label: 'ABOUT', href: '/about' },
    { label: 'CONTACT', href: '/contact' },
  ];

  return (
    <header className="sticky top-0 z-50 w-full bg-[#091b15]/95 backdrop-blur-md border-b border-[#c4a265]/15 transition-all">
      <div className="max-w-[1440px] mx-auto px-6 sm:px-10 lg:px-16 h-20 sm:h-24 flex items-center justify-between">
        
        {/* Brand Monogram Left */}
        <Link 
          href="/" 
          className="group flex items-center focus:outline-none"
          aria-label="Roger W. Smith Home"
        >
          <span className="font-serif text-3xl sm:text-4xl tracking-[0.18em] font-light text-[#dfc590] group-hover:text-white transition-colors duration-300">
            RWS
          </span>
        </Link>

        {/* Central Navigation Links (Desktop) */}
        <nav 
          className="hidden md:flex items-center space-x-7 lg:space-x-10 text-[11px] sm:text-[12px] tracking-[0.24em] font-medium text-[#c9d3cc]"
          aria-label="Primary Navigation"
        >
          {navLinks.map((link) => {
            const isActive = pathname === link.href || (link.href !== '/' && pathname.startsWith(link.href));
            return (
              <Link
                key={link.label}
                href={link.href}
                className="relative py-2 transition-colors duration-300 hover:text-white group"
              >
                <span className={isActive ? 'text-white' : 'text-[#b0bfb5]'}>
                  {link.label}
                </span>
                {/* Active Underline matching visual reference */}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-[1px] bg-[#c4a265]" />
                )}
                {!isActive && (
                  <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-[#c4a265] transition-all duration-300 group-hover:w-full" />
                )}
              </Link>
            );
          })}
        </nav>

        {/* Isle of Man Triskelion & Location Mark (Right) */}
        <div className="flex items-center space-x-5">
          <Link
            href="/about"
            className="flex flex-col items-center group text-center focus:outline-none"
            title="Handcrafted on the Isle of Man"
          >
            <Triskelion 
              size={24} 
              className="text-[#c4a265] group-hover:scale-105 transition-transform duration-300" 
            />
            <span className="text-[9px] tracking-[0.26em] text-[#c4a265] group-hover:text-[#dfc590] font-medium mt-1 uppercase transition-colors">
              ISLE OF MAN
            </span>
          </Link>

          {/* Mobile menu hamburger button */}
          <button
            type="button"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 text-[#dfc590] hover:text-white focus:outline-none"
            aria-label="Toggle Navigation Menu"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#071712] border-b border-[#c4a265]/20 px-6 py-6 space-y-4">
          <nav className="flex flex-col space-y-3">
            {navLinks.map((link) => {
              const isActive = pathname === link.href || (link.href !== '/' && pathname.startsWith(link.href));
              return (
                <Link
                  key={link.label}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`text-sm tracking-[0.22em] py-2 border-b border-white/5 transition-colors ${
                    isActive ? 'text-[#c4a265] font-medium' : 'text-[#b0bfb5] hover:text-white'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
            <Link
              href="/admin"
              onClick={() => setMobileMenuOpen(false)}
              className="text-[11px] tracking-[0.2em] text-[#c4a265]/80 hover:text-[#c4a265] pt-2"
            >
              ATELIER CMS & CLIENT LEDGER →
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
