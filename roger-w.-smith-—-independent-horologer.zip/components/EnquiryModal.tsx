'use client';

import React, { useState } from 'react';
import { X, CheckCircle2, ShieldCheck, Clock, AlertCircle } from 'lucide-react';
import { Triskelion } from './Triskelion';

interface EnquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  defaultWatchSlug?: string;
  defaultWatchName?: string;
}

export function EnquiryModal({
  isOpen,
  onClose,
  defaultWatchSlug,
  defaultWatchName,
}: EnquiryModalProps) {
  const [clientName, setClientName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [country, setCountry] = useState('United Kingdom');
  const [selectedWatch, setSelectedWatch] = useState(defaultWatchName || 'General Atelier Enquiry');
  const [preferredContact, setPreferredContact] = useState<'email' | 'phone' | 'atelier_visit'>('email');
  const [message, setMessage] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submittedData, setSubmittedData] = useState<{
    reference: string;
    clientName: string;
    email: string;
  } | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setSubmitting(true);

    try {
      const res = await fetch('/api/enquiries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientName,
          email,
          phone,
          country,
          watchSlug: defaultWatchSlug || undefined,
          watchName: selectedWatch,
          type: defaultWatchSlug ? 'watch_allocation' : 'general',
          preferredContact,
          message,
        }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to register your allocation request.');
      }

      setSubmittedData({
        reference: data.enquiry.reference,
        clientName: data.enquiry.clientName,
        email: data.enquiry.email,
      });
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'An unexpected error occurred.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleReset = () => {
    setSubmittedData(null);
    setClientName('');
    setEmail('');
    setPhone('');
    setMessage('');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto bg-black/85 backdrop-blur-md animate-in fade-in duration-200">
      <div 
        className="relative w-full max-w-2xl bg-[#091b15] border border-[#c4a265]/35 p-6 sm:p-10 shadow-2xl my-8 text-[#f4f1ea]"
        role="dialog"
        aria-modal="true"
        aria-labelledby="enquiry-modal-title"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-[#8fa397] hover:text-[#c4a265] transition-colors p-1"
          aria-label="Close dialogue"
        >
          <X size={22} />
        </button>

        {submittedData ? (
          /* Confirmation State */
          <div className="text-center py-6 sm:py-8 space-y-6">
            <div className="flex justify-center">
              <div className="w-16 h-16 rounded-full bg-[#0d261e] border border-[#c4a265] flex items-center justify-center text-[#c4a265]">
                <CheckCircle2 size={36} />
              </div>
            </div>

            <div className="space-y-2">
              <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                TRANSMISSION CONFIRMED
              </span>
              <h2 id="enquiry-modal-title" className="font-serif text-2xl sm:text-3xl text-[#f4f1ea]">
                Enquiry Successfully Logged
              </h2>
            </div>

            <div className="bg-[#061510] border border-[#c4a265]/25 p-5 max-w-md mx-auto text-left space-y-3">
              <div className="flex justify-between items-center border-b border-white/10 pb-2">
                <span className="text-xs text-[#8fa397] uppercase tracking-wider">Reference Code</span>
                <span className="font-mono text-sm text-[#dfc590] font-semibold tracking-wider">
                  {submittedData.reference}
                </span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-[#8fa397]">Client</span>
                <span className="text-white font-medium">{submittedData.clientName}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-[#8fa397]">Acknowledgement To</span>
                <span className="text-white/90">{submittedData.email}</span>
              </div>
              <div className="flex justify-between items-center text-xs pt-1">
                <span className="text-[#8fa397]">Allocation Ledger</span>
                <span className="text-[#c4a265]">Recorded in Ramsey Atelier Registry</span>
              </div>
            </div>

            <p className="text-xs text-[#8fa397] max-w-md mx-auto leading-relaxed">
              Every Roger W. Smith timepiece is crafted individually by hand. A member of the Isle of Man atelier team will review your dossier and contact you directly.
            </p>

            <div className="pt-2">
              <button
                type="button"
                onClick={handleReset}
                className="px-8 py-3 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#dfc590] transition-colors"
              >
                CLOSE CONFIRMATION
              </button>
            </div>
          </div>
        ) : (
          /* Form State */
          <div>
            <div className="text-center space-y-2 mb-8">
              <div className="flex justify-center mb-2">
                <Triskelion size={24} color="#c4a265" />
              </div>
              <span className="text-[10px] tracking-[0.28em] text-[#c4a265] uppercase font-medium">
                CONFIDENTIAL ENQUIRY & ALLOCATION
              </span>
              <h2 id="enquiry-modal-title" className="font-serif text-2xl sm:text-3xl text-[#f4f1ea] font-normal">
                {defaultWatchName ? `Enquire on ${defaultWatchName}` : 'Private Atelier Dialogue'}
              </h2>
              <p className="text-xs text-[#8fa397] max-w-lg mx-auto">
                Timepieces from Roger W. Smith are strictly built to individual commission. We do not engage in online transactions; all acquisitions proceed through private consultation.
              </p>
            </div>

            {error && (
              <div className="mb-6 p-3 bg-red-950/40 border border-red-500/40 text-red-200 text-xs flex items-center space-x-2">
                <AlertCircle size={16} className="shrink-0 text-red-400" />
                <span>{error}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                    FULL NAME *
                  </label>
                  <input
                    type="text"
                    required
                    value={clientName}
                    onChange={(e) => setClientName(e.target.value)}
                    placeholder="e.g. Lord Alistair Sterling"
                    className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] placeholder-[#4f6459] outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                    EMAIL ADDRESS *
                  </label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="client@domain.com"
                    className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] placeholder-[#4f6459] outline-none transition-colors"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                    TELEPHONE (OPTIONAL)
                  </label>
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="+44 20 7000 0000"
                    className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] placeholder-[#4f6459] outline-none transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                    COUNTRY / REGION *
                  </label>
                  <select
                    value={country}
                    onChange={(e) => setCountry(e.target.value)}
                    className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none transition-colors"
                  >
                    <option value="United Kingdom">United Kingdom</option>
                    <option value="Isle of Man">Isle of Man</option>
                    <option value="United States">United States</option>
                    <option value="Switzerland">Switzerland</option>
                    <option value="Japan">Japan</option>
                    <option value="Germany">Germany</option>
                    <option value="Singapore">Singapore</option>
                    <option value="United Arab Emirates">United Arab Emirates</option>
                    <option value="Other">Other International</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                    TIMEPIECE OF INTEREST
                  </label>
                  <select
                    value={selectedWatch}
                    onChange={(e) => setSelectedWatch(e.target.value)}
                    className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none transition-colors"
                  >
                    <option value="The Heron">The Heron (Series 1 Special Edition)</option>
                    <option value="The Manx">The Manx (Series 2 Classic)</option>
                    <option value="The Tynwald">The Tynwald (Series 5 Sovereign)</option>
                    <option value="Series 4 Triple Calendar">Series 4 Triple Calendar</option>
                    <option value="Bespoke Commission">Bespoke Commission / Unique Piece</option>
                    <option value="General Atelier Enquiry">General Atelier Enquiry</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                    PREFERRED CONTACT METHOD
                  </label>
                  <select
                    value={preferredContact}
                    onChange={(e) => setPreferredContact(e.target.value as any)}
                    className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] outline-none transition-colors"
                  >
                    <option value="email">Discreet Email Correspondence</option>
                    <option value="phone">Telephone Consultation</option>
                    <option value="atelier_visit">Private Atelier Visit (Ramsey, Isle of Man)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-[10px] uppercase tracking-[0.2em] text-[#c4a265] mb-1 font-medium">
                  MESSAGE / HOROLOGICAL DETAILS
                </label>
                <textarea
                  rows={3}
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Please specify any case metal preferences, dial customization interest, or particular horological aspects you wish to discuss..."
                  className="w-full bg-[#061510] border border-[#c4a265]/30 focus:border-[#c4a265] px-3.5 py-2.5 text-sm text-[#f4f1ea] placeholder-[#4f6459] outline-none transition-colors resize-none"
                />
              </div>

              <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="flex items-center space-x-2 text-[11px] text-[#8fa397]">
                  <ShieldCheck size={16} className="text-[#c4a265]" />
                  <span>Confidential. Stored in Isle of Man Registry.</span>
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full sm:w-auto px-8 py-3 bg-[#c4a265] text-[#091b15] text-xs font-semibold tracking-[0.2em] uppercase hover:bg-[#dfc590] disabled:opacity-50 transition-colors shadow-lg"
                >
                  {submitting ? 'RECORDING DOSSIER...' : 'SUBMIT ENQUIRY →'}
                </button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
