import { WATCHES } from '../lib/data/watches';
import { ARTICLES } from '../lib/data/articles';
import { enquiryStore } from '../lib/data/enquiries';
import fs from 'fs';
import path from 'path';

async function runSystemVerification() {
  console.log('--- ROGER W. SMITH HOROLOGICAL SYSTEM VERIFICATION ---');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, testName: string) {
    if (condition) {
      console.log(`[PASS] ${testName}`);
      passed++;
    } else {
      console.error(`[FAIL] ${testName}`);
      failed++;
    }
  }

  // 1. Asset verification
  console.log('\n1. Visual Asset Verification:');
  const requiredImages = [
    'public/images/rws_hero_watch_green.jpg',
    'public/images/rws_watch_the_heron.jpg',
    'public/images/rws_watch_the_manx.jpg',
    'public/images/rws_watch_the_tynwald.jpg',
    'public/images/rws_isle_of_man_cliffs.jpg',
    'public/images/rws_watchmaker_workshop.jpg'
  ];

  for (const img of requiredImages) {
    const exists = fs.existsSync(path.resolve(process.cwd(), img));
    assert(exists, `Image asset exists: ${img}`);
  }

  // 2. Watch Catalog Verification
  console.log('\n2. Watch Catalogue & Verified Specifications:');
  assert(WATCHES.length >= 4, `Catalogue contains at least 4 timepieces (Found: ${WATCHES.length})`);
  
  for (const watch of WATCHES) {
    assert(watch.slug.length > 0, `Watch ${watch.name} has valid slug: ${watch.slug}`);
    assert(watch.specifications.length > 0, `Watch ${watch.name} has verified specifications (${watch.specifications.length})`);
    assert(watch.escapement.includes('co-axial') || watch.escapement.includes('Co-Axial'), `Watch ${watch.name} includes Co-Axial escapement`);
  }

  // 3. Journal Verification
  console.log('\n3. Journal & Workshop Chronicles:');
  assert(ARTICLES.length >= 3, `Journal contains at least 3 articles (Found: ${ARTICLES.length})`);
  for (const art of ARTICLES) {
    assert(art.title.length > 5, `Article title verified: ${art.title}`);
    assert(art.body.length > 100, `Article body has detailed text (${art.body.length} chars)`);
  }

  // 4. Enquiry Store Verification
  console.log('\n4. Enquiry & Client Allocation Registry:');
  const initialCount = enquiryStore.getAll().length;
  assert(initialCount >= 3, `Initial registry contains seeded dossiers (Found: ${initialCount})`);

  // Test creating new enquiry
  const newEnquiry = enquiryStore.create({
    clientName: 'Viscount Montgomery of Alamein',
    email: 'montgomery@alamein-estate.co.uk',
    phone: '+44 1420 541234',
    country: 'United Kingdom',
    watchSlug: 'the-heron',
    watchName: 'The Heron (Series 1)',
    type: 'watch_allocation',
    preferredContact: 'atelier_visit',
    message: 'Seeking allocation for an 18ct yellow gold Series 1.',
  });

  assert(newEnquiry.reference.startsWith('RWS-2026-'), `Generated valid reference code: ${newEnquiry.reference}`);
  assert(newEnquiry.status === 'Pending Review', 'Default status is Pending Review');

  // Test updating status
  const updated = enquiryStore.updateStatus(newEnquiry.id, 'In Discussion', 'Invited to Ramsey workshop.');
  assert(updated !== null && updated.status === 'In Discussion', 'Successfully updated enquiry status to In Discussion');
  assert(updated?.adminNotes === 'Invited to Ramsey workshop.', 'Successfully saved confidential atelier notes');

  console.log(`\nVerification Complete: ${passed} passed, ${failed} failed.\n`);
  if (failed > 0) {
    process.exit(1);
  }
}

runSystemVerification().catch((err) => {
  console.error(err);
  process.exit(1);
});
