export interface WatchSpecification {
  category: 'Case' | 'Dial & Hands' | 'Movement' | 'Escapement' | 'Strap' | 'Production';
  label: string;
  value: string;
  verified: boolean;
}

export interface Watch {
  id: string;
  slug: string;
  name: string;
  series: string;
  tagline: string;
  description: string;
  longDescription: string;
  caseMaterial: string;
  caseDiameter: string;
  dialType: string;
  movementCalibre: string;
  powerReserve: string;
  vibrationsPerHour: string;
  jewels: number;
  escapement: string;
  productionVolume: string;
  heroImage: string;
  galleryImages: string[];
  featured: boolean;
  published: boolean;
  sortOrder: number;
  specifications: WatchSpecification[];
}

export const WATCHES: Watch[] = [
  {
    id: 'w-heron',
    slug: 'the-heron',
    name: 'The Heron',
    series: 'Series 1 Special Edition',
    tagline: 'Time-only elegance with hand-engine-turned British racing green guilloché.',
    description: 'A bespoke time-only chronometer featuring a hand-turned British racing green guilloché dial, 18ct yellow gold case and Roger W Smith’s single-wheel co-axial escapement.',
    longDescription: 'Conceived to celebrate the rugged natural hues of the Isle of Man coastline, The Heron represents purity of horological expression. Powered by Roger W Smith’s proprietary hand-finished movement, its dial is engine-turned on an antique 19th-century straight-line and rose engine in the Ramsey atelier. Each component—from the sculptured gold hands to the escape wheel—is crafted entirely by hand following the Daniels Method.',
    caseMaterial: '18ct Yellow Gold (also available in Red Gold, White Gold or Platinum)',
    caseDiameter: '38.0 mm (Thickness: 10.5 mm)',
    dialType: 'Sterling silver base with deep hand-lacquered British racing green finish, hand-turned guilloché basketweave and sunburst sector patterns, solid 18ct gold Breguet numerals.',
    movementCalibre: 'RWS Calibre 1 — Handcrafted in-house movement',
    powerReserve: '38 hours',
    vibrationsPerHour: '18,000 vph (2.5 Hz)',
    jewels: 28,
    escapement: 'Latest generation Roger W Smith single-wheel co-axial escapement with free-sprung Quadra-cushion balance.',
    productionVolume: 'Strictly limited to bespoke allocation (approx. 10–12 pieces per annum workshop output)',
    heroImage: '/images/rws_watch_the_heron.jpg',
    galleryImages: [
      '/images/rws_watch_the_heron.jpg',
      '/images/rws_hero_watch_green.jpg',
      '/images/rws_watchmaker_workshop.jpg'
    ],
    featured: true,
    published: true,
    sortOrder: 1,
    specifications: [
      { category: 'Case', label: 'Material', value: '18ct Yellow Gold', verified: true },
      { category: 'Case', label: 'Diameter', value: '38.0 mm', verified: true },
      { category: 'Case', label: 'Thickness', value: '10.5 mm', verified: true },
      { category: 'Case', label: 'Crystal', value: 'Anti-reflective sapphire crystal front and exhibition caseback', verified: true },
      { category: 'Dial & Hands', label: 'Dial Base', value: 'Solid sterling silver hand-engine turned', verified: true },
      { category: 'Dial & Hands', label: 'Dial Finish', value: 'British Racing Green hand-lacquer with wave guilloché', verified: true },
      { category: 'Dial & Hands', label: 'Numerals', value: 'Applied 18ct Yellow Gold Breguet numerals', verified: true },
      { category: 'Dial & Hands', label: 'Hands', value: 'Handmade 18ct gold spade hands with signature eccentric rings', verified: true },
      { category: 'Movement', label: 'Calibre', value: 'RWS Calibre 1 Manual Wind', verified: true },
      { category: 'Movement', label: 'Dimensions', value: '31.2 mm diameter, 5.8 mm height', verified: true },
      { category: 'Movement', label: 'Finishing', value: 'Traditional English frosted gilt plates with polished chamfers', verified: true },
      { category: 'Movement', label: 'Power Reserve', value: '38 Hours', verified: true },
      { category: 'Escapement', label: 'Type', value: 'Single-wheel Co-Axial escapement', verified: true },
      { category: 'Escapement', label: 'Balance', value: 'Free-sprung Quadra-cushion variable inertia balance', verified: true },
      { category: 'Escapement', label: 'Frequency', value: '18,000 vph (2.5 Hz)', verified: true },
      { category: 'Strap', label: 'Material', value: 'Hand-stitched dark green Louisiana alligator leather', verified: true },
      { category: 'Strap', label: 'Buckle', value: 'Handmade 18ct yellow gold pin buckle with Isle of Man hallmark', verified: true },
      { category: 'Production', label: 'Method', value: 'The Daniels Method (32 of 34 crafts under one roof)', verified: true }
    ]
  },
  {
    id: 'w-manx',
    slug: 'the-manx',
    name: 'The Manx',
    series: 'Series 2 Classic',
    tagline: 'The quintessential British dress chronometer in hand-guilloché silver.',
    description: 'Roger W Smith’s signature Series 2 chronometer, featuring a multi-layered sterling silver engine-turned dial, eccentric blued steel spade hands and off-centre small seconds.',
    longDescription: 'The Series 2 is Roger W Smith’s most famous archetype. Handcrafted in the Isle of Man, the dial comprises separate sterling silver chapters, hand-turned using antique rose engines to produce exquisite barleycorn and wave patterns. The blued steel hands are sculptured entirely by eye using hand files and heat-treated to an iridescent royal purple-blue.',
    caseMaterial: '18ct Yellow Gold or 18ct Red Gold',
    caseDiameter: '40.0 mm (Thickness: 11.2 mm)',
    dialType: 'Hand-engine turned solid sterling silver with multi-part construction, hand-engraved Roman numerals filled with black ink, concentric subsidiary seconds.',
    movementCalibre: 'RWS Calibre 2 — Manual wind chronometer movement',
    powerReserve: '38 hours',
    vibrationsPerHour: '18,000 vph (2.5 Hz)',
    jewels: 28,
    escapement: 'Proprietary single-wheel co-axial escapement directly inspired by George Daniels.',
    productionVolume: 'Individual commission only',
    heroImage: '/images/rws_watch_the_manx.jpg',
    galleryImages: [
      '/images/rws_watch_the_manx.jpg',
      '/images/rws_watchmaker_workshop.jpg',
      '/images/rws_isle_of_man_cliffs.jpg'
    ],
    featured: true,
    published: true,
    sortOrder: 2,
    specifications: [
      { category: 'Case', label: 'Material', value: '18ct Yellow Gold', verified: true },
      { category: 'Case', label: 'Diameter', value: '40.0 mm', verified: true },
      { category: 'Case', label: 'Thickness', value: '11.2 mm', verified: true },
      { category: 'Case', label: 'Water Resistance', value: '30 metres (3 ATM)', verified: true },
      { category: 'Dial & Hands', label: 'Dial Base', value: 'Hand-turned solid sterling silver', verified: true },
      { category: 'Dial & Hands', label: 'Patterns', value: 'Barleycorn central motif with clous de Paris subsidiary seconds', verified: true },
      { category: 'Dial & Hands', label: 'Hands', value: 'Flame-blued sculptured carbon steel', verified: true },
      { category: 'Movement', label: 'Calibre', value: 'RWS Calibre 2 Manual Wind', verified: true },
      { category: 'Movement', label: 'Finish', value: 'English frosted gold plating with mirror-polished steel work', verified: true },
      { category: 'Escapement', label: 'Type', value: 'Single-wheel Co-Axial escapement', verified: true },
      { category: 'Strap', label: 'Material', value: 'Matte black hand-stitched alligator', verified: true },
      { category: 'Strap', label: 'Buckle', value: 'Solid 18ct gold hand-finished buckle', verified: true }
    ]
  },
  {
    id: 'w-tynwald',
    slug: 'the-tynwald',
    name: 'The Tynwald',
    series: 'Series 5 Sovereign',
    tagline: 'Deep imperial blue dial honoring the historic parliament of the Isle of Man.',
    description: 'Named in honour of the world’s oldest continuous parliament on the Isle of Man, The Tynwald showcases a radiant midnight blue sunburst dial with gold hour indices.',
    longDescription: 'Created as an homage to the ancient parliamentary heritage of Tynwald Hill in St John’s, Isle of Man. The watch combines classical restraint with contemporary mechanical refinement, offering an intensely legible layout with gold faceted hour markers, hand-polished spade hands and the legendary co-axial escapement.',
    caseMaterial: '18ct Yellow Gold or Platinum 950',
    caseDiameter: '39.0 mm (Thickness: 10.8 mm)',
    dialType: 'Deep midnight blue circular sunburst lacquer, solid 18ct gold applied batons and Roman numerals.',
    movementCalibre: 'RWS Calibre 5 — Manual winding chronometer',
    powerReserve: '40 hours',
    vibrationsPerHour: '18,000 vph (2.5 Hz)',
    jewels: 29,
    escapement: 'Single-wheel co-axial escapement with optimised impulse angles.',
    productionVolume: 'Strictly limited bespoke commissions',
    heroImage: '/images/rws_watch_the_tynwald.jpg',
    galleryImages: [
      '/images/rws_watch_the_tynwald.jpg',
      '/images/rws_watchmaker_workshop.jpg'
    ],
    featured: true,
    published: true,
    sortOrder: 3,
    specifications: [
      { category: 'Case', label: 'Material', value: '18ct Yellow Gold', verified: true },
      { category: 'Case', label: 'Diameter', value: '39.0 mm', verified: true },
      { category: 'Case', label: 'Thickness', value: '10.8 mm', verified: true },
      { category: 'Dial & Hands', label: 'Dial Finish', value: 'Imperial Midnight Blue sunburst galvanic lacquer', verified: true },
      { category: 'Dial & Hands', label: 'Hands', value: 'Handmade 18ct yellow gold', verified: true },
      { category: 'Movement', label: 'Calibre', value: 'RWS Calibre 5 Manual Wind', verified: true },
      { category: 'Escapement', label: 'Escapement', value: 'Single-wheel Co-Axial escapement', verified: true },
      { category: 'Strap', label: 'Material', value: 'Midnight blue Louisiana alligator with tonal stitching', verified: true }
    ]
  },
  {
    id: 'w-series4',
    slug: 'series-4-triple-calendar',
    name: 'Series 4 Triple Calendar',
    series: 'Series 4 Complication',
    tagline: 'Instantaneous triple calendar with moonphase and travelling date aperture.',
    description: 'A grand complication chronometer uniting day, date, month and precision astronomical moonphase with Roger W Smith’s co-axial heart.',
    longDescription: 'The Series 4 represents Roger W Smith’s crowning achievement in calendar complications. Designed to resolve the visual congestion common to astronomical timepieces, the dial features a proprietary curved calendar display and hand-painted moonphase disc made in gold and fired enamel.',
    caseMaterial: '18ct Red Gold or Platinum 950',
    caseDiameter: '41.0 mm (Thickness: 12.8 mm)',
    dialType: 'Multi-tiered sterling silver hand-turned guilloché with blued steel calendar hands.',
    movementCalibre: 'RWS Calibre 4 — In-house calendar complication',
    powerReserve: '38 hours',
    vibrationsPerHour: '18,000 vph (2.5 Hz)',
    jewels: 36,
    escapement: 'Single-wheel co-axial escapement with free-sprung balance.',
    productionVolume: 'Extremely limited production (1–2 pieces per year)',
    heroImage: '/images/rws_watch_the_manx.jpg',
    galleryImages: [
      '/images/rws_watch_the_manx.jpg',
      '/images/rws_watchmaker_workshop.jpg'
    ],
    featured: false,
    published: true,
    sortOrder: 4,
    specifications: [
      { category: 'Case', label: 'Material', value: '18ct Red Gold', verified: true },
      { category: 'Case', label: 'Diameter', value: '41.0 mm', verified: true },
      { category: 'Movement', label: 'Calibre', value: 'RWS Calibre 4', verified: true },
      { category: 'Movement', label: 'Complications', value: 'Triple Calendar with Moonphase and Instantaneous Date', verified: true }
    ]
  }
];
