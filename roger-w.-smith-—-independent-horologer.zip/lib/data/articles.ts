export interface Article {
  id: string;
  slug: string;
  title: string;
  summary: string;
  body: string;
  author: string;
  publishDate: string;
  readingTime: string;
  category: 'Craftsmanship' | 'Horology' | 'Heritage' | 'Workshop Log';
  heroImage: string;
  published: boolean;
}

export const ARTICLES: Article[] = [
  {
    id: 'art-daniels-method',
    slug: 'the-daniels-method-and-its-legacy',
    title: 'The Daniels Method: Mastery of Thirty-Two Watchmaking Crafts',
    summary: 'How Dr. George Daniels CBE established the uncompromising standard of creating every component of a watch by hand, and how that legacy thrives in the Isle of Man today.',
    body: `In the modern Swiss and global watch industry, mass manufacturing relies on hundreds of specialized suppliers: dial makers in La Chaux-de-Fonds, hand manufacturers in Le Locle, jewel makers and case manufacturers dispersed across valleys. 

Dr. George Daniels CBE fundamentally rejected this fragmented industrialization. He believed that a true watchmaker must conceive, design and fabricate every component of a timepiece individually—from raw metals to the finished escapement. To Daniels, this represented thirty-four distinct crafts.

Roger W Smith began his journey under Daniels’ watchful mentorship in 1990. After seven years of solitary endeavour in a spare bedroom to build his second pocket watch by hand—which Daniels finally approved with the words "You are now a watchmaker"—Roger moved to the Isle of Man to work beside him on the famous Millennium series.

Today, in the Roger W Smith atelier outside Ramsey, thirty-two of the thirty-four crafts are performed under one roof. Only the balance spring and the sapphire crystal glasses are sourced externally. The cases are shaped, soldered, and finished by hand; the dials are engine-turned on century-old straight-line and rose engines; and the bridges are frosted using traditional English acid dipping and gilded with 18ct yellow gold.`,
    author: 'Roger W. Smith OBE',
    publishDate: '12 September 2026',
    readingTime: '6 min read',
    category: 'Heritage',
    heroImage: '/images/rws_watchmaker_workshop.jpg',
    published: true
  },
  {
    id: 'art-co-axial-escapement',
    slug: 'the-evolution-of-the-single-wheel-co-axial-escapement',
    title: 'The Single-Wheel Co-Axial Escapement: A British Horological Triumph',
    summary: 'An exploration of the geometry, reduced friction and radial impulse mechanics that distinguish Roger W Smith’s refined single-wheel co-axial escapement.',
    body: `Invented by Dr. George Daniels in 1974, the co-axial escapement is recognized as the first fundamentally new, practical mechanical escapement to succeed the Swiss lever since 1754.

Unlike the Swiss lever, which relies on a sliding friction action that rapidly degrades oil and alters timekeeping rates, the co-axial escapement utilizes radial impulses. The ruby impulse pallets deliver energy tangentially with negligible sliding friction, drastically reducing reliance on lubrication and ensuring consistent amplitude over decades.

Roger W Smith took this monumental invention further. In 2010, after years of intensive prototyping, Roger unveiled his proprietary single-wheel co-axial escapement. By integrating the two separate escape wheels of the original Daniels design into a single, intricately milled wheel with raised teeth, inertia was reduced by over 30%, resulting in faster lockup, enhanced shock resistance, and greater long-term isochronism.`,
    author: 'Horological Engineering Notes',
    publishDate: '18 July 2026',
    readingTime: '8 min read',
    category: 'Horology',
    heroImage: '/images/rws_watchmaker_workshop.jpg',
    published: true
  },
  {
    id: 'art-isle-of-man-atelier',
    slug: 'why-we-make-watches-on-the-isle-of-man',
    title: 'Solitude and Sea Spray: Why We Build Watches on the Isle of Man',
    summary: 'Far from the bustling trade halls of Geneva, the isolation of the Isle of Man fosters the quiet concentration essential for true mechanical horology.',
    body: `Perched in the Irish Sea between Great Britain and Ireland, the Isle of Man has long nurtured an independent, self-reliant spirit. With its own parliament, Tynwald, established over a millennium ago, the island is steeped in history and undisturbed nature.

It was here that Dr. George Daniels chose to establish his solitary workshop in Riversdale, and it is here that Roger W Smith established his own atelier. 

The physical separation from horological fashion allows the workshop to operate on geological time. There are no quarterly marketing quotas; there are no corporate boardrooms demanding cost reductions. Each watch requires between 1,500 and 2,500 hours of manual labour. In the silence of the workshop, with the sea winds sweeping across the northern hills, every component receives the contemplative attention it requires.`,
    author: 'Roger W. Smith OBE',
    publishDate: '4 May 2026',
    readingTime: '5 min read',
    category: 'Workshop Log',
    heroImage: '/images/rws_isle_of_man_cliffs.jpg',
    published: true
  }
];
