export interface Enquiry {
  id: string;
  reference: string;
  type: 'watch_allocation' | 'bespoke_commission' | 'atelier_visit' | 'general';
  watchSlug?: string;
  watchName?: string;
  clientName: string;
  email: string;
  phone?: string;
  country: string;
  message: string;
  preferredContact: 'email' | 'phone' | 'atelier_visit';
  status: 'Pending Review' | 'In Discussion' | 'Allocated' | 'Waitlist' | 'Completed' | 'Declined';
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
}

// Initial seed enquiries for demonstration of the CMS administrative ledger
const INITIAL_ENQUIRIES: Enquiry[] = [
  {
    id: 'enq-001',
    reference: 'RWS-2026-8491',
    type: 'watch_allocation',
    watchSlug: 'the-heron',
    watchName: 'The Heron (Series 1 Special Edition)',
    clientName: 'Lord Alistair Sterling',
    email: 'sterling.a@mayfair-advisors.co.uk',
    phone: '+44 20 7946 0912',
    country: 'United Kingdom',
    message: 'I have followed Roger’s work since the Millennium series with Dr. Daniels. I would be honoured to discuss allocation for The Heron in 18ct yellow gold with custom dial engraving.',
    preferredContact: 'atelier_visit',
    status: 'In Discussion',
    adminNotes: 'Client visited Goodwood Members’ Meeting previously. Invited to visit the Ramsey workshop in November for dial pattern selection.',
    createdAt: '2026-09-28T14:22:10Z',
    updatedAt: '2026-10-02T09:15:00Z'
  },
  {
    id: 'enq-002',
    reference: 'RWS-2026-9043',
    type: 'watch_allocation',
    watchSlug: 'the-manx',
    watchName: 'The Manx (Series 2 Classic)',
    clientName: 'Dr. Evelyn Vance',
    email: 'evance@oxford-research.ac.uk',
    phone: '+44 1865 270000',
    country: 'United Kingdom',
    message: 'Enquiring regarding the waitlist duration for a Series 2 in red gold. Interested in understanding the Daniels Method finishing process for the bridges.',
    preferredContact: 'email',
    status: 'Pending Review',
    adminNotes: 'Horological scholar. Reviewing current production allocation for Q3 2027.',
    createdAt: '2026-10-10T11:05:42Z',
    updatedAt: '2026-10-10T11:05:42Z'
  },
  {
    id: 'enq-003',
    reference: 'RWS-2026-9118',
    type: 'bespoke_commission',
    watchSlug: 'the-tynwald',
    watchName: 'The Tynwald (Series 5 Sovereign)',
    clientName: 'Kenji Takahashi',
    email: 'ktakahashi@ginza-horology.jp',
    phone: '+81 3 5555 0144',
    country: 'Japan',
    message: 'Seeking a bespoke platinum variant of The Tynwald with custom hand-carved Roman numerals. Would be delighted to arrange a private video consultation.',
    preferredContact: 'email',
    status: 'Allocated',
    adminNotes: 'Deposit confirmed and allocation slot locked for workshop schedule 2027.',
    createdAt: '2026-10-05T08:14:20Z',
    updatedAt: '2026-10-11T16:40:00Z'
  }
];

class EnquiryStore {
  private enquiries: Enquiry[] = [...INITIAL_ENQUIRIES];

  public getAll(): Enquiry[] {
    return [...this.enquiries].sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public getById(id: string): Enquiry | undefined {
    return this.enquiries.find((e) => e.id === id);
  }

  public create(data: Omit<Enquiry, 'id' | 'reference' | 'status' | 'createdAt' | 'updatedAt'>): Enquiry {
    const randomDigits = Math.floor(1000 + Math.random() * 9000);
    const newEnquiry: Enquiry = {
      ...data,
      id: `enq-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      reference: `RWS-2026-${randomDigits}`,
      status: 'Pending Review',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.enquiries.unshift(newEnquiry);
    return newEnquiry;
  }

  public updateStatus(id: string, status: Enquiry['status'], adminNotes?: string): Enquiry | null {
    const item = this.enquiries.find((e) => e.id === id);
    if (!item) return null;
    item.status = status;
    if (adminNotes !== undefined) {
      item.adminNotes = adminNotes;
    }
    item.updatedAt = new Date().toISOString();
    return item;
  }
}

// Global singleton instance
const globalForEnquiries = globalThis as unknown as { enquiryStore?: EnquiryStore };
export const enquiryStore = globalForEnquiries.enquiryStore ?? new EnquiryStore();
if (process.env.NODE_ENV !== 'production') globalForEnquiries.enquiryStore = enquiryStore;
