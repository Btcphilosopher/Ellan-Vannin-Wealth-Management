/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ProjectInputs, CashFlowYear, FinancialOutputs } from '../types';

/**
 * Calculates the internal rate of return (IRR) using the Bisection Method.
 * Highly robust, handles negative and positive cash flows, and prevents infinite loops.
 */
export function calculateIRR(cashFlows: number[], targetTolerance = 1e-6, maxIterations = 150): number {
  if (cashFlows.length === 0) return 0;
  
  // Check if there is at least one positive and one negative cash flow
  const positive = cashFlows.some(cf => cf > 0);
  const negative = cashFlows.some(cf => cf < 0);
  if (!positive || !negative) return 0; // IRR is undefined if all cash flows have the same sign

  let low = -0.999;
  let high = 5.0; // up to 500% return
  let irr = 0;
  
  const npvAt = (rate: number): number => {
    let sum = 0;
    for (let t = 0; t < cashFlows.length; t++) {
      sum += cashFlows[t] / Math.pow(1 + rate, t);
    }
    return sum;
  };

  let fLow = npvAt(low);
  let fHigh = npvAt(high);

  // If roots lie outside standard [-0.99, 5.0] range, expand bounds
  if (fLow * fHigh > 0) {
    while (high < 100.0 && fLow * fHigh > 0) {
      high *= 2;
      fHigh = npvAt(high);
    }
    if (fLow * fHigh > 0) return 0; // Could not isolate root
  }

  for (let i = 0; i < maxIterations; i++) {
    irr = (low + high) / 2;
    const fMid = npvAt(irr);

    if (Math.abs(fMid) < targetTolerance) {
      return irr;
    }

    if (fLow * fMid < 0) {
      high = irr;
      fHigh = fMid;
    } else {
      low = irr;
      fLow = fMid;
    }
  }

  return irr;
}

/**
 * Generates the full annual cash flow statement for a project.
 */
export function generateCashFlowSchedule(inputs: ProjectInputs): CashFlowYear[] {
  const years: CashFlowYear[] = [];
  const constYears = inputs.constructionPeriod + inputs.constructionDelay;
  const opYears = inputs.projectLife;
  const totalYears = constYears + opYears;

  // Adjust capital expenditure for cost overrun
  const adjustedCapex = inputs.constructionCost * (1 + inputs.costOverrun / 100);
  const adjustedLand = inputs.landAcquisition * (1 + inputs.costOverrun / 100);
  const adjustedPlanning = inputs.planningCosts;
  const adjustedFees = inputs.professionalFees;
  const adjustedMitigation = inputs.environmentalMitigation;
  
  const totalDevelopmentCost = adjustedCapex + adjustedLand + adjustedPlanning + adjustedFees + adjustedMitigation;
  
  // Debt parameters
  const totalDebtCapital = totalDevelopmentCost * (inputs.debtPercentage / 100);
  const totalEquityCapital = totalDevelopmentCost - totalDebtCapital;

  // Breakdown debt
  const seniorDebtRatio = inputs.financingMix.seniorDebt / (inputs.financingMix.seniorDebt + inputs.financingMix.juniorDebt + 1e-9);
  const totalSeniorDebt = totalDebtCapital * (inputs.financingMix.seniorDebt / 100);
  const totalJuniorDebt = totalDebtCapital * (inputs.financingMix.juniorDebt / 100);
  
  // Straight-line annual principal repayments
  const seniorRepaymentTerm = Math.min(25, opYears); // standard project finance terms
  const juniorRepaymentTerm = Math.min(20, opYears);
  
  const annualSeniorPrincipalBase = totalSeniorDebt / seniorRepaymentTerm;
  const annualJuniorPrincipalBase = totalJuniorDebt / juniorRepaymentTerm;

  let seniorDebtOutstanding = 0;
  let juniorDebtOutstanding = 0;
  let accumulatedUnleveredCF = 0;
  let accumulatedLeveredCF = 0;

  for (let y = 0; y <= totalYears; y++) {
    const isConst = y < constYears;
    const isOp = y >= constYears && y < totalYears;
    const isRes = y === totalYears;

    let capex = 0;
    let opex = 0;
    let rev = 0;
    let residual = 0;
    let debtDrawdown = 0;
    let equityContribution = 0;
    let maintCapex = 0;
    let envMitigation = 0;
    let landAcq = 0;
    let profFees = 0;

    let seniorInterest = 0;
    let seniorPrincipal = 0;
    let juniorInterest = 0;
    let juniorPrincipal = 0;
    let idc = 0; // Interest during construction

    const phase = isConst ? 'Construction' : isOp ? 'Operational' : 'Residual';

    // Index variables for inflation over time
    const cumInflation = Math.pow(1 + inputs.inflationRate / 100, y);

    if (isConst) {
      // Linear drawdown of CAPEX and other development costs
      capex = (adjustedCapex / constYears) * cumInflation;
      landAcq = (adjustedLand / constYears) * cumInflation;
      envMitigation = (adjustedMitigation / constYears) * cumInflation;
      profFees = (adjustedFees / constYears) * cumInflation;
      
      const totalDevYear = capex + landAcq + envMitigation + profFees;
      
      debtDrawdown = totalDevYear * (inputs.debtPercentage / 100);
      equityContribution = totalDevYear - debtDrawdown;

      // Track senior and junior debt drawdown
      const seniorDraw = totalDevYear * (inputs.financingMix.seniorDebt / 100);
      const juniorDraw = totalDevYear * (inputs.financingMix.juniorDebt / 100);

      // Accumulate debt outstanding
      seniorDebtOutstanding += seniorDraw;
      juniorDebtOutstanding += juniorDraw;

      // Calculate Interest during construction (capitalized)
      const currentYearSeniorInt = (seniorDebtOutstanding - seniorDraw / 2) * (inputs.interestRate / 100);
      const currentYearJuniorInt = (juniorDebtOutstanding - juniorDraw / 2) * (inputs.juniorDebtInterestRate / 100);
      
      idc = currentYearSeniorInt + currentYearJuniorInt;
      seniorDebtOutstanding += currentYearSeniorInt; // capitalized interest
      juniorDebtOutstanding += currentYearJuniorInt;
    } else if (isOp) {
      // Operational Phase
      const opYearIndex = y - constYears;
      
      // Revenue indexed to inflation + growth
      rev = inputs.annualRevenue * Math.pow(1 + inputs.annualRevenueGrowth / 100, opYearIndex) * cumInflation;
      
      // Operating costs indexed to inflation
      opex = inputs.operatingCost * cumInflation;
      maintCapex = inputs.maintenanceCapex * cumInflation;

      // Debt Servicing
      // Senior Debt
      if (y - constYears < seniorRepaymentTerm) {
        seniorInterest = seniorDebtOutstanding * (inputs.interestRate / 100);
        
        if (inputs.debtType === 'Straight-Line') {
          seniorPrincipal = Math.min(seniorDebtOutstanding, annualSeniorPrincipalBase);
        } else if (inputs.debtType === 'Bullet') {
          seniorPrincipal = (y - constYears === seniorRepaymentTerm - 1) ? seniorDebtOutstanding : 0;
        } else if (inputs.debtType === 'Annuity') {
          // Fixed Debt Service (P+I)
          const rate = inputs.interestRate / 100;
          const annuityPayment = (totalSeniorDebt * rate) / (1 - Math.pow(1 + rate, -seniorRepaymentTerm));
          seniorPrincipal = Math.min(seniorDebtOutstanding, Math.max(0, annuityPayment - seniorInterest));
        } else if (inputs.debtType === 'Sculpted') {
          // Principal sculpted to EBITDA: Debt Service = Free Cash Flow / Target DSCR
          const targetDscr = 1.35;
          const ebitda = rev - opex - maintCapex;
          const targetDebtService = Math.max(0, ebitda / targetDscr);
          seniorPrincipal = Math.min(seniorDebtOutstanding, Math.max(0, targetDebtService - seniorInterest));
        }
        seniorDebtOutstanding -= seniorPrincipal;
      }

      // Junior Debt
      if (y - constYears < juniorRepaymentTerm) {
        juniorInterest = juniorDebtOutstanding * (inputs.juniorDebtInterestRate / 100);
        
        if (inputs.debtType === 'Bullet') {
          juniorPrincipal = (y - constYears === juniorRepaymentTerm - 1) ? juniorDebtOutstanding : 0;
        } else {
          // Standard Straight-line for junior debt
          juniorPrincipal = Math.min(juniorDebtOutstanding, annualJuniorPrincipalBase);
        }
        juniorDebtOutstanding -= juniorPrincipal;
      }
    } else if (isRes) {
      // Project exit / Residual value realized at final year
      residual = inputs.residualValue * cumInflation;
      
      // Clean up any remaining debt at residual year
      seniorPrincipal = seniorDebtOutstanding;
      seniorDebtOutstanding = 0;
      
      juniorPrincipal = juniorDebtOutstanding;
      juniorDebtOutstanding = 0;
    }

    // TAX CALCULATIONS
    const depreciation = isOp ? (adjustedCapex / opYears) * cumInflation : 0;
    const ebitda = rev - opex - maintCapex;
    const taxableIncome = isOp ? Math.max(0, ebitda - depreciation - seniorInterest - juniorInterest) : 0;
    const taxPaid = taxableIncome * (inputs.taxRate / 100);

    // FREE CASH FLOWS
    // Unlevered cash flow = Cash Flow from operations before debt servicing (Capex is negative)
    const unleveredCashFlow = isConst 
      ? -(capex + landAcq + envMitigation + profFees)
      : isOp 
        ? (ebitda - maintCapex - taxPaid)
        : residual; // Residual is realized at the very end

    // Levered cash flow = Unlevered cash flow after debt inflows (drawdown) and debt outflows (P+I)
    const leveredCashFlow = isConst
      ? -(capex + landAcq + envMitigation + profFees) + debtDrawdown // net equity contribution (should equal -equityContribution)
      : isOp
        ? (unleveredCashFlow - (seniorPrincipal + seniorInterest + juniorPrincipal + juniorInterest))
        : (residual - (seniorPrincipal + juniorPrincipal)); // pay off any residual debt

    accumulatedUnleveredCF += unleveredCashFlow;
    accumulatedLeveredCF += leveredCashFlow;

    // Financial Coverage Ratios
    const totalDebtService = seniorPrincipal + seniorInterest + juniorPrincipal + juniorInterest;
    const dscr = totalDebtService > 0 ? (ebitda - maintCapex) / totalDebtService : 10.0;
    const iscr = (seniorInterest + juniorInterest) > 0 ? ebitda / (seniorInterest + juniorInterest) : 10.0;

    years.push({
      year: y,
      phase,
      revenue: parseFloat(rev.toFixed(4)),
      residualValue: parseFloat(residual.toFixed(4)),
      debtDrawdown: parseFloat(debtDrawdown.toFixed(4)),
      equityContribution: parseFloat(equityContribution.toFixed(4)),
      capex: parseFloat(capex.toFixed(4)),
      landAcquisition: parseFloat(landAcq.toFixed(4)),
      environmentalMitigation: parseFloat(envMitigation.toFixed(4)),
      professionalFees: parseFloat(profFees.toFixed(4)),
      opex: parseFloat(opex.toFixed(4)),
      maintenanceCapex: parseFloat(maintCapex.toFixed(4)),
      seniorInterest: parseFloat(seniorInterest.toFixed(4)),
      seniorPrincipal: parseFloat(seniorPrincipal.toFixed(4)),
      juniorInterest: parseFloat(juniorInterest.toFixed(4)),
      juniorPrincipal: parseFloat(juniorPrincipal.toFixed(4)),
      interestDuringConstruction: parseFloat(idc.toFixed(4)),
      taxableIncome: parseFloat(taxableIncome.toFixed(4)),
      taxPaid: parseFloat(taxPaid.toFixed(4)),
      unleveredCashFlow: parseFloat(unleveredCashFlow.toFixed(4)),
      leveredCashFlow: parseFloat(leveredCashFlow.toFixed(4)),
      cumulativeUnleveredCashFlow: parseFloat(accumulatedUnleveredCF.toFixed(4)),
      cumulativeLeveredCashFlow: parseFloat(accumulatedLeveredCF.toFixed(4)),
      dscr: parseFloat((dscr > 10 ? 10 : dscr < -5 ? -5 : dscr).toFixed(2)),
      iscr: parseFloat((iscr > 10 ? 10 : iscr < -5 ? -5 : iscr).toFixed(2))
    });
  }

  return years;
}

/**
 * Calculates project finance output metrics from a generated cash flow schedule.
 */
export function calculateFinancialOutputs(inputs: ProjectInputs, schedule: CashFlowYear[]): FinancialOutputs {
  const unleveredCFs = schedule.map(y => y.unleveredCashFlow);
  const leveredCFs = schedule.map(y => y.leveredCashFlow);

  // IRR Calculations
  // Add risk premium to discount rate if applicable
  const adjustedDiscountRate = (inputs.discountRate + inputs.riskPremium) / 100;
  
  const unleveredIrr = calculateIRR(unleveredCFs);
  const leveredIrr = calculateIRR(leveredCFs);

  // NPV Calculation
  let npv = 0;
  let unleveredNpv = 0;
  for (let t = 0; t < schedule.length; t++) {
    npv += leveredCFs[t] / Math.pow(1 + adjustedDiscountRate, t);
    unleveredNpv += unleveredCFs[t] / Math.pow(1 + adjustedDiscountRate, t);
  }

  // ROI / Equity Multiple
  const totalEquityInvested = schedule
    .filter(y => y.phase === 'Construction')
    .reduce((sum, y) => sum + y.equityContribution, 0);

  const totalLeveredInflows = schedule
    .filter(y => y.phase !== 'Construction' && y.leveredCashFlow > 0)
    .reduce((sum, y) => sum + y.leveredCashFlow, 0);

  const equityMultiple = totalEquityInvested > 0 ? totalLeveredInflows / totalEquityInvested : 0;
  const roi = totalEquityInvested > 0 ? (totalLeveredInflows - totalEquityInvested) / totalEquityInvested * 100 : 0;

  // Payback Period (Levered Cash Flow)
  let paybackPeriod = -1;
  let runningEquityUncovered = totalEquityInvested;
  const constYears = inputs.constructionPeriod + inputs.constructionDelay;

  for (let t = constYears; t < schedule.length; t++) {
    const cf = schedule[t].leveredCashFlow;
    if (cf > 0) {
      if (runningEquityUncovered <= cf) {
        paybackPeriod = (t - constYears) + (runningEquityUncovered / cf);
        break;
      } else {
        runningEquityUncovered -= cf;
      }
    }
  }

  // If running equity is still uncovered after full project life
  if (paybackPeriod === -1) {
    paybackPeriod = inputs.projectLife; // Cap at project life
  }

  // Coverage ratios metrics
  const opYears = schedule.filter(y => y.phase === 'Operational');
  const dscrs = opYears.map(y => y.dscr).filter(d => d !== 10.0 && !isNaN(d));
  const iscrs = opYears.map(y => y.iscr).filter(i => i !== 10.0 && !isNaN(i));

  const averageDscr = dscrs.length > 0 ? dscrs.reduce((a, b) => a + b, 0) / dscrs.length : 1.5;
  const minimumDscr = dscrs.length > 0 ? Math.min(...dscrs) : 1.1;
  const averageIscr = iscrs.length > 0 ? iscrs.reduce((a, b) => a + b, 0) / iscrs.length : 2.5;

  const totalRevenue = opYears.reduce((sum, y) => sum + y.revenue, 0);
  const totalTaxPaid = opYears.reduce((sum, y) => sum + y.taxPaid, 0);

  // Asset Value & Enterprise Value
  // Asset Value = Net Present Value of Future Unlevered Cash Flows during operational phase discounted at WACC
  let assetValue = 0;
  const opAndResYears = schedule.filter(y => y.phase === 'Operational' || y.phase === 'Residual');
  for (let t = 0; t < opAndResYears.length; t++) {
    assetValue += opAndResYears[t].unleveredCashFlow / Math.pow(1 + adjustedDiscountRate, t + 1);
  }

  const enterpriseValue = assetValue + inputs.residualValue;

  return {
    unleveredIrr: parseFloat((unleveredIrr * 100).toFixed(2)),
    leveredIrr: parseFloat((leveredIrr * 100).toFixed(2)),
    npv: parseFloat(npv.toFixed(2)),
    unleveredNpv: parseFloat(unleveredNpv.toFixed(2)),
    roi: parseFloat(roi.toFixed(2)),
    equityMultiple: parseFloat(equityMultiple.toFixed(2)),
    paybackPeriod: parseFloat(paybackPeriod.toFixed(1)),
    averageDscr: parseFloat(averageDscr.toFixed(2)),
    minimumDscr: parseFloat(minimumDscr.toFixed(2)),
    averageIscr: parseFloat(averageIscr.toFixed(2)),
    totalRevenue: parseFloat(totalRevenue.toFixed(2)),
    totalTaxPaid: parseFloat(totalTaxPaid.toFixed(2)),
    enterpriseValue: parseFloat(enterpriseValue.toFixed(2)),
    assetValue: parseFloat(assetValue.toFixed(2))
  };
}
