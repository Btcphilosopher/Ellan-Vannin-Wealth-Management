/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ProjectInputs, FinancialOutputs, EconomicOutputs } from '../types';
import { ASSET_CLASS_PRESETS } from '../constants';

/**
 * Calculates national and regional economic impact metrics of an infrastructure project.
 */
export function calculateEconomicImpact(inputs: ProjectInputs, financial: FinancialOutputs): EconomicOutputs {
  const capex = inputs.constructionCost;
  const opex = inputs.operatingCost;
  const revenue = financial.totalRevenue / inputs.projectLife; // average annual operational revenue
  
  // Retrieve multipliers from inputs (which can be customized by the user)
  const mult = inputs.multipliers;
  
  // 1. GDP IMPACTS (millions)
  // Construction GDP: Direct Capex spending multiplied by construction multiplier
  const constructionGdp = capex * mult.construction;
  
  // Permanent GDP: Annual operational revenues multiplied by infrastructure/transport/energy multiplier
  let sectorMultiplier = mult.infrastructure;
  const preset = ASSET_CLASS_PRESETS[inputs.assetType];
  if (preset) {
    if (preset.category === 'Transport') sectorMultiplier = mult.transport;
    else if (preset.category === 'Energy') sectorMultiplier = mult.energy;
    else if (preset.category === 'Digital & Tech') sectorMultiplier = mult.digital;
    else if (preset.category === 'Housing & Social') sectorMultiplier = mult.housing;
  }
  
  const permanentGdp = revenue * sectorMultiplier;
  
  // Supply chain effects: indirect purchasing during development
  const supplyChainGdp = capex * 0.35 * mult.construction;
  
  // Agglomeration effects: regional productivity clusters created by infrastructure access
  const agglomerationGdp = permanentGdp * 0.15; // 15% productivity premium
  
  // Total GDP impact over the active project life + construction
  const totalGdpImpact = constructionGdp + supplyChainGdp + (permanentGdp + agglomerationGdp) * inputs.projectLife;

  // 2. EMPLOYMENT MODEL (FTEs Supported)
  // Construction Jobs (direct job-years / construction period)
  // Formula: £120k CAPEX supports 1 direct construction worker-year, amplified by construction multiplier
  const directConstructionJobs = Math.round((capex / 0.12) * mult.construction / inputs.constructionPeriod);
  
  // Permanent Jobs (annual operational employees)
  // Formula: £150k operational revenues supports 1 operator, amplified by sector multiplier
  const directPermanentJobs = Math.round((revenue / 0.15) * sectorMultiplier);
  
  // Indirect Jobs (supply chain supported)
  const indirectJobs = Math.round(directConstructionJobs * 0.45 + directPermanentJobs * 0.55);
  
  // Induced Jobs (consumer spending supported in local economy)
  const inducedJobs = Math.round((directConstructionJobs + directPermanentJobs) * 0.30);
  
  const totalJobsSupported = directConstructionJobs + directPermanentJobs + indirectJobs + inducedJobs;

  // 3. TAX REVENUES GENERATED (millions - cumulative over project life)
  const corporationTax = financial.totalTaxPaid;
  
  // Income Tax (assuming average construction wage is £42,000, permanent is £45,000, 20% effective tax rate + national insurance)
  const avgWageConstruction = 0.042; // £m
  const avgWagePermanent = 0.045; // £m
  const incomeTaxConst = directConstructionJobs * inputs.constructionPeriod * avgWageConstruction * 0.28; // 28% aggregate tax/NI rate
  const incomeTaxPerm = directPermanentJobs * inputs.projectLife * avgWagePermanent * 0.28;
  const incomeTax = incomeTaxConst + incomeTaxPerm;

  // VAT generated from commercial operations and supply spending (average 15% effective tax)
  const vat = financial.totalRevenue * 0.15;

  // Business Rates (commercial property tax - approx 0.8% of capital asset value annually)
  const businessRates = capex * 0.008 * inputs.projectLife;

  // Council Tax (stimulated by local residential developments, housing multipliers, etc.)
  const councilTax = (inputs.assetType === 'Housing' ? 0.0025 * (capex / 0.25) * inputs.projectLife : 0.0005 * capex * inputs.projectLife);

  const totalTaxGenerated = corporationTax + incomeTax + vat + businessRates + councilTax;

  // 4. ENVIRONMENTAL IMPACT
  // Tonnes of CO2 equivalent abated per year
  // Scaled by CAPEX based on asset preset carbon saving profiles
  const carbonFactor = preset ? preset.carbonSavings : 0;
  const carbonSaved = (capex / 10) * carbonFactor;

  return {
    constructionGdp: parseFloat(constructionGdp.toFixed(1)),
    permanentGdp: parseFloat(permanentGdp.toFixed(1)),
    supplyChainGdp: parseFloat(supplyChainGdp.toFixed(1)),
    agglomerationGdp: parseFloat(agglomerationGdp.toFixed(1)),
    totalGdpImpact: parseFloat(totalGdpImpact.toFixed(1)),
    constructionJobs: directConstructionJobs,
    permanentJobs: directPermanentJobs,
    indirectJobs,
    inducedJobs,
    totalJobsSupported,
    corporationTax: parseFloat(corporationTax.toFixed(1)),
    incomeTax: parseFloat(incomeTax.toFixed(1)),
    vat: parseFloat(vat.toFixed(1)),
    businessRates: parseFloat(businessRates.toFixed(1)),
    councilTax: parseFloat(councilTax.toFixed(1)),
    totalTaxGenerated: parseFloat(totalTaxGenerated.toFixed(1)),
    carbonSaved: parseFloat(carbonSaved.toFixed(0))
  };
}
