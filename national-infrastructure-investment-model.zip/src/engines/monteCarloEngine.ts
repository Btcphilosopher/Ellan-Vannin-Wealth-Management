/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ProjectInputs, MonteCarloRun, MonteCarloSummary } from '../types';
import { generateCashFlowSchedule, calculateFinancialOutputs } from './financialEngine';
import { calculateEconomicImpact } from './economicEngine';

/**
 * Generates a random number using Box-Muller transform for Normal Distribution.
 */
function randomNormal(mean: number, stdDev: number): number {
  let u = 0, v = 0;
  while(u === 0) u = Math.random(); 
  while(v === 0) v = Math.random();
  const num = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  return num * stdDev + mean;
}

/**
 * Runs a Monte Carlo simulation on a project.
 * Runs N iterations (default 500 for smooth real-time performance, adjustable up to 2000).
 */
export function runMonteCarloSimulation(
  inputs: ProjectInputs,
  iterations = 500,
  targetIrrHurdle = 6.0
): MonteCarloSummary {
  const runs: MonteCarloRun[] = [];

  for (let i = 1; i <= iterations; i++) {
    // 1. Apply stochastic variations with realistic project finance distributions
    // CAPEX: skewed right (more prone to overruns). Triangular-like skewed normal
    const capexOverrunRandom = Math.max(-0.05, randomNormal(0.12, 0.08)); // Mean 12% overrun, 8% std dev, cap at -5%
    const randomizedCapex = inputs.constructionCost * (1 + capexOverrunRandom);

    // Construction delay: 0 to 2 years, integer-based probability
    const rand = Math.random();
    const randomizedDelay = rand < 0.65 ? 0 : rand < 0.88 ? 1 : 2; // 65% on time, 23% 1-yr delay, 12% 2-yr delay

    // Revenue/Demand: normally distributed around base
    const demandMultiplier = Math.max(0.5, randomNormal(1.0, 0.12)); // 12% standard deviation, min 50%
    const randomizedRevenue = inputs.annualRevenue * demandMultiplier;

    // Inflation rate: normally distributed
    const randomizedInflation = Math.max(0.0, randomNormal(inputs.inflationRate, 0.8)); // std dev 0.8%

    // Interest rate: normally distributed
    const randomizedInterest = Math.max(1.0, randomNormal(inputs.interestRate, 1.2)); // std dev 1.2%

    // Build stochastic inputs
    const stochasticInputs: ProjectInputs = {
      ...inputs,
      constructionCost: randomizedCapex,
      constructionDelay: inputs.constructionDelay + randomizedDelay,
      annualRevenue: randomizedRevenue,
      inflationRate: randomizedInflation,
      interestRate: randomizedInterest,
      costOverrun: 0, // already folded into constructionCost directly
    };

    // 2. Execute Financial and Economic Engines
    try {
      const schedule = generateCashFlowSchedule(stochasticInputs);
      const financial = calculateFinancialOutputs(stochasticInputs, schedule);
      const economic = calculateEconomicImpact(stochasticInputs, financial);

      runs.push({
        simulationId: i,
        capex: parseFloat(randomizedCapex.toFixed(2)),
        revenue: parseFloat(randomizedRevenue.toFixed(2)),
        npv: financial.npv,
        irr: financial.leveredIrr,
        gdpImpact: economic.totalGdpImpact,
        jobsSupported: economic.totalJobsSupported
      });
    } catch (e) {
      // In rare edge cases where IRR fails to converge, skip or add neutral run
      continue;
    }
  }

  if (runs.length === 0) {
    return {
      runs: [],
      probabilityOfPositiveNpv: 0,
      probabilityOfTargetIrr: 0,
      confidenceIntervals: {
        npv: { p10: 0, p50: 0, p90: 0 },
        irr: { p10: 0, p50: 0, p90: 0 }
      },
      meanNpv: 0,
      meanIrr: 0
    };
  }

  // 3. Aggregate statistical summaries
  const npvs = runs.map(r => r.npv).sort((a, b) => a - b);
  const irrs = runs.map(r => r.irr).sort((a, b) => a - b);

  const meanNpv = npvs.reduce((a, b) => a + b, 0) / npvs.length;
  const meanIrr = irrs.reduce((a, b) => a + b, 0) / irrs.length;

  const positiveNpvCount = npvs.filter(n => n > 0).length;
  const targetIrrCount = irrs.filter(r => r >= targetIrrHurdle).length;

  // Calculate Percentiles
  const getPercentile = (arr: number[], percentile: number) => {
    const idx = Math.floor((percentile / 100) * (arr.length - 1));
    return arr[idx];
  };

  const confidenceIntervals = {
    npv: {
      p10: parseFloat(getPercentile(npvs, 10).toFixed(2)),
      p50: parseFloat(getPercentile(npvs, 50).toFixed(2)),
      p90: parseFloat(getPercentile(npvs, 90).toFixed(2))
    },
    irr: {
      p10: parseFloat(getPercentile(irrs, 10).toFixed(2)),
      p50: parseFloat(getPercentile(irrs, 50).toFixed(2)),
      p90: parseFloat(getPercentile(irrs, 90).toFixed(2))
    }
  };

  return {
    runs,
    probabilityOfPositiveNpv: parseFloat(((positiveNpvCount / runs.length) * 100).toFixed(1)),
    probabilityOfTargetIrr: parseFloat(((targetIrrCount / runs.length) * 100).toFixed(1)),
    confidenceIntervals,
    meanNpv: parseFloat(meanNpv.toFixed(2)),
    meanIrr: parseFloat(meanIrr.toFixed(2))
  };
}
