/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import Sidebar from './components/Sidebar';
import DashboardHome from './components/DashboardHome';
import PortfolioManager from './components/PortfolioManager';
import InteractiveMap from './components/InteractiveMap';
import ProjectForm from './components/ProjectForm';
import FinancialOutputsView from './components/FinancialOutputsView';
import CashFlowScheduleView from './components/CashFlowScheduleView';
import EconomicModelView from './components/EconomicModelView';
import RiskAnalysisView from './components/RiskAnalysisView';
import ReportGenerator from './components/ReportGenerator';
import RShinyExporter from './components/RShinyExporter';

import { INITIAL_PROJECTS, ASSET_CLASS_PRESETS } from './constants';
import { ProjectInputs, FinancialOutputs, EconomicOutputs, CashFlowYear } from './types';
import { generateCashFlowSchedule, calculateFinancialOutputs } from './engines/financialEngine';
import { calculateEconomicImpact } from './engines/economicEngine';

import { 
  Plus, 
  HelpCircle, 
  FileCheck, 
  ShieldAlert, 
  Layers, 
  Globe, 
  Terminal,
  Settings as SettingsIcon,
  Check
} from 'lucide-react';

export default function App() {
  const [projects, setProjects] = useState<ProjectInputs[]>(INITIAL_PROJECTS);
  const [selectedProjectId, setSelectedProjectId] = useState<string>(INITIAL_PROJECTS[0].id);
  const [currentTab, setCurrentTab] = useState<string>('dashboard');
  const [darkMode, setDarkMode] = useState<boolean>(true);

  // Global settings override states
  const [globalTaxRate, setGlobalTaxRate] = useState<number>(25.0);
  const [globalDiscountRate, setGlobalDiscountRate] = useState<number>(6.0);

  // Sync dark mode class with HTML tag
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Derived active project inputs
  const activeProject = useMemo(() => {
    return projects.find(p => p.id === selectedProjectId) || projects[0] || INITIAL_PROJECTS[0];
  }, [projects, selectedProjectId]);

  // Derived financials for active project
  const activeCashFlow = useMemo(() => {
    return generateCashFlowSchedule(activeProject);
  }, [activeProject]);

  const activeFinancials = useMemo(() => {
    return calculateFinancialOutputs(activeProject, activeCashFlow);
  }, [activeProject, activeCashFlow]);

  const activeEconomics = useMemo(() => {
    return calculateEconomicImpact(activeProject, activeFinancials);
  }, [activeProject, activeFinancials]);

  // Dicts for full portfolio-wide analytics
  const projectFinancials = useMemo(() => {
    const dict: Record<string, FinancialOutputs> = {};
    projects.forEach(p => {
      const schedule = generateCashFlowSchedule(p);
      dict[p.id] = calculateFinancialOutputs(p, schedule);
    });
    return dict;
  }, [projects]);

  const projectEconomics = useMemo(() => {
    const dict: Record<string, EconomicOutputs> = {};
    projects.forEach(p => {
      const fin = projectFinancials[p.id];
      if (fin) {
        dict[p.id] = calculateEconomicImpact(p, fin);
      }
    });
    return dict;
  }, [projects, projectFinancials]);

  // Update handlers
  const handleUpdateProject = (updated: ProjectInputs) => {
    setProjects(prev => prev.map(p => p.id === updated.id ? updated : p));
  };

  const handleSaveProject = () => {
    // Simply updates internal state
    alert(`Project specifications saved successfully.`);
  };

  const handleDeleteProject = (id: string) => {
    if (projects.length <= 1) {
      alert('Cannot delete the last remaining project in the active registry.');
      return;
    }
    const filtered = projects.filter(p => p.id !== id);
    setProjects(filtered);
    setSelectedProjectId(filtered[0].id);
    setCurrentTab('portfolio');
  };

  const handleAddNewProject = () => {
    const newId = `EV-PR-${Math.floor(1000 + Math.random() * 9000)}`;
    const newProj: ProjectInputs = {
      id: newId,
      name: 'Douglas Offshore Wind Ext',
      assetType: 'Offshore Wind',
      region: 'Isle of Man',
      status: 'Planning',
      constructionCost: 450.0,
      landAcquisition: 12.0,
      environmentalMitigation: 15.0,
      planningCosts: 8.5,
      professionalFees: 11.0,
      constructionPeriod: 3,
      projectLife: 25,
      annualRevenue: 55.0,
      annualRevenueGrowth: 2.0,
      operatingCost: 11.5,
      maintenanceCapex: 4.5,
      residualValue: 35.0,
      discountRate: globalDiscountRate,
      riskPremium: 1.0,
      costOverrun: 0,
      constructionDelay: 0,
      debtPercentage: 60,
      interestRate: 4.8,
      juniorDebtInterestRate: 7.2,
      debtType: 'Straight-Line',
      inflationRate: 2.5,
      taxRate: globalTaxRate,
      financingMix: {
        seniorDebt: 55,
        juniorDebt: 10,
        equity: 20,
        govEquity: 10,
        greenBonds: 5
      },
      multipliers: {
        construction: 1.85,
        infrastructure: 2.2,
        housing: 1.6,
        transport: 2.5,
        energy: 2.8,
        digital: 3.2
      }
    };

    setProjects(prev => [...prev, newProj]);
    setSelectedProjectId(newId);
    setCurrentTab('project-inputs');
  };

  // Sensitivity Recalculator helper for Tornado/Sliding
  const handleRecalculateSens = (capexMult: number, inflationRate: number, waccRate: number, demandMult: number) => {
    const testProject: ProjectInputs = {
      ...activeProject,
      constructionCost: activeProject.constructionCost * capexMult,
      inflationRate: inflationRate,
      discountRate: waccRate,
      annualRevenue: activeProject.annualRevenue * demandMult
    };
    const testCf = generateCashFlowSchedule(testProject);
    const testFin = calculateFinancialOutputs(testProject, testCf);
    return {
      irr: testFin.leveredIrr,
      npv: testFin.npv
    };
  };

  return (
    <div className="flex h-screen bg-[#F1F5F9] dark:bg-slate-950 text-slate-900 dark:text-slate-100 font-sans transition-colors duration-150 overflow-hidden">
      {/* 1. Left Sidebar Navigation */}
      <Sidebar 
        currentTab={currentTab} 
        setCurrentTab={setCurrentTab} 
        selectedProjectId={selectedProjectId}
        projectsCount={projects.length}
        darkMode={darkMode}
        setDarkMode={setDarkMode}
      />

      {/* 2. Main Terminal Content Stage */}
      <main className="flex-1 flex flex-col min-w-0 h-screen overflow-hidden">
        {/* Top bar header */}
        <header className="h-16 border-b border-slate-200 dark:border-slate-800/80 bg-white dark:bg-slate-950 flex items-center justify-between px-8 shrink-0 z-10">
          <div className="flex items-center gap-4">
            <span className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest hidden sm:inline">
              Secure Investment Appraisal Terminal
            </span>
            <div className="h-4 w-px bg-slate-200 dark:bg-slate-800 hidden sm:inline" />
            <div className="flex items-center gap-2">
              <label className="text-xs font-bold text-slate-500">Active Asset:</label>
              <select
                value={selectedProjectId}
                onChange={(e) => setSelectedProjectId(e.target.value)}
                className="text-xs font-bold border border-slate-200 dark:border-slate-800 p-1.5 rounded bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 cursor-pointer outline-none max-w-xs"
              >
                {projects.map((p) => (
                  <option key={p.id} value={p.id}>
                    [{p.id.split('-').pop()}] {p.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleAddNewProject}
              className="flex items-center gap-1 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold px-3 py-1.5 rounded shadow-sm transition-all cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              Add Project
            </button>
          </div>
        </header>

        {/* Dynamic view router */}
        <div className="flex-1 overflow-y-auto p-6 bg-[#F1F5F9] dark:bg-slate-950/40">
          {currentTab === 'dashboard' && (
            <DashboardHome 
              projects={projects}
              projectFinancials={projectFinancials}
              projectEconomics={projectEconomics}
              onSelectProject={(id) => {
                setSelectedProjectId(id);
                setCurrentTab('financial-outputs');
              }}
              onAddProject={handleAddNewProject}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'portfolio' && (
            <PortfolioManager 
              projects={projects}
              projectFinancials={projectFinancials}
              projectEconomics={projectEconomics}
              onSelectProject={(id) => {
                setSelectedProjectId(id);
                setCurrentTab('project-inputs');
              }}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'map' && (
            <InteractiveMap 
              projects={projects}
              projectFinancials={projectFinancials}
              projectEconomics={projectEconomics}
              selectedProjectId={selectedProjectId}
              onSelectProject={(id) => {
                setSelectedProjectId(id);
                setCurrentTab('financial-outputs');
              }}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'project-inputs' && (
            <ProjectForm 
              project={activeProject}
              onUpdateProject={handleUpdateProject}
              onSave={handleSaveProject}
              onDelete={() => handleDeleteProject(selectedProjectId)}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'financial-outputs' && (
            <FinancialOutputsView 
              project={activeProject}
              outputs={activeFinancials}
              schedule={activeCashFlow}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'cash-flow' && (
            <CashFlowScheduleView 
              project={activeProject}
              schedule={activeCashFlow}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'gdp-model' && (
            <EconomicModelView 
              project={activeProject}
              economics={activeEconomics}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'employment-model' && (
            <EconomicModelView 
              project={activeProject}
              economics={activeEconomics}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'tax-model' && (
            <EconomicModelView 
              project={activeProject}
              economics={activeEconomics}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'sensitivity' && (
            <RiskAnalysisView 
              project={activeProject}
              baseFinancials={activeFinancials}
              onRecalculateSens={handleRecalculateSens}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'monte-carlo' && (
            <RiskAnalysisView 
              project={activeProject}
              baseFinancials={activeFinancials}
              onRecalculateSens={handleRecalculateSens}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'reports' && (
            <ReportGenerator 
              project={activeProject}
              financials={activeFinancials}
              economics={activeEconomics}
              schedule={activeCashFlow}
              portfolioProjects={projects}
              darkMode={darkMode}
            />
          )}

          {currentTab === 'r-shiny' && (
            <RShinyExporter />
          )}

          {currentTab === 'settings' && (
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg p-6 space-y-6">
              <div>
                <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-3 mb-4">
                  <SettingsIcon className="w-4 h-4 text-emerald-600" />
                  Terminal Configuration & Profile
                </h3>
                <p className="text-xs text-slate-500">
                  Manage global model defaults, security clearance, and tax overrides.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
                <div className="space-y-4">
                  <h4 className="font-bold text-slate-500 uppercase tracking-wider">Global Appraisals Parameters</h4>
                  
                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300">Default Hurdle Discount Rate (WACC)</label>
                    <input 
                      type="number" 
                      step="0.5"
                      value={globalDiscountRate}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 6.0;
                        setGlobalDiscountRate(val);
                        setProjects(prev => prev.map(p => ({ ...p, discountRate: val })));
                      }}
                      className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-semibold text-slate-900 dark:text-white outline-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[11px] font-bold text-slate-700 dark:text-slate-300">Corporate Tax Base Rate Override</label>
                    <input 
                      type="number" 
                      step="0.5"
                      value={globalTaxRate}
                      onChange={(e) => {
                        const val = parseFloat(e.target.value) || 25.0;
                        setGlobalTaxRate(val);
                        setProjects(prev => prev.map(p => ({ ...p, taxRate: val })));
                      }}
                      className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-semibold text-slate-900 dark:text-white outline-none"
                    />
                  </div>
                </div>

                <div className="bg-slate-50 dark:bg-slate-800/40 p-5 rounded-lg border border-slate-100 dark:border-slate-800 space-y-4">
                  <h4 className="font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                    <Terminal className="w-4 h-4 text-emerald-600" />
                    Security Clearance Ledger
                  </h4>
                  <div className="space-y-2 text-[11px] font-semibold text-slate-500">
                    <div className="flex justify-between">
                      <span>USER ACCOUNT:</span>
                      <strong className="text-slate-900 dark:text-white">tom@ahyx.org</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>CLEARANCE STAGE:</span>
                      <strong className="text-emerald-600 dark:text-emerald-400">STAGE GATE-3 DIRECT ADVOCACY</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>ENCRYPTION DEPLOYED:</span>
                      <strong className="text-slate-900 dark:text-white">AES-GCM 256-BIT</strong>
                    </div>
                    <div className="flex justify-between">
                      <span>POSIX SERVER STATUS:</span>
                      <strong className="text-slate-900 dark:text-white">CONNECT ONLINE</strong>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
