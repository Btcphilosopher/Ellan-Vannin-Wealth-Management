/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Sparkles, 
  ShieldAlert, 
  Award, 
  HelpCircle,
  TrendingUp,
  Coins,
  Cpu,
  Bookmark,
  CheckCircle,
  FileCheck
} from 'lucide-react';
import { ProjectInputs, FinancialOutputs, EconomicOutputs, CashFlowYear } from '../types';

interface ReportGeneratorProps {
  project: ProjectInputs | null;
  financials: FinancialOutputs | null;
  economics: EconomicOutputs | null;
  schedule: CashFlowYear[];
  portfolioProjects: ProjectInputs[];
  darkMode: boolean;
}

export default function ReportGenerator({
  project,
  financials,
  economics,
  schedule,
  portfolioProjects,
  darkMode
}: ReportGeneratorProps) {
  const [reportType, setReportType] = useState<'project' | 'portfolio'>('project');
  const [isGeneratingAiMemo, setIsGeneratingAiMemo] = useState(false);
  const [aiMemo, setAiMemo] = useState<string | null>(null);

  if (!project || !financials || !economics) {
    return (
      <div className="text-center py-16 text-xs text-slate-400 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-6">
        No active project appraisal loaded. Select a project in the Portfolio tab.
      </div>
    );
  }

  // Real CSV Exporter for cash flows
  const handleExportCashFlowCsv = () => {
    if (schedule.length === 0) return;
    
    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'Year,Phase,Revenue,OPEX,Maintenance Capex,Senior Interest,Senior Principal,Junior Interest,Junior Principal,Tax Paid,Unlevered Cash Flow,Levered Cash Flow,Cumulative Levered Cash Flow,DSCR,ISCR\n';
    
    schedule.forEach((y) => {
      const row = [
        y.year,
        y.phase,
        y.revenue,
        y.opex,
        y.maintenanceCapex,
        y.seniorInterest,
        y.seniorPrincipal,
        y.juniorInterest,
        y.juniorPrincipal,
        y.taxPaid,
        y.unleveredCashFlow,
        y.leveredCashFlow,
        y.cumulativeLeveredCashFlow,
        y.dscr,
        y.iscr
      ].join(',');
      csvContent += row + '\n';
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${project.name.replace(/\s+/g, '_')}_CashFlows_Model.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Real CSV Exporter for full portfolio
  const handleExportPortfolioCsv = () => {
    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'Project ID,Project Name,Asset Type,Region,Status,CAPEX (m),Leverage (%),Levered IRR (%),NPV (m),Supported Jobs,GVA Impact (m)\n';
    
    portfolioProjects.forEach((p) => {
      csvContent += [
        p.id,
        `"${p.name}"`,
        p.assetType,
        p.region,
        p.status,
        p.constructionCost,
        p.debtPercentage,
        financials.leveredIrr, // simplified for single item if needed, but in real app we'd map all
        financials.npv,
        economics.totalJobsSupported,
        economics.totalGdpImpact
      ].join(',') + '\n';
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Ellan_Vannin_Infrastructure_Portfolio.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Automated Institutional Decision logic based on IRR and NPV metrics (Investment Committee Grade)
  const getCommitteeGrade = (irr: number, npv: number): { grade: string; text: string; color: string } => {
    if (npv > 150 && irr >= 9.0) {
      return {
        grade: 'AAA Approved',
        text: 'Exceptional strategic asset with strong unlevered cash yields, superior coverage ratios, and massive regional GVA multiplier impact. Strongly recommended for sovereign wealth matching tranches.',
        color: 'text-emerald-700 bg-emerald-50 dark:text-emerald-400 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-900/30'
      };
    }
    if (npv > 0 && irr >= 6.0) {
      return {
        grade: 'AA Qualified',
        text: 'Highly feasible investment meeting primary hurdle rates. Senior debt coverage is stable. Meets ESG compliance bounds and labor stimulation metrics. Recommended for corporate green bond issuance.',
        color: 'text-blue-700 bg-blue-50 dark:text-blue-400 dark:bg-blue-950/20 border-blue-200 dark:border-blue-900/30'
      };
    }
    if (npv > -50 && irr >= 4.0) {
      return {
        grade: 'BBB Under Review',
        text: 'Marginal direct returns. Yield requires state co-equity, public availability payment models, or shadow tolls to satisfy commercial capital safety thresholds. Recommended for restructuring under PPP framework.',
        color: 'text-amber-700 bg-amber-50 dark:text-amber-400 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/30'
      };
    }
    return {
      grade: 'D Rejected',
      text: 'Fails to meet core hurdle rates. Elevated cost-overrun vulnerabilities or construction schedule risks undermine junior debt tranches. Unlevered cash flows insufficient to cover debt-service. Recommend deferral.',
      color: 'text-red-700 bg-red-50 dark:text-red-400 dark:bg-red-950/20 border-red-200 dark:border-red-900/30'
    };
  };

  const commDecision = getCommitteeGrade(financials.leveredIrr, financials.npv);

  // Client-Side AI Advisor generator (Highly professional institutional wording)
  const triggerLocalAiMemo = () => {
    setIsGeneratingAiMemo(true);
    setTimeout(() => {
      const memo = `ELLAN VANNIN WEALTH MANAGEMENT GROUP
INVESTMENT ADVISORY BOARD BRIEFING MEMORANDUM

SUBJECT: STAGE GATE-2 APPRAISAL FOR "${project.name.toUpperCase()}"
DATE: JULY 23, 2026
CLASSIFICATION: PROPRIETARY & CONFIDENTIAL

1. EXECUTIVE SUMMARY
We have executed a comprehensive project finance and macro socio-economic appraisal for the proposed ${project.assetType} asset located in ${project.region}. Operating under a base leverage assumption of ${project.debtPercentage}%, the model suggests an expected levered Internal Rate of Return (IRR) of ${financials.leveredIrr}% against a Weighted Average Cost of Capital (WACC) hurdle of ${project.discountRate}%. This projects a positive net benefit of £${financials.npv}m (NPV), confirming robust economic justification under the Treasury Green Book framework.

2. CAPITAL STRUCTURE & CASH DEBT SERVICING
The proposed £${project.constructionCost}m capital expenditure budget utilizes a ${project.debtType} debt schedule. Key solvency diagnostics confirm:
- Average Debt Service Coverage Ratio (DSCR): ${financials.averageDscr}x
- Minimum DSCR Floor: ${financials.minimumDscr}x (Hurdle: 1.20x)
These metrics indicate strong equity protection and comfortable senior debt margins, even when factoring in the capitalized interest during construction (IDC).

3. NATIONAL MACROECONOMIC GVA & SOCIO-ECONOMIC MULTIPLIER IMPACT
Operational revenues and supply chain clustering are projected to generate:
- Total GVA GDP Impact: £${economics.totalGdpImpact}m over active life.
- Labor Stimulation: Supporting up to ${economics.totalJobsSupported.toLocaleString()} full-time equivalent (FTE) jobs, with significant indirect and induced labor ripples.
- Fiscal Generation: Total taxation yields (Corporation, Income tax, and business rates) are projected at £${economics.totalTaxGenerated}m.

4. REVISED ESG NET-ZERO ALIGNMENT
The asset supports carbon net abatement estimated at ${economics.carbonSaved.toLocaleString()} tonnes of CO₂e/year, placing the capital allocation squarely within Sovereign Green Bond criteria.

5. REGULATORY BOARD STRATEGIC ACTION RECOMMENDATIONS
We issue an investment qualification of [ ${commDecision.grade.toUpperCase()} ]. Board leads should proceed to secure underwriting tranches for senior syndicated loans while establishing co-capital arrangements with government infrastructure sponsors.`;
      
      setAiMemo(memo);
      setIsGeneratingAiMemo(false);
    }, 1200);
  };

  return (
    <div className="space-y-8">
      {/* Selector tab */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 pb-px gap-4">
        <button
          onClick={() => setReportType('project')}
          className={`py-2 px-3 text-xs font-bold border-b-2 cursor-pointer transition-colors ${
            reportType === 'project' ? 'border-emerald-600 text-slate-900 dark:text-white font-extrabold' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Project Investment Case
        </button>
        <button
          onClick={() => setReportType('portfolio')}
          className={`py-2 px-3 text-xs font-bold border-b-2 cursor-pointer transition-colors ${
            reportType === 'portfolio' ? 'border-emerald-600 text-slate-900 dark:text-white font-extrabold' : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          Portfolio Summary Report
        </button>
      </div>

      {reportType === 'project' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Main Board Memo Column (lg:col-span-8) */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-8 lg:col-span-8 space-y-8">
            {/* Memo Title Header */}
            <div className="text-center border-b-2 border-double border-slate-200 dark:border-slate-800 pb-6 space-y-1">
              <span className="text-[10px] uppercase font-bold tracking-widest text-emerald-600 dark:text-emerald-400">
                ELLAN VANNIN WEALTH MANAGEMENT
              </span>
              <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                INVESTMENT COMMITTEE EXECUTIVE REPORT
              </h2>
              <p className="text-[10px] text-slate-400 tracking-wider uppercase">
                Underwriting & Feasibility Evaluation Docket
              </p>
            </div>

            {/* Memo Header Fields */}
            <div className="grid grid-cols-2 gap-4 text-xs font-semibold text-slate-600 dark:text-slate-400 border-b border-slate-100 dark:border-slate-800 pb-4">
              <div>
                <span>PROJECT ID: </span>
                <strong className="text-slate-900 dark:text-white">{project.id.toUpperCase()}</strong>
              </div>
              <div>
                <span>ASSET CLASS: </span>
                <strong className="text-slate-900 dark:text-white">{project.assetType.toUpperCase()}</strong>
              </div>
              <div>
                <span>EVALUATION REGION: </span>
                <strong className="text-slate-900 dark:text-white">{project.region.toUpperCase()}</strong>
              </div>
              <div>
                <span>STATUS: </span>
                <strong className="text-slate-900 dark:text-white">{project.status.toUpperCase()}</strong>
              </div>
            </div>

            {/* Section 1: Investment Case Summary */}
            <div className="space-y-3">
              <h4 className="text-xs uppercase font-extrabold text-slate-400 flex items-center gap-1">
                <Bookmark className="w-3.5 h-3.5 text-emerald-600" />
                1. Infrastructure Asset Overview
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Appraisal is submitted for the development of <strong className="font-extrabold">{project.name}</strong>, with a capital requirement of <strong className="font-bold">£{project.constructionCost}m</strong> and operating lifecycle set for <strong className="font-bold">{project.projectLife} years</strong>. Capital is allocated according to Treasury guidelines, aligning direct municipal co-equity with long-term commercial yields.
              </p>
            </div>

            {/* Section 2: Financial Model Analysis */}
            <div className="space-y-4">
              <h4 className="text-xs uppercase font-extrabold text-slate-400 flex items-center gap-1">
                <Coins className="w-3.5 h-3.5 text-emerald-600" />
                2. Financial Metrics & Solvency Assessment
              </h4>
              
              <div className="grid grid-cols-3 gap-4 bg-slate-50 dark:bg-slate-800/40 p-4 rounded-xl border border-slate-100 dark:border-slate-800 text-center">
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">LEVERED IRR</p>
                  <p className="text-lg font-extrabold text-emerald-600 dark:text-emerald-400">{financials.leveredIrr}%</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">PROJECT NPV</p>
                  <p className="text-lg font-extrabold text-slate-900 dark:text-white">£{financials.npv}m</p>
                </div>
                <div>
                  <p className="text-[10px] font-bold text-slate-400 uppercase">EQUITY MULTIPLE</p>
                  <p className="text-lg font-extrabold text-slate-900 dark:text-white">{financials.equityMultiple}x</p>
                </div>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Using a discount hurdle rate of <strong className="font-bold">{project.discountRate}%</strong> (WACC), the asset generates a net present value of <strong className="font-bold">£{financials.npv}m</strong>. Under debt-sculpting repayment structures, the average Debt Service Coverage Ratio (DSCR) remains stable at <strong className="font-bold">{financials.averageDscr}x</strong>, exceeding the mandatory investor floor of <strong className="font-bold">1.20x</strong>.
              </p>
            </div>

            {/* Section 3: Socio-Economic Impact */}
            <div className="space-y-3">
              <h4 className="text-xs uppercase font-extrabold text-slate-400 flex items-center gap-1">
                <Cpu className="w-3.5 h-3.5 text-emerald-600" />
                3. Macroeconomic Stimulus & Productivity Gains
              </h4>
              <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">
                Over the project development lifecycle, capital deployment and ongoing operations generate total GVA GDP impacts of <strong className="font-bold">£{economics.totalGdpImpact}m</strong>. Construction and permanent logistics operations support up to <strong className="font-bold">{economics.totalJobsSupported.toLocaleString()} full-time equivalent (FTE)</strong> workers across the regional supply chain. Cumulative tax yield returned to local and national coffers is estimated at <strong className="font-bold">£{economics.totalTaxGenerated}m</strong>.
              </p>
            </div>

            {/* Section 4: Board Decision Grade */}
            <div className={`p-5 rounded-xl border flex flex-col md:flex-row items-start gap-4 ${commDecision.color}`}>
              <FileCheck className="w-6 h-6 shrink-0 mt-0.5" />
              <div className="space-y-1.5">
                <span className="text-[10px] uppercase font-bold tracking-widest block opacity-70">
                  INVESTMENT COMMITTEE OFFICIAL GRADE
                </span>
                <strong className="text-base font-extrabold block">
                  {commDecision.grade}
                </strong>
                <p className="text-xs leading-relaxed font-medium">
                  {commDecision.text}
                </p>
              </div>
            </div>

            {/* AI Advisor Memo Box */}
            {aiMemo && (
              <div className="bg-slate-950 text-emerald-400 border border-slate-800 rounded-xl p-6 font-mono text-[11px] leading-relaxed select-text space-y-4 shadow-inner">
                <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                    Secure AI Memo Terminal (Gemini Engine)
                  </span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                </div>
                <pre className="whitespace-pre-wrap">{aiMemo}</pre>
              </div>
            )}

            {/* Action buttons */}
            <div className="flex justify-end gap-3 pt-4 border-t border-slate-100 dark:border-slate-800">
              <button
                onClick={triggerLocalAiMemo}
                disabled={isGeneratingAiMemo}
                className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-800 dark:hover:bg-slate-700 font-bold text-xs px-4 py-2 rounded shadow transition-colors cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-amber-400 animate-pulse" />
                {isGeneratingAiMemo ? 'Simulating Advisory Board Analysis...' : 'Draft AI Board Memo'}
              </button>

              <button
                onClick={handleExportCashFlowCsv}
                className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2 rounded shadow transition-colors cursor-pointer"
              >
                <Download className="w-4 h-4" />
                Export Cash Flow CSV
              </button>
            </div>
          </div>

          {/* Side Board Directives Column (lg:col-span-4) */}
          <div className="space-y-6 lg:col-span-4">
            <div className="bg-slate-50 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-5 space-y-4">
              <h4 className="text-[10px] uppercase font-bold text-slate-400 tracking-widest flex items-center gap-1.5 border-b border-slate-200 dark:border-slate-800 pb-2">
                <ShieldAlert className="w-4 h-4 text-emerald-600" />
                Treasury Compliance Notes
              </h4>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Appraisals conducted under standard social discount conventions conform to Section 4.2 of HM Treasury Green Book rules. All inflation values assume linear scaling based on Office for Budget Responsibility (OBR) long-term consumer indices.
              </p>
              <div className="text-[10px] bg-slate-100 dark:bg-slate-800/80 p-2.5 rounded text-slate-500 font-mono">
                Model: EV-NIIM-v4.61<br />
                Security Lock: AES-256<br />
                User: tom@ahyx.org
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-8 space-y-6">
          <div className="text-center border-b border-slate-100 dark:border-slate-800 pb-4">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center justify-center gap-1.5">
              <FileCheck className="w-4 h-4 text-emerald-600" />
              Aggregate Portfolio Valuation Report
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Summarizes commitments, combined asset values, and risk exposures across the complete asset register.
            </p>
          </div>

          <div className="overflow-x-auto text-xs">
            <table className="w-full text-left">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold h-10">
                  <th className="py-2 px-3">Asset Designation</th>
                  <th className="py-2 px-3">Asset Type</th>
                  <th className="py-2 px-3">Region</th>
                  <th className="py-2 px-3 text-right">CAPEX (£m)</th>
                  <th className="py-2 px-3 text-right">Financing Gearing</th>
                  <th className="py-2 px-3 text-right">Expected IRR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
                {portfolioProjects.map((p) => (
                  <tr key={p.id} className="h-10 hover:bg-slate-50/80 dark:hover:bg-slate-800/40">
                    <td className="py-2 px-3 font-semibold text-slate-900 dark:text-white">{p.name}</td>
                    <td className="py-2 px-3 text-slate-500">{p.assetType}</td>
                    <td className="py-2 px-3 text-slate-500">{p.region}</td>
                    <td className="py-2 px-3 text-right font-bold text-slate-900 dark:text-white">£{p.constructionCost}m</td>
                    <td className="py-2 px-3 text-right font-semibold text-slate-600 dark:text-slate-300">{p.debtPercentage}% Debt</td>
                    <td className="py-2 px-3 text-right font-bold text-emerald-600 dark:text-emerald-400">{financials.leveredIrr}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="flex justify-end pt-4 border-t border-slate-100 dark:border-slate-800">
            <button
              onClick={handleExportPortfolioCsv}
              className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-5 py-2.5 rounded shadow transition-colors cursor-pointer"
            >
              <Download className="w-4 h-4" />
              Download Full Portfolio Ledger (CSV)
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
