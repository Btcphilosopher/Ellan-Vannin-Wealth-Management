/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Building2, 
  TrendingUp, 
  Globe2, 
  Users, 
  Layers, 
  Coins, 
  Plus, 
  ArrowUpRight, 
  Activity,
  CheckCircle2,
  Clock,
  Compass
} from 'lucide-react';
import { ProjectInputs, FinancialOutputs, EconomicOutputs } from '../types';
import { ASSET_CLASS_PRESETS } from '../constants';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell, PieChart, Pie } from 'recharts';

interface DashboardHomeProps {
  projects: ProjectInputs[];
  projectFinancials: Record<string, FinancialOutputs>;
  projectEconomics: Record<string, EconomicOutputs>;
  onSelectProject: (id: string) => void;
  onAddProject: () => void;
  darkMode: boolean;
}

export default function DashboardHome({
  projects,
  projectFinancials,
  projectEconomics,
  onSelectProject,
  onAddProject,
  darkMode
}: DashboardHomeProps) {
  
  // Aggregate portfolio metrics
  const totalAssets = projects.length;
  
  const totalInvestment = projects.reduce((sum, p) => sum + p.constructionCost, 0);
  
  const avgIrr = projects.length > 0 
    ? projects.reduce((sum, p) => sum + (projectFinancials[p.id]?.leveredIrr || 0), 0) / projects.length 
    : 0;
    
  const totalNpv = projects.reduce((sum, p) => sum + (projectFinancials[p.id]?.npv || 0), 0);
  
  const totalGdpImpact = projects.reduce((sum, p) => sum + (projectEconomics[p.id]?.totalGdpImpact || 0), 0);
  
  const totalJobsSupported = projects.reduce((sum, p) => sum + (projectEconomics[p.id]?.totalJobsSupported || 0), 0);

  const totalCarbonAbated = projects.reduce((sum, p) => sum + (projectEconomics[p.id]?.carbonSaved || 0), 0);

  // Sector Allocation data mapping
  const sectorDataMap: Record<string, number> = {};
  projects.forEach(p => {
    const category = ASSET_CLASS_PRESETS[p.assetType]?.category || 'Other';
    sectorDataMap[category] = (sectorDataMap[category] || 0) + p.constructionCost;
  });
  
  const sectorData = Object.entries(sectorDataMap).map(([name, value]) => ({ name, value }));

  // Regional Exposure data mapping
  const regionDataMap: Record<string, number> = {};
  projects.forEach(p => {
    regionDataMap[p.region] = (regionDataMap[p.region] || 0) + p.constructionCost;
  });
  const regionData = Object.entries(regionDataMap)
    .map(([name, value]) => ({ name, value }))
    .sort((a, b) => b.value - a.value);

  // Premium institutional colors
  const SECTOR_COLORS = ['#0f172a', '#10b981', '#475569', '#3b82f6', '#ec4899', '#8b5cf6'];
  const REGION_COLORS = ['#0284c7', '#0d9488', '#4f46e5', '#2563eb', '#16a34a', '#db2777', '#ea580c'];

  return (
    <div className="space-y-8 p-1">
      {/* Top Welcome Panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">
            National Infrastructure Investment Model (NIIM)
          </h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">
            Ellan Vannin Wealth Management • Strategic Capital Decision-Support Terminal
          </p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={onAddProject}
            className="flex items-center gap-1.5 bg-emerald-600 hover:bg-emerald-700 text-white font-medium text-xs px-4 py-2.5 rounded-md shadow-sm transition-colors cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            Appraise New Project
          </button>
        </div>
      </div>

      {/* Portfolio Aggregate Cards (3-4 columns, strict high contrast layouts) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Stat 1 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 dark:text-slate-400">
              Total Managed Assets
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-bold text-slate-900 dark:text-white">{totalAssets}</span>
              <span className="text-xs font-semibold text-slate-400">Strategic Projects</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">Active pipeline under advisory</p>
          </div>
          <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-md">
            <Layers className="w-5 h-5 text-slate-600 dark:text-slate-400" />
          </div>
        </div>

        {/* Stat 2 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">
              Total Capital Committed
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-bold text-slate-900 dark:text-white">
                £{(totalInvestment / 1000).toFixed(2)}B
              </span>
              <span className="text-xs font-semibold text-slate-400">CAPEX</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">Combined development and land cost</p>
          </div>
          <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/40 rounded-md">
            <Coins className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          </div>
        </div>

        {/* Stat 3 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 dark:text-slate-400">
              Expected Portfolio IRR
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-bold text-slate-900 dark:text-white">
                {avgIrr.toFixed(2)}%
              </span>
              <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400">Avg Levered</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">
              Combined NPV: <strong className="text-slate-700 dark:text-slate-300">£{totalNpv.toFixed(0)}m</strong>
            </p>
          </div>
          <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded-md">
            <TrendingUp className="w-5 h-5 text-slate-600 dark:text-slate-400" />
          </div>
        </div>

        {/* Stat 4 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500 dark:text-slate-400">
              National GDP Stimulus
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-2xl font-bold text-slate-900 dark:text-white">
                £{(totalGdpImpact / 1000).toFixed(2)}B
              </span>
              <span className="text-xs font-semibold text-slate-400">Lifecycle GDP</span>
            </div>
            <p className="text-[11px] text-slate-500 mt-2">
              Jobs Supported: <strong className="text-slate-700 dark:text-slate-300">{totalJobsSupported.toLocaleString()} FTE</strong>
            </p>
          </div>
          <div className="p-2.5 bg-indigo-50 dark:bg-indigo-950/40 rounded-md">
            <Globe2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
          </div>
        </div>
      </div>

      {/* Primary Analytics grid: Regional & Sector Distributions */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Sector Allocation (Donut Chart) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-xl shadow-sm flex flex-col justify-between">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Layers className="w-4 h-4 text-emerald-600" />
              Capital Allocation by Asset Sector
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">Asset diversification based on total project cost</p>
          </div>
          
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 py-4">
            <div className="w-48 h-48 shrink-0 relative flex items-center justify-center">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={sectorData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {sectorData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={SECTOR_COLORS[index % SECTOR_COLORS.length]} />
                    ))}
                  </Pie>
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute flex flex-col items-center justify-center text-center">
                <span className="text-xl font-bold text-slate-900 dark:text-white">
                  £{totalInvestment}m
                </span>
                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                  Total CAPEX
                </span>
              </div>
            </div>
            
            <div className="flex-1 space-y-2 w-full">
              {sectorData.map((item, index) => {
                const percent = ((item.value / totalInvestment) * 100).toFixed(1);
                return (
                  <div key={item.name} className="flex items-center justify-between text-xs border-b border-slate-50 dark:border-slate-800/40 pb-1.5">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-2.5 h-2.5 rounded-full" 
                        style={{ backgroundColor: SECTOR_COLORS[index % SECTOR_COLORS.length] }}
                      />
                      <span className="font-medium text-slate-700 dark:text-slate-300">{item.name}</span>
                    </div>
                    <div className="flex items-center gap-2 text-slate-500">
                      <span className="font-semibold text-slate-900 dark:text-white">£{item.value}m</span>
                      <span className="text-slate-400">({percent}%)</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Regional Exposure (Bar Chart) */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-xl shadow-sm flex flex-col justify-between">
          <div className="border-b border-slate-100 dark:border-slate-800 pb-3 mb-4">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Compass className="w-4 h-4 text-emerald-600" />
              Regional Exposure and Commitments
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">Geographic deployment of infrastructure capital</p>
          </div>

          <div className="h-48 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={regionData} layout="vertical" margin={{ left: 10, right: 10, top: 5, bottom: 5 }}>
                <XAxis type="number" stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} />
                <YAxis dataKey="name" type="category" stroke="#94a3b8" fontSize={10} tickLine={false} axisLine={false} width={100} />
                <Tooltip 
                  cursor={{ fill: 'rgba(148, 163, 184, 0.05)' }} 
                  contentStyle={{ backgroundColor: darkMode ? '#0f172a' : '#ffffff', borderColor: '#e2e8f0', borderRadius: '4px' }}
                  labelStyle={{ fontWeight: 'bold', fontSize: 11, color: darkMode ? '#f8fafc' : '#0f172a' }}
                  itemStyle={{ fontSize: 11 }}
                />
                <Bar dataKey="value" fill="#0d9488" radius={[0, 4, 4, 0]}>
                  {regionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={REGION_COLORS[index % REGION_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Bottom Grid: Recent Projects Pipeline (Structured grid list with precise status indicators) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 mb-4 gap-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-emerald-600 animate-pulse" />
              Active Project Appraisal Pipeline
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">Select a project to load its full financial & macro models</p>
          </div>
          <div className="text-xs text-slate-400 font-medium">
            Showing {projects.length} evaluated assets
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold h-10">
                <th className="py-2 px-3">Asset & Class</th>
                <th className="py-2 px-3">Region</th>
                <th className="py-2 px-3">Status</th>
                <th className="py-2 px-3 text-right">CAPEX (£m)</th>
                <th className="py-2 px-3 text-right">Levered IRR</th>
                <th className="py-2 px-3 text-right">NPV (£m)</th>
                <th className="py-2 px-3 text-right">Jobs (FTE)</th>
                <th className="py-2 px-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
              {projects.map((project) => {
                const fin = projectFinancials[project.id];
                const eco = projectEconomics[project.id];
                const category = ASSET_CLASS_PRESETS[project.assetType]?.category || 'Other';
                
                return (
                  <tr key={project.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors h-12">
                    <td className="py-2 px-3">
                      <div className="font-semibold text-slate-900 dark:text-slate-100">{project.name}</div>
                      <div className="text-[10px] text-slate-400 font-medium flex items-center gap-1 mt-0.5">
                        <span className="bg-slate-100 dark:bg-slate-800 px-1 rounded text-slate-500 dark:text-slate-400 font-bold">{category}</span>
                        <span>• {project.assetType}</span>
                      </div>
                    </td>
                    <td className="py-2 px-3 font-medium text-slate-600 dark:text-slate-300">
                      {project.region}
                    </td>
                    <td className="py-2 px-3">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                        project.status === 'Operational' 
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400'
                          : project.status === 'Under Construction'
                            ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400'
                            : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
                      }`}>
                        {project.status === 'Operational' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                        {project.status}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-right font-semibold text-slate-900 dark:text-white">
                      £{project.constructionCost.toLocaleString()}m
                    </td>
                    <td className="py-2 px-3 text-right font-bold text-emerald-600 dark:text-emerald-400">
                      {fin ? `${fin.leveredIrr}%` : 'N/A'}
                    </td>
                    <td className="py-2 px-3 text-right font-semibold text-slate-900 dark:text-white">
                      {fin ? `£${fin.npv.toLocaleString()}m` : 'N/A'}
                    </td>
                    <td className="py-2 px-3 text-right font-medium text-slate-600 dark:text-slate-300">
                      {eco ? eco.totalJobsSupported.toLocaleString() : 'N/A'}
                    </td>
                    <td className="py-2 px-3 text-center">
                      <button
                        onClick={() => onSelectProject(project.id)}
                        className="inline-flex items-center gap-1 bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-800 dark:hover:bg-slate-700 font-semibold px-2.5 py-1 rounded text-[10px] tracking-wide transition-colors cursor-pointer"
                      >
                        Model
                        <ArrowUpRight className="w-3 h-3" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
