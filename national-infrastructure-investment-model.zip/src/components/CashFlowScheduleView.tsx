/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Download, 
  Table, 
  HelpCircle,
  TrendingUp,
  Coins
} from 'lucide-react';
import { ProjectInputs, CashFlowYear } from '../types';

interface CashFlowScheduleViewProps {
  project: ProjectInputs;
  schedule: CashFlowYear[];
  darkMode: boolean;
}

export default function CashFlowScheduleView({
  project,
  schedule,
  darkMode
}: CashFlowScheduleViewProps) {

  // CSV trigger
  const handleExportCsv = () => {
    if (schedule.length === 0) return;
    
    let csvContent = 'data:text/csv;charset=utf-8,';
    csvContent += 'Year,Phase,Revenue,OPEX,Maintenance Capex,Senior Interest,Senior Principal,Junior Interest,Junior Principal,Tax Paid,Unlevered Cash Flow,Levered Cash Flow,Cumulative Levered Cash Flow,DSCR,ISCR\n';
    
    schedule.forEach((y) => {
      const row = [
        y.year,
        y.phase,
        y.revenue,
        y.opex,
        y.maintenanceCapex,
        y.seniorInterest,
        y.seniorPrincipal,
        y.juniorInterest,
        y.juniorPrincipal,
        y.taxPaid,
        y.unleveredCashFlow,
        y.leveredCashFlow,
        y.cumulativeLeveredCashFlow,
        y.dscr,
        y.iscr
      ].join(',');
      csvContent += row + '\n';
    });

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `${project.name.replace(/\s+/g, '_')}_Financial_Statement.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 gap-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
            <Table className="w-4 h-4 text-emerald-600" />
            Detailed Annual Cash Flow Schedule
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Full project finance model statement from construction drawdown to terminal residual valuation.
          </p>
        </div>
        <div>
          <button
            onClick={handleExportCsv}
            className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-800 dark:hover:bg-slate-700 font-bold text-xs px-3.5 py-1.5 rounded shadow transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            Export Statement CSV
          </button>
        </div>
      </div>

      {/* Table Frame */}
      <div className="overflow-x-auto select-text scrollbar-thin">
        <table className="w-full text-left text-[11px] border-collapse min-w-[1000px]">
          <thead>
            <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-bold uppercase tracking-wider h-10">
              <th className="py-2 px-3">Year</th>
              <th className="py-2 px-3">Phase</th>
              <th className="py-2 px-3 text-right">Revenue</th>
              <th className="py-2 px-3 text-right">OPEX & Maint</th>
              <th className="py-2 px-3 text-right">Senior P+I</th>
              <th className="py-2 px-3 text-right">Junior P+I</th>
              <th className="py-2 px-3 text-right">Tax Paid</th>
              <th className="py-2 px-3 text-right">Unlevered CF</th>
              <th className="py-2 px-3 text-right">Levered CF</th>
              <th className="py-2 px-3 text-right">Cumulative CF</th>
              <th className="py-2 px-3 text-right">DSCR</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 dark:divide-slate-800/50">
            {schedule.map((y) => {
              const isConst = y.phase === 'Construction';
              const isRes = y.phase === 'Residual';
              
              // Colors for levered cash flows
              const cfColor = y.leveredCashFlow > 0 
                ? 'text-emerald-600 dark:text-emerald-400 font-bold'
                : y.leveredCashFlow < 0 
                  ? 'text-red-600 dark:text-red-400 font-bold'
                  : 'text-slate-500';

              return (
                <tr 
                  key={y.year} 
                  className={`h-9 hover:bg-slate-50/80 dark:hover:bg-slate-800/30 transition-colors ${
                    isConst 
                      ? 'bg-slate-50/30 dark:bg-slate-900/10' 
                      : isRes 
                        ? 'bg-emerald-50/20 dark:bg-emerald-950/5' 
                        : ''
                  }`}
                >
                  <td className="py-1 px-3 font-semibold text-slate-900 dark:text-white">
                    {y.year === 0 ? 'Yr 0 (Base)' : `Year ${y.year}`}
                  </td>
                  <td className="py-1 px-3">
                    <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold uppercase tracking-wider ${
                      isConst 
                        ? 'bg-slate-100 dark:bg-slate-800 text-slate-500'
                        : isRes 
                          ? 'bg-blue-100 dark:bg-blue-950/40 text-blue-700 dark:text-blue-400'
                          : 'bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400'
                    }`}>
                      {y.phase}
                    </span>
                  </td>
                  <td className="py-1 px-3 text-right font-medium text-slate-700 dark:text-slate-300">
                    {y.revenue > 0 ? `£${y.revenue.toFixed(1)}m` : '—'}
                  </td>
                  <td className="py-1 px-3 text-right font-medium text-slate-600 dark:text-slate-400">
                    {isConst ? '—' : `£${(y.opex + y.maintenanceCapex).toFixed(1)}m`}
                  </td>
                  <td className="py-1 px-3 text-right font-medium text-slate-600 dark:text-slate-400">
                    {y.seniorPrincipal + y.seniorInterest > 0 
                      ? `£${(y.seniorPrincipal + y.seniorInterest).toFixed(1)}m` 
                      : '—'}
                  </td>
                  <td className="py-1 px-3 text-right font-medium text-slate-600 dark:text-slate-400">
                    {y.juniorPrincipal + y.juniorInterest > 0 
                      ? `£${(y.juniorPrincipal + y.juniorInterest).toFixed(1)}m` 
                      : '—'}
                  </td>
                  <td className="py-1 px-3 text-right font-medium text-slate-600 dark:text-slate-400">
                    {y.taxPaid > 0 ? `£${y.taxPaid.toFixed(1)}m` : '—'}
                  </td>
                  <td className="py-1 px-3 text-right font-semibold text-slate-900 dark:text-white">
                    £{y.unleveredCashFlow.toFixed(1)}m
                  </td>
                  <td className={`py-1 px-3 text-right ${cfColor}`}>
                    £{y.leveredCashFlow.toFixed(1)}m
                  </td>
                  <td className="py-1 px-3 text-right font-semibold text-slate-900 dark:text-white">
                    £{y.cumulativeLeveredCashFlow.toFixed(1)}m
                  </td>
                  <td className={`py-1 px-3 text-right font-bold ${
                    isConst ? 'text-slate-300' : y.dscr >= 1.35 ? 'text-emerald-600' : 'text-amber-500'
                  }`}>
                    {isConst ? '—' : `${y.dscr}x`}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
