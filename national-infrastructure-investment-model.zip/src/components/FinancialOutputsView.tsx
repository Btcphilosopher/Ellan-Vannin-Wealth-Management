/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  TrendingUp, 
  Coins, 
  Percent, 
  Clock, 
  Activity,
  Shield,
  Briefcase,
  HelpCircle
} from 'lucide-react';
import { ProjectInputs, FinancialOutputs, CashFlowYear } from '../types';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip, CartesianGrid } from 'recharts';

interface FinancialOutputsViewProps {
  project: ProjectInputs;
  outputs: FinancialOutputs;
  schedule: CashFlowYear[];
  darkMode: boolean;
}

export default function FinancialOutputsView({
  project,
  outputs,
  schedule,
  darkMode
}: FinancialOutputsViewProps) {
  
  // Format operational coverage data for Recharts
  const coverageData = schedule
    .filter(y => y.phase === 'Operational')
    .map(y => ({
      year: `Yr ${y.year - project.constructionPeriod - project.constructionDelay + 1}`,
      dscr: y.dscr === 10.0 ? 0 : y.dscr,
      iscr: y.iscr === 10.0 ? 0 : y.iscr
    }));

  return (
    <div className="space-y-8">
      {/* Metrics Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Metric 1 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Levered IRR</span>
            <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400">{outputs.leveredIrr}%</p>
            <p className="text-[10px] text-slate-400">Unlevered IRR: <strong className="font-semibold text-slate-600 dark:text-slate-300">{outputs.unleveredIrr}%</strong></p>
          </div>
          <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/20 rounded">
            <TrendingUp className="w-5 h-5 text-emerald-600" />
          </div>
        </div>

        {/* Metric 2 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Project Net Present Value</span>
            <p className="text-2xl font-bold text-slate-900 dark:text-white">£{outputs.npv.toLocaleString()}m</p>
            <p className="text-[10px] text-slate-400">Discount hurdle: <strong className="font-semibold text-slate-600 dark:text-slate-300">{project.discountRate}% WACC</strong></p>
          </div>
          <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded">
            <Coins className="w-5 h-5 text-slate-600 dark:text-slate-400" />
          </div>
        </div>

        {/* Metric 3 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Return on Equity Multiple</span>
            <p className="text-2xl font-bold text-slate-900 dark:text-white">{outputs.equityMultiple}x</p>
            <p className="text-[10px] text-slate-400">Equity ROI: <strong className="font-semibold text-slate-600 dark:text-slate-300">{outputs.roi.toFixed(1)}%</strong></p>
          </div>
          <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded">
            <Percent className="w-5 h-5 text-slate-600 dark:text-slate-400" />
          </div>
        </div>

        {/* Metric 4 */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm flex items-start justify-between">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Levered Payback Period</span>
            <p className="text-2xl font-bold text-slate-900 dark:text-white">{outputs.paybackPeriod} Years</p>
            <p className="text-[10px] text-slate-400">Concession life: <strong className="font-semibold text-slate-600 dark:text-slate-300">{project.projectLife} years</strong></p>
          </div>
          <div className="p-2.5 bg-slate-50 dark:bg-slate-800 rounded">
            <Clock className="w-5 h-5 text-slate-600 dark:text-slate-400" />
          </div>
        </div>
      </div>

      {/* Coverage Ratios Dashboard */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 mb-6 gap-3">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-emerald-600" />
              Debt Service Cover (DSCR) & Interest Service Cover (ISCR) Schedules
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Operational cash flows available for senior debt principal and coupon payments.
            </p>
          </div>
          <div className="flex items-center gap-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
            <div className="flex items-center gap-1">
              <div className="w-3 h-1.5 bg-emerald-600 rounded" />
              <span>DSCR Ratio</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="w-3 h-1.5 bg-blue-600 rounded" />
              <span>ISCR Ratio</span>
            </div>
          </div>
        </div>

        {/* Recharts Coverage Curve */}
        <div className="h-64 mt-4">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={coverageData} margin={{ top: 10, bottom: 5, left: 10, right: 10 }}>
              <defs>
                <linearGradient id="colorDscr" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#10b981" stopOpacity={0.15}/>
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0.01}/>
                </linearGradient>
                <linearGradient id="colorIscr" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.15}/>
                  <stop offset="95%" stopColor="#3b82f6" stopOpacity={0.01}/>
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#1e293b' : '#f1f5f9'} vertical={false} />
              <XAxis dataKey="year" stroke="#94a3b8" fontSize={10} tickLine={false} />
              <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} domain={[0, 'auto']} />
              <Tooltip
                contentStyle={{ backgroundColor: darkMode ? '#0f172a' : '#ffffff', borderColor: '#e2e8f0', borderRadius: '4px' }}
                itemStyle={{ fontSize: 11 }}
                labelStyle={{ fontWeight: 'bold', fontSize: 11, color: darkMode ? '#f8fafc' : '#0f172a' }}
              />
              <Area type="monotone" dataKey="dscr" name="DSCR" stroke="#10b981" strokeWidth={2.5} fillOpacity={1} fill="url(#colorDscr)" />
              <Area type="monotone" dataKey="iscr" name="ISCR" stroke="#3b82f6" strokeWidth={2} fillOpacity={1} fill="url(#colorIscr)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Coverage Highlights */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 border-t border-slate-100 dark:border-slate-800 pt-6 mt-6">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Average DSCR Metric</span>
            <p className="text-xl font-bold text-slate-900 dark:text-white">{outputs.averageDscr}x</p>
            <p className="text-[10px] text-slate-400">Required banking floor hurdle: <strong className="font-semibold text-slate-600 dark:text-slate-300">1.20x - 1.30x</strong></p>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Minimum DSCR Floor</span>
            <p className={`text-xl font-bold ${outputs.minimumDscr >= 1.25 ? 'text-emerald-600 dark:text-emerald-400' : 'text-amber-500'}`}>{outputs.minimumDscr}x</p>
            <p className="text-[10px] text-slate-400">Risk rating: <strong className="font-semibold text-slate-600 dark:text-slate-300">{outputs.minimumDscr >= 1.25 ? 'Investment Grade' : 'High Gearing Alert'}</strong></p>
          </div>

          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Average Interest Cover (ISCR)</span>
            <p className="text-xl font-bold text-slate-900 dark:text-white">{outputs.averageIscr}x</p>
            <p className="text-[10px] text-slate-400">Debt service buffer is solid.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
