/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  AlertTriangle, 
  HelpCircle, 
  TrendingUp, 
  Activity, 
  ShieldAlert, 
  Sparkles,
  Calculator,
  RefreshCw,
  TrendingDown
} from 'lucide-react';
import { ProjectInputs, FinancialOutputs, MonteCarloRun, MonteCarloSummary } from '../types';
import { runMonteCarloSimulation } from '../engines/monteCarloEngine';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, Cell, AreaChart, Area } from 'recharts';

interface RiskAnalysisViewProps {
  project: ProjectInputs;
  baseFinancials: FinancialOutputs;
  onRecalculateSens: (capexMult: number, inflationRate: number, waccRate: number, demandMult: number) => { irr: number; npv: number };
  darkMode: boolean;
}

export default function RiskAnalysisView({
  project,
  baseFinancials,
  onRecalculateSens,
  darkMode
}: RiskAnalysisViewProps) {
  // Sensitivity Sliders
  const [capexSens, setCapexSens] = useState<number>(0); // % change, e.g. -20 to +20
  const [waccSens, setWaccSens] = useState<number>(project.discountRate); // WACC rate
  const [inflationSens, setInflationSens] = useState<number>(2.5); // Inflation rate
  const [demandSens, setDemandSens] = useState<number>(1.0); // Demand multiplier

  // Monte Carlo state
  const [simIterations, setSimIterations] = useState<number>(1000);
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [simResults, setSimResults] = useState<MonteCarloSummary | null>(null);

  // Calculate instant sensitivity output
  const capexMultiplier = 1 + (capexSens / 100);
  const instantSens = onRecalculateSens(capexMultiplier, inflationSens, waccSens, demandSens);

  // Sensitivity Tornado Data
  const tornadoFactors = [
    { name: 'CAPEX Cost Overrun (+20%)', irrDelta: onRecalculateSens(1.20, 2.5, project.discountRate, 1.0).irr - baseFinancials.leveredIrr, type: 'negative' },
    { name: 'CAPEX Cost Savings (-15%)', irrDelta: onRecalculateSens(0.85, 2.5, project.discountRate, 1.0).irr - baseFinancials.leveredIrr, type: 'positive' },
    { name: 'WACC Rate Increase (+1.5%)', irrDelta: onRecalculateSens(1.0, 2.5, project.discountRate + 1.5, 1.0).irr - baseFinancials.leveredIrr, type: 'negative' },
    { name: 'WACC Rate Reduction (-1.0%)', irrDelta: onRecalculateSens(1.0, 2.5, project.discountRate - 1.0, 1.0).irr - baseFinancials.leveredIrr, type: 'positive' },
    { name: 'Demand Outperformance (+15%)', irrDelta: onRecalculateSens(1.0, 2.5, project.discountRate, 1.15).irr - baseFinancials.leveredIrr, type: 'positive' },
    { name: 'Demand Underperformance (-15%)', irrDelta: onRecalculateSens(1.0, 2.5, project.discountRate, 0.85).irr - baseFinancials.leveredIrr, type: 'negative' }
  ];

  // Run stochastic simulation
  const handleRunSimulation = () => {
    setIsSimulating(true);
    setTimeout(() => {
      const results = runMonteCarloSimulation(project, simIterations, project.discountRate);
      setSimResults(results);
      setIsSimulating(false);
    }, 900);
  };

  // Convert Monte Carlo runs to standard distribution buckets for Recharts histogram
  const getHistogramData = () => {
    if (!simResults) return [];
    const runs = simResults.runs;
    
    // Find min and max IRRs
    const irrs = runs.map(r => r.irr);
    const minIrr = Math.min(...irrs);
    const maxIrr = Math.max(...irrs);
    const numBuckets = 16;
    const bucketSize = (maxIrr - minIrr) / numBuckets;
    
    const buckets = Array.from({ length: numBuckets }, (_, idx) => {
      const start = minIrr + idx * bucketSize;
      const end = start + bucketSize;
      return {
        label: `${start.toFixed(1)}%`,
        start,
        end,
        count: 0
      };
    });

    runs.forEach(r => {
      for (let idx = 0; idx < numBuckets; idx++) {
        const b = buckets[idx];
        if (r.irr >= b.start && r.irr <= b.end) {
          b.count++;
          break;
        }
      }
    });

    return buckets;
  };

  const histogramData = getHistogramData();

  return (
    <div className="space-y-8">
      {/* Sensitivity Tornado Dashboard */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-6 space-y-6">
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-3 mb-4">
            <Calculator className="w-4 h-4 text-emerald-600" />
            Dynamic Stress Testing & Sensitivity Modeler
          </h3>
          <p className="text-xs text-slate-500">
            Slide and adjust capital, macro, and tariff values to stress test IRR solvency in real time.
          </p>
        </div>

        {/* Sliders Grid */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 bg-slate-50 dark:bg-slate-800/40 p-5 rounded-lg border border-slate-100 dark:border-slate-800">
          {/* Factor 1 */}
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-500 uppercase block">CAPEX Shift (%)</label>
            <input 
              type="range" 
              min="-25" 
              max="25" 
              value={capexSens} 
              onChange={(e) => setCapexSens(parseFloat(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer h-1 rounded-lg"
            />
            <div className="flex justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300">
              <span>{capexSens > 0 ? `+${capexSens}` : capexSens}%</span>
              <span className="text-slate-400 font-semibold">Cost variance</span>
            </div>
          </div>

          {/* Factor 2 */}
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-500 uppercase block">WACC Rate (%)</label>
            <input 
              type="range" 
              min="3" 
              max="12" 
              step="0.5"
              value={waccSens} 
              onChange={(e) => setWaccSens(parseFloat(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer h-1 rounded-lg"
            />
            <div className="flex justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300">
              <span>{waccSens.toFixed(1)}%</span>
              <span className="text-slate-400 font-semibold">Base: {project.discountRate}%</span>
            </div>
          </div>

          {/* Factor 3 */}
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-500 uppercase block">Inflation Rate (%)</label>
            <input 
              type="range" 
              min="0.5" 
              max="6.0" 
              step="0.1"
              value={inflationSens} 
              onChange={(e) => setInflationSens(parseFloat(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer h-1 rounded-lg"
            />
            <div className="flex justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300">
              <span>{inflationSens.toFixed(1)}%</span>
              <span className="text-slate-400 font-semibold">Index target</span>
            </div>
          </div>

          {/* Factor 4 */}
          <div className="space-y-2">
            <label className="text-[10px] font-bold text-slate-500 uppercase block">Demand Index</label>
            <input 
              type="range" 
              min="0.7" 
              max="1.3" 
              step="0.05"
              value={demandSens} 
              onChange={(e) => setDemandSens(parseFloat(e.target.value))}
              className="w-full accent-emerald-600 cursor-pointer h-1 rounded-lg"
            />
            <div className="flex justify-between text-[11px] font-bold text-slate-700 dark:text-slate-300">
              <span>{(demandSens * 100).toFixed(0)}%</span>
              <span className="text-slate-400 font-semibold">Utilization yield</span>
            </div>
          </div>
        </div>

        {/* Real-time calculated sensitive results */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 bg-slate-950 text-slate-300 p-5 rounded-lg border border-slate-800">
          <div>
            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block">Recalculated Sensitive Levered IRR</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-bold text-emerald-400">{instantSens.irr.toFixed(2)}%</span>
              <span className="text-xs text-slate-500 font-medium">Base: {baseFinancials.leveredIrr}%</span>
            </div>
          </div>

          <div>
            <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block">Recalculated Sensitive NPV</span>
            <div className="flex items-baseline gap-2 mt-1">
              <span className="text-2xl font-bold text-slate-100">£{instantSens.npv.toFixed(1)}m</span>
              <span className="text-xs text-slate-500 font-medium">Base: £{baseFinancials.npv}m</span>
            </div>
          </div>
        </div>

        {/* Tornado chart */}
        <div className="space-y-3">
          <h4 className="text-[11px] uppercase font-bold text-slate-400 tracking-wider">
            Tornado Elasticity Chart (Sensitivity Delta on Levered IRR %)
          </h4>
          <div className="h-44">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={tornadoFactors} layout="vertical" margin={{ left: 10, right: 10, top: 5, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke={darkMode ? '#1e293b' : '#f1f5f9'} />
                <XAxis type="number" stroke="#94a3b8" fontSize={9} />
                <YAxis dataKey="name" type="category" stroke="#94a3b8" fontSize={9} width={130} tickLine={false} />
                <Tooltip 
                  cursor={{ fill: 'rgba(148, 163, 184, 0.05)' }}
                  contentStyle={{ backgroundColor: darkMode ? '#0f172a' : '#ffffff', borderColor: '#e2e8f0' }}
                  itemStyle={{ fontSize: 11 }}
                />
                <Bar dataKey="irrDelta" radius={[4, 4, 4, 4]}>
                  {tornadoFactors.map((entry, index) => (
                    <Cell 
                      key={`cell-${index}`} 
                      fill={entry.irrDelta >= 0 ? '#10b981' : '#f43f5e'} 
                    />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Monte Carlo Section */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-6 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-100 dark:border-slate-800 pb-4 gap-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5">
              <Activity className="w-4 h-4 text-emerald-600" />
              Interactive Monte Carlo Stochastic Simulation Engine
            </h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Runs thousand-run Normal distribution simulations across volatile construction CAPEX schedules, delay risks, and demand structures.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <select
              value={simIterations}
              onChange={(e) => setSimIterations(parseInt(e.target.value))}
              className="text-xs font-bold border border-slate-200 dark:border-slate-800 p-2 rounded bg-slate-50 dark:bg-slate-900 text-slate-700 dark:text-slate-300 cursor-pointer"
            >
              <option value="500">500 Iterations</option>
              <option value="1000">1,000 Iterations</option>
              <option value="2000">2,000 Iterations</option>
            </select>

            <button
              onClick={handleRunSimulation}
              disabled={isSimulating}
              className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-800 dark:hover:bg-slate-700 font-bold text-xs px-4 py-2 rounded shadow transition-all cursor-pointer"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSimulating ? 'animate-spin' : ''}`} />
              {isSimulating ? 'Running Loop...' : 'Execute Simulator'}
            </button>
          </div>
        </div>

        {simResults ? (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
            {/* Stats list */}
            <div className="lg:col-span-4 space-y-6">
              <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 rounded-xl shadow-sm p-5 space-y-4">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-widest border-b border-slate-200 dark:border-slate-800 pb-2">
                  Stochastic Probability Ratios
                </span>

                <div className="space-y-3 text-xs">
                  <div className="flex justify-between items-center pb-2 border-b border-slate-100 dark:border-slate-800/60">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">Mean Simulated IRR:</span>
                    <span className="font-bold text-slate-900 dark:text-white">{simResults.meanIrr}%</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-slate-100 dark:border-slate-800/60">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">Mean Simulated NPV:</span>
                    <span className="font-bold text-slate-900 dark:text-white">£{simResults.meanNpv}m</span>
                  </div>
                  <div className="flex justify-between items-center pb-2 border-b border-slate-100 dark:border-slate-800/60">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">NPV Loss Risk (NPV &lt; 0):</span>
                    <span className={`font-bold ${simResults.probabilityOfPositiveNpv >= 90 ? 'text-emerald-600' : 'text-red-500'}`}>
                      {(100 - simResults.probabilityOfPositiveNpv).toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">Hurdle Beat Probability:</span>
                    <span className="font-bold text-slate-900 dark:text-white">{simResults.probabilityOfTargetIrr}%</span>
                  </div>
                </div>
              </div>

              {/* Confidence limits */}
              <div className="bg-slate-900 text-slate-300 rounded-xl shadow-sm p-5 space-y-4">
                <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider border-b border-slate-800 pb-2">
                  Sovereign Percentile Thresholds
                </span>
                
                <div className="space-y-3 text-[11px] font-mono">
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-bold">P10 (Pessimistic Case):</span>
                    <span className="font-bold text-slate-100">{simResults.confidenceIntervals.irr.p10}% IRR | £{simResults.confidenceIntervals.npv.p10}m</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-emerald-400 font-bold">P50 (Median Case):</span>
                    <span className="font-bold text-emerald-400">{simResults.confidenceIntervals.irr.p50}% IRR | £{simResults.confidenceIntervals.npv.p50}m</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500 font-bold">P90 (Optimistic Case):</span>
                    <span className="font-bold text-slate-100">{simResults.confidenceIntervals.irr.p90}% IRR | £{simResults.confidenceIntervals.npv.p90}m</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Distribution Graph */}
            <div className="lg:col-span-8 space-y-4">
              <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
                Simulated Levered IRR Probability Density Distribution (Frequency Curve)
              </span>

              <div className="h-60">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={histogramData} margin={{ top: 10, bottom: 5, left: 10, right: 10 }}>
                    <defs>
                      <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.15}/>
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0.01}/>
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke={darkMode ? '#1e293b' : '#f1f5f9'} vertical={false} />
                    <XAxis dataKey="label" stroke="#94a3b8" fontSize={9} />
                    <YAxis stroke="#94a3b8" fontSize={9} width={24} tickLine={false} />
                    <Tooltip 
                      cursor={{ stroke: '#10b981', strokeWidth: 1 }}
                      contentStyle={{ backgroundColor: darkMode ? '#0f172a' : '#ffffff', borderColor: '#e2e8f0' }}
                      itemStyle={{ fontSize: 11 }}
                    />
                    <Area type="monotone" dataKey="count" name="Runs Count" stroke="#10b981" strokeWidth={2} fillOpacity={1} fill="url(#colorCount)" />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
        ) : (
          <div className="text-center py-16 border-2 border-dashed border-slate-200 dark:border-slate-800 rounded-xl shadow-sm">
            <AlertTriangle className="w-8 h-8 text-slate-300 dark:text-slate-700 mx-auto" />
            <p className="text-xs text-slate-400 mt-2 font-semibold">Stochastic simulation not yet executed for this project.</p>
            <p className="text-[10px] text-slate-500 mt-1">Configure iterations and click Execute Simulator above to model risk parameters.</p>
          </div>
        )}
      </div>
    </div>
  );
}
