/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Briefcase, 
  Layers, 
  Coins, 
  TrendingUp, 
  Percent, 
  AlertTriangle,
  FileText,
  Activity,
  CheckCircle2,
  Clock,
  ArrowUpRight
} from 'lucide-react';
import { ProjectInputs, FinancialOutputs, EconomicOutputs } from '../types';
import { ASSET_CLASS_PRESETS } from '../constants';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell, Legend } from 'recharts';

interface PortfolioManagerProps {
  projects: ProjectInputs[];
  projectFinancials: Record<string, FinancialOutputs>;
  projectEconomics: Record<string, EconomicOutputs>;
  onSelectProject: (id: string) => void;
  darkMode: boolean;
}

export default function PortfolioManager({
  projects,
  projectFinancials,
  projectEconomics,
  onSelectProject,
  darkMode
}: PortfolioManagerProps) {

  // Aggregate stats
  const totalAssets = projects.length;
  const portfolioCapex = projects.reduce((sum, p) => sum + p.constructionCost, 0);
  
  const totalLeveredNpv = projects.reduce((sum, p) => sum + (projectFinancials[p.id]?.npv || 0), 0);
  const totalUnleveredNpv = projects.reduce((sum, p) => sum + (projectFinancials[p.id]?.unleveredNpv || 0), 0);
  
  const averageLeveredIrr = projects.length > 0
    ? projects.reduce((sum, p) => sum + (projectFinancials[p.id]?.leveredIrr || 0), 0) / projects.length
    : 0;
    
  const averageUnleveredIrr = projects.length > 0
    ? projects.reduce((sum, p) => sum + (projectFinancials[p.id]?.unleveredIrr || 0), 0) / projects.length
    : 0;

  // Calculate Combined Debt vs Equity profile
  let totalSeniorDebt = 0;
  let totalJuniorDebt = 0;
  let totalPrivateEquity = 0;
  let totalStateEquity = 0;
  let totalGreenBonds = 0;

  projects.forEach(p => {
    const totalDevCost = p.constructionCost + p.landAcquisition + p.environmentalMitigation + p.professionalFees + p.planningCosts;
    const debtCapital = totalDevCost * (p.debtPercentage / 100);
    const equityCapital = totalDevCost - debtCapital;

    totalSeniorDebt += debtCapital * (p.financingMix.seniorDebt / 100);
    totalJuniorDebt += debtCapital * (p.financingMix.juniorDebt / 100);
    totalPrivateEquity += equityCapital * (p.financingMix.equity / 100);
    totalStateEquity += equityCapital * (p.financingMix.govEquity / 100);
    totalGreenBonds += debtCapital * (p.financingMix.greenBonds / 100);
  });

  const combinedFinancingData = [
    { name: 'Senior Debt', value: parseFloat(totalSeniorDebt.toFixed(1)), fill: '#1e3a8a' },
    { name: 'Junior Debt', value: parseFloat(totalJuniorDebt.toFixed(1)), fill: '#3b82f6' },
    { name: 'Green Bonds', value: parseFloat(totalGreenBonds.toFixed(1)), fill: '#10b981' },
    { name: 'Private Equity', value: parseFloat(totalPrivateEquity.toFixed(1)), fill: '#475569' },
    { name: 'Sovereign Equity', value: parseFloat(totalStateEquity.toFixed(1)), fill: '#f59e0b' }
  ].filter(d => d.value > 0);

  // Calculate Asset Risk Rating
  const getRiskRating = (p: ProjectInputs, fin: FinancialOutputs | null): { rating: 'Low' | 'Medium' | 'High' | 'Severe'; color: string } => {
    let score = 0;
    // Status
    if (p.status === 'Planning') score += 2;
    if (p.status === 'Under Construction') score += 1;
    
    // Leverage Gearing
    if (p.debtPercentage > 65) score += 3;
    else if (p.debtPercentage > 50) score += 1.5;

    // Cost Overrun & delay
    if (p.costOverrun > 10) score += 2;
    if (p.constructionDelay > 0) score += 1.5;

    // Return metrics
    if (fin && fin.leveredIrr < 5.0) score += 2.5;

    if (score >= 7) return { rating: 'Severe', color: 'text-red-600 bg-red-50 dark:text-red-400 dark:bg-red-950/20' };
    if (score >= 4.5) return { rating: 'High', color: 'text-amber-600 bg-amber-50 dark:text-amber-400 dark:bg-amber-950/20' };
    if (score >= 2) return { rating: 'Medium', color: 'text-indigo-600 bg-indigo-50 dark:text-indigo-400 dark:bg-indigo-950/20' };
    return { rating: 'Low', color: 'text-emerald-600 bg-emerald-50 dark:text-emerald-400 dark:bg-emerald-950/20' };
  };

  return (
    <div className="space-y-8">
      {/* Overview stats panel */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 dark:border-slate-800 pb-5">
        <div>
          <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest">
            ELLAN VANNIN GLOBAL INVESTMENT BOARD
          </span>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white mt-1">
            Aggregate Infrastructure Portfolio
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Diversified direct investments across regional utilities, baseload nuclear, green energy wind farms, and transport networks.
          </p>
        </div>
      </div>

      {/* Grid stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm">
          <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Portfolio Gearing Ratio</span>
          <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
            {((totalSeniorDebt + totalJuniorDebt + totalGreenBonds) / (portfolioCapex + 1e-9) * 100).toFixed(1)}%
          </p>
          <div className="text-[11px] text-slate-400 mt-1">Combined Debt to CAPEX ratio</div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm">
          <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Average Hurdle/Discount Rate</span>
          <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
            {(projects.reduce((sum, p) => sum + p.discountRate, 0) / (totalAssets || 1)).toFixed(2)}%
          </p>
          <div className="text-[11px] text-slate-400 mt-1">Weighted Social WACC</div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm">
          <span className="text-[10px] uppercase font-bold tracking-wider text-emerald-600 dark:text-emerald-400">Weighted Levered IRR</span>
          <p className="text-2xl font-bold text-emerald-600 dark:text-emerald-400 mt-1">
            {averageLeveredIrr.toFixed(2)}%
          </p>
          <div className="text-[11px] text-slate-400 mt-1">Unlevered average: {averageUnleveredIrr.toFixed(2)}%</div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm">
          <span className="text-[10px] uppercase font-bold tracking-wider text-slate-500">Combined Portfolio NPV</span>
          <p className="text-2xl font-bold text-slate-900 dark:text-white mt-1">
            £{totalLeveredNpv.toLocaleString(undefined, { maximumFractionDigits: 0 })}m
          </p>
          <div className="text-[11px] text-slate-400 mt-1">Unlevered: £{totalUnleveredNpv.toLocaleString(undefined, { maximumFractionDigits: 0 })}m</div>
        </div>
      </div>

      {/* Capital Financing Mix ledger / risk matrix chart */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Financing Breakdown */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-xl shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-3 mb-4">
              <Coins className="w-4 h-4 text-emerald-600" />
              Combined Capital Tranche Breakdown (£ Millions)
            </h3>
            <p className="text-xs text-slate-500">
              Aggregated leverage structure including Senior Term, Mezzanine, Green Bonds, Private Equity, and Sovereign co-capital.
            </p>
          </div>

          <div className="h-56 mt-4">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={combinedFinancingData} margin={{ top: 10, bottom: 5, left: 10, right: 10 }}>
                <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} />
                <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                <Tooltip 
                  cursor={{ fill: 'rgba(148, 163, 184, 0.05)' }}
                  contentStyle={{ backgroundColor: darkMode ? '#0f172a' : '#ffffff', borderColor: '#e2e8f0' }}
                  itemStyle={{ fontSize: 11 }}
                />
                <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]}>
                  {combinedFinancingData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Portfolio Debt and Risk Ledger */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-xl shadow-sm flex flex-col justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-3 mb-4">
              <AlertTriangle className="w-4 h-4 text-emerald-600" />
              Sovereign and Private Equity Commitments
            </h3>
            <p className="text-xs text-slate-500">
              Direct cash balances drawn to date against general partner advisory funds.
            </p>
          </div>

          <div className="space-y-4 py-3">
            <div className="flex items-center justify-between text-xs border-b border-slate-100 dark:border-slate-800 pb-2">
              <span className="font-semibold text-slate-600 dark:text-slate-400">Total Senior Bank Finance:</span>
              <span className="font-bold text-slate-900 dark:text-white">£{totalSeniorDebt.toLocaleString(undefined, { maximumFractionDigits: 1 })}m</span>
            </div>
            <div className="flex items-center justify-between text-xs border-b border-slate-100 dark:border-slate-800 pb-2">
              <span className="font-semibold text-slate-600 dark:text-slate-400">Total Mezzanine / Junior Term:</span>
              <span className="font-bold text-slate-900 dark:text-white">£{totalJuniorDebt.toLocaleString(undefined, { maximumFractionDigits: 1 })}m</span>
            </div>
            <div className="flex items-center justify-between text-xs border-b border-slate-100 dark:border-slate-800 pb-2">
              <span className="font-semibold text-slate-600 dark:text-slate-400">Total Certified Green Bonds Issued:</span>
              <span className="font-bold text-emerald-600 dark:text-emerald-400">£{totalGreenBonds.toLocaleString(undefined, { maximumFractionDigits: 1 })}m</span>
            </div>
            <div className="flex items-center justify-between text-xs border-b border-slate-100 dark:border-slate-800 pb-2">
              <span className="font-semibold text-slate-600 dark:text-slate-400">Ellan Vannin GP Private Equity:</span>
              <span className="font-bold text-slate-900 dark:text-white">£{totalPrivateEquity.toLocaleString(undefined, { maximumFractionDigits: 1 })}m</span>
            </div>
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-600 dark:text-slate-400">Government / Municipal Co-capital:</span>
              <span className="font-bold text-slate-900 dark:text-white">£{totalStateEquity.toLocaleString(undefined, { maximumFractionDigits: 1 })}m</span>
            </div>
          </div>
        </div>
      </div>

      {/* Asset Risk and Performance Registry */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-6">
        <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-3 mb-4">
          <Activity className="w-4 h-4 text-emerald-600" />
          Full Strategic Asset Performance Registry
        </h3>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-semibold h-10">
                <th className="py-2 px-3">Asset Designation</th>
                <th className="py-2 px-3">Status</th>
                <th className="py-2 px-3 text-right">Leverage (%)</th>
                <th className="py-2 px-3 text-right">Levered IRR (%)</th>
                <th className="py-2 px-3 text-right">WACC Hurdle (%)</th>
                <th className="py-2 px-3 text-right">NPV (£m)</th>
                <th className="py-2 px-3 text-center">Risk Rating</th>
                <th className="py-2 px-3 text-center">Appraise</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800/60">
              {projects.map((project) => {
                const fin = projectFinancials[project.id];
                const risk = getRiskRating(project, fin);
                return (
                  <tr key={project.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors h-12">
                    <td className="py-2 px-3 font-semibold text-slate-900 dark:text-white">
                      {project.name}
                      <span className="block text-[9px] text-slate-400 font-medium mt-0.5">{project.assetType} • {project.region}</span>
                    </td>
                    <td className="py-2 px-3">
                      <span className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded text-[9px] font-bold ${
                        project.status === 'Operational' 
                          ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400'
                          : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400'
                      }`}>
                        {project.status}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-right font-semibold text-slate-600 dark:text-slate-300">
                      {project.debtPercentage}%
                    </td>
                    <td className="py-2 px-3 text-right font-bold text-emerald-600 dark:text-emerald-400">
                      {fin ? `${fin.leveredIrr}%` : 'N/A'}
                    </td>
                    <td className="py-2 px-3 text-right font-semibold text-slate-600 dark:text-slate-300">
                      {project.discountRate}%
                    </td>
                    <td className="py-2 px-3 text-right font-bold text-slate-900 dark:text-white">
                      {fin ? `£${fin.npv.toLocaleString()}m` : 'N/A'}
                    </td>
                    <td className="py-2 px-3 text-center">
                      <span className={`inline-block px-2 py-0.5 rounded text-[9px] font-extrabold uppercase tracking-wider ${risk.color}`}>
                        {risk.rating}
                      </span>
                    </td>
                    <td className="py-2 px-3 text-center">
                      <button
                        onClick={() => onSelectProject(project.id)}
                        className="p-1 bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-800 dark:hover:bg-slate-700 rounded transition-colors cursor-pointer"
                        title="Open appraisal model"
                      >
                        <ArrowUpRight className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
