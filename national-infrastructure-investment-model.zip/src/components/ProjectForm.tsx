/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  FolderTree, 
  Settings, 
  Wrench, 
  Coins, 
  TrendingUp, 
  AlertTriangle, 
  BookOpen, 
  Info,
  Sliders,
  Check
} from 'lucide-react';
import { ProjectInputs, AssetType, Region, ProjectStatus } from '../types';
import { ASSET_CLASS_PRESETS, UK_REGIONS } from '../constants';

interface ProjectFormProps {
  project: ProjectInputs;
  onUpdateProject: (p: ProjectInputs) => void;
  onSave: () => void;
  onDelete?: () => void;
  darkMode: boolean;
}

type FormSection = 'specifications' | 'capex' | 'operations' | 'financing' | 'multipliers';

export default function ProjectForm({
  project,
  onUpdateProject,
  onSave,
  onDelete,
  darkMode
}: ProjectFormProps) {
  const [activeSection, setActiveSection] = useState<FormSection>('specifications');
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  // Load Preset Defaults
  const handleApplyPreset = (type: AssetType) => {
    const preset = ASSET_CLASS_PRESETS[type];
    if (!preset) return;

    const updated: ProjectInputs = {
      ...project,
      assetType: type,
      constructionCost: preset.defaultCapex,
      operatingCost: preset.defaultOpex,
      constructionPeriod: preset.defaultConstructionPeriod,
      projectLife: preset.defaultProjectLife,
      annualRevenue: preset.defaultAnnualRevenue,
      annualRevenueGrowth: preset.defaultRevenueGrowth,
      multipliers: { ...preset.multipliers }
    };
    onUpdateProject(updated);
    showToast(`Applied preset for: ${type}`);
  };

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  const handleFieldChange = (key: keyof ProjectInputs, value: any) => {
    onUpdateProject({
      ...project,
      [key]: value
    });
  };

  const handleMultiplierChange = (key: keyof ProjectInputs['multipliers'], value: number) => {
    onUpdateProject({
      ...project,
      multipliers: {
        ...project.multipliers,
        [key]: value
      }
    });
  };

  const handleFinancingChange = (key: keyof ProjectInputs['financingMix'], value: number) => {
    const mix = { ...project.financingMix, [key]: value };
    
    // Auto-adjust equity to keep total at 100%
    const debtRatio = project.debtPercentage;
    const remaining = 100 - debtRatio;
    
    onUpdateProject({
      ...project,
      financingMix: mix
    });
  };

  // Sections navigation
  const sections: { id: FormSection; label: string; icon: any }[] = [
    { id: 'specifications', label: 'Specifications & Assets', icon: FolderTree },
    { id: 'capex', label: 'Development CAPEX', icon: Wrench },
    { id: 'operations', label: 'Operations & Revenues', icon: TrendingUp },
    { id: 'financing', label: 'Capital & Financing', icon: Coins },
    { id: 'multipliers', label: 'Economic Multipliers', icon: Settings }
  ];

  return (
    <div className="space-y-6">
      {/* Toast Alert */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 bg-slate-900 text-white border border-slate-700 rounded-lg py-3 px-4 shadow-lg text-xs font-semibold flex items-center gap-2 animate-bounce z-50">
          <span className="w-2 h-2 rounded-full bg-emerald-500" />
          {toastMsg}
        </div>
      )}

      {/* Editor Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-slate-200 dark:border-slate-800 pb-5 gap-3">
        <div>
          <span className="text-[10px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-widest">
            ACTIVE EVALUATION WORKSPACE
          </span>
          <h2 className="text-xl font-bold tracking-tight text-slate-900 dark:text-white mt-1">
            {project.name || 'Untitled Asset Model'}
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Modify structural specifications below. Financial and GDP multipliers re-simulate dynamically.
          </p>
        </div>
        <div className="flex items-center gap-2">
          {onDelete && (
            <button
              onClick={onDelete}
              className="px-3 py-1.5 border border-red-200 text-red-700 hover:bg-red-50 dark:border-red-900/40 dark:text-red-400 dark:hover:bg-red-950/20 text-xs font-semibold rounded transition-colors cursor-pointer"
            >
              Delete Project
            </button>
          )}
          <button
            onClick={onSave}
            className="flex items-center gap-1.5 bg-slate-900 hover:bg-slate-800 text-white dark:bg-slate-800 dark:hover:bg-slate-700 font-bold text-xs px-4 py-1.5 rounded shadow-sm transition-colors cursor-pointer"
          >
            Save Project Changes
          </button>
        </div>
      </div>

      {/* Workspace Tabs */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 overflow-x-auto no-scrollbar">
        {sections.map((sec) => {
          const Icon = sec.icon;
          const isActive = activeSection === sec.id;
          return (
            <button
              key={sec.id}
              onClick={() => setActiveSection(sec.id)}
              className={`py-3 px-5 text-xs font-bold border-b-2 transition-all whitespace-nowrap flex items-center gap-2 cursor-pointer ${
                isActive 
                  ? 'border-emerald-600 text-slate-900 dark:text-white font-extrabold' 
                  : 'border-transparent text-slate-400 hover:text-slate-600 dark:hover:text-slate-200'
              }`}
            >
              <Icon className="w-4 h-4" />
              {sec.label}
            </button>
          );
        })}
      </div>

      {/* Main Form content area */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-6">
        {activeSection === 'specifications' && (
          <div className="space-y-6">
            <h3 className="text-xs uppercase font-extrabold tracking-wider text-slate-400 flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-2">
              <Info className="w-4 h-4 text-emerald-600" />
              Asset & Site Specifications
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Project Identifier Name</label>
                <input
                  type="text"
                  value={project.name}
                  onChange={(e) => handleFieldChange('name', e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-semibold text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                  placeholder="Enter project name..."
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Geographic Region</label>
                <select
                  value={project.region}
                  onChange={(e) => handleFieldChange('region', e.target.value as Region)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-semibold text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                >
                  {Object.keys(UK_REGIONS).map((reg) => (
                    <option key={reg} value={reg}>{reg}</option>
                  ))}
                </select>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Asset Class Preset Library</label>
                <div className="flex gap-2">
                  <select
                    value={project.assetType}
                    onChange={(e) => handleApplyPreset(e.target.value as AssetType)}
                    className="flex-1 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-bold text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                  >
                    {Object.keys(ASSET_CLASS_PRESETS).map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </div>
                <p className="text-[10px] text-slate-400">Applying presets will load standardized CAPEX, operating lifespans, and multiplier coefficients.</p>
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Development Lifecycle Stage</label>
                <select
                  value={project.status}
                  onChange={(e) => handleFieldChange('status', e.target.value as ProjectStatus)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-semibold text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                >
                  <option value="Planning">Planning (Appraisal Phase)</option>
                  <option value="Under Construction">Under Construction</option>
                  <option value="Operational">Operational (Live-Generating)</option>
                  <option value="Decommissioned">Decommissioned</option>
                </select>
              </div>
            </div>

            {/* Risk Premium Panel */}
            <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-lg border border-slate-100 dark:border-slate-800 space-y-4">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white flex items-center gap-1.5">
                <AlertTriangle className="w-4 h-4 text-amber-500" />
                Construction & Risk Overlays
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">Risk Premium Overlay</span>
                    <span className="font-bold text-slate-950 dark:text-white">+{project.riskPremium}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="5"
                    step="0.1"
                    value={project.riskPremium}
                    onChange={(e) => handleFieldChange('riskPremium', parseFloat(e.target.value))}
                    className="w-full accent-emerald-600"
                  />
                  <p className="text-[9px] text-slate-400">Adds hurdle padding to the NPV discount rate.</p>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">Cost Overrun Variance</span>
                    <span className="font-bold text-slate-950 dark:text-white">+{project.costOverrun}%</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="50"
                    step="1"
                    value={project.costOverrun}
                    onChange={(e) => handleFieldChange('costOverrun', parseInt(e.target.value))}
                    className="w-full accent-emerald-600"
                  />
                  <p className="text-[9px] text-slate-400">Simulates inflation or logistics budget overruns.</p>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">Construction Delays</span>
                    <span className="font-bold text-slate-950 dark:text-white">+{project.constructionDelay} Years</span>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="5"
                    step="1"
                    value={project.constructionDelay}
                    onChange={(e) => handleFieldChange('constructionDelay', parseInt(e.target.value))}
                    className="w-full accent-emerald-600"
                  />
                  <p className="text-[9px] text-slate-400">Delays operational revenues, adding interest carry costs.</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'capex' && (
          <div className="space-y-6">
            <h3 className="text-xs uppercase font-extrabold tracking-wider text-slate-400 flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-2">
              <Sliders className="w-4 h-4 text-emerald-600" />
              Development CAPEX Allocation (£ Millions)
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">EPC Construction & Equipment Cost</label>
                <input
                  type="number"
                  value={project.constructionCost}
                  onChange={(e) => handleFieldChange('constructionCost', parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Land Acquisition & Assembly</label>
                <input
                  type="number"
                  value={project.landAcquisition}
                  onChange={(e) => handleFieldChange('landAcquisition', parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Environmental Mitigation & Net Gain Compliance</label>
                <input
                  type="number"
                  value={project.environmentalMitigation}
                  onChange={(e) => handleFieldChange('environmentalMitigation', parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Planning, Consents & Legal Approvals</label>
                <input
                  type="number"
                  value={project.planningCosts}
                  onChange={(e) => handleFieldChange('planningCosts', parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Professional Fees & Engineering Design</label>
                <input
                  type="number"
                  value={project.professionalFees}
                  onChange={(e) => handleFieldChange('professionalFees', parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>
            </div>

            <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-lg border border-slate-100 dark:border-slate-800 space-y-4">
              <h4 className="text-xs font-bold text-slate-900 dark:text-white">Drawdown Phase Schedules</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">EPC Construction Duration</span>
                    <span className="font-bold text-slate-950 dark:text-white">{project.constructionPeriod} Years</span>
                  </div>
                  <input
                    type="range"
                    min="1"
                    max="10"
                    step="1"
                    value={project.constructionPeriod}
                    onChange={(e) => handleFieldChange('constructionPeriod', parseInt(e.target.value))}
                    className="w-full accent-emerald-600"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-600 dark:text-slate-400">Operational Horizon (Concession Term)</span>
                    <span className="font-bold text-slate-950 dark:text-white">{project.projectLife} Years</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="60"
                    step="5"
                    value={project.projectLife}
                    onChange={(e) => handleFieldChange('projectLife', parseInt(e.target.value))}
                    className="w-full accent-emerald-600"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'operations' && (
          <div className="space-y-6">
            <h3 className="text-xs uppercase font-extrabold tracking-wider text-slate-400 flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-2">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              Operational Budgets, Tariffs & Assumptions
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Base Annual Revenues (£m/year)</label>
                <input
                  type="number"
                  value={project.annualRevenue}
                  onChange={(e) => handleFieldChange('annualRevenue', parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Annual Revenue Real Growth Rate (%)</label>
                <input
                  type="number"
                  value={project.annualRevenueGrowth}
                  onChange={(e) => handleFieldChange('annualRevenueGrowth', parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Base Operating Expenses (OPEX - £m/year)</label>
                <input
                  type="number"
                  value={project.operatingCost}
                  onChange={(e) => handleFieldChange('operatingCost', parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Capitalized Maintenance & Refurbishment CAPEX (£m/year)</label>
                <input
                  type="number"
                  value={project.maintenanceCapex}
                  onChange={(e) => handleFieldChange('maintenanceCapex', parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>

              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Terminal Residual Asset Value (£m)</label>
                <input
                  type="number"
                  value={project.residualValue}
                  onChange={(e) => handleFieldChange('residualValue', parseFloat(e.target.value) || 0)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-bold text-slate-900 dark:text-white"
                />
              </div>
            </div>

            {/* Macroeconomic assumption cards */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 bg-slate-50 dark:bg-slate-800/40 p-4 rounded-lg border border-slate-100 dark:border-slate-800">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase">Long-Term Inflation Rate</label>
                <div className="flex items-center gap-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-2.5 py-1">
                  <input
                    type="number"
                    step="0.1"
                    value={project.inflationRate}
                    onChange={(e) => handleFieldChange('inflationRate', parseFloat(e.target.value) || 0)}
                    className="w-full bg-transparent text-xs font-bold text-slate-900 dark:text-white outline-none"
                  />
                  <span className="text-xs font-bold text-slate-400">%</span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase">Hurdle/Social Discount Rate (WACC)</label>
                <div className="flex items-center gap-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-2.5 py-1">
                  <input
                    type="number"
                    step="0.1"
                    value={project.discountRate}
                    onChange={(e) => handleFieldChange('discountRate', parseFloat(e.target.value) || 0)}
                    className="w-full bg-transparent text-xs font-bold text-slate-900 dark:text-white outline-none"
                  />
                  <span className="text-xs font-bold text-slate-400">%</span>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase">Corporate Tax Rate</label>
                <div className="flex items-center gap-1 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded px-2.5 py-1">
                  <input
                    type="number"
                    step="0.5"
                    value={project.taxRate}
                    onChange={(e) => handleFieldChange('taxRate', parseFloat(e.target.value) || 0)}
                    className="w-full bg-transparent text-xs font-bold text-slate-900 dark:text-white outline-none"
                  />
                  <span className="text-xs font-bold text-slate-400">%</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeSection === 'financing' && (
          <div className="space-y-6">
            <h3 className="text-xs uppercase font-extrabold tracking-wider text-slate-400 flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-2">
              <Coins className="w-4 h-4 text-emerald-600" />
              Capital Structure, Leverage & Debt Repayment
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Debt Ratio */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="font-bold text-slate-700 dark:text-slate-300">Total Leverage Ratio (Gearing)</span>
                  <span className="font-extrabold text-slate-950 dark:text-white">{project.debtPercentage}% Debt / {100 - project.debtPercentage}% Equity</span>
                </div>
                <input
                  type="range"
                  min="10"
                  max="90"
                  step="5"
                  value={project.debtPercentage}
                  onChange={(e) => handleFieldChange('debtPercentage', parseInt(e.target.value))}
                  className="w-full accent-emerald-600"
                />
                <p className="text-[10px] text-slate-400">Ratio of senior and junior debt to total development CAPEX.</p>
              </div>

              {/* Debt Repayment Type */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Principal Repayment Profile</label>
                <select
                  value={project.debtType}
                  onChange={(e) => handleFieldChange('debtType', e.target.value)}
                  className="w-full bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-md px-3 py-2 text-xs font-semibold text-slate-900 dark:text-white outline-none focus:border-emerald-500"
                >
                  <option value="Straight-Line">Straight Line (Equal Principal)</option>
                  <option value="Annuity">Annuity Mortgage Style (Constant Debt Service)</option>
                  <option value="Sculpted">Sculpted to Cash Flow (Custom DSCR 1.35 Target)</option>
                  <option value="Bullet">Bullet Payment (Repaid in full at Maturity)</option>
                </select>
                <p className="text-[10px] text-slate-400">Determines senior debt amortization styling.</p>
              </div>

              {/* Senior Interest Rate */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Senior Debt Interest Cost (Coupon)</label>
                <div className="flex items-center gap-1 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded px-2.5 py-2">
                  <input
                    type="number"
                    step="0.1"
                    value={project.interestRate}
                    onChange={(e) => handleFieldChange('interestRate', parseFloat(e.target.value) || 0)}
                    className="w-full bg-transparent text-xs font-bold text-slate-900 dark:text-white outline-none"
                  />
                  <span className="text-xs font-bold text-slate-400">%</span>
                </div>
              </div>

              {/* Junior Interest Rate */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold text-slate-700 dark:text-slate-300">Mezzanine / Junior Debt Coupon Cost</label>
                <div className="flex items-center gap-1 bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded px-2.5 py-2">
                  <input
                    type="number"
                    step="0.1"
                    value={project.juniorDebtInterestRate}
                    onChange={(e) => handleFieldChange('juniorDebtInterestRate', parseFloat(e.target.value) || 0)}
                    className="w-full bg-transparent text-xs font-bold text-slate-900 dark:text-white outline-none"
                  />
                  <span className="text-xs font-bold text-slate-400">%</span>
                </div>
              </div>
            </div>

            {/* Custom Ratios Mix */}
            <div className="bg-slate-50 dark:bg-slate-800/40 p-4 rounded-lg border border-slate-100 dark:border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-bold text-slate-900 dark:text-white">Financing Tranches Allocation % of Debt</h4>
                <span className="text-[10px] font-extrabold text-slate-400 bg-slate-200 dark:bg-slate-800 px-2 py-0.5 rounded">SUM MUST EQUAL 100%</span>
              </div>
              
              <div className="grid grid-cols-1 sm:grid-cols-5 gap-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500">Senior Term Debt</label>
                  <input
                    type="number"
                    value={project.financingMix.seniorDebt}
                    onChange={(e) => handleFinancingChange('seniorDebt', parseInt(e.target.value) || 0)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-xs font-bold p-1.5 text-center"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500">Junior Mezzanine</label>
                  <input
                    type="number"
                    value={project.financingMix.juniorDebt}
                    onChange={(e) => handleFinancingChange('juniorDebt', parseInt(e.target.value) || 0)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-xs font-bold p-1.5 text-center"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500">Private Equity</label>
                  <input
                    type="number"
                    value={project.financingMix.equity}
                    onChange={(e) => handleFinancingChange('equity', parseInt(e.target.value) || 0)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-xs font-bold p-1.5 text-center"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500">State co-equity</label>
                  <input
                    type="number"
                    value={project.financingMix.govEquity}
                    onChange={(e) => handleFinancingChange('govEquity', parseInt(e.target.value) || 0)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-xs font-bold p-1.5 text-center"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500">Green Bonds</label>
                  <input
                    type="number"
                    value={project.financingMix.greenBonds}
                    onChange={(e) => handleFinancingChange('greenBonds', parseInt(e.target.value) || 0)}
                    className="w-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded text-xs font-bold p-1.5 text-center"
                  />
                </div>
              </div>

              {/* Total Balance Check */}
              {(() => {
                const total = project.financingMix.seniorDebt + project.financingMix.juniorDebt + project.financingMix.equity + project.financingMix.govEquity + project.financingMix.greenBonds;
                const isCorrect = total === 100;
                return (
                  <div className={`text-[10px] font-bold px-3 py-1.5 rounded flex items-center gap-1.5 ${
                    isCorrect ? 'bg-emerald-50 dark:bg-emerald-950/20 text-emerald-600' : 'bg-amber-50 dark:bg-amber-950/20 text-amber-600'
                  }`}>
                    {isCorrect ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        Financing tranche sum matches 100% perfectly.
                      </>
                    ) : (
                      <>
                        <AlertTriangle className="w-3.5 h-3.5 animate-pulse" />
                        Tranches total equals {total}%. Scale values to ensure exact 100% distribution prior to committee approval.
                      </>
                    )}
                  </div>
                );
              })()}
            </div>
          </div>
        )}

        {activeSection === 'multipliers' && (
          <div className="space-y-6">
            <h3 className="text-xs uppercase font-extrabold tracking-wider text-slate-400 flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-2">
              <Settings className="w-4 h-4 text-emerald-600" />
              Socio-Economic GVA Multipliers (Dynamic Assumptions)
            </h3>
            <p className="text-xs text-slate-500">
              Customize local economic multiplier coefficients based on Treasury Green Book guidelines or regional econometric evaluations.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Multiplier 1 */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Construction Multiplier (GVA)</span>
                  <span className="font-bold text-slate-950 dark:text-white">x{project.multipliers.construction}</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="3.0"
                  step="0.05"
                  value={project.multipliers.construction}
                  onChange={(e) => handleMultiplierChange('construction', parseFloat(e.target.value))}
                  className="w-full accent-emerald-600"
                />
                <p className="text-[10px] text-slate-400">Measures raw construction expenditure spillover into local material suppliers and services.</p>
              </div>

              {/* Multiplier 2 */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Generic Infrastructure Multiplier</span>
                  <span className="font-bold text-slate-950 dark:text-white">x{project.multipliers.infrastructure}</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="3.0"
                  step="0.05"
                  value={project.multipliers.infrastructure}
                  onChange={(e) => handleMultiplierChange('infrastructure', parseFloat(e.target.value))}
                  className="w-full accent-emerald-600"
                />
              </div>

              {/* Multiplier 3 */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Housing Supply Stimulus Multiplier</span>
                  <span className="font-bold text-slate-950 dark:text-white">x{project.multipliers.housing}</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="3.0"
                  step="0.05"
                  value={project.multipliers.housing}
                  onChange={(e) => handleMultiplierChange('housing', parseFloat(e.target.value))}
                  className="w-full accent-emerald-600"
                />
              </div>

              {/* Multiplier 4 */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Transport Agglomeration Multiplier</span>
                  <span className="font-bold text-slate-950 dark:text-white">x{project.multipliers.transport}</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="4.0"
                  step="0.05"
                  value={project.multipliers.transport}
                  onChange={(e) => handleMultiplierChange('transport', parseFloat(e.target.value))}
                  className="w-full accent-emerald-600"
                />
              </div>

              {/* Multiplier 5 */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Energy Security Multiplier</span>
                  <span className="font-bold text-slate-950 dark:text-white">x{project.multipliers.energy}</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="4.0"
                  step="0.05"
                  value={project.multipliers.energy}
                  onChange={(e) => handleMultiplierChange('energy', parseFloat(e.target.value))}
                  className="w-full accent-emerald-600"
                />
              </div>

              {/* Multiplier 6 */}
              <div className="space-y-1">
                <div className="flex justify-between text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Digital Density Multiplier</span>
                  <span className="font-bold text-slate-950 dark:text-white">x{project.multipliers.digital}</span>
                </div>
                <input
                  type="range"
                  min="1.0"
                  max="5.0"
                  step="0.1"
                  value={project.multipliers.digital}
                  onChange={(e) => handleMultiplierChange('digital', parseFloat(e.target.value))}
                  className="w-full accent-emerald-600"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
