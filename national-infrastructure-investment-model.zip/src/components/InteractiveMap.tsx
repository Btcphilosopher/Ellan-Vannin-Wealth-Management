/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  MapPin, 
  Map, 
  Layers, 
  TrendingUp, 
  Coins, 
  Cpu, 
  Compass, 
  Info,
  CheckCircle2,
  Clock,
  ExternalLink
} from 'lucide-react';
import { ProjectInputs, FinancialOutputs, EconomicOutputs } from '../types';
import { UK_REGIONS, ASSET_CLASS_PRESETS } from '../constants';

interface InteractiveMapProps {
  projects: ProjectInputs[];
  projectFinancials: Record<string, FinancialOutputs>;
  projectEconomics: Record<string, EconomicOutputs>;
  selectedProjectId: string | null;
  onSelectProject: (id: string) => void;
  darkMode: boolean;
}

export default function InteractiveMap({
  projects,
  projectFinancials,
  projectEconomics,
  selectedProjectId,
  onSelectProject,
  darkMode
}: InteractiveMapProps) {
  const [hoveredProjectId, setHoveredProjectId] = useState<string | null>(null);

  const activeProject = projects.find(p => p.id === (selectedProjectId || projects[0]?.id));
  const activeFin = activeProject ? projectFinancials[activeProject.id] : null;
  const activeEco = activeProject ? projectEconomics[activeProject.id] : null;

  // Render regional polygons in our beautiful bespoke vector outline of GBR & IRL.
  // We'll define simple representative path centers or circles for UK regions on a 400x700 map coordinate system.
  const regionPins = Object.entries(UK_REGIONS).map(([name, data]) => ({
    name,
    ...data
  }));

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
      {/* Left Column: Geographic Vector Map (lg:col-span-7) */}
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-6 lg:col-span-7 flex flex-col justify-between min-h-[580px]">
        <div>
          <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-3 mb-4">
            <Map className="w-4 h-4 text-emerald-600" />
            National Asset Geographic GIS Map
          </h3>
          <p className="text-xs text-slate-500">
            Interactive geographic map of the United Kingdom, Ireland, and the Isle of Man. Click nodes to load financial profiles.
          </p>
        </div>

        {/* Map Stage Container */}
        <div className="relative w-full h-[480px] bg-slate-50 dark:bg-slate-950/40 rounded-lg flex items-center justify-center border border-slate-100 dark:border-slate-800/60 p-4 mt-4 overflow-hidden select-none">
          <svg
            viewBox="0 0 400 700"
            className="w-full h-full max-h-[460px] max-w-[340px]"
            xmlns="http://www.w3.org/2000/svg"
          >
            {/* Vector Base: Great Britain & Ireland Coastline Outlines (Stylized) */}
            {/* Scotland Outline */}
            <path
              d="M 120 40 L 220 20 L 280 80 L 260 140 L 210 180 L 160 170 L 120 120 Z"
              fill={darkMode ? '#1e293b' : '#f1f5f9'}
              stroke={darkMode ? '#334155' : '#cbd5e1'}
              strokeWidth="1.5"
              className="transition-colors duration-200"
            />
            {/* England & Wales Outline */}
            <path
              d="M 160 170 L 210 180 L 240 220 L 290 240 L 310 320 L 330 380 L 370 480 L 380 560 L 320 620 L 260 620 L 190 640 L 140 600 L 120 540 L 150 490 L 140 440 L 170 380 L 160 300 L 150 220 Z"
              fill={darkMode ? '#1e293b' : '#f1f5f9'}
              stroke={darkMode ? '#334155' : '#cbd5e1'}
              strokeWidth="1.5"
              className="transition-colors duration-200"
            />
            {/* Ireland Outline */}
            <path
              d="M 40 240 L 110 230 L 130 280 L 120 360 L 70 420 L 30 370 L 20 300 Z"
              fill={darkMode ? '#0f172a' : '#f8fafc'}
              stroke={darkMode ? '#1e293b' : '#e2e8f0'}
              strokeWidth="1.5"
              strokeDasharray="4 4"
            />
            
            {/* Regional Outline Boundaries Label Indicators */}
            {regionPins.map((reg) => {
              const hasProjectsInRegion = projects.some(p => p.region === reg.name);
              return (
                <text
                  key={reg.name}
                  x={reg.x}
                  y={reg.y + 16}
                  fontSize="8"
                  fontWeight="bold"
                  textAnchor="middle"
                  className={`${
                    hasProjectsInRegion 
                      ? 'fill-emerald-600 dark:fill-emerald-400 opacity-60' 
                      : 'fill-slate-400 dark:fill-slate-600 opacity-30'
                  }`}
                >
                  {reg.name === 'Yorkshire & Humber' ? 'Yorkshire' : reg.name}
                </text>
              );
            })}

            {/* Plot Active Project Pin Nodes */}
            {projects.map((project) => {
              const regionData = UK_REGIONS[project.region];
              if (!regionData) return null;

              // Apply a small scatter displacement to prevent exact overlaps if multiple projects are in the same region
              const indexInRegion = projects.filter(p => p.region === project.region).indexOf(project);
              const dx = indexInRegion * 12 - 10;
              const dy = indexInRegion * -10 + 5;
              
              const px = regionData.x + dx;
              const py = regionData.y + dy;
              
              const isSelected = project.id === selectedProjectId;
              const isHovered = project.id === hoveredProjectId;

              const category = ASSET_CLASS_PRESETS[project.assetType]?.category || 'Other';
              const pinColor = category === 'Energy' 
                ? '#10b981' // Green
                : category === 'Transport' 
                  ? '#3b82f6' // Blue
                  : category === 'Digital & Tech' 
                    ? '#8b5cf6' // Purple
                    : '#eab308'; // Amber

              return (
                <g
                  key={project.id}
                  className="cursor-pointer"
                  onClick={() => onSelectProject(project.id)}
                  onMouseEnter={() => setHoveredProjectId(project.id)}
                  onMouseLeave={() => setHoveredProjectId(null)}
                >
                  {/* Ripple Effect ring for selected or hovered nodes */}
                  {(isSelected || isHovered) && (
                    <circle
                      cx={px}
                      cy={py}
                      r={16}
                      fill={pinColor}
                      fillOpacity="0.15"
                      className="animate-ping"
                    />
                  )}

                  {/* Outer circle halo */}
                  <circle
                    cx={px}
                    cy={py}
                    r={isSelected ? 8 : 6}
                    fill={isSelected ? '#ffffff' : pinColor}
                    stroke={pinColor}
                    strokeWidth={isSelected ? 3.5 : 2}
                    className="transition-all duration-150"
                  />

                  {/* Inner center dot */}
                  <circle
                    cx={px}
                    cy={py}
                    r={isSelected ? 3.5 : 2.5}
                    fill={isSelected ? pinColor : '#ffffff'}
                  />
                </g>
              );
            })}
          </svg>

          {/* Hover Floating Tooltip */}
          {hoveredProjectId && (() => {
            const hProj = projects.find(p => p.id === hoveredProjectId);
            const hRegion = hProj ? UK_REGIONS[hProj.region] : null;
            if (!hProj || !hRegion) return null;
            return (
              <div 
                className="absolute bg-slate-900 border border-slate-700 text-white rounded p-3 text-[10px] space-y-1 shadow-md pointer-events-none"
                style={{
                  bottom: '20px',
                  left: '20px'
                }}
              >
                <div className="font-extrabold text-xs">{hProj.name}</div>
                <div className="text-slate-400 font-semibold">{hProj.assetType} • {hProj.region}</div>
                <div className="flex justify-between gap-6 pt-1 border-t border-slate-800">
                  <span>CAPEX:</span>
                  <span className="font-bold">£{hProj.constructionCost}m</span>
                </div>
                <div className="flex justify-between gap-6">
                  <span>Levered IRR:</span>
                  <span className="font-bold text-emerald-400">{projectFinancials[hProj.id]?.leveredIrr}%</span>
                </div>
              </div>
            );
          })()}
        </div>
      </div>

      {/* Right Column: Portfolio Side Ledger Panel (lg:col-span-5) */}
      <div className="space-y-6 lg:col-span-5 flex flex-col justify-between">
        {/* Scorecard */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-sm p-5 space-y-4">
          <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-2">
            <Layers className="w-4 h-4 text-emerald-600" />
            Selected Asset GIS Profile
          </h4>

          {activeProject ? (
            <div className="space-y-5">
              <div>
                <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                  activeProject.status === 'Operational' 
                    ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400'
                    : 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400'
                }`}>
                  {activeProject.status === 'Operational' ? <CheckCircle2 className="w-3 h-3" /> : <Clock className="w-3 h-3" />}
                  {activeProject.status}
                </span>
                <h3 className="text-base font-bold text-slate-900 dark:text-white mt-1.5 leading-snug">
                  {activeProject.name}
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Asset Class: <strong className="text-slate-600 dark:text-slate-300 font-bold">{activeProject.assetType}</strong> in <strong className="text-slate-600 dark:text-slate-300 font-bold">{activeProject.region}</strong>
                </p>
              </div>

              {/* Dials & Metrics Ledger */}
              <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-100 dark:border-slate-800">
                <div className="space-y-0.5 bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded border border-slate-100/60 dark:border-slate-800/60">
                  <span className="text-[9px] uppercase font-bold text-slate-400">Committed CAPEX</span>
                  <p className="text-sm font-bold text-slate-900 dark:text-white">£{activeProject.constructionCost.toLocaleString()}m</p>
                </div>

                <div className="space-y-0.5 bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded border border-slate-100/60 dark:border-slate-800/60">
                  <span className="text-[9px] uppercase font-bold text-emerald-600 dark:text-emerald-400">Levered IRR</span>
                  <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{activeFin ? `${activeFin.leveredIrr}%` : 'N/A'}</p>
                </div>

                <div className="space-y-0.5 bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded border border-slate-100/60 dark:border-slate-800/60">
                  <span className="text-[9px] uppercase font-bold text-slate-400">Supported Jobs</span>
                  <p className="text-sm font-bold text-slate-900 dark:text-white">{activeEco ? activeEco.totalJobsSupported.toLocaleString() : 'N/A'} FTE</p>
                </div>

                <div className="space-y-0.5 bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded border border-slate-100/60 dark:border-slate-800/60">
                  <span className="text-[9px] uppercase font-bold text-slate-400">GVA GDP Impact</span>
                  <p className="text-sm font-bold text-slate-900 dark:text-white">£{activeEco ? activeEco.totalGdpImpact.toLocaleString() : 'N/A'}m</p>
                </div>
              </div>

              {/* Environmental Carbon net abatement */}
              {activeEco && activeEco.carbonSaved !== 0 && (
                <div className={`p-3 rounded-md flex items-start gap-2.5 ${
                  activeEco.carbonSaved > 0 
                    ? 'bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 text-emerald-800 dark:text-emerald-400'
                    : 'bg-red-50 dark:bg-red-950/20 border border-red-100 dark:border-red-900/30 text-red-800 dark:text-red-400'
                }`}>
                  <Compass className="w-4 h-4 shrink-0 mt-0.5" />
                  <div className="text-[11px] leading-tight font-medium">
                    {activeEco.carbonSaved > 0 ? (
                      <>
                        Abating <strong className="font-extrabold">{activeEco.carbonSaved.toLocaleString()} tonnes CO₂e/year</strong> over operating concession lifespan, contributing to regional net-zero obligations.
                      </>
                    ) : (
                      <>
                        Generating <strong className="font-extrabold">{Math.abs(activeEco.carbonSaved).toLocaleString()} tonnes CO₂e/year</strong> of net construction emissions, subject to biodiversity offsets.
                      </>
                    )}
                  </div>
                </div>
              )}

              {/* Concession summary details */}
              <div className="space-y-2 text-[11px] text-slate-500 border-t border-slate-100 dark:border-slate-800 pt-3">
                <div className="flex justify-between">
                  <span>EPC Construction Period:</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">{activeProject.constructionPeriod} Years</span>
                </div>
                <div className="flex justify-between">
                  <span>Operating Life Span:</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">{activeProject.projectLife} Years</span>
                </div>
                <div className="flex justify-between">
                  <span>Annual Operating Cost:</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">£{activeProject.operatingCost}m/year</span>
                </div>
                <div className="flex justify-between">
                  <span>Annuity Debt Repayment:</span>
                  <span className="font-bold text-slate-700 dark:text-slate-300">{activeProject.debtType} Profile ({activeProject.debtPercentage}% Gearing)</span>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-xs text-slate-400">
              No project loaded. Select a map node.
            </div>
          )}
        </div>

        {/* Aggregate Geographic Exposure Ledger */}
        <div className="bg-slate-900 border border-slate-800 text-slate-300 rounded-xl shadow-sm p-5 space-y-4">
          <h4 className="text-[10px] uppercase font-bold text-slate-400 tracking-wider flex items-center gap-1.5 border-b border-slate-800 pb-2">
            <Info className="w-4 h-4 text-emerald-500" />
            Ellan Vannin Regional Scorecard
          </h4>
          <div className="space-y-3 text-xs">
            <div className="flex justify-between items-center text-[11px] border-b border-slate-800/60 pb-1.5">
              <span className="text-slate-400">Isle of Man Green Capital:</span>
              <span className="font-bold text-white">£650m Allocated</span>
            </div>
            <div className="flex justify-between items-center text-[11px] border-b border-slate-800/60 pb-1.5">
              <span className="text-slate-400">Scotland Tech & Compute:</span>
              <span className="font-bold text-white">£800m Allocated</span>
            </div>
            <div className="flex justify-between items-center text-[11px] border-b border-slate-800/60 pb-1.5">
              <span className="text-slate-400">Wales Wind & Ocean Yield:</span>
              <span className="font-bold text-white">£1,650m Allocated</span>
            </div>
            <p className="text-[9px] text-slate-500 italic mt-2 leading-snug">
              *All valuations represent institutional allocations by Ellan Vannin Wealth Management Group under Treasury compliance guidelines.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
