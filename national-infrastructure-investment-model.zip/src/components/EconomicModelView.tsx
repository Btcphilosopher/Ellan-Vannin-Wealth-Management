/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Compass, 
  Cpu, 
  Shield, 
  HelpCircle,
  TrendingUp,
  Coins,
  Activity,
  Users,
  Briefcase
} from 'lucide-react';
import { ProjectInputs, EconomicOutputs } from '../types';
import { ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Cell, PieChart, Pie, Legend } from 'recharts';

interface EconomicModelViewProps {
  project: ProjectInputs;
  economics: EconomicOutputs;
  darkMode: boolean;
}

type EconSubTab = 'gdp' | 'labor' | 'tax';

export default function EconomicModelView({
  project,
  economics,
  darkMode
}: EconomicModelViewProps) {
  const [subTab, setSubTab] = useState<EconSubTab>('gdp');

  // Sector colors
  const COLOR_PALETTE = ['#0f172a', '#10b981', '#3b82f6', '#8b5cf6', '#f59e0b', '#ec4899'];

  // GDP Breakdown for Recharts
  const gdpWaterfallData = [
    { name: 'Construction GVA', value: economics.constructionGdp, fill: '#0f172a' },
    { name: 'Supply Chain GVA', value: economics.supplyChainGdp, fill: '#3b82f6' },
    { name: 'Direct Operations GVA', value: economics.permanentGdp * project.projectLife, fill: '#10b981' },
    { name: 'Productivity Agglomeration', value: economics.agglomerationGdp * project.projectLife, fill: '#8b5cf6' }
  ];

  // Labor Breakdown
  const laborData = [
    { name: 'Construction FTE', value: economics.constructionJobs, fill: '#0f172a' },
    { name: 'Permanent Operators', value: economics.permanentJobs, fill: '#10b981' },
    { name: 'Indirect Suppliers', value: economics.indirectJobs, fill: '#3b82f6' },
    { name: 'Induced Spend FTE', value: economics.inducedJobs, fill: '#f59e0b' }
  ];

  // Tax Breakdown
  const taxData = [
    { name: 'Corporation Tax', value: economics.corporationTax, fill: '#0f172a' },
    { name: 'Employment Income Tax', value: economics.incomeTax, fill: '#3b82f6' },
    { name: 'VAT Generation', value: economics.vat, fill: '#10b981' },
    { name: 'Commercial Business Rates', value: economics.businessRates, fill: '#8b5cf6' },
    { name: 'Council Tax', value: economics.councilTax, fill: '#ec4899' }
  ];

  return (
    <div className="space-y-6">
      {/* Selector tab bar */}
      <div className="flex border-b border-slate-200 dark:border-slate-800 pb-px gap-4 overflow-x-auto no-scrollbar">
        <button
          onClick={() => setSubTab('gdp')}
          className={`py-2 px-3 text-xs font-bold border-b-2 cursor-pointer transition-all whitespace-nowrap flex items-center gap-1.5 ${
            subTab === 'gdp' 
              ? 'border-emerald-600 text-slate-900 dark:text-white font-extrabold' 
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Compass className="w-4 h-4" />
          GDP GVA Impact
        </button>
        <button
          onClick={() => setSubTab('labor')}
          className={`py-2 px-3 text-xs font-bold border-b-2 cursor-pointer transition-all whitespace-nowrap flex items-center gap-1.5 ${
            subTab === 'labor' 
              ? 'border-emerald-600 text-slate-900 dark:text-white font-extrabold' 
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Cpu className="w-4 h-4" />
          Labor & Supported Jobs
        </button>
        <button
          onClick={() => setSubTab('tax')}
          className={`py-2 px-3 text-xs font-bold border-b-2 cursor-pointer transition-all whitespace-nowrap flex items-center gap-1.5 ${
            subTab === 'tax' 
              ? 'border-emerald-600 text-slate-900 dark:text-white font-extrabold' 
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Shield className="w-4 h-4" />
          Treasury Taxation Receipts
        </button>
      </div>

      {subTab === 'gdp' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Chart */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-xl shadow-sm lg:col-span-8 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-3 mb-4">
                <Compass className="w-4 h-4 text-emerald-600" />
                Lifecycle Gross Value Added (GVA) Impact Analysis
              </h3>
              <p className="text-xs text-slate-500">
                Total socio-economic stimulus over the operational concession lifespan, including direct construction outlays and productivity clusters.
              </p>
            </div>

            <div className="h-64 mt-6">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={gdpWaterfallData} margin={{ top: 10, bottom: 5, left: 10, right: 10 }}>
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <Tooltip 
                    cursor={{ fill: 'rgba(148, 163, 184, 0.05)' }}
                    contentStyle={{ backgroundColor: darkMode ? '#0f172a' : '#ffffff', borderColor: '#e2e8f0' }}
                    itemStyle={{ fontSize: 11 }}
                  />
                  <Bar dataKey="value" fill="#10b981" radius={[4, 4, 0, 0]}>
                    {gdpWaterfallData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Ledger */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm space-y-4">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 dark:border-slate-800 pb-2">
                Aggregate GVA Scorecard
              </h4>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between text-xs border-b border-slate-50 dark:border-slate-800/60 pb-1.5">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Total Lifecycle GVA:</span>
                  <span className="font-extrabold text-slate-900 dark:text-white">£{economics.totalGdpImpact.toLocaleString()}m</span>
                </div>
                <div className="flex items-center justify-between text-xs border-b border-slate-50 dark:border-slate-800/60 pb-1.5">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Construction GVA:</span>
                  <span className="font-bold text-slate-900 dark:text-white">£{economics.constructionGdp.toLocaleString()}m</span>
                </div>
                <div className="flex items-center justify-between text-xs border-b border-slate-50 dark:border-slate-800/60 pb-1.5">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Supply Chain Indirect GVA:</span>
                  <span className="font-bold text-slate-900 dark:text-white">£{economics.supplyChainGdp.toLocaleString()}m</span>
                </div>
                <div className="flex items-center justify-between text-xs border-b border-slate-50 dark:border-slate-800/60 pb-1.5">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Annual Operational GVA:</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">£{economics.permanentGdp.toLocaleString()}m/year</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Annual Agglomeration GVA:</span>
                  <span className="font-bold text-slate-950 dark:text-white">£{economics.agglomerationGdp.toLocaleString()}m/year</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {subTab === 'labor' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Chart */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-xl shadow-sm lg:col-span-8 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-3 mb-4">
                <Users className="w-4 h-4 text-emerald-600" />
                Employment and Supported FTE Job Distribution
              </h3>
              <p className="text-xs text-slate-500">
                Quantified direct operational employees, EPC construction labor, and indirect supply/consumer spending ripples.
              </p>
            </div>

            <div className="h-64 mt-6">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={laborData} margin={{ top: 10, bottom: 5, left: 10, right: 10 }}>
                  <XAxis dataKey="name" stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <YAxis stroke="#94a3b8" fontSize={10} tickLine={false} />
                  <Tooltip 
                    cursor={{ fill: 'rgba(148, 163, 184, 0.05)' }}
                    contentStyle={{ backgroundColor: darkMode ? '#0f172a' : '#ffffff', borderColor: '#e2e8f0' }}
                    itemStyle={{ fontSize: 11 }}
                  />
                  <Bar dataKey="value" fill="#3b82f6" radius={[4, 4, 0, 0]}>
                    {laborData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.fill} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Ledger / Skill mix */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm space-y-4">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 dark:border-slate-800 pb-2">
                Supported Labor Summary
              </h4>
              
              <div className="space-y-3.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Total Supported Workers:</span>
                  <span className="font-extrabold text-slate-900 dark:text-white">{economics.totalJobsSupported.toLocaleString()} FTE</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">EPC Construction Jobs:</span>
                  <span className="font-bold text-slate-900 dark:text-white">{economics.constructionJobs.toLocaleString()} FTE</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Direct Operators:</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">{economics.permanentJobs.toLocaleString()} FTE</span>
                </div>
              </div>
            </div>

            {/* Proportional Skill Mix */}
            <div className="bg-slate-900 border border-slate-800 text-slate-300 rounded-xl shadow-sm p-5 space-y-4">
              <h4 className="text-[10px] uppercase font-bold text-slate-400 tracking-wider border-b border-slate-800 pb-2">
                Labor Skill Matrix Mix
              </h4>
              <div className="space-y-2.5 text-[11px]">
                <div className="space-y-1">
                  <div className="flex justify-between text-slate-400">
                    <span>Engineers & Tech Specialists:</span>
                    <span className="font-bold">25%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 rounded-full" style={{ width: '25%' }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-slate-400">
                    <span>Industrial Trades & Operators:</span>
                    <span className="font-bold">40%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 rounded-full" style={{ width: '40%' }} />
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex justify-between text-slate-400">
                    <span>Supply chain logistics:</span>
                    <span className="font-bold">20%</span>
                  </div>
                  <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div className="h-full bg-emerald-500 rounded-full" style={{ width: '20%' }} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {subTab === 'tax' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Chart */}
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-6 rounded-xl shadow-sm lg:col-span-8 flex flex-col justify-between">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-1.5 border-b border-slate-100 dark:border-slate-800/60 pb-3 mb-4">
                <Coins className="w-4 h-4 text-emerald-600" />
                Treasury Tax Revenue Distributions (£ Millions)
              </h3>
              <p className="text-xs text-slate-500">
                Detailed breakdown of long-term tax receipts returned to central and regional government treasuries over the concession.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-8 py-4">
              <div className="w-48 h-48 shrink-0 relative flex items-center justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={taxData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={3}
                      dataKey="value"
                    >
                      {taxData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLOR_PALETTE[index % COLOR_PALETTE.length]} />
                      ))}
                    </Pie>
                  </PieChart>
                </ResponsiveContainer>
                <div className="absolute flex flex-col items-center justify-center text-center">
                  <span className="text-lg font-bold text-slate-900 dark:text-white">
                    £{economics.totalTaxGenerated.toFixed(0)}m
                  </span>
                  <span className="text-[9px] text-slate-400 font-bold uppercase tracking-wider">
                    Total Tax
                  </span>
                </div>
              </div>

              <div className="flex-1 space-y-2 w-full">
                {taxData.map((item, index) => {
                  const percent = ((item.value / (economics.totalTaxGenerated + 1e-9)) * 100).toFixed(1);
                  return (
                    <div key={item.name} className="flex items-center justify-between text-xs border-b border-slate-50 dark:border-slate-800/40 pb-1.5">
                      <div className="flex items-center gap-2">
                        <div 
                          className="w-2.5 h-2.5 rounded-full" 
                          style={{ backgroundColor: COLOR_PALETTE[index % COLOR_PALETTE.length] }}
                        />
                        <span className="font-medium text-slate-700 dark:text-slate-300">{item.name}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-500">
                        <span className="font-semibold text-slate-900 dark:text-white">£{item.value.toFixed(1)}m</span>
                        <span className="text-slate-400">({percent}%)</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Ledger */}
          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 p-5 rounded-xl shadow-sm space-y-4">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest border-b border-slate-100 dark:border-slate-800 pb-2">
                Treasury Receipts Scorecard
              </h4>
              
              <div className="space-y-3.5">
                <div className="flex items-center justify-between text-xs border-b border-slate-50 dark:border-slate-800/60 pb-1.5">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Total Tax Generated:</span>
                  <span className="font-extrabold text-emerald-600 dark:text-emerald-400">£{economics.totalTaxGenerated.toLocaleString()}m</span>
                </div>
                <div className="flex items-center justify-between text-xs border-b border-slate-50 dark:border-slate-800/60 pb-1.5">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Corporation Tax Receipts:</span>
                  <span className="font-bold text-slate-900 dark:text-white">£{economics.corporationTax.toLocaleString()}m</span>
                </div>
                <div className="flex items-center justify-between text-xs border-b border-slate-50 dark:border-slate-800/60 pb-1.5">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Labor Income Tax & NI:</span>
                  <span className="font-bold text-slate-900 dark:text-white">£{economics.incomeTax.toLocaleString()}m</span>
                </div>
                <div className="flex items-center justify-between text-xs border-b border-slate-50 dark:border-slate-800/60 pb-1.5">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">VAT Generated:</span>
                  <span className="font-bold text-slate-900 dark:text-white">£{economics.vat.toLocaleString()}m</span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-600 dark:text-slate-400">Regional Business Rates:</span>
                  <span className="font-bold text-slate-900 dark:text-white">£{economics.businessRates.toLocaleString()}m</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
