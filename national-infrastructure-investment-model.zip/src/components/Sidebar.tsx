/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  LayoutDashboard,
  FolderTree,
  Coins,
  TrendingUp,
  Briefcase,
  Map,
  FileText,
  Settings,
  Shield,
  Zap,
  Cpu,
  ChevronRight,
  Calculator,
  Compass,
  LineChart,
  Sun,
  Moon
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  selectedProjectId: string | null;
  projectsCount: number;
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
}

export default function Sidebar({
  currentTab,
  setCurrentTab,
  selectedProjectId,
  projectsCount,
  darkMode,
  setDarkMode
}: SidebarProps) {
  const menuGroups = [
    {
      title: 'Navigation',
      items: [
        { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
        { id: 'portfolio', label: 'Asset Portfolio', icon: Briefcase, badge: projectsCount.toString() },
        { id: 'map', label: 'Geographic Map', icon: Map }
      ]
    },
    {
      title: 'Project Appraisal',
      items: [
        { id: 'project-inputs', label: 'Project Inputs', icon: FolderTree },
        { id: 'financial-outputs', label: 'Financial Outputs', icon: Coins },
        { id: 'cash-flow', label: 'Cash Flow Schedule', icon: Calculator }
      ]
    },
    {
      title: 'Macroeconomic Impact',
      items: [
        { id: 'gdp-model', label: 'GDP Forecasting', icon: Compass },
        { id: 'employment-model', label: 'Labor & Employment', icon: Cpu },
        { id: 'tax-model', label: 'Taxation & Revenues', icon: Shield }
      ]
    },
    {
      title: 'Risk & Strategy',
      items: [
        { id: 'sensitivity', label: 'Sensitivity Analysis', icon: LineChart },
        { id: 'monte-carlo', label: 'Monte Carlo Simulation', icon: Zap }
      ]
    },
    {
      title: 'Publish & Deployment',
      items: [
        { id: 'reports', label: 'Investment Reports', icon: FileText },
        { id: 'r-shiny', label: 'R Shiny Bundle', icon: TrendingUp },
        { id: 'settings', label: 'Global Settings', icon: Settings }
      ]
    }
  ];

  return (
    <aside className="w-64 bg-[#0F172A] border-r border-slate-800 text-slate-300 flex flex-col h-screen select-none shrink-0">
      {/* Brand Header */}
      <div className="p-6 border-b border-slate-800 flex flex-col">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 rounded bg-emerald-500 flex items-center justify-center text-white font-extrabold text-sm shadow-sm shrink-0">
            EV
          </div>
          <div className="min-w-0">
            <h1 className="text-xs font-bold tracking-widest text-white uppercase leading-none">
              Ellan Vannin
            </h1>
            <p className="text-[10px] text-slate-500 uppercase font-semibold mt-1 tracking-wider">
              Wealth Management
            </p>
          </div>
        </div>
        <p className="text-[10px] text-slate-400 mt-2 font-medium border-l-2 border-emerald-500 pl-2 leading-tight">
          Infrastructure Investment Model
        </p>
      </div>

      {/* Navigation Groups */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-7 scrollbar-thin scrollbar-thumb-slate-800">
        {menuGroups.map((group, gIdx) => (
          <div key={gIdx} className="space-y-2">
            <span className="text-[10px] uppercase tracking-wider text-slate-500 font-bold px-3">
              {group.title}
            </span>
            <nav className="space-y-1">
              {group.items.map((item) => {
                const IconComponent = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentTab(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-md text-xs font-medium transition-all duration-150 group ${
                      isActive
                        ? 'bg-slate-800 text-white font-semibold shadow-sm'
                        : 'text-slate-400 hover:bg-slate-800/40 hover:text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-2.5">
                      <IconComponent
                        className={`w-4 h-4 shrink-0 transition-transform duration-150 ${
                          isActive ? 'text-emerald-400' : 'text-slate-500 group-hover:text-slate-300'
                        }`}
                      />
                      <span className="truncate">{item.label}</span>
                    </div>
                    {item.badge ? (
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${
                          isActive ? 'bg-slate-700 text-emerald-300' : 'bg-slate-800 text-slate-400'
                        }`}
                      >
                        {item.badge}
                      </span>
                    ) : isActive ? (
                      <ChevronRight className="w-3.5 h-3.5 text-emerald-400" />
                    ) : null}
                  </button>
                );
              })}
            </nav>
          </div>
        ))}
      </div>

      {/* Sidebar Footer */}
      <div className="p-4 border-t border-slate-800 bg-slate-950/40 flex items-center justify-between gap-2">
        <div className="flex items-center gap-2 min-w-0">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0" />
          <div className="min-w-0">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider leading-none">
              SECURE TERMINAL
            </p>
            <p className="text-[11px] text-slate-500 truncate leading-tight mt-0.5">
              Role: Investment Lead
            </p>
          </div>
        </div>
        
        {/* Dark/Light mode toggle */}
        <button
          onClick={() => setDarkMode(!darkMode)}
          title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
          className="p-1.5 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
        >
          {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4 text-indigo-400" />}
        </button>
      </div>
    </aside>
  );
}
