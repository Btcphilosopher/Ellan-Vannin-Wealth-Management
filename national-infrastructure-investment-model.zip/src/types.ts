/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type AssetType =
  | 'Railway'
  | 'Metro'
  | 'Light Rail'
  | 'Port'
  | 'Airport'
  | 'Road'
  | 'Bridge'
  | 'Nuclear Power'
  | 'SMR'
  | 'Offshore Wind'
  | 'Solar Farm'
  | 'Hydrogen Hub'
  | 'Reservoir'
  | 'Water Treatment'
  | 'Forestry'
  | 'Housing'
  | 'Industrial Estate'
  | 'Science Park'
  | 'University Campus'
  | 'Hospital'
  | 'School'
  | 'Data Centre'
  | 'Broadband Networks'
  | 'AI Compute Facility'
  | 'Battery Storage'
  | 'Carbon Capture';

export type ProjectStatus = 'Planning' | 'Under Construction' | 'Operational' | 'Decommissioned';

export type FinancingType = 'Standard' | 'PPP' | 'PFI' | 'Green Bonds' | 'Sovereign Wealth';

export type Region =
  | 'North West'
  | 'North East'
  | 'Yorkshire & Humber'
  | 'East Midlands'
  | 'West Midlands'
  | 'East of England'
  | 'London'
  | 'South East'
  | 'South West'
  | 'Scotland'
  | 'Wales'
  | 'Northern Ireland'
  | 'Isle of Man';

export interface FinancingMix {
  seniorDebt: number; // %
  juniorDebt: number; // %
  equity: number; // %
  govEquity: number; // %
  greenBonds: number; // %
}

export interface EconomicMultipliers {
  construction: number;
  infrastructure: number;
  housing: number;
  transport: number;
  energy: number;
  digital: number;
}

export interface ProjectInputs {
  id: string;
  name: string;
  assetType: AssetType;
  region: Region;
  status: ProjectStatus;
  
  // Phase durations
  constructionPeriod: number; // years (1-10)
  projectLife: number; // operating years (10-60)
  
  // Financial parameters
  constructionCost: number; // £ millions
  landAcquisition: number; // £ millions
  environmentalMitigation: number; // £ millions
  planningCosts: number; // £ millions
  professionalFees: number; // £ millions
  
  operatingCost: number; // £ millions / year
  maintenanceCapex: number; // £ millions / year
  annualRevenue: number; // £ millions / year
  annualRevenueGrowth: number; // % / year
  
  // Economic & Finance assumptions
  inflationRate: number; // % / year
  discountRate: number; // % / year (WACC or Social Discount Rate)
  taxRate: number; // % / year
  residualValue: number; // £ millions
  
  // Debt & Equity parameters
  debtPercentage: number; // Total Debt % of Capex
  interestRate: number; // % / year (senior debt)
  juniorDebtInterestRate: number; // % / year
  debtType: 'Bullet' | 'Straight-Line' | 'Annuity' | 'Sculpted';
  financingMix: FinancingMix;
  
  // Risk adjustments
  costOverrun: number; // % capex increase
  constructionDelay: number; // years delay (0-5)
  riskPremium: number; // % added to discount rate
  
  // Multipliers
  multipliers: EconomicMultipliers;
}

export interface CashFlowYear {
  year: number;
  phase: 'Construction' | 'Operational' | 'Residual';
  
  // Inflows
  revenue: number;
  residualValue: number;
  debtDrawdown: number;
  equityContribution: number;
  
  // Outflows
  capex: number;
  landAcquisition: number;
  environmentalMitigation: number;
  professionalFees: number;
  opex: number;
  maintenanceCapex: number;
  
  // Debt service
  seniorInterest: number;
  seniorPrincipal: number;
  juniorInterest: number;
  juniorPrincipal: number;
  interestDuringConstruction: number;
  
  // Taxes
  taxableIncome: number;
  taxPaid: number;
  
  // Bottom line
  unleveredCashFlow: number;
  leveredCashFlow: number;
  cumulativeUnleveredCashFlow: number;
  cumulativeLeveredCashFlow: number;
  
  // Debt Metrics
  dscr: number; // Debt Service Coverage Ratio
  iscr: number; // Interest Service Coverage Ratio
}

export interface FinancialOutputs {
  unleveredIrr: number;
  leveredIrr: number;
  npv: number;
  unleveredNpv: number;
  roi: number;
  equityMultiple: number;
  paybackPeriod: number;
  averageDscr: number;
  minimumDscr: number;
  averageIscr: number;
  totalRevenue: number;
  totalTaxPaid: number;
  enterpriseValue: number;
  assetValue: number;
}

export interface EconomicOutputs {
  constructionGdp: number; // £m
  permanentGdp: number; // £m / year
  supplyChainGdp: number; // £m
  agglomerationGdp: number; // £m / year
  totalGdpImpact: number; // £m over lifecycle
  
  constructionJobs: number;
  permanentJobs: number;
  indirectJobs: number;
  inducedJobs: number;
  totalJobsSupported: number;
  
  corporationTax: number;
  incomeTax: number;
  vat: number;
  businessRates: number;
  councilTax: number;
  totalTaxGenerated: number;
  
  carbonSaved: number; // Tonnes CO2e / year (positive means carbon reduction, negative means increase)
}

export interface MonteCarloRun {
  simulationId: number;
  capex: number;
  revenue: number;
  npv: number;
  irr: number;
  gdpImpact: number;
  jobsSupported: number;
}

export interface MonteCarloSummary {
  runs: MonteCarloRun[];
  probabilityOfPositiveNpv: number; // %
  probabilityOfTargetIrr: number; // %
  confidenceIntervals: {
    npv: { p10: number; p50: number; p90: number };
    irr: { p10: number; p50: number; p90: number };
  };
  meanNpv: number;
  meanIrr: number;
}

export interface ScenarioDefinition {
  id: string;
  name: string;
  description: string;
  capexMultiplier: number;
  demandMultiplier: number;
  inflationDelta: number;
  interestRateDelta: number;
  delayYears: number;
}
