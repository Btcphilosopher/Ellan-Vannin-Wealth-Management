################################################################################
# Ellan Vannin Wealth Management
# National Infrastructure Investment Model (NIIM) - Master Application
# Production-ready, compatible with Posit Connect / Shiny Server
################################################################################

library(shiny)
library(shinydashboard)
library(bslib)
library(plotly)
library(ggplot2)
library(DT)
library(dplyr)
library(tidyr)
library(shinyWidgets)
library(leaflet)

# Source modular calculation engines
source("R/cashflow_engine.R")
source("R/gdp_model.R")
source("R/monte_carlo.R")

# Central Configuration & Default Assumptions
ASSUMPTIONS <- list(
  inflation = 2.0,
  discount_rate = 6.0,
  tax_rate = 25.0,
  target_dscr = 1.35
)

# 1. UI DEFINITION using bslib and shinydashboard
ui <- dashboardPage(
  skin = "black",
  dashboardHeader(
    title = "Ellan Vannin - NIIM",
    titleWidth = 280
  ),
  dashboardSidebar(
    width = 280,
    sidebarMenu(
      id = "sidebar_menu",
      menuItem("Dashboard Overview", tabName = "dashboard", icon = icon("dashboard")),
      menuItem("Asset Appraisal Workspace", tabName = "appraisal", icon = icon("calculator")),
      menuItem("GDP & Productivity Model", tabName = "gdp", icon = icon("line-chart")),
      menuItem("Monte Carlo Risk Simulator", tabName = "monte_carlo", icon = icon("random")),
      menuItem("National GIS Map", tabName = "map", icon = icon("map-marker")),
      menuItem("Underwriting Reports", tabName = "reports", icon = icon("file-text"))
    )
  ),
  dashboardBody(
    theme = bs_theme(
      bg = "#ffffff", 
      fg = "#0f172a", 
      primary = "#059669", # Emerald
      base_font = font_google("Plus Jakarta Sans")
    ),
    
    tabItems(
      # Overview Dashboard
      tabItem(tabName = "dashboard",
        fluidRow(
          valueBoxOutput("total_investment", width = 3),
          valueBoxOutput("weighted_irr", width = 3),
          valueBoxOutput("combined_npv", width = 3),
          valueBoxOutput("supported_jobs", width = 3)
        ),
        fluidRow(
          box(title = "Diversification by Sector", width = 6, plotlyOutput("sector_pie")),
          box(title = "Geographic Commitments", width = 6, plotlyOutput("regional_bar"))
        )
      ),
      
      # Appraisal inputs & financial statements
      tabItem(tabName = "appraisal",
        sidebarLayout(
          sidebarPanel(
            width = 4,
            textInput("proj_name", "Project Name", "Douglas Green Tidal Barrage"),
            selectInput("asset_type", "Asset Category", choices = c("SMR", "Offshore Wind", "Railway", "Port", "Data Centre")),
            numericInput("capex", "Construction CAPEX (£m)", 650, min = 10),
            sliderInput("debt_pct", "Gearing Ratio (Debt %)", 10, 90, 60),
            numericInput("discount_rate", "WACC Hurdle Rate (%)", 6.0, step = 0.5),
            numericInput("tax_rate", "Corporate Tax Rate (%)", 25.0),
            selectInput("debt_type", "Principal Amortization Style", choices = c("Straight-Line", "Annuity", "Sculpted", "Bullet")),
            actionButton("run_appraisal", "Appraise Asset Model", class = "btn-success w-100")
          ),
          mainPanel(
            width = 8,
            tabsetPanel(
              tabPanel("Financial Outputs Summary", 
                tableOutput("metrics_ledger"),
                plotlyOutput("cash_flow_timeline")
              ),
              tabPanel("Cash Flow Schedule", DTOutput("cashflow_table"))
            )
          )
        )
      ),
      
      # GDP Tab
      tabItem(tabName = "gdp",
        fluidRow(
          box(title = "Multiplier Inputs", width = 4,
            sliderInput("mult_const", "Construction Multiplier", 1.0, 3.0, 1.8),
            sliderInput("mult_infra", "Infrastructure Multiplier", 1.0, 3.0, 2.2)
          ),
          box(title = "GVA GDP Impact Analysis", width = 8,
            plotlyOutput("gdp_waterfall"),
            tableOutput("labor_ledger")
          )
        )
      )
    )
  )
)

# 2. SERVER LOGIC
server <- function(input, output, session) {
  
  # Reactive project appraisal
  appraisal_data <- eventReactive(input$run_appraisal, {
    # Calls sourced modular R engines
    cf <- calculate_cash_flows(
      name = input$proj_name,
      capex = input$capex,
      debt_pct = input$debt_pct,
      debt_style = input$debt_type,
      discount_rate = input$discount_rate,
      tax_rate = input$tax_rate
    )
    
    metrics <- calculate_irr_npv(cf, input$discount_rate)
    
    list(schedule = cf, metrics = metrics)
  }, ignoreNULL = FALSE)
  
  # Render value boxes
  output$weighted_irr <- renderValueBox({
    val <- appraisal_data()$metrics$levered_irr
    valueBox(paste0(round(val, 2), "%"), "Expected Levered IRR", icon = icon("line-chart"), color = "green")
  })
  
  # Render datatable
  output$cashflow_table <- renderDT({
    datatable(appraisal_data()$schedule, options = list(pageLength = 10, scrollX = TRUE))
  })
}

shinyApp(ui, server)
