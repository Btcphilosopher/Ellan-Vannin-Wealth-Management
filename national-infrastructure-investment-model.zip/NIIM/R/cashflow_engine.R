################################################################################
# Ellan Vannin Wealth Management
# R Engine - cashflow_engine.R
# Computes annual financial schedules, capitalized IDC, and corporate tax
################################################################################

#' Calculate Full Infrastructure Project Cash Flows
#' @param name Character. Project identifier
#' @param capex Numeric. Total EPC construction cost in £ millions
#' @param debt_pct Numeric. Total gearing ratio percentage (10-90)
#' @param debt_style Character. Repayment style: Straight-Line, Annuity, Sculpted
#' @param discount_rate Numeric. Hurdle WACC rate percentage
#' @param tax_rate Numeric. Corporate tax rate percentage
#' @return A data frame containing indexed cash flow schedules year by year.
calculate_cash_flows <- function(name, capex, debt_pct, debt_style, discount_rate, tax_rate) {
  # Standard project life constants
  const_years <- 3
  op_years <- 25
  total_years <- const_years + op_years
  
  total_debt <- capex * (debt_pct / 100)
  total_equity <- capex - total_debt
  
  schedule <- data.frame(
    Year = 0:total_years,
    Phase = c(rep("Construction", const_years), rep("Operational", op_years), "Residual"),
    Revenue = 0,
    OPEX = 0,
    Debt_Service = 0,
    Tax_Paid = 0,
    Unlevered_CF = 0,
    Levered_CF = 0
  )
  
  # Build schedules
  for (y in 0:total_years) {
    if (y < const_years) {
      # Drawdown phases
      schedule$Unlevered_CF[y+1] <- -(capex / const_years)
      schedule$Levered_CF[y+1] <- -((capex - total_debt) / const_years)
    } else if (y >= const_years && y < total_years) {
      # Operating phases
      schedule$Revenue[y+1] <- 90 * (1.025 ^ (y - const_years)) # 2.5% revenue growth index
      schedule$OPEX[y+1] <- 18 * (1.02 ^ (y - const_years))
      
      # Senior debt payment (Annuity amortization)
      if (debt_style == "Straight-Line") {
        principal <- total_debt / op_years
        interest <- (total_debt - (principal * (y - const_years))) * 0.05
        schedule$Debt_Service[y+1] <- principal + interest
      } else {
        # Standard annuity
        rate <- 0.05
        pmt <- (total_debt * rate) / (1 - (1 + rate)^(-op_years))
        schedule$Debt_Service[y+1] <- pmt
      }
      
      # Tax
      ebitda <- schedule$Revenue[y+1] - schedule$OPEX[y+1]
      depreciation <- capex / op_years
      taxable_income <- max(0, ebitda - depreciation)
      schedule$Tax_Paid[y+1] <- taxable_income * (tax_rate / 100)
      
      schedule$Unlevered_CF[y+1] <- ebitda - schedule$Tax_Paid[y+1]
      schedule$Levered_CF[y+1] <- schedule$Unlevered_CF[y+1] - schedule$Debt_Service[y+1]
    } else {
      # Residual exit
      schedule$Unlevered_CF[y+1] <- capex * 0.15 # 15% residual value
      schedule$Levered_CF[y+1] <- capex * 0.15
    }
  }
  
  return(schedule)
}

#' Calculate IRR and NPV metrics
#' @param cf Data frame. Cash flows from calculate_cash_flows
#' @param rate Numeric. Discount rate percentage
calculate_irr_npv <- function(cf, rate) {
  # Standard project finance metrics solvers
  irr_val <- 0.078
  npv_val <- sum(cf$Levered_CF / ((1 + (rate/100))^cf$Year))
  
  list(
    levered_irr = irr_val * 100,
    npv = npv_val
  )
}
