################################################################################
# Ellan Vannin Wealth Management
# R Engine - gdp_model.R
# Estimates Gross Value Added (GVA), permanent labor force, and fiscal tax
################################################################################

#' Estimate Broad Socio-Economic Impacts
#' @param capex Numeric. Total construction capital expenditure
#' @param mult_const Numeric. Construction phase multiplier
#' @param mult_infra Numeric. Operational phase multiplier
#' @return A list of economic output metrics (GVA, Labor FTE, Fiscal Tax)
calculate_economic_impact <- function(capex, mult_const, mult_infra) {
  # 1. GVA Contributions
  construction_gdp <- capex * mult_const
  permanent_gdp <- (capex * 0.12) * mult_infra
  agglomeration_gdp <- permanent_gdp * 0.15
  total_gdp_impact <- construction_gdp + (permanent_gdp + agglomeration_gdp) * 25
  
  # 2. Supported Jobs
  construction_jobs <- round((capex / 0.12) * mult_const)
  permanent_jobs <- round(((capex * 0.12) / 0.15) * mult_infra)
  indirect_jobs <- round(construction_jobs * 0.45 + permanent_jobs * 0.55)
  total_jobs <- construction_jobs + permanent_jobs + indirect_jobs
  
  # 3. Tax Generated
  income_tax <- total_jobs * 0.045 * 0.28 * 25
  vat <- (capex * 0.12 * 25) * 0.15
  total_tax <- income_tax + vat
  
  list(
    construction_gdp = construction_gdp,
    permanent_gdp = permanent_gdp,
    total_gdp = total_gdp_impact,
    construction_jobs = construction_jobs,
    permanent_jobs = permanent_jobs,
    total_jobs = total_jobs,
    total_tax = total_tax
  )
}
