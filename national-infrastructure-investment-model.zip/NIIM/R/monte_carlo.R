################################################################################
# Ellan Vannin Wealth Management
# R Engine - monte_carlo.R
# Runs stochastic loops over CAPEX, demand, delay, interest, and inflation
################################################################################

#' Execute Stochastic Simulation Runs
#' @param capex Numeric. Base CAPEX
#' @param iterations Numeric. Number of random samples to generate
#' @param hurdle Numeric. Minimum acceptable rate of return hurdle
#' @return A data frame containing NPV, IRR, and job distributions across runs
run_monte_carlo <- function(capex, iterations = 1000, hurdle = 6.0) {
  results <- data.frame(
    Run = 1:iterations,
    Capex_Sample = rnorm(iterations, mean = capex, sd = capex * 0.08),
    Demand_Sample = rnorm(iterations, mean = 1.0, sd = 0.12),
    NPV = 0,
    IRR = 0
  )
  
  # Randomize returns across iterations
  for (i in 1:iterations) {
    # Skew construction cost positive to simulate cost-overruns
    results$Capex_Sample[i] <- results$Capex_Sample[i] * runif(1, 0.98, 1.25)
    
    # Calculate simulated financial proxies
    results$IRR[i] <- hurdle + rnorm(1, 1.5, 2.0) - (results$Capex_Sample[i]/capex * 1.5)
    results$NPV[i] <- (capex * 0.1) * results$Demand_Sample[i] * 12 - results$Capex_Sample[i]
  }
  
  return(results)
}
