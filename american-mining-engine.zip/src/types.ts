/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface GeologicalBlock {
  id: string;
  coordinates: { x: number; y: number; z: number };
  lithology: string;
  grade: number; // e.g. % for Cu, g/t for Au
  density: number; // t/m3
  contaminants: { sulfur: number; silica: number; phosphorus: number };
  recovery: number; // e.g. 0.85 (85%)
  confidence: "Measured" | "Indicated" | "Inferred" | "Exploration Target";
  tonnage: number;
  economicValue: number; // Net value in USD
}

export interface Mine {
  id: string;
  name: string;
  commodity: string;
  state: string;
  location: { lat: number; lng: number };
  method: "Open Pit" | "Underground Longwall" | "Underground Room & Pillar" | "Block Caving";
  status: "Operational" | "Maintenance" | "Extreme Weather Alert" | "Suspended";
  
  // Real-time Metrics
  productionRate: number; // t/day
  targetProduction: number; // t/day
  headGrade: number; // % or g/t
  recoveryRate: number; // %
  
  // Resources
  fleetSize: number;
  activeTrucks: number;
  workforceCount: number;
  
  // Utilities & Carbon
  energyDemand: number; // MW
  waterConsumption: number; // ML/day
  carbonEmissions: number; // tCO2e/day
  
  // Financials
  revenue: number; // USD/month
  ebitda: number; // USD/month
  opexPerTon: number; // USD/t
  reclamationLiability: number; // USD
}

export interface FleetVehicle {
  id: string;
  mineId: string;
  type: "Haul Truck" | "Shovel" | "Drill" | "Dozor" | "Loader";
  model: string;
  isAutonomous: boolean;
  status: "Loading" | "Hauling" | "Dumping" | "Returning" | "Queueing" | "Charging" | "Maintenance" | "Emergency Stop";
  payload: number; // tons
  maxCapacity: number; // tons
  fuelLevel: number; // % (or State of Charge for electric)
  isElectric: boolean;
  speed: number; // km/h
  engineTemp: number; // °C
  tirePressure: number; // psi
  operatingHours: number;
  position: { x: number; y: number }; // Relative coordinates for dynamic display
  destination: string;
}

export interface ProcessingPlant {
  id: string;
  mineId: string;
  name: string;
  status: "Running" | "Idle" | "Underperforming" | "Bypassed" | "Maintenance";
  feedRate: number; // t/h
  maxCapacity: number; // t/h
  grindingUtilization: number; // %
  flotationRecovery: number; // %
  energyConsumption: number; // MW
  waterRecyclingRate: number; // %
  screenBottleneck: string; // "Primary Screen" | "Secondary Screen" | "Ball Mill" | "None"
}

export interface Stockpile {
  id: string;
  mineId: string;
  name: string;
  tonnage: number;
  maxCapacity: number;
  grade: number;
  moisture: number; // %
  contaminants: { sulfur: number; silica: number };
}

export interface LogisticsRoute {
  id: string;
  mineId: string;
  destination: string;
  type: "Rail" | "Truck" | "Conveyor";
  activeVehicles: number; // active trains/trucks on route
  transitTimeHours: number;
  capacityTonPerDay: number;
  currentFlowRate: number; // t/day
  disruptionLevel: number; // % 0-100 (due to weather/maintenance)
}

export interface EnergyGridState {
  market: "PJM" | "ERCOT" | "MISO" | "SPP" | "CAISO" | "Western Grid";
  electricityPrice: number; // USD/MWh
  demandCharge: number; // USD/kW
  gridCarbonIntensity: number; // kg CO2/MWh
  solarGeneration: number; // MW (company owned solar)
  windGeneration: number; // MW
  batterySOC: number; // %
  batteryCapacityMWh: number;
  batteryStatus: "Charging" | "Discharging" | "Idle";
}

export interface WaterBalance {
  groundwaterInflow: number; // m3/day
  pitWaterAccumulation: number; // m3/day
  reservoirLevel: number; // %
  freshwaterIntake: number; // m3/day
  recycledWater: number; // m3/day
  dischargeRate: number; // m3/day
  floodRisk: "Low" | "Moderate" | "High";
}

export interface WeatherCondition {
  temperature: number; // °C
  precipitation: number; // mm/h
  snowAccumulation: number; // cm
  windSpeed: number; // km/h
  humidity: number; // %
  alert: string | null; // "Heatwave" | "Blizzard" | "Flood Warning" | "Wildfire Smoke" | "None"
}

export interface Incident {
  id: string;
  severity: "Critical" | "High" | "Medium" | "Low";
  location: string;
  mineId: string;
  title: string;
  time: string;
  affectedAssets: string[];
  affectedProduction: number; // Estimated t/day impact
  status: "Active" | "Investigating" | "Resolved";
  resolutionResponse: string;
}

export interface Recommendation {
  id: string;
  title: string;
  what: string;
  why: string;
  impact: string;
  confidence: number; // %
  category: "Production" | "Energy" | "Logistics" | "Maintenance" | "Safety";
  explainability: {
    featuresAnalyzed: string[];
    modelVersion: string;
    trainingPeriod: string;
    keyFactors: { factor: string; weight: number }[];
    dataQualityScore: number; // %
  };
}

export interface MarketState {
  spotPrices: {
    copper: number; // USD/lb
    gold: number; // USD/oz
    lithium: number; // USD/t
    coal: number; // USD/t
    ironOre: number; // USD/t
    rareEarths: number; // USD/kg
  };
  scenarioName: "BASE CASE" | "COMMODITY BOOM" | "COMMODITY CRASH" | "POWER PRICE SHOCK" | "FUEL SHOCK" | "RAIL DISRUPTION" | "EXTREME WEATHER";
}

export interface SimulationState {
  timestamp: number;
  optimizationMode: "MAX PROFIT" | "MIN CARBON" | "BALANCED";
  mines: Mine[];
  fleet: FleetVehicle[];
  processingPlants: ProcessingPlant[];
  stockpiles: Stockpile[];
  logistics: LogisticsRoute[];
  energy: EnergyGridState;
  water: Record<string, WaterBalance>; // Mine ID -> Water Balance
  weather: WeatherCondition;
  incidents: Incident[];
  market: MarketState;
  recommendations: Recommendation[];
  carbonTaxRate: number; // USD/t CO2e
  totalEmissionsThisYear: number; // tCO2e
}
