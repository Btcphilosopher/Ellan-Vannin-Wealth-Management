/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { LogisticsRoute, Mine } from "../types";
import { Train, Truck, ShieldAlert, Navigation, Calendar, ShoppingBag } from "lucide-react";

interface LogisticsModeProps {
  logistics: LogisticsRoute[];
  mines: Mine[];
}

export const LogisticsMode: React.FC<LogisticsModeProps> = ({
  logistics,
  mines
}) => {
  // Fictional Customer contracts matching domestic logistical endpoints
  const customerContracts = [
    { id: "con-1", customer: "Utah Copper Smelter (Kennecott)", mineral: "Copper Concentrates", quantity: "24,000 t/month", price: "Spot - 2% treatment charge", status: "Active Delivery" },
    { id: "con-2", customer: "Gigafactory Tesla Nevada", mineral: "Lithium Carbonate Battery-grade", quantity: "1,200 t/month", price: "Fixed Premium $17,500/t", status: "Buffer Stock Warning" },
    { id: "con-3", customer: "Gary Steel Works Minnesota", mineral: "Pelletized Iron Ore", quantity: "180,000 t/month", price: "Long-term contract $98/t", status: "Active Delivery" },
    { id: "con-4", customer: "Longview Smelter Texas", mineral: "Rare Earth Oxides (REO)", quantity: "340 t/month", price: "Spot - 1.5% premium", status: "Active Delivery" }
  ];

  const totalFlowRate = logistics.reduce((acc, curr) => acc + curr.currentFlowRate, 0);

  return (
    <div id="logistics-mode-container" className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      
      {/* 1. Rail corridors & heavy transport vectors */}
      <div className="col-span-12 lg:col-span-6 border border-white/10 bg-white/5 p-5 rounded-lg flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-3 border-b border-white/5 pb-2">
            <h3 className="text-[10px] uppercase tracking-widest text-white/40 font-bold flex items-center gap-1.5 font-mono">
              <Train className="w-4 h-4 text-[#F27D26]" /> Transcontinental Logistics Corridors
            </h3>
            <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest font-bold">{logistics.length} routes tracked</span>
          </div>
          <p className="text-xs text-white/50 mb-4 font-sans leading-relaxed">
            Real-time tracking of Class I railroads (BNSF, Union Pacific) and bulk haulage corridors routing raw ore concentrates from pits to processing terminals.
          </p>

          <div className="flex flex-col gap-2.5 max-h-[280px] overflow-y-auto pr-1">
            {logistics.map((r) => {
              const mine = mines.find(m => m.id === r.mineId);
              return (
                <div key={r.id} className="bg-[#050608] p-3 rounded-lg border border-white/10 font-mono text-[11px]">
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-bold text-white uppercase">{r.type} Connector - {mine?.name || "Morenci"}</span>
                    <span className="text-[9px] text-white/40">{r.destination}</span>
                  </div>
                  <div className="grid grid-cols-2 gap-2 mt-2 text-[10px] text-white/50">
                    <div>Active Carriers: <span className="text-white/80">{r.activeVehicles} Trains/Trucks</span></div>
                    <div>Transit Time: <span className="text-white/80">{r.transitTimeHours} Hours</span></div>
                    <div>Daily Capacity: <span className="text-white/80">{r.capacityTonPerDay.toLocaleString()} t/d</span></div>
                    <div>Current Flow: <span className="text-[#00FF41] font-bold">{r.currentFlowRate.toLocaleString()} t/d</span></div>
                  </div>
                  {/* Progress bar visual for Capacity */}
                  <div className="mt-2.5">
                    <div className="flex justify-between text-[8px] text-white/30 mb-1">
                      <span>Corridor Congestion Capacity</span>
                      <span>{Math.round((r.currentFlowRate / r.capacityTonPerDay) * 100)}%</span>
                    </div>
                    <div className="h-1.5 w-full bg-[#0A0C10] rounded-full overflow-hidden">
                      <div 
                        className={`h-full rounded-full ${
                          r.disruptionLevel > 50 ? "bg-red-500" : "bg-[#00FF41]"
                        }`}
                        style={{ width: `${Math.min(100, (r.currentFlowRate / r.capacityTonPerDay) * 100)}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-white/5 flex justify-between items-center text-[10px] font-mono text-white/40">
          <span>Daily Ingested Flow Rate:</span>
          <span className="text-white font-bold">{totalFlowRate.toLocaleString()} t/day</span>
        </div>
      </div>

      {/* 2. Domestic customer contract logs */}
      <div className="col-span-12 lg:col-span-6 border border-white/10 bg-white/5 p-5 rounded-lg flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-3 border-b border-white/5 pb-2">
            <h3 className="text-[10px] uppercase tracking-widest text-white/40 font-bold flex items-center gap-1.5 font-mono">
              <ShoppingBag className="w-4 h-4 text-[#F27D26]" /> Commercial Customer Contract Logs
            </h3>
            <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest font-bold">Smelters & Gigafactories</span>
          </div>
          <p className="text-xs text-white/50 mb-4 font-sans leading-relaxed">
            Direct high-value contract commitments showing monthly quantity thresholds, pricing benchmarks, and immediate transport shipping delivery statuses.
          </p>

          <div className="flex flex-col gap-2.5">
            {customerContracts.map((c) => (
              <div key={c.id} className="bg-[#050608] p-3 rounded-lg border border-white/10 font-mono text-[11px] text-white/70">
                <div className="flex justify-between items-center mb-1 border-b border-white/5 pb-1">
                  <span className="font-bold text-white">{c.customer}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase ${
                    c.status === "Buffer Stock Warning" 
                      ? "bg-[#F27D26]/5 text-[#F27D26] border border-[#F27D26]/10" 
                      : "bg-[#00FF41]/5 text-[#00FF41] border border-[#00FF41]/10"
                  }`}>
                    {c.status}
                  </span>
                </div>
                <div className="flex justify-between mt-1.5">
                  <span className="text-white/30">Product Specification:</span>
                  <span className="text-white/90">{c.mineral}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/30">Monthly Contract Rate:</span>
                  <span className="text-white font-bold">{c.quantity}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/30">Benchmark Pricing Terms:</span>
                  <span className="text-[#00FF41] font-bold">{c.price}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#050608] p-3 rounded border border-white/10 text-[9px] text-white/40 font-mono mt-4 leading-normal flex items-start gap-1.5">
          <ShieldAlert className="w-3.5 h-3.5 text-[#F27D26] shrink-0 mt-0.5" />
          <span>
            Contractual Penalty Rule: Failure to deliver gold concentrate within 72 hours of Carlin railway dispatch commits Northstar Mining to a 1.8% delivery price deduction.
          </span>
        </div>
      </div>

    </div>
  );
};
