/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Mine } from "../types";
import { DollarSign, Landmark, BarChart3, ShieldAlert, Award, Compass } from "lucide-react";

interface ExecutiveModeProps {
  mines: Mine[];
  optimizationMode: "MAX PROFIT" | "MIN CARBON" | "BALANCED";
  onChangeMode: (mode: "MAX PROFIT" | "MIN CARBON" | "BALANCED") => void;
}

export const ExecutiveMode: React.FC<ExecutiveModeProps> = ({
  mines,
  optimizationMode,
  onChangeMode
}) => {
  // Configured Capital Allocation Projects list for comparison (Northstar Mining Strategic CapEx)
  const capexProjects = [
    {
      id: "proj-1",
      name: "Morenci Copper Pit Deep Extension",
      capex: 250, // Millions USD
      npv: 410,
      irr: 18.4,
      risk: "Medium",
      waterImpact: "+1.2 ML/day",
      carbonFootprint: "Medium",
      mineralCategory: "Critical Base Metals"
    },
    {
      id: "proj-2",
      name: "Sweetwater Lithium Brine Carbonate Expansion",
      capex: 310,
      npv: 520,
      irr: 24.1,
      risk: "High",
      waterImpact: "+4.8 ML/day",
      carbonFootprint: "Low",
      mineralCategory: "Battery Minerals"
    },
    {
      id: "proj-3",
      name: "Carlin Gold Autoclave Refractory Retrofit",
      capex: 180,
      npv: 265,
      irr: 16.7,
      risk: "Low",
      waterImpact: "-0.4 ML/day (Water Recycling)",
      carbonFootprint: "Very Low",
      mineralCategory: "Precious Metals"
    }
  ];

  const totalOpex = mines.reduce((acc, curr) => acc + (curr.productionRate * curr.opexPerTon), 0);
  const totalReclamation = mines.reduce((acc, curr) => acc + curr.reclamationLiability, 0);

  return (
    <div id="executive-mode-container" className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      
      {/* Portfolio Optimiser Strategy Selection */}
      <div className="col-span-12 lg:col-span-4 border border-white/10 bg-white/5 p-5 rounded-lg">
        <h3 className="text-[10px] uppercase tracking-widest text-white/40 font-bold mb-3 flex items-center gap-1.5 font-mono">
          <Compass className="w-4 h-4 text-[#F27D26]" /> Corporate Optimisation Goal
        </h3>
        <p className="text-xs text-white/50 mb-4 leading-relaxed font-sans">
          Select target objective for Northstar Mining Portfolio. This guides machine dispatch priorities, processing velocities, and electricity cost arbitrage models.
        </p>

        <div className="flex flex-col gap-2.5">
          {[
            {
              id: "MAX PROFIT",
              label: "Max Profit Mode",
              desc: "Override carbon/energy ceilings to maximize extraction head grade and ore throughput.",
              activeStyle: "ring-1 ring-[#00FF41] border-[#00FF41] bg-[#00FF41]/5 text-[#00FF41]",
              inactiveStyle: "border-white/10 text-white/75 bg-[#050608] hover:bg-white/5"
            },
            {
              id: "MIN CARBON",
              label: "Min Carbon Mode",
              desc: "Cap grinding mill velocities, prioritize electric vehicle charging, and shut down flexible circuits during thermal grid peaks.",
              activeStyle: "ring-1 ring-indigo-400 border-indigo-400 bg-indigo-950/10 text-indigo-300",
              inactiveStyle: "border-white/10 text-white/75 bg-[#050608] hover:bg-white/5"
            },
            {
              id: "BALANCED",
              label: "Balanced Optimizer",
              desc: "Equally weight ESG targets, peak power arbitrage, and contract commitments (Default AME Mode).",
              activeStyle: "ring-1 ring-[#F27D26] border-[#F27D26] bg-[#F27D26]/10 text-[#F27D26]",
              inactiveStyle: "border-white/10 text-white/75 bg-[#050608] hover:bg-white/5"
            }
          ].map((mode) => (
            <button
              key={mode.id}
              id={`opt-mode-btn-${mode.id.replace(" ", "-")}`}
              onClick={() => onChangeMode(mode.id as any)}
              className={`border p-3 rounded-lg text-left transition-all cursor-pointer focus:outline-none ${
                optimizationMode === mode.id 
                  ? mode.activeStyle + " font-bold" 
                  : mode.inactiveStyle + " opacity-70 hover:opacity-100"
              }`}
            >
              <div className="text-[10px] uppercase tracking-widest font-bold mb-1 font-mono">{mode.label}</div>
              <p className="text-[10px] leading-relaxed font-sans opacity-85">{mode.desc}</p>
            </button>
          ))}
        </div>
      </div>

      {/* Capital Allocation & CapEx Multi-Mine projects */}
      <div className="col-span-12 lg:col-span-8 border border-white/10 bg-white/5 p-5 rounded-lg flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-3 border-b border-white/5 pb-2">
            <h3 className="text-[10px] uppercase tracking-widest text-white/40 font-bold flex items-center gap-1.5 font-mono">
              <Landmark className="w-4 h-4 text-[#F27D26]" /> Capital Allocation Analysis (Multi-Mine Portfolio)
            </h3>
            <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest font-bold">Strategic Planning</span>
          </div>
          <p className="text-xs text-white/50 mb-4 leading-relaxed font-sans">
            Compare risk-adjusted NPV, Capex requirements, and long-term carbon metrics for potential corporate investment projects across the United States.
          </p>

          <div className="overflow-x-auto">
            <table id="capex-projects-table" className="w-full text-xs font-mono text-white/70">
              <thead>
                <tr className="border-b border-white/10 text-[9px] text-white/40 text-left uppercase tracking-wider">
                  <th className="pb-2">Strategic Project</th>
                  <th className="pb-2">CapEx</th>
                  <th className="pb-2">Expected NPV</th>
                  <th className="pb-2">IRR %</th>
                  <th className="pb-2">ESG / Carbon</th>
                  <th className="pb-2">Risk</th>
                </tr>
              </thead>
              <tbody>
                {capexProjects.map((p) => (
                  <tr key={p.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                    <td className="py-2.5 font-bold text-white">
                      <div>{p.name}</div>
                      <div className="text-[9px] text-white/30 font-normal uppercase mt-0.5 tracking-tight font-mono">{p.mineralCategory}</div>
                    </td>
                    <td className="py-2.5 text-white/90">${p.capex}M</td>
                    <td className="py-2.5 text-[#00FF41] font-bold">${p.npv}M</td>
                    <td className="py-2.5 text-white/95">{p.irr}%</td>
                    <td className="py-2.5">
                      <span className={`px-1.5 py-0.5 rounded text-[9px] uppercase font-mono ${
                        p.carbonFootprint === "Low" || p.carbonFootprint === "Very Low" 
                          ? "bg-[#00FF41]/5 text-[#00FF41] border border-[#00FF41]/10" 
                          : "bg-[#F27D26]/5 text-[#F27D26] border border-[#F27D26]/10"
                      }`}>
                        {p.carbonFootprint}
                      </span>
                    </td>
                    <td className="py-2.5">
                      <span className={`px-1.5 py-0.5 rounded text-[9px] uppercase font-mono ${
                        p.risk === "Low" ? "bg-white/5 text-white/80 border border-white/10" :
                        p.risk === "Medium" ? "bg-[#F27D26]/5 text-[#F27D26] border border-[#F27D26]/10" :
                        "bg-red-950/20 text-red-400 border border-red-500/10"
                      }`}>
                        {p.risk}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Financial Reclamation Metrics Summary */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 pt-4 border-t border-white/10">
          <div className="bg-[#050608] p-3 rounded border border-white/10">
            <div className="text-[9px] text-white/40 uppercase font-mono tracking-widest font-bold flex items-center gap-1">
              <DollarSign className="w-3.5 h-3.5 text-white/30" /> Corporate OpEx Pool
            </div>
            <div className="text-base font-mono font-bold text-white mt-1 leading-none">
              ${(totalOpex / 1000).toFixed(2)}k <span className="text-[10px] text-white/30 font-normal">/day</span>
            </div>
          </div>
          <div className="bg-[#050608] p-3 rounded border border-white/10">
            <div className="text-[9px] text-white/40 uppercase font-mono tracking-widest font-bold flex items-center gap-1">
              <Award className="w-3.5 h-3.5 text-white/30" /> Mine Closure liability
            </div>
            <div className="text-base font-mono font-bold text-white mt-1 leading-none">
              ${(totalReclamation / 1000000).toFixed(0)}M <span className="text-[10px] text-white/30 font-normal">Asset Liability</span>
            </div>
          </div>
          <div className="bg-[#050608] p-3 rounded border border-white/10">
            <div className="text-[9px] text-white/40 uppercase font-mono tracking-widest font-bold flex items-center gap-1">
              <BarChart3 className="w-3.5 h-3.5 text-white/30" /> Risk-weighted NPV
            </div>
            <div className="text-base font-mono font-bold text-[#00FF41] mt-1 leading-none">
              $1.19B <span className="text-[10px] text-white/30 font-normal">Active Portfolio</span>
            </div>
          </div>
        </div>

      </div>

    </div>
  );
};
