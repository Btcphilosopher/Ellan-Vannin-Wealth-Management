/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { MarketState, Mine } from "../types";
import { Landmark, TrendingUp, ShieldAlert, Sparkles, CheckSquare, Zap } from "lucide-react";

interface EconomicsModeProps {
  market: MarketState;
  mines: Mine[];
  onTriggerScenario: (scenario: string) => void;
}

export const EconomicsMode: React.FC<EconomicsModeProps> = ({
  market,
  mines,
  onTriggerScenario
}) => {
  const currentScenario = market.scenarioName;

  // Sensitivity Margins based on commodities
  const commodityUnits = {
    copper: "USD/lb",
    gold: "USD/oz",
    lithium: "USD/t",
    coal: "USD/t",
    ironOre: "USD/t",
    rareEarths: "USD/kg"
  };

  return (
    <div id="economics-mode-container" className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      
      {/* 1. Commodity spot pricing indices */}
      <div className="col-span-12 lg:col-span-5 border border-white/10 bg-white/5 p-5 rounded-lg flex flex-col justify-between">
        <div>
          <h3 className="text-[10px] uppercase tracking-widest text-white/40 font-bold mb-3 flex items-center gap-1.5 font-mono">
            <TrendingUp className="w-4 h-4 text-[#F27D26]" /> Commodity Index Futures Pricing
          </h3>
          <p className="text-xs text-white/50 mb-4 font-sans leading-relaxed">
            Real-time market feeds tracking strategic metal valuations. Price movements directly affect the risk-adjusted economic value (NPV) calculated in the geology matrix.
          </p>

          <div className="flex flex-col gap-2.5">
            {[
              { label: "Copper Index LME", val: market.spotPrices.copper, unit: commodityUnits.copper, color: "text-[#F27D26]" },
              { label: "Gold COMEX Futures", val: market.spotPrices.gold, unit: commodityUnits.gold, color: "text-amber-400" },
              { label: "Lithium Hydroxide Index", val: market.spotPrices.lithium, unit: commodityUnits.lithium, color: "text-indigo-400" },
              { label: "Rare Earths Carbonate", val: market.spotPrices.rareEarths, unit: commodityUnits.rareEarths, color: "text-[#00FF41]" },
              { label: "Coking Coal futures", val: market.spotPrices.coal, unit: commodityUnits.coal, color: "text-white/80" },
              { label: "Iron Ore 62% Fe CFR", val: market.spotPrices.ironOre, unit: commodityUnits.ironOre, color: "text-red-400" }
            ].map((c, idx) => (
              <div key={idx} className="bg-[#050608] p-2.5 rounded border border-white/10 font-mono text-xs flex justify-between items-center">
                <span className="text-white/65">{c.label}</span>
                <div className="text-right">
                  <span className={`font-bold ${c.color}`}>
                    ${c.val.toLocaleString()}
                  </span>
                  <span className="text-[9px] text-white/30 font-normal uppercase ml-1">{c.unit}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#050608] p-2.5 rounded border border-white/10 text-[9px] text-white/40 font-mono mt-4 leading-normal">
          * Spot indices pull directly from COMEX and London Metal Exchange (LME) APIs. Standard royalty deductions are modeled at 2.4% net.
        </div>
      </div>

      {/* 2. Portfolio Stress testing Scenarios */}
      <div className="col-span-12 lg:col-span-7 border border-white/10 bg-white/5 p-5 rounded-lg flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-3 border-b border-white/5 pb-2">
            <h3 className="text-[10px] uppercase tracking-widest text-white/40 font-bold flex items-center gap-1.5 font-mono">
              <Landmark className="w-4 h-4 text-[#F27D26]" /> Operational Portfolio Stress Testing
            </h3>
            <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest font-bold">Active: {currentScenario}</span>
          </div>
          <p className="text-xs text-white/50 mb-4 font-sans leading-relaxed">
            Trigger custom macro-economic or weather-related events to evaluate portfolio resilience, EBITDA margins, and automatic contingency actions.
          </p>

          <div className="grid grid-cols-2 gap-2">
            {[
              { id: "BASE CASE", desc: "Standard operating environment." },
              { id: "ERCOT POWER PRICE SHOCK", desc: "ERCOT grid surges to $850/MWh. Triggers automated load-shedding." },
              { id: "BLIZZARD", desc: "Forces Minnesota pit safety limits, slows haul fleet velocities." },
              { id: "RAIL DISRUPTION", desc: "Washouts block transcontinental rail buffers." },
              { id: "CRUSHER FAIL", desc: "Mill gearbox seizure. Bypasses concentrator feeds." }
            ].map((scen) => {
              const isActive = currentScenario === scen.id || 
                (scen.id === "ERCOT POWER PRICE SHOCK" && currentScenario === "POWER PRICE SHOCK") || 
                (scen.id === "BLIZZARD" && currentScenario === "EXTREME WEATHER");
              
              return (
                <button
                  key={scen.id}
                  id={`scen-btn-${scen.id.replace(/ /g, "-")}`}
                  onClick={() => onTriggerScenario(scen.id)}
                  className={`border p-3 rounded-lg text-left transition-all cursor-pointer focus:outline-none ${
                    isActive 
                      ? "ring-1 ring-[#F27D26] border-[#F27D26] bg-[#F27D26]/10 text-white font-bold" 
                      : "border-white/10 bg-[#050608] text-white/70 opacity-70 hover:opacity-100"
                  }`}
                >
                  <div className="text-[10px] uppercase font-mono tracking-wider font-bold mb-1">{scen.id}</div>
                  <p className="text-[9px] text-white/40 leading-normal font-sans font-normal">{scen.desc}</p>
                </button>
              );
            })}
          </div>
        </div>

        <div className="bg-[#050608] p-3 rounded border border-white/10 text-[9px] text-white/40 font-mono mt-4 leading-normal flex items-start gap-1.5">
          <ShieldAlert className="w-3.5 h-3.5 text-[#F27D26] shrink-0 mt-0.5" />
          <span>
            Stress testing does not modify physical assets permanently. It acts as a real-time sandbox simulation representing actual operational and cash-flow variances.
          </span>
        </div>
      </div>

    </div>
  );
};
