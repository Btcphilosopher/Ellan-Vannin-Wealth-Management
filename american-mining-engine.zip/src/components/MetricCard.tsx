/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { LucideIcon } from "lucide-react";

interface MetricCardProps {
  id: string;
  title: string;
  value: string;
  subtext?: string;
  icon: LucideIcon;
  trend?: "up" | "down" | "neutral";
  trendText?: string;
  color?: "emerald" | "amber" | "rose" | "cyan" | "indigo" | "yellow";
}

export const MetricCard: React.FC<MetricCardProps> = ({
  id,
  title,
  value,
  subtext,
  icon: Icon,
  trend,
  trendText,
  color = "emerald"
}) => {
  const colorMap = {
    emerald: "text-[#00FF41] border-white/10 bg-[#0A0C10]",
    amber: "text-amber-500 border-white/10 bg-[#0A0C10]",
    rose: "text-red-400 border-white/10 bg-[#0A0C10]",
    cyan: "text-[#F27D26] border-white/10 bg-[#0A0C10]",
    indigo: "text-indigo-400 border-white/10 bg-[#0A0C10]",
    yellow: "text-yellow-400 border-white/10 bg-[#0A0C10]"
  };

  return (
    <div 
      id={id}
      className={`border p-4 rounded-lg flex flex-col justify-between transition-all duration-300 hover:border-[#F27D26]/40 hover:bg-[#14171D] ${colorMap[color]}`}
    >
      <div className="flex items-center justify-between gap-3">
        <span className="text-[10px] uppercase tracking-widest text-white/40 font-mono font-bold">{title}</span>
        <Icon className="w-4 h-4 opacity-70" />
      </div>
      <div className="mt-3">
        <div className="text-xl font-light font-mono text-white leading-none">{value}</div>
        {subtext && <div className="text-[10px] text-white/50 font-mono mt-1">{subtext}</div>}
      </div>
      {trend && (
        <div className="flex items-center gap-1.5 mt-3 pt-2 border-t border-white/10 text-[10px] font-mono">
          <span className={`h-1.5 w-1.5 rounded-full ${
            trend === "up" ? "bg-[#00FF41]" : trend === "down" ? "bg-red-500" : "bg-amber-500"
          }`} />
          <span className="text-white/40 uppercase tracking-tighter">{trendText || "Operational Status"}</span>
        </div>
      )}
    </div>
  );
};
