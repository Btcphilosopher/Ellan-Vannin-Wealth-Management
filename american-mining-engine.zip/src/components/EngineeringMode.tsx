/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { FleetVehicle, ProcessingPlant } from "../types";
import { Hammer, BatteryCharging, AlertTriangle, Cpu, Wrench, ShieldAlert } from "lucide-react";

interface EngineeringModeProps {
  fleet: FleetVehicle[];
  plants: ProcessingPlant[];
  selectedMineId: string | null;
}

export const EngineeringMode: React.FC<EngineeringModeProps> = ({
  fleet,
  plants,
  selectedMineId
}) => {
  const [selectedVehicle, setSelectedVehicle] = useState<FleetVehicle | null>(null);

  const filteredFleet = selectedMineId 
    ? fleet.filter((v) => v.mineId === selectedMineId)
    : fleet;

  const filteredPlants = selectedMineId
    ? plants.filter((p) => p.mineId === selectedMineId)
    : plants;

  // Mock Predictive maintenance list
  const predictiveMaintList = [
    { id: "T-01", asset: "Morenci Truck T-01", issue: "Tire Pressure Uneven Wear", rul: "42 Hours", risk: "Low", sensorValue: "98 psi vs 94 psi" },
    { id: "S-04", asset: "Morenci Excavator S-04", issue: "Hydraulic Fluid Temperature High", rul: "8 Hours", risk: "High", sensorValue: "94°C (Limit 90°C)" },
    { id: "C-02", asset: "Carlin Autoclave Pump C-02", issue: "Vibrational Harmonic Phase Shift", rul: "2.5 Days", risk: "Medium", sensorValue: "Amplitude Spike (2.4 Hz)" }
  ];

  return (
    <div id="engineering-mode-container" className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      
      {/* 1. Vehicle Telemetry roster & GPS monitors */}
      <div className="col-span-12 lg:col-span-7 border border-white/10 bg-white/5 p-5 rounded-lg">
        <div className="flex justify-between items-center mb-3 border-b border-white/5 pb-2">
          <h3 className="text-[10px] uppercase tracking-widest text-white/40 font-bold flex items-center gap-1.5 font-mono">
            <Cpu className="w-4 h-4 text-[#F27D26]" /> Rust Telemetry: Real-Time Fleet Monitors
          </h3>
          <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest font-bold">{filteredFleet.length} Active assets</span>
        </div>
        <p className="text-xs text-white/50 mb-4 leading-relaxed font-sans">
          Live ingestion from autonomous vehicle CAN bus logs and PLC controllers. Select a heavy transport truck to drill into motor temperatures and payload pressures.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-[300px] overflow-y-auto pr-1">
          {filteredFleet.map((v) => (
            <button
              key={v.id}
              id={`vehicle-card-${v.id}`}
              onClick={() => setSelectedVehicle(v === selectedVehicle ? null : v)}
              className={`border p-3 rounded-lg text-left transition-all cursor-pointer focus:outline-none ${
                selectedVehicle?.id === v.id 
                  ? "border-[#F27D26] bg-[#050608] ring-1 ring-[#F27D26]" 
                  : "border-white/10 bg-[#050608]/40 hover:bg-[#050608]"
              }`}
            >
              <div className="flex justify-between items-center mb-1.5">
                <span className="text-xs font-mono font-bold text-white">{v.id.toUpperCase()}</span>
                <span className={`px-1.5 py-0.5 rounded text-[8px] font-mono uppercase font-bold tracking-wider ${
                  v.status === "Hauling" ? "bg-[#00FF41]/5 text-[#00FF41] border border-[#00FF41]/10" :
                  v.status === "Loading" ? "bg-[#F27D26]/5 text-[#F27D26] border border-[#F27D26]/10" :
                  v.status === "Charging" ? "bg-amber-950/20 text-amber-400 border border-amber-500/10" :
                  "bg-white/5 text-white/40 border border-white/10"
                }`}>
                  {v.status}
                </span>
              </div>
              
              <div className="grid grid-cols-2 gap-1.5 text-[10px] font-mono text-white/50">
                <div>Speed: <span className="text-white/90">{v.speed} km/h</span></div>
                <div>Payload: <span className="text-white/90">{v.payload} t</span></div>
                <div className="flex items-center gap-1">
                  <span className="text-white/40">SOC / Fuel:</span>
                  <span className={v.fuelLevel < 20 ? "text-red-400 font-bold" : "text-[#00FF41]"}>{Math.round(v.fuelLevel)}%</span>
                </div>
                <div>Engine: <span className="text-white/90">{v.engineTemp}°C</span></div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* 2. Predictive maintenance alarms (R ML models) */}
      <div className="col-span-12 lg:col-span-5 border border-white/10 bg-white/5 p-5 rounded-lg flex flex-col justify-between">
        <div>
          <h3 className="text-[10px] uppercase tracking-widest text-white/40 font-bold mb-3 flex items-center gap-1.5 font-mono">
            <Wrench className="w-4 h-4 text-[#F27D26]" /> R-Forecasting: Predictive Maintenance Alarms
          </h3>
          <p className="text-xs text-white/50 mb-4 font-sans leading-relaxed">
            Machine learning models predict remaining useful life (RUL) using vibrational and thermal sensor logs, helping engineers plan maintenance before failure.
          </p>

          <div className="flex flex-col gap-2.5">
            {predictiveMaintList.map((item) => (
              <div key={item.id} className="bg-[#050608] p-3 rounded-lg border border-white/10 font-mono text-[11px] text-white/70">
                <div className="flex justify-between items-center mb-1 border-b border-white/5 pb-1">
                  <span className="font-bold text-white">{item.asset}</span>
                  <span className={`px-1.5 py-0.5 rounded text-[8px] font-bold uppercase ${
                    item.risk === "High" ? "bg-red-950/20 text-red-400 border border-red-500/10" :
                    item.risk === "Medium" ? "bg-[#F27D26]/5 text-[#F27D26] border border-[#F27D26]/10" :
                    "bg-white/5 text-white/40 border border-white/10"
                  }`}>
                    {item.risk} Risk
                  </span>
                </div>
                <div className="flex justify-between mt-1.5">
                  <span className="text-white/30">Predicted Failure:</span>
                  <span className="text-white/90">{item.issue}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/30">Remaining Useful Life:</span>
                  <span className="text-[#00FF41] font-bold">{item.rul}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-white/30">Sensor Drift:</span>
                  <span className="text-red-400">{item.sensorValue}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#050608] p-3 rounded border border-white/10 text-[9px] text-white/40 font-mono mt-4 leading-normal flex items-start gap-1.5">
          <ShieldAlert className="w-3.5 h-3.5 text-[#F27D26] shrink-0 mt-0.5" />
          <span>
            Mandatory Engineering Boundary: Fleet dispatch rules prohibit autonomous vehicle operations when tire pressure drops below 85 psi or engine temperature exceeds 105°C.
          </span>
        </div>
      </div>

    </div>
  );
};
