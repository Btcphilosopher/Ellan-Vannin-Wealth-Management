/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Recommendation } from "../types";
import { Sparkles, Brain, Cpu, ShieldAlert, CheckSquare, Activity, HelpCircle } from "lucide-react";

interface WhatShouldWeDoProps {
  recommendations: Recommendation[];
  onFetchNewRecommendation: () => void;
  isLoading: boolean;
  error: string | null;
}

export const WhatShouldWeDo: React.FC<WhatShouldWeDoProps> = ({
  recommendations,
  onFetchNewRecommendation,
  isLoading,
  error
}) => {
  const [activeRecId, setActiveRecId] = useState<string | null>(recommendations[0]?.id || null);

  // Automatically select the first recommendation if none is selected
  React.useEffect(() => {
    if (recommendations.length > 0 && !activeRecId) {
      setActiveRecId(recommendations[0].id);
    }
  }, [recommendations, activeRecId]);

  const activeRec = recommendations.find(r => r.id === activeRecId) || recommendations[0];

  return (
    <div id="recommendation-engine-panel" className="border border-white/10 rounded-lg bg-white/5 p-5">
      
      {/* Header with trigger action */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-white/5 pb-4 mb-4">
        <div>
          <div className="flex items-center gap-2">
            <Brain className="w-5 h-5 text-[#F27D26]" />
            <h2 className="text-sm font-bold tracking-widest uppercase text-white font-mono">
              AME Intelligence & Recommendation Engine
            </h2>
          </div>
          <p className="text-xs text-white/50 mt-1 font-sans">
            Predictive geological adjustments, transport routing optimizers, and automated grid-load balancing
          </p>
        </div>
        
        <button
          id="query-gemini-btn"
          onClick={onFetchNewRecommendation}
          disabled={isLoading}
          className="px-4 py-2 bg-[#F27D26] hover:bg-[#F27D26]/90 disabled:bg-white/5 disabled:text-white/30 text-white text-xs font-mono font-bold rounded transition-all flex items-center gap-2 uppercase tracking-wider focus:outline-none cursor-pointer"
        >
          {isLoading ? (
            <>
              <Activity className="w-4 h-4 animate-spin text-white" />
              Ingesting Core SCADA logs...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 text-white animate-pulse" />
              Query Gemini AI Advisor
            </>
          )}
        </button>
      </div>

      {error && (
        <div className="bg-rose-950/20 border border-red-500/10 text-red-400 text-xs p-3 rounded mb-4 font-mono">
          🚨 Integration Alert: {error} (Falling back to offline quantitative routing rules)
        </div>
      )}

      {recommendations.length === 0 ? (
        <div className="text-center py-12 border border-white/10 rounded bg-[#050608]/30">
          <Cpu className="w-8 h-8 text-white/20 mx-auto mb-2 animate-pulse" />
          <p className="text-xs text-white/40 font-mono">No active recommendations compiled yet.</p>
          <button 
            onClick={onFetchNewRecommendation}
            className="mt-3 text-xs text-[#F27D26] font-mono hover:underline"
          >
            Compute initial operational dispatch rules →
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
          
          {/* Left Column: List of compiled recommendations */}
          <div className="col-span-12 lg:col-span-5 flex flex-col gap-2 max-h-[360px] overflow-y-auto pr-1">
            {recommendations.map((rec) => (
              <button
                key={rec.id}
                id={`rec-item-${rec.id}`}
                onClick={() => setActiveRecId(rec.id)}
                className={`text-left p-3.5 border rounded transition-all flex flex-col gap-1.5 cursor-pointer focus:outline-none ${
                  activeRecId === rec.id || activeRec?.id === rec.id
                    ? "border-[#F27D26] bg-[#F27D26]/5 ring-1 ring-[#F27D26]" 
                    : "border-white/10 bg-[#050608] hover:bg-[#050608]/80 text-white/70"
                }`}
              >
                <div className="flex justify-between items-center">
                  <span className={`px-2 py-0.5 rounded text-[8px] font-mono font-bold uppercase tracking-wider ${
                    rec.category === "Production" ? "bg-[#00FF41]/5 text-[#00FF41] border border-[#00FF41]/10" :
                    rec.category === "Energy" ? "bg-amber-950/20 text-amber-400 border border-amber-500/10" :
                    rec.category === "Logistics" ? "bg-[#F27D26]/5 text-[#F27D26] border border-[#F27D26]/10" :
                    rec.category === "Maintenance" ? "bg-indigo-950/20 text-indigo-300 border border-indigo-500/10" :
                    "bg-red-950/20 text-red-400 border border-red-500/10"
                  }`}>
                    {rec.category} Optimiser
                  </span>
                  <span className="text-[9px] font-mono font-bold text-white/40">
                    {rec.confidence}% Confidence
                  </span>
                </div>
                <div className="text-xs font-bold text-white mt-1 leading-snug">{rec.title}</div>
                <p className="text-[10px] text-white/40 line-clamp-2 leading-relaxed">{rec.what}</p>
              </button>
            ))}
          </div>

          {/* Right Column: Currently selected Recommendation Detail with EXPLAINABILITY metrics */}
          {activeRec && (
            <div id="active-rec-details" className="col-span-12 lg:col-span-7 border border-white/10 rounded p-4 bg-[#050608]/40 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start gap-4 border-b border-white/5 pb-2.5 mb-3">
                  <div>
                    <span className="text-[9px] font-mono text-white/40 uppercase tracking-widest font-bold">Active Dispatch Strategy</span>
                    <h3 className="text-xs font-bold text-white mt-0.5 font-mono">{activeRec.title}</h3>
                  </div>
                  <div className="text-right shrink-0">
                    <div className="text-[8px] text-white/30 uppercase font-mono font-bold">Confidence Level</div>
                    <div className="text-xs font-mono font-bold text-[#F27D26]">{activeRec.confidence}%</div>
                  </div>
                </div>

                {/* What / Why / Impact Cards */}
                <div className="flex flex-col gap-3 font-sans text-xs">
                  <div>
                    <span className="text-[8px] font-mono uppercase font-bold text-white/40 tracking-wider">Proposed Command Intervention</span>
                    <p className="text-white mt-0.5 leading-relaxed font-mono bg-[#050608] p-2 border border-white/10 rounded">{activeRec.what}</p>
                  </div>
                  <div>
                    <span className="text-[8px] font-mono uppercase font-bold text-white/40 tracking-wider">Physical & Economic Logic</span>
                    <p className="text-white/60 mt-0.5 leading-relaxed">{activeRec.why}</p>
                  </div>
                  <div>
                    <span className="text-[8px] font-mono uppercase font-bold text-[#00FF41] tracking-wider">Quantified Portfolio Impact</span>
                    <p className="text-[#00FF41] mt-0.5 font-semibold bg-[#00FF41]/5 p-2 border border-[#00FF41]/10 rounded font-mono">{activeRec.impact}</p>
                  </div>
                </div>
              </div>

              {/* Explainable AI block */}
              {activeRec.explainability && (
                <div id="explainability-panel" className="mt-4 pt-4 border-t border-white/5 grid grid-cols-1 md:grid-cols-2 gap-4 font-mono text-[9px]">
                  {/* Left sub-block: Factor weights */}
                  <div className="bg-[#050608] p-3 rounded border border-white/10">
                    <span className="text-[8px] text-white/30 uppercase font-bold block mb-2 tracking-wider">Neural Factor Weights</span>
                    <div className="flex flex-col gap-1.5">
                      {activeRec.explainability.keyFactors.map((f, idx) => (
                        <div key={idx} className="flex flex-col">
                          <div className="flex justify-between mb-0.5 text-white/50">
                            <span>{f.factor}</span>
                            <span>{Math.round(f.weight * 100)}%</span>
                          </div>
                          <div className="h-1 w-full bg-[#0A0C10] rounded-full overflow-hidden">
                            <div className="h-full bg-[#F27D26] rounded-full" style={{ width: `${f.weight * 100}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Right sub-block: Core features & quality */}
                  <div className="bg-[#050608] p-3 rounded border border-white/10 flex flex-col justify-between">
                    <div>
                      <span className="text-[8px] text-white/30 uppercase font-bold block mb-1.5 tracking-wider">Model Specifications</span>
                      <div className="flex justify-between text-white/50">
                        <span>Core Version:</span>
                        <span className="text-white/80">{activeRec.explainability.modelVersion}</span>
                      </div>
                      <div className="flex justify-between text-white/50">
                        <span>Data Ingest Score:</span>
                        <span className="text-[#00FF41]">{activeRec.explainability.dataQualityScore}% QC Verified</span>
                      </div>
                    </div>
                    <div className="border-t border-white/5 pt-1.5 mt-2 flex justify-between text-white/40 items-center">
                      <span>Historical Set:</span>
                      <span className="text-[8px] text-white/30">{activeRec.explainability.trainingPeriod}</span>
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

        </div>
      )}

    </div>
  );
};
