/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Mine, GeologicalBlock } from "../types";
import { LineChart, LayoutGrid, Award, Sliders, ListFilter, HelpCircle } from "lucide-react";

interface GeologyModeProps {
  mines: Mine[];
  selectedMineId: string | null;
  geology: Record<string, GeologicalBlock[]>;
}

export const GeologyMode: React.FC<GeologyModeProps> = ({
  mines,
  selectedMineId,
  geology
}) => {
  const [activeDrillHole, setActiveDrillHole] = useState<string | null>(null);

  const mineId = selectedMineId || "mine-01";
  const currentMine = mines.find(m => m.id === mineId);
  const blocks = geology ? (geology[mineId] || []) : [];

  // Categorize blocks based on reserve confidence
  const categories = {
    Measured: blocks.filter(b => b.confidence === "Measured"),
    Indicated: blocks.filter(b => b.confidence === "Indicated"),
    Inferred: blocks.filter(b => b.confidence === "Inferred"),
    Exploration: blocks.filter(b => b.confidence === "Exploration Target")
  };

  // Mock Drill Holes data matching states
  const drillHoles = [
    { id: `${mineId}-DH-001`, location: "North Bench Pit Face", depth: 450, coreLithology: "Porphyry Monzonite", grade: 0.68, date: "2026-03-12" },
    { id: `${mineId}-DH-002`, location: "South Ramp Cutoff", depth: 320, coreLithology: "Brecciated Limestone", grade: 0.42, date: "2026-04-18" },
    { id: `${mineId}-DH-003`, location: "Deep Siding Zone", depth: 680, coreLithology: "Silica-flooded Shale", grade: 0.95, date: "2026-06-25" }
  ];

  // Monte Carlo simulation curves (P10 / P50 / P90)
  const monteCarloDistributions = {
    grade: { p10: "0.84%", p50: "0.65%", p90: "0.48%" },
    tonnage: { p10: "1.42 Mt", p50: "1.20 Mt", p90: "0.98 Mt" },
    containedMetal: { p10: "11,920 t", p50: "7,800 t", p90: "4,700 t" },
    economicValue: { p10: "$32.4M", p50: "$22.8M", p90: "$12.4M" }
  };

  return (
    <div id="geology-mode-container" className="grid grid-cols-1 lg:grid-cols-12 gap-5">
      
      {/* 1. Monte Carlo Uncertainty Model (R engine predictions) */}
      <div className="col-span-12 lg:col-span-5 border border-white/10 bg-white/5 p-5 rounded-lg flex flex-col justify-between">
        <div>
          <h3 className="text-[10px] uppercase tracking-widest text-white/40 font-bold mb-3 flex items-center gap-1.5 font-mono">
            <LineChart className="w-4 h-4 text-[#F27D26]" /> R-Quantitative Monte Carlo Simulation
          </h3>
          <p className="text-xs text-white/50 mb-4 font-sans leading-relaxed">
            Uncertainty distributions generated from 5,000 statistical R-routines. Shows probabilities of economic grade and recoverable metal values for {currentMine?.name || "Morenci"}.
          </p>

          <div className="grid grid-cols-2 gap-3 mt-4">
            {[
              { label: "Reserve Grade", val: monteCarloDistributions.grade, color: "emerald" },
              { label: "Mineable Tonnage", val: monteCarloDistributions.tonnage, color: "cyan" },
              { label: "Contained Metal", val: monteCarloDistributions.containedMetal, color: "indigo" },
              { label: "Expected Value (NPV)", val: monteCarloDistributions.economicValue, color: "yellow" }
            ].map((item, idx) => (
              <div key={idx} className="bg-[#050608] p-3 rounded border border-white/10 font-mono text-[11px]">
                <div className="text-[9px] text-white/40 uppercase tracking-wider font-bold">{item.label}</div>
                <div className="flex justify-between items-center mt-2 border-b border-white/5 pb-1">
                  <span className="text-[8px] text-white/30">P10 (Optimistic)</span>
                  <span className="font-bold text-white/90">{item.val.p10}</span>
                </div>
                <div className="flex justify-between items-center py-1 border-b border-white/5">
                  <span className="text-[8px] text-white/30">P50 (Expected)</span>
                  <span className="font-bold text-[#00FF41]">{item.val.p50}</span>
                </div>
                <div className="flex justify-between items-center pt-1">
                  <span className="text-[8px] text-white/30">P90 (Conservative)</span>
                  <span className="font-bold text-white/50">{item.val.p90}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-[#050608] p-2.5 rounded border border-white/10 text-[9px] text-white/40 font-mono mt-4 leading-normal">
          * R engine uses kriging geostatistics alongside core-sample variances to determine block confidence boundaries automatically.
        </div>
      </div>

      {/* 2. Core Sample Assay Logging */}
      <div className="col-span-12 lg:col-span-7 border border-white/10 bg-white/5 p-5 rounded-lg flex flex-col justify-between">
        <div>
          <div className="flex justify-between items-center mb-3 border-b border-white/5 pb-2">
            <h3 className="text-[10px] uppercase tracking-widest text-white/40 font-bold flex items-center gap-1.5 font-mono">
              <Sliders className="w-4 h-4 text-[#F27D26]" /> Active Boreholes & Assay Interpretations
            </h3>
            <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest font-bold">Drilling Logs</span>
          </div>
          <p className="text-xs text-white/50 mb-4 font-sans leading-relaxed">
            Geological assay drilling reports from active pit rigs. Selecting a bore highlights the monitored physical core lithology and head grade metrics.
          </p>

          <div className="flex flex-col gap-2.5">
            {drillHoles.map((dh) => (
              <button
                key={dh.id}
                id={`dh-btn-${dh.id}`}
                onClick={() => setActiveDrillHole(dh.id === activeDrillHole ? null : dh.id)}
                className={`border p-3 rounded-lg text-left transition-all cursor-pointer focus:outline-none ${
                  activeDrillHole === dh.id 
                    ? "border-[#F27D26] bg-[#050608] ring-1 ring-[#F27D26]" 
                    : "border-white/10 bg-[#050608]/40 hover:bg-[#050608]"
                }`}
              >
                <div className="flex justify-between items-center mb-1.5">
                  <span className="text-xs font-mono font-bold text-white">{dh.id}</span>
                  <span className="text-[8px] font-mono uppercase bg-[#0A0C10] border border-white/10 px-1.5 rounded text-white/50">
                    Depth: {dh.depth}m
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-[10px] font-mono text-white/50">
                  <div>Location: <span className="text-white/80">{dh.location}</span></div>
                  <div>Rock Structure: <span className="text-white/80">{dh.coreLithology}</span></div>
                  <div>Monitored Assay: <span className="text-[#00FF41] font-bold">{dh.grade}% / gt</span></div>
                  <div>Logged Date: <span className="text-white/80">{dh.date}</span></div>
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Geology blocks breakdown status */}
        <div className="grid grid-cols-4 gap-2 mt-4 pt-4 border-t border-white/10 font-mono text-center">
          {[
            { label: "Measured", count: categories.Measured.length },
            { label: "Indicated", count: categories.Indicated.length },
            { label: "Inferred", count: categories.Inferred.length },
            { label: "Exploration", count: categories.Exploration.length }
          ].map((cat, idx) => (
            <div key={idx} className="bg-[#050608] p-2.5 rounded border border-white/10">
              <div className="text-[8px] text-white/30 uppercase tracking-wider font-bold">{cat.label}</div>
              <div className="text-xs font-bold text-white mt-1">{cat.count} blocks</div>
            </div>
          ))}
        </div>

      </div>

    </div>
  );
};
