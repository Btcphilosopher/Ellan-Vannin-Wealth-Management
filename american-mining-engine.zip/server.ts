/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import { 
  SimulationState, Mine, FleetVehicle, ProcessingPlant, 
  Stockpile, LogisticsRoute, EnergyGridState, WaterBalance, 
  WeatherCondition, Incident, Recommendation, GeologicalBlock 
} from "./src/types";

const PORT = 3000;
const app = express();
app.use(express.json());

// -----------------------------------------------------------------------------
// Lazy Gemini SDK Setup (Prevents crash if API key is missing)
// -----------------------------------------------------------------------------
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    console.warn("GEMINI_API_KEY environment variable is not defined or is placeholder. Falling back to heuristic recommendation engine.");
    return null;
  }
  if (!aiClient) {
    aiClient = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// -----------------------------------------------------------------------------
// In-Memory Synthetic Operational State (Northstar Mining Corporation)
// -----------------------------------------------------------------------------
let simState: SimulationState = {
  timestamp: Date.now(),
  optimizationMode: "BALANCED",
  mines: [
    {
      id: "mine-01",
      name: "Morenci Mine",
      commodity: "Copper",
      state: "Arizona",
      location: { lat: 33.0801, lng: -109.3667 },
      method: "Open Pit",
      status: "Operational",
      productionRate: 112400,
      targetProduction: 115000,
      headGrade: 0.62, // %
      recoveryRate: 84.5, // %
      fleetSize: 340,
      activeTrucks: 312,
      workforceCount: 1420,
      energyDemand: 340, // MW
      waterConsumption: 22.4, // ML/day
      carbonEmissions: 1840, // tCO2e/day
      revenue: 122000000, // USD/month
      ebitda: 56000000,
      opexPerTon: 4.12,
      reclamationLiability: 340000000
    },
    {
      id: "mine-02",
      name: "Carlin Trend",
      commodity: "Gold",
      state: "Nevada",
      location: { lat: 40.7139, lng: -116.1222 },
      method: "Open Pit",
      status: "Operational",
      productionRate: 48000,
      targetProduction: 50000,
      headGrade: 3.45, // g/t
      recoveryRate: 91.2,
      fleetSize: 180,
      activeTrucks: 164,
      workforceCount: 890,
      energyDemand: 160,
      waterConsumption: 12.8,
      carbonEmissions: 790,
      revenue: 145000000,
      ebitda: 68000000,
      opexPerTon: 32.50,
      reclamationLiability: 220000000
    },
    {
      id: "mine-03",
      name: "Iron Mountain",
      commodity: "Iron Ore",
      state: "Minnesota",
      location: { lat: 47.5253, lng: -92.5354 },
      method: "Open Pit",
      status: "Operational",
      productionRate: 240000,
      targetProduction: 250000,
      headGrade: 62.4, // % Fe
      recoveryRate: 78.5,
      fleetSize: 420,
      activeTrucks: 380,
      workforceCount: 1100,
      energyDemand: 410,
      waterConsumption: 28.5,
      carbonEmissions: 2420,
      revenue: 94000000,
      ebitda: 38000000,
      opexPerTon: 2.85,
      reclamationLiability: 180000000
    },
    {
      id: "mine-04",
      name: "Cumberland Mine",
      commodity: "Coal",
      state: "Pennsylvania",
      location: { lat: 39.8514, lng: -80.1233 },
      method: "Underground Longwall",
      status: "Operational",
      productionRate: 185000,
      targetProduction: 180000,
      headGrade: 72.1, // % Carbon content
      recoveryRate: 98.2,
      fleetSize: 120,
      activeTrucks: 98,
      workforceCount: 750,
      energyDemand: 145,
      waterConsumption: 8.4,
      carbonEmissions: 3100,
      revenue: 58000000,
      ebitda: 21000000,
      opexPerTon: 18.20,
      reclamationLiability: 140000000
    },
    {
      id: "mine-05",
      name: "Sweetwater Mine",
      commodity: "Lithium",
      state: "Wyoming",
      location: { lat: 41.6586, lng: -108.8821 },
      method: "Underground Room & Pillar",
      status: "Operational",
      productionRate: 12400,
      targetProduction: 15000,
      headGrade: 1.45, // % Li2O
      recoveryRate: 76.4,
      fleetSize: 90,
      activeTrucks: 74,
      workforceCount: 450,
      energyDemand: 95,
      waterConsumption: 16.2,
      carbonEmissions: 380,
      revenue: 48000000,
      ebitda: 24000000,
      opexPerTon: 54.10,
      reclamationLiability: 110000000
    },
    {
      id: "mine-06",
      name: "Mountain Pass",
      commodity: "Rare Earths",
      state: "California",
      location: { lat: 35.4761, lng: -115.5342 },
      method: "Open Pit",
      status: "Operational",
      productionRate: 8200,
      targetProduction: 9000,
      headGrade: 8.24, // % TREO
      recoveryRate: 68.2,
      fleetSize: 60,
      activeTrucks: 52,
      workforceCount: 380,
      energyDemand: 72,
      waterConsumption: 6.8,
      carbonEmissions: 290,
      revenue: 42000000,
      ebitda: 19000000,
      opexPerTon: 84.50,
      reclamationLiability: 95000000
    }
  ],
  fleet: [],
  processingPlants: [],
  stockpiles: [],
  logistics: [],
  energy: {
    market: "ERCOT",
    electricityPrice: 42.50, // USD/MWh
    demandCharge: 18.20, // USD/kW
    gridCarbonIntensity: 420, // kg CO2/MWh
    solarGeneration: 145, // MW generated dynamically
    windGeneration: 85,
    batterySOC: 62,
    batteryCapacityMWh: 500,
    batteryStatus: "Idle"
  },
  water: {},
  weather: {
    temperature: 24.5,
    precipitation: 0.0,
    snowAccumulation: 0.0,
    windSpeed: 12.4,
    humidity: 48,
    alert: null
  },
  incidents: [
    {
      id: "inc-1",
      severity: "Medium",
      location: "Morenci Shovel S-04",
      mineId: "mine-01",
      title: "Hydraulic Leak Detected",
      time: new Date().toLocaleTimeString(),
      affectedAssets: ["Shovel S-04", "Haul Truck T-12"],
      affectedProduction: 3200,
      status: "Investigating",
      resolutionResponse: "Dispatched field technician for hose replacement."
    },
    {
      id: "inc-2",
      severity: "High",
      location: "Carlin Plant Crusher 02",
      mineId: "mine-02",
      title: "Oversized Rock Jam",
      time: new Date(Date.now() - 45 * 60 * 1000).toLocaleTimeString(),
      affectedAssets: ["Crusher C-02", "Conveyor CV-01"],
      affectedProduction: 8400,
      status: "Active",
      resolutionResponse: "Rockbreaker actively clearing. Secondary screen bypassed."
    }
  ],
  market: {
    spotPrices: {
      copper: 4.12, // USD/lb
      gold: 2420, // USD/oz
      lithium: 16500, // USD/t
      coal: 112,
      ironOre: 104,
      rareEarths: 320
    },
    scenarioName: "BASE CASE"
  },
  recommendations: [],
  carbonTaxRate: 45.00, // USD/ton of CO2e
  totalEmissionsThisYear: 148200
};

// 3D Geological Block Models for each mine (synthetic)
const geologicalModels: Record<string, GeologicalBlock[]> = {};

function initGeologicalModels() {
  simState.mines.forEach((mine) => {
    const blocks: GeologicalBlock[] = [];
    const lithologyOptions = ["Monzonite", "Sandstone", "Shale", "Breccia", "Taconite", "Clay"];
    const grades = {
      "Copper": { base: 0.55, range: 0.3 },
      "Gold": { base: 3.2, range: 2.1 },
      "Iron Ore": { base: 60.5, range: 12 },
      "Coal": { base: 70.0, range: 15 },
      "Lithium": { base: 1.35, range: 0.8 },
      "Rare Earths": { base: 7.5, range: 4.2 }
    };

    const gData = grades[mine.commodity as keyof typeof grades] || { base: 1.0, range: 0.5 };

    let blockIdx = 1;
    // Build a miniature 3D matrix 4 x 4 x 4 = 64 blocks for each mine
    for (let x = 0; x < 4; x++) {
      for (let y = 0; y < 4; y++) {
        for (let z = 0; z < 4; z++) {
          const depthFactor = 1 - (z * 0.12); // Slightly higher quality deeper or shallower
          const grade = parseFloat((gData.base + (Math.sin(x + y) * gData.range * depthFactor)).toFixed(2));
          const confidence = z === 0 ? "Measured" : z === 1 ? "Indicated" : z === 2 ? "Inferred" : "Exploration Target";
          const lithology = lithologyOptions[(x + y + z) % lithologyOptions.length];
          const density = parseFloat((2.5 + (z * 0.15) + (Math.cos(x) * 0.2)).toFixed(2));
          const tonnage = Math.round(12000 * density);
          
          // Calculate net block value (Grade * Tonnage * recovery * Commodity Price - miningCost - processingCost)
          let commodityPrice = 1.0;
          if (mine.commodity === "Copper") commodityPrice = simState.market.spotPrices.copper * 2204.62; // convert $/lb to $/ton
          else if (mine.commodity === "Gold") commodityPrice = simState.market.spotPrices.gold / 31.1035 * 1000000; // $/ton approx
          else if (mine.commodity === "Lithium") commodityPrice = simState.market.spotPrices.lithium;
          else if (mine.commodity === "Coal") commodityPrice = simState.market.spotPrices.coal;
          else if (mine.commodity === "Iron Ore") commodityPrice = simState.market.spotPrices.ironOre;
          else if (mine.commodity === "Rare Earths") commodityPrice = simState.market.spotPrices.rareEarths * 1000;

          const recovery = 0.7 + (z * 0.04) > 0.95 ? 0.92 : 0.7 + (z * 0.04);
          const revenue = (grade / (mine.commodity === "Gold" ? 1 : 100)) * tonnage * recovery * commodityPrice;
          const miningCost = tonnage * mine.opexPerTon;
          const processCost = tonnage * (mine.opexPerTon * 1.5);
          const economicValue = Math.round(revenue - (miningCost + processCost));

          blocks.push({
            id: `${mine.id}-blk-${blockIdx++}`,
            coordinates: { x, y, z },
            lithology,
            grade,
            density,
            contaminants: {
              sulfur: parseFloat((0.2 + (Math.sin(x) * 0.15)).toFixed(2)),
              silica: parseFloat((1.2 + (Math.cos(y) * 0.5)).toFixed(2)),
              phosphorus: parseFloat((0.05 + (Math.sin(z) * 0.03)).toFixed(3))
            },
            recovery: parseFloat((recovery * 100).toFixed(1)),
            confidence,
            tonnage,
            economicValue
          });
        }
      }
    }
    geologicalModels[mine.id] = blocks;
  });
}

// -----------------------------------------------------------------------------
// Initialize Mock Data Arrays
// -----------------------------------------------------------------------------
function initAssets() {
  simState.mines.forEach((m) => {
    // 1. Stockpiles
    simState.stockpiles.push({
      id: `${m.id}-stockpile-01`,
      mineId: m.id,
      name: "Run-of-Mine (ROM) High Grade",
      tonnage: 42000,
      maxCapacity: 150000,
      grade: parseFloat((m.headGrade * 1.25).toFixed(2)),
      moisture: 4.2,
      contaminants: { sulfur: 0.12, silica: 1.1 }
    });
    simState.stockpiles.push({
      id: `${m.id}-stockpile-02`,
      mineId: m.id,
      name: "ROM Low Grade Stack",
      tonnage: 125000,
      maxCapacity: 300000,
      grade: parseFloat((m.headGrade * 0.75).toFixed(2)),
      moisture: 5.6,
      contaminants: { sulfur: 0.28, silica: 1.8 }
    });

    // 2. Processing Plants
    simState.processingPlants.push({
      id: `${m.id}-plant-01`,
      mineId: m.id,
      name: `${m.name} Concentrator`,
      status: "Running",
      feedRate: Math.round(m.productionRate / 24),
      maxCapacity: Math.round(m.targetProduction / 24 * 1.1),
      grindingUtilization: 88,
      flotationRecovery: m.recoveryRate,
      energyConsumption: Math.round(m.energyDemand * 0.75),
      waterRecyclingRate: 85,
      screenBottleneck: "None"
    });

    // 3. Vehicles
    // Spawn 8 key trucks per mine for detailed pathing and telemetry
    for (let i = 1; i <= 8; i++) {
      const isElectric = i % 3 === 0; // 33% electric
      simState.fleet.push({
        id: `${m.id}-truck-0${i}`,
        mineId: m.id,
        type: "Haul Truck",
        model: isElectric ? "CAT 793 XE EV" : "CAT 797F Diesel",
        isAutonomous: i > 2, // Autonomous Dispatch enabled
        status: i % 4 === 0 ? "Loading" : i % 4 === 1 ? "Hauling" : i % 4 === 2 ? "Dumping" : "Returning",
        payload: i % 4 === 2 ? 240 : 0,
        maxCapacity: 250,
        fuelLevel: isElectric ? (65 + (i * 4) % 35) : (50 + (i * 6) % 50),
        isElectric,
        speed: 24 + (i * 3) % 25,
        engineTemp: 82 + (i * 2) % 15,
        tirePressure: 95 + (i % 3),
        operatingHours: 1200 + i * 145,
        position: { x: 10 + i * 10, y: 30 + (Math.sin(i) * 20) },
        destination: i % 2 === 0 ? "ROM Stockpile" : "Primary Crusher"
      });
    }

    // 4. Logistics Lines
    simState.logistics.push({
      id: `${m.id}-logistics-rail`,
      mineId: m.id,
      destination: "Pacific Export Terminal",
      type: "Rail",
      activeVehicles: m.id === "mine-01" ? 4 : 2,
      transitTimeHours: 36,
      capacityTonPerDay: Math.round(m.targetProduction * 0.8),
      currentFlowRate: Math.round(m.productionRate * 0.75),
      disruptionLevel: 0
    });
    simState.logistics.push({
      id: `${m.id}-logistics-road`,
      mineId: m.id,
      destination: "Regional Smelter Facility",
      type: "Truck",
      activeVehicles: 24,
      transitTimeHours: 4,
      capacityTonPerDay: Math.round(m.targetProduction * 0.25),
      currentFlowRate: Math.round(m.productionRate * 0.2),
      disruptionLevel: 0
    });

    // 5. Water Balance
    simState.water[m.id] = {
      groundwaterInflow: 4200,
      pitWaterAccumulation: 2100,
      reservoirLevel: 74.5,
      freshwaterIntake: m.waterConsumption * 0.15 * 1000, // conversion ML to m3
      recycledWater: m.waterConsumption * 0.85 * 1000,
      dischargeRate: 1200,
      floodRisk: "Low"
    };
  });
}

// Initialize Heuristic Recommendations (as fallback and base data)
function initRecommendations() {
  simState.recommendations = [
    {
      id: "rec-01",
      title: "Optimise Carlin Concentrator Blending",
      what: "Shift haul dispatch ratios from Low-Grade Stockpile to ROM High Grade Stockpile by 15%.",
      why: "Carlin Trend's plant is running at 88% capacity. Blending in higher grade ore will increase mill recovery without triggering secondary screening bottlenecks.",
      impact: "+$1.85M Monthly EBITDA, +0.22g/t Gold Head Grade.",
      confidence: 94,
      category: "Production",
      explainability: {
        featuresAnalyzed: ["Stockpile Tonnages", "Mill Feed Rate", "Flotation Recovery", "Screen Pressures"],
        modelVersion: "AME-R-OPT-v4.2.1",
        trainingPeriod: "90-Day Real-Time SCADA Window",
        keyFactors: [
          { factor: "Gold Price Delta", weight: 0.42 },
          { factor: "Grinding Mill Throughput Margin", weight: 0.35 },
          { factor: "High-Grade Resource Availability", weight: 0.23 }
        ],
        dataQualityScore: 98
      }
    },
    {
      id: "rec-02",
      title: "PJM Energy Demand-Side Peak Shaving",
      what: "Temporarily lower processing throughput at Cumberland Mine by 8% between 4:00 PM and 7:00 PM EST.",
      why: "PJM Grid day-ahead pricing predicts extreme peak spike to $185/MWh during this block. Cumberland has 24 hours of buffer stock.",
      impact: "-$320k in direct energy demand costs, -14t CO2e Carbon Avoided.",
      confidence: 88,
      category: "Energy",
      explainability: {
        featuresAnalyzed: ["PJM Day-Ahead Forward Curves", "Cumberland Stockpile Buffer", "Process Power Draw"],
        modelVersion: "AME-Rust-Energy-v2.1",
        trainingPeriod: "Seasonal Load Profile Data (1 Year)",
        keyFactors: [
          { factor: "Day-Ahead Locational Marginal Pricing (LMP)", weight: 0.65 },
          { factor: "Buffer Stock Safety Margins", weight: 0.25 },
          { factor: "Carbon Offset Value", weight: 0.10 }
        ],
        dataQualityScore: 95
      }
    },
    {
      id: "rec-03",
      title: "Predictive Maintenance: Morenci Shovel S-04 Hydraulic Hose",
      what: "Schedule absolute replacement of hydraulic control block on Morenci Shovel S-04 within the next 24 hours.",
      why: "Real-time vibration and temperature telemetry detected high-frequency amplitude deviation (2.4 Hz harmonics) indicating imminent seal degradation.",
      impact: "Avoided catastrophic failure worth $1.2M in unplanned stoppage and environmental remediation.",
      confidence: 91,
      category: "Maintenance",
      explainability: {
        featuresAnalyzed: ["Vibration Spectrum", "Hydraulic Backpressure", "Operating Hours"],
        modelVersion: "R-PredictiveMaintenance-XGBoost-14",
        trainingPeriod: "2-Year Shovel Failure Log",
        keyFactors: [
          { factor: "Vibrational Harmonic Spike", weight: 0.58 },
          { factor: "Average Fluid Temp Trend", weight: 0.27 },
          { factor: "Resource Criticality Score", weight: 0.15 }
        ],
        dataQualityScore: 92
      }
    }
  ];
}

initGeologicalModels();
initAssets();
initRecommendations();

// -----------------------------------------------------------------------------
// Real-Time Simulation Loop (Runs once per second to represent real operations)
// -----------------------------------------------------------------------------
setInterval(() => {
  simState.timestamp = Date.now();

  // 1. Telemetry Speed & Position Drift for Vehicles
  simState.fleet.forEach((truck) => {
    // Simulate movement: move coordinates a bit and update fuel
    if (truck.status === "Hauling") {
      truck.position.x += 0.8 * (Math.random() - 0.3);
      truck.fuelLevel = Math.max(0, truck.fuelLevel - (truck.isElectric ? 0.05 : 0.08));
      if (truck.position.x > 80) {
        truck.status = "Dumping";
        truck.destination = "Reversing to Crusher Bin";
      }
    } else if (truck.status === "Dumping") {
      truck.payload = Math.max(0, truck.payload - 50);
      if (truck.payload <= 0) {
        truck.status = "Returning";
        truck.destination = "Pit Face 03B";
      }
    } else if (truck.status === "Returning") {
      truck.position.x -= 0.8 * (Math.random() - 0.3);
      truck.fuelLevel = Math.max(0, truck.fuelLevel - (truck.isElectric ? 0.03 : 0.05));
      if (truck.position.x < 15) {
        truck.status = "Loading";
        truck.destination = "Shovel Loading Berth";
      }
    } else if (truck.status === "Loading") {
      truck.payload = Math.min(truck.maxCapacity, truck.payload + 60);
      if (truck.payload >= truck.maxCapacity) {
        truck.status = "Hauling";
        truck.destination = "Primary Crusher";
      }
    } else if (truck.status === "Charging" || (truck.isElectric && truck.fuelLevel < 15)) {
      truck.status = "Charging";
      truck.fuelLevel = Math.min(100, truck.fuelLevel + 4.5);
      if (truck.fuelLevel >= 95) {
        truck.status = "Returning";
      }
    }

    // Engine temperature fluctuation
    if (truck.status !== "Charging" && truck.status !== "Maintenance") {
      truck.engineTemp = 80 + Math.floor(Math.sin(Date.now() / 10000) * 8 + Math.random() * 2);
    } else {
      truck.engineTemp = Math.max(25, truck.engineTemp - 0.5);
    }
  });

  // 2. Power Markets fluctuations
  // If ERCOT or other grids fluctuate based on load
  const timeSec = Math.floor(Date.now() / 1000);
  simState.energy.electricityPrice = parseFloat(
    (38.00 + Math.sin(timeSec / 30) * 15.00 + Math.random() * 4.00).toFixed(2)
  );

  // Dynamic renewable generation based on synthetic sun/wind logic
  simState.energy.solarGeneration = Math.round(130 + Math.sin(timeSec / 120) * 50);
  simState.energy.windGeneration = Math.round(90 + Math.cos(timeSec / 160) * 25);

  // Battery SOC Charging/Discharging based on pricing
  if (simState.energy.electricityPrice < 35.0) {
    simState.energy.batteryStatus = "Charging";
    simState.energy.batterySOC = Math.min(100, simState.energy.batterySOC + 0.2);
  } else if (simState.energy.electricityPrice > 50.0) {
    simState.energy.batteryStatus = "Discharging";
    simState.energy.batterySOC = Math.max(10, simState.energy.batterySOC - 0.4);
  } else {
    simState.energy.batteryStatus = "Idle";
  }

  // 3. Fluctuating Stockpiles (Simulate mine-to-market material flow)
  simState.stockpiles.forEach((s) => {
    // Add ore from shovel haulage and subtract from mill reclaim
    const plant = simState.processingPlants.find((p) => p.mineId === s.mineId);
    if (plant && plant.status === "Running") {
      s.tonnage = Math.max(5000, s.tonnage + Math.round((Math.random() - 0.48) * 120));
    }
  });

  // 4. Commodity price micro-fluctuations
  simState.market.spotPrices.copper = parseFloat((simState.market.spotPrices.copper + (Math.random() - 0.5) * 0.01).toFixed(3));
  simState.market.spotPrices.gold = parseFloat((simState.market.spotPrices.gold + (Math.random() - 0.5) * 2.50).toFixed(2));
  simState.market.spotPrices.lithium = parseFloat((simState.market.spotPrices.lithium + (Math.random() - 0.5) * 15).toFixed(0));

  // 5. Water level simulation with weather effects
  simState.mines.forEach((m) => {
    const w = simState.water[m.id];
    if (w) {
      if (simState.weather.alert === "Flood Warning") {
        w.pitWaterAccumulation += 20;
        w.reservoirLevel = Math.min(100, w.reservoirLevel + 0.5);
        w.floodRisk = "High";
      } else {
        w.pitWaterAccumulation = Math.max(200, w.pitWaterAccumulation + (Math.random() - 0.5) * 5);
        w.reservoirLevel = Math.max(30, Math.min(100, w.reservoirLevel + (Math.random() - 0.5) * 0.1));
        w.floodRisk = "Low";
      }
    }
  });

}, 1000);

// -----------------------------------------------------------------------------
// REST API Endpoints
// -----------------------------------------------------------------------------

// Retrieve current live operating telemetry and metrics
app.get("/api/simulation/state", (req, res) => {
  res.json({
    simState,
    geologicalModels
  });
});

// Set optimization modes (MAX PROFIT / MIN CARBON / BALANCED)
app.post("/api/simulation/set-optimisation-mode", (req, res) => {
  const { mode } = req.body;
  if (mode === "MAX PROFIT" || mode === "MIN CARBON" || mode === "BALANCED") {
    simState.optimizationMode = mode;
    
    // Adjust target outputs & grid behaviors based on strategy
    simState.mines.forEach((m) => {
      if (mode === "MAX PROFIT") {
        m.productionRate = Math.round(m.targetProduction * 1.05);
        m.carbonEmissions = Math.round(m.carbonEmissions * 1.1);
        m.ebitda = Math.round(m.ebitda * 1.08);
      } else if (mode === "MIN CARBON") {
        m.productionRate = Math.round(m.targetProduction * 0.92);
        m.carbonEmissions = Math.round(m.carbonEmissions * 0.78);
        m.ebitda = Math.round(m.ebitda * 0.94);
      } else {
        m.productionRate = m.targetProduction;
        m.carbonEmissions = Math.round(m.carbonEmissions);
        m.ebitda = Math.round(m.ebitda);
      }
    });

    res.json({ success: true, mode });
  } else {
    res.status(400).json({ error: "Invalid optimization mode" });
  }
});

// Trigger customized scenario failures to stress-test the operating systems
app.post("/api/simulation/trigger-failure", (req, res) => {
  const { scenario } = req.body;
  
  if (scenario === "ERCOT POWER PRICE SHOCK") {
    simState.market.scenarioName = "POWER PRICE SHOCK";
    simState.energy.electricityPrice = 850.00; // Sky-high price spikes
    simState.energy.market = "ERCOT";
    
    // Auto-create incident
    simState.incidents.unshift({
      id: `inc-${Date.now()}`,
      severity: "Critical",
      location: "Corporate Power Link",
      mineId: "all",
      title: "ERCOT Grid Congestion Price Spike",
      time: new Date().toLocaleTimeString(),
      affectedAssets: ["All Processing plants", "Grid Feeders"],
      affectedProduction: 45000,
      status: "Active",
      resolutionResponse: "AME automated load-shedding activated. Battery bank discharging at maximum capacity."
    });
  } 
  else if (scenario === "BLIZZARD") {
    simState.market.scenarioName = "EXTREME WEATHER";
    simState.weather = {
      temperature: -18.5,
      precipitation: 12.4,
      snowAccumulation: 35.0,
      windSpeed: 65.0,
      humidity: 92,
      alert: "Blizzard"
    };

    // Slow down trucks, trigger high heating demand
    simState.fleet.forEach((t) => {
      t.speed = Math.max(5, t.speed * 0.3);
      t.status = "Maintenance"; // some park for safety
    });

    simState.mines.forEach((m) => {
      m.status = "Extreme Weather Alert";
      m.productionRate = Math.round(m.productionRate * 0.4);
    });

    simState.incidents.unshift({
      id: `inc-${Date.now()}`,
      severity: "High",
      location: "Minnesota Iron Mountain / Sweetwater",
      mineId: "mine-03",
      title: "Blizzard Ground Transport Lockout",
      time: new Date().toLocaleTimeString(),
      affectedAssets: ["Haul Roads", "Drill Rigs"],
      affectedProduction: 80000,
      status: "Active",
      resolutionResponse: "Mandatory safety separation rules activated. Snowplow escorts dispatched to primary corridors."
    });
  } 
  else if (scenario === "RAIL DISRUPTION") {
    simState.market.scenarioName = "RAIL DISRUPTION";
    simState.logistics.forEach((l) => {
      if (l.type === "Rail") {
        l.disruptionLevel = 100;
        l.currentFlowRate = 0;
      }
    });

    simState.incidents.unshift({
      id: `inc-${Date.now()}`,
      severity: "High",
      location: "BNSF / Union Pacific Corridors",
      mineId: "all",
      title: "Logistics Corridor Washout",
      time: new Date().toLocaleTimeString(),
      affectedAssets: ["Pacific Rail Connection", "Midwest Ore Siding"],
      affectedProduction: 120000,
      status: "Active",
      resolutionResponse: "Re-routing critical stockpiles to regional trucking vectors. Smelter buffers active."
    });
  }
  else if (scenario === "CRUSHER FAIL") {
    const mine = simState.mines[0]; // Morenci
    mine.status = "Maintenance";
    const plant = simState.processingPlants.find((p) => p.mineId === "mine-01");
    if (plant) {
      plant.status = "Maintenance";
      plant.screenBottleneck = "Primary Screen";
    }

    simState.incidents.unshift({
      id: `inc-${Date.now()}`,
      severity: "Critical",
      location: "Morenci Mine",
      mineId: "mine-01",
      title: "Crusher Mill Gearbox Seizure",
      time: new Date().toLocaleTimeString(),
      affectedAssets: ["Morenci Concentrator"],
      affectedProduction: 110000,
      status: "Active",
      resolutionResponse: "Emergency engineering response team deployed. Backup parts being hot-loaded."
    });
  }
  else if (scenario === "BASE CASE") {
    // Reset to normal
    simState.market.scenarioName = "BASE CASE";
    simState.weather = {
      temperature: 24.5,
      precipitation: 0.0,
      snowAccumulation: 0.0,
      windSpeed: 12.4,
      humidity: 48,
      alert: null
    };
    simState.mines.forEach((m) => {
      m.status = "Operational";
      m.productionRate = m.targetProduction;
    });
    simState.fleet.forEach((t) => {
      t.status = "Hauling";
      t.speed = 35;
    });
    simState.logistics.forEach((l) => {
      l.disruptionLevel = 0;
      l.currentFlowRate = Math.round(l.capacityTonPerDay * 0.9);
    });
    simState.incidents = simState.incidents.filter(inc => inc.severity === "Low" || inc.id === "inc-2");
  }

  res.json({ success: true, simState });
});

// Resolve specific incidents from the control room
app.post("/api/simulation/resolve-incident", (req, res) => {
  const { id } = req.body;
  const idx = simState.incidents.findIndex((inc) => inc.id === id);
  if (idx !== -1) {
    simState.incidents[idx].status = "Resolved";
    simState.incidents[idx].resolutionResponse = "Resolved by Operator command from main control room.";
    res.json({ success: true, incidents: simState.incidents });
  } else {
    res.status(404).json({ error: "Incident not found" });
  }
});

// -----------------------------------------------------------------------------
// Gemini AI Recommendation Agent Endpoint ("What Should We Do?" Engine)
// -----------------------------------------------------------------------------
app.post("/api/gemini/recommendation", async (req, res) => {
  const client = getGeminiClient();

  if (!client) {
    // Fallback: Generate high-quality procedural recommendations if API key is not present
    console.log("No Gemini key. Returning premium heuristic analytical response.");
    const timeVal = new Date().toLocaleTimeString();
    const dynamicRec: Recommendation = {
      id: `rec-${Date.now()}`,
      title: "Heuristic Operational Shift Recommendation",
      what: "Shed 15 MW load at Carlin Trend and dispatch 4 autonomous haul trucks from ROM stack directly to heap leach pads.",
      why: "Current regional ERCOT/Western prices are surging ($124/MWh). Heap leach processes are non-grinding and use 80% less electric energy compared to autoclave processing, safeguarding recovery margins.",
      impact: "Expected EBITDA protection of +$420k today, saving 8.2 MWh of premium peak grid load.",
      confidence: 89,
      category: "Production",
      explainability: {
        featuresAnalyzed: ["Western Grid Spot Prices", "Autoclave Feed Rate", "Leach Pad Heap Volumes"],
        modelVersion: "AME-LocalOptimiser-v1.0",
        trainingPeriod: "Local pricing simulation log",
        keyFactors: [
          { factor: "Electricity price delta", weight: 0.55 },
          { factor: "Leach pad feed recovery", weight: 0.35 },
          { factor: "Autonomous dispatch latency", weight: 0.10 }
        ],
        dataQualityScore: 94
      }
    };
    
    // Add to recommendation list if not already there
    if (!simState.recommendations.some(r => r.title === dynamicRec.title)) {
      simState.recommendations.unshift(dynamicRec);
    }

    return res.json({ recommendations: simState.recommendations });
  }

  try {
    const activeIncidentContext = simState.incidents
      .filter((i) => i.status !== "Resolved")
      .map((i) => `- [${i.severity}] ${i.title} at ${i.location}`).join("\n");

    const mineProductionContext = simState.mines
      .map((m) => `- ${m.name}: ${m.productionRate}/${m.targetProduction} t/d (${m.commodity}, Head Grade: ${m.headGrade}, Status: ${m.status})`)
      .join("\n");

    const prompt = `You are the core intelligence engine of the American Mining Engine (AME).
Your task is to analyze the current real-time operations of Northstar Mining Corporation and generate a brand-new, highly actionable, strategic recommendation.

Here is the current operational data:
1. MINING PORTFOLIO STATUS:
${mineProductionContext}

2. ENERGY SPOT PRICING:
Grid region: ${simState.energy.market}
Spot electricity price: $${simState.energy.electricityPrice}/MWh
Grid solar generation: ${simState.energy.solarGeneration} MW
Wind generation: ${simState.energy.windGeneration} MW
Battery State of Charge: ${simState.energy.batterySOC}%

3. ENVIRONMENT & LOGISTICS:
Optimization strategy: ${simState.optimizationMode}
Active Incidents:
${activeIncidentContext || "None"}

Generate exactly ONE premium, detailed recommendation targeting geology, fleet, processing, water, logistics, or carbon, in strict valid JSON format matching this schema:
{
  "title": "Short descriptive title of the action",
  "what": "Clear, highly technical industrial instruction on WHAT to do",
  "why": "Physical, chemical, geological, or economic logic explaining WHY",
  "impact": "Concrete financial (USD EBITDA) and physical metric improvements (e.g., fuel, recovery %)",
  "confidence": 92, // number between 50 and 99
  "category": "Production" | "Energy" | "Logistics" | "Maintenance" | "Safety",
  "explainability": {
    "featuresAnalyzed": ["metric A", "metric B", "metric C"],
    "modelVersion": "AME-AI-Omni-v1.2",
    "trainingPeriod": "90-Day Continuous Operations Block",
    "keyFactors": [
      { "factor": "Factor Name 1", "weight": 0.60 },
      { "factor": "Factor Name 2", "weight": 0.40 }
    ],
    "dataQualityScore": 96
  }
}

Respond ONLY with the JSON block. Do not include markdown wraps other than the JSON itself. Ensure the response is perfectly formatted, parsed, and contains real physical insight.`;

    // Query Gemini
    const response = await client.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
      },
    });

    if (response.text) {
      const parsed = JSON.parse(response.text.trim());
      // Generate unique ID
      parsed.id = `rec-${Date.now()}`;
      
      // Prepend to recommendations list
      simState.recommendations.unshift(parsed);
      
      // Keep max 5 recommendations
      if (simState.recommendations.length > 5) {
        simState.recommendations = simState.recommendations.slice(0, 5);
      }
    }

    res.json({ recommendations: simState.recommendations });
  } catch (error: any) {
    console.error("Failed to fetch recommendation from Gemini API:", error);
    res.status(500).json({ error: error.message || "Unknown API generation error" });
  }
});

// -----------------------------------------------------------------------------
// Production build static serving & Vite Dev Server Middleware mounting
// -----------------------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Starting in DEV mode. Embedding Vite server middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    console.log("Starting in PRODUCTION mode. Serving pre-compiled build folder...");
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`American Mining Engine Server booted successfully on http://0.0.0.0:${PORT}`);
  });
}

startServer();
