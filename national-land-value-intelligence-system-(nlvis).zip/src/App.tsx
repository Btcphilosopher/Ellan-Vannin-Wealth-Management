import React, { useState, useEffect } from "react";
import { Parcel, PortfolioAsset, InfrastructureProject } from "./types";
import { INITIAL_PARCELS, SOVEREIGN_PORTFOLIO, INFRASTRUCTURE_PROJECTS } from "./data";
import Dashboard from "./components/Dashboard";
import GisEngine from "./components/GisEngine";
import ValuationEngine from "./components/ValuationEngine";
import PlanningIntelligence from "./components/PlanningIntelligence";
import ValueCapture from "./components/ValueCapture";
import DevelopmentSimulator from "./components/DevelopmentSimulator";
import RegenerationEngine from "./components/RegenerationEngine";
import AiValuationEngine from "./components/AiValuationEngine";
import PortfolioManager from "./components/PortfolioManager";
import { 
  Database, Map as MapIcon, Calculator, Landmark, BarChart, 
  Hammer, Trees, Cpu, Briefcase, FileText, X, Printer, 
  TrendingUp, Compass, CheckCircle2, ShieldAlert, Zap, ArrowRight,
  Sparkles
} from "lucide-react";

export default function App() {
  // Global Shared States
  const [parcels, setParcels] = useState<Parcel[]>(INITIAL_PARCELS);
  const [selectedParcel, setSelectedParcel] = useState<Parcel>(INITIAL_PARCELS[0]);
  const [portfolio, setPortfolio] = useState<PortfolioAsset[]>(SOVEREIGN_PORTFOLIO);
  const [infraProjects, setInfraProjects] = useState<InfrastructureProject[]>(INFRASTRUCTURE_PROJECTS);

  // Search and Filter states (shared or fed into Dashboard)
  const [searchTerm, setSearchTerm] = useState<string>("");
  const [selectedCounty, setSelectedCounty] = useState<string>("");
  const [selectedStatus, setSelectedStatus] = useState<string>("");

  // GIS state
  const [activeOverlay, setActiveOverlay] = useState<"standard" | "classification" | "planning" | "flood" | "heatmap" | "infrastructure">("standard");
  const [addedProjects, setAddedProjects] = useState<Array<{ name: string; type: string; lat: number; lng: number; buffer: number; uplift: number }>>([]);

  // Active Navigation Module
  // Available: 'database' | 'gis' | 'valuation' | 'planning' | 'infrastructure' | 'development' | 'regeneration' | 'ai_valuation' | 'portfolio'
  const [activeModule, setActiveModule] = useState<string>("database");

  // Investment Memo Modal State
  const [isMemoOpen, setIsMemoOpen] = useState<boolean>(false);

  // Sync selected parcel search filters in case they change elsewhere
  const handleSelectParcel = (parcel: Parcel) => {
    setSelectedParcel(parcel);
  };

  // Quick portfolio navigation helpers
  const handleApplyPortfolioFilter = (county: string) => {
    setSelectedCounty(county);
    setActiveModule("database");
  };

  // Filter parcels based on search input & filters for secondary indicators
  const filteredParcels = parcels.filter(p => {
    const matchesSearch = p.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.postcode.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.county.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.district.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.ownership.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCounty = selectedCounty === "" || p.county === selectedCounty;
    const matchesStatus = selectedStatus === "" || p.planningStatus === selectedStatus;

    return matchesSearch && matchesCounty && matchesStatus;
  });

  return (
    <div className="bg-[#050505] text-[#E5E5E5] font-sans h-screen flex flex-col overflow-hidden select-none">
      {/* 1. Header Area - Clean Minimal style */}
      <header className="h-14 bg-[#000000] border-b border-white/10 flex items-center justify-between px-6 shrink-0 z-20">
        {/* Logo and metadata */}
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 bg-white flex items-center justify-center font-bold text-black text-xs tracking-tighter">
            EV
          </div>
          <div>
            <h1 className="text-xs font-bold tracking-widest text-white uppercase font-sans">NLVIS</h1>
            <p className="text-[8px] tracking-wider text-white/40 font-mono">ELLAN VANNIN WEALTH MGMT // UK LAND TWIN</p>
          </div>
        </div>

        {/* Live Sovereignty KPI stats */}
        <div className="hidden md:flex gap-8">
          <div className="text-right">
            <p className="text-[9px] uppercase tracking-wider text-white/30 font-mono">Sovereign Asset Value</p>
            <p className="text-xs text-[#00FF41] font-mono font-bold">
              £105.8M <span className="text-[9px] opacity-70 ml-1">▲ 0.14%</span>
            </p>
          </div>
          <div className="text-right">
            <p className="text-[9px] uppercase tracking-wider text-white/30 font-mono">Registered Strategic Lands</p>
            <p className="text-xs text-white font-mono font-bold">
              10 Parcels <span className="text-[9px] opacity-40 ml-1">({(parcels.reduce((sum, p) => sum + p.area, 0)).toFixed(1)} Ha)</span>
            </p>
          </div>
          <div className="text-right">
            <p className="text-[9px] uppercase tracking-wider text-white/30 font-mono">Strategic Infrastructure Projects</p>
            <p className="text-xs text-white font-mono font-bold">
              {infraProjects.length} Nodes
            </p>
          </div>
        </div>

        {/* Header Search Input */}
        <div className="relative">
          <div className="h-8 w-64 bg-white/5 rounded border border-white/10 px-3 flex items-center gap-2">
            <div className="w-2 h-2 border border-white/30 rounded-full shrink-0"></div>
            <input
              type="text"
              placeholder="Search Land Twin database..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-transparent border-none text-[10px] text-white placeholder-white/30 font-sans outline-none w-full"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm("")} className="text-white/40 hover:text-white">
                <X className="w-3 h-3" />
              </button>
            )}
          </div>
        </div>
      </header>

      {/* 2. Main Workspace Layout */}
      <main className="flex flex-1 overflow-hidden">
        
        {/* Left Aside: Module Navigation */}
        <aside className="w-48 bg-[#0A0A0A] border-r border-white/5 flex flex-col shrink-0">
          <nav className="flex-1 py-4 flex flex-col justify-between overflow-y-auto">
            <div className="px-4">
              <p className="text-[9px] text-white/30 uppercase tracking-widest mb-3 font-mono font-bold">Analytics Modules</p>
              <ul className="space-y-1">
                {[
                  { id: "database", label: "Land Database", icon: <Database className="w-3.5 h-3.5" /> },
                  { id: "gis", label: "GIS Mapping Engine", icon: <MapIcon className="w-3.5 h-3.5" /> },
                  { id: "valuation", label: "Valuation Lab", icon: <Calculator className="w-3.5 h-3.5" /> },
                  { id: "planning", label: "Planning Intel", icon: <Landmark className="w-3.5 h-3.5" /> },
                  { id: "infrastructure", label: "Infra-Value Capture", icon: <BarChart className="w-3.5 h-3.5" /> },
                  { id: "development", label: "Development Sim", icon: <Hammer className="w-3.5 h-3.5" /> },
                  { id: "regeneration", label: "Brownfield Regen", icon: <Trees className="w-3.5 h-3.5" /> },
                  { id: "ai_valuation", label: "AI Hedonic Model", icon: <Cpu className="w-3.5 h-3.5" /> },
                  { id: "portfolio", label: "Portfolio Manager", icon: <Briefcase className="w-3.5 h-3.5" /> }
                ].map((item) => {
                  const isActive = activeModule === item.id;
                  return (
                    <li key={item.id}>
                      <button
                        onClick={() => setActiveModule(item.id)}
                        className={`w-full text-left text-[11px] px-3 py-1.5 rounded transition-all duration-150 flex items-center gap-2.5 ${
                          isActive
                            ? "text-[#00FF41] font-bold bg-white/5 border-l-2 border-[#00FF41]"
                            : "text-white/50 hover:text-white hover:bg-white/5 border-l-2 border-transparent"
                        }`}
                      >
                        <span className={isActive ? "text-[#00FF41]" : "text-white/40"}>
                          {item.icon}
                        </span>
                        {item.label}
                      </button>
                    </li>
                  );
                })}
              </ul>
            </div>

            {/* Quick Portfolios Filter section */}
            <div className="px-4 mt-6">
              <p className="text-[9px] text-white/30 uppercase tracking-widest mb-3 font-mono font-bold">Region Portfolios</p>
              <ul className="space-y-1">
                {[
                  { label: "Warwickshire Strategic", county: "Warwickshire" },
                  { label: "Salford Core Hubs", county: "Greater Manchester" },
                  { label: "Bristol Severnside", county: "Bristol (City of)" },
                  { label: "Edinburgh Innovation", county: "Midlothian" },
                  { label: "Sovereign Offshore", county: "Sovereign Isle" }
                ].map((p, idx) => (
                  <li key={idx}>
                    <button
                      onClick={() => handleApplyPortfolioFilter(p.county)}
                      className={`w-full text-left text-[10px] py-1 text-white/40 hover:text-white truncate flex items-center gap-1.5 ${
                        selectedCounty === p.county ? "text-[#00FF41] font-bold" : ""
                      }`}
                    >
                      <span>▪</span>
                      {p.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* System Node status marker */}
            <div className="p-4 border-t border-white/5 bg-black/40 mt-auto">
              <p className="text-[8px] text-white/20 uppercase font-mono tracking-wider">System Status</p>
              <div className="flex items-center gap-2 mt-1">
                <span className="w-1.5 h-1.5 rounded-full bg-[#00FF41] animate-ping" />
                <span className="text-[10px] text-[#00FF41] font-mono font-bold">UK-NODE-01: ONLINE</span>
              </div>
            </div>
          </nav>
        </aside>

        {/* Column 2: Active Component View Area */}
        <section className="flex-1 bg-[#050505] p-6 overflow-y-auto flex flex-col justify-between">
          <div className="flex-1">
            {/* Header within active section describing selection */}
            <div className="flex justify-between items-center border-b border-white/10 pb-3 mb-4">
              <div>
                <span className="text-[9px] uppercase tracking-widest text-[#00FF41] font-mono font-bold">ACTIVE ANALYTICAL NODE</span>
                <h2 className="text-lg font-bold text-white tracking-tight uppercase font-sans mt-0.5">
                  {activeModule === "database" && "Strategic Land Database Registry"}
                  {activeModule === "gis" && "Metropolitan GIS Geospatial Twin Layout"}
                  {activeModule === "valuation" && "Valuation Laboratory Engine"}
                  {activeModule === "planning" && "Strategic Planning Intelligence Unit"}
                  {activeModule === "infrastructure" && "Infrastructure Value Capture Spillover Model"}
                  {activeModule === "development" && "Development Stage Financial Simulator"}
                  {activeModule === "regeneration" && "Brownfield Regeneration Reclamation Portal"}
                  {activeModule === "ai_valuation" && "Sovereign AI Hedonic Pricing Model"}
                  {activeModule === "portfolio" && "Ellan Vannin Asset Portfolio Registers"}
                </h2>
              </div>
              <div className="text-right text-[10px] text-white/40 font-mono">
                FOCUS PARCEL: <span className="text-[#00FF41] font-bold">{selectedParcel.id}</span> ({selectedParcel.county})
              </div>
            </div>

            {/* Core engine router */}
            <div className="h-full">
              {activeModule === "database" && (
                <Dashboard
                  parcels={filteredParcels}
                  portfolio={portfolio}
                  onSelectParcel={handleSelectParcel}
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  selectedCounty={selectedCounty}
                  setSelectedCounty={setSelectedCounty}
                  selectedStatus={selectedStatus}
                  setSelectedStatus={setSelectedStatus}
                />
              )}

              {activeModule === "gis" && (
                <GisEngine
                  parcels={parcels}
                  selectedParcel={selectedParcel}
                  onSelectParcel={handleSelectParcel}
                  infrastructureProjects={infraProjects}
                  activeOverlay={activeOverlay}
                  setActiveOverlay={setActiveOverlay}
                  addedProjects={addedProjects}
                />
              )}

              {activeModule === "valuation" && (
                <ValuationEngine parcel={selectedParcel} />
              )}

              {activeModule === "planning" && (
                <PlanningIntelligence parcel={selectedParcel} />
              )}

              {activeModule === "infrastructure" && (
                <ValueCapture />
              )}

              {activeModule === "development" && (
                <DevelopmentSimulator parcel={selectedParcel} />
              )}

              {activeModule === "regeneration" && (
                <RegenerationEngine 
                  parcels={parcels} 
                  selectedParcel={selectedParcel} 
                  onSelectParcel={handleSelectParcel} 
                />
              )}

              {activeModule === "ai_valuation" && (
                <AiValuationEngine parcel={selectedParcel} />
              )}

              {activeModule === "portfolio" && (
                <PortfolioManager />
              )}
            </div>
          </div>
        </section>

        {/* Column 3: "Selected Parcel" Aside Details */}
        <aside className="w-72 bg-[#0A0A0A] border-l border-white/5 flex flex-col shrink-0 overflow-y-auto">
          {/* Aside Header */}
          <div className="p-5 border-b border-white/5 bg-black/20 shrink-0">
            <span className="text-[9px] uppercase tracking-widest text-white/40 font-mono font-bold block mb-1">Target Land Twin</span>
            <h2 className="text-lg font-bold text-white tracking-tight leading-tight">{selectedParcel.id}</h2>
            <p className="text-[10px] text-[#00FF41] font-mono mt-0.5">{selectedParcel.postcode} // {selectedParcel.county.toUpperCase()}</p>
          </div>

          {/* Aside Body */}
          <div className="p-5 flex-1 space-y-5">
            
            {/* 1. Value Appraisal Block */}
            <div className="grid grid-cols-2 gap-4 border-b border-white/5 pb-4">
              <div>
                <p className="text-[8px] text-white/30 uppercase tracking-widest font-mono">Book Base Cost</p>
                <p className="text-base text-white font-mono font-bold">£{(selectedParcel.currentValue / 1000000).toFixed(2)}M</p>
              </div>
              <div>
                <p className="text-[8px] text-white/30 uppercase tracking-widest font-mono">Future Target GDV</p>
                <p className="text-base text-[#00FF41] font-mono font-bold">£{(selectedParcel.futureValue / 1000000).toFixed(2)}M</p>
              </div>
            </div>

            {/* 2. Key Land Attributes list */}
            <div className="space-y-2 border-b border-white/5 pb-4">
              <p className="text-[8px] text-white/30 uppercase tracking-widest font-mono font-bold">Physical Specifications</p>
              <div className="grid grid-cols-2 gap-2 text-[10px]">
                <div className="bg-white/5 p-1.5 border border-white/5 rounded-sm">
                  <span className="text-white/40 block text-[8px] uppercase font-mono">Total Area</span>
                  <span className="text-white font-bold">{selectedParcel.area} Hectares</span>
                </div>
                <div className="bg-white/5 p-1.5 border border-white/5 rounded-sm">
                  <span className="text-white/40 block text-[8px] uppercase font-mono">Ownership Status</span>
                  <span className="text-white font-bold truncate block" title={selectedParcel.ownership}>{selectedParcel.ownership.split("/")[0]}</span>
                </div>
                <div className="bg-white/5 p-1.5 border border-white/5 rounded-sm">
                  <span className="text-white/40 block text-[8px] uppercase font-mono">Flood Risk Zone</span>
                  <span className={`font-bold ${selectedParcel.floodZone.includes("High") ? "text-red-400" : selectedParcel.floodZone.includes("Medium") ? "text-yellow-400" : "text-emerald-400"}`}>
                    {selectedParcel.floodZone.split(" ")[1]}
                  </span>
                </div>
                <div className="bg-white/5 p-1.5 border border-white/5 rounded-sm">
                  <span className="text-white/40 block text-[8px] uppercase font-mono">Transport Access</span>
                  <span className="text-white font-bold block truncate">{selectedParcel.transportAccess}</span>
                </div>
              </div>
            </div>

            {/* 3. Planning & Environmental Block */}
            <div className="space-y-3.5 border-b border-white/5 pb-4">
              <p className="text-[8px] text-white/30 uppercase tracking-widest font-mono font-bold">Regulatory & Safety Indicators</p>
              
              {/* Planning allocation status badge */}
              <div className="flex justify-between items-center text-[10px]">
                <span className="text-white/40 uppercase font-mono">Planning Status</span>
                <span className={`px-2 py-0.5 text-[8px] font-mono font-bold ${
                  selectedParcel.planningStatus === "Planning Approved" ? "bg-emerald-950 text-emerald-400 border border-emerald-500" :
                  selectedParcel.planningStatus === "Allocated" ? "bg-cyan-950 text-cyan-400 border border-cyan-500" :
                  selectedParcel.planningStatus === "Draft Allocation" ? "bg-blue-950 text-blue-400 border border-blue-500" : "bg-neutral-950 text-neutral-400 border border-neutral-700"
                }`}>
                  {selectedParcel.planningStatus.toUpperCase()}
                </span>
              </div>

              {/* Environmental Constraints */}
              <div className="space-y-1">
                <span className="text-white/40 text-[9px] uppercase font-mono block">Detected Environmental Overlays</span>
                <div className="space-y-1">
                  {selectedParcel.envConstraints.map((constraint, index) => (
                    <div key={index} className="text-[9px] bg-red-950/20 text-red-400 border border-red-900/50 p-1 flex items-center gap-1.5">
                      <ShieldAlert className="w-3 h-3 shrink-0" />
                      <span className="truncate">{constraint}</span>
                    </div>
                  ))}
                  {selectedParcel.envConstraints.length === 0 && (
                    <div className="text-[9px] bg-emerald-950/20 text-emerald-400 border border-emerald-900/50 p-1 flex items-center gap-1.5">
                      <CheckCircle2 className="w-3 h-3 shrink-0" />
                      <span>NO RECOGNIZED CONSTRAINT OVERLAYS</span>
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* 4. Action CTA */}
            <div className="pt-2">
              <button
                onClick={() => setIsMemoOpen(true)}
                className="w-full py-3 bg-white text-black font-bold text-[10px] uppercase tracking-widest hover:bg-neutral-200 transition-colors flex items-center justify-center gap-2 rounded-sm cursor-pointer shadow-md"
              >
                <FileText className="w-3.5 h-3.5" />
                Generate Investment Memo
              </button>
            </div>

          </div>
        </aside>

      </main>

      {/* 3. Bloomberg-Style Scrolling Market Ticker Footer */}
      <footer className="h-6 bg-[#000000] border-t border-white/10 flex items-center px-6 justify-between shrink-0 font-mono text-[9px] z-10">
        <div className="flex gap-6 overflow-hidden">
          <span className="text-white/30 uppercase shrink-0">MARKET TRANSMISSION:</span>
          <div className="flex gap-6 animate-marquee whitespace-nowrap">
            <span className="text-[#00FF41]">RESIDENTIAL LAND INDEX +0.14%</span>
            <span className="text-red-500 font-bold">LOGISTICS YIELD CRUNCH -0.04%</span>
            <span className="text-[#00FF41]">AGRICULTURE GRADES STEADY (+0.02%)</span>
            <span className="text-[#00FF41]">ISLE OF MAN FREEPORT TAX COVENANT STABLE</span>
            <span className="text-white/50">M4 LOGISTICS SPUR COMMITTED FOR 2027</span>
            <span className="text-[#00FF41]">HS2 EXEMPTIONS IN SOLIHULL FULLY CERTIFIED</span>
          </div>
        </div>
        <div className="hidden lg:flex gap-4 opacity-40 shrink-0 text-white text-[8px]">
          <span>LAT: 54.1520° N</span>
          <span>LON: 4.4780° W</span>
          <span>SECURED SYSTEM ENVIRONMENT // EV-NLVIS</span>
        </div>
      </footer>

      {/* 4. Sovereign Investment Memo Print Modal Overlay */}
      {isMemoOpen && (
        <div className="fixed inset-0 bg-black/95 backdrop-blur-sm z-50 flex items-center justify-center p-6 text-neutral-800">
          <div className="bg-[#FFFFFF] w-full max-w-3xl rounded-sm shadow-2xl flex flex-col h-[90vh] overflow-hidden relative border border-neutral-300">
            
            {/* Modal Header Controls */}
            <div className="bg-neutral-100 border-b border-neutral-200 px-6 py-3 flex justify-between items-center shrink-0">
              <div className="flex items-center gap-2">
                <FileText className="w-4 h-4 text-neutral-600" />
                <span className="text-[10px] uppercase tracking-widest font-mono font-black text-neutral-600">Sovereign Land Appraisal Registry</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => window.print()}
                  className="px-3 py-1 bg-white border border-neutral-300 hover:bg-neutral-50 text-[10px] font-bold font-mono uppercase flex items-center gap-1.5 rounded-sm shadow-sm transition-colors text-neutral-700 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  Print Memo
                </button>
                <button
                  onClick={() => setIsMemoOpen(false)}
                  className="p-1 hover:bg-neutral-200 text-neutral-500 hover:text-neutral-900 rounded transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Memorandum Document Print Stage */}
            <div id="print-memo-stage" className="flex-1 p-12 overflow-y-auto space-y-8 font-serif leading-relaxed text-neutral-900 bg-white">
              {/* Cover Letterhead */}
              <div className="flex justify-between items-start border-b-4 border-neutral-950 pb-6">
                <div>
                  <h3 className="text-xs uppercase tracking-widest font-mono font-black text-neutral-600">Ellan Vannin Strategic Land Holdings</h3>
                  <h1 className="text-3xl font-extrabold font-serif tracking-tight text-neutral-950 mt-1">INVESTMENT MEMORANDUM</h1>
                  <p className="text-[10px] font-mono text-neutral-500 uppercase mt-0.5">PLATFORM ASSIGNED SERIAL ID: EV-NLVIS-{selectedParcel.id}</p>
                </div>
                <div className="w-12 h-12 bg-neutral-950 text-white flex items-center justify-center font-bold text-lg font-mono">
                  EV
                </div>
              </div>

              {/* Document Meta fields */}
              <div className="grid grid-cols-2 gap-x-8 gap-y-2 text-xs font-mono border-b border-neutral-200 pb-4 text-neutral-700">
                <div><span className="font-bold text-neutral-900">DATE:</span> July 2026 Appraisal</div>
                <div><span className="font-bold text-neutral-900">PREPARED BY:</span> National Land Twin Core</div>
                <div><span className="font-bold text-neutral-900">TARGET PARCEL:</span> {selectedParcel.id}</div>
                <div><span className="font-bold text-neutral-900">COUNTY REGION:</span> {selectedParcel.county.toUpperCase()}</div>
                <div><span className="font-bold text-neutral-900">CLASSIFICATION:</span> {selectedParcel.classification.toUpperCase()}</div>
                <div><span className="font-bold text-neutral-900">REGISTERED OWNER:</span> {selectedParcel.ownership}</div>
              </div>

              {/* Executive Summary */}
              <div className="space-y-3">
                <h2 className="text-sm font-mono font-black uppercase text-neutral-900 tracking-wider">1. Executive Allocation Summary</h2>
                <p className="text-xs text-neutral-800 leading-relaxed font-serif">
                  Under instruction of Ellan Vannin Wealth Management and sovereign development protocols, this document certifies the strategic real estate profile of land parcel <span className="font-bold text-neutral-900">{selectedParcel.id}</span>. Situated in the district of <span className="font-serif italic text-neutral-900">{selectedParcel.district}</span>, the parcel represents <span className="font-bold text-neutral-900">{selectedParcel.area} Hectares</span> of strategically aligned space. Current appraisal indicates a high-fidelity development path prioritizing transit infrastructure and local population demands.
                </p>
              </div>

              {/* Economic Appraisal Grid */}
              <div className="space-y-3">
                <h2 className="text-sm font-mono font-black uppercase text-neutral-900 tracking-wider">2. Sovereign Economic Valuation</h2>
                <div className="grid grid-cols-3 gap-4 border border-neutral-300 bg-neutral-50 p-4 rounded-sm text-center">
                  <div className="border-r border-neutral-200">
                    <span className="text-[8px] font-mono uppercase text-neutral-500 block">BASE ACQUISITION LIMIT</span>
                    <span className="text-base font-serif font-bold text-neutral-950">£{(selectedParcel.currentValue / 1000000).toFixed(2)}M</span>
                  </div>
                  <div className="border-r border-neutral-200">
                    <span className="text-[8px] font-mono uppercase text-neutral-500 block">ESTIMATED TARGET GDV</span>
                    <span className="text-base font-serif font-bold text-neutral-950">£{(selectedParcel.futureValue / 1000000).toFixed(2)}M</span>
                  </div>
                  <div>
                    <span className="text-[8px] font-mono uppercase text-neutral-500 block">EXPECTED NET VALUE JUMP</span>
                    <span className="text-base font-serif font-bold text-emerald-700">
                      +£{((selectedParcel.futureValue - selectedParcel.currentValue) / 1000000).toFixed(2)}M
                    </span>
                  </div>
                </div>
              </div>

              {/* Constraints Matrix */}
              <div className="space-y-3">
                <h2 className="text-sm font-mono font-black uppercase text-neutral-900 tracking-wider">3. Technical & Environmental Risk Profile</h2>
                <p className="text-xs text-neutral-800 font-serif">
                  Detailed site investigation validates the physical properties below. Specific planning safeguards and environmental covenants must be satisfied prior to construction release.
                </p>
                <div className="border border-neutral-200 rounded-sm">
                  <table className="w-full text-left text-xs font-mono">
                    <tbody className="divide-y divide-neutral-200">
                      <tr>
                        <td className="p-2.5 bg-neutral-50 font-bold text-neutral-900 w-1/3">Elevation & Slope:</td>
                        <td className="p-2.5 text-neutral-800">{selectedParcel.elevation}m above Ordnance Datum // {selectedParcel.slope}° average inclination</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 bg-neutral-50 font-bold text-neutral-900">Flood Classification:</td>
                        <td className="p-2.5 text-neutral-800 font-bold">{selectedParcel.floodZone} (Environment Agency assessment)</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 bg-neutral-50 font-bold text-neutral-900">Utilities Connectivity:</td>
                        <td className="p-2.5 text-neutral-800">{selectedParcel.utilities}</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 bg-neutral-50 font-bold text-neutral-900">Agricultural Soil Rating:</td>
                        <td className="p-2.5 text-neutral-800">{selectedParcel.agriculturalGrade}</td>
                      </tr>
                      <tr>
                        <td className="p-2.5 bg-neutral-50 font-bold text-neutral-900">Detected Restrictions:</td>
                        <td className="p-2.5 text-red-700 font-bold uppercase">{selectedParcel.envConstraints.join(", ") || "None Identified"}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Strategic Direction Recommendation */}
              <div className="space-y-3">
                <h2 className="text-sm font-mono font-black uppercase text-neutral-900 tracking-wider">4. Institutional Directives</h2>
                <div className="bg-neutral-50 border-l-4 border-neutral-900 p-4 text-xs font-serif italic text-neutral-800 leading-relaxed">
                  "Based on GIS Twin simulation modeling, the acquisition of parcel {selectedParcel.id} is strongly endorsed at or below £{(selectedParcel.currentValue / 1000000).toFixed(2)}M. Environmental risk buffers of {selectedParcel.classification === "Brownfield" ? "20" : "10"}% should be maintained within the developer S106 contingency model to offset Green Belt or flood zone overlays."
                </div>
              </div>

              {/* Institutional Signoffs */}
              <div className="pt-8 border-t border-neutral-300 grid grid-cols-2 gap-8 text-xs font-mono text-neutral-600">
                <div>
                  <div className="border-b border-neutral-400 h-10"></div>
                  <span className="block mt-1 uppercase font-bold text-neutral-900 text-[9px]">Sovereign Land Registrar Sign-off</span>
                  <span className="block text-[8px] text-neutral-400">EV-NLVIS REGISTER REVISION 2026</span>
                </div>
                <div>
                  <div className="border-b border-neutral-400 h-10"></div>
                  <span className="block mt-1 uppercase font-bold text-neutral-900 text-[9px]">Crown Estate Approval Stamp</span>
                  <span className="block text-[8px] text-neutral-400">DATE SECURED: _______________________</span>
                </div>
              </div>

            </div>
          </div>
        </div>
      )}

    </div>
  );
}
