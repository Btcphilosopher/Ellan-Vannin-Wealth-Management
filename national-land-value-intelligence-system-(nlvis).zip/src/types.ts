/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type LandClassification =
  | "Agricultural"
  | "Greenfield"
  | "Brownfield"
  | "Residential"
  | "Commercial"
  | "Industrial"
  | "Logistics"
  | "Mixed Use"
  | "Forestry"
  | "Public Land"
  | "Energy Infrastructure"
  | "Vacant Land"
  | "Urban Regeneration";

export interface Parcel {
  id: string;
  county: string;
  district: string;
  postcode: string;
  lat: number;
  lng: number;
  area: number; // in hectares
  boundary: Array<{ x: number; y: number }>; // local polygon coordinates for GIS mapping
  ownership: string;
  currentUse: string;
  previousUse?: string;
  planningStatus: "Allocated" | "Draft Allocation" | "Strategic Reserve" | "No Allocation" | "Planning Approved" | "Planning Refused" | "Under Review";
  floodZone: "Zone 1 (Low)" | "Zone 2 (Medium)" | "Zone 3 (High)";
  elevation: number; // in meters
  slope: number; // in degrees
  soilGrade: number; // Grade 1 to 5
  agriculturalGrade: "Grade 1 (Excellent)" | "Grade 2 (Good)" | "Grade 3 (Moderate)" | "Grade 4 (Poor)" | "Grade 5 (Very Poor)";
  existingBuildings: string;
  utilities: "Full Connection" | "Proximity Only" | "No Utilities" | "Off-Grid Only";
  envConstraints: string[];
  transportAccess: "Direct Motorway" | "Primary Road" | "Secondary Road" | "Rail Connection" | "Rural Lane";
  localPopulation: number;
  employmentDensity: number; // per sq km
  medianIncome: number; // £
  housePrices: number; // average £ per sqm
  commercialLandValue: number; // £ per hectare
  industrialLandValue: number; // £ per hectare
  currentValue: number; // Current calculated land value (£)
  futureValue: number; // Future value based on planning/infrastructure (£)
  classification: LandClassification;
  remediationCost?: number; // for brownfield sites
  expectedIrre?: number; // IRR for development
  regenerationScore?: number; // out of 100
}

export interface InfrastructureProject {
  id: string;
  name: string;
  type: "Railway Station" | "Metro Extension" | "Motorway Junction" | "Port" | "Airport" | "Hospital" | "University" | "Data Centre" | "Power Station" | "Business Park";
  lat: number;
  lng: number;
  cost: number; // in millions £
  status: "Under Construction" | "Proposed" | "Completed" | "Strategic Plan";
  valueUpliftRadiusKm: number; // radius of influence
  valueUpliftPercent: number; // land value increase inside radius
  gdpImpact: number; // in millions £
  privateInvestmentStimulated: number; // in millions £
}

export interface PortfolioAsset {
  id: string;
  name: string;
  location: string;
  classification: LandClassification;
  area: number;
  acquisitionCost: number; // £
  currentValue: number; // £
  rentalIncome: number; // £/annum
  vacancyRate: number; // %
  maintenanceCost: number; // £/annum
  irr: number; // %
  yield: number; // %
  esgScore: number; // out of 100 (Environmental Performance)
}

export interface ComparativeSale {
  id: string;
  location: string;
  date: string;
  area: number;
  price: number;
  pricePerHectare: number;
  use: string;
  similarity: number; // %
}

export interface DCFRow {
  year: number;
  cashInflow: number;
  cashOutflow: number;
  netCashFlow: number;
  discountFactor: number;
  pv: number;
}
