import React, { useState } from "react";
import { Parcel } from "../types";
import { Trees, AlertCircle, TrendingUp, ClipboardCheck } from "lucide-react";

interface RegenerationEngineProps {
  parcels: Parcel[];
  selectedParcel: Parcel | null;
  onSelectParcel: (parcel: Parcel) => void;
}

export default function RegenerationEngine({ parcels, selectedParcel, onSelectParcel }: RegenerationEngineProps) {
  // Filter only brownfield/industrial candidates
  const brownfieldParcels = parcels.filter(p => p.classification === "Brownfield" || p.classification === "Industrial" || p.remediationCost);

  // Focus on the currently selected parcel if it's brownfield, otherwise default to first brownfield
  const activeParcel = brownfieldParcels.find(p => p.id === selectedParcel?.id) || brownfieldParcels[0];

  // Configurable remediation states
  const [soilDecontaminationCost, setSoilDecontaminationCost] = useState<number>(activeParcel?.remediationCost ? Math.round(activeParcel.remediationCost * 0.5) : 800000);
  const [structuralDemolitionCost, setStructuralDemolitionCost] = useState<number>(activeParcel?.remediationCost ? Math.round(activeParcel.remediationCost * 0.3) : 400000);
  const [environmentalRiskBuffer, setEnvironmentalRiskBuffer] = useState<number>(15); // % contingency

  if (!activeParcel) {
    return (
      <div className="bg-[#0A0A0A] border border-white/5 p-6 text-center text-xs font-mono text-red-400 rounded-sm">
        No designated brownfield regeneration sites found in current registry.
      </div>
    );
  }

  // Cost and yield calculations
  const baseRemediationSubtotal = soilDecontaminationCost + structuralDemolitionCost;
  const riskContingencyCost = Math.round((baseRemediationSubtotal * environmentalRiskBuffer) / 100);
  const finalRemediationCost = baseRemediationSubtotal + riskContingencyCost;

  const grossUplift = activeParcel.futureValue - activeParcel.currentValue;
  const expectedIrr = activeParcel.expectedIrre ? activeParcel.expectedIrre - (finalRemediationCost / grossUplift) * 5 : 15.0;
  
  // Custom Regeneration Score (0-100)
  const calculateRegenScore = (p: Parcel) => {
    let score = 50;
    if (p.utilities === "Full Connection") score += 15;
    if (p.transportAccess === "Direct Motorway") score += 15;
    if (p.remediationCost && p.remediationCost < 1000000) score += 10;
    if (p.employmentDensity > 500) score += 10;
    score += Math.round((p.futureValue / p.currentValue) * 2);
    return Math.min(98, Math.max(10, score));
  };

  const regenScore = calculateRegenScore(activeParcel);

  return (
    <div className="bg-[#0A0A0A] border border-white/5 p-5 text-neutral-400 font-sans grid grid-cols-1 lg:grid-cols-3 gap-6 rounded-sm">
      
      {/* Brownfield Site Registry and Selection */}
      <div className="lg:col-span-1 bg-black/40 border border-white/5 p-4 space-y-4 rounded-sm">
        <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-2">
          <Trees className="w-4 h-4 text-[#00FF41]" />
          <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">Brownfield Registers</span>
        </div>
        
        <div className="space-y-1.5 max-h-[300px] overflow-y-auto">
          {brownfieldParcels.map(p => {
            const isActive = p.id === activeParcel.id;
            const score = calculateRegenScore(p);
            return (
              <div
                key={p.id}
                onClick={() => onSelectParcel(p)}
                className={`p-3 border cursor-pointer transition-all text-[10px] rounded-sm font-mono ${
                  isActive
                    ? "bg-white/5 border-[#00FF41] text-white font-bold"
                    : "bg-transparent border-white/5 hover:border-white/15 text-white/50"
                }`}
              >
                <div className="flex justify-between">
                  <span>{p.id}</span>
                  <span className="text-[#00FF41]">SCORE: {score}/100</span>
                </div>
                <div className="text-[8.5px] text-white/30 uppercase mt-1.5">{p.county} // {p.area} Ha</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Remediation Cost Modeler */}
      <div className="lg:col-span-1 bg-transparent p-4 border border-white/5 space-y-4 flex flex-col justify-between rounded-sm">
        <div>
          <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-2">
            <AlertCircle className="w-4 h-4 text-red-400" />
            <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">Remediation Estimator</span>
          </div>

          <div className="space-y-4 text-[11px] font-mono">
            <div>
              <div className="flex justify-between text-[10px] mb-1.5">
                <span>HAZARDOUS DECONTAMINATION</span>
                <span className="text-white font-bold">£{soilDecontaminationCost.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="100000"
                max="2500000"
                step="50000"
                value={soilDecontaminationCost}
                onChange={(e) => setSoilDecontaminationCost(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] mb-1.5">
                <span>DEMOLITION & SITE CLEARANCE</span>
                <span className="text-white font-bold">£{structuralDemolitionCost.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="50000"
                max="1000000"
                step="25000"
                value={structuralDemolitionCost}
                onChange={(e) => setStructuralDemolitionCost(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] mb-1.5">
                <span>RISK MITIGATION PLEDGES</span>
                <span className="text-yellow-400 font-bold">+{environmentalRiskBuffer}%</span>
              </div>
              <input
                type="range"
                min="5"
                max="30"
                step="1"
                value={environmentalRiskBuffer}
                onChange={(e) => setEnvironmentalRiskBuffer(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>
          </div>
        </div>

        <div className="bg-black/40 border border-white/5 p-3 text-[10px] space-y-1.5 mt-2 rounded-sm font-mono">
          <div className="flex justify-between text-white/40">
            <span>Reclamation Base Subtotal:</span>
            <span className="text-white">£{baseRemediationSubtotal.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-red-400">
            <span>[+] Contingency Buffer:</span>
            <span>£{riskContingencyCost.toLocaleString()}</span>
          </div>
          <div className="flex justify-between font-bold text-white border-t border-white/10 pt-2 mt-2">
            <span>FINAL CLEANUP ESTIMATE:</span>
            <span className="text-[#00FF41]">£{finalRemediationCost.toLocaleString()}</span>
          </div>
        </div>
      </div>

      {/* Viability and Scoring Outputs */}
      <div className="lg:col-span-1 bg-white/5 border border-white/10 p-5 flex flex-col justify-between rounded-sm">
        <div>
          <span className="text-[10px] font-bold text-[#00FF41] uppercase tracking-wider block font-mono mb-2">RECONSTRUCTION FEASIBILITY</span>
          <div className="text-2xl font-bold font-mono text-white border-b border-white/10 pb-3 mb-4">
            £{finalRemediationCost.toLocaleString()}
            <span className="text-[9px] block text-white/40 font-sans font-normal mt-1">Sovereign environmental cleaning allocation</span>
          </div>

          <div className="space-y-3.5 text-xs font-mono">
            <div className="flex justify-between">
              <span className="flex items-center gap-1.5 text-white/40"><ClipboardCheck className="w-3.5 h-3.5 text-[#00FF41]" /> REGEN OPPORTUNITY SCORE:</span>
              <span className="font-extrabold text-white">{regenScore} / 100</span>
            </div>
            <div className="flex justify-between">
              <span className="flex items-center gap-1.5 text-white/40"><TrendingUp className="w-3.5 h-3.5 text-[#00FF41]" /> RECALCULATED MARGIN IRR:</span>
              <span className="font-extrabold text-[#00FF41]">{expectedIrr.toFixed(1)}%</span>
            </div>
            <div className="flex justify-between">
              <span className="flex items-center gap-1.5 text-white/40"><AlertCircle className="w-3.5 h-3.5 text-yellow-400" /> INFRASTRUCTURE CONNECTION:</span>
              <span className="font-bold text-white block truncate max-w-[120px]">{activeParcel.utilities}</span>
            </div>
          </div>
        </div>

        <div className="text-[9px] bg-black/40 p-3 mt-4 text-white/30 rounded-xs font-mono">
          {expectedIrr > 15 ? (
            <span className="text-[#00FF41] font-bold">✓ VIABLE: Brownfield reclamation complies with Ellan Vannin sovereign return-hurdles.</span>
          ) : (
            <span className="text-yellow-400 font-bold">⚠ ASSIGNED RISK: Explore municipal reclamation tax offsets or public-private subsidies.</span>
          )}
        </div>
      </div>
    </div>
  );
}
