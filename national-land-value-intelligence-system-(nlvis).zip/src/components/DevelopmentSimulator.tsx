import React, { useState } from "react";
import { Parcel } from "../types";
import { Hammer, ChevronRight } from "lucide-react";

interface DevelopmentSimulatorProps {
  parcel: Parcel;
}

export default function DevelopmentSimulator({ parcel }: DevelopmentSimulatorProps) {
  // Simulator Parameters
  const [densityUnits, setDensityUnits] = useState<number>(Math.round(parcel.area * 12)); // default units
  const [salesPricePerUnit, setSalesPricePerUnit] = useState<number>(310000); // £ per residential unit
  const [contingencyPct, setContingencyPct] = useState<number>(10); // % contingency buffer
  const [buildTimeMonths, setBuildTimeMonths] = useState<number>(24);

  // Computed Values
  const totalGdExitValue = densityUnits * salesPricePerUnit;
  const baseLandAcquisition = parcel.currentValue;
  const zoningPlanningCost = Math.round(parcel.currentValue * 0.15); // legal/lobbying/fees
  const directBuildCosts = Math.round(densityUnits * 145000); // average unit build cost £145k
  const contingencyCost = Math.round((directBuildCosts * contingencyPct) / 100);
  const totalOutlays = baseLandAcquisition + zoningPlanningCost + directBuildCosts + contingencyCost;
  
  const realizedNetProfit = totalGdExitValue - totalOutlays;
  const returnOnCapitalPct = ((realizedNetProfit / totalOutlays) * 100) || 0;

  // Active Stage Highlight state
  const [activeStage, setActiveStage] = useState<number>(0);

  const stages = [
    { title: "Strategic Land Acquisition", desc: "Acquiring low-value agricultural or greenfield reserves.", cost: `£${baseLandAcquisition.toLocaleString()}` },
    { title: "Local Plan Rezoning", desc: "Securing strategic local development allocations.", cost: `£${zoningPlanningCost.toLocaleString()}` },
    { title: "Full Planning Approvals", desc: "BREEAM design signs, S106 drafts & site layouts.", cost: "£250,000" },
    { title: "Civil Infrastructure & Build", desc: "Constructing core road grids, utilities, and units.", cost: `£${(directBuildCosts + contingencyCost).toLocaleString()}` },
    { title: "Exit Disposal / Asset Delivery", desc: "Sovereign lease disposal or retail residential sales.", cost: `£${totalGdExitValue.toLocaleString()} (Disposal Value)` }
  ];

  return (
    <div className="bg-[#0A0A0A] border border-white/5 p-5 text-neutral-400 font-sans grid grid-cols-1 lg:grid-cols-3 gap-6 rounded-sm">
      
      {/* Parameter Adjustment Panel */}
      <div className="lg:col-span-1 space-y-4 p-4 bg-black/40 border border-white/5 rounded-sm">
        <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-2">
          <Hammer className="w-4 h-4 text-[#00FF41]" />
          <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">Development Sandbox</span>
        </div>

        <div className="space-y-4 text-[11px] font-mono">
          <div>
            <div className="flex justify-between text-[10px] mb-1.5">
              <span>PROPOSED UNIT DENSITY</span>
              <span className="text-[#00FF41] font-bold">{densityUnits} Units</span>
            </div>
            <input
              type="range"
              min={Math.round(parcel.area * 4)}
              max={Math.round(parcel.area * 25)}
              step="10"
              value={densityUnits}
              onChange={(e) => setDensityUnits(parseInt(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
            />
            <span className="text-[8px] text-white/30 block mt-1">Recommended density limit: ~{(parcel.area * 20).toFixed(0)} units</span>
          </div>

          <div>
            <div className="flex justify-between text-[10px] mb-1.5">
              <span>TARGET SALES VALUATION</span>
              <span className="text-[#00FF41] font-bold">£{salesPricePerUnit.toLocaleString()} / Unit</span>
            </div>
            <input
              type="range"
              min="180000"
              max="650000"
              step="10000"
              value={salesPricePerUnit}
              onChange={(e) => setSalesPricePerUnit(parseInt(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
            />
          </div>

          <div>
            <div className="flex justify-between text-[10px] mb-1.5">
              <span>CIVIL RISK CONTINGENCY</span>
              <span className="text-yellow-400 font-bold">{contingencyPct}% Contingency</span>
            </div>
            <input
              type="range"
              min="5"
              max="25"
              step="1"
              value={contingencyPct}
              onChange={(e) => setContingencyPct(parseInt(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
            />
          </div>

          <div>
            <div className="flex justify-between text-[10px] mb-1.5">
              <span>CONSTRUCTION HORIZON</span>
              <span className="text-[#00FF41] font-bold">{buildTimeMonths} Months</span>
            </div>
            <input
              type="range"
              min="12"
              max="48"
              step="3"
              value={buildTimeMonths}
              onChange={(e) => setBuildTimeMonths(parseInt(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
            />
          </div>
        </div>
      </div>

      {/* Exit Feasibility Metrics / Chart representation */}
      <div className="lg:col-span-2 space-y-4 flex flex-col justify-between">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono">
          <div className="bg-[#00FF41]/5 border border-[#00FF41]/20 p-3 text-center rounded-sm">
            <span className="text-[8px] text-white/30 font-bold uppercase block mb-1">EXIT REVENUE (GDV)</span>
            <span className="text-sm font-bold text-white">£{(totalGdExitValue / 1000000).toFixed(2)}M</span>
          </div>
          <div className="bg-red-500/5 border border-red-500/20 p-3 text-center rounded-sm">
            <span className="text-[8px] text-white/30 font-bold uppercase block mb-1">CONSTRUCTION OUTLAYS</span>
            <span className="text-sm font-bold text-red-400">£{(totalOutlays / 1000000).toFixed(2)}M</span>
          </div>
          <div className="bg-white/5 border border-white/10 p-3 text-center rounded-sm">
            <span className="text-[8px] text-white/30 font-bold uppercase block mb-1">RETURN ON CAPITAL</span>
            <span className={`text-sm font-bold ${realizedNetProfit >= 0 ? "text-[#00FF41]" : "text-red-400"}`}>
              {returnOnCapitalPct.toFixed(1)}%
            </span>
          </div>
        </div>

        {/* Milestone tracking cards */}
        <div className="space-y-3.5 p-4 bg-black/40 border border-white/5 rounded-sm">
          <span className="text-[10px] font-bold text-white uppercase tracking-wider block font-mono">Development Milestone Covenants</span>
          
          <div className="grid grid-cols-5 gap-1.5 text-[9px] text-center font-bold font-mono">
            {stages.map((stage, idx) => (
              <button
                key={idx}
                onClick={() => setActiveStage(idx)}
                className={`p-2 border transition-all flex flex-col items-center justify-between min-h-[70px] rounded-sm cursor-pointer ${
                  activeStage === idx
                    ? "bg-white/5 border-[#00FF41] text-white"
                    : "bg-transparent border-white/5 hover:border-white/10 text-white/40"
                }`}
              >
                <span>STAGE 0{idx + 1}</span>
                <ChevronRight className="w-3.5 h-3.5 transform rotate-90 my-1 text-[#00FF41]" />
                <span className="text-[7.5px] truncate max-w-full font-bold">{stage.cost}</span>
              </button>
            ))}
          </div>

          <div className="bg-white/5 border border-white/10 p-3 text-[10px] space-y-1 rounded-sm font-mono">
            <div className="flex justify-between font-bold text-white">
              <span className="text-[#00FF41] uppercase">{stages[activeStage].title}</span>
              <span className="text-[8px] bg-[#00FF41]/15 border border-[#00FF41]/25 px-1 rounded-xs text-[#00FF41] font-bold">ACTIVE PHASE</span>
            </div>
            <p className="text-white/50 leading-relaxed text-[9px] mt-1">{stages[activeStage].desc}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
