import React, { useState } from "react";
import { PortfolioAsset } from "../types";
import { SOVEREIGN_PORTFOLIO } from "../data";
import { Sliders } from "lucide-react";

export default function PortfolioManager() {
  const [portfolioList, setPortfolioList] = useState<PortfolioAsset[]>(SOVEREIGN_PORTFOLIO);
  const [selectedAssetIdx, setSelectedAssetIdx] = useState<number>(0);

  const activeAsset = portfolioList[selectedAssetIdx];

  // Handler to let analysts tune properties dynamically in real-time
  const handleTuneProperty = (field: "rentalIncome" | "maintenanceCost", value: number) => {
    setPortfolioList(prev => {
      const updated = [...prev];
      const target = { ...updated[selectedAssetIdx] };
      
      if (field === "rentalIncome") {
        target.rentalIncome = value;
      } else {
        target.maintenanceCost = value;
      }
      
      // Recalculate Yield based on current appraised value
      target.yield = parseFloat(((target.rentalIncome / target.currentValue) * 100).toFixed(2));
      // Recalculate estimated IRR based on net yields
      const netYield = ((target.rentalIncome - target.maintenanceCost) / target.currentValue) * 100;
      target.irr = parseFloat((netYield * 1.8).toFixed(2));

      updated[selectedAssetIdx] = target;
      return updated;
    });
  };

  return (
    <div className="bg-[#0A0A0A] border border-white/5 p-5 text-neutral-400 font-sans grid grid-cols-1 lg:grid-cols-3 gap-6 rounded-sm">
      
      {/* Portfolio holdings list */}
      <div className="lg:col-span-2 space-y-4">
        <div className="flex justify-between items-center border-b border-white/10 pb-3 mb-2">
          <span className="text-[11px] font-bold text-white uppercase tracking-wider font-mono">Portfolio Asset Registry</span>
          <span className="text-[8px] bg-[#00FF41]/10 border border-[#00FF41]/20 text-[#00FF41] font-bold font-mono px-2 py-0.5 rounded-xs">SECURE CROWN REGISTER</span>
        </div>

        <div className="overflow-x-auto border border-white/5 bg-black rounded-sm">
          <table className="w-full text-left text-[10px] font-mono">
            <thead className="bg-white/5 text-white/40 uppercase font-bold sticky top-0 border-b border-white/10">
              <tr>
                <th className="p-3">Asset Name</th>
                <th className="p-3">Classification</th>
                <th className="p-3 text-right">Cost Basis</th>
                <th className="p-3 text-right">Appraisal</th>
                <th className="p-3 text-right">Yield</th>
                <th className="p-3 text-right text-center">ESG</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {portfolioList.map((asset, idx) => {
                const isSelected = idx === selectedAssetIdx;
                return (
                  <tr
                    key={asset.id}
                    onClick={() => setSelectedAssetIdx(idx)}
                    className={`cursor-pointer transition-all ${
                      isSelected ? "bg-white/5 text-white font-bold" : "hover:bg-white/5 text-white/50"
                    }`}
                  >
                    <td className="p-3 font-semibold">{asset.name}</td>
                    <td className="p-3 text-[9px] uppercase font-bold text-[#00FF41]">{asset.classification}</td>
                    <td className="p-3 text-right text-white/40">£{(asset.acquisitionCost / 1000000).toFixed(1)}M</td>
                    <td className="p-3 text-right text-white font-bold">£{(asset.currentValue / 1000000).toFixed(1)}M</td>
                    <td className="p-3 text-right text-[#00FF41] font-bold">{asset.yield}%</td>
                    <td className="p-3 text-center">
                      <span className={`px-1.5 py-0.5 text-[8px] font-bold rounded-xs ${
                        asset.esgScore >= 85 ? "bg-[#00FF41]/10 text-[#00FF41] border border-[#00FF41]/25" : "bg-yellow-400/10 text-yellow-400 border border-yellow-400/25"
                      }`}>
                        {asset.esgScore}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Operational Adjustments & ESG scorecard */}
      <div className="lg:col-span-1 bg-black/40 border border-white/5 p-4 flex flex-col justify-between rounded-sm">
        <div className="space-y-4">
          <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-2">
            <Sliders className="w-4 h-4 text-[#00FF41]" />
            <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">Asset Benchmarks</span>
          </div>

          <div className="space-y-4 text-[11px] font-mono">
            <h4 className="text-xs font-bold text-white border-b border-white/5 pb-1.5">{activeAsset.name}</h4>
            
            {/* Rental Income Slide */}
            <div>
              <div className="flex justify-between text-[10px] mb-1.5">
                <span>ANNUAL COVENANT INCOME</span>
                <span className="text-[#00FF41] font-bold">£{activeAsset.rentalIncome.toLocaleString()}/yr</span>
              </div>
              <input
                type="range"
                min={Math.round(activeAsset.rentalIncome * 0.5)}
                max={Math.round(activeAsset.rentalIncome * 1.8)}
                step="50000"
                value={activeAsset.rentalIncome}
                onChange={(e) => handleTuneProperty("rentalIncome", parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            {/* Maintenance Costs Slide */}
            <div>
              <div className="flex justify-between text-[10px] mb-1.5">
                <span>MAINTENANCE PROVISIONS (OpEx)</span>
                <span className="text-red-400 font-bold">£{activeAsset.maintenanceCost.toLocaleString()}/yr</span>
              </div>
              <input
                type="range"
                min="20000"
                max={Math.round(activeAsset.rentalIncome * 0.45)}
                step="5000"
                value={activeAsset.maintenanceCost}
                onChange={(e) => handleTuneProperty("maintenanceCost", parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            {/* ESG & Performance benchmarks */}
            <div className="space-y-2 border-t border-white/5 pt-3.5 mt-2 text-[10px]">
              <div className="flex justify-between items-center">
                <span>ENVIRONMENTAL SCORE:</span>
                <span className="text-[#00FF41] font-bold">{activeAsset.esgScore} / 100</span>
              </div>
              <div className="flex justify-between items-center">
                <span>TARGET STABILIZED IRR:</span>
                <span className="text-white font-bold">{activeAsset.irr}%</span>
              </div>
              <div className="flex justify-between items-center">
                <span>PORTFOLIO VACANCY FRACTION:</span>
                <span className="text-yellow-400 font-bold">{activeAsset.vacancyRate}% Vacant</span>
              </div>
            </div>
          </div>
        </div>

        <div className="text-[9px] bg-black/40 border border-white/5 p-3 mt-4 text-white/30 rounded-xs font-mono">
          <span className="text-[#00FF41] font-bold">✓ STABLE COVENANTS: Sovereignty filters report robust backing buffers and negligible risk profiles.</span>
        </div>
      </div>
    </div>
  );
}
