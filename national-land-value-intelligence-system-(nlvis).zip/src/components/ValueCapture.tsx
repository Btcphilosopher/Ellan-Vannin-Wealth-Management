import React, { useState } from "react";
import { InfrastructureProject } from "../types";
import { INFRASTRUCTURE_PROJECTS } from "../data";
import { Building, Landmark, BarChart } from "lucide-react";

export default function ValueCapture() {
  const [selectedProj, setSelectedProj] = useState<InfrastructureProject>(INFRASTRUCTURE_PROJECTS[0]);

  // Configurable sliders
  const [budgetCost, setBudgetCost] = useState<number>(selectedProj.cost); // £M
  const [influenceRadius, setInfluenceRadius] = useState<number>(selectedProj.valueUpliftRadiusKm); // km
  const [upliftPercent, setUpliftPercent] = useState<number>(selectedProj.valueUpliftPercent); // %

  // Computations based on macroeconomic multiplier models
  const totalLandValueUplift = Math.round(budgetCost * (upliftPercent / 100) * 4.2); // £M value capture spillover
  const annualCouncilTaxGrowth = Math.round(totalLandValueUplift * 0.015 * 100000); // £ per annum
  const annualBusinessRatesGrowth = Math.round(totalLandValueUplift * 0.025 * 100000); // £ per annum
  const stampDutyPotential = Math.round(totalLandValueUplift * 0.045 * 1000000); // stamp duty windfall (£)
  
  const privateInvestmentMultiplier = Math.round(budgetCost * 3.2); // £M stimulated
  const regionalGdpContribution = Math.round(totalLandValueUplift * 1.8); // £M GDP impact

  return (
    <div className="bg-[#0A0A0A] border border-white/5 p-5 text-neutral-400 font-sans grid grid-cols-1 lg:grid-cols-3 gap-6 rounded-sm">
      
      {/* Infrastructure Project Selector Grid */}
      <div className="lg:col-span-1 bg-black/40 border border-white/5 p-4 space-y-4 rounded-sm">
        <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-2">
          <Building className="w-4 h-4 text-[#00FF41]" />
          <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">Infrastructure Nodes</span>
        </div>

        <div className="space-y-1.5 max-h-[300px] overflow-y-auto">
          {INFRASTRUCTURE_PROJECTS.map(proj => {
            const isSelected = proj.id === selectedProj.id;
            return (
              <div
                key={proj.id}
                onClick={() => {
                  setSelectedProj(proj);
                  setBudgetCost(proj.cost);
                  setInfluenceRadius(proj.valueUpliftRadiusKm);
                  setUpliftPercent(proj.valueUpliftPercent);
                }}
                className={`p-3 border cursor-pointer transition-all text-[10px] rounded-sm font-mono ${
                  isSelected
                    ? "bg-white/5 border-[#00FF41] text-white font-bold"
                    : "bg-transparent border-white/5 hover:border-white/20 text-white/50"
                }`}
              >
                <div className="flex justify-between">
                  <span>{proj.name}</span>
                  <span className="text-[#00FF41]">£{proj.cost}M</span>
                </div>
                <div className="text-[8px] text-white/30 uppercase mt-1.5">{proj.type} // {proj.status}</div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Value Capture Modeler Sliders */}
      <div className="lg:col-span-1 bg-transparent p-4 border border-white/5 space-y-4 flex flex-col justify-between rounded-sm">
        <div>
          <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-2">
            <BarChart className="w-4 h-4 text-yellow-400" />
            <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">Macro Spillover Sliders</span>
          </div>

          <div className="space-y-4 text-[11px] font-mono">
            <div>
              <div className="flex justify-between text-[10px] mb-1.5">
                <span>PROJECT CAPITAL BUDGET</span>
                <span className="text-[#00FF41] font-bold">£{budgetCost} Million</span>
              </div>
              <input
                type="range"
                min="10"
                max="1000"
                step="10"
                value={budgetCost}
                onChange={(e) => setBudgetCost(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] mb-1.5">
                <span>VALUE IMPACT RADIUS</span>
                <span className="text-yellow-400 font-bold">{influenceRadius} km Buffer</span>
              </div>
              <input
                type="range"
                min="1"
                max="10"
                step="1"
                value={influenceRadius}
                onChange={(e) => setInfluenceRadius(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] mb-1.5">
                <span>VALUATION UPLIFT FACTOR</span>
                <span className="text-[#00FF41] font-bold">+{upliftPercent}% Valuation Jump</span>
              </div>
              <input
                type="range"
                min="5"
                max="50"
                step="1"
                value={upliftPercent}
                onChange={(e) => setUpliftPercent(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>
          </div>
        </div>

        <div className="bg-black/40 border border-white/5 p-3 text-[10px] space-y-1.5 mt-2 rounded-sm font-mono">
          <span className="font-bold text-white/40 block uppercase tracking-wide">Macro Impact Estimates</span>
          <div className="flex justify-between">
            <span>Aggregated Spillover Land Value:</span>
            <span className="text-[#00FF41] font-bold">£{totalLandValueUplift}M</span>
          </div>
          <div className="flex justify-between">
            <span>Private Capital Leveraged:</span>
            <span className="text-white font-bold">£{privateInvestmentMultiplier}M</span>
          </div>
        </div>
      </div>

      {/* Captured Public Tax and Growth Indicators */}
      <div className="lg:col-span-1 bg-white/5 border border-white/10 p-5 flex flex-col justify-between rounded-sm">
        <div>
          <span className="text-[10px] font-bold text-[#00FF41] uppercase tracking-wider block mb-2 font-mono">Tax Capture Windfall</span>
          <div className="text-2xl font-bold font-mono text-white border-b border-white/10 pb-3 mb-4">
            £{(stampDutyPotential / 1000000).toFixed(1)}M
            <span className="text-[9px] block text-white/40 font-sans font-normal mt-1">Estimated Stamp Duty Land Tax (SDLT) captured</span>
          </div>

          <div className="space-y-3.5 text-xs text-white/50 font-mono">
            <div className="flex justify-between">
              <span className="flex items-center gap-1.5 text-white/40"><Landmark className="w-3.5 h-3.5 text-[#00FF41]" /> Council Tax Base Growth:</span>
              <span className="font-bold text-white">£{annualCouncilTaxGrowth.toLocaleString()}/yr</span>
            </div>
            <div className="flex justify-between">
              <span className="flex items-center gap-1.5 text-white/40"><Building className="w-3.5 h-3.5 text-yellow-400" /> Business Rates Base:</span>
              <span className="font-bold text-white">£{annualBusinessRatesGrowth.toLocaleString()}/yr</span>
            </div>
            <div className="flex justify-between border-t border-white/10 pt-3">
              <span className="text-white/30">Total Regional GDP Impact:</span>
              <span className="font-black text-[#00FF41]">£{regionalGdpContribution}M</span>
            </div>
          </div>
        </div>

        <div className="text-[9px] bg-black/40 p-3 mt-4 text-white/30 rounded-xs font-mono">
          <span className="text-[#00FF41] font-bold">✓ EFFICIENCY: Infrastructure yields 4.2x sovereign multiplier on aggregate regional wealth.</span>
        </div>
      </div>
    </div>
  );
}
