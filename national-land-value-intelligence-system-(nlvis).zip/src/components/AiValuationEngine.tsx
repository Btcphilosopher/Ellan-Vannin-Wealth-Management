import React, { useState } from "react";
import { Parcel } from "../types";
import { HEDONIC_WEIGHTS } from "../data";
import { Cpu, Activity, TrendingUp } from "lucide-react";

interface AiValuationEngineProps {
  parcel: Parcel;
}

export default function AiValuationEngine({ parcel }: AiValuationEngineProps) {
  // Analytical Sliders representing hedonic pricing factors
  const [distanceToTransitKm, setDistanceToTransitKm] = useState<number>(1.2); // km
  const [popDensityFactor, setPopDensityFactor] = useState<number>(parcel.employmentDensity); // density per sq km
  const [utilityConnectivityBonus, setUtilityConnectivityBonus] = useState<number>(1.15); // multiplier
  const [planningConsentWeight, setPlanningConsentWeight] = useState<number>(
    parcel.planningStatus === "Planning Approved" ? 3.5 : parcel.planningStatus === "Allocated" ? 2.2 : 1.1
  );

  // Core linear hedonic estimation logic
  const calculateHedonicPrediction = () => {
    const baseValue = HEDONIC_WEIGHTS.intercept;
    const sizeComponent = parcel.area * HEDONIC_WEIGHTS.areaHectareMultiplier;
    
    // Proximity factor
    const proximityDiscount = Math.max(0.5, 1.5 - distanceToTransitKm * 0.15);
    
    // Density scaling
    const densityScaler = 1 + (popDensityFactor / 5000);

    const calculatedValue = Math.round(
      (baseValue + sizeComponent) *
      proximityDiscount *
      densityScaler *
      utilityConnectivityBonus *
      planningConsentWeight
    );

    return calculatedValue;
  };

  const predictedValue = calculateHedonicPrediction();
  const lowerConfidenceBound = Math.round(predictedValue * 0.88);
  const upperConfidenceBound = Math.round(predictedValue * 1.12);

  // Sample residuals data points representing prediction scatter (Predicted, Actual)
  const residualsPoints = [
    { pred: 1.8, act: 1.85, id: "NLVIS-001" },
    { pred: 3.2, act: 3.50, id: "NLVIS-002" },
    { pred: 2.7, act: 2.90, id: "NLVIS-003" },
    { pred: 8.9, act: 8.40, id: "NLVIS-004" },
    { pred: 4.5, act: 4.10, id: "NLVIS-005" },
    { pred: 5.8, act: 6.20, id: "NLVIS-006" },
    { pred: 2.0, act: 2.20, id: "NLVIS-007" },
    { pred: 3.4, act: 3.10, id: "NLVIS-008" },
    { pred: 4.8, act: 4.50, id: "NLVIS-009" }
  ];

  return (
    <div className="bg-[#0A0A0A] border border-white/5 p-5 text-neutral-400 font-sans grid grid-cols-1 lg:grid-cols-3 gap-6 rounded-sm">
      
      {/* Parameter Control Panel */}
      <div className="lg:col-span-1 p-4 bg-black/40 border border-white/5 space-y-4 rounded-sm">
        <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-2">
          <Cpu className="w-4 h-4 text-[#00FF41]" />
          <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">Hedonic Parameters</span>
        </div>

        <div className="space-y-4 text-[11px] font-mono">
          <div>
            <div className="flex justify-between text-[10px] mb-1.5">
              <span>PROXIMITY TO TRANSIT HUB</span>
              <span className="text-[#00FF41] font-bold">{distanceToTransitKm.toFixed(1)} km</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="15.0"
              step="0.1"
              value={distanceToTransitKm}
              onChange={(e) => setDistanceToTransitKm(parseFloat(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
            />
          </div>

          <div>
            <div className="flex justify-between text-[10px] mb-1.5">
              <span>LOCAL EMPLOYMENT DENSITY</span>
              <span className="text-[#00FF41] font-bold">{popDensityFactor.toLocaleString()} / km²</span>
            </div>
            <input
              type="range"
              min="10"
              max="5000"
              step="50"
              value={popDensityFactor}
              onChange={(e) => setPopDensityFactor(parseInt(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
            />
          </div>

          <div>
            <div className="flex justify-between text-[10px] mb-1.5">
              <span>GRID UTILITIES MULTIPLIER</span>
              <span className="text-yellow-400 font-bold">{utilityConnectivityBonus.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.80"
              max="1.50"
              step="0.05"
              value={utilityConnectivityBonus}
              onChange={(e) => setUtilityConnectivityBonus(parseFloat(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
            />
          </div>

          <div>
            <div className="flex justify-between text-[10px] mb-1.5">
              <span>PLANNING CONSENT MULTIPLIER</span>
              <span className="text-[#00FF41] font-bold">{planningConsentWeight.toFixed(2)}x</span>
            </div>
            <input
              type="range"
              min="0.5"
              max="4.0"
              step="0.1"
              value={planningConsentWeight}
              onChange={(e) => setPlanningConsentWeight(parseFloat(e.target.value))}
              className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
            />
          </div>
        </div>
      </div>

      {/* Model Performance Comparison Stats */}
      <div className="lg:col-span-1 bg-transparent border border-white/5 p-4 flex flex-col justify-between rounded-sm">
        <div>
          <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-2">
            <Activity className="w-4 h-4 text-[#00FF41]" />
            <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">Model Benchmarks</span>
          </div>

          <div className="space-y-1.5 text-[10px] font-mono">
            {[
              { name: "XGBoost Spatial Regressor", r2: "0.96", rmse: "£62,000", status: "PRIMARY" },
              { name: "Random Forest Ensemble", r2: "0.94", rmse: "£85,000", status: "VALIDATED" },
              { name: "Hedonic Pricing Calibration", r2: "0.86", rmse: "£185,000", status: "ACTIVE" },
              { name: "Ordinary Least Squares (OLS)", r2: "0.81", rmse: "£240,000", status: "BENCHMARK" }
            ].map((model, idx) => (
              <div key={idx} className="bg-black/40 border border-white/5 p-2 flex justify-between items-center rounded-xs">
                <div>
                  <div className="font-bold text-white">{model.name}</div>
                  <div className="text-[8px] text-white/30">RMSE: {model.rmse}</div>
                </div>
                <div className="text-right">
                  <div className="text-[#00FF41] font-bold">R² {model.r2}</div>
                  <span className="text-[7px] text-[#00FF41] bg-[#00FF41]/10 border border-[#00FF41]/20 px-1 py-0.5 rounded-xs">{model.status}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Confidence Interval Scatter Chart */}
        <div className="mt-4 font-mono">
          <span className="text-[8px] text-white/30 uppercase tracking-wider block mb-1.5">Model Residuals Plot (Actual vs Pred)</span>
          <div className="border border-white/5 bg-black h-[100px] relative p-1.5 rounded-sm">
            <svg className="w-full h-full" viewBox="0 0 100 50">
              {/* Regression line */}
              <line x1="10" y1="40" x2="90" y2="10" stroke="#00FF41" strokeWidth="0.5" strokeDasharray="1,1" />
              
              {/* 95% Confidence Interval Bands */}
              <path d="M 10 37 L 90 7 L 90 13 L 10 43 Z" fill="rgba(0, 255, 65, 0.03)" />

              {/* Data points */}
              {residualsPoints.map((pt, idx) => {
                const cx = 10 + (pt.pred / 10) * 80;
                const cy = 45 - (pt.act / 10) * 40;
                return (
                  <circle
                    key={idx}
                    cx={cx}
                    cy={cy}
                    r="1"
                    fill={idx % 2 === 0 ? "#00FF41" : "#EAB308"}
                    title={`${pt.id}: Pred £${pt.pred}M vs Act £${pt.act}M`}
                  />
                );
              })}
            </svg>
            <div className="absolute bottom-1 right-2 text-[6.5px] text-white/30 flex gap-2 font-bold">
              <span className="flex items-center gap-0.5"><span className="w-1 h-1 bg-[#00FF41] rounded-full"/> VALID</span>
              <span className="flex items-center gap-0.5"><span className="w-1 h-1 bg-[#EAB308] rounded-full"/> OUTLIER</span>
            </div>
          </div>
        </div>
      </div>

      {/* AI Predicted Valuation Panel */}
      <div className="lg:col-span-1 bg-white/5 border border-white/10 p-5 flex flex-col justify-between rounded-sm">
        <div>
          <span className="text-[10px] font-bold text-[#00FF41] uppercase tracking-wider block font-mono mb-2">HEDONIC REGRESSION VALUATION</span>
          <div className="text-2xl font-bold font-mono text-white border-b border-white/10 pb-3 mb-4">
            £{predictedValue.toLocaleString()}
            <span className="text-[9px] block text-white/40 font-sans font-normal mt-1">Sovereign valuation algorithm baseline target</span>
          </div>

          <div className="space-y-3.5 text-xs text-white/50 font-mono">
            <div className="flex justify-between">
              <span className="flex items-center gap-1.5 text-white/40"><TrendingUp className="w-3.5 h-3.5 text-[#00FF41]" /> Lower Confidence Bound (95%):</span>
              <span className="font-bold text-white">£{lowerConfidenceBound.toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="flex items-center gap-1.5 text-white/40"><TrendingUp className="w-3.5 h-3.5 text-yellow-400" /> Upper Confidence Bound (95%):</span>
              <span className="font-bold text-white">£{upperConfidenceBound.toLocaleString()}</span>
            </div>
            <div className="flex justify-between border-t border-white/10 pt-3">
              <span className="text-white/30 font-sans">OLS Adjusted R-Squared:</span>
              <span className="font-black text-[#00FF41]">0.864</span>
            </div>
          </div>
        </div>

        <div className="text-[9px] bg-black/40 p-3 mt-4 text-white/30 rounded-xs font-mono">
          {predictedValue > parcel.currentValue ? (
            <span className="text-[#00FF41] font-bold">✓ OPPORTUNITY DETECTED: ML model indicates current Crown register book value is discounted relative to hedonic potential.</span>
          ) : (
            <span className="text-yellow-400 font-bold">⚠ FULLY APPRECIATED: Model estimates property currently priced at parity with regional baseline indexes.</span>
          )}
        </div>
      </div>
    </div>
  );
}
