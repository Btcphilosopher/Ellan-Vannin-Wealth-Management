import React, { useState } from "react";
import { Parcel } from "../types";
import { HISTORIC_SALES } from "../data";
import { Calculator, Percent, DollarSign, Activity, Layers } from "lucide-react";

interface ValuationEngineProps {
  parcel: Parcel;
}

export default function ValuationEngine({ parcel }: ValuationEngineProps) {
  const [activeMethod, setActiveMethod] = useState<"comparables" | "residual" | "income" | "dcf">("comparables");

  // State for Residual Land Valuation Calculator
  const [gdv, setGdv] = useState<number>(parcel.futureValue || 15000000);
  const [constructionCost, setConstructionCost] = useState<number>(Math.round(gdv * 0.45));
  const [financeCostRate, setFinanceCostRate] = useState<number>(6.5); // %
  const [professionalFeesPct, setProfessionalFeesPct] = useState<number>(8); // %
  const [developerProfitPct, setDeveloperProfitPct] = useState<number>(18); // %
  const [infraPlanningObligations, setInfraPlanningObligations] = useState<number>(Math.round(gdv * 0.05));

  // State for Income Capitalisation
  const [noi, setNoi] = useState<number>(Math.round(parcel.currentValue * 0.065));
  const [capRate, setCapRate] = useState<number>(6.2); // %
  const [rentalGrowth, setRentalGrowth] = useState<number>(3.5); // % per annum

  // State for Discounted Cash Flow
  const [discountRate, setDiscountRate] = useState<number>(8.0); // %
  const [years, setYears] = useState<number>(10);

  // --- Calculations ---

  // 1. Comparables
  const relevantSales = HISTORIC_SALES.filter(
    s => s.use === parcel.classification || s.similarity >= 80
  );
  const avgComparableHectareRate =
    relevantSales.reduce((sum, s) => sum + s.pricePerHectare, 0) / (relevantSales.length || 1);
  const estimatedComparableValue = Math.round(avgComparableHectareRate * parcel.area);

  // 2. Residual Land Valuation
  const financeCost = Math.round((constructionCost * financeCostRate) / 100);
  const professionalFees = Math.round((constructionCost * professionalFeesPct) / 100);
  const developerProfit = Math.round((gdv * developerProfitPct) / 100);
  
  const totalDevelopmentCost =
    constructionCost + financeCost + professionalFees + developerProfit + infraPlanningObligations;
  const residualLandValue = Math.max(0, gdv - totalDevelopmentCost);

  // 3. Income Capitalisation
  const capitalValue = Math.round((noi * 100) / capRate);

  // 4. Discounted Cash Flow (Multi-year projection)
  const dcfRows = [];
  let cumulativePV = 0;
  const initialOutflow = parcel.currentValue;

  for (let year = 1; year <= years; year++) {
    const escalatedNOI = noi * Math.pow(1 + rentalGrowth / 100, year - 1);
    const inflow = escalatedNOI;
    const terminalValue = year === years ? Math.round(( escalatedNOI * (1 + rentalGrowth / 100) * 100 ) / capRate) : 0;
    
    const cashInflow = inflow + terminalValue;
    const cashOutflow = Math.round(initialOutflow * 0.02); // minor maintenance outflow
    const netCashFlow = cashInflow - cashOutflow;
    
    const discountFactor = 1 / Math.pow(1 + discountRate / 100, year);
    const pv = Math.round(netCashFlow * discountFactor);
    cumulativePV += pv;

    dcfRows.push({
      year,
      cashInflow,
      cashOutflow,
      netCashFlow,
      discountFactor,
      pv
    });
  }

  const npv = Math.round(cumulativePV - initialOutflow);

  const estimateIrr = () => {
    let low = -10.0;
    let high = 50.0;
    let iterations = 20;
    
    while (iterations > 0) {
      const mid = (low + high) / 2;
      let tempNPV = -initialOutflow;
      for (let y = 1; y <= years; y++) {
        const escalated = noi * Math.pow(1 + rentalGrowth / 100, y - 1);
        const term = y === years ? Math.round(( escalated * (1 + rentalGrowth / 100) * 100 ) / capRate) : 0;
        const net = escalated + term - (initialOutflow * 0.02);
        tempNPV += net / Math.pow(1 + mid / 100, y);
      }
      if (tempNPV > 0) {
        low = mid;
      } else {
        high = mid;
      }
      iterations--;
    }
    return Math.max(0, low);
  };

  const calculatedIrr = estimateIrr();

  return (
    <div className="bg-[#0A0A0A] border border-white/5 p-5 text-neutral-400 font-sans rounded-sm">
      
      {/* Title Header */}
      <div className="flex justify-between items-center border-b border-white/10 pb-3 mb-4">
        <div className="flex items-center gap-2">
          <Calculator className="w-4 h-4 text-[#00FF41]" />
          <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">Geospatial Valuation Laboratory</span>
        </div>
        <div className="text-[10px] text-[#00FF41] bg-[#00FF41]/10 border border-[#00FF41]/25 px-2 py-0.5 font-bold font-mono rounded-xs">
          TARGET: {parcel.id} ({parcel.classification.toUpperCase()})
        </div>
      </div>

      {/* Methodology Navigation Tabs */}
      <div className="flex flex-wrap gap-1 mb-4 border-b border-white/5 pb-2">
        {[
          { id: "comparables", label: "Comparable Sales", icon: <Layers className="w-3.5 h-3.5" /> },
          { id: "residual", label: "Residual Viability", icon: <Percent className="w-3.5 h-3.5" /> },
          { id: "income", label: "Income Capitalisation", icon: <Activity className="w-3.5 h-3.5" /> },
          { id: "dcf", label: "Discounted Cash Flow", icon: <Calculator className="w-3.5 h-3.5" /> }
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveMethod(tab.id as any)}
            className={`px-3 py-1.5 text-[10px] font-bold font-mono uppercase transition-all flex items-center gap-1.5 border-b-2 rounded-t-sm ${
              activeMethod === tab.id
                ? "bg-white/5 text-white border-[#00FF41]"
                : "text-white/40 hover:text-white border-transparent"
            }`}
          >
            {tab.icon}
            {tab.label}
          </button>
        ))}
      </div>

      {/* Method 1: Comparable Sales */}
      {activeMethod === "comparables" && (
        <div className="space-y-4">
          <div className="p-4 bg-black/40 border border-white/5 rounded-sm">
            <h3 className="text-[11px] font-bold text-white uppercase tracking-wider font-mono mb-2">Comparable Transaction Adjustments</h3>
            <p className="text-[10px] text-white/40 mb-3 leading-relaxed">
              Analyzing historical, spatial land registries matching {parcel.county} with high land-use alignment.
            </p>
            <div className="space-y-1.5">
              {relevantSales.map(sale => (
                <div key={sale.id} className="bg-[#050505] border border-white/5 p-3 flex justify-between text-[10px] rounded-sm font-mono">
                  <div>
                    <span className="font-bold text-white">{sale.location}</span>
                    <span className="text-[8px] bg-white/5 text-white/50 border border-white/10 ml-2 px-1 py-0.5 rounded-sm font-bold">{sale.use}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-white font-bold">£{sale.price.toLocaleString()}</span>
                    <span className="text-[#00FF41] ml-2 text-[9px] font-bold">{sale.similarity}% SIMILARITY</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-white/5 border border-white/10 flex flex-col justify-between rounded-sm">
              <span className="text-[9px] font-bold font-mono text-[#00FF41] uppercase tracking-wider">COMPARABLE EXTRAPOLATION VALUE</span>
              <div className="my-3">
                <span className="text-xl font-bold font-mono text-white">£{estimatedComparableValue.toLocaleString()}</span>
                <span className="text-[9px] block text-white/40 mt-1">Based on £{Math.round(avgComparableHectareRate).toLocaleString()} / Ha across {parcel.area} Ha</span>
              </div>
            </div>
            <div className="p-4 bg-black/40 border border-white/5 flex flex-col justify-between rounded-sm">
              <span className="text-[9px] font-bold font-mono text-white/40 uppercase tracking-wider">BASE BOOK REGISTER VALUE</span>
              <div className="my-3">
                <span className="text-xl font-bold font-mono text-white">£{parcel.currentValue.toLocaleString()}</span>
                <span className="text-[9px] block text-white/40 mt-1">Sovereign Crown baseline book assessment.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Method 2: Residual Land Valuation */}
      {activeMethod === "residual" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Sliders */}
          <div className="space-y-3 p-4 bg-black/40 border border-white/5 rounded-sm">
            <h3 className="text-[11px] font-bold text-white uppercase tracking-wider font-mono border-b border-white/10 pb-2 mb-3">Viability Assumptions</h3>

            <div>
              <div className="flex justify-between text-[10px] mb-1 font-mono">
                <span>GROSS DEVELOPMENT VALUE (GDV)</span>
                <span className="text-white font-bold">£{gdv.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min={Math.round(parcel.currentValue * 1.5)}
                max={Math.round(parcel.futureValue * 1.8)}
                step="500000"
                value={gdv}
                onChange={(e) => setGdv(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] mb-1 font-mono">
                <span>CONSTRUCTION COST BASIS</span>
                <span className="text-white font-bold">£{constructionCost.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min={Math.round(gdv * 0.25)}
                max={Math.round(gdv * 0.70)}
                step="100000"
                value={constructionCost}
                onChange={(e) => setConstructionCost(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] mb-1 font-mono">
                <span>FINANCE CHARGE RATE</span>
                <span className="text-[#00FF41] font-bold">{financeCostRate}% p.a.</span>
              </div>
              <input
                type="range"
                min="3"
                max="14"
                step="0.5"
                value={financeCostRate}
                onChange={(e) => setFinanceCostRate(parseFloat(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] mb-1 font-mono">
                <span>DEVELOPER TARGET PROFIT</span>
                <span className="text-[#00FF41] font-bold">{developerProfitPct}% of GDV</span>
              </div>
              <input
                type="range"
                min="10"
                max="30"
                step="1"
                value={developerProfitPct}
                onChange={(e) => setDeveloperProfitPct(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] mb-1 font-mono">
                <span>S106 INFRA / TRANSIT OBLIGATIONS</span>
                <span className="text-yellow-400 font-bold">£{infraPlanningObligations.toLocaleString()}</span>
              </div>
              <input
                type="range"
                min="100000"
                max={Math.round(gdv * 0.15)}
                step="50000"
                value={infraPlanningObligations}
                onChange={(e) => setInfraPlanningObligations(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>
          </div>

          {/* Results Summary Stack */}
          <div className="flex flex-col justify-between bg-white/5 border border-white/10 p-5 rounded-sm">
            <div>
              <span className="text-[9px] font-bold font-mono text-[#00FF41] uppercase tracking-wider block mb-2">RESIDUAL LAND BID LIMIT</span>
              <div className="text-2xl font-bold font-mono text-white border-b border-white/10 pb-3 mb-4">
                £{residualLandValue.toLocaleString()}
                <span className="text-[9px] block text-white/40 font-sans font-normal mt-1">Maximum feasible land purchase bid recommendation</span>
              </div>

              <div className="space-y-2 text-[11px] font-mono">
                <div className="flex justify-between">
                  <span className="text-white/40">Gross Dev Value (GDV):</span>
                  <span className="font-bold text-white">£{gdv.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-red-400">
                  <span>[-] Construction Outlays:</span>
                  <span>-£{constructionCost.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-red-400">
                  <span>[-] Finance Charges:</span>
                  <span>-£{financeCost.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-red-400">
                  <span>[-] Design Fees ({professionalFeesPct}%):</span>
                  <span>-£{professionalFees.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-yellow-500">
                  <span>[-] Developer Profit ({developerProfitPct}%):</span>
                  <span>-£{developerProfit.toLocaleString()}</span>
                </div>
                <div className="flex justify-between text-red-400 border-t border-white/10 pt-2 mt-2 font-bold">
                  <span>[-] S106 Strategic Levies:</span>
                  <span>-£{infraPlanningObligations.toLocaleString()}</span>
                </div>
              </div>
            </div>

            <div className="text-[10px] bg-black/40 border border-white/5 p-2.5 mt-4 rounded-xs font-mono">
              {residualLandValue > parcel.currentValue ? (
                <span className="text-[#00FF41] font-bold">✓ VIABLE: Bid limit exceeds current base value by £{(residualLandValue - parcel.currentValue).toLocaleString()}</span>
              ) : (
                <span className="text-red-400 font-bold">✗ UNVIABLE: Acquisition cost exceeds residual threshold.</span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Method 3: Income Capitalisation */}
      {activeMethod === "income" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-4 bg-black/40 border border-white/5 rounded-sm space-y-4">
              <span className="text-[10px] font-bold text-white font-mono uppercase block">CAPITALIZATION ASSUMPTIONS</span>
              
              <div>
                <div className="flex justify-between text-[10px] mb-1 font-mono">
                  <span>NET OPERATING INCOME</span>
                  <span className="text-white font-bold">£{noi.toLocaleString()}/yr</span>
                </div>
                <input
                  type="range"
                  min={Math.round(parcel.currentValue * 0.02)}
                  max={Math.round(parcel.futureValue * 0.08)}
                  step="50000"
                  value={noi}
                  onChange={(e) => setNoi(parseInt(e.target.value))}
                  className="w-full h-1 bg-neutral-800 accent-[#00FF41]"
                />
              </div>

              <div>
                <div className="flex justify-between text-[10px] mb-1 font-mono">
                  <span>YIELD CAP RATE</span>
                  <span className="text-[#00FF41] font-bold">{capRate}%</span>
                </div>
                <input
                  type="range"
                  min="3.5"
                  max="12.0"
                  step="0.1"
                  value={capRate}
                  onChange={(e) => setCapRate(parseFloat(e.target.value))}
                  className="w-full h-1 bg-neutral-800 accent-[#00FF41]"
                />
              </div>
            </div>

            {/* Income capitalized value result */}
            <div className="md:col-span-2 p-5 bg-[#00FF41]/5 border border-[#00FF41]/20 rounded-sm flex flex-col justify-between">
              <div>
                <span className="text-[9px] font-bold text-[#00FF41] uppercase tracking-wider font-mono block mb-2">INCOME CAPITALIZED ASSET VALUE</span>
                <div className="text-3xl font-bold font-mono text-white border-b border-[#00FF41]/10 pb-3 mb-4">
                  £{capitalValue.toLocaleString()}
                  <span className="text-[10px] block text-white/40 font-sans font-normal mt-1">Appraised value based on direct capitalization covenants</span>
                </div>
              </div>

              <div className="text-[9px] font-mono text-white/30 flex justify-between">
                <span>ANNUAL ESCALATION RATE: {rentalGrowth}%</span>
                <span>YIELD GRADE: PRIME LOGISTICS MULTIPLIER</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Method 4: Discounted Cash Flow */}
      {activeMethod === "dcf" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 bg-black/40 border border-white/5 p-4 rounded-sm text-[10px] font-mono">
            <div>
              <span className="text-white/30 block mb-1">SOVEREIGN HURDLE RATE</span>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="5.0"
                  max="15.0"
                  step="0.5"
                  value={discountRate}
                  onChange={(e) => setDiscountRate(parseFloat(e.target.value))}
                  className="w-full h-1"
                />
                <span className="font-bold text-[#00FF41]">{discountRate}%</span>
              </div>
            </div>
            <div>
              <span className="text-white/30 block mb-1">RENTAL ESCALATION P.A.</span>
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="1.0"
                  max="8.0"
                  step="0.5"
                  value={rentalGrowth}
                  onChange={(e) => setRentalGrowth(parseFloat(e.target.value))}
                  className="w-full h-1"
                />
                <span className="font-bold text-[#00FF41]">{rentalGrowth}%</span>
              </div>
            </div>
            <div className="bg-white/5 border border-white/10 p-3 flex flex-col justify-center text-center rounded-sm">
              <span className="text-white/30 text-[8px] uppercase font-bold">PROJECTED NPV</span>
              <span className={`text-sm font-bold ${npv >= 0 ? "text-[#00FF41]" : "text-red-400"}`}>
                £{(npv / 1000000).toFixed(2)}M
              </span>
            </div>
            <div className="bg-white/5 border border-white/10 p-3 flex flex-col justify-center text-center rounded-sm">
              <span className="text-white/30 text-[8px] uppercase font-bold">INTERNAL RETURN (IRR)</span>
              <span className="text-sm font-bold text-[#00FF41]">
                {calculatedIrr.toFixed(1)}%
              </span>
            </div>
          </div>

          <div className="overflow-x-auto max-h-[190px] border border-white/5 bg-black rounded-sm">
            <table className="w-full text-left text-[10px] font-mono">
              <thead className="bg-white/5 text-white/40 uppercase sticky top-0 border-b border-white/10">
                <tr>
                  <th className="p-3">Year</th>
                  <th className="p-3 text-right">Inflow</th>
                  <th className="p-3 text-right">Outflow</th>
                  <th className="p-3 text-right">Net Flow</th>
                  <th className="p-3 text-right">Discount Factor</th>
                  <th className="p-3 text-right">Present Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                <tr className="bg-white/5 font-bold">
                  <td className="p-3 text-red-400">0</td>
                  <td className="p-3 text-right">£0</td>
                  <td className="p-3 text-right text-red-400">-£{initialOutflow.toLocaleString()}</td>
                  <td className="p-3 text-right text-red-400">-£{initialOutflow.toLocaleString()}</td>
                  <td className="p-3 text-right">1.000</td>
                  <td className="p-3 text-right text-red-400">-£{initialOutflow.toLocaleString()}</td>
                </tr>
                {dcfRows.map((row) => (
                  <tr key={row.year} className="hover:bg-white/5">
                    <td className="p-3 font-bold text-white">{row.year}</td>
                    <td className="p-3 text-right text-[#00FF41]">£{row.cashInflow.toLocaleString()}</td>
                    <td className="p-3 text-right text-red-400">-£{row.cashOutflow.toLocaleString()}</td>
                    <td className="p-3 text-right font-semibold text-white">£{row.netCashFlow.toLocaleString()}</td>
                    <td className="p-3 text-right text-[#00FF41]/60">{row.discountFactor.toFixed(4)}</td>
                    <td className="p-3 text-right text-[#00FF41] font-semibold">£{row.pv.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
