import React, { useState, useEffect } from "react";
import { Parcel } from "../types";
import { ShieldCheck, ShieldAlert, Landmark, Compass } from "lucide-react";

interface PlanningIntelligenceProps {
  parcel: Parcel;
}

export default function PlanningIntelligence({ parcel }: PlanningIntelligenceProps) {
  // S106 Overrides and Configurable Parameter States
  const [housingDeficit, setHousingDeficit] = useState<number>(68); // 0 - 100 (high deficit increases planning odds)
  const [communityOpposition, setCommunityOpposition] = useState<boolean>(false);
  const [strategicProjectStatus, setStrategicProjectStatus] = useState<boolean>(false); // NSIP exemption
  const [floodMitigationMet, setFloodMitigationMet] = useState<boolean>(true);
  const [esgSustainabilityPledges, setEsgSustainabilityPledges] = useState<number>(85); // %

  const [probability, setProbability] = useState<number>(50);

  // Score algorithm simulating actual UK local plan weighting criteria
  useEffect(() => {
    let baseScore = 40;

    // Base parcel alignment
    if (parcel.planningStatus === "Planning Approved") baseScore += 45;
    else if (parcel.planningStatus === "Allocated") baseScore += 25;
    else if (parcel.planningStatus === "Draft Allocation") baseScore += 15;
    else if (parcel.planningStatus === "Under Review") baseScore += 5;
    else if (parcel.planningStatus === "Planning Refused") baseScore -= 20;

    // Environmental / Green Belt Constraints
    const isGreenBelt = parcel.envConstraints.some(c => c.includes("Green Belt") || c.includes("Protected"));
    if (isGreenBelt) {
      if (strategicProjectStatus) {
        baseScore += 10; // Strategic overrides
      } else {
        baseScore -= 35; // Severe Green Belt penalty
      }
    }

    // Flood Risk Penalities vs Mitigations
    if (parcel.floodZone === "Zone 3 (High)") {
      if (floodMitigationMet) {
        baseScore -= 10; // Mitigated high risk
      } else {
        baseScore -= 30; // Severe unmitigated flood penalty
      }
    } else if (parcel.floodZone === "Zone 2 (Medium)") {
      if (!floodMitigationMet) baseScore -= 10;
    }

    // Sliders & Toggles
    baseScore += (housingDeficit / 10) * 2; // up to +20% for extreme housing shortfalls
    if (communityOpposition) baseScore -= 15; // parish pushbacks
    if (esgSustainabilityPledges > 80) baseScore += 10; // BREEAM Outstanding credits

    // Absolute boundaries
    const finalScore = Math.max(5, Math.min(98, baseScore));
    setProbability(finalScore);
  }, [parcel, housingDeficit, communityOpposition, strategicProjectStatus, floodMitigationMet, esgSustainabilityPledges]);

  const getVerdictLabel = () => {
    if (probability >= 80) return { text: "HIGH PROBABILITY (CORE ALIGNMENT)", color: "text-[#00FF41]", bg: "bg-[#00FF41]/5 border-[#00FF41]/20" };
    if (probability >= 50) return { text: "CONDITIONAL REVIEW REQUIRED", color: "text-yellow-400", bg: "bg-yellow-400/5 border-yellow-400/20" };
    return { text: "CRITICAL REGULATORY RISK OVERLAY", color: "text-red-400", bg: "bg-red-400/5 border-red-400/20" };
  };

  const verdict = getVerdictLabel();

  return (
    <div className="bg-[#0A0A0A] border border-white/5 p-5 text-neutral-400 font-sans grid grid-cols-1 md:grid-cols-2 gap-6 rounded-sm">
      
      {/* Constraints Inspector */}
      <div className="space-y-4">
        <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-2">
          <Landmark className="w-4 h-4 text-yellow-400" />
          <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">Spatial Constraint Registry</span>
        </div>

        <div className="space-y-3">
          <div className="bg-black/40 border border-white/5 p-4 text-[11px] space-y-3 font-mono rounded-sm">
            <div className="flex justify-between items-center border-b border-white/5 pb-2">
              <span>METROPOLITAN GREEN BELT:</span>
              {parcel.envConstraints.some(c => c.includes("Green Belt")) ? (
                <span className="text-red-400 font-bold flex items-center gap-1"><ShieldAlert className="w-3.5 h-3.5" /> GREEN BELT OVERLAY</span>
              ) : (
                <span className="text-[#00FF41] font-bold flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5" /> CLEAR</span>
              )}
            </div>

            <div className="flex justify-between items-center border-b border-white/5 pb-2">
              <span>FLOOD ZONE CLASSIFICATION:</span>
              <span className={`font-bold ${parcel.floodZone.includes("High") ? "text-red-400" : parcel.floodZone.includes("Medium") ? "text-yellow-400" : "text-[#00FF41]"}`}>
                {parcel.floodZone.toUpperCase()}
              </span>
            </div>

            <div className="flex justify-between items-center border-b border-white/5 pb-2">
              <span>DEVELOPMENT SLOPE / TOPOGRAPHY:</span>
              <span className="text-white font-bold">
                {parcel.elevation}m ({parcel.slope}° Slope)
              </span>
            </div>

            <div className="flex justify-between items-center pb-1">
              <span>SENSITIVE SITE OVERLAYS:</span>
              <span className="text-yellow-400 font-bold text-right truncate max-w-[150px]" title={parcel.envConstraints.filter(c => !c.includes("Green Belt")).join(", ")}>
                {parcel.envConstraints.filter(c => !c.includes("Green Belt")).join(", ") || "NONE DETECTED"}
              </span>
            </div>
          </div>

          <div className="bg-[#00FF41]/5 border border-[#00FF41]/20 p-4 text-[10px] space-y-1 rounded-sm">
            <span className="font-bold text-[#00FF41] block uppercase tracking-wider font-mono">✓ SOVEREIGN REGULATORY OVERRIDES</span>
            <p className="text-white/50 leading-relaxed">
              Ellan Vannin maintains priority statutory options under transit/housing covenants for offshore Crown development reserves.
            </p>
          </div>
        </div>
      </div>

      {/* Probability Configurator Panel */}
      <div className="space-y-4 flex flex-col justify-between">
        <div>
          <div className="flex items-center gap-2 border-b border-white/10 pb-3 mb-2">
            <Compass className="w-4 h-4 text-[#00FF41]" />
            <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">Approval Scoring Matrix</span>
          </div>

          <div className="space-y-4 text-[11px] font-mono">
            <div>
              <div className="flex justify-between text-[10px] mb-1.5">
                <span>LOCAL AREA HOUSING DEFICIT INDEX</span>
                <span className="text-white font-bold">{housingDeficit} / 100</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                step="5"
                value={housingDeficit}
                onChange={(e) => setHousingDeficit(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            <div>
              <div className="flex justify-between text-[10px] mb-1.5">
                <span>ESG BIODIVERSITY NET-GAIN TARGETS</span>
                <span className="text-[#00FF41] font-bold">{esgSustainabilityPledges}% Gain</span>
              </div>
              <input
                type="range"
                min="10"
                max="100"
                step="5"
                value={esgSustainabilityPledges}
                onChange={(e) => setEsgSustainabilityPledges(parseInt(e.target.value))}
                className="w-full h-1 bg-neutral-800 rounded appearance-none cursor-pointer accent-[#00FF41]"
              />
            </div>

            {/* Strategic Toggles */}
            <div className="grid grid-cols-2 gap-3 mt-3">
              <label className="flex items-center gap-2.5 cursor-pointer bg-black/40 border border-white/5 p-3 hover:bg-white/5 rounded-sm">
                <input
                  type="checkbox"
                  checked={strategicProjectStatus}
                  onChange={(e) => setStrategicProjectStatus(e.target.checked)}
                  className="rounded border-white/10 text-[#00FF41] focus:ring-0 cursor-pointer accent-[#00FF41]"
                />
                <div>
                  <div className="text-[9px] font-bold text-[#00FF41]">NSIP CLASSIFICATION</div>
                  <div className="text-[8px] text-white/30 mt-0.5">Strategic Exemption</div>
                </div>
              </label>

              <label className="flex items-center gap-2.5 cursor-pointer bg-black/40 border border-white/5 p-3 hover:bg-white/5 rounded-sm">
                <input
                  type="checkbox"
                  checked={floodMitigationMet}
                  onChange={(e) => setFloodMitigationMet(e.target.checked)}
                  className="rounded border-white/10 text-[#00FF41] focus:ring-0 cursor-pointer accent-[#00FF41]"
                />
                <div>
                  <div className="text-[9px] font-bold text-yellow-400">SUDS SCHEME</div>
                  <div className="text-[8px] text-white/30 mt-0.5">Mitigated Drainage</div>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Live Probability Result HUD */}
        <div className={`p-4 border ${verdict.bg} flex justify-between items-center rounded-sm`}>
          <div>
            <span className="text-[9px] text-white/40 font-bold uppercase tracking-wider block font-mono">STATUTORY APPROVAL PROBABILITY</span>
            <span className={`text-[11px] font-black font-mono ${verdict.color}`}>{verdict.text}</span>
          </div>
          <div className="text-right font-mono">
            <span className={`text-2xl font-black ${verdict.color}`}>{probability}%</span>
          </div>
        </div>
      </div>
    </div>
  );
}
