import React, { useState, useRef } from "react";
import { Parcel, InfrastructureProject } from "../types";
import { Compass, Eye, Map as MapIcon, ShieldAlert, Layers, ZoomIn, ZoomOut, RotateCcw } from "lucide-react";

interface GisEngineProps {
  parcels: Parcel[];
  selectedParcel: Parcel | null;
  onSelectParcel: (parcel: Parcel) => void;
  infrastructureProjects: InfrastructureProject[];
  activeOverlay: "standard" | "classification" | "planning" | "flood" | "heatmap" | "infrastructure";
  setActiveOverlay: (overlay: "standard" | "classification" | "planning" | "flood" | "heatmap" | "infrastructure") => void;
  addedProjects: Array<{ name: string; type: string; lat: number; lng: number; buffer: number; uplift: number }>;
}

export default function GisEngine({
  parcels,
  selectedParcel,
  onSelectParcel,
  infrastructureProjects,
  activeOverlay,
  setActiveOverlay,
  addedProjects
}: GisEngineProps) {
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPanning, setIsPanning] = useState<boolean>(false);
  const [panStart, setPanStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [mouseCoord, setMouseCoord] = useState<{ lat: number; lng: number; x: number; y: number }>({ lat: 52.5, lng: -1.5, x: 0, y: 0 });
  const svgRef = useRef<SVGSVGElement>(null);

  // Geographic boundary bounds to map lat/lng to a standard 600x400 canvas space
  const mapBounds = {
    minLat: 51.0,
    maxLat: 56.2,
    minLng: -5.0,
    maxLng: -0.1
  };

  const mapLatToY = (lat: number) => {
    const pct = (lat - mapBounds.minLat) / (mapBounds.maxLat - mapBounds.minLat);
    return 400 - (pct * 360 + 20); // invert Y
  };

  const mapLngToX = (lng: number) => {
    const pct = (lng - mapBounds.minLng) / (mapBounds.maxLng - mapBounds.minLng);
    return pct * 560 + 20;
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button === 0) { // left click for pan
      setIsPanning(true);
      setPanStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    // Convert canvas (x, y) back to approximate WGS84 coordinates
    const mapX = (x - pan.x - 20) / zoom;
    const mapY = (400 - (y - pan.y) - 20) / zoom;

    const pctX = mapX / 560;
    const pctY = mapY / 360;

    const approxLng = mapBounds.minLng + pctX * (mapBounds.maxLng - mapBounds.minLng);
    const approxLat = mapBounds.minLat + pctY * (mapBounds.maxLat - mapBounds.minLat);

    setMouseCoord({
      lat: Math.max(mapBounds.minLat, Math.min(mapBounds.maxLat, approxLat)),
      lng: Math.max(mapBounds.minLng, Math.min(mapBounds.maxLng, approxLng)),
      x: Math.round(x),
      y: Math.round(y)
    });

    if (isPanning) {
      setPan({
        x: e.clientX - panStart.x,
        y: e.clientY - panStart.y
      });
    }
  };

  const handleMouseUp = () => {
    setIsPanning(false);
  };

  const handleZoom = (factor: number) => {
    setZoom(prev => Math.max(0.6, Math.min(6, prev * factor)));
  };

  const resetMap = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  // Helper to color-code parcel classes using high fidelity minimalist scheme
  const getClassificationColor = (classification: string, outline = false) => {
    switch (classification) {
      case "Agricultural": return outline ? "border-[#A3E635]" : "rgba(163, 230, 53, 0.15)";
      case "Brownfield": return outline ? "border-[#F97316]" : "rgba(249, 115, 22, 0.15)";
      case "Greenfield": return outline ? "border-[#00FF41]" : "rgba(0, 255, 65, 0.1)";
      case "Residential": return outline ? "border-[#06B6D4]" : "rgba(6, 182, 212, 0.15)";
      case "Commercial": return outline ? "border-[#3B82F6]" : "rgba(59, 130, 246, 0.15)";
      case "Industrial": return outline ? "border-[#8B5CF6]" : "rgba(139, 92, 246, 0.15)";
      case "Logistics": return outline ? "border-[#EC4899]" : "rgba(236, 72, 153, 0.15)";
      case "Mixed Use": return outline ? "border-[#EAB308]" : "rgba(234, 179, 8, 0.15)";
      default: return outline ? "border-[#6B7280]" : "rgba(107, 114, 128, 0.15)";
    }
  };

  // Calculate Opportunity Score (0-100) for Heatmap visualization
  const getOpportunityScore = (p: Parcel) => {
    let score = 50;
    if (p.planningStatus === "Planning Approved") score += 15;
    if (p.planningStatus === "Allocated") score += 10;
    if (p.floodZone === "Zone 1 (Low)") score += 10;
    if (p.floodZone === "Zone 3 (High)") score -= 20;
    if (p.utilities === "Full Connection") score += 10;
    if (p.transportAccess === "Direct Motorway" || p.transportAccess === "Rail Connection") score += 15;
    if (p.remediationCost && p.remediationCost > 1500000) score -= 10;
    if (p.futureValue / p.currentValue > 5) score += 15;
    return Math.max(10, Math.min(100, score));
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 bg-[#050505] text-neutral-400 font-sans border border-white/5 p-4 rounded-sm shadow-2xl relative">
      
      {/* Sidebar Controls */}
      <div className="lg:col-span-1 bg-[#0A0A0A] border border-white/5 p-4 flex flex-col justify-between rounded-sm">
        <div>
          <div className="flex items-center gap-2 mb-4 border-b border-white/10 pb-3">
            <Layers className="w-4 h-4 text-[#00FF41]" />
            <span className="font-bold text-white text-[11px] uppercase tracking-wider font-mono">GIS Overlays</span>
          </div>

          <div className="space-y-1">
            {[
              { id: "standard", label: "STANDARD BASEMAP", color: "text-white/40", icon: <MapIcon className="w-3.5 h-3.5" /> },
              { id: "classification", label: "LAND USE CATEGORY", color: "text-[#A3E635]", icon: <Layers className="w-3.5 h-3.5" /> },
              { id: "planning", label: "PLANNING RESTRICTIONS", color: "text-yellow-500", icon: <Compass className="w-3.5 h-3.5" /> },
              { id: "flood", label: "FLOOD RISK (EA ZONES)", color: "text-cyan-500", icon: <ShieldAlert className="w-3.5 h-3.5" /> },
              { id: "heatmap", label: "INVESTMENT OPPORTUNITY", color: "text-[#00FF41]", icon: <Eye className="w-3.5 h-3.5" /> },
              { id: "infrastructure", label: "INFRASTRUCTURE BUFFERS", color: "text-[#06B6D4]", icon: <ZoomIn className="w-3.5 h-3.5" /> }
            ].map(layer => (
              <button
                key={layer.id}
                onClick={() => setActiveOverlay(layer.id as any)}
                className={`w-full text-left px-3 py-2 text-[11px] transition-all flex items-center gap-2 font-mono font-bold rounded-sm ${
                  activeOverlay === layer.id
                    ? "bg-white/5 text-white border-l-2 border-[#00FF41]"
                    : "hover:bg-white/5 text-white/50"
                }`}
              >
                <span className={layer.color}>{layer.icon}</span>
                {layer.label}
              </button>
            ))}
          </div>

          {/* Contextual Legend */}
          <div className="mt-6 border-t border-white/10 pt-4">
            <span className="text-[9px] text-white/30 font-bold uppercase tracking-wider font-mono block mb-2">GIS Map Legend</span>
            <div className="space-y-2 text-[10px]">
              {activeOverlay === "classification" && (
                <>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-lime-500/10 border border-lime-400 rounded-xs"></div> Agricultural</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-orange-500/15 border border-orange-400 rounded-xs"></div> Brownfield</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-[#00FF41]/10 border border-[#00FF41] rounded-xs"></div> Greenfield</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-cyan-500/15 border border-cyan-400 rounded-xs"></div> Residential</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-indigo-500/15 border border-indigo-400 rounded-xs"></div> Industrial / Logistics</div>
                </>
              )}
              {activeOverlay === "planning" && (
                <>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-[#00FF41]/10 border border-[#00FF41] border-dashed rounded-xs"></div> Local Housing Allocation</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-red-500/15 border border-red-500 rounded-xs"></div> Protected Metropolitan Green Belt</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-yellow-500/15 border border-yellow-500 rounded-xs"></div> Conservation / Listed Reserve</div>
                </>
              )}
              {activeOverlay === "flood" && (
                <>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-cyan-950/45 border border-cyan-500 rounded-xs"></div> Flood Zone 3 (High Risk)</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-blue-950/20 border border-blue-500 rounded-xs"></div> Flood Zone 2 (Medium Risk)</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-neutral-900 border border-neutral-700 rounded-xs"></div> Zone 1 (Negligible Risk)</div>
                </>
              )}
              {activeOverlay === "heatmap" && (
                <>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-emerald-500/20 border border-emerald-500 rounded-xs"></div> High Yield (Score 75-100)</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-yellow-500/15 border border-yellow-500 rounded-xs"></div> Moderate Viability (Score 45-74)</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-red-500/10 border border-red-500 rounded-xs"></div> Capital Constrained Zone</div>
                </>
              )}
              {activeOverlay === "standard" && (
                <>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 bg-neutral-900 border border-neutral-700 rounded-xs"></div> Land Core Boundary</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3.5 h-0.5 bg-[#00FF41]"></div> Trans-UK Rail Trunk Links</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3.5 h-0.5 bg-neutral-700"></div> National Strategic Motorways</div>
                </>
              )}
              {activeOverlay === "infrastructure" && (
                <>
                  <div className="flex items-center gap-2 text-white/70"><div className="w-3 h-3 rounded-full border border-dashed border-[#06B6D4]"></div> Value Uplift Buffer Ring</div>
                  <div className="flex items-center gap-2 text-white/70"><div className="text-[#06B6D4] font-bold">▲</div> Transit Hub Capital Node</div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Technical Coordinate Indicators */}
        <div className="mt-4 pt-3 border-t border-white/10 text-[9px] text-white/30 space-y-1 font-mono">
          <div className="flex justify-between">
            <span>COORDINATE LAT:</span>
            <span className="text-[#00FF41] font-bold">{mouseCoord.lat.toFixed(5)}°N</span>
          </div>
          <div className="flex justify-between">
            <span>COORDINATE LNG:</span>
            <span className="text-[#00FF41] font-bold">{mouseCoord.lng.toFixed(5)}°W</span>
          </div>
          <div className="flex justify-between">
            <span>RESOLVED DATUM:</span>
            <span>OSGB36 // ED50</span>
          </div>
          <div className="flex justify-between">
            <span>RENDER SCALE:</span>
            <span>1 : 250,000 VECTOR</span>
          </div>
        </div>
      </div>

      {/* Main Interactive Map Stage */}
      <div className="lg:col-span-3 border border-white/5 bg-black relative overflow-hidden flex flex-col justify-between h-[440px] rounded-sm">
        
        {/* Map Header HUD */}
        <div className="absolute top-3 left-3 z-10 flex items-center gap-2 bg-black/80 border border-white/10 px-3 py-1.5 pointer-events-none rounded-sm">
          <span className="animate-pulse w-1.5 h-1.5 rounded-full bg-[#00FF41]" />
          <span className="text-[9px] text-[#00FF41] font-bold tracking-widest font-mono">GEOSPATIAL COGNITION RENDER // ACTIVE</span>
        </div>

        {/* GIS Interactive Control HUD */}
        <div className="absolute top-3 right-3 z-10 flex gap-1 bg-black/80 border border-white/10 p-1 rounded-sm">
          <button onClick={() => handleZoom(1.2)} className="p-1 hover:bg-white/5 text-[#00FF41] rounded transition-colors" title="Zoom In"><ZoomIn className="w-3.5 h-3.5" /></button>
          <button onClick={() => handleZoom(0.8)} className="p-1 hover:bg-white/5 text-[#00FF41] rounded transition-colors" title="Zoom Out"><ZoomOut className="w-3.5 h-3.5" /></button>
          <button onClick={resetMap} className="p-1 hover:bg-white/5 text-[#00FF41] rounded transition-colors" title="Reset View"><RotateCcw className="w-3.5 h-3.5" /></button>
        </div>

        {/* Compass Overlay */}
        <div className="absolute bottom-4 right-4 z-10 pointer-events-none flex flex-col items-center opacity-40 bg-black/80 p-2.5 border border-white/10 rounded-sm">
          <Compass className="w-7 h-7 text-[#00FF41]" />
          <span className="text-[8px] font-mono font-bold text-white/40 mt-1 uppercase">TRUE NORTH</span>
        </div>

        {/* Main Vector SVG Stage */}
        <svg
          ref={svgRef}
          className={`w-full h-full cursor-crosshair select-none ${isPanning ? "cursor-grabbing" : "cursor-grab"}`}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          {/* Static Map Coordinates Grid Lines */}
          <g opacity="0.04">
            {[50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550].map(cx => (
              <line key={`v-${cx}`} x1={cx} y1="0" x2={cx} y2="440" stroke="#FFFFFF" strokeWidth="1" />
            ))}
            {[50, 100, 150, 200, 250, 300, 350, 400].map(cy => (
              <line key={`h-${cy}`} x1="0" y1={cy} x2="600" y2={cy} stroke="#FFFFFF" strokeWidth="1" />
            ))}
          </g>

          <g transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}>
            {/* Base Shoreline Outline representing Great Britain coastline layout */}
            <path
              d="M 50,380 C 120,390 180,340 180,320 C 180,300 240,280 260,250 C 280,220 340,180 340,140 C 340,100 420,80 440,50 C 420,20 300,10 240,40 C 180,70 120,110 90,160 C 60,210 20,280 50,380 Z"
              fill="#0F0F0F"
              stroke="rgba(255,255,255,0.08)"
              strokeWidth="1.5"
            />

            {/* Transport Network Lines */}
            <path
              d="M 80,380 L 150,300 L 250,220 L 320,120 L 410,35"
              fill="none"
              stroke="#00FF41"
              strokeWidth="1"
              strokeOpacity="0.4"
              strokeDasharray="3,3"
            />
            <path
              d="M 40,350 L 120,290 L 220,240 L 310,180 L 390,90"
              fill="none"
              stroke="rgba(255,255,255,0.15)"
              strokeWidth="0.75"
            />

            {/* Environmental Zoning Overlays */}
            {activeOverlay === "planning" && (
              <g opacity="0.2">
                {/* Solihull and Warwickshire Green Belt zone */}
                <circle cx={mapLngToX(-1.7)} cy={mapLatToY(52.4)} r="45" fill="url(#diagonalHatchRed)" stroke="#EF4444" strokeWidth="1" />
                {/* Edinburgh Conservation Arc area */}
                <circle cx={mapLngToX(-3.2)} cy={mapLatToY(55.9)} r="28" fill="url(#diagonalHatchYellow)" stroke="#EAB308" strokeWidth="1" />
              </g>
            )}

            {/* Flood Hazard zoning */}
            {activeOverlay === "flood" && (
              <g opacity="0.3">
                <path d="M 80,300 Q 150,290 220,240 L 240,260 Q 140,320 80,350 Z" fill="#06B6D4" stroke="#06B6D4" strokeWidth="0.5" />
                <circle cx={mapLngToX(-2.296)} cy={mapLatToY(53.478)} r="35" fill="#1D4ED8" />
              </g>
            )}

            {/* Strategic Infrastructure Spillovers */}
            {activeOverlay === "infrastructure" && (
              <g opacity="0.45">
                {infrastructureProjects.map(proj => {
                  const cx = mapLngToX(proj.lng);
                  const cy = mapLatToY(proj.lat);
                  const r = proj.valueUpliftRadiusKm * 12;
                  return (
                    <g key={`buffer-${proj.id}`}>
                      <circle cx={cx} cy={cy} r={r} fill="none" stroke="#06B6D4" strokeWidth="1" strokeDasharray="3,3" />
                      <circle cx={cx} cy={cy} r={r * 0.5} fill="rgba(6, 182, 212, 0.03)" stroke="#06B6D4" strokeWidth="0.5" />
                    </g>
                  );
                })}
                {addedProjects.map((proj, idx) => {
                  const cx = mapLngToX(proj.lng);
                  const cy = mapLatToY(proj.lat);
                  const r = proj.buffer * 12;
                  return (
                    <g key={`custom-buf-${idx}`}>
                      <circle cx={cx} cy={cy} r={r} fill="none" stroke="#EAB308" strokeWidth="1" strokeDasharray="2,2" />
                    </g>
                  );
                })}
              </g>
            )}

            {/* Dynamic Parcel Vector Polygons */}
            <g>
              {parcels.map(parcel => {
                const cx = mapLngToX(parcel.lng);
                const cy = mapLatToY(parcel.lat);
                
                // Project boundary points string onto global lat/long scale
                const pointsString = parcel.boundary
                  .map(pt => `${cx + (pt.x - 30) * 0.75},${cy + (pt.y - 30) * 0.75}`)
                  .join(" ");

                const isSelected = selectedParcel?.id === parcel.id;
                
                // Calculate fill/stroke based on overlay
                let polygonFill = "rgba(255, 255, 255, 0.02)";
                let strokeColor = "rgba(255, 255, 255, 0.15)";
                let strokeWidth = isSelected ? "2" : "1";

                if (activeOverlay === "classification") {
                  polygonFill = getClassificationColor(parcel.classification);
                  strokeColor = getClassificationColor(parcel.classification, true).replace("border-[", "").replace("]", "");
                } else if (activeOverlay === "flood") {
                  polygonFill = parcel.floodZone === "Zone 3 (High)" 
                    ? "rgba(6, 182, 212, 0.3)" 
                    : parcel.floodZone === "Zone 2 (Medium)" 
                      ? "rgba(29, 78, 216, 0.2)" 
                      : "rgba(255, 255, 255, 0.01)";
                  strokeColor = parcel.floodZone === "Zone 3 (High)" ? "#06B6D4" : "#1D4ED8";
                } else if (activeOverlay === "planning") {
                  polygonFill = parcel.planningStatus === "Planning Approved"
                    ? "rgba(0, 255, 65, 0.08)"
                    : parcel.envConstraints.some(c => c.includes("Green Belt"))
                      ? "rgba(239, 68, 68, 0.15)"
                      : "rgba(234, 179, 8, 0.1)";
                  strokeColor = parcel.planningStatus === "Planning Approved"
                    ? "#00FF41"
                    : parcel.envConstraints.some(c => c.includes("Green Belt"))
                      ? "#EF4444"
                      : "#EAB308";
                } else if (activeOverlay === "heatmap") {
                  const score = getOpportunityScore(parcel);
                  if (score >= 75) {
                    polygonFill = "rgba(0, 255, 65, 0.15)";
                    strokeColor = "#00FF41";
                  } else if (score >= 45) {
                    polygonFill = "rgba(234, 179, 8, 0.15)";
                    strokeColor = "#EAB308";
                  } else {
                    polygonFill = "rgba(239, 68, 68, 0.08)";
                    strokeColor = "#EF4444";
                  }
                }

                if (isSelected) {
                  strokeColor = "#00FF41";
                }

                return (
                  <g key={`parcel-poly-${parcel.id}`}>
                    <polygon
                      points={pointsString}
                      fill={polygonFill}
                      stroke={strokeColor}
                      strokeWidth={strokeWidth}
                      onClick={() => onSelectParcel(parcel)}
                      className="transition-all duration-150 cursor-pointer hover:fill-opacity-80"
                      referrerPolicy="no-referrer"
                    />
                    
                    {/* ID HUD label */}
                    <text
                      x={cx}
                      y={cy - 12}
                      fill={isSelected ? "#00FF41" : "rgba(255, 255, 255, 0.4)"}
                      fontSize="7"
                      fontWeight="bold"
                      textAnchor="middle"
                      className="pointer-events-none font-mono"
                    >
                      {parcel.id}
                    </text>
                  </g>
                );
              })}
            </g>

            {/* Strategic Infrastructure Nodes */}
            <g>
              {infrastructureProjects.map(proj => {
                const cx = mapLngToX(proj.lng);
                const cy = mapLatToY(proj.lat);
                return (
                  <g key={`marker-${proj.id}`}>
                    <circle cx={cx} cy={cy} r="3" fill="#06B6D4" />
                    <polygon
                      points={`${cx},${cy - 5} ${cx - 4},${cy + 3} ${cx + 4},${cy + 3}`}
                      fill="#06B6D4"
                      stroke="#FFFFFF"
                      strokeWidth="0.5"
                    />
                    <text
                      x={cx}
                      y={cy + 10}
                      fill="rgba(255, 255, 255, 0.7)"
                      fontSize="6.5"
                      fontWeight="bold"
                      textAnchor="middle"
                      className="pointer-events-none font-mono"
                    >
                      {proj.name.split(" ")[0]}
                    </text>
                  </g>
                );
              })}

              {/* Added simulation nodes */}
              {addedProjects.map((proj, idx) => {
                const cx = mapLngToX(proj.lng);
                const cy = mapLatToY(proj.lat);
                return (
                  <g key={`custom-proj-${idx}`}>
                    <circle cx={cx} cy={cy} r="4" fill="#EAB308" className="animate-pulse" />
                    <text x={cx} y={cy - 6} fill="#EAB308" fontSize="6" fontWeight="bold" textAnchor="middle" className="font-mono">
                      {proj.name.toUpperCase()}
                    </text>
                  </g>
                );
              })}
            </g>
          </g>

          {/* Patterns for hatched zoning grids */}
          <defs>
            <pattern id="diagonalHatchRed" width="10" height="10" patternTransform="rotate(45 0 0)" patternUnits="userSpaceOnUse">
              <line x1="0" y1="0" x2="0" y2="10" stroke="#EF4444" strokeWidth="0.75" />
            </pattern>
            <pattern id="diagonalHatchYellow" width="10" height="10" patternTransform="rotate(135 0 0)" patternUnits="userSpaceOnUse">
              <line x1="0" y1="0" x2="0" y2="10" stroke="#EAB308" strokeWidth="0.75" />
            </pattern>
          </defs>
        </svg>

        {/* GIS Footer HUD Bar */}
        <div className="bg-[#0A0A0A] border-t border-white/5 p-3 flex justify-between items-center text-[9px] font-mono text-white/30 rounded-b-sm">
          <div className="flex gap-4">
            <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 bg-[#00FF41] rounded-full"/> REGISTRY TARGETS: {parcels.length}</span>
            <span className="flex items-center gap-1.5"><span className="w-1.5 h-1.5 bg-[#06B6D4] rounded-full"/> COV-NODES: {infrastructureProjects.length}</span>
            {selectedParcel && (
              <span className="text-[#00FF41] font-bold">▶ ACTIVE SELECTION: {selectedParcel.id} ({selectedParcel.county.toUpperCase()})</span>
            )}
          </div>
          <div>
            <span>SYSTEM GRAPHICS: VECTOR LAYERED</span>
          </div>
        </div>
      </div>

    </div>
  );
}
