import React from "react";
import { Parcel, PortfolioAsset } from "../types";
import { TrendingUp, Award, DollarSign, Activity, Search, Bell } from "lucide-react";

interface DashboardProps {
  parcels: Parcel[];
  portfolio: PortfolioAsset[];
  onSelectParcel: (parcel: Parcel) => void;
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  selectedCounty: string;
  setSelectedCounty: (county: string) => void;
  selectedStatus: string;
  setSelectedStatus: (status: string) => void;
}

export default function Dashboard({
  parcels,
  portfolio,
  onSelectParcel,
  searchTerm,
  setSearchTerm,
  selectedCounty,
  setSelectedCounty,
  selectedStatus,
  setSelectedStatus
}: DashboardProps) {
  // Compute key executive metrics
  const totalHoldingsValue = portfolio.reduce((sum, asset) => sum + asset.currentValue, 0);
  const totalAcquisitionCost = portfolio.reduce((sum, asset) => sum + asset.acquisitionCost, 0);
  const aggregateIrr = (portfolio.reduce((sum, asset) => sum + asset.irr, 0) / portfolio.length) || 0;
  const aggregateYield = (portfolio.reduce((sum, asset) => sum + asset.yield, 0) / portfolio.length) || 0;
  const avgEsgScore = (portfolio.reduce((sum, asset) => sum + asset.esgScore, 0) / portfolio.length) || 0;

  // Filter list of counties & statuses for drop-downs
  const counties = ["Warwickshire", "Greater Manchester", "West Midlands", "Bristol (City of)", "Midlothian", "Sovereign Isle", "West Yorkshire", "Northamptonshire", "Hertfordshire"];
  const statuses = ["Planning Approved", "Allocated", "Draft Allocation", "Strategic Reserve", "Under Review", "No Allocation"];

  // Bloomberg-style live property sensor feed
  const feedItems = [
    { time: "08:14", category: "REGULATORY", text: "HM Treasury confirms planning sandbox rules for key HS2 transit hubs." },
    { time: "07:30", category: "SOVEREIGN", text: "Ellan Vannin Strategic Fund targets £45m allocation for Northwestern brownfield log-parks." },
    { time: "06:05", category: "ENVIRONMENT", text: "EA issues updated Zone 3 flood risk maps for Severnside delta corridor." },
    { time: "Yesterday", category: "ACQUISITION", text: "Crown Estate offloads 12-hectare agricultural parcel in Warwickshire for strategic review." }
  ];

  return (
    <div className="space-y-6 font-sans text-neutral-400">
      
      {/* 1. Top HUD Sovereign KPI Panel */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* KPI: Value */}
        <div className="bg-[#0A0A0A] border border-white/5 p-4 flex flex-col justify-between rounded-sm">
          <div className="flex justify-between items-center text-white/40">
            <span className="text-[9px] uppercase tracking-wider font-mono font-bold">TOTAL PORTFOLIO VALUE</span>
            <DollarSign className="w-3.5 h-3.5 text-[#00FF41]" />
          </div>
          <div className="my-2.5">
            <span className="text-xl font-bold font-mono text-white">£{(totalHoldingsValue / 1000000).toFixed(1)}M</span>
            <span className="text-[9px] text-[#00FF41] ml-2 font-mono font-bold">
              +{(((totalHoldingsValue - totalAcquisitionCost) / totalAcquisitionCost) * 100).toFixed(1)}%
            </span>
          </div>
          <div className="text-[8px] text-white/30 flex justify-between font-mono">
            <span>COST BASIS: £{(totalAcquisitionCost / 1000000).toFixed(1)}M</span>
            <span>4 CORE ASSETS</span>
          </div>
        </div>

        {/* KPI: IRR */}
        <div className="bg-[#0A0A0A] border border-white/5 p-4 flex flex-col justify-between rounded-sm">
          <div className="flex justify-between items-center text-white/40">
            <span className="text-[9px] uppercase tracking-wider font-mono font-bold">PORTFOLIO IRR (AGG)</span>
            <TrendingUp className="w-3.5 h-3.5 text-[#00FF41]" />
          </div>
          <div className="my-2.5">
            <span className="text-xl font-bold font-mono text-[#00FF41]">{aggregateIrr.toFixed(2)}%</span>
            <span className="text-[9px] text-white/40 ml-2 font-mono">BM: 8.5%</span>
          </div>
          <div className="text-[8px] text-white/30 flex justify-between font-mono">
            <span>TARGET HURDLE: 10.0%</span>
            <span className="text-[#00FF41]">EXCEEDED</span>
          </div>
        </div>

        {/* KPI: Yield */}
        <div className="bg-[#0A0A0A] border border-white/5 p-4 flex flex-col justify-between rounded-sm">
          <div className="flex justify-between items-center text-white/40">
            <span className="text-[9px] uppercase tracking-wider font-mono font-bold">WEIGHTED ANNUAL YIELD</span>
            <Activity className="w-3.5 h-3.5 text-yellow-400" />
          </div>
          <div className="my-2.5">
            <span className="text-xl font-bold font-mono text-white">{aggregateYield.toFixed(1)}%</span>
            <span className="text-[9px] text-[#00FF41] ml-2 font-mono font-bold">Stable Inflow</span>
          </div>
          <div className="text-[8px] text-white/30 flex justify-between font-mono">
            <span>RENT: £4.36M/AN</span>
            <span>97.2% CAP RATE</span>
          </div>
        </div>

        {/* KPI: ESG */}
        <div className="bg-[#0A0A0A] border border-white/5 p-4 flex flex-col justify-between rounded-sm">
          <div className="flex justify-between items-center text-white/40">
            <span className="text-[9px] uppercase tracking-wider font-mono font-bold">ESG COMPLIANCE</span>
            <Award className="w-3.5 h-3.5 text-[#00FF41]" />
          </div>
          <div className="my-2.5">
            <span className="text-xl font-bold font-mono text-white">{avgEsgScore.toFixed(0)} / 100</span>
            <span className="text-[9px] text-[#00FF41] ml-2 font-mono font-bold">Class A</span>
          </div>
          <div className="text-[8px] text-white/30 flex justify-between font-mono">
            <span>NET-ZERO LIMIT: 2030</span>
            <span>HIGH ACCORD</span>
          </div>
        </div>

      </div>

      {/* 2. Land Search Grid Filters Panel */}
      <div className="bg-[#0A0A0A] border border-white/5 p-4 rounded-sm">
        <div className="text-[10px] font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-2 font-mono">
          <Search className="w-3.5 h-3.5 text-[#00FF41]" />
          LAND TWIN DATABASE INTEGRATION FILTERS
        </div>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          
          {/* Postcode Search */}
          <div>
            <span className="text-[9px] text-white/40 block font-mono font-bold mb-1.5 uppercase">Postcode / Address Query</span>
            <input
              type="text"
              placeholder="e.g. B92, Salford..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-black/40 border border-white/10 text-white px-3 py-1.5 text-[11px] font-mono outline-none focus:border-[#00FF41] rounded-sm placeholder-white/20"
            />
          </div>

          {/* County Filter */}
          <div>
            <span className="text-[9px] text-white/40 block font-mono font-bold mb-1.5 uppercase">Appraisal County</span>
            <select
              value={selectedCounty}
              onChange={(e) => setSelectedCounty(e.target.value)}
              className="w-full bg-black/40 border border-white/10 text-white px-2 py-1.5 text-[11px] font-mono outline-none focus:border-[#00FF41] rounded-sm cursor-pointer"
            >
              <option value="">-- ALL COUNTIES --</option>
              {counties.map(c => (
                <option key={c} value={c} className="bg-neutral-950 text-white">{c.toUpperCase()}</option>
              ))}
            </select>
          </div>

          {/* Planning Status Filter */}
          <div>
            <span className="text-[9px] text-white/40 block font-mono font-bold mb-1.5 uppercase">Planning Release status</span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full bg-black/40 border border-white/10 text-white px-2 py-1.5 text-[11px] font-mono outline-none focus:border-[#00FF41] rounded-sm cursor-pointer"
            >
              <option value="">-- ALL STATUSES --</option>
              {statuses.map(s => (
                <option key={s} value={s} className="bg-neutral-950 text-white">{s.toUpperCase()}</option>
              ))}
            </select>
          </div>

          {/* Reset button */}
          <div className="flex items-end">
            <button
              onClick={() => {
                setSearchTerm("");
                setSelectedCounty("");
                setSelectedStatus("");
              }}
              className="w-full bg-white/5 border border-white/10 hover:bg-white/10 text-white py-1.5 text-[11px] font-bold uppercase transition-colors rounded-sm cursor-pointer tracking-wider font-mono"
            >
              Reset Filters
            </button>
          </div>

        </div>
      </div>

      {/* 3. Main content area: Registry Grid vs Live Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* National Registry Database Grid */}
        <div className="lg:col-span-2 bg-[#0A0A0A] border border-white/5 p-4 flex flex-col justify-between rounded-sm">
          <div>
            <div className="flex justify-between items-center border-b border-white/10 pb-3 mb-3">
              <span className="text-[11px] font-bold text-white uppercase tracking-wider font-mono">Sovereign Land Ledger</span>
              <span className="text-[9px] text-white/40 font-mono">{parcels.length} CLASSIFIED REGISTERS</span>
            </div>
            
            <div className="max-h-[260px] overflow-y-auto space-y-1.5 pr-1">
              {parcels.map(p => (
                <div
                  key={p.id}
                  onClick={() => onSelectParcel(p)}
                  className="bg-black/20 border border-white/5 hover:border-[#00FF41] p-3 flex justify-between items-center cursor-pointer transition-all duration-150 rounded-sm"
                >
                  <div className="flex items-center gap-3">
                    <div className="text-[10px] font-mono font-bold text-[#00FF41] bg-[#00FF41]/10 px-2 py-1 rounded-sm border border-[#00FF41]/20">
                      {p.id}
                    </div>
                    <div>
                      <div className="text-[10px] font-bold text-white font-mono">{p.county.toUpperCase()} ({p.postcode})</div>
                      <div className="text-[9px] text-white/40 font-sans mt-0.5">{p.currentUse} // {p.area} Hectares</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-[10px] font-bold font-mono text-white">£{(p.currentValue / 1000000).toFixed(2)}M</div>
                    <div className="text-[8px] uppercase tracking-wider text-white/30 mt-0.5 font-mono">{p.planningStatus}</div>
                  </div>
                </div>
              ))}
              {parcels.length === 0 && (
                <div className="text-center py-12 text-xs text-white/30 font-mono">No matching records found.</div>
              )}
            </div>
          </div>

          <div className="text-[8px] text-white/20 border-t border-white/5 pt-3 mt-3 flex justify-between font-mono">
            <span>GRID SYNCHRONIZATION: REGISTER MATCHED</span>
            <span>DATA REPLICAS: DEFRA // ORDNANCE SURVEY // HM LAND REGISTRY</span>
          </div>
        </div>

        {/* Live Market/Property Ticker Logs */}
        <div className="bg-[#0A0A0A] border border-white/5 p-4 flex flex-col justify-between rounded-sm">
          <div>
            <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-3">
              <span className="text-[11px] font-bold text-[#00FF41] uppercase tracking-wider flex items-center gap-2 font-mono">
                <Bell className="w-3.5 h-3.5 animate-pulse text-yellow-400" /> LIVE PROPERTY SENSOR
              </span>
              <span className="bg-white/10 text-white text-[8px] px-1.5 py-0.5 font-bold font-mono rounded-xs">TAPE-01</span>
            </div>

            <div className="space-y-3.5 max-h-[260px] overflow-y-auto">
              {feedItems.map((feed, idx) => (
                <div key={idx} className="border-b border-white/5 pb-3 last:border-none">
                  <div className="flex justify-between text-[8px] mb-1 font-mono">
                    <span className="font-bold text-[#00FF41] bg-[#00FF41]/10 px-1 border border-[#00FF41]/25 rounded-xs">{feed.category}</span>
                    <span className="text-white/30 font-bold">{feed.time}</span>
                  </div>
                  <p className="text-[10px] text-white/60 leading-normal font-sans">{feed.text}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="text-[8px] bg-black/40 text-white/30 py-2 text-center mt-3 border border-white/5 rounded-xs font-mono">
            SECURED CRYPTO FEED ENCRYPTION ACTIVE
          </div>
        </div>

      </div>

    </div>
  );
}
