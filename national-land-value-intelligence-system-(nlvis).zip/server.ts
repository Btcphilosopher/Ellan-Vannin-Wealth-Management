import express from "express";
import path from "path";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";

dotenv.config();

const app = express();
app.use(express.json());

const PORT = 3000;

// Lazy initialization of Gemini API Client
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      throw new Error("GEMINI_API_KEY environment variable is not defined.");
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          "User-Agent": "aistudio-build",
        },
      },
    });
  }
  return aiClient;
}

// REST API Endpoints
app.get("/api/health", (req, res) => {
  res.json({ status: "healthy", timestamp: new Date().toISOString() });
});

// Server-side AI Assessment Generator
app.post("/api/gemini/assessment", async (req, res) => {
  try {
    const { parcel } = req.body;
    if (!parcel) {
      return res.status(400).json({ error: "Missing parcel details." });
    }

    const client = getAiClient();
    
    const prompt = `You are an expert GIS engineer, senior property economist, and quantitative sovereign land analyst representing Ellan Vannin Wealth Management (Isle of Man).
    
    Review and analyze the following UK land parcel under our National Land Value Intelligence System (NLVIS):
    
    PARCEL DETAILS:
    - ID: ${parcel.id}
    - Region/County: ${parcel.county} / ${parcel.district}
    - Location: ${parcel.location} (Coordinates: ${parcel.lat.toFixed(4)}, ${parcel.lng.toFixed(4)})
    - Area: ${parcel.area} hectares
    - Current Use: ${parcel.currentUse}
    - Soil Grade/Elevation: Class ${parcel.soilGrade || "N/A"} / ${parcel.elevation}m (Slope: ${parcel.slope}°)
    - Planning Status: ${parcel.planningStatus}
    - Flood Zone Risk: ${parcel.floodZone}
    - Base Market Value: £${(parcel.currentValue || 0).toLocaleString()}
    - Expected Uplift with Development: £${(parcel.futureValue || 0).toLocaleString()}
    - Key Infrastructure Proximity: ${parcel.transportAccess || "Standard"}
    
    Please provide an institutional-grade, highly structured Land Investment Memorandum.
    Structure your answer exactly using these Markdown sections:
    
    ### 1. STRATEGIC ACQUISITION THESIS
    (Formulate a professional sovereign investment thesis detailing why this site fits Ellan Vannin Wealth Management's long-term sovereign strategic criteria. Discuss regional alignment, macro growth corridors, and locational advantages.)
    
    ### 2. RISK ANALYSIS & CONSTRAINTS
    (Provide a detailed engineering and economic evaluation of structural risks, specifically referencing the elevation, slope, soil grade, flood zone risk, and any planning hurdles like Green Belt or Conservation buffer overrides.)
    
    ### 3. DEVELOPMENT POTENTIAL & VALUE CAPTURE
    (Analyze the residual land valuation uplift, proposing the most viable development route. Quantify how much value could be unlocked and describe the local community and infrastructure tax base improvements, such as council rates or local business rates.)
    
    ### 4. SOVEREIGN ADVISORY VERDICT
    (Give a final executive decision: Strong Buy, Strategic Hold, Conditional Option, or Reject, accompanied by a target acquisition range and recommended tactical next steps.)
    
    Keep the tone clinical, quantitative, objective, and highly professional, fitting the standards of a multi-billion-pound sovereign wealth fund.`;

    const response = await client.models.generateContent({
      model: "gemini-3.6-flash",
      contents: prompt,
    });

    res.json({ assessment: response.text });
  } catch (error: any) {
    console.error("Gemini API Error:", error.message);
    res.status(500).json({ 
      error: "Could not generate AI assessment.",
      details: error.message,
      keyMissing: !process.env.GEMINI_API_KEY
    });
  }
});

// Configure Vite or Serve Static Files
async function main() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`NLVIS Server running on port ${PORT}`);
  });
}

main().catch((err) => {
  console.error("Failed to start server:", err);
});
