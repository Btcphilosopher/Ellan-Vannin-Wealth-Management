/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Airport, Route, PortfolioAsset } from "./types";
import { 
  Layers, Database, Compass, Settings2, BarChart3, 
  Map, Activity, Eye, Shield, Play, Code, FileText, 
  ChevronRight, Calendar, AlertCircle, Wallet
} from "lucide-react";

// Views
import ExecutiveDashboard from "./components/ExecutiveDashboard";
import AirportRegister from "./components/AirportRegister";
import RouteEngine from "./components/RouteEngine";
import RouteEconomics from "./components/RouteEconomics";
import InvestmentDashboard from "./components/InvestmentDashboard";
import ConnectivityIndex from "./components/ConnectivityIndex";
import DigitalTwin from "./components/DigitalTwin";
import DemandForecasting from "./components/DemandForecasting";
import GisDashboard from "./components/GisDashboard";
import PortfolioAnalytics from "./components/PortfolioAnalytics";
import ScenarioSimulator from "./components/ScenarioSimulator";
import RustCodeExplorer from "./components/RustCodeExplorer";
import ReportingEngine from "./components/ReportingEngine";

type Tab = 
  | "executive" 
  | "register" 
  | "route-engine" 
  | "economics" 
  | "investment" 
  | "connectivity" 
  | "digital-twin" 
  | "forecasting" 
  | "gis" 
  | "portfolio" 
  | "scenario" 
  | "rust" 
  | "reporting";

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>("executive");

  // Global Datasets States
  const [airports, setAirports] = useState<Airport[]>([]);
  const [routes, setRoutes] = useState<Route[]>([]);
  const [connectivityScores, setConnectivityScores] = useState<any[]>([]);
  const [portfolio, setPortfolio] = useState<PortfolioAsset[]>([]);

  // Simulation parameters
  const [warnings, setWarnings] = useState<string[]>([]);
  const [globalConnectivityScore, setGlobalConnectivityScore] = useState(74.5);
  const [isSimulating, setIsSimulating] = useState(false);

  // Digital Twin specific selection
  const [digitalTwinCode, setDigitalTwinCode] = useState("IOM");

  // Initial synchronization on mount
  useEffect(() => {
    fetch("/api/airports")
      .then((res) => res.json())
      .then((data) => setAirports(data))
      .catch((err) => console.error("Error fetching airports:", err));

    fetch("/api/routes")
      .then((res) => res.json())
      .then((data) => setRoutes(data))
      .catch((err) => console.error("Error fetching routes:", err));

    fetch("/api/connectivity")
      .then((res) => res.json())
      .then((data) => setConnectivityScores(data))
      .catch((err) => console.error("Error fetching connectivity:", err));

    fetch("/api/portfolio")
      .then((res) => res.json())
      .then((data) => setPortfolio(data))
      .catch((err) => console.error("Error fetching portfolio:", err));
  }, []);

  // Airport Register handlers
  const handleUpsertAirport = (updatedApt: Airport) => {
    fetch("/api/airports", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(updatedApt),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          const index = airports.findIndex((a) => a.code === updatedApt.code);
          if (index > -1) {
            const updatedList = [...airports];
            updatedList[index] = updatedApt;
            setAirports(updatedList);
          } else {
            setAirports([...airports, updatedApt]);
          }
        }
      })
      .catch((err) => console.error("Error upserting airport:", err));
  };

  const handleDeleteAirport = (code: string) => {
    fetch(`/api/airports/${code}`, { method: "DELETE" })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setAirports(airports.filter((a) => a.code !== code));
        }
      })
      .catch((err) => console.error("Error deleting airport:", err));
  };

  // Scenario Simulator execution
  const handleTriggerSimulation = (params: {
    newRunwayAt: string | null;
    terminalExpansionAt: string | null;
    demandShift: number;
    fuelPriceMultiplier: number;
    closedAirports: string[];
  }) => {
    setIsSimulating(true);
    fetch("/api/scenario-simulate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(params),
    })
      .then((res) => res.json())
      .then((data) => {
        if (data.success) {
          setAirports(data.airports);
          setWarnings(data.warnings);
          setGlobalConnectivityScore(74.5 * params.demandShift);
          setIsSimulating(false);
          // Auto route to Executive view to see changes
          setActiveTab("executive");
        }
      })
      .catch((err) => {
        console.error("Error running simulation:", err);
        setIsSimulating(false);
      });
  };

  if (airports.length === 0 || routes.length === 0) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-50 text-slate-500 font-mono text-xs">
        <div className="text-center space-y-3">
          <Activity className="w-8 h-8 mx-auto text-indigo-500 animate-spin" />
          <p className="font-semibold text-slate-700">Booting SKYBRIDGE™ Operating System...</p>
          <p className="text-[10px] text-slate-400">Loading sovereign domestic aviation graph registers</p>
        </div>
      </div>
    );
  }

  return (
    <div id="skybridge-app-layout" className="flex h-screen bg-[#F8F9FA] text-[#1A1A1A] font-sans overflow-hidden">
      
      {/* Sidebar Navigation */}
      <div className="w-64 bg-white text-[#1A1A1A] flex flex-col justify-between shrink-0 border-r border-[#E5E7EB] py-8 px-6">
        
        {/* Brand Header */}
        <div>
          <div>
            <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">SKYBRIDGE™</h1>
            <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">National Infrastructure OS</p>
          </div>

          {/* Nav Items */}
          <nav className="space-y-1 mt-8 overflow-y-auto max-h-[60vh] pr-1">
            <span className="text-[10px] uppercase font-bold tracking-widest text-gray-400 block mb-3">SYSTEM CONSOLE</span>

            {[
              { id: "executive", label: "Executive Board", icon: Layers },
              { id: "register", label: "Airport Register", icon: Database },
              { id: "route-engine", label: "Route Graph Engine", icon: Compass },
              { id: "economics", label: "Route Economics", icon: Settings2 },
              { id: "investment", label: "Asset Capex & ROI", icon: BarChart3 },
              { id: "connectivity", label: "Connectivity Index", icon: Map },
              { id: "digital-twin", label: "Digital Twin", icon: Eye },
              { id: "forecasting", label: "Demand Forecasting", icon: Activity },
              { id: "gis", label: "GIS Dashboard", icon: Map },
              { id: "portfolio", label: "Portfolio Analytics", icon: Wallet },
              { id: "scenario", label: "Scenario Sandbox", icon: Play },
              { id: "rust", label: "Rust Core Engine", icon: Code },
              { id: "reporting", label: "Memorandums", icon: FileText }
            ].map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id as Tab)}
                  className={`w-full flex items-center justify-between px-3 py-1.5 rounded-sm text-xs font-medium transition-all ${
                    isActive 
                      ? "bg-gray-100 text-black font-semibold" 
                      : "hover:bg-gray-50 hover:text-black text-gray-500"
                  }`}
                >
                  <div className="flex items-center gap-2">
                    {isActive ? (
                      <span className="w-1.5 h-1.5 rounded-full bg-blue-600 shrink-0"></span>
                    ) : (
                      <span className="w-1.5 h-1.5 border border-gray-300 rounded-full shrink-0"></span>
                    )}
                    <span>{item.label}</span>
                  </div>
                  <ChevronRight className="w-3 h-3 opacity-30" />
                </button>
              );
            })}
          </nav>
        </div>

        {/* User Account / Corporate Status Footer */}
        <div className="space-y-4 pt-6 border-t border-gray-100">
          <div className="p-3 bg-gray-50 border border-gray-100 rounded-sm">
            <p className="text-[9px] text-gray-400 uppercase tracking-widest font-bold mb-1">System Status</p>
            <div className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span>
              <span className="text-[10px] font-mono text-gray-600 font-semibold uppercase">UK_CORE_ACTIVE</span>
            </div>
          </div>
          <div className="text-[10px] text-gray-400 font-mono tracking-wider">
            v1.2.4 | ELLAN VANNIN
          </div>
        </div>
      </div>

      {/* Main Board Viewport */}
      <div className="flex-1 flex flex-col overflow-hidden bg-[#F8F9FA]">
        
        {/* Header telemetry ribbon */}
        <header className="h-16 bg-white border-b border-[#E5E7EB] px-8 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-4 text-[10px] font-mono uppercase tracking-wider text-gray-500">
            <span className="flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 bg-green-500 rounded-full"></span>
              Grid Active
            </span>
            <span className="text-gray-300">|</span>
            <span>Airports: {airports.length}</span>
            <span className="text-gray-300">|</span>
            <span>Route Legs: {routes.length}</span>
          </div>

          {/* Quick link to twin selector */}
          <div className="flex items-center gap-2 text-xs">
            <span className="text-gray-400 font-mono text-[10px] uppercase tracking-wider">Twin Telemetry Focus:</span>
            <select
              value={digitalTwinCode}
              onChange={(e) => {
                setDigitalTwinCode(e.target.value);
                setActiveTab("digital-twin");
              }}
              className="bg-white border border-gray-200 rounded-sm px-2.5 py-1 focus:outline-none font-bold text-black text-xs cursor-pointer hover:border-gray-300 transition-colors"
            >
              {airports.map((a) => (
                <option key={a.code} value={a.code}>
                  {a.code} - {a.name}
                </option>
              ))}
            </select>
          </div>
        </header>

        {/* Interactive Viewport Content */}
        <main className="flex-1 overflow-y-auto p-8 max-w-7xl w-full mx-auto">
          {activeTab === "executive" && (
            <ExecutiveDashboard
              airports={airports}
              routes={routes}
              portfolio={portfolio}
              warnings={warnings}
              connectivityScore={globalConnectivityScore}
            />
          )}

          {activeTab === "register" && (
            <AirportRegister
              airports={airports}
              onUpsert={handleUpsertAirport}
              onDelete={handleDeleteAirport}
            />
          )}

          {activeTab === "route-engine" && (
            <RouteEngine
              airports={airports}
              routes={routes}
              connectivityScore={globalConnectivityScore}
            />
          )}

          {activeTab === "economics" && (
            <RouteEconomics
              routes={routes}
            />
          )}

          {activeTab === "investment" && (
            <InvestmentDashboard
              airports={airports}
            />
          )}

          {activeTab === "connectivity" && (
            <ConnectivityIndex
              connectivityScores={connectivityScores}
            />
          )}

          {activeTab === "digital-twin" && (
            <DigitalTwin
              airportCode={digitalTwinCode}
            />
          )}

          {activeTab === "forecasting" && (
            <DemandForecasting
              airports={airports}
            />
          )}

          {activeTab === "gis" && (
            <GisDashboard
              airports={airports}
              routes={routes}
            />
          )}

          {activeTab === "portfolio" && (
            <PortfolioAnalytics
              portfolio={portfolio}
            />
          )}

          {activeTab === "scenario" && (
            <ScenarioSimulator
              airports={airports}
              onTriggerSimulation={handleTriggerSimulation}
              isSimulating={isSimulating}
            />
          )}

          {activeTab === "rust" && (
            <RustCodeExplorer />
          )}

          {activeTab === "reporting" && (
            <ReportingEngine />
          )}
        </main>
      </div>
    </div>
  );
}
