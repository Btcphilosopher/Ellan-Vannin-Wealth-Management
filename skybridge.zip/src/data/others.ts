/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ConnectivityScore, DigitalTwinInfrastructure, PortfolioAsset } from "../types";

export const initialConnectivityScores: ConnectivityScore[] = [
  {
    region: "Greater London",
    domesticFlightsScore: 98,
    railConnectivityScore: 99,
    motorwayAccessScore: 92,
    ferryAccessScore: 10,
    overallIndex: 88,
  },
  {
    region: "South East",
    domesticFlightsScore: 90,
    railConnectivityScore: 95,
    motorwayAccessScore: 94,
    ferryAccessScore: 75,
    overallIndex: 89,
  },
  {
    region: "North West",
    domesticFlightsScore: 85,
    railConnectivityScore: 90,
    motorwayAccessScore: 92,
    ferryAccessScore: 50,
    overallIndex: 83,
  },
  {
    region: "West Midlands",
    domesticFlightsScore: 80,
    railConnectivityScore: 92,
    motorwayAccessScore: 96,
    ferryAccessScore: 5,
    overallIndex: 81,
  },
  {
    region: "Scotland (Central Belt)",
    domesticFlightsScore: 88,
    railConnectivityScore: 82,
    motorwayAccessScore: 80,
    ferryAccessScore: 40,
    overallIndex: 78,
  },
  {
    region: "Scotland (Highlands & Islands)",
    domesticFlightsScore: 65,
    railConnectivityScore: 25,
    motorwayAccessScore: 20,
    ferryAccessScore: 85,
    overallIndex: 44, // Vulnerable region
  },
  {
    region: "Yorkshire and Humber",
    domesticFlightsScore: 60,
    railConnectivityScore: 85,
    motorwayAccessScore: 88,
    ferryAccessScore: 35,
    overallIndex: 71,
  },
  {
    region: "North East",
    domesticFlightsScore: 65,
    railConnectivityScore: 78,
    motorwayAccessScore: 80,
    ferryAccessScore: 30,
    overallIndex: 68,
  },
  {
    region: "Wales",
    domesticFlightsScore: 45,
    railConnectivityScore: 70,
    motorwayAccessScore: 75,
    ferryAccessScore: 60,
    overallIndex: 61,
  },
  {
    region: "Northern Ireland",
    domesticFlightsScore: 78,
    railConnectivityScore: 45,
    motorwayAccessScore: 50,
    ferryAccessScore: 80,
    overallIndex: 65,
  },
  {
    region: "Isle of Man",
    domesticFlightsScore: 82,
    railConnectivityScore: 10, // Vintage/heritage rail only
    motorwayAccessScore: 5,   // No motorways
    ferryAccessScore: 95,     // Lifeline sea link
    overallIndex: 46,         // Isolated transport profile, highly dependent on air link resilience
  },
  {
    region: "South West",
    domesticFlightsScore: 55,
    railConnectivityScore: 72,
    motorwayAccessScore: 78,
    ferryAccessScore: 35,
    overallIndex: 64,
  },
  {
    region: "East Midlands",
    domesticFlightsScore: 70,
    railConnectivityScore: 84,
    motorwayAccessScore: 90,
    ferryAccessScore: 5,
    overallIndex: 74,
  }
];

export const initialDigitalTwins: DigitalTwinInfrastructure[] = [
  {
    airportCode: "IOM",
    terminalsCount: 1,
    gatesCount: 8,
    taxiwaysCount: 3,
    runwaysCount: 2,
    aircraftStands: 12,
    maintenanceFacilities: 2,
    terminalUtilisation: 68,
    runwayUtilisation: 42,
    gateUtilisation: 58,
    maintenanceSchedule: [
      { asset: "Runway 08/26 Resurfacing", lastChecked: "2025-06-15", nextScheduled: "2026-09-20", status: "Pending" },
      { asset: "Terminal HVAC Upgrade", lastChecked: "2026-02-10", nextScheduled: "2026-08-15", status: "Optimal" },
      { asset: "Gate 4 Stand Extension", lastChecked: "2025-11-01", nextScheduled: "2026-07-01", status: "Under Maintenance" },
      { asset: "Instrument Landing System Calibration", lastChecked: "2026-05-20", nextScheduled: "2026-11-20", status: "Optimal" }
    ]
  },
  {
    airportCode: "MAN",
    terminalsCount: 3,
    gatesCount: 54,
    taxiwaysCount: 18,
    runwaysCount: 2,
    aircraftStands: 110,
    maintenanceFacilities: 6,
    terminalUtilisation: 82,
    runwayUtilisation: 88,
    gateUtilisation: 79,
    maintenanceSchedule: [
      { asset: "Runway 23R Alpha Taxiway Joint Repair", lastChecked: "2026-04-05", nextScheduled: "2026-08-05", status: "Under Maintenance" },
      { asset: "Terminal 2 Pier C Expansion", lastChecked: "2025-08-12", nextScheduled: "2026-10-10", status: "Optimal" },
      { asset: "Stand 32 Visual Docking Guidance Repair", lastChecked: "2026-07-28", nextScheduled: "2026-08-02", status: "Pending" }
    ]
  },
  {
    airportCode: "LHR",
    terminalsCount: 4,
    gatesCount: 135,
    taxiwaysCount: 42,
    runwaysCount: 2,
    aircraftStands: 210,
    maintenanceFacilities: 12,
    terminalUtilisation: 94,
    runwayUtilisation: 98,
    gateUtilisation: 95,
    maintenanceSchedule: [
      { asset: "Southern Runway Core Maintenance", lastChecked: "2026-07-01", nextScheduled: "2026-08-15", status: "Pending" },
      { asset: "Terminal 5 Baggage Handling Retrofit", lastChecked: "2025-12-10", nextScheduled: "2026-12-10", status: "Optimal" }
    ]
  },
  {
    airportCode: "EDI",
    terminalsCount: 1,
    gatesCount: 28,
    taxiwaysCount: 8,
    runwaysCount: 1,
    aircraftStands: 45,
    maintenanceFacilities: 2,
    terminalUtilisation: 88,
    runwayUtilisation: 91,
    gateUtilisation: 84,
    maintenanceSchedule: [
      { asset: "Terminal Security Laneway Expansion", lastChecked: "2026-01-20", nextScheduled: "2026-08-25", status: "Under Maintenance" },
      { asset: "Main Runway Rubber Removal", lastChecked: "2026-07-15", nextScheduled: "2026-09-15", status: "Optimal" }
    ]
  },
  {
    airportCode: "CWL",
    terminalsCount: 1,
    gatesCount: 12,
    taxiwaysCount: 4,
    runwaysCount: 1,
    aircraftStands: 18,
    maintenanceFacilities: 3,
    terminalUtilisation: 32,
    runwayUtilisation: 28,
    gateUtilisation: 35,
    maintenanceSchedule: [
      { asset: "Hangar 2 Roof Repairs", lastChecked: "2025-09-01", nextScheduled: "2026-08-10", status: "Pending" },
      { asset: "Runway Lighting Upgrade", lastChecked: "2026-03-12", nextScheduled: "2026-09-12", status: "Optimal" }
    ]
  }
];

export const ellanVanninPortfolio: PortfolioAsset[] = [
  {
    code: "IOM",
    name: "Isle of Man (Ronaldsway) Lease",
    capitalDeployed: 65.2, // £M
    equityOwnership: 45, // 45% infrastructure leasehold
    currentValue: 72.8,
    expectedIRR: 8.4,
    cashFlowAnnual: [5.2, 5.5, 5.8, 6.2, 6.6], // £M
    acquisitionDate: "2022-04-12",
  },
  {
    code: "CWL",
    name: "Cardiff Airport Joint-Venture",
    capitalDeployed: 35.0,
    equityOwnership: 30,
    currentValue: 31.5,
    expectedIRR: 5.2,
    cashFlowAnnual: [1.8, 2.0, 2.3, 2.7, 3.1],
    acquisitionDate: "2023-09-30",
  },
  {
    code: "EMA",
    name: "East Midlands Logistics Hub",
    capitalDeployed: 120.0,
    equityOwnership: 15,
    currentValue: 135.6,
    expectedIRR: 11.2,
    cashFlowAnnual: [12.4, 13.2, 14.1, 15.0, 16.2],
    acquisitionDate: "2021-02-18",
  }
];
