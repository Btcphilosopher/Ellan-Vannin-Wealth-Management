/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Airport {
  code: string;
  name: string;
  region: string;
  runway_length_m: number;
  terminal_capacity: number; // annual passenger capacity limit
  annual_passengers: number;
  annual_movements: number;
  utilisation: number; // ratio of annual_passengers to terminal_capacity (0 to 1)
  estimated_asset_value: number; // in GBP millions
  cargo_throughput_tonnes: number;
  ownership: string; // e.g., "Private", "Public", "Ellan Vannin Asset"
  expansion_potential: "Low" | "Medium" | "High";
  strategic_importance: "Sovereign Hub" | "Regional Critical" | "Local Connective";
}

export interface Route {
  id: string;
  origin: string; // airport code
  destination: string; // airport code
  distance_km: number;
  frequency_weekly: number;
  average_fare: number; // GBP
  operating_cost_hour: number; // GBP/hour
  passenger_demand_annual: number;
  average_load_factor: number; // percentage (0 to 100)
  block_time_mins: number;
}

export interface RouteEconomicsInput {
  passengerDemand: number;
  averageFare: number;
  operatingCostHour: number;
  airportCharges: number;
  aircraftUtilisationHours: number;
}

export interface RouteEconomicsOutput {
  revenue: number;
  operatingCost: number;
  airportChargesTotal: number;
  profit: number;
  operatingMargin: number;
  breakEvenLoadFactor: number;
  sensitivity: {
    fareChange: number;
    margin: number;
  }[];
}

export interface ConnectivityScore {
  region: string;
  domesticFlightsScore: number; // 0-100
  railConnectivityScore: number; // 0-100
  motorwayAccessScore: number; // 0-100
  ferryAccessScore: number; // 0-100
  overallIndex: number; // 0-100
}

export interface DigitalTwinInfrastructure {
  airportCode: string;
  terminalsCount: number;
  gatesCount: number;
  taxiwaysCount: number;
  runwaysCount: number;
  aircraftStands: number;
  maintenanceFacilities: number;
  terminalUtilisation: number; // percentage
  runwayUtilisation: number; // percentage
  gateUtilisation: number; // percentage
  maintenanceSchedule: {
    asset: string;
    lastChecked: string;
    nextScheduled: string;
    status: "Optimal" | "Pending" | "Under Maintenance";
  }[];
}

export interface PortfolioAsset {
  code: string;
  name: string;
  capitalDeployed: number; // GBP millions
  equityOwnership: number; // percentage (e.g. 45%)
  currentValue: number; // GBP millions
  expectedIRR: number; // percentage
  cashFlowAnnual: number[]; // 5-year project cashflows
  acquisitionDate: string;
}

export interface ScenarioParameters {
  newRunwayAt: string | null; // Airport code
  terminalExpansionAt: string | null; // Airport code
  additionalRoutes: string[]; // List of "ORIG-DEST" routes added
  demandShift: number; // multiplier (e.g. 1.15 for +15%, 0.85 for -15%)
  fuelPriceMultiplier: number; // multiplier (e.g. 1.25 for +25% fuel cost)
  closedAirports: string[]; // list of closed airport codes
}
