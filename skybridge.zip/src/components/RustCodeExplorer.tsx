/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Code, Terminal, FileCode, CheckCircle, Info, Layers } from "lucide-react";

interface RustFile {
  filename: string;
  path: string;
  content: string;
}

export default function RustCodeExplorer() {
  const [rustFiles, setRustFiles] = useState<RustFile[]>([]);
  const [selectedFilename, setSelectedFilename] = useState("Cargo.toml");
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    setIsLoading(true);
    fetch("/api/rust-code")
      .then((res) => res.json())
      .then((data) => {
        setRustFiles(data);
        setIsLoading(false);
      })
      .catch((err) => {
        console.error(err);
        setIsLoading(false);
      });
  }, []);

  const activeFile = rustFiles.find((f) => f.filename === selectedFilename);

  return (
    <div id="rust-code-explorer-container" className="space-y-6">
      <div className="border-b border-[#E5E7EB] pb-4">
        <h1 className="text-xl font-bold tracking-tighter text-[#0F172A] font-mono">Module 12: Rust Core Architecture</h1>
        <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Production-ready asynchronous Rust codebase executing graph models, polars forecasting, and REST services</p>
      </div>

      {/* Code highlights grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs font-mono uppercase">
        <div className="bg-gray-50 border border-[#E5E7EB] rounded-sm p-3.5 flex items-center gap-3">
          <Terminal className="w-4 h-4 text-blue-600 shrink-0" />
          <div>
            <div className="text-[#0F172A] font-bold text-[10px] tracking-wider">Tokio & Axum</div>
            <div className="text-[8px] text-gray-400 font-normal mt-0.5 tracking-tight leading-none">Asynchronous concurrent API</div>
          </div>
        </div>

        <div className="bg-gray-50 border border-[#E5E7EB] rounded-sm p-3.5 flex items-center gap-3">
          <Layers className="w-4 h-4 text-emerald-600 shrink-0" />
          <div>
            <div className="text-[#0F172A] font-bold text-[10px] tracking-wider">SQLx & PostgreSQL</div>
            <div className="text-[8px] text-gray-400 font-normal mt-0.5 tracking-tight leading-none">Safe compile checked DB</div>
          </div>
        </div>

        <div className="bg-gray-50 border border-[#E5E7EB] rounded-sm p-3.5 flex items-center gap-3">
          <Code className="w-4 h-4 text-blue-600 shrink-0" />
          <div>
            <div className="text-[#0F172A] font-bold text-[10px] tracking-wider">Petgraph Engine</div>
            <div className="text-[8px] text-gray-400 font-normal mt-0.5 tracking-tight leading-none">Dijkstra network routing</div>
          </div>
        </div>

        <div className="bg-gray-50 border border-[#E5E7EB] rounded-sm p-3.5 flex items-center gap-3">
          <Layers className="w-4 h-4 text-amber-600 shrink-0" />
          <div>
            <div className="text-[#0F172A] font-bold text-[10px] tracking-wider">Polars Analytics</div>
            <div className="text-[8px] text-gray-400 font-normal mt-0.5 tracking-tight leading-none">High-perf demand modeling</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left Hand: Files list */}
        <div className="space-y-2">
          <h3 className="text-[10px] font-bold uppercase tracking-widest text-[#0F172A] mb-2 border-b border-gray-100 pb-2">Workspace Source Files</h3>
          {isLoading ? (
            <div className="text-[10px] font-mono text-gray-400 uppercase tracking-widest animate-pulse">Scanning file tree...</div>
          ) : (
            rustFiles.map((file) => (
              <button
                key={file.filename}
                onClick={() => setSelectedFilename(file.filename)}
                className={`w-full text-left p-2.5 rounded-sm border text-[10px] font-mono transition flex items-center justify-between uppercase tracking-wider ${
                  selectedFilename === file.filename
                    ? "bg-black text-white border-black font-bold"
                    : "bg-white text-gray-500 border-gray-100 hover:bg-gray-50"
                }`}
              >
                <span className="truncate">{file.filename}</span>
                <FileCode className="w-3.5 h-3.5 opacity-50 shrink-0 ml-1" />
              </button>
            ))
          )}
        </div>

        {/* Right Hand: Code Viewer */}
        <div className="lg:col-span-3 space-y-4">
          <div className="bg-black text-gray-300 rounded-sm overflow-hidden border border-black">
            {/* Tab header bar */}
            <div className="bg-zinc-950 border-b border-zinc-900 px-5 py-3 flex justify-between items-center">
              <span className="text-[10px] font-mono font-bold text-blue-400 uppercase tracking-widest">{selectedFilename}</span>
              <span className="text-[8px] font-mono text-gray-500 bg-zinc-900 px-2 py-0.5 rounded-sm tracking-widest uppercase">RUST SOURCE</span>
            </div>

            {/* Source Display */}
            <pre className="p-5 overflow-auto text-[11px] font-mono leading-relaxed h-[420px] text-left">
              <code>{activeFile?.content || "// Load state active..."}</code>
            </pre>
          </div>

          <div className="bg-blue-50 border border-blue-100 p-4 rounded-sm flex gap-3 text-xs leading-relaxed text-blue-800">
            <Info className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
            <div className="font-mono uppercase tracking-tight text-[10px]">
              <p className="font-bold">Sovereign Compiler Integration Verified</p>
              <p className="mt-1 font-normal text-blue-700 leading-normal">
                This fully modular codebase implements complete type definitions, database wrapper abstractions, and
                graph network optimizations using cargo standards. It compiles into a single performant native binary
                for robust container orchestration on secure, sovereign server nodes.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
