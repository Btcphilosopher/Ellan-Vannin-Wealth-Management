/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Airport } from "../types";
import { HelpCircle, Play, RefreshCw, Sparkles, AlertTriangle } from "lucide-react";

interface Props {
  airports: Airport[];
  onTriggerSimulation: (params: {
    newRunwayAt: string | null;
    terminalExpansionAt: string | null;
    demandShift: number;
    fuelPriceMultiplier: number;
    closedAirports: string[];
  }) => void;
  isSimulating: boolean;
}

export default function ScenarioSimulator({ airports, onTriggerSimulation, isSimulating }: Props) {
  const [newRunwayAt, setNewRunwayAt] = useState<string>("");
  const [terminalExpansionAt, setTerminalExpansionAt] = useState<string>("");
  const [demandShift, setDemandShift] = useState<number>(1.0); // 1.0 = neutral
  const [fuelPriceMultiplier, setFuelPriceMultiplier] = useState<number>(1.0); // 1.0 = baseline
  const [closedAirports, setClosedAirports] = useState<string[]>([]);

  const handleToggleCloseAirport = (code: string) => {
    if (closedAirports.includes(code)) {
      setClosedAirports(closedAirports.filter((c) => c !== code));
    } else {
      setClosedAirports([...closedAirports, code]);
    }
  };

  const handleRun = () => {
    onTriggerSimulation({
      newRunwayAt: newRunwayAt || null,
      terminalExpansionAt: terminalExpansionAt || null,
      demandShift,
      fuelPriceMultiplier,
      closedAirports,
    });
  };

  const handleReset = () => {
    setNewRunwayAt("");
    setTerminalExpansionAt("");
    setDemandShift(1.0);
    setFuelPriceMultiplier(1.0);
    setClosedAirports([]);
    onTriggerSimulation({
      newRunwayAt: null,
      terminalExpansionAt: null,
      demandShift: 1.0,
      fuelPriceMultiplier: 1.0,
      closedAirports: [],
    });
  };

  return (
    <div id="scenario-simulator-container" className="space-y-6">
      <div className="border-b border-[#E5E7EB] pb-4">
        <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">Infrastructure Scenario Simulator</h1>
        <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Stress-test UK aviation asset resilience, network congestion, and regional viability live</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Sandbox parameter configuration */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm lg:col-span-2 space-y-5">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] border-b border-gray-100 pb-2">Simulator Control Panel</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Control 1 */}
            <div className="space-y-1">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400">Construct New Runway at:</label>
              <select
                value={newRunwayAt}
                onChange={(e) => setNewRunwayAt(e.target.value)}
                className="w-full text-xs bg-white border border-[#E5E7EB] rounded-sm p-2 focus:outline-none font-mono font-semibold"
              >
                <option value="">-- NO RUNWAY PROJECTS --</option>
                {airports.map((a) => (
                  <option key={a.code} value={a.code}>
                    {a.code} - {a.name}
                  </option>
                ))}
              </select>
            </div>

            {/* Control 2 */}
            <div className="space-y-1">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400">Expand Terminal Apron at:</label>
              <select
                value={terminalExpansionAt}
                onChange={(e) => setTerminalExpansionAt(e.target.value)}
                className="w-full text-xs bg-white border border-[#E5E7EB] rounded-sm p-2 focus:outline-none font-mono font-semibold"
              >
                <option value="">-- NO TERMINAL EXPANSIONS --</option>
                {airports.map((a) => (
                  <option key={a.code} value={a.code}>
                    {a.code} - {a.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Control 3 */}
            <div className="space-y-1">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">
                Demand Shift: {Math.round((demandShift - 1.0) * 100)}%
              </label>
              <input
                type="range"
                min="0.70"
                max="1.30"
                step="0.05"
                value={demandShift}
                onChange={(e) => setDemandShift(Number(e.target.value))}
                className="w-full h-1 bg-gray-200 rounded-sm appearance-none cursor-pointer accent-blue-600"
              />
            </div>

            {/* Control 4 */}
            <div className="space-y-1">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400 font-mono">
                Fuel Price Surcharge: {Math.round((fuelPriceMultiplier - 1.0) * 100)}%
              </label>
              <input
                type="range"
                min="1.0"
                max="1.50"
                step="0.05"
                value={fuelPriceMultiplier}
                onChange={(e) => setFuelPriceMultiplier(Number(e.target.value))}
                className="w-full h-1 bg-gray-200 rounded-sm appearance-none cursor-pointer accent-blue-600"
              />
            </div>
          </div>

          {/* Core Closure list */}
          <div className="space-y-2">
            <label className="block text-[10px] font-bold uppercase tracking-wider text-gray-400">Simulate Airport Decommissioning / Closures:</label>
            <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 text-xs font-mono">
              {airports.map((a) => {
                const isClosed = closedAirports.includes(a.code);
                return (
                  <button
                    key={a.code}
                    onClick={() => handleToggleCloseAirport(a.code)}
                    className={`py-1.5 px-2 rounded-sm border transition text-center font-bold uppercase text-[10px] tracking-wider ${
                      isClosed
                        ? "bg-red-50 text-red-700 border-red-300"
                        : "bg-gray-50 text-gray-600 border-gray-100 hover:bg-gray-100"
                    }`}
                  >
                    {a.code} {isClosed ? "CLOSED" : ""}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Simulation trigger bar */}
          <div className="flex gap-3 pt-4 border-t border-gray-100">
            <button
              onClick={handleReset}
              className="flex items-center justify-center gap-1.5 px-4 py-2 border border-gray-200 hover:bg-gray-50 rounded-sm text-xs font-mono font-bold uppercase text-gray-500 transition"
            >
              <RefreshCw className="w-3.5 h-3.5" /> Reset
            </button>
            <button
              onClick={handleRun}
              disabled={isSimulating}
              className="flex-1 flex items-center justify-center gap-1.5 px-4 py-2 bg-black hover:bg-zinc-800 disabled:opacity-50 text-white rounded-sm text-xs font-mono font-bold uppercase tracking-wider transition"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              {isSimulating ? "Recalculating network constraints..." : "Execute Simulation Analysis"}
            </button>
          </div>
        </div>

        {/* Right Column: Information memo on constraints */}
        <div className="bg-[#0F172A] text-white p-6 border border-zinc-800 rounded-sm flex flex-col justify-between">
          <div>
            <h3 className="text-[10px] font-bold uppercase tracking-widest text-blue-400 font-mono">Simulation Science</h3>
            <h2 className="text-base font-bold uppercase tracking-wider mt-1.5">Sovereign Asset Modeler</h2>
            <p className="text-[11px] text-gray-300 leading-relaxed mt-4 font-mono uppercase tracking-tight">
              Our micro-scenario solver runs mathematical propagation. Constructing a runway or terminal 
              apron drops local terminal utilization tension, avoiding gate delays and increasing the 
              associated infrastructure valuation. 
            </p>
            <p className="text-[11px] text-gray-300 leading-relaxed mt-3 font-mono uppercase tracking-tight">
              Conversely, high fuel rates surcharge route overheads, depressing net cash yield returns on thin regional 
              routes.
            </p>
          </div>

          <div className="border-t border-zinc-800 pt-5 mt-6 text-[10px] font-mono uppercase tracking-wider text-gray-400 space-y-2">
            <div className="flex justify-between">
              <span>Simulation state:</span>
              <span className="text-emerald-400 font-bold">Ready</span>
            </div>
            <div className="flex justify-between">
              <span>Calculated constraints:</span>
              <span className="text-white font-bold">14 Nodes</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
