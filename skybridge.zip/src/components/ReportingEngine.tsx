/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { FileText, Download, Printer, Award, AlertTriangle } from "lucide-react";

export default function ReportingEngine() {
  const [reportType, setReportType] = useState<"executive" | "comparison">("executive");
  const [scopeFilter, setScopeFilter] = useState("System-Wide Airports");
  const [report, setReport] = useState<{ filename: string; content: string; generatedAt: string } | null>(null);
  const [isCompiling, setIsCompiling] = useState(false);

  const handleGenerate = () => {
    setIsCompiling(true);
    fetch("/api/reports/generate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reportType, scope: scopeFilter }),
    })
      .then((res) => res.json())
      .then((data) => {
        setReport(data);
        setIsCompiling(false);
      })
      .catch((err) => {
        console.error(err);
        setIsCompiling(false);
      });
  };

  const handleDownload = () => {
    if (!report) return;
    const blob = new Blob([report.content], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.setAttribute("download", report.filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div id="reporting-engine-container" className="space-y-6">
      <div className="border-b border-[#E5E7EB] pb-4">
        <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">National Infrastructure Reporting</h1>
        <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Sovereign briefing compiler for generating Investment Papers and Executive Memorandums</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Briefing selection panel */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] border-b border-gray-100 pb-2">Compile Specifications</h2>

          <div className="space-y-3.5 text-xs font-mono">
            <div>
              <label className="block text-gray-400 font-bold uppercase tracking-wider text-[9px] mb-1">Briefing Category</label>
              <select
                value={reportType}
                onChange={(e: any) => setReportType(e.target.value)}
                className="w-full text-xs bg-white border border-[#E5E7EB] rounded-sm p-2 focus:outline-none uppercase tracking-wide font-semibold"
              >
                <option value="executive">Executive Committee Paper</option>
                <option value="comparison">Comparative Performance Ledger</option>
              </select>
            </div>

            <div>
              <label className="block text-gray-400 font-bold uppercase tracking-wider text-[9px] mb-1">Analytical Scope Filter</label>
              <input
                type="text"
                value={scopeFilter}
                onChange={(e) => setScopeFilter(e.target.value)}
                placeholder="e.g. SYSTEM-WIDE, RONALDSWAY"
                className="w-full text-xs bg-white border border-[#E5E7EB] rounded-sm p-2 focus:outline-none uppercase tracking-wider font-semibold"
              />
            </div>

            <button
              onClick={handleGenerate}
              disabled={isCompiling}
              className="w-full mt-4 flex items-center justify-center gap-2 py-2 px-4 bg-black hover:bg-zinc-800 disabled:opacity-50 text-white rounded-sm text-xs font-mono font-bold uppercase tracking-wider transition"
            >
              <FileText className="w-3.5 h-3.5" />
              {isCompiling ? "Compiling briefing data..." : "Compile Committee Paper"}
            </button>
          </div>
        </div>

        {/* Right 2 Columns: Output Briefing Memorandum */}
        <div className="lg:col-span-2 space-y-4">
          {report ? (
            <div className="bg-white border border-[#E5E7EB] rounded-sm overflow-hidden flex flex-col justify-between">
              {/* Header */}
              <div className="px-5 py-3 bg-gray-50 border-b border-gray-200 flex justify-between items-center text-[10px] font-mono uppercase tracking-wider">
                <span className="text-gray-500 font-semibold">Output: {report.filename}</span>
                <div className="flex gap-2">
                  <button
                    onClick={handleDownload}
                    className="p-1.5 hover:bg-white border border-transparent hover:border-gray-200 text-gray-600 hover:text-blue-600 rounded-sm transition"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Document Sheet */}
              <div className="p-6 bg-gray-50/50 text-[#0F172A] font-mono text-xs whitespace-pre-wrap leading-relaxed h-[360px] overflow-y-auto text-left border-b border-gray-100">
                {report.content}
              </div>

              {/* Actions Footer */}
              <div className="px-5 py-3.5 bg-gray-50 flex justify-between items-center text-[10px] font-mono uppercase tracking-widest">
                <span className="text-gray-400 font-bold">Compiled at: {report.generatedAt}</span>
                <button
                  onClick={handleDownload}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded-sm font-bold flex items-center gap-1 transition"
                >
                  <Download className="w-3.5 h-3.5" /> Save Memorandum
                </button>
              </div>
            </div>
          ) : (
            <div className="bg-gray-50 border border-dashed border-gray-200 p-12 text-center h-full flex flex-col justify-center items-center rounded-sm">
              <FileText className="w-8 h-8 text-gray-300 mb-2" />
              <p className="text-gray-400 text-[10px] font-mono uppercase tracking-widest max-w-xs leading-normal">Select specifications on the left to compile sovereign-grade papers.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
