/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { ConnectivityScore } from "../types";
import { Map, Info, AlertTriangle, CheckCircle, Activity } from "lucide-react";

interface Props {
  connectivityScores: ConnectivityScore[];
}

export default function ConnectivityIndex({ connectivityScores }: Props) {
  const [selectedRegion, setSelectedRegion] = useState<string>("Isle of Man");

  const currentScore = connectivityScores.find((c) => c.region === selectedRegion) || connectivityScores[0];

  // Identify vulnerable regions (overall index < 50)
  const vulnerableRegions = connectivityScores.filter((c) => c.overallIndex < 50);

  return (
    <div id="connectivity-index-container" className="space-y-6">
      <div className="border-b border-[#E5E7EB] pb-4">
        <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">National Connectivity Index (NCI)</h1>
        <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Multi-modal accessibility index measuring regional flight, rail, road, and ferry linkages</p>
      </div>

      {/* Vulnerability Warnings */}
      {vulnerableRegions.length > 0 && (
        <div className="bg-red-50 border-l-2 border-red-500 p-4 rounded-sm">
          <div className="flex">
            <div className="flex-shrink-0">
              <AlertTriangle className="h-4 w-4 text-red-500" />
            </div>
            <div className="ml-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-red-800">Critical Connectivity Gaps Identified</h3>
              <p className="text-[10px] text-red-700 mt-1 uppercase tracking-tight font-mono">
                The following regions demonstrate high structural isolation (NCI &lt; 50) and are highly dependent on aviation and sea channels for civic logistics:
              </p>
              <div className="mt-2 text-[10px] font-bold font-mono text-red-800 flex flex-wrap gap-4 uppercase">
                {vulnerableRegions.map((r) => (
                  <span key={r.region} className="bg-red-100 border border-red-200 px-2 py-0.5 rounded-sm">
                    {r.region} (NCI: {r.overallIndex})
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Main Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: List of regions with index bars */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] border-b border-gray-100 pb-2">Regional Heat Ledger</h2>
          
          <div className="space-y-2 overflow-y-auto max-h-[400px] pr-2">
            {connectivityScores.map((score) => {
              const heatColor = 
                score.overallIndex >= 80 ? "text-emerald-700 bg-emerald-50 border-emerald-100" :
                score.overallIndex >= 60 ? "text-blue-700 bg-blue-50 border-blue-100" :
                "text-red-700 bg-red-50 border-red-100";

              return (
                <div
                  key={score.region}
                  onClick={() => setSelectedRegion(score.region)}
                  className={`p-2.5 rounded-sm border cursor-pointer transition flex items-center justify-between ${
                    selectedRegion === score.region
                      ? "bg-black text-white border-black"
                      : "bg-gray-50 hover:bg-gray-100 text-gray-700 border-gray-100"
                  }`}
                >
                  <span className="text-[11px] font-bold uppercase tracking-wider">{score.region}</span>
                  <span className={`text-[9px] font-mono font-bold px-2 py-0.5 rounded-sm border ${
                    selectedRegion === score.region ? "text-white bg-zinc-800 border-zinc-700" : heatColor
                  }`}>
                    NCI: {score.overallIndex}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Middle: Custom Visual Geographic Heatmap (SVG) */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm flex flex-col justify-between">
          <div>
            <h2 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] mb-1">UK Heatmap Representative</h2>
            <p className="text-[10px] text-gray-400 uppercase tracking-tight font-mono">Green = High integration, Blue/Yellow = Medium, Red = Isolated</p>
          </div>

          <div className="relative h-64 w-full flex items-center justify-center bg-black rounded-sm border border-black p-2 my-4">
            {/* Conceptual custom heat map */}
            <svg viewBox="0 0 200 250" className="w-full h-full max-w-xs font-mono">
              {/* Concept land masses representing regions with Heat fills */}
              {/* Highlands */}
              <circle cx="95" cy="50" r="30" fill="#f87171" opacity="0.3" />
              {/* Central Scotland */}
              <circle cx="105" cy="90" r="22" fill="#34d399" opacity="0.3" />
              {/* North East */}
              <circle cx="130" cy="115" r="15" fill="#60a5fa" opacity="0.3" />
              {/* Yorkshire */}
              <circle cx="125" cy="140" r="18" fill="#60a5fa" opacity="0.3" />
              {/* North West */}
              <circle cx="110" cy="140" r="18" fill="#34d399" opacity="0.3" />
              {/* Midlands */}
              <circle cx="115" cy="170" r="18" fill="#34d399" opacity="0.3" />
              {/* Wales */}
              <circle cx="90" cy="180" r="15" fill="#fcd34d" opacity="0.3" />
              {/* London & SE */}
              <circle cx="135" cy="195" r="25" fill="#10b981" opacity="0.4" />
              {/* Isle of Man */}
              <circle cx="85" cy="135" r="10" fill="#f87171" opacity="0.5" />

              {/* Text labels for highlights */}
              <text x="85" y="137" fill="#ffffff" fontSize="6" fontWeight="bold" textAnchor="middle">IOM</text>
              <text x="95" y="52" fill="#ffffff" fontSize="6" fontWeight="bold" textAnchor="middle">HIGHLANDS</text>
              <text x="135" y="197" fill="#ffffff" fontSize="6" fontWeight="bold" textAnchor="middle">LONDON</text>
            </svg>
          </div>

          <p className="text-[10px] text-gray-400 text-center font-mono uppercase tracking-tight leading-relaxed">
            Isle of Man (IOM) and Highlands display critical isolation. Protecting local airport gateways is structurally mandatory for civil cohesion.
          </p>
        </div>

        {/* Right Column: Multi-modal transport breakdown */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] border-b border-gray-100 pb-2">Multi-Modal Ledger</h2>
          <p className="text-[10px] font-bold text-[#0F172A] uppercase tracking-wider font-mono">{currentScore.region} Integration Details</p>

          <div className="space-y-4">
            {/* Index 1 */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono uppercase">
                <span className="text-gray-400">Domestic Flight Corridors</span>
                <span className="font-bold text-gray-700">{currentScore.domesticFlightsScore}/100</span>
              </div>
              <div className="w-full bg-gray-100 h-1.5 rounded-sm overflow-hidden">
                <div className="bg-blue-600 h-full rounded-sm" style={{ width: `${currentScore.domesticFlightsScore}%` }}></div>
              </div>
            </div>

            {/* Index 2 */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono uppercase">
                <span className="text-gray-400">Rail Network Connectivity</span>
                <span className="font-bold text-gray-700">{currentScore.railConnectivityScore}/100</span>
              </div>
              <div className="w-full bg-gray-100 h-1.5 rounded-sm overflow-hidden">
                <div className="bg-emerald-600 h-full rounded-sm" style={{ width: `${currentScore.railConnectivityScore}%` }}></div>
              </div>
            </div>

            {/* Index 3 */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono uppercase">
                <span className="text-gray-400">Motorway / Road Access</span>
                <span className="font-bold text-gray-700">{currentScore.motorwayAccessScore}/100</span>
              </div>
              <div className="w-full bg-gray-100 h-1.5 rounded-sm overflow-hidden">
                <div className="bg-zinc-700 h-full rounded-sm" style={{ width: `${currentScore.motorwayAccessScore}%` }}></div>
              </div>
            </div>

            {/* Index 4 */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono uppercase">
                <span className="text-gray-400">Ferry/Marine Lifelines</span>
                <span className="font-bold text-gray-700">{currentScore.ferryAccessScore}/100</span>
              </div>
              <div className="w-full bg-gray-100 h-1.5 rounded-sm overflow-hidden">
                <div className="bg-amber-500 h-full rounded-sm" style={{ width: `${currentScore.ferryAccessScore}%` }}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
