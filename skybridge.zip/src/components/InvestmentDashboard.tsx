/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Airport } from "../types";
import { Award, ArrowUpRight, TrendingUp, Sparkles, Building2 } from "lucide-react";

interface Props {
  airports: Airport[];
}

export default function InvestmentDashboard({ airports }: Props) {
  // We allow the user to tweak some capital parameters live
  const [minUtilisationThreshold, setMinUtilisationThreshold] = useState(60); // only focus on airports above 60% utilisation
  const [commercialYieldWeight, setCommercialYieldWeight] = useState(30); // in percent weight

  // Let's dynamically map each airport to have Investment evaluations
  const evaluatedAirports = airports.map((apt) => {
    // Determine CapEx requirements based on current utilisation
    // High utilisation needs terminal/runway CapEx
    let capexReq = 15.0; // Base £M
    if (apt.utilisation > 0.85) {
      capexReq = 120.0;
    } else if (apt.utilisation > 0.70) {
      capexReq = 45.0;
    }

    // Commercial income ratio mapping (derived from passengers and strategic weight)
    const commercialIncome = Math.round((apt.annual_passengers * 0.005) + (apt.estimated_asset_value * 0.02)); // in £M
    const expectedROI = capexReq > 0 ? (commercialIncome / capexReq) * 100 : 0;

    // Strategic weights
    const importanceWeight = 
      apt.strategic_importance === "Sovereign Hub" ? 30 :
      apt.strategic_importance === "Regional Critical" ? 20 : 10;

    const expansionWeight = 
      apt.expansion_potential === "High" ? 20 :
      apt.expansion_potential === "Medium" ? 10 : 5;

    // Investment score computation: Weighted aggregation
    const utilisationScore = apt.utilisation * 35; // max 35
    const roiScore = Math.min(25, expectedROI * 1.5); // max 25
    
    const investmentScore = utilisationScore + roiScore + importanceWeight + expansionWeight;

    return {
      ...apt,
      capexReq,
      commercialIncome,
      expectedROI: parseFloat(expectedROI.toFixed(1)),
      investmentScore: parseFloat(investmentScore.toFixed(1)),
    };
  });

  // Sort by investment score descending (producing ranked investment list)
  const rankedList = [...evaluatedAirports].sort((a, b) => b.investmentScore - a.investmentScore);

  return (
    <div id="investment-dashboard-container" className="space-y-6">
      <div className="border-b border-[#E5E7EB] pb-4">
        <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">Airport Investment & Prioritisation</h1>
        <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Capital allocation scoring engine for evaluating long-term infrastructure returns (ROI)</p>
      </div>

      {/* Control sliders */}
      <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 font-mono">
            Min Utilisation Filter: {minUtilisationThreshold}%
          </label>
          <input
            type="range"
            min="20"
            max="90"
            value={minUtilisationThreshold}
            onChange={(e) => setMinUtilisationThreshold(Number(e.target.value))}
            className="w-full h-1 bg-gray-200 rounded-sm appearance-none cursor-pointer accent-blue-600"
          />
          <p className="text-[9px] text-gray-400 mt-1 font-mono uppercase tracking-tight">Hides assets below specified terminal utilization from top list</p>
        </div>

        <div>
          <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2 font-mono">
            ROI Target Stress Factor: {commercialYieldWeight}%
          </label>
          <input
            type="range"
            min="10"
            max="60"
            value={commercialYieldWeight}
            onChange={(e) => setCommercialYieldWeight(Number(e.target.value))}
            className="w-full h-1 bg-gray-200 rounded-sm appearance-none cursor-pointer accent-blue-600"
          />
          <p className="text-[9px] text-gray-400 mt-1 font-mono uppercase tracking-tight">Modulates simulated commercial yield weights under volatile trends</p>
        </div>
      </div>

      {/* Top Ranked priorities highlight card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {rankedList.slice(0, 3).map((apt, index) => (
          <div key={apt.code} className="bg-black text-white rounded-sm p-5 border border-black flex flex-col justify-between relative overflow-hidden">
            {/* Absolute badge */}
            <div className="absolute top-4 right-4 bg-blue-600 font-bold font-mono text-[9px] px-2 py-0.5 rounded-sm uppercase tracking-wider">
              RANK #{index + 1}
            </div>

            <div>
              <span className="text-[9px] text-blue-400 uppercase font-bold tracking-widest block font-mono">Priority Target</span>
              <h2 className="text-base font-bold tracking-tight mt-1">{apt.name}</h2>
              <p className="text-[10px] text-gray-400 font-mono mt-1 uppercase tracking-wider">{apt.code} • {apt.strategic_importance}</p>
            </div>

            <div className="mt-6 grid grid-cols-2 gap-4 border-t border-zinc-800 pt-4 text-xs font-mono">
              <div>
                <span className="text-zinc-500 block text-[9px] uppercase">CapEx Required</span>
                <span className="font-bold text-zinc-100">£{apt.capexReq.toFixed(1)}M</span>
              </div>
              <div>
                <span className="text-zinc-500 block text-[9px] uppercase">Expected ROI</span>
                <span className="font-bold text-emerald-400">{apt.expectedROI}%</span>
              </div>
            </div>

            <div className="mt-5 flex items-center justify-between border-t border-zinc-900 pt-3">
              <span className="text-[10px] text-gray-400 font-mono uppercase tracking-wider">Priority Score:</span>
              <span className="text-xs font-bold font-mono text-blue-300">{apt.investmentScore}/100</span>
            </div>
          </div>
        ))}
      </div>

      {/* Full Priority Ledger Table */}
      <div className="bg-white border border-[#E5E7EB] rounded-sm overflow-hidden">
        <div className="px-5 py-4 border-b border-[#E5E7EB] flex items-center justify-between">
          <h3 className="font-bold text-[#0F172A] text-xs uppercase tracking-widest font-mono">Complete Investment Prioritisation Table</h3>
          <span className="text-[10px] text-gray-400 font-mono uppercase tracking-wider">{rankedList.length} Airports Ranked</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-gray-600 font-mono">
            <thead className="bg-gray-50 text-[10px] font-bold uppercase text-gray-400 border-b border-[#E5E7EB]">
              <tr>
                <th className="px-6 py-3.5">Airport Code</th>
                <th className="px-6 py-3.5 font-sans">Name / Importance</th>
                <th className="px-6 py-3.5 text-center">Utilisation</th>
                <th className="px-6 py-3.5 text-right">Est. CapEx</th>
                <th className="px-6 py-3.5 text-right">Commercial Income</th>
                <th className="px-6 py-3.5 text-right">Expected ROI</th>
                <th className="px-6 py-3.5 text-right">Priority Score</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#E5E7EB]">
              {rankedList
                .filter((a) => a.utilisation * 100 >= minUtilisationThreshold)
                .map((apt) => (
                  <tr key={apt.code} className="hover:bg-gray-50/80 transition">
                    <td className="px-6 py-4">
                      <span className="font-bold text-[#0F172A] bg-gray-100 px-2 py-0.5 rounded-sm text-[10px] border border-gray-200">
                        {apt.code}
                      </span>
                    </td>
                    <td className="px-6 py-4 font-sans">
                      <div className="font-bold text-[#0F172A]">{apt.name}</div>
                      <div className="text-[10px] text-gray-400 uppercase tracking-wider mt-0.5">{apt.strategic_importance}</div>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className={`text-[10px] font-bold px-2 py-0.5 rounded-sm border ${
                        apt.utilisation > 0.80 ? "text-amber-800 bg-amber-50 border-amber-100" : "text-emerald-800 bg-emerald-50 border-emerald-100"
                      }`}>
                        {(apt.utilisation * 100).toFixed(0)}%
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right font-bold text-gray-700">£{apt.capexReq.toFixed(1)}M</td>
                    <td className="px-6 py-4 text-right font-bold text-gray-700">£{apt.commercialIncome.toFixed(1)}M</td>
                    <td className="px-6 py-4 text-right font-bold text-emerald-600">{apt.expectedROI}%</td>
                    <td className="px-6 py-4 text-right font-bold text-blue-600">{apt.investmentScore}</td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
