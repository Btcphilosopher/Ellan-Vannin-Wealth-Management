/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Route } from "../types";
import { DollarSign, Percent, BarChart3, Settings2 } from "lucide-react";

interface Props {
  routes: Route[];
}

export default function RouteEconomics({ routes }: Props) {
  const [selectedRouteId, setSelectedRouteId] = useState(routes[0]?.id || "");
  
  // Simulation Inputs
  const [passengerDemand, setPassengerDemand] = useState(150000);
  const [averageFare, setAverageFare] = useState(85);
  const [operatingCostHour, setOperatingCostHour] = useState(3200);
  const [airportCharges, setAirportCharges] = useState(15); // per passenger
  const [aircraftUtilisation, setAircraftUtilisation] = useState(8); // hours per day

  // Synchronise simulation inputs when user selects a different route
  const handleRouteChange = (id: string) => {
    setSelectedRouteId(id);
    const rt = routes.find((r) => r.id === id);
    if (rt) {
      setPassengerDemand(rt.passenger_demand_annual);
      setAverageFare(rt.average_fare);
      setOperatingCostHour(rt.operating_cost_hour);
      // Derive approximate airport charges
      setAirportCharges(12);
    }
  };

  const currentRoute = routes.find((r) => r.id === selectedRouteId) || routes[0];

  // Mathematical Economics Calculations
  const blockTimeHours = currentRoute ? currentRoute.block_time_mins / 60 : 1.0;
  
  // Weekly and Annual operations
  const weeklyFrequency = currentRoute ? currentRoute.frequency_weekly : 14;
  const annualFlights = weeklyFrequency * 52 * 2; // out & return
  
  // Financial outputs
  const annualPassengersCarried = Math.min(passengerDemand, annualFlights * 150); // assuming a 150-seat aircraft capacity
  const estimatedRevenue = annualPassengersCarried * averageFare;
  const operatingCostPerFlight = blockTimeHours * operatingCostHour;
  const annualOperatingCost = annualFlights * operatingCostPerFlight;
  const annualAirportCharges = annualPassengersCarried * airportCharges;
  const totalCost = annualOperatingCost + annualAirportCharges;
  const profit = estimatedRevenue - totalCost;
  const operatingMargin = estimatedRevenue > 0 ? (profit / estimatedRevenue) * 100 : 0;

  // Break Even Load Factor
  // Cost per flight / (Seats per flight * Fare - Seats per flight * Charges)
  const seatsPerFlight = 150;
  const flightRevenueBreakeven = operatingCostPerFlight + (seatsPerFlight * airportCharges);
  const breakEvenLoadFactor = averageFare > 0 
    ? Math.min(100, (operatingCostPerFlight / (seatsPerFlight * (averageFare - airportCharges))) * 100) 
    : 100;

  // Sensitivity Analysis
  // Create 5 fare points relative to current base to plot margin impact
  const farePoints = [0.8, 0.9, 1.0, 1.1, 1.2]; // -20%, -10%, base, +10%, +20%
  const sensitivityData = farePoints.map((factor) => {
    const fare = averageFare * factor;
    const rev = annualPassengersCarried * fare;
    const sensProfit = rev - totalCost;
    const margin = rev > 0 ? (sensProfit / rev) * 100 : 0;
    return {
      fare: Math.round(fare),
      margin: parseFloat(margin.toFixed(1)),
    };
  });

  return (
    <div id="route-economics-container" className="space-y-6">
      <div className="border-b border-[#E5E7EB] pb-4">
        <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">Route Economics Dashboard</h1>
        <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Strategic ledger for modeling UK regional route economics and yields</p>
      </div>

      {/* Corridor Selector */}
      <div className="bg-white p-4 border border-[#E5E7EB] rounded-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <Settings2 className="w-4 h-4 text-blue-600" />
          <span className="text-[11px] font-bold uppercase tracking-wider text-gray-500">Select Corridor:</span>
          <select
            value={selectedRouteId}
            onChange={(e) => handleRouteChange(e.target.value)}
            className="text-xs bg-white border border-[#E5E7EB] rounded-sm px-2.5 py-1 font-mono font-bold text-blue-600 focus:outline-none"
          >
            {routes.map((r) => (
              <option key={r.id} value={r.id}>
                {r.origin} ➔ {r.destination} ({r.distance_km} km)
              </option>
            ))}
          </select>
        </div>
        <span className="text-[10px] text-gray-400 font-mono uppercase tracking-wider">Sector: {currentRoute?.block_time_mins} mins block-time</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Parameter configuration inputs */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] border-b border-gray-100 pb-2">Assumption Panel</h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Annual Passenger Demand Potential</label>
              <input
                type="number"
                value={passengerDemand}
                onChange={(e) => setPassengerDemand(Number(e.target.value))}
                className="w-full text-xs font-mono border border-[#E5E7EB] rounded-sm p-1.5 focus:outline-none focus:border-blue-600"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Average Sector Fare (£)</label>
              <input
                type="number"
                value={averageFare}
                onChange={(e) => setAverageFare(Number(e.target.value))}
                className="w-full text-xs font-mono border border-[#E5E7EB] rounded-sm p-1.5 focus:outline-none focus:border-blue-600"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Operating Cost per Block Hour (£)</label>
              <input
                type="number"
                value={operatingCostHour}
                onChange={(e) => setOperatingCostHour(Number(e.target.value))}
                className="w-full text-xs font-mono border border-[#E5E7EB] rounded-sm p-1.5 focus:outline-none focus:border-blue-600"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Airport Charges per Passenger (£)</label>
              <input
                type="number"
                value={airportCharges}
                onChange={(e) => setAirportCharges(Number(e.target.value))}
                className="w-full text-xs font-mono border border-[#E5E7EB] rounded-sm p-1.5 focus:outline-none focus:border-blue-600"
              />
            </div>
            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Aircraft Daily Utilisation Target (Hours)</label>
              <input
                type="number"
                value={aircraftUtilisation}
                onChange={(e) => setAircraftUtilisation(Number(e.target.value))}
                className="w-full text-xs font-mono border border-[#E5E7EB] rounded-sm p-1.5 focus:outline-none focus:border-blue-600"
              />
            </div>
          </div>
        </div>

        {/* Right 2 Columns: Financial ledger details & SVG Sensitivity */}
        <div className="lg:col-span-2 space-y-6">
          {/* Top row: Outputs metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white border border-[#E5E7EB] rounded-sm p-4 flex flex-col justify-between">
              <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Projected Annual Revenue</span>
              <div className="mt-3">
                <div className="text-xl font-bold font-mono text-[#0F172A] flex items-center">
                  <DollarSign className="w-4 h-4 text-gray-400 shrink-0" />
                  {(estimatedRevenue / 1000).toFixed(0)}k
                </div>
                <p className="text-[10px] text-gray-400 mt-1 font-mono">Seats: {annualPassengersCarried.toLocaleString()}</p>
              </div>
            </div>

            <div className="bg-white border border-[#E5E7EB] rounded-sm p-4 flex flex-col justify-between">
              <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Operating Margin</span>
              <div className="mt-3">
                <div className={`text-xl font-bold font-mono flex items-center ${
                  operatingMargin >= 10 ? "text-emerald-700" : operatingMargin > 0 ? "text-slate-700" : "text-red-700"
                }`}>
                  <Percent className="w-4 h-4 shrink-0 opacity-70" />
                  {operatingMargin.toFixed(1)}%
                </div>
                <p className="text-[10px] text-gray-400 mt-1 font-mono">Profit: £{(profit / 1000).toFixed(0)}k</p>
              </div>
            </div>

            <div className="bg-white border border-[#E5E7EB] rounded-sm p-4 flex flex-col justify-between">
              <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400">Break-Even Load Factor</span>
              <div className="mt-3">
                <div className="text-xl font-bold font-mono text-blue-600 flex items-center">
                  <Percent className="w-4 h-4 shrink-0 opacity-70" />
                  {breakEvenLoadFactor.toFixed(1)}%
                </div>
                <p className="text-[10px] text-gray-400 mt-1 font-mono">Req: {Math.round(seatsPerFlight * (breakEvenLoadFactor / 100))} pax/leg</p>
              </div>
            </div>
          </div>

          {/* Bottom section: Sensitivity SVG Chart */}
          <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm">
            <h3 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] mb-4 flex items-center gap-1.5 border-b border-gray-100 pb-2">
              <BarChart3 className="w-3.5 h-3.5 text-blue-600" /> Fare Yield Sensitivity Sweep
            </h3>
            
            <div className="relative h-60 w-full flex items-center justify-center">
              {/* Custom SVG line graph for sensitivity plot */}
              <svg className="w-full h-full max-w-lg font-mono" viewBox="0 0 400 200">
                {/* Axes and gridlines */}
                <line x1="40" y1="160" x2="380" y2="160" stroke="#E5E7EB" strokeWidth="1" />
                <line x1="40" y1="20" x2="40" y2="160" stroke="#E5E7EB" strokeWidth="1" />
                <line x1="40" y1="90" x2="380" y2="90" stroke="#E5E7EB" strokeDasharray="2 2" />

                {/* Draw sensitivity line */}
                {(() => {
                  const points = sensitivityData.map((d, idx) => {
                    const x = 50 + idx * 75;
                    // Margin ranges roughly from -50% to +50%
                    // Map -50 margin to y=150, +50 margin to y=30
                    const y = 90 - (d.margin * 1.2); 
                    return { x, y, label: `${d.margin}%`, fare: `£${d.fare}` };
                  });

                  const dPath = points.map((p, idx) => `${idx === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");

                  return (
                    <g>
                      {/* Line */}
                      <path d={dPath} fill="none" stroke="#2563eb" strokeWidth="2" strokeLinecap="square" />
                      
                      {/* Data Dots and values */}
                      {points.map((p, idx) => (
                        <g key={idx}>
                          <circle cx={p.x} cy={p.y} r="4" fill="#2563eb" stroke="#ffffff" strokeWidth="1" />
                          <text x={p.x} y={p.y - 10} textAnchor="middle" fontSize="9" fontWeight="bold" fill="#0F172A">
                            {p.label}
                          </text>
                          <text x={p.x} y="175" textAnchor="middle" fontSize="9" fill="#94a3b8">
                            {p.fare}
                          </text>
                        </g>
                      ))}
                    </g>
                  );
                })()}

                {/* Chart Label */}
                <text x="200" y="195" textAnchor="middle" fontSize="9" fill="#94a3b8" fontWeight="bold" className="uppercase tracking-widest">
                  Sovereign Yield (Ticket Fare Curve)
                </text>
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
