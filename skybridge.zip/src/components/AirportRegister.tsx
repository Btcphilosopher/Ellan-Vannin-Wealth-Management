/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Airport } from "../types";
import { Search, Plus, Filter, Trash2, Edit3, X, MapPin, Gauge } from "lucide-react";

interface Props {
  airports: Airport[];
  onUpsert: (airport: Airport) => void;
  onDelete: (code: string) => void;
}

export default function AirportRegister({ airports, onUpsert, onDelete }: Props) {
  const [searchTerm, setSearchTerm] = useState("");
  const [regionFilter, setRegionFilter] = useState("All");
  const [importanceFilter, setImportanceFilter] = useState("All");

  // State for Add/Edit Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAirport, setEditingAirport] = useState<Airport | null>(null);

  // Form Fields State
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [region, setRegion] = useState("");
  const [runwayLength, setRunwayLength] = useState(2000);
  const [terminalCapacity, setTerminalCapacity] = useState(5000000);
  const [annualPassengers, setAnnualPassengers] = useState(3000000);
  const [annualMovements, setAnnualMovements] = useState(30000);
  const [assetValue, setAssetValue] = useState(250);
  const [cargo, setCargo] = useState(1000);
  const [ownership, setOwnership] = useState("Private");
  const [expansion, setExpansion] = useState<"Low" | "Medium" | "High">("Medium");
  const [strategic, setStrategic] = useState<"Sovereign Hub" | "Regional Critical" | "Local Connective">("Regional Critical");

  const openAddModal = () => {
    setEditingAirport(null);
    setCode("");
    setName("");
    setRegion("");
    setRunwayLength(2000);
    setTerminalCapacity(5000000);
    setAnnualPassengers(3000000);
    setAnnualMovements(30000);
    setAssetValue(250);
    setCargo(1000);
    setOwnership("Private");
    setExpansion("Medium");
    setStrategic("Regional Critical");
    setIsModalOpen(true);
  };

  const openEditModal = (apt: Airport) => {
    setEditingAirport(apt);
    setCode(apt.code);
    setName(apt.name);
    setRegion(apt.region);
    setRunwayLength(apt.runway_length_m);
    setTerminalCapacity(apt.terminal_capacity);
    setAnnualPassengers(apt.annual_passengers);
    setAnnualMovements(apt.annual_movements);
    setAssetValue(apt.estimated_asset_value);
    setCargo(apt.cargo_throughput_tonnes);
    setOwnership(apt.ownership);
    setExpansion(apt.expansion_potential);
    setStrategic(apt.strategic_importance);
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!code || !name || !region) return;

    const utilisation = annualPassengers / terminalCapacity;

    const updatedAirport: Airport = {
      code: code.toUpperCase().trim(),
      name: name.trim(),
      region: region.trim(),
      runway_length_m: Number(runwayLength),
      terminal_capacity: Number(terminalCapacity),
      annual_passengers: Number(annualPassengers),
      annual_movements: Number(annualMovements),
      utilisation: parseFloat(utilisation.toFixed(2)),
      estimated_asset_value: Number(assetValue),
      cargo_throughput_tonnes: Number(cargo),
      ownership,
      expansion_potential: expansion,
      strategic_importance: strategic,
    };

    onUpsert(updatedAirport);
    setIsModalOpen(false);
  };

  // Filter Airports
  const filteredAirports = airports.filter((apt) => {
    const matchesSearch =
      apt.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      apt.code.toLowerCase().includes(searchTerm.toLowerCase()) ||
      apt.region.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesRegion = regionFilter === "All" || apt.region === regionFilter;
    const matchesImportance = importanceFilter === "All" || apt.strategic_importance === importanceFilter;

    return matchesSearch && matchesRegion && matchesImportance;
  });

  // Get Unique Regions for filters
  const uniqueRegions = Array.from(new Set(airports.map((a) => a.region)));

  return (
    <div id="airport-register-container" className="space-y-6">
      {/* Header action */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-[#E5E7EB] pb-5">
        <div>
          <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">National Airport Register</h1>
          <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Core registry of UK commercial airports and asset parameters</p>
        </div>
        <button
          onClick={openAddModal}
          className="bg-black hover:bg-gray-800 text-white px-3 py-1.5 rounded-sm text-xs font-semibold flex items-center justify-center gap-2 transition"
        >
          <Plus className="w-3.5 h-3.5" /> Add Airport
        </button>
      </div>

      {/* Filter and search panel */}
      <div className="bg-white p-4 border border-[#E5E7EB] rounded-sm flex flex-col md:flex-row gap-4">
        {/* Search */}
        <div className="relative flex-1">
          <Search className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search by code, name, or region..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-4 py-1.5 text-xs bg-white border border-[#E5E7EB] rounded-sm focus:outline-none focus:border-black transition"
          />
        </div>

        {/* Region Filter */}
        <div className="flex items-center gap-2">
          <Filter className="w-3.5 h-3.5 text-gray-400 shrink-0" />
          <select
            value={regionFilter}
            onChange={(e) => setRegionFilter(e.target.value)}
            className="text-xs bg-white border border-[#E5E7EB] rounded-sm px-3 py-1.5 focus:outline-none focus:border-black"
          >
            <option value="All">All Regions</option>
            {uniqueRegions.map((r) => (
              <option key={r} value={r}>
                {r}
              </option>
            ))}
          </select>
        </div>

        {/* Importance Filter */}
        <div className="flex items-center gap-2">
          <Gauge className="w-3.5 h-3.5 text-gray-400 shrink-0" />
          <select
            value={importanceFilter}
            onChange={(e) => setImportanceFilter(e.target.value)}
            className="text-xs bg-white border border-[#E5E7EB] rounded-sm px-3 py-1.5 focus:outline-none focus:border-black"
          >
            <option value="All">All Importance Levels</option>
            <option value="Sovereign Hub">Sovereign Hub</option>
            <option value="Regional Critical">Regional Critical</option>
            <option value="Local Connective">Local Connective</option>
          </select>
        </div>
      </div>

      {/* Grid List */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredAirports.map((apt) => {
          const isHighUtil = apt.utilisation > 0.85;
          const isLowUtil = apt.utilisation < 0.40;
          return (
            <div
              key={apt.code}
              className="bg-white border border-[#E5E7EB] rounded-sm flex flex-col justify-between overflow-hidden"
            >
              {/* Card top */}
              <div className="p-5">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-[11px] font-bold px-2 py-0.5 bg-black text-white rounded-sm tracking-wider font-mono">
                      {apt.code}
                    </span>
                    <div>
                      <h3 className="text-xs font-bold text-gray-800 line-clamp-1">{apt.name}</h3>
                      <p className="text-[10px] text-gray-400 flex items-center gap-1 mt-0.5">
                        <MapPin className="w-3 h-3 text-gray-400" />
                        {apt.region}
                      </p>
                    </div>
                  </div>
                  <span className={`text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-sm border ${
                    apt.strategic_importance === "Sovereign Hub"
                      ? "bg-purple-50 text-purple-700 border-purple-200"
                      : apt.strategic_importance === "Regional Critical"
                      ? "bg-blue-50 text-blue-700 border-blue-200"
                      : "bg-gray-50 text-gray-700 border-gray-200"
                  }`}>
                    {apt.strategic_importance}
                  </span>
                </div>

                {/* Utilisation gauge bar */}
                <div className="mt-5 space-y-1">
                  <div className="flex justify-between text-[10px] font-mono uppercase tracking-wider text-gray-500">
                    <span>Terminal Utilisation</span>
                    <span className={isHighUtil ? "text-amber-700" : isLowUtil ? "text-blue-600" : "text-black"}>
                      {(apt.utilisation * 100).toFixed(0)}%
                    </span>
                  </div>
                  <div className="w-full bg-gray-100 h-1 rounded-sm overflow-hidden">
                    <div
                      className={`h-full rounded-sm transition-all duration-300 ${
                        isHighUtil ? "bg-amber-500" : isLowUtil ? "bg-blue-500" : "bg-black"
                      }`}
                      style={{ width: `${Math.min(100, apt.utilisation * 100)}%` }}
                    ></div>
                  </div>
                </div>

                {/* Parameters */}
                <div className="grid grid-cols-2 gap-x-4 gap-y-3 mt-5 pt-4 border-t border-gray-100 text-[10px]">
                  <div>
                    <span className="text-gray-400 uppercase font-mono block">Annual Passengers</span>
                    <span className="font-semibold text-gray-800">{(apt.annual_passengers / 1000000).toFixed(2)}M</span>
                  </div>
                  <div>
                    <span className="text-gray-400 uppercase font-mono block">Aircraft Movements</span>
                    <span className="font-semibold text-gray-800">{apt.annual_movements.toLocaleString()}</span>
                  </div>
                  <div>
                    <span className="text-gray-400 uppercase font-mono block">Cargo Throughput</span>
                    <span className="font-semibold text-gray-800">{apt.cargo_throughput_tonnes.toLocaleString()} t</span>
                  </div>
                  <div>
                    <span className="text-gray-400 uppercase font-mono block">Runway Length</span>
                    <span className="font-semibold text-gray-800">{apt.runway_length_m}m</span>
                  </div>
                </div>
              </div>

              {/* Card Footer action controls */}
              <div className="px-5 py-3 bg-gray-50 border-t border-gray-100 flex justify-between items-center">
                <span className="text-[9px] font-bold tracking-wider text-gray-400 uppercase font-mono">
                  Asset Value: £{apt.estimated_asset_value}M
                </span>
                <div className="flex gap-1.5">
                  <button
                    onClick={() => openEditModal(apt)}
                    className="p-1 hover:bg-white border border-gray-200 text-gray-500 hover:text-black rounded-sm transition"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDelete(apt.code)}
                    className="p-1 hover:bg-white border border-gray-200 text-gray-500 hover:text-red-600 rounded-sm transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/30 backdrop-blur-xs flex items-center justify-center z-50 p-4 overflow-y-auto">
          <div className="bg-white rounded-sm border border-[#E5E7EB] shadow-lg w-full max-w-lg overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b border-[#E5E7EB] bg-[#F8F9FA]">
              <h2 className="text-xs font-bold uppercase tracking-wider text-black">
                {editingAirport ? `Edit Airport Record (${editingAirport.code})` : "Add Airport to Register"}
              </h2>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-black">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4 max-h-[70vh] overflow-y-auto">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Airport Code (3 Letters)</label>
                  <input
                    type="text"
                    required
                    maxLength={3}
                    disabled={!!editingAirport}
                    value={code}
                    onChange={(e) => setCode(e.target.value.toUpperCase())}
                    placeholder="LHR"
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs bg-white disabled:opacity-50 focus:outline-none focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Airport Name</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="London Heathrow"
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs focus:outline-none focus:border-black"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Region</label>
                  <input
                    type="text"
                    required
                    value={region}
                    onChange={(e) => setRegion(e.target.value)}
                    placeholder="Greater London"
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs focus:outline-none focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Strategic Importance</label>
                  <select
                    value={strategic}
                    onChange={(e: any) => setStrategic(e.target.value)}
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs focus:outline-none focus:border-black bg-white"
                  >
                    <option value="Sovereign Hub">Sovereign Hub</option>
                    <option value="Regional Critical">Regional Critical</option>
                    <option value="Local Connective">Local Connective</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Terminal Capacity (Passengers/Year)</label>
                  <input
                    type="number"
                    required
                    value={terminalCapacity}
                    onChange={(e) => setTerminalCapacity(Number(e.target.value))}
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs focus:outline-none focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Annual Passengers</label>
                  <input
                    type="number"
                    required
                    value={annualPassengers}
                    onChange={(e) => setAnnualPassengers(Number(e.target.value))}
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs focus:outline-none focus:border-black"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Runway Length (meters)</label>
                  <input
                    type="number"
                    required
                    value={runwayLength}
                    onChange={(e) => setRunwayLength(Number(e.target.value))}
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs focus:outline-none focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Annual Movements</label>
                  <input
                    type="number"
                    required
                    value={annualMovements}
                    onChange={(e) => setAnnualMovements(Number(e.target.value))}
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs focus:outline-none focus:border-black"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Cargo Throughput (tonnes)</label>
                  <input
                    type="number"
                    required
                    value={cargo}
                    onChange={(e) => setCargo(Number(e.target.value))}
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs focus:outline-none focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Estimated Asset Value (£ Millions)</label>
                  <input
                    type="number"
                    required
                    value={assetValue}
                    onChange={(e) => setAssetValue(Number(e.target.value))}
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs focus:outline-none focus:border-black"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Ownership Model</label>
                  <input
                    type="text"
                    required
                    value={ownership}
                    onChange={(e) => setOwnership(e.target.value)}
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs focus:outline-none focus:border-black"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Expansion Potential</label>
                  <select
                    value={expansion}
                    onChange={(e: any) => setExpansion(e.target.value)}
                    className="w-full border border-[#E5E7EB] rounded-sm px-3 py-1.5 text-xs focus:outline-none focus:border-black bg-white"
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>
              </div>

              <div className="flex justify-end gap-3 pt-4 border-t border-gray-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-3 py-1.5 border border-gray-200 rounded-sm text-xs text-gray-500 hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-3 py-1.5 bg-black hover:bg-gray-800 text-white rounded-sm text-xs font-semibold"
                >
                  Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
