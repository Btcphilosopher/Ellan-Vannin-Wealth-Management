/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { PortfolioAsset } from "../types";
import { TrendingUp, Award, Layers, DollarSign, Wallet } from "lucide-react";

interface Props {
  portfolio: PortfolioAsset[];
}

export default function PortfolioAnalytics({ portfolio }: Props) {
  const [selectedAssetCode, setSelectedAssetCode] = useState<string>("IOM");

  const totalCapital = portfolio.reduce((acc, curr) => acc + curr.capitalDeployed, 0);
  const totalValue = portfolio.reduce((acc, curr) => acc + curr.currentValue, 0);
  const portfolioIRR = portfolio.reduce((acc, curr) => acc + curr.expectedIRR * (curr.capitalDeployed / totalCapital), 0);

  const activeAsset = portfolio.find((a) => a.code === selectedAssetCode) || portfolio[0];

  return (
    <div id="portfolio-analytics-container" className="space-y-6">
      <div className="border-b border-[#E5E7EB] pb-4">
        <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">Portfolio Analytics</h1>
        <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Management Ledger for Ellan Vannin Wealth Management's regional aviation infrastructure holdings</p>
      </div>

      {/* Portfolio overview stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        <div className="bg-gray-50 border border-[#E5E7EB] rounded-sm p-5 flex flex-col justify-between">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Aviation Valuation Pool</span>
          <div className="mt-4">
            <div className="text-xl font-bold font-mono text-[#0F172A]">£{totalValue.toFixed(1)}M</div>
            <p className="text-[9px] font-mono text-gray-400 uppercase tracking-tight mt-1">Capital Stake: £{totalCapital.toFixed(1)}M</p>
          </div>
        </div>

        <div className="bg-gray-50 border border-[#E5E7EB] rounded-sm p-5 flex flex-col justify-between">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">System Yield (Expected IRR)</span>
          <div className="mt-4">
            <div className="text-xl font-bold font-mono text-emerald-600">{portfolioIRR.toFixed(2)}%</div>
            <p className="text-[9px] font-mono text-gray-400 uppercase tracking-tight mt-1">Weighted Capital Allocation</p>
          </div>
        </div>

        <div className="bg-gray-50 border border-[#E5E7EB] rounded-sm p-5 flex flex-col justify-between">
          <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Assets Under Management</span>
          <div className="mt-4">
            <div className="text-xl font-bold font-mono text-[#0F172A]">{portfolio.length} Holdings</div>
            <p className="text-[9px] font-mono text-blue-600 uppercase tracking-tight mt-1">IOM • CWL • EMA</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Holdings asset ledger breakdown and cashflows */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm lg:col-span-2 space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] border-b border-gray-100 pb-2 flex items-center gap-1.5">
            <Wallet className="w-4 h-4 text-blue-600" /> Active Infrastructure Stakes
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm text-gray-600 font-mono uppercase tracking-tight">
              <thead className="bg-gray-50 text-[10px] font-bold text-gray-400 border-b border-gray-200">
                <tr>
                  <th className="px-4 py-3 font-sans">Asset</th>
                  <th className="px-4 py-3 text-right">Capital Stake</th>
                  <th className="px-4 py-3 text-right">Equity Share</th>
                  <th className="px-4 py-3 text-right">Asset Value</th>
                  <th className="px-4 py-3 text-right">Target IRR</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-[11px] font-semibold">
                {portfolio.map((asset) => (
                  <tr
                    key={asset.code}
                    onClick={() => setSelectedAssetCode(asset.code)}
                    className={`cursor-pointer transition hover:bg-gray-50/80 ${
                      selectedAssetCode === asset.code ? "bg-blue-50/50" : ""
                    }`}
                  >
                    <td className="px-4 py-3 font-sans font-bold text-[#0F172A]">{asset.name}</td>
                    <td className="px-4 py-3 text-right text-gray-700">£{asset.capitalDeployed.toFixed(1)}M</td>
                    <td className="px-4 py-3 text-right text-gray-700">{asset.equityOwnership}%</td>
                    <td className="px-4 py-3 text-right font-bold text-blue-600">£{asset.currentValue.toFixed(1)}M</td>
                    <td className="px-4 py-3 text-right font-bold text-emerald-600">{asset.expectedIRR}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Right Column: 5-Year projected cash flows for active asset */}
        {activeAsset && (
          <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm flex flex-col justify-between">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] border-b border-gray-100 pb-2">
                Projected 5-Year Cash Flow
              </h3>
              <p className="text-[10px] text-gray-400 font-mono uppercase tracking-tight mt-1">Stake: {activeAsset.name} (IRR: {activeAsset.expectedIRR}%)</p>
            </div>

            {/* Custom SVG bar plot for cash flows */}
            <div className="relative h-44 w-full flex items-center justify-center my-4 bg-gray-50 rounded-sm border border-gray-100">
              <svg className="w-full h-full p-2 font-mono" viewBox="0 0 200 100">
                {/* Baseline grid */}
                <line x1="20" y1="85" x2="190" y2="85" stroke="#E5E7EB" strokeWidth="1" />
                
                {activeAsset.cashFlowAnnual.map((flow, idx) => {
                  const barWidth = 18;
                  const spacing = 12;
                  const x = 30 + idx * (barWidth + spacing);
                  // Scale flow values up to max height (approx £18M)
                  const height = (flow / 18) * 70;
                  const y = 85 - height;

                  return (
                    <g key={idx}>
                      {/* Bar */}
                      <rect x={x} y={y} width={barWidth} height={height} fill="#2563eb" rx="0" />
                      {/* Label flow value */}
                      <text x={x + barWidth / 2} y={y - 4} fontSize="6" fontWeight="bold" fill="#0F172A" textAnchor="middle">
                        £{flow.toFixed(1)}M
                      </text>
                      {/* Label Year index */}
                      <text x={x + barWidth / 2} y="94" fontSize="6" fill="#94a3b8" textAnchor="middle">
                        YR {idx + 1}
                      </text>
                    </g>
                  );
                })}
              </svg>
            </div>

            <p className="text-[9px] text-gray-400 text-center font-mono uppercase tracking-tight leading-relaxed">
              Compounded annually. Underlying cashflows derived from commercial airport concession leases and aircraft movement terminal yields.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
