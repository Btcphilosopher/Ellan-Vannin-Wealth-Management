/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { DigitalTwinInfrastructure } from "../types";
import { Wrench, Eye, ShieldAlert, Sparkles, Plus, Calendar } from "lucide-react";

interface Props {
  airportCode: string;
}

export default function DigitalTwin({ airportCode }: Props) {
  const [twin, setTwin] = useState<DigitalTwinInfrastructure | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  // States for live simulation inside the digital twin
  const [terminalBoost, setTerminalBoost] = useState(false);
  const [runwayBoost, setRunwayBoost] = useState(false);

  useEffect(() => {
    setIsLoading(true);
    fetch(`/api/digital-twin/${airportCode}`)
      .then((res) => res.json())
      .then((data) => {
        setTwin(data);
        setIsLoading(false);
        setTerminalBoost(false);
        setRunwayBoost(false);
      })
      .catch((err) => {
        console.error(err);
        setIsLoading(false);
      });
  }, [airportCode]);

  if (isLoading || !twin) {
    return (
      <div className="flex items-center justify-center h-48 bg-white border border-[#E5E7EB] rounded-sm">
        <div className="text-gray-400 text-[10px] font-mono uppercase tracking-widest animate-pulse">Syncing with physical telemetry streams...</div>
      </div>
    );
  }

  // Calculate simulated live levels
  const currentTerminalUtil = terminalBoost 
    ? Math.max(20, Math.round(twin.terminalUtilisation * 0.7)) 
    : twin.terminalUtilisation;

  const currentRunwayUtil = runwayBoost 
    ? Math.max(25, Math.round(twin.runwayUtilisation * 0.75)) 
    : twin.runwayUtilisation;

  return (
    <div id="digital-twin-container" className="space-y-6">
      <div className="border-b border-[#E5E7EB] pb-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">Infrastructure Digital Twin</h1>
          <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Sovereign real-time telemetry model & asset inventory state for {airportCode}</p>
        </div>
        <div className="flex items-center gap-1.5 bg-blue-50 text-blue-700 border border-blue-200 px-2.5 py-1 rounded-sm text-[10px] font-mono font-bold uppercase">
          <Eye className="w-3.5 h-3.5" /> Telemetry synchronized
        </div>
      </div>

      {/* Grid: Assets Inventory & Gauges */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Left Column: Asset count inventory */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] border-b border-gray-100 pb-2">Physical Asset Ledger</h3>
          
          <div className="grid grid-cols-2 gap-3 text-xs font-mono">
            <div className="bg-gray-50 p-3 rounded-sm border border-gray-100 text-center">
              <span className="text-gray-400 block text-[9px] uppercase tracking-wider">Terminals</span>
              <span className="text-base font-bold text-[#0F172A]">{twin.terminalsCount}</span>
            </div>
            <div className="bg-gray-50 p-3 rounded-sm border border-gray-100 text-center">
              <span className="text-gray-400 block text-[9px] uppercase tracking-wider">Stands / Gates</span>
              <span className="text-base font-bold text-[#0F172A]">{twin.gatesCount}</span>
            </div>
            <div className="bg-gray-50 p-3 rounded-sm border border-gray-100 text-center">
              <span className="text-gray-400 block text-[9px] uppercase tracking-wider">Runways</span>
              <span className="text-base font-bold text-[#0F172A]">{twin.runwaysCount}</span>
            </div>
            <div className="bg-gray-50 p-3 rounded-sm border border-gray-100 text-center">
              <span className="text-gray-400 block text-[9px] uppercase tracking-wider">Aircraft Stands</span>
              <span className="text-base font-bold text-[#0F172A]">{twin.aircraftStands}</span>
            </div>
          </div>

          <div className="bg-[#0F172A] text-gray-300 p-4 rounded-sm text-xs font-mono space-y-2">
            <div className="font-bold text-white uppercase tracking-wider text-[10px]">Digital Calibration Engine</div>
            <p className="text-[9px] text-gray-400 uppercase tracking-tight leading-normal">Runway sensor alignment active. Telemetry samples ingested every 450ms from local ADS-B networks.</p>
          </div>
        </div>

        {/* Middle Column: Real-time Telemetry Gauges */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] border-b border-gray-100 pb-2">Operational Telemetry</h3>
          
          <div className="space-y-4">
            {/* Gauge 1 */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono uppercase">
                <span className="text-gray-400">Terminal Gate Congestion</span>
                <span className={currentTerminalUtil > 80 ? "text-red-600 font-bold" : "text-gray-700 font-bold"}>{currentTerminalUtil}%</span>
              </div>
              <div className="w-full bg-gray-100 h-1.5 rounded-sm overflow-hidden">
                <div 
                  className={`h-full rounded-sm transition-all duration-500 ${
                    currentTerminalUtil > 80 ? "bg-red-500" : "bg-emerald-500"
                  }`} 
                  style={{ width: `${currentTerminalUtil}%` }}
                ></div>
              </div>
            </div>

            {/* Gauge 2 */}
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] font-mono uppercase">
                <span className="text-gray-400">Runway Movements Capacity</span>
                <span className={currentRunwayUtil > 80 ? "text-red-600 font-bold" : "text-gray-700 font-bold"}>{currentRunwayUtil}%</span>
              </div>
              <div className="w-full bg-gray-100 h-1.5 rounded-sm overflow-hidden">
                <div 
                  className={`h-full rounded-sm transition-all duration-500 ${
                    currentRunwayUtil > 80 ? "bg-red-500" : "bg-emerald-500"
                  }`} 
                  style={{ width: `${currentRunwayUtil}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Sandbox Controls */}
          <div className="mt-4 pt-4 border-t border-gray-100 space-y-2 text-xs">
            <span className="font-bold text-gray-400 uppercase tracking-widest text-[9px] font-mono block">Simulate Expansion:</span>
            <div className="flex gap-2">
              <button
                onClick={() => setTerminalBoost(!terminalBoost)}
                className={`flex-1 py-1 px-2 rounded-sm text-[9px] font-mono font-bold uppercase border transition ${
                  terminalBoost 
                    ? "bg-emerald-50 text-emerald-700 border-emerald-300" 
                    : "bg-white text-gray-500 border-gray-200 hover:bg-gray-50"
                }`}
              >
                {terminalBoost ? "✓ Terminals Expanded" : "+ Expand Terminals"}
              </button>
              <button
                onClick={() => setRunwayBoost(!runwayBoost)}
                className={`flex-1 py-1 px-2 rounded-sm text-[9px] font-mono font-bold uppercase border transition ${
                  runwayBoost 
                    ? "bg-emerald-50 text-emerald-700 border-emerald-300" 
                    : "bg-white text-gray-500 border-gray-200 hover:bg-gray-50"
                }`}
              >
                {runwayBoost ? "✓ Runway Sited" : "+ Add Runway"}
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Maintenance calendars */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] border-b border-gray-100 pb-2">Maintenance Schedule</h3>
          
          <div className="space-y-2.5 overflow-y-auto max-h-[220px]">
            {twin.maintenanceSchedule.map((m, idx) => {
              const statusColor = 
                m.status === "Optimal" ? "text-emerald-700 bg-emerald-50 border-emerald-100" :
                m.status === "Pending" ? "text-amber-700 bg-amber-50 border-amber-100" :
                "text-red-700 bg-red-50 border-red-100";

              return (
                <div key={idx} className="p-2.5 bg-gray-50 rounded-sm border border-gray-100 text-xs">
                  <div className="flex justify-between items-start">
                    <span className="font-bold text-[#0F172A] leading-tight text-[11px] uppercase tracking-wide">{m.asset}</span>
                    <span className={`text-[8px] font-mono font-bold px-1.5 py-0.5 rounded-sm border uppercase tracking-wider ${statusColor}`}>
                      {m.status}
                    </span>
                  </div>
                  <div className="flex items-center gap-1 text-[9px] font-mono text-gray-400 uppercase tracking-wider mt-2">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>Next Checked: {m.nextScheduled}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
