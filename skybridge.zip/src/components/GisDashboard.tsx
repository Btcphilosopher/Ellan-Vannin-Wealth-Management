/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Airport, Route } from "../types";
import { Map, Layers, Target, Compass, CircleDot } from "lucide-react";

interface Props {
  airports: Airport[];
  routes: Route[];
}

// Map coordinates mapping for standard coordinate rendering
const GIS_COORDS: Record<string, { x: number; y: number }> = {
  LHR: { x: 260, y: 390 },
  LGW: { x: 275, y: 410 },
  MAN: { x: 200, y: 280 },
  EDI: { x: 170, y: 150 },
  BHX: { x: 215, y: 335 },
  IOM: { x: 130, y: 250 },
  BFS: { x: 90, y: 220 },
  GLA: { x: 145, y: 145 },
  ABZ: { x: 225, y: 90 },
  LBA: { x: 225, y: 265 },
  NCL: { x: 220, y: 225 },
  INV: { x: 165, y: 75 },
  CWL: { x: 165, y: 385 },
  LPL: { x: 190, y: 285 },
  SOU: { x: 235, y: 405 },
  EXT: { x: 160, y: 420 },
  NQY: { x: 110, y: 440 },
  HUY: { x: 245, y: 275 },
  EMA: { x: 230, y: 315 },
};

export default function GisDashboard({ airports, routes }: Props) {
  const [selectedApt, setSelectedApt] = useState<string | null>("IOM");
  const [assetFilter, setAssetFilter] = useState<string>("All");

  const clickedAirport = airports.find((a) => a.code === selectedApt);

  // Active routes emanating from selected airport
  const radiatingRoutes = routes.filter(
    (r) => r.origin === selectedApt || r.destination === selectedApt
  );

  return (
    <div id="gis-dashboard-container" className="space-y-6">
      <div className="border-b border-[#E5E7EB] pb-4">
        <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">GIS Infrastructure Dashboard</h1>
        <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Geographical maps, catchment buffers, and asset positioning parameters</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Columns: Large GIS Vector SVG Map */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm lg:col-span-2 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-widest text-[#0F172A]">Sovereign Geolocation Engine</h2>
              <p className="text-[10px] text-gray-400 uppercase tracking-tight font-mono mt-0.5">Click any airport to trace catchment buffers and routing linkages</p>
            </div>
            
            <div className="flex gap-2 text-xs">
              <select
                value={assetFilter}
                onChange={(e) => setAssetFilter(e.target.value)}
                className="bg-white border border-[#E5E7EB] rounded-sm px-2.5 py-1.5 focus:outline-none font-mono font-bold text-gray-600 uppercase text-[10px] tracking-wider"
              >
                <option value="All">All Assets</option>
                <option value="Sovereign Hub">Sovereign Hubs Only</option>
                <option value="Regional Critical">Regional Critical Only</option>
              </select>
            </div>
          </div>

          <div className="relative bg-black rounded-sm border border-black flex items-center justify-center p-4" style={{ height: "450px" }}>
            <svg viewBox="0 0 400 500" className="w-full h-full max-w-sm font-mono">
              {/* Plot Catchment Area Circle for selected airport */}
              {clickedAirport && GIS_COORDS[clickedAirport.code] && (
                <circle
                  cx={GIS_COORDS[clickedAirport.code].x}
                  cy={GIS_COORDS[clickedAirport.code].y}
                  r="45" // Representative 50km catchment area radius
                  fill="#2563eb"
                  fillOpacity="0.12"
                  stroke="#2563eb"
                  strokeWidth="1"
                  strokeDasharray="4 2"
                />
              )}

              {/* Render non-selected routes */}
              {routes.map((route) => {
                const start = GIS_COORDS[route.origin];
                const end = GIS_COORDS[route.destination];
                if (!start || !end) return null;

                const isRadiallySelected = route.origin === selectedApt || route.destination === selectedApt;
                if (isRadiallySelected) return null; // Draw selected routes in next layer

                return (
                  <line
                    key={route.id}
                    x1={start.x}
                    y1={start.y}
                    x2={end.x}
                    y2={end.y}
                    stroke="#1e293b"
                    strokeWidth="1"
                    opacity="0.4"
                  />
                );
              })}

              {/* Render active selected radiating routes in high-contrast overlay */}
              {radiatingRoutes.map((route) => {
                const start = GIS_COORDS[route.origin];
                const end = GIS_COORDS[route.destination];
                if (!start || !end) return null;

                return (
                  <line
                    key={route.id}
                    x1={start.x}
                    y1={start.y}
                    x2={end.x}
                    y2={end.y}
                    stroke="#2563eb"
                    strokeWidth="2"
                    opacity="0.9"
                  />
                );
              })}

              {/* Render Airports */}
              {airports
                .filter((a) => assetFilter === "All" || a.strategic_importance === assetFilter)
                .map((apt) => {
                  const coord = GIS_COORDS[apt.code];
                  if (!coord) return null;

                  const isSelected = apt.code === selectedApt;

                  return (
                    <g
                      key={apt.code}
                      transform={`translate(${coord.x}, ${coord.y})`}
                      onClick={() => setSelectedApt(apt.code)}
                      className="cursor-pointer"
                    >
                      <circle
                        r={isSelected ? 6 : 4}
                        fill={isSelected ? "#2563eb" : "#475569"}
                        stroke="#ffffff"
                        strokeWidth="1"
                      />
                      <text
                        y={-10}
                        textAnchor="middle"
                        fill={isSelected ? "#2563eb" : "#94a3b8"}
                        fontSize={8}
                        fontWeight="bold"
                      >
                        {apt.code}
                      </text>
                    </g>
                  );
                })}
            </svg>
          </div>
        </div>

        {/* Right Column: Catchment & Asset Parameters metadata panels */}
        <div className="space-y-6">
          {clickedAirport ? (
            <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] flex items-center gap-1.5 border-b border-gray-100 pb-2">
                <Target className="w-4 h-4 text-blue-600" />
                Catchment Assessment
              </h3>

              <div className="space-y-3 text-xs font-mono uppercase tracking-tight">
                <div>
                  <span className="text-gray-400 block font-sans text-[10px]">Focus Gateway:</span>
                  <span className="font-bold text-[#0F172A] text-[12px]">{clickedAirport.name} ({clickedAirport.code})</span>
                </div>
                <div>
                  <span className="text-gray-400 block font-sans text-[10px]">Regional Location:</span>
                  <span className="font-bold text-gray-700">{clickedAirport.region}</span>
                </div>
                <div>
                  <span className="text-gray-400 block font-sans text-[10px]">Total 50km Population Reach:</span>
                  <span className="font-bold text-gray-700">
                    {clickedAirport.strategic_importance === "Sovereign Hub" ? "6.8 Million" : clickedAirport.code === "IOM" ? "85,000" : "1.2 Million"}
                  </span>
                </div>
                <div>
                  <span className="text-gray-400 block font-sans text-[10px]">Proposed GIS Investment:</span>
                  <span className="font-bold text-blue-700 bg-blue-50 border border-blue-100 px-2 py-1 rounded-sm inline-block mt-1 text-[10px] tracking-wide">
                    {clickedAirport.utilisation > 0.80 ? "Terminal Apron Extension" : "Hangar Retrofitting"}
                  </span>
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm text-center py-12">
              <p className="text-gray-400 text-[10px] font-mono uppercase tracking-wider">Select any airport node to analyze catchment coordinates.</p>
            </div>
          )}

          {/* Radiating Links Panel */}
          {clickedAirport && radiatingRoutes.length > 0 && (
            <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-3">
              <h4 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] flex items-center gap-1 border-b border-gray-100 pb-2">
                <Compass className="w-4 h-4 text-blue-600" /> Direct Connected Corridors
              </h4>
              <div className="space-y-2 text-xs font-mono max-h-[160px] overflow-y-auto uppercase tracking-tight">
                {radiatingRoutes.map((r) => (
                  <div key={r.id} className="p-2 bg-gray-50 border border-gray-100 rounded-sm flex justify-between items-center">
                    <span className="font-bold text-gray-700">{r.origin} ➔ {r.destination}</span>
                    <span className="text-[9px] text-gray-400">{r.distance_km} km • {r.frequency_weekly}x/wk</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
