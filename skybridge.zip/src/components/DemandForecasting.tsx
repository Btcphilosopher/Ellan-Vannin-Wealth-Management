/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Airport } from "../types";
import { TrendingUp, Percent, Filter, DollarSign } from "lucide-react";

interface Props {
  airports: Airport[];
}

export default function DemandForecasting({ airports }: Props) {
  const [selectedCode, setSelectedCode] = useState("IOM"); // Default Isle of Man
  
  // Statistical Growth Parameters
  const [gdpGrowth, setGdpGrowth] = useState(1.8); // 1.8%
  const [tourismFactor, setTourismFactor] = useState(1.1); // +10%
  const [businessFactor, setBusinessFactor] = useState(1.0); // Neutral
  const [populationGrowth, setPopulationGrowth] = useState(0.5); // 0.5%

  const activeAirport = airports.find((a) => a.code === selectedCode) || airports[0];

  // Calculate 10-Year Projections dynamically
  const years = [2026, 2027, 2028, 2029, 2030, 2031, 2032, 2033, 2034, 2035];
  
  const generateScenarioData = (scenario: "Baseline" | "Optimistic" | "Downside") => {
    let currentPax = activeAirport.annual_passengers;
    
    // Adjust base rates depending on scenario
    let growthRateModifier = 0;
    if (scenario === "Optimistic") {
      growthRateModifier = 0.015; // Extra +1.5%
    } else if (scenario === "Downside") {
      growthRateModifier = -0.02; // Downside -2.0%
    }

    // Combine rates
    const annualCompoundRate = 
      ((gdpGrowth / 100) * 0.4) + 
      ((populationGrowth / 100) * 0.3) + 
      ((tourismFactor - 1.0) * 0.2) + 
      ((businessFactor - 1.0) * 0.1) + 
      growthRateModifier;

    return years.map((year, idx) => {
      currentPax = Math.round(currentPax * (1.0 + annualCompoundRate));
      return {
        year,
        pax: currentPax,
      };
    });
  };

  const baselineData = generateScenarioData("Baseline");
  const optimisticData = generateScenarioData("Optimistic");
  const downsideData = generateScenarioData("Downside");

  // Determine max projection to scale SVG chart coordinates
  const allPaxValues = [
    ...baselineData.map((d) => d.pax),
    ...optimisticData.map((d) => d.pax),
    ...downsideData.map((d) => d.pax),
  ];
  const maxPaxVal = Math.max(...allPaxValues);
  const minPaxVal = Math.min(...allPaxValues);

  return (
    <div id="demand-forecasting-container" className="space-y-6">
      <div className="border-b border-[#E5E7EB] pb-4">
        <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">Passenger Demand Forecasting</h1>
        <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Multi-scenario statistical modeling for civil aviation infrastructure demand over a 10-year horizon</p>
      </div>

      {/* Inputs Header Selector */}
      <div className="bg-white p-4 border border-[#E5E7EB] rounded-sm flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex flex-wrap items-center gap-2">
          <Filter className="w-4 h-4 text-blue-600" />
          <span className="text-[11px] font-bold uppercase tracking-wider text-gray-500">Forecast Airport Target:</span>
          <select
            value={selectedCode}
            onChange={(e) => setSelectedCode(e.target.value)}
            className="text-xs bg-white border border-[#E5E7EB] rounded-sm px-2.5 py-1 font-mono font-bold text-blue-600 focus:outline-none"
          >
            {airports.map((a) => (
              <option key={a.code} value={a.code}>
                {a.code} - {a.name} (Base: {(a.annual_passengers/1000).toFixed(0)}k)
              </option>
            ))}
          </select>
        </div>
        <span className="text-[10px] text-gray-400 font-mono uppercase tracking-wider">Sector: {activeAirport.region} • National Impact</span>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column: Macroeconomic Modifiers */}
        <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-5">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] border-b border-gray-100 pb-2">Macroeconomic Indicators</h2>

          <div className="space-y-4">
            {/* Control 1 */}
            <div>
              <div className="flex justify-between text-[10px] font-bold font-mono uppercase mb-1">
                <span className="text-gray-400 font-sans">GDP Growth Assumption</span>
                <span className="text-blue-600 font-bold">{gdpGrowth}%</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="5.0"
                step="0.1"
                value={gdpGrowth}
                onChange={(e) => setGdpGrowth(Number(e.target.value))}
                className="w-full h-1 bg-gray-200 rounded-sm appearance-none cursor-pointer accent-blue-600"
              />
            </div>

            {/* Control 2 */}
            <div>
              <div className="flex justify-between text-[10px] font-bold font-mono uppercase mb-1">
                <span className="text-gray-400 font-sans">Tourism Growth Index</span>
                <span className="text-blue-600 font-bold">{(tourismFactor * 100 - 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="1.5"
                step="0.05"
                value={tourismFactor}
                onChange={(e) => setTourismFactor(Number(e.target.value))}
                className="w-full h-1 bg-gray-200 rounded-sm appearance-none cursor-pointer accent-blue-600"
              />
            </div>

            {/* Control 3 */}
            <div>
              <div className="flex justify-between text-[10px] font-bold font-mono uppercase mb-1">
                <span className="text-gray-400 font-sans">Business Travel Modifier</span>
                <span className="text-blue-600 font-bold">{(businessFactor * 100 - 100).toFixed(0)}%</span>
              </div>
              <input
                type="range"
                min="0.5"
                max="1.5"
                step="0.05"
                value={businessFactor}
                onChange={(e) => setBusinessFactor(Number(e.target.value))}
                className="w-full h-1 bg-gray-200 rounded-sm appearance-none cursor-pointer accent-blue-600"
              />
            </div>

            {/* Control 4 */}
            <div>
              <div className="flex justify-between text-[10px] font-bold font-mono uppercase mb-1">
                <span className="text-gray-400 font-sans">Demographic Growth</span>
                <span className="text-blue-600 font-bold">{populationGrowth}%</span>
              </div>
              <input
                type="range"
                min="0.0"
                max="2.0"
                step="0.1"
                value={populationGrowth}
                onChange={(e) => setPopulationGrowth(Number(e.target.value))}
                className="w-full h-1 bg-gray-200 rounded-sm appearance-none cursor-pointer accent-blue-600"
              />
            </div>
          </div>
        </div>

        {/* Right 2 Columns: Scenic Line graph */}
        <div className="lg:col-span-2 bg-white p-6 border border-[#E5E7EB] rounded-sm space-y-4">
          <h2 className="text-xs font-bold uppercase tracking-widest text-[#0F172A] flex items-center gap-1.5 border-b border-gray-100 pb-2">
            <TrendingUp className="w-4 h-4 text-blue-600" /> 10-Year Scenic Growth Projections (2026-2035)
          </h2>

          <div className="relative h-64 w-full flex items-center justify-center">
            {/* Line plot SVG */}
            <svg className="w-full h-full max-w-lg font-mono" viewBox="0 0 400 200">
              {/* Axes */}
              <line x1="45" y1="170" x2="380" y2="170" stroke="#E5E7EB" strokeWidth="1" />
              <line x1="45" y1="20" x2="45" y2="170" stroke="#E5E7EB" strokeWidth="1" />

              {/* Gridlines */}
              <line x1="45" y1="95" x2="380" y2="95" stroke="#F3F4F6" strokeDasharray="2 2" />
              <line x1="45" y1="45" x2="380" y2="45" stroke="#F3F4F6" strokeDasharray="2 2" />

              {(() => {
                // Mapping helpers
                // Map Year (2026-2035) to X (50 to 370)
                // Map Pax (minPaxVal * 0.9 to maxPaxVal * 1.1) to Y (160 to 30)
                const getX = (year: number) => 50 + (year - 2026) * 35;
                const getY = (pax: number) => {
                  const range = maxPaxVal * 1.05 - minPaxVal * 0.95;
                  if (range === 0) return 100;
                  return 160 - ((pax - minPaxVal * 0.95) / range) * 130;
                };

                const plotLine = (data: typeof baselineData, color: string) => {
                  const pts = data.map((d) => `${getX(d.year)} ${getY(d.pax)}`).join(" L ");
                  return <path d={`M ${pts}`} fill="none" stroke={color} strokeWidth="1.8" strokeLinecap="square" />;
                };

                return (
                  <g>
                    {/* Optimistic Scenario (Emerald) */}
                    {plotLine(optimisticData, "#10b981")}
                    {/* Baseline Scenario (Blue) */}
                    {plotLine(baselineData, "#2563eb")}
                    {/* Downside Scenario (Red) */}
                    {plotLine(downsideData, "#ef4444")}

                    {/* Simple axis label */}
                    <text x="50" y="185" fontSize="8" fill="#94a3b8" textAnchor="middle">2026</text>
                    <text x="212" y="185" fontSize="8" fill="#94a3b8" textAnchor="middle">2030</text>
                    <text x="365" y="185" fontSize="8" fill="#94a3b8" textAnchor="middle">2035</text>
                  </g>
                );
              })()}
            </svg>
          </div>

          {/* Legend indicator bar */}
          <div className="flex flex-wrap justify-center gap-6 text-[10px] font-mono uppercase tracking-wider pt-4 border-t border-gray-100">
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-emerald-500 rounded-sm"></span>
              <span className="text-gray-500">Optimistic Horizon</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-blue-600 rounded-sm"></span>
              <span className="text-gray-500">Baseline Target</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 bg-red-500 rounded-sm"></span>
              <span className="text-gray-500">Downside Trend</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
