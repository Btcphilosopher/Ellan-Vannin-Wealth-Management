/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Airport, Route } from "../types";
import { GitBranch, Activity, Link2, Compass, AlertCircle, ShieldAlert } from "lucide-react";

interface Props {
  airports: Airport[];
  routes: Route[];
  connectivityScore: number;
}

// Approximate coordinate positions for UK airports to render an elegant custom SVG map
const AIRPORT_COORDS: Record<string, { x: number; y: number }> = {
  LHR: { x: 260, y: 390 },
  LGW: { x: 275, y: 410 },
  MAN: { x: 200, y: 280 },
  EDI: { x: 170, y: 150 },
  BHX: { x: 215, y: 335 },
  IOM: { x: 130, y: 250 }, // Ronaldsway
  BFS: { x: 90, y: 220 },
  GLA: { x: 145, y: 145 },
  ABZ: { x: 225, y: 90 },
  LBA: { x: 225, y: 265 },
  NCL: { x: 220, y: 225 },
  INV: { x: 165, y: 75 },
  CWL: { x: 165, y: 385 },
  LPL: { x: 190, y: 285 },
  SOU: { x: 235, y: 405 },
  EXT: { x: 160, y: 420 },
  NQY: { x: 110, y: 440 },
  HUY: { x: 245, y: 275 },
  EMA: { x: 230, y: 315 },
};

export default function RouteEngine({ airports, routes, connectivityScore }: Props) {
  const [origin, setOrigin] = useState("MAN");
  const [destination, setDestination] = useState("INV");
  const [failedNode, setFailedNode] = useState<string | null>(null);

  // Dijkstra Shortest Path Finder (conceptual implementation in frontend)
  const computeShortestPath = (start: string, end: string, decommissioned: string | null) => {
    if (start === end) return { path: [start], distance: 0, time: 0 };
    if (start === decommissioned || end === decommissioned) return null;

    // Filter out routes that involve decommissioned node
    const activeRoutes = routes.filter(
      (r) => r.origin !== decommissioned && r.destination !== decommissioned
    );

    // Build adjacency map
    const adj: Record<string, { node: string; dist: number; time: number; id: string }[]> = {};
    airports.forEach((a) => {
      adj[a.code] = [];
    });

    activeRoutes.forEach((r) => {
      if (!adj[r.origin]) adj[r.origin] = [];
      adj[r.origin].push({ node: r.destination, dist: r.distance_km, time: r.block_time_mins, id: r.id });
      // Add bi-directional representation for completeness if not exists
      if (!adj[r.destination]) adj[r.destination] = [];
      adj[r.destination].push({ node: r.origin, dist: r.distance_km, time: r.block_time_mins, id: r.id });
    });

    // Dijkstra's
    const dists: Record<string, number> = {};
    const times: Record<string, number> = {};
    const prev: Record<string, string | null> = {};
    const q = new Set<string>();

    airports.forEach((a) => {
      dists[a.code] = Infinity;
      times[a.code] = Infinity;
      prev[a.code] = null;
      q.add(a.code);
    });

    dists[start] = 0;
    times[start] = 0;

    while (q.size > 0) {
      // Find min dist node in Q
      let minNode: string | null = null;
      q.forEach((node) => {
        if (minNode === null || dists[node] < dists[minNode]) {
          minNode = node;
        }
      });

      if (minNode === null || dists[minNode] === Infinity) break;
      if (minNode === end) break;

      q.delete(minNode);

      const neighbors = adj[minNode] || [];
      for (const edge of neighbors) {
        if (!q.has(edge.node)) continue;
        const alt = dists[minNode] + edge.dist;
        if (alt < dists[edge.node]) {
          dists[edge.node] = alt;
          times[edge.node] = times[minNode] + edge.time;
          prev[edge.node] = minNode;
        }
      }
    }

    if (dists[end] === Infinity) return null;

    // Reconstruct path
    const path: string[] = [];
    let curr: string | null = end;
    while (curr !== null) {
      path.unshift(curr);
      curr = prev[curr];
    }

    return {
      path,
      distance: dists[end],
      time: times[end],
    };
  };

  const pathResult = computeShortestPath(origin, destination, failedNode);

  // Calculate Resilience Index (percentage of connected nodes)
  const activeAirports = airports.filter((a) => a.code !== failedNode);
  const totalPossiblePairs = (activeAirports.length * (activeAirports.length - 1)) / 2;
  
  // Estimate connected pairs
  let connectedPairs = 0;
  for (let i = 0; i < activeAirports.length; i++) {
    for (let j = i + 1; j < activeAirports.length; j++) {
      const pathExists = computeShortestPath(activeAirports[i].code, activeAirports[j].code, failedNode);
      if (pathExists) connectedPairs++;
    }
  }
  const resiliencePercentage = totalPossiblePairs > 0 ? (connectedPairs / totalPossiblePairs) * 100 : 100;

  return (
    <div id="route-engine-container" className="space-y-6">
      <div className="border-b border-[#E5E7EB] pb-4">
        <h1 className="text-xl font-bold tracking-tighter text-[#0F172A]">Domestic Route Network Engine</h1>
        <p className="text-[10px] text-gray-400 mt-1 uppercase tracking-widest font-semibold">Sovereign graph modeling of UK domestic connections and network-wide resilience</p>
      </div>

      {/* Grid of tools */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Hand: Interactive SVG Graph View */}
        <div className="bg-white p-6 border border-[#E5E7EB] rounded-sm lg:col-span-2">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-xs font-bold uppercase tracking-wider text-[#0F172A]">UK Domestic Connectivity Graph</h2>
              <p className="text-[10px] text-gray-400 mt-0.5">Geometrical representation of active flight paths & hubs</p>
            </div>
            {failedNode && (
              <div className="flex items-center gap-1.5 bg-red-50 text-red-700 px-2.5 py-1 rounded-sm text-[10px] font-mono font-bold border border-red-200 uppercase">
                <ShieldAlert className="w-3 h-3" /> Failure: {failedNode}
              </div>
            )}
          </div>

          <div className="relative bg-black rounded-sm overflow-hidden flex items-center justify-center border border-black" style={{ height: "480px" }}>
            {/* Background elements */}
            <div className="absolute top-4 left-4 text-left">
              <span className="text-[9px] uppercase font-bold tracking-widest text-gray-500 font-mono">System Topology</span>
              <div className="text-[10px] text-gray-400 mt-1 font-mono">MAN Backbone: MAN ➔ LBA ➔ NCL ➔ EDI ➔ ABZ ➔ INV</div>
            </div>

            <svg viewBox="0 0 400 500" className="w-full h-full max-w-md opacity-90">
              {/* Concept land shadow */}
              <path
                d="M 120 40 C 130 50, 150 50, 160 60 C 170 80, 150 110, 140 130 C 130 150, 150 160, 120 180 C 100 200, 70 200, 80 230 C 100 240, 140 240, 150 250 C 170 270, 180 300, 160 330 C 150 360, 140 370, 150 400 C 160 410, 120 450, 100 460 C 130 465, 170 450, 190 440 C 230 430, 260 430, 290 410 C 310 370, 290 320, 270 300 C 250 280, 260 250, 250 220 C 240 180, 240 140, 210 120 C 200 100, 180 80, 170 40 Z"
                fill="#1e293b"
                opacity="0.1"
              />

              {/* Render Routes (Edges) */}
              {routes.map((route) => {
                const start = AIRPORT_COORDS[route.origin];
                const end = AIRPORT_COORDS[route.destination];
                if (!start || !end) return null;

                const isPathActive = pathResult?.path.includes(route.origin) && pathResult?.path.includes(route.destination);
                const isDecommissioned = route.origin === failedNode || route.destination === failedNode;

                return (
                  <line
                    key={route.id}
                    x1={start.x}
                    y1={start.y}
                    x2={end.x}
                    y2={end.y}
                    stroke={isDecommissioned ? "#ef4444" : isPathActive ? "#3b82f6" : "#334155"}
                    strokeWidth={isPathActive ? 2.5 : 1}
                    strokeDasharray={isDecommissioned ? "4 4" : isPathActive ? "0" : "2 2"}
                    opacity={isDecommissioned ? 0.2 : isPathActive ? 1.0 : 0.4}
                  />
                );
              })}

              {/* Render Airports (Nodes) */}
              {Object.keys(AIRPORT_COORDS).map((code) => {
                const coord = AIRPORT_COORDS[code];
                const apt = airports.find((a) => a.code === code);
                if (!coord || !apt) return null;

                const isDecommissioned = code === failedNode;
                const isSelectedOnPath = pathResult?.path.includes(code);

                return (
                  <g key={code} transform={`translate(${coord.x}, ${coord.y})`} className="cursor-pointer">
                    <circle
                      r={isDecommissioned ? 3.5 : isSelectedOnPath ? 7 : 4.5}
                      fill={isDecommissioned ? "#ef4444" : isSelectedOnPath ? "#3b82f6" : "#10b981"}
                      stroke="#ffffff"
                      strokeWidth={1.2}
                    />
                    <text
                      y={-8}
                      textAnchor="middle"
                      fill={isDecommissioned ? "#ef4444" : isSelectedOnPath ? "#ffffff" : "#64748b"}
                      fontSize={9}
                      fontWeight={isSelectedOnPath ? "bold" : "normal"}
                      fontFamily="monospace"
                    >
                      {code}
                    </text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        {/* Right Hand: Shortest Path Routing and Resilience Calculator */}
        <div className="space-y-6">
          {/* Section 1: Router tool */}
          <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-4">
            <h3 className="text-[11px] font-bold uppercase tracking-widest text-[#0F172A] flex items-center gap-1.5 border-b border-gray-100 pb-2">
              <Compass className="w-3.5 h-3.5 text-blue-600" />
              Sovereign Path Router
            </h3>
            <p className="text-[10px] text-gray-400 uppercase tracking-wider font-mono">Compute shortest routing and flying hours over the domestic graph</p>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Departure</label>
                <select
                  value={origin}
                  onChange={(e) => setOrigin(e.target.value)}
                  className="w-full text-xs bg-white border border-[#E5E7EB] rounded-sm p-1.5 focus:outline-none"
                >
                  {airports.map((a) => (
                    <option key={a.code} value={a.code}>
                      {a.code} - {a.name}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Arrival</label>
                <select
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  className="w-full text-xs bg-white border border-[#E5E7EB] rounded-sm p-1.5 focus:outline-none"
                >
                  {airports.map((a) => (
                    <option key={a.code} value={a.code}>
                      {a.code} - {a.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Results */}
            {pathResult ? (
              <div className="bg-gray-50 p-4 border border-gray-100 rounded-sm text-xs space-y-2">
                <div className="flex justify-between font-semibold">
                  <span className="text-gray-400 font-mono text-[10px] uppercase">Routing Path:</span>
                  <span className="text-blue-600 font-bold font-mono text-xs">{pathResult.path.join(" ➔ ")}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400 font-mono text-[10px] uppercase">Route Distance:</span>
                  <span className="font-semibold text-gray-800">{pathResult.distance} km</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400 font-mono text-[10px] uppercase">Est. Flight Duration:</span>
                  <span className="font-semibold text-gray-800">{pathResult.time} mins</span>
                </div>
              </div>
            ) : (
              <div className="bg-red-50 p-3 border border-red-100 rounded-sm text-[10px] font-mono uppercase text-red-700 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5 shrink-0" /> Route disconnected or blocked.
              </div>
            )}
          </div>

          {/* Section 2: Resilience Simulator */}
          <div className="bg-white p-5 border border-[#E5E7EB] rounded-sm space-y-4">
            <h3 className="text-[11px] font-bold uppercase tracking-widest text-[#0F172A] flex items-center gap-1.5 border-b border-gray-100 pb-2">
              <GitBranch className="w-3.5 h-3.5 text-blue-600" />
              Network Resilience Index
            </h3>
            <p className="text-[10px] text-gray-400 uppercase tracking-wider font-mono">Decommission or close any airport node to analyze structural graph fragility</p>

            <div>
              <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-1">Simulate Failure of Node:</label>
              <select
                value={failedNode || ""}
                onChange={(e) => setFailedNode(e.target.value || null)}
                className="w-full text-xs bg-white border border-[#E5E7EB] rounded-sm p-1.5 focus:outline-none"
              >
                <option value="">-- No Failure (Fully Operational) --</option>
                {airports.map((a) => (
                  <option key={a.code} value={a.code}>
                    {a.code} - {a.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="p-4 bg-gray-50 border border-gray-100 rounded-sm space-y-3">
              <div className="flex justify-between items-center text-xs">
                <span className="text-gray-500 font-mono text-[10px] uppercase">Resilience Index:</span>
                <span className={`font-mono text-xs font-bold px-2 py-0.5 rounded-sm ${
                  resiliencePercentage > 85 ? "text-emerald-700 bg-emerald-50" : "text-red-700 bg-red-50"
                }`}>
                  {resiliencePercentage.toFixed(1)}%
                </span>
              </div>
              <div className="w-full bg-gray-200 h-1 rounded-sm overflow-hidden">
                <div
                  className={`h-full rounded-sm transition-all duration-300 ${
                    resiliencePercentage > 85 ? "bg-emerald-500" : "bg-red-500"
                  }`}
                  style={{ width: `${resiliencePercentage}%` }}
                ></div>
              </div>
              <p className="text-[10px] text-gray-400 leading-relaxed font-mono uppercase tracking-tight">
                {failedNode
                  ? `Simulating closure of ${failedNode}. System accessibility index is impacted. Active flight linkages are severed, forcing longer connecting hops.`
                  : "All regional sovereign connections online. Complete multi-path redundancies verified."}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
